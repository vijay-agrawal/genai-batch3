"""
pydantic_demos.py
───────────────────────────────────────────────────────────────────────────────
HPE Infrastructure demos of Pydantic — from basic models to LLM-powered
structured output using Amazon Bedrock (Nova Micro).

WHAT THIS FILE COVERS
─────────────────────
1. Basic Pydantic model — Server asset schema with auto type coercion
2. Validation Error     — Bad telemetry data caught before it reaches pipelines
3. Optional fields      — Sensible defaults for newly provisioned servers
4. Nested models        — Server with embedded Metrics and RackLocation
5. Custom validators    — Domain rules (firmware version format, temp range, power draw)
6. Serialization        — model → JSON and JSON → model round-trip (CMDB export)
7. LLM + Pydantic (Extraction)  — LLM reads an HPE IML log entry and pulls out
                        structured fields that already exist in the text
8. LLM + Pydantic (Generation)  — LLM reads an incident description and reasons
                        about severity, root cause, and recommended remediation


RUN
───
pip install pydantic boto3 python-dotenv
python pydantic_demos.py

Prereqs: .env file in project root with AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY
"""

# ── Standard + third-party imports ───────────────────────────────────────────
import json
import re
import os
from typing import Optional
from dotenv import load_dotenv

from pydantic import BaseModel, Field, field_validator, ValidationError

load_dotenv()

def strip_markdown_json(text: str) -> str:
    """
    LLMs often wrap JSON in markdown fences like:
        ```json
        { ... }
        ```
    Pydantic's model_validate_json expects raw JSON with no surrounding text.
    This helper strips those fences so validation works correctly.
    """
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 1 — Basic Pydantic Model (Server Asset)
#
# Key concept: define a class that inherits BaseModel.
# Each class attribute becomes a validated, typed field.
# Pydantic will COERCE compatible types (e.g. "2" → 2 for an int field).
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 1 — Basic Server Asset Model (type coercion)")
print("═" * 60)
print("Story: The HPE OneView REST API returns server inventory data.")
print("The API sends 'cpu_count' as the string '2' instead of an integer.")
print("Pydantic quietly fixes this — no manual casting needed.\n")

class Server(BaseModel):
    server_id: str      # HPE serial number e.g. "MXQ92340017"
    model: str          # e.g. "HPE ProLiant DL380 Gen11"
    cpu_count: int      # "2" as a string will be coerced to int 2
    status: str         # "online" | "degraded" | "offline"


raw_data = {
    "server_id": "MXQ92340017",
    "model": "HPE ProLiant DL380 Gen11",
    "cpu_count": "2",       # <-- string from API, coerced to int
    "status": "online"
}

server = Server(**raw_data)
print(f"✔ Server asset registered:")
print(f"  Server ID   : {server.server_id}")
print(f"  Model       : {server.model}")
print(f"  CPU Count   : {server.cpu_count}  ← was string '2', coerced to {type(server.cpu_count).__name__}")
print(f"  Status      : {server.status}")
print(f"\n  Full model repr: {server}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 2 — Validation Error
#
# Key concept: if incoming data is INCOMPATIBLE (not coercible), Pydantic
# raises a ValidationError with a clear, structured error message.
# Bad telemetry is caught BEFORE it reaches monitoring pipelines or the CMDB.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 2 — Validation Error (bad telemetry caught at the gate)")
print("═" * 60)
print("Story: A monitoring agent sends a garbled telemetry record —")
print("power_watts is the string 'two-fifty' instead of a number.")
print("Pydantic refuses and tells us exactly which field failed and why.\n")

class ServerTelemetry(BaseModel):
    server_id: str
    cpu_util_pct: float
    power_watts: int      # must be numeric — "two-fifty" cannot convert
    inlet_temp_c: float


bad_telemetry = {
    "server_id": "MXQ92340017",
    "cpu_util_pct": 78.4,
    "power_watts": "two-fifty",   # <-- cannot convert to int → ValidationError
    "inlet_temp_c": 36.2
}

try:
    bad_reading = ServerTelemetry(**bad_telemetry)
except ValidationError as e:
    print("✘ Telemetry record rejected — validation failed (expected):")
    for err in e.errors():
        print(f"  Field : {err['loc']}")
        print(f"  Error : {err['msg']}")
    print("\n  ↳ The bad record never reached the monitoring pipeline. Data integrity preserved.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 3 — Optional Fields & Default Values
#
# Key concept: wrap a type with Optional[X] to allow None, and use
# Field(default=...) to provide fallback values.
# Useful when iLO hasn't fully reported in yet for a newly racked server.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 3 — Optional Fields & Defaults")
print("═" * 60)
print("Story: A new HPE ProLiant server is racked and cabled but not yet")
print("fully provisioned — firmware version is unknown, no team assigned,")
print("not yet accepting production workloads.")
print("The model accepts partial data and fills in sensible defaults.\n")

class ProvisionedServer(BaseModel):
    server_id: str
    model: str
    datacenter: str

    firmware_version: Optional[str] = None       # unknown until iLO first checks in
    assigned_team: Optional[str] = None          # not yet assigned
    is_active: bool = False                      # not yet in production
    environment: str = Field(default="staging", description="Target environment")


# Minimal registration — just what we know at rack-and-stack time
new_server = ProvisionedServer(
    server_id="CZ23456789",
    model="HPE ProLiant DL360 Gen11",
    datacenter="AMS-DC1"
)
print(f"✔ New server registered at rack time (minimal data):")
print(f"  Server ID       : {new_server.server_id}")
print(f"  Model           : {new_server.model}")
print(f"  Firmware        : {new_server.firmware_version}  ← unknown until iLO connects")
print(f"  Team            : {new_server.assigned_team}  ← not yet assigned")
print(f"  Active?         : {new_server.is_active}  ← staging, not live yet")
print(f"  Environment     : {new_server.environment}  ← defaults to staging")

# Full record after provisioning is complete
prod_server = ProvisionedServer(
    server_id="MXQ92340017",
    model="HPE ProLiant DL380 Gen11",
    datacenter="SJC-DC3",
    firmware_version="3.10.00.00",
    assigned_team="GreenLake-Ops",
    is_active=True,
    environment="production"
)
print(f"\n✔ Same server after full provisioning:")
print(f"  Server ID       : {prod_server.server_id}")
print(f"  Firmware        : {prod_server.firmware_version}")
print(f"  Team            : {prod_server.assigned_team}")
print(f"  Active?         : {prod_server.is_active}  ← now live")
print(f"  Environment     : {prod_server.environment}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 4 — Nested Models
#
# Key concept: embed one Pydantic model inside another to represent
# hierarchical data (a server HAS metrics, HAS a rack location).
# Pydantic validates the nested model recursively.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 4 — Nested Models (Metrics + RackLocation inside Server)")
print("═" * 60)
print("Story: The HPE OneView API returns a full server record —")
print("real-time performance metrics AND physical rack location for")
print("capacity planning and on-site dispatch. Each sub-record is its")
print("own Pydantic model, validated independently.\n")

class ServerMetrics(BaseModel):
    """Real-time telemetry pulled from iLO."""
    cpu_util_pct: float        # 0.0–100.0 %
    power_watts: int           # current draw in watts
    inlet_temp_celsius: float  # ambient temp at server air intake
    memory_used_gb: float      # RAM in use

class RackLocation(BaseModel):
    """Physical location — used for on-site maintenance dispatch."""
    datacenter: str
    rack_id: str
    unit_position: int         # starting U position in the rack

class FullServer(BaseModel):
    server_id: str
    model: str
    firmware_version: str
    metrics: ServerMetrics     # ← nested Pydantic model
    location: RackLocation     # ← another nested model
    workload: str = "unassigned"


server_data = {
    "server_id": "MXQ92340017",
    "model": "HPE ProLiant DL380 Gen11",
    "firmware_version": "3.10.00.00",
    "metrics": {               # dict is auto-converted to ServerMetrics model
        "cpu_util_pct": 87.3,
        "power_watts": 420,
        "inlet_temp_celsius": 38.0,
        "memory_used_gb": 192.5
    },
    "location": {              # dict is auto-converted to RackLocation model
        "datacenter": "SJC-DC3",
        "rack_id": "R12",
        "unit_position": 4
    },
    "workload": "GreenLake Compute"
}

fs = FullServer(**server_data)
print(f"✔ Full server record built with nested sub-models:")
print(f"  Server     : {fs.server_id} ({fs.model})")
print(f"  Firmware   : {fs.firmware_version}")
print(f"  Metrics    → CPU: {fs.metrics.cpu_util_pct}%, Power: {fs.metrics.power_watts}W, "
      f"Inlet: {fs.metrics.inlet_temp_celsius}°C, Mem: {fs.metrics.memory_used_gb} GB")
print(f"  Location   → {fs.location.datacenter}, Rack {fs.location.rack_id}, U{fs.location.unit_position}")
print(f"  Workload   : {fs.workload}")
print(f"\n  ↳ fs.metrics and fs.location are full Pydantic objects, not plain dicts.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 5 — Custom Field Validators
#
# Key concept: @field_validator lets you add domain-specific rules that go
# beyond type checking. Example: firmware version must match HPE's format,
# CPU utilisation must be 0-100%, power draw must be in a plausible range.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 5 — Custom Field Validators")
print("═" * 60)
print("Story: Monitoring agents sometimes send impossible values —")
print("CPU at 150%, power draw of 50,000W, or a firmware version written")
print("as '3-10-00'. Custom validators catch these before they corrupt the")
print("CMDB or trigger false escalation alerts.\n")

class ValidatedServer(BaseModel):
    server_id: str
    cpu_util_pct: float
    power_watts: int
    firmware_version: str    # HPE format: N.NN.NN.NN e.g. "3.10.00.00"
    inlet_temp_celsius: float

    @field_validator("cpu_util_pct")
    @classmethod
    def check_cpu(cls, v):
        if not (0.0 <= v <= 100.0):
            raise ValueError(f"CPU utilisation {v}% is outside valid range 0–100")
        return v

    @field_validator("power_watts")
    @classmethod
    def check_power(cls, v):
        if not (50 <= v <= 10000):
            raise ValueError(
                f"Power draw {v}W is outside plausible server range (50–10000W)"
            )
        return v

    @field_validator("firmware_version")
    @classmethod
    def check_firmware_format(cls, v):
        # HPE iLO firmware version format: integer.integer.integer.integer
        pattern = r"^\d+\.\d+\.\d+\.\d+$"
        if not re.match(pattern, v):
            raise ValueError(
                f"firmware_version '{v}' must be in 'X.XX.XX.XX' format e.g. '3.10.00.00'"
            )
        return v

    @field_validator("inlet_temp_celsius")
    @classmethod
    def check_temp(cls, v):
        if not (0.0 <= v <= 55.0):
            raise ValueError(f"Inlet temp {v}°C is outside plausible range (0–55°C)")
        return v


# Valid record
try:
    vs = ValidatedServer(
        server_id="MXQ92340017",
        cpu_util_pct=87.3,
        power_watts=420,
        firmware_version="3.10.00.00",
        inlet_temp_celsius=38.0
    )
    print(f"✔ Valid telemetry record accepted:")
    print(f"  {vs}")
except ValidationError as e:
    print(f"Unexpected error: {e}")

# Invalid record — bad CPU%, impossible power, wrong firmware format
print("\n✘ Corrupted record (cpu=150%, power=50000W, firmware='3-10-00') — rejected:")
try:
    bad_vs = ValidatedServer(
        server_id="MXQ92340017",
        cpu_util_pct=150.0,          # fails cpu validator
        power_watts=50000,           # fails power validator
        firmware_version="3-10-00",  # fails firmware format validator
        inlet_temp_celsius=38.0
    )
except ValidationError as e:
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
    print("\n  ↳ All three domain-specific rules fired. Record blocked.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 6 — Serialization: model → JSON and JSON → model
#
# Key concept: Pydantic models have built-in methods for serialization.
#   model.model_dump()       → Python dict
#   model.model_dump_json()  → JSON string
#   Model.model_validate()   → parse dict/JSON into model (Pydantic v2)
#
# Essential for exporting server records to a CMDB (ServiceNow, Backstage),
# sending over HTTP to HPE OneView APIs, or logging structured events to S3.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 6 — Serialization (model ↔ JSON)")
print("═" * 60)
print("Story: The server record from Demo 4 needs to be exported to the")
print("HPE CMDB and later retrieved for a capacity planning report.")
print("Pydantic converts to JSON for storage and rebuilds an identical")
print("typed object when reading it back.\n")

# Reuse FullServer (fs) from Demo 4
as_dict = fs.model_dump()
print("① model_dump() — Python dict (ready for a CMDB insert):")
print(json.dumps(as_dict, indent=2))

as_json = fs.model_dump_json(indent=2)
print("\n② model_dump_json() — JSON string (ready for API upload, first 200 chars):")
print(as_json[:200] + "…")

restored = FullServer.model_validate_json(as_json)
print(f"\n③ model_validate_json() — restored from JSON back to a typed object:")
print(f"  Server: {restored.server_id}, CPU: {restored.metrics.cpu_util_pct}%, Rack: {restored.location.rack_id}")
print(f"  ↳ Round-trip complete — same data, fully validated Pydantic object.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 7 — LLM Integration: Extract Structured Data from an IML Log Entry
#
# Key concept: the LLM acts as a READER / EXTRACTOR.
# The IML log already contains all the facts (server ID, failed component,
# temperatures, firmware version). The LLM's job is simply to find them
# and format them as JSON matching the Pydantic schema.
#
# This is an EXTRACTION task — not reasoning or judgment.
# Every value in the output schema can be directly traced back to a sentence
# in the IML log.
#
# Flow:
#   IML log (free text)
#       → Bedrock LLM (prompted to return JSON)
#           → JSON string
#               → Pydantic model (validate + use safely)
#
# This is the CORE pattern used in LangChain, LlamaIndex, and OpenAI
# structured-output features — Pydantic acts as the contract.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 7 — LLM as Extractor: IML Log Entry → Structured Incident Data")
print("(LLM reads facts that already exist in the log — no reasoning needed)")
print("═" * 60)
print("Story: HPE iLO generates Integrated Management Log (IML) entries as")
print("free text. We need the data in structured form to open a ServiceNow")
print("ticket. The LLM reads the log and pulls out fields as JSON.\n")

class IMLExtraction(BaseModel):
    """Schema we expect the LLM to fill from an IML log entry."""
    server_id: str
    server_model: str
    ilo_firmware: str
    event_severity: str               # CRITICAL / WARNING / INFORMATIONAL
    component: str                    # what failed or triggered the event
    inlet_temp_celsius: Optional[float] = None
    datacenter: Optional[str] = None
    rack_id: Optional[str] = None
    recommended_action: str


iml_log_entry = """
CRITICAL — Server ID: MXQ92340017. Model: HPE ProLiant DL380 Gen11.
iLO 6 firmware version: 3.10.00.00.
Event: Fan 2 (CPU Zone) has failed or been removed.
Current inlet temperature: 41°C. Thermal shutdown threshold: 45°C.
Location: Datacenter SJC-DC3, Rack R12.
Recommended action: Immediately replace failed fan to prevent thermal shutdown
of the production GreenLake workload.
"""

system_prompt = """You are an HPE infrastructure data extraction assistant.
Extract incident information from the provided IML log entry and return ONLY
valid JSON (no markdown, no explanation) with these exact keys:
{
  "server_id": "<string>",
  "server_model": "<string>",
  "ilo_firmware": "<string>",
  "event_severity": "<string>",
  "component": "<string>",
  "inlet_temp_celsius": <number or null>,
  "datacenter": "<string or null>",
  "rack_id": "<string or null>",
  "recommended_action": "<string>"
}
"""

AWS_ACCESS_KEY_ID     = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION            = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID              = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")

import boto3

bedrock = boto3.client(
    "bedrock-runtime",
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
)

print(f"Calling Bedrock model: {MODEL_ID}")
print(f"Input IML log:\n{iml_log_entry.strip()}\n")

response = bedrock.converse(
    modelId=MODEL_ID,
    system=[{"text": system_prompt}],
    messages=[{"role": "user", "content": [{"text": iml_log_entry}]}],
    inferenceConfig={"maxTokens": 512, "temperature": 0.0},
)

raw_llm_output = response["output"]["message"]["content"][0]["text"]
print(f"Raw LLM output:\n{raw_llm_output}\n")

try:
    extracted = IMLExtraction.model_validate_json(strip_markdown_json(raw_llm_output))
    print("✔ Pydantic-validated extraction (facts pulled from IML log):")
    print(f"  Server       : {extracted.server_id} ({extracted.server_model})")
    print(f"  iLO Firmware : {extracted.ilo_firmware}")
    print(f"  Severity     : {extracted.event_severity}")
    print(f"  Component    : {extracted.component}")
    print(f"  Inlet Temp   : {extracted.inlet_temp_celsius}°C")
    print(f"  Location     : {extracted.datacenter}, Rack {extracted.rack_id}")
    print(f"  Action       : {extracted.recommended_action}")
    print(f"\n  ↳ All values came verbatim from the IML log — LLM just extracted them.")
except ValidationError as e:
    print("LLM output failed Pydantic validation:")
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
except json.JSONDecodeError as e:
    print(f"LLM did not return valid JSON: {e}")
    print(f"Raw output was: {raw_llm_output}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 8 — LLM as Infrastructure Reasoner (Schema-Driven Output)
#
# Key concept: the LLM acts as an SRE / REASONER.
# Unlike Demo 7 (extraction), here the LLM must JUDGE and DECIDE:
#   • severity        — P1/P2/P3/P4  (not stated in the input)
#   • likely_root_cause — hypothesis the LLM must form
#   • remediation_steps — ordered actions the LLM must plan
#   • escalation_required — true/false decision (requires judgment)
#   • estimated_resolution_hours — estimate (requires experience)
#
# This is a GENERATION / REASONING task. None of the output fields exist
# verbatim in the input — the LLM applies domain knowledge to produce them.
#
# The Pydantic pattern is identical to Demo 7; only the LLM's role changes.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 8 — LLM as Reasoner: Incident Description → RCA Report")
print("(LLM judges severity, root cause, remediation — not just extraction)")
print("═" * 60)
print("Story: An on-call engineer enters a brief incident description.")
print("Instead of pulling out facts, the LLM must reason: how severe is this?")
print("What caused it? What are the remediation steps? Should it be escalated?")
print("The answers don't exist in the text — the LLM has to think them through.\n")

class IncidentRCA(BaseModel):
    """Structured RCA report that a downstream ITSM system would consume."""
    server_id: str
    incident_summary: str
    severity: str                    # "P1" | "P2" | "P3" | "P4" ← LLM must judge
    likely_root_cause: str           # LLM must hypothesise this
    remediation_steps: list[str]     # ordered actions ← LLM must plan these
    escalation_required: bool        # true/false ← LLM must decide
    estimated_resolution_hours: int  # ← LLM must estimate


schema_prompt = """You are an HPE Site Reliability Engineer AI assistant.
Given an infrastructure incident description, return ONLY valid JSON (no markdown) matching:
{
  "server_id": "<string>",
  "incident_summary": "<string>",
  "severity": "<P1|P2|P3|P4>",
  "likely_root_cause": "<string>",
  "remediation_steps": ["<step1>", "<step2>", ...],
  "escalation_required": <true|false>,
  "estimated_resolution_hours": <integer>
}
Severity guide: P1=critical business impact, P2=major degradation, P3=minor impact, P4=no impact.
"""

incident_description = """
Server MXQ92340017 (HPE ProLiant DL380 Gen11) is running a GreenLake Compute
workload for Customer XYZ (Enterprise SLA: 99.95% uptime). CPU throttling has
been active since 14:23 UTC — performance degraded by 40%. The iLO IML shows
Fan 2 failed at 14:20 UTC. Inlet temperature: 38°C at 14:23, now 41°C at 14:35.
Thermal shutdown threshold is 45°C. No other servers in the rack are affected.
The customer has not yet noticed the degradation, but the SLA breach window
opens in 90 minutes.
"""

print(f"Incident:\n{incident_description.strip()}\n")

resp2 = bedrock.converse(
    modelId=MODEL_ID,
    system=[{"text": schema_prompt}],
    messages=[{"role": "user", "content": [{"text": incident_description}]}],
    inferenceConfig={"maxTokens": 512, "temperature": 0.0},
)

raw2 = resp2["output"]["message"]["content"][0]["text"]
print(f"Raw LLM output:\n{raw2}\n")

try:
    rca = IncidentRCA.model_validate_json(strip_markdown_json(raw2))
    print("✔ Validated RCA Report (LLM reasoned, not just extracted):")
    print(f"  Server          : {rca.server_id}")
    print(f"  Summary         : {rca.incident_summary}")
    print(f"  Severity        : {rca.severity}  ← LLM judged this from SLA + temp context")
    print(f"  Root Cause      : {rca.likely_root_cause}  ← LLM hypothesised this")
    print(f"  Remediation     :  ← LLM planned these steps")
    for step in rca.remediation_steps:
        print(f"    • {step}")
    print(f"  Escalate?       : {rca.escalation_required}  ← LLM made this decision")
    print(f"  Est. Resolution : {rca.estimated_resolution_hours}h  ← LLM estimated this")
    print(f"\n  ↳ None of these values were stated verbatim — LLM reasoned them out.")
except ValidationError as e:
    print("Validation error on RCA report:")
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
except json.JSONDecodeError as e:
    print(f"JSON parse error: {e}\nRaw: {raw2}")

"""
KEY DIFFERENCE BETWEEN DEMO 7 AND DEMO 8
─────────────────────────────────────────
Demo 7 is EXTRACTION: the LLM acts as a reader — all the answers (server ID,
failed component, temperature, firmware version) are already present in the IML
log; it just needs to find and format them.

Demo 8 is GENERATION / REASONING: the LLM acts as an SRE — it must JUDGE
severity (P1/P2/P3/P4), HYPOTHESISE a root cause, PLAN remediation steps, and
DECIDE whether escalation is needed. None of these answers exist verbatim in
the input text; the LLM has to reason them out.

Both use the identical Pydantic-as-contract pattern (LLM → JSON → Pydantic
validation → typed object). The difference is purely in what you ask the LLM
to do with the input.
"""

print("\n" + "═" * 60)
print("All demos complete.")
print("═" * 60)
