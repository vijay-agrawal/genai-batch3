"""
04hybrid_search.py  –  Why Hybrid Search (BM25 + Semantic + RRF) Beats Either Alone
=====================================================================================

Learning objectives
───────────────────
  1. BM25 (keyword)   – wins on exact codes, part numbers, model identifiers
  2. Semantic         – wins on conceptual / paraphrased queries (vocabulary gap)
  3. Hybrid + RRF     – fuses two ranked lists; consistently the strongest option

Retrieval architecture
──────────────────────
  Data (TXT + MD)
       │
       ├── chunk ──▶  BM25Retriever  ─────────────────────┐
       │               (rank_bm25)                         │
       │                                                   ▼
       └── chunk ──▶  Chroma + Bedrock  ──▶  RRF Fusion  ──▶  Ranked results
                       (dense vectors)        (k = 60)

RRF formula (Cormack et al., 2009)
────────────────────────────────────
  RRF_score(d) = Σ_list  1 / (k + rank(d, list))

  k = 60 dampens the gap between rank-1 and rank-2 so that strong matches
  from either list still surface in the fused ranking.

Setup
─────
  pip install rank_bm25 langchain langchain-community langchain-aws langchain-chroma boto3 python-dotenv

  First run creates chroma_db_hybrid/ (calls Bedrock embedding API ~30 s).
  Subsequent runs reuse the stored index.
  Pass --rebuild to force re-indexing after adding new data files.

Usage
─────
  python 04hybrid_search.py           # run demo + interactive mode
  python 04hybrid_search.py --rebuild # delete + recreate vector store
"""

from __future__ import annotations

import os
import sys
import shutil
import textwrap
from pathlib import Path

import boto3
import warnings
warnings.filterwarnings("ignore")

from dotenv import load_dotenv
load_dotenv()

from langchain_core.documents import Document
from langchain_community.retrievers import BM25Retriever
from langchain.retrievers import EnsembleRetriever
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_aws import BedrockEmbeddings
from langchain_chroma import Chroma

# ─── Paths & constants ────────────────────────────────────────────────────────
SCRIPT_DIR  = Path(__file__).parent
DATA_DIR    = SCRIPT_DIR / "data"
CHROMA_PATH = SCRIPT_DIR / "chroma_db_hybrid"

CHUNK_SIZE    = 512
CHUNK_OVERLAP = 20
TOP_K         = 4    # results per retriever in the demo
RRF_K         = 60   # standard smoothing constant for RRF

W = 90               # display width

# ─── 1. Document loading ──────────────────────────────────────────────────────

def load_chunks() -> list[Document]:
    """
    Load all TXT and MD files from data/, split into chunks.

    BM25 is built purely from these chunks (no API calls).
    Chroma is also built from the same chunks — same corpus, fair comparison.
    """
    docs: list[Document] = []
    for pattern in ("*.txt", "*.md"):
        for path in sorted(DATA_DIR.glob(pattern)):
            try:
                loaded = TextLoader(str(path), encoding="utf-8").load()
                docs.extend(loaded)
                print(f"    ✓ {path.name}  ({sum(len(d.page_content) for d in loaded):,} chars)")
            except Exception as exc:
                print(f"    ✗ {path.name}: {exc}")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
    )
    chunks = splitter.split_documents(docs)
    print(f"  → {len(chunks)} chunks from {len(docs)} document sections")
    return chunks


# ─── 2. Retriever builders ────────────────────────────────────────────────────

def build_bm25(chunks: list[Document]) -> BM25Retriever:
    """
    BM25 (Best Match 25) — probabilistic keyword retrieval.

    Scores documents by TF-IDF variant; rewards exact term matches,
    rare terms, and appropriate document length.  No embeddings needed.
    """
    retriever = BM25Retriever.from_documents(chunks)
    retriever.k = TOP_K
    return retriever


def _bedrock_embeddings() -> BedrockEmbeddings:
    client = boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )
    return BedrockEmbeddings(
        client=client,
        model_id=os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0"),
    )


def build_or_load_chroma(chunks: list[Document], rebuild: bool = False) -> Chroma:
    """
    Dense vector store backed by Amazon Bedrock Titan embeddings.

    First run (~30 s): embeds all chunks via Bedrock API and stores in chroma_db_hybrid/.
    Subsequent runs:   loads the stored index — no API calls.
    """
    embeddings = _bedrock_embeddings()

    if rebuild and CHROMA_PATH.exists():
        shutil.rmtree(CHROMA_PATH)
        print(f"  Deleted existing index at {CHROMA_PATH.name}")

    if CHROMA_PATH.exists():
        print(f"  Loading existing Chroma DB from {CHROMA_PATH.name}/  (use --rebuild to refresh)")
        return Chroma(persist_directory=str(CHROMA_PATH), embedding_function=embeddings)

    print(f"  Building Chroma DB — embedding {len(chunks)} chunks via Bedrock…")
    store = Chroma.from_documents(
        chunks, embeddings, persist_directory=str(CHROMA_PATH)
    )
    print(f"  Saved to {CHROMA_PATH.name}/")
    return store


# ─── 3. Reciprocal Rank Fusion ────────────────────────────────────────────────

def rrf(
    ranked_lists: list[list[Document]],
    top_n: int = TOP_K,
    k: int = RRF_K,
) -> list[tuple[Document, float]]:
    """
    Reciprocal Rank Fusion — Cormack, Clarke & Buettcher (SIGIR 2009).

    Given N ranked lists of documents, produce one merged ranking:

        RRF_score(d) = Σ_list  1 / (k + rank(d, list))

    Why k=60?
      At rank 1:  1/61  ≈ 0.0164
      At rank 10: 1/70  ≈ 0.0143
      The gap is small — a document at rank 10 in a strong list still
      scores well.  k < 60 would make rank-1 overwhelmingly dominant.

    A document that appears in BOTH lists gets contributions from each,
    so it naturally floats to the top — the core hybrid search advantage.
    """
    scores: dict[str, float] = {}
    doc_store: dict[str, Document] = {}

    for ranked in ranked_lists:
        for rank, doc in enumerate(ranked, start=1):
            key = doc.page_content[:150]          # stable identity key per chunk
            scores[key]    = scores.get(key, 0.0) + 1.0 / (k + rank)
            doc_store[key] = doc

    ordered = sorted(scores, key=lambda x: scores[x], reverse=True)
    return [(doc_store[dk], round(scores[dk], 6)) for dk in ordered[:top_n]]


# ─── 4. EnsembleRetriever (LangChain's production-ready RRF) ─────────────────

def build_ensemble(bm25_ret: BM25Retriever, sem_ret) -> EnsembleRetriever:
    """
    LangChain's EnsembleRetriever implements the same RRF algorithm internally
    (via weighted_reciprocal_rank).  Weights [0.5, 0.5] = equal contribution.

    Use this in production code; use the manual rrf() above to understand HOW it works.
    """
    return EnsembleRetriever(
        retrievers=[bm25_ret, sem_ret],
        weights=[0.5, 0.5],
    )


# ─── 5. Display helpers ───────────────────────────────────────────────────────

def _banner(text: str, char: str = "═") -> None:
    print(f"\n{char * W}")
    for line in text.splitlines():
        print(f"  {line}")
    print(char * W)


def _section(title: str) -> None:
    print(f"\n  ┌{'─' * (W - 4)}┐")
    print(f"  │  {title:<{W-6}}│")
    print(f"  └{'─' * (W - 4)}┘")


def _result(rank: int, doc: Document, rrf_score: float | None = None) -> None:
    src   = Path(doc.metadata.get("source", "unknown")).name
    snip  = textwrap.shorten(
        doc.page_content.strip().replace("\n", " "), width=230, placeholder=" …"
    )
    score = f"  RRF={rrf_score:.5f}" if rrf_score is not None else ""
    print(f"\n  {rank}. [{src}]{score}")
    print(f"     {snip}")


# ─── 6. Core comparison function ─────────────────────────────────────────────

def compare(
    query: str,
    bm25_ret: BM25Retriever,
    sem_ret,
    note: str = "",
) -> None:
    """
    Run BM25, semantic, and manual RRF on the same query.
    Print results side-by-side so students can see the differences.
    """
    _banner(
        f"QUERY : {query}\n"
        + (f"NOTE  : {note}" if note else ""),
        char="─",
    )

    bm25_docs = bm25_ret.invoke(query)[:TOP_K]
    sem_docs  = sem_ret.invoke(query)[:TOP_K]
    hybrid    = rrf([bm25_docs, sem_docs])

    _section("BM25 (keyword / lexical)  — rewards exact term matches")
    for i, doc in enumerate(bm25_docs, 1):
        _result(i, doc)

    _section("Semantic (dense vectors)  — rewards conceptual similarity")
    for i, doc in enumerate(sem_docs, 1):
        _result(i, doc)

    _section("Hybrid RRF  (BM25 ⊕ Semantic, k=60)  — fused ranking")
    for i, (doc, score) in enumerate(hybrid, 1):
        _result(i, doc, score)


# ─── 7. Demo scenario definitions ────────────────────────────────────────────

SCENARIOS: list[dict] = [
    # ══════════════════════════════════════════════════════════════════════════
    # SCENARIO A  —  BM25 WINS
    # Queries contain exact technical identifiers that appear verbatim in the docs.
    # BM25 term-frequency matching scores these directly.
    # Semantic embedding maps toward general meaning and may score non-matching
    # chunks higher if they discuss similar concepts in different words.
    # ══════════════════════════════════════════════════════════════════════════
    {
        "title": "SCENARIO A  —  BM25 WINS: exact identifier queries",
        "description": (
            "These queries contain specific error codes, serial numbers, register names,\n"
            "and account names that appear *verbatim* in the documents.\n"
            "BM25 term-matching excels here; semantic search may miss or rank them lower\n"
            "because the embedding space doesn't care about exact strings."
        ),
        "queries": [
            (
                "TSG-4405 IML-017 PCIe AER uncorrectable error device isolated",
                "Exact problem ID + exact IML event code from the troubleshooting guide.",
            ),
            (
                "HPE-SAS-4T-A2291 reallocated sectors predictive failure bay 3",
                "Exact drive serial number from the server event log.",
            ),
            (
                "PROCHOT# assertion PCH status register MSR IA32_THERM_STATUS",
                "Exact CPU register names that only appear in the TSG-4401 KB entry.",
            ),
            (
                "admin_ops iLO Remote Console authentication failure account locked",
                "Exact account name + exact event phrase from the server log.",
            ),
        ],
    },

    # ══════════════════════════════════════════════════════════════════════════
    # SCENARIO B  —  SEMANTIC WINS
    # Queries use natural language that is conceptually correct but uses DIFFERENT
    # vocabulary from the documents.  No term overlap → BM25 scores these poorly.
    # Semantic embeddings bridge the vocabulary gap.
    # ══════════════════════════════════════════════════════════════════════════
    {
        "title": "SCENARIO B  —  SEMANTIC WINS: conceptual / paraphrased queries",
        "description": (
            "These queries describe events in plain English that differs from the\n"
            "exact wording in the documents (the 'vocabulary gap' problem).\n"
            "BM25 finds few or no term matches; semantic embedding understands the\n"
            "underlying concept and retrieves the right documents anyway."
        ),
        "queries": [
            (
                "processor forced an emergency halt to prevent irreversible heat damage",
                # docs say: 'thermal trip', 'emergency shutdown', 'temperatures beyond ceiling'
                "Docs say 'thermal trip' and 'emergency shutdown' — not 'halt' or 'heat damage'.",
            ),
            (
                "storage array lost its redundancy protection because a disk stopped working",
                # docs say: 'RAID-5 degraded', 'physical drive failure', 'HSP_ACTIVATED'
                "Docs say 'RAID-5 degraded' and 'physical drive failure', not 'lost redundancy'.",
            ),
            (
                "network card dropped its connection and traffic was automatically rerouted",
                # docs say: 'link down', 'multipath failover activated', 'I/O rerouted'
                "Docs say 'link down' and 'multipath failover' — not 'dropped connection' or 'rerouted'.",
            ),
            (
                "storage pool ran completely out of space causing database writes to stop",
                # docs say: 'CPG-PROD-TIER1 reached 100% capacity', 'I/O suspended'
                "Docs say 'CPG at 100%' and 'I/O suspended' — not 'ran out of space' or 'writes stopped'.",
            ),
        ],
    },

    # ══════════════════════════════════════════════════════════════════════════
    # SCENARIO C  —  HYBRID WINS
    # Queries combine a precise technical term (BM25 strength) with a conceptual
    # component (semantic strength).  Neither retriever alone catches everything.
    # RRF fuses their ranked lists and surfaces the best of both.
    # ══════════════════════════════════════════════════════════════════════════
    {
        "title": "SCENARIO C  —  HYBRID WINS: mixed exact + conceptual queries",
        "description": (
            "These queries have both a specific technical identifier (BM25 wins that part)\n"
            "AND a conceptual or paraphrased component (semantic wins that part).\n"
            "RRF merges the two ranked lists: documents appearing in both are boosted,\n"
            "producing a final ranking better than either retriever alone."
        ),
        "queries": [
            (
                "Mellanox CX-7 adapter lost its link and how was connectivity restored",
                # BM25: 'Mellanox CX-7' exact | Semantic: 'connectivity restored' ≈ 'link restored'
                "'Mellanox CX-7' = exact model (BM25 wins); 'connectivity restored' = conceptual (semantic wins).",
            ),
            (
                "DIMM slot memory module failure that stopped the server from completing startup",
                # BM25: 'DIMM slot' exact | Semantic: 'stopped server from completing startup' ≈ POST halt
                "'DIMM slot' = exact term (BM25); 'stopped server from completing startup' → POST failure (semantic).",
            ),
            (
                "HPE Smart Array P408i-a RAID degradation and risk to data while rebuilding",
                # BM25: 'HPE Smart Array P408i-a RAID' exact | Semantic: 'risk to data while rebuilding'
                "'Smart Array P408i-a' exact (BM25); 'risk to data during rebuild' is conceptual (semantic).",
            ),
            (
                "SAN fabric RSCN storm caused by faulty HBA flooding the storage network",
                # BM25: 'RSCN storm', 'HBA' exact | Semantic: 'flooding storage network' ≈ 240 RSCNs/30s
                "'RSCN storm' and 'HBA' exact (BM25); 'flooding the storage network' is conceptual (semantic).",
            ),
        ],
    },
]


# ─── 8. Main ──────────────────────────────────────────────────────────────────

def main() -> None:
    rebuild = "--rebuild" in sys.argv

    _banner(
        "HYBRID SEARCH DEMO  —  BM25 + Semantic Embeddings + RRF\n"
        "HPE ProLiant / SAN Engineering  |  GenAI Training",
        char="═",
    )

    # ── Load documents ────────────────────────────────────────────────────────
    print("\n[1/3] Loading and chunking documents…")
    chunks = load_chunks()

    # ── Build retrievers ──────────────────────────────────────────────────────
    print("\n[2/3] Building retrievers…")
    bm25_ret = build_bm25(chunks)
    print(f"  BM25 retriever ready  (in-memory, no API calls, instant)")

    vectorstore = build_or_load_chroma(chunks, rebuild=rebuild)
    sem_ret = vectorstore.as_retriever(
        search_type="similarity", search_kwargs={"k": TOP_K}
    )
    print(f"  Semantic retriever ready  (Chroma + Bedrock Titan embeddings)")

    # LangChain's production-ready hybrid retriever (same RRF algorithm):
    ensemble_ret = build_ensemble(bm25_ret, sem_ret)
    print(f"  EnsembleRetriever ready   (LangChain's built-in RRF wrapper)")

    # ── Demo scenarios ────────────────────────────────────────────────────────
    print(f"\n[3/3] Running demo scenarios…")

    for scenario in SCENARIOS:
        _banner(
            f"{scenario['title']}\n\n{scenario['description']}",
            char="█",
        )
        for query, note in scenario["queries"]:
            compare(query, bm25_ret, sem_ret, note=note)
            try:
                input(f"\n  {'─'*60}\n  [Enter] next query  |  Ctrl-C to jump to interactive mode\n  {'─'*60}\n")
            except (KeyboardInterrupt, EOFError):
                print("\n  (Jumping to interactive mode…)\n")
                break

    # ── Interactive mode ──────────────────────────────────────────────────────
    _banner(
        "INTERACTIVE MODE\n"
        "Try your own queries to explore BM25 vs. Semantic vs. Hybrid.\n"
        "Type  q  to quit.",
        char="═",
    )

    print("\n  Tip: notice how adding an exact code (like 'IML-017') changes BM25 results,")
    print("       while adding a conceptual phrase changes semantic results.\n")

    while True:
        try:
            query = input("  Query: ").strip()
        except (KeyboardInterrupt, EOFError):
            break
        if not query or query.lower() in ("q", "quit", "exit"):
            break
        compare(query, bm25_ret, sem_ret)

    print("\nDone.")


if __name__ == "__main__":
    main()
