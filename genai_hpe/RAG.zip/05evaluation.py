"""
RAG Evaluation Demo: BERTScore + LLM-as-Judge (AWS Bedrock)
============================================================
Evaluates the RAG pipeline against a golden dataset derived from HPE
infrastructure documents in rag/data/ — server event logs, SAN/storage
logs, and the internal troubleshooting guide.

Metrics:
  - BERTScore (Precision / Recall / F1) via the bert-score package
  - LLM-as-Judge score (0-10) via AWS Bedrock (amazon.nova-micro-v1:0)

Install dependencies first (if not already present):
  pip install bert-score
"""

import os
import json
import textwrap
import boto3
import warnings

warnings.filterwarnings("ignore")

from dotenv import load_dotenv
load_dotenv()

# ── RAG helpers (mirrors 02retriever.py to avoid triggering its REPL loop) ────

CHROMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chroma_db_new2")


def _bedrock_client():
    return boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )


def load_embeddings_chroma(persist_directory=CHROMA_PATH):
    from langchain_chroma import Chroma
    from langchain_aws import BedrockEmbeddings

    embeddings = BedrockEmbeddings(
        client=_bedrock_client(),
        model_id=os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0"),
    )
    return Chroma(persist_directory=persist_directory, embedding_function=embeddings)


def ask_and_get_answer(vector_store, question: str, k: int = 3) -> dict:
    from langchain_aws import ChatBedrock
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.runnables import RunnablePassthrough
    from langchain_core.output_parsers import StrOutputParser

    llm = ChatBedrock(
        client=_bedrock_client(),
        model_id=os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0"),
        model_kwargs={"temperature": 0},
    )

    retriever = vector_store.as_retriever(search_type="similarity", search_kwargs={"k": k})

    template = """You are an assistant for question-answering tasks.
Use the following pieces of retrieved context to answer the question.
If you don't know the answer, say that you don't know.
Use three sentences maximum and keep the answer concise.

Context: {context}

Question: {question}

Answer:"""

    prompt = ChatPromptTemplate.from_template(template)

    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

    answer = rag_chain.invoke(question)
    source_docs = retriever.invoke(question)
    return {"answer": answer, "context": source_docs, "input": question}


# ── Golden dataset ─────────────────────────────────────────────────────────────
# Q&A pairs grounded in HPE-specific documents inside rag/data/:
#   • hpe_proliant_server_logs.txt   – ProLiant DL380/DL360/Synergy/ML350 event logs
#   • hpe_san_storage_logs.txt       – HPE 3PAR StoreServ & MSA 2060 SAN/storage logs
#   • hpe_troubleshooting_guide.md   – Internal KB troubleshooting reference

GOLDEN_DATASET = [
    # Q1 — specific server event (tests precise fact retrieval)
    {
        "question": "What happened to PROLIANT-DL380-NODE01 on March 20, 2026?",
        "reference_answer": (
            "PROLIANT-DL380-NODE01 experienced an unexpected system reset at "
            "00:30:15 on March 20 2026 when the watchdog timer expired while "
            "running workload HPE-ML-JOB-4421. The system rebooted cleanly, "
            "BIOS POST passed, and OS handoff completed at 00:31."
        ),
        "source": "hpe_proliant_server_logs.txt",
    },
    # Q2 — root cause + resolution (tests causal reasoning across log entries)
    {
        "question": "What was the root cause of the RSCN storm on SAN-SW-FABRIC-A and how was it fixed?",
        "reference_answer": (
            "240 RSCNs in 30 seconds were detected on SAN-SW-FABRIC-A on "
            "March 18 2026. The root cause was a faulty Emulex LPe35000 HBA on "
            "SYNERGY-480-BLADE-07. The affected port was isolated to stop the "
            "storm and the faulty HBA was replaced."
        ),
        "source": "hpe_san_storage_logs.txt",
    },
    # Q3 — multi-fact synthesis across three LUN events
    {
        "question": "What LUN issues were reported and how were they resolved?",
        "reference_answer": (
            "Three LUN issues were reported: LUN 12 (VV-ORACLE-DB-PROD01) had "
            "I/O suspended for 5 minutes due to CPG-PROD-TIER1 reaching 100% "
            "capacity on March 15, resolved by emergency CPG expansion. "
            "LUN 18 (VV-SQLSERVER-DEV) was not found by the host after a "
            "multipath daemon crash on March 17, fixed by restarting multipathd. "
            "LUN 5 (LUN-BACKUP-STORE-02) had a SCSI Medium Error with bad blocks "
            "on March 19, resolved by bad-block remapping."
        ),
        "source": "hpe_san_storage_logs.txt",
    },
    # Q4 — time-sequenced incident with RPO impact (tests temporal chain retrieval)
    {
        "question": "What is the status of the replication link between the primary and DR site 3PAR arrays?",
        "reference_answer": (
            "The replication link between HPE-3PAR-8450-01 (primary) and "
            "HPE-3PAR-8450-DRSITE-02 (DR site) was delayed on March 18 2026 due "
            "to WAN link bandwidth saturation, breaching the 1-hour RPO target "
            "at 2 hours 14 minutes. WAN congestion was resolved by 16:30 and "
            "replication resynced with RPO restored to 8 minutes."
        ),
        "source": "hpe_san_storage_logs.txt",
    },
    # Q5 — KB / troubleshooting lookup (tests structured technical doc retrieval)
    {
        "question": "What is the technical signature and resolution for a DIMM training failure on HPE ProLiant servers?",
        "reference_answer": (
            "A DIMM training failure (TSG-4402) is a POST phase error where the "
            "JEDEC DDR5 command/address initialization sequence is aborted. The "
            "IML logs MEM_INIT_ERROR and the server halts at POST with no OS "
            "handoff. Resolution is to reseat the DIMM; if the error persists "
            "after reseating, the DIMM is defective and must be replaced."
        ),
        "source": "hpe_troubleshooting_guide.md",
    },
]

# ── BERTScore ─────────────────────────────────────────────────────────────────

def compute_bertscore(candidates: list, references: list) -> dict:
    """
    BERTScore computes token-level cosine similarities between contextual
    embeddings (from a pre-trained BERT model) of the candidate and reference
    sentences, giving Precision, Recall, and F1.

    model_type options (trade accuracy vs. speed):
      distilbert-base-uncased  – fast, ~260 MB
      bert-base-uncased        – balanced
      roberta-large            – highest accuracy, ~1.4 GB
    """
    try:
        from bert_score import score as bert_score_fn
    except ImportError:
        print("\n[ERROR] bert-score is not installed.  Run:  pip install bert-score\n")
        raise

    print("\nComputing BERTScore (model downloads on first run) …")
    P, R, F1 = bert_score_fn(
        candidates,
        references,
        lang="en",
        model_type="distilbert-base-uncased",
        verbose=False,
    )
    return {
        "precision": P.tolist(),
        "recall":    R.tolist(),
        "f1":        F1.tolist(),
    }

# ── LLM-as-Judge via AWS Bedrock ──────────────────────────────────────────────

def llm_judge_score(question: str, reference: str, candidate: str) -> dict:
    """
    Prompts a Bedrock LLM to score the candidate answer 0-10.
    Returns {"score": int, "rationale": str}.
    """
    judge_prompt = textwrap.dedent(f"""
        You are an impartial judge evaluating a RAG system answer.

        Question: {question}

        Reference answer (ground truth): {reference}

        Candidate answer (generated by the system): {candidate}

        Score the candidate answer from 0 to 10:
          10 = factually complete and correct, matches reference closely
           7 = mostly correct with minor omissions
           4 = partially correct but missing key facts
           0 = incorrect or irrelevant

        Respond with a JSON object only, no extra text:
        {{"score": <integer 0-10>, "rationale": "<one sentence>"}}
    """).strip()

    response = _bedrock_client().invoke_model(
        modelId=os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0"),
        body=json.dumps({
            "messages": [{"role": "user", "content": judge_prompt}],
            "inferenceConfig": {"temperature": 0, "maxTokens": 200},
        }),
        contentType="application/json",
        accept="application/json",
    )

    raw_text = json.loads(response["body"].read())["output"]["message"]["content"][0]["text"].strip()

    # Strip markdown code fences if present
    if raw_text.startswith("```"):
        raw_text = raw_text.split("```")[1]
        if raw_text.startswith("json"):
            raw_text = raw_text[4:]
        raw_text = raw_text.strip()

    try:
        return json.loads(raw_text)
    except json.JSONDecodeError:
        return {"score": -1, "rationale": "parse error: " + raw_text[:80]}

# ── Reporting ─────────────────────────────────────────────────────────────────

def _bar(value: float, width: int = 30) -> str:
    filled = int(round(value * width))
    return "█" * filled + "░" * (width - filled)


def print_summary_table(results: list) -> None:
    print("\n" + "=" * 95)
    print(" RAG EVALUATION SUMMARY")
    print("=" * 95)
    print(f"{'#':<3} {'BEP':>6} {'BER':>6} {'BEF1':>6} {'LLM':>6}  Source / Question (truncated)")
    print("-" * 95)

    for r in results:
        q_short = r["question"][:52] + "…" if len(r["question"]) > 52 else r["question"]
        llm_str = f"{r['llm_score']:>4}/10" if r["llm_score"] >= 0 else "  n/a"
        print(
            f"{r['idx']:<3} "
            f"{r['bert_p']:>6.3f} {r['bert_r']:>6.3f} {r['bert_f1']:>6.3f} "
            f"{llm_str}  [{r['source'][:20]}] {q_short}"
        )

    print("-" * 95)
    avg_p   = sum(r["bert_p"]  for r in results) / len(results)
    avg_r   = sum(r["bert_r"]  for r in results) / len(results)
    avg_f1  = sum(r["bert_f1"] for r in results) / len(results)
    valid   = [r["llm_score"] for r in results if r["llm_score"] >= 0]
    avg_llm = sum(valid) / len(valid) if valid else float("nan")

    print(f"{'AVG':<3} {avg_p:>6.3f} {avg_r:>6.3f} {avg_f1:>6.3f} {avg_llm:>5.1f}/10")
    print("=" * 95)
    print(f"\nLegend:  BEP = BERTScore Precision  BER = BERTScore Recall  BEF1 = BERTScore F1")

    print("\nBERTScore F1 bar chart:")
    for r in results:
        print(f"  Q{r['idx']:<2} {_bar(r['bert_f1'])} {r['bert_f1']:.3f}")


def print_detail(results: list) -> None:
    print("\n" + "=" * 95)
    print(" DETAILED ANSWERS")
    print("=" * 95)
    for r in results:
        print(f"\n── Q{r['idx']} [{r['source']}] ──")
        print(f"Question   : {r['question']}")
        print(f"Reference  : {r['reference']}")
        print(f"RAG Answer : {r['candidate']}")
        print(
            f"BERTScore  : P={r['bert_p']:.3f}  R={r['bert_r']:.3f}  F1={r['bert_f1']:.3f}"
        )
        if r["llm_score"] >= 0:
            print(f"LLM Judge  : {r['llm_score']}/10 — {r['llm_rationale']}")


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    print("Loading Chroma vector store …")
    vector_store = load_embeddings_chroma()
    print(f"Vector DB loaded — {vector_store._collection.count()} chunks\n")

    questions  = [item["question"]         for item in GOLDEN_DATASET]
    references = [item["reference_answer"] for item in GOLDEN_DATASET]

    # Step 1 — generate RAG answers
    candidates = []
    print(f"Running RAG pipeline on {len(GOLDEN_DATASET)} golden questions …\n")
    for i, item in enumerate(GOLDEN_DATASET, 1):
        print(f"  [{i:>2}/{len(GOLDEN_DATASET)}] {item['question'][:72]} …")
        result = ask_and_get_answer(vector_store, item["question"])
        candidates.append(result["answer"])

    # Step 2 — BERTScore
    bert = compute_bertscore(candidates, references)

    # Step 3 — LLM-as-Judge
    print("\nRunning LLM-as-Judge evaluation via Bedrock …")
    llm_evals = []
    for i, (q, ref, cand) in enumerate(zip(questions, references, candidates), 1):
        print(f"  Judging Q{i:>2} …", end=" ", flush=True)
        try:
            ev = llm_judge_score(q, ref, cand)
            llm_evals.append(ev)
            print(f"score={ev['score']}")
        except Exception as exc:
            llm_evals.append({"score": -1, "rationale": str(exc)})
            print(f"ERROR — {exc}")

    # Step 4 — assemble and report
    results = [
        {
            "idx":           i + 1,
            "question":      questions[i],
            "source":        GOLDEN_DATASET[i]["source"],
            "reference":     references[i],
            "candidate":     candidates[i],
            "bert_p":        bert["precision"][i],
            "bert_r":        bert["recall"][i],
            "bert_f1":       bert["f1"][i],
            "llm_score":     llm_evals[i]["score"],
            "llm_rationale": llm_evals[i].get("rationale", ""),
        }
        for i in range(len(GOLDEN_DATASET))
    ]

    print_summary_table(results)
    print_detail(results)


if __name__ == "__main__":
    main()
