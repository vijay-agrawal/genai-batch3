# HPE ProLiant / SAN Troubleshooting Reference Guide
# Internal KB  |  DataCenter-West Engineering Team

This guide maps structured problem identifiers to operational descriptions.
It is intentionally written in two registers:
  • **Technical** – uses exact codes, register names, and model identifiers (BM25-friendly)
  • **Operational** – uses plain-language impact descriptions (semantic-friendly)

---

## TSG-4401: PROC_THERMAL_TRIP_EVENT
**Severity**: Critical | **Category**: Thermal Management | **Platform**: ProLiant DL/ML/Synergy

### Technical Signature
Error code: IPMI SEL event type 04h (Processor), offset 09h (Thermal Trip).
IML event class: PROCESSOR_ALERT. BIOS flag: PROCHOT# assertion latched in PCH status register.
MSR IA32_THERM_STATUS bit 4 set. Recovery requires full AC power cycle and thermal compound inspection.
Platform IDs: PROLIANT-DL360-NODE02 and PROLIANT-ML350-EDGE-01 logged thermal trip events.

### Operational Impact
The processor's built-in safeguard detected temperatures beyond the safe ceiling and triggered an
immediate hardware shutdown to prevent permanent CPU damage. Any jobs running at the time were
abruptly terminated without saving state. Administrators must inspect the heatsink seating and
reapply thermal paste before powering the system back on. The system will not restart automatically
until the thermal condition is cleared.

---

## TSG-4402: DIMM_TRAINING_FAILURE
**Severity**: Critical | **Category**: Memory Subsystem | **Platform**: ProLiant Gen10+

### Technical Signature
POST phase error: SPD training failure, JEDEC DDR5 command/address initialization sequence aborted.
iLO IML log entry code: MEM_INIT_ERROR. Affected slot notation: [channel][slot] e.g. 4A or 6B.
Supported DRAM vendors: Samsung 64GB DDR5, Micron 32GB DDR5, SK Hynix 64GB DDR5.
Server halted at POST; no OS handoff. Resolution: reseat DIMM or replace if persistent.

### Operational Impact
The server cannot complete startup because memory module initialization failed — the system stops
dead at the POST phase and will not load the operating system. Physically removing and reinserting
the memory stick in its slot resolves the issue in most cases. If the error persists after reseating,
the DIMM itself is defective and must be swapped with a replacement unit from the spares cabinet.

---

## TSG-4403: SMART_ARRAY_RAID_DEGRADED
**Severity**: High | **Category**: Storage Controller | **Platform**: ProLiant DL/ML

### Technical Signature
HPE Smart Array P408i-a SR Gen10+ event: logical drive status changed from OPTIMAL to DEGRADED.
Physical drive failure code: PD_FAILED. RAID levels affected: RAID-5 or RAID-6.
Hot spare auto-activation code: HSP_ACTIVATED. Estimated rebuild time logged to iLO IML.
RAID controller slot: embedded (P408i-a). Volume: logical drive 1.

### Operational Impact
One physical hard drive in the RAID group has stopped responding, stripping away the storage
redundancy that normally protects against data loss. The data is still accessible, and a hot spare
drive may already be automatically rebuilding — but during that rebuild window the array is
dangerously exposed: a second drive failure would cause total data loss. Admins should replace
the failed drive as an emergency priority and monitor the rebuild to completion before treating
the server as safe.

---

## TSG-4404: NIC_LINK_DOWN_EVENT
**Severity**: High | **Category**: Network Adapter | **Platform**: ProLiant / Synergy

### Technical Signature
NIC driver event: link status changed to DOWN. Affected adapters: Mellanox ConnectX-7 (CX-7) 25GbE
(NIC1) and HPE FlexFabric 10GbE (NIC2). Upstream switch: CORE-SW-RACK12-A port 14 and
DIST-SW-RACK12-B port 7. LINK_STATUS_REG = 0x00. Auto-negotiation fallback attempted. Driver: mlx5_core.

### Operational Impact
The server's network interface went offline, severing all active connections including database
sessions, clustered application heartbeats, and management traffic. If the server depends on a
single NIC with no bonding or teaming, all network services stop immediately. Operations staff
should check the patch cable at both ends, inspect the SFP transceiver, and verify the upstream
switch port is showing link on both sides before declaring a hardware fault.

---

## TSG-4405: PCIE_AER_UNCORRECTABLE
**Severity**: High | **Category**: PCIe Subsystem | **Platform**: ProLiant Gen11

### Technical Signature
PCIe Advanced Error Reporting (AER): Uncorrectable Non-Fatal Error (UNFE) or Fatal Error (FE) logged.
Device isolated by firmware AER handler. NVMe SSD endpoint: U.2 slot 3 or E1.S.
AER uncorrectable error status bits: ECRC, Malformed TLP, Completion Timeout.
IML event code: IML-017. Recovery: replace NVMe SSD and initiate RAID rebuild.

### Operational Impact
An NVMe solid-state drive in a PCIe expansion slot reported persistent hardware errors that the
firmware could not correct, so the drive was quarantined from the rest of the system to prevent
data corruption from spreading. Any data on that isolated drive may be inaccessible or damaged.
The storage team must physically replace the NVMe module with a spare and then start the storage
rebuild process. All other drives in the system continue operating normally — only the faulty
slot is affected.

---

## TSG-4406: HDD_PREDICTIVE_FAILURE
**Severity**: Medium | **Category**: Drive Health | **Platform**: ProLiant / 3PAR StoreServ

### Technical Signature
SMART attribute threshold exceeded: Attribute 05 (Reallocated Sectors Count) above 20 sectors.
HPE SSA reports: HDD_PREDICTIVE_FAILURE or 3PAR reports SMART pre-failure warning.
Drive serial numbers logged: HPE-SAS-4T-A2291 (ProLiant bay 3) and MK192GFJGB-HPE (3PAR cage 1 pos 14).
Drive still functional but scheduled for immediate proactive replacement.

### Operational Impact
The drive's internal health chip has flagged an early warning of imminent mechanical failure — the
storage media is physically degrading and the drive is expected to stop working in the near future.
While it is still operational today, administrators are strongly advised to swap it out at the next
available maintenance window rather than waiting for it to fail on its own during production hours.
Drives in this state often fail completely without further warning within days or weeks.

---

## TSG-4407: PSU_INPUT_VOLTAGE_SAG
**Severity**: Medium | **Category**: Power Subsystem | **Platform**: ProLiant DL/ML

### Technical Signature
iLO power subsystem alert: PSU input voltage below threshold. Threshold: 200 V AC.
Event code: PSU2_INPUT_VOLTAGE_SAG. Observed voltage: 198V on PSU2 input.
HPE Common Slot PSU, 1+1 redundancy mode. Load automatically transferred to PSU1.

### Operational Impact
One of the two redundant power supplies detected that the electrical voltage from the facility outlet
dropped below the minimum safe level. The server immediately and automatically shifted its entire
power draw to the other healthy supply, so the server keeps running without interruption. However,
the system has now lost its power safety net — if the remaining healthy supply also has a problem,
or if there is another voltage fluctuation, the server will go down hard. Facilities engineering
should investigate the quality of the electrical supply to that rack.

---

## TSG-4408: FABRIC_UPLINK_DEGRADED
**Severity**: High | **Category**: Virtual Connect / SAN Fabric | **Platform**: HPE Synergy / SAN

### Technical Signature
HPE OneView alert: VC SE 40Gb F8 Module uplink port degraded. Expected: 40Gb. Actual: 10Gb.
Frame: SYN-FRAME-03, interconnect bay. SFP+ transceiver TX power below -7.5 dBm.
SAN fabric event: SAN-SW-FABRIC-A port 18 Fibre Channel link down (32Gb FC).
WWN: 10:00:00:90:FA:3B:22:01. Multipath failover activated to FABRIC-B.

### Operational Impact
The high-speed connection from the blade enclosure to the core network and storage fabric is
running at a fraction of its designed bandwidth because the optical transceiver is failing.
Network and storage traffic continues to flow through a failover path, but that backup path now
carries the full workload — leaving no room for the cluster to absorb another failure. The degraded
transceiver module (SFP+) must be replaced to restore full redundant connectivity and eliminate
the single point of failure.

---

## TSG-4409: SAN_RSCN_STORM
**Severity**: High | **Category**: SAN Fabric | **Platform**: HPE B-Series SAN Switch

### Technical Signature
SAN-SW-FABRIC-A event: RSCN (Registered State Change Notification) storm. Threshold exceeded:
240 RSCNs in 30 seconds. Root cause: faulty HBA — Emulex LPe35000 on SYNERGY-480-BLADE-07.
Affected port isolated by fabric software. Fabric recovery: RSCN storm subsided after port isolation.

### Operational Impact
A defective host bus adapter flooded the storage network with hundreds of unnecessary state-change
messages per second, overwhelming the SAN fabric switches and threatening to disrupt storage access
for all other servers in the datacenter. The network software automatically detected the flood,
isolated the misbehaving port, and the disruption subsided. The faulty HBA card in the affected
blade server must be physically replaced to permanently resolve the issue and allow the port
to be brought back online safely.

---

## TSG-4410: CPG_CAPACITY_EXHAUSTED
**Severity**: Critical | **Category**: Storage Provisioning | **Platform**: HPE 3PAR StoreServ 8450

### Technical Signature
3PAR event: CPG (Common Provisioning Group) CPG-PROD-TIER1 (SSD) reached 100% capacity.
Virtual volume VV-ORACLE-DB-PROD01, LUN ID 12, WWN: 60002AC0000000000200012300A4.
I/O suspended on host PROLIANT-DL380-NODE01. Resolution: emergency CPG expansion with 2 TB SSD.
Related alert: CPG-DEV-TIER3 (NL-SAS) at 81%, projected to hit 90% within 7 days.

### Operational Impact
A storage pool reached its absolute capacity limit, causing the primary Oracle production database
volume to stop all read and write operations for five minutes. Applications dependent on that database
experienced complete outages during the I/O suspension window. Emergency storage expansion restored
service, but the root cause was insufficient capacity planning — storage utilization had been trending
toward this threshold for days before the alert was acted on. Proactive monitoring and tiering
decisions are needed to prevent recurrence.
