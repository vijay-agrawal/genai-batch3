"""
RAG Evaluation Demo: RAGAS Framework with AWS Bedrock
=====================================================
Evaluates the HPE RAG pipeline using the RAGAS framework.

RAGAS metrics used:
  Faithfulness      – are the answer's claims supported by the retrieved context?
  AnswerRelevancy   – is the answer on-topic for the question asked?
  ContextPrecision  – are the retrieved chunks actually relevant to the question?
  ContextRecall     – do the retrieved chunks cover all facts in the reference answer?

All four metrics use AWS Bedrock (amazon.nova-micro-v1:0) as the judge LLM.
AnswerRelevancy additionally uses Titan embeddings to measure semantic similarity.

Install dependencies (if not already present):
  pip install ragas
"""

import os
import json
import boto3
import warnings

warnings.filterwarnings("ignore")

from dotenv import load_dotenv
load_dotenv()

# ── AWS Bedrock clients ───────────────────────────────────────────────────────

def _bedrock_client():
    return boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )


# ── RAG helpers (same as 05evaluation.py — inlined to avoid REPL side-effects) ─

CHROMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chroma_db_new2")


def load_embeddings_chroma(persist_directory=CHROMA_PATH):
    from langchain_chroma import Chroma
    from langchain_aws import BedrockEmbeddings

    embeddings = BedrockEmbeddings(
        client=_bedrock_client(),
        model_id=os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0"),
    )
    return Chroma(persist_directory=persist_directory, embedding_function=embeddings)


def ask_and_get_answer(vector_store, question: str, k: int = 3) -> dict:
    from langchain_aws import ChatBedrock
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.runnables import RunnablePassthrough
    from langchain_core.output_parsers import StrOutputParser

    llm = ChatBedrock(
        client=_bedrock_client(),
        model_id=os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0"),
        model_kwargs={"temperature": 0},
    )
    retriever = vector_store.as_retriever(search_type="similarity", search_kwargs={"k": k})

    template = """You are an assistant for question-answering tasks.
Use the following pieces of retrieved context to answer the question.
If you don't know the answer, say that you don't know.
Use three sentences maximum and keep the answer concise.

Context: {context}

Question: {question}

Answer:"""

    prompt = ChatPromptTemplate.from_template(template)

    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

    answer = rag_chain.invoke(question)
    source_docs = retriever.invoke(question)
    return {"answer": answer, "context": source_docs}


# ── Golden dataset (HPE-specific, same 5 questions as 05evaluation.py) ────────

GOLDEN_DATASET = [
    # Q1 — specific server event (tests precise fact retrieval)
    {
        "question": "What happened to PROLIANT-DL380-NODE01 on March 20, 2026?",
        "reference_answer": (
            "PROLIANT-DL380-NODE01 experienced an unexpected system reset at "
            "00:30:15 on March 20 2026 when the watchdog timer expired while "
            "running workload HPE-ML-JOB-4421. The system rebooted cleanly, "
            "BIOS POST passed, and OS handoff completed at 00:31."
        ),
        "source": "hpe_proliant_server_logs.txt",
    },
    # Q2 — root cause + resolution (tests causal reasoning across log entries)
    {
        "question": "What was the root cause of the RSCN storm on SAN-SW-FABRIC-A and how was it fixed?",
        "reference_answer": (
            "240 RSCNs in 30 seconds were detected on SAN-SW-FABRIC-A on "
            "March 18 2026. The root cause was a faulty Emulex LPe35000 HBA on "
            "SYNERGY-480-BLADE-07. The affected port was isolated to stop the "
            "storm and the faulty HBA was replaced."
        ),
        "source": "hpe_san_storage_logs.txt",
    },
    # Q3 — multi-fact synthesis across three LUN events
    {
        "question": "What LUN issues were reported and how were they resolved?",
        "reference_answer": (
            "Three LUN issues were reported: LUN 12 (VV-ORACLE-DB-PROD01) had "
            "I/O suspended for 5 minutes due to CPG-PROD-TIER1 reaching 100% "
            "capacity on March 15, resolved by emergency CPG expansion. "
            "LUN 18 (VV-SQLSERVER-DEV) was not found by the host after a "
            "multipath daemon crash on March 17, fixed by restarting multipathd. "
            "LUN 5 (LUN-BACKUP-STORE-02) had a SCSI Medium Error with bad blocks "
            "on March 19, resolved by bad-block remapping."
        ),
        "source": "hpe_san_storage_logs.txt",
    },
    # Q4 — time-sequenced incident with RPO impact
    {
        "question": "What is the status of the replication link between the primary and DR site 3PAR arrays?",
        "reference_answer": (
            "The replication link between HPE-3PAR-8450-01 (primary) and "
            "HPE-3PAR-8450-DRSITE-02 (DR site) was delayed on March 18 2026 due "
            "to WAN link bandwidth saturation, breaching the 1-hour RPO target "
            "at 2 hours 14 minutes. WAN congestion was resolved by 16:30 and "
            "replication resynced with RPO restored to 8 minutes."
        ),
        "source": "hpe_san_storage_logs.txt",
    },
    # Q5 — KB / troubleshooting lookup (tests structured technical doc retrieval)
    {
        "question": "What is the technical signature and resolution for a DIMM training failure on HPE ProLiant servers?",
        "reference_answer": (
            "A DIMM training failure (TSG-4402) is a POST phase error where the "
            "JEDEC DDR5 command/address initialization sequence is aborted. The "
            "IML logs MEM_INIT_ERROR and the server halts at POST with no OS "
            "handoff. Resolution is to reseat the DIMM; if the error persists "
            "after reseating, the DIMM is defective and must be replaced."
        ),
        "source": "hpe_troubleshooting_guide.md",
    },
]

# ── RAGAS metric explanations (printed before results) ────────────────────────

METRIC_EXPLAINERS = {
    "faithfulness": (
        "Faithfulness — fraction of answer claims that are supported by the "
        "retrieved context. A low score means the RAG is hallucinating facts "
        "not present in the retrieved chunks."
    ),
    "answer_relevancy": (
        "Answer Relevancy — how well the answer addresses the question (not "
        "whether it is factually correct). Measured by embedding similarity "
        "between the question and generated answer."
    ),
    "context_precision": (
        "Context Precision — what fraction of the retrieved chunks are actually "
        "useful for answering the question. Low score = noisy retrieval bringing "
        "in irrelevant chunks."
    ),
    "context_recall": (
        "Context Recall — how much of the reference answer can be attributed to "
        "the retrieved context. Low score = the retriever missed relevant chunks."
    ),
}

# ── Build RAGAS evaluation dataset ────────────────────────────────────────────

def build_ragas_dataset(vector_store):
    from ragas.dataset_schema import SingleTurnSample, EvaluationDataset

    print(f"\nRunning RAG pipeline on {len(GOLDEN_DATASET)} questions …\n")
    samples = []

    for i, item in enumerate(GOLDEN_DATASET, 1):
        print(f"  [{i}/{len(GOLDEN_DATASET)}] {item['question'][:70]} …")
        result = ask_and_get_answer(vector_store, item["question"])

        sample = SingleTurnSample(
            user_input=item["question"],
            response=result["answer"],
            retrieved_contexts=[doc.page_content for doc in result["context"]],
            reference=item["reference_answer"],
        )
        samples.append(sample)

    return EvaluationDataset(samples=samples)


# ── Run RAGAS evaluation ──────────────────────────────────────────────────────

def run_ragas_evaluation(dataset):
    from ragas import evaluate
    from ragas.metrics.collections import (
        Faithfulness,
        AnswerRelevancy,
        ContextPrecision,
        ContextRecall,
    )
    from ragas.llms import LangchainLLMWrapper
    from ragas.embeddings import LangchainEmbeddingsWrapper
    from langchain_aws import ChatBedrock, BedrockEmbeddings

    print("\nInitialising RAGAS with AWS Bedrock …")

    ragas_llm = LangchainLLMWrapper(
        ChatBedrock(
            client=_bedrock_client(),
            model_id=os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0"),
            model_kwargs={"temperature": 0, "max_tokens": 1024},
        )
    )

    ragas_embeddings = LangchainEmbeddingsWrapper(
        BedrockEmbeddings(
            client=_bedrock_client(),
            model_id=os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0"),
        )
    )

    metrics = [
        Faithfulness(llm=ragas_llm),
        AnswerRelevancy(llm=ragas_llm, embeddings=ragas_embeddings),
        ContextPrecision(llm=ragas_llm),
        ContextRecall(llm=ragas_llm),
    ]

    print("Running RAGAS evaluation (LLM calls per metric per question) …\n")
    results = evaluate(dataset=dataset, metrics=metrics)
    return results


# ── Reporting ─────────────────────────────────────────────────────────────────

def _bar(value: float, width: int = 25) -> str:
    if value is None or value != value:   # nan guard
        return "?" * width
    filled = int(round(max(0.0, min(1.0, value)) * width))
    return "█" * filled + "░" * (width - filled)


def print_metric_explainers():
    print("\n" + "=" * 90)
    print(" RAGAS METRICS — WHAT THEY MEASURE")
    print("=" * 90)
    for name, explanation in METRIC_EXPLAINERS.items():
        print(f"\n  {name.upper()}")
        print(f"  {explanation}")


def print_results(ragas_result, dataset):
    df = ragas_result.to_pandas()

    metric_cols = ["faithfulness", "answer_relevancy", "context_precision", "context_recall"]
    present = [c for c in metric_cols if c in df.columns]

    print("\n" + "=" * 90)
    print(" RAGAS EVALUATION RESULTS  (per question)")
    print("=" * 90)
    header = f"{'#':<3} {'Faith':>7} {'AnsRel':>7} {'CtxPrec':>8} {'CtxRec':>7}  Question"
    print(header)
    print("-" * 90)

    for i, row in df.iterrows():
        q_short = GOLDEN_DATASET[i]["question"][:52] + "…" \
            if len(GOLDEN_DATASET[i]["question"]) > 52 \
            else GOLDEN_DATASET[i]["question"]

        scores = {c: row.get(c, float("nan")) for c in metric_cols}
        print(
            f"{i+1:<3} "
            f"{scores['faithfulness']:>7.3f} "
            f"{scores['answer_relevancy']:>7.3f} "
            f"{scores['context_precision']:>8.3f} "
            f"{scores['context_recall']:>7.3f}  "
            f"{q_short}"
        )

    print("-" * 90)
    avg = {c: df[c].mean() for c in present}
    print(
        f"{'AVG':<3} "
        f"{avg.get('faithfulness', float('nan')):>7.3f} "
        f"{avg.get('answer_relevancy', float('nan')):>7.3f} "
        f"{avg.get('context_precision', float('nan')):>8.3f} "
        f"{avg.get('context_recall', float('nan')):>7.3f}"
    )
    print("=" * 90)

    # Bar chart for each metric
    for col in present:
        print(f"\n{col.upper()} per question:")
        for i, val in enumerate(df[col]):
            print(f"  Q{i+1}  {_bar(val)} {val:.3f}")
        print(f"  AVG {_bar(avg[col])} {avg[col]:.3f}")

    # Diagnostic commentary
    print("\n" + "=" * 90)
    print(" INTERPRETATION GUIDE")
    print("=" * 90)
    thresholds = {
        "faithfulness":      (0.8, "hallucination risk — answer contains facts not in context"),
        "answer_relevancy":  (0.8, "answer drifts off-topic from the question"),
        "context_precision": (0.7, "retriever returning noisy / off-topic chunks"),
        "context_recall":    (0.7, "retriever missing chunks needed to answer fully"),
    }
    for col, (threshold, warning) in thresholds.items():
        if col not in avg:
            continue
        score = avg[col]
        status = "OK" if score >= threshold else f"LOW — {warning}"
        print(f"  {col:<22}  avg={score:.3f}  {'✓' if score >= threshold else '!'} {status}")
    print("=" * 90)


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    print_metric_explainers()

    print("\n\nLoading Chroma vector store …")
    vector_store = load_embeddings_chroma()
    print(f"Vector DB loaded — {vector_store._collection.count()} chunks")

    dataset = build_ragas_dataset(vector_store)
    ragas_result = run_ragas_evaluation(dataset)

    print_results(ragas_result, dataset)


if __name__ == "__main__":
    main()
