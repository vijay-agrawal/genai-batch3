import boto3
from botocore.exceptions import NoCredentialsError, ClientError

def print_aws_credentials():
    session = boto3.session.Session()
    credentials = session.get_credentials()

    if credentials is None:
        print("No AWS credentials found.")
        return

    resolved = credentials.get_frozen_credentials()
    print("=== AWS Credentials ===")
    print(f"Access Key ID: {resolved.access_key}")
    print(f"Secret Access Key: {resolved.secret_key[:4]}****{resolved.secret_key[-4:] if resolved.secret_key else ''}")
    print(f"Session Token: {'Present' if resolved.token else 'None'}")
    print(f"Region: {session.region_name or 'Not set'}")
    print(f"Profile: {session.profile_name or 'default'}")

    try:
        sts = session.client("sts")
        identity = sts.get_caller_identity()
        arn = identity.get("Arn", "")
        username = arn.split("/")[-1] if "/" in arn else arn
        print(f"IAM User/Role: {username}")
        print(f"Account ID: {identity.get('UserId', '')}")
    except Exception as e:
        print(f"Could not fetch IAM identity: {e}")

def test_s3_access():
    print("\n=== S3 Access Test ===")
    s3 = boto3.client("s3")

    try:
        response = s3.list_buckets()
        buckets = response.get("Buckets", [])
        print(f"S3 access: SUCCESS — {len(buckets)} bucket(s) found")
        for bucket in buckets:
            print(f"  - {bucket['Name']} (created: {bucket['CreationDate'].strftime('%Y-%m-%d')})")
    except NoCredentialsError:
        print("S3 access: FAILED — No credentials available")
    except ClientError as e:
        print(f"S3 access: FAILED — {e.response['Error']['Code']}: {e.response['Error']['Message']}")

if __name__ == "__main__":
    print_aws_credentials()
    test_s3_access()
