# simple_mcp — Weather MCP Demos

This folder contains two progressive demos of the **Model Context Protocol (MCP)**:
a classic stdio server, and a modern HTTP server with a Streamlit chatbot front-end.

---

## Files at a Glance

| File | Transport | Purpose |
|---|---|---|
| `weather_mcp_server.py` | stdio | MCP server — runs as a subprocess, speaks JSON-RPC over stdin/stdout |
| `test_weather_mcp_server.py` | stdio | Test harness — spawns the stdio server and fires raw JSON-RPC requests |
| `weather_http_server.py` | streamable-http | MCP server — runs as a persistent HTTP process (FastMCP) |
| `weather_chatbot.py` | streamable-http | Streamlit chatbot — connects to the HTTP server + Amazon Bedrock |

---

## Demo 1 — stdio MCP Server

### What it is

`weather_mcp_server.py` implements the MCP protocol manually over **stdin/stdout**.
Each client request is a line of JSON; each server response is a line of JSON back.
This is the transport used by VS Code extensions and Claude Desktop — the host process
spawns the server as a child process and pipes messages through it.

### Run the test client

```bash
# From the repo root
python mcp_demo/simple_mcp/test_weather_mcp_server.py
```

The test script spawns the server three times (once per test case) and prints the results:

```
🧪 Testing: List Tools
   - get_weather: Get current weather information for a city
   - get_forecast: Get weather forecast for a city

🧪 Testing: Get Weather
   ✅ Success!  {"city": "London", "temperature": "22°C", ...}

🧪 Testing: Get Forecast
   ✅ Success!  {"city": "Tokyo", "forecast": [...]}
```

### Wire format (JSON-RPC 2.0)

```json
// Request (written to stdin)
{"jsonrpc": "2.0", "id": 1, "method": "tools/call",
 "params": {"name": "get_weather", "arguments": {"city": "London"}}}

// Response (read from stdout)
{"jsonrpc": "2.0", "id": 1, "result": {"content": [{"type": "text", "text": "..."}]}}
```

---

## Demo 2 — HTTP MCP Server + Streamlit Chatbot

### What it is

`weather_http_server.py` uses **FastMCP** with the `streamable-http` transport.
Instead of a subprocess pipe, it runs a real HTTP server. Any number of clients
can connect simultaneously — from browsers, curl, the Streamlit app, or MCP-aware editors.

`weather_chatbot.py` is a Streamlit app that:
1. Connects to the HTTP server and fetches the tool list.
2. Converts the MCP tools into Amazon Bedrock Converse API `toolSpec` format.
3. Runs an agentic loop — the LLM decides when to call a tool, the app executes it
   against the MCP server, then feeds the result back to the LLM.

### Sequence to run

**Terminal 1 — start the MCP server**

```bash
python mcp_demo/simple_mcp/weather_http_server.py
```

Expected output:
```
[10:00:00] Weather MCP server → http://localhost:8001/mcp
INFO:     Started server process [...]
INFO:     Uvicorn running on http://0.0.0.0:8001 (Press CTRL+C to quit)
```

**Terminal 2 — start the Streamlit chatbot**

```bash
streamlit run mcp_demo/simple_mcp/weather_chatbot.py
```

Open the URL printed (usually `http://localhost:8501`).

The chatbot auto-connects to the MCP server on load. You can then type questions like:

- *"What's the weather in Mumbai?"*
- *"Compare Paris and Tokyo weather."*
- *"Give me a 5-day forecast for New York and tell me what to pack."*

---

## Environment Variables

All credentials are read from the `.env` file at the repo root.

| Variable | Used by | Notes |
|---|---|---|
| `OPENWEATHERMAP_API_KEY` | Both servers | If absent, mock weather data is returned |
| `AWS_ACCESS_KEY_ID` | Chatbot | AWS credential for Bedrock |
| `AWS_SECRET_ACCESS_KEY` | Chatbot | AWS credential for Bedrock |
| `AWS_REGION` | Chatbot | Bedrock region (default `us-east-1`) |
| `BEDROCK_MODEL_ID` | Chatbot | Model to call (default `amazon.nova-micro-v1:0`) |
| `BEDROCK_MAX_TOKENS` | Chatbot | Max output tokens (default `512`) |
| `BEDROCK_TEMPERATURE` | Chatbot | Sampling temperature (default `0.7`) |

---

## MCP Tools Exposed

Both servers expose the same logical tools:

| Tool | Parameters | Description |
|---|---|---|
| `get_weather` | `city`, `units` | Current temperature, condition, humidity, wind |
| `get_forecast` | `city`, `days` (1–5) | Multi-day high/low and conditions |
| `compare_weather` | `cities[]`, `units` | Side-by-side comparison of multiple cities |

---

## Core Concepts

### 1 — Model Context Protocol (MCP)

MCP is an open standard for connecting LLM applications to external tools and data sources.
It defines a **JSON-RPC 2.0** message format and a set of standard methods:

| Method | What it does |
|---|---|
| `initialize` | Handshake — server declares its protocol version and capabilities |
| `notifications/initialized` | Client acknowledges the handshake |
| `tools/list` | Client asks what tools the server exposes |
| `tools/call` | Client invokes a named tool with arguments |

### 2 — Transports

MCP is transport-agnostic. The same JSON-RPC messages can travel over different channels:

| Transport | How it works | When to use |
|---|---|---|
| **stdio** | Server is a subprocess; messages over stdin/stdout | Local tools, VS Code/Claude Desktop extensions |
| **SSE** (`/sse`) | HTTP server + Server-Sent Events stream | Web-accessible, multi-client, older FastMCP |
| **streamable-http** (`/mcp`) | HTTP POST with optional SSE streaming | Modern default; tools can `yield` partial results |

This demo uses **streamable-http**, which is the current recommended transport for
production MCP servers.

### 3 — FastMCP

FastMCP wraps the MCP protocol so you define tools as plain Python functions:

```python
from fastmcp import FastMCP
mcp = FastMCP("My Server")

@mcp.tool()
def my_tool(param: str) -> str:
    """Tool description shown to the LLM."""
    return f"result for {param}"

mcp.run(transport="streamable-http", host="0.0.0.0", port=8001)
```

FastMCP reads the type hints and docstring to generate the `inputSchema` that MCP
clients use to understand how to call the tool.

### 4 — Amazon Bedrock Tool Calling

The chatbot registers MCP tools with Bedrock's Converse API using the `toolConfig` parameter:

```python
tool_config = {"tools": [{"toolSpec": {"name": ..., "description": ..., "inputSchema": {"json": ...}}}]}
response = bedrock.converse(modelId=..., messages=..., toolConfig=tool_config)
```

When the model decides to call a tool (`stopReason == "tool_use"`), the app:
1. Reads the `toolUse` content blocks in `response["output"]["message"]`
2. Calls `mcp_client.call_tool(name, input)` on the MCP server for each one
3. Appends the results as `toolResult` content blocks in a new `user` turn
4. Calls the LLM again with the updated history

This loop repeats until the model produces a final text reply.

### 5 — Agentic Loop

```
User question
     │
     ▼
Amazon Bedrock (with toolConfig)
     │
     ├─ stopReason = "tool_use" ──────► Execute tool via MCP ──► append toolResult ──┐
     │                                                                                 │
     └─ stopReason = "end_turn" ──────► Final reply to user  ◄───────────────────────┘
```

The model autonomously decides which tools to call, in what order, and when enough
information has been gathered to answer the user.

---

## Dependencies

```bash
pip install fastmcp streamlit boto3 python-dotenv requests
```
