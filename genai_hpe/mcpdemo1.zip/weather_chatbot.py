"""
Weather Chatbot — Streamlit UI
Connects to the local weather MCP server (streamable-http) and uses Amazon Bedrock
to answer weather questions via tool calling.

Start the MCP server first:  python weather_http_server.py
Then run this app:            streamlit run weather_chatbot.py
"""

import json
import os
import requests
import boto3
from dotenv import load_dotenv
import streamlit as st

load_dotenv()

MCP_SERVER_URL = "http://localhost:8001/mcp"

AWS_ACCESS_KEY_ID     = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION            = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID              = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
MAX_TOKENS            = int(os.getenv("BEDROCK_MAX_TOKENS", "512"))
TEMPERATURE           = float(os.getenv("BEDROCK_TEMPERATURE", "0.7"))

SYSTEM_PROMPT = """You are a helpful weather assistant. You have tools available to get current weather and forecast data for any location.
Always use the tools when weather data is requested. After getting data, give a
friendly, practical response — mention what to wear, whether an umbrella is needed, etc."""


# ── Synchronous MCP HTTP client ───────────────────────────────────────────────

class MCPClient:
    """Minimal synchronous client for MCP streamable-http servers."""

    def __init__(self, url: str):
        self.url = url
        self.session_id: str | None = None
        self._req_id = 0

    def _next_id(self) -> int:
        self._req_id += 1
        return self._req_id

    def _post(self, method: str, params: dict | None = None) -> dict:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        if self.session_id:
            headers["Mcp-Session-Id"] = self.session_id

        payload: dict = {"jsonrpc": "2.0", "id": self._next_id(), "method": method}
        if params is not None:
            payload["params"] = params

        resp = requests.post(self.url, json=payload, headers=headers, timeout=15)
        resp.raise_for_status()

        if "Mcp-Session-Id" in resp.headers:
            self.session_id = resp.headers["Mcp-Session-Id"]

        ct = resp.headers.get("Content-Type", "")
        if "text/event-stream" in ct:
            for line in resp.text.splitlines():
                if line.startswith("data:"):
                    data = line[5:].strip()
                    if data and data != "[DONE]":
                        return json.loads(data)
            return {}
        return resp.json()

    def initialize(self):
        self._post("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "weather-chatbot", "version": "1.0"},
        })
        try:
            h = {"Content-Type": "application/json"}
            if self.session_id:
                h["Mcp-Session-Id"] = self.session_id
            requests.post(
                self.url,
                json={"jsonrpc": "2.0", "method": "notifications/initialized"},
                headers=h,
                timeout=5,
            )
        except Exception:
            pass

    def list_tools(self) -> list[dict]:
        r = self._post("tools/list")
        return r.get("result", {}).get("tools", [])

    def call_tool(self, name: str, arguments: dict) -> str:
        r = self._post("tools/call", {"name": name, "arguments": arguments})
        content = r.get("result", {}).get("content", [])
        texts = [c["text"] for c in content if c.get("type") == "text"]
        return "\n".join(texts) if texts else str(r.get("result", "No result"))


# ── Session state init ────────────────────────────────────────────────────────

def _init_state():
    defaults = {
        "messages": [],          # chat history shown in UI
        "llm_history": [],       # full Bedrock Converse-format history (incl. tool use/result blocks)
        "mcp_client": None,
        "mcp_tools": [],
        "mcp_error": None,
        "connected": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v


_init_state()


# ── MCP connection helper ─────────────────────────────────────────────────────

def connect_mcp(url: str):
    try:
        client = MCPClient(url)
        client.initialize()
        tools = client.list_tools()
        st.session_state.mcp_client = client
        st.session_state.mcp_tools  = tools
        st.session_state.mcp_error  = None
        st.session_state.connected  = True
        return True, tools
    except Exception as exc:
        st.session_state.mcp_error  = str(exc)
        st.session_state.connected  = False
        return False, []


def mcp_tools_to_bedrock(tools: list[dict]) -> list[dict]:
    """Convert MCP tool descriptors to Bedrock Converse API toolSpec format."""
    return [
        {
            "toolSpec": {
                "name": t["name"],
                "description": t.get("description", ""),
                "inputSchema": {
                    "json": t.get("inputSchema", {"type": "object", "properties": {}}),
                },
            }
        }
        for t in tools
    ]


# ── LLM + tool-calling loop ───────────────────────────────────────────────────

def run_agent(user_message: str) -> str:
    """Send user message to Amazon Bedrock, handle tool calls, return final reply."""
    bedrock = boto3.client(
        "bedrock-runtime",
        region_name=AWS_REGION,
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    )

    st.session_state.llm_history.append({"role": "user", "content": [{"text": user_message}]})
    tools = mcp_tools_to_bedrock(st.session_state.mcp_tools)
    tool_config = {"tools": tools} if tools else None

    for _ in range(5):  # safety cap on tool-call rounds
        kwargs = dict(
            modelId=MODEL_ID,
            system=[{"text": SYSTEM_PROMPT}],
            messages=st.session_state.llm_history,
            inferenceConfig={"maxTokens": MAX_TOKENS, "temperature": TEMPERATURE},
        )
        if tool_config:
            kwargs["toolConfig"] = tool_config

        response = bedrock.converse(**kwargs)
        output_message = response["output"]["message"]
        st.session_state.llm_history.append(output_message)

        if response.get("stopReason") != "tool_use":
            texts = [block["text"] for block in output_message["content"] if "text" in block]
            reply = "\n".join(texts)
            return reply

        # Execute every toolUse block the model asked for, collect toolResult blocks
        tool_result_blocks = []
        for block in output_message["content"]:
            if "toolUse" not in block:
                continue
            tool_use = block["toolUse"]
            fn_name = tool_use["name"]
            fn_args = tool_use.get("input", {})

            with st.spinner(f"Calling tool `{fn_name}`…"):
                result = st.session_state.mcp_client.call_tool(fn_name, fn_args)

            tool_result_blocks.append({
                "toolResult": {
                    "toolUseId": tool_use["toolUseId"],
                    "content": [{"text": result}],
                }
            })

        st.session_state.llm_history.append({"role": "user", "content": tool_result_blocks})

    return "I wasn't able to complete the request after several tool calls."


# ── UI ────────────────────────────────────────────────────────────────────────

st.set_page_config(page_title="Weather Chatbot", page_icon="🌤", layout="wide")
st.title("🌤 Weather Chatbot")
st.caption("Powered by Amazon Bedrock + MCP weather tools")

# Sidebar ── connection panel
with st.sidebar:
    st.header("MCP Server")
    server_url = st.text_input("Server URL", value=MCP_SERVER_URL)

    if st.button("Connect", use_container_width=True):
        with st.spinner("Connecting…"):
            ok, tools = connect_mcp(server_url)
        if ok:
            st.success(f"Connected — {len(tools)} tool(s)")
        else:
            st.error(f"Failed: {st.session_state.mcp_error}")

    if st.session_state.connected:
        st.markdown("**Tools available:**")
        for t in st.session_state.mcp_tools:
            st.markdown(f"- `{t['name']}`: {t.get('description','')[:60]}…")

    st.divider()
    st.header("Amazon Bedrock")
    st.caption(f"Model: `{MODEL_ID}`")
    st.caption(f"Region: `{AWS_REGION}`")

    st.divider()
    if st.button("Clear conversation", use_container_width=True):
        st.session_state.messages    = []
        st.session_state.llm_history = []
        st.rerun()

# Auto-connect on first load
if not st.session_state.connected and not st.session_state.mcp_error:
    with st.spinner("Auto-connecting to MCP server…"):
        connect_mcp(MCP_SERVER_URL)

# Connection status banner
if not st.session_state.connected:
    st.warning(
        f"Not connected to MCP server at `{MCP_SERVER_URL}`. "
        "Start `weather_http_server.py` and click **Connect** in the sidebar."
    )

# Render chat history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input
if prompt := st.chat_input("Ask me about the weather anywhere…", disabled=not st.session_state.connected):
    # Show user message immediately
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Get assistant response
    with st.chat_message("assistant"):
        with st.spinner("Thinking…"):
            reply = run_agent(prompt)
        st.markdown(reply)

    st.session_state.messages.append({"role": "assistant", "content": reply})
