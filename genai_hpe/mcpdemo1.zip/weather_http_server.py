"""
Weather MCP Server — streamable-http transport
Runs at http://localhost:8001/mcp

Start:  python weather_http_server.py
Test:   python test_weather_http_client.py
"""

import os
import random
from datetime import datetime, timedelta
from dotenv import load_dotenv
from fastmcp import FastMCP
import requests as http_requests

load_dotenv()

HOST = "0.0.0.0"
PORT = 8001

mcp = FastMCP("Weather MCP Server")


def _unit_symbols(units: str) -> tuple[str, str]:
    if units == "imperial":
        return "°F", "mph"
    if units == "kelvin":
        return "K", "m/s"
    return "°C", "m/s"


@mcp.tool()
def get_weather(city: str, units: str = "metric") -> str:
    """
    Get current weather for a city.

    Args:
        city:  City name (e.g. "London", "Tokyo")
        units: "metric" (°C), "imperial" (°F), or "kelvin"
    """
    api_key = os.getenv("OPENWEATHERMAP_API_KEY", "")
    unit_sym, speed_unit = _unit_symbols(units)

    if not api_key:
        # Mock data so the demo works without an API key
        return (
            f"Weather in {city}: 22{unit_sym}, Partly cloudy, "
            f"Humidity 65%, Wind 10 {speed_unit}  [mock — set OPENWEATHERMAP_API_KEY for live data]"
        )

    try:
        resp = http_requests.get(
            "http://api.openweathermap.org/data/2.5/weather",
            params={"q": city, "appid": api_key, "units": units},
            timeout=10,
        )
        resp.raise_for_status()
        d = resp.json()
        return (
            f"Weather in {d['name']}, {d['sys']['country']}: "
            f"{d['main']['temp']}{unit_sym}, {d['weather'][0]['description'].capitalize()}, "
            f"Humidity {d['main']['humidity']}%, "
            f"Wind {d['wind']['speed']} {speed_unit}, "
            f"Pressure {d['main']['pressure']} hPa"
        )
    except Exception as exc:
        return f"Error fetching weather for '{city}': {exc}"


@mcp.tool()
def get_forecast(city: str, days: int = 3) -> str:
    """
    Get a multi-day weather forecast for a city.

    Args:
        city: City name
        days: Number of days to forecast (1–5)
    """
    days = max(1, min(days, 5))
    api_key = os.getenv("OPENWEATHERMAP_API_KEY", "")

    if not api_key:
        # Mock forecast
        conditions = ["Sunny", "Cloudy", "Rainy", "Partly Cloudy", "Thunderstorms"]
        lines = [f"Forecast for {city} ({days} days):"]
        for i in range(days):
            date = (datetime.now() + timedelta(days=i)).strftime("%Y-%m-%d")
            high = random.randint(18, 32)
            low = random.randint(8, 17)
            cond = random.choice(conditions)
            lines.append(f"  {date}: {cond}, High {high}°C, Low {low}°C")
        lines.append("[mock data — set OPENWEATHERMAP_API_KEY for live data]")
        return "\n".join(lines)

    try:
        # OWM free tier provides 3-hour intervals; we pick one per day
        resp = http_requests.get(
            "http://api.openweathermap.org/data/2.5/forecast",
            params={"q": city, "appid": api_key, "units": "metric", "cnt": days * 8},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()

        seen_dates: set[str] = set()
        lines = [f"Forecast for {data['city']['name']}, {data['city']['country']}:"]
        for item in data["list"]:
            date = item["dt_txt"].split(" ")[0]
            if date not in seen_dates:
                seen_dates.add(date)
                lines.append(
                    f"  {date}: {item['weather'][0]['description'].capitalize()}, "
                    f"{item['main']['temp_min']:.0f}–{item['main']['temp_max']:.0f}°C"
                )
            if len(seen_dates) >= days:
                break
        return "\n".join(lines)
    except Exception as exc:
        return f"Error fetching forecast for '{city}': {exc}"


@mcp.tool()
def compare_weather(cities: list[str], units: str = "metric") -> str:
    """
    Compare current weather across multiple cities.

    Args:
        cities: List of city names to compare
        units:  "metric", "imperial", or "kelvin"
    """
    results = []
    for city in cities:
        results.append(f"• {get_weather(city, units)}")
    return "\n".join(results)


if __name__ == "__main__":
    print(f"[{datetime.now().strftime('%H:%M:%S')}] Weather MCP server → http://localhost:{PORT}/mcp")
    mcp.run(transport="streamable-http", host=HOST, port=PORT)
