import os
import re
import requests
import boto3
from dotenv import load_dotenv
import streamlit as st


def _find_dotenv():
    current = os.path.abspath(os.getcwd())
    while True:
        candidate = os.path.join(current, ".env")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            print("Error: .env file not found in current directory or any parent directory.")
            raise SystemExit(1)
        current = parent


load_dotenv(dotenv_path=_find_dotenv())

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

if not OPENWEATHERMAP_API_KEY:
    st.error("OPENWEATHERMAP_API_KEY is not set in .env — add it and restart the app.")
    st.stop()

st.title("Agent and Function Calling Demo")

st.markdown("""
This demo showcases **tool/function calling** with LLM. The model can get external tools
(like a weather API) invoked when needed to answer your questions.
- Enter a question like: **"What's the weather in New York?"**
- Ask follow-up questions like "What's there to see?" — history is passed to the LLM each turn.
""")

# Initialize session state
if "bedrock_messages" not in st.session_state:
    st.session_state.bedrock_messages = []  # full history sent to Bedrock API
if "display_messages" not in st.session_state:
    st.session_state.display_messages = []  # (role, text) pairs for chat display
if "last_debug" not in st.session_state:
    st.session_state.last_debug = None

with st.sidebar:
    st.markdown(f"**Region:** {AWS_REGION}")
    st.markdown(f"**Model:** {MODEL_ID}")


def get_weather(location: str) -> str:
    """Get current weather for a location."""
    print("get weather function called. Parameter passed:", location)
    url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={OPENWEATHERMAP_API_KEY}"
    response = requests.get(url)
    get_response = response.json()

    if not get_response:
        return f"Could not find location: {location}"

    latitude = get_response[0]['lat']
    longitude = get_response[0]['lon']

    url_final = f"https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={OPENWEATHERMAP_API_KEY}&units=metric"
    final_response = requests.get(url_final)
    final_response_json = final_response.json()

    weather = (f"Weather: {final_response_json['weather'][0]['description']}, "
               f"Temperature: {final_response_json['main']['temp']}°C")
    return weather


# Bedrock tool definition
TOOLS = [
    {
        "toolSpec": {
            "name": "get_weather",
            "description": "Retrieve real-time weather information/data about a particular location/place",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "The exact location whose real-time weather is to be determined"
                        }
                    },
                    "required": ["location"]
                }
            }
        }
    }
]

# System prompt to guide the model's behavior around tool use
# In this prompt we instruct the model to only use tools when the user explicitly asks for that information, 
# and to ask clarifying questions if the user's intent is unclear.
# SYSTEM_PROMPT = (
#     "You are a helpful assistant. "
#     "Only use tools when the user explicitly asks for that information in a complete sentence or question. "
#     "If the intent is unclear from the user's input, "
#     "respond by asking what they would like to know. Never assume intent from a single word."
# )

# In this version of the system prompt, we give the model more discretion to use tools when it thinks it's appropriate, 
# but still instruct it to ask clarifying questions if the user's intent is unclear.
SYSTEM_PROMPT = (
     "You are a helpful assistant. "
     "Use tools at your discretion to answer the user's questions"
     "but only when you are confident that the tool will help you provide a more accurate or complete answer. "
     "If no tools are needed, respond directly to the user's question without using tools. "
     "If the intent is unclear from the user's input, "
     "respond by asking what they would like to know. Never assume intent from a single word."
 )



def generate_response(input_text):
    bedrock_rt = boto3.client("bedrock-runtime", region_name=AWS_REGION)
    debug = {"turns": []}

    # Append user message to history and display
    st.session_state.bedrock_messages.append(
        {"role": "user", "content": [{"text": input_text}]}
    )
    st.session_state.display_messages.append(("user", input_text))

    with st.spinner('Processing...'):
        turn1_request = {
            "messages": list(st.session_state.bedrock_messages),
            "tools": TOOLS,
            "system": SYSTEM_PROMPT,
        }

        response = bedrock_rt.converse(
            modelId=MODEL_ID,
            system=[{"text": SYSTEM_PROMPT}],
            messages=st.session_state.bedrock_messages,
            toolConfig={"tools": TOOLS}
        )

        stop_reason = response["stopReason"]
        assistant_content = response["output"]["message"]["content"]

        turn1 = {
            "turn": 1,
            "request": turn1_request,
            "response_stop_reason": stop_reason,
        }

        # Check if the model wants to call a tool
        if stop_reason == "tool_use":
            tool_use_block = next(b for b in assistant_content if "toolUse" in b)
            function_name = tool_use_block["toolUse"]["name"]
            function_args = tool_use_block["toolUse"]["input"]
            tool_use_id = tool_use_block["toolUse"]["toolUseId"]

            turn1["response_type"] = "tool_call"
            turn1["tool_call"] = {
                "tool_name": function_name,
                "tool_use_id": tool_use_id,
                "arguments": function_args,
            }
            turn1["raw_response_content"] = assistant_content
            debug["turns"].append(turn1)

            # Call the function dynamically by name
            try:
                result = globals()[function_name](**function_args)
            except KeyError:
                result = f"Unknown function: {function_name}"

            # Append tool use + tool result to Bedrock history
            st.session_state.bedrock_messages.append(
                {"role": "assistant", "content": assistant_content}
            )
            st.session_state.bedrock_messages.append({
                "role": "user",
                "content": [
                    {
                        "toolResult": {
                            "toolUseId": tool_use_id,
                            "content": [{"text": str(result)}]
                        }
                    }
                ]
            })

            turn2_request = {
                "messages": list(st.session_state.bedrock_messages),
                "tools": TOOLS,
                "system": SYSTEM_PROMPT,
            }

            response = bedrock_rt.converse(
                modelId=MODEL_ID,
                system=[{"text": SYSTEM_PROMPT}],
                messages=st.session_state.bedrock_messages,
                toolConfig={"tools": TOOLS}
            )

            stop_reason2 = response["stopReason"]
            resp = response["output"]["message"]["content"][0]["text"]

            turn2 = {
                "turn": 2,
                "request": turn2_request,
                "response_stop_reason": stop_reason2,
                "response_type": "text",
                "response_text": resp,
            }
            debug["turns"].append(turn2)
        else:
            resp = assistant_content[0]["text"]
            turn1["response_type"] = "text"
            turn1["response_text"] = resp
            debug["turns"].append(turn1)

    st.session_state.last_debug = debug

    # Append final assistant reply to history and display
    st.session_state.bedrock_messages.append(
        {"role": "assistant", "content": [{"text": resp}]}
    )
    st.session_state.display_messages.append(("assistant", resp))


# Render conversation history
for role, text in st.session_state.display_messages:
    with st.chat_message(role):
        if role == "assistant":
            thinking_match = re.search(r"<thinking>(.*?)</thinking>", text, flags=re.DOTALL)
            clean = re.sub(r"<thinking>.*?</thinking>", "", text, flags=re.DOTALL).strip()
            if thinking_match:
                with st.expander("Thinking...", expanded=False):
                    st.markdown(thinking_match.group(1).strip())
            st.markdown(f"**{clean}**")
        else:
            st.markdown(text)

# Chat input
if prompt := st.chat_input("Ask about the weather..."):
    generate_response(prompt)
    st.rerun()

if st.sidebar.button("Clear conversation"):
    st.session_state.bedrock_messages = []
    st.session_state.display_messages = []
    st.session_state.last_debug = None
    st.rerun()

if st.session_state.last_debug:
    st.divider()
    st.subheader("LLM Context Inspector")
    for turn in st.session_state.last_debug["turns"]:
        turn_num = turn["turn"]
        with st.expander(f"Turn {turn_num} — Request", expanded=True):
            st.caption("Messages sent to LLM")
            st.json(turn["request"]["messages"])
            st.caption("Tools sent to LLM")
            st.json(turn["request"]["tools"])

        with st.expander(f"Turn {turn_num} — Response", expanded=True):
            stop_reason = turn["response_stop_reason"]
            resp_type = turn["response_type"]

            if resp_type == "tool_call":
                st.markdown(f"**Response type:** `tool_call` (stopReason: `{stop_reason}`)")
                st.markdown(f"**Tool called:** `{turn['tool_call']['tool_name']}`")
                st.caption("Tool call details")
                st.json(turn["tool_call"])
                st.caption("Raw assistant content")
                st.json(turn["raw_response_content"])
            else:
                st.markdown(f"**Response type:** `text` (stopReason: `{stop_reason}`)")
                st.caption("Response text")
                st.write(turn.get("response_text", ""))
