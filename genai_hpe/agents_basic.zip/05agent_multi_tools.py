import json
import os
import requests
import yfinance as yf
from datetime import datetime
from dotenv import load_dotenv
import boto3
import streamlit as st


def _find_dotenv():
    current = os.path.abspath(os.getcwd())
    while True:
        candidate = os.path.join(current, ".env")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            print("Error: .env file not found in current directory or any parent directory.")
            raise SystemExit(1)
        current = parent


load_dotenv(dotenv_path=_find_dotenv())

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

if not OPENWEATHERMAP_API_KEY:
    st.error("OPENWEATHERMAP_API_KEY is not set in .env — add it and restart the app.")
    st.stop()

# App title and description
st.title("Multipurpose Assistant (Amazon Bedrock)")
st.markdown("Ask me about weather or stock prices!")

# Initialize chat history in session state
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])


# Function to get weather data
def get_weather(location: str, days: int = 1) -> dict:
    """
    Get weather forecast for a location.

    Args:
        location: City or location name
        days: Number of days to forecast (default 1)

    Returns:
        Weather forecast data
    """
    print(f"Getting weather for location: {location}, days: {days}")

    geo_url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={OPENWEATHERMAP_API_KEY}"
    geo_response = requests.get(geo_url)

    if geo_response.status_code != 200:
        return {"error": f"Could not retrieve location data. Status code: {geo_response.status_code}"}

    geo_data = geo_response.json()
    if not geo_data:
        return {"error": f"Location '{location}' not found."}

    latitude = geo_data[0]['lat']
    longitude = geo_data[0]['lon']

    weather_url = f"http://api.openweathermap.org/data/2.5/forecast?lat={latitude}&lon={longitude}&appid={OPENWEATHERMAP_API_KEY}&units=metric"
    weather_response = requests.get(weather_url)

    if weather_response.status_code != 200:
        return {"error": f"Could not retrieve weather data. Status code: {weather_response.status_code}"}

    weather_data = weather_response.json()

    entries_per_day = 8
    total_entries = min(entries_per_day * days, len(weather_data['list']))

    forecasts = []
    for forecast in weather_data['list'][:total_entries]:
        forecasts.append({
            'time': forecast['dt_txt'],
            'description': forecast['weather'][0]['description'],
            'rain_probability': forecast.get('pop', 0) * 100,
            'temp': forecast['main']['temp'],
            'humidity': forecast['main']['humidity'],
            'wind_speed': forecast['wind']['speed']
        })

    return {
        'location': location,
        'forecast': forecasts
    }


# Function to get stock information
def get_stock_price(symbol: str) -> dict:
    """
    Get the latest stock price and information for a given ticker symbol.

    Args:
        symbol: Stock ticker symbol (e.g., 'AAPL' for Apple)

    Returns:
        Stock information including price, change, and company details
    """
    try:
        stock = yf.Ticker(symbol)
        stock_info = stock.info

        hist = stock.history(period="2d")

        if hist.empty:
            return {"error": f"No data available for symbol '{symbol}'"}

        latest_close = hist['Close'].iloc[-1]
        previous_close = hist['Close'].iloc[0] if len(hist) > 1 else latest_close
        change = latest_close - previous_close
        change_percent = (change / previous_close) * 100 if previous_close else 0

        return {
            'symbol': symbol,
            'company_name': stock_info.get('shortName', 'N/A'),
            'latest_price': float(latest_close),
            'currency': stock_info.get('currency', 'USD'),
            'change': float(change),
            'change_percent': float(change_percent),
            'previous_close': float(previous_close),
            'market_cap': stock_info.get('marketCap', 'N/A'),
            'volume': int(hist['Volume'].iloc[-1]) if 'Volume' in hist else 'N/A',
            'exchange': stock_info.get('exchange', 'N/A'),
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

    except Exception as e:
        return {"error": f"Could not retrieve stock information for '{symbol}'. {str(e)}"}


# Function to get company information
def get_company_info(symbol: str) -> dict:
    """
    Get detailed information about a company by its stock ticker symbol.

    Args:
        symbol: Stock ticker symbol (e.g., 'AAPL' for Apple)

    Returns:
        Company information including business summary, sector, industry, etc.
    """
    try:
        stock = yf.Ticker(symbol)
        info = stock.info

        return {
            'symbol': symbol,
            'name': info.get('shortName', 'N/A'),
            'long_name': info.get('longName', 'N/A'),
            'sector': info.get('sector', 'N/A'),
            'industry': info.get('industry', 'N/A'),
            'employees': info.get('fullTimeEmployees', 'N/A'),
            'website': info.get('website', 'N/A'),
            'business_summary': info.get('longBusinessSummary', 'N/A'),
            'country': info.get('country', 'N/A'),
            'city': info.get('city', 'N/A')
        }

    except Exception as e:
        return {"error": f"Could not retrieve company information for '{symbol}'. {str(e)}"}


def format_function_result(function_name: str, result: dict) -> str:
    """Format the result of a function call for the model."""
    if "error" in result:
        return result["error"]

    if function_name == "get_weather":
        weather_summary = f"Weather forecast for {result['location']}:\n\n"
        for forecast in result['forecast']:
            weather_summary += f"- {forecast['time']}: {forecast['description'].capitalize()}, {forecast['temp']}°C, Rain: {forecast['rain_probability']}%\n"
        return weather_summary

    elif function_name == "get_stock_price":
        change_symbol = "+" if result['change'] >= 0 else ""
        return (f"Stock: {result['company_name']} ({result['symbol']})\n"
                f"Price: {result['latest_price']:.2f} {result['currency']}\n"
                f"Change: {change_symbol}{result['change']:.2f} ({change_symbol}{result['change_percent']:.2f}%)\n"
                f"Previous Close: {result['previous_close']:.2f}\n"
                f"Volume: {result['volume']}\n"
                f"As of: {result['timestamp']}")

    elif function_name == "get_company_info":
        return (f"Company: {result['name']} ({result['symbol']})\n"
                f"Full Name: {result['long_name']}\n"
                f"Sector: {result['sector']}\n"
                f"Industry: {result['industry']}\n"
                f"Employees: {result['employees']}\n"
                f"Country: {result['country']}\n\n"
                f"Summary: {result['business_summary'][:500]}...")

    return json.dumps(result, indent=2)


# Bedrock tool definitions
TOOLS = [
    {
        "toolSpec": {
            "name": "get_weather",
            "description": "Get weather forecast for a location",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "City or location name"
                        },
                        "days": {
                            "type": "integer",
                            "description": "Number of days to forecast (default 1)"
                        }
                    },
                    "required": ["location"]
                }
            }
        }
    },
    {
        "toolSpec": {
            "name": "get_stock_price",
            "description": "Get the latest stock price and information for a given ticker symbol",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "symbol": {
                            "type": "string",
                            "description": "Stock ticker symbol (e.g., 'AAPL' for Apple, 'GOOGL' for Google)"
                        }
                    },
                    "required": ["symbol"]
                }
            }
        }
    },
    {
        "toolSpec": {
            "name": "get_company_info",
            "description": "Get detailed information about a company by its stock ticker symbol",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "symbol": {
                            "type": "string",
                            "description": "Stock ticker symbol (e.g., 'AAPL' for Apple)"
                        }
                    },
                    "required": ["symbol"]
                }
            }
        }
    }
]

SYSTEM_PROMPT = """
You are a helpful assistant that can provide information about weather and stock prices.

You have access to several tools:
- get_weather: Get weather forecast for a location
- get_stock_price: Get latest stock price information for a ticker symbol
- get_company_info: Get detailed information about a company

When handling requests:

For weather queries:
1. Identify if a location is mentioned. If not, ask for it.
2. Use the get_weather function to retrieve weather data.
3. Provide a helpful response based on the forecast.

For stock/company queries:
1. Identify the stock ticker symbol. Common examples: AAPL (Apple), GOOGL (Google), MSFT (Microsoft), TSLA (Tesla)
2. Use the appropriate function to get stock prices or company information.
3. Provide a concise summary of the important financial information.

Always respond in a helpful, informative manner.
"""


def generate_response(input_text):
    bedrock_rt = boto3.client("bedrock-runtime", region_name=AWS_REGION)

    messages = [{"role": "user", "content": [{"text": input_text}]}]

    response = bedrock_rt.converse(
        modelId=MODEL_ID,
        system=[{"text": SYSTEM_PROMPT}],
        messages=messages,
        toolConfig={"tools": TOOLS}
    )

    # Check if the model wants to call a tool
    if response["stopReason"] == "tool_use":
        assistant_content = response["output"]["message"]["content"]

        tool_use_block = next(b for b in assistant_content if "toolUse" in b)
        function_name = tool_use_block["toolUse"]["name"]
        function_args = tool_use_block["toolUse"]["input"]
        tool_use_id = tool_use_block["toolUse"]["toolUseId"]

        # Convert any float args to int if needed (e.g., days parameter)
        if 'days' in function_args:
            function_args['days'] = int(function_args['days'])

        # Execute the function dynamically by name
        try:
            result = globals()[function_name](**function_args)
        except KeyError:
            result = {"error": f"Unknown function: {function_name}"}

        formatted_result = format_function_result(function_name, result)

        # Send the function result back to the model
        messages.append({"role": "assistant", "content": assistant_content})
        messages.append({
            "role": "user",
            "content": [
                {
                    "toolResult": {
                        "toolUseId": tool_use_id,
                        "content": [{"text": formatted_result}]
                    }
                }
            ]
        })

        response = bedrock_rt.converse(
            modelId=MODEL_ID,
            system=[{"text": SYSTEM_PROMPT}],
            messages=messages,
            toolConfig={"tools": TOOLS}
        )

        return response["output"]["message"]["content"][0]["text"]
    else:
        return response["output"]["message"]["content"][0]["text"]


# User input via chat interface
if prompt := st.chat_input("Ask me about weather or stocks..."):
    st.session_state.messages.append({"role": "user", "content": prompt})

    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            response = generate_response(prompt)
            st.markdown(response)

    st.session_state.messages.append({"role": "assistant", "content": response})

# Sidebar with app information
with st.sidebar:
    st.header("Multipurpose Assistant")
    st.markdown(f"""
    This assistant uses **Amazon Nova** and can help with:

    **Weather Information**
    - Current weather conditions
    - Weather forecasts
    - Rain predictions

    **Stock Market Data**
    - Latest stock prices
    - Price changes and trends
    - Company information

    **Region:** {AWS_REGION}
    **Model:** {MODEL_ID}
    """)

    st.subheader("Sample Questions")
    st.markdown("""
    **Weather Examples:**
    - "What's the weather in Tokyo?"
    - "Will it rain in New York tomorrow?"

    **Stock Examples:**
    - "What's the price of Apple stock?"
    - "How is TSLA performing today?"
    - "Tell me about Microsoft"
    """)

    st.markdown("---")
    st.markdown("""
    **Requirements:**
    ```
    pip install streamlit python-dotenv requests yfinance boto3
    ```
    """)
