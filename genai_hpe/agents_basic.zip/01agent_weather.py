import os
import requests
import boto3
from dotenv import load_dotenv


def _find_dotenv():
    current = os.path.abspath(os.getcwd())
    while True:
        candidate = os.path.join(current, ".env")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            print("Error: .env file not found in current directory or any parent directory.")
            raise SystemExit(1)
        current = parent


load_dotenv(dotenv_path=_find_dotenv())

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

if not OPENWEATHERMAP_API_KEY:
    print("Error: OPENWEATHERMAP_API_KEY is not set in .env")
    raise SystemExit(1)


# Define these functions at the module level so they can be called dynamically
def get_weather(location: str) -> str:
    """Retrieve real-time weather information about a particular location."""
    print("Getting weather for: " + location)
    url = "http://api.openweathermap.org/geo/1.0/direct?q=" + location + "&limit=1&appid=" + OPENWEATHERMAP_API_KEY
    response = requests.get(url, verify=False)
    print(response)
    get_response = response.json()

    if not get_response:
        return f"Could not find location: {location}"

    latitude = get_response[0]['lat']
    longitude = get_response[0]['lon']

    url_final = "https://api.openweathermap.org/data/2.5/weather?lat=" + str(latitude) + "&lon=" + \
        str(longitude) + "&appid=" + OPENWEATHERMAP_API_KEY + "&units=metric"
    final_response = requests.get(url_final, verify=False)
    final_response_json = final_response.json()

    weather = (f"Weather: {final_response_json['weather'][0]['description']}\n"
               f"Temperature: {final_response_json['main']['temp']}°C\n"
               f"Humidity: {final_response_json['main']['humidity']}%")
    print(weather)
    return weather


def get_latlong(location: str) -> str:
    """Retrieve latitude and longitude for a particular location."""
    print("Getting lat/long for: " + location)
    url = "http://api.openweathermap.org/geo/1.0/direct?q=" + location + "&limit=1&appid=" + OPENWEATHERMAP_API_KEY
    response = requests.get(url, verify=False)
    print(response)
    get_response = response.json()

    if not get_response:
        return f"Could not find location: {location}"

    latitude = get_response[0]['lat']
    longitude = get_response[0]['lon']

    result = f"Latitude: {latitude}, Longitude: {longitude}"
    print(result)
    return result


def main():
    bedrock_rt = boto3.client("bedrock-runtime", region_name=AWS_REGION)
    print(f"Using Amazon Bedrock model: {MODEL_ID}, region: {AWS_REGION}")

    # Define tools in Bedrock toolSpec format
    tools = [
        {
            "toolSpec": {
                "name": "get_weather",
                "description": "Retrieve real-time weather information/data about a particular location/place",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "location": {
                                "type": "string",
                                "description": "The exact location whose real-time weather is to be determined"
                            }
                        },
                        "required": ["location"]
                    }
                }
            }
        },
        {
            "toolSpec": {
                "name": "get_latlong",
                "description": "Retrieve latitude and longitude information about a particular location/place",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "location": {
                                "type": "string",
                                "description": "The exact location whose latitude and longitude is to be determined"
                            }
                        },
                        "required": ["location"]
                    }
                }
            }
        }
    ]

    user_message = "How is the weather in Mumbai?"
    print(f"\nUser: {user_message}")

    messages = [
        {"role": "user", "content": [{"text": user_message}]}
    ]

    response = bedrock_rt.converse(
        modelId=MODEL_ID,
        system=[{"text": "You are a helpful weather assistant."}],
        messages=messages,
        toolConfig={"tools": tools}
    )

    # Check if the model wants to call a tool
    if response["stopReason"] == "tool_use":
        assistant_content = response["output"]["message"]["content"]

        tool_use_block = next(b for b in assistant_content if "toolUse" in b)
        function_name = tool_use_block["toolUse"]["name"]
        function_args = tool_use_block["toolUse"]["input"]
        tool_use_id = tool_use_block["toolUse"]["toolUseId"]

        print(f"\nLLM returned a function call response for: {function_name}")
        print(f"Arguments: {function_args}")

        # Call the function dynamically by name
        try:
            result = globals()[function_name](**function_args)
        except KeyError:
            result = f"Unknown function: {function_name}"

        print(f"\nFunction result: {result}")

        # Send the function result back to the model
        messages.append({"role": "assistant", "content": assistant_content})
        messages.append({
            "role": "user",
            "content": [
                {
                    "toolResult": {
                        "toolUseId": tool_use_id,
                        "content": [{"text": str(result)}]
                    }
                }
            ]
        })

        response = bedrock_rt.converse(
            modelId=MODEL_ID,
            system=[{"text": "You are a helpful weather assistant."}],
            messages=messages,
            toolConfig={"tools": tools}
        )

        final_response = response["output"]["message"]["content"][0]["text"]
        print(f"\nAssistant: {final_response}")
    else:
        print(f"\nAssistant: {response['output']['message']['content'][0]['text']}")


if __name__ == "__main__":
    main()
