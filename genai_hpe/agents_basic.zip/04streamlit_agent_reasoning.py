import os
import re
import requests
import boto3
from dotenv import load_dotenv
import streamlit as st


def _find_dotenv():
    current = os.path.abspath(os.getcwd())
    while True:
        candidate = os.path.join(current, ".env")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            print("Error: .env file not found in current directory or any parent directory.")
            raise SystemExit(1)
        current = parent


load_dotenv(dotenv_path=_find_dotenv())

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

if not OPENWEATHERMAP_API_KEY:
    st.error("OPENWEATHERMAP_API_KEY is not set in .env — add it and restart the app.")
    st.stop()

# App title
st.title("Weather Assistant - Umbrella Advisor (Amazon Bedrock)")
st.markdown("Ask me if you should carry an umbrella tomorrow!")

# Initialize chat history in session state
if "messages" not in st.session_state:
    st.session_state.messages = []

# Bedrock chat history (role/content pairs) kept separate from display messages
if "bedrock_messages" not in st.session_state:
    st.session_state.bedrock_messages = []
if "last_debug" not in st.session_state:
    st.session_state.last_debug = None

# Bedrock tool definition
WEATHER_TOOL = {
    "toolSpec": {
        "name": "get_weather",
        "description": "Retrieve weather forecast for tomorrow for a specific location",
        "inputSchema": {
            "json": {
                "type": "object",
                "properties": {
                    "location": {
                        "type": "string",
                        "description": "The city or location to get weather information for"
                    }
                },
                "required": ["location"]
            }
        }
    }
}

# ReAct system prompt
SYSTEM_PROMPT = """
You are an intelligent weather assistant that helps users decide if they should carry an umbrella tomorrow.
Follow a ReAct-based approach to reason about the weather before responding.

Steps to follow:
1. Identify if the user has mentioned a location.
   - If no location is provided, ask the user to specify one.
2. Retrieve the weather forecast for the given location.
3. Based on the forecast, decide whether carrying an umbrella is necessary.
   - Consider rain probability, weather descriptions like "rain", "drizzle", "shower", etc.
   - If any period tomorrow has >30% chance of rain or contains rain-related terms, recommend an umbrella.
4. Explain your reasoning in a natural, conversational manner.

Example Responses:
- "You do not need to carry an umbrella tomorrow as the weather in {location} is sunny with only a 5% chance of precipitation."
- "Yes, you should carry an umbrella as there is a high chance of rain in {location} tomorrow afternoon, with a 60% probability of precipitation."

Always provide your reasoning based on the actual forecast data.
"""


# Function to get weather data
def get_weather(location: str) -> dict:
    """Get weather forecast for a location."""
    print(f"Getting weather for location: {location}")

    geo_url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={OPENWEATHERMAP_API_KEY}"
    geo_response = requests.get(geo_url)

    if geo_response.status_code != 200:
        return {"error": f"Could not retrieve location data. Status code: {geo_response.status_code}"}

    geo_data = geo_response.json()
    if not geo_data:
        return {"error": f"Location '{location}' not found."}

    latitude = geo_data[0]['lat']
    longitude = geo_data[0]['lon']

    weather_url = f"http://api.openweathermap.org/data/2.5/forecast?lat={latitude}&lon={longitude}&appid={OPENWEATHERMAP_API_KEY}&units=metric"
    weather_response = requests.get(weather_url)

    if weather_response.status_code != 200:
        return {"error": f"Could not retrieve weather data. Status code: {weather_response.status_code}"}

    weather_data = weather_response.json()

    tomorrow_forecasts = []
    for forecast in weather_data['list'][:8]:
        forecast_time = forecast['dt_txt']
        description = forecast['weather'][0]['description']
        rain_probability = forecast.get('pop', 0) * 100

        tomorrow_forecasts.append({
            'time': forecast_time,
            'description': description,
            'rain_probability': rain_probability,
            'temp': forecast['main']['temp']
        })

    return {
        'location': location,
        'forecast': tomorrow_forecasts
    }


def generate_response(input_text):
    bedrock_rt = boto3.client("bedrock-runtime", region_name=AWS_REGION)
    debug = {"turns": []}

    # Append user message to Bedrock conversation history
    st.session_state.bedrock_messages.append(
        {"role": "user", "content": [{"text": input_text}]}
    )

    turn1_request = {
        "messages": list(st.session_state.bedrock_messages),
        "tools": [WEATHER_TOOL],
        "system": SYSTEM_PROMPT,
    }

    response = bedrock_rt.converse(
        modelId=MODEL_ID,
        system=[{"text": SYSTEM_PROMPT}],
        messages=st.session_state.bedrock_messages,
        toolConfig={"tools": [WEATHER_TOOL]}
    )

    stop_reason = response["stopReason"]
    assistant_content = response["output"]["message"]["content"]

    turn1 = {
        "turn": 1,
        "request": turn1_request,
        "response_stop_reason": stop_reason,
    }

    # Check if the model wants to call a tool
    if stop_reason == "tool_use":
        tool_use_block = next(b for b in assistant_content if "toolUse" in b)
        function_name = tool_use_block["toolUse"]["name"]
        function_args = tool_use_block["toolUse"]["input"]
        tool_use_id = tool_use_block["toolUse"]["toolUseId"]

        turn1["response_type"] = "tool_call"
        turn1["tool_call"] = {
            "tool_name": function_name,
            "tool_use_id": tool_use_id,
            "arguments": function_args,
        }
        turn1["raw_response_content"] = assistant_content
        debug["turns"].append(turn1)

        location = function_args.get('location')
        if not location:
            st.session_state.last_debug = debug
            return "I'd be happy to help! To check if you need an umbrella tomorrow, could you please tell me your location?"

        try:
            weather_data = globals()[function_name](**function_args)
        except KeyError:
            st.session_state.last_debug = debug
            return f"Unknown function: {function_name}"

        if "error" in weather_data:
            st.session_state.last_debug = debug
            return f"I'm sorry, I couldn't get the weather information: {weather_data['error']}"

        weather_summary = f"Weather forecast for {weather_data['location']} for tomorrow:\n\n"
        for forecast in weather_data['forecast']:
            weather_summary += f"- {forecast['time']}: {forecast['description'].capitalize()}, {forecast['temp']}°C, Rain probability: {forecast['rain_probability']}%\n"

        # Add assistant tool-use turn and tool result to history
        st.session_state.bedrock_messages.append(
            {"role": "assistant", "content": assistant_content}
        )
        st.session_state.bedrock_messages.append({
            "role": "user",
            "content": [
                {
                    "toolResult": {
                        "toolUseId": tool_use_id,
                        "content": [{"text": weather_summary}]
                    }
                }
            ]
        })

        turn2_request = {
            "messages": list(st.session_state.bedrock_messages),
            "tools": [WEATHER_TOOL],
            "system": SYSTEM_PROMPT,
        }

        response = bedrock_rt.converse(
            modelId=MODEL_ID,
            system=[{"text": SYSTEM_PROMPT}],
            messages=st.session_state.bedrock_messages,
            toolConfig={"tools": [WEATHER_TOOL]}
        )

        stop_reason2 = response["stopReason"]
        final_text = response["output"]["message"]["content"][0]["text"]

        turn2 = {
            "turn": 2,
            "request": turn2_request,
            "response_stop_reason": stop_reason2,
            "response_type": "text",
            "response_text": final_text,
        }
        debug["turns"].append(turn2)
        st.session_state.last_debug = debug

        # Add final assistant response to history
        st.session_state.bedrock_messages.append(
            {"role": "assistant", "content": [{"text": final_text}]}
        )
        return final_text
    else:
        text = assistant_content[0]["text"]
        turn1["response_type"] = "text"
        turn1["response_text"] = text
        debug["turns"].append(turn1)
        st.session_state.last_debug = debug

        st.session_state.bedrock_messages.append(
            {"role": "assistant", "content": [{"text": text}]}
        )
        return text


# Display chat history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        if message["role"] == "assistant":
            text = message["content"]
            thinking_match = re.search(r"<thinking>(.*?)</thinking>", text, flags=re.DOTALL)
            clean = re.sub(r"<thinking>.*?</thinking>", "", text, flags=re.DOTALL).strip()
            if thinking_match:
                with st.expander("Thinking...", expanded=False):
                    st.markdown(thinking_match.group(1).strip())
            st.markdown(f"**{clean}**")
        else:
            st.markdown(message["content"])

# User input via chat interface
if prompt := st.chat_input("Type your question here..."):
    st.session_state.messages.append({"role": "user", "content": prompt})

    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            response = generate_response(prompt)
            thinking_match = re.search(r"<thinking>(.*?)</thinking>", response, flags=re.DOTALL)
            clean_response = re.sub(r"<thinking>.*?</thinking>", "", response, flags=re.DOTALL).strip()
            if thinking_match:
                with st.expander("Thinking...", expanded=False):
                    st.markdown(thinking_match.group(1).strip())
            st.markdown(f"**{clean_response}**")

    st.session_state.messages.append({"role": "assistant", "content": response})

# Sidebar with app information
with st.sidebar:
    st.header("About")
    st.markdown(f"""
    This Weather Assistant uses:
    - **Amazon Nova** for reasoning
    - **OpenWeatherMap API** for real-time weather data
    - **ReAct approach** for planning and execution

    **Region:** {AWS_REGION}
    **Model:** {MODEL_ID}

    Ask if you should carry an umbrella tomorrow!
    """)

    st.subheader("Sample Questions")
    st.markdown("""
    - Should I bring an umbrella tomorrow?
    - Will it rain tomorrow in Seattle?
    - Do I need an umbrella in London tomorrow?
    """)

    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.session_state.bedrock_messages = []
        st.session_state.last_debug = None
        st.rerun()

if st.session_state.last_debug:
    st.divider()
    st.subheader("LLM Context Inspector")
    for turn in st.session_state.last_debug["turns"]:
        turn_num = turn["turn"]
        with st.expander(f"Turn {turn_num} — Request", expanded=True):
            st.caption("Messages sent to LLM")
            st.json(turn["request"]["messages"])
            st.caption("Tools sent to LLM")
            st.json(turn["request"]["tools"])

        with st.expander(f"Turn {turn_num} — Response", expanded=True):
            stop_reason = turn["response_stop_reason"]
            resp_type = turn["response_type"]

            if resp_type == "tool_call":
                st.markdown(f"**Response type:** `tool_call` (stopReason: `{stop_reason}`)")
                st.markdown(f"**Tool called:** `{turn['tool_call']['tool_name']}`")
                st.caption("Tool call details")
                st.json(turn["tool_call"])
                st.caption("Raw assistant content")
                st.json(turn["raw_response_content"])
            else:
                st.markdown(f"**Response type:** `text` (stopReason: `{stop_reason}`)")
                st.caption("Response text")
                st.write(turn.get("response_text", ""))
