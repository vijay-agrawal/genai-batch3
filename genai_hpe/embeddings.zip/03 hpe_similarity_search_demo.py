"""
=============================================================================
HPE REAL-WORLD DEMO — Semantic Similarity Search for Server Operations
=============================================================================

SCENARIO: You are building an AI-assisted triage tool for HPE infrastructure.
When a new server alert fires — an iLO event, a firmware failure, a CI/CD
pipeline error — you want to instantly surface the most similar PAST incidents
that were already diagnosed and resolved.

  Keyword search fails here:
    new alert   → "POST error on memory slot A2"
    past ticket → "DIMM initialization fault during boot on A2"   ← no shared keywords!

  Semantic search succeeds:  both describe the same thing in different words.

THE FOUR SECTIONS:
------------------
  1. Why keyword search fails on HPE log entries
  2. iLO / IML alert matching  (firmware & QA engineers)
  3. CI/CD pipeline failure triage  (DevOps & QA automation engineers)
  4. GreenLake runbook retrieval  (cloud & server-management engineers)

DEPENDENCIES:  sentence-transformers, numpy
=============================================================================
"""

import numpy as np
from sentence_transformers import SentenceTransformer

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def cos_sim(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-10))


def rank_and_print(query: str, corpus: list[dict], model: SentenceTransformer,
                   top_k: int = 3, label_key: str = "text") -> None:
    q_vec = model.encode([query])[0]
    p_vecs = model.encode([item[label_key] for item in corpus])
    scored = sorted(
        zip(corpus, p_vecs),
        key=lambda x: cos_sim(q_vec, x[1]),
        reverse=True,
    )
    print(f'\n  QUERY: "{query}"\n')
    for rank, (item, pvec) in enumerate(scored[:top_k], 1):
        sim = cos_sim(q_vec, pvec)
        bar = "█" * int(sim * 40)
        print(f"  #{rank}  sim={sim:.4f}  {bar}")
        print(f'         Alert : {item[label_key]}')
        if "resolution" in item:
            print(f'         Fix   : {item["resolution"]}')
        print()


def pause():
    input("\n  [Press Enter to continue...]\n")


# ─────────────────────────────────────────────────────────────────────────────
# Load model
# ─────────────────────────────────────────────────────────────────────────────
print("Loading all-MiniLM-L6-v2 …  (first run downloads ~90 MB, cached after)")
model = SentenceTransformer("all-MiniLM-L6-v2")
print("Model ready.\n")


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 — Why keyword search fails on HPE logs
#
#   Engineers on-call often search IML (Integrated Management Log) entries
#   using grep or Splunk keyword filters.  The same failure is described in
#   dozens of different ways:
#     iLO firmware  → "DIMM installation error"
#     OS EDAC driver → "CE on DIMM_A2: corrected hardware memory error"
#     Vendor ticket  → "memory module fault, slot A2, POST incomplete"
#   Keyword search misses cross-system matches.  Semantic search does not.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 65)
print("SECTION 1 — Keyword search vs Semantic search on HPE log entries")
print("=" * 65)

KEYWORD_QUERY = "POST error memory slot A2"

log_entries = [
    "DIMM installation fault during system boot on slot A2",            # same issue, no shared keywords
    "Memory initialization failure: DIMM_A2 not recognized by BIOS",   # same issue, different phrasing
    "POST error on memory slot A2 detected",                            # exact keyword match
    "NIC link down on FlexLOM port 1, check cable",                    # unrelated
    "iLO fan speed threshold exceeded in zone 2",                      # unrelated
]

print(f'\n  Keyword query: "{KEYWORD_QUERY}"\n')
print("  ── Keyword (grep) results ──────────────────────────────────────")
kw_tokens = set(KEYWORD_QUERY.lower().split())
for entry in log_entries:
    entry_tokens = set(entry.lower().split())
    overlap = len(kw_tokens & entry_tokens)
    if overlap >= 2:
        print(f"  [MATCH]  {entry}")

print()
print("  Keyword search MISSES the first two entries — they describe the")
print("  exact same failure in different words (BIOS vs POST, slot vs DIMM).")
print()
print("  ── Semantic (embedding) results ────────────────────────────────")

q_vec = model.encode([KEYWORD_QUERY])[0]
p_vecs = model.encode(log_entries)
scored = sorted(zip(log_entries, p_vecs), key=lambda x: cos_sim(q_vec, x[1]), reverse=True)
for rank, (entry, pvec) in enumerate(scored, 1):
    sim = cos_sim(q_vec, pvec)
    bar = "█" * int(sim * 40)
    print(f"  #{rank}  sim={sim:.4f}  {bar}")
    print(f'         "{entry}"')
    print()

print("  → Semantic search surfaces the DIMM/BIOS variants at #1/#2 even")
print("    though they share almost no words with the query.")

pause()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 — iLO / IML alert matching
#
#   Context for firmware + QA engineers:
#   Your lab has a history of resolved iLO/IML incidents with root-cause notes.
#   When a new alert fires, you want to instantly find the top-3 past incidents
#   that look most similar — so the on-call engineer sees the resolution before
#   they even open a browser.
#
#   HPE iLO (Integrated Lights-Out): the out-of-band management controller
#   IML  (Integrated Management Log): the hardware event log on ProLiant servers
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 65)
print("SECTION 2 — iLO / IML alert matching")
print("(Firmware engineers & QA: find similar past resolved incidents)")
print("=" * 65)

RESOLVED_INCIDENTS = [
    {
        "text": "DL380 Gen10: iLO reported correctable memory error on DIMM slot 3A, server continued running",
        "resolution": "Replaced DIMM in slot 3A. Errors cleared after reboot. Monitor for 48 h.",
    },
    {
        "text": "ProLiant DL360 Gen10: POST hung at memory initialization, BIOS code 5A6",
        "resolution": "Reseated all DIMMs. Bad DIMM in A2 confirmed by memtest86. Replaced.",
    },
    {
        "text": "iLO thermal alert: CPU1 inlet temp exceeded 42°C threshold, fan zone 1 ramped to 100%",
        "resolution": "Cleaned air filter. Repositioned 2U server in rack for proper airflow. Temp normalised.",
    },
    {
        "text": "Smart Array P408i-a: physical drive predictive failure on port 1I:1:1",
        "resolution": "Drive replaced under warranty. Array rebuilt overnight. Verify backup before swap.",
    },
    {
        "text": "iLO firmware update failed on DL560 Gen10 — rollback triggered automatically",
        "resolution": "Cleared iLO NVRam, re-flashed using iLO 5 v2.81 offline SPP. Update succeeded.",
    },
    {
        "text": "HPE Ethernet 10Gb 2-port 562FLR: NIC teaming failover logged, link degraded on port 0",
        "resolution": "Replaced SFP+ module. Link restored. Teaming re-verified in iLO network config.",
    },
    {
        "text": "DL380 Gen10 HPE Persistent Memory (NVDIMM) health warning: media wearout > 80%",
        "resolution": "NVDIMM replaced. Backup policy confirmed. No data loss.",
    },
    {
        "text": "Server failed to boot after firmware SPP update: boot device not found",
        "resolution": "iLO settings reset. Boot order reprogrammed via UEFI shell. Root cause: SPP cleared NVRam.",
    },
]

new_alerts = [
    "DL360: uncorrectable memory error logged, BIOS halted at startup with POST code 5A6",
    "iLO 5 update on ProLiant server aborted mid-flash, server stuck at POST",
    "Sensor reading: CPU package temperature climbing, fans not spinning up",
]

for alert in new_alerts:
    rank_and_print(alert, RESOLVED_INCIDENTS, model, top_k=2)
    print("  " + "-" * 60)

print("  → Engineers see the resolution note instantly — no ticket search needed.")

pause()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 — CI/CD pipeline failure triage
#
#   Context for DevOps & QA Automation engineers:
#   A firmware validation pipeline (Jenkins / GitHub Actions) produces hundreds
#   of failure strings per day.  A new failure string should be matched against
#   a library of known-cause patterns so the engineer sees the likely root
#   cause without reading logs manually.
#
#   This mirrors what every QA automation engineer does in triage today —
#   except today they do it with grep and muscle memory.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 65)
print("SECTION 3 — CI/CD pipeline failure triage")
print("(DevOps & QA Automation: auto-classify build failures)")
print("=" * 65)

KNOWN_FAILURE_PATTERNS = [
    {
        "text": "pytest: test_ilo_redfish_api.py FAILED — ConnectionRefusedError on port 443",
        "resolution": "iLO not reachable from CI runner. Check VPN/lab network, or restart iLO network stack.",
    },
    {
        "text": "SPP firmware flash timed out after 600 s waiting for POST completion",
        "resolution": "Lab server did not reboot cleanly post-flash. Power-cycle via iLO and re-run job.",
    },
    {
        "text": "Docker image pull failed: toomanyrequests — rate limit hit on Docker Hub",
        "resolution": "Use HPE internal registry mirror. Update pipeline to pull from registry.hpe.internal.",
    },
    {
        "text": "Ansible playbook failed: unreachable host hpe-lab-dl380-07 — SSH timeout",
        "resolution": "Lab node offline. Check iLO console, may need manual power-on via GreenLake portal.",
    },
    {
        "text": "Memory stress test (memtester) reported bit-flip error on 8 GB allocation",
        "resolution": "Known flaky DIMM on hpe-lab-dl380-03. File HW defect ticket, skip node in test pool.",
    },
    {
        "text": "Jenkins pipeline aborted: no available executor on label 'firmware-lab'",
        "resolution": "All firmware lab runners are busy or offline. Scale up runner pool or queue and wait.",
    },
    {
        "text": "Redfish API returned HTTP 503 during firmware inventory collection",
        "resolution": "iLO overloaded — this happens during concurrent SPP flashing. Stagger pipeline runs.",
    },
    {
        "text": "pytest: 3 tests deselected, 0 tests ran — no tests matched selector 'ilo_v5'",
        "resolution": "Test selector typo. The correct marker is 'ilo5' (no underscore). Fix pytest.ini.",
    },
]

new_failures = [
    "CI job failed: requests.exceptions.ConnectionError — https://192.168.10.45:443 refused",
    "Pipeline step 'flash_bios' hung for 12 minutes with no POST signal from the server",
    "pytest collected 0 items using -k 'ilo_v5' — nothing ran, job marked green incorrectly",
]

for failure in new_failures:
    rank_and_print(failure, KNOWN_FAILURE_PATTERNS, model, top_k=2)
    print("  " + "-" * 60)

print("  → Failure descriptions phrased differently by Jenkins, pytest,")
print("    and Ansible are all matched to the correct known pattern.")

pause()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 — GreenLake runbook retrieval
#
#   Context for cloud & server-management engineers:
#   HPE GreenLake operations teams maintain runbooks (SOPs) for common tasks.
#   An operator who doesn't know the exact runbook title should be able to
#   describe their problem in plain English and get the right procedure back.
#
#   This is the retrieval step of a RAG (Retrieval-Augmented Generation) pipeline:
#   embed the query → find top-K runbook chunks → send to LLM → get answer.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 65)
print("SECTION 4 — GreenLake runbook / SOP retrieval (plain-English query)")
print("(Cloud & server-mgmt engineers: the retrieval layer of a RAG system)")
print("=" * 65)

RUNBOOK_CHUNKS = [
    {
        "text": "To add compute capacity to a GreenLake Flex Solutions pool, navigate to HPE GreenLake Central > Manage > Compute Ops Manager > Resource Pools and click 'Add Server'.",
        "source": "Runbook: GreenLake Compute Pool Expansion",
    },
    {
        "text": "Before decommissioning an HPE ProLiant server from GreenLake, ensure the node is drained in the orchestrator (Kubernetes/ESXi), iLO is factory-reset, and the asset is unlinked from the GreenLake workspace.",
        "source": "Runbook: Server Decommission Checklist",
    },
    {
        "text": "To apply a firmware baseline across a fleet of ProLiant servers, create an SPP (Service Pack for ProLiant) baseline in Compute Ops Manager, assign it to a server group, and schedule the compliance job during the maintenance window.",
        "source": "Runbook: Fleet Firmware Compliance",
    },
    {
        "text": "iLO Federation allows managing groups of iLO interfaces from a single browser session. Configure Federation groups under iLO Administration > Management > iLO Federation and push group keys to all nodes.",
        "source": "Runbook: iLO Federation Setup",
    },
    {
        "text": "To rotate iLO credentials in a GreenLake-managed environment, use the Compute Ops Manager API: PATCH /compute-ops/v1beta2/servers/{id}/settings with the updated iloSettings payload.",
        "source": "Runbook: iLO Credential Rotation",
    },
    {
        "text": "HPE GreenLake generates monthly usage reports by service. Export billing data via GreenLake Central > Billing & Subscriptions > Export CSV. Use the 'compute-instances' resource type filter for IaaS workloads.",
        "source": "Runbook: GreenLake Billing Export",
    },
    {
        "text": "When a server shows Non-Compliant in Compute Ops Manager firmware view, check the SPP baseline version, verify server model compatibility, and re-run the compliance scan after network connectivity to iLO is confirmed.",
        "source": "Runbook: Firmware Non-Compliance Troubleshooting",
    },
    {
        "text": "To integrate HPE GreenLake with AWS, deploy the HPE GreenLake for Hybrid Cloud connector, configure IAM cross-account roles, and register the GreenLake workspace endpoint in AWS Service Catalog.",
        "source": "Runbook: GreenLake–AWS Integration",
    },
]

print("\n  (Each chunk comes from a different runbook — operator asks in plain English)\n")

operator_queries = [
    "How do I update the firmware on all servers at once?",
    "I need to add more servers to our cloud pool",
    "My server shows non-compliant in the dashboard, what do I do?",
    "How do I connect GreenLake to our AWS environment?",
]

for query in operator_queries:
    q_vec = model.encode([query])[0]
    p_vecs = model.encode([r["text"] for r in RUNBOOK_CHUNKS])
    scored = sorted(zip(RUNBOOK_CHUNKS, p_vecs), key=lambda x: cos_sim(q_vec, x[1]), reverse=True)

    top = scored[0]
    sim = cos_sim(q_vec, top[1])
    bar = "█" * int(sim * 40)
    print(f'  Q: "{query}"')
    print(f"     sim={sim:.4f}  {bar}")
    print(f'     → [{top[0]["source"]}]')
    print(f'       {top[0]["text"][:90]}…')
    print()

print("  → In a full RAG pipeline, these top-K chunks are passed as context")
print("    to an LLM (e.g. claude-sonnet-4-6) which generates a grounded answer.")
print("    The embedding step here IS that retrieval layer.")


print("\n" + "=" * 65)
print("DEMO COMPLETE — Key takeaways for HPE engineers")
print("=" * 65)
print("""
  1. Semantic search finds what keyword/grep search misses.
     Same failure, different words → same embedding neighborhood.

  2. The pattern is identical across all three use cases:
       embed corpus once  →  embed query at runtime  →  cosine rank
     Whether the corpus is IML alerts, CI failure strings, or runbook chunks.

  3. This is the retrieval layer of every RAG (Retrieval-Augmented Generation)
     system.  Swap the small in-memory list for a vector database (pgvector,
     OpenSearch k-NN, Pinecone) and you have a production-scale system.

  4. all-MiniLM-L6-v2 (~23 M params) runs on a laptop CPU in milliseconds.
     For HPE-specific terminology (iLO, SPP, Redfish, GreenLake) you can
     fine-tune it on your own incident history with as few as 500 examples.
""")
