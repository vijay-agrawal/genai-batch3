"""
=============================================================================
CONTEXTUAL EMBEDDINGS DEMO — BERT + Sentence-Transformers
=============================================================================

WHAT ARE CONTEXTUAL EMBEDDINGS?
---------------------------------
Unlike static embeddings (Word2Vec, GloVe) that give every word a FIXED
vector, contextual embeddings produce a DIFFERENT vector for the same token
depending on the full sentence surrounding it.

  "I sat on the river BANK"       → bank gets vector A
  "I went to the BANK to deposit" → bank gets vector B   (A ≠ B)

HOW BERT WORKS (in brief):
---------------------------
  BERT (Devlin et al., 2018) is a Transformer encoder pretrained with two
  objectives on BookCorpus + English Wikipedia (~3.3B words):

  1. Masked Language Modeling (MLM):
       15 % of tokens are masked → model predicts the original token.
       Forces every token to attend to ALL other tokens in the sentence.

  2. Next Sentence Prediction (NSP):
       Given two sentences A, B, predict if B follows A in the corpus.
       (Later models like RoBERTa dropped NSP — MLM alone is sufficient.)

  Architecture — bert-base-uncased:
    • 12 Transformer encoder layers (blocks)
        WHY MULTIPLE LAYERS?
        One self-attention pass only mixes information from immediate neighbours
        (weighted, but still a single round of "who attends to whom").  Stacking
        12 layers creates a HIERARCHY of representations:
          Layer  1–3  : surface syntax — POS tags, morphology, local phrase structure
          Layer  4–8  : semantic roles — subject/object, coreference, named entities
          Layer  9–12 : task-level semantics — entailment, polysemy resolution
        By the time a token reaches layer 12 it has seen every other token's
        information filtered through 11 increasingly abstract lenses — far richer
        than any single attention pass could produce.
    • 12 attention heads per layer
    • Hidden size  : 768  (each token's vector at every layer is 768-dim)
    • Feed-forward : 3072
        WHAT IS 3072?
        After self-attention each token's 768-dim vector passes through a
        position-wise Feed-Forward Network (FFN):
          768  →  3072  (linear + GELU activation)   ← expand by 4×
          3072 →   768  (linear)                      ← project back
        The 4× expansion (768 × 4 = 3072) is the standard ratio from the
        original Transformer paper ("Attention is All You Need", Vaswani 2017).
        The wider intermediate layer gives the model capacity to learn
        non-linear feature combinations that self-attention alone cannot capture.
    • Parameters   : ~110 million
    • Vocabulary   : 30,522 WordPiece sub-word tokens

WHY SELF-ATTENTION MAKES EMBEDDINGS CONTEXTUAL:
------------------------------------------------
  In each Transformer layer every token queries every other token (all-to-all
  attention). The result for token i is a WEIGHTED SUM of all other tokens'
  values — the weights depend on how relevant each token is to token i.

  So after Layer 1, "bank" in "river bank" is already blended with "river",
  while "bank" in "bank deposit" is blended with "deposit".  By Layer 12
  the two representations are geometrically far apart in 768-D space.

=============================================================================
"""

from transformers import BertTokenizer, BertModel
from sentence_transformers import SentenceTransformer
from embedding_utils import cos_sim, get_word_embedding, get_layer_embeddings


def pause():
    input("\n  [Press Enter to continue...]\n")


# ── Load models ───────────────────────────────────────────────────────────────
print("Loading bert-base-uncased  (~440 MB on first run, cached after) …")
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
bert      = BertModel.from_pretrained("bert-base-uncased")
bert.eval()

print("Loading all-MiniLM-L6-v2 (sentence-transformer) …")
st_model = SentenceTransformer("all-MiniLM-L6-v2")
print("Models ready.\n")


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 — Polysemy
#   The same word "bank" appears in two sentences with opposite meanings.
#   BERT should produce DIFFERENT vectors; Word2Vec would give identical ones.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 60)
print("SECTION 1 — Polysemy: same word, different context")
print("=" * 60)

s_river   = "I sat on the grassy bank of the river."
s_finance = "She went to the bank to deposit her salary."

vec_river   = get_word_embedding(bert, tokenizer, s_river,   "bank")
vec_finance = get_word_embedding(bert, tokenizer, s_finance, "bank")
sim = cos_sim(vec_river, vec_finance)

print(f'\n  S1 (geographic) : "{s_river}"')
print(f'  S2 (financial)  : "{s_finance}"')
print(f"\n  Similarity of 'bank' vectors = {sim:.4f}")
print("  → Low score = BERT produced genuinely DIFFERENT vectors.")
print("  → Word2Vec gives 1.000 — it has only ONE vector for 'bank'.")

pause()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 — Layer evolution
#   Watch "bank" transform across BERT's 12 layers.
#   At layer 0 it is a static lookup; by layer 12 context has pulled the two
#   senses far apart.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 60)
print("SECTION 2 — 'bank' similarity across BERT's 12 layers")
print("(river context vs finance context)")
print("=" * 60)

layers_river   = get_layer_embeddings(bert, tokenizer, s_river,   "bank")
layers_finance = get_layer_embeddings(bert, tokenizer, s_finance, "bank")

print(f"\n  {'Stage':12s}  {'sim':>6s}  Bar")
print("  " + "-" * 50)
for i, (v_r, v_f) in enumerate(zip(layers_river, layers_finance)):
    sim   = cos_sim(v_r, v_f)
    bar   = "█" * int(sim * 40)
    label = "embedding" if i == 0 else f"layer {i:2d}"
    print(f"  {label:12s}  {sim:.4f}  {bar}")

print("\n  → Layer 0 = identical (static WordPiece lookup, no context yet).")
print("  → Each attention layer blends in surrounding tokens.")
print("  → By layer 12 the two senses are clearly separated.")

pause()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 — Sentence similarity
#   Using a model fine-tuned for similarity (Sentence-Transformers).
#   A paraphrase should score high; an unrelated sentence should score low.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 60)
print("SECTION 3 — Sentence-level similarity (all-MiniLM-L6-v2)")
print("=" * 60)

anchor     = "The doctor gave the patient some medicine."
paraphrase = "The physician prescribed medication to the ill person."
unrelated  = "The chef prepared a delicious pasta dish."

vecs         = st_model.encode([anchor, paraphrase, unrelated])
sim_para     = cos_sim(vecs[0], vecs[1])
sim_unrelated = cos_sim(vecs[0], vecs[2])

print(f'\n  Anchor     : "{anchor}"')
print(f'  Paraphrase : "{paraphrase}"')
print(f'               → sim = {sim_para:.4f}   (different words, same meaning)')
print(f'\n  Unrelated  : "{unrelated}"')
print(f'               → sim = {sim_unrelated:.4f}   (different topic)')

pause()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 — Semantic retrieval
#   Query vs a small passage set. The top result shares almost no keywords
#   with the query but is semantically the most relevant.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 60)
print("SECTION 4 — Semantic retrieval: query → ranked passages")
print("=" * 60)

query = "What medication helps reduce high blood pressure?"

passages = [
    "Lisinopril is an ACE inhibitor prescribed to treat hypertension.",  # no shared keywords
    "Doctors recommend a low-sodium diet for blood pressure.",            # partial overlap
    "Aspirin relieves mild pain and reduces fever.",                      # medical, off-topic
    "Beta-blockers like metoprolol manage high blood pressure.",          # very relevant
    "Python is a versatile programming language.",                        # unrelated
]

q_vec  = st_model.encode([query])[0]
p_vecs = st_model.encode(passages)
ranked = sorted(zip(passages, p_vecs), key=lambda x: cos_sim(q_vec, x[1]), reverse=True)

print(f'\n  Query: "{query}"\n')
for rank, (passage, pvec) in enumerate(ranked, 1):
    sim = cos_sim(q_vec, pvec)
    bar = "█" * int(sim * 40)
    print(f"  #{rank}  sim={sim:.4f}  {bar}")
    print(f'       "{passage}"')
    print()

print("  → #1 (Lisinopril) shares almost NO keywords with the query,")
print("    yet ranks first — embeddings capture meaning beyond word overlap.")


print("\n" + "=" * 60)
print("DEMO COMPLETE")
print("=" * 60)
