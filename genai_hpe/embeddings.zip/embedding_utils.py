"""
Shared helpers for the contextual-embeddings demo.
"""
import numpy as np
import torch
from scipy.spatial.distance import cosine


def cos_sim(a, b):
    """Cosine similarity: 1 = identical direction, 0 = orthogonal."""
    return float(1 - cosine(a, b))


def _find_word_span(tokenizer, sentence: str, word: str):
    """Return (start, end) token indices for the first occurrence of `word`."""
    token_ids   = tokenizer(sentence, return_tensors="pt")["input_ids"][0].tolist()
    tokens      = tokenizer.convert_ids_to_tokens(token_ids)
    target_toks = tokenizer.convert_ids_to_tokens(
                      tokenizer.encode(word, add_special_tokens=False))
    n = len(target_toks)
    for i in range(len(tokens) - n + 1):
        if tokens[i : i + n] == target_toks:
            return i, i + n
    raise ValueError(f"'{word}' not found in tokenised sentence: {tokens}")


def get_word_embedding(bert, tokenizer, sentence: str, word: str) -> np.ndarray:
    """Last-layer contextual vector for `word` in `sentence` (sub-tokens averaged)."""
    inputs = tokenizer(sentence, return_tensors="pt")
    start, end = _find_word_span(tokenizer, sentence, word)
    with torch.no_grad():
        outputs = bert(**inputs)
    hidden = outputs.last_hidden_state[0]           # [seq_len, 768]
    return hidden[start:end].mean(dim=0).numpy()


def get_layer_embeddings(bert, tokenizer, sentence: str, word: str) -> list:
    """
    Returns a list of 13 vectors — one per output of each stage:
      index 0   : static WordPiece embedding (before any attention)
      index 1-12: output of each of the 12 Transformer encoder layers
    """
    inputs = tokenizer(sentence, return_tensors="pt")
    start, end = _find_word_span(tokenizer, sentence, word)
    with torch.no_grad():
        outputs = bert(**inputs, output_hidden_states=True)
    return [h[0, start:end].mean(0).numpy() for h in outputs.hidden_states]


def analogy(vecs: dict, a: str, b: str, c: str, topn: int = 3) -> list:
    """
    Solve  a : b :: c : ?   via vector arithmetic  query = vec(b) - vec(a) + vec(c).
    Returns the top-n (word, similarity) pairs, excluding a, b, c themselves.
    """
    query = vecs[b] - vecs[a] + vecs[c]
    sims  = [(w, cos_sim(query, v)) for w, v in vecs.items() if w not in {a, b, c}]
    sims.sort(key=lambda x: x[1], reverse=True)
    return sims[:topn]
