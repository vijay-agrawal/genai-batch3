# GenAI Training — AWS Setup Guide

## Step 1 — Install the AWS CLI

Download and install the AWS CLI for your operating system:

| OS | Download | Install |
|----|----------|---------|
| **Windows** | [aws AWSCLIV2.msi](https://awscli.amazonaws.com/AWSCLIV2.msi) | Run the downloaded `.msi` installer and follow the prompts |
| **macOS** | [aws AWSCLIV2.pkg](https://awscli.amazonaws.com/AWSCLIV2.pkg) | Run the downloaded `.pkg` installer and follow the prompts |

After installation, verify it worked by opening a new terminal and running:

```bash
aws --version
```

Expected output (version numbers may differ):

```
aws-cli/2.x.x Python/3.x.x Linux/Windows/Darwin
```
---

## Step 2 — Configure the AWS CLI

Open a terminal and run:

```bash
aws configure
```

Enter the values when prompted:

```
AWS Access Key ID [None]: <your Access Key ID>
AWS Secret Access Key [None]: <your Secret Access Key>
Default region name [None]: us-east-1
Default output format [None]: json
```

## Step 3 — Verify the configuration

```bash
aws sts get-caller-identity
```

Expected output (values will differ):

```json
{
    "UserId": "AIDA...",
    "Account": "123456789012",
    "Arn": "arn:aws:iam::123456789012:user/your-username"
}
```

---