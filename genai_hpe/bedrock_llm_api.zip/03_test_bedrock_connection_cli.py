"""
test_bedrock_connection.py
──────────────────────────
Run this script to verify your Bedrock connection is working.
Works on Mac, Linux, and Windows.

Usage
─────
python test_bedrock_connection.py
"""

import subprocess
import json
import tempfile
import os

MODEL_ID = "amazon.nova-micro-v1:0"

PROMPT = "What is the capital of France?"

BODY = {
    "messages": [
        {"role": "user", "content": [{"text": PROMPT}]}
    ],
    "inferenceConfig": {"max_new_tokens": 150}
}

def test_bedrock():
    print(f"Testing Bedrock connection...")
    print(f"Model : {MODEL_ID}\n")

    # Write request body to a temp file (avoids all shell quoting issues)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as body_file:
        json.dump(BODY, body_file)
        body_path = body_file.name

    # Write response to a temp file
    response_path = body_path.replace(".json", "_response.json")

    try:
        result = subprocess.run(
            [
                "aws", "bedrock-runtime", "invoke-model",
                "--model-id",       MODEL_ID,
                "--body",                f"file://{body_path}",
                "--cli-binary-format",   "raw-in-base64-out",
                "--content-type",        "application/json",
                "--accept",              "application/json",
                response_path,
            ],
            capture_output=True,
            text=True
        )

        # Check for CLI errors
        if result.returncode != 0:
            print("❌ Connection failed.")
            print(result.stderr)
            return

        # Parse and display the response
        with open(response_path) as f:
            response = json.load(f)

        reply = response["output"]["message"]["content"][0]["text"]
        print("✅ Connection successful!")
        print(f"\nPrompt   : {PROMPT}")
        print(f"\nResponse : {reply}")

    finally:
        # Clean up temp files
        os.remove(body_path)
        if os.path.exists(response_path):
            os.remove(response_path)

if __name__ == "__main__":
    test_bedrock()
    