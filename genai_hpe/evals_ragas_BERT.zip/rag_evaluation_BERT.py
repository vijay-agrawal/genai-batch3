# --------------------------------------------------------------------------
# Imports
# --------------------------------------------------------------------------
import numpy as np
from sentence_transformers import SentenceTransformer
from bert_score import score
import faiss
from typing import List, Dict, Any
import torch
from transformers import AutoTokenizer, AutoModelForSeq2Seq

# --------------------------------------------------------------------------
# Test Data
# --------------------------------------------------------------------------
test_data = [
    {
       "prompt": "who has java skills?",
       "ground_truth": "Sujata, Rajesh Chaudhary"
    },
    {
       "prompt": "find candidates with machine learning experience",
       "ground_truth": "Priya Kumar, John Smith, Maria Rodriguez"
    },
    {
       "prompt": "which candidates know Python and SQL?",
       "ground_truth": "John Smith, Maria Rodriguez, David Chen"
    }
    # Add more test items with different queries & ground truths
]

# --------------------------------------------------------------------------
# Helper Functions
# --------------------------------------------------------------------------
def load_resumes() -> List[Dict[str, Any]]:
    """
    Load resume data from your data source.
    Returns a list of resume dictionaries with text and metadata.
    """
    # This is a placeholder - replace with your actual resume loading logic
    return [
        {"id": 1, "text": "Sujata is a senior developer with 5 years of Java experience...", "name": "Sujata"},
        {"id": 2, "text": "Rajesh Chaudhary has worked with Java for 7 years and Spring framework...", "name": "Rajesh Chaudhary"},
        # Add more resumes here
    ]

def setup_embedding_index(resumes: List[Dict[str, Any]]):
    """
    Creates and returns the embedding model and FAISS index for fast similarity search.
    
    Embeddings are needed to convert text into numerical vectors that capture semantic meaning.
    This allows us to find relevant documents by measuring vector similarity rather than
    simple keyword matching.
    """
    # Initialize the embedding model
    embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
    
    # Extract resume texts
    texts = [resume["text"] for resume in resumes]
    
    # Generate embeddings for all resumes
    embeddings = embedding_model.encode(texts)
    
    # Normalize embeddings for cosine similarity
    embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
    
    # Create a FAISS index for fast similarity search
    dimension = embeddings.shape[1]
    index = faiss.IndexFlatIP(dimension)  # Inner product for cosine similarity with normalized vectors
    index.add(embeddings.astype('float32'))
    
    return embedding_model, index

def generate_answer_from_llm(query: str, retrieved_snippets: List[str]) -> str:
    """
    Generate an answer using an LLM based on the query and retrieved snippets.
    
    Args:
        query: The user's question
        retrieved_snippets: Text chunks from relevant documents
    
    Returns:
        Generated answer that responds to the query
    """
    # Example implementation with a Seq2Seq model
    model_name = "t5-base"  # Can be replaced with your preferred model
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSeq2Seq.from_pretrained(model_name)
    
    # Prepare context from retrieved snippets
    context = " ".join(retrieved_snippets)
    
    # Create prompt with query and context
    prompt = f"Question: {query}\nContext: {context}\nAnswer:"
    
    # Generate answer
    inputs = tokenizer(prompt, return_tensors="pt", max_length=512, truncation=True)
    outputs = model.generate(
        inputs.input_ids, 
        max_length=64, 
        num_beams=4, 
        early_stopping=True
    )
    answer = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
    return answer

# --------------------------------------------------------------------------
# Evaluate Over the Test Dataset
# --------------------------------------------------------------------------
def evaluate_rag_system():
    """Evaluate RAG system performance using BERTScore"""
    # Load resume data
    resumes = load_resumes()
    
    # Setup embedding model and index
    embedding_model, index = setup_embedding_index(resumes)
    
    # Initialize results storage
    predictions = []
    references = []
    
    for item in test_data:
        query = item["prompt"]
        ground_truth = item["ground_truth"]
    
        # Retrieve top-k chunks for this query
        # (Embeddings enable semantic search to find relevant resumes)
        query_emb = embedding_model.encode(query).reshape(1, -1)
        query_emb = query_emb / np.linalg.norm(query_emb)  # Normalize for cosine similarity
        distances, indices = index.search(query_emb.astype('float32'), k=3)  # retrieve top-3 docs
        retrieved_indices = indices[0]
    
        # Collect the relevant text from these retrieved docs
        retrieved_snippets = [resumes[idx]["text"] for idx in retrieved_indices]
    
        # Generate the final answer by passing the query and the snippets to the LLM
        answer = generate_answer_from_llm(query, retrieved_snippets)
    
        predictions.append(answer)
        references.append(ground_truth)
    
    # --------------------------------------------------------------------------
    # Calculate BERTScore
    # --------------------------------------------------------------------------
    # BERTScore measures semantic similarity between predictions and references
    # using contextual embeddings from BERT models, going beyond exact string matching.
    
    # Calculate precision, recall, and F1 scores
    # - Precision: How much of the prediction content is in the reference
    # - Recall: How much of the reference content is in the prediction
    # - F1: Harmonic mean of precision and recall
    precision, recall, f1 = score(
        predictions, 
        references, 
        model_type='microsoft/deberta-xlarge-mnli',  # Better language model than bert-base
        lang='en',
        verbose=True
    )
    
    # Calculate averages
    avg_precision = precision.mean().item()
    avg_recall = recall.mean().item() 
    avg_f1 = f1.mean().item()
    
    # Print overall results
    print("\n========== BERTScore Results ==========")
    print(f"Average Precision: {avg_precision:.4f}")
    print(f"Average Recall: {avg_recall:.4f}")
    print(f"Average F1: {avg_f1:.4f}")
    print("=======================================")
    
    # Print detailed results per query
    print("\n========== Detailed Results ==========")
    for i, (pred, ref) in enumerate(zip(predictions, references)):
        print(f"\nQuery {i+1}: {test_data[i]['prompt']}")
        print(f"Prediction: {pred}")
        print(f"Ground Truth: {ref}")
        print(f"BERTScore: P={precision[i].item():.4f}, R={recall[i].item():.4f}, F1={f1[i].item():.4f}")
    
    return {
        "precision": avg_precision,
        "recall": avg_recall,
        "f1": avg_f1,
        "detailed_results": [
            {
                "query": item["prompt"],
                "prediction": pred,
                "reference": ref,
                "precision": p.item(),
                "recall": r.item(),
                "f1": f.item()
            }
            for item, pred, ref, p, r, f in zip(test_data, predictions, references, precision, recall, f1)
        ]
    }

# --------------------------------------------------------------------------
# Execute Evaluation
# --------------------------------------------------------------------------
if __name__ == "__main__":
    results = evaluate_rag_system()