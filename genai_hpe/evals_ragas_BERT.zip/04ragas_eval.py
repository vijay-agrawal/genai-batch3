"""
RAGAS Evaluation Demo — Diagnosing RAG Failures
=================================================
RAGAS (Retrieval Augmented Generation Assessment) gives us per-component metrics
so we can pinpoint WHERE a RAG pipeline broke down:

  RETRIEVAL metrics  →  Was the right information fetched?
    • context_recall     : fraction of ground-truth facts present in the retrieved chunks
    • context_precision  : fraction of retrieved chunks that were actually relevant

  GENERATION metrics  →  Did the LLM use that information correctly?
    • faithfulness       : does the answer only assert things supported by the context?
    • answer_relevancy   : does the answer actually address the question asked?

Diagnostic grid
───────────────
                        context_recall  faithfulness
  Retrieval problem         LOW            LOW/HIGH     → fix chunking / retrieval
  Generation problem        HIGH           LOW          → fix prompt / LLM / temperature
  Both OK                   HIGH           HIGH         → pipeline healthy

This file demonstrates TWO deliberately broken scenarios against HPE ProLiant
server-log data (the same corpus used in 01indexer / 02retriever).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW RAGAS WORKS INTERNALLY — LLM-as-a-Judge
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Yes — RAGAS is fundamentally an LLM-as-a-Judge framework.
Rather than comparing text with string matching or BLEU scores,
it uses a second LLM (the "judge") to reason about quality,
just like a human evaluator would.

Each metric is a small, focused LLM pipeline:

  context_recall  (LLM judge)
  ───────────────────────────
  Input : reference (ground-truth answer) + retrieved_contexts
  Step 1: Judge LLM breaks the reference into individual atomic claims.
          e.g. "CPU1 had a thermal trip" / "fan speed was increased"
  Step 2: For each claim, judge LLM asks:
          "Can this claim be inferred from the retrieved context? Yes/No"
  Score : claims supported by context  ÷  total claims in reference
  → Tells you: did the retriever fetch the docs that contain the answer?

  context_precision  (LLM judge)
  ────────────────────────────────
  Input : user_input + reference + each retrieved chunk individually
  Step 1: For each chunk, judge LLM asks:
          "Is this chunk useful for answering the question? Yes/No"
  Score : weighted precision — relevant chunks ranked higher score more
  → Tells you: was the retrieved context signal or noise?

  faithfulness  (LLM judge, two-step)
  ────────────────────────────────────
  Input : response + retrieved_contexts
  Step 1: Judge LLM extracts every factual claim made in the response.
          e.g. "FAN-1 failed" / "temperature reached 80°C"
  Step 2: For each claim, judge LLM checks:
          "Is this claim directly supported by the context? Yes/No"
  Score : supported claims  ÷  total claims in response
  → Tells you: did the LLM hallucinate, or stay grounded in context?

  answer_relevancy  (LLM + Embeddings)
  ─────────────────────────────────────
  Input : response + user_input
  Step 1: Judge LLM generates N synthetic questions that the response
          could plausibly be answering (reverse-engineering the question).
  Step 2: Embedding model encodes each synthetic question and the
          original user_input into vectors.
  Step 3: Cosine similarity between synthetic questions and user_input.
  Score : mean cosine similarity across all synthetic questions
  → Tells you: does the answer actually address what was asked?
    (A response about NIC errors scores low for a CPU question.)

  Summary of what the judge LLM is actually doing:
  ┌──────────────────────┬────────────────────────────────────────┐
  │ Metric               │ Judge LLM task                         │
  ├──────────────────────┼────────────────────────────────────────┤
  │ context_recall       │ Claim extraction + entailment check    │
  │ context_precision    │ Relevance classification per chunk      │
  │ faithfulness         │ Claim extraction + support check        │
  │ answer_relevancy     │ Reverse question generation             │
  └──────────────────────┴────────────────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHICH LLM IS RAGAS USING HERE? — AWS Bedrock configuration
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RAGAS does NOT hard-code any LLM provider. By default it tries
to use OpenAI (which would fail without an OPENAI_API_KEY).

We override this by passing our own LLM and embeddings at call time:

    result = evaluate(
        dataset,
        metrics=METRICS,
        llm=evaluator_llm,        # ← our Bedrock judge LLM
        embeddings=evaluator_embeddings,  # ← our Bedrock embeddings
    )

The wrappers translate between LangChain's interface and RAGAS's
internal BaseRagasLLM / BaseRagasEmbeddings interfaces:

    LangchainLLMWrapper(ChatBedrock(...))
        ChatBedrock speaks LangChain's .invoke() protocol.
        LangchainLLMWrapper adapts that to what RAGAS expects
        internally (generate_text, a_generate_text, etc.).

    LangchainEmbeddingsWrapper(BedrockEmbeddings(...))
        Only answer_relevancy needs embeddings — the other three metrics
        (context_recall, context_precision, faithfulness) are pure LLM
        yes/no judgement calls and never touch the embedding model.

        Why does answer_relevancy need embeddings?
        answer_relevancy works in two steps:
          Step 1 (LLM): generate ~3 synthetic questions the response
                        could plausibly be answering, e.g.:
                          "What hardware event happened on NODE01?"
                          "Was there a CPU fault on March 18?"
          Step 2 (Embeddings): embed those synthetic questions AND the
                        original user_input, then compute cosine similarity.
                        A relevant answer implies questions that are
                        semantically close to what was actually asked.

        If you remove answer_relevancy from METRICS, you can drop
        evaluator_embeddings entirely and evaluation still works.

So the SAME Bedrock model (amazon.nova-micro-v1:0) that runs the
RAG pipeline is also acting as the RAGAS judge — a valid setup for
air-gapped / dark-site HPE deployments where only one model endpoint
is available.  In production you would typically use a stronger judge
model (e.g. Nova Pro or Claude Sonnet) than your RAG response model.
"""

import os
import boto3
from langchain_aws import BedrockEmbeddings, ChatBedrock
from dotenv import load_dotenv
import pandas as pd

from ragas import EvaluationDataset, SingleTurnSample, evaluate
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
from ragas.metrics import faithfulness, answer_relevancy, context_recall, context_precision

load_dotenv()

# ──────────────────────────────────────────────
# Shared AWS Bedrock setup (LLM + Embeddings)
# ──────────────────────────────────────────────

def _bedrock_client():
    return boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )

evaluator_llm = LangchainLLMWrapper(ChatBedrock(
    client=_bedrock_client(),
    model_id=os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0"),
    model_kwargs={"temperature": 0},
))

evaluator_embeddings = LangchainEmbeddingsWrapper(BedrockEmbeddings(
    client=_bedrock_client(),
    model_id=os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0"),
))


# ══════════════════════════════════════════════════════════════════════════════
# EXAMPLE 1 — RETRIEVAL FAILURE
# ══════════════════════════════════════════════════════════════════════════════
#
# Scenario:
#   The user asks about the CPU thermal trip on NODE01.
#   The retriever returns mostly WRONG chunks (NIC / network events) but also
#   one tangentially related CPU health-check log from earlier that morning —
#   simulating a retriever that "gets close" but misses the critical window.
#   The LLM partially acknowledges the CPU topic but cannot answer specifically.
#
# Expected RAGAS signal:
#   context_recall   → LOW  (~0.1–0.2: reference facts like "thermal trip / 800 MHz"
#                            are absent; only generic CPU mention present)
#   context_precision→ LOW  (~0.2–0.3: 1 of 3 chunks is partially on-topic)
#   faithfulness     → medium (LLM stays within what context says)
#   answer_relevancy → LOW–MEDIUM (~0.3–0.5: mentions CPU + right server/date
#                            but cannot give the actual answer)
#
# FIX: improve chunking granularity, tune embedding model, or add metadata filters.

example1_retrieval_failure = SingleTurnSample(
    # The question the user asked
    user_input=(
        "What CPU error occurred on PROLIANT-DL380-NODE01 at 03:22 on March 18 2026, "
        "and what was the immediate hardware response?"
    ),

    # What the retriever actually returned:
    #   Chunk A — NIC log (irrelevant)
    #   Chunk B — Storage log (irrelevant)
    #   Chunk C — Routine CPU health check from 00:05 same day (partially on-topic
    #             but from 3+ hours before the event; misses the fault entirely)
    retrieved_contexts=[
        (
            "[2026-03-18 07:45:12] PROLIANT-DL380-NODE01 | iLO5 | WARNING | NIC | "
            "NIC1 Mellanox CX-7 25GbE: link-down event detected on port eth0. "
            "Switch port HPE-FlexFabric-5940-A:port-24 reported SFP+ transceiver signal loss. "
            "Multipath failover activated; traffic rerouted to NIC2 (eth1). "
            "Cumulative TX queue overflow: 1,247 packets dropped."
        ),
        (
            "[2026-03-18 09:10:33] PROLIANT-DL380-NODE01 | iLO5 | ERROR | STORAGE | "
            "RAID controller P408i-a: logical drive LD1 (RAID-5) status changed to DEGRADED. "
            "Physical drive bay 3 (SAS 1.8TB 10K) reported predictive failure (SMART threshold exceeded). "
            "Spare drive bay 7 activated; rebuild initiated at 12% completion."
        ),
        # Partial hit — right server, right day, right subsystem (CPU thermal), WRONG time window
        (
            "[2026-03-18 00:05:00] PROLIANT-DL380-NODE01 | iLO5 | INFO | THERMAL | "
            "Scheduled CPU thermal baseline check completed. CPU1 inlet temp: 54°C, "
            "CPU2 inlet temp: 52°C. Both within normal operating range. "
            "Fan speeds nominal. No corrective action required."
        ),
    ],

    # LLM response: acknowledges the CPU context but cannot answer the specific question
    # because the fault-window chunk is missing.
    response=(
        "The retrieved logs for PROLIANT-DL380-NODE01 on March 18 2026 show that CPU "
        "temperatures were normal during the 00:05 baseline check (CPU1: 54°C, CPU2: 52°C). "
        "However, there is no log entry for 03:22 in the provided context, so the specific "
        "CPU error and hardware response at that time cannot be determined from the available data."
    ),

    # The correct answer (what SHOULD have been answered had retrieval worked)
    reference=(
        "At 03:22 on March 18 2026, CPU1 on PROLIANT-DL380-NODE01 experienced a thermal trip. "
        "The iLO5 BMC immediately throttled CPU1 to 800 MHz and increased fan speed to maximum "
        "to protect the hardware. An alert was raised for physical inspection."
    ),
)


# ══════════════════════════════════════════════════════════════════════════════
# EXAMPLE 2 — GENERATION FAILURE (hallucination / unfaithfulness)
# ══════════════════════════════════════════════════════════════════════════════
#
# Scenario:
#   The retriever works perfectly — it fetches the exact log entries describing
#   the MSA 2060 overtemperature event. However, the LLM ignores parts of the
#   context and invents additional "facts" (e.g. wrong component, wrong RCA).
#   This is a classic hallucination / prompt-following failure.
#
# Expected RAGAS signal:
#   context_recall   → HIGH (the relevant chunks ARE in the retrieved context)
#   context_precision→ HIGH (retrieved chunks are highly relevant)
#   faithfulness     → LOW  (LLM asserted things not supported by the context)
#   answer_relevancy → medium/HIGH (the answer is about the right topic, just wrong)
#
# FIX: lower temperature, add "only use context" instructions, switch to a
#      stronger model, or add a self-consistency / citation check step.

example2_generation_failure = SingleTurnSample(
    user_input=(
        "What caused the MSA 2060 overtemperature event on March 20 2026, "
        "and what component failed?"
    ),

    # Retriever returned PERFECT, highly-relevant chunks
    retrieved_contexts=[
        # Chunk A — exact log of the event
        (
            "[2026-03-20 14:33:07] HPE-MSA2060-SAN1 | Controller A | CRITICAL | THERMAL | "
            "Controller A inlet temperature reached 72°C (threshold: 65°C). "
            "Root cause identified: cooling fan module FAN-2 failed (zero RPM). "
            "System automatically failed over all I/O to Controller B. "
            "Admin notified via SNMP trap and email alert."
        ),
        # Chunk B — follow-up resolution log
        (
            "[2026-03-20 16:10:44] HPE-MSA2060-SAN1 | Controller A | INFO | THERMAL | "
            "Replacement fan module FAN-2 installed by on-site technician. "
            "Controller A temperature normalised to 41°C. "
            "Controller A returned to active I/O duties; failover reverted."
        ),
    ],

    # LLM hallucinated: blamed a different fan (FAN-1), added an imaginary
    # power-supply failure, and got the temperature threshold wrong.
    response=(
        "The MSA 2060 overtemperature event on March 20 2026 was caused by the failure of "
        "cooling fan FAN-1, which stopped spinning. Additionally, a power supply unit "
        "experienced a partial failure that contributed to reduced airflow. "
        "Controller A reached 80°C before the threshold of 75°C triggered automatic failover "
        "to Controller B. A replacement fan and PSU were installed to resolve the issue."
    ),

    # Ground truth derived from the logs above
    reference=(
        "Fan module FAN-2 failed (zero RPM), causing Controller A inlet temperature to reach "
        "72°C against a threshold of 65°C. The system failed over all I/O to Controller B. "
        "A replacement FAN-2 was installed and the temperature normalised to 41°C."
    ),
)


# ──────────────────────────────────────────────
# Build dataset and run evaluation
# ──────────────────────────────────────────────

METRICS = [context_recall, context_precision, faithfulness, answer_relevancy]

LABELS = {
    "example1_retrieval_failure": example1_retrieval_failure,
    "example2_generation_failure": example2_generation_failure,
}

def run_evaluation():
    results = {}

    for label, sample in LABELS.items():
        print(f"\n{'═'*60}")
        print(f"  Evaluating: {label}")
        print(f"{'═'*60}")
        print(f"  Question : {sample.user_input[:80]}...")
        print(f"  Answer   : {sample.response[:80]}...")

        dataset = EvaluationDataset(samples=[sample])
        result = evaluate(
            dataset,
            metrics=METRICS,
            llm=evaluator_llm,
            embeddings=evaluator_embeddings,
        )
        results[label] = result
        print(f"\n  Raw scores: {result}")

    return results


def print_diagnostic_report(results):
    """
    Summarise the scores in the diagnostic grid format and explain what each
    failure mode means for the HPE RAG pipeline.
    """
    print("\n")
    print("╔══════════════════════════════════════════════════════════════════════╗")
    print("║              RAGAS DIAGNOSTIC REPORT — HPE RAG Pipeline             ║")
    print("╠══════════════════════════════════════════════════════════════════════╣")
    print(f"║ {'Metric':<22} {'Example 1 (Retrieval ✗)':>22} {'Example 2 (Generation ✗)':>22} ║")
    print("╠══════════════════════════════════════════════════════════════════════╣")

    metric_names = ["context_recall", "context_precision", "faithfulness", "answer_relevancy"]
    labels = list(results.keys())

    for m in metric_names:
        scores = []
        for lbl in labels:
            df = results[lbl].to_pandas()
            val = df[m].iloc[0] if m in df.columns else float("nan")
            scores.append(f"{val:.2f}")
        print(f"║ {m:<22} {scores[0]:>22} {scores[1]:>22} ║")

    print("╠══════════════════════════════════════════════════════════════════════╣")
    print("║  DIAGNOSIS                                                           ║")
    print("╠══════════════════════════════════════════════════════════════════════╣")
    print("║  Example 1: context_recall LOW + context_precision LOW              ║")
    print("║    → RETRIEVAL PROBLEM                                               ║")
    print("║    Fix: tune chunk size, embedding model, or add metadata filters    ║")
    print("╠══════════════════════════════════════════════════════════════════════╣")
    print("║  Example 2: context_recall HIGH + faithfulness LOW                  ║")
    print("║    → GENERATION / HALLUCINATION PROBLEM                              ║")
    print("║    Fix: lower temperature, stricter system prompt, stronger model    ║")
    print("╚══════════════════════════════════════════════════════════════════════╝")

    print("""
KEY TAKEAWAY
────────────
  context_recall / context_precision  →  Mirrors are held up to the RETRIEVER.
  faithfulness / answer_relevancy     →  Mirrors are held up to the LLM.

  Without this split, a single end-to-end accuracy score is useless for
  debugging — you cannot tell whether to fix the vector DB or the prompt.
""")


if __name__ == "__main__":
    results = run_evaluation()
    print_diagnostic_report(results)
