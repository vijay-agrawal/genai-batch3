# Transformer Encoder Log Anomaly Scoring — HPE Infrastructure Analytics
#
# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  IMPORTANT — What this model IS and IS NOT                             ║
# ║                                                                        ║
# ║  IS    : A custom Transformer Encoder trained FROM SCRATCH on 30 rows. ║
# ║           Architecture is inspired by BERT (CLS token, multi-head      ║
# ║           self-attention, positional encoding), but the weights are     ║
# ║           randomly initialised — there is NO pre-training.             ║
# ║                                                                        ║
# ║  IS NOT: The real BERT model (bert-base-uncased, 110M params), which   ║
# ║           was pre-trained by Google on 3.3 billion words.              ║
# ║  IS NOT: LogBERT (Guo et al. 2021), which pre-trains on millions of    ║
# ║           raw log lines before fine-tuning on anomaly labels.          ║
# ║                                                                        ║
# ║  The model is called LogTransformer in this demo to make this clear.  ║
# ╚══════════════════════════════════════════════════════════════════════════╝
#
# WHAT THIS DEMO TEACHES:
#   ✓ How Query / Key / Value attention works — with matrix dimensions
#   ✓ Why we scale by √d_k (and what goes wrong without it)
#   ✓ What multi-head attention buys you over single-head
#   ✓ What dropout does and why it prevents overfitting
#   ✓ Why CLS token is used instead of average pooling
#   ✓ Why sinusoidal positional encoding is needed
#   ✓ How the full forward pass flows, shape by shape
#
# Setup:
#   pip install torch pandas numpy scikit-learn matplotlib

import math
import re
from collections import Counter

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

torch.manual_seed(42)
np.random.seed(42)

print("LogTransformer — Custom Transformer Encoder for Log Anomaly Scoring")
print("=" * 68)


# =============================================================================
# 1. DATASET  (30 synthetic HPE infrastructure log events)
#    10 Healthy (INFO) · 10 Degraded (WARNING) · 10 Critical (ERROR/CRITICAL)
# =============================================================================
print("\n1. Loading Log Dataset (30 events)...")

data = {
    'log_message': [
        # ── Healthy / Informational (anomaly score 0–1) ───────────────────────
        "disk read write operations normal",
        "network interface link speed stable",
        "cpu utilization within expected range",
        "fan speed nominal all modules reporting",
        "memory ecc errors zero count nominal",
        "storage controller cache hit rate good",
        "power supply voltage levels stable",
        "raid rebuild completed successfully",
        "network packet loss negligible acceptable",
        "temperature sensors all within threshold",
        # ── Degraded / Warning (anomaly score 3–7) ────────────────────────────
        "disk latency elevated threshold warning",
        "network retransmit rate increasing observed",
        "cpu temperature approaching limit warning",
        "fan module reporting intermittent failures",
        "memory correctable ecc errors increasing",
        "storage controller queue depth high warning",
        "power supply ripple voltage detected",
        "raid degraded missing drive detected",
        "packet drops increasing on port warning",
        "thermal sensor reading high warning",
        # ── Critical / Failure (anomaly score 8–10) ───────────────────────────
        "disk io timeout uncorrectable error critical",
        "network link down failover triggered critical",
        "cpu throttling thermal emergency shutdown",
        "fan failure multiple modules offline critical",
        "memory uncorrectable ecc error panic critical",
        "storage controller cache failed data loss risk",
        "power supply failed redundancy lost critical",
        "raid failed multiple drives offline critical",
        "network storm detected broadcast loop critical",
        "chassis over temperature emergency shutdown",
    ],
    'component': [
        'StorageCtrl',  'NetworkAdapter', 'ComputeBlade',  'FanModule',    'MemorySubsys',
        'StorageCtrl',  'PowerSupply',    'StorageCtrl',   'NetworkAdapter','ThermalMgmt',
        'StorageCtrl',  'NetworkAdapter', 'ComputeBlade',  'FanModule',    'MemorySubsys',
        'StorageCtrl',  'PowerSupply',    'StorageCtrl',   'NetworkAdapter','ThermalMgmt',
        'StorageCtrl',  'NetworkAdapter', 'ComputeBlade',  'FanModule',    'MemorySubsys',
        'StorageCtrl',  'PowerSupply',    'StorageCtrl',   'NetworkAdapter','ThermalMgmt',
    ],
    'log_level': [
        'INFO','INFO','INFO','INFO','INFO',
        'INFO','INFO','INFO','INFO','INFO',
        'WARNING','WARNING','WARNING','WARNING','WARNING',
        'WARNING','WARNING','WARNING','WARNING','WARNING',
        'ERROR','ERROR','ERROR','ERROR','ERROR',
        'CRITICAL','CRITICAL','CRITICAL','CRITICAL','CRITICAL',
    ],
    'mins_since_last_error': [
        120, 90,150,200,180,110,300, 95, 75,250,
         45, 30, 20, 15, 40, 25, 10,  8, 35, 18,
          5,  3,  7,  2,  4,  1,  1,  1,  2,  1,
    ],
    'error_count_10min': [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        2, 3, 4, 5, 2, 6, 7, 8, 3, 5,
        9,12,10,15,11,18,20,22,14,25,
    ],
    'anomaly_score': [
        0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
        3, 4, 5, 5, 4, 5, 6, 7, 4, 5,
        8, 8, 9, 9, 8, 9,10,10, 8,10,
    ],
}

df = pd.DataFrame(data)
print(f"  Shape : {df.shape}")
print(df[['log_message', 'component', 'log_level', 'anomaly_score']].head(6).to_string(index=False))


# =============================================================================
# 2. TEXT PRE-PROCESSING
#    Each log message is tokenised into words, then each word is mapped to
#    an integer ID (its row in the embedding lookup table).
#
#    Special tokens (BERT convention):
#      [PAD]  — padding, fills short sequences to a fixed length (id=0)
#      [CLS]  — "classification" token prepended to every sequence;
#               its final Transformer output is used as the sequence summary
#      [MASK] — reserved for masked language model pre-training (not used here)
# =============================================================================
print("\n2. Text Pre-Processing...")

CLS_TOKEN = '<CLS>'
MSK_TOKEN = '<MASK>'
PAD_TOKEN = '<PAD>'

def tokenize(text):
    """Lowercase + strip punctuation + split on whitespace."""
    return re.sub(r'[^\w\s]', '', text.lower()).split()

# Build vocabulary from all tokens in the corpus
all_tokens = [tok for msg in df['log_message'] for tok in tokenize(msg)]
vocab = Counter(all_tokens)

# id=0 → PAD (used as padding_idx in nn.Embedding — its gradient is zeroed)
# id=1 → CLS
# id=2 → MASK
word_to_idx = {PAD_TOKEN: 0, CLS_TOKEN: 1, MSK_TOKEN: 2}
for i, w in enumerate(vocab.keys()):
    word_to_idx[w] = i + 3
idx_to_word = {i: w for w, i in word_to_idx.items()}

VOCAB_SIZE  = len(word_to_idx)
MAX_SEQ_LEN = 8   # truncate / pad all messages to this many tokens
              # CLS is prepended later inside the model → transformer sees seq+1 tokens

print(f"  Vocabulary size (incl. special tokens) : {VOCAB_SIZE}")
print(f"  Max sequence length (raw tokens)       : {MAX_SEQ_LEN}")
print(f"  Top tokens by frequency : {vocab.most_common(8)}")


def encode_message(text, max_len=MAX_SEQ_LEN):
    """
    Convert a raw log string to a fixed-length list of token IDs.
      - Unknown tokens → 0 (PAD id, effectively ignored by the embedding)
      - Short sequences → right-padded with 0
      - Long sequences  → truncated at max_len
    CLS is NOT added here; the model prepends it in forward().
    """
    ids = [word_to_idx.get(t, 0) for t in tokenize(text)]
    ids = ids[:max_len]                     # truncate
    ids += [0] * (max_len - len(ids))       # pad
    return ids

X_text = np.array([encode_message(m) for m in df['log_message']])


# =============================================================================
# 3. ENCODE CATEGORICAL + SCALE NUMERICAL FEATURES
#    The Transformer only handles the text; numerical metadata is injected
#    after the CLS pooling step, just before the final regression head.
#
#    Scaling to [0, 1] keeps all inputs in a similar numeric range, which
#    stabilises gradient magnitudes and speeds up convergence.
# =============================================================================
print("\n3. Encoding Features...")

le_comp  = LabelEncoder()   # e.g. ComputeBlade→0, FanModule→1, ...
le_level = LabelEncoder()   # e.g. CRITICAL→0, ERROR→1, INFO→2, WARNING→3

X_comp   = le_comp.fit_transform(df['component']).reshape(-1, 1)
X_level  = le_level.fit_transform(df['log_level']).reshape(-1, 1)
X_mins   = (df['mins_since_last_error'].values / 300.0).reshape(-1, 1)  # divide by max
X_errwin = (df['error_count_10min'].values / 25.0).reshape(-1, 1)       # divide by max

X_numerical = np.concatenate([X_comp, X_level, X_mins, X_errwin], axis=1)
y           = df['anomaly_score'].values

print(f"  Text input shape       : {X_text.shape}       (30 events × 8 token ids)")
print(f"  Numerical feature shape: {X_numerical.shape}  (30 events × 4 features)")


# =============================================================================
# 4. TRAIN / TEST SPLIT
#    75% train (22 events), 25% test (8 events)
#    random_state=42 → reproducible split
# =============================================================================
print("\n4. Splitting Data (75% train / 25% test)...")

(X_txt_tr, X_txt_te,
 X_num_tr, X_num_te,
 y_tr,     y_te) = train_test_split(
    X_text, X_numerical, y,
    test_size=0.25, random_state=42
)

# Convert numpy arrays to PyTorch tensors
X_txt_tr = torch.LongTensor(X_txt_tr)    # LongTensor required by nn.Embedding
X_txt_te = torch.LongTensor(X_txt_te)
X_num_tr = torch.FloatTensor(X_num_tr)
X_num_te = torch.FloatTensor(X_num_te)
y_tr     = torch.FloatTensor(y_tr).view(-1, 1)   # shape (22, 1) — MSELoss needs this
y_te     = torch.FloatTensor(y_te).view(-1, 1)

print(f"  Train: {len(X_txt_tr)} events  |  Test: {len(X_txt_te)} events")


# =============================================================================
# 5. POSITIONAL ENCODING
#
# THE PROBLEM:
#   A Transformer processes all tokens simultaneously (in parallel).
#   Unlike an RNN that reads left→right and implicitly knows position,
#   the Transformer has no built-in notion of order.
#   Without positional encoding: "disk error" ≡ "error disk" — identical!
#
# THE SOLUTION — Sinusoidal Positional Encoding (Vaswani et al., 2017):
#   For each position pos and each embedding dimension i:
#
#     PE(pos, 2i)   = sin( pos / 10000^(2i / d_model) )
#     PE(pos, 2i+1) = cos( pos / 10000^(2i / d_model) )
#
#   This creates a unique "fingerprint" vector for each position.
#   The wavelengths form a geometric sequence from 2π (high-freq) to
#   10000·2π (low-freq), so different dimensions encode different scales
#   of position — similar to binary place values (1s, 2s, 4s, 8s, ...).
#
# WHY SINE/COSINE?
#   1. The model can generalise to longer sequences unseen in training
#      because sin/cos patterns extend smoothly beyond the training length.
#   2. The relative offset between positions is expressible as a linear
#      function of the encoding — the model can learn "3 positions ago".
#
# BERT alternative: learned positional embeddings (an extra nn.Embedding
#   of size max_seq_len × d_model).  Equivalent on short sequences; does
#   NOT generalise beyond the trained maximum length.
# =============================================================================
class PositionalEncoding(nn.Module):
    def __init__(self, embed_dim, max_len=512):
        super().__init__()

        # Pre-compute the entire positional encoding table once at init time.
        # Shape: (max_len, embed_dim)
        pe  = torch.zeros(max_len, embed_dim)

        # pos: shape (max_len, 1) — each row is a position index [0, 1, 2, ...]
        pos = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)

        # div: shape (embed_dim/2,) — the frequency denominators
        # We compute in log-space for numerical stability:
        #   10000^(2i/d) = exp( 2i * log(10000) / d )
        div = torch.exp(
            torch.arange(0, embed_dim, 2).float() * (-math.log(10000.0) / embed_dim)
        )

        # Even indices (0, 2, 4, ...) → sine;  odd indices (1, 3, 5, ...) → cosine
        pe[:, 0::2] = torch.sin(pos * div)   # sin for even dims
        pe[:, 1::2] = torch.cos(pos * div)   # cos for odd dims

        # register_buffer: not a trainable parameter, but saved with the model
        # and moved to the correct device with .to(device)
        # unsqueeze(0) adds the batch dimension → shape (1, max_len, embed_dim)
        self.register_buffer('pe', pe.unsqueeze(0))

    def forward(self, x):
        # x shape: (batch, seq_len, embed_dim)
        # self.pe[:, :seq_len, :] slices exactly seq_len positions
        # Adding to x: positional signal is baked into each token's representation
        return x + self.pe[:, :x.size(1), :]


# =============================================================================
# 6. LogTransformer MODEL
#
# ── FULL ARCHITECTURE ────────────────────────────────────────────────────────
#
#  Input (batch=B, seq=S=8 token ids):
#    ↓
#  [CLS] prepended → (B, S+1, embed_dim=32)
#    ↓
#  Positional Encoding (adds position signal, no new parameters)
#    ↓
#  TransformerEncoder × 2 layers:
#    each layer contains:
#      ├── LayerNorm (pre-norm: applied BEFORE attention for training stability)
#      ├── Multi-Head Self-Attention (4 heads, d_k=8 each)
#      │     Q, K, V projections → scaled dot-product → softmax → value mix
#      ├── Dropout (randomly zeroes activations during training)
#      ├── Residual Add  (output += input — prevents gradient vanishing)
#      ├── LayerNorm
#      ├── Feed-Forward Network (linear→ReLU→linear, hidden=64)
#      ├── Dropout
#      └── Residual Add
#    ↓
#  CLS output at position 0 → (B, embed_dim=32)
#    ↓
#  Dropout
#    ↓
#  Concat metadata → (B, embed_dim + 4 = 36)
#    ↓
#  FC(36→64) → ReLU → FC(64→32) → ReLU → FC(32→1)
#    ↓
#  Anomaly score ∈ ℝ  (regression; clipped to [0,10] at inference time)
#
# ── MULTI-HEAD SELF-ATTENTION: Q / K / V EXPLAINED ──────────────────────────
#
# Each Transformer layer applies the formula:
#
#   Attention(Q, K, V) = softmax( Q · Kᵀ / √d_k ) · V
#
# WHERE:
#   Q (Query) = X · W_Q    shape: (B, S+1, d_k)   "What am I looking for?"
#   K (Key)   = X · W_K    shape: (B, S+1, d_k)   "What do I offer?"
#   V (Value) = X · W_V    shape: (B, S+1, d_v)   "What information do I carry?"
#
#   X is the input (B, S+1, embed_dim=32) — all tokens including [CLS].
#   W_Q, W_K, W_V are learned weight matrices, shape (embed_dim, d_k).
#
# STEP-BY-STEP MATRIX MATH (single head, d_k = embed_dim / num_heads = 32/4 = 8):
#
#   1. Project:
#        Q = X · W_Q   →  (B, 9, 8)     each token gets its "query vector"
#        K = X · W_K   →  (B, 9, 8)     each token gets its "key vector"
#        V = X · W_V   →  (B, 9, 8)     each token gets its "value vector"
#
#   2. Score matrix (raw attention):
#        scores = Q · Kᵀ              →  (B, 9, 9)
#        Entry [i, j] = how much token i should "attend to" token j
#        (dot product of query i with key j → high if they are similar)
#
#   3. Scale:
#        scores = scores / √8  ≈  scores / 2.83
#        WHY? Without scaling, for large d_k the dot products grow large
#        (variance ∝ d_k), pushing softmax into saturation regions where
#        gradients are near-zero and learning stalls.
#        Dividing by √d_k keeps the variance at ~1 regardless of d_k.
#
#   4. Mask (optional):
#        Padding positions (token_id == 0) are set to -∞ before softmax
#        so they receive 0 attention weight. (Applied via src_key_padding_mask.)
#
#   5. Softmax over last dimension (j):
#        weights = softmax(scores)    →  (B, 9, 9)
#        Each row sums to 1. Row i is token i's attention distribution over
#        all other tokens — "what fraction of each other token do I aggregate?"
#
#   6. Weighted sum of values:
#        output = weights · V         →  (B, 9, 8)
#        Token i's new representation is a weighted blend of all tokens' values.
#        If token "uncorrectable" attends 70% to "error" and 20% to "critical",
#        its new vector is 70% error's value + 20% critical's value + ...
#
# MULTI-HEAD:
#   Run the above 4 times in parallel with 4 different (W_Q, W_K, W_V) triples.
#   Each head can specialise:
#     Head 0: "error/critical severity tokens attend to each other"
#     Head 1: "component tokens attend to level tokens"
#     Head 2: "[CLS] attends to the most anomalous token"
#     Head 3: "adjacent tokens for syntactic patterns (io → timeout)"
#   Concatenate the 4 outputs → (B, 9, 4×8=32), then project with W_O → (B, 9, 32).
#   Using 4 heads with d_k=8 is parameter-efficient: 4×(32×8+32×8+32×8) = same
#   total as one head with d_k=32 but with 4× the representational diversity.
#
# WHY CLS POOLING?
#   After the Transformer, we have a (B, 9, 32) output — one vector per token.
#   We need a single vector to represent the whole sequence.
#   Options:
#     • Average all tokens  — dilutes signal from less important tokens
#     • Take final token    — arbitrary; no special semantic meaning
#     • [CLS] token (pos 0) — the model LEARNS to aggregate the whole
#       sequence into [CLS] because it is always present and the regression
#       loss only flows back through [CLS]. Explicitly teaches this token
#       to "summarise everything relevant for scoring".
# =============================================================================
class LogTransformer(nn.Module):
    """
    Custom Transformer Encoder for log anomaly regression.
    Trained from scratch — NOT a pre-trained BERT model.
    """
    def __init__(self, vocab_size, embed_dim, num_heads, num_layers,
                 ffn_dim, max_seq_len, num_meta=4, dropout=0.1):
        super().__init__()

        # Sanity check: multi-head attention requires embed_dim divisible by num_heads.
        # Each head gets embed_dim // num_heads dimensions (d_k).
        assert embed_dim % num_heads == 0, \
            f"embed_dim ({embed_dim}) must be divisible by num_heads ({num_heads})"

        # ── Token Embedding ───────────────────────────────────────────────────
        # Maps each integer token ID → a dense vector of size embed_dim.
        # Think of it as a lookup table: table[token_id] → float vector.
        # Shape of the full table: (vocab_size, embed_dim)
        # padding_idx=0: the row for PAD is always zeroed and its gradient
        #   is not accumulated — PAD tokens contribute nothing to learning.
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)

        # ── Positional Encoding ───────────────────────────────────────────────
        # max_seq_len+2: +1 for CLS, +1 safety margin
        self.pos_enc = PositionalEncoding(embed_dim, max_len=max_seq_len + 2)

        # ── [CLS] Token Embedding ─────────────────────────────────────────────
        # One learnable vector of size (1, 1, embed_dim).
        # It is prepended to every input sequence.  After passing through all
        # Transformer layers, its output is the "sequence summary" vector.
        # nn.Parameter: included in model.parameters() and updated by the optimizer.
        # torch.randn: initialised from a standard normal distribution N(0,1).
        self.cls_embedding = nn.Parameter(torch.randn(1, 1, embed_dim))

        # ── Transformer Encoder ───────────────────────────────────────────────
        # TransformerEncoderLayer is one full block:
        #   Pre-LayerNorm → Multi-Head Self-Attention → Dropout → Residual
        #   Pre-LayerNorm → FeedForward (linear→ReLU→linear) → Dropout → Residual
        #
        # norm_first=True: "pre-norm" variant — LayerNorm applied BEFORE attention.
        #   Pre-norm is more stable for small datasets than post-norm (original paper).
        #   It prevents gradient explosion in early training.
        #
        # d_model=embed_dim: dimensionality of token representations throughout.
        # nhead=num_heads  : number of parallel attention heads.
        # dim_feedforward  : hidden size of the FFN (usually 2–4× embed_dim).
        # dropout          : applied inside attention AND inside FFN.
        # batch_first=True : expects input as (batch, seq, features) — natural convention.
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=embed_dim,
            nhead=num_heads,
            dim_feedforward=ffn_dim,
            dropout=dropout,
            batch_first=True,
            norm_first=True,
        )

        # Stack num_layers of the above block.
        # Each layer refines the representations produced by the previous one.
        # Layer 1: learns basic token-level patterns (severity keywords).
        # Layer 2: learns higher-order interactions (cross-component correlations).
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        # ── Dropout ───────────────────────────────────────────────────────────
        # During TRAINING: randomly sets p% of activations to 0.
        #   This forces the network to learn redundant representations —
        #   no single neuron can be relied upon, so the model generalises better.
        # During INFERENCE (model.eval()): dropout is a no-op (all neurons active,
        #   but outputs are scaled by (1-p) to preserve expected magnitude).
        # Applied to the CLS vector before the regression head.
        self.dropout = nn.Dropout(dropout)

        # ── Regression Head ───────────────────────────────────────────────────
        # CLS vector (embed_dim=32) + metadata (4 features) = 36-dim input
        # Three linear layers progressively reduce: 36 → 64 → 32 → 1
        # ReLU between layers adds non-linearity — without it, stacking linear
        # layers is mathematically equivalent to a single linear layer.
        self.fc1  = nn.Linear(embed_dim + num_meta, 64)
        self.fc2  = nn.Linear(64, 32)
        self.fc3  = nn.Linear(32, 1)      # outputs a single anomaly score
        self.relu = nn.ReLU()

    def forward(self, token_seq, meta):
        """
        token_seq : (B, MAX_SEQ_LEN)   — integer token IDs
        meta      : (B, 4)             — [component, level, mins_norm, err_norm]
        returns   : (B, 1)             — predicted anomaly score
        """
        B = token_seq.size(0)   # batch size

        # ── Step 1: Token Embedding ───────────────────────────────────────────
        # token_seq: (B, 8)  → emb: (B, 8, 32)
        # Each integer id is replaced by its 32-dim dense vector.
        emb = self.embedding(token_seq)

        # ── Step 2: Prepend [CLS] Token ───────────────────────────────────────
        # self.cls_embedding: (1, 1, 32) — one shared CLS vector
        # expand(B, 1, -1): tile across batch → (B, 1, 32)  (no memory copy)
        # cat along dim=1: (B, 8, 32) + (B, 1, 32) → (B, 9, 32)
        cls = self.cls_embedding.expand(B, 1, -1)
        emb = torch.cat([cls, emb], dim=1)      # (B, 9, 32)

        # ── Step 3: Positional Encoding ───────────────────────────────────────
        # Adds sinusoidal position vectors in-place: (B, 9, 32) + (1, 9, 32)
        # After this, each token's vector encodes BOTH its identity AND position.
        emb = self.pos_enc(emb)                 # (B, 9, 32)

        # ── Step 4: Padding Mask ──────────────────────────────────────────────
        # Tells the attention mechanism to ignore PAD positions (token_id == 0).
        # Shape: (B, 9)  — True means "ignore this position".
        # CLS (position 0) is always valid → prepend False for it.
        pad_mask = torch.cat([
            torch.zeros(B, 1, dtype=torch.bool, device=token_seq.device),  # CLS → valid
            token_seq == 0                                                   # PAD → ignore
        ], dim=1)                               # (B, 9)

        # ── Step 5: Transformer Encoder ───────────────────────────────────────
        # All 9 tokens (CLS + 8 message tokens) attend to each other in parallel.
        # Input : (B, 9, 32);  Output: (B, 9, 32)
        # src_key_padding_mask: positions marked True are set to -∞ before softmax
        #   → they contribute 0 attention weight → effectively ignored.
        enc = self.transformer(emb, src_key_padding_mask=pad_mask)  # (B, 9, 32)

        # ── Step 6: CLS Pooling ───────────────────────────────────────────────
        # enc[:, 0, :] → take position 0 (CLS) from every item in the batch
        # Shape: (B, 32)
        # The model has learned through backprop to route all sequence-level
        # information into this position's final representation.
        cls_out = self.dropout(enc[:, 0, :])    # (B, 32)

        # ── Step 7: Fuse Metadata & Regress ──────────────────────────────────
        # Concatenate the 32-dim CLS summary with 4 numerical features → (B, 36)
        # Then pass through 3 FC layers to produce the scalar anomaly score.
        x = self.relu(self.fc1(torch.cat([cls_out, meta], dim=1)))  # (B, 64)
        x = self.relu(self.fc2(x))                                  # (B, 32)
        return self.fc3(x)                                          # (B, 1)


# ── Hyperparameters ────────────────────────────────────────────────────────────
EMBED_DIM  = 32    # d_model: dimensionality of all token representations
NUM_HEADS  = 4     # number of attention heads; d_k = 32 / 4 = 8 per head
NUM_LAYERS = 2     # number of stacked Transformer encoder layers
FFN_DIM    = 64    # inner dimension of the feed-forward block (2× embed_dim)
DROPOUT    = 0.1   # 10% of activations zeroed during training
LR         = 0.001 # Adam learning rate
EPOCHS     = 200   # more epochs compensate for the tiny 22-example training set

model = LogTransformer(
    vocab_size=VOCAB_SIZE,
    embed_dim=EMBED_DIM,
    num_heads=NUM_HEADS,
    num_layers=NUM_LAYERS,
    ffn_dim=FFN_DIM,
    max_seq_len=MAX_SEQ_LEN,
    dropout=DROPOUT,
)

total_params = sum(p.numel() for p in model.parameters())
trainable    = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"\n5. Model: LogTransformer")
print(f"   Total parameters    : {total_params:,}")
print(f"   Trainable parameters: {trainable:,}")
print(f"   Heads={NUM_HEADS}, d_k={EMBED_DIM//NUM_HEADS}, Layers={NUM_LAYERS}, FFN={FFN_DIM}")
print(f"   Transformer sees sequence of length: {MAX_SEQ_LEN + 1} ([CLS] + {MAX_SEQ_LEN} tokens)")


# =============================================================================
# 7. TRAINING
#
# Loss: MSELoss — mean squared error between predicted and true anomaly score.
#   MSE penalises large errors quadratically, appropriate for a 0-10 scale
#   where being off by 4 is much worse than being off by 1.
#
# Optimiser: Adam — adaptive learning rates per parameter.
#   Combines momentum (smooths gradients) with RMSProp (normalises by gradient
#   magnitude). Generally converges faster than plain SGD.
#
# Gradient clipping (max_norm=1.0):
#   If the global L2 norm of all gradients exceeds 1.0, scale them down.
#   Prevents occasional "exploding gradient" steps that destabilise training,
#   especially important with Transformers on tiny datasets.
# =============================================================================
print("\n6. Training LogTransformer...")

optimizer = optim.Adam(model.parameters(), lr=LR)
criterion = nn.MSELoss()
losses    = []

model.train()
for epoch in range(EPOCHS):
    optimizer.zero_grad()                           # clear previous gradients
    preds = model(X_txt_tr, X_num_tr)              # forward pass → (22, 1)
    loss  = criterion(preds, y_tr)                  # MSE(predicted, true)
    loss.backward()                                 # backprop: compute ∂loss/∂param
    nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
    optimizer.step()                                # update all parameters
    losses.append(loss.item())

    if (epoch + 1) % 40 == 0:
        print(f"  Epoch {epoch+1:3d}/{EPOCHS}  MSE Loss: {loss.item():.4f}")

print(f"  Final training loss: {losses[-1]:.4f}")


# =============================================================================
# 8. EVALUATION
#
# We evaluate on both train and test sets:
#   • Train metrics show how well the model fits what it has seen.
#   • Test metrics show generalisation to unseen data.
#   • A large Train–Test gap indicates overfitting (expected on 22 training events).
#
# Per-severity-band MAE breaks down where the model struggles most:
#   • Healthy events are easy (score≈0; the model learns the baseline quickly).
#   • Boundary events (score=3–5) are hardest — the signal is ambiguous.
#   • Critical events (score≥8) should have low MAE if the model captures
#     keywords like "uncorrectable", "panic", "shutdown".
# =============================================================================
print("\n7. Evaluation...")

model.eval()   # switches off dropout; all neurons active for inference
with torch.no_grad():
    # torch.no_grad(): disables gradient tracking — saves memory and speeds
    # up inference (we don't need gradients when we're not doing backprop).
    tr_pred = model(X_txt_tr, X_num_tr)   # (22, 1)
    te_pred = model(X_txt_te, X_num_te)   # (8, 1)

# Convert to numpy for sklearn metrics
y_tr_np  = y_tr.numpy().flatten()
y_te_np  = y_te.numpy().flatten()
tr_p_np  = tr_pred.numpy().flatten()
te_p_np  = te_pred.numpy().flatten()

tr_mse = mean_squared_error(y_tr_np, tr_p_np)
tr_mae = mean_absolute_error(y_tr_np, tr_p_np)
te_mse = mean_squared_error(y_te_np, te_p_np)
te_mae = mean_absolute_error(y_te_np, te_p_np)

print(f"\n  {'Metric':<20} {'Train':>8}  {'Test':>8}")
print(f"  {'-'*40}")
print(f"  {'MSE':<20} {tr_mse:>8.4f}  {te_mse:>8.4f}")
print(f"  {'MAE':<20} {tr_mae:>8.4f}  {te_mae:>8.4f}")
print(f"  {'RMSE':<20} {tr_mse**0.5:>8.4f}  {te_mse**0.5:>8.4f}")

# ── Per-severity-band breakdown (on the full dataset) ─────────────────────────
print("\n  Per-severity MAE (full dataset):")
model.eval()
with torch.no_grad():
    all_pred = model(torch.LongTensor(X_text), torch.FloatTensor(X_numerical))
all_pred_np = all_pred.numpy().flatten()
true_np     = y.astype(float)

bands = [
    ("Healthy  (0–2)",  0,  2),
    ("Warning  (3–5)",  3,  5),
    ("High     (6–7)",  6,  7),
    ("Critical (8–10)", 8, 10),
]
for label, lo, hi in bands:
    mask     = (true_np >= lo) & (true_np <= hi)
    mae_band = mean_absolute_error(true_np[mask], all_pred_np[mask])
    print(f"    {label:<22}  MAE={mae_band:.2f}  (n={mask.sum()})")

# ── Side-by-side predictions on the test set ──────────────────────────────────
print("\n  Test set predictions:")

def severity_label(score):
    if score < 3:  return "HEALTHY"
    if score < 6:  return "DEGRADED"
    if score < 9:  return "HIGH"
    return "CRITICAL"

print(f"\n  {'Log message (truncated)':<38} {'True':>5} {'Pred':>5}  {'Error':>6}  {'Label'}")
print("  " + "-" * 80)
for i in range(len(X_txt_te)):
    tokens = X_txt_te[i].numpy()
    words  = [idx_to_word.get(t, '') for t in tokens if t != 0]
    msg    = ' '.join(words)[:37]
    actual = y_te_np[i]
    pred   = te_p_np[i]
    error  = pred - actual
    print(f"  {msg:<38} {actual:>5.1f} {pred:>5.1f}  {error:>+6.1f}  {severity_label(pred)}")


# =============================================================================
# 9. INFERENCE ON NEW LOG EVENTS
# =============================================================================
print("\n8. Inference on New Log Events...")

def predict_log(message, component, log_level, mins_since_last_error, error_count_10min):
    """
    Score a single new log event.
    All preprocessing steps mirror the training pipeline exactly.
    """
    model.eval()
    with torch.no_grad():
        txt   = torch.LongTensor([encode_message(message)])
        comp  = le_comp.transform([component])[0]
        level = le_level.transform([log_level])[0]
        meta  = torch.FloatTensor([[
            comp,
            level,
            mins_since_last_error / 300.0,
            error_count_10min     /  25.0,
        ]])
        raw = model(txt, meta).item()
        return max(0.0, min(10.0, raw))   # clamp to valid range [0, 10]

new_events = [
    # message                                            comp              level     mins  errs
    ("disk read write operations normal",              'StorageCtrl',    'INFO',    200,   0),
    ("storage controller queue depth high warning",   'StorageCtrl',    'WARNING',  20,   6),
    ("disk io timeout uncorrectable error critical",  'StorageCtrl',    'ERROR',     3,  14),
    ("fan failure multiple modules offline critical", 'FanModule',      'CRITICAL',  1,  20),
    ("network retransmit rate increasing observed",   'NetworkAdapter', 'WARNING',  30,   3),
    ("power supply failed redundancy lost critical",  'PowerSupply',    'CRITICAL',  1,  22),
]

print(f"\n  {'Log Message':<50} {'Score':>6}  {'Severity'}")
print("  " + "-" * 75)
for msg, comp, lvl, mins, errs in new_events:
    score = predict_log(msg, comp, lvl, mins, errs)
    print(f"  {msg:<50} {score:>6.2f}  {severity_label(score)}")


# =============================================================================
# 10. VISUALISATION
# =============================================================================
print("\n9. Plotting results...")

fig = plt.figure(figsize=(16, 11))
fig.suptitle(
    "LogTransformer — Custom Transformer Encoder for Log Anomaly Scoring\n"
    "(Trained from scratch · NOT a pre-trained BERT model)",
    fontsize=13, fontweight='bold'
)
gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)

# ── Panel 1: Training loss curve ──────────────────────────────────────────────
ax1 = fig.add_subplot(gs[0, 0])
ax1.plot(losses, color='steelblue', linewidth=1.5)
ax1.set_title("Training Loss (MSE)")
ax1.set_xlabel("Epoch")
ax1.set_ylabel("MSE Loss")
ax1.grid(True, alpha=0.4)
ax1.text(0.97, 0.95, f"Final: {losses[-1]:.4f}",
         transform=ax1.transAxes, ha='right', va='top',
         fontsize=9, bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.8))

# ── Panel 2: True vs Predicted (full dataset) ─────────────────────────────────
ax2 = fig.add_subplot(gs[0, 1])
color_map = {'INFO': '#2196F3', 'WARNING': '#FF9800', 'ERROR': '#F44336', 'CRITICAL': '#9C27B0'}
point_colors = [color_map[lvl] for lvl in df['log_level']]
ax2.scatter(true_np, all_pred_np, c=point_colors, s=80,
            alpha=0.85, edgecolors='black', linewidth=0.5, zorder=3)
ax2.plot([0, 10], [0, 10], 'k--', alpha=0.4, linewidth=1, label='Perfect')
ax2.set_xlabel("True Anomaly Score")
ax2.set_ylabel("Predicted Anomaly Score")
ax2.set_title("True vs Predicted (All 30 Events)")
ax2.set_xlim(-0.5, 10.5); ax2.set_ylim(-0.5, 10.5)
ax2.text(0.05, 0.92, f"MAE={mean_absolute_error(true_np, all_pred_np):.2f}",
         transform=ax2.transAxes, fontsize=9,
         bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.8))
from matplotlib.patches import Patch
ax2.legend(handles=[Patch(color=c, label=l) for l, c in color_map.items()],
           fontsize=7, loc='lower right')

# ── Panel 3: Prediction error bars (full dataset) ─────────────────────────────
ax3 = fig.add_subplot(gs[0, 2])
errors_all = all_pred_np - true_np
bar_cols   = ['#4CAF50' if abs(e) < 1 else '#FF9800' if abs(e) < 2 else '#F44336'
              for e in errors_all]
ax3.bar(range(30), errors_all, color=bar_cols, alpha=0.85, edgecolor='black', linewidth=0.3)
ax3.axhline(0, color='black', linewidth=1)
ax3.set_xlabel("Event Index")
ax3.set_ylabel("Error (Pred − True)")
ax3.set_title("Prediction Error per Event")
ax3.set_xticks(range(0, 30, 5))
ax3.grid(True, axis='y', alpha=0.4)
from matplotlib.patches import Patch as P
ax3.legend(handles=[P(color='#4CAF50', label='|err|<1'),
                    P(color='#FF9800', label='|err|<2'),
                    P(color='#F44336', label='|err|≥2')], fontsize=7)

# ── Panel 4: Score distribution: true vs predicted ────────────────────────────
ax4 = fig.add_subplot(gs[1, 0])
bins = np.arange(-0.5, 11.5, 1)
ax4.hist(true_np,     bins=bins, alpha=0.6, label='True',      color='#2196F3', edgecolor='black')
ax4.hist(all_pred_np, bins=bins, alpha=0.6, label='Predicted', color='#FF9800', edgecolor='black')
ax4.set_xlabel("Anomaly Score"); ax4.set_ylabel("Count")
ax4.set_title("Score Distribution: True vs Predicted")
ax4.legend()

# ── Panel 5: MAE by severity band ─────────────────────────────────────────────
ax5 = fig.add_subplot(gs[1, 1])
band_labels, band_maes, band_ns = [], [], []
band_colors = ['#4CAF50', '#FF9800', '#F44336', '#9C27B0']
for (label, lo, hi), col in zip(bands, band_colors):
    mask     = (true_np >= lo) & (true_np <= hi)
    mae_val  = mean_absolute_error(true_np[mask], all_pred_np[mask])
    band_labels.append(label.split()[0])
    band_maes.append(mae_val)
    band_ns.append(mask.sum())
bars = ax5.bar(band_labels, band_maes, color=band_colors, alpha=0.85, edgecolor='black')
for bar, m, n in zip(bars, band_maes, band_ns):
    ax5.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.03,
             f"{m:.2f}\n(n={n})", ha='center', va='bottom', fontsize=9)
ax5.set_ylabel("MAE"); ax5.set_title("MAE by Severity Band")
ax5.grid(True, axis='y', alpha=0.4)

# ── Panel 6: Attention concept diagram (text annotation) ─────────────────────
ax6 = fig.add_subplot(gs[1, 2])
ax6.axis('off')
attention_text = (
    "Multi-Head Self-Attention\n"
    "─────────────────────────\n"
    "Q = X · W_Q  (What am I looking for?)\n"
    "K = X · W_K  (What do I offer?)\n"
    "V = X · W_V  (What do I carry?)\n\n"
    "scores = Q · Kᵀ / √d_k\n"
    "weights = softmax(scores)\n"
    "output  = weights · V\n\n"
    f"d_model = {EMBED_DIM}  |  heads = {NUM_HEADS}\n"
    f"d_k per head = {EMBED_DIM // NUM_HEADS}\n"
    f"Layers = {NUM_LAYERS}  |  FFN dim = {FFN_DIM}\n\n"
    "CLS (pos 0) aggregates the\n"
    "full sequence → regression head"
)
ax6.text(0.05, 0.95, attention_text, transform=ax6.transAxes,
         fontsize=9, verticalalignment='top', family='monospace',
         bbox=dict(boxstyle='round', facecolor='#f0f4ff', alpha=0.9))
ax6.set_title("Architecture Summary")

plt.savefig("logtransformer_results.png", dpi=120, bbox_inches='tight')
print("  Saved: logtransformer_results.png")
plt.show()

print(f"\n{'=' * 68}")
print("LogTransformer Demo Complete")
print(f"{'=' * 68}")
