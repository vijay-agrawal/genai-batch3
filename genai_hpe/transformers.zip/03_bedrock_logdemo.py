# Bedrock Log Anomaly Scoring — HPE Infrastructure Analytics
# Uses Amazon Nova (via Amazon Bedrock) with few-shot prompting to score
# log events from 0 (healthy) to 10 (critical).
#
# KEY DIFFERENCE vs gpt_logdemo.py:
#   DistilGPT-2 is a base completion model — we use log-probability tricks
#   to extract a numeric score because it can't follow instructions.
#
#   Amazon Nova IS an instruction-following model, so we can ask it directly:
#     "Reply with a single integer 0-10."
#   The model understands the instruction and outputs exactly what we need.
#   This makes the prompt design simpler and the output parsing straightforward.
#
# PROMPTING STRATEGY:
#   System prompt  — defines the role, scoring rubric, and strict output format
#   User prompt    — provides few-shot examples + the log event to score
#   Low temperature (0.1) — keeps outputs deterministic / consistent
#
# Setup:
#   pip install boto3 python-dotenv pandas matplotlib
#   Fill in AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY in a .env file

import re
import time
import boto3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from dotenv import load_dotenv
import os

np.random.seed(42)

print("Bedrock Log Anomaly Scoring — Few-Shot Inference with Amazon Nova")
print("=" * 65)

# =============================================================================
# 1. AWS / BEDROCK SETUP
# =============================================================================
load_dotenv()

client = boto3.client(
    "bedrock-runtime",
    region_name=os.getenv("AWS_REGION", "us-east-1"),
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
)

MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
print(f"\nModel : {MODEL_ID}  |  Region : {os.getenv('AWS_REGION', 'us-east-1')}")


# =============================================================================
# 2. GOLDEN DATASET  (same 30 events as gpt_logdemo.py)
# =============================================================================
print("\n1. Loading Golden Log Dataset (30 events)...")

data = {
    'log_message': [
        # healthy / informational
        "disk read write operations normal",
        "network interface link speed stable",
        "cpu utilization within expected range",
        "fan speed nominal all modules reporting",
        "memory ecc errors zero count nominal",
        "storage controller cache hit rate good",
        "power supply voltage levels stable",
        "raid rebuild completed successfully",
        "network packet loss negligible acceptable",
        "temperature sensors all within threshold",
        # degraded / warning signals
        "disk latency elevated threshold warning",
        "network retransmit rate increasing observed",
        "cpu temperature approaching limit warning",
        "fan module reporting intermittent failures",
        "memory correctable ecc errors increasing",
        "storage controller queue depth high warning",
        "power supply ripple voltage detected",
        "raid degraded missing drive detected",
        "packet drops increasing on port warning",
        "thermal sensor reading high warning",
        # critical / failure signals
        "disk io timeout uncorrectable error critical",
        "network link down failover triggered critical",
        "cpu throttling thermal emergency shutdown",
        "fan failure multiple modules offline critical",
        "memory uncorrectable ecc error panic critical",
        "storage controller cache failed data loss risk",
        "power supply failed redundancy lost critical",
        "raid failed multiple drives offline critical",
        "network storm detected broadcast loop critical",
        "chassis over temperature emergency shutdown",
    ],
    'component': [
        'StorageCtrl','NetworkAdapter','ComputeBlade','FanModule',   'MemorySubsys',
        'StorageCtrl','PowerSupply',  'StorageCtrl', 'NetworkAdapter','ThermalMgmt',
        'StorageCtrl','NetworkAdapter','ComputeBlade','FanModule',   'MemorySubsys',
        'StorageCtrl','PowerSupply',  'StorageCtrl', 'NetworkAdapter','ThermalMgmt',
        'StorageCtrl','NetworkAdapter','ComputeBlade','FanModule',   'MemorySubsys',
        'StorageCtrl','PowerSupply',  'StorageCtrl', 'NetworkAdapter','ThermalMgmt',
    ],
    'log_level': [
        'INFO','INFO','INFO','INFO','INFO',
        'INFO','INFO','INFO','INFO','INFO',
        'WARNING','WARNING','WARNING','WARNING','WARNING',
        'WARNING','WARNING','WARNING','WARNING','WARNING',
        'ERROR','ERROR','ERROR','ERROR','ERROR',
        'CRITICAL','CRITICAL','CRITICAL','CRITICAL','CRITICAL',
    ],
    'mins_since_last_error': [
        120, 90,150,200,180,110,300, 95, 75,250,
         45, 30, 20, 15, 40, 25, 10,  8, 35, 18,
          5,  3,  7,  2,  4,  1,  1,  1,  2,  1,
    ],
    'error_count_10min': [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        2, 3, 4, 5, 2, 6, 7, 8, 3, 5,
        9,12,10,15,11,18,20,22,14,25,
    ],
    'anomaly_score': [
        0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
        3, 4, 5, 5, 4, 5, 6, 7, 4, 5,
        8, 8, 9, 9, 8, 9,10,10, 8,10,
    ],
}

df = pd.DataFrame(data)
print(f"  Golden dataset: {len(df)} log events across 4 severity tiers")


# =============================================================================
# 3. PROMPT DESIGN
#
#   SYSTEM PROMPT — sets the persona and hard output constraints
#     - "Infrastructure monitoring AI" establishes domain expertise
#     - Explicit 0-10 scale with named anchors (0=healthy, 10=critical)
#       prevents the model from inventing its own scale
#     - "Reply with a SINGLE integer" is the key instruction that makes
#       output parsing trivial (no logprob tricks needed unlike DistilGPT-2)
#     - "No explanation" avoids verbose output that would complicate parsing
#
#   USER PROMPT — few-shot examples then the target event
#     - 6 labelled examples (two per severity band) teach the output format
#     - Numeric metadata (mins_since_last_error, error_count_10min) gives the
#       model quantitative signal beyond keywords
#     - Examples end mid-scale (score=4) to avoid the model anchoring on the
#       last seen value
#     - "Anomaly score:" as the final cue — clear and consistent with examples
# =============================================================================
print("\n2. Designing Prompts...")

SYSTEM_PROMPT = """You are an infrastructure monitoring AI for HPE server hardware.
Your job is to assign an anomaly score to a log event.

Scoring scale:
  0-2  : Healthy / Informational — system operating normally
  3-5  : Degraded / Warning     — performance degraded, attention needed
  6-7  : High                   — significant fault, risk of failure
  8-10 : Critical               — active failure or emergency condition

Rules:
- Consider the log message, component, log level, recency of errors, and error frequency.
- Reply with a SINGLE integer between 0 and 10.
- No explanation. No punctuation. Just the integer."""

# Few-shot examples embedded in the user turn.
# Two examples per severity band anchor the full 0-10 range.
FEW_SHOT_EXAMPLES = [
    # (message, component, log_level, mins_since_error, error_count_10min, score)
    ("cpu utilization within expected range",   "ComputeBlade",   "INFO",     150, 0,  0),
    ("temperature sensors all within threshold","ThermalMgmt",    "INFO",     250, 0,  0),
    ("disk latency elevated threshold warning", "StorageCtrl",    "WARNING",   45, 2,  3),
    ("fan module reporting intermittent failures","FanModule",     "WARNING",   15, 5,  5),
    ("power supply failed redundancy lost critical","PowerSupply", "CRITICAL",   1,20, 10),
    ("memory correctable ecc errors increasing","MemorySubsys",   "WARNING",   40, 2,  4),
]

def build_user_prompt(row):
    """
    Builds the user-turn prompt for a single log event.
    Starts with few-shot examples so the model learns the expected format,
    then appends the event to score.
    """
    lines = ["Score each log event as instructed.\n"]

    # ── Few-shot examples ──────────────────────────────────────────────────────
    for msg, comp, lvl, mins, cnt, score in FEW_SHOT_EXAMPLES:
        lines.append(
            f"Log     : {msg}\n"
            f"Component: {comp} | Level: {lvl} | "
            f"Mins since last error: {mins} | Errors in 10 min: {cnt}\n"
            f"Anomaly score: {score}\n"
        )

    # ── Target event ───────────────────────────────────────────────────────────
    lines.append(
        f"Log     : {row['log_message']}\n"
        f"Component: {row['component']} | Level: {row['log_level']} | "
        f"Mins since last error: {row['mins_since_last_error']} | "
        f"Errors in 10 min: {row['error_count_10min']}\n"
        f"Anomaly score:"   # model completes this line with just the integer
    )

    return "\n".join(lines)


# =============================================================================
# 4. SCORE EACH LOG EVENT VIA BEDROCK
# =============================================================================
print("\n3. Scoring 30 log events via Bedrock (this may take ~60 s)...")
print("   Low temperature (0.1) keeps responses deterministic.\n")

def score_log(row):
    """
    Calls Bedrock Converse API and extracts the integer score from the reply.
    Returns -1 if parsing fails so the batch continues.
    """
    user_prompt = build_user_prompt(row)

    response = client.converse(
        modelId=MODEL_ID,
        system=[{"text": SYSTEM_PROMPT}],
        messages=[{"role": "user", "content": [{"text": user_prompt}]}],
        inferenceConfig={
            "maxTokens": 5,       # we only need 1-2 tokens for a score 0-10
            "temperature": 0.1,   # near-deterministic — avoids creative reinterpretation
        },
    )

    reply = response["output"]["message"]["content"][0]["text"].strip()

    # Parse: find the first integer in the reply (handles "10", " 7", "Score: 8", etc.)
    match = re.search(r'\b(\d+)\b', reply)
    if match:
        score = int(match.group(1))
        return max(0, min(10, score))   # clamp to valid range
    return -1   # parse failure


predicted_scores = []
for i, (_, row) in enumerate(df.iterrows()):
    score = score_log(row)
    predicted_scores.append(score)
    status = f"  [{i+1:02d}/30] {row['log_level']:8s} | true={row['anomaly_score']:2d} | pred={score:2d}"
    print(status)
    time.sleep(0.3)   # avoid throttling on free-tier accounts

df['predicted_score'] = predicted_scores


# =============================================================================
# 5. EVALUATE
# =============================================================================
print("\n4. Evaluation Results")
print("-" * 50)

valid = df[df['predicted_score'] >= 0]
mse = np.mean((valid['anomaly_score'] - valid['predicted_score']) ** 2)
mae = np.mean(np.abs(valid['anomaly_score'] - valid['predicted_score']))
print(f"  Events scored : {len(valid)}/30")
print(f"  MSE           : {mse:.2f}")
print(f"  MAE           : {mae:.2f}")

# Per-severity breakdown
bands = [("Healthy (0–2)", 0, 2), ("Warning (3–5)", 3, 5),
         ("High (6–7)",    6, 7), ("Critical (8–10)", 8, 10)]
print("\n  Per-severity MAE:")
for label, lo, hi in bands:
    mask = (valid['anomaly_score'] >= lo) & (valid['anomaly_score'] <= hi)
    subset = valid[mask]
    band_mae = np.mean(np.abs(subset['anomaly_score'] - subset['predicted_score'])) if len(subset) else float('nan')
    print(f"    {label:20s}: MAE={band_mae:.2f}  (n={len(subset)})")


# =============================================================================
# 6. VISUALISE  (same 3-panel layout as gpt_logdemo.py)
# =============================================================================
print("\n5. Plotting results...")

fig = plt.figure(figsize=(15, 10))
fig.suptitle("Bedrock (Amazon Nova) — Log Anomaly Scoring\nFew-Shot Prompting | No Training",
             fontsize=14, fontweight='bold')
gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.4, wspace=0.35)

colors = {
    'INFO': '#2196F3', 'WARNING': '#FF9800',
    'ERROR': '#F44336', 'CRITICAL': '#9C27B0',
}
point_colors = [colors[lvl] for lvl in df['log_level']]

# ── Panel 1: True vs Predicted scatter ────────────────────────────────────────
ax1 = fig.add_subplot(gs[0, 0])
ax1.scatter(df['anomaly_score'], df['predicted_score'],
            c=point_colors, s=80, alpha=0.8, edgecolors='black', linewidths=0.5)
ax1.plot([0, 10], [0, 10], 'k--', alpha=0.4, label='Perfect')
ax1.set_xlabel("True Score"); ax1.set_ylabel("Predicted Score")
ax1.set_title("True vs Predicted")
ax1.set_xlim(-0.5, 10.5); ax1.set_ylim(-0.5, 10.5)
ax1.text(0.05, 0.92, f"MSE={mse:.2f}  MAE={mae:.2f}",
         transform=ax1.transAxes, fontsize=9,
         bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.8))
from matplotlib.patches import Patch
legend_patches = [Patch(color=c, label=l) for l, c in colors.items()]
ax1.legend(handles=legend_patches, fontsize=7, loc='lower right')

# ── Panel 2: Prediction error per event ───────────────────────────────────────
ax2 = fig.add_subplot(gs[0, 1])
errors = df['predicted_score'] - df['anomaly_score']
bar_colors = ['#4CAF50' if e == 0 else '#F44336' if e > 0 else '#2196F3' for e in errors]
ax2.bar(range(len(df)), errors, color=bar_colors, alpha=0.8, edgecolor='black', linewidth=0.3)
ax2.axhline(0, color='black', linewidth=1)
ax2.set_xlabel("Event Index"); ax2.set_ylabel("Error (Pred − True)")
ax2.set_title("Prediction Error per Event")
ax2.set_xticks(range(0, 30, 5))

# ── Panel 3: Score distribution comparison ────────────────────────────────────
ax3 = fig.add_subplot(gs[1, 0])
bins = np.arange(-0.5, 11.5, 1)
ax3.hist(df['anomaly_score'],    bins=bins, alpha=0.6, label='True',      color='#2196F3', edgecolor='black')
ax3.hist(df['predicted_score'],  bins=bins, alpha=0.6, label='Predicted', color='#FF9800', edgecolor='black')
ax3.set_xlabel("Anomaly Score"); ax3.set_ylabel("Count")
ax3.set_title("Score Distribution: True vs Predicted")
ax3.legend()

# ── Panel 4: MAE by severity band ─────────────────────────────────────────────
ax4 = fig.add_subplot(gs[1, 1])
band_labels, band_maes, band_ns = [], [], []
for label, lo, hi in bands:
    mask = (df['anomaly_score'] >= lo) & (df['anomaly_score'] <= hi)
    subset = df[mask]
    mae_val = np.mean(np.abs(subset['anomaly_score'] - subset['predicted_score']))
    band_labels.append(label.split()[0])
    band_maes.append(mae_val)
    band_ns.append(len(subset))
bar_cols = ['#4CAF50', '#FF9800', '#F44336', '#9C27B0']
bars = ax4.bar(band_labels, band_maes, color=bar_cols, alpha=0.8, edgecolor='black')
for bar, mae_v, n in zip(bars, band_maes, band_ns):
    ax4.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.05,
             f"{mae_v:.2f}\n(n={n})", ha='center', va='bottom', fontsize=9)
ax4.set_ylabel("MAE"); ax4.set_title("MAE by Severity Band")

plt.savefig("bedrock_logdemo_results.png", dpi=120, bbox_inches='tight')
print("  Saved: bedrock_logdemo_results.png")
plt.show()

print("\nDone.")
