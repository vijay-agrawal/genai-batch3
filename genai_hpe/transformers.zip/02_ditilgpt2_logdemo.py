# GPT Log Anomaly Scoring — HPE Infrastructure Analytics
# Uses a pre-trained small GPT model (DistilGPT-2, 82M params) with
# few-shot prompting to score log events from 0 (healthy) to 10 (critical).
#
# NO TRAINING.  The model's weights are frozen.
# Knowledge comes from:
#   - GPT-2 pre-training on 40 GB of internet text
#   - A carefully designed few-shot prompt (6 labelled examples)
# The full 30-row dataset is used as the golden evaluation set.
#
# SCORING METHOD — LOG-PROBABILITY (not text generation)
# ─────────────────────────────────────────────────────────
# WHY NOT text generation?
#   DistilGPT-2 is a BASE completion model, not instruction-following.
#   When asked to generate text it tends to continue the most statistically
#   common pattern in the prompt context — often the last few-shot answer,
#   or any digit that appears frequently (like "10" in "error count 10 min").
#   This causes it to predict 10 for nearly everything (MSE > 40, MAE > 5).
#
# HOW logprob scoring works:
#   After building the prompt ending with "Anomaly score:", we do ONE forward
#   pass and read the model's next-token probability distribution.
#   We then ask: "of all tokens that spell out 0, 1, 2 ... 10, which does
#   the model assign the highest probability to?"  That is our score.
#
#   For single-digit scores 0–9  → one token each  (" 0", " 1", ..., " 9")
#   For score 10                 → two tokens       (" 1" then "0")
#                                  P(" 10") = P(" 1") × P("0" | context+" 1")
#
#   This is deterministic, needs NO generation loop, and uses the model's
#   actual learned probability distribution rather than forcing it to string-
#   complete.  It is the standard technique for GPT-based classification.
#
# APPROACH:
#   1. Build a structured few-shot prompt with 6 labelled examples
#   2. One forward pass → read next-token log-probabilities at "Anomaly score:"
#   3. Argmax over candidate score tokens 0–10 → predicted score
#   4. Evaluate with MSE / MAE / per-severity-band breakdown
#   5. Visualise — same graph layout as logbert_logdemo.py

import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

# Transformers is required: pip install transformers
import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer

np.random.seed(42)
torch.manual_seed(42)

print("GPT Log Anomaly Scoring — Zero-shot Inference with DistilGPT-2")
print("=" * 65)


# =============================================================================
# 1. GOLDEN DATASET  (same 30 events as all other demos)
#    All 30 rows serve as the evaluation set — no train/test split needed
#    because the model has never been trained on this data.
# =============================================================================
print("\n1. Loading Golden Log Dataset (30 events)...")

data = {
    'log_message': [
        # healthy / informational
        "disk read write operations normal",
        "network interface link speed stable",
        "cpu utilization within expected range",
        "fan speed nominal all modules reporting",
        "memory ecc errors zero count nominal",
        "storage controller cache hit rate good",
        "power supply voltage levels stable",
        "raid rebuild completed successfully",
        "network packet loss negligible acceptable",
        "temperature sensors all within threshold",
        # degraded / warning signals
        "disk latency elevated threshold warning",
        "network retransmit rate increasing observed",
        "cpu temperature approaching limit warning",
        "fan module reporting intermittent failures",
        "memory correctable ecc errors increasing",
        "storage controller queue depth high warning",
        "power supply ripple voltage detected",
        "raid degraded missing drive detected",
        "packet drops increasing on port warning",
        "thermal sensor reading high warning",
        # critical / failure signals
        "disk io timeout uncorrectable error critical",
        "network link down failover triggered critical",
        "cpu throttling thermal emergency shutdown",
        "fan failure multiple modules offline critical",
        "memory uncorrectable ecc error panic critical",
        "storage controller cache failed data loss risk",
        "power supply failed redundancy lost critical",
        "raid failed multiple drives offline critical",
        "network storm detected broadcast loop critical",
        "chassis over temperature emergency shutdown",
    ],
    'component': [
        'StorageCtrl','NetworkAdapter','ComputeBlade','FanModule',   'MemorySubsys',
        'StorageCtrl','PowerSupply',  'StorageCtrl', 'NetworkAdapter','ThermalMgmt',
        'StorageCtrl','NetworkAdapter','ComputeBlade','FanModule',   'MemorySubsys',
        'StorageCtrl','PowerSupply',  'StorageCtrl', 'NetworkAdapter','ThermalMgmt',
        'StorageCtrl','NetworkAdapter','ComputeBlade','FanModule',   'MemorySubsys',
        'StorageCtrl','PowerSupply',  'StorageCtrl', 'NetworkAdapter','ThermalMgmt',
    ],
    'log_level': [
        'INFO','INFO','INFO','INFO','INFO',
        'INFO','INFO','INFO','INFO','INFO',
        'WARNING','WARNING','WARNING','WARNING','WARNING',
        'WARNING','WARNING','WARNING','WARNING','WARNING',
        'ERROR','ERROR','ERROR','ERROR','ERROR',
        'CRITICAL','CRITICAL','CRITICAL','CRITICAL','CRITICAL',
    ],
    'mins_since_last_error': [
        120, 90,150,200,180,110,300, 95, 75,250,
         45, 30, 20, 15, 40, 25, 10,  8, 35, 18,
          5,  3,  7,  2,  4,  1,  1,  1,  2,  1,
    ],
    'error_count_10min': [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        2, 3, 4, 5, 2, 6, 7, 8, 3, 5,
        9,12,10,15,11,18,20,22,14,25,
    ],
    'anomaly_score': [
        0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
        3, 4, 5, 5, 4, 5, 6, 7, 4, 5,
        8, 8, 9, 9, 8, 9,10,10, 8,10,
    ],
}

df = pd.DataFrame(data)
print(f"  Golden dataset: {len(df)} log events across 4 severity tiers")
print(df[['log_message','component','log_level','anomaly_score']].head(6).to_string(index=False))


# =============================================================================
# 2. LOAD PRE-TRAINED GPT MODEL (no fine-tuning, weights frozen)
# =============================================================================
print("\n2. Loading Pre-trained DistilGPT-2...")
print("   (downloads ~330 MB on first run from HuggingFace Hub)")

MODEL_NAME = "distilgpt2"   # 82M parameters — GPT-2 architecture, half the layers
                              # Alternatives: "gpt2" (117M), "gpt2-medium" (345M)

tokenizer = GPT2Tokenizer.from_pretrained(MODEL_NAME)
tokenizer.pad_token = tokenizer.eos_token   # GPT-2 has no dedicated pad token

gpt = GPT2LMHeadModel.from_pretrained(MODEL_NAME)
gpt.eval()   # inference mode — no dropout, no gradient tracking

param_count = sum(p.numel() for p in gpt.parameters())
print(f"  Model      : {MODEL_NAME}")
print(f"  Parameters : {param_count:,}")
print(f"  Frozen     : Yes — weights unchanged throughout this script")


# =============================================================================
# 3. PROMPT DESIGN
#    Few-shot prompting: provide 4 labelled examples (one per severity tier)
#    so the model learns the output format from context alone.
#
#    DESIGN PRINCIPLES:
#    - Structured, consistent format so the model can pattern-match reliably
#    - One representative example per severity band to anchor the 0–10 scale
#    - Numeric metadata included (mins_since_last_error, error_count) so the
#      model can reason about temporal signal, not just keywords
#    - "Anomaly score:" as the completion cue — GPT continues the sequence
#      with whatever comes next, and we parse the first integer
# =============================================================================
print("\n3. Designing Few-Shot Prompt...")

# ── 6 examples: two per severity cluster (low / mid / high) ──────────────────
# Using more examples, and deliberately NOT ending on score=10,
# reduces the model's tendency to bias toward the last seen answer.
FEW_SHOT_EXAMPLES = [
    # (message, component, log_level, mins_since_error, error_count_10min, score)
    ("temperature sensors all within threshold",
     "ThermalMgmt", "INFO", 250, 0, 0),
    ("network packet loss negligible acceptable",
     "NetworkAdapter", "INFO", 75, 0, 0),
    ("cpu temperature approaching limit warning",
     "ComputeBlade", "WARNING", 20, 4, 5),
    ("storage controller queue depth high warning",
     "StorageCtrl", "WARNING", 25, 6, 5),
    ("fan failure multiple modules offline critical",
     "FanModule", "CRITICAL", 2, 15, 9),
    ("memory uncorrectable ecc error panic critical",
     "MemorySubsys", "ERROR", 4, 11, 8),
]

SYSTEM_HEADER = (
    "Infrastructure log anomaly scoring system. "
    "Score = integer 0 (completely healthy) to 10 (imminent failure). "
    "0-2: HEALTHY  3-5: DEGRADED  6-8: WARNING  9-10: CRITICAL\n\n"
)

def format_event_block(message, component, log_level, mins, errs,
                       answer=None):
    """Format one log event into the prompt template."""
    block = (
        f'Log: "{message}"\n'
        f"Component: {component} | Level: {log_level} | "
        f"Mins since last error: {mins} | Error count (10 min): {errs}\n"
        f"Anomaly score:"
    )
    if answer is not None:
        block += f" {answer}"
    return block

def build_prompt(message, component, log_level, mins, errs):
    """Build the full few-shot prompt for one target event."""
    parts = [SYSTEM_HEADER]
    for msg, comp, lvl, m, e, score in FEW_SHOT_EXAMPLES:
        parts.append(format_event_block(msg, comp, lvl, m, e, answer=score))
        parts.append("")           # blank line between examples
    parts.append(format_event_block(message, component, log_level, mins, errs))
    return "\n".join(parts)

# Show the prompt for one event so the user can see the format
sample_prompt = build_prompt(
    "memory uncorrectable ecc error panic critical",
    "MemorySubsys", "ERROR", 4, 11
)
print("\n  ── Sample prompt (for event 25) ─────────────────────────────────────")
for line in sample_prompt.split("\n"):
    print(f"    {line}")

# Count prompt tokens for reporting
sample_tokens = tokenizer(sample_prompt, return_tensors="pt")["input_ids"].shape[1]
print(f"\n  Prompt tokens : ~{sample_tokens} (varies slightly per event)")
print(f"  Few-shot examples: {len(FEW_SHOT_EXAMPLES)} (one per severity tier)")


# =============================================================================
# 4. INFERENCE — log-probability scoring (one forward pass per event)
#
#    After the prompt ends with "Anomaly score:" the model's next-token
#    distribution tells us which digit it considers most likely.
#    We evaluate P(" 0") … P(" 9") directly, and for " 10" we chain two
#    tokens: P(" 1") × P("0" | context+" 1").  argmax → predicted score.
#
#    WHY THIS IS BETTER THAN TEXT GENERATION FOR BASE MODELS:
#    - No risk of the model continuing with unrelated text ("10 things...")
#    - Uses the full softmax distribution, not just the greedy top-1 token
#    - ~4× faster — no auto-regressive generation loop needed
#    - Deterministic and fully interpretable (we can inspect all 11 probs)
# =============================================================================
print("\n4. Running Log-Probability Inference on all 30 events (no training)...")

# Pre-compute token IDs for every candidate score once (not per event)
CANDIDATE_SCORES = list(range(11))   # 0 … 10

def get_candidate_token_ids():
    """
    Return a dict: score_int → list of token IDs that spell " <score>".
    Both " 7" (space-digit) and "7" (no-space) forms are checked;
    whichever tokenises to fewer tokens is preferred for efficiency.
    """
    cands = {}
    for s in CANDIDATE_SCORES:
        ids_space = tokenizer.encode(f" {s}", add_special_tokens=False)
        ids_nospace = tokenizer.encode(f"{s}", add_special_tokens=False)
        # Prefer the shorter encoding (single token when possible)
        cands[s] = ids_space if len(ids_space) <= len(ids_nospace) else ids_nospace
    return cands

CAND_IDS = get_candidate_token_ids()

print("  Candidate token shapes:")
for s, ids in CAND_IDS.items():
    decoded = tokenizer.decode(ids)
    print(f"    score {s:>2} → tokens {ids}  ('{decoded}')")

def score_event(message, component, log_level, mins, errs):
    """
    Score one log event via next-token log-probability.

    Returns:
        best_score   : int   — argmax score in [0, 10]
        all_logprobs : dict  — {score: log_prob} for all 11 candidates
        prompt_len   : int   — number of tokens in the prompt
    """
    prompt = build_prompt(message, component, log_level, mins, errs)
    inputs = tokenizer(prompt, return_tensors="pt")
    prompt_len = inputs["input_ids"].shape[1]

    # ── Single forward pass — get next-token logits ───────────────────────────
    with torch.no_grad():
        out = gpt(**inputs)

    # Log-softmax over the full vocabulary at the final prompt position
    log_probs_vocab = torch.log_softmax(out.logits[0, -1, :], dim=-1)

    all_logprobs = {}
    for s, ids in CAND_IDS.items():
        if len(ids) == 1:
            # Single-token score (e.g. " 7" → token 767)
            lp = log_probs_vocab[ids[0]].item()

        else:
            # Two-token score (e.g. " 10" → tokens for " 1" and "0")
            # P(" 10") = P(" 1") × P("0" | context + " 1")
            lp_first = log_probs_vocab[ids[0]].item()

            extended_ids = torch.cat([
                inputs["input_ids"],
                torch.tensor([[ids[0]]])
            ], dim=1)
            with torch.no_grad():
                out2 = gpt(extended_ids)
            lp_second = torch.log_softmax(
                out2.logits[0, -1, :], dim=-1
            )[ids[1]].item()
            lp = lp_first + lp_second   # log P(A,B) = log P(A) + log P(B|A)

        all_logprobs[s] = lp

    best_score = max(all_logprobs, key=lambda s: all_logprobs[s])
    return float(best_score), all_logprobs, prompt_len

# Score all 30 events
predictions   = []
all_logprobs_list = []
prompt_lengths = []

for idx, row in df.iterrows():
    score, lps, plen = score_event(
        row['log_message'], row['component'], row['log_level'],
        row['mins_since_last_error'], row['error_count_10min']
    )
    predictions.append(score)
    all_logprobs_list.append(lps)
    prompt_lengths.append(plen)
    if (idx + 1) % 10 == 0:
        print(f"  Scored {idx+1:2d}/30 events...")

df['predicted_score'] = predictions
df['prompt_tokens']   = prompt_lengths

print(f"  Done. All {len(df)} events scored.")


# =============================================================================
# 5. EVALUATION
# =============================================================================
print("\n5. Evaluating Predictions...")

actual    = df['anomaly_score'].values.astype(float)
predicted = df['predicted_score'].values

mse = np.mean((actual - predicted) ** 2)
mae = np.mean(np.abs(actual - predicted))
rmse = math.sqrt(mse)

def score_label(s):
    if s < 3:  return "HEALTHY"
    if s < 6:  return "DEGRADED"
    if s < 9:  return "WARNING"
    return "CRITICAL"

actual_labels    = [score_label(s) for s in actual]
predicted_labels = [score_label(s) for s in predicted]
correct = sum(a == p for a, p in zip(actual_labels, predicted_labels))

print(f"\n  MSE  : {mse:.4f}")
print(f"  RMSE : {rmse:.4f}")
print(f"  MAE  : {mae:.4f}")
print(f"  Severity band accuracy: {correct}/{len(df)} = {correct/len(df)*100:.1f}%")

# Per-severity-tier breakdown
TIERS = ['HEALTHY', 'DEGRADED', 'WARNING', 'CRITICAL']
print(f"\n  {'Tier':<10} {'Count':>5}  {'MAE':>6}  {'Correct':>7}")
print(f"  {'-'*36}")
for tier in TIERS:
    mask = np.array(actual_labels) == tier
    if not mask.any():
        continue
    tier_mae = np.mean(np.abs(actual[mask] - predicted[mask]))
    tier_correct = sum(
        np.array(predicted_labels)[mask] == tier
    )
    print(f"  {tier:<10} {mask.sum():>5}  {tier_mae:>6.3f}  {tier_correct:>4}/{mask.sum()}")


# =============================================================================
# 6. PREDICTIONS TABLE  (all 30 events)
# =============================================================================
print("\n6. Full Prediction Table...")
print(f"\n  {'#':>2}  {'Log Message (truncated)':<42}  {'Actual':>6}  {'GPT':>5}  "
      f"{'Actual Label':<10} {'GPT Label':<10}  Top-3 logprobs")
print("  " + "-" * 115)

for i, row in df.iterrows():
    msg   = row['log_message'][:41]
    act   = row['anomaly_score']
    pred  = row['predicted_score']
    al    = score_label(act)
    pl    = score_label(pred)
    marker = "*" if al != pl else " "
    # Show top-3 candidate scores by log-probability for interpretability
    lps   = all_logprobs_list[i]
    top3  = sorted(lps, key=lambda s: lps[s], reverse=True)[:3]
    top3_str = "  ".join(f"{s}({lps[s]:.1f})" for s in top3)
    print(f"  {i+1:>2}{marker} {msg:<42}  {act:>6.0f}  {pred:>5.1f}  {al:<10} {pl:<10}  {top3_str}")

print("  (* = severity band mismatch)")


# =============================================================================
# 7. INFERENCE ON NEW / UNSEEN LOG EVENTS
#    (same 6 events used in rnn_logdemo, lstm_logdemo, logbert_logdemo)
# =============================================================================
print("\n7. Inference on New Log Events...")

new_events = [
    # message                                           comp              level     mins  errs
    ("disk read write operations normal",              "StorageCtrl",    "INFO",    200,   0),
    ("storage controller queue depth high warning",   "StorageCtrl",    "WARNING",  20,   6),
    ("disk io timeout uncorrectable error critical",  "StorageCtrl",    "ERROR",     3,  14),
    ("fan failure multiple modules offline critical", "FanModule",      "CRITICAL",  1,  20),
    ("network retransmit rate increasing observed",   "NetworkAdapter", "WARNING",  30,   3),
    ("power supply failed redundancy lost critical",  "PowerSupply",    "CRITICAL",  1,  22),
]

print(f"\n  {'Log Message':<48}  {'Score':>5}  Status")
print("  " + "-" * 72)
for msg, comp, lvl, mins, errs in new_events:
    score, _, _ = score_event(msg, comp, lvl, mins, errs)
    print(f"  {msg:<48}  {score:>5.1f}  {score_label(score)}")


# =============================================================================
# 8. VISUALISATIONS
#    Layout mirrors logbert_logdemo.py:
#      Figure 1 (2×3): score distributions + scatter + per-sample error
#      Figure 2 (1×2): sorted comparison line + MAE by severity band
#    Adapted for zero-shot inference (no training loss to plot).
# =============================================================================
print("\n8. Generating Visualisations...")

GPT_COLOR  = 'mediumorchid'
ACT_COLOR  = 'steelblue'
ERR_COLOR  = 'tomato'

# ── Figure 1 (2 × 3) ─────────────────────────────────────────────────────────
fig, axes = plt.subplots(2, 3, figsize=(17, 9))
fig.suptitle("GPT Few-Shot Log Anomaly Scoring — HPE Infrastructure",
             fontsize=13, fontweight='bold')

# ── [0,0] Actual score distribution (bar per event, coloured by tier) ─────────
tier_colors = {
    'HEALTHY': 'steelblue', 'DEGRADED': 'gold',
    'WARNING': 'darkorange', 'CRITICAL': 'tomato',
}
bar_colors = [tier_colors[score_label(s)] for s in actual]
axes[0, 0].bar(range(len(actual)), actual, color=bar_colors, alpha=0.85, width=0.7)
axes[0, 0].set_title('Golden Dataset — Actual Scores')
axes[0, 0].set_xlabel('Log Event Index')
axes[0, 0].set_ylabel('Anomaly Score')
axes[0, 0].set_ylim(-0.5, 11)
axes[0, 0].grid(True, axis='y', alpha=0.4)
# Legend
from matplotlib.patches import Patch
legend_els = [Patch(facecolor=c, label=t) for t, c in tier_colors.items()]
axes[0, 0].legend(handles=legend_els, fontsize=7, loc='upper left')

# ── [0,1] GPT predicted score distribution ────────────────────────────────────
pred_bar_colors = [tier_colors[score_label(s)] for s in predicted]
axes[0, 1].bar(range(len(predicted)), predicted, color=pred_bar_colors, alpha=0.85, width=0.7)
axes[0, 1].set_title('GPT Few-Shot — Predicted Scores')
axes[0, 1].set_xlabel('Log Event Index')
axes[0, 1].set_ylabel('Predicted Anomaly Score')
axes[0, 1].set_ylim(-0.5, 11)
axes[0, 1].grid(True, axis='y', alpha=0.4)
axes[0, 1].legend(handles=legend_els, fontsize=7, loc='upper left')

# ── [0,2] Predicted vs Actual scatter ─────────────────────────────────────────
axes[0, 2].scatter(actual, predicted, color=GPT_COLOR, alpha=0.85, s=60, zorder=3)
axes[0, 2].plot([0, 10], [0, 10], 'r--', linewidth=1, label='Perfect')
axes[0, 2].set_xlabel('Actual Anomaly Score')
axes[0, 2].set_ylabel('GPT Predicted Score')
axes[0, 2].set_title('Predicted vs Actual (all 30 events)')
axes[0, 2].set_xlim(-0.5, 10.5)
axes[0, 2].set_ylim(-0.5, 10.5)
axes[0, 2].legend(fontsize=8)
axes[0, 2].grid(True, alpha=0.4)
# Annotate MSE/MAE
axes[0, 2].text(0.05, 0.92, f'MSE={mse:.2f}  MAE={mae:.2f}',
                transform=axes[0, 2].transAxes, fontsize=8,
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

# ── [1,0] Log-probability heatmap for first 15 events ────────────────────────
# Shows the full distribution the model computes over 0–10 for each event.
# Bright = high probability; the model's argmax is its predicted score.
# This is unique to logprob scoring — text generation never exposes this.
n_show   = min(15, len(df))
lp_matrix = np.array([
    [all_logprobs_list[i][s] for s in CANDIDATE_SCORES]
    for i in range(n_show)
])
# Normalise each row to [0,1] for visual clarity (relative confidence)
lp_min = lp_matrix.min(axis=1, keepdims=True)
lp_max = lp_matrix.max(axis=1, keepdims=True)
lp_norm = (lp_matrix - lp_min) / (lp_max - lp_min + 1e-9)

im = axes[1, 0].imshow(lp_norm.T, aspect='auto', cmap='YlOrRd',
                        origin='lower', vmin=0, vmax=1)
# Mark the argmax (predicted score) per event
for i in range(n_show):
    pred_s = int(predictions[i])
    axes[1, 0].plot(i, pred_s, 'b^', markersize=5, zorder=5)
# Mark actual score per event
for i in range(n_show):
    act_s = int(actual[i])
    axes[1, 0].plot(i, act_s, 'g*', markersize=7, zorder=5)

axes[1, 0].set_yticks(CANDIDATE_SCORES)
axes[1, 0].set_yticklabels(CANDIDATE_SCORES, fontsize=7)
axes[1, 0].set_xlabel('Log Event Index (first 15)')
axes[1, 0].set_ylabel('Candidate Score')
axes[1, 0].set_title('Logprob Heatmap  (▲=predicted  ★=actual)')
plt.colorbar(im, ax=axes[1, 0], label='Normalised log-prob', shrink=0.85)

# ── [1,1] MAE by severity band ────────────────────────────────────────────────
bands      = ['HEALTHY\n(0–2)', 'DEGRADED\n(3–5)', 'WARNING\n(6–8)', 'CRITICAL\n(9–10)']
band_keys  = ['HEALTHY', 'DEGRADED', 'WARNING', 'CRITICAL']
band_maes  = []
band_cnts  = []

def band_idx(score):
    if score <= 2: return 0
    if score <= 5: return 1
    if score <= 8: return 2
    return 3

bucket_errors = [[] for _ in range(4)]
for a, p in zip(actual, predicted):
    bucket_errors[band_idx(a)].append(abs(a - p))

band_maes = [np.mean(v) if v else 0 for v in bucket_errors]
band_cnts = [len(v) for v in bucket_errors]
band_colors = [tier_colors[k] for k in band_keys]

bars = axes[1, 1].bar(bands, band_maes, color=band_colors, alpha=0.85, width=0.5)
axes[1, 1].set_ylabel('Mean Absolute Error')
axes[1, 1].set_title('MAE per Severity Band')
axes[1, 1].grid(True, axis='y', alpha=0.4)
# Annotate count on each bar
for bar, cnt in zip(bars, band_cnts):
    axes[1, 1].text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.05, f'n={cnt}',
                    ha='center', va='bottom', fontsize=8)

# ── [1,2] Mean actual vs mean predicted score per component ────────────────────
comp_actual = df.groupby('component')['anomaly_score'].mean().sort_values()
comp_pred   = df.groupby('component')['predicted_score'].mean().reindex(comp_actual.index)

x_pos = np.arange(len(comp_actual))
w = 0.35
axes[1, 2].barh(x_pos - w/2, comp_actual.values, w,
                color=ACT_COLOR, alpha=0.8, label='Actual')
axes[1, 2].barh(x_pos + w/2, comp_pred.values,   w,
                color=GPT_COLOR, alpha=0.8, label='GPT Predicted')
axes[1, 2].set_yticks(x_pos)
axes[1, 2].set_yticklabels(comp_actual.index, fontsize=8)
axes[1, 2].set_xlabel('Mean Anomaly Score')
axes[1, 2].set_title('Mean Score by Component')
axes[1, 2].legend(fontsize=8)
axes[1, 2].grid(True, axis='x', alpha=0.4)

plt.tight_layout()
plt.show()

# ── Figure 2 (1 × 2) ─────────────────────────────────────────────────────────
fig2, axes2 = plt.subplots(1, 2, figsize=(13, 5))
fig2.suptitle("GPT Few-Shot Scoring — Event Comparison & Severity Accuracy",
              fontsize=12, fontweight='bold')

# ── [0] Actual vs Predicted side-by-side sorted by actual score ───────────────
sort_idx   = np.argsort(actual)
x_ev       = np.arange(len(actual))

axes2[0].plot(x_ev, actual[sort_idx],    color=ACT_COLOR,  linewidth=2,
              marker='o', markersize=4,  label='Actual',    zorder=3)
axes2[0].plot(x_ev, predicted[sort_idx], color=GPT_COLOR,  linewidth=2,
              marker='s', markersize=4,  label='GPT Predicted', zorder=3,
              linestyle='--')
axes2[0].fill_between(x_ev, actual[sort_idx], predicted[sort_idx],
                       alpha=0.15, color='grey', label='Error region')
axes2[0].set_xlabel('Event (sorted by actual severity)')
axes2[0].set_ylabel('Anomaly Score')
axes2[0].set_title('Actual vs GPT Predicted (sorted)')
axes2[0].legend(fontsize=9)
axes2[0].grid(True, alpha=0.4)

# Reference lines for severity tier boundaries
for boundary, label_txt in [(2.5, 'HEALTHY|DEGRADED'),
                              (5.5, 'DEGRADED|WARNING'),
                              (8.5, 'WARNING|CRITICAL')]:
    axes2[0].axhline(boundary, color='grey', linewidth=0.8,
                      linestyle=':', alpha=0.7)
    axes2[0].text(len(actual) - 0.5, boundary + 0.1, label_txt,
                   ha='right', fontsize=6, color='grey')

# ── [1] Severity band classification accuracy (actual vs GPT label) ───────────
from collections import Counter as Ctr

correct_counts = {t: 0 for t in TIERS}
total_counts   = {t: 0 for t in TIERS}
for al, pl in zip(actual_labels, predicted_labels):
    total_counts[al] += 1
    if al == pl:
        correct_counts[al] += 1

acc_vals    = [correct_counts[t] / total_counts[t] if total_counts[t] else 0 for t in TIERS]
total_vals  = [total_counts[t] for t in TIERS]
acc_colors  = [tier_colors[t] for t in TIERS]

bar_acc = axes2[1].bar(TIERS, acc_vals, color=acc_colors, alpha=0.85, width=0.5)
axes2[1].set_ylim(0, 1.15)
axes2[1].set_ylabel('Accuracy (correct tier / total)')
axes2[1].set_title(f'Severity Band Accuracy  (overall {correct}/{len(df)} = {correct/len(df)*100:.0f}%)')
axes2[1].grid(True, axis='y', alpha=0.4)
axes2[1].axhline(1.0, color='grey', linewidth=0.8, linestyle='--')
for bar, acc, tot in zip(bar_acc, acc_vals, total_vals):
    axes2[1].text(bar.get_x() + bar.get_width() / 2,
                  bar.get_height() + 0.03,
                  f'{acc*100:.0f}%\n(n={tot})',
                  ha='center', va='bottom', fontsize=8)

plt.tight_layout()
plt.show()

print(f"\n{'='*65}")
print("GPT Log Anomaly Demo Complete!")
print(f"  Model      : {MODEL_NAME} (pre-trained, frozen)")
print(f"  Technique  : {len(FEW_SHOT_EXAMPLES)}-shot prompting — NO fine-tuning")
print(f"  MAE        : {mae:.4f}   RMSE: {rmse:.4f}")
print(f"  Accuracy   : {correct}/{len(df)} severity bands correct")
print(f"{'='*65}")


# =============================================================================
# HOW THIS DIFFERS FROM RNN / LSTM / LogBERT
# =============================================================================
#
# ── KNOWLEDGE SOURCE ──────────────────────────────────────────────────────────
# RNN / LSTM / LogBERT: all knowledge comes from the 22-row TRAINING SET.
#   They learn "uncorrectable → high score" purely from the examples they see.
#
# GPT (this file): knowledge is baked into 82 M parameters pre-trained on
#   40 GB of internet text.  The model already "knows" that "uncorrectable",
#   "failed", "emergency shutdown" are bad, because those words appear in
#   negative contexts throughout its training corpus.
#   The 4-shot prompt only teaches the OUTPUT FORMAT, not the meaning of words.
#
# ── WHEN GPT WINS ─────────────────────────────────────────────────────────────
# 1. No labelled data available: GPT scores unseen log events immediately.
# 2. Rare failure modes: a 30-row training set cannot cover every failure type;
#    GPT's broad pre-training generalises to novel phrasings.
# 3. Rapid prototyping: zero engineering time — just write a good prompt.
#
# ── WHEN TRAINED MODELS WIN ───────────────────────────────────────────────────
# 1. Domain-specific numeric signals: GPT does not understand that
#    "error_count_10min=22" is worse than "=2" unless the prompt is very
#    explicit.  Trained models learn these numerical relationships directly.
# 2. High throughput: GPT inference requires ~400 prompt tokens per event.
#    An RNN scores events in microseconds; GPT takes tens of milliseconds.
# 3. Precision on known patterns: a trained model on 1 M labelled logs will
#    consistently outperform zero-shot GPT on in-distribution events.
# 4. Cost at scale: scoring 1 M logs/day via a cloud LLM API is expensive;
#    a local RNN/LSTM costs fractions of a cent.
#
# ── PROMPT ENGINEERING MATTERS ────────────────────────────────────────────────
# The 4-shot examples anchor the model's 0–10 scale.  Without them:
#   - GPT might output "high", "critical", or a score on a 1–5 scale.
#   - Including one example per tier reduces hallucination of out-of-range values.
#
# Improvements to try:
#   a) Chain-of-thought: add "Reasoning: ..." before each score in the examples.
#      GPT will generate intermediate reasoning before the number, which often
#      improves accuracy on borderline cases.
#   b) Calibration prompt: explicitly state score semantics
#      ("level: CRITICAL always implies score ≥ 9").
#   c) Retrieval-augmented: at inference time, retrieve the 3 most similar
#      events from a labelled store and include them as dynamic few-shot examples.
#
# =============================================================================
# NEXT STEPS — PRODUCTION GPT LOG SCORING
# =============================================================================
#
# STEP 1 — REPLACE DistilGPT-2 WITH A LARGER INSTRUCTION-TUNED MODEL
#    distilgpt2 is a base model (completion only, not instruction-tuned).
#    In production, use an instruction-tuned variant (GPT-3.5/4 via API, or
#    Llama-3-8B-Instruct / Mistral-7B-Instruct running locally) — they follow
#    structured output instructions far more reliably.
#
# STEP 2 — STRUCTURED OUTPUT / JSON MODE
#    Force the model to output JSON: {"score": 8, "tier": "WARNING", "reason": "..."}
#    Use json_mode=True (OpenAI API) or constrained decoding (llama.cpp, vLLM)
#    to guarantee parseable output and eliminate the fallback default.
#
# STEP 3 — RETRIEVAL-AUGMENTED FEW-SHOT (RAG)
#    Store all labelled events in a vector database (FAISS, Chroma).
#    At inference time, embed the new log event and retrieve the k=4 most
#    similar labelled examples.  Use those as dynamic few-shot demonstrations.
#    This adapts the prompt to the specific failure pattern being scored.
#
# STEP 4 — FINE-TUNING FOR DOMAIN ADAPTATION
#    If accuracy from prompting is insufficient, fine-tune a smaller model
#    (e.g. Llama-3-1B) on your labelled log dataset using LoRA (Low-Rank
#    Adaptation).  You retain the pre-trained world knowledge but adapt the
#    model to HPE log vocabulary and the 0–10 scoring rubric.
#    Cost: ~1 GPU-hour on a few thousand examples.
#
# STEP 5 — CHAIN-OF-THOUGHT SCORING FOR EXPLAINABILITY
#    Prompt: "Think step by step: identify the severity keywords, check the
#    component criticality, factor in error_count_10min, then give the score."
#    The model's reasoning chain doubles as an explanation for on-call engineers.
#
# STEP 6 — LATENCY OPTIMISATION
#    For online scoring (<50 ms SLA):
#      - Quantise the model to INT8 / INT4 (bitsandbytes / llama.cpp)
#      - Cache common prompt prefixes (KV-cache prefix sharing in vLLM)
#      - Batch multiple events into one prompt (few events → one API call)
