import json
import os
import ssl
import requests
import urllib3
import yfinance as yf
from datetime import datetime
from dotenv import load_dotenv
import boto3
import streamlit as st

# Suppress SSL warnings that appear when verification is disabled
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Disable SSL verification globally so yfinance's internal curl_cffi session
# (and any other https calls) skip certificate checks — fixes corporate proxy issues
ssl._create_default_https_context = ssl._create_unverified_context

# Shared requests session with SSL verification disabled for OpenWeatherMap calls
_session = requests.Session()
_session.verify = False


def _find_dotenv():
    current = os.path.abspath(os.getcwd())
    while True:
        candidate = os.path.join(current, ".env")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            print("Error: .env file not found in current directory or any parent directory.")
            raise SystemExit(1)
        current = parent


load_dotenv(dotenv_path=_find_dotenv())

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

if not OPENWEATHERMAP_API_KEY:
    st.error("OPENWEATHERMAP_API_KEY is not set in .env — add it and restart the app.")
    st.stop()

# App title and description
st.title("Multipurpose Assistant (Amazon Bedrock)")
st.markdown("Ask me about weather or stock prices!")

# Initialize chat history in session state
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])


# ─── Diagnostic helpers ───────────────────────────────────────────────────────

def diag_section(title: str, color: str = "#1e3a5f"):
    """Return an HTML badge-style header for a diagnostic step."""
    return f"""<div style="background:{color};color:white;padding:6px 12px;
        border-radius:6px;font-weight:bold;font-size:0.85em;margin-top:8px">
        {title}</div>"""


def show_json(label: str, data, container=None):
    target = container if container else st
    target.markdown(f"**{label}**")
    target.code(json.dumps(data, indent=2, default=str), language="json")


# ─── Tool functions ────────────────────────────────────────────────────────────

def get_weather(location: str, days: int = 1, _diag=None) -> dict:
    """Get weather forecast for a location."""
    if _diag:
        _diag.markdown(diag_section("🔧 TOOL CALLED: get_weather", "#1a5276"), unsafe_allow_html=True)
        _diag.markdown("**Inputs received by tool:**")
        _diag.code(json.dumps({"location": location, "days": days}, indent=2), language="json")

    print(f"Getting weather for location: {location}, days: {days}")

    geo_url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={OPENWEATHERMAP_API_KEY}"

    if _diag:
        _diag.markdown("**API call being made (Step 1 — geocoding):**")
        safe_url = geo_url.replace(OPENWEATHERMAP_API_KEY, "***API_KEY***")
        _diag.code(f"GET {safe_url}", language="text")

    geo_response = _session.get(geo_url)

    if _diag:
        _diag.markdown(f"**Geocoding API response** (status `{geo_response.status_code}`):")
        try:
            _diag.code(json.dumps(geo_response.json(), indent=2), language="json")
        except Exception:
            _diag.code(geo_response.text, language="text")

    if geo_response.status_code != 200:
        return {"error": f"Could not retrieve location data. Status code: {geo_response.status_code}"}

    geo_data = geo_response.json()
    if not geo_data:
        return {"error": f"Location '{location}' not found."}

    latitude = geo_data[0]['lat']
    longitude = geo_data[0]['lon']

    weather_url = f"http://api.openweathermap.org/data/2.5/forecast?lat={latitude}&lon={longitude}&appid={OPENWEATHERMAP_API_KEY}&units=metric"

    if _diag:
        _diag.markdown("**API call being made (Step 2 — forecast):**")
        safe_wurl = weather_url.replace(OPENWEATHERMAP_API_KEY, "***API_KEY***")
        _diag.code(f"GET {safe_wurl}", language="text")

    weather_response = _session.get(weather_url)

    if _diag:
        _diag.markdown(f"**Forecast API response** (status `{weather_response.status_code}`, showing first 2 items):")
        try:
            raw = weather_response.json()
            preview = {**raw, "list": raw.get("list", [])[:2]}
            _diag.code(json.dumps(preview, indent=2), language="json")
        except Exception:
            _diag.code(weather_response.text[:500], language="text")

    if weather_response.status_code != 200:
        return {"error": f"Could not retrieve weather data. Status code: {weather_response.status_code}"}

    weather_data = weather_response.json()

    entries_per_day = 8
    total_entries = min(entries_per_day * days, len(weather_data['list']))

    forecasts = []
    for forecast in weather_data['list'][:total_entries]:
        forecasts.append({
            'time': forecast['dt_txt'],
            'description': forecast['weather'][0]['description'],
            'rain_probability': forecast.get('pop', 0) * 100,
            'temp': forecast['main']['temp'],
            'humidity': forecast['main']['humidity'],
            'wind_speed': forecast['wind']['speed']
        })

    result = {'location': location, 'forecast': forecasts}

    if _diag:
        _diag.markdown("**Tool return value (sent back to context):**")
        _diag.code(json.dumps(result, indent=2), language="json")

    return result


def get_stock_price(symbol: str, _diag=None) -> dict:
    """Get the latest stock price and information for a given ticker symbol."""
    if _diag:
        _diag.markdown(diag_section("🔧 TOOL CALLED: get_stock_price", "#1a5276"), unsafe_allow_html=True)
        _diag.markdown("**Inputs received by tool:**")
        _diag.code(json.dumps({"symbol": symbol}, indent=2), language="json")

    try:
        print(f"Getting stock price for symbol: {symbol}")

        if _diag:
            _diag.markdown("**API call being made:**")
            _diag.code(f"yfinance.Ticker('{symbol}').history(period='2d')", language="python")

        stock = yf.Ticker(symbol)
        stock_info = stock.info
        hist = stock.history(period="2d")

        if hist.empty:
            result = {"error": f"No data available for symbol '{symbol}'"}
            if _diag:
                _diag.markdown("**API response:**")
                _diag.code(json.dumps(result, indent=2), language="json")
            return result

        if _diag:
            _diag.markdown("**API response (raw history, last 2 days):**")
            _diag.code(hist.to_string(), language="text")

        latest_close = hist['Close'].iloc[-1]
        previous_close = hist['Close'].iloc[0] if len(hist) > 1 else latest_close
        change = latest_close - previous_close
        change_percent = (change / previous_close) * 100 if previous_close else 0

        result = {
            'symbol': symbol,
            'company_name': stock_info.get('shortName', 'N/A'),
            'latest_price': float(latest_close),
            'currency': stock_info.get('currency', 'USD'),
            'change': float(change),
            'change_percent': float(change_percent),
            'previous_close': float(previous_close),
            'market_cap': stock_info.get('marketCap', 'N/A'),
            'volume': int(hist['Volume'].iloc[-1]) if 'Volume' in hist else 'N/A',
            'exchange': stock_info.get('exchange', 'N/A'),
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        if _diag:
            _diag.markdown("**Tool return value (sent back to context):**")
            _diag.code(json.dumps(result, indent=2, default=str), language="json")

        return result

    except Exception as e:
        result = {"error": f"Could not retrieve stock information for '{symbol}'. {str(e)}"}
        if _diag:
            _diag.markdown("**Tool error:**")
            _diag.code(json.dumps(result, indent=2), language="json")
        return result


def get_company_info(symbol: str, _diag=None) -> dict:
    """Get detailed information about a company by its stock ticker symbol."""
    if _diag:
        _diag.markdown(diag_section("🔧 TOOL CALLED: get_company_info", "#1a5276"), unsafe_allow_html=True)
        _diag.markdown("**Inputs received by tool:**")
        _diag.code(json.dumps({"symbol": symbol}, indent=2), language="json")

    try:
        if _diag:
            _diag.markdown("**API call being made:**")
            _diag.code(f"yfinance.Ticker('{symbol}').info", language="python")

        stock = yf.Ticker(symbol)
        info = stock.info

        result = {
            'symbol': symbol,
            'name': info.get('shortName', 'N/A'),
            'long_name': info.get('longName', 'N/A'),
            'sector': info.get('sector', 'N/A'),
            'industry': info.get('industry', 'N/A'),
            'employees': info.get('fullTimeEmployees', 'N/A'),
            'website': info.get('website', 'N/A'),
            'business_summary': info.get('longBusinessSummary', 'N/A'),
            'country': info.get('country', 'N/A'),
            'city': info.get('city', 'N/A')
        }

        if _diag:
            _diag.markdown("**Tool return value (sent back to context):**")
            _diag.code(json.dumps(result, indent=2, default=str), language="json")

        return result

    except Exception as e:
        result = {"error": f"Could not retrieve company information for '{symbol}'. {str(e)}"}
        if _diag:
            _diag.markdown("**Tool error:**")
            _diag.code(json.dumps(result, indent=2), language="json")
        return result


def format_function_result(function_name: str, result: dict) -> str:
    """Format the result of a function call for the model."""
    if "error" in result:
        return result["error"]

    if function_name == "get_weather":
        weather_summary = f"Weather forecast for {result['location']}:\n\n"
        for forecast in result['forecast']:
            weather_summary += f"- {forecast['time']}: {forecast['description'].capitalize()}, {forecast['temp']}°C, Rain: {forecast['rain_probability']}%\n"
        return weather_summary

    elif function_name == "get_stock_price":
        change_symbol = "+" if result['change'] >= 0 else ""
        return (f"Stock: {result['company_name']} ({result['symbol']})\n"
                f"Price: {result['latest_price']:.2f} {result['currency']}\n"
                f"Change: {change_symbol}{result['change']:.2f} ({change_symbol}{result['change_percent']:.2f}%)\n"
                f"Previous Close: {result['previous_close']:.2f}\n"
                f"Volume: {result['volume']}\n"
                f"As of: {result['timestamp']}")

    elif function_name == "get_company_info":
        return (f"Company: {result['name']} ({result['symbol']})\n"
                f"Full Name: {result['long_name']}\n"
                f"Sector: {result['sector']}\n"
                f"Industry: {result['industry']}\n"
                f"Employees: {result['employees']}\n"
                f"Country: {result['country']}\n\n"
                f"Summary: {result['business_summary'][:500]}...")

    return json.dumps(result, indent=2)


# Bedrock tool definitions
TOOLS = [
    {
        "toolSpec": {
            "name": "get_weather",
            "description": "Get weather forecast for a location",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "City or location name"
                        },
                        "days": {
                            "type": "integer",
                            "description": "Number of days to forecast (default 1)"
                        }
                    },
                    "required": ["location"]
                }
            }
        }
    },
    {
        "toolSpec": {
            "name": "get_stock_price",
            "description": "Get the latest stock price and information for a given ticker symbol",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "symbol": {
                            "type": "string",
                            "description": "Stock ticker symbol (e.g., 'AAPL' for Apple, 'GOOGL' for Google)"
                        }
                    },
                    "required": ["symbol"]
                }
            }
        }
    },
    {
        "toolSpec": {
            "name": "get_company_info",
            "description": "Get detailed information about a company by its stock ticker symbol",
            "inputSchema": {
                "json": {
                    "type": "object",
                    "properties": {
                        "symbol": {
                            "type": "string",
                            "description": "Stock ticker symbol (e.g., 'AAPL' for Apple)"
                        }
                    },
                    "required": ["symbol"]
                }
            }
        }
    }
]

SYSTEM_PROMPT = """
You are a helpful assistant that can provide information about weather and stock prices.

You have access to several tools:
- get_weather: Get weather forecast for a location
- get_stock_price: Get latest stock price information for a ticker symbol
- get_company_info: Get detailed information about a company

When handling requests:

For weather queries:
1. Identify if a location is mentioned. If not, ask for it.
2. Use the get_weather function to retrieve weather data.
3. Provide a helpful response based on the forecast.

For stock/company queries:
1. Identify the stock ticker symbol. Common examples: AAPL (Apple), GOOGL (Google), MSFT (Microsoft), TSLA (Tesla)
2. Use the appropriate function to get stock prices or company information.
3. Provide a concise summary of the important financial information.

Always respond in a helpful, informative manner.
"""


def generate_response(input_text, diag):
    bedrock_rt = boto3.client("bedrock-runtime", region_name=AWS_REGION)

    messages = [{"role": "user", "content": [{"text": input_text}]}]

    # ── CALL 1 ─────────────────────────────────────────────────────────────────
    diag.markdown(diag_section("📤 STEP 1 — Sending user message to LLM", "#145a32"), unsafe_allow_html=True)
    diag.markdown("**Messages sent to Bedrock (converse call #1):**")
    diag.code(json.dumps(messages, indent=2), language="json")

    response = bedrock_rt.converse(
        modelId=MODEL_ID,
        system=[{"text": SYSTEM_PROMPT}],
        messages=messages,
        toolConfig={"tools": TOOLS}
    )

    diag.markdown(diag_section("📥 STEP 2 — LLM response (call #1)", "#6e2f1a"), unsafe_allow_html=True)
    diag.markdown(f"**Stop reason:** `{response['stopReason']}`")
    diag.markdown("**Full LLM response content:**")
    diag.code(json.dumps(response["output"]["message"]["content"], indent=2), language="json")

    # ── TOOL USE ───────────────────────────────────────────────────────────────
    if response["stopReason"] == "tool_use":
        assistant_content = response["output"]["message"]["content"]

        tool_use_block = next(b for b in assistant_content if "toolUse" in b)
        function_name = tool_use_block["toolUse"]["name"]
        function_args = tool_use_block["toolUse"]["input"]
        tool_use_id = tool_use_block["toolUse"]["toolUseId"]

        diag.markdown(diag_section("🤖 STEP 3 — LLM requested a tool call", "#4a235a"), unsafe_allow_html=True)
        diag.markdown(f"**Tool name:** `{function_name}`")
        diag.markdown("**Arguments chosen by LLM:**")
        diag.code(json.dumps(function_args, indent=2), language="json")
        diag.markdown(f"**Tool use ID:** `{tool_use_id}`")

        # Convert any float args to int if needed (e.g., days parameter)
        if 'days' in function_args:
            function_args['days'] = int(function_args['days'])

        # Execute the tool, passing the diag container for live output
        try:
            result = globals()[function_name](**function_args, _diag=diag)
        except KeyError:
            result = {"error": f"Unknown function: {function_name}"}

        formatted_result = format_function_result(function_name, result)

        # ── CONTEXT UPDATE ────────────────────────────────────────────────────
        diag.markdown(diag_section("➕ STEP 4 — App adds tool result to context & resends to LLM", "#0b3d61"), unsafe_allow_html=True)

        messages.append({"role": "assistant", "content": assistant_content})
        messages.append({
            "role": "user",
            "content": [
                {
                    "toolResult": {
                        "toolUseId": tool_use_id,
                        "content": [{"text": formatted_result}]
                    }
                }
            ]
        })

        diag.markdown("**Updated messages array now being sent to LLM (converse call #2):**")
        diag.code(json.dumps(messages, indent=2, default=str), language="json")

        # ── CALL 2 ────────────────────────────────────────────────────────────
        response = bedrock_rt.converse(
            modelId=MODEL_ID,
            system=[{"text": SYSTEM_PROMPT}],
            messages=messages,
            toolConfig={"tools": TOOLS}
        )

        diag.markdown(diag_section("📥 STEP 5 — Final LLM response (call #2)", "#6e2f1a"), unsafe_allow_html=True)
        diag.markdown(f"**Stop reason:** `{response['stopReason']}`")
        final_text = response["output"]["message"]["content"][0]["text"]
        diag.markdown("**Final LLM text:**")
        diag.code(final_text, language="text")

        return final_text
    else:
        final_text = response["output"]["message"]["content"][0]["text"]
        diag.markdown(diag_section("📥 STEP 2 — LLM answered directly (no tool use)", "#145a32"), unsafe_allow_html=True)
        diag.markdown("**Final LLM text:**")
        diag.code(final_text, language="text")
        return final_text


# ─── Chat UI ──────────────────────────────────────────────────────────────────

if prompt := st.chat_input("Ask me about weather or stocks..."):
    st.session_state.messages.append({"role": "user", "content": prompt})

    with st.chat_message("user"):
        st.markdown(prompt)

    # 1. Reserve the assistant answer slot
    with st.chat_message("assistant"):
        answer_slot = st.empty()

    # 2. Diagnostics section sits below the answer — declared here so it renders after
    st.markdown("---")
    with st.expander("🔍 Agent Flow Diagnostics", expanded=False):
        st.markdown(
            "<small>Step-by-step trace of the full agent loop — LLM calls, tool invocations, and context updates.</small>",
            unsafe_allow_html=True,
        )
        diag = st.container()

    # 3. Run the agent — diagnostics write directly into the expander container above
    with st.spinner("Thinking..."):
        response = generate_response(prompt, diag)

    # 4. Fill the answer slot now that we have the response
    answer_slot.markdown(response)

    st.session_state.messages.append({"role": "assistant", "content": response})

# Sidebar with app information
with st.sidebar:
    st.header("Multipurpose Assistant")
    st.markdown(f"""
    This assistant uses **Amazon Nova** and can help with:

    **Weather Information**
    - Current weather conditions
    - Weather forecasts
    - Rain predictions

    **Stock Market Data**
    - Latest stock prices
    - Price changes and trends
    - Company information

    **Region:** {AWS_REGION}
    **Model:** {MODEL_ID}
    """)

    st.subheader("Sample Questions")
    st.markdown("""
    **Weather Examples:**
    - "What's the weather in Tokyo?"
    - "Will it rain in New York tomorrow?"

    **Stock Examples:**
    - "What's the price of Apple stock?"
    - "How is TSLA performing today?"
    - "Tell me about Microsoft"
    """)

    st.markdown("---")
    st.markdown("""
    **Requirements:**
    ```
    pip install streamlit python-dotenv requests yfinance boto3
    ```
    """)
