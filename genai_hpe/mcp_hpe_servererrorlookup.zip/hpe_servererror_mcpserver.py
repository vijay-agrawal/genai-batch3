"""
HPE Server Error Lookup MCP Server using FastMCP
A minimal demo showing how to create and use MCP tools in VS Code
"""

from fastmcp import FastMCP
import re
from datetime import datetime

# Initialize FastMCP server
mcp = FastMCP("HPE Server Error Lookup")

def log_message(msg):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] {msg}\n")

# Mock iLO/IML event code database for demo purposes
ERROR_CODE_DATABASE = {
    "fan failure": "IML-1004 - Fan redundancy lost: Fan #3 failure detected",
    "fan redundancy lost": "IML-1004 - Fan redundancy lost: Fan #3 failure detected",
    "psu failure": "IML-1102 - Power supply #2 failure, redundancy lost",
    "power supply failure": "IML-1102 - Power supply #2 failure, redundancy lost",
    "overheating": "IML-1210 - System over-temperature condition detected",
    "over temperature": "IML-1210 - System over-temperature condition detected",
    "cpu thermal trip": "IML-1215 - Processor thermal trip, CPU throttled",
    "memory ecc error": "IML-1301 - Correctable memory ECC error, DIMM slot 4",
    "ecc error": "IML-1301 - Correctable memory ECC error, DIMM slot 4",
    "uncorrectable memory error": "IML-1305 - Uncorrectable memory error, system halted",
    "raid degraded": "IML-1402 - Logical drive degraded, physical drive failure",
    "disk predictive failure": "IML-1410 - Physical drive predictive failure, replace drive",
    "drive failure": "IML-1412 - Physical drive failure detected in bay 3",
    "network link down": "IML-1501 - NIC port 1 link down",
    "nic failure": "IML-1502 - Embedded NIC failure detected",
    "post error": "IML-1601 - POST error, boot device not found",
    "boot device not found": "IML-1601 - POST error, boot device not found",
    "bios corruption": "IML-1610 - BIOS/UEFI checksum failure, ROM corruption detected",
    "battery failure": "IML-1705 - Smart Storage Battery failure",
    "ilo self test failure": "IML-1801 - iLO self-test failure detected",
    "high cpu temperature": "IML-1215 - Processor thermal trip, CPU throttled",
    "voltage regulator fault": "IML-1902 - Voltage regulator module fault detected",
    "asr": "IML-2001 - Automatic Server Recovery (ASR) triggered, system reset",
    "watchdog reset": "IML-2001 - Automatic Server Recovery (ASR) triggered, system reset",
}


@mcp.tool()
def lookup_error_code(description: str) -> str:
    """
    Look up an HPE server (iLO/IML) event code based on a hardware error description.

    Args:
        description: Description of the hardware fault (e.g., "fan failure", "raid degraded")

    Returns:
        Event code and description, or a message if not found
    """
    log_message(f"TOOL CALLED: lookup_error_code('{description}')")

    # Convert to lowercase for case-insensitive matching
    description_lower = description.lower().strip()

    # Direct match
    if description_lower in ERROR_CODE_DATABASE:
        result = ERROR_CODE_DATABASE[description_lower]
        log_message(f"DIRECT MATCH FOUND: {result}")
        return result

    # Partial match using regex
    for key, value in ERROR_CODE_DATABASE.items():
        if re.search(r'\b' + re.escape(key) + r'\b', description_lower):
            log_message(f"PARTIAL MATCH FOUND (key: {key}): {value}")
            return value

    # If no match found, return available options
    available = ", ".join(sorted(ERROR_CODE_DATABASE.keys()))
    log_message(f"NO MATCH FOUND for '{description}'")
    return f"No error code found for '{description}'. Available conditions: {available}"


@mcp.tool()
def list_available_errors() -> str:
    """
    List all available hardware fault conditions in the database.

    Returns:
        Comma-separated list of available fault conditions
    """
    log_message(f"TOOL CALLED: list_available_errors()")
    conditions = sorted(ERROR_CODE_DATABASE.keys())
    result = f"Available conditions ({len(conditions)}): " + ", ".join(conditions)
    log_message(f"RETURNING {len(conditions)} conditions")
    return result


if __name__ == "__main__":
    log_message("=" * 50)
    log_message("MCP SERVER STARTING")
    log_message("=" * 50)
    # Run the MCP server
    mcp.run()
