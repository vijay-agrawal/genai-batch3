"""
Simple test client for the HPE Server Error Lookup MCP Server.
Runs the server as a subprocess and calls its tools via the MCP protocol.
"""

import asyncio
from fastmcp import Client


async def main():
    async with Client("hpe_servererror_mcpserver.py") as client:
        # List available tools
        tools = await client.list_tools()
        print("Available tools:", [t.name for t in tools])
        print()

        # Test list_available_errors
        result = await client.call_tool("list_available_errors", {})
        print("list_available_errors:")
        print(result.content[0].text)
        print()

        # Test lookup_error_code with various inputs
        test_cases = [
            "fan failure",
            "raid degraded",
            "overheating",
            "boot device not found",
            "unknown condition",
        ]

        for condition in test_cases:
            result = await client.call_tool("lookup_error_code", {"description": condition})
            print(f"lookup_error_code('{condition}'):")
            print(" ", result.content[0].text)
        print()


if __name__ == "__main__":
    asyncio.run(main())
