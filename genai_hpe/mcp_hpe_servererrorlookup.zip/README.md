# HPE Server Error Lookup MCP Server - Setup Guide

## Prerequisites
- Python 3.10 or higher
- VS Code latest version (1.126 or above)
- pip (Python package manager)

## Step 1: Install Dependencies

```bash
# Create a virtual environment (recommended)
python -m venv mcp-env
source mcp-env/bin/activate  # On Windows: mcp-env\Scripts\activate

# Install FastMCP
pip install fastmcp
```

## Step 2: Test the Server Locally

```bash
# Run the server to verify it works
python hpe_servererror_mcpserver.py
```

You should see output indicating the server is running.

## Step 3: Configure VS Code MCP Settings

**Important**: Check VS Code Version you have (Help->About)
You will need VS Code 1.126 or above for proper MCP support in VS Code
If your version is older, download latest VS Code and install.

1. Open VS Code
2. Press `Cmd+Shift+P` (Mac) or `Ctrl+Shift+P` (Windows/Linux)
3. Type "Preferences: Open User Settings (JSON)"
4. Locate that file in the filesystem (Usually in C:\Users\<username>\AppData\Roaming\Code\User)
5. sometimes AppData is hidden - in windows Explorer, you can use the File menu "show hidden files" to make it visible
6. Create a mcp.json at that location with following content (*Update with proper path from your machine*):
```json
{
	"servers": {
		"hpe-server-error-lookup": {
			"type": "stdio",
			"command": "C:\\Users\\vijay\\code\\genaitraining\\venv\\Scripts\\python.exe",
			"args": [
				"C:\\Users\\vijay\\code\\genaitraining\\mcpdemo\\mcp_hpe_servererrorlookup\\hpe_servererror_mcpserver.py"
			]
		}
	},
	"inputs": []
}
```
**Important**: Replace `/absolute/path/to/hpe_servererror_mcpserver.py` with the actual full path to your file.

**Caveat - file saved as `mcp.json.txt`**: If you create this file using Windows File Explorer (right-click → New → Text Document), Windows will save it as `mcp.json.txt`, not `mcp.json`. By default, Windows Explorer hides known file extensions, so it will display as just `mcp.json` even though the real filename is wrong - and VS Code will silently ignore it since it isn't looking for a `.txt` file.

To do this correctly:
- First make file extensions visible: in Explorer, go to the "View" menu → "Show" → check "File name extensions" (or in older Explorer: View tab → check "File name extensions").
- Now when you create or rename the file, you'll see the true extension. Make sure it is named exactly `mcp.json` (not `mcp.json.txt`).
- Alternatively, create the file from a terminal (e.g. `notepad mcp.json` or using VS Code's own "New File" command inside the folder), which avoids Explorer's extension guessing entirely.
- If you're not sure, open a terminal in that folder and run `dir` - it will show the real filename including any hidden extension.

7. Install the "Copilot MCP" extension

## Step 4: Restart VS Code

Close and reopen VS Code to load the MCP server.

## Step 7: Verify the Tools are Available

### In VS Code:
1. Open AI Chat panel (available in chat icon near the top center besides the search box)
2. Start a new chat
3. Choose "Agent" in the first dropdown and "GPT 4.1" in the second dropdown in the AI chat window
4. Try these example prompts in your AI assistant:

```
"Use the lookup_error_code tool to find the event code for a fan failure"

"Show me all available fault conditions using list_available_errors"

"Look up the event code for a RAID degraded condition"
```
**Important**: Make sure it is invoking the tool and not just doing file search and presenting search results! The messages you see should clearly tell you it is invoking the tool

**Expected Behavior**:
1. The AI (the LLM you selected from the dropdown) will automatically map the user query to the `lookup_error_code` tool
2. It will tell VS code to invoke the tool
3. VS Code will run the tool and return the results to the LLM
4. LLM will print the formatted response, for example:
   - Fan failure: IML-1004 - Fan redundancy lost: Fan #3 failure detected

## Troubleshooting


### Server not appearing in VS Code:
- Verify the path in settings.json is absolute and correct
- Restart VS Code after configuration changes
- In "Extensions", make sure the MCP server is showing up in the "MCP Servers - Installed" pane
- open mcp.json (in same folder as settings.json, typically "C:\Users\<username>\AppData\Roaming\Code\User\mcp.json") and ensure mcp server definition is correct

### "Module not found" error:
- Make sure you are using the full path to Python in the virtual environment:
  ```json
  "command": "/path/to/mcp-env/bin/python"
  ```

### Tools not visible:
- Check VS Code Developer Console (Help → Toggle Developer Tools) for errors
- Verify FastMCP is installed: `pip show fastmcp`
- Check MCP server logs in the extension output panel

## How It Works

1. **FastMCP** creates an MCP-compliant server from Python functions
2. The `@mcp.tool()` decorator exposes functions as MCP tools
3. VS Code extensions (such as Copilot MCP) connect to the server via stdio
4. The AI can see tool descriptions and invoke them automatically
5. Results are returned to the AI and incorporated into responses

## Extending the Demo

Add more tools by decorating functions:

```python
@mcp.tool()
def search_error_by_code(code: str) -> str:
    """Search for a fault description by IML/iLO event code"""
    # Your implementation here
    pass
```

The tool will automatically appear in VS Code
