import os
import boto3
from langchain_aws import BedrockEmbeddings, ChatBedrock
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
import warnings
warnings.filterwarnings("ignore")

from dotenv import load_dotenv

load_dotenv()

CHROMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chroma_db_new2")

def load_embeddings_chroma(persist_directory=CHROMA_PATH):
    from langchain_chroma import Chroma

    # Instantiate the same embedding model used during creation
    print('Instantiating the embedding model')

    bedrock_client = boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )

    embeddings = BedrockEmbeddings(
        client=bedrock_client,
        model_id=os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0")
    )

    print('Loading Chroma vector database, passing the embedding model to be used to it...')

    # Load the Chroma vector store from the specified directory, using the provided embedding function
    vector_store = Chroma(persist_directory=persist_directory, embedding_function=embeddings) 

    return vector_store  # Return the loaded vector store

def ask_and_get_answer(vector_store, q, k=3):
    """
    Modern approach using LCEL (LangChain Expression Language)
    This works without needing langchain.chains module
    """
    
    # Initialize Bedrock LLM
    bedrock_client = boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )

    llm = ChatBedrock(
        client=bedrock_client,
        model_id=os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0"),
        model_kwargs={"temperature": 0}
    )
    
    print('Fetching the retriever for the vector DB')
    retriever = vector_store.as_retriever(search_type='similarity', search_kwargs={'k': k})

    # Create a prompt template
    template = """You are an assistant for question-answering tasks. 
Use the following pieces of retrieved context to answer the question. 
If you don't know the answer, say that you don't know. 
Use three sentences maximum and keep the answer concise.

Context: {context}

Question: {question}

Answer:"""
    
    prompt = ChatPromptTemplate.from_template(template)

    print('Creating the RAG chain using LCEL')
    
    # Helper function to format documents
    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)
    
    # Create the RAG chain using LCEL (LangChain Expression Language)
    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    
    print('Executing the chain with the retriever and the LLM')
    
    # Invoke the chain
    answer = rag_chain.invoke(q)
    
    # Get source documents separately for display
    source_docs = retriever.invoke(q)
    
    # Return in same format as before
    return {
        'answer': answer,
        'context': source_docs,
        'input': q
    }

## MAIN PROCESSING ##

# Load the chroma vector store using the same embedding model as the one used during indexing
vector_store = load_embeddings_chroma()

print(f"Total chunks in vector DB: {vector_store._collection.count()}")

# Seed question
q = "What are Pankaj's skills?"

# Sample questions for the interactive loop (based on server and SAN logs):
#
# --- General Troubleshooting ---
# - Which servers experienced critical hardware failures and what were the root causes?
# - What LUN issues were reported and how were they resolved?
# - Which storage pools are running out of capacity and what action was taken?
# - What happened to PROLIANT-DL380-NODE01 on March 20 2026?
# - Which network switches reported errors and which servers were affected?
# - What is the status of the replication link between the primary and DR site 3PAR arrays?
# - Which SAN fabric ports failed and how did multipath failover respond?
# - What RAID arrays went into degraded state and how long did the rebuild take?
#
# --- Time-Window Troubleshooting ---
# - What errors occurred on PROLIANT-DL380-NODE01 between March 18 and March 19 2026?
# - Summarise all critical events across all servers on March 20 2026.
# - What storage events happened between March 15 and March 16 2026?
# - Were there any warnings or errors logged on March 17 2026 across any server?
# - What sequence of events led to the MSA 2060 controller overtemperature on March 20 2026?
#
# --- CPU-Related Messages ---
# - What CPU errors or warnings were logged across all servers?
# - Which server had a CPU thermal trip and what action was taken to fix it?
# - What happened to CPU1 on PROLIANT-DL380-NODE01 at 03:22 on March 18 2026?
# - Which server was shut down due to a CPU overtemperature event and when did it come back online?
# - Were any ECC memory errors associated with CPU activity reported? Which DIMM slots were affected?
#
# --- NIC / Network Troubleshooting ---
# - NIC1 Mellanox CX-7 25GbE on PROLIANT-DL380-NODE01 is connected to which switch and port?
# - What caused the NIC1 link-down event on PROLIANT-DL380-NODE01 and how was it resolved?
# - Which NIC reported TX queue overflow and how many packets were dropped?
# - What network adapter issues affected PROLIANT-DL360-NODE02 and which switch port was involved?
answer = ask_and_get_answer(vector_store, q)

print("\n--- Answer ---")
print(answer['answer'])

print("\n--- Source Documents ---")
print(f"Total chunks retrieved: {len(answer['context'])}")
for i, doc in enumerate(answer['context'], 1):
    print(f"\n--- Chunk {i} ---")
    print(doc.page_content)
    if doc.metadata:
        print(f"[Metadata: {doc.metadata}]")

while True:
    q = input("\nEnter your question (or 'q' to exit): ").strip()
    if q.lower() == 'q':
        print("Exiting.")
        break
    if not q:
        continue

    answer = ask_and_get_answer(vector_store, q)

    print("\n--- Answer ---")
    print(answer['answer'])

    print("\n--- Source Documents ---")
    print(f"Total chunks retrieved: {len(answer['context'])}")
    for i, doc in enumerate(answer['context'], 1):
        print(f"\n--- Chunk {i} ---")
        print(doc.page_content)
        if doc.metadata:
            print(f"[Metadata: {doc.metadata}]")