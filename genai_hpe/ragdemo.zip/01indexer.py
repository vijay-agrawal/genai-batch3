import os
import shutil
import boto3
from langchain_aws import BedrockEmbeddings
import warnings
from dotenv import load_dotenv
import glob

load_dotenv()
warnings.filterwarnings("ignore")

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CHROMA_PATH = os.path.join(SCRIPT_DIR, "chroma_db_new2")

# HPE-specific docs in the data/ folder:
#   hpe_proliant_gen11_firmware_manual.pdf – UEFI boot flow, CXL 2.0, SRoT, OCP NIC firmware, RAG limitations
#   hpe_proliant_server_logs.txt           – ProLiant DL380/DL360/Synergy/ML350 server event logs
#   hpe_san_storage_logs.txt               – HPE 3PAR StoreServ & MSA 2060 SAN/storage event logs
# NOTE: hpe_ilo_bmc_log_reference.pdf is excluded from indexing

def load_document(file):
    name, extension = os.path.splitext(file)

    if extension == '.pdf':
        from langchain_community.document_loaders import PyPDFLoader
        print(f'Loading {file}')
        loader = PyPDFLoader(file)
    elif extension == '.docx':
        from langchain_community.document_loaders import Docx2txtLoader
        print(f'Loading {file}')
        loader = Docx2txtLoader(file)
    elif extension == '.txt':
        from langchain_community.document_loaders import TextLoader
        loader = TextLoader(file)
    else:
        print('Document format is not supported!')
        return None

    # Each Document returned by the loader automatically has metadata populated,
    # including {"source": <file_path>, "page": <page_number>} for PDFs.
    # This metadata is set by LangChain loaders — no extra code needed.
    data = loader.load()
    return data

def chunk_data(data, chunk_size=256):
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, 
        chunk_overlap=20  # Added some overlap
    )
    # split_documents preserves and copies the parent document's metadata
    # (including "source") into every chunk it produces.
    chunks = text_splitter.split_documents(data)
    print(f"Created {len(chunks)} chunks")
    return chunks 

def create_embeddings_chroma(chunks, persist_directory=CHROMA_PATH):
    from langchain_community.vectorstores import Chroma

    bedrock_client = boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )

    embeddings = BedrockEmbeddings(
        client=bedrock_client,
        model_id=os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0")
    )

    try:
        # from_documents stores each chunk's text AND its metadata dict in ChromaDB,
        # so "source" (and "page") are persisted alongside every vector.
        Chroma.from_documents(chunks, embeddings, persist_directory=persist_directory)
        print("Successfully created Chroma vector store")
    except Exception as e:
        print(f"Error creating embeddings: {e}")
        raise

#### MAIN PROCESSING STARTS HERE

# Look for 'data' folder in the same directory as this script, then one level above
_candidate_same = os.path.join(SCRIPT_DIR, 'data')
_candidate_parent = os.path.join(os.path.dirname(SCRIPT_DIR), 'data')

if os.path.isdir(_candidate_same):
    data_dir = _candidate_same
elif os.path.isdir(_candidate_parent):
    data_dir = _candidate_parent
else:
    print(f"Error: 'data' folder not found in '{SCRIPT_DIR}' or '{os.path.dirname(SCRIPT_DIR)}'")
    exit(1)

# Delete existing vector DB upfront so we always start with a clean index
if os.path.exists(CHROMA_PATH):
    shutil.rmtree(CHROMA_PATH)
    print(f'Deleted existing vector database at {CHROMA_PATH}')
else:
    print(f'No existing vector database found at {CHROMA_PATH}')

EXCLUDED_FILES = {'hpe_ilo_bmc_log_reference.pdf'}

print(f'Looking for files in {data_dir}')
pdf_files = [f for f in glob.glob(os.path.join(data_dir, '*.pdf'))
             if os.path.basename(f) not in EXCLUDED_FILES]
txt_files = glob.glob(os.path.join(data_dir, '*.txt'))
all_files = pdf_files + txt_files

print(f'Found {len(pdf_files)} PDF files and {len(txt_files)} TXT files to process (excluded: {EXCLUDED_FILES}).')

# Load all documents - flatten the structure
all_documents = []
for file in all_files:
    try:
        print(f'Processing file: {file}')
        docs = load_document(file)
        if docs:
            all_documents.extend(docs)
            print(f"Loaded: {os.path.basename(file)}")
    except Exception as e:
        print(f"Error loading {file}: {e}")

if not all_documents:
    print("No documents loaded successfully!")
    exit(1)

print(f'Loaded {len(all_documents)} document pages...')

# Split the documents into chunks
print('Splitting documents into chunks')
# Use larger chunks for technical firmware docs to preserve multi-step procedure context
chunks = chunk_data(all_documents, chunk_size=512)

if chunks:
    create_embeddings_chroma(chunks)
    print('Chroma vector db created successfully')
else:
    print('No chunks created - check your documents')