import os
import boto3
import streamlit as st
from langchain_aws import BedrockEmbeddings, ChatBedrock
from langchain_chroma import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
import warnings
warnings.filterwarnings("ignore")

from dotenv import load_dotenv
load_dotenv()

CHROMA_PATH = os.path.join(os.path.dirname(__file__), "chroma_db_new2")

# ─────────────────────────────────────────────────────────────────────────────
# Pre-seeded questions — grouped into three categories to demonstrate what
# RAG handles well vs. where it hallucinates or simply cannot answer.
# ─────────────────────────────────────────────────────────────────────────────
PRESET_QUESTIONS = {
    "✅ HPE Firmware Manual": [
        "How does HPE Silicon Root of Trust (SRoT) protect the UEFI boot chain?",
        "What are the steps to update NIC firmware in a dark-site / air-gapped HPE environment?",
        "What CXL memory expander limitations exist on HPE ProLiant Gen11?",
        "What is the difference between IML, IEL, and AHS logs in iLO 6?",
    ],
    "✅ Server Logs — General Troubleshooting": [
        "What does IML event code IML-004 mean and how do I fix it?",
        "Which servers experienced critical hardware failures and what were the root causes?",
        "What LUN issues were reported and how were they resolved?",
        "Which storage pools are running out of capacity and what action was taken?",
        "Which network switches reported errors and which servers were affected?",
    ],
    "✅ Server Logs — Time-Window Troubleshooting": [
        "What errors occurred on PROLIANT-DL380-NODE01 between March 18 and March 19 2026?",
        "Summarise all critical events across all servers on March 20 2026.",
        "What storage events happened between March 15 and March 16 2026?",
        "Were there any warnings or errors logged on March 17 2026 across any server?",
        "What sequence of events led to the MSA 2060 controller overtemperature on March 20 2026?",
    ],
    "✅ Server Logs — CPU Troubleshooting": [
        "What CPU errors or warnings were logged across all servers?",
        "Which server had a CPU thermal trip and what action was taken to fix it?",
        "What happened to CPU1 on PROLIANT-DL380-NODE01 at 03:22 on March 18 2026?",
        "Which server was shut down due to a CPU overtemperature event and when did it come back online?",
        "Were any ECC memory errors associated with CPU activity reported? Which DIMM slots were affected?",
    ],
    "✅ Server Logs — NIC & Network Troubleshooting": [
        "NIC1 Mellanox CX-7 25GbE on PROLIANT-DL380-NODE01 is connected to which switch and port?",
        "What caused the NIC1 link-down event on PROLIANT-DL380-NODE01 and how was it resolved?",
        "Which NIC reported TX queue overflow and how many packets were dropped?",
        "What network adapter issues affected PROLIANT-DL360-NODE02 and which switch port was involved?",
    ],
    "✅ Resumes & People": [
        "What technical skills does Pankaj have?",
        "Summarise the work experience of all candidates in the database.",
        "Which candidates have experience with Python or machine learning?",
        "Who has the most years of experience overall?",
        "List the educational qualifications mentioned across all resumes.",
    ],
    "⚠️ RAG Limitations — Hallucination / Out-of-scope": [
        "Show me people with 3 or more years of experience in firmware development.",
        "Suggest a suitable HR Talent Specialist from the resumes.",
        "Who is the best candidate for a senior iLO firmware engineer role?",
    ],
}

# ─────────────────────────────────────────────────────────────────────────────

st.set_page_config(page_title="HPE RAG Demo", page_icon="🔍", layout="wide")
st.title("HPE RAG Question Answering Demo")
st.caption("Powered by Amazon Bedrock + ChromaDB · Demonstrates RAG strengths and limitations")

# --- Session state init ---
if "messages" not in st.session_state:
    st.session_state.messages = []
if "pending_question" not in st.session_state:
    st.session_state.pending_question = None

# --- Sidebar config ---
with st.sidebar:
    st.header("Settings")
    k = st.slider("Number of retrieved chunks (k)", min_value=1, max_value=10, value=3)
    model_id = st.selectbox(
        "Bedrock model",
        ["amazon.nova-micro-v1:0", "amazon.nova-lite-v1:0", "amazon.nova-pro-v1:0",
         "anthropic.claude-3-haiku-20240307-v1:0"],
        index=0,
    )
    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.rerun()

    st.divider()
    st.subheader("Vector DB")
    if st.button("Load / Reload vector store"):
        st.cache_resource.clear()
        st.rerun()


# --- Load vector store (cached) ---
@st.cache_resource(show_spinner="Loading vector store...")
def get_vector_store(chroma_path):
    bedrock_client = boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )
    embeddings = BedrockEmbeddings(
        client=bedrock_client,
        model_id=os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0"),
    )
    return Chroma(persist_directory=chroma_path, embedding_function=embeddings)

try:
    vector_store = get_vector_store(CHROMA_PATH)
    with st.sidebar:
        st.success("Vector store loaded")
        count = vector_store._collection.count()
        st.metric("Chunks in DB", count)
except Exception as e:
    st.error(f"Failed to load vector store: {e}")
    st.stop()


# ─────────────────────────────────────────────────────────────────────────────
# Pre-seeded question panel
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# RAG helpers
# ─────────────────────────────────────────────────────────────────────────────
def build_prompt_text(context_text: str, question: str) -> str:
    return f"""You are an assistant for question-answering tasks.
Use the following pieces of retrieved context to answer the question.
If you don't know the answer, say that you don't know.
Use three sentences maximum and keep the answer concise.

Context: {context_text}

Question: {question}

Answer:"""


def run_rag(question: str, k: int, model_id: str):
    bedrock_client = boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )
    llm = ChatBedrock(
        client=bedrock_client,
        model_id=model_id,
        model_kwargs={"temperature": 0},
    )
    retriever = vector_store.as_retriever(search_type="similarity", search_kwargs={"k": k})
    source_docs = retriever.invoke(question)
    context_text = "\n\n".join(doc.page_content for doc in source_docs)
    prompt_text = build_prompt_text(context_text, question)

    template = """You are an assistant for question-answering tasks.
Use the following pieces of retrieved context to answer the question.
If you don't know the answer, say that you don't know.
Use three sentences maximum and keep the answer concise.

Context: {context}

Question: {question}

Answer:"""
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm | StrOutputParser()
    answer = chain.invoke({"context": context_text, "question": question})
    return answer, source_docs, prompt_text


# ─────────────────────────────────────────────────────────────────────────────
# Helper: render a single assistant message (answer + expanders)
# ─────────────────────────────────────────────────────────────────────────────
def render_assistant_msg(msg: dict):
    st.markdown(msg["content"])

    with st.expander("📄 Context retrieved from vector DB", expanded=False):
        for i, chunk in enumerate(msg["chunks"], 1):
            source_name = os.path.basename(chunk.get("source", "unknown"))
            page = chunk.get("page", "?")
            st.markdown(f"**Chunk {i}** — `{source_name}` · page {page}")
            st.text(chunk["content"])
            st.divider()

    with st.expander("📨 Full prompt sent to LLM", expanded=False):
        st.code(msg["prompt_sent"], language="markdown")


# ─────────────────────────────────────────────────────────────────────────────
# Render conversation history
# ─────────────────────────────────────────────────────────────────────────────
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        if msg["role"] == "assistant":
            render_assistant_msg(msg)
        else:
            st.markdown(msg["content"])


# ─────────────────────────────────────────────────────────────────────────────
# Chat input (non-sticky, so questions can appear below)
# ─────────────────────────────────────────────────────────────────────────────
with st.form(key="chat_form", clear_on_submit=True):
    col_input, col_btn = st.columns([9, 1])
    with col_input:
        typed = st.text_input(
            label="question",
            placeholder="Ask your own question about the documents...",
            label_visibility="collapsed",
        )
    with col_btn:
        submitted = st.form_submit_button("Send", use_container_width=True)

# ─────────────────────────────────────────────────────────────────────────────
# Pre-seeded question panel (below the input box)
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
/* Question buttons: plain left-aligned text, no box */
div[data-testid="stExpander"] button[kind="secondary"] {
    background: none !important;
    border: none !important;
    box-shadow: none !important;
    text-align: left !important;
    justify-content: flex-start !important;
    padding: 0px 0px 0px 4px !important;
    margin: -6px 0px !important;
    min-height: 0px !important;
    height: auto !important;
    line-height: 1.3 !important;
    color: #1a73e8 !important;
    font-weight: normal !important;
    width: auto !important;
}
div[data-testid="stExpander"] button[kind="secondary"]:hover {
    text-decoration: underline !important;
    background: none !important;
    color: #0d47a1 !important;
}
</style>
""", unsafe_allow_html=True)

with st.expander("💡 Pre-seeded questions — click to ask", expanded=True):
    st.caption(
        "Green = RAG answers well. Red = hallucination / out-of-scope (for classroom discussion)."
    )
    for category, questions in PRESET_QUESTIONS.items():
        st.markdown(f"**{category}**")
        for i, q_text in enumerate(questions):
            if st.button(q_text, key=f"btn_{category}_{i}"):
                st.session_state.pending_question = q_text

# ─────────────────────────────────────────────────────────────────────────────
# Determine question: preset button click OR typed input
# ─────────────────────────────────────────────────────────────────────────────
question = st.session_state.pop("pending_question", None)
if not question and submitted and typed.strip():
    question = typed.strip()


# ─────────────────────────────────────────────────────────────────────────────
# Process question
# ─────────────────────────────────────────────────────────────────────────────
if question:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("Retrieving and generating..."):
            try:
                answer, source_docs, prompt_text = run_rag(question, k, model_id)
            except Exception as e:
                st.error(f"Error: {e}")
                st.stop()

        chunks_data = [
            {
                "content": doc.page_content,
                "source": doc.metadata.get("source", "unknown"),
                "page": doc.metadata.get("page", "?"),
            }
            for doc in source_docs
        ]

        msg = {
            "role": "assistant",
            "content": answer,
            "chunks": chunks_data,
            "prompt_sent": prompt_text,
        }
        render_assistant_msg(msg)

    st.session_state.messages.append(msg)
    st.rerun()
