# LSTM vs RNN Log Anomaly Scoring - HPE Infrastructure Analytics
# Same dataset and use-case as rnn_logdemo.py.
# Trains BOTH a vanilla RNN and an LSTM side-by-side, then compares
# training dynamics, test accuracy, and per-event predictions.

import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error
import re
from collections import Counter
import matplotlib.pyplot as plt

torch.manual_seed(42)
np.random.seed(42)

print("LSTM vs RNN — Infrastructure Log Anomaly Scoring")
print("=" * 55)


# =============================================================================
# 1. IDENTICAL DATA TO rnn_logdemo.py
#    (kept the same so every difference in results is purely architectural)
# =============================================================================
print("\n1. Loading Synthetic Log Data...")

data = {
    'log_message': [
        "disk read write operations normal",
        "network interface link speed stable",
        "cpu utilization within expected range",
        "fan speed nominal all modules reporting",
        "memory ecc errors zero count nominal",
        "storage controller cache hit rate good",
        "power supply voltage levels stable",
        "raid rebuild completed successfully",
        "network packet loss negligible acceptable",
        "temperature sensors all within threshold",
        "disk latency elevated threshold warning",
        "network retransmit rate increasing observed",
        "cpu temperature approaching limit warning",
        "fan module reporting intermittent failures",
        "memory correctable ecc errors increasing",
        "storage controller queue depth high warning",
        "power supply ripple voltage detected",
        "raid degraded missing drive detected",
        "packet drops increasing on port warning",
        "thermal sensor reading high warning",
        "disk io timeout uncorrectable error critical",
        "network link down failover triggered critical",
        "cpu throttling thermal emergency shutdown",
        "fan failure multiple modules offline critical",
        "memory uncorrectable ecc error panic critical",
        "storage controller cache failed data loss risk",
        "power supply failed redundancy lost critical",
        "raid failed multiple drives offline critical",
        "network storm detected broadcast loop critical",
        "chassis over temperature emergency shutdown",
    ],
    'component': [
        'StorageCtrl','NetworkAdapter','ComputeBlade','FanModule',   'MemorySubsys',
        'StorageCtrl','PowerSupply',  'StorageCtrl', 'NetworkAdapter','ThermalMgmt',
        'StorageCtrl','NetworkAdapter','ComputeBlade','FanModule',   'MemorySubsys',
        'StorageCtrl','PowerSupply',  'StorageCtrl', 'NetworkAdapter','ThermalMgmt',
        'StorageCtrl','NetworkAdapter','ComputeBlade','FanModule',   'MemorySubsys',
        'StorageCtrl','PowerSupply',  'StorageCtrl', 'NetworkAdapter','ThermalMgmt',
    ],
    'log_level': [
        'INFO','INFO','INFO','INFO','INFO',
        'INFO','INFO','INFO','INFO','INFO',
        'WARNING','WARNING','WARNING','WARNING','WARNING',
        'WARNING','WARNING','WARNING','WARNING','WARNING',
        'ERROR','ERROR','ERROR','ERROR','ERROR',
        'CRITICAL','CRITICAL','CRITICAL','CRITICAL','CRITICAL',
    ],
    'mins_since_last_error': [
        120, 90,150,200,180,110,300, 95, 75,250,
         45, 30, 20, 15, 40, 25, 10,  8, 35, 18,
          5,  3,  7,  2,  4,  1,  1,  1,  2,  1,
    ],
    'error_count_10min': [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        2, 3, 4, 5, 2, 6, 7, 8, 3, 5,
        9,12,10,15,11,18,20,22,14,25,
    ],
    'anomaly_score': [
        0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
        3, 4, 5, 5, 4, 5, 6, 7, 4, 5,
        8, 8, 9, 9, 8, 9,10,10, 8,10,
    ],
}

df = pd.DataFrame(data)
print(f"Dataset shape: {df.shape}")
print(df[['log_message','component','log_level','anomaly_score']].head(6).to_string(index=False))


# =============================================================================
# 2. TEXT PRE-PROCESSING  (identical to rnn_logdemo.py)
# =============================================================================
print("\n2. Text Preprocessing...")

def tokenize(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    return text.split()

all_tokens = []
for msg in df['log_message']:
    all_tokens.extend(tokenize(msg))

vocab       = Counter(all_tokens)
word_to_idx = {w: i + 1 for i, w in enumerate(vocab.keys())}
word_to_idx['<PAD>'] = 0
idx_to_word = {i: w for w, i in word_to_idx.items()}
VOCAB_SIZE   = len(word_to_idx)

MAX_SEQ_LEN = 8

def encode_message(text, max_len=MAX_SEQ_LEN):
    tokens = tokenize(text)
    seq    = [word_to_idx.get(t, 0) for t in tokens]
    if len(seq) < max_len:
        seq += [0] * (max_len - len(seq))
    return seq[:max_len]

X_text = np.array([encode_message(m) for m in df['log_message']])


# =============================================================================
# 3. ENCODE CATEGORICAL + SCALE NUMERICAL  (identical to rnn_logdemo.py)
# =============================================================================
print("\n3. Encoding Features...")

le_comp  = LabelEncoder()
le_level = LabelEncoder()

X_comp   = le_comp.fit_transform(df['component']).reshape(-1, 1)
X_level  = le_level.fit_transform(df['log_level']).reshape(-1, 1)
X_mins   = (df['mins_since_last_error'].values / 300.0).reshape(-1, 1)
X_errwin = (df['error_count_10min'].values / 25.0).reshape(-1, 1)

X_numerical = np.concatenate([X_comp, X_level, X_mins, X_errwin], axis=1)
y           = df['anomaly_score'].values


# =============================================================================
# 4. TRAIN / TEST SPLIT  (same split as rnn_logdemo.py)
# =============================================================================
print("\n4. Splitting Data...")

(X_txt_tr, X_txt_te,
 X_num_tr, X_num_te,
 y_tr, y_te) = train_test_split(
    X_text, X_numerical, y, test_size=0.25, random_state=42
)

X_txt_tr = torch.LongTensor(X_txt_tr)
X_txt_te = torch.LongTensor(X_txt_te)
X_num_tr = torch.FloatTensor(X_num_tr)
X_num_te = torch.FloatTensor(X_num_te)
y_tr     = torch.FloatTensor(y_tr).view(-1, 1)
y_te     = torch.FloatTensor(y_te).view(-1, 1)

print(f"Train: {len(X_txt_tr)}  |  Test: {len(X_txt_te)}")


# =============================================================================
# 5. MODEL DEFINITIONS
# =============================================================================
print("\n5. Defining Models...")

# ── 5a. Vanilla RNN (copied from rnn_logdemo.py for fair comparison) ─────────
class LogAnomalyRNN(nn.Module):
    """
    Vanilla RNN: one hidden state h_t updated at each step via:
        h_t = tanh(W_h * h_{t-1} + W_x * x_t + b)
    The final h_t is concatenated with metadata and passed to FC layers.

    KEY WEAKNESS: tanh is applied at every step, so gradients must flow
    through many tanh saturations to reach early tokens.  On sequences
    longer than ~10 steps the gradient shrinks toward zero (vanishing
    gradient) and early context is effectively forgotten.
    """
    def __init__(self, vocab_size, embed_dim, hidden_dim, num_meta=4):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.rnn       = nn.RNN(embed_dim, hidden_dim, batch_first=True,
                                nonlinearity='tanh')
        self.dropout   = nn.Dropout(0.3)
        self.fc1 = nn.Linear(hidden_dim + num_meta, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)
        self.relu = nn.ReLU()

    def forward(self, token_seq, meta):
        emb     = self.embedding(token_seq)
        out, _  = self.rnn(emb)               # _ = h_n  (final hidden state)
        last    = self.dropout(out[:, -1, :])
        x = self.relu(self.fc1(torch.cat([last, meta], dim=1)))
        x = self.relu(self.fc2(x))
        return self.fc3(x)


# ── 5b. LSTM ──────────────────────────────────────────────────────────────────
class LogAnomalyLSTM(nn.Module):
    """
    LSTM adds a CELL STATE (c_t) alongside the hidden state (h_t).
    Three learned gates control information flow at each time step:

        Forget gate : f_t = sigmoid(W_f * [h_{t-1}, x_t] + b_f)
                      → decides how much of the old cell to erase
                      → when f_t ≈ 1 the cell "remembers" indefinitely
                      → this is the fix for vanishing gradients

        Input gate  : i_t = sigmoid(W_i * [h_{t-1}, x_t] + b_i)
          + candidate: g_t = tanh(W_g * [h_{t-1}, x_t] + b_g)
                      → decides what new information to write into c_t

        Output gate : o_t = sigmoid(W_o * [h_{t-1}, x_t] + b_o)
                      → decides how much of c_t to expose as h_t

        Cell update : c_t = f_t ⊙ c_{t-1} + i_t ⊙ g_t
        Hidden out  : h_t = o_t ⊙ tanh(c_t)

    The cell state c_t provides a "highway" for gradients: they can flow
    backwards through time via the forget gate multiplications (which are
    close to 1 for important information) without passing through tanh
    saturation at every step.

    COST: ~4x more parameters than a vanilla RNN of the same hidden_dim
    because all four gates (f, i, g, o) each have their own weight matrix.
    """
    def __init__(self, vocab_size, embed_dim, hidden_dim, num_meta=4):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        # nn.LSTM returns (output, (h_n, c_n)) — note the tuple vs RNN's h_n
        self.lstm      = nn.LSTM(embed_dim, hidden_dim, batch_first=True)
        self.dropout   = nn.Dropout(0.3)
        self.fc1 = nn.Linear(hidden_dim + num_meta, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)
        self.relu = nn.ReLU()

    def forward(self, token_seq, meta):
        emb           = self.embedding(token_seq)
        out, (h_n, _) = self.lstm(emb)        # h_n = final hidden, _ = c_n
        last          = self.dropout(out[:, -1, :])
        x = self.relu(self.fc1(torch.cat([last, meta], dim=1)))
        x = self.relu(self.fc2(x))
        return self.fc3(x)


# ── Hyperparameters (same for both to ensure fair comparison) ─────────────────
EMBED_DIM  = 16
HIDDEN_DIM = 32
LR         = 0.001
EPOCHS     = 150

rnn_model  = LogAnomalyRNN( VOCAB_SIZE, EMBED_DIM, HIDDEN_DIM)
lstm_model = LogAnomalyLSTM(VOCAB_SIZE, EMBED_DIM, HIDDEN_DIM)

rnn_params  = sum(p.numel() for p in rnn_model.parameters())
lstm_params = sum(p.numel() for p in lstm_model.parameters())

print(f"\n  RNN  parameters : {rnn_params:,}")
print(f"  LSTM parameters : {lstm_params:,}")
print(f"  LSTM / RNN ratio: {lstm_params / rnn_params:.2f}x")
# ── WHY the ratio matters ─────────────────────────────────────────────────────
# The LSTM has ~4x more weight matrices (one per gate) in its recurrent core.
# On tiny datasets this extra capacity can overfit; on real production logs
# (millions of events) it pays off because failure patterns are more complex.


# =============================================================================
# 6. TRAINING LOOP (identical procedure for both)
# =============================================================================
print("\n6. Training both models...")

def train_model(model, epochs, label):
    optimizer    = optim.Adam(model.parameters(), lr=LR)
    criterion    = nn.MSELoss()
    losses       = []
    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()
        preds = model(X_txt_tr, X_num_tr)
        loss  = criterion(preds, y_tr)
        loss.backward()
        optimizer.step()
        losses.append(loss.item())
        if (epoch + 1) % 30 == 0:
            print(f"  [{label}] Epoch {epoch+1:3d}/{epochs}  Loss: {loss.item():.4f}")
    return losses

rnn_losses  = train_model(rnn_model,  EPOCHS, "RNN ")
lstm_losses = train_model(lstm_model, EPOCHS, "LSTM")


# =============================================================================
# 7. EVALUATION
# =============================================================================
print("\n7. Evaluating both models...")

def evaluate(model, label):
    model.eval()
    with torch.no_grad():
        tr_pred = model(X_txt_tr, X_num_tr)
        te_pred = model(X_txt_te, X_num_te)
    tr_mse = mean_squared_error(y_tr.numpy(), tr_pred.numpy())
    tr_mae = mean_absolute_error(y_tr.numpy(), tr_pred.numpy())
    te_mse = mean_squared_error(y_te.numpy(), te_pred.numpy())
    te_mae = mean_absolute_error(y_te.numpy(), te_pred.numpy())
    print(f"\n  {label}  Train MSE={tr_mse:.4f} MAE={tr_mae:.4f}"
          f"  |  Test MSE={te_mse:.4f} MAE={te_mae:.4f}")
    return tr_mse, tr_mae, te_mse, te_mae, te_pred

rnn_tr_mse,  rnn_tr_mae,  rnn_te_mse,  rnn_te_mae,  rnn_te_pred  = evaluate(rnn_model,  "RNN ")
lstm_tr_mse, lstm_tr_mae, lstm_te_mse, lstm_te_mae, lstm_te_pred = evaluate(lstm_model, "LSTM")

print("\n  ── Summary ──────────────────────────────────────────")
print(f"  {'Metric':<20} {'RNN':>10} {'LSTM':>10} {'Winner':>10}")
print(f"  {'-'*52}")
for metric, rv, lv in [
    ("Test MSE",        rnn_te_mse, lstm_te_mse),
    ("Test MAE",        rnn_te_mae, lstm_te_mae),
    ("Train MSE",       rnn_tr_mse, lstm_tr_mse),
    ("Final train loss",rnn_losses[-1], lstm_losses[-1]),
]:
    winner = "LSTM" if lv < rv else ("RNN" if rv < lv else "Tie")
    print(f"  {metric:<20} {rv:>10.4f} {lv:>10.4f} {winner:>10}")


# =============================================================================
# 8. SIDE-BY-SIDE PREDICTIONS ON TEST EVENTS
# =============================================================================
print("\n8. Side-by-side predictions on test events...")

def score_label(s):
    if s < 3:  return "HEALTHY"
    if s < 6:  return "DEGRADED"
    if s < 9:  return "WARNING"
    return "CRITICAL"

print(f"\n  {'Log (truncated)':<36} {'Actual':>7} {'RNN':>7} {'LSTM':>7}  {'RNN Label':<10} {'LSTM Label'}")
print("  " + "-" * 85)

rnn_model.eval()
lstm_model.eval()
with torch.no_grad():
    rnn_preds_all  = rnn_model( X_txt_te, X_num_te)
    lstm_preds_all = lstm_model(X_txt_te, X_num_te)

for i in range(len(X_txt_te)):
    tokens = X_txt_te[i].numpy()
    words  = [idx_to_word.get(t, '') for t in tokens if t != 0]
    msg    = ' '.join(words)[:35]
    actual = y_te[i].item()
    rp     = rnn_preds_all[i].item()
    lp     = lstm_preds_all[i].item()
    print(f"  {msg:<36} {actual:>7.1f} {rp:>7.1f} {lp:>7.1f}  "
          f"{score_label(rp):<10} {score_label(lp)}")


# =============================================================================
# 9. VISUALISATIONS
# =============================================================================
print("\n9. Generating Visualisations...")

fig, axes = plt.subplots(2, 3, figsize=(17, 9))
fig.suptitle("RNN vs LSTM — HPE Log Anomaly Scoring", fontsize=13, fontweight='bold')

# ── Row 1: Training loss curves ───────────────────────────────────────────────
axes[0, 0].plot(rnn_losses,  color='steelblue', label='RNN')
axes[0, 0].set_title('RNN Training Loss')
axes[0, 0].set_xlabel('Epoch'); axes[0, 0].set_ylabel('MSE Loss')
axes[0, 0].grid(True)

axes[0, 1].plot(lstm_losses, color='darkorange', label='LSTM')
axes[0, 1].set_title('LSTM Training Loss')
axes[0, 1].set_xlabel('Epoch'); axes[0, 1].set_ylabel('MSE Loss')
axes[0, 1].grid(True)

axes[0, 2].plot(rnn_losses,  color='steelblue',  label='RNN',  alpha=0.8)
axes[0, 2].plot(lstm_losses, color='darkorange', label='LSTM', alpha=0.8)
axes[0, 2].set_title('Loss Comparison (overlay)')
axes[0, 2].set_xlabel('Epoch'); axes[0, 2].set_ylabel('MSE Loss')
axes[0, 2].legend(); axes[0, 2].grid(True)

# ── Row 2: Predicted vs Actual scatter ───────────────────────────────────────
actual_vals = y_te.numpy().flatten()
rnn_vals    = rnn_te_pred.numpy().flatten()
lstm_vals   = lstm_te_pred.numpy().flatten()

for ax, vals, color, label in [
    (axes[1, 0], rnn_vals,  'steelblue',  'RNN'),
    (axes[1, 1], lstm_vals, 'darkorange', 'LSTM'),
]:
    ax.scatter(actual_vals, vals, alpha=0.85, color=color)
    ax.plot([0, 10], [0, 10], 'r--', label='Perfect')
    ax.set_xlabel('Actual Anomaly Score')
    ax.set_ylabel('Predicted Anomaly Score')
    ax.set_title(f'{label}: Predicted vs Actual')
    ax.legend(); ax.grid(True)

# ── Bar chart: MAE comparison per severity band ───────────────────────────────
bands     = ['HEALTHY\n(0–2)', 'DEGRADED\n(3–5)', 'WARNING\n(6–8)', 'CRITICAL\n(9–10)']
def band_idx(score):
    if score <= 2: return 0
    if score <= 5: return 1
    if score <= 8: return 2
    return 3

rnn_band_mae  = [[] for _ in range(4)]
lstm_band_mae = [[] for _ in range(4)]
for i in range(len(actual_vals)):
    b = band_idx(actual_vals[i])
    rnn_band_mae[b].append( abs(rnn_vals[i]  - actual_vals[i]))
    lstm_band_mae[b].append(abs(lstm_vals[i] - actual_vals[i]))

rnn_means  = [np.mean(v) if v else 0 for v in rnn_band_mae]
lstm_means = [np.mean(v) if v else 0 for v in lstm_band_mae]

x = np.arange(len(bands))
w = 0.35
axes[1, 2].bar(x - w/2, rnn_means,  w, label='RNN',  color='steelblue',  alpha=0.8)
axes[1, 2].bar(x + w/2, lstm_means, w, label='LSTM', color='darkorange', alpha=0.8)
axes[1, 2].set_xticks(x); axes[1, 2].set_xticklabels(bands, fontsize=8)
axes[1, 2].set_ylabel('Mean Absolute Error')
axes[1, 2].set_title('MAE per Severity Band')
axes[1, 2].legend(); axes[1, 2].grid(True, axis='y')

plt.tight_layout()
plt.show()


# =============================================================================
# 10. INFERENCE ON NEW LOG EVENTS  (same events as rnn_logdemo.py)
# =============================================================================
print("\n10. Inference on New Log Events...")

def predict_log(model, message, component, log_level,
                mins_since_last_error, error_count_10min):
    model.eval()
    with torch.no_grad():
        txt   = torch.LongTensor([encode_message(message)])
        comp  = le_comp.transform([component])[0]
        level = le_level.transform([log_level])[0]
        meta  = torch.FloatTensor([[
            comp, level,
            mins_since_last_error / 300.0,
            error_count_10min     /  25.0,
        ]])
        return model(txt, meta).item()

new_events = [
    ("disk read write operations normal",              'StorageCtrl',    'INFO',      200,  0),
    ("storage controller queue depth high warning",   'StorageCtrl',    'WARNING',    20,  6),
    ("disk io timeout uncorrectable error critical",  'StorageCtrl',    'ERROR',       3, 14),
    ("fan failure multiple modules offline critical", 'FanModule',      'CRITICAL',    1, 20),
    ("network retransmit rate increasing observed",   'NetworkAdapter', 'WARNING',    30,  3),
    ("power supply failed redundancy lost critical",  'PowerSupply',    'CRITICAL',    1, 22),
]

print(f"\n  {'Log Message':<48}  {'RNN':>6}  {'LSTM':>6}  {'RNN Status':<10} {'LSTM Status'}")
print("  " + "-" * 100)
for msg, comp, lvl, mins, errs in new_events:
    rs = predict_log(rnn_model,  msg, comp, lvl, mins, errs)
    ls = predict_log(lstm_model, msg, comp, lvl, mins, errs)
    print(f"  {msg:<48}  {rs:>6.1f}  {ls:>6.1f}  {score_label(rs):<10} {score_label(ls)}")


# =============================================================================
# ANALYSIS: RNN vs LSTM — WHAT WE OBSERVED AND WHY
# =============================================================================
#
# ── PARAMETER COUNT ───────────────────────────────────────────────────────────
# LSTM has ~4x more parameters in its recurrent core than the RNN because it
# maintains four independent weight matrices (forget / input / gate / output).
# In this demo both models are small (< 10 k params) so the overhead is
# negligible.  On a real HPE log stream with a 50 k-token vocabulary the gap
# matters more for memory and inference latency.
#
# ── TRAINING LOSS CONVERGENCE ─────────────────────────────────────────────────
# Look at the overlay chart (top-right).  Typical behaviour on this dataset:
#   - Both models converge quickly because log messages are short (≤ 8 tokens)
#     and the anomaly signal is strong and consistent.
#   - LSTM often converges to a lower final loss, or reaches the same loss in
#     fewer epochs, because its gates can rapidly learn to pass the critical
#     tokens ("uncorrectable", "failed", "offline") straight through to the
#     output without the tanh squashing that the RNN applies at every step.
#   - On this tiny 30-row dataset the difference may appear small; on longer
#     real sequences (full syslog lines, multi-line stack traces) the gap widens
#     significantly in favour of LSTM.
#
# ── TEST ACCURACY (MSE / MAE) ─────────────────────────────────────────────────
# Both models score well when the severity band is clear-cut (INFO vs CRITICAL).
# The interesting comparison is in the DEGRADED / WARNING band (scores 3–8)
# where messages are ambiguous — "warning" and "elevated" co-occur with normal
# operations.  The per-band MAE chart (bottom-right) typically shows:
#   - HEALTHY   : tie (both trivially predict ~0 for INFO messages)
#   - DEGRADED  : LSTM slightly lower MAE — forget gate learns to downweight
#                 routine words like "observed" or "detected" and upweight
#                 "warning" context from earlier tokens
#   - WARNING   : LSTM advantage more visible — gate mechanism preserves the
#                 danger signal across the full token sequence
#   - CRITICAL  : both models do well because the vocabulary is unambiguous
#                 ("uncorrectable", "panic", "shutdown", "failed")
#
# ── WHERE THE RNN STRUGGLES ───────────────────────────────────────────────────
# The vanilla RNN compresses everything into a single float vector h_t using
# tanh at every step.  When a log message has an early warning word followed
# by several normal words, the tanh can wash out the warning by the final step.
# Example:
#   "disk io timeout uncorrectable error critical"
#   token 1: "disk"      → h_1 = tanh(...)   — neutral
#   token 2: "io"        → h_2 = tanh(...)   — neutral
#   token 3: "timeout"   → h_3 = tanh(...)   — starts to signal
#   token 4: "uncorrect" → h_4 = tanh(...)   — high signal
#   token 5: "error"     → h_5 = tanh(...)   — still high
#   token 6: "critical"  → h_6 = tanh(...)   — peak signal
# For this message the dangerous words are late, so the RNN copes.
# But for a message like:
#   "uncorrectable sector error detected during normal read operation"
# the dangerous word "uncorrectable" is token 1, followed by many neutral words.
# The RNN progressively overwrites h_1 and the danger signal fades.
# The LSTM forget gate would keep f_t ≈ 1 for the danger signal in c_t,
# preserving it through the remaining neutral tokens.
#
# ── WHERE THE LSTM HELPS IN HPE LOG CONTEXT ──────────────────────────────────
# Real HPE server logs often look like:
#   "smartd[1234]: Device: /dev/sda [SAT], 1 Offline uncorrectable sectors"
# After tokenisation this is ~10 tokens.  The RNN will have vanished the
# "uncorrectable" signal by the time it processes the trailing metadata.
# The LSTM cell state retains "uncorrectable" in c_t and the output gate
# can surface it when forming the final representation.
#
# ── WHEN TO USE WHICH ─────────────────────────────────────────────────────────
# Use RNN when:
#   - Sequences are very short (≤ 5 tokens) and patterns are near the end
#   - Inference speed / memory is the primary constraint (edge devices, FPGAs)
#   - The dataset is tiny and you are worried about overfitting (fewer params)
#
# Use LSTM when:
#   - Log messages are long (full syslog lines, kernel stack traces)
#   - Critical tokens appear early in the message
#   - You are modelling sequences OF log lines (event windows), not just tokens
#     — the forget gate learns which past events to carry forward across lines
#   - Production environment with sufficient memory and compute (HPE ProLiant,
#     Synergy, or SimpliVity management plane)
#
# ── NEXT STEP BEYOND LSTM ─────────────────────────────────────────────────────
# Bidirectional LSTM (BiLSTM): reads the sequence both forwards and backwards,
# giving every token access to full left and right context.  One extra line:
#     self.lstm = nn.LSTM(..., bidirectional=True)
# then double hidden_dim in the FC input size.
# After BiLSTM: Transformer / LogBERT (see rnn_logdemo.py comments).
print(f"\n{'='*55}")
print("LSTM vs RNN Comparison Complete!")
print(f"{'='*55}")


# =============================================================================
# OBSERVED RESULT ANALYSIS: WHY LSTM PERFORMED WORSE THAN RNN HERE
# (Based on the actual charts produced by this script)
# =============================================================================
#
# The charts showed the opposite of the textbook expectation:
#   RNN  → loss converges smoothly, predictions tight around the diagonal
#   LSTM → loss converges more slowly and noisily, CRITICAL band MAE ≈ 6.0
#           vs RNN's ≈ 0.8 — LSTM was nearly 8× worse on critical events
#
# This is a well-known empirical trap.  Here is the complete explanation.
#
#
# REASON 1 — DATASET IS TOO SMALL TO TRAIN LSTM GATES (root cause)
# ─────────────────────────────────────────────────────────────────
# Training set size after 75/25 split: ~22 samples.
# LSTM has four weight matrices per gate (forget/input/candidate/output),
# each of size (embed_dim + hidden_dim) × hidden_dim.
# With EMBED_DIM=16, HIDDEN_DIM=32 that is 4 × 48×32 = 6,144 recurrent
# weights that must be learned from 22 examples.
# The RNN has just ONE such matrix: 48×32 = 1,536 weights.
#
# The LSTM has 4× more free parameters to optimise, but 4× fewer examples
# per parameter.  The gate weights fail to converge to meaningful open/close
# decisions; instead they settle at near-random values that produce
# mid-range outputs (~5) regardless of input — exactly what the CRITICAL
# scatter plot shows: all predicted values clumped around 4–5 when
# actual values are 9–10.
#
#
# REASON 2 — FORGET GATE IS INITIALISED TO "FORGET EVERYTHING" (f_t ≈ 0.5)
# ──────────────────────────────────────────────────────────────────────────
# PyTorch initialises bias terms to zero, so at epoch 0:
#   f_t = sigmoid(0) = 0.5  → half the cell state is erased every step
# This means the LSTM starts by actively destroying the very signal it
# is supposed to preserve.  A known fix is to initialise forget-gate bias
# to 1.0 (Jozefowicz et al., 2015), which makes f_t ≈ 0.73 at init,
# closer to "keep everything".  PyTorch does NOT do this by default.
# With 22 training samples there are not enough gradient updates to
# correct this initialisation bias before the model over-adjusts and
# starts mis-scoring critical events.
# The RNN has no such bias: it starts with tanh(0) = 0, a neutral slate.
#
#
# REASON 3 — SEQUENCES ARE ONLY 8 TOKENS LONG (LSTM'S ADVANTAGE IS IRRELEVANT)
# ──────────────────────────────────────────────────────────────────────────────
# The vanishing gradient problem that LSTM was designed to solve only
# becomes significant at sequence lengths of ~20+ tokens.
# At MAX_SEQ_LEN = 8 the vanilla RNN gradient flows back through just 8
# tanh steps — a small enough depth that vanishing barely occurs.
# The RNN therefore suffers none of the pathology that justifies LSTM's
# extra complexity, yet still pays the overfitting cost of LSTM's gates.
# The LSTM's complexity buys nothing here but costs data efficiency.
#
#
# REASON 4 — LSTM LOSS IS NOISIER (LOSS CURVE SHOWS SPIKES ~EPOCH 40–80)
# ────────────────────────────────────────────────────────────────────────
# The overlay chart shows the LSTM loss spiking upward several times while
# the RNN's loss is smooth.  This is the gate interaction problem: all four
# gate activations feed into the cell update simultaneously.  When one gate
# overshoots (a common occurrence under Adam with sparse data), it amplifies
# error signals for all others — a mini "internal covariate shift" that
# causes the loss to jump.  With only 22 samples there is no regularising
# effect from batch diversity to dampen these spikes.
# The RNN has a single multiplicative path, so there is no gate
# cross-amplification.
#
#
# REASON 5 — THE CRITICAL BAND MAE ≈ 6.0 IS A SATURATION ARTEFACT
# ─────────────────────────────────────────────────────────────────
# There are only ~5 CRITICAL events (score 9–10) in the full dataset,
# roughly 1–2 in the test set.  The LSTM's output gate (o_t = sigmoid(...))
# squashes h_t through tanh before the FC layers, capping the effective
# signal range.  When gate weights have not converged, o_t ≈ 0.5 and the
# output is approximately tanh(0.5 × c_t) — a heavily compressed signal.
# The FC layers then map this compressed value to the middle of the 0–10
# range (~4–5) regardless of whether the input was CRITICAL or HEALTHY.
# The RNN's final hidden state is not compressed by an output gate, so
# its FC layers receive a wider dynamic range and can discriminate extremes.
#
#
# REASON 6 — ADAM LEARNING RATE IS NOT TUNED FOR LSTM
# ─────────────────────────────────────────────────────
# Both models use LR = 0.001.  Adam adapts per-parameter step sizes, but
# LSTM has 4× more parameters interacting through gate products.  The
# effective curvature of the LSTM loss surface is sharper, so the same
# LR = 0.001 that is "just right" for the RNN is too coarse for the LSTM
# — it overshoots on early gate updates and then oscillates.  A lower LR
# (e.g. 0.0003) and a warmup schedule would help the LSTM significantly.
#
#
# SUMMARY TABLE
# ─────────────────────────────────────────────────────────────────────────────
#  Factor                      | Favours RNN here | Favours LSTM in production
#  ─────────────────────────────────────────────────────────────────────────
#  Dataset size                | 22 samples       | millions of log events
#  Sequence length             | 8 tokens (short) | 50–200 tokens (full line)
#  Gate initialisation bias    | RNN has none     | fixable (bias init = 1.0)
#  Parameter count             | RNN is leaner    | LSTM handles complex patterns
#  Vanishing gradient risk     | none at len=8    | severe at len > 20
#  Critical-band discrimination| RNN wider range  | LSTM with proper data/tuning
#
#
# WHAT NEEDS TO CHANGE FOR LSTM TO WIN ON THIS USE-CASE
# ─────────────────────────────────────────────────────────────────────────────
# 1. More data    : ≥ 500 labelled log events (still tiny by ML standards)
# 2. Forget bias  : initialise forget-gate bias to 1.0 in __init__:
#                     for name, p in self.lstm.named_parameters():
#                         if 'bias_hh' in name:
#                             nn.init.constant_(p[hidden_dim:2*hidden_dim], 1.0)
# 3. Lower LR     : 0.0003 with a cosine schedule or warmup
# 4. Longer seqs  : use full syslog lines (50–100 tokens) — this is when
#                   the cell-state highway pays off over the RNN
# 5. Event windows: model sequences OF log lines, not tokens within one line
#                   — LSTM's true strength is multi-event temporal memory
