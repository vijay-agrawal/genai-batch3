# RNN Log Anomaly Scoring - HPE Infrastructure Analytics
# Demonstrates using RNN to predict failure severity from timestamped,
# multi-component server log sequences (Storage, Network, Compute, Power, Cooling)

import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error
import re
from collections import Counter
import matplotlib.pyplot as plt

torch.manual_seed(42)
np.random.seed(42)

print("RNN Infrastructure Log Anomaly Scoring")
print("=" * 55)

# ─────────────────────────────────────────────────────────────
# 1. SYNTHETIC LOG DATA
#    Each row = one log event from an HPE server farm.
#    anomaly_score 0-10: 0 = healthy, 10 = imminent failure
# ─────────────────────────────────────────────────────────────
print("\n1. Loading Synthetic Log Data...")

data = {
    'log_message': [
        # healthy / informational
        "disk read write operations normal",
        "network interface link speed stable",
        "cpu utilization within expected range",
        "fan speed nominal all modules reporting",
        "memory ecc errors zero count nominal",
        "storage controller cache hit rate good",
        "power supply voltage levels stable",
        "raid rebuild completed successfully",
        "network packet loss negligible acceptable",
        "temperature sensors all within threshold",
        # degraded / warning signals
        "disk latency elevated threshold warning",
        "network retransmit rate increasing observed",
        "cpu temperature approaching limit warning",
        "fan module reporting intermittent failures",
        "memory correctable ecc errors increasing",
        "storage controller queue depth high warning",
        "power supply ripple voltage detected",
        "raid degraded missing drive detected",
        "packet drops increasing on port warning",
        "thermal sensor reading high warning",
        # critical / failure signals
        "disk io timeout uncorrectable error critical",
        "network link down failover triggered critical",
        "cpu throttling thermal emergency shutdown",
        "fan failure multiple modules offline critical",
        "memory uncorrectable ecc error panic critical",
        "storage controller cache failed data loss risk",
        "power supply failed redundancy lost critical",
        "raid failed multiple drives offline critical",
        "network storm detected broadcast loop critical",
        "chassis over temperature emergency shutdown",
    ],
    'component': [
        'StorageCtrl', 'NetworkAdapter', 'ComputeBlade', 'FanModule',   'MemorySubsys',
        'StorageCtrl', 'PowerSupply',   'StorageCtrl',  'NetworkAdapter','ThermalMgmt',
        'StorageCtrl', 'NetworkAdapter', 'ComputeBlade', 'FanModule',   'MemorySubsys',
        'StorageCtrl', 'PowerSupply',   'StorageCtrl',  'NetworkAdapter','ThermalMgmt',
        'StorageCtrl', 'NetworkAdapter', 'ComputeBlade', 'FanModule',   'MemorySubsys',
        'StorageCtrl', 'PowerSupply',   'StorageCtrl',  'NetworkAdapter','ThermalMgmt',
    ],
    'log_level': [
        'INFO','INFO','INFO','INFO','INFO',
        'INFO','INFO','INFO','INFO','INFO',
        'WARNING','WARNING','WARNING','WARNING','WARNING',
        'WARNING','WARNING','WARNING','WARNING','WARNING',
        'ERROR','ERROR','ERROR','ERROR','ERROR',
        'CRITICAL','CRITICAL','CRITICAL','CRITICAL','CRITICAL',
    ],
    # minutes since last error event on this component (0 = very recent)
    'mins_since_last_error': [
        120, 90, 150, 200, 180, 110, 300, 95, 75, 250,
         45, 30,  20,  15,  40,  25,  10,  8,  35,  18,
          5,  3,   7,   2,   4,   1,   1,   1,   2,   1,
    ],
    # error count in a 10-minute rolling window
    'error_count_10min': [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        2, 3, 4, 5, 2, 6, 7, 8, 3, 5,
        9,12,10,15,11,18,20,22,14,25,
    ],
    # ground-truth anomaly severity 0-10
    'anomaly_score': [
        0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
        3, 4, 5, 5, 4, 5, 6, 7, 4, 5,
        8, 8, 9, 9, 8, 9,10,10, 8,10,
    ],
}

df = pd.DataFrame(data)
print(f"Dataset shape: {df.shape}")
print("\nSample records:")
print(df[['log_message','component','log_level','anomaly_score']].head(6).to_string(index=False))


# ─────────────────────────────────────────────────────────────
# 2. TEXT PRE-PROCESSING
# ─────────────────────────────────────────────────────────────
print("\n2. Text Preprocessing (Log Messages)...")

def tokenize(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    return text.split()

all_tokens = []
for msg in df['log_message']:
    all_tokens.extend(tokenize(msg))

vocab = Counter(all_tokens)
word_to_idx = {w: i + 1 for i, w in enumerate(vocab.keys())}
word_to_idx['<PAD>'] = 0
idx_to_word = {i: w for w, i in word_to_idx.items()}
VOCAB_SIZE = len(word_to_idx)

print(f"Vocabulary size: {VOCAB_SIZE}")
print(f"Top tokens: {vocab.most_common(8)}")

MAX_SEQ_LEN = 8

def encode_message(text, max_len=MAX_SEQ_LEN):
    tokens = tokenize(text)
    seq = [word_to_idx.get(t, 0) for t in tokens]
    if len(seq) < max_len:
        seq += [0] * (max_len - len(seq))
    return seq[:max_len]

X_text = np.array([encode_message(m) for m in df['log_message']])


# ─────────────────────────────────────────────────────────────
# 3. ENCODE CATEGORICAL + SCALE NUMERICAL FEATURES
# ─────────────────────────────────────────────────────────────
print("\n3. Encoding Categorical & Numerical Features...")

le_comp  = LabelEncoder()
le_level = LabelEncoder()

X_comp    = le_comp.fit_transform(df['component']).reshape(-1, 1)
X_level   = le_level.fit_transform(df['log_level']).reshape(-1, 1)
X_mins    = (df['mins_since_last_error'].values / 300.0).reshape(-1, 1)   # normalise
X_errwin  = (df['error_count_10min'].values / 25.0).reshape(-1, 1)        # normalise

X_numerical = np.concatenate([X_comp, X_level, X_mins, X_errwin], axis=1)
y = df['anomaly_score'].values

print(f"Text input shape  : {X_text.shape}")
print(f"Numerical features: {X_numerical.shape}  "
      f"[component, log_level, mins_since_error, error_count_10min]")
print(f"Components encoded: {dict(zip(le_comp.classes_, le_comp.transform(le_comp.classes_)))}")
print(f"Log levels encoded: {dict(zip(le_level.classes_, le_level.transform(le_level.classes_)))}")


# ─────────────────────────────────────────────────────────────
# 4. RNN MODEL
# ─────────────────────────────────────────────────────────────
print("\n4. Defining RNN Model...")

class LogAnomalyRNN(nn.Module):
    """
    RNN that reads a tokenised log message as a sequence, then combines
    the resulting hidden state with structured metadata (component,
    log level, time-since-error, rolling error count) to regress an
    anomaly severity score from 0 (healthy) to 10 (critical failure).
    """
    def __init__(self, vocab_size, embed_dim, hidden_dim, num_meta=4):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.rnn       = nn.RNN(embed_dim, hidden_dim, batch_first=True, nonlinearity='tanh')
        self.dropout   = nn.Dropout(0.3)

        self.fc1 = nn.Linear(hidden_dim + num_meta, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)
        self.relu = nn.ReLU()

    def forward(self, token_seq, meta):
        emb     = self.embedding(token_seq)          # (B, seq, embed)
        out, _  = self.rnn(emb)                      # (B, seq, hidden)
        last    = self.dropout(out[:, -1, :])        # final time-step

        combined = torch.cat([last, meta], dim=1)
        x = self.relu(self.fc1(combined))
        x = self.relu(self.fc2(x))
        return self.fc3(x)


EMBED_DIM  = 16
HIDDEN_DIM = 32
LR         = 0.001
EPOCHS     = 150

model     = LogAnomalyRNN(VOCAB_SIZE, EMBED_DIM, HIDDEN_DIM)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=LR)

print(f"Parameters: {sum(p.numel() for p in model.parameters()):,}")


# ─────────────────────────────────────────────────────────────
# 5. TRAIN / TEST SPLIT & TENSOR CONVERSION
# ─────────────────────────────────────────────────────────────
print("\n5. Preparing Training Data...")

(X_txt_tr, X_txt_te,
 X_num_tr, X_num_te,
 y_tr, y_te) = train_test_split(
    X_text, X_numerical, y, test_size=0.25, random_state=42
)

X_txt_tr = torch.LongTensor(X_txt_tr)
X_txt_te = torch.LongTensor(X_txt_te)
X_num_tr = torch.FloatTensor(X_num_tr)
X_num_te = torch.FloatTensor(X_num_te)
y_tr     = torch.FloatTensor(y_tr).view(-1, 1)
y_te     = torch.FloatTensor(y_te).view(-1, 1)

print(f"Train: {len(X_txt_tr)}  |  Test: {len(X_txt_te)}")


# ─────────────────────────────────────────────────────────────
# 6. TRAINING LOOP
# ─────────────────────────────────────────────────────────────
print("\n6. Training RNN...")

train_losses = []
model.train()

for epoch in range(EPOCHS):
    optimizer.zero_grad()
    preds = model(X_txt_tr, X_num_tr)
    loss  = criterion(preds, y_tr)
    loss.backward()
    optimizer.step()
    train_losses.append(loss.item())

    if (epoch + 1) % 30 == 0:
        print(f"  Epoch [{epoch+1:3d}/{EPOCHS}]  Loss: {loss.item():.4f}")


# ─────────────────────────────────────────────────────────────
# 7. EVALUATION
# ─────────────────────────────────────────────────────────────
print("\n7. Evaluating Model...")

model.eval()
with torch.no_grad():
    tr_pred  = model(X_txt_tr, X_num_tr)
    te_pred  = model(X_txt_te, X_num_te)

tr_mse = mean_squared_error(y_tr.numpy(), tr_pred.numpy())
tr_mae = mean_absolute_error(y_tr.numpy(), tr_pred.numpy())
te_mse = mean_squared_error(y_te.numpy(), te_pred.numpy())
te_mae = mean_absolute_error(y_te.numpy(), te_pred.numpy())

print(f"\n  Train  MSE={tr_mse:.4f}  MAE={tr_mae:.4f}")
print(f"  Test   MSE={te_mse:.4f}  MAE={te_mae:.4f}")


# ─────────────────────────────────────────────────────────────
# 8. SAMPLE PREDICTIONS ON TEST SET
# ─────────────────────────────────────────────────────────────
print("\n8. Sample Predictions on Test Logs...")

def score_label(s):
    if s < 3:   return "HEALTHY"
    if s < 6:   return "DEGRADED"
    if s < 9:   return "WARNING"
    return "CRITICAL"

for i in range(len(X_txt_te)):
    actual    = y_te[i].item()
    predicted = te_pred[i].item()
    tokens    = X_txt_te[i].numpy()
    words     = [idx_to_word.get(t, '') for t in tokens if t != 0]
    msg       = ' '.join(words)
    print(f"\n  Log : '{msg}'")
    print(f"  Actual={actual:.0f} [{score_label(actual)}]  "
          f"Predicted={predicted:.1f} [{score_label(predicted)}]")


# ─────────────────────────────────────────────────────────────
# 9. INFERENCE ON NEW / UNSEEN LOG EVENTS
# ─────────────────────────────────────────────────────────────
print("\n9. Inference on New Log Events...")

def predict_log(message, component, log_level, mins_since_last_error, error_count_10min):
    """Score a single new log event."""
    model.eval()
    with torch.no_grad():
        txt   = torch.LongTensor([encode_message(message)])
        comp  = le_comp.transform([component])[0]
        level = le_level.transform([log_level])[0]
        meta  = torch.FloatTensor([[
            comp,
            level,
            mins_since_last_error / 300.0,
            error_count_10min     / 25.0,
        ]])
        score = model(txt, meta).item()
    return score

new_events = [
    # message                                           comp              level    mins  errs
    ("disk read write operations normal",              'StorageCtrl',    'INFO',   200,   0),
    ("storage controller queue depth high warning",   'StorageCtrl',    'WARNING', 20,   6),
    ("disk io timeout uncorrectable error critical",  'StorageCtrl',    'ERROR',    3,  14),
    ("fan failure multiple modules offline critical", 'FanModule',      'CRITICAL', 1,  20),
    ("network retransmit rate increasing observed",   'NetworkAdapter', 'WARNING', 30,   3),
    ("power supply failed redundancy lost critical",  'PowerSupply',    'CRITICAL', 1,  22),
]

print(f"\n  {'Log Message':<48}  {'Comp':<16} {'Level':<9} {'Score':>6}  Status")
print("  " + "-" * 95)
for msg, comp, lvl, mins, errs in new_events:
    score = predict_log(msg, comp, lvl, mins, errs)
    print(f"  {msg:<48}  {comp:<16} {lvl:<9} {score:>6.1f}  {score_label(score)}")


# ─────────────────────────────────────────────────────────────
# 10. VISUALISATIONS
# ─────────────────────────────────────────────────────────────
print("\n10. Generating Visualisations...")

fig, axes = plt.subplots(1, 3, figsize=(16, 4))

# Training loss curve
axes[0].plot(train_losses, color='steelblue')
axes[0].set_title('Training Loss (MSE)')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('MSE Loss')
axes[0].grid(True)

# Predicted vs Actual on test set
actual_vals    = y_te.numpy().flatten()
predicted_vals = te_pred.numpy().flatten()
axes[1].scatter(actual_vals, predicted_vals, alpha=0.8, color='darkorange')
axes[1].plot([0, 10], [0, 10], 'r--', label='Perfect')
axes[1].set_xlabel('Actual Anomaly Score')
axes[1].set_ylabel('Predicted Anomaly Score')
axes[1].set_title('Predicted vs Actual (Test Set)')
axes[1].legend()
axes[1].grid(True)

# Anomaly score distribution per component
comp_scores = df.groupby('component')['anomaly_score'].mean().sort_values()
axes[2].barh(comp_scores.index, comp_scores.values, color='tomato')
axes[2].set_xlabel('Mean Anomaly Score')
axes[2].set_title('Avg Anomaly Score by Component')
axes[2].grid(True, axis='x')

plt.tight_layout()
plt.show()

print(f"\n{'='*55}")
print("RNN Log Anomaly Demo Complete!")
print("The RNN learned to score infrastructure log events")
print("by reading token sequences from log messages and")
print("combining them with component/level/time metadata.")
print(f"{'='*55}")


# =============================================================================
# LIMITATIONS OF THIS APPROACH
# =============================================================================
#
# 1. VANILLA RNN — SHORT MEMORY
#    A plain RNN uses a single hidden state updated at each token step.
#    Gradients vanish over long sequences, so the model forgets context
#    from early tokens by the time it reaches the end of a long log line.
#    A log message like "disk [OK] ... correctable error on sector 0x3A"
#    may lose the "OK" signal before the model processes "error".
#
# 2. EACH LOG LINE IS TREATED INDEPENDENTLY
#    Real anomaly patterns unfold across many log lines over time.
#    This demo scores one event at a time — it has no memory of the
#    sequence of events that preceded the current line.  A burst of
#    WARNING lines from different components leading up to a CRITICAL
#    is exactly the pattern that matters, and this model cannot see it.
#
# 3. TINY SYNTHETIC DATASET (30 rows)
#    The model is trained on hand-crafted examples.  With real logs,
#    vocabulary is orders of magnitude larger, class imbalance is severe
#    (failures are rare), and the signal-to-noise ratio is much lower.
#    Results here are optimistic and will not transfer directly.
#
# 4. FIXED-LENGTH TOKEN WINDOW (MAX_SEQ_LEN = 8)
#    Log messages vary wildly in length.  Truncating to 8 tokens drops
#    structured fields (hostnames, error codes, hex addresses) that
#    carry diagnostic signal.  A smarter tokeniser would preserve these.
#
# 5. CHARACTER-LEVEL DETAIL IS LOST
#    Error codes like "0x8000000000000000" or "SIGBUS" are split into
#    sub-tokens or mapped to <PAD>.  Pre-trained log-specific embeddings
#    (e.g. trained on Apache/kernel/IPMI logs) would handle this better.
#
# 6. NO TEMPORAL ENCODING
#    Timestamps are reduced to a single scalar (mins_since_last_error).
#    The model does not know time-of-day, day-of-week, or the exact
#    elapsed time between consecutive events — all of which correlate
#    with failure patterns in production infrastructure.
#
# 7. REGRESSION FRAMING MAY NOT BE IDEAL
#    Anomaly "score" is a continuous 0-10 target.  In practice you may
#    want multi-class classification (normal / degraded / critical) or
#    a ranked output with calibrated probabilities for alerting thresholds.


# =============================================================================
# NEXT STEPS — UPGRADING THIS APPROACH
# =============================================================================
#
# STEP 1 — LSTM or GRU  (drop-in replacement, immediate win)
#    Replace nn.RNN with nn.LSTM or nn.GRU.  Both have gating mechanisms
#    that preserve long-range context and are far less prone to vanishing
#    gradients.  Change one line:
#        self.rnn = nn.LSTM(embed_dim, hidden_dim, batch_first=True)
#    and unpack the (output, (h_n, c_n)) tuple in forward().
#
# STEP 2 — EVENT-SEQUENCE MODEL (log lines as time steps, not tokens)
#    Instead of feeding tokens of one log line, feed a *window of recent
#    log events* as the sequence — each event is a feature vector
#    (embedding of message + component + level + numerical metadata).
#    The RNN/LSTM then learns patterns that span multiple events, which
#    is where the real predictive signal lives.
#
# STEP 3 — BIDIRECTIONAL RNN / ATTENTION
#    A Bidirectional LSTM reads the sequence forwards and backwards,
#    giving richer context at every position.  Adding an attention layer
#    on top lets the model focus on the most anomalous tokens/events
#    and makes predictions interpretable ("the model fired on 'timeout'
#    and 'uncorrectable'").
#
# STEP 4 — TRANSFORMER / LOG-BERT
#    For long log lines and large vocabularies, Transformers outperform
#    RNNs.  LogBERT and Drain-based approaches are purpose-built for
#    log data: they parse free-text into structured templates first, then
#    apply BERT-style pre-training on log corpora.
#    Paper: "LogBERT: Log Anomaly Detection via BERT" (Guo et al., 2021)
#
# STEP 5 — REAL FEATURE ENGINEERING FOR HPE LOGS
#    - Parse structured fields: timestamp, hostname, component, PID,
#      error code, message template (use Drain3 or a regex parser).
#    - Compute rolling statistics: error rate per component per 1/5/15 min,
#      inter-arrival times, burst indicators.
#    - Encode log templates as categorical IDs rather than raw text tokens.
#
# STEP 6 — CLASS IMBALANCE HANDLING
#    Production logs are 99 %+ INFO.  Use:
#      - Weighted loss: nn.MSELoss with sample_weight, or
#        nn.CrossEntropyLoss(weight=class_weights) for classification.
#      - Oversampling rare failure windows (SMOTE on tabular features).
#      - Anomaly-detection framing: train only on normal logs, flag
#        high reconstruction error as anomalous (autoencoder / one-class).
#
# STEP 7 — ONLINE / STREAMING INFERENCE
#    Deploy as a streaming pipeline (Kafka → Flink / Spark Streaming).
#    Maintain a sliding window of the last N events per node in memory.
#    Score each new event incrementally without re-running the full window.
#
# STEP 8 — EXPLAINABILITY FOR ON-CALL ENGINEERS
#    Wrap predictions with SHAP or Integrated Gradients to show which
#    tokens and metadata features contributed most to a high score.
#    This turns a black-box score into an actionable alert:
#    "Score=9.2 driven by: error_count_10min=22, token='uncorrectable',
#     component=StorageCtrl"
