"""
HPE Infrastructure Change Management Knowledge Graph — Population Script
========================================================================
Connects to Neo4j and builds the full knowledge graph representing HPE
server infrastructure, firmware versions, change requests, service contracts,
maintenance windows, and incidents.

Usage:
    python populate_kg.py

Requires:
    - Neo4j instance (local or Aura)
    - .env file with NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD
"""

import json
import os
from neo4j import GraphDatabase
from dotenv import load_dotenv

load_dotenv()

NEO4J_URI      = os.getenv("NEO4J_URI",      "bolt://localhost:7687")
NEO4J_USERNAME = os.getenv("NEO4J_USERNAME", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "password")

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


# ── Helper ─────────────────────────────────────────────────────────────────────

def load_json(filename):
    with open(os.path.join(DATA_DIR, filename)) as f:
        return json.load(f)


# ── Constraints ────────────────────────────────────────────────────────────────

def create_constraints(session):
    print("\n[1/8] Creating uniqueness constraints...")
    constraints = [
        ("Customer",          "id"),
        ("ServiceContract",   "id"),
        ("Server",            "id"),
        ("FirmwareVersion",   "id"),
        ("ChangeRequest",     "id"),
        ("ChangePolicy",      "id"),
        ("MaintenanceWindow", "id"),
        ("Incident",          "id"),
    ]
    for label, prop in constraints:
        session.run(
            f"CREATE CONSTRAINT IF NOT EXISTS "
            f"FOR (n:{label}) REQUIRE n.{prop} IS UNIQUE"
        )
        print(f"   Constraint: {label}.{prop}")


# ── Node Creation ──────────────────────────────────────────────────────────────

def create_customers(session, customers):
    print("\n[2/8] Creating Customer nodes...")
    for c in customers:
        session.run(
            """
            MERGE (cu:Customer {id: $id})
            SET cu.name             = $name,
                cu.industry         = $industry,
                cu.region           = $region,
                cu.contract_id      = $contract_id,
                cu.account_manager  = $account_manager,
                cu.greenlake_tenant = $greenlake_tenant,
                cu.notes            = $notes
            """,
            id=c["id"], name=c["name"], industry=c["industry"],
            region=c["region"], contract_id=c["contract_id"],
            account_manager=c["account_manager"],
            greenlake_tenant=c["greenlake_tenant"],
            notes=c.get("notes", ""),
        )
    print(f"   Created/merged {len(customers)} Customer nodes.")


def create_service_contracts(session, contracts):
    print("\n[3/8] Creating ServiceContract nodes...")
    for sc in contracts:
        session.run(
            """
            MERGE (sc:ServiceContract {id: $id})
            SET sc.name                      = $name,
                sc.tier                      = $tier,
                sc.uptime_sla_percent        = $uptime_sla_percent,
                sc.response_sla_hours        = $response_sla_hours,
                sc.onsite_sla_hours          = $onsite_sla_hours,
                sc.change_notice_hours       = $change_notice_hours,
                sc.dual_approval_required    = $dual_approval_required,
                sc.maintenance_window_required = $mw_required,
                sc.blackout_periods          = $blackout_periods,
                sc.sla_credit_per_hour_usd   = $sla_credit,
                sc.annual_value_usd          = $annual_value,
                sc.notes                     = $notes
            """,
            id=sc["id"], name=sc["name"], tier=sc["tier"],
            uptime_sla_percent=sc["uptime_sla_percent"],
            response_sla_hours=sc["response_sla_hours"],
            onsite_sla_hours=sc["onsite_sla_hours"],
            change_notice_hours=sc["change_notice_hours"],
            dual_approval_required=sc["dual_approval_required"],
            mw_required=sc["maintenance_window_required"],
            blackout_periods=sc["blackout_periods"],
            sla_credit=sc["sla_credit_per_hour_usd"],
            annual_value=sc["annual_value_usd"],
            notes=sc.get("notes", ""),
        )
    print(f"   Created/merged {len(contracts)} ServiceContract nodes.")


def create_servers(session, servers):
    print("\n[4/8] Creating Server nodes...")
    for s in servers:
        session.run(
            """
            MERGE (sv:Server {id: $id})
            SET sv.hostname             = $hostname,
                sv.model                = $model,
                sv.serial_number        = $serial_number,
                sv.customer_id          = $customer_id,
                sv.datacenter           = $datacenter,
                sv.rack                 = $rack,
                sv.criticality_tier     = $criticality_tier,
                sv.role                 = $role,
                sv.os                   = $os,
                sv.ilo_version          = $ilo_version,
                sv.bios_version         = $bios_version,
                sv.greenlake_resource_id = $gl_id,
                sv.notes                = $notes
            """,
            id=s["id"], hostname=s["hostname"], model=s["model"],
            serial_number=s["serial_number"], customer_id=s["customer_id"],
            datacenter=s["datacenter"], rack=s["rack"],
            criticality_tier=s["criticality_tier"], role=s["role"],
            os=s["os"], ilo_version=s["ilo_version"],
            bios_version=s["bios_version"],
            gl_id=s.get("greenlake_resource_id", ""),
            notes=s.get("notes", ""),
        )
    print(f"   Created/merged {len(servers)} Server nodes.")


def create_firmware_versions(session, versions):
    print("\n[5/8] Creating FirmwareVersion nodes...")
    for fw in versions:
        session.run(
            """
            MERGE (fv:FirmwareVersion {id: $id})
            SET fv.component_type        = $component_type,
                fv.component_name        = $component_name,
                fv.version               = $version,
                fv.release_date          = $release_date,
                fv.status                = $status,
                fv.security_advisories   = $security_advisories,
                fv.prerequisite_fw_id    = $prerequisite_fw_id,
                fv.notes                 = $notes
            """,
            id=fw["id"],
            component_type=fw["component_type"],
            component_name=fw["component_name"],
            version=fw["version"],
            release_date=fw["release_date"],
            status=fw["status"],
            security_advisories=fw.get("security_advisories", []),
            prerequisite_fw_id=fw.get("prerequisite_fw_id") or "",
            notes=fw.get("notes", ""),
        )
    print(f"   Created/merged {len(versions)} FirmwareVersion nodes.")


def create_change_policies(session, policies):
    print("\n[6/8] Creating ChangePolicy nodes...")
    for p in policies:
        session.run(
            """
            MERGE (cp:ChangePolicy {id: $id})
            SET cp.name                      = $name,
                cp.contract_tier             = $contract_tier,
                cp.server_criticality_tier   = $server_tier,
                cp.notice_required_hours     = $notice_hours,
                cp.dual_approval_required    = $dual_approval,
                cp.approvers                 = $approvers,
                cp.maintenance_window_required = $mw_required,
                cp.blackout_periods          = $blackout_periods,
                cp.max_change_duration_hours = $max_duration,
                cp.rollback_plan_required    = $rollback_required,
                cp.notes                     = $notes
            """,
            id=p["id"], name=p["name"],
            contract_tier=p["contract_tier"],
            server_tier=p.get("server_criticality_tier"),
            notice_hours=p["notice_required_hours"],
            dual_approval=p["dual_approval_required"],
            approvers=p["approvers"],
            mw_required=p["maintenance_window_required"],
            blackout_periods=", ".join(p["blackout_periods"])
                             if isinstance(p["blackout_periods"], list)
                             else p["blackout_periods"],
            max_duration=p.get("max_change_duration_hours", 8),
            rollback_required=p.get("rollback_plan_required", False),
            notes=p.get("notes", ""),
        )
    print(f"   Created/merged {len(policies)} ChangePolicy nodes.")


def create_maintenance_windows(session, windows):
    print("\n[7/8] Creating MaintenanceWindow nodes...")
    for mw in windows:
        session.run(
            """
            MERGE (mw:MaintenanceWindow {id: $id})
            SET mw.name           = $name,
                mw.type           = $type,
                mw.start_datetime = $start_dt,
                mw.end_datetime   = $end_dt,
                mw.recurrence     = $recurrence,
                mw.status         = $status,
                mw.approved_by    = $approved_by,
                mw.customer_id    = $customer_id,
                mw.notes          = $notes
            """,
            id=mw["id"], name=mw["name"], type=mw["type"],
            start_dt=mw["start_datetime"], end_dt=mw["end_datetime"],
            recurrence=mw["recurrence"], status=mw["status"],
            approved_by=mw["approved_by"],
            customer_id=mw["customer_id"],
            notes=mw.get("notes", ""),
        )
    print(f"   Created/merged {len(windows)} MaintenanceWindow nodes.")


def create_incidents(session, incidents):
    print("\n[8/8] Creating Incident nodes...")
    for inc in incidents:
        session.run(
            """
            MERGE (inc:Incident {id: $id})
            SET inc.severity       = $severity,
                inc.status         = $status,
                inc.title          = $title,
                inc.server_id      = $server_id,
                inc.customer_id    = $customer_id,
                inc.created_date   = $created_date,
                inc.resolved_date  = $resolved_date,
                inc.category       = $category,
                inc.description    = $description,
                inc.notes          = $notes
            """,
            id=inc["id"], severity=inc["severity"], status=inc["status"],
            title=inc["title"], server_id=inc["server_id"],
            customer_id=inc["customer_id"],
            created_date=inc["created_date"],
            resolved_date=inc.get("resolved_date") or "",
            category=inc["category"], description=inc["description"],
            notes=inc.get("notes", ""),
        )
    print(f"   Created/merged {len(incidents)} Incident nodes.")


def create_change_requests(session, change_requests):
    print("\n[+] Creating ChangeRequest nodes...")
    for cr in change_requests:
        session.run(
            """
            MERGE (cr:ChangeRequest {id: $id})
            SET cr.title               = $title,
                cr.change_type         = $change_type,
                cr.component           = $component,
                cr.target_version      = $target_version,
                cr.current_version     = $current_version,
                cr.status              = $status,
                cr.request_date        = $request_date,
                cr.decision_date       = $decision_date,
                cr.urgency             = $urgency,
                cr.submitter           = $submitter,
                cr.decision_notes      = $decision_notes,
                cr.auth_number         = $auth_number,
                cr.server_id           = $server_id,
                cr.customer_id         = $customer_id,
                cr.policy_id           = $policy_id,
                cr.target_firmware_id  = $target_fw_id
            """,
            id=cr["id"], title=cr["title"],
            change_type=cr["change_type"], component=cr["component"],
            target_version=cr.get("target_version") or "",
            current_version=cr.get("current_version") or "",
            status=cr["status"],
            request_date=cr["request_date"],
            decision_date=cr.get("decision_date") or "",
            urgency=cr.get("urgency", "routine"),
            submitter=cr.get("submitter", ""),
            decision_notes=cr.get("decision_notes") or "",
            auth_number=cr.get("auth_number") or "",
            server_id=cr["server_id"],
            customer_id=cr["customer_id"],
            policy_id=cr["policy_id"],
            target_fw_id=cr.get("target_firmware_id") or "",
        )
    print(f"   Created/merged {len(change_requests)} ChangeRequest nodes.")


# ── Relationship Creation ──────────────────────────────────────────────────────

# Mapping: server_id → [(component_type, firmware_id)]
SERVER_FIRMWARE_MAP = {
    "SVR001": [("iLO", "FW002"), ("BIOS", "FW006"), ("Smart Array", "FW008")],
    "SVR002": [("iLO", "FW003"), ("BIOS", "FW006"), ("Smart Array", "FW008")],
    "SVR003": [("iLO", "FW003"), ("BIOS", "FW007")],
    "SVR004": [("iLO", "FW002"), ("BIOS", "FW005")],
    "SVR005": [("iLO", "FW001"), ("BIOS", "FW005")],
    "SVR006": [("iLO", "FW004"), ("BIOS", "FW007")],
    "SVR007": [("iLO", "FW003"), ("BIOS", "FW006")],
    "SVR008": [("iLO", "FW004"), ("BIOS", "FW007")],
    "SVR009": [("iLO", "FW002"), ("BIOS", "FW006")],
    "SVR010": [("iLO", "FW003"), ("BIOS", "FW007")],
}


def create_relationships(session, customers, contracts, servers, firmware,
                         change_requests, policies, windows, incidents):
    print("\n[R] Creating relationships...")

    # Build lookup maps
    contract_map = {sc["id"]: sc for sc in contracts}
    fw_map       = {fw["id"]: fw for fw in firmware}

    # ── Customer → ServiceContract ─────────────────────────────────────────────
    print("   (Customer)-[:HAS_CONTRACT]->(ServiceContract)")
    for cu in customers:
        session.run(
            """
            MATCH (cu:Customer {id: $cid}),
                  (sc:ServiceContract {id: $scid})
            MERGE (cu)-[:HAS_CONTRACT]->(sc)
            """,
            cid=cu["id"], scid=cu["contract_id"],
        )

    # ── Server → Customer ──────────────────────────────────────────────────────
    print("   (Server)-[:BELONGS_TO]->(Customer)")
    for sv in servers:
        session.run(
            """
            MATCH (sv:Server {id: $svid}),
                  (cu:Customer {id: $cid})
            MERGE (sv)-[:BELONGS_TO]->(cu)
            """,
            svid=sv["id"], cid=sv["customer_id"],
        )

    # ── ChangePolicy → ServiceContract ────────────────────────────────────────
    print("   (ChangePolicy)-[:APPLIES_TO]->(ServiceContract)")
    for pol in policies:
        tiers = pol["contract_tier"].split("/")  # handle "Silver/Bronze"
        for tier in tiers:
            tier = tier.strip()
            session.run(
                """
                MATCH (cp:ChangePolicy {id: $pid}),
                      (sc:ServiceContract)
                WHERE sc.tier = $tier OR sc.tier CONTAINS $tier
                MERGE (cp)-[:APPLIES_TO]->(sc)
                """,
                pid=pol["id"], tier=tier,
            )

    # ── FirmwareVersion prerequisite chain ────────────────────────────────────
    print("   (FirmwareVersion)-[:PREREQUISITE_FOR]->(FirmwareVersion)")
    for fw in firmware:
        if fw.get("prerequisite_fw_id"):
            session.run(
                """
                MATCH (prereq:FirmwareVersion {id: $prereq_id}),
                      (target:FirmwareVersion {id: $target_id})
                MERGE (prereq)-[:PREREQUISITE_FOR]->(target)
                """,
                prereq_id=fw["prerequisite_fw_id"], target_id=fw["id"],
            )

    # ── Server → FirmwareVersion (current installed firmware) ─────────────────
    print("   (Server)-[:RUNNING_FIRMWARE {component_type}]->(FirmwareVersion)")
    for svr_id, fw_list in SERVER_FIRMWARE_MAP.items():
        for component_type, fw_id in fw_list:
            session.run(
                """
                MATCH (sv:Server {id: $svid}),
                      (fv:FirmwareVersion {id: $fwid})
                MERGE (sv)-[r:RUNNING_FIRMWARE]->(fv)
                SET r.component_type = $comp_type
                """,
                svid=svr_id, fwid=fw_id, comp_type=component_type,
            )

    # ── ChangeRequest → Server ─────────────────────────────────────────────────
    print("   (ChangeRequest)-[:TARGETS]->(Server)")
    for cr in change_requests:
        session.run(
            """
            MATCH (cr:ChangeRequest {id: $crid}),
                  (sv:Server {id: $svid})
            MERGE (cr)-[:TARGETS]->(sv)
            """,
            crid=cr["id"], svid=cr["server_id"],
        )

    # ── ChangeRequest → Customer ───────────────────────────────────────────────
    print("   (ChangeRequest)-[:FOR_CUSTOMER]->(Customer)")
    for cr in change_requests:
        session.run(
            """
            MATCH (cr:ChangeRequest {id: $crid}),
                  (cu:Customer {id: $cid})
            MERGE (cr)-[:FOR_CUSTOMER]->(cu)
            """,
            crid=cr["id"], cid=cr["customer_id"],
        )

    # ── ChangeRequest → ChangePolicy ──────────────────────────────────────────
    print("   (ChangeRequest)-[:GOVERNED_BY]->(ChangePolicy)")
    for cr in change_requests:
        session.run(
            """
            MATCH (cr:ChangeRequest {id: $crid}),
                  (cp:ChangePolicy {id: $pid})
            MERGE (cr)-[:GOVERNED_BY]->(cp)
            """,
            crid=cr["id"], pid=cr["policy_id"],
        )

    # ── ChangeRequest → FirmwareVersion (target) ──────────────────────────────
    print("   (ChangeRequest)-[:TARGETS_FIRMWARE]->(FirmwareVersion)")
    for cr in change_requests:
        if cr.get("target_firmware_id"):
            session.run(
                """
                MATCH (cr:ChangeRequest {id: $crid}),
                      (fv:FirmwareVersion {id: $fwid})
                MERGE (cr)-[:TARGETS_FIRMWARE]->(fv)
                """,
                crid=cr["id"], fwid=cr["target_firmware_id"],
            )

    # ── ChangeRequest → MaintenanceWindow ─────────────────────────────────────
    print("   (ChangeRequest)-[:SCHEDULED_IN]->(MaintenanceWindow)")
    for cr in change_requests:
        if cr.get("maintenance_window_id"):
            session.run(
                """
                MATCH (cr:ChangeRequest {id: $crid}),
                      (mw:MaintenanceWindow {id: $mwid})
                MERGE (cr)-[:SCHEDULED_IN]->(mw)
                """,
                crid=cr["id"], mwid=cr["maintenance_window_id"],
            )

    # ── Server → MaintenanceWindow ─────────────────────────────────────────────
    print("   (Server)-[:IN_MAINTENANCE_WINDOW]->(MaintenanceWindow)")
    for mw in windows:
        for svr_id in mw.get("servers_included", []):
            session.run(
                """
                MATCH (sv:Server {id: $svid}),
                      (mw:MaintenanceWindow {id: $mwid})
                MERGE (sv)-[:IN_MAINTENANCE_WINDOW]->(mw)
                """,
                svid=svr_id, mwid=mw["id"],
            )

    # ── MaintenanceWindow → Customer ───────────────────────────────────────────
    print("   (MaintenanceWindow)-[:OWNED_BY]->(Customer)")
    for mw in windows:
        session.run(
            """
            MATCH (mw:MaintenanceWindow {id: $mwid}),
                  (cu:Customer {id: $cid})
            MERGE (mw)-[:OWNED_BY]->(cu)
            """,
            mwid=mw["id"], cid=mw["customer_id"],
        )

    # ── Incident → Server ──────────────────────────────────────────────────────
    print("   (Incident)-[:AFFECTS]->(Server)")
    for inc in incidents:
        session.run(
            """
            MATCH (inc:Incident {id: $incid}),
                  (sv:Server {id: $svid})
            MERGE (inc)-[:AFFECTS]->(sv)
            """,
            incid=inc["id"], svid=inc["server_id"],
        )

    # ── Incident → ChangeRequest (blocks) ─────────────────────────────────────
    print("   (Incident)-[:BLOCKS]->(ChangeRequest)")
    for inc in incidents:
        for cr_id in inc.get("blocks_change_requests", []):
            session.run(
                """
                MATCH (inc:Incident {id: $incid}),
                      (cr:ChangeRequest {id: $crid})
                MERGE (inc)-[:BLOCKS]->(cr)
                """,
                incid=inc["id"], crid=cr_id,
            )

    print("   All relationships created.")


# ── Summary ────────────────────────────────────────────────────────────────────

def print_summary(session):
    print("\n" + "=" * 62)
    print("  HPE INFRASTRUCTURE KG — POPULATION SUMMARY")
    print("=" * 62)

    node_types = [
        "Customer", "ServiceContract", "Server", "FirmwareVersion",
        "ChangeRequest", "ChangePolicy", "MaintenanceWindow", "Incident",
    ]
    total_nodes = 0
    for label in node_types:
        result = session.run(f"MATCH (n:{label}) RETURN count(n) AS cnt")
        cnt = result.single()["cnt"]
        total_nodes += cnt
        print(f"  {label:<22} {cnt:>4} nodes")

    print(f"\n  {'TOTAL NODES':<22} {total_nodes:>4}")

    rel_result = session.run("MATCH ()-[r]->() RETURN count(r) AS cnt")
    total_rels = rel_result.single()["cnt"]
    print(f"  {'TOTAL RELATIONSHIPS':<22} {total_rels:>4}")

    print("\n  Relationship types:")
    rel_type_result = session.run(
        "MATCH ()-[r]->() RETURN type(r) AS rel_type, count(r) AS cnt "
        "ORDER BY cnt DESC"
    )
    for record in rel_type_result:
        print(f"    {record['rel_type']:<36} {record['cnt']:>3}")

    print("=" * 62)
    print("  Graph is ready — run: python app.py")
    print("=" * 62)


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    print("=" * 62)
    print("  HPE Infrastructure KG — Population Script")
    print("=" * 62)
    print(f"\n  Connecting to Neo4j at: {NEO4J_URI}")

    try:
        driver = GraphDatabase.driver(
            NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD)
        )
        driver.verify_connectivity()
        print("  Connected successfully!\n")
    except Exception as e:
        print(f"\n  ERROR: Could not connect to Neo4j.")
        print(f"  Details: {e}")
        print("\n  Please check:")
        print("  1. Neo4j is running (local) or your Aura URI is correct")
        print("  2. .env has correct NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD")
        return

    print("  Loading data files from ./data/ ...")
    customers        = load_json("customers.json")
    contracts        = load_json("service_contracts.json")
    servers          = load_json("servers.json")
    firmware         = load_json("firmware_versions.json")
    change_requests  = load_json("change_requests.json")
    policies         = load_json("change_policies.json")
    windows          = load_json("maintenance_windows.json")
    incidents        = load_json("incidents.json")

    print(f"  Loaded: {len(customers)} customers, {len(contracts)} contracts, "
          f"{len(servers)} servers, {len(firmware)} firmware versions")
    print(f"          {len(change_requests)} change requests, {len(policies)} policies, "
          f"{len(windows)} maintenance windows, {len(incidents)} incidents")

    with driver.session() as session:
        # Uncomment to wipe and restart:
        # session.run("MATCH (n) DETACH DELETE n")

        create_constraints(session)
        create_customers(session, customers)
        create_service_contracts(session, contracts)
        create_servers(session, servers)
        create_firmware_versions(session, firmware)
        create_change_policies(session, policies)
        create_maintenance_windows(session, windows)
        create_incidents(session, incidents)
        create_change_requests(session, change_requests)

        create_relationships(
            session, customers, contracts, servers, firmware,
            change_requests, policies, windows, incidents,
        )

        print_summary(session)

    driver.close()
    print("\n  Done! Knowledge graph populated successfully.")


if __name__ == "__main__":
    main()
