"""
Neo4j Database Cleaner
======================
Deletes ALL nodes, relationships, indexes, and constraints from the database.

Usage:
    python clear_db.py          # prompts for confirmation
    python clear_db.py --yes    # skips confirmation prompt
"""

import os
import sys
from dotenv import load_dotenv

load_dotenv()

_REQUIRED = ("NEO4J_URI", "NEO4J_USERNAME", "NEO4J_PASSWORD")
_missing = [v for v in _REQUIRED if not os.getenv(v)]
if _missing:
    print("ERROR: Missing required .env variables:", ", ".join(_missing))
    sys.exit(1)

NEO4J_URI      = os.environ["NEO4J_URI"]
NEO4J_USERNAME = os.environ["NEO4J_USERNAME"]
NEO4J_PASSWORD = os.environ["NEO4J_PASSWORD"]

try:
    from neo4j import GraphDatabase
    from neo4j.exceptions import Neo4jError
except ImportError:
    print("ERROR: neo4j package not installed. Run: pip install neo4j")
    sys.exit(1)

# ── Confirmation ──────────────────────────────────────────────────────────────

auto_yes = "--yes" in sys.argv
if not auto_yes:
    print(f"\n  Target : {NEO4J_URI}")
    print("  Action : DELETE ALL nodes, relationships, indexes, and constraints\n")
    answer = input("  This cannot be undone. Type 'yes' to continue: ").strip().lower()
    if answer != "yes":
        print("  Aborted.")
        sys.exit(0)

# ── Connect ───────────────────────────────────────────────────────────────────

driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))
try:
    driver.verify_connectivity()
except Exception as e:
    print(f"ERROR: Cannot connect to Neo4j: {e}")
    sys.exit(1)

def run(session, cypher, description):
    try:
        session.run(cypher)
        print(f"  ✓  {description}")
    except Neo4jError as e:
        print(f"  ⚠  {description} — {e.message}")

# ── Drop indexes ──────────────────────────────────────────────────────────────

print("\nDropping indexes...")
with driver.session() as session:
    result = session.run("SHOW INDEXES YIELD name, type WHERE type <> 'LOOKUP'")
    index_names = [row["name"] for row in result]

with driver.session() as session:
    for name in index_names:
        run(session, f"DROP INDEX `{name}` IF EXISTS", f"Dropped index '{name}'")
    if not index_names:
        print("  ℹ  No user-defined indexes found")

# ── Drop constraints ──────────────────────────────────────────────────────────

print("\nDropping constraints...")
with driver.session() as session:
    result = session.run("SHOW CONSTRAINTS YIELD name")
    constraint_names = [row["name"] for row in result]

with driver.session() as session:
    for name in constraint_names:
        run(session, f"DROP CONSTRAINT `{name}` IF EXISTS", f"Dropped constraint '{name}'")
    if not constraint_names:
        print("  ℹ  No constraints found")

# ── Delete all nodes and relationships ───────────────────────────────────────

print("\nDeleting nodes and relationships...")
with driver.session() as session:
    # Count before deletion
    total = session.run("MATCH (n) RETURN count(n) AS c").single()["c"]
    rel_total = session.run("MATCH ()-[r]->() RETURN count(r) AS c").single()["c"]
    print(f"  ℹ  Found {total} nodes and {rel_total} relationships")

    # Delete in batches to avoid heap exhaustion on large graphs
    deleted = 0
    batch_size = 10_000
    while True:
        result = session.run(
            "MATCH (n) WITH n LIMIT $batch "
            "DETACH DELETE n RETURN count(n) AS c",
            batch=batch_size,
        )
        count = result.single()["c"]
        deleted += count
        if count > 0:
            print(f"  ✓  Deleted batch of {count} nodes (total so far: {deleted})")
        if count < batch_size:
            break

    remaining = session.run("MATCH (n) RETURN count(n) AS c").single()["c"]
    if remaining == 0:
        print(f"  ✓  All nodes and relationships deleted")
    else:
        print(f"  ⚠  {remaining} nodes still remain — re-run the script")

driver.close()

print("\n══════════════════════════════════════════════")
print("  Database cleared successfully.")
print("══════════════════════════════════════════════\n")
