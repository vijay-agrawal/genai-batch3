# KG-RAG Demo: Healthcare Prior Authorization Management

A Knowledge Graph + RAG (Retrieval Augmented Generation) demonstration for
the AWS GenAI Training Course, using a healthcare prior authorization use case
to show how knowledge graphs enable multi-hop reasoning that traditional vector
search cannot achieve.

---

## Why Knowledge Graphs for Healthcare Prior Authorization?

Prior authorization (PA) is one of the most document-intensive, rule-driven
processes in healthcare. A single PA decision requires reasoning across multiple
interconnected data entities:

- **Patient** → diagnosis → treatment history
- **Insurance plan** → formulary → coverage rules → step therapy requirements
- **Provider** → in-network status → specialty credentials
- **Claim history** → step therapy proof → prior treatment failures

A traditional vector/RAG approach can retrieve relevant policy text, but **cannot
answer** questions like: _"Is Ozempic covered for John Martinez given his current
plan, A1C value, Metformin history, and provider's specialty?"_ This requires
traversing 6+ hops across a graph — exactly what Neo4j excels at.

Knowledge graphs excel here because:
1. **Relationships are first-class** — "step therapy before," "covered by,"
   "in-network for" are explicit edges, not buried in text
2. **Multi-hop queries are fast** — Cypher traverses connections in milliseconds
3. **Completeness is guaranteed** — you can't miss a coverage rule that's stored
   as a node with an edge to a plan
4. **Auditability** — the reasoning path through the graph is traceable

### What "6+ hops" means

In a property graph, a **hop** is one traversal along a relationship edge from
one node to another. To answer _"Is Ozempic covered for John Martinez?"_ you
must link these nodes in sequence:

```
Patient (John Martinez)
  └─[HAS_DIAGNOSIS]──► Diagnosis (Type 2 Diabetes / E11.9)      ← hop 1
       └─[TREATED_WITH]──► Medication (Metformin)               ← hop 2
            └─[STEP_THERAPY_BEFORE]──► Medication (Ozempic)     ← hop 3
                 └─[GOVERNS]──◄ CoverageRule (A1C ≥ 7.0 req.)  ← hop 4
                      └─[BELONGS_TO_PLAN]──► InsurancePlan      ← hop 5
                           └─[IN_NETWORK_FOR]──◄ Provider       ← hop 6
```

All 6 relationships must hold simultaneously — the answer only emerges by
walking the full path.

**Why vector RAG fails here:** A vector store might retrieve the policy text
saying "Ozempic requires a prior Metformin trial," but it cannot:
- Verify whether John's claims actually show a completed Metformin trial
- Check whether his A1C value meets the numeric threshold
- Confirm his provider is in-network for his specific plan
- Chain all these conditions together as a logical AND

**Why graphs handle this natively:** Cypher traverses all 6 hops in one query:

```cypher
MATCH (pt:Patient {name: 'John Martinez'})
      -[:HAS_DIAGNOSIS]->(dx:Diagnosis)
      -[:TREATED_WITH]->(prior:Medication)
      -[:STEP_THERAPY_BEFORE]->(ozempic:Medication {name: 'Ozempic'})
      <-[:GOVERNS]-(rule:CoverageRule)
      <-[:BELONGS_TO_PLAN]-(plan:InsurancePlan)
      <-[:COVERED_BY]-(pt)
WHERE pt.a1c >= rule.min_a1c_threshold
RETURN pt.name, ozempic.name, rule.criteria, plan.name
```

The graph engine follows edges directly — no join explosion, no embedding
similarity threshold to tune, no missing data because a relevant chunk wasn't
retrieved. The answer is either there or it isn't.

---

## Architecture

```
User Question (natural language)
        │
        ▼
┌─────────────────────────────┐
│   Amazon Bedrock (Claude)   │  ← NL2Cypher: converts question to Cypher
│   NL → Cypher Query         │
└─────────────────────────────┘
        │  Cypher Query
        ▼
┌─────────────────────────────┐
│   Neo4j Knowledge Graph     │  ← Executes query, returns structured data
│   (Prior Auth Graph)        │
└─────────────────────────────┘
        │  Query Results (JSON)
        ▼
┌─────────────────────────────┐
│   Amazon Bedrock (Claude)   │  ← Reasoning: interprets results, forms answer
│   Results → Human Answer    │
└─────────────────────────────┘
        │
        ▼
   Final Answer (clinical context + insurance context)
```

---

## Graph Schema

```
                    ┌─────────────┐
                    │InsurancePlan│
                    └──────┬──────┘
                  COVERED_BY│  ↑IN_NETWORK_FOR
                            │  │BELONGS_TO_PLAN
         ┌──────────────────┼──┼──────────────────┐
         │                  │  │                  │
    ┌────▼────┐      ┌──────▼──┴───┐       ┌──────┴──────┐
    │ Patient │      │  Provider   │       │CoverageRule │
    └────┬────┘      └──────┬──────┘       └──────┬──────┘
         │HAS_DIAGNOSIS     │TREATS               │GOVERNS
         │                  │SUBMITTED_BY         │
    ┌────▼─────┐    ┌───────▼──────┐    ┌─────────▼──────┐
    │Diagnosis │    │    Claim     │    │  Medication    │
    └────┬─────┘    └───────┬──────┘    └────────────────┘
TREATED_WITH│    FOR_PROCEDURE│                    ↑
    TREATED_BY│    FOR_MEDICATION│    STEP_THERAPY_BEFORE
         │                  │                    │
    ┌────▼─────┐    ┌────────▼─────┐    ┌─────────┴──────┐
    │Procedure │    │PriorAuthReq  │    │  Medication    │
    └──────────┘    └──────────────┘    └────────────────┘
                       FOR_PATIENT ──► Patient
                       UNDER_PLAN  ──► InsurancePlan
```

**Node Types (9):** Patient, Provider, InsurancePlan, Diagnosis, Procedure,
Medication, Claim, PriorAuthRequest, CoverageRule

**Relationship Types (15):** COVERED_BY, HAS_DIAGNOSIS, IN_NETWORK_FOR, TREATS,
FOR_PATIENT, SUBMITTED_BY, FOR_PROCEDURE, FOR_MEDICATION, UNDER_PLAN,
REQUESTS_PROCEDURE, REQUESTS_MEDICATION, GOVERNS, BELONGS_TO_PLAN,
TREATED_BY, TREATED_WITH, STEP_THERAPY_BEFORE

---

## Dataset

| Entity              | Count | Details                                      |
|---------------------|-------|----------------------------------------------|
| Patients            | 8     | Diverse conditions: T2D, cancer, RA, COPD... |
| Providers           | 8     | PCP, Endocrinologist, Oncologist, Surgeon... |
| Insurance Plans     | 4     | BlueCross PPO, Aetna HMO, United PPO, Cigna  |
| Diagnoses (ICD-10)  | 10    | E11.9, C50.912, M17.11, K50.90, I48.91...   |
| Procedures (CPT)    | 8     | Knee replacement, Chemo, PT, MRI, ECG...     |
| Medications         | 10    | Ozempic, Keytruda, Humira, Stelara, Eliquis..|
| Claims              | 15    | Mix of PAID/DENIED/PENDING with rich notes   |
| Prior Auth Requests | 10    | APPROVED/DENIED/PENDING with clinical detail |
| Coverage Rules      | 8     | Step therapy, prior auth criteria per plan   |

---

## Setup Instructions

### Prerequisites

- Python 3.11+
- Neo4j instance (Aura free tier OR local Neo4j Desktop)
- AWS account with Bedrock access (Claude claude-sonnet-4-6 enabled)

### Step 1: Clone and install dependencies

```bash
cd kg-rag/
pip install -r requirements.txt
```

### Step 2: Set up Neo4j (Aura Free Tier - Recommended)

1. Go to [https://console.neo4j.io](https://console.neo4j.io)
2. Create a free AuraDB instance
3. Download the credentials file (or note the URI, username, password)
4. The URI looks like: `neo4j+s://xxxxxxxx.databases.neo4j.io`

For local Neo4j Desktop:
1. Download from [https://neo4j.com/download/](https://neo4j.com/download/)
2. Create a new database, set a password
3. URI is: `bolt://localhost:7687`

### Step 3: Configure environment

```bash
cp .env.example .env
```

Edit `.env`:
```
NEO4J_URI=neo4j+s://your-instance.databases.neo4j.io
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=your-password
AWS_DEFAULT_REGION=us-east-1
```

**IMPORTANT**
If you are seeing connection issues, skip ssl certificate validation by changing
neo4j:s to neo4j:ssc

NEO4J_URI="neo4j+ssc://c2975ddb.databases.neo4j.io"


### Step 4: Enable Claude in Amazon Bedrock

1. Open AWS Console → Amazon Bedrock → Model Access
2. Request access to **Anthropic Claude claude-sonnet-4-6** (us-east-1 region)
3. Ensure your IAM user/role has `bedrock:InvokeModel` permission

### Step 5: Populate the Knowledge Graph

```bash
python populate_kg.py
```

Expected output:
```
  Healthcare Prior Auth KG - Population Script
  Connected to Neo4j successfully!
  [1/9] Creating uniqueness constraints...
  [2/9] Creating Patient nodes... Created/merged 8 Patient nodes.
  ...
  KNOWLEDGE GRAPH POPULATION SUMMARY
  Patient                   8 nodes
  Provider                  8 nodes
  InsurancePlan             4 nodes
  Diagnosis                10 nodes
  Procedure                 8 nodes
  Medication               10 nodes
  Claim                    15 nodes
  PriorAuthRequest         10 nodes
  CoverageRule              8 nodes
  TOTAL NODES              81
  TOTAL RELATIONSHIPS      ~120
```

### Step 6: Run the KG-RAG Application

```bash
python app.py
```

---

## Sample Q&A - Demonstrating KG Power

### Question 1: Multi-hop Coverage Reasoning

**Q:** "What step therapy was required before Emily Johnson could get Humira approved?"

**Generated Cypher:**
```cypher
MATCH (pt:Patient {name: 'Emily Johnson'})
MATCH (par:PriorAuthRequest)-[:FOR_PATIENT]->(pt)
MATCH (par)-[:REQUESTS_MEDICATION]->(m:Medication)
OPTIONAL MATCH (prereq:Medication)-[:STEP_THERAPY_BEFORE]->(m)
OPTIONAL MATCH (c:Claim)-[:FOR_PATIENT]->(pt)
OPTIONAL MATCH (c)-[:FOR_MEDICATION]->(prereq)
RETURN pt.name AS patient, m.name AS requested_medication,
       par.status AS pa_status, prereq.name AS prerequisite_drug,
       c.status AS prerequisite_claim_status, c.date AS treatment_date
LIMIT 10
```

**Answer:** Emily Johnson was approved for Humira (PA003). The step therapy
required her to first complete a 3-month trial of **Methotrexate** (the
conventional DMARD prerequisite). Claim CLM009 (September 2023) and CLM010
(January 2024) confirm 4 months of paid Methotrexate claims with documented
inadequate response (DAS28 remained 5.8). This satisfied BlueCross's step
therapy requirement, leading to approval on February 7, 2024.

---

### Question 2: Why Was a PA Denied?

**Q:** "Why was David Kim's prior auth request denied?"

**Generated Cypher:**
```cypher
MATCH (pt:Patient)-[:HAS_DIAGNOSIS]->(dx:Diagnosis)
WHERE pt.name CONTAINS 'Kim'
MATCH (par:PriorAuthRequest)-[:FOR_PATIENT]->(pt)
MATCH (par)-[:REQUESTS_MEDICATION]->(m:Medication)
MATCH (par)-[:UNDER_PLAN]->(ip:InsurancePlan)
OPTIONAL MATCH (prereq:Medication)-[:STEP_THERAPY_BEFORE]->(m)
RETURN pt.name AS patient, dx.description AS diagnosis,
       m.name AS requested_med, par.status AS status,
       par.decision_notes AS denial_reason, ip.name AS plan,
       prereq.name AS required_step_therapy
LIMIT 5
```

**Answer:** David Kim's request for Stelara (ustekinumab) was **DENIED** by
Aetna HMO Select. The reason: step therapy not satisfied. Aetna requires a
12-week trial of an anti-TNF biologic (Humira or Remicade) before covering
Stelara for Crohn's Disease. David had only been managed with corticosteroids —
no prior biologic claim history existed. The graph shows the step therapy chain:
**Humira → Stelara**, meaning Humira must be tried first.

---

### Question 3: Pending Requests with Context

**Q:** "What prior authorization requests are currently pending for BlueCross Premier PPO?"

**Answer:** Two requests are pending under BlueCross Premier PPO:
- **Robert Williams** (PA002): Knee replacement (CPT 27447) pending since March
  10, 2024. Missing: complete PT records showing 20+ sessions over 6 months.
  Only 16 sessions over 4 months documented so far.
- **Linda Thompson** (PA006): Dupixent pending since February 20, 2024. Awaiting:
  blood eosinophil count (must be ≥300 cells/µL) and 12-month exacerbation history
  from hospital records.

---

## Educational Notes: The NL2Cypher Pipeline

### Why Cypher?

Cypher is Neo4j's declarative query language for graph databases. Unlike SQL,
Cypher uses ASCII-art pattern matching that mirrors how humans think about
relationships:

```cypher
-- "Find patients covered by BlueCross who have pending prior auth requests"
MATCH (pt:Patient)-[:COVERED_BY]->(ip:InsurancePlan)
WHERE ip.name CONTAINS 'BlueCross'
MATCH (par:PriorAuthRequest)-[:FOR_PATIENT]->(pt)
WHERE par.status = 'PENDING'
RETURN pt.name, par.id, par.item_code, par.request_date
```

### The Three LLM Calls

1. **NL2Cypher (Temperature = 0.0):** Deterministic, precise translation.
   The LLM receives the full graph schema and converts the question to Cypher.
   Low temperature ensures consistent, correct syntax.

2. **Cypher Execution:** Neo4j runs the query against the live graph.
   Results are structured JSON records — not text, not embeddings.

3. **Reasoning (Temperature = 0.2):** The LLM receives the question + raw data
   and generates a human-readable, contextually rich answer. Slightly higher
   temperature allows natural language variation.

### Why KG-RAG beats plain RAG for this use case

| Capability                          | Vector RAG | KG-RAG |
|-------------------------------------|------------|--------|
| Multi-hop reasoning (6+ nodes)      | No         | Yes    |
| Exact match (member ID, ICD code)   | Weak       | Yes    |
| Relationship traversal              | No         | Yes    |
| Step therapy chain verification     | No         | Yes    |
| Structured answer from structured data | No      | Yes    |
| Semantic document search            | Yes        | No*    |

*KG-RAG + Vector RAG combined (hybrid) gives the best of both worlds: the
clinical notes and policy documents can be stored in a vector store while the
structured relationships live in the graph.
