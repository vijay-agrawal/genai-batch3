# KG-RAG Demo: HPE Infrastructure Change Management

A Knowledge Graph + RAG demonstration for the HPE Engineering GenAI Training,
using HPE server firmware and change request management to show how knowledge
graphs enable multi-hop reasoning that traditional vector search cannot achieve.

---

## The Core Problem: Infrastructure Change Authorization

Every HPE field engineer knows this scenario: a customer wants a firmware update
pushed tonight. But answering "can this change be approved?" requires reasoning
across multiple interconnected systems simultaneously:

- **Server** → criticality tier → customer SLA tier
- **Firmware target** → prerequisite version chain → current installed version
- **Change policy** → notice period requirement → maintenance window availability
- **Open incidents** → do any block this change?
- **Approval chain** → dual approval required? Who has signed?

A single wrong answer at any hop can mean an SLA breach, a failed flash that
bricks a production server, or a compliance violation at a government customer.

---

## Why Vector RAG Fails Here — and KG Excels

### The Classic Failure Mode

A vector store can retrieve the policy document saying:
> *"iLO firmware updates require the previous minor version as a prerequisite"*

But it **cannot**:
1. Look up which version is currently installed on `jpl-mission-compute-01`
2. Verify whether an active incident on that server blocks the change
3. Check whether there is a maintenance window available before the next mission phase
4. Confirm the 96-hour notice requirement for JPL government compliance
5. Chain all five conditions together as a logical AND to give a single decision

This is exactly what the knowledge graph does natively in milliseconds.

### The "Firmware Step Therapy" Analogy

Just as healthcare insurance requires step therapy before approving an expensive
biologic (try Metformin before Ozempic), HPE firmware has **mandatory sequential
upgrade paths**:

```
iLO UPGRADE CHAIN — cannot skip versions:
  2.55 ──[PREREQUISITE_FOR]──► 2.65
  2.65 ──[PREREQUISITE_FOR]──► 2.72  ← CVE-2023-28082 patch
  2.72 ──[PREREQUISITE_FOR]──► 2.80  ← latest recommended

BIOS UPGRADE CHAIN:
  UEFI 2.10 ──[PREREQUISITE_FOR]──► 2.30
  UEFI 2.30 ──[PREREQUISITE_FOR]──► 2.54

SMART ARRAY P840ar:
  v7.00 ──[PREREQUISITE_FOR]──► v8.00
```

A request to jump `chevron-seismic-01` from iLO **2.55 directly to 2.80** was
denied (CR003) because 2 intermediate versions were skipped. The graph reveals
the full required path in a single Cypher traversal.

### 6-Hop Reasoning: "Can CR007 Be Approved Tonight?"

```
ChangeRequest (CR007)
  └─[TARGETS]──────────────► Server (jpl-mission-compute-01)          ← hop 1
       └─[BELONGS_TO]──────► Customer (NASA JPL)                      ← hop 2
            └─[HAS_CONTRACT]► ServiceContract (Platinum)              ← hop 3
       └─[RUNNING_FIRMWARE]► FirmwareVersion (iLO 2.65)               ← hop 4
            └─[PREREQUISITE_FOR]──► iLO 2.72 (NOT installed → BLOCKED) ← hop 5
  └─[BLOCKS]◄─────────────── Incident INC006 (Fan failure, OPEN)      ← hop 6
```

**All 6 must hold simultaneously.** The answer only emerges by walking the full
path — exactly what a property graph does natively.

**Why vector RAG fails here:** A vector store might retrieve:
- The change policy text about 96-hour notice requirements
- The firmware release notes about prerequisite versions

But it cannot verify in real-time:
- Whether iLO 2.72 is actually installed on this specific server
- Whether INC006 is still open or was resolved
- Whether a maintenance window exists in the required timeframe
- Chain all conditions together as a logical AND for a final decision

---

## Architecture

```
User Question (natural language)
        │
        ▼
┌─────────────────────────────────┐
│   Amazon Bedrock (Nova/Claude)  │  ← NL2Cypher: question → Cypher
│   NL → Cypher Query (temp=0.0) │     Schema injected into system prompt
└─────────────────────────────────┘
        │  Cypher Query
        ▼
┌─────────────────────────────────┐
│   Neo4j Knowledge Graph         │  ← Executes multi-hop graph query
│   (HPE Infrastructure Graph)   │     Returns structured JSON records
└─────────────────────────────────┘
        │  Structured Query Results
        ▼
┌─────────────────────────────────┐
│   Amazon Bedrock (Nova/Claude)  │  ← Reasoning: interprets results,
│   Results → Human Answer (0.2) │     forms actionable HPE answer
└─────────────────────────────────┘
        │
        ▼
   Final Answer (change decision + operational context)
```

---

## Graph Schema

```
                    ┌──────────────────┐
                    │  ServiceContract  │ (SLA tier, notice hours, approvals)
                    └────────┬─────────┘
              HAS_CONTRACT ↑ │ ↑ APPLIES_TO
                            │ │
              ┌─────────────┴─┴──────────────┐
              │                              │
         ┌────▼────┐                  ┌──────▼──────┐
         │Customer │                  │ChangePolicy │
         └────┬────┘                  └──────┬──────┘
     BELONGS_TO│                     GOVERNED_BY│
               │                              │
         ┌─────▼─────┐    TARGETS    ┌────────▼────────┐
         │  Server   │◄──────────────│  ChangeRequest  │
         └─────┬─────┘               └────────┬────────┘
 RUNNING_FIRMWARE│  IN_MAINTENANCE_WINDOW│   SCHEDULED_IN│  TARGETS_FIRMWARE│
               │                │             │              │
  ┌────────────▼───┐    ┌───────▼──────┐  ┌──▼──────────┐  │
  │FirmwareVersion │    │Maintenance   │  │(same MW node)│  │
  │  (iLO/BIOS/SA) │    │  Window      │  └─────────────┘  │
  └────────────┬───┘    └──────────────┘                   │
  PREREQUISITE_FOR│                          ┌──────────────▼──┐
               │                            │ FirmwareVersion │
  ┌────────────▼───┐    AFFECTS   ┌─────────┤ (target version)│
  │FirmwareVersion │    BLOCKS    │Incident │ └────────────────┘
  │  (next version)│◄─────────────┤(P1/P2/P3│
  └────────────────┘              └─────────┘
```

**Node Types (8):** Server, Customer, ServiceContract, FirmwareVersion,
ChangeRequest, ChangePolicy, MaintenanceWindow, Incident

**Relationship Types (14):** BELONGS_TO, HAS_CONTRACT, APPLIES_TO,
RUNNING_FIRMWARE, PREREQUISITE_FOR, TARGETS, FOR_CUSTOMER, GOVERNED_BY,
TARGETS_FIRMWARE, SCHEDULED_IN, IN_MAINTENANCE_WINDOW, OWNED_BY, AFFECTS, BLOCKS

---

## Dataset

| Entity             | Count | Details                                               |
|--------------------|-------|-------------------------------------------------------|
| Customers          | 6     | Goldman Sachs, Mayo Clinic, Chevron, UT, NASA JPL, HPE|
| Service Contracts  | 4     | Platinum, Gold, Silver, Bronze                        |
| Servers            | 10    | ProLiant DL380/DL360/DL20, Synergy 480, Superdome Flex|
| Firmware Versions  | 9     | iLO (4 versions), BIOS/UEFI (3), Smart Array (2)     |
| Change Requests    | 14    | Mix of APPROVED/DENIED/PENDING with rich context      |
| Change Policies    | 6     | POL001–POL006 covering all SLA tiers + emergency/govt |
| Maintenance Windows| 8     | Completed + upcoming, regular + emergency             |
| Incidents          | 8     | P1/P2/P3 mix, OPEN and RESOLVED, some blocking CRs   |

---

## HPE Use Cases: Where KG Beats Other Approaches

### Use Case 1: Firmware Compliance Auditing

**Question:** *"Which servers are still vulnerable to CVE-2023-28082?"*

Vector RAG retrieves the advisory text but cannot cross-reference which specific
servers are running the vulnerable version AND haven't had an approved patch
applied. The graph traverses: CVE in FirmwareVersion.security_advisories →
which servers RUNNING_FIRMWARE that version → which lack an APPROVED ChangeRequest
TARGETS_FIRMWARE to a patched version.

**Finding:** `finance-prod-db-01` (SVR001) is still at iLO 2.65 despite
`finance-prod-app-01` being patched in February.

### Use Case 2: Change Request Triage

**Question:** *"What is blocking CR007 from approval?"*

The graph reveals **all 5 blockers simultaneously** in one query — active incident,
missing prerequisite firmware, no maintenance window, insufficient notice period,
and missing CAB review. Vector RAG would require 5 separate searches with no
guarantee of completeness.

### Use Case 3: Upgrade Path Navigation

**Question:** *"What sequential updates does chevron-seismic-01 need to reach iLO 2.80?"*

```cypher
MATCH (sv:Server {hostname: 'chevron-seismic-01'})
MATCH (sv)-[r:RUNNING_FIRMWARE]->(current:FirmwareVersion)
WHERE r.component_type = 'iLO'
MATCH path = (current)-[:PREREQUISITE_FOR*]->(target:FirmwareVersion {version: '2.80'})
RETURN [n IN nodes(path) | n.version] AS upgrade_path
```

Returns: `["2.55", "2.65", "2.72", "2.80"]` — the exact ordered sequence,
verified against live graph state.

### Use Case 4: SLA Risk Analysis

**Question:** *"Which OPEN incidents affect Platinum SLA customers?"*

Traversal: Incident (OPEN) → AFFECTS → Server → BELONGS_TO → Customer →
HAS_CONTRACT → ServiceContract (Platinum). No text similarity required —
pure relationship traversal with precise answers.

### Use Case 5: CI/CD Firmware Validation Pipeline Integration

For DevOps engineers: the same NL2Cypher pipeline can be called programmatically
to gate firmware deployment pipelines. Before pushing a firmware update to a
server fleet, query the graph to validate prerequisite chains, policy compliance,
and active incident status — before a single flash is attempted.

---

## KG vs. RAG vs. SQL Comparison

| Capability                              | Vector RAG | SQL/RDBMS | KG-RAG   |
|-----------------------------------------|------------|-----------|----------|
| Multi-hop traversal (6+ entities)       | No         | Complex   | Native   |
| Prerequisite chain discovery            | No         | Recursive | Native   |
| Simultaneous multi-condition blocking   | No         | Possible  | Native   |
| Natural language → structured query     | Partial    | No        | Yes (LLM)|
| Semantic policy document search         | Yes        | No        | No*      |
| Schema-free relationship exploration    | No         | No        | Yes      |
| Real-time compliance verification       | No         | Partial   | Yes      |
| Explainable reasoning path              | No         | Partial   | Yes      |
| Exact match on IDs, versions, hostnames | Weak       | Yes       | Yes      |

*KG + Vector RAG hybrid gives the best of both worlds: structured relationships in
the graph, unstructured runbook/policy text in a vector store. The text files in
`data/` illustrate what the vector component would contain.

---

## Setup Instructions

### Prerequisites

- Python 3.11+
- Neo4j instance (Aura free tier OR local Neo4j Desktop)
- AWS account with Amazon Bedrock access (Nova Micro or Claude enabled)

### Step 1: Install dependencies

```bash
cd kg-rag-neo4j/
pip install -r requirements.txt
```

### Step 2: Set up Neo4j

**Option A — Aura Free Tier (recommended for demos):**
1. Go to [https://console.neo4j.io](https://console.neo4j.io)
2. Create a free AuraDB instance
3. Note the URI (format: `neo4j+s://xxxxxxxx.databases.neo4j.io`)

**Option B — Local Neo4j Desktop:**
1. Download from [https://neo4j.com/download/](https://neo4j.com/download/)
2. Create a database, set a password
3. URI: `bolt://localhost:7687`

### Step 3: Configure environment

```bash
cp .env.example .env
```

Edit `.env`:
```
NEO4J_URI=neo4j+s://your-instance.databases.neo4j.io
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=your-password
AWS_DEFAULT_REGION=us-east-1
```

> **SSL issues?** Change `neo4j+s://` to `neo4j+ssc://` to skip cert verification.

### Step 4: Enable a model in Amazon Bedrock

1. AWS Console → Amazon Bedrock → Model Access
2. Request access to **Amazon Nova Micro** or **Anthropic Claude Haiku** (us-east-1)
3. Ensure your IAM user has `bedrock:InvokeModel` permission

Set in `.env`:
```
BEDROCK_MODEL_ID=amazon.nova-micro-v1:0
```

### Step 5: Populate the knowledge graph

```bash
python populate_kg.py
```

Expected output:
```
  HPE Infrastructure KG — Population Script
  Connected successfully!
  [1/8] Creating uniqueness constraints...
  [2/8] Creating Customer nodes...         6 nodes
  [3/8] Creating ServiceContract nodes...  4 nodes
  [4/8] Creating Server nodes...          10 nodes
  [5/8] Creating FirmwareVersion nodes...  9 nodes
  [6/8] Creating ChangePolicy nodes...     6 nodes
  [7/8] Creating MaintenanceWindow nodes...8 nodes
  [8/8] Creating Incident nodes...         8 nodes
  [+]   Creating ChangeRequest nodes...   14 nodes
  [R]   Creating relationships...
  TOTAL NODES          65
  TOTAL RELATIONSHIPS  ~95
```

### Step 6: Run the demo

```bash
python app.py
```

---

## Sample Q&A — Multi-Hop Reasoning in Action

### Question 1: Why was CR003 denied?

**Q:** *"Why was change request CR003 denied for the Chevron seismic server?"*

**Generated Cypher:**
```cypher
MATCH (cr:ChangeRequest {id: 'CR003'})
MATCH (cr)-[:TARGETS]->(sv:Server)
MATCH (cr)-[:GOVERNED_BY]->(pol:ChangePolicy)
MATCH (cr)-[:TARGETS_FIRMWARE]->(target:FirmwareVersion)
MATCH (sv)-[r:RUNNING_FIRMWARE]->(current:FirmwareVersion)
WHERE r.component_type = 'iLO'
OPTIONAL MATCH path = (current)-[:PREREQUISITE_FOR*]->(target)
RETURN cr.id, cr.status, cr.decision_notes, sv.hostname,
       current.version AS current_ilo, target.version AS target_ilo,
       [n IN nodes(path) | n.version] AS required_upgrade_path
```

**Answer:**
CR003 was **DENIED** because the firmware upgrade path was invalid.
`chevron-seismic-01` is running iLO **2.55**, but the change requested a direct
jump to **2.80** — skipping two mandatory intermediate versions. The required
sequential path is: **2.55 → 2.65 → 2.72 → 2.80**. The iLO installer enforces
this restriction and will abort with `FWUPG_E_PREREQ_NOT_MET` if intermediate
versions are skipped. The fix: resubmit as 3 separate sequential change requests.

---

### Question 2: What is blocking CR007?

**Q:** *"What is blocking CR007 from being approved for the NASA JPL mission compute server?"*

**Answer:**
CR007 has **5 simultaneous blockers**:
1. **Prerequisite not met**: iLO 2.65 → 2.80 requires intermediate version 2.72 (not installed)
2. **Active incident**: P2 fan failure incident INC006 is OPEN on the server
3. **No maintenance window**: Next approved JPL window is MW006 (March 30)
4. **Insufficient notice**: POL006 (JPL Government) requires 96hr advance notice — current submission lacks this
5. **CAB review missing**: JPL policy requires Change Advisory Board review, not yet scheduled

This is the key demo of KG power: **all 5 blockers discovered in a single traversal**,
not 5 separate searches.

---

### Question 3: Firmware compliance status

**Q:** *"Which servers are still running iLO firmware versions affected by CVE-2023-28082?"*

**Answer:**
Three servers remain vulnerable (iLO < 2.72):
- `finance-prod-db-01` (Goldman Sachs, Tier 1) — iLO **2.65** — CR001 pending but has prerequisite issue
- `mayo-imaging-01` (Mayo Clinic, Tier 2) — iLO **2.65** — no active patch CR
- `jpl-mission-compute-01` (NASA JPL, Tier 1) — iLO **2.65** — CR007 pending but blocked

`chevron-seismic-01` runs iLO **2.55** which is also vulnerable but not listed in
CVE advisories as the advisory targets 2.65 specifically. Both are below the safe baseline.

---

## Educational Notes: The NL2Cypher Pipeline

### Three LLM Calls

1. **NL → Cypher (temp=0.0):** Deterministic translation. The full graph schema
   is injected into the system prompt. Low temperature ensures consistent, syntactically
   correct Cypher without hallucinated property names.

2. **Neo4j execution:** The graph traverses edges in milliseconds. Results are
   structured JSON records — not text chunks, not embeddings with similarity scores.

3. **Reasoning (temp=0.2):** The LLM receives the question + raw structured data
   and produces a human-readable, operationally relevant answer. Slightly higher
   temperature allows natural language variation without making up facts.

### Why Cypher is Ideal for This

Cypher's ASCII-art pattern syntax mirrors how engineers think about connected systems:

```cypher
-- "Find Tier-1 servers with open incidents under Platinum contracts"
MATCH (inc:Incident {status: 'OPEN'})
      -[:AFFECTS]->(sv:Server {criticality_tier: 1})
      -[:BELONGS_TO]->(cu:Customer)
      -[:HAS_CONTRACT]->(sc:ServiceContract {tier: 'Platinum'})
RETURN inc.severity, inc.title, sv.hostname, cu.name, sc.uptime_sla_percent
ORDER BY inc.severity
```

This is readable, explainable, and auditable — the reasoning path is the query
itself.
