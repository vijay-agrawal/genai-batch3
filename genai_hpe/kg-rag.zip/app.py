"""
HPE Infrastructure Change Management — KG-RAG Application
==========================================================
Demonstrates Knowledge Graph + RAG for HPE server firmware and
change request management using Neo4j + Amazon Bedrock.

Pipeline:
  User Question → LLM generates Cypher → Execute on Neo4j → LLM reasons → Answer

Usage:
    python app.py

Requirements:
    - Neo4j populated via populate_kg.py
    - AWS credentials configured (aws configure or IAM role)
    - .env with NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD
"""

import os
import json
import boto3
from neo4j import GraphDatabase
from dotenv import load_dotenv

load_dotenv()

# ── Configuration ──────────────────────────────────────────────────────────────

NEO4J_URI      = os.getenv("NEO4J_URI",       "bolt://localhost:7687")
NEO4J_USERNAME = os.getenv("NEO4J_USERNAME",  "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD",  "password")
AWS_REGION     = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
BEDROCK_MODEL  = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")

# ── Graph Schema (injected into LLM prompts) ───────────────────────────────────

GRAPH_SCHEMA = """
GRAPH SCHEMA — HPE Infrastructure Change Management Knowledge Graph
===================================================================

NODE TYPES:
-----------
Server           {id, hostname, model, serial_number, customer_id, datacenter, rack,
                  criticality_tier, role, os, ilo_version, bios_version,
                  greenlake_resource_id, notes}
Customer         {id, name, industry, region, contract_id, account_manager,
                  greenlake_tenant, notes}
ServiceContract  {id, name, tier, uptime_sla_percent, response_sla_hours,
                  onsite_sla_hours, change_notice_hours, dual_approval_required,
                  maintenance_window_required, blackout_periods,
                  sla_credit_per_hour_usd, annual_value_usd}
FirmwareVersion  {id, component_type, component_name, version, release_date,
                  status, security_advisories, prerequisite_fw_id, notes}
ChangeRequest    {id, title, change_type, component, target_version, current_version,
                  status, request_date, decision_date, urgency, submitter,
                  decision_notes, auth_number, server_id, customer_id, policy_id}
ChangePolicy     {id, name, contract_tier, server_criticality_tier,
                  notice_required_hours, dual_approval_required, approvers,
                  maintenance_window_required, blackout_periods,
                  max_change_duration_hours, rollback_plan_required}
MaintenanceWindow {id, name, type, start_datetime, end_datetime, recurrence,
                   status, approved_by, customer_id, notes}
Incident         {id, severity, status, title, category, created_date,
                  resolved_date, description, server_id, customer_id, notes}

RELATIONSHIPS:
--------------
(Customer)-[:HAS_CONTRACT]->(ServiceContract)
(Server)-[:BELONGS_TO]->(Customer)
(ChangePolicy)-[:APPLIES_TO]->(ServiceContract)
(FirmwareVersion)-[:PREREQUISITE_FOR]->(FirmwareVersion)
(Server)-[:RUNNING_FIRMWARE {component_type}]->(FirmwareVersion)
(ChangeRequest)-[:TARGETS]->(Server)
(ChangeRequest)-[:FOR_CUSTOMER]->(Customer)
(ChangeRequest)-[:GOVERNED_BY]->(ChangePolicy)
(ChangeRequest)-[:TARGETS_FIRMWARE]->(FirmwareVersion)
(ChangeRequest)-[:SCHEDULED_IN]->(MaintenanceWindow)
(Server)-[:IN_MAINTENANCE_WINDOW]->(MaintenanceWindow)
(MaintenanceWindow)-[:OWNED_BY]->(Customer)
(Incident)-[:AFFECTS]->(Server)
(Incident)-[:BLOCKS]->(ChangeRequest)

KEY DATA NOTES:
---------------
- Customer IDs: CUST001=Goldman Sachs, CUST002=Mayo Clinic, CUST003=Chevron,
                CUST004=Univ of Texas, CUST005=NASA JPL, CUST006=HPE Labs
- Service Contract tiers: Platinum (SVC001), Gold (SVC002), Silver (SVC003), Bronze (SVC004)
- Server criticality_tier values: 1 (critical), 2 (important), 3 (standard)
- FirmwareVersion component_type values: 'iLO', 'BIOS', 'Smart Array'
- iLO prerequisite chain (MUST follow in order): FW001(2.55)→FW002(2.65)→FW003(2.72)→FW004(2.80)
- BIOS prerequisite chain: FW005(2.10)→FW006(2.30)→FW007(2.54)
- Smart Array chain: FW008(7.00)→FW009(8.00)
- FirmwareVersion status values: 'superseded', 'current_baseline', 'recommended'
- ChangeRequest status values: APPROVED, DENIED, PENDING
- ChangeRequest urgency values: routine, high, emergency
- Incident severity values: P1 (critical), P2 (high), P3 (medium)
- Incident status values: OPEN, RESOLVED
- Policy IDs: POL001=Platinum Tier-1, POL002=Platinum Tier-2, POL003=Gold,
              POL004=Silver/Bronze, POL005=Emergency Security Patch, POL006=Govt/ITAR
- CVE-2023-28082 affects iLO firmware versions 2.65 and below (CVSS 9.8)
- MaintenanceWindow status values: upcoming, completed
"""

# ── Sample Questions ───────────────────────────────────────────────────────────

SAMPLE_QUESTIONS = [
    # Multi-hop: change request analysis
    "What change requests are currently pending for Goldman Sachs servers?",
    "Why was change request CR003 denied for the Chevron seismic server?",
    "What is blocking CR007 from being approved for the NASA JPL mission compute server?",
    # Firmware compliance
    "Which servers are still running iLO firmware versions affected by CVE-2023-28082?",
    "What is the complete firmware upgrade path from iLO version 2.55 to 2.80?",
    "How many servers are fully compliant with the recommended iLO firmware baseline?",
    # Policy and approval chain
    "What approval requirements must be met for a Tier 1 firmware change at Mayo Clinic?",
    "Which pending change requests require dual approval and are still missing a signature?",
    "Show all change requests denied due to policy violations and the specific reason",
    # Incidents and blockers
    "Show me all active incidents and the change requests they are blocking",
    "Which customers have both open incidents and pending change requests on the same server?",
    # Maintenance windows
    "What maintenance windows are upcoming and which change requests are scheduled in them?",
    "Show the complete change history for all Goldman Sachs servers",
]

# ── Bedrock Client ─────────────────────────────────────────────────────────────

def get_bedrock_client():
    try:
        return boto3.client("bedrock-runtime", region_name=AWS_REGION)
    except Exception as e:
        print(f"  ERROR: Could not create Bedrock client: {e}")
        return None


def call_bedrock(client, system_prompt: str, user_message: str,
                 temperature: float = 0.0) -> str:
    """Call the configured model via Amazon Bedrock Converse API."""
    try:
        response = client.converse(
            modelId=BEDROCK_MODEL,
            system=[{"text": system_prompt}],
            messages=[
                {"role": "user", "content": [{"text": user_message}]}
            ],
            inferenceConfig={
                "maxTokens": 2048,
                "temperature": temperature,
            },
        )
        return response["output"]["message"]["content"][0]["text"].strip()
    except Exception as e:
        raise RuntimeError(f"Bedrock API call failed: {e}") from e


# ── NL2Cypher ─────────────────────────────────────────────────────────────────

NL2CYPHER_SYSTEM_PROMPT = f"""You are an expert Neo4j Cypher query writer for an HPE
infrastructure change management knowledge graph.

Your job: Convert the user's natural language question into a valid Cypher query.

Rules:
1. Return ONLY the Cypher query — no explanation, no markdown code blocks, no commentary.
2. Use MATCH/RETURN patterns. Use OPTIONAL MATCH when data may be absent.
3. Use case-insensitive matching for names: toLower(n.name) CONTAINS toLower('...')
4. Always LIMIT results (default LIMIT 25) unless counting.
5. Return meaningful property names using aliases (e.g., sv.hostname AS server).
6. For "pending" items: status = 'PENDING'. "denied": status = 'DENIED'. "approved": status = 'APPROVED'.
7. For "open" incidents: status = 'OPEN'. For "resolved": status = 'RESOLVED'.
8. Customer names use CONTAINS for partial matching (e.g., cu.name CONTAINS 'Goldman').
9. Firmware versions are stored as strings (e.g., fv.version = '2.80').
10. The RUNNING_FIRMWARE relationship has a component_type property — use it to filter:
    (sv)-[r:RUNNING_FIRMWARE]->(fv) WHERE r.component_type = 'iLO'
11. To find the prerequisite chain use: (fv1)-[:PREREQUISITE_FOR*]->(fv2)
12. Do not use deprecated Cypher syntax. Use modern Neo4j 5.x syntax.

{GRAPH_SCHEMA}
"""


def generate_cypher(bedrock_client, question: str) -> str:
    """Use LLM to convert a natural language question to a Cypher query."""
    user_msg = f"Convert this question to a Cypher query:\n\n{question}"
    cypher = call_bedrock(bedrock_client, NL2CYPHER_SYSTEM_PROMPT, user_msg,
                          temperature=0.0)

    # Strip markdown code blocks if model included them
    cypher = cypher.strip()
    if cypher.startswith("```"):
        lines = cypher.split("\n")
        cypher = "\n".join(
            lines[1:-1] if lines[-1].startswith("```") else lines[1:]
        )
    return cypher.strip()


# ── Graph Query ────────────────────────────────────────────────────────────────

def execute_cypher(driver, cypher: str) -> list[dict]:
    """Execute a Cypher query and return results as a list of dicts."""
    with driver.session() as session:
        result = session.run(cypher)
        return [dict(record) for record in result]


# ── Reasoning / Answer Generation ─────────────────────────────────────────────

REASONING_SYSTEM_PROMPT = """You are a knowledgeable HPE infrastructure AI assistant
specializing in server firmware management, change control processes, and GreenLake
service operations.

You will be given:
1. A question from an HPE engineer or customer success manager
2. Raw data returned from a knowledge graph query

Your job: Provide a clear, accurate, and actionable answer using the data provided.

Guidelines:
- Interpret data in terms an HPE field engineer or DevOps team would understand
- Highlight key findings: blocked changes, policy violations, firmware gaps, compliance risks
- If data is empty, explain what that means in context
- Add brief operational context: SLA implications, security risk of unpatched firmware, etc.
- Be concise but complete — use bullet points for lists of items
- Do not make up data not present in the results
- Reference specific server hostnames, change request IDs, customer names from results
- When explaining denials/blocks, be specific about WHICH policy rule was violated
"""


def generate_answer(bedrock_client, question: str,
                    query_results: list[dict]) -> str:
    """Use LLM to reason over graph results and produce a human-readable answer."""
    results_text = (
        json.dumps(query_results, indent=2, default=str)
        if query_results
        else "(No results returned from the knowledge graph)"
    )

    user_msg = (
        f"Question: {question}\n\n"
        f"Knowledge Graph Query Results:\n{results_text}\n\n"
        f"Please provide a clear, helpful, actionable answer based on these results."
    )
    return call_bedrock(bedrock_client, REASONING_SYSTEM_PROMPT, user_msg,
                        temperature=0.2)


# ── Display Helpers ────────────────────────────────────────────────────────────

def print_divider(char="─", width=72):
    print(char * width)


def print_menu():
    print_divider("═")
    print("  HPE Infrastructure Change Management — KG-RAG Demo")
    print("  Powered by Neo4j Knowledge Graph + Amazon Bedrock")
    print_divider("═")
    print("\n  Sample Questions (demonstrating multi-hop graph reasoning):\n")
    print_divider()
    for i, q in enumerate(SAMPLE_QUESTIONS, 1):
        print(f"  {i:>2}. {q}")
    print_divider()
    print("   C. Enter a custom question")
    print("   Q. Quit")
    print_divider()


def print_results_table(results: list[dict]):
    """Pretty-print query results as a table."""
    if not results:
        print("  (No records returned)")
        return
    keys = list(results[0].keys())
    col_widths = {
        k: min(max(len(k), max((len(str(r.get(k, ""))) for r in results), default=0)), 48)
        for k in keys
    }
    header = "  " + " │ ".join(k.ljust(col_widths[k]) for k in keys)
    print(header)
    print("  " + "─┼─".join("─" * col_widths[k] for k in keys))
    for row in results[:20]:
        cells = [
            (str(row.get(k, "")) if row.get(k) is not None else "")[:col_widths[k]].ljust(col_widths[k])
            for k in keys
        ]
        print("  " + " │ ".join(cells))
    if len(results) > 20:
        print(f"\n  ... and {len(results) - 20} more records (showing first 20)")


# ── Main Application Loop ─────────────────────────────────────────────────────

def main():
    # ── Connect to Neo4j ──────────────────────────────────────────────────────
    print("\n  Connecting to Neo4j...")
    try:
        driver = GraphDatabase.driver(
            NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD)
        )
        driver.verify_connectivity()
        print("  Neo4j connected.\n")
    except Exception as e:
        print(f"\n  ERROR: Cannot connect to Neo4j: {e}")
        print("  Run: python populate_kg.py")
        print("  And verify .env has correct Neo4j credentials.\n")
        return

    # ── Connect to Bedrock ────────────────────────────────────────────────────
    print("  Initializing Amazon Bedrock client...")
    bedrock_client = get_bedrock_client()
    if not bedrock_client:
        print("  ERROR: Could not initialize Bedrock. Check AWS credentials.")
        driver.close()
        return
    print(f"  Bedrock client ready (model: {BEDROCK_MODEL}).\n")

    # ── Main Loop ─────────────────────────────────────────────────────────────
    while True:
        print_menu()
        choice = input("  Your choice: ").strip()

        if choice.upper() == "Q":
            print("\n  Goodbye!\n")
            break

        question = None
        if choice.upper() == "C":
            question = input("\n  Enter your question: ").strip()
            if not question:
                print("  No question entered.")
                continue
        else:
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(SAMPLE_QUESTIONS):
                    question = SAMPLE_QUESTIONS[idx]
                else:
                    print(f"  Invalid selection. Choose 1-{len(SAMPLE_QUESTIONS)}.")
                    continue
            except ValueError:
                print("  Invalid input. Enter a number, 'C', or 'Q'.")
                continue

        print(f"\n  Question: {question}")
        print_divider()

        # ── Step 1: NL → Cypher ───────────────────────────────────────────────
        print("\n  [Step 1] Generating Cypher query via LLM...")
        try:
            cypher_query = generate_cypher(bedrock_client, question)
        except Exception as e:
            print(f"  ERROR generating Cypher: {e}")
            input("\n  Press Enter to continue...")
            continue

        print("\n  Generated Cypher Query:")
        print_divider("·")
        print(f"  {cypher_query}")
        print_divider("·")

        # ── Step 2: Execute on Neo4j ──────────────────────────────────────────
        print("\n  [Step 2] Executing query on Neo4j knowledge graph...")
        try:
            results = execute_cypher(driver, cypher_query)
            print(f"  Returned {len(results)} records.")
        except Exception as e:
            print(f"\n  ERROR executing Cypher: {e}")
            print("  The generated Cypher may have a syntax error.")
            print("  Tip: Try rephrasing your question or check the schema.")
            input("\n  Press Enter to continue...")
            continue

        print("\n  Raw Query Results:")
        print_divider("·")
        print_results_table(results)
        print_divider("·")

        # ── Step 3: LLM Reasoning ─────────────────────────────────────────────
        print("\n  [Step 3] Generating answer via LLM reasoning over graph data...")
        try:
            answer = generate_answer(bedrock_client, question, results)
        except Exception as e:
            print(f"  ERROR generating answer: {e}")
            answer = "Could not generate answer due to an API error."

        print("\n  Answer:")
        print_divider("═")
        # Word-wrap the answer for readability
        words = answer.split()
        line = "  "
        for word in words:
            if len(line) + len(word) + 1 > 74:
                print(line)
                line = "  " + word + " "
            else:
                line += word + " "
        if line.strip():
            print(line)
        print_divider("═")

        input("\n  Press Enter to continue...\n")

    driver.close()


if __name__ == "__main__":
    main()
