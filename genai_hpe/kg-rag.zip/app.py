"""
Healthcare KG-RAG Application
==============================
Natural Language to Cypher Query using Amazon Bedrock + Neo4j

Pipeline:
  User Question → LLM generates Cypher → Execute on Neo4j → LLM reasons over results → Answer

Usage:
    python app.py

Requirements:
    - Neo4j populated via populate_kg.py
    - AWS credentials configured (aws configure or IAM role)
    - .env with NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD
"""

import os
import json
import boto3
from neo4j import GraphDatabase
from dotenv import load_dotenv

load_dotenv()

# ── Configuration ─────────────────────────────────────────────────────────────

NEO4J_URI       = os.getenv("NEO4J_URI",       "bolt://localhost:7687")
NEO4J_USERNAME  = os.getenv("NEO4J_USERNAME",  "neo4j")
NEO4J_PASSWORD  = os.getenv("NEO4J_PASSWORD",  "password")
AWS_REGION      = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
BEDROCK_MODEL   = os.getenv("BEDROCK_MODEL_ID",      "amazon.nova-micro-v1:0")

# ── Graph Schema (used in LLM prompts) ───────────────────────────────────────

GRAPH_SCHEMA = """
GRAPH SCHEMA — Healthcare Prior Authorization Knowledge Graph
=============================================================

NODE TYPES:
-----------
Patient         {id, name, age, gender, dob, member_id, plan_id, bmi, notes}
Provider        {id, name, specialty, npi, type}
InsurancePlan   {id, name, type, insurer, deductible, max_out_of_pocket,
                 prior_auth_required_threshold, appeal_timeframe_days}
Diagnosis       {code, description, category, severity_level, chronic}
Procedure       {code, description, type, typical_cost, prior_auth_required,
                 inpatient_required, specialty_required}
Medication      {name, generic_name, drug_class, ndc, typical_monthly_cost,
                 prior_auth_required, step_therapy_required,
                 step_therapy_prerequisite, tier, indication}
Claim           {id, date, item_type, item_name, amount, status, denial_reason, notes}
PriorAuthRequest{id, request_date, item_type, item_code, status, decision_date,
                 urgency, decision_notes, auth_number, plan_id}
CoverageRule    {id, name, description, applies_to_type, applies_to_code,
                 requirements, decision_timeframe_days, appeal_allowed, plan_id}

RELATIONSHIPS:
--------------
(Patient)-[:COVERED_BY]->(InsurancePlan)
(Patient)-[:HAS_DIAGNOSIS {diagnosed_date}]->(Diagnosis)
(Provider)-[:IN_NETWORK_FOR]->(InsurancePlan)
(Provider)-[:TREATS]->(Patient)
(Claim)-[:FOR_PATIENT]->(Patient)
(Claim)-[:SUBMITTED_BY]->(Provider)
(Claim)-[:FOR_PROCEDURE]->(Procedure)
(Claim)-[:FOR_MEDICATION]->(Medication)
(PriorAuthRequest)-[:FOR_PATIENT]->(Patient)
(PriorAuthRequest)-[:SUBMITTED_BY]->(Provider)
(PriorAuthRequest)-[:UNDER_PLAN]->(InsurancePlan)
(PriorAuthRequest)-[:REQUESTS_PROCEDURE]->(Procedure)
(PriorAuthRequest)-[:REQUESTS_MEDICATION]->(Medication)
(CoverageRule)-[:GOVERNS]->(Medication)
(CoverageRule)-[:GOVERNS]->(Procedure)
(CoverageRule)-[:BELONGS_TO_PLAN]->(InsurancePlan)
(Diagnosis)-[:TREATED_BY]->(Procedure)
(Diagnosis)-[:TREATED_WITH]->(Medication)
(Medication)-[:STEP_THERAPY_BEFORE]->(Medication)

KEY DATA NOTES:
---------------
- Plan IDs: PLAN001=BlueCross Premier PPO, PLAN002=Aetna HMO Select,
             PLAN003=United Choice Plus, PLAN004=Cigna Medicare Advantage
- Provider IDs: DR001=Rodriguez(PCP), DR002=Park(Endo), DR003=Santos(Onco),
                DR004=O'Brien(Ortho), DR005=Patel(Rheum), DR006=Lee(Pulm),
                DR007=Chang(GI), DR008=Garcia(Cardio)
- Claim status values: PAID, DENIED, PENDING
- PriorAuthRequest status values: APPROVED, DENIED, PENDING
- Medication tiers: "1" (generic), "2" (preferred brand), "3" (non-preferred), "specialty"
- Step therapy chain: Metformin→Ozempic, Methotrexate→Humira, Humira→Stelara, Eliquis→Xarelto
"""

# ── Sample Questions ──────────────────────────────────────────────────────────

SAMPLE_QUESTIONS = [
    "What prior authorization requests are currently pending for BlueCross Premier PPO?",
    "Which patients have been prescribed Ozempic and what is their diabetes diagnosis?",
    "Show me all denied prior auth requests and the reasons for denial",
    "What medications require step therapy and what are the prerequisite drugs?",
    "Which providers are in-network for Aetna HMO Select and what specialties do they have?",
    "What is the complete prior auth history for patient John Martinez?",
    "Which patients have Type 2 Diabetes and have NOT been approved for Ozempic?",
    "What coverage rules apply to knee replacement surgery under BlueCross Premier PPO?",
    "Show all claims submitted by Dr. Rodriguez and their payment status",
    "Which medications are on specialty tier and require prior authorization?",
    "What step therapy was required before Emily Johnson could get Humira approved?",
    "Which patients were denied prior auth and what were the denial reasons?",
]

# ── Bedrock Client ────────────────────────────────────────────────────────────

def get_bedrock_client():
    try:
        client = boto3.client("bedrock-runtime", region_name=AWS_REGION)
        return client
    except Exception as e:
        print(f"  ERROR: Could not create Bedrock client: {e}")
        return None


def call_bedrock(client, system_prompt: str, user_message: str) -> str:
    """Call Claude via Amazon Bedrock using the Converse API."""
    try:
        response = client.converse(
            modelId=BEDROCK_MODEL,
            system=[{"text": system_prompt}],
            messages=[
                {"role": "user", "content": [{"text": user_message}]}
            ],
            inferenceConfig={
                "maxTokens": 2048,
                "temperature": 0.0,  # Deterministic for Cypher generation
            },
        )
        return response["output"]["message"]["content"][0]["text"].strip()
    except Exception as e:
        raise RuntimeError(f"Bedrock API call failed: {e}") from e


# ── NL2Cypher ────────────────────────────────────────────────────────────────

NL2CYPHER_SYSTEM_PROMPT = f"""You are an expert Neo4j Cypher query writer for a healthcare
prior authorization knowledge graph.

Your job: Convert the user's natural language question into a valid Cypher query.

Rules:
1. Return ONLY the Cypher query — no explanation, no markdown code blocks, no commentary.
2. Use MATCH/RETURN patterns. Use OPTIONAL MATCH when data may be missing.
3. Use case-insensitive matching for names: toLower(n.name) CONTAINS toLower('...')
4. Always LIMIT results (default LIMIT 25) unless counting.
5. Return meaningful property names using aliases (e.g., pt.name AS patient_name).
6. For "pending" items: status = 'PENDING'. For "denied": status = 'DENIED'. For "approved": status = 'APPROVED'.
7. Medication names are case-sensitive in the graph (e.g., 'Ozempic', 'Humira', 'Stelara').
8. Plan names use CONTAINS for partial matching (e.g., ip.name CONTAINS 'BlueCross').
9. Do not use deprecated Cypher syntax. Use modern Neo4j 5.x syntax.

{GRAPH_SCHEMA}
"""


def generate_cypher(bedrock_client, question: str) -> str:
    """Use LLM to convert natural language question to Cypher."""
    user_msg = f"Convert this question to a Cypher query:\n\n{question}"
    cypher = call_bedrock(bedrock_client, NL2CYPHER_SYSTEM_PROMPT, user_msg)

    # Strip markdown code blocks if the LLM included them anyway
    cypher = cypher.strip()
    if cypher.startswith("```"):
        lines = cypher.split("\n")
        # Remove first and last lines (``` markers)
        cypher = "\n".join(lines[1:-1] if lines[-1].startswith("```") else lines[1:])

    return cypher.strip()


# ── Graph Query ───────────────────────────────────────────────────────────────

def execute_cypher(driver, cypher: str) -> list[dict]:
    """Execute Cypher query on Neo4j and return list of records as dicts."""
    with driver.session() as session:
        result = session.run(cypher)
        records = []
        for record in result:
            records.append(dict(record))
        return records


# ── Reasoning / Answer Generation ─────────────────────────────────────────────

REASONING_SYSTEM_PROMPT = """You are a knowledgeable healthcare AI assistant specializing
in prior authorization, insurance coverage, and clinical decision support.

You will be given:
1. A question from a healthcare professional
2. Raw data returned from a knowledge graph query

Your job: Provide a clear, accurate, and helpful answer using the data provided.

Guidelines:
- Interpret the data in plain language a healthcare professional would understand
- Highlight key findings (e.g., which requests are pending, what step therapy is required)
- If data is empty, explain what that means (e.g., "No pending requests found")
- Add brief clinical or coverage context when relevant
- Be concise but complete — use bullet points for lists
- Do not make up data not present in the results
- Mention specific patient names, medication names, and plan names from the results
"""


def generate_answer(bedrock_client, question: str, query_results: list[dict]) -> str:
    """Use LLM to reason over query results and produce a human-readable answer."""
    if not query_results:
        results_text = "(No results returned from the knowledge graph)"
    else:
        results_text = json.dumps(query_results, indent=2, default=str)

    user_msg = (
        f"Question: {question}\n\n"
        f"Knowledge Graph Query Results:\n{results_text}\n\n"
        f"Please provide a clear, helpful answer to the question based on these results."
    )
    return call_bedrock(bedrock_client, REASONING_SYSTEM_PROMPT, user_msg)


# ── Display Helpers ───────────────────────────────────────────────────────────

def print_divider(char="─", width=70):
    print(char * width)


def print_menu():
    print_divider("═")
    print("  Healthcare Prior Authorization KG-RAG Demo")
    print("  Powered by Neo4j + Amazon Bedrock (Claude)")
    print_divider("═")
    print("\n  Sample Questions:")
    print_divider()
    for i, q in enumerate(SAMPLE_QUESTIONS, 1):
        print(f"  {i:>2}. {q}")
    print_divider()
    print("   C. Enter a custom question")
    print("   Q. Quit")
    print_divider()


def print_results_table(results: list[dict]):
    """Pretty-print query results as a table."""
    if not results:
        print("  (No records returned)")
        return
    # Get all keys
    keys = list(results[0].keys())
    # Calculate column widths
    col_widths = {k: max(len(k), max((len(str(r.get(k, ""))) for r in results), default=0))
                  for k in keys}
    col_widths = {k: min(v, 45) for k, v in col_widths.items()}  # cap at 45 chars

    # Header
    header = "  " + " │ ".join(k.ljust(col_widths[k]) for k in keys)
    print(header)
    print("  " + "─┼─".join("─" * col_widths[k] for k in keys))

    # Rows
    for row in results[:20]:  # show up to 20 rows
        cells = []
        for k in keys:
            val = str(row.get(k, "")) if row.get(k) is not None else ""
            cells.append(val[:col_widths[k]].ljust(col_widths[k]))
        print("  " + " │ ".join(cells))

    if len(results) > 20:
        print(f"\n  ... and {len(results) - 20} more records (showing first 20)")


# ── Main Application Loop ─────────────────────────────────────────────────────

def main():
    # ── Connect to Neo4j ──────────────────────────────────────────────────────
    print("\n  Connecting to Neo4j...")
    try:
        driver = GraphDatabase.driver(
            NEO4J_URI,
            auth=(NEO4J_USERNAME, NEO4J_PASSWORD)
        )
        driver.verify_connectivity()
        print("  Neo4j connected.\n")
    except Exception as e:
        print(f"\n  ERROR: Cannot connect to Neo4j: {e}")
        print("  Please run: python populate_kg.py")
        print("  And ensure your .env has correct Neo4j credentials.\n")
        return

    # ── Connect to Bedrock ────────────────────────────────────────────────────
    print("  Initializing Amazon Bedrock client...")
    bedrock_client = get_bedrock_client()
    if not bedrock_client:
        print("  ERROR: Could not initialize Bedrock. Check AWS credentials.")
        driver.close()
        return
    print("  Bedrock client ready.\n")

    # ── Main Loop ─────────────────────────────────────────────────────────────
    while True:
        print_menu()
        choice = input("  Your choice: ").strip()

        if choice.upper() == "Q":
            print("\n  Goodbye!\n")
            break

        question = None
        if choice.upper() == "C":
            question = input("\n  Enter your question: ").strip()
            if not question:
                print("  No question entered. Returning to menu.")
                continue
        else:
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(SAMPLE_QUESTIONS):
                    question = SAMPLE_QUESTIONS[idx]
                else:
                    print(f"  Invalid selection. Please choose 1-{len(SAMPLE_QUESTIONS)}.")
                    continue
            except ValueError:
                print("  Invalid input. Please enter a number or 'C' or 'Q'.")
                continue

        print(f"\n  Question: {question}")
        print_divider()

        # ── Step 1: Generate Cypher ───────────────────────────────────────────
        print("\n  [Step 1] Generating Cypher query via LLM...")
        try:
            cypher_query = generate_cypher(bedrock_client, question)
        except Exception as e:
            print(f"  ERROR generating Cypher: {e}")
            input("\n  Press Enter to continue...")
            continue

        print("\n  Generated Cypher Query:")
        print_divider("·")
        print(f"  {cypher_query}")
        print_divider("·")

        # ── Step 2: Execute Cypher on Neo4j ──────────────────────────────────
        print("\n  [Step 2] Executing query on Neo4j...")
        try:
            results = execute_cypher(driver, cypher_query)
            print(f"  Returned {len(results)} records.")
        except Exception as e:
            print(f"\n  ERROR executing Cypher query: {e}")
            print("\n  The generated Cypher may have a syntax error.")
            print("  Tip: Try rephrasing your question or check the schema.")
            input("\n  Press Enter to continue...")
            continue

        # ── Step 3: Display raw results ───────────────────────────────────────
        print("\n  Raw Query Results:")
        print_divider("·")
        print_results_table(results)
        print_divider("·")

        # ── Step 4: LLM Reasoning ─────────────────────────────────────────────
        print("\n  [Step 3] Generating intelligent answer via LLM reasoning...")
        try:
            answer = generate_answer(bedrock_client, question, results)
        except Exception as e:
            print(f"  ERROR generating answer: {e}")
            answer = "Could not generate answer due to an API error."

        print("\n  Answer:")
        print_divider("═")
        # Word-wrap the answer for readability
        words = answer.split()
        line = "  "
        for word in words:
            if len(line) + len(word) + 1 > 72:
                print(line)
                line = "  " + word + " "
            else:
                line += word + " "
        if line.strip():
            print(line)
        print_divider("═")

        input("\n  Press Enter to continue...\n")

    driver.close()


if __name__ == "__main__":
    main()
