"""
HPE iLO Test Failure Triage Agent
===================================
A LangGraph-based multi-agent pipeline that triages regression test failures
and pinpoints the commits most likely responsible, using AI reasoning instead
of brittle keyword matching.

Agent pipeline (StateGraph):

  START
    │
    ▼
  [triage_node]          ← Extracts technical signals from the failure log
    │
    ▼
  [search_node]          ← Searches 50 commits for semantically related changes
    │
    ▼
  [correlate_node]       ← Deep causal reasoning: how could each commit cause this?
    │
    ├─ confidence=low ──► [broad_search_node]  ← Widens search scope
    │                           │
    │                           └──────────────► [correlate_node]  (retry once)
    │
    └─ confidence=high/medium
    │
    ▼
  [report_node]          ← Generates structured QE triage report
    │
    ▼
   END
"""

import json
import os
import sys

import boto3
from dotenv import load_dotenv
from langgraph.graph import StateGraph, END, START
from typing import TypedDict


# ---------------------------------------------------------------------------
# .env — walk up from __file__ to find project-level .env
# ---------------------------------------------------------------------------

def _find_dotenv() -> str:
    current = os.path.abspath(os.path.dirname(__file__))
    while True:
        candidate = os.path.join(current, ".env")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            print("Error: .env file not found in any parent directory.")
            raise SystemExit(1)
        current = parent


load_dotenv(dotenv_path=_find_dotenv())

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID    = os.getenv("BEDROCK_MODEL_ID", "us.anthropic.claude-sonnet-4-5-20250929-v1:0")
MAX_TOKENS  = int(os.getenv("BEDROCK_MAX_TOKENS", "4096"))
TEMPERATURE = float(os.getenv("BEDROCK_TEMPERATURE", "0"))


# ---------------------------------------------------------------------------
# Shared State
# ---------------------------------------------------------------------------

class TriageState(TypedDict):
    failure: dict               # input: the test failure report
    commits: list               # input: all 50 commits
    failure_signals: str        # node 1 output: extracted technical signals
    candidate_commit_ids: list  # node 2 output: shortlisted commit IDs
    correlation_analysis: str   # node 3 output: per-commit causal reasoning
    confidence_level: str       # node 3 output: "high" | "medium" | "low"
    final_report: str           # node 4 output: formatted diagnosis report
    search_iteration: int       # loop guard: prevents infinite re-search


# ---------------------------------------------------------------------------
# Bedrock helper
# ---------------------------------------------------------------------------

def _call(prompt: str) -> str:
    """Single-turn Bedrock converse call. Returns the text response."""
    client = boto3.client("bedrock-runtime", region_name=AWS_REGION)
    response = client.converse(
        modelId=MODEL_ID,
        messages=[{"role": "user", "content": [{"text": prompt}]}],
        inferenceConfig={"maxTokens": MAX_TOKENS, "temperature": TEMPERATURE},
    )
    return response["output"]["message"]["content"][0]["text"]


# ---------------------------------------------------------------------------
# Node 1 — Triage: Extract failure signals
# ---------------------------------------------------------------------------

def triage_node(state: TriageState) -> dict:
    """
    Analyzes the raw test failure and extracts the technical signals that matter
    for commit correlation: what subsystem failed, what behavior changed, what
    thresholds / timings / values are involved.
    """
    _print_step("STEP 1/4 — TRIAGE AGENT: Analyzing failure signals")

    f = state["failure"]
    prompt = f"""You are a senior QE engineer specializing in HPE iLO (Integrated Lights-Out)
server management firmware and the Redfish API standard.

Analyze the following test failure and extract precise technical signals that will
help identify which recent code change caused it. Be specific and domain-aware.

═══ TEST FAILURE ═══════════════════════════════════════════
Test Name  : {f["test_name"]}
Test Suite : {f["test_suite"]}
Error Type : {f["error_type"]}
Error Msg  : {f["error_message"]}

Stack Trace:
{chr(10).join(f.get("stack_trace", ["N/A"]))}

Environment:
{json.dumps(f.get("environment", {}), indent=2)}

Notes: {f.get("notes", "None")}
Previously passing build: {f.get("previously_passing_build", "unknown")}
════════════════════════════════════════════════════════════

Extract the following — be technical, not generic:

1. CORE BEHAVIORAL CHANGE: What specific system behavior changed from expected?
   (e.g., timing, threshold, unit of measurement, permission, data format)

2. AFFECTED SUBSYSTEM: Which component(s) are involved?
   (e.g., power cap enforcement, fan PID controller, session store, RBAC, schema validation)

3. KEY DIAGNOSTIC INDICATORS: Exact numbers, thresholds, latencies, or values from the failure.
   These are the fingerprints of the bug.

4. CAUSAL HYPOTHESIS: What TYPES of code changes could produce this exact failure?
   Think about: timing/mode changes, configuration default changes, data model changes,
   security enforcement additions, algorithm parameter tuning, storage backend swaps.

5. SEARCH KEYWORDS: 5-10 specific technical terms and concepts to look for in commit messages
   and descriptions. Think semantically — the commit may NOT use the same words as the error."""

    signals = _call(prompt)
    _print_result(signals)
    return {"failure_signals": signals, "search_iteration": 0}


# ---------------------------------------------------------------------------
# Node 2 — Search: Find candidate commits
# ---------------------------------------------------------------------------

def search_node(state: TriageState) -> dict:
    """
    Performs semantic search over all 50 commits using the signals extracted in
    step 1. Returns a ranked shortlist of commit IDs for deep analysis.
    The key insight: the LLM must reason SEMANTICALLY, not just keyword-match.
    """
    _print_step("STEP 2/4 — SEARCH AGENT: Scanning 50 commits for related changes")

    prompt = f"""You are performing commit archaeology to find which changes caused a test regression.

FAILURE SIGNALS (from triage analysis):
{state["failure_signals"]}

ALL COMMITS IN THE BRANCH (50 total, chronological order):
{json.dumps(state["commits"], indent=2)}

Your task: Identify ALL commits that MIGHT be causally related to this failure.

IMPORTANT — Think beyond keyword matching. Consider:
• SEMANTIC RELATIONSHIPS: A commit about "deferred mode" can cause a latency timeout.
  A commit about "gain reduction" can cause insufficient response magnitude.
  A commit about "TTL" can cause session expiry. None of these match the error keywords directly.

• INDIRECT EFFECTS: Schema version bumps affect validators. Mutex scope changes affect
  atomicity. Storage backend swaps change persistence semantics.

• COMPOUND CAUSES: Sometimes two commits together cause the failure (e.g., a refactor
  changes the reference point, then a second refactor doubles down on it).

• VALIDATED RANGE GAPS: If a commit says "validated up to X", and the test uses X+N,
  that's a coverage gap that could explain the failure.

Return ONLY valid JSON (no markdown, no explanation outside the JSON):
{{
  "candidates": ["commit_id_1", "commit_id_2", ...],
  "search_rationale": "Brief explanation of why these commits were selected"
}}

Order candidates by suspicion level — highest first.
Include 3-8 candidates. Do not include commits that are clearly unrelated."""

    raw = _call(prompt)

    candidates = []
    try:
        clean = raw.strip()
        if clean.startswith("```"):
            clean = clean.split("```")[1]
            if clean.startswith("json"):
                clean = clean[4:]
        result = json.loads(clean.strip())
        candidates = result.get("candidates", [])
        rationale = result.get("search_rationale", "")
        _print_result(f"Selected {len(candidates)} candidates: {candidates}\n{rationale}")
    except json.JSONDecodeError:
        _print_result(f"[Warning] Could not parse JSON. Raw:\n{raw[:400]}")

    return {"candidate_commit_ids": candidates}


# ---------------------------------------------------------------------------
# Node 3 — Correlate: Deep causal reasoning
# ---------------------------------------------------------------------------

def correlate_node(state: TriageState) -> dict:
    """
    For each candidate commit, reasons through the causal chain:
    HOW does this commit's change lead to the observed failure?
    Produces a ranked diagnosis with confidence levels.
    """
    _print_step("STEP 3/4 — CORRELATION AGENT: Reasoning through causal chains")

    commit_map = {c["id"]: c for c in state["commits"]}
    candidates = [
        commit_map[cid] for cid in state["candidate_commit_ids"] if cid in commit_map
    ]

    if not candidates:
        return {
            "correlation_analysis": "No candidate commits found for analysis.",
            "confidence_level": "low",
        }

    f = state["failure"]
    prompt = f"""You are a senior software engineer and HPE iLO domain expert performing
root cause analysis on a QE regression failure.

═══ REGRESSION FAILURE ══════════════════════════════════════
Test:  {f["test_name"]}
Suite: {f["test_suite"]}
Error: {f["error_message"]}

Stack trace:
{chr(10).join(f.get("stack_trace", ["N/A"]))}

Environment: {json.dumps(f.get("environment", {}), indent=2)}
Notes: {f.get("notes", "None")}
════════════════════════════════════════════════════════════

TRIAGE SIGNALS ALREADY EXTRACTED:
{state["failure_signals"]}

═══ CANDIDATE COMMITS TO ANALYZE ════════════════════════════
{json.dumps(candidates, indent=2)}
════════════════════════════════════════════════════════════

For EACH candidate commit, provide:

COMMIT [id]: [message]
  Causal Mechanism: Explain step-by-step HOW this commit's change produces the exact
    observed failure. Be specific — reference the exact numbers/thresholds/behaviors.
  Evidence: Quote specific words/phrases from the commit description that connect to
    the failure symptoms.
  Confidence: High / Medium / Low
  Ruling out: (if this commit is NOT the cause, explain why)

Then provide:

PRIMARY SUSPECT:
  Commit ID and message of the most likely root cause.
  Full reasoning chain: commit change → intermediate effect → test observation.

CONTRIBUTING FACTORS (if any):
  Other commits that compound or enable the primary cause.

OVERALL DIAGNOSIS CONFIDENCE: High / Medium / Low
  Reason for confidence level.

Use rigorous causal reasoning. The commit description and error message may use
completely different vocabulary — your job is to bridge that semantic gap."""

    analysis = _call(prompt)

    confidence = "medium"
    lower = analysis.lower()
    if "overall diagnosis confidence: high" in lower:
        confidence = "high"
    elif "overall diagnosis confidence: low" in lower:
        confidence = "low"

    _print_result(analysis)
    return {"correlation_analysis": analysis, "confidence_level": confidence}


# ---------------------------------------------------------------------------
# Conditional Edge — re-search if confidence is low
# ---------------------------------------------------------------------------

def route_after_correlation(state: TriageState) -> str:
    if state["confidence_level"] == "low" and state.get("search_iteration", 0) < 1:
        _print_step("  ↺  Low confidence — broadening search scope (retry 1/1)")
        return "broad_search"
    return "report"


# ---------------------------------------------------------------------------
# Node 3b — Broad Search: Widen the net when confidence is low
# ---------------------------------------------------------------------------

def broad_search_node(state: TriageState) -> dict:
    """
    Fallback: expands the search to consider more indirect relationships
    when the initial search yields low-confidence candidates.
    """
    _print_step("STEP 3b — BROAD SEARCH: Expanding commit search scope")

    f = state["failure"]
    prompt = f"""The initial targeted commit search yielded low-confidence results for this failure.
We need to broaden the search to include more indirect relationships.

FAILURE: {f["test_name"]}
Error: {f["error_message"]}

Initial correlation analysis (inconclusive):
{state["correlation_analysis"]}

ALL COMMITS:
{json.dumps(state["commits"], indent=2)}

Expand the search to include commits that:
• Changed shared configuration files or defaults
• Modified infrastructure components (caching, storage, networking, auth)
• Updated libraries, schemas, or protocol versions
• Changed behaviors of services used indirectly by the failing test
• Made "optimization" or "refactoring" changes that altered semantics

Return ONLY valid JSON:
{{
  "candidates": ["commit_id_1", "commit_id_2", ...],
  "search_rationale": "Explanation of expanded search approach"
}}"""

    raw = _call(prompt)

    candidates = state["candidate_commit_ids"]
    try:
        clean = raw.strip()
        if clean.startswith("```"):
            clean = clean.split("```")[1]
            if clean.startswith("json"):
                clean = clean[4:]
        result = json.loads(clean.strip())
        new_candidates = result.get("candidates", [])
        if new_candidates:
            candidates = new_candidates
        _print_result(f"Expanded to {len(candidates)} candidates: {candidates}")
    except json.JSONDecodeError:
        _print_result("[Warning] Could not parse broad search JSON. Keeping prior candidates.")

    return {
        "candidate_commit_ids": candidates,
        "search_iteration": state.get("search_iteration", 0) + 1,
    }


# ---------------------------------------------------------------------------
# Node 4 — Report: Generate structured QE triage report
# ---------------------------------------------------------------------------

def report_node(state: TriageState) -> dict:
    """
    Synthesizes all agent outputs into a clean, actionable QE triage report
    that a developer can use immediately to investigate and fix the regression.
    """
    _print_step("STEP 4/4 — REPORT AGENT: Generating QE triage report")

    f = state["failure"]
    prompt = f"""Generate a professional QE Triage Report for this regression failure.

TEST: {f["test_name"]}  |  SUITE: {f["test_suite"]}
ERROR: {f["error_message"]}

CORRELATION ANALYSIS (from reasoning agent):
{state["correlation_analysis"]}

Write the report in this exact structure:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
QE TRIAGE REPORT  —  {f["test_name"]}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. EXECUTIVE SUMMARY
   [2-3 sentences: what failed, which commit caused it, confidence level]

2. FAILURE DESCRIPTION
   [What the test does, what it expected, what actually happened, with specific values]

3. ROOT CAUSE — MOST LIKELY COMMIT
   Commit: [ID] — "[message]"
   Author: [author]  Date: [date]
   [Clear explanation of how this commit's change causes the observed failure]

4. REASONING CHAIN
   [Step-by-step causal logic: commit change → intermediate effect → test symptom]
   Use arrows (→) to show causation.

5. CONTRIBUTING FACTORS
   [Other commits that compound the issue, or "None"]

6. RECOMMENDED ACTIONS FOR DEV TEAM
   [ ] [Specific, actionable steps]

7. CONFIDENCE & CAVEATS
   Confidence: [High / Medium / Low]
   [Any alternative explanations or gaps in analysis]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Be specific with commit IDs, technical values, and developer-ready action items."""

    report = _call(prompt)
    return {"final_report": report}


# ---------------------------------------------------------------------------
# Graph Assembly
# ---------------------------------------------------------------------------

def build_graph():
    g = StateGraph(TriageState)

    g.add_node("triage", triage_node)
    g.add_node("search", search_node)
    g.add_node("correlate", correlate_node)
    g.add_node("broad_search", broad_search_node)
    g.add_node("report", report_node)

    g.add_edge(START, "triage")
    g.add_edge("triage", "search")
    g.add_edge("search", "correlate")
    g.add_conditional_edges(
        "correlate",
        route_after_correlation,
        {"broad_search": "broad_search", "report": "report"},
    )
    g.add_edge("broad_search", "correlate")
    g.add_edge("report", END)

    return g.compile()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_triage(failure_id: str | None = None) -> dict:
    """Run the triage pipeline on a specific failure (by ID) or a random one."""
    data_dir = os.path.join(os.path.dirname(__file__), "data")

    with open(os.path.join(data_dir, "commits.json")) as fh:
        commits = json.load(fh)

    with open(os.path.join(data_dir, "test_failures.json")) as fh:
        failures = json.load(fh)

    if failure_id:
        failure = next((f for f in failures if f["id"] == failure_id), None)
        if failure is None:
            valid = [f["id"] for f in failures]
            raise ValueError(f"Failure '{failure_id}' not found. Valid IDs: {valid}")
    else:
        import random
        failure = random.choice(failures)

    print(f"\n{'═' * 60}")
    print(f"  HPE iLO TEST FAILURE TRIAGE AGENT")
    print(f"  Model: {MODEL_ID}  |  Region: {AWS_REGION}")
    print(f"{'═' * 60}")
    print(f"  Failure  : {failure['id']} — {failure['test_name']}")
    print(f"  Suite    : {failure['test_suite']}")
    print(f"  Error    : {failure['error_message'][:80]}...")
    print(f"  Commits  : {len(commits)} commits to analyze")
    print(f"{'═' * 60}\n")

    graph = build_graph()

    initial_state: TriageState = {
        "failure": failure,
        "commits": commits,
        "failure_signals": "",
        "candidate_commit_ids": [],
        "correlation_analysis": "",
        "confidence_level": "medium",
        "final_report": "",
        "search_iteration": 0,
    }

    result = graph.invoke(initial_state)

    print(f"\n{'═' * 60}")
    print(result["final_report"])
    print(f"{'═' * 60}\n")

    return result


def list_failures() -> None:
    """Print all available test failures."""
    data_dir = os.path.join(os.path.dirname(__file__), "data")
    with open(os.path.join(data_dir, "test_failures.json")) as fh:
        failures = json.load(fh)

    print("\nAvailable test failures:")
    print(f"{'─' * 60}")
    for f in failures:
        print(f"  {f['id']}  {f['test_name']}")
        print(f"         Suite: {f['test_suite']}")
    print(f"{'─' * 60}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _print_step(label: str) -> None:
    print(f"\n  ▶ {label}")
    print(f"    {'─' * 50}")


def _print_result(text: str) -> None:
    for line in text.strip().split("\n")[:12]:
        print(f"    {line}")
    lines = text.strip().split("\n")
    if len(lines) > 12:
        print(f"    ... [{len(lines) - 12} more lines]")
