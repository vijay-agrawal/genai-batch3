"""
HPE iLO Test Failure Triage — CLI Entry Point

Usage:
    python main.py                      # triage a random failure
    python main.py --id TF-001          # triage a specific failure
    python main.py --list               # show all available failures
    python main.py --all                # triage all 7 failures sequentially
"""

import argparse
import json
import os
import sys

from triage_agent import run_triage, list_failures


def main() -> None:
    parser = argparse.ArgumentParser(
        description="HPE iLO Test Failure Triage Agent (LangGraph + Claude)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                   Triage a random failure
  python main.py --id TF-001       Triage the power cap latency failure
  python main.py --id TF-005       Triage the RBAC permission failure
  python main.py --list            List all available failures
  python main.py --all             Run all 7 failures (takes ~5 min)
  python main.py --save report.json  Save the result as JSON
        """,
    )
    parser.add_argument(
        "--id",
        metavar="FAILURE_ID",
        help="Triage a specific failure by ID (e.g. TF-001)",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List all available test failures and exit",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Triage all available failures sequentially",
    )
    parser.add_argument(
        "--save",
        metavar="FILE",
        help="Save the triage result to a JSON file",
    )
    args = parser.parse_args()

    if args.list:
        list_failures()
        return

    if not os.getenv("AWS_REGION"):
        print("\n[ERROR] AWS_REGION is not set. Ensure the project-level .env is present.")
        sys.exit(1)

    if args.all:
        data_dir = os.path.join(os.path.dirname(__file__), "data")
        with open(os.path.join(data_dir, "test_failures.json")) as fh:
            all_failures = json.load(fh)
        results = []
        for failure in all_failures:
            print(f"\n{'#' * 60}")
            print(f"  Running triage for: {failure['id']}")
            print(f"{'#' * 60}")
            result = run_triage(failure_id=failure["id"])
            results.append({
                "failure_id": failure["id"],
                "test_name": failure["test_name"],
                "report": result["final_report"],
                "candidate_commits": result["candidate_commit_ids"],
                "confidence": result["confidence_level"],
            })
        if args.save:
            with open(args.save, "w") as fh:
                json.dump(results, fh, indent=2)
            print(f"\nResults saved to {args.save}")
        return

    result = run_triage(failure_id=args.id)

    if args.save:
        output = {
            "failure_id": result["failure"]["id"],
            "test_name": result["failure"]["test_name"],
            "candidate_commits": result["candidate_commit_ids"],
            "confidence": result["confidence_level"],
            "failure_signals": result["failure_signals"],
            "correlation_analysis": result["correlation_analysis"],
            "report": result["final_report"],
        }
        with open(args.save, "w") as fh:
            json.dump(output, fh, indent=2)
        print(f"\nResult saved to {args.save}")


if __name__ == "__main__":
    main()
