# HPE iLO Test Failure Triage Agent

**LangGraph-based agentic AI pipeline for pinpointing regression-causing commits**

---

## Use Case

In large software projects, developers make hundreds of commits before a release
branch is handed off to QE. Unit tests pass at check-in, but some regression tests
fail during QE's test cycle.

The developer's question: **"Which of my 50+ commits broke this test?"**

The naive approach (grep the error message in commit history) fails because:
- Commit descriptions use *domain language* ("deferred mode", "PID gain", "TTL")  
- Error messages use *test/system language* ("latency exceeded", "fan speed insufficient", "session expired")
- The **semantic gap** between cause and symptom requires reasoning, not matching

This demo shows how **Agentic AI** bridges that gap.

---

## Application: HPE iLO Power Management REST API

The simulated codebase is the **iLO Power Management REST API v3**, a real-world
HPE firmware service that manages:

- **Power Capping** — Limit server power consumption via Redfish PATCH
- **Fan Control** — PID-controlled cooling with manual override
- **Thermal Monitoring** — Zone-based alerting against configurable thresholds
- **Session Management** — JWT + Redis-backed session store
- **RBAC Authorization** — Role-based access for power operations
- **Redfish Compliance** — Schema validation (PowerV1_3_0 → PowerV1_5_0)

The API is used by:
- HPE GreenLake cloud management platforms
- Rack-scale power management orchestrators
- QA automation frameworks (Playwright, pytest)
- Prometheus/Grafana monitoring stacks

---

## Dataset Design

### 50 Commits (`data/commits.json`)

A realistic 6-week development sprint with:

| Week | Focus | Commits |
|------|-------|---------|
| 1 (Apr 1–7) | Foundation, auth, schemas | 1–7 |
| 2 (Apr 8–14) | Core power & thermal APIs | 8–14 |
| 3 (Apr 15–21) | Feature enhancement | 15–21 |
| 4 (Apr 22–28) | Optimization & refactoring | 22–28 |
| 5 (Apr 29–May 5) | Security & RBAC | 29–35 |
| 6 (May 6–12) | Integration & bug fixes | 36–42 |
| 7 (May 12–15) | Final polish, release | 43–50 |

**7 commits are carefully designed to cause failures.** Their descriptions use
HPE/iLO domain vocabulary that does NOT directly match the error messages —
the AI must reason across the semantic gap.

### 7 Test Failures (`data/test_failures.json`)

| ID | Test | Symptom | Root Cause Commit |
|----|------|---------|-------------------|
| TF-001 | `test_power_cap_enforcement_latency` | Timeout: enforcement took 2143ms (expected ≤200ms) | `c5d6e7f` — deferred enforcement mode |
| TF-002 | `test_inlet_temperature_alert_trigger` | No alert fired at inlet=38°C (threshold=35°C) | `c7d8e9f` — outlet normalization |
| TF-003 | `test_fan_speed_high_cpu_thermal_load` | Fan at 67% (expected ≥85%) at CPU=92°C | `d2e3f4a` — PID gain 1.0→0.6 |
| TF-004 | `test_session_validity_during_extended_operation` | 401 at T+302s (no explicit timeout set) | `f4a5b6c` — Redis TTL=300s |
| TF-005 | `test_administrator_role_power_off_permission` | 403 for role=Administrator | `a1b2c3e` — RBAC role name mismatch |
| TF-006 | `test_power_response_redfish_schema_compliance` | Missing `PowerMetrics.IntervalInMin` | `f6a7b8d` — schema v1.3→v1.5, strict mode |
| TF-007 | `test_concurrent_power_cap_update_consistency` | 3/5 nodes at wrong cap after concurrent updates | `d0e1f2b` — mutex scope narrowed |

---

## Why AI Reasoning is Required (Not String Matching)

Each failure requires multi-step reasoning:

### TF-001: Power Cap Latency
```
Commit says:   "deferred application at next regulation cycle (up to 2000ms)"
Test says:     "enforcement timeout: measured 2143ms, expected ≤200ms"
Reasoning:     "deferred" → "next cycle" → "up to 2000ms" > 200ms threshold → timeout
```

### TF-003: Fan Speed Insufficient
```
Commit says:   "reduce Kp from 1.0 to 0.6, validated at load up to 75% CPU"
Test says:     "fan_speed=67% at CPU_temp=92°C, expected ≥85%"
Reasoning:     Lower Kp = slower/weaker response. 92°C > 75% validated range.
               Insufficient gain at extreme load = fan speed too low.
```

### TF-004: Session Expiry
```
Commit says:   "Redis TTL=300 seconds"
Test says:     "401 Unauthorized at T+302s"
Reasoning:     300 seconds = exactly 5 minutes. 302s > TTL. Session expired.
               The number "300" never appears in the error message.
```

### TF-005: RBAC Role Mismatch
```
Commit says:   "JWT 'role' claim must exactly match policy role keys: 'admin', 'operator'"
JWT contains:  role = "Administrator"
Policy has:    role key = "admin"
Reasoning:     "Administrator" ≠ "admin". Case + abbreviation mismatch = lookup fails = 403.
```

---

## Agent Architecture (LangGraph)

```
 ┌─────────────────────────────────────────────────────────────┐
 │                    TriageState (shared)                      │
 │  failure • commits • failure_signals • candidate_commits     │
 │  correlation_analysis • confidence_level • final_report      │
 └─────────────────────────────────────────────────────────────┘
           │
    ┌──────▼──────┐
    │ triage_node  │  Analyzes failure log; extracts
    │  (LLM call)  │  domain signals & behavioral changes
    └──────┬──────┘
           │ failure_signals
    ┌──────▼──────┐
    │  search_node │  Semantic search over all 50 commits;
    │  (LLM call)  │  returns ranked candidate commit IDs
    └──────┬──────┘
           │ candidate_commit_ids
    ┌──────▼──────┐
    │correlate_node│  Per-commit causal reasoning;
    │  (LLM call)  │  produces confidence-rated analysis
    └──────┬──────┘
           │
    ┌──────▼──────────────────┐
    │  confidence_level?       │  Conditional routing
    │  low + first try?        │
    └──────┬──────────────────┘
           │
     ┌─────┴─────┐
   low           high/medium
     │                │
┌────▼─────┐    ┌────▼──────┐
│broad_    │    │ report_   │  Synthesizes into structured
│search_   │    │ node      │  QE triage report
│node      │    │ (LLM)     │
│(LLM)     │    └────┬──────┘
└────┬─────┘         │
     │               ▼
     └──► correlate  END
          (retry)
```

**LangGraph concepts demonstrated:**
- `StateGraph` with `TypedDict` shared state
- 5 nodes, each an isolated agent step
- `add_conditional_edges` for intelligent routing
- Cycle support (broad_search → correlate retry)
- `graph.compile()` → executable pipeline

---

## Setup

### Prerequisites
- Python 3.11+
- AWS credentials configured with Bedrock access (uses the project-level `.env`)

### Install

```bash
cd miniprojects/test_failure_triage

# Create virtual environment (or reuse the project-level venv)
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

The agent loads `AWS_REGION`, `BEDROCK_MODEL_ID`, `BEDROCK_MAX_TOKENS`, and
`BEDROCK_TEMPERATURE` from the project-level `.env` file (same `.env` used
by all other demos in this repo — no extra configuration needed).

---

## Run

```bash
# List all available test failures
python main.py --list

# Triage a specific failure (recommended for demo)
python main.py --id TF-001      # Power cap latency — classic timing bug
python main.py --id TF-003      # Fan speed — PID tuning regression
python main.py --id TF-004      # Session expiry — storage backend change
python main.py --id TF-005      # RBAC 403 — role naming mismatch

# Triage a random failure
python main.py

# Save result to JSON
python main.py --id TF-001 --save result_tf001.json

# Run all 7 failures and save all results
python main.py --all --save all_results.json
```

---

## Sample Output (TF-005: RBAC Permission Failure)

```
════════════════════════════════════════════════════
  HPE iLO TEST FAILURE TRIAGE AGENT
════════════════════════════════════════════════════
  Failure  : TF-005 — test_administrator_role_power_off_permission
  Suite    : Security::RBAC::PowerOperations
  Error    : POST /redfish/v1/Systems/1/Actions/ComputerSystem.Reset returned
             HTTP 403 Forbidden. Role 'Administrator' lacks permission...
  Commits  : 50 commits to analyze
════════════════════════════════════════════════════

  ▶ STEP 1/4 — TRIAGE AGENT: Analyzing failure signals
    ──────────────────────────────────────────────────
    CORE BEHAVIORAL CHANGE: A valid Administrator JWT is being rejected
    by the RBAC check for power operations, which previously had no RBAC gate.
    
    KEY DIAGNOSTIC INDICATORS:
    - JWT role claim value: "Administrator" (capital A, full word)
    - Required permission: "PowerControl"
    - HTTP response: 403 with "Role Administrator does not have permission PowerControl"
    
    CAUSAL HYPOTHESIS: The RBAC enforcement is either newly introduced (no prior
    gate), or has a role name mapping issue between the JWT claim format
    and the policy file role key format.

  ▶ STEP 2/4 — SEARCH AGENT: Scanning 50 commits for related changes
    ──────────────────────────────────────────────────
    Selected 4 candidate commits: ['a1b2c3e', 'f0a1b2c', 'e9f0a1b', 'd4e5f6a']
    RBAC enforcement is new — commits adding the framework and role definitions
    are the primary suspects.

  ▶ STEP 3/4 — CORRELATION AGENT: Reasoning through causal chains
    ──────────────────────────────────────────────────
    COMMIT a1b2c3e: "Enforce mandatory RBAC policy check before all privileged operations"
      Causal Mechanism: This commit adds the RBAC gate. The policy maps role key
      'admin' → PowerControl. JWT claims use 'Administrator'. These do not match.
      Evidence: "JWT 'role' claim values must exactly match the role keys defined
      in rbac_policy.yaml" — exact case-sensitive comparison fails.
      Confidence: HIGH
    
    PRIMARY SUSPECT: a1b2c3e
    CONTRIBUTING FACTOR: f0a1b2c (defines role keys as 'admin' not 'Administrator')
    OVERALL DIAGNOSIS CONFIDENCE: High

  ▶ STEP 4/4 — REPORT AGENT: Generating QE triage report
    ──────────────────────────────────────────────────

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
QE TRIAGE REPORT  —  test_administrator_role_power_off_permission
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. EXECUTIVE SUMMARY
   Administrator-role users are being rejected with 403 Forbidden on power
   operations due to a case/format mismatch between JWT role claim values and
   RBAC policy role keys introduced in commit a1b2c3e. Confidence: High.

2. FAILURE DESCRIPTION
   POST /redfish/v1/Systems/1/Actions/ComputerSystem.Reset with a valid
   Administrator JWT returns 403. The RBAC check looks up the JWT 'role'
   claim ("Administrator") in rbac_policy.yaml, but the policy defines
   the role key as "admin". The lookup fails → permission denied.

3. ROOT CAUSE — MOST LIKELY COMMIT
   Commit: a1b2c3e — "Enforce mandatory RBAC policy check before all
           privileged power state change operations"
   Author: meena.iyer  Date: 2026-05-01
   The RBAC enforcement gate does a case-sensitive exact-match lookup of the
   JWT 'role' claim against policy role keys. JWT uses "Administrator";
   policy uses "admin". The mismatch causes the lookup to return no
   permissions, triggering a 403.

4. REASONING CHAIN
   Commit a1b2c3e adds RBAC gate
   → JWT claim extracted: role = "Administrator"
   → Policy lookup: rbac_policy["Administrator"] → KeyError (not found)
   → Policy lookup falls back to: no permissions granted
   → Permission check for "PowerControl" → denied
   → HTTP 403 returned

5. CONTRIBUTING FACTORS
   Commit f0a1b2c defined role keys as lowercase abbreviated ("admin", "operator",
   "readonly") while the iLO UI and JWT middleware use full display names
   ("Administrator", "Operator", "ReadOnly"). The mismatch was latent until
   enforcement was added in a1b2c3e.

6. RECOMMENDED ACTIONS FOR DEV TEAM
   [ ] In rbac.py, normalize JWT role claim to lowercase before lookup
       OR update rbac_policy.yaml to use "Administrator" as the role key
   [ ] Add unit test: verify that JWT role="Administrator" maps to PowerControl
   [ ] Check all iLO role name formats: JWT claims vs. policy keys vs. UI labels
   [ ] Consider adding a startup validation that warns on policy/JWT format mismatch

7. CONFIDENCE & CAVEATS
   Confidence: High
   Both the JWT format ("Administrator") and the policy format ("admin") are
   explicitly documented in the commit descriptions, making the mismatch clear.
   No alternative root cause identified.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Key Design Decisions

### Why LangGraph?

| Requirement | LangGraph Feature Used |
|-------------|----------------------|
| Multi-step reasoning pipeline | `StateGraph` with 4+ nodes |
| Persistent state across steps | `TypedDict` state flows through all nodes |
| Conditional retry on low confidence | `add_conditional_edges` + cycle back |
| Independent agent roles | Each node has its own focused prompt |
| Extensible | Add new nodes (e.g., Jira integration) without rewiring |

### Why Claude?

The failures require domain reasoning that connects:
- Control theory (PID gain → fan response magnitude)
- Distributed systems (Redis TTL semantics)
- Security models (RBAC role name case sensitivity)
- Protocol specifications (Redfish schema version changes)
- Concurrency (mutex scope → atomicity guarantees)

This multi-domain reasoning capability is where LLMs excel over traditional tools.

### Dataset Design Philosophy

The "answer key" for trainers:

| Failure | Root Cause Commit | Semantic Distance |
|---------|------------------|------------------|
| TF-001 | `c5d6e7f` — deferred mode | "deferred" ↔ "timeout" — no shared words |
| TF-002 | `c7d8e9f` — outlet normalization | "outlet baseline" ↔ "inlet alert" — opposite zones |
| TF-003 | `d2e3f4a` — PID gain 0.6 | "oscillation damping" ↔ "insufficient speed" — requires control theory |
| TF-004 | `f4a5b6c` — Redis TTL | "300 seconds" ↔ "302s expiry" — requires unit math |
| TF-005 | `a1b2c3e` + `f0a1b2c` | "admin" ↔ "Administrator" — requires auth domain knowledge |
| TF-006 | `f6a7b8d` — schema v1.5 | "strict mode" + "new field" ↔ "missing required field" |
| TF-007 | `d0e1f2b` — mutex scope | "read atomicity" ↔ "race condition" — requires concurrency knowledge |

---

## Improving with RAG (Retrieval-Augmented Generation)

The current agent sends **all 50 commits** to the LLM in every search call.
This works for a demo but hits two hard limits at real scale:

1. A production branch has **thousands of commits** — far beyond any context window.
2. The agent has **no memory of past failures** — it re-reasons from scratch every time,
   even for patterns it has seen before.

RAG solves both by turning relevant knowledge into a **retrievable corpus** so the
LLM only receives the small slice it actually needs.

### What to index

| Corpus | What goes in | Why it helps |
|--------|-------------|--------------|
| **Commit store** | Embeddings of all commit messages + descriptions | `search_node` retrieves top-K most semantically similar commits instead of scanning all 50+ |
| **Incident history** | Past triage reports, post-mortems, JIRA tickets | "This symptom (fan speed insufficient at high load) appeared in incident INC-2847 — root cause was also a PID gain change" |
| **Domain documentation** | Redfish spec, IPMI SDR guide, iLO programmer's guide, ASHRAE thermal spec | `correlate_node` can retrieve exact spec sections instead of relying on training-data knowledge |
| **Test-to-file map** | Which source files each test exercises (from coverage reports) | Narrows candidates to only commits that touched files the failing test actually runs |

### How it changes the architecture

```
triage_node                    search_node (today)
  │                              │
  │  failure_signals             │  sends ALL 50 commits to LLM
  ▼                              ▼
  ┌─────────────────────────┐    ┌──────────────────────────────────────┐
  │ extract signals          │───►│ LLM scans 50 commits in one prompt   │
  └─────────────────────────┘    └──────────────────────────────────────┘

                  With RAG:

triage_node                    search_node (with RAG)
  │                              │
  │  failure_signals             │  vector query → top-8 commits from 5,000
  ▼                              ▼
  ┌─────────────────────────┐    ┌──────────────┐    ┌─────────────────┐
  │ extract signals          │───►│ embed signals│───►│ Bedrock KB /    │
  │ + retrieve past          │    └──────────────┘    │ OpenSearch      │
  │   incidents like this    │◄───────────────────────│ vector store    │
  └─────────────────────────┘    top-K commits +      └─────────────────┘
                                  similar past bugs
```

### Implementation with AWS Bedrock Knowledge Bases

```python
import boto3

bedrock_agent = boto3.client("bedrock-agent-runtime", region_name=AWS_REGION)

def rag_search_commits(failure_signals: str, top_k: int = 8) -> list[dict]:
    """Retrieve the most semantically relevant commits from the KB."""
    response = bedrock_agent.retrieve(
        knowledgeBaseId=os.getenv("BEDROCK_KB_ID"),
        retrievalQuery={"text": failure_signals},
        retrievalConfiguration={
            "vectorSearchConfiguration": {"numberOfResults": top_k}
        },
    )
    return [r["content"]["text"] for r in response["retrievalResults"]]
```

Commits are ingested into S3, chunked (one commit per chunk), and indexed by
Bedrock Knowledge Bases using Titan Embeddings. The `search_node` calls
`rag_search_commits(state["failure_signals"])` instead of dumping all commits
into the prompt.

### What you gain

- **Scale**: Works on 50,000 commits, not just 50.
- **Speed**: Retrieval is milliseconds; LLM reasoning is only over 8 commits, not 50.
- **Historical memory**: Past triage reports teach the agent to recognize recurring
  failure patterns without re-reasoning them from first principles.
- **Cost**: 8-commit prompt vs. 50-commit prompt = ~6× cheaper per triage run.

---

## Improving with a Knowledge Graph

RAG retrieves relevant *text*. A knowledge graph retrieves relevant *relationships* —
and for commit triage, relationships are the entire point.

The core question is not "which commits mention thermal?" but **"which commits
modified the files that this failing test actually exercises?"** That is a graph
traversal, not a text search.

### The graph model

```
                     ┌──────────┐
          AUTHORED   │Developer │  EXPERTISE_IN
    ┌────────────────│rajesh.m  │──────────────────┐
    │                └──────────┘                  │
    │                                              ▼
┌───▼──────────┐  MODIFIES  ┌──────────────┐  ┌────────────┐
│   Commit     │───────────►│ Source File  │  │  Domain    │
│ d2e3f4a      │            │fan_pid_ctrl  │  │ Thermal    │
│ "PID gain    │            └──────┬───────┘  └────────────┘
│  1.0→0.6"   │                   │ IMPLEMENTS
└──────────────┘                   ▼
       │              ┌─────────────────────────┐
       │  CAUSED      │      Function            │
       └─────────────►│ update_pid_gains()       │
                      └──────────┬──────────────┘
                                 │ CALLED_BY
                                 ▼
                      ┌─────────────────────────┐
                      │      Function            │
                      │ compute_fan_speed()      │
                      └──────────┬──────────────┘
                                 │ TESTED_BY
                                 ▼
                      ┌─────────────────────────┐  PART_OF  ┌──────────────────┐
                      │      Test               │──────────►│   Test Suite     │
                      │ test_fan_speed_high_    │           │ ThermalMgmt::    │
                      │ cpu_thermal_load        │           │ FanControl       │
                      └──────────┬──────────────┘           └──────────────────┘
                                 │
                         FAILED_IN
                                 ▼
                      ┌─────────────────────────┐
                      │    Failure Event         │
                      │ TF-003 (this triage run) │
                      └─────────────────────────┘
```

**Node types:** Commit · SourceFile · Function · Test · TestSuite · Component · Developer · FailureEvent · Bug

**Edge types:** MODIFIES · IMPLEMENTS · CALLS · TESTED_BY · CAUSED · FIXED_BY · PART_OF · AUTHORED · FAILED_IN · SIMILAR_TO

### How graph traversal replaces the blind search

**Today (50-commit blind search):**
```
test_fan_speed_high_cpu_thermal_load  FAILS
  → send all 50 commits to LLM
  → LLM reasons about all of them
  → finds d2e3f4a after scanning everything
```

**With knowledge graph:**
```
test_fan_speed_high_cpu_thermal_load  FAILS
  → graph: test TESTED_BY compute_fan_speed()
  → graph: compute_fan_speed() CALLED_BY update_pid_gains()
  → graph: update_pid_gains() in fan_pid_controller.py
  → graph: fan_pid_controller.py MODIFIES ← [d2e3f4a, b4c5d6f]  ← only 2 commits!
  → LLM reasons about 2 commits
  → finds d2e3f4a immediately
```

The graph reduces candidate search from 50 → 2. LLM reasoning only confirms which
of those 2 is the culprit.

### Additional graph-powered capabilities

**Blast radius analysis** — given a commit, traverse `MODIFIES → file → TESTED_BY`
to predict which tests are at risk before QE even runs them:
```
commit d2e3f4a MODIFIES fan_pid_controller.py
fan_pid_controller.py TESTED_BY → [test_fan_speed_*, test_thermal_*, test_oem_cooling_*]
→ flag those 12 tests as HIGH_RISK before the regression run
```

**Bug recurrence detection** — when a new failure arrives, traverse `SIMILAR_TO`
edges connecting past FailureEvent nodes to surface "this has happened before":
```
TF-003 SIMILAR_TO INC-1847 (2025-09-12)
INC-1847 CAUSED_BY commit abc1234 "reduce Ki from 0.2 to 0.1"
INC-1847 FIXED_BY commit def5678 "revert Ki change, add load-range validation"
→ recommend same fix pattern
```

**Developer context enrichment** — `AUTHORED` + `EXPERTISE_IN` edges let the
correlate agent know whether the author of a suspect commit is a thermal specialist
or a newcomer to that subsystem, adjusting confidence accordingly.

### Implementation with Amazon Neptune

```python
from gremlin_python.driver import client as gremlin_client

neptune = gremlin_client.Client(
    f"wss://{os.getenv('NEPTUNE_ENDPOINT')}:8182/gremlin", "g"
)

def get_commits_by_test(test_name: str) -> list[str]:
    """Return commit IDs that modified files exercised by this test."""
    query = (
        f"g.V().has('test', 'name', '{test_name}')"
        f".out('TESTED_BY').in('IMPLEMENTS').in('MODIFIES')"
        f".values('commit_id')"
    )
    return neptune.submit(query).result().all().result()
```

The `search_node` calls `get_commits_by_test(failure["test_name"])` first. Only
if the graph returns an empty set (new test, no coverage data yet) does it fall
back to the current LLM-based semantic search.

### RAG + Knowledge Graph together

The two techniques are complementary, not competing:

| Technique | Best for |
|-----------|---------|
| **Knowledge Graph** | Structured relationships: which files, which tests, which past bugs |
| **RAG** | Unstructured similarity: commit descriptions, past incident reports, documentation |
| **LLM reasoning** | Bridging the semantic gap between commit language and failure language |

A production triage system uses all three in sequence:

```
graph traversal → candidate commits (2-5)
      +
RAG retrieval   → similar past incidents + relevant docs
      ↓
LLM correlation → causal reasoning over a small, focused context
      ↓
report_node     → actionable diagnosis
```

This combination is accurate at scale, cheap per call, and gets smarter with
every triage run as new `FailureEvent → CAUSED_BY → Commit` edges are added.

---

## Extending the Demo

**Add a new failure**: Add an entry to `data/test_failures.json` following the
existing schema and run `python main.py --id <your-id>`.

**Add more commits**: Add to `data/commits.json`. The search node automatically
considers all commits in the file.

**Add Jira integration**: Add a `jira_node` after `report_node` that creates a
Jira ticket with the triage report. Wire it with `g.add_edge("report", "jira")`.

**Add a GitHub tool**: Replace `search_node`'s LLM-based search with a real
`git log --grep` tool call to ground the search in actual diffs.

---

## File Structure

```
test_failure_triage/
├── README.md                    ← This file
├── requirements.txt             ← Python dependencies
├── triage_agent.py              ← LangGraph agent (core)
├── main.py                      ← CLI entry point
└── data/
    ├── commits.json             ← 50 realistic iLO commits
    └── test_failures.json       ← 7 simulated regression failures
```
