"""
LangGraph Router Demo — Weather & Stock Agents with Step-by-Step Diagnostics
=============================================================================

Architecture:

  User Query
      │
      ▼
  ┌──────────────┐   route="weather"   ┌────────────────────┐
  │  Router Node │ ──────────────────▶ │  Weather Agent     │
  │  (LLM call)  │                     │  tool: get_weather  │ ──▶ Answer
  └──────────────┘   route="stock"     └────────────────────┘
                  ──────────────────▶  ┌────────────────────┐
                                       │  Stock Agent        │
                                       │  tool: get_stock    │ ──▶ Answer
                                       └────────────────────┘

LangGraph Concepts Demonstrated:
  • TypedDict state object threaded through all nodes
  • Conditional edges — router's JSON decision drives which node runs next
  • Tool-augmented nodes — LLM sees tool schema, picks tool, executes, answers
  • Full prompt/response tracing rendered live in Streamlit
"""

import json, os, re, ssl
import urllib3, requests
import yfinance as yf
from datetime import datetime
from typing import TypedDict, List, Optional

from dotenv import load_dotenv
import streamlit as st

from langchain_aws import ChatBedrock
from langchain_core.messages import (
    HumanMessage, SystemMessage, AIMessage, ToolMessage, BaseMessage,
)
from langchain_core.tools import tool as lc_tool
from langgraph.graph import StateGraph, END

# ── SSL / corporate proxy bypass ──────────────────────────────────────────────
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
ssl._create_default_https_context = ssl._create_unverified_context
_http = requests.Session()
_http.verify = False


# ── .env loader (walks up to repo root) ──────────────────────────────────────
def _find_dotenv() -> str:
    current = os.path.abspath(os.getcwd())
    while True:
        candidate = os.path.join(current, ".env")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            raise SystemExit("Error: .env file not found in any parent directory.")
        current = parent


load_dotenv(dotenv_path=_find_dotenv())

AWS_REGION     = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID       = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
OPENWEATHER_KEY = os.getenv("OPENWEATHERMAP_API_KEY", "")


# ── LangChain Tools (no _diag param — tool args must match schema exactly) ────

@lc_tool
def get_weather(location: str, days: int = 1) -> str:
    """Get weather forecast for a city or location. Returns JSON with forecast data."""
    geo_url = (
        f"http://api.openweathermap.org/geo/1.0/direct"
        f"?q={location}&limit=1&appid={OPENWEATHER_KEY}"
    )
    geo = _http.get(geo_url)
    if geo.status_code != 200 or not geo.json():
        return json.dumps({"error": f"Location '{location}' not found."})

    g = geo.json()[0]
    lat, lon = g["lat"], g["lon"]
    w_url = (
        f"http://api.openweathermap.org/data/2.5/forecast"
        f"?lat={lat}&lon={lon}&appid={OPENWEATHER_KEY}&units=metric"
    )
    w = _http.get(w_url)
    if w.status_code != 200:
        return json.dumps({"error": "Could not retrieve forecast."})

    data = w.json()
    entries = data["list"][: min(8 * days, len(data["list"]))]
    forecasts = [
        {
            "time": f["dt_txt"],
            "description": f["weather"][0]["description"],
            "temp_c": round(f["main"]["temp"], 1),
            "humidity_pct": f["main"]["humidity"],
            "rain_probability_pct": round(f.get("pop", 0) * 100, 1),
            "wind_kmh": round(f["wind"]["speed"] * 3.6, 1),
        }
        for f in entries
    ]
    return json.dumps({"location": location, "forecast": forecasts}, indent=2)


@lc_tool
def get_stock_price(symbol: str) -> str:
    """Get latest stock price and info for a ticker symbol (e.g. AAPL, MSFT). Returns JSON."""
    try:
        stock = yf.Ticker(symbol)
        hist  = stock.history(period="2d")
        if hist.empty:
            return json.dumps({"error": f"No market data for symbol '{symbol}'."})
        info    = stock.info
        latest  = float(hist["Close"].iloc[-1])
        prev    = float(hist["Close"].iloc[0]) if len(hist) > 1 else latest
        change  = latest - prev
        return json.dumps(
            {
                "symbol":       symbol.upper(),
                "company":      info.get("shortName", "N/A"),
                "price":        round(latest, 2),
                "currency":     info.get("currency", "USD"),
                "change":       round(change, 2),
                "change_pct":   round((change / prev) * 100, 2) if prev else 0,
                "volume":       int(hist["Volume"].iloc[-1]),
                "exchange":     info.get("exchange", "N/A"),
                "timestamp":    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            },
            indent=2,
        )
    except Exception as exc:
        return json.dumps({"error": str(exc)})


# ── LangGraph State ───────────────────────────────────────────────────────────

class AgentState(TypedDict):
    user_query:   str
    route:        str   # "weather" | "stock" | "unknown"
    final_answer: str


# ── Diagnostic helpers ────────────────────────────────────────────────────────
# We store a reference to the current Streamlit diagnostic container here.
# This is set by run_agent() before the graph executes, cleared afterwards.
_diag: Optional[object] = None

_COLORS = {
    "router":   "#145a32",
    "decision": "#4a235a",
    "agent":    "#0b3d61",
    "tool":     "#1a5276",
    "final":    "#6e2f1a",
}


def _banner(title: str, kind: str = "agent") -> str:
    c = _COLORS.get(kind, "#333")
    return (
        f'<div style="background:{c};color:white;padding:6px 14px;'
        f'border-radius:6px;font-weight:bold;font-size:0.85em;margin-top:10px">'
        f"{title}</div>"
    )


def _show(label: str, data, lang: str = "json") -> None:
    if _diag is None:
        return
    _diag.markdown(f"**{label}**")
    if isinstance(data, (dict, list)):
        _diag.code(json.dumps(data, indent=2, default=str), language=lang)
    else:
        _diag.code(str(data), language=lang)


def _msgs_repr(messages: List[BaseMessage]) -> list:
    """Serialise LangChain messages for human-readable JSON display."""
    out = []
    for m in messages:
        d: dict = {"role": m.__class__.__name__, "content": m.content}
        if hasattr(m, "tool_calls") and m.tool_calls:
            d["tool_calls"] = [
                {"name": tc["name"], "args": tc["args"], "id": tc["id"]}
                for tc in m.tool_calls
            ]
        if hasattr(m, "tool_call_id") and m.tool_call_id:  # type: ignore[attr-defined]
            d["tool_call_id"] = m.tool_call_id             # type: ignore[attr-defined]
        out.append(d)
    return out


def _tool_schema(t) -> dict:
    schema = {}
    try:
        if hasattr(t, "args_schema") and t.args_schema:
            try:
                schema = t.args_schema.model_json_schema()
            except AttributeError:
                schema = t.args_schema.schema()
    except Exception:
        pass
    return {"name": t.name, "description": t.description, "input_schema": schema}


def _extract_json(text: str) -> dict:
    """Robust JSON extractor — handles code fences and surrounding text."""
    text = text.strip()
    # Strip markdown fences
    if "```" in text:
        blocks = re.findall(r"```(?:json)?\s*([\s\S]*?)```", text)
        if blocks:
            text = blocks[0].strip()
    # Try direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # Find first {...} in text
    m = re.search(r"\{[^{}]+\}", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group())
        except json.JSONDecodeError:
            pass
    return {}


# ── LLM factory ───────────────────────────────────────────────────────────────

def _llm() -> ChatBedrock:
    return ChatBedrock(
        model_id=MODEL_ID,
        region_name=AWS_REGION,
        model_kwargs={"temperature": 0.1, "max_tokens": 1500},
    )


# ── Node 1: Router ────────────────────────────────────────────────────────────

ROUTER_SYSTEM = """You are a query classifier. Your ONLY job is to classify user queries.

Respond with ONLY a JSON object — no explanation, no markdown, nothing else:
  {"route": "weather"}  — weather, temperature, rain, forecast, climate, humidity
  {"route": "stock"}    — stocks, share price, market data, company financials, ticker symbols
  {"route": "unknown"}  — anything else

Examples:
  "What is the weather in Paris?" → {"route": "weather"}
  "How is AAPL doing today?"      → {"route": "stock"}
  "Tell me a joke"                → {"route": "unknown"}"""


def router_node(state: AgentState) -> dict:
    query = state["user_query"]
    llm   = _llm()

    if _diag:
        _diag.markdown(_banner("🧭  NODE 1 — ROUTER  (LLM classifies the query)", "router"),
                       unsafe_allow_html=True)

    system = SystemMessage(content=ROUTER_SYSTEM)
    human  = HumanMessage(content=f'Classify this query: "{query}"')
    msgs: List[BaseMessage] = [system, human]

    # ── Show exact prompt going to LLM ────────────────────────────────────────
    if _diag:
        _diag.markdown("**📤 Exact messages array sent to LLM:**")
        _show("messages", _msgs_repr(msgs))

    response = llm.invoke(msgs)

    if _diag:
        _diag.markdown("**📥 Raw LLM response:**")
        _diag.code(response.content, language="text")

    parsed = _extract_json(response.content)
    route  = parsed.get("route", "unknown")

    if _diag:
        _diag.markdown(_banner(f"🔀  ROUTING DECISION → {route.upper()} AGENT", "decision"),
                       unsafe_allow_html=True)
        _diag.markdown(f"Parsed route from LLM response: **`{route}`**")

    return {"route": route}


# ── Conditional edge function ─────────────────────────────────────────────────

def _route_selector(state: AgentState) -> str:
    r = state.get("route", "unknown")
    if r == "weather":
        return "weather_agent"
    if r == "stock":
        return "stock_agent"
    return END


# ── Shared agentic loop (used by both weather and stock nodes) ─────────────────

def _run_agent_loop(
    node_label: str,
    system_prompt: str,
    tools: list,
    query: str,
) -> str:
    """
    One agentic loop:
      1. Send system + user message to LLM (with tools bound)
      2. LLM either returns tool_calls or a final text response
      3. If tool_calls: execute tool, append ToolMessage, call LLM again
      4. Return final text answer
    """
    llm_with_tools = _llm().bind_tools(tools)
    system = SystemMessage(content=system_prompt)
    human  = HumanMessage(content=query)
    msgs: List[BaseMessage] = [system, human]

    # ── Step A: first LLM call ────────────────────────────────────────────────
    if _diag:
        _diag.markdown("**📤 Step A — Messages sent to LLM (includes tool schema):**")
        _show("messages", _msgs_repr(msgs))
        _show("tool schemas available to LLM", [_tool_schema(t) for t in tools])

    response1: AIMessage = llm_with_tools.invoke(msgs)  # type: ignore[assignment]

    if _diag:
        _diag.markdown(
            f"**📥 Step B — LLM response** "
            f"(tool call requested: `{bool(response1.tool_calls)}`):"
        )
        _show("LLM response", _msgs_repr([response1])[0])

    # ── Step B: tool execution (if requested) ─────────────────────────────────
    if response1.tool_calls:
        tc        = response1.tool_calls[0]
        tool_name = tc["name"]
        tool_args = tc["args"]
        tool_id   = tc["id"]

        if _diag:
            _diag.markdown(_banner(f"🔧  TOOL EXECUTION: {tool_name}", "tool"),
                           unsafe_allow_html=True)
            _show("Arguments chosen by LLM", tool_args)

        tool_map    = {t.name: t for t in tools}
        tool_result = tool_map[tool_name].invoke(tool_args)

        if _diag:
            _diag.markdown("**Tool return value (sent back to LLM as context):**")
            try:
                _show("tool result", json.loads(tool_result))
            except Exception:
                _diag.code(str(tool_result)[:2000], language="text")

        # Append assistant message (with tool_call) + tool result message
        msgs.append(response1)
        msgs.append(ToolMessage(content=str(tool_result), tool_call_id=tool_id))

        # ── Step C: second LLM call (generate natural-language answer) ─────────
        if _diag:
            _diag.markdown("**📤 Step C — Second LLM call (context now includes tool result):**")
            _show("updated messages array", _msgs_repr(msgs))

        response2: AIMessage = llm_with_tools.invoke(msgs)  # type: ignore[assignment]
        final = response2.content

        if _diag:
            _diag.markdown(_banner(f"✅  FINAL ANSWER from {node_label}", "final"),
                           unsafe_allow_html=True)
            _diag.code(final, language="text")
        return final

    # LLM answered without calling a tool
    final = response1.content
    if _diag:
        _diag.markdown(_banner(f"✅  {node_label} answered directly (no tool call)", "final"),
                       unsafe_allow_html=True)
    return final


# ── Node 2: Weather Agent ─────────────────────────────────────────────────────

WEATHER_SYSTEM = """You are a weather assistant. Use the get_weather tool to answer weather questions.
Always call the tool to get real data, then summarise the result in a clear, friendly way."""


def weather_agent_node(state: AgentState) -> dict:
    if _diag:
        _diag.markdown(_banner("🌤️  NODE 2 — WEATHER AGENT", "agent"),
                       unsafe_allow_html=True)

    answer = _run_agent_loop(
        node_label    = "Weather Agent",
        system_prompt = WEATHER_SYSTEM,
        tools         = [get_weather],
        query         = state["user_query"],
    )
    return {"final_answer": answer}


# ── Node 3: Stock Agent ───────────────────────────────────────────────────────

STOCK_SYSTEM = """You are a stock market assistant. Use the get_stock_price tool to answer stock questions.
Always call the tool first, then present price, change, and any useful context concisely."""


def stock_agent_node(state: AgentState) -> dict:
    if _diag:
        _diag.markdown(_banner("📈  NODE 3 — STOCK AGENT", "agent"),
                       unsafe_allow_html=True)

    answer = _run_agent_loop(
        node_label    = "Stock Agent",
        system_prompt = STOCK_SYSTEM,
        tools         = [get_stock_price],
        query         = state["user_query"],
    )
    return {"final_answer": answer}


# ── Build and compile the LangGraph ──────────────────────────────────────────

def _build_graph():
    g = StateGraph(AgentState)
    g.add_node("router",        router_node)
    g.add_node("weather_agent", weather_agent_node)
    g.add_node("stock_agent",   stock_agent_node)

    g.set_entry_point("router")
    g.add_conditional_edges(
        "router",
        _route_selector,
        {
            "weather_agent": "weather_agent",
            "stock_agent":   "stock_agent",
            END:             END,
        },
    )
    g.add_edge("weather_agent", END)
    g.add_edge("stock_agent",   END)
    return g.compile()


# ── Cache the compiled graph — built once, reused across all Streamlit runs ───
# Do NOT call _build_graph() at module level: it would block the UI from
# rendering on every page load. @st.cache_resource builds it once and caches.

@st.cache_resource
def _get_graph():
    return _build_graph()


# ── Main entry called from Streamlit ─────────────────────────────────────────

def run_agent(query: str, diag_container) -> str:
    global _diag
    _diag = diag_container
    try:
        initial: AgentState = {
            "user_query":   query,
            "route":        "",
            "final_answer": "",
        }
        result = _get_graph().invoke(initial)
        return result.get("final_answer") or "⚠️ The router could not handle that query."
    finally:
        _diag = None


# ══════════════════════════════════════════════════════════════════════════════
# Streamlit UI
# ══════════════════════════════════════════════════════════════════════════════

if not OPENWEATHER_KEY:
    st.error("⚠️  OPENWEATHERMAP_API_KEY not set in .env — add it and restart.")
    st.stop()

st.title("LangGraph Router — Weather & Stock Agents")
st.markdown(
    """
A **Router Agent** (LLM call) classifies your query and delegates to the correct specialist agent.

```
User Query
    │
    ▼
[Router LLM]  →  {"route": "weather"} or {"route": "stock"}
    │                  │
    ▼                  ▼
[Weather Agent]   [Stock Agent]
(get_weather tool) (get_stock_price tool)
```

> Expand **🔍 LangGraph Step-by-Step Diagnostics** to see every LLM call, the exact
> messages array sent, tool invocations, and results.
"""
)

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

if prompt := st.chat_input("Ask about weather or stocks…"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        answer_slot = st.empty()

    st.markdown("---")
    with st.expander("🔍 LangGraph Step-by-Step Diagnostics", expanded=True):
        st.markdown(
            "<small>Every LLM call, routing decision, tool invocation, and result — "
            "rendered in sequence as the graph executes.</small>",
            unsafe_allow_html=True,
        )
        diag = st.container()

    with st.spinner("Graph running…"):
        answer = run_agent(prompt, diag)

    answer_slot.markdown(answer)
    st.session_state.messages.append({"role": "assistant", "content": answer})

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("LangGraph Router Demo")
    st.markdown(
        f"""
**Framework:** LangGraph + LangChain AWS
**Backend:** Amazon Bedrock
**Model:** `{MODEL_ID}`
**Region:** `{AWS_REGION}`

---

**Graph nodes:**

| Node | Role |
|------|------|
| `router` | LLM classifies query → JSON |
| `weather_agent` | LLM + `get_weather` tool |
| `stock_agent` | LLM + `get_stock_price` tool |

**Edges:**
`router` → conditional edge → `weather_agent` or `stock_agent`
Both agent nodes → `END`

---

**Key concept:** The router returns `{{"route": "weather"}}` or
`{{"route": "stock"}}`. LangGraph's `add_conditional_edges()`
reads that value and picks the next node.
"""
    )
    st.subheader("Sample Queries")
    st.markdown(
        """
**Weather:**
- "What's the weather in Tokyo?"
- "Will it rain in Mumbai tomorrow?"
- "How cold is it in Oslo?"

**Stocks:**
- "What's Apple's stock price?"
- "How is NVIDIA doing today?"
- "Show me TSLA"
"""
    )
