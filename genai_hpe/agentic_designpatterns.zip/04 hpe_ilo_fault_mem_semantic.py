# -*- coding: utf-8 -*-
"""
Semantic Memory Pattern — HPE iLO Fault Pattern Learning System
================================================================
Implemented with LangGraph State + MemorySaver Checkpointing

Focus: the VALUE of SEMANTIC MEMORY specifically.

The demo runs four server incidents on a single on-call shift. After each
incident the graph extracts a generalizable hardware fault pattern and adds
it to the shared semantic knowledge base. Incidents 3 and 4 benefit from
what incidents 1 and 2 taught the system. A side-by-side comparison for
Incident 3 shows the concrete difference between "HPE documentation only"
and "documentation + learned fault patterns" semantic memory.

LangGraph constructs used:
  - StateGraph with TypedDict state
  - Annotated[List[str], operator.add] on semantic_learned:
      every incident APPENDS new patterns to the accumulating list
  - MemorySaver + thread_id = shift_id:
      all incidents in a shift share one checkpoint, so patterns persist
      from one server event to the next
  - A dedicated extract_pattern_node:
      generalises a specific incident into a transferable diagnostic rule

Why semantic, not episodic?
  Episodic would store: "proliant-node-02 had a BBU fault on Friday at 3 AM."
  Semantic extracts:    "Smart Array BBU fault + high ambient temp → thermal
                         throttle reduces write performance → I/O queue fills →
                         write-back cache is disabled → latency spike → OOM."
  The semantic form belongs to NO specific server. It fires for
  proliant-node-05 — a completely different server — the moment its BBU
  fault alert appears.

================================================================================
HPE USE CASE — Why Semantic Memory Transforms iLO Support:
================================================================================
A Level-1 NOC engineer monitoring HPE ProLiant servers sees hundreds of iLO
alerts per shift. Most are noise. Some are the first symptom of a multi-stage
cascade failure. Without semantic memory, each alert is evaluated in isolation.
With semantic memory, the system recognises: "this BBU fault looks like what
caused the cluster meltdown last Tuesday — act NOW before the I/O storm."

The four incidents in this demo:
  Incident 1: Smart Array P408i BBU fault → learned: BBU fault cascade pattern
  Incident 2: iLO thermal throttle on DL360 → learned: thermal-storage interaction
  Incident 3: NVMe drive SMART failure      → benefits from Incident 1 pattern
  Incident 4: Memory UE error (DIMM fault)  → benefits from all prior patterns
"""

import os
import json
import operator
from pathlib import Path
from typing import TypedDict, List, Annotated
from textwrap import dedent
from datetime import datetime
from dotenv import load_dotenv
import warnings

warnings.filterwarnings("ignore")

import sys
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------
def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

from langchain_aws import ChatBedrock
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

llm = ChatBedrock(model_id=MODEL_ID, region_name=AWS_REGION, model_kwargs={"temperature": 0.4})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def pause(msg="Press Enter to continue..."):
    try:
        input(f"\n  [{msg}] ")
    except EOFError:
        print("  [non-interactive: continuing automatically]")
    print()

def section(title, width=70):
    print("=" * width)
    print(f"  {title}")
    print("=" * width)

def subsection(title, width=70):
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print("─" * width)


# =============================================================================
# FOUR HPE SERVER INCIDENTS — Processed in sequence during one on-call shift
# =============================================================================

HPE_INCIDENTS = [
    {
        "id": "INC-001",
        "server": "proliant-node-02",
        "model": "HPE ProLiant DL380 Gen11",
        "alert": "Smart Array P408i-a: Battery Backup Unit (BBU) fault",
        "ilo_iml": dedent("""\
            03:08:33  CAUTION  [Thermal]  CPU1: 83C — exceeded warn threshold (82C)
            03:08:33  CAUTION  [Power]    CPU1 throttled P0→P3 (-48% performance)
            03:10:08  CRITICAL [Storage]  Smart Array P408i-a: BBU fault — write-back DISABLED
            03:10:09  CRITICAL [Storage]  Controller entered write-through mode
            03:12:16  CRITICAL [OS]       OOM kill: python3 (ML training job, 128GB RSS)
            03:22:41  CRITICAL [System]   ASR watchdog reset — OS unresponsive 180s
        """),
        "outcome": "Server crashed. ML training job lost. 6m54s downtime.",
    },
    {
        "id": "INC-002",
        "server": "proliant-node-05",
        "model": "HPE ProLiant DL360 Gen11",
        "alert": "iLO thermal alert: CPU1 temperature 79C (warn: 75C)",
        "ilo_iml": dedent("""\
            14:22:05  CAUTION  [Thermal]  CPU1: 79C — exceeded warn threshold (75C)
            14:22:06  WARNING  [Power]    CPU1 throttled P0→P1 (-12% performance)
            14:28:19  WARNING  [Fan]      Zone B: 45% → 82% (thermal auto-response)
            14:35:40  CAUTION  [Thermal]  CPU1: 81C — rising despite fan increase
            14:38:11  WARNING  [Storage]  Smart Array: write queue 72% (3,686/5,120)
            14:42:00  INFO     [Thermal]  CPU1: 76C — stabilizing after airflow check
        """),
        "outcome": "Stabilized after NOC adjusted airflow. No crash, but 20% perf degradation for 20 minutes.",
    },
    {
        "id": "INC-003",
        "server": "proliant-node-07",
        "model": "HPE ProLiant DL380 Gen11",
        "alert": "Smart Array P408i-a: Physical drive bay 2 SMART predictive failure (SN: SEA-NVMe-002)",
        "ilo_iml": dedent("""\
            09:15:03  WARNING  [Storage]  Drive bay 2 SMART attr 5 (reallocated sectors): +1,847 in 24h
            09:15:05  WARNING  [Storage]  Drive bay 2 SMART attr 187 (uncorrectable errors): 3
            09:20:14  WARNING  [Storage]  Smart Array P408i: I/O retry count elevated (bay 2: 847 retries/min)
            09:25:33  CAUTION  [Storage]  Smart Array P408i: RAID-5 array degraded — drive bay 2 marked failed
            09:25:35  CAUTION  [Storage]  Smart Array P408i: RAID rebuild started on spare drive (bay 8)
            09:25:40  INFO     [Storage]  Write queue depth: 68% (3,481/5,120) during rebuild
        """),
        "outcome": "RAID rebuild in progress. Server operational but storage performance degraded.",
    },
    {
        "id": "INC-004",
        "server": "proliant-node-03",
        "model": "HPE ProLiant DL380 Gen11",
        "alert": "EDAC memory error: Uncorrectable Error (UE) on DIMM slot 4B",
        "ilo_iml": dedent("""\
            22:08:41  WARNING  [Memory]   DIMM 4B: correctable ECC errors +412 in 1 hour (elevated)
            22:08:42  INFO     [Memory]   Memory patrol scrub triggered (auto-response to CE spike)
            22:31:05  CRITICAL [Memory]   DIMM 4B: Uncorrectable Error (UE) — hardware fault
            22:31:06  CRITICAL [System]   Machine Check Exception (MCE) raised — CPU2 halted
            22:31:10  CRITICAL [OS]       OS heartbeat lost — iLO monitoring
            22:33:44  CRITICAL [System]   ASR watchdog reset triggered (unresponsive 180s)
        """),
        "outcome": "Server crashed. DIMM 4B failed. Requires physical DIMM replacement.",
    },
]


# =============================================================================
# LANGGRAPH STATE
# semantic_learned uses operator.add — every incident APPENDS, never overwrites
# =============================================================================

class ShiftState(TypedDict):
    # Current incident being processed
    incident_id:      str
    server:           str
    model:            str
    alert:            str
    ilo_iml:          str
    incident_outcome: str

    # Agent outputs for current incident
    triage_analysis:  str
    action_plan:      str

    # Accumulating semantic knowledge — APPENDS across all incidents in the shift
    semantic_learned: Annotated[List[str], operator.add]


# =============================================================================
# NODE FUNCTIONS
# =============================================================================

def triage_node(state: ShiftState) -> dict:
    """
    Triage the current iLO alert.
    If semantic_learned contains patterns, use them to improve diagnosis.
    """
    semantic_context = ""
    if state.get("semantic_learned"):
        patterns = "\n\n".join(
            f"  LEARNED PATTERN {i+1}:\n  {p}"
            for i, p in enumerate(state["semantic_learned"])
        )
        semantic_context = f"""
FAULT PATTERNS LEARNED EARLIER THIS SHIFT (apply these to this incident):
{patterns}

"""

    prompt = dedent(f"""\
        You are an HPE NOC Level-2 Engineer triaging a ProLiant server alert.
        {semantic_context}
        CURRENT INCIDENT:
        Server:  {state['server']} ({state['model']})
        Alert:   {state['alert']}
        iLO IML:
        {state['ilo_iml']}

        Provide a concise triage analysis (3-4 paragraphs):
        1. Immediate risk assessment — is this a pre-failure warning or active failure?
        2. Root cause hypothesis — what component is failing and why?
        3. Cascade risk — based on the IML sequence, what could go wrong next if not acted on?
        4. Urgency classification (P1-Critical / P2-High / P3-Medium / P4-Low)

        If any LEARNED PATTERNS above are relevant, explicitly state how they informed your assessment.
    """)
    response = llm.invoke(prompt)
    return {"triage_analysis": response.content}


def action_plan_node(state: ShiftState) -> dict:
    """Generate HPE-specific action steps for the triaged incident."""
    prompt = dedent(f"""\
        You are an HPE Level-3 Support Engineer. Based on this triage, produce an
        action plan with exact HPE tool commands and procedures.

        SERVER: {state['server']} ({state['model']})
        ALERT:  {state['alert']}
        TRIAGE: {state['triage_analysis']}

        Produce a numbered action plan (max 5 steps):
        - Step number + what to do
        - Exact HPE command or procedure (ssacli, iLO CLI, Redfish API, SPP)
        - Expected output or success criterion

        Keep it executable — a field engineer must be able to follow this at 3 AM.
    """)
    response = llm.invoke(prompt)
    return {"action_plan": response.content}


def extract_pattern_node(state: ShiftState) -> dict:
    """
    Extract a generalizable fault pattern from this incident.
    This is the semantic memory creation step — the pattern must NOT
    reference the specific server. It must fire for ANY similar server.
    """
    prompt = dedent(f"""\
        You have just triaged this HPE ProLiant server incident:

        Alert:    {state['alert']}
        IML Data: {state['ilo_iml']}
        Outcome:  {state['incident_outcome']}
        Analysis: {state['triage_analysis']}

        Extract ONE generalizable fault pattern that will help diagnose SIMILAR
        incidents on DIFFERENT servers in future.

        CRITICAL RULE: Do NOT mention the specific server name ({state['server']}).
        The pattern must be in the form: "IF [observable signal(s)] THEN [diagnosis + risk]"

        Format your response as:
        PATTERN: [one-line IF→THEN rule]
        MECHANISM: [2-3 sentences explaining the hardware/firmware interaction]
        EARLY WARNING SIGNALS: [2-3 specific iLO IML entries or metrics to watch]
        RECOMMENDED EARLY ACTION: [one specific HPE command or procedure]
    """)
    response = llm.invoke(prompt)
    return {"semantic_learned": [response.content]}


# =============================================================================
# GRAPH CONSTRUCTION
# =============================================================================

def build_shift_graph():
    builder = StateGraph(ShiftState)
    builder.add_node("triage",          triage_node)
    builder.add_node("action_plan",     action_plan_node)
    builder.add_node("extract_pattern", extract_pattern_node)

    builder.set_entry_point("triage")
    builder.add_edge("triage",          "action_plan")
    builder.add_edge("action_plan",     "extract_pattern")
    builder.add_edge("extract_pattern", END)

    checkpointer = MemorySaver()
    return builder.compile(checkpointer=checkpointer)


# =============================================================================
# MAIN
# =============================================================================

def run_with_textbook_only(incident: dict, graph, shift_id: str) -> str:
    """Run triage WITHOUT semantic memory — simulate a fresh system with no learned patterns."""
    config = {"configurable": {"thread_id": f"{shift_id}-textbook-only"}}
    state: ShiftState = {
        "incident_id":      incident["id"],
        "server":           incident["server"],
        "model":            incident["model"],
        "alert":            incident["alert"],
        "ilo_iml":          incident["ilo_iml"],
        "incident_outcome": incident["outcome"],
        "triage_analysis":  "",
        "action_plan":      "",
        "semantic_learned": [],   # ← no learned patterns
    }
    result = graph.invoke(state, config=config)
    return result.get("triage_analysis", "")


if __name__ == "__main__":
    section("SEMANTIC MEMORY PATTERN — HPE iLO Fault Pattern Learning System")
    print("""
  SCENARIO
  ─────────
  You are a Level-2 NOC engineer on an overnight on-call shift monitoring
  a fleet of HPE ProLiant DL380/DL360 Gen11 servers. Four server incidents
  occur during your shift.

  WITHOUT semantic memory: each alert is evaluated from HPE documentation alone.
  WITH semantic memory:    patterns extracted from earlier incidents inform
                           the diagnosis of later ones — just like an experienced
                           engineer who has "seen this before."

  The system uses LangGraph's Annotated[List[str], operator.add] reducer
  to ACCUMULATE learned patterns across incidents within a shift.
  All incidents share a single MemorySaver checkpoint (thread_id = shift_id).

  EPISODIC vs SEMANTIC:
    Episodic: "proliant-node-02 had a BBU fault on 2025-03-21 at 03:10."
              (specific to that server, that time)
    Semantic: "BBU fault → write-through mode → I/O latency spike → OOM cascade"
              (fires for ANY server showing the same pattern)
""")

    shift_id = f"shift-{datetime.now().strftime('%Y%m%d-%H%M')}"
    graph = build_shift_graph()

    # State accumulates across incidents — carry semantic_learned forward
    accumulated_patterns: List[str] = []

    for idx, incident in enumerate(HPE_INCIDENTS):
        pause(f"Press Enter to process Incident {idx+1}/4: {incident['id']} — {incident['server']}")

        subsection(f"INCIDENT {idx+1}/4 — {incident['id']}")
        print(f"  Server:  {incident['server']} ({incident['model']})")
        print(f"  Alert:   {incident['alert']}")
        print(f"  Learned patterns available: {len(accumulated_patterns)}")
        print()

        config = {"configurable": {"thread_id": f"{shift_id}-inc-{idx+1}"}}

        state: ShiftState = {
            "incident_id":      incident["id"],
            "server":           incident["server"],
            "model":            incident["model"],
            "alert":            incident["alert"],
            "ilo_iml":          incident["ilo_iml"],
            "incident_outcome": incident["outcome"],
            "triage_analysis":  "",
            "action_plan":      "",
            "semantic_learned": list(accumulated_patterns),  # inject prior patterns
        }

        result = graph.invoke(state, config=config)

        print("  TRIAGE ANALYSIS:")
        print("─" * 70)
        print(result["triage_analysis"])

        print("\n  ACTION PLAN:")
        print("─" * 70)
        print(result["action_plan"])

        new_patterns = result.get("semantic_learned", [])
        # new_patterns contains ALL patterns (old + new); extract just the new one
        new_pattern = new_patterns[-1] if new_patterns else ""

        print(f"\n  EXTRACTED FAULT PATTERN (added to semantic memory):")
        print("─" * 70)
        print(new_pattern)

        accumulated_patterns = new_patterns  # carry forward for next incident

        # Side-by-side comparison for Incident 3 (first incident to benefit from 2 patterns)
        if idx == 2:
            pause(f">> Incident {idx+1} used {idx} prior patterns. Press Enter to see side-by-side comparison.")
            subsection(f"SIDE-BY-SIDE COMPARISON — Incident {idx+1}: WITH vs WITHOUT Semantic Memory")

            print("  --- WITHOUT SEMANTIC MEMORY (textbook only) ---")
            print()
            textbook_analysis = run_with_textbook_only(incident, graph, shift_id)
            print(textbook_analysis)

            print()
            print("  --- WITH SEMANTIC MEMORY (textbook + 2 learned patterns) ---")
            print()
            print(result["triage_analysis"])

            print()
            print("  WHAT CHANGED WITH SEMANTIC MEMORY:")
            print("    The learned patterns from Incidents 1 and 2 allow the system to:")
            print("    - Recognise the cascade risk BEFORE it happens")
            print("    - Recommend the BBU-specific early action (ssacli check)")
            print("    - Flag that RAID rebuild + thermal stress = compounding risk")
            print("    The textbook-only version treats this as an isolated storage alert.")
            print("    The semantic version says: 'I've seen this cascade before — act NOW.'")

    # Final summary
    print()
    section("SHIFT SUMMARY — ACCUMULATED SEMANTIC KNOWLEDGE")
    print(f"\n  {len(accumulated_patterns)} fault patterns learned during this shift:\n")
    for i, pattern in enumerate(accumulated_patterns, 1):
        print(f"  PATTERN {i}:")
        for line in pattern.splitlines()[:4]:
            print(f"    {line}")
        print()

    print("""
  KEY TAKEAWAYS — SEMANTIC MEMORY:

    1. Semantic memory is GENERALISED knowledge, not episode recall.
       The pattern "BBU fault → write-through → latency spike → OOM" fires
       for any server, any time — not just proliant-node-02 on that Friday.

    2. LangGraph's operator.add reducer accumulates patterns without ever
       overwriting. Each incident APPENDS its lesson to the shared list.
       The list grows; nothing is lost.

    3. MemorySaver + thread_id = shift_id means all incidents in a shift
       share one persistent checkpoint. The graph "remembers" across invocations
       within the same shift thread.

    4. HPE NOC engineers naturally build semantic memory over years of experience.
       This pattern replicates that capability in software — a junior engineer
       on their first on-call shift has access to the pattern library of an expert.
""")
