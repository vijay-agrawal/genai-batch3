#!/usr/bin/env python3
"""
Reflection Pattern — HPE Server Incident Root Cause Analysis (RCA) Writer
==========================================================================

REFLECTION pattern : The SAME agent reviews its OWN previous outputs across
                     multiple iterations, accumulates self-critique notes, and
                     uses them to improve the NEXT attempt.
                     ("How do I get better over time / across iterations?")
                     → This demo

================================================================================
REFLECTION PATTERN — HOW IT WORKS:
================================================================================
Key characteristics:
  - Single agent identity (same role, same system prompt — HPE RCA Analyst)
  - The agent reads back its OWN previous draft(s)
  - It writes explicit self-critique notes ("what did I miss?")
  - Those notes are carried in state and fed into the NEXT generation pass
  - This loop repeats N times — each iteration the draft gets better
  - Improvement comes from accumulated self-knowledge, not an external reviewer

Mechanics implemented in this demo:
  NOTE: There is ONE agent (RCA_AUTHOR_SYSTEM prompt). The LangGraph "nodes" below
  are sequential phases of that single agent's loop — not separate agents.
  evaluate_node is purely deterministic (no LLM call).

  1. GraphState holds:  current_draft, reflection_notes (list), iteration count,
                        evaluation_scores (list of metric dicts per draft)
  2. generate_node  :  [AGENT — write phase]
                        Same agent reads raw iLO IML + kernel logs + ALL its own prior
                        reflection notes → produces a new/improved RCA draft
  3. evaluate_node  :  [NOT an agent — rule-based scorer, no LLM call]
                        Scores the current draft on 5 deterministic metrics:
                        timeline accuracy, root cause clarity, evidence completeness,
                        mitigation steps, technical accuracy — all 0-100
                        → computes a weighted OVERALL score
  4. reflect_node   :  [AGENT — critique phase, same agent identity as generate_node]
                        The same agent reads its own current draft
                        → writes honest self-critique (what's missing, vague, wrong)
                        → appends critique to reflection_notes list
  5. router         :  STOP if overall score >= QUALITY_THRESHOLD  ← early stop
                        STOP if iteration > MAX_REFLECTIONS        ← hard cap
                        CONTINUE → reflect (and then generate again)
  6. Each generate pass explicitly tells the LLM:
        "This is your Nth attempt.  Here is what you wrote before.
         Here are your own reflection notes.  Now do better."

================================================================================
HPE USE CASE — Why Reflection Matters Here:
================================================================================
An HPE ProLiant DL380 Gen11 (proliant-node-02) crashed at 3:22 AM during an
overnight ML training job. The raw data is a mix of:
  - iLO 6 Integrated Management Log (IML) — hardware-layer events
  - Linux kernel fragments — OS-layer events
  - Active HPE advisory numbers — firmware context

A first-pass RCA from raw logs is typically rough:
  - Abbreviations left unexplained (BBU, ASR, EDAC, DIMM)
  - Timeline is vague ("sometime before the crash")
  - Root cause stated too broadly ("storage issue caused the crash")
  - No mitigation steps with specific HPE tooling
  - Missing: Advisory cross-references, firmware gaps

Reflection then identifies these gaps → later drafts fix them →
metrics visibly rise. Each evaluate pass prints a WHY DID SCORES CHANGE?
explanation tracing: reflection note → agent action → metric movement.

================================================================================
EVALUATION METRICS (rule-based, deterministic — no extra LLM calls):
================================================================================
Metric                    Weight  What it measures
────────────────────────────────────────────────────────────────────────────────
Timeline Accuracy           25%   Does RCA include timestamps for each key event?
Root Cause Clarity          30%   Is the primary root cause clearly named with
                                  the mechanism explained (not just "hardware failure")?
Evidence Completeness       20%   Are iLO IML entries, kernel log lines, and
                                  advisory numbers cited as specific evidence?
Mitigation Steps            15%   Are there actionable next steps using real HPE
                                  tools (ssacli, iLO REST API, SPP, OneView)?
Technical Accuracy          10%   Are HPE-specific terms used correctly?
                                  (BBU, write-through vs write-back, ASR watchdog, EDAC)
────────────────────────────────────────────────────────────────────────────────
OVERALL (weighted)                Combined score used for stop decision

Stop conditions (evaluated after EVERY draft):
  1. QUALITY_THRESHOLD : if OVERALL >= threshold AND >= MIN_REFLECTIONS passes done
  2. MIN_REFLECTIONS   : early stop blocked until this many passes have run
  3. MAX_REFLECTIONS   : hard cap → stop regardless of score
================================================================================
"""

#!/usr/bin/env python3

import os
import re
import sys
from pathlib import Path
from typing import TypedDict, List

from dotenv import load_dotenv
from langchain_aws import ChatBedrock
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph

import warnings
warnings.filterwarnings("ignore")

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------
def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")

llm = ChatBedrock(
    model_id=MODEL_ID,
    region_name=AWS_REGION,
    model_kwargs={"temperature": 0.7},
)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
MAX_REFLECTIONS     = 4    # Hard cap on reflection iterations
MIN_REFLECTIONS     = 1    # Must do at least this many before early-stop
QUALITY_THRESHOLD   = 88   # Stop early if weighted score >= this

# ---------------------------------------------------------------------------
# Graph state
# ---------------------------------------------------------------------------
class RCAState(TypedDict):
    server_report:      str          # Raw iLO report — set once before graph runs
    current_draft:      str          # Latest RCA draft
    reflection_notes:   List[str]    # Accumulated self-critique from each pass
    evaluation_scores:  List[dict]   # Score dicts per draft
    iteration:          int


# ---------------------------------------------------------------------------
# Raw server incident data (also readable from data/ilo_server_health_report.txt)
# ---------------------------------------------------------------------------
def read_server_report() -> str:
    data_path = Path(__file__).resolve().parent / "data" / "ilo_server_health_report.txt"
    if data_path.exists():
        return data_path.read_text(encoding="utf-8")
    return SERVER_REPORT_INLINE

SERVER_REPORT_INLINE = """\
HPE ProLiant DL380 Gen11 — proliant-node-02 — Unexpected reset 03:22:41 UTC
iLO IML: CPU1 thermal throttle P0->P3 at 03:08:33 | BBU fault write-through at 03:10:08
         UE memory error DIMM 6A at 03:15:44 | ASR watchdog reset at 03:22:41
Kernel:  hpsa controller busy retries failed 03:09:15 | OOM kill python3 03:12:16
         EDAC uncorrectable error 03:15:44 | kernel panic machine check 03:15:50
Advisories: c08245132 (Smart Array P408i BBU), a00125843en (iLO 6 thermal)
"""

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

RCA_AUTHOR_SYSTEM = (
    "You are an HPE Level-3 Support Engineer specialising in ProLiant server "
    "incident root cause analysis. You write RCA documents from raw iLO IML entries "
    "and kernel logs that are used by field engineers to fix hardware and prevent recurrence. "
    "Your RCAs must be technically precise, cite specific log evidence, and include "
    "actionable mitigation steps using real HPE tooling."
)

# First-pass prompt — deliberately minimal to produce a rough baseline draft
RCA_FIRST_PASS_TEMPLATE = """\
Write a QUICK FIRST DRAFT Root Cause Analysis from the server incident data below.
Do not worry about completeness — just capture the key facts as you see them.

--- SERVER INCIDENT DATA ---
{server_report}
----------------------------
"""

# Subsequent passes — explicitly feeds back all prior reflection notes
RCA_IMPROVED_PASS_TEMPLATE = """\
You are revising your Root Cause Analysis — this is attempt #{iteration}.

HERE IS WHAT YOU WROTE PREVIOUSLY:
{previous_draft}

YOUR OWN REFLECTION NOTES FROM ALL PRIOR PASSES (read these carefully):
{reflection_notes_block}

Now write a SIGNIFICANTLY IMPROVED RCA that addresses every gap you identified.

Required sections:
1. INCIDENT SUMMARY      (server, time, business impact)
2. TIMELINE              (each event with exact timestamp from the logs)
3. ROOT CAUSE            (primary cause — name it specifically, explain the mechanism)
4. CONTRIBUTING FACTORS  (secondary causes that amplified the primary)
5. EVIDENCE              (cite specific iLO IML entries, kernel log lines, advisory numbers)
6. MITIGATION STEPS      (numbered, with exact HPE tool commands: ssacli, iLO CLI,
                          SPP update procedure, iLO REST API calls where applicable)
7. PREVENTION            (configuration changes, monitoring thresholds, firmware updates)

--- SERVER INCIDENT DATA ---
{server_report}
----------------------------
"""

REFLECT_TEMPLATE = """\
You have just written this Root Cause Analysis (RCA) draft.
Read it critically — as if you were a senior HPE engineer reviewing a junior's work.

YOUR DRAFT:
{current_draft}

Write specific, honest self-critique notes. For each gap you find:
  - Name the exact section or missing item
  - Explain WHY it matters for an HPE field engineer reading this
  - State what you should add or fix in the NEXT draft

Focus on:
  - Are timestamps cited for EVERY key event? Or is the timeline vague?
  - Is the root cause named specifically (e.g., "BBU capacitor degradation") or vague ("hardware failure")?
  - Are HPE IML entries and kernel log lines quoted as direct evidence?
  - Are HPE advisory numbers (c08245132, a00125843en) referenced?
  - Do the mitigation steps name real HPE tools (ssacli, iLO 6 CLI, SPP, OneView)?
  - Are technical abbreviations (BBU, ASR, EDAC, DIMM, write-through) explained on first use?
"""


# ---------------------------------------------------------------------------
# Evaluation (rule-based, deterministic — no LLM call)
# ---------------------------------------------------------------------------
def evaluate_rca(draft: str, iteration: int) -> dict:
    text = draft.lower()

    # Timeline Accuracy (25%) — presence of exact HH:MM timestamps
    ts_matches = len(re.findall(r'\d{2}:\d{2}:\d{2}', draft))
    timeline_score = min(100, ts_matches * 20)   # 5 timestamps = 100

    # Root Cause Clarity (30%) — specific root cause language
    rc_keywords = ["bbu", "battery backup", "write-through", "thermal throttl",
                   "uncorrectable memory", "dimm 6a", "smart array"]
    rc_hits = sum(1 for kw in rc_keywords if kw in text)
    root_cause_score = min(100, rc_hits * 20)

    # Evidence Completeness (20%) — advisory numbers + log citations
    evidence_kw = ["c08245132", "a00125843en", "iml", "kernel", "edac",
                   "hpsa", "asr", "0000:05:00.0"]
    ev_hits = sum(1 for kw in evidence_kw if kw in text)
    evidence_score = min(100, ev_hits * 18)

    # Mitigation Steps (15%) — HPE tool names
    mit_kw = ["ssacli", "ilo", "spp", "service pack", "oneview", "redfish",
              "firmware", "advisory", "dimm replacement", "bbu replacement"]
    mit_hits = sum(1 for kw in mit_kw if kw in text)
    mitigation_score = min(100, mit_hits * 14)

    # Technical Accuracy (10%) — correct HPE-specific terms used
    tech_kw = ["write-back", "write-through", "iml", "asm", "asr watchdog",
               "bbu", "p-state", "p0", "p3", "edac", "uncorrectable"]
    tech_hits = sum(1 for kw in tech_kw if kw in text)
    tech_score = min(100, tech_hits * 14)

    overall = (
        timeline_score   * 0.25 +
        root_cause_score * 0.30 +
        evidence_score   * 0.20 +
        mitigation_score * 0.15 +
        tech_score       * 0.10
    )

    return {
        "iteration":        iteration,
        "timeline":         round(timeline_score),
        "root_cause":       round(root_cause_score),
        "evidence":         round(evidence_score),
        "mitigation":       round(mitigation_score),
        "technical":        round(tech_score),
        "overall":          round(overall, 1),
    }


def explain_score_change(prev: dict, curr: dict) -> str:
    lines = []
    deltas = {
        "timeline":   ("Timeline Accuracy",   "25%"),
        "root_cause": ("Root Cause Clarity",  "30%"),
        "evidence":   ("Evidence Completeness","20%"),
        "mitigation": ("Mitigation Steps",    "15%"),
        "technical":  ("Technical Accuracy",  "10%"),
    }
    for key, (label, weight) in deltas.items():
        diff = curr[key] - prev[key]
        if diff != 0:
            direction = "IMPROVED" if diff > 0 else "DECLINED"
            lines.append(f"  {label} ({weight}): {prev[key]} → {curr[key]} [{direction} {abs(diff):+d}]")
    if not lines:
        lines.append("  No metric changes detected in this pass.")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# LangGraph nodes
# ---------------------------------------------------------------------------
def generate_node(state: RCAState) -> dict:
    iteration = state.get("iteration", 0) + 1
    reflection_notes = state.get("reflection_notes", [])

    if iteration == 1:
        prompt = RCA_FIRST_PASS_TEMPLATE.format(server_report=state["server_report"])
    else:
        notes_block = "\n\n".join(
            f"--- REFLECTION PASS {i+1} ---\n{note}"
            for i, note in enumerate(reflection_notes)
        )
        prompt = RCA_IMPROVED_PASS_TEMPLATE.format(
            iteration=iteration,
            previous_draft=state["current_draft"],
            reflection_notes_block=notes_block,
            server_report=state["server_report"],
        )

    response = llm.invoke([
        SystemMessage(content=RCA_AUTHOR_SYSTEM),
        HumanMessage(content=prompt),
    ])
    return {
        "current_draft": response.content,
        "iteration":     iteration,
    }


def evaluate_node(state: RCAState) -> dict:
    scores = state.get("evaluation_scores", [])
    new_score = evaluate_rca(state["current_draft"], state["iteration"])
    return {"evaluation_scores": scores + [new_score]}


def reflect_node(state: RCAState) -> dict:
    response = llm.invoke([
        SystemMessage(content=RCA_AUTHOR_SYSTEM),
        HumanMessage(content=REFLECT_TEMPLATE.format(
            current_draft=state["current_draft"]
        )),
    ])
    notes = state.get("reflection_notes", [])
    return {"reflection_notes": notes + [response.content]}


def router(state: RCAState) -> str:
    scores = state.get("evaluation_scores", [])
    if not scores:
        return "reflect"
    latest = scores[-1]
    iteration = state.get("iteration", 0)
    if (latest["overall"] >= QUALITY_THRESHOLD and iteration >= MIN_REFLECTIONS + 1):
        return END
    if iteration > MAX_REFLECTIONS:
        return END
    return "reflect"


# ---------------------------------------------------------------------------
# Build graph
# ---------------------------------------------------------------------------
def build_graph():
    g = StateGraph(RCAState)
    g.add_node("generate",  generate_node)
    g.add_node("evaluate",  evaluate_node)
    g.add_node("reflect",   reflect_node)

    g.add_edge(START,       "generate")
    g.add_edge("generate",  "evaluate")
    g.add_conditional_edges("evaluate", router, {"reflect": "reflect", END: END})
    g.add_edge("reflect",   "generate")
    return g.compile()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def pause(msg: str = "") -> None:
    if msg:
        print(msg)
    try:
        input("  >>> Press Enter to continue... ")
    except EOFError:
        print("  [non-interactive: continuing automatically]")
    print()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
if __name__ == "__main__":

    print("=" * 72)
    print("  REFLECTION PATTERN DEMO — HPE Server Incident RCA Writer")
    print("=" * 72)
    print()
    print("WHAT IS THE REFLECTION PATTERN?")
    print("-" * 72)
    print("The SAME agent writes an RCA, then reviews its OWN draft,")
    print("identifies gaps, and improves in the next iteration.")
    print()
    print("  ONE agent (same system prompt) runs two phases each iteration:")
    print("  generate_node : agent WRITES  — RCA draft from iLO + kernel logs  (LLM)")
    print("  evaluate_node : rule-based scorer — no agent, no LLM call")
    print("  reflect_node  : agent CRITIQUES its own draft                      (LLM)")
    print()
    print("  This is DIFFERENT from the Critic pattern (demo 02) where a")
    print("  SEPARATE agent (different role/prompt) reviews another agent's work.")
    print("  Here the same agent critiques itself — self-knowledge accumulates")
    print("  across iterations; each draft is informed by ALL prior reflections.")
    print()
    print(f"  LLM backend : {MODEL_ID}  (AWS Bedrock)")
    print(f"  Max drafts  : {MAX_REFLECTIONS + 1}  (stop early if score >= {QUALITY_THRESHOLD}%)")
    print()

    pause(
        "INCIDENT SCENARIO\n"
        + "-" * 72 + "\n"
        + "HPE ProLiant DL380 Gen11 (proliant-node-02) crashed at 03:22:41 AM\n"
        + "during a 6-hour ML training job. The iLO ASR watchdog fired.\n"
        + "Raw data: iLO IML entries, kernel fragments, HPE advisory numbers.\n"
        + "The RCA must be technically precise — a field engineer acts on this."
    )

    server_report = read_server_report()

    # Show evaluation rubric
    print("EVALUATION RUBRIC (rule-based, deterministic — no extra LLM calls):")
    print("-" * 72)
    print("  Timeline Accuracy   (25%) — timestamps cited for each key event")
    print("  Root Cause Clarity  (30%) — specific cause named + mechanism explained")
    print("  Evidence Complete.  (20%) — IML entries, kernel lines, advisory numbers cited")
    print("  Mitigation Steps    (15%) — uses real HPE tools (ssacli, SPP, iLO CLI)")
    print("  Technical Accuracy  (10%) — HPE terms used correctly (BBU, ASR, EDAC)")
    print()
    print(f"  Early stop: OVERALL >= {QUALITY_THRESHOLD}% after >= {MIN_REFLECTIONS+1} drafts")
    print(f"  Hard cap:   {MAX_REFLECTIONS+1} drafts maximum")
    print()

    pause(">> Starting LangGraph reflection loop now. Watch scores improve.")

    print("=" * 72)
    print("  RUNNING REFLECTION LOOP")
    print("=" * 72)

    app = build_graph()
    initial: RCAState = {
        "server_report":     server_report,
        "current_draft":     "",
        "reflection_notes":  [],
        "evaluation_scores": [],
        "iteration":         0,
    }

    final_state: RCAState = {**initial}
    prev_score = None

    for event in app.stream(initial, stream_mode="updates"):
        node_name, node_output = next(iter(event.items()))

        if node_name == "generate":
            final_state.update(node_output)
            iteration = final_state["iteration"]
            print(f"\n{'─' * 72}")
            print(f"  DRAFT #{iteration} — generate_node output")
            print("─" * 72)
            print(final_state["current_draft"])
            print()

        elif node_name == "evaluate":
            final_state["evaluation_scores"] = (
                final_state.get("evaluation_scores", []) + node_output["evaluation_scores"]
            )
            curr_score = final_state["evaluation_scores"][-1]
            print(f"  SCORES — Draft #{curr_score['iteration']}")
            print(f"    Timeline Accuracy:    {curr_score['timeline']:>3}%")
            print(f"    Root Cause Clarity:   {curr_score['root_cause']:>3}%")
            print(f"    Evidence Completeness:{curr_score['evidence']:>3}%")
            print(f"    Mitigation Steps:     {curr_score['mitigation']:>3}%")
            print(f"    Technical Accuracy:   {curr_score['technical']:>3}%")
            print(f"    ─────────────────────────")
            print(f"    OVERALL (weighted):   {curr_score['overall']:>5}%")
            if prev_score:
                print(f"\n  WHY DID SCORES CHANGE?")
                print(explain_score_change(prev_score, curr_score))
            prev_score = curr_score
            iteration = final_state.get("iteration", 0)
            if curr_score["overall"] >= QUALITY_THRESHOLD and iteration >= MIN_REFLECTIONS + 1:
                print(f"\n  *** QUALITY THRESHOLD REACHED ({QUALITY_THRESHOLD}%) — stopping early ***")
            elif iteration > MAX_REFLECTIONS:
                print(f"\n  *** HARD CAP REACHED ({MAX_REFLECTIONS} reflections) — stopping ***")
            else:
                try:
                    input(f"\n  [Score: {curr_score['overall']}%] >>> Press Enter to continue... ")
                except EOFError:
                    pass
                print()

        elif node_name == "reflect":
            final_state["reflection_notes"] = (
                final_state.get("reflection_notes", []) + node_output["reflection_notes"]
            )
            notes = final_state["reflection_notes"]
            print(f"\n  REFLECTION #{len(notes)} — agent self-critique")
            print("─" * 72)
            print(notes[-1])
            print()

    # ── Final progression table ──────────────────────────────────────────────
    all_scores = final_state.get("evaluation_scores", [])
    if all_scores:
        print("\n" + "=" * 72)
        print("  METRIC PROGRESSION ACROSS ALL DRAFTS")
        print("=" * 72)
        header = f"  {'Draft':<7} {'Timeline':>10} {'RootCause':>11} {'Evidence':>10} {'Mitigation':>12} {'Technical':>11} {'OVERALL':>9}"
        print(header)
        print("  " + "─" * 68)
        for s in all_scores:
            print(f"  Draft {s['iteration']:<2}  {s['timeline']:>9}%  {s['root_cause']:>10}%  "
                  f"{s['evidence']:>9}%  {s['mitigation']:>11}%  {s['technical']:>10}%  "
                  f"{s['overall']:>8}%")

    # ── Save final RCA ───────────────────────────────────────────────────────
    out_dir = Path(__file__).resolve().parent / "outputs"
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / "hpe_rca_reflection.md"
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("# HPE ProLiant DL380 Gen11 — Root Cause Analysis\n")
        f.write("# Generated by Reflection Pattern Agent\n\n")
        f.write(final_state["current_draft"])
    print(f"\n  Final RCA saved → {out_path.name}")

    print()
    print("=" * 72)
    print("  KEY TAKEAWAYS — REFLECTION PATTERN")
    print("=" * 72)
    print()
    print("  WHY REFLECTION IMPROVES HPE RCA QUALITY:")
    print("    Draft 1: Raw abbreviations (BBU, ASR, EDAC) unexplained,")
    print("             timeline vague, no HPE tool commands.")
    print("    After reflection: timestamps cited, root cause mechanism")
    print("    explained, ssacli/SPP commands included, advisories referenced.")
    print()
    print("  THE REFLECTION MECHANISM:")
    print("    The agent is fed its own previous draft + all prior critique notes.")
    print("    It sees exactly what it wrote and what it said was wrong.")
    print("    This is how HPE engineers improve under pressure: read your own")
    print("    work, identify what's missing, fix it before the customer sees it.")
    print("=" * 72)
