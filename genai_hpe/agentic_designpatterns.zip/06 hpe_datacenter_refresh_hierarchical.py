# -*- coding: utf-8 -*-
"""
Hierarchical Agent Pattern with Critic Feedback Loop
=====================================================
Implemented with LangGraph conditional edges and multi-level agent hierarchy

Pattern:
  Agents are organised in THREE levels. Work flows bottom-up through
  the hierarchy. A Critic agent reviews the top-level output and can
  route feedback back to ANY level that produced a gap — the hierarchy
  then re-runs from that point upward.

  Level 3 (Specialists) → Level 2 (Supervisor) → Level 1 (IT Director)
                                   ↑                    ↑
                                   └────── Critic ───────┘
                                      (conditional routing)

LangGraph constructs used:
  - StateGraph with TypedDict — levels share a single state
  - add_conditional_edges from the Critic node:
      routes to "datacenter_manager", "it_director", or "finalize"
      based on the critic's assessment of where the gap originated
  - revision_round counter: prevents infinite loops (max 2 revisions)
  - No MemorySaver needed: the entire flow is one graph.stream() call

================================================================================
HPE USE CASE — Datacenter Refresh Planning:
================================================================================
An HPE enterprise customer needs to plan a hardware refresh of their
compute cluster. The decision involves three intersecting concerns:
  - Compute: Should they upgrade to Gen11, or extend Gen10+ lifecycle?
  - Storage: NVMe Alletra vs. expanding current Nimble AF40 capacity?
  - Network: 100GbE sufficient, or jump to 400GbE spine?

These decisions are technically complex and interdependent. The hierarchy:

  Level 3 — Specialists (deep domain knowledge, independent assessments):
    - Compute Specialist:  HPE ProLiant Gen11 vs. Gen10+ TCO and capabilities
    - Storage Specialist:  Alletra 9060 vs. Nimble AF40 expansion analysis

  Level 2 — Datacenter Manager (synthesis):
    - Reads both specialist reports and produces an integrated recommendation
    - Considers budget, operational complexity, and migration risk

  Level 1 — IT Director (final decision):
    - Produces the executive recommendation for board approval
    - Considers business risk, vendor contracts, and strategic alignment

  Critic (quality gate):
    - Reviews the IT Director's recommendation
    - Checks for: SPOF analysis, migration risk, total cost accuracy, HA design
    - Routes feedback to whichever level introduced the gap
    - The hierarchy re-runs from that level upward (not from scratch)

Why hierarchical + critic?
  The datacenter manager can synthesise compute + storage correctly but
  miss the interaction between storage rebuild traffic and network bandwidth.
  The critic closes this quality loop before the recommendation goes to the board.
"""

import os
from pathlib import Path
from typing import TypedDict, Literal
from textwrap import dedent
from dotenv import load_dotenv
import warnings

warnings.filterwarnings("ignore")

import sys
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------
def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

from langchain_aws import ChatBedrock
from langgraph.graph import StateGraph, END

llm = ChatBedrock(model_id=MODEL_ID, region_name=AWS_REGION, model_kwargs={"temperature": 0.4})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def pause(msg="Press Enter to continue..."):
    try:
        input(f"\n  [{msg}] ")
    except EOFError:
        print("  [non-interactive: continuing automatically]")
    print()

def section(title, width=70):
    print("=" * width)
    print(f"  {title}")
    print("=" * width)

def subsection(title, width=70):
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print("─" * width)

def indent(text, prefix="  "):
    return "\n".join(prefix + line for line in text.splitlines())

def critic_banner(msg: str, width=70):
    print(f"\n  {'!' * width}")
    print(f"  CRITIC: {msg}")
    print(f"  {'!' * width}")


# =============================================================================
# STATE — Shared across all three hierarchy levels
# =============================================================================

class RefreshState(TypedDict):
    # ── Case input (immutable throughout) ───────────────────────────────────
    customer_name:   str
    cluster_profile: str

    # ── Level 3 — Specialist outputs (written once, read by all above) ───────
    compute_report:  str
    storage_report:  str

    # ── Level 2 — Datacenter Manager synthesis ───────────────────────────────
    dc_synthesis:    str

    # ── Level 1 — IT Director recommendation ─────────────────────────────────
    it_recommendation: str

    # ── Critic feedback loop ─────────────────────────────────────────────────
    critic_verdict:   str   # "approved" | "revise_dc_manager" | "revise_it_director"
    critic_feedback:  str
    revision_round:   int

    # ── Final approved output ────────────────────────────────────────────────
    approved_plan: str


MAX_REVISIONS = 2


# =============================================================================
# CURRENT CLUSTER PROFILE — the case handed to the hierarchy
# =============================================================================

CLUSTER_PROFILE = dedent("""\
    Customer:        AeroDynamics Corp (HPE Platinum Partner)
    Current cluster: 8x HPE ProLiant DL380 Gen10+ (2021 vintage, 4 years old)
                     2x HPE Nimble AF40 all-flash storage (2021 vintage)
                     HPE Aruba 6300 25GbE ToR switches (4x)
    Workload:        Computational Fluid Dynamics (CFD) — 24/7 production
                     Peak memory demand: 1.5TB per node
                     Storage I/O: 120,000 IOPS sustained (CFD checkpoint writes)
    Pain points:
      - CPU limited: Gen10+ (Xeon Gold 6300 series) maxed out on CFD cores
      - Memory limited: 1TB max per Gen10+ node, jobs spilling to slow swap
      - Storage latency: Nimble AF40 showing 28ms average I/O on checkpoint jobs
      - Network: 25GbE saturated during parallel job communication (MPI)
    Budget:          $2.1M refresh budget (capex)
    Constraints:
      - Must maintain production continuity — rolling migration only
      - Current Nimble support contract expires in 8 months
      - HPE GreenLake subscription preferred (opex shift being considered)
""")


# =============================================================================
# LEVEL 3 — SPECIALIST NODES
# Each specialist produces an independent report.
# =============================================================================

def compute_specialist_node(state: RefreshState) -> dict:
    """
    Level 3 — Compute Specialist.
    Analyses the compute refresh option (Gen11 vs. other) independently.
    """
    prompt = dedent(f"""\
        You are an HPE Compute Solutions Architect specialising in ProLiant Gen11 servers.

        CUSTOMER: {state['customer_name']}
        CLUSTER PROFILE:
        {state['cluster_profile']}

        Provide your compute refresh assessment (4-5 sentences):
        - Gen10+ vs Gen11 TCO comparison for this workload profile
        - Specific Gen11 SKU recommendation (DL380 Gen11? DL560 Gen11? Why?)
        - Memory capacity improvement (Gen11 DDR5 vs Gen10+ DDR4)
        - Performance uplift estimate for CFD workloads
        - Migration complexity (rolling replacement feasibility)

        Be specific with HPE part numbers or SKU families where relevant.
        Do not address storage or network — that is another specialist's domain.
    """)
    response = llm.invoke(prompt)
    return {"compute_report": response.content}


def storage_specialist_node(state: RefreshState) -> dict:
    """
    Level 3 — Storage Specialist.
    Analyses the storage refresh option independently.
    """
    prompt = dedent(f"""\
        You are an HPE Storage Solutions Architect specialising in Alletra and Nimble arrays.

        CUSTOMER: {state['customer_name']}
        CLUSTER PROFILE:
        {state['cluster_profile']}

        Provide your storage refresh assessment (4-5 sentences):
        - Current Nimble AF40 pain point diagnosis (28ms I/O latency on checkpoint writes)
        - Alletra 9060 vs Nimble AF40 capacity expansion comparison
        - Expected I/O latency and IOPS improvement with Alletra
        - GreenLake Storage-as-a-Service option relevance
        - Migration path from Nimble AF40 (can data be migrated non-disruptively?)

        Be specific with HPE product families and expected performance numbers.
        Do not address compute or network — that is another specialist's domain.
    """)
    response = llm.invoke(prompt)
    return {"storage_report": response.content}


# =============================================================================
# LEVEL 2 — DATACENTER MANAGER NODE
# Synthesises both specialist reports.
# =============================================================================

def dc_manager_node(state: RefreshState) -> dict:
    """
    Level 2 — Datacenter Manager.
    Synthesises compute and storage specialist reports into an integrated plan.
    """
    revision = state.get("revision_round", 0)
    critique = ""
    if state.get("critic_feedback") and state.get("critic_verdict") == "revise_dc_manager":
        critique = f"\n\nCRITIC FEEDBACK TO ADDRESS:\n{state['critic_feedback']}\n"

    prompt = dedent(f"""\
        You are the Datacenter Manager at {state['customer_name']}'s IT department.
        You have received specialist assessments from your compute and storage teams.
        Produce an integrated datacenter refresh recommendation.
        {critique}
        COMPUTE SPECIALIST REPORT:
        {state['compute_report']}

        STORAGE SPECIALIST REPORT:
        {state['storage_report']}

        CLUSTER PROFILE:
        {state['cluster_profile']}

        Produce an integrated synthesis (4-5 sentences):
        1. Combined refresh recommendation (what to buy, in what sequence)
        2. Migration strategy (rolling approach — how to keep CFD jobs running)
        3. Budget allocation between compute and storage ($2.1M total)
        4. Key dependencies and sequencing (e.g., storage must come first for migration staging)
        5. Operational risk during the migration window
    """)
    response = llm.invoke(prompt)
    return {"dc_synthesis": response.content}


# =============================================================================
# LEVEL 1 — IT DIRECTOR NODE
# Produces the board-level recommendation.
# =============================================================================

def it_director_node(state: RefreshState) -> dict:
    """
    Level 1 — IT Director.
    Produces the final executive recommendation for board approval.
    """
    revision = state.get("revision_round", 0)
    critique = ""
    if state.get("critic_feedback") and state.get("critic_verdict") == "revise_it_director":
        critique = f"\n\nCRITIC FEEDBACK TO ADDRESS:\n{state['critic_feedback']}\n"

    prompt = dedent(f"""\
        You are the IT Director at {state['customer_name']}.
        You are preparing a board-level recommendation for the cluster refresh.
        {critique}
        DATACENTER MANAGER SYNTHESIS:
        {state['dc_synthesis']}

        COMPUTE SPECIALIST REPORT (context):
        {state['compute_report'][:300]}...

        STORAGE SPECIALIST REPORT (context):
        {state['storage_report'][:300]}...

        Produce an executive recommendation (5-6 sentences):
        1. Clear go/no-go recommendation with rationale
        2. Strategic alignment (GreenLake opex vs. capex, HPE partnership value)
        3. Risk summary: what are the top 2-3 risks and mitigations?
        4. Timeline: phased rollout milestones
        5. Single-point-of-failure analysis: does the new design eliminate current SPOFs?
        6. Expected business outcome: performance improvement + ROI justification

        This recommendation will go to the board. Be decisive and quantitative.
    """)
    response = llm.invoke(prompt)
    return {"it_recommendation": response.content}


# =============================================================================
# CRITIC NODE — Reviews the IT Director's recommendation
# Routes feedback to the level where the gap originated.
# =============================================================================

def critic_node(state: RefreshState) -> dict:
    """
    Critic reviews the IT Director's recommendation.
    Determines whether to approve or send feedback to a specific level.
    """
    prompt = dedent(f"""\
        You are an independent HPE Solutions Validation Architect.
        You review datacenter refresh recommendations before they go to board approval.
        You are known for finding gaps that others miss — especially around:
          - High Availability design (HA): Are there new single points of failure?
          - Network bottlenecks: Does the refreshed compute+storage exceed network capacity?
          - Migration risk: Is the rolling migration plan actually non-disruptive?
          - Total cost accuracy: Does the $2.1M budget actually cover the full scope?
          - Storage rebuild traffic: During Alletra migration, what is the network load?

        CURRENT RECOMMENDATION (from IT Director):
        {state['it_recommendation']}

        DATACENTER MANAGER SYNTHESIS (context):
        {state['dc_synthesis']}

        REVIEW CHECKLIST:
        1. Network bandwidth: 4x Gen11 nodes with NVMe workloads → does 25GbE suffice?
           (CFD MPI + storage I/O simultaneously)
        2. HA design: Is the new storage (Alletra) dual-controller? Any SPOF introduced?
        3. Migration non-disruption: Are there explicit steps for zero-downtime Nimble→Alletra?
        4. Budget: Does $2.1M cover compute + storage + network upgrade + migration labour?
        5. Nimble contract: 8 months left — does the migration timeline respect this?

        Identify the most critical gap (if any).

        CRITICAL: End with EXACTLY one of:
          VERDICT: APPROVED
          VERDICT: REVISE_DC_MANAGER  (gap is in the synthesis — DC Manager missed it)
          VERDICT: REVISE_IT_DIRECTOR  (gap is in the exec recommendation — IT Director missed it)
    """)
    response = llm.invoke(prompt)
    feedback = response.content

    # Parse verdict
    if "VERDICT: APPROVED" in feedback:
        verdict = "approved"
    elif "VERDICT: REVISE_DC_MANAGER" in feedback:
        verdict = "revise_dc_manager"
    else:
        verdict = "revise_it_director"

    new_round = state.get("revision_round", 0) + 1

    if new_round > MAX_REVISIONS:
        verdict = "approved"
        feedback += f"\n\n[SYSTEM: Max revisions ({MAX_REVISIONS}) reached. Approving current recommendation.]"

    return {
        "critic_verdict":  verdict,
        "critic_feedback": feedback,
        "revision_round":  new_round,
    }


# =============================================================================
# FINALIZE NODE
# =============================================================================

def finalize_node(state: RefreshState) -> dict:
    return {"approved_plan": state["it_recommendation"]}


# =============================================================================
# ROUTING
# =============================================================================

def route_after_critic(state: RefreshState) -> str:
    verdict = state.get("critic_verdict", "approved")
    if verdict == "approved":
        return "finalize"
    elif verdict == "revise_dc_manager":
        return "datacenter_manager"
    else:
        return "it_director"


# =============================================================================
# GRAPH CONSTRUCTION
# =============================================================================

def build_graph():
    g = StateGraph(RefreshState)

    g.add_node("compute_specialist",  compute_specialist_node)
    g.add_node("storage_specialist",  storage_specialist_node)
    g.add_node("datacenter_manager",  dc_manager_node)
    g.add_node("it_director",         it_director_node)
    g.add_node("critic",              critic_node)
    g.add_node("finalize",            finalize_node)

    g.set_entry_point("compute_specialist")
    g.add_edge("compute_specialist", "storage_specialist")
    g.add_edge("storage_specialist", "datacenter_manager")
    g.add_edge("datacenter_manager", "it_director")
    g.add_edge("it_director",        "critic")

    g.add_conditional_edges(
        "critic",
        route_after_critic,
        {
            "finalize":          "finalize",
            "datacenter_manager": "datacenter_manager",
            "it_director":       "it_director",
        },
    )
    g.add_edge("finalize", END)
    return g.compile()


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    section("HIERARCHICAL AGENT PATTERN — HPE Datacenter Refresh Planning")
    print("""
  PATTERN OVERVIEW
  ─────────────────
  Three levels of agents collaborate on a datacenter refresh recommendation.
  A Critic reviews the final output and can route feedback back to the
  SPECIFIC level that introduced the gap — not back to the beginning.

  Level 3 — Specialists (independent deep assessments):
    Compute Specialist  → HPE Gen11 compute options, TCO, migration
    Storage Specialist  → HPE Alletra vs Nimble, I/O performance, migration

  Level 2 — Datacenter Manager:
    Synthesises both specialist reports into an integrated plan.
    Owns: budget allocation, migration sequencing, operational risk.

  Level 1 — IT Director:
    Produces board-level executive recommendation.
    Owns: strategic alignment, HA analysis, ROI, risk summary.

  Critic (quality gate):
    Reviews IT Director's recommendation against a validation checklist.
    Routes to: APPROVED | REVISE_DC_MANAGER | REVISE_IT_DIRECTOR
    Max 2 revision rounds (guards against infinite loops).

  CUSTOMER: AeroDynamics Corp
  CHALLENGE: 8x Gen10+ servers + 2x Nimble AF40 refresh.
             CFD workloads, $2.1M budget, must stay in production.
""")
    pause("Press Enter to run the hierarchy")

    graph = build_graph()
    initial: RefreshState = {
        "customer_name":   "AeroDynamics Corp",
        "cluster_profile": CLUSTER_PROFILE,
        "compute_report":  "",
        "storage_report":  "",
        "dc_synthesis":    "",
        "it_recommendation": "",
        "critic_verdict":  "",
        "critic_feedback": "",
        "revision_round":  0,
        "approved_plan":   "",
    }

    final_state = {**initial}

    for event in graph.stream(initial, stream_mode="updates"):
        node_name, updates = next(iter(event.items()))
        final_state.update(updates)

        if node_name == "compute_specialist":
            subsection("LEVEL 3 — Compute Specialist")
            print(final_state["compute_report"])
            pause("Press Enter to run Storage Specialist")

        elif node_name == "storage_specialist":
            subsection("LEVEL 3 — Storage Specialist")
            print(final_state["storage_report"])
            pause("Press Enter to run Datacenter Manager (Level 2)")

        elif node_name == "datacenter_manager":
            subsection(f"LEVEL 2 — Datacenter Manager (revision #{final_state.get('revision_round', 0)})")
            print(final_state["dc_synthesis"])
            pause("Press Enter to run IT Director (Level 1)")

        elif node_name == "it_director":
            subsection(f"LEVEL 1 — IT Director (revision #{final_state.get('revision_round', 0)})")
            print(final_state["it_recommendation"])
            pause("Press Enter to run Critic review")

        elif node_name == "critic":
            verdict = final_state.get("critic_verdict", "")
            critic_banner(f"VERDICT: {verdict.upper()}")
            print(final_state["critic_feedback"])
            if verdict == "approved":
                print("\n  >> Recommendation approved — proceeding to finalize.")
            elif verdict == "revise_dc_manager":
                print("\n  >> Gap identified at Level 2 (DC Manager). Re-running from that level.")
            else:
                print("\n  >> Gap identified at Level 1 (IT Director). Re-running from that level.")
            pause()

        elif node_name == "finalize":
            subsection("FINAL APPROVED RECOMMENDATION")
            print(final_state["approved_plan"])

    print()
    section("KEY TAKEAWAYS — HIERARCHICAL PATTERN")
    print(f"""
  WHY HIERARCHY + CRITIC TOGETHER:

    1. The hierarchy ensures each level contributes appropriate expertise.
       The Compute Specialist doesn't debate network strategy.
       The IT Director doesn't get lost in ssacli commands.
       Each level adds what it knows; the level above synthesises.

    2. The Critic closes the quality loop — the hierarchy alone can produce
       a coherent-sounding plan with a dangerous gap (e.g., 25GbE saturation
       when Gen11 + NVMe storage doubles the I/O throughput).

    3. TARGETED ROUTING is the key LangGraph capability here.
       The Critic doesn't say "start over." It says "the DC Manager missed
       the network interaction — re-run from there." Only Levels 2 and 1
       re-execute. Level 3 specialists are not re-invoked (their domain
       assessments were sound).

  REVISION ROUNDS COMPLETED: {final_state.get('revision_round', 0)} / {MAX_REVISIONS} max
""")
