# -*- coding: utf-8 -*-
"""
Episodic & Semantic Memory Pattern — HPE Field Service Engineer Support Chatbot
================================================================================
Implemented with LangGraph State + MemorySaver Checkpointing

LangGraph Memory Constructs Used:
  - StateGraph with TypedDict state (Annotated reducer for episode_log)
  - MemorySaver checkpointer: thread_id = server_serial provides EPISODIC memory
    by persisting each server's service history across separate support sessions
  - Pre-loaded HPE knowledge base in initial state: SEMANTIC memory
    (firmware compatibility matrix, known issues, SOPs shared across all servers)

The key insight:
  EPISODIC  = MemorySaver per thread_id  — "what this specific server has had done"
  SEMANTIC  = shared HPE knowledge base  — "what we know about ProLiant in general"
  Together  → personalised server guidance grounded in safe, consistent HPE procedure

HPE USE CASE:
  An HPE field service engineer arrives at a customer site and opens the
  support chatbot for a specific server. The chatbot:
  - Instantly knows the server's service history (prior visits, parts replaced, faults)
  - Has deep HPE technical knowledge (firmware versions, known issues, SSDs commands)
  - Combines both to give advice that is SPECIFIC to this server's history

  Example: "Don't update the Smart Array to FW 7.26 — we tried that on this server
  last month and it triggered the BBU false-positive fault. Stay on 7.24 for now."
  That advice comes from EPISODIC memory (last month's visit).
  The recommendation to update to 7.26 comes from SEMANTIC memory (HPE advisory).
  The chatbot RESOLVES the conflict using both.

Two demo sessions:
  Session A: Server USE2340B7K (proliant-node-02) — has prior service history
  Session B: Server USE2340C1M (proliant-node-05) — clean slate
"""

import os
import json
import operator
from pathlib import Path
from typing import TypedDict, List, Dict, Annotated
from textwrap import dedent
from datetime import datetime
from dotenv import load_dotenv
import warnings

warnings.filterwarnings("ignore")

import sys
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------
def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

from langchain_aws import ChatBedrock
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

llm = ChatBedrock(model_id=MODEL_ID, region_name=AWS_REGION, model_kwargs={"temperature": 0.3})


# =============================================================================
# SEMANTIC KNOWLEDGE BASE — Pre-loaded HPE technical knowledge
# Shared across ALL servers — this is "what we know about ProLiant in general"
# =============================================================================

HPE_SEMANTIC_KNOWLEDGE = dedent("""\
    HPE ProLiant Gen11 Field Service Knowledge Base
    ================================================

    SMART ARRAY P408i-a CONTROLLER:
      - FW 7.22.x: Known BBU false-positive fault after 36+ months operation
        Advisory c08245132 recommends upgrade to 7.26.x
      - FW 7.24.x: Stable release, BBU behavior improved
      - FW 7.26.x: Current recommended release. Fix for c08245132.
      - IMPORTANT: Downgrade from 7.26 to 7.24 not supported without controller replacement
      - ssacli command to check: ssacli ctrl all show detail
      - ssacli command to check BBU: ssacli ctrl slot=0 show detail | grep -i battery

    iLO 6 FIRMWARE:
      - v1.48-1.50: Affected by thermal throttle issue (Advisory a00125843en)
      - v1.52: First fixed version for thermal issue
      - v1.55: Current recommended release. Adds improved DIMM fault prediction.
      - Dark-site update: Use HPE SPP 2025.03 ISO via iLO virtual media
      - iLO 6 REST API to check version: GET /redfish/v1/Managers/1

    DIMM (MEMORY) REPLACEMENT:
      - Gen11 uses DDR5-4800 RDIMMs only — no mixing with DDR4
      - DIMM replacement requires server power-off (hot-swap NOT supported)
      - After replacement: iLO memory test should be run before returning to service
      - HPE memory test via iLO: iLO Advanced Memory Test (AMT), ~30 min
      - Slot numbering: Slot 1A-4B on CPU1, 5A-8B on CPU2 (consult service manual for Gen11)

    HPE SSDs (NVMe/SAS):
      - SMART critical attributes: Attr 5 (reallocated sectors), Attr 187 (UE), Attr 194 (temp)
      - ssacli to check SMART: ssacli ctrl slot=0 pd bay=<N> show detail
      - Predictive failure alert = replace within 24-72 hours (do not wait for full failure)
      - RAID rebuild time: ~4 hours per TB at 50% rebuild priority

    THERMAL MANAGEMENT:
      - Gen11 thermal sensors: iLO monitors 20+ sensors per node
      - CPU throttle at 82C (configurable in BIOS)
      - Fan failure (any zone) triggers ASR watchdog consideration
      - iLO fan control: iLO 6 Thermal Configuration page or REST API

    SLURM JOB MANAGEMENT:
      - Drain a node before maintenance: scontrol update NodeName=<node> State=DRAIN Reason="maintenance"
      - Resume after maintenance: scontrol update NodeName=<node> State=RESUME
      - Check node state: sinfo -N -l | grep <node>
""")


# =============================================================================
# SIMULATED SERVER SERVICE HISTORIES (Episodic memory per server)
# These represent prior support sessions already recorded for each server.
# In a real system, these would be loaded from a CMDB / ServiceNow ticket history.
# =============================================================================

SERVER_HISTORIES = {
    "USE2340B7K": dedent("""\
        SERVICE HISTORY — HPE ProLiant DL380 Gen11 | S/N: USE2340B7K | proliant-node-02
        ==================================================================================
        [2025-02-15] Visit: Annual PM | Engineer: M. Rodriguez
          - Replaced thermal paste on both CPUs (2 years old)
          - Cleaned dust filters — significant dust accumulation found
          - Checked all DIMM slots — all seated correctly
          - Updated iLO from 1.48 to 1.50 (note: 1.52 not yet available at this date)
          - Smart Array FW: stayed on 7.22 per customer request (they test FW before deploying)
          - Issue found: DIMM 6A showing elevated CE count (+28 over 3 months) — FLAGGED
          - Action: Ordered replacement DIMM 6A (HPE P/N: P43328-B21), ETA 2 weeks

        [2025-02-28] Attempted Smart Array FW update 7.22→7.26 (remote)
          - FAILED: Controller entered unresponsive state mid-flash (iLO lost controller access)
          - Recovery: iLO hard reset via REST API POST /redfish/v1/Managers/1/Actions/Manager.Reset
          - Controller recovered with 7.22 still intact (partial flash aborted by BBU watchdog)
          - Customer decision: Hold Smart Array FW update until next maintenance window
          - NOTE: This server's P408i-a may be sensitive to FW updates while under load
            Always drain SLURM jobs BEFORE any storage FW update on this server

        [2025-03-21] Incident: Unexpected reboot at 03:22 (Ticket INC-2025-0321-002)
          - Root cause: BBU fault (c08245132) + DIMM 6A UE error (EDAC)
          - Replacement DIMM 6A installed (P43328-B21) — AMT test passed
          - Smart Array BBU module replaced (HPE P/N: BB460A)
          - iLO updated to 1.55
          - Smart Array FW: STILL on 7.22 (customer holding — see note above)
          - Server returned to service 11:45 AM
          - OPEN ITEM: Smart Array FW update to 7.24 or 7.26 still required
            Schedule for next Sunday maintenance window. Drain SLURM first.
    """),
    "USE2340C1M": dedent("""\
        SERVICE HISTORY — HPE ProLiant DL380 Gen11 | S/N: USE2340C1M | proliant-node-05
        ==================================================================================
        [2025-01-10] Initial setup and deployment
          - New server deployment: SLURM compute node
          - iLO 6 configured: v1.50 (factory default)
          - Smart Array P408i-a FW: 7.22 (factory default)
          - All components checked — no issues found
          - Note: iLO firmware update to 1.52+ deferred (customer backlog)

        No subsequent service visits recorded.
        Current status: Running iLO 1.50, Smart Array 7.22 — both below recommended versions.
    """),
}


# =============================================================================
# GRAPH STATE
# episode_log uses operator.add — each question+answer APPENDS to the log
# =============================================================================

class SupportState(TypedDict):
    # Server identity
    server_serial:    str
    server_hostname:  str

    # Semantic knowledge (pre-loaded, same for all servers)
    hpe_knowledge:    str

    # Episodic memory (server-specific service history — loaded per server)
    service_history:  str

    # Conversation
    engineer_question: str
    chatbot_response:  str

    # Append-only conversation log across sessions
    episode_log: Annotated[List[Dict], operator.add]


# =============================================================================
# NODE: Support response generator
# =============================================================================

def support_response_node(state: SupportState) -> dict:
    """Generate a response using BOTH episodic (service history) and semantic (HPE knowledge)."""
    prompt = dedent(f"""\
        You are the HPE ProLiant Field Service AI Assistant.
        You help HPE field engineers make safe, server-specific decisions.

        SERVER IDENTITY:
        Serial: {state['server_serial']}  |  Hostname: {state['server_hostname']}

        THIS SERVER'S SERVICE HISTORY (EPISODIC MEMORY — specific to this server):
        {state['service_history']}

        HPE TECHNICAL KNOWLEDGE BASE (SEMANTIC MEMORY — applies to all ProLiant Gen11):
        {state['hpe_knowledge']}

        ENGINEER'S QUESTION:
        {state['engineer_question']}

        Instructions:
        1. Answer the question using BOTH the server's specific history AND the HPE knowledge base.
        2. If the service history contains information that OVERRIDES the general HPE guidance
           (e.g., a known issue specific to this server), explicitly flag the conflict and explain.
        3. Provide specific HPE commands where relevant (ssacli, iLO CLI, Redfish API).
        4. Be concise — the engineer is on-site and needs a quick, actionable answer.
        5. End with a clear recommendation: what to do next (numbered, max 3 steps).
    """)
    response = llm.invoke(prompt)

    log_entry = {
        "timestamp": datetime.now().isoformat(),
        "serial":    state["server_serial"],
        "question":  state["engineer_question"],
        "answer":    response.content,
    }

    return {
        "chatbot_response": response.content,
        "episode_log":      [log_entry],
    }


# =============================================================================
# GRAPH CONSTRUCTION
# =============================================================================

def build_support_graph():
    builder = StateGraph(SupportState)
    builder.add_node("support", support_response_node)
    builder.set_entry_point("support")
    builder.add_edge("support", END)

    checkpointer = MemorySaver()
    return builder.compile(checkpointer=checkpointer)


# =============================================================================
# HELPERS
# =============================================================================

def pause(msg="Press Enter to continue..."):
    try:
        input(f"\n  [{msg}] ")
    except EOFError:
        print("  [non-interactive: continuing automatically]")
    print()

def section(title, width=70):
    print("=" * width)
    print(f"  {title}")
    print("=" * width)

def ask_question(graph, server_serial: str, server_hostname: str,
                 question: str, session_num: int) -> str:
    """Run one question through the support graph for a given server."""
    config = {"configurable": {"thread_id": f"server-{server_serial}"}}

    history = SERVER_HISTORIES.get(server_serial, "No prior service history found.")
    state: SupportState = {
        "server_serial":    server_serial,
        "server_hostname":  server_hostname,
        "hpe_knowledge":    HPE_SEMANTIC_KNOWLEDGE,
        "service_history":  history,
        "engineer_question": question,
        "chatbot_response": "",
        "episode_log":      [],
    }

    result = graph.invoke(state, config=config)
    return result["chatbot_response"]


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    section("EPISODIC + SEMANTIC MEMORY — HPE Field Service Support Chatbot")
    print("""
  SCENARIO
  ─────────
  An HPE field service engineer arrives at a customer data centre.
  They open the support chatbot and scan the server's serial number.
  The chatbot immediately knows:

    EPISODIC:  Everything done to THIS server — parts replaced, firmware
               updates attempted, known issues, open action items.
               (MemorySaver per thread_id = server_serial)

    SEMANTIC:  General HPE ProLiant knowledge — firmware compatibility,
               known advisories, ssacli commands, SOPs.
               (Pre-loaded knowledge base, same for all servers)

  Two demo sessions:
    Session A: S/N USE2340B7K (proliant-node-02) — rich service history
    Session B: S/N USE2340C1M (proliant-node-05) — clean slate server

  Watch how the SAME questions get DIFFERENT answers based on server history.
""")
    pause("Press Enter to start Session A — proliant-node-02 (USE2340B7K)")

    graph = build_support_graph()

    # ─── Session A: Server with complex history ────────────────────────────
    section("SESSION A — proliant-node-02 | S/N: USE2340B7K")
    print("""
  This server has a 3-visit service history including:
  - A failed Smart Array FW update attempt on 2025-02-28
  - A DIMM replacement and BBU module replacement on 2025-03-21
  - An OPEN ITEM: Smart Array FW update still pending
""")

    questions_a = [
        "The customer wants to update the Smart Array firmware to 7.26. Is it safe to do that now?",
        "I want to update the iLO firmware. What version should I update to and how?",
        "How do I drain SLURM jobs before the maintenance window?",
    ]

    for i, question in enumerate(questions_a, 1):
        print(f"\n  QUESTION {i}: {question}")
        print("─" * 70)
        answer = ask_question(graph, "USE2340B7K", "proliant-node-02", question, i)
        print(answer)
        if i < len(questions_a):
            pause(f"Press Enter for Question {i+1}")

    pause("Press Enter to start Session B — proliant-node-05 (USE2340C1M)")

    # ─── Session B: New server, clean slate ────────────────────────────────
    section("SESSION B — proliant-node-05 | S/N: USE2340C1M")
    print("""
  This server was deployed in January and has had no service visits.
  It is still running factory-default firmware versions.
  The SAME question about Smart Array FW will get a DIFFERENT answer.
""")

    questions_b = [
        "The customer wants to update the Smart Array firmware to 7.26. Is it safe to do that now?",
        "I want to update the iLO firmware. What version should I update to and how?",
    ]

    for i, question in enumerate(questions_b, 1):
        print(f"\n  QUESTION {i}: {question}")
        print("─" * 70)
        answer = ask_question(graph, "USE2340C1M", "proliant-node-05", question, i)
        print(answer)
        if i < len(questions_b):
            pause(f"Press Enter for Question {i+1}")

    print()
    section("COMPARISON — Same Question, Two Different Servers")
    print("""
  QUESTION: "Is it safe to update Smart Array firmware to 7.26 now?"

  USE2340B7K (proliant-node-02) — WITH service history:
    → "NO — this server had a failed FW flash on 2025-02-28. The controller
       entered an unresponsive state mid-flash. Drain SLURM jobs FIRST,
       then use the iLO REST API reset procedure if the controller goes
       unresponsive again. Use 7.24 as a safer intermediate step."
       [Advice personalised from EPISODIC memory of the failed flash attempt]

  USE2340C1M (proliant-node-05) — CLEAN SLATE:
    → "YES — no known issues with this specific server. Standard procedure:
       drain SLURM jobs, then flash 7.22→7.26 via HPE SPP or ssacli.
       Advisory c08245132 recommends 7.26 to fix the BBU fault issue."
       [Standard advice from SEMANTIC knowledge — no episodic data to override it]

  THE KEY INSIGHT:
    The SAME semantic knowledge gives different advice because EPISODIC
    memory of a prior incident on USE2340B7K overrides the general guidance.
    Without episodic memory, the chatbot would give identical advice to both
    servers — and potentially cause the same failed flash on USE2340B7K again.

  LANGGRAPH MECHANISM:
    thread_id = server_serial in MemorySaver creates SEPARATE state histories
    per server. The same graph code serves both servers; the checkpointer
    routes each server's state to the right episode history automatically.
""")
