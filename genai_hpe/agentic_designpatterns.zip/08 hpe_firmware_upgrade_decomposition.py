# -*- coding: utf-8 -*-
"""
Decomposition Pattern — HPE Firmware Upgrade Campaign Planner + Executor
=========================================================================
Implemented with LangGraph dynamic fan-out via the Send() API

Decomposition Pattern:
  A Planner agent receives a complex task (upgrade firmware across a fleet)
  and breaks it down into independent sub-tasks. Each sub-task is dispatched
  to an Executor agent that handles only that unit of work. An Aggregator
  then synthesises all results into a campaign report.

  "Don't write one agent that manages everything serially. Let the Planner
   identify the work units and let Executors focus on one task each."

LangGraph implementation:
  - planner_node: LLM produces a JSON list of upgrade sub-tasks
  - route_to_executors: uses Send() to dynamically fan-out one executor
    instance per sub-task — true parallel decomposition
  - executor_node: receives a SINGLE sub-task, evaluates the upgrade step
    (pre-checks, risk, rollback procedure) for that server/component
  - aggregator_node: reads ALL execution_results and writes campaign_report
  - execution_results: Annotated[List[str], operator.add]
      — each executor appends one result; aggregator reads them all

================================================================================
HPE USE CASE — Firmware Upgrade Campaign:
================================================================================
An HPE infrastructure team must upgrade firmware across a mixed fleet of
ProLiant servers before a quarterly maintenance window. Components needing
updates vary per server. A human operator cannot manually plan 20 upgrade
steps without missing dependencies or risk interactions.

The Decomposition Pattern splits this into two clean roles:

  PLANNER
    Receives the full fleet inventory and upgrade policy.
    Produces an ordered list of upgrade sub-tasks — one per
    server/component pair — with priority and risk classification.

    Example output (structured JSON):
      [
        {"server": "proliant-node-01", "component": "iLO 6", ...},
        {"server": "proliant-node-01", "component": "BIOS",  ...},
        {"server": "proliant-node-02", "component": "NIC",   ...},
        ...
      ]

  EXECUTOR (one instance per sub-task)
    Receives a single upgrade sub-task.
    Evaluates: pre-checks required, estimated downtime, rollback procedure,
    known advisories, and a GO / HOLD / DEFER recommendation.

  AGGREGATOR
    Reads all executor results.
    Produces a campaign summary: GO items, HOLD items, total risk profile,
    recommended execution order, and maintenance window estimate.

KEY INSIGHT:
  The Planner does not execute anything.
  The Executors do not plan anything.
  Clear separation of concerns enables parallelism and specialisation.
"""

import os
import json
import operator
from pathlib import Path
from typing import TypedDict, List, Annotated
from textwrap import dedent
from dotenv import load_dotenv
import warnings

warnings.filterwarnings("ignore")

import sys
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------
def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

from langchain_aws import ChatBedrock
from langgraph.graph import StateGraph, END
from langgraph.types import Send

llm = ChatBedrock(model_id=MODEL_ID, region_name=AWS_REGION, model_kwargs={"temperature": 0.3})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def pause(msg="Press Enter to continue..."):
    try:
        input(f"\n  [{msg}] ")
    except EOFError:
        print("  [non-interactive: continuing automatically]")
    print()

def section(title, width=70):
    print("=" * width)
    print(f"  {title}")
    print("=" * width)

def subsection(title, width=70):
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print("─" * width)

def indent(text, prefix="  "):
    return "\n".join(prefix + line for line in text.splitlines())


# =============================================================================
# SHARED STATE
#
# execution_results uses operator.add so each Executor instance APPENDS
# its result. The Aggregator reads the full list — whether 3 or 12 items.
# =============================================================================

class FirmwareCampaignState(TypedDict):
    # ── Campaign input ─────────────────────────────────────────────────────
    fleet_description: str      # Inventory: servers, current firmware versions
    upgrade_policy:    str      # Rules: maintenance window, risk tolerance, order

    # ── Planner output ─────────────────────────────────────────────────────
    upgrade_tasks:      List[dict]   # Sub-tasks produced by planner (parsed JSON)
    planner_rationale:  str          # Planner's reasoning / dependency notes

    # ── Executor outputs (accumulated via fan-out) ──────────────────────────
    # operator.add: each Executor appends one result string
    execution_results: Annotated[List[str], operator.add]

    # ── Final output ────────────────────────────────────────────────────────
    campaign_report: str


# Per-executor sub-state — passed via Send() to each executor instance
class UpgradeTaskState(TypedDict):
    task:           dict   # Single upgrade sub-task from planner
    upgrade_policy: str    # Policy context for the executor

    # Merge back into FirmwareCampaignState via operator.add
    execution_results: Annotated[List[str], operator.add]


# =============================================================================
# NODE 1 — PLANNER
#
# Receives the full fleet description and upgrade policy.
# Decomposes the campaign into an ordered list of upgrade sub-tasks.
# Each sub-task is a self-contained unit: one server, one component.
# =============================================================================

def planner_node(state: FirmwareCampaignState) -> dict:
    """
    PLANNER: Decompose the firmware upgrade campaign into sub-tasks.

    The Planner's job is decomposition ONLY — it does not execute,
    evaluate risk details, or write procedures. That is the Executor's job.

    Output: a JSON list of upgrade sub-tasks + a rationale string.
    """
    prompt = dedent(f"""\
        You are an HPE Firmware Campaign Planner. Your ONLY job is to decompose
        a firmware upgrade campaign into an ordered list of upgrade sub-tasks.

        FLEET INVENTORY:
        {state['fleet_description']}

        UPGRADE POLICY:
        {state['upgrade_policy']}

        Produce a JSON array of upgrade sub-tasks. Each sub-task must have:
        - "task_id":      string (e.g., "T-01")
        - "server":       string (server hostname)
        - "component":    string (e.g., "iLO 6", "BIOS", "Smart Array P408i", "NIC ConnectX-7", "Drive firmware")
        - "current_fw":   string (current firmware version)
        - "target_fw":    string (target firmware version)
        - "priority":     "P1" | "P2" | "P3"  (P1=security/critical, P2=reliability, P3=optional)
        - "risk_level":   "LOW" | "MEDIUM" | "HIGH"
        - "requires_reboot": true | false
        - "dependency":   string or null  (task_id this must come AFTER, or null)

        After the JSON array, add a section starting with "RATIONALE:" explaining
        your sequencing and dependency decisions in 3-4 sentences.

        IMPORTANT: Respond with ONLY the JSON array first, then "RATIONALE:" on a new line.
        Do not wrap the JSON in markdown code blocks.
    """)

    result = llm.invoke(prompt)
    raw = result.content.strip()

    # Split JSON from rationale
    rationale = ""
    if "RATIONALE:" in raw:
        json_part, _, rationale_part = raw.partition("RATIONALE:")
        rationale = rationale_part.strip()
    else:
        json_part = raw

    # Parse JSON — gracefully handle LLM formatting quirks
    tasks = []
    try:
        # Strip any accidental markdown fences
        clean = json_part.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
        tasks = json.loads(clean)
    except json.JSONDecodeError:
        # Fallback: try to extract JSON array from the text
        start = json_part.find("[")
        end   = json_part.rfind("]") + 1
        if start >= 0 and end > start:
            try:
                tasks = json.loads(json_part[start:end])
            except json.JSONDecodeError:
                tasks = []

    return {
        "upgrade_tasks":     tasks,
        "planner_rationale": rationale,
    }


# =============================================================================
# NODE 2 — EXECUTOR (one instance per sub-task)
#
# Receives a SINGLE upgrade sub-task via Send().
# Evaluates: pre-checks, estimated downtime, rollback procedure, known
# advisories, and produces a GO / HOLD / DEFER recommendation.
#
# Executors run independently — no shared state between them.
# =============================================================================

def executor_node(state: UpgradeTaskState) -> dict:
    """
    EXECUTOR: Evaluate a single firmware upgrade sub-task.

    Each executor instance knows nothing about other tasks.
    It focuses entirely on: can this specific upgrade proceed safely?
    """
    task   = state["task"]
    policy = state["upgrade_policy"]

    prompt = dedent(f"""\
        You are an HPE Firmware Upgrade Executor. Evaluate ONE specific firmware
        upgrade sub-task and provide a detailed execution assessment.

        TASK:
          Task ID:         {task.get('task_id', 'N/A')}
          Server:          {task.get('server', 'N/A')}
          Component:       {task.get('component', 'N/A')}
          Current FW:      {task.get('current_fw', 'N/A')}
          Target FW:       {task.get('target_fw', 'N/A')}
          Priority:        {task.get('priority', 'N/A')}
          Risk Level:      {task.get('risk_level', 'N/A')}
          Requires Reboot: {task.get('requires_reboot', False)}
          Dependency:      {task.get('dependency', 'None')}

        CAMPAIGN POLICY:
        {policy}

        Provide a structured execution assessment:

        RECOMMENDATION: [GO | HOLD | DEFER]

        PRE-CHECKS (2-3 bullet points):
        - What must be verified BEFORE applying this update?

        PROCEDURE (2-3 steps):
        - Concise step-by-step for this specific component

        ROLLBACK:
        - How to revert if the update fails

        KNOWN ADVISORIES:
        - Any relevant HPE advisory, SA, or known issue for this component/version

        DOWNTIME ESTIMATE: [X minutes | Non-disruptive]

        Keep your response focused on this single task only.
    """)

    result = llm.invoke(prompt)

    task_label = f"{task.get('task_id','?')} | {task.get('server','?')} | {task.get('component','?')}"
    formatted  = f"EXECUTOR RESULT — {task_label}\n{result.content}"

    return {"execution_results": [formatted]}


# =============================================================================
# ROUTING FUNCTION — Fan-out via Send()
#
# After the planner runs, this function reads state['upgrade_tasks'] and
# creates one Send() per task — dispatching each to executor_node with
# only the data that executor needs.
#
# This IS the decomposition: one list → N parallel executor invocations.
# =============================================================================

def route_to_executors(state: FirmwareCampaignState):
    """
    Decomposition router: sends each upgrade sub-task to its own executor.

    Each Send() creates an independent executor instance with only the
    data that executor needs — no cross-task coupling.
    """
    tasks = state.get("upgrade_tasks", [])
    if not tasks:
        # No tasks produced by planner — skip to aggregator
        return "aggregator"

    return [
        Send("executor_node", {
            "task":           task,
            "upgrade_policy": state["upgrade_policy"],
        })
        for task in tasks
    ]


# =============================================================================
# NODE 3 — AGGREGATOR
#
# Reads ALL execution_results (from all executors) and synthesises them
# into a final campaign report: GO list, HOLD list, execution order,
# total maintenance window estimate.
# =============================================================================

def aggregator_node(state: FirmwareCampaignState) -> dict:
    """
    AGGREGATOR: Synthesise all executor results into a campaign report.

    The aggregator does not re-evaluate individual tasks — it reads the
    executor outputs as authoritative and produces the campaign view.
    """
    results_block = "\n\n".join(state.get("execution_results", []))
    tasks_count   = len(state.get("upgrade_tasks", []))

    prompt = dedent(f"""\
        You are the HPE Firmware Campaign Manager. You have received execution
        assessments from {tasks_count} upgrade executors. Synthesise them into
        a campaign report.

        ALL EXECUTOR ASSESSMENTS:
        {results_block}

        CAMPAIGN POLICY:
        {state['upgrade_policy']}

        Produce a campaign report with these sections:

        CAMPAIGN SUMMARY
        - Total tasks: {tasks_count}
        - GO count, HOLD count, DEFER count

        APPROVED EXECUTION ORDER (GO items only)
        - Numbered list respecting dependencies and policy constraints
        - Note any tasks that must be sequential vs. can be parallel

        HOLD / DEFER ITEMS
        - List with reason for each HOLD or DEFER recommendation

        MAINTENANCE WINDOW ESTIMATE
        - Total estimated time (sequential worst-case)
        - Opportunities to parallelise (which tasks can overlap)

        RISK SUMMARY
        - Overall campaign risk: LOW / MEDIUM / HIGH
        - Top 2 risk items and mitigation

        SIGN-OFF CHECKLIST
        - 3-4 bullet points that must be confirmed before campaign starts
    """)

    result = llm.invoke(prompt)
    return {"campaign_report": result.content}


# =============================================================================
# GRAPH ASSEMBLY
# =============================================================================

def build_decomposition_graph():
    """
    Build the Planner → [Executors via Send()] → Aggregator graph.

    Graph topology:
      START → planner → route_to_executors → executor_node (x N) → aggregator → END
                                          ↘ (if no tasks) ──────────────────────↗
    """
    g = StateGraph(FirmwareCampaignState)

    g.add_node("planner",       planner_node)
    g.add_node("executor_node", executor_node)
    g.add_node("aggregator",    aggregator_node)

    g.set_entry_point("planner")

    # After planner: conditionally fan-out or skip to aggregator
    g.add_conditional_edges(
        "planner",
        route_to_executors,
        ["executor_node", "aggregator"],
    )

    # All executor instances converge to aggregator
    g.add_edge("executor_node", "aggregator")
    g.add_edge("aggregator",    END)

    return g.compile()


# =============================================================================
# DEMO CAMPAIGN
# =============================================================================

FLEET_DESCRIPTION = dedent("""\
    HPE ProLiant Fleet — Pre-Maintenance Firmware Audit (2026-Q1)
    ==============================================================

    proliant-node-01  (Production — SAP HANA primary)
      iLO 6:          v1.50  → target v1.58  (security patch: CVE-2025-38821)
      BIOS:           v2.80  → target v3.10  (Spectre-v4 mitigation + DDR5 stability)
      Smart Array:    P408i-a FW 4.51 → target 5.10  (BBU calibration fix)

    proliant-node-02  (Production — ML training node, dual A100)
      iLO 6:          v1.52  → target v1.58  (security patch: CVE-2025-38821)
      NIC ConnectX-7: FW 28.36.1010 → target 28.39.1002  (RoCEv2 PFC stall fix)
      Drive firmware: ST18000NM000J → HPD2 → HPD4  (SMART threshold update)

    proliant-node-03  (Dev/Test — non-production)
      iLO 6:          v1.45  → target v1.58  (3 versions behind)
      BIOS:           v2.60  → target v3.10  (multiple stability fixes)
""")

UPGRADE_POLICY = dedent("""\
    HPE Firmware Upgrade Policy — Q1 2026 Maintenance Window
    =========================================================
    - Maintenance window: Saturday 02:00–06:00 AEST (4 hours maximum)
    - Production servers (node-01, node-02): require Change Advisory Board approval
    - Dev/Test servers (node-03): can be upgraded without CAB approval
    - iLO updates are non-disruptive (no server reboot required)
    - BIOS updates require server power-cycle (schedule last for each server)
    - Do not upgrade iLO and BIOS on the same server in the same step
    - Smart Array firmware: update iLO first, then Smart Array, then BIOS
    - P1 security patches (CVE-tagged) must be applied before P2/P3 items
    - Rollback capability must be confirmed for all P1 items before proceeding
    - Maximum 2 production servers in-maintenance simultaneously
""")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    section("DECOMPOSITION PATTERN — HPE Firmware Upgrade Campaign")
    print("""
  PATTERN OVERVIEW
  ─────────────────
  The Decomposition Pattern splits a complex task into independent sub-tasks.

  PLANNER
    Receives the full fleet inventory and upgrade policy.
    Produces a structured list of upgrade sub-tasks — one per
    server/component pair. Defines dependencies and priority.
    Does NOT execute anything.

  EXECUTORS (one per sub-task, running in parallel via Send())
    Each executor handles exactly ONE upgrade sub-task.
    Evaluates: pre-checks, procedure, rollback, advisories, GO/HOLD.
    Has no knowledge of other tasks — pure single-task focus.

  AGGREGATOR
    Reads all executor results.
    Produces: approved execution order, HOLD items, window estimate,
    risk summary, and sign-off checklist.

  KEY INSIGHT:
    Send() creates N executor instances dynamically — one per task.
    The graph topology is determined at runtime by the Planner's output.
    Add more servers to the fleet? Zero code changes. The Planner
    decomposes more tasks; the router dispatches more executors.
""")

    pause("Press Enter to start the Planner phase")

    # ── Build graph ─────────────────────────────────────────────────────────
    graph = build_decomposition_graph()

    initial_state: FirmwareCampaignState = {
        "fleet_description": FLEET_DESCRIPTION,
        "upgrade_policy":    UPGRADE_POLICY,
        "upgrade_tasks":     [],
        "planner_rationale": "",
        "execution_results": [],
        "campaign_report":   "",
    }

    # ── Stream execution so we can show intermediate steps ──────────────────
    subsection("PHASE 1 — PLANNER: Decomposing campaign into sub-tasks")
    print("  Running planner node...")
    print()

    final_state = None
    planner_shown  = False
    executor_count = 0

    for step in graph.stream(initial_state, stream_mode="updates"):
        node_name = list(step.keys())[0]
        node_data = step[node_name]

        if node_name == "planner" and not planner_shown:
            planner_shown = True
            tasks = node_data.get("upgrade_tasks", [])
            rationale = node_data.get("planner_rationale", "")

            print(f"  Planner produced {len(tasks)} upgrade sub-tasks:\n")
            for t in tasks:
                dep_str = f"  (after {t.get('dependency')})" if t.get("dependency") else ""
                print(f"    [{t.get('task_id','?')}] {t.get('server','?'):20s}  "
                      f"{t.get('component','?'):25s}  "
                      f"{t.get('priority','?')} / {t.get('risk_level','?'):6s}  "
                      f"Reboot: {'Y' if t.get('requires_reboot') else 'N'}"
                      f"{dep_str}")

            if rationale:
                print()
                print("  PLANNER RATIONALE:")
                print(indent(rationale))

            print()
            subsection(f"PHASE 2 — EXECUTORS: {len(tasks)} parallel task evaluations")
            pause(f"Press Enter to fan-out {len(tasks)} executor instances")

        elif node_name == "executor_node":
            results = node_data.get("execution_results", [])
            for r in results:
                executor_count += 1
                # Print first line (task label) as progress indicator
                first_line = r.splitlines()[0] if r else ""
                print(f"  [{executor_count:02d}] {first_line}")

        elif node_name == "aggregator":
            final_state = node_data

    print()
    subsection("PHASE 3 — AGGREGATOR: Campaign Report")
    pause("Press Enter to see the campaign report")

    # Retrieve campaign_report — it may be in final_state or we need the full state
    # Re-run synchronously to ensure we have the full final state
    if not final_state or not final_state.get("campaign_report"):
        result = graph.invoke(initial_state)
        campaign_report = result.get("campaign_report", "No report generated.")
    else:
        campaign_report = final_state.get("campaign_report", "No report generated.")

    print()
    print("  FIRMWARE CAMPAIGN REPORT")
    print("─" * 70)
    print(campaign_report)

    print()
    section("KEY TAKEAWAYS — DECOMPOSITION PATTERN")
    print("""
  1. PLANNER creates the sub-task list — EXECUTORS evaluate them.
     Clean separation: the Planner never evaluates risk or writes procedures.
     The Executors never decide what needs upgrading or in what order.

  2. Send() enables true parallel fan-out.
     Each executor gets only the data it needs for its single task.
     No shared mutable state between executor instances.
     Add 10 more servers? Zero code changes. The Planner decomposes more;
     Send() dispatches more executors automatically.

  3. operator.add on execution_results is the convergence mechanism.
     All executor instances append to the same list.
     The Aggregator reads the complete list regardless of how many ran.
     This is the same Annotated[List, operator.add] pattern from earlier
     files — now powering a dynamic fan-out instead of a fixed pipeline.

  4. The Aggregator never re-does executor work.
     It reads executor outputs as authoritative facts and only adds
     the campaign-level view: ordering, window estimate, sign-off checklist.
     Each agent does EXACTLY its job — no more.

  5. HPE REAL-WORLD ANALOGY:
     A firmware campaign manager does not personally evaluate every
     component's rollback procedure. They assign sub-tasks to specialists,
     collect their assessments, and produce the execution plan.
     This pattern automates that workflow at scale.
""")
