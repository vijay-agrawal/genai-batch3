#!/usr/bin/env python3
"""
Critic Pattern — HPE Change Request (CR) Review
================================================

================================================================================
CRITIC PATTERN vs REFLECTION PATTERN — Key Difference (2-3 lines):
================================================================================
CRITIC pattern  : A SEPARATE agent evaluates and scores another agent's output
                  within the same execution.  Focus is quality control RIGHT NOW.
                  ("Is this output good enough?")

REFLECTION pattern : The SAME agent reviews its OWN past outputs across iterations
                     to update its reasoning strategy and improve future behaviour.
                     ("How do I get better over time?")

This demo implements the CRITIC pattern — two distinct agents, one execution loop.
================================================================================

================================================================================
CRITIC PATTERN OVERVIEW:
================================================================================
A Critic agent is an external evaluator that reviews another agent's output
during the same execution run. It is NOT the generator; its purpose is quality
control.

Key Components:
- Author Agent    : Generates the initial output (change request document)
- Critic Agent    : Evaluates against a domain-specific rubric
- Feedback pass   : Critic's findings are used to produce a corrected version
- Single run      : Both agents execute once in the same pipeline (no episodes)

Key Benefits:
- Catches gaps and safety issues a single agent misses
- Forces systematic checking via an explicit rubric
- Produces a safer, higher-quality output than any single-pass generation
- Mirrors HPE's own change management peer review process

Typical Workflow:
1. Author generates initial change request
2. Critic evaluates against HPE change management rubric
3. Critic returns (a) numbered issues found  (b) a fully revised CR
4. Pipeline ends — the revised CR is the final deliverable

================================================================================
HPE USE CASE — Why the Critic Pattern is Critical Here:
================================================================================
Every planned firmware update or hardware maintenance activity on HPE ProLiant
servers requires a Change Request (CR) document. In enterprise environments:
  - A CR missing a rollback plan can strand a server if the firmware flash fails
  - A CR missing blast-radius assessment can trigger outages on dependent systems
  - A CR missing pre-check steps can brick a server (iLO update during I/O = disaster)
  - A CR that doesn't specify the maintenance window can be executed at wrong time

The Critic catches these gaps systematically. Without it, a well-intentioned
engineer can submit a CR that passes a quick glance but fails at execution time.

Scenario: proliant-node-02 needs:
  - Smart Array P408i firmware update (7.22 → 7.26) to fix BBU fault (advisory c08245132)
  - iLO 6 firmware update (1.50 → 1.55) to fix thermal throttle (advisory a00125843en)
  - Physical DIMM replacement (slot 6A — uncorrectable ECC error)
  The Author drafts the CR. The Critic reviews it before it goes to CAB approval.

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: LangGraph (stateful multi-node pipeline)
LLM Model: AWS Bedrock (ChatBedrock)
Data:
  - Input  : data/ilo_server_health_report.txt (iLO IML + incident data)
  - Output : outputs/hpe_change_request_critic.md
================================================================================
"""

import os
import sys
from pathlib import Path
from typing import TypedDict

from dotenv import load_dotenv
from langchain_aws import ChatBedrock
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph

import warnings
warnings.filterwarnings("ignore")

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------
def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")

llm = ChatBedrock(
    model_id=MODEL_ID,
    region_name=AWS_REGION,
    model_kwargs={"temperature": 0.7},
)

# ---------------------------------------------------------------------------
# GRAPH STATE
# ---------------------------------------------------------------------------
class GraphState(TypedDict):
    incident_report: str   # raw iLO incident data — set once
    author_draft:    str   # produced by author_node
    critic_output:   str   # produced by critic_node


# ---------------------------------------------------------------------------
# PROMPTS
# ---------------------------------------------------------------------------

AUTHOR_SYSTEM = (
    "You are an HPE Level-2 Systems Administrator writing a Change Request (CR) "
    "document for a planned ProLiant server maintenance activity. "
    "Your CR must be clear enough for the Change Advisory Board (CAB) to approve "
    "and for a field engineer to execute in a maintenance window without prior context."
)

AUTHOR_TASK_TEMPLATE = """\
Using the server incident report below, write a Change Request (CR) document
for the required maintenance actions on proliant-node-02.

Required CR sections:
1. Change Summary         (server, change type, reason, urgency)
2. Scope & Blast Radius   (which systems/services are affected during maintenance)
3. Maintenance Window     (proposed date/time and duration)
4. Pre-Change Checks      (steps to verify server state before starting)
5. Change Steps           (numbered procedure with exact HPE commands)
6. Validation Steps       (how to confirm success after the change)
7. Rollback Plan          (exactly how to undo if something goes wrong)
8. Approvals Required     (CAB, server owner, application team)

Keep to approximately 250-300 words. Be specific.

--- SERVER INCIDENT REPORT ---
{incident_report}
------------------------------
"""

CRITIC_SYSTEM = (
    "You are an HPE Change Advisory Board (CAB) reviewer — a senior infrastructure "
    "architect whose only job is to find gaps in Change Request documents and produce "
    "a safer, more complete revised version. "
    "You do NOT write CRs from scratch; you evaluate and fix existing ones. "
    "You have approved and rejected hundreds of HPE ProLiant maintenance CRs. "
    "You know that a CR missing a rollback plan or blast-radius assessment has "
    "caused major outages. You are systematically rigorous."
)

CRITIC_TASK_TEMPLATE = """\
Review the Change Request draft below against this HPE CAB review rubric.
Be explicit about every issue you find under each rubric point.

HPE CR REVIEW RUBRIC:
1) BLAST RADIUS      — Does the CR clearly state which servers, services, VMs, and
                        jobs are affected during maintenance? Is the production impact
                        window quantified?
2) PRE-CHANGE CHECKS — Are there explicit steps to verify the server is in a
                        safe state before starting? (SLURM job drain, storage I/O quiesce,
                        iLO connectivity check, backup/snapshot verification)
3) CHANGE PROCEDURE  — Are the exact HPE commands specified?
                        (e.g., ssacli ctrl slot=0 modify dwc=disable for Smart Array,
                         iLO 6 UI/CLI for firmware update, physical DIMM procedure)
                        Are steps numbered and sequenced correctly?
4) ROLLBACK PLAN     — Is there an explicit rollback for EACH change step?
                        What is the recovery path if iLO firmware flash fails mid-way?
                        If the DIMM slot is vacant post-removal and the server won't POST?
5) VALIDATION        — After the change, how do you confirm: BBU is active,
                        write-back cache is re-enabled, DIMM is recognized and ECC-clean,
                        iLO version is correct, SLURM can resume jobs?

Return:
  a) A numbered critique listing every issue found under each rubric point.
  b) A fully revised Change Request that fixes all identified issues.

--- CR DRAFT TO REVIEW ---
{author_draft}
--------------------------
"""


# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------
def read_incident_report() -> str:
    data_path = Path(__file__).resolve().parent / "data" / "ilo_server_health_report.txt"
    if data_path.exists():
        return data_path.read_text(encoding="utf-8")
    return "HPE ProLiant DL380 Gen11 proliant-node-02 incident: Smart Array P408i BBU fault, iLO 6 thermal throttle, DIMM 6A UE error. Advisories: c08245132, a00125843en."


def pause(msg: str = "") -> None:
    if msg:
        print(msg)
    try:
        input("  >>> Press Enter to continue... ")
    except EOFError:
        print("  [non-interactive: continuing automatically]")
    print()


# ---------------------------------------------------------------------------
# LANGGRAPH NODE 1 — Author
# ---------------------------------------------------------------------------
def author_node(state: GraphState) -> dict:
    """Draft the Change Request from the incident report."""
    user_prompt = AUTHOR_TASK_TEMPLATE.format(incident_report=state["incident_report"])
    response = llm.invoke([
        SystemMessage(content=AUTHOR_SYSTEM),
        HumanMessage(content=user_prompt),
    ])
    return {"author_draft": response.content}


# ---------------------------------------------------------------------------
# LANGGRAPH NODE 2 — Critic
# ---------------------------------------------------------------------------
def critic_node(state: GraphState) -> dict:
    """Evaluate the CR draft against the HPE CAB review rubric."""
    user_prompt = CRITIC_TASK_TEMPLATE.format(author_draft=state["author_draft"])
    response = llm.invoke([
        SystemMessage(content=CRITIC_SYSTEM),
        HumanMessage(content=user_prompt),
    ])
    return {"critic_output": response.content}


# ---------------------------------------------------------------------------
# BUILD LANGGRAPH PIPELINE:  START → author → critic → END
# ---------------------------------------------------------------------------
graph_builder = StateGraph(GraphState)
graph_builder.add_node("author", author_node)
graph_builder.add_node("critic", critic_node)
graph_builder.add_edge(START,    "author")
graph_builder.add_edge("author", "critic")
graph_builder.add_edge("critic", END)
app = graph_builder.compile()


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
if __name__ == "__main__":

    print("=" * 70)
    print("  CRITIC PATTERN DEMO  —  HPE Change Request (CR) Review")
    print("=" * 70)
    print()
    print("WHAT IS THE CRITIC PATTERN?")
    print("-" * 70)
    print("A Critic agent is a SEPARATE evaluator that checks another agent's")
    print("output within the SAME execution run.")
    print()
    print("  Author node : drafts the Change Request from incident data (LLM call #1)")
    print("  Critic node : reviews CR against CAB rubric, produces fixed version (LLM call #2)")
    print()
    print("  This mirrors HPE's own change management process: an engineer drafts,")
    print("  a senior reviewer checks before the CAB approves and execution begins.")
    print()
    print(f"  LLM backend : {MODEL_ID}  (AWS Bedrock)")
    print(f"  Framework   : LangGraph  (START → author → critic → END)")
    print()

    pause(
        "MAINTENANCE SCENARIO\n"
        + "-" * 70 + "\n"
        + "proliant-node-02 crashed at 3 AM. Root cause: Smart Array P408i\n"
        + "BBU fault + DIMM 6A uncorrectable ECC error.\n"
        + "Required: P408i FW update, iLO 6 FW update, DIMM replacement.\n"
        + "A Change Request must be approved by CAB before the maintenance window.\n"
        + "A missing rollback plan or blast-radius assessment could block approval\n"
        + "or cause an extended outage during execution."
    )

    report = read_incident_report()

    print("STEP 1 — AUTHOR NODE CONFIGURATION")
    print("-" * 70)
    print("The Author node persona:")
    print(f'  "{AUTHOR_SYSTEM}"')
    print()
    print("The Author task (incident report will be injected):")
    print()
    for line in AUTHOR_TASK_TEMPLATE.format(incident_report="<< incident report >>").splitlines():
        print(f"    {line}")
    print()
    pause(">> LangGraph will now invoke the Author node (Bedrock LLM call #1).")

    print("STEP 2 — CRITIC NODE CONFIGURATION")
    print("-" * 70)
    print("The Critic node persona:")
    print(f'  "{CRITIC_SYSTEM}"')
    print()
    print("The Critic rubric (CR draft will be injected at runtime):")
    print()
    preview = CRITIC_TASK_TEMPLATE.replace("{author_draft}", "<< CR draft will be inserted here >>")
    for line in preview.splitlines():
        print(f"    {line}")
    print()
    print("KEY POINT: The Critic prompt contains an explicit HPE CAB RUBRIC.")
    print("Without a rubric, a reviewer LLM gives vague praise.")
    print("With a rubric, it becomes a CAB gate — every safety dimension")
    print("must be addressed or the CR gets a numbered list of deficiencies.")
    print()
    pause(">> LangGraph will run Author → Critic now. Watch both outputs.")

    print("=" * 70)
    print("  RUNNING LANGGRAPH PIPELINE")
    print("=" * 70)
    print()
    print("  [ Author node executing... please wait ]")
    print()

    final_state = {}
    for event in app.stream(
        {"incident_report": report},
        stream_mode="updates",
    ):
        node_name, node_output = next(iter(event.items()))

        if node_name == "author":
            print("[ AUTHOR NODE COMPLETED ]")
            print("-" * 70)
            print("First-pass CR draft — competent but potentially missing:")
            print("rollback steps per change, SLURM drain procedure, blast-radius detail.")
            print()
            print(node_output["author_draft"])
            print()
            final_state["author_draft"] = node_output["author_draft"]
            pause(">> Author node done. Critic will now review against HPE CAB rubric.")
            print("  [ Critic node executing... please wait ]")
            print()

        elif node_name == "critic":
            print("[ CRITIC NODE COMPLETED ]")
            print("-" * 70)
            print("The Critic evaluated the CR against all five CAB rubric points.")
            print("Below: (a) numbered issues found,  (b) revised safer CR.")
            print()
            print(node_output["critic_output"])
            print()
            final_state["critic_output"] = node_output["critic_output"]
            pause()

    # Save outputs
    out_dir = Path(__file__).resolve().parent / "outputs"
    out_dir.mkdir(exist_ok=True)
    out_path = out_dir / "hpe_change_request_critic.md"
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("# HPE Change Request — Author Draft (pre-Critic)\n\n")
        f.write(final_state.get("author_draft", ""))
        f.write("\n\n---\n\n")
        f.write("# HPE Change Request — CAB-Reviewed Revision (post-Critic)\n\n")
        f.write(final_state.get("critic_output", ""))
    print(f"Both draft and revised CR saved to: {out_path}")
    print()

    print("=" * 70)
    print("  OUTCOME SUMMARY — CRITIC PATTERN IN HPE CONTEXT")
    print("=" * 70)
    print()
    print("  BEFORE Critic pass (Author only):")
    print("    - Competent structured CR from incident data")
    print("    - Likely gaps: missing SLURM drain steps, vague rollback,")
    print("      no iLO firmware flash failure recovery, blast-radius understated")
    print()
    print("  AFTER Critic pass (Author + Critic):")
    print("    - Critic identified every gap against the 5-point CAB rubric")
    print("    - Revised CR is demonstrably safer and more complete")
    print("    - Cost: 2 LLM calls, 1 LangGraph pipeline execution")
    print()
    print("  WHY THE RUBRIC IS THE KEY INGREDIENT:")
    print("    Without the rubric, the Critic is just another writing assistant.")
    print("    With the rubric, it becomes a CAB gate — the Critic MUST address")
    print("    blast-radius, rollback, and validation before the pipeline ends.")
    print("    That is what separates the Critic pattern from a simple 'review this'.")
    print()
    print("  HPE REAL-WORLD ANALOGY:")
    print("    This mirrors HPE's Change Management process: an engineer submits a CR,")
    print("    a CAB reviewer finds gaps, the engineer revises before the change window.")
    print("    The AI Critic compresses that review cycle from days to seconds.")
    print("=" * 70)
