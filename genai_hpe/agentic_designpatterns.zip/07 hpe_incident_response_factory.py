# -*- coding: utf-8 -*-
"""
Factory Pattern — Dynamic HPE Incident Response Graph Assembly at Runtime
=========================================================================
Implemented with LangGraph dynamic graph construction

Factory Pattern:
  A factory function examines the incident and builds the right agent
  configuration at runtime. The caller does not hardcode which response
  team to assemble — the factory inspects the incident profile and decides.

  "Don't build one graph that routes every incident through every possible
   specialist. Build the right response team for each incident type."

LangGraph implementation:
  - Three build_*_graph() functions create different StateGraph topologies
  - All three share a single IncidentState TypedDict
  - specialist_notes: Annotated[List[str], operator.add]
      each specialist node APPENDS its assessment; the compile node
      reads them all — whether there is 1 note or 4
  - The factory function examines the incident severity and type,
    then calls the right builder

================================================================================
HPE USE CASE — Incident Response Factory:
================================================================================
An HPE NOC receives server incidents of varying complexity. Routing every
incident through the full specialist team wastes time. Routing a simple
alert to only L1 triage misses critical context for complex failures.

The factory assembles the right team automatically:

  SIMPLE (single component alert):
    → L1 NOC triage only
    Example: "iLO temperature warning on proliant-node-07 — CPU1 82C"

  MODERATE (two interacting components):
    → Domain specialist + Change Risk assessor
    Example: "Smart Array BBU fault + write-through mode degrading SAP HANA I/O"

  COMPLEX (multi-layer cascade or production impact):
    → Full stack: iLO/Hardware + OS/Kernel + Storage + Network specialists
      + Incident Commander synthesis
    Example: "Cluster meltdown: thermal → BBU → OOM → NFS → app crash"

Nodes are REUSED across pathways. The storage specialist and change risk
assessor appear in both moderate and complex pathways — the factory
assembles them differently each time.
"""

import os
import operator
from pathlib import Path
from typing import TypedDict, List, Annotated
from textwrap import dedent
from dotenv import load_dotenv
import warnings

warnings.filterwarnings("ignore")

import sys
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------
def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

from langchain_aws import ChatBedrock
from langgraph.graph import StateGraph, END

llm = ChatBedrock(model_id=MODEL_ID, region_name=AWS_REGION, model_kwargs={"temperature": 0.4})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def pause(msg="Press Enter to continue..."):
    try:
        input(f"\n  [{msg}] ")
    except EOFError:
        print("  [non-interactive: continuing automatically]")
    print()

def section(title, width=70):
    print("=" * width)
    print(f"  {title}")
    print("=" * width)

def subsection(title, width=70):
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print("─" * width)

def indent(text, prefix="  "):
    return "\n".join(prefix + line for line in text.splitlines())


# =============================================================================
# SHARED STATE — Used by ALL three graph topologies
#
# specialist_notes uses operator.add so each node APPENDS its assessment.
# The compile node reads them all — whether there is 1 note or 4.
# The same state type works for a 1-node graph and a 5-node graph.
# =============================================================================

class IncidentState(TypedDict):
    # ── Incident input ────────────────────────────────────────────────────────
    incident_id:   str
    server:        str
    severity:      str          # "simple" | "moderate" | "complex"
    alert_summary: str          # Short description of the alert
    raw_data:      str          # Full iLO IML + kernel log fragments

    # ── Accumulated specialist assessments ────────────────────────────────────
    # operator.add: each specialist node appends one item to this list.
    # The compile node synthesises whatever is present — 1, 2, or 4 items.
    specialist_notes: Annotated[List[str], operator.add]

    # ── Final output ──────────────────────────────────────────────────────────
    response_plan: str


# =============================================================================
# SPECIALIST NODE FUNCTIONS
# These are plain functions. The factory assembles them into different
# graph topologies — some nodes appear in multiple pathways.
# =============================================================================

def l1_noc_triage_node(state: IncidentState) -> dict:
    """L1 NOC triage — used in the SIMPLE pathway only."""
    prompt = dedent(f"""\
        You are an HPE NOC Level-1 engineer doing a first-pass alert triage.

        INCIDENT: {state['incident_id']} | Server: {state['server']}
        ALERT: {state['alert_summary']}
        DATA:
        {state['raw_data']}

        Provide a brief L1 triage (3-4 sentences):
        - Is this alert actionable right now or can it wait for a scheduled window?
        - What is the immediate recommended action (acknowledge, escalate, or self-resolve)?
        - Any HPE iLO CLI command to quickly verify the alert condition?
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"L1 NOC TRIAGE:\n{result.content}"]}


def hardware_specialist_node(state: IncidentState) -> dict:
    """HPE hardware/iLO specialist — used in MODERATE and COMPLEX pathways."""
    prompt = dedent(f"""\
        You are an HPE Level-3 Hardware Specialist. Analyse only the hardware and
        iLO layer of this incident.

        INCIDENT: {state['incident_id']} | Server: {state['server']}
        DATA:
        {state['raw_data']}

        Provide a hardware-layer assessment (3-4 sentences):
        - Which hardware components are implicated (CPU, DIMM, Smart Array, BBU, NIC, fan)?
        - What does the iLO IML sequence tell you about the failure progression?
        - Are there relevant HPE advisories (check for: BBU fault → c08245132,
          thermal throttle → a00125843en, DIMM UE → iLO 6 v1.55)?
        - Immediate hardware action required?

        Do not address OS or network layers.
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"HARDWARE SPECIALIST:\n{result.content}"]}


def storage_specialist_node(state: IncidentState) -> dict:
    """Storage specialist — used in MODERATE and COMPLEX pathways."""
    prompt = dedent(f"""\
        You are an HPE Storage Specialist (Smart Array + Alletra/Nimble).
        Analyse only the storage layer of this incident.

        INCIDENT: {state['incident_id']} | Server: {state['server']}
        DATA:
        {state['raw_data']}

        Provide a storage-layer assessment (3-4 sentences):
        - What is the storage symptom (BBU fault, RAID degraded, I/O latency, SMART alert)?
        - Impact on storage performance (write-back vs write-through, queue depth)?
        - ssacli command to diagnose the specific condition?
        - Is this a pre-failure warning or active failure requiring immediate action?

        Do not address compute or network layers.
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"STORAGE SPECIALIST:\n{result.content}"]}


def os_kernel_specialist_node(state: IncidentState) -> dict:
    """Linux kernel/OS specialist — used in COMPLEX pathway only."""
    prompt = dedent(f"""\
        You are a Linux kernel and systems reliability engineer. Analyse only the OS layer.

        INCIDENT: {state['incident_id']} | Server: {state['server']}
        DATA:
        {state['raw_data']}

        Provide an OS-layer assessment (3-4 sentences):
        - What kernel events occurred (OOM, I/O wait, machine check, kernel panic)?
        - What processes were killed or what services failed?
        - Is the root cause at the OS level, or is the OS a victim of a lower-level failure?
        - What kernel log evidence points to the upstream hardware/storage failure?

        Do not address hardware internals or network.
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"OS/KERNEL SPECIALIST:\n{result.content}"]}


def network_specialist_node(state: IncidentState) -> dict:
    """Network specialist — used in COMPLEX pathway only."""
    prompt = dedent(f"""\
        You are an HPE network fabric specialist. Analyse only the network layer.

        INCIDENT: {state['incident_id']} | Server: {state['server']}
        DATA:
        {state['raw_data']}

        Provide a network-layer assessment (3-4 sentences):
        - Were there NFS timeouts, iSCSI drops, or RDMA PFC stalls?
        - Did any NIC link events occur (speed changes, link drops)?
        - Is the network failure a root cause or a downstream symptom?
        - Any relevant NIC firmware advisory (ConnectX-7 → a00137661en)?

        Do not address storage internals or OS layer.
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"NETWORK SPECIALIST:\n{result.content}"]}


def change_risk_node(state: IncidentState) -> dict:
    """Change risk assessor — used in MODERATE pathway."""
    prompt = dedent(f"""\
        You are an HPE Change Risk Assessor. Based on the specialist assessment(s)
        available, determine what change actions are needed and their risk profile.

        INCIDENT: {state['incident_id']} | Server: {state['server']}
        SEVERITY: {state['severity']}
        SPECIALIST INPUTS:
        {chr(10).join(state.get('specialist_notes', ['No specialist notes yet.']))}

        Provide a change risk assessment (3-4 sentences):
        - What change actions are needed (firmware update, hardware replacement, config change)?
        - What is the risk to production if we act now vs. defer to maintenance window?
        - Can the change be done non-disruptively (iLO update = non-disruptive;
          DIMM replacement = requires server power-off)?
        - Recommended change window and approvals needed?
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"CHANGE RISK ASSESSMENT:\n{result.content}"]}


def incident_commander_node(state: IncidentState) -> dict:
    """
    Incident Commander — used in COMPLEX pathway only.
    Synthesises ALL specialist inputs into a unified response plan.
    """
    notes_block = "\n\n".join(state.get("specialist_notes", []))
    prompt = dedent(f"""\
        You are the Incident Commander for a major HPE ProLiant server incident.
        You have received assessments from Hardware, OS/Kernel, Storage, and Network specialists.
        Produce a unified incident response plan.

        INCIDENT: {state['incident_id']} | Server: {state['server']}
        SEVERITY: {state['severity'].upper()}

        ALL SPECIALIST ASSESSMENTS:
        {notes_block}

        Produce a numbered incident response plan (5-7 steps):
        1. Immediate actions (next 30 minutes) — what to do RIGHT NOW
        2. Root cause determination — primary vs. contributing failures
        3. Restoration steps — how to return the server to production
        4. Post-incident fixes — firmware, hardware, config changes required
        5. Monitoring enhancements — what thresholds or alerts to add
        6. Timeline and ownership — who does what by when

        Be decisive. This is a production outage.
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"INCIDENT COMMANDER SYNTHESIS:\n{result.content}"]}


def compile_response_node(state: IncidentState) -> dict:
    """
    Compile final response plan from ALL available specialist notes.
    Works for SIMPLE (1 note), MODERATE (2-3 notes), and COMPLEX (5 notes).
    """
    notes_block = "\n\n".join(state.get("specialist_notes", []))

    if state["severity"] in ("simple",):
        # For simple incidents, the L1 triage IS the response
        return {"response_plan": notes_block}

    # For moderate/complex, produce a concise executive summary
    prompt = dedent(f"""\
        Produce a concise incident response summary for:

        INCIDENT: {state['incident_id']} | Server: {state['server']}
        SEVERITY: {state['severity'].upper()}

        SPECIALIST INPUT(S):
        {notes_block}

        Summary format:
        - SEVERITY: [P1/P2/P3]
        - ROOT CAUSE: [one sentence]
        - IMMEDIATE ACTION: [one sentence — what to do in next 30 min]
        - NEXT STEPS: [numbered list, max 3 items]
        - ESTIMATED RESOLUTION TIME: [hours]
    """)
    result = llm.invoke(prompt)
    return {"response_plan": result.content}


# =============================================================================
# FACTORY FUNCTIONS — Build the right graph for each severity level
# =============================================================================

def build_simple_graph():
    """
    SIMPLE pathway: L1 triage only.
    Single-component alert — no cascade risk.
    """
    g = StateGraph(IncidentState)
    g.add_node("l1_noc",  l1_noc_triage_node)
    g.add_node("compile", compile_response_node)
    g.set_entry_point("l1_noc")
    g.add_edge("l1_noc",  "compile")
    g.add_edge("compile", END)
    return g.compile()


def build_moderate_graph():
    """
    MODERATE pathway: Hardware + Storage specialists + Change Risk.
    Two interacting components — needs domain expertise and change planning.
    """
    g = StateGraph(IncidentState)
    g.add_node("hardware",    hardware_specialist_node)
    g.add_node("storage",     storage_specialist_node)
    g.add_node("change_risk", change_risk_node)
    g.add_node("compile",     compile_response_node)
    g.set_entry_point("hardware")
    g.add_edge("hardware",    "storage")
    g.add_edge("storage",     "change_risk")
    g.add_edge("change_risk", "compile")
    g.add_edge("compile",     END)
    return g.compile()


def build_complex_graph():
    """
    COMPLEX pathway: Full stack — Hardware + OS + Storage + Network + Incident Commander.
    Multi-layer cascade or production impact — needs full team + synthesis.
    """
    g = StateGraph(IncidentState)
    g.add_node("hardware",           hardware_specialist_node)
    g.add_node("os_kernel",          os_kernel_specialist_node)
    g.add_node("storage",            storage_specialist_node)
    g.add_node("network",            network_specialist_node)
    g.add_node("incident_commander", incident_commander_node)
    g.add_node("compile",            compile_response_node)
    g.set_entry_point("hardware")
    g.add_edge("hardware",           "os_kernel")
    g.add_edge("os_kernel",          "storage")
    g.add_edge("storage",            "network")
    g.add_edge("network",            "incident_commander")
    g.add_edge("incident_commander", "compile")
    g.add_edge("compile",            END)
    return g.compile()


# =============================================================================
# THE FACTORY FUNCTION — Examines the incident and calls the right builder
# =============================================================================

def incident_response_factory(incident: IncidentState):
    """
    Factory: inspects incident severity and assembles the right graph at runtime.
    Returns the compiled graph — the caller invokes it without knowing which
    topology was built.
    """
    severity = incident.get("severity", "simple").lower()
    if severity == "simple":
        print(f"  [FACTORY] Severity: SIMPLE → assembling L1 triage pathway (1 node)")
        return build_simple_graph()
    elif severity == "moderate":
        print(f"  [FACTORY] Severity: MODERATE → assembling hardware+storage+change pathway (3 nodes)")
        return build_moderate_graph()
    else:
        print(f"  [FACTORY] Severity: COMPLEX → assembling full-stack pathway (5 nodes)")
        return build_complex_graph()


# =============================================================================
# THREE DEMO INCIDENTS
# =============================================================================

DEMO_INCIDENTS = [
    {
        "incident_id":   "INC-S-001",
        "server":        "proliant-node-07",
        "severity":      "simple",
        "alert_summary": "iLO temperature warning: CPU1 temperature 79C (warn threshold: 75C). No throttle yet.",
        "raw_data": dedent("""\
            14:22:05  CAUTION  [Thermal]  CPU1: 79C (warn: 75C, crit: 90C)
            14:22:06  INFO     [Power]    CPU1 power state: P0 (no throttle yet)
            14:25:00  INFO     [Fan]      Zone A fans: 45% → 62% (thermal auto-response)
            14:30:00  INFO     [Thermal]  CPU1: 76C (stabilizing)
        """),
    },
    {
        "incident_id":   "INC-M-002",
        "server":        "proliant-node-05",
        "severity":      "moderate",
        "alert_summary": "Smart Array P408i BBU fault — controller in write-through mode. SAP HANA I/O latency elevated (42ms avg, SLA: 10ms).",
        "raw_data": dedent("""\
            10:05:12  CRITICAL [Storage]  Smart Array P408i-a: BBU fault — write-back cache DISABLED
            10:05:14  CRITICAL [Storage]  Controller entered write-through mode
            10:06:30  WARNING  [Storage]  I/O queue depth: 78% (3,994/5,120)
            10:08:00  WARNING  [OS]       SAP HANA: database I/O wait exceeding threshold (42ms avg)
            10:10:00  WARNING  [Storage]  Smart Array: I/O queue 89% (4,557/5,120) — approaching saturation
        """),
    },
    {
        "incident_id":   "INC-C-003",
        "server":        "proliant-node-02",
        "severity":      "complex",
        "alert_summary": "Production cluster meltdown: thermal throttle → BBU fault → I/O storm → OOM → NFS loss → app crash. Server reset by ASR watchdog.",
        "raw_data": dedent("""\
            03:08:33  CAUTION  [Thermal]  CPU1: 83C — exceeded warn threshold (82C)
            03:08:33  CAUTION  [Power]    CPU1 throttled P0→P3 (-48% performance)
            03:10:08  CRITICAL [Storage]  Smart Array P408i-a: BBU fault — write-back DISABLED
            03:10:09  CRITICAL [Storage]  Controller entered write-through mode
            03:09:15  ERROR    [OS/Kernel] hpsa 0000:05:00.0: controller busy — I/O retries failed
            03:12:16  CRITICAL [OS/Kernel] OOM kill: python3 (ML training job, 128GB RSS)
            03:15:44  CRITICAL [Memory]   DIMM 6A: Uncorrectable Error (UE) — hardware fault
            03:47:51  WARNING  [NIC/Net]  FlexibleLOM port 1: link degraded 100GbE→25GbE
            03:52:05  ERROR    [OS/Net]   NFS: server storage-san-01 not responding — timeout
            03:53:55  CRITICAL [OS/Net]   NFS unmount /data/shared (stale filehandle)
            03:22:41  CRITICAL [System]   ASR watchdog reset — OS unresponsive 300s
        """),
    },
]


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    section("FACTORY PATTERN — HPE Incident Response Graph Assembly")
    print("""
  PATTERN OVERVIEW
  ─────────────────
  The factory function examines each incident's severity profile and
  assembles the RIGHT agent team at runtime — no more, no less.

  SIMPLE   → 1 node: L1 NOC triage
             (temperature warning — watch-and-wait)

  MODERATE → 3 nodes: Hardware specialist + Storage specialist + Change Risk
             (BBU fault degrading production SAP HANA — needs domain expertise)

  COMPLEX  → 5 nodes: Hardware + OS/Kernel + Storage + Network + Incident Commander
             (multi-layer cascade failure — needs full stack analysis + synthesis)

  KEY INSIGHT:
    Nodes are REUSED across pathways. The storage specialist appears in both
    MODERATE and COMPLEX. The factory assembles the same node into a different
    graph topology each time. This is the factory pattern's power:
    "Build the right graph, not a Swiss Army knife that does everything."
""")

    for idx, incident in enumerate(DEMO_INCIDENTS):
        pause(f"Press Enter for Incident {idx+1}/3: {incident['incident_id']} (SEVERITY: {incident['severity'].upper()})")

        subsection(f"INCIDENT {idx+1}/3 — {incident['incident_id']}")
        print(f"  Server:   {incident['server']}")
        print(f"  Severity: {incident['severity'].upper()}")
        print(f"  Alert:    {incident['alert_summary']}")
        print()

        # Factory creates the right graph at runtime
        graph = incident_response_factory(incident)
        print()

        # Show which nodes were assembled
        topology = {
            "simple":   "L1 NOC → compile",
            "moderate": "hardware → storage → change_risk → compile",
            "complex":  "hardware → os_kernel → storage → network → incident_commander → compile",
        }
        print(f"  Graph topology: {topology[incident['severity']]}")
        print()

        state: IncidentState = {
            **incident,
            "specialist_notes": [],
            "response_plan":    "",
        }

        final = graph.invoke(state)

        print("  RESPONSE PLAN:")
        print("─" * 70)
        print(final["response_plan"])

        if idx == 0:
            print()
            print("  FACTORY ADVANTAGE:")
            print("    This simple temperature alert got L1 triage only.")
            print("    No storage, OS, or network specialists were invoked.")
            print("    Cost: 1 LLM call. Time: ~3 seconds.")
            print("    A monolithic 'route everything through all agents' design")
            print("    would have used 5 LLM calls and taken 5x longer.")

        elif idx == 2:
            print()
            print("  FACTORY ADVANTAGE:")
            print("    The same storage_specialist_node function ran in both")
            print("    the MODERATE and COMPLEX graphs — reused, not duplicated.")
            print("    The COMPLEX graph added OS/Kernel and Network specialists")
            print("    only because the cascade failure required them.")
            print(f"    Notes accumulated: {len(final['specialist_notes'])}")

    print()
    section("KEY TAKEAWAYS — FACTORY PATTERN")
    print("""
  1. The factory examines the input and builds the MINIMUM viable graph.
     SIMPLE alerts don't need 5 specialists. COMPLEX cascades do.
     Right-sizing the graph saves cost and reduces latency.

  2. Node REUSE across topologies is the factory pattern's elegance.
     storage_specialist_node is defined once. The factory places it
     in the right position in whichever graph it builds.

  3. The caller doesn't know which graph was built.
     incident_response_factory() returns a compiled graph.
     graph.invoke(state) works identically for all three topologies.
     The factory is the only place that knows the routing decision.

  4. Annotated[List[str], operator.add] on specialist_notes means
     the compile node works regardless of how many specialists ran.
     It reads whatever is in the list — 1 entry or 5 — and synthesises.

  5. HPE REAL-WORLD ANALOGY:
     L1 NOC engineers shouldn't page L3 architects for a temperature warning.
     L3 architects shouldn't spend time on simple alerts that L1 can handle.
     The factory enforces the right escalation path — automatically, at runtime.
""")
