# LangGraph — Agentic AI Framework

## What is LangGraph?

LangGraph is a low-level orchestration library from LangChain that lets you build **stateful, multi-step AI agents as directed graphs**. Each node in the graph is a function (an LLM call, a tool execution, a decision step). Edges between nodes define the flow of control — either fixed sequences or conditional branches driven by LLM output or state values.

LangGraph is purpose-built for agentic workloads where you need:
- Explicit control over the execution path (not hidden inside a black-box agent loop)
- Persistent, typed state shared across all nodes
- Conditional routing, cycles, and human-in-the-loop checkpoints
- Streaming and step-by-step observability

---

## Core Concepts

### 1. State (`TypedDict`)

The central data structure threaded through every node. You define it as a Python `TypedDict`. Every node receives the full state and returns a partial dict with only the keys it updated.

```python
from typing import TypedDict, List, Annotated
import operator

class AgentState(TypedDict):
    user_query:   str
    route:        str          # "weather" | "stock" | "unknown"
    messages:     Annotated[List, operator.add]  # append-only with Annotated
    final_answer: str
```

`Annotated[List, operator.add]` is a LangGraph convention: instead of replacing the list on each update, new items are **appended** — critical for building conversation history.

---

### 2. Nodes

A node is any callable `(state: State) -> dict`. It reads from state and returns only the keys it wants to update.

```python
def router_node(state: AgentState) -> dict:
    llm = get_llm()
    response = llm.invoke([
        SystemMessage(content="Classify as 'weather' or 'stock'. Return JSON only."),
        HumanMessage(content=state["user_query"]),
    ])
    route = parse_json(response.content).get("route", "unknown")
    return {"route": route}   # only updates 'route' in state
```

---

### 3. Edges

**Fixed edges** always go from node A to node B:

```python
graph.add_edge("weather_agent", END)
```

**Conditional edges** call a selector function to decide the next node at runtime:

```python
def route_selector(state: AgentState) -> str:
    if state["route"] == "weather":
        return "weather_agent"
    if state["route"] == "stock":
        return "stock_agent"
    return END

graph.add_conditional_edges(
    "router",              # source node
    route_selector,        # decides next node
    {                      # explicit mapping (optional but recommended for clarity)
        "weather_agent": "weather_agent",
        "stock_agent":   "stock_agent",
        END:             END,
    },
)
```

---

### 4. `StateGraph` and Compilation

```python
from langgraph.graph import StateGraph, END

g = StateGraph(AgentState)

g.add_node("router",        router_node)
g.add_node("weather_agent", weather_agent_node)
g.add_node("stock_agent",   stock_agent_node)

g.set_entry_point("router")

g.add_conditional_edges("router", route_selector, {...})
g.add_edge("weather_agent", END)
g.add_edge("stock_agent",   END)

app = g.compile()               # compile once; invoke many times
result = app.invoke(initial_state)
```

---

### 5. Tool-Augmented Nodes

Bind tools to an LLM with `.bind_tools(tools)`. The LLM returns `tool_calls` in its response; your node executes them and appends a `ToolMessage`.

```python
from langchain_core.tools import tool as lc_tool
from langchain_core.messages import ToolMessage

@lc_tool
def get_weather(location: str) -> str:
    """Get current weather for a city."""
    # ... call weather API ...
    return json.dumps({"temp_c": 22, "description": "partly cloudy"})

def weather_agent_node(state: AgentState) -> dict:
    llm = get_llm().bind_tools([get_weather])
    messages = [SystemMessage(content="Use get_weather to answer."),
                HumanMessage(content=state["user_query"])]

    response = llm.invoke(messages)                  # may return tool_calls

    if response.tool_calls:
        tc = response.tool_calls[0]
        result = get_weather.invoke(tc["args"])      # execute the tool
        messages += [response, ToolMessage(content=result, tool_call_id=tc["id"])]
        response = llm.invoke(messages)              # second call with tool result

    return {"final_answer": response.content}
```

---

### 6. Human-in-the-Loop (HITL) with `interrupt_before`

LangGraph supports pausing execution before a node runs, waiting for human input, then resuming. This requires a **checkpointer** (e.g. `MemorySaver`) so state is persisted across the interruption.

```python
from langgraph.checkpoint.memory import MemorySaver

checkpointer = MemorySaver()
app = g.compile(
    checkpointer=checkpointer,
    interrupt_before=["human_approval_node"],   # pause before this node
)

config = {"configurable": {"thread_id": "deployment-001"}}

# First run — stops at interrupt
app.invoke(initial_state, config=config)

# Engineer inspects state, then resumes with their decision
app.invoke({"human_decision": "approve"}, config=config)
```

---

### 7. Parallel Sub-Graphs

Use `Send` to fan out work to multiple nodes simultaneously:

```python
from langgraph.types import Send

def fan_out(state: AgentState):
    return [
        Send("validate_network", state),
        Send("validate_storage", state),
        Send("validate_ilo",     state),
    ]

graph.add_conditional_edges("planner", fan_out)
```

All three validation nodes run concurrently; a downstream node collects results via `Annotated[List, operator.add]` state fields.

---

## Building an Agentic Flow — Step by Step

```
1. Define your State TypedDict
2. Write node functions (each returns a partial state dict)
3. Create StateGraph(State)
4. add_node() for each node
5. set_entry_point()
6. add_edge() / add_conditional_edges() to wire the graph
7. compile() → invoke() or stream()
```

---

## Complete Example: Weather / Stock Router

This is the `langgraph_weather_stock_router.py` demo in this folder.

```
User Query
    │
    ▼
[router_node]   ← LLM classifies query → {"route": "weather"} or {"route": "stock"}
    │
    ├──── route=="weather" ──▶ [weather_agent_node] ──▶ get_weather tool ──▶ answer
    │
    └──── route=="stock"   ──▶ [stock_agent_node]   ──▶ get_stock_price tool ──▶ answer
```

Key patterns used:
- **TypedDict state** with `user_query`, `route`, `final_answer`
- **Router node** uses LLM to classify the query into a JSON routing decision
- **Conditional edge** reads `state["route"]` to pick the next node
- **Tool-augmented nodes** bind LangChain tools and run a 2-step LLM loop (tool call → result → final answer)
- **Streamlit diagnostics** show every LLM call, message array, tool invocation, and result live

---

## Complete Example: Datacenter Deployment Planner with HITL

The `langgraph_datacenter_deployment.py` demo shows:

```
[planner_node]
      │
      ▼
[reflection_node]  ← self-critique loop (up to 2 iterations)
      │
      ▼
[validate_network]  ─┐
[validate_storage]  ─┤  (parallel via Send)
[validate_ilo]      ─┘
      │
      ▼
[risk_assessment_node]
      │
      ▼ ← interrupt_before here — human engineer reviews
[human_approval_node]
      │
      ├── approve  ──▶ [generate_runbook_node] ──▶ END
      ├── revise   ──▶ back to [planner_node]
      └── reject   ──▶ END
```

Key patterns:
- **Append-only audit trail** via `Annotated[List, operator.add]`
- **Reflection loop** with cycle edge and loop counter in state
- **Parallel validators** via `Send` fan-out
- **HITL checkpoint** using `MemorySaver` + `interrupt_before`
- **Conditional post-HITL routing** (approve / revise / reject)

---

## Memory and State in LangGraph

LangGraph's memory model maps directly onto its typed state object and checkpointing system. There is no separate "memory module" — state **is** memory, and where it is stored determines how long it lives.

### Short-Term Memory (In-Graph State)

Short-term memory is the `TypedDict` state object flowing through a single `invoke()` call. Every node that runs reads the whole state and can write to it; downstream nodes automatically see those writes. The `messages` list is the canonical short-term scratchpad — it grows as the graph runs.

```python
from typing import TypedDict, List, Annotated
import operator
from langchain_core.messages import BaseMessage

class AgentState(TypedDict):
    user_query:   str
    messages:     Annotated[List[BaseMessage], operator.add]  # grows across nodes
    tool_results: Annotated[List[dict], operator.add]         # each node appends its findings
    route:        str
    final_answer: str
```

`Annotated[List, operator.add]` is the key idiom: instead of replacing the list on each node update, new items are **appended**. This gives a full audit trail within the run — every LLM response, tool call, and tool result is preserved and visible to all subsequent nodes.

Short-term state is lost when the process exits unless you attach a checkpointer.

---

### Long-Term Memory (Cross-Session Persistence via Checkpointers)

Long-term memory is achieved by attaching a **checkpointer** to the compiled graph. The checkpointer serialises the full state to a backing store after every node completes, keyed by `thread_id`. On the next `invoke()` with the same `thread_id`, the graph restores that state and continues as if the prior session never ended.

```python
from langgraph.checkpoint.memory import MemorySaver          # in-process only
from langgraph.checkpoint.sqlite import SqliteSaver           # pip install langgraph-checkpoint-sqlite
from langgraph.checkpoint.postgres import PostgresSaver       # pip install langgraph-checkpoint-postgres

# SQLite — persists to disk, survives restarts
with SqliteSaver.from_conn_string("agent_memory.db") as saver:
    app = g.compile(checkpointer=saver)

config = {"configurable": {"thread_id": "hpe-incident-proliant-node-01"}}

# Session 1
app.invoke({"user_query": "What caused the BBU fault?"}, config=config)

# Session 2 — same thread_id; the graph sees the full prior state
app.invoke({"user_query": "Was the firmware update applied?"}, config=config)
```

To accumulate structured long-term facts across sessions, store them explicitly in a dedicated state field:

```python
class AgentState(TypedDict):
    messages:    Annotated[List, operator.add]
    known_facts: Annotated[List[str], operator.add]   # never truncated; grows over time

def analyst_node(state: AgentState) -> dict:
    prior_facts = "\n".join(state.get("known_facts", []))
    # inject prior_facts into the LLM prompt as background context
    new_fact = "BBU capacitor degradation confirmed on proliant-node-01 (2025-03-21)"
    return {"known_facts": [new_fact]}   # appended to the accumulator
```

---

### Episodic Memory (Semantic Recall Across Sessions)

Episodic memory stores **summaries of past interactions** in a vector store so that future runs can retrieve semantically relevant episodes. The pattern requires two dedicated nodes: one that loads relevant past episodes at the start of a run, and one that saves the current run's summary at the end.

```python
from langchain_community.vectorstores import Chroma
from langchain_aws import BedrockEmbeddings

episode_store = Chroma(
    collection_name="agent_episodes",
    embedding_function=BedrockEmbeddings(model_id="amazon.titan-embed-text-v2:0"),
    persist_directory="./episodes_db",
)

def load_episodes_node(state: AgentState) -> dict:
    """Retrieve past episodes relevant to the current query."""
    hits = episode_store.similarity_search(state["user_query"], k=3)
    episodes = [doc.page_content for doc in hits]
    # inject episodes into the messages list as system context
    from langchain_core.messages import SystemMessage
    episode_msg = SystemMessage(content="Relevant past incidents:\n" + "\n---\n".join(episodes))
    return {"messages": [episode_msg]}

def save_episode_node(state: AgentState) -> dict:
    """Summarise this session and persist it for future semantic recall."""
    summary = f"Query: {state['user_query']}\nAnswer: {state['final_answer']}"
    episode_store.add_texts([summary])
    return {}

# Wire the graph: load_episodes → [main agent nodes] → save_episode
g.set_entry_point("load_episodes")
g.add_edge("load_episodes", "router")
g.add_edge("weather_agent", "save_episode")
g.add_edge("stock_agent",   "save_episode")
g.add_edge("save_episode",  END)
```

This pattern is demonstrated in [`agentic_designpatterns/04 hpe_ilo_fault_mem_semantic.py`](../agentic_designpatterns/04%20hpe_ilo_fault_mem_semantic.py) and [`05 hpe_field_service_mem_episodic.py`](../agentic_designpatterns/05%20hpe_field_service_mem_episodic.py).

---

### Memory Types — Summary

| Memory Type | Mechanism | Scope | Persists across restarts? |
|-------------|-----------|-------|--------------------------|
| Short-term | `TypedDict` state + `Annotated[List, operator.add]` | Current `invoke()` call | No |
| Long-term | Checkpointer (`SqliteSaver` / `PostgresSaver`) keyed by `thread_id` | Across sessions per thread | Yes |
| Episodic | Vector store (Chroma / Pinecone) + load/save nodes | Across sessions, semantic retrieval | Yes |

---

## Inter-Agent Communication in LangGraph

In LangGraph there is no message bus between agents. **All communication flows through the shared state object.** An "agent" is a node; nodes coordinate by reading and writing the same `TypedDict`. The graph topology — the edges — defines who can see what and when.

### 1. Shared State (Primary Channel)

When node A writes a field, every node that runs after A on the same graph execution reads that field. This is the fundamental communication mechanism.

```python
class PipelineState(TypedDict):
    raw_logs:        str
    hardware_report: str   # written by ilo_node, read by correlation_node
    os_report:       str   # written by linux_node, read by correlation_node
    final_rca:       str

def ilo_node(state: PipelineState) -> dict:
    report = analyse_ilo_logs(state["raw_logs"])
    return {"hardware_report": report}         # leaves output for downstream nodes

def correlation_node(state: PipelineState) -> dict:
    rca = correlate(state["hardware_report"], state["os_report"])  # reads both
    return {"final_rca": rca}
```

---

### 2. Supervisor / Orchestrator Pattern

A supervisor node reads state, uses an LLM to decide which specialist agent to invoke next, writes that decision into state, and receives control back after the specialist runs. This loop continues until the supervisor writes `"DONE"`.

```python
class OrchestratorState(TypedDict):
    task:       str
    next_agent: str                                    # supervisor writes this
    reports:    Annotated[List[str], operator.add]     # specialists append here

def supervisor_node(state: OrchestratorState) -> dict:
    # LLM decides which specialist to invoke next based on what has been gathered so far
    decision = llm.invoke(build_supervisor_prompt(state["task"], state["reports"]))
    return {"next_agent": decision.content}    # "ilo_agent" | "linux_agent" | "DONE"

def route_to_agent(state: OrchestratorState) -> str:
    return state["next_agent"]

g.add_conditional_edges("supervisor", route_to_agent, {
    "ilo_agent":   "ilo_agent",
    "linux_agent": "linux_agent",
    "DONE":         END,
})
g.add_edge("ilo_agent",   "supervisor")   # always return control to supervisor
g.add_edge("linux_agent", "supervisor")
```

---

### 3. Subgraphs (Nested Agent Graphs)

A compiled `StateGraph` can itself be used as a node inside a parent graph. The parent passes state into the subgraph; the subgraph runs its own internal nodes; its final output is merged back into the parent state. This enables hierarchical agent decomposition.

```python
# Specialist subgraph — has its own internal nodes and edges
sub = StateGraph(SpecialistState)
sub.add_node("fetch",   fetch_node)
sub.add_node("analyse", analyse_node)
sub.add_edge("fetch", "analyse")
sub.add_edge("analyse", END)
specialist_app = sub.compile()

# Parent graph uses the specialist as a single node
parent = StateGraph(PipelineState)
parent.add_node("specialist", specialist_app)   # subgraph is just a node
parent.add_node("aggregator", aggregator_node)
parent.add_edge("specialist", "aggregator")
```

---

### 4. Fan-Out via `Send` (Parallel Agents Writing to a Shared Accumulator)

`Send` dispatches work to multiple agent nodes concurrently. Each agent appends its result to a shared `Annotated[List, operator.add]` field. A downstream aggregator node reads all results after all parallel agents complete.

```python
from langgraph.types import Send

class ParallelState(TypedDict):
    raw_logs: str
    reports:  Annotated[List[str], operator.add]   # all agents write here

def dispatch(state: ParallelState):
    return [
        Send("ilo_agent",     {"raw_logs": state["raw_logs"]}),
        Send("linux_agent",   {"raw_logs": state["raw_logs"]}),
        Send("network_agent", {"raw_logs": state["raw_logs"]}),
    ]

def ilo_agent(state: ParallelState) -> dict:
    return {"reports": [analyse_ilo(state["raw_logs"])]}    # appended to shared list

def aggregator(state: ParallelState) -> dict:
    combined = "\n\n---\n\n".join(state["reports"])         # reads all three
    return {"final_rca": produce_rca(combined)}

g.add_conditional_edges("dispatch_node", dispatch)
g.add_edge("ilo_agent",     "aggregator")
g.add_edge("linux_agent",   "aggregator")
g.add_edge("network_agent", "aggregator")
```

---

### 5. Message History as a Shared Conversation Record

All agent nodes share the same `messages` list. By appending `AIMessage` or `ToolMessage` objects to it, each node leaves a structured record that every subsequent node can read. This works naturally for conversational flows — each agent's contribution is part of a coherent running dialogue.

```python
def node_a(state: AgentState) -> dict:
    response = llm.invoke(state["messages"])
    return {"messages": [response]}          # AIMessage appended

def node_b(state: AgentState) -> dict:
    # state["messages"] now contains node_a's response as context
    response = llm.invoke(state["messages"] + [HumanMessage(content="Now summarise.")])
    return {"messages": [response]}
```

---

### Communication Patterns — Summary

| Pattern | How | When to use |
|---------|-----|-------------|
| Shared state fields | Node writes → next node reads | Sequential pipelines, simple handoff |
| Supervisor loop | Supervisor writes `next_agent`, edge routes to it, specialist returns | Dynamic orchestration, retry logic |
| Subgraphs | Compiled graph used as a node | Hierarchical decomposition, reusable sub-agents |
| `Send` fan-out | Parallel dispatch → `Annotated` accumulator | Independent parallel agents merging results |
| Messages list | Append `AIMessage`/`ToolMessage` | Conversational multi-agent flows |

---

## Key APIs

| API | Purpose |
|-----|---------|
| `StateGraph(State)` | Create a new graph |
| `g.add_node(name, fn)` | Register a node |
| `g.set_entry_point(name)` | Set the start node |
| `g.add_edge(a, b)` | Fixed edge from a → b |
| `g.add_conditional_edges(a, fn, map)` | Dynamic edge from a |
| `g.compile(checkpointer=..., interrupt_before=[...])` | Compile to runnable |
| `app.invoke(state, config=...)` | Run synchronously |
| `app.stream(state, config=...)` | Stream node outputs |
| `Send(node, state)` | Fan out to parallel nodes |

---

## When to Use LangGraph

- You need **explicit control flow** — you want to see and own every step
- Your workflow has **conditional branching or cycles** (retry loops, reflection)
- You need **human-in-the-loop** checkpoints before irreversible actions
- You need **parallel sub-tasks** that merge back into a single state
- You are building **long-running workflows** that must be resumable (checkpointing)
- You want **fine-grained observability** — every node's input/output is inspectable

---

## Installation

```bash
pip install langgraph langchain-aws langchain-core
```

For HITL / persistence:

```bash
pip install langgraph-checkpoint        # base checkpointer interface
# MemorySaver is built into langgraph
```

---

## Files in This Folder

| File | What it shows |
|------|--------------|
| `langgraph_weather_stock_router.py` | Router + conditional edges + tool-augmented nodes + Streamlit UI |
| `langgraph_datacenter_deployment.py` | Parallel sub-graph + reflection loop + HITL approval + post-HITL routing |
