import os
import requests

def test_connectivity(label):
    print(f"\n{'='*50}")
    print(f" {label}")
    print(f"{'='*50}")

    # Test 1: Basic connectivity
    print("\n1. Testing basic connectivity to huggingface.co ...")
    try:
        verify = os.environ.get("HF_HUB_DISABLE_SSL_VERIFICATION") != "1"
        response = requests.get("https://huggingface.co", timeout=10, verify=verify)
        print(f"   OK — status code: {response.status_code}")
    except Exception as e:
        print(f"   FAILED — {e}")

    # Test 2: huggingface_hub library version
    print("\n2. Testing huggingface_hub library ...")
    try:
        import huggingface_hub
        print(f"   OK — version: {huggingface_hub.__version__}")
    except ImportError as e:
        print(f"   FAILED — {e}")

    # Test 3: List files in GPT-2 repo (simulates what pipeline() does on first run)
    print("\n3. Testing access to GPT-2 model repo on Hugging Face ...")
    try:
        from huggingface_hub import list_repo_files
        files = list(list_repo_files("openai-community/gpt2"))
        print(f"   OK — files found: {files}")
    except Exception as e:
        print(f"   FAILED — {e}")


# --- Round 1: Without disabling SSL ---
test_connectivity("WITHOUT SSL verification disabled")

# --- Round 2: With SSL verification disabled ---
os.environ["HF_HUB_DISABLE_SSL_VERIFICATION"] = "1"
test_connectivity("WITH SSL verification disabled")

print("\n=== Test complete ===")
