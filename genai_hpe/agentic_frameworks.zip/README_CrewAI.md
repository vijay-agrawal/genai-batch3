# CrewAI — Multi-Agent Framework

## What is CrewAI?

CrewAI is a high-level Python framework for orchestrating **role-based multi-agent systems**. You define a crew of AI agents, each with a specialised persona (role, goal, backstory), assign them tasks, and CrewAI manages the entire execution loop — tool calls, inter-agent context hand-off, and final output assembly.

Where LangGraph gives you explicit control over every edge and node, CrewAI operates at a higher abstraction: you describe **who** the agents are and **what** they need to accomplish, and the framework drives the LLM reasoning loop internally.

---

## Core Concepts

### 1. Agent

An `Agent` is an autonomous AI persona. CrewAI builds a rich system prompt from its three defining attributes:

| Attribute | Purpose |
|-----------|---------|
| `role` | Job title — frames the LLM's domain expertise |
| `goal` | What this agent must accomplish in this crew |
| `backstory` | Experience narrative — shapes tone, depth, and heuristics |

```python
from crewai import Agent, LLM

llm = LLM(model="bedrock/amazon.nova-lite-v1:0", max_tokens=2500)

ilo_agent = Agent(
    role="HPE iLO Hardware Fault Analyst",
    goal=(
        "Analyse the HPE iLO 6 Integrated Management Log to identify ALL hardware-level "
        "fault events — thermal, power, storage controller, NIC — and establish a precise timeline."
    ),
    backstory=(
        "You are a Level-3 HPE ProLiant Hardware Specialist with 15 years of field experience. "
        "You know the iLO 6 IML inside-out and can decode every severity event, cross-reference "
        "HPE Customer Advisories, and understand how a Smart Array BBU fault cascades into the OS."
    ),
    tools=[fetch_ilo_event_log, lookup_hpe_advisory],
    llm=llm,
    verbose=True,
)
```

The three attributes combine into the LLM's system prompt. A strong backstory dramatically improves reasoning quality — it gives the LLM context to make expert-level inferences rather than generic observations.

---

### 2. Tool

A tool is a plain Python function decorated with `@tool`. CrewAI exposes it to the agent's LLM; the LLM decides when to call it, with what arguments, and how many times.

```python
from crewai.tools import tool

@tool("fetch_ilo_event_log")
def fetch_ilo_event_log(node_id: str = "proliant-node-01") -> str:
    """
    Fetches the HPE iLO 6 Integrated Management Log (IML) for a given server node.
    In production: calls GET /redfish/v1/Systems/{SystemId}/LogServices/IML/Entries
    node_id: the server node identifier, e.g. 'proliant-node-01'
    """
    return call_ilo_rest_api(node_id)
```

The docstring is critical — it becomes the tool's description in the LLM prompt. Write it like an API contract: what it does, what it returns, what the parameters mean.

Assign tools per agent via `tools=[...]`. An agent will only call the tools it has been given.

---

### 3. Task

A `Task` is a unit of work assigned to exactly one agent. It has:

| Attribute | Purpose |
|-----------|---------|
| `description` | The user-turn prompt — what to do and how |
| `expected_output` | Specifies the required format/content of the answer |
| `agent` | Which agent executes this task |
| `context` | List of prior tasks whose outputs are injected into this task's prompt |

```python
from crewai import Task

task_ilo_analysis = Task(
    description=(
        "Fetch and analyse the iLO 6 IML for node 'proliant-node-01'. "
        "Look up advisories for 'smart_array_p408' and 'ilo6_thermal'. "
        "Produce: (1) chronological timeline, (2) severity per component, "
        "(3) relevant advisories, (4) your root-cause hypothesis."
    ),
    expected_output=(
        "A structured iLO Hardware Fault Report with timestamped event timeline, "
        "component severity assessment, HPE advisory cross-references, "
        "and a clear hardware root-cause hypothesis."
    ),
    agent=ilo_hardware_agent,
)
```

---

### 4. Context — How Results Flow Between Tasks

The `context` parameter injects the **output text of prior tasks** directly into this task's prompt. This is the primary mechanism for chaining agent work.

```python
task_correlation = Task(
    description="Synthesise findings from all four specialist agents into a root cause analysis...",
    expected_output="A definitive RCA with unified timeline and cascade chain.",
    agent=correlation_agent,
    context=[task_ilo_analysis, task_os_analysis, task_network_analysis, task_storage_analysis],
    #        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    #        CrewAI concatenates all four outputs and prepends them to this task's description
)
```

Tasks without `context` start with a clean slate — they see only their own description and any tool results they fetch themselves. This means the four specialist tasks in the HPE demo run independently and produce unbiased reports.

---

### 5. Crew

The `Crew` wires agents and tasks together and starts execution.

```python
from crewai import Crew, Process

crew = Crew(
    agents=[ilo_agent, linux_agent, network_agent, storage_agent,
            correlation_agent, remediation_agent],
    tasks=[task_ilo, task_linux, task_network, task_storage,
           task_correlation, task_remediation],
    process=Process.sequential,
    verbose=True,
)

result = crew.kickoff()
print(result)
```

`crew.kickoff()` drives the full loop: for each task, CrewAI builds the LLM prompt, runs the agent's reasoning loop (tool calls, retries, reflection), collects the output, and moves to the next task.

---

## Execution Processes

### Sequential (default)

Tasks run one at a time in list order. Each can optionally read prior task outputs via `context=[...]`.

```python
process=Process.sequential
```

```
task_ilo ──► task_linux ──► task_network ──► task_storage ──► task_correlation ──► task_remediation
```

Use when tasks have a natural pipeline: later steps need earlier results.

---

### Hierarchical

A manager LLM is created (or you supply your own `manager_agent`). The manager decomposes the goal, delegates to specialist agents, reviews their outputs, and decides when the work is complete. Agents can be called multiple times or in any order.

```python
process=Process.hierarchical,
manager_llm=llm          # or manager_agent=my_manager_agent
```

Use when the order and depth of agent invocation should be decided dynamically rather than statically.

---

### Parallel Tasks (within sequential process)

Mark tasks with `async_execution=True` to run them concurrently. CrewAI schedules all async tasks simultaneously and waits for all to finish before executing any task that depends on them via `context=[...]`.

```python
task_ilo     = Task(..., async_execution=True, ...)
task_linux   = Task(..., async_execution=True, ...)
task_network = Task(..., async_execution=True, ...)
task_storage = Task(..., async_execution=True, ...)

task_correlation = Task(
    ...,
    context=[task_ilo, task_linux, task_network, task_storage],  # waits for all four
)
```

---

### Conditional Tasks

A `ConditionalTask` is skipped if a condition callable returns `False` on the prior task's output.

```python
from crewai import ConditionalTask

task_escalate = ConditionalTask(
    description="Escalate to on-call manager with P1 notification...",
    condition=lambda output: "CRITICAL" in output.raw,
    agent=remediation_agent,
)
```

This lets you build `if/else` branches in a pipeline without leaving the Crew.

---

### Router / Dynamic Delegation

A `RouterTask` lets one agent decide which task to execute next, enabling dynamic multi-branch flows.

---

## Building a CrewAI Flow — Step by Step

```
1. Define tools (@tool functions) with clear docstrings
2. Create Agents with role / goal / backstory + assign tools
3. Create Tasks with description / expected_output / agent
4. Wire tasks with context=[...] for data dependencies
5. Create Crew with agents, tasks, and process type
6. crew.kickoff() — done
```

---

## Complete Example: HPE Server Incident Triage

This is the `crewai_ilo_logs_triage.py` demo in this folder.

### Scenario

A production HPE ProLiant DL380 Gen11 cluster goes dark at 3 AM. Four log sources across four infrastructure layers must be analysed simultaneously, correlated into a root cause, and turned into an actionable runbook — in under 5 minutes.

### Agent Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  INDEPENDENT SPECIALIST ANALYSIS (tasks 1–4 have no context=[]) │
├──────────────────┬─────────────────┬──────────────────┬─────────┤
│ iLO Hardware     │ Linux OS SRE    │ Network Fabric   │ Storage │
│ Fault Analyst    │ (kernel/systemd)│ & RoCEv2 Eng.    │ & SAN   │
│                  │                 │                  │ Eng.    │
│ tools:           │ tools:          │ tools:           │ tools:  │
│ fetch_ilo_log    │ fetch_linux_log │ fetch_net_log    │ fetch_  │
│ lookup_advisory  │                 │ lookup_advisory  │ san_log │
└──────────────────┴─────────────────┴──────────────────┴─────────┘
                          │ context=[all four above]
                          ▼
              ┌───────────────────────────┐
              │ Correlation Engine Agent  │
              │ (cross-layer RCA)         │
              └───────────────────────────┘
                          │ context=[correlation task]
                          ▼
              ┌───────────────────────────┐
              │ Remediation Planner Agent │
              │ (3-phase HPE runbook)     │
              └───────────────────────────┘
```

### Root Cause Chain Uncovered

```
iLO THERMAL EVENT (CPU throttle -35%)
    → Smart Array P408i-a BBU fault → write-back cache DISABLED
        → I/O latency 45ms → 280ms
            → Linux hpsa driver lockup → EXT4 filesystem errors
                → Memory pressure → OOM kills (postgres, java)
                    → NFS unmount → NFS over RDMA path lost
                        → Application pods crash
                            → iLO ASR watchdog resets server
```

### Why CrewAI fits this scenario

- Each layer (iLO, OS, network, SAN) requires deep, different domain knowledge — separate agent personas prevent cross-contamination of reasoning
- The four specialist tasks run independently to produce unbiased reports, then a correlation agent synthesises them — this mirrors how a real incident response team works
- The backstory for each agent encodes actual diagnostic heuristics (e.g. "when you see 'hpsa controller lockup', it is almost always the Smart Array firmware or a BBU issue, not a kernel bug")

---

## Memory and State in CrewAI

CrewAI provides a layered, built-in memory system that mirrors how human teams retain and recall knowledge. Enable it with a single flag on the Crew; the framework manages all layers automatically. Each layer serves a different time horizon and use case.

### Short-Term Memory (Within a Single Task Execution)

Short-term memory is the agent's internal ReAct reasoning loop during one task run. It holds:
- The full sequence of tool calls and their results for the current task
- The agent's chain-of-thought reasoning steps
- Intermediate observations the LLM made before reaching a final answer

This is entirely internal to CrewAI — you never interact with it directly. It exists for the duration of one task execution and is discarded once the task's final answer is produced and passed downstream via `context=[...]`.

---

### Long-Term Memory (Cross-Run Persistence)

When `memory=True` is set on the Crew, CrewAI persists task outputs to a local SQLite database (backed by LangChain's storage layer). On subsequent runs, agents automatically retrieve relevant past results and inject them as additional context before reasoning begins.

```python
from crewai import Crew, Process

crew = Crew(
    agents=[ilo_hardware_agent, correlation_agent, remediation_agent],
    tasks=[task_ilo_analysis, task_correlation, task_remediation],
    process=Process.sequential,
    memory=True,     # enables short-term, long-term, and episodic layers
    verbose=True,
)

# First run — analyses the incident and stores findings
crew.kickoff()

# A week later — the agent recalls the BBU fault resolution from last week
# and uses it as context when analysing a similar alert on a different node
crew.kickoff(inputs={"node": "proliant-node-02"})
```

For production, replace the default SQLite store with a vector database:

```python
from crewai.memory import LongTermMemory
from crewai.memory.storage import RAGStorage

crew = Crew(
    agents=[...],
    tasks=[...],
    memory=True,
    long_term_memory=LongTermMemory(
        storage=RAGStorage(
            type="long_term",
            embedder_config={
                "provider": "aws_bedrock",
                "config": {"model": "amazon.titan-embed-text-v2:0"},
            },
        )
    ),
)
```

---

### Episodic Memory (What Happened in Past Runs)

Episodic memory stores **interactions as timestamped episodes** — each episode records what an agent did, which tools it called, what it concluded, and when. On future runs, semantically similar past episodes are retrieved and shown to the agent before it starts reasoning.

```python
from crewai.memory import EpisodicMemory
from crewai.memory.storage import RAGStorage

crew = Crew(
    agents=[ilo_hardware_agent, remediation_agent],
    tasks=[task_ilo_analysis, task_remediation],
    memory=True,
    episodic_memory=EpisodicMemory(
        storage=RAGStorage(
            type="short_term",
            embedder_config={
                "provider": "aws_bedrock",
                "config": {"model": "amazon.titan-embed-text-v2:0"},
            },
        )
    ),
)
```

When the remediation agent runs next week on a similar BBU fault, it can recall: *"Last time I saw this pattern, the fix was: update Smart Array FW to 7.26.00.0 and replace the BBU module (HPE part BB460A)."*

**What is actually happening here — and what isn't:**

This is **retrieval-augmented reasoning**, not learning in the machine-learning sense. No model weights are updated; the system cannot generalize beyond what it has explicitly stored. What happens under the hood is:

1. The past episode is embedded as a vector and stored.
2. At query time, **semantic similarity search** (cosine distance over embeddings) finds the closest past episode.
3. That retrieved text is injected into the LLM's context window before it starts reasoning.
4. The LLM then reasons *with* that retrieved context — which produces output that looks like "remembering."

What makes this more than a static knowledge base is that the store **grows dynamically** with every crew run — new incidents are added automatically. But if the embedding similarity doesn't match (semantic drift, new failure modes, poor chunking), the agent gets nothing; a truly learning system would generalize more robustly. The reasoning is in the LLM's forward pass, not in any memory update mechanism.

---

### Entity Memory (Persistent Knowledge Graph of Named Things)

Entity memory automatically extracts and stores **named entities** encountered during a run — server hostnames, component IDs, firmware versions, error codes, engineer names — and makes them available in future runs.

```python
from crewai.memory import EntityMemory

crew = Crew(
    agents=[...],
    tasks=[...],
    memory=True,
    entity_memory=EntityMemory(),   # auto-extracts entities from all agent outputs
)
```

After the first incident triage, the crew will have stored entities like:
- `proliant-node-01` → `type: server, status: degraded, last_incident: 2025-03-21`
- `Smart Array P408i-a` → `type: controller, firmware: 7.24.23.0, advisory: c08245132`

Future runs can query these stored entities rather than re-deriving them from raw logs.

---

### Custom External Memory via Shared Tools

For full control, give agents tools that read from and write to any external store (vector DB, relational DB, Redis). This separates memory implementation from CrewAI internals.

```python
from crewai.tools import tool
import chromadb

chroma = chromadb.Client()
collection = chroma.get_or_create_collection("hpe_incidents")

@tool("store_finding")
def store_finding(component: str, finding: str, severity: str) -> str:
    """Store a diagnostic finding in the shared incident knowledge base."""
    collection.add(documents=[finding], metadatas=[{"component": component, "severity": severity}],
                   ids=[f"{component}-{hash(finding)}"])
    return f"Stored finding for {component}."

@tool("recall_findings")
def recall_findings(query: str) -> str:
    """Recall past findings semantically similar to the query."""
    results = collection.query(query_texts=[query], n_results=3)
    return "\n".join(results["documents"][0])
```

---

### Memory Types — Summary

| Memory Type | API | Scope | What it stores |
|-------------|-----|-------|----------------|
| Short-term | Automatic (ReAct loop, no config needed) | One task execution | Tool calls, reasoning steps, observations |
| Long-term | `memory=True` | Cross-run, semantic retrieval | Task outputs, findings, conclusions |
| Episodic | `episodic_memory=EpisodicMemory()` | Cross-run, timestamped | What happened in each past crew run |
| Entity | `entity_memory=EntityMemory()` | Cross-run | Named things: servers, components, versions |
| Custom | `@tool` reading/writing external store | Any scope you design | Any structured or unstructured data |

---

## Inter-Agent Communication in CrewAI

CrewAI agents do not call each other's methods directly. Communication is mediated through the framework via five distinct mechanisms, ranging from static task wiring to dynamic event-driven flows.

### 1. Task Context Hand-Off (Primary Channel)

The `context=[prior_tasks]` parameter causes CrewAI to prepend the full text output of the listed tasks into the receiving agent's prompt under a "Observations from prior tasks" header. This is how the correlation agent in the HPE demo receives the four specialist reports.

```python
task_correlation = Task(
    description="Synthesise all four specialist reports into a root cause analysis.",
    expected_output="Unified RCA with timeline and cascade chain.",
    agent=correlation_agent,
    context=[task_ilo_analysis, task_os_analysis, task_network_analysis, task_storage_analysis],
    # CrewAI concatenates all four outputs and injects them before this task's description
)
```

The receiving agent can refer to specific timestamps, findings, and conclusions from any injected task. The separation — four independent specialist tasks first, then one synthesis task — mirrors how real incident response teams work: gather unbiased evidence before drawing conclusions.

---

### 2. Agent Delegation (`allow_delegation=True`)

An agent with `allow_delegation=True` can autonomously ask another agent in the crew to do work mid-task — outside the static task list. CrewAI invokes the delegated agent, returns its answer inline, and the originating agent continues reasoning with that new information.

```python
correlation_agent = Agent(
    role="Multi-Layer Correlation Analyst",
    goal="Synthesise all findings into a definitive root cause analysis.",
    backstory="...",
    allow_delegation=True,   # can ask specialist agents follow-up questions
    llm=llm,
)
```

Typical delegation: the correlation agent, mid-reasoning, realises it needs the exact SMART attribute reading for drive WDC-X731-004. It delegates to the storage agent: *"What is the reallocated sector count for drive WDC-X731-004?"* CrewAI invokes the storage agent, gets the answer, and returns it to the correlation agent's ReAct loop.

Use `allow_delegation=True` on agents that synthesise or coordinate. Leave it `False` (default) on pure specialist agents to prevent unintended re-routing.

---

### 3. Hierarchical Process (Manager → Worker Communication)

In `Process.hierarchical`, CrewAI creates a manager LLM that explicitly orchestrates all worker agents:
- Manager receives the overall goal and decomposes it into sub-tasks
- Manager assigns each sub-task to the most appropriate agent
- Worker returns its output; manager reviews and either accepts it or sends it back for revision
- Manager continues until it is satisfied, then produces the final output

```python
crew = Crew(
    agents=[ilo_agent, linux_agent, network_agent, storage_agent, remediation_agent],
    tasks=[master_triage_task],   # one high-level task; manager decomposes it
    process=Process.hierarchical,
    manager_llm=llm,              # or manager_agent=my_custom_manager_agent
    verbose=True,
)
```

The manager can call the same agent multiple times with different questions. It acts like a senior engineer directing a team during an incident — delegating, reviewing, asking for clarification, and integrating results.

---

### 4. Shared Tools as a Communication Bus

Multiple agents given the same tool backed by a shared store can read each other's writes without going through the task context chain. This is the right pattern when agent outputs are structured data that would be degraded by flattening into free text.

```python
from crewai.tools import tool
import json

_shared_db: dict = {}   # in production: a real database or Redis

@tool("write_finding")
def write_finding(component: str, finding: str) -> str:
    """Write a diagnostic finding to the shared incident database."""
    _shared_db[component] = finding
    return f"Finding recorded for {component}."

@tool("read_all_findings")
def read_all_findings(query: str = "") -> str:
    """Read all findings from the shared incident database."""
    return json.dumps(_shared_db, indent=2)

# ilo_agent writes structured findings; correlation_agent reads all of them
ilo_agent         = Agent(role="iLO Analyst",       tools=[fetch_ilo_log, write_finding], ...)
correlation_agent = Agent(role="Correlation Engine", tools=[read_all_findings], ...)
```

Structure is preserved across agent boundaries — the correlation agent receives the exact JSON the ilo_agent wrote, not a natural-language paraphrase of it.

---

### 5. CrewAI Flows (Event-Driven Inter-Crew Communication)

CrewAI Flows (v0.80+) add an event-driven layer above individual Crew runs. One Crew or function emits a result; another Crew listens and triggers when that result arrives. This composes multiple Crews into a pipeline where outputs drive subsequent actions.

```python
from crewai.flow.flow import Flow, listen, start

class IncidentResponseFlow(Flow):

    @start()
    def detect_anomaly(self):
        # triggered by a monitoring alert, webhook, or scheduled check
        return "Smart Array BBU fault detected on proliant-node-01"

    @listen(detect_anomaly)
    def run_triage(self, alert_description):
        triage_crew = Crew(
            agents=[ilo_agent, linux_agent, network_agent, storage_agent, correlation_agent],
            tasks=[task_ilo, task_linux, task_network, task_storage, task_correlation],
            process=Process.sequential, memory=True,
        )
        return triage_crew.kickoff(inputs={"alert": alert_description})

    @listen(run_triage)
    def generate_runbook(self, rca_report):
        runbook_crew = Crew(
            agents=[remediation_agent],
            tasks=[task_remediation],
        )
        return runbook_crew.kickoff(inputs={"rca": rca_report})

flow = IncidentResponseFlow()
flow.kickoff()
```

Flows are the right abstraction when you need to chain entire Crews (not just tasks) or when different parts of your pipeline have different agents, processes, or memory configurations.

---

### Communication Patterns — Summary

| Pattern | Mechanism | When to use |
|---------|-----------|-------------|
| Task context hand-off | `context=[prior_tasks]` | Sequential pipelines where later agents need earlier results |
| Agent delegation | `allow_delegation=True` | Dynamic follow-up questions mid-task, ad-hoc sub-tasking |
| Hierarchical process | Manager LLM assigns and reviews | Dynamic task decomposition, quality-gated workflows |
| Shared tools | Common `@tool` backed by shared store | Structured data exchange, bypassing text serialisation |
| CrewAI Flows | `@listen` / `@start` decorators | Multi-Crew pipelines, event-driven inter-crew triggers |

---

## Key APIs

| API | Purpose |
|-----|---------|
| `Agent(role, goal, backstory, tools, llm)` | Define a specialist agent |
| `@tool("name")` | Decorate a function as a callable tool |
| `Task(description, expected_output, agent, context=[])` | Define a unit of work |
| `Crew(agents, tasks, process, verbose)` | Wire everything together |
| `crew.kickoff()` | Start execution; returns final task output |
| `crew.kickoff_async()` | Async execution |
| `Process.sequential` | Tasks in list order |
| `Process.hierarchical` | Manager LLM orchestrates dynamically |
| `async_execution=True` | Run a task in parallel with other async tasks |
| `ConditionalTask(condition=fn)` | Skip task if condition returns False |

---

## LangGraph vs. CrewAI — When to Use Each

| Dimension | LangGraph | CrewAI |
|-----------|-----------|--------|
| Control level | Low-level (you define every edge) | High-level (framework manages the loop) |
| State management | Explicit TypedDict, you own it | Implicit, managed by CrewAI internals |
| Routing | Conditional edges, you write the logic | Sequential / hierarchical / router tasks |
| Human-in-the-loop | First-class (`interrupt_before`) | Via callbacks; less native |
| Parallel execution | `Send` fan-out, native | `async_execution=True` on tasks |
| Observability | Full step-by-step, every message visible | Verbose mode shows agent reasoning |
| Best for | Complex state machines, HITL, cycles | Role-based teams, pipeline triage, RCA |
| Learning curve | Higher (graph primitives) | Lower (describe agents, not edges) |

---

## Installation

```bash
pip install crewai crewai-tools
```

For AWS Bedrock:

```bash
pip install crewai boto3
```

Configure the LLM:

```python
from crewai import LLM

llm = LLM(
    model="bedrock/amazon.nova-lite-v1:0",
    max_tokens=2500,
    temperature=0.2,
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    aws_region_name=os.getenv("AWS_REGION", "us-east-1"),
)
```

---

## Files in This Folder

| File | What it shows |
|------|--------------|
| `crewai_ilo_logs_triage.py` | 6-agent sequential crew, @tool functions, context hand-off, parallel analysis pattern, process options |
| `agentic-ai-role-goal-backstory.md` | Guidance on writing effective role / goal / backstory attributes |
