"""
HPE Server Incident Triage — Multi-Agent Log Correlation System
================================================================
CrewAI demo tailored for HPE iLO / Firmware / Platform engineers.

Story: "The ProLiant Cluster Meltdown — 3 AM on a Friday"
  A production HPE ProLiant DL380 Gen11 cluster (4 nodes) in a dark-site
  data centre starts throwing alerts. Servers are rebooting, jobs are
  failing, storage paths are dropping — and no one knows why.

  Six specialised AI agents collaborate to triage logs from every layer
  of the stack simultaneously, correlate events across time, pinpoint the
  root cause, and produce an actionable remediation runbook — all before
  the on-call engineer's coffee gets cold.

Why this matters for HPE engineers:
  - iLO logs, OS logs, network logs, and SAN logs speak DIFFERENT languages
    and live in different systems. Manual correlation takes hours.
  - A single thermal event in iLO might explain kernel panics in Linux,
    which explain NFS timeouts, which explain application failures.
  - This demo shows how agentic AI can compress 4 hours of triage to < 5 minutes.

Agents:
  1. iLO Hardware Agent        — HPE iLO 6 event log / IML analysis
  2. Linux OS Agent            — kernel, systemd, OOM killer, dmesg analysis
  3. Network Fabric Agent      — NIC, switch, RDMA, PFC, ECN log analysis
  4. Storage / SAN Agent       — NVMe, SAS, multipath, Brocade SAN log analysis
  5. Correlation Engine Agent  — cross-layer timeline correlation & root cause
  6. Remediation Planner Agent — HPE-specific fix procedures & iLO recovery steps

CrewAI Concepts Demonstrated:
  - Role / Goal / Backstory persona engineering per agent
  - Custom @tool functions returning synthetic HPE log data
  - Sequential process with context hand-off between agents
  - Human-readable final remediation runbook
"""

import os
import sys
import json
import datetime
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
from crewai.tools import tool

# ── encoding fix (Windows) ──────────────────────────────────────────────────
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if sys.stderr.encoding and sys.stderr.encoding.lower() != "utf-8":
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

load_dotenv()

# ── LLM via AWS Bedrock ──────────────────────────────────────────────────────
llm = LLM(
    model=f"bedrock/{os.getenv('BEDROCK_MODEL_ID', 'us.anthropic.claude-3-7-sonnet-20250219-v1:0')}",
    max_tokens=2500,
    temperature=0.2,
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    aws_region_name=os.getenv("AWS_REGION", "us-east-1"),
)

# ═══════════════════════════════════════════════════════════════════════════════
# SYNTHETIC LOG DATA  —  Realistic HPE ProLiant / iLO 6 / Linux / SAN logs
#
# The scenario: A failing HPE Smart Array controller caused a storage I/O storm.
# The I/O storm triggered Linux OOM killer. OOM kills caused NFS unmounts.
# NFS unmounts caused application pods to crash. All of this was preceded
# by an iLO thermal event that throttled the CPU, slowing the controller.
# ═══════════════════════════════════════════════════════════════════════════════

ILO_EVENT_LOG = """
=== HPE iLO 6 Integrated Management Log (IML) — Node: proliant-node-01 ===
Severity  | Timestamp            | Event
----------|----------------------|--------------------------------------------------------
CAUTION   | 2025-03-21 02:47:11  | [Thermal] CPU1 inlet temperature exceeded threshold: 81C (warn: 75C, crit: 90C)
CAUTION   | 2025-03-21 02:47:18  | [Power]   CPU1 P-state forced to P2 (thermal throttle engaged). Performance -35%
INFO      | 2025-03-21 02:48:03  | [Storage] Smart Array P408i-a: controller I/O queue depth exceeded 80% (4096/5120)
CRITICAL  | 2025-03-21 02:49:55  | [Storage] Smart Array P408i-a: Cache battery backup unit (BBU) fault — write-back cache DISABLED
CRITICAL  | 2025-03-21 02:50:02  | [Storage] Smart Array P408i-a: Forced to write-through mode. I/O latency will increase significantly
WARNING   | 2025-03-21 02:51:44  | [NIC]     FlexibleLOM port 1 (Mellanox ConnectX-7): link degraded 100GbE -> 25GbE (auto-negotiation)
INFO      | 2025-03-21 02:52:30  | [System]  Server Health Status changed: OK -> Degraded
CRITICAL  | 2025-03-21 02:58:17  | [Storage] Smart Array P408i-a: Physical drive bay 4 SMART predictive failure alert (SN: WDC-X731-004)
WARNING   | 2025-03-21 03:01:05  | [Thermal] Fans speed increased: Zone A 40% -> 78% (auto thermal response)
INFO      | 2025-03-21 03:04:22  | [System]  Automatic Server Recovery (ASR) watchdog timer triggered on node proliant-node-01
CRITICAL  | 2025-03-21 03:04:25  | [System]  System reset initiated by iLO ASR watchdog (OS unresponsive > 300s)
"""

LINUX_OS_LOG = """
=== Linux Kernel + Systemd Log — Node: proliant-node-01 (kernel 6.8.0-hpe-2) ===
Timestamp            | Level   | Source               | Message
---------------------|---------|----------------------|----------------------------------------------------
2025-03-21 02:48:10  | WARN    | kernel               | hpsa 0000:05:00.0: controller lockup detected (storage busy timeout 30s)
2025-03-21 02:48:45  | WARN    | kernel               | hpsa 0000:05:00.0: reset attempt 1/3
2025-03-21 02:49:10  | ERROR   | kernel               | hpsa 0000:05:00.0: reset failed — I/O requests queued: 3847
2025-03-21 02:49:58  | ERROR   | kernel               | EXT4 error on /dev/sdb1: I/O error writing inode table — filesystem marked dirty
2025-03-21 02:50:30  | WARN    | kernel               | [  +0.3s] INFO: task kworker/u64:3:2041 blocked for 120s (D state, waiting for I/O)
2025-03-21 02:51:15  | WARN    | kernel               | Memory pressure: available 812MB / 256GB (swap: 0MB free)
2025-03-21 02:51:30  | CRIT    | kernel               | Out of memory: Kill process 14832 (postgres) score 847 or sacrifice child
2025-03-21 02:51:31  | CRIT    | kernel               | Killed process 14832 (postgres), UID 999, total-vm:42843648kB, anon-rss:36219904kB
2025-03-21 02:51:35  | CRIT    | kernel               | Killed process 14890 (java), UID 1001, total-vm:31457280kB, anon-rss:28311552kB
2025-03-21 02:52:05  | ERROR   | nfs                  | NFS: server storage-san-01 not responding (nfs4 mount /data/shared) — retrying
2025-03-21 02:53:55  | ERROR   | kernel               | nfs: server storage-san-01: not responding, timed out — unmounting /data/shared
2025-03-21 02:54:00  | CRIT    | systemd              | Unit data-shared.mount: Failed with result 'exit-code'
2025-03-21 02:54:01  | CRIT    | systemd              | Unit postgresql.service: Main process exited, code=killed, status=9/KILL
2025-03-21 02:54:02  | CRIT    | systemd              | Unit app-workload.service: dependency failed — failed to start
2025-03-21 02:58:15  | CRIT    | kernel               | BUG: soft lockup — CPU#12 stuck for 22s! [ksoftirqd/12:78]
2025-03-21 03:04:20  | CRIT    | kernel               | Watchdog: BUG: soft lockup — CPU#0 stuck for 300s — triggering system reset
"""

NETWORK_LOG = """
=== Network Fabric Log — Aruba CX 10000 ToR Switch + HPE FlexibleLOM ===
Timestamp            | Level   | Component              | Message
---------------------|---------|------------------------|--------------------------------------------------
2025-03-21 02:47:50  | INFO    | FlexFabric-mellanox-01 | Port Eth1/1/1 (proliant-node-01): speed changed 100G -> 25G
2025-03-21 02:47:55  | WARN    | aruba-cx-tor-01        | Port 1/1/1 link speed mismatch detected — disabling flow control
2025-03-21 02:51:20  | WARN    | aruba-cx-tor-01        | RoCEv2 PFC watchdog: Priority Flow Control stall detected on port 1/1/1 (queue 3 frozen 6.2s)
2025-03-21 02:51:25  | ERROR   | aruba-cx-tor-01        | ECN marking threshold exceeded port 1/1/1 — congestion notification sent to endpoint
2025-03-21 02:51:30  | WARN    | aruba-cx-tor-01        | RDMA traffic dropped 38,412 packets on port 1/1/1 (buffer overflow, last 10s)
2025-03-21 02:52:10  | WARN    | aruba-cx-tor-01        | iSCSI session DROP: proliant-node-01 -> storage-san-01:3260 (TCP RST after 30s timeout)
2025-03-21 02:52:15  | ERROR   | aruba-cx-tor-01        | NFS over RDMA (NFS/RDMA) path to storage-san-01 unreachable (3 consecutive ping failures)
2025-03-21 02:53:00  | ERROR   | aruba-cx-tor-01        | iSCSI multipath degraded: 2/4 paths DOWN for target storage-san-01:proliant-node-01
2025-03-21 03:04:20  | WARN    | aruba-cx-tor-01        | Port 1/1/1 (proliant-node-01) link DOWN — node reset detected
2025-03-21 03:05:55  | INFO    | aruba-cx-tor-01        | Port 1/1/1 link UP 100GbE after node reboot
"""

STORAGE_SAN_LOG = """
=== Storage / SAN Log — HPE Nimble AF40 + Brocade G720 FC Switch ===
Timestamp            | Level   | Component              | Message
---------------------|---------|------------------------|--------------------------------------------------
2025-03-21 02:47:00  | WARN    | hpe-nimble-af40-01     | Volume vol-proliant-cluster: I/O latency elevated (avg 45ms, threshold 20ms)
2025-03-21 02:48:15  | WARN    | hpe-nimble-af40-01     | Cache hit ratio dropped: 94.2% -> 71.3% (last 5 min) — NVMe wear levelling pause?
2025-03-21 02:48:50  | ERROR   | hpe-nimble-af40-01     | iSCSI initiator proliant-node-01 (IQN: iqn.2025-01.com.hpe:proliant-node-01): command timeout x8 in 30s
2025-03-21 02:49:00  | ERROR   | brocade-g720-fc-01     | FC fabric: PLOGI timeout — N_Port FD:32:A1 (proliant-node-01 HBA port 1) registration failed
2025-03-21 02:49:30  | CRIT    | hpe-nimble-af40-01     | Volume vol-proliant-cluster: write I/O queue depth > 90% (18432/20480). Throttling new I/O.
2025-03-21 02:50:05  | ERROR   | hpe-nimble-af40-01     | NFS export /data/shared: stale filehandle reported by 3 clients (proliant-node-01/02/03)
2025-03-21 02:50:30  | ERROR   | brocade-g720-fc-01     | Zoning conflict detected: proliant-node-01 HBA accessing zone outside defined SAN zone set
2025-03-21 02:52:00  | CRIT    | hpe-nimble-af40-01     | FATAL: Forced write-through mode for vol-proliant-cluster (initiator cache error). Latency: 280ms
2025-03-21 02:58:20  | WARN    | hpe-nimble-af40-01     | Disk health: Drive D07 (SN: WDC-X731-004) — reallocated sectors count increased +847 (SMART attr 5)
2025-03-21 03:04:30  | INFO    | hpe-nimble-af40-01     | iSCSI session from proliant-node-01 dropped (node reset). Pending I/Os flushed: 4,203
2025-03-21 03:06:00  | INFO    | hpe-nimble-af40-01     | iSCSI session from proliant-node-01 re-established after node reboot
"""


# ═══════════════════════════════════════════════════════════════════════════════
# CREWAI TOOLS  —  Simulate fetching logs from real HPE systems
# In production these would call iLO REST API, syslog server, SAN management API
# ═══════════════════════════════════════════════════════════════════════════════

@tool("fetch_ilo_event_log")
def fetch_ilo_event_log(node_id: str) -> str:
    """
    Fetches the HPE iLO 6 Integrated Management Log (IML) for a given server node.
    In production: calls GET /redfish/v1/Systems/{SystemId}/LogServices/IML/Entries
    Returns raw IML entries including thermal, power, storage, and NIC events.
    """
    return f"[iLO REST API] IML for node '{node_id}':\n{ILO_EVENT_LOG}"


@tool("fetch_linux_kernel_log")
def fetch_linux_kernel_log(node_id: str) -> str:
    """
    Fetches kernel + systemd journal logs from a Linux server node via syslog aggregator.
    In production: queries Elasticsearch / Splunk for host=<node_id> source=kernel,systemd
    Returns OOM events, block I/O errors, NFS errors, filesystem events.
    """
    return f"[Syslog Aggregator] Linux kernel/systemd log for node '{node_id}':\n{LINUX_OS_LOG}"


@tool("fetch_network_switch_log")
def fetch_network_switch_log(switch_id: str) -> str:
    """
    Fetches network switch and NIC logs from the Top-of-Rack switch and HPE FlexibleLOM.
    In production: queries Aruba Central API + SNMP trap receiver.
    Returns link-state changes, PFC stalls, RDMA drop events, iSCSI session drops.
    """
    return f"[Network Management] Switch/NIC log for '{switch_id}':\n{NETWORK_LOG}"


@tool("fetch_san_storage_log")
def fetch_san_storage_log(storage_id: str) -> str:
    """
    Fetches SAN and storage array logs from HPE Nimble and Brocade FC switch.
    In production: calls HPE InfoSight API + Brocade FOS REST API.
    Returns volume I/O metrics, iSCSI session events, disk health (SMART), FC zoning events.
    """
    return f"[Storage Management] SAN/Nimble log for '{storage_id}':\n{STORAGE_SAN_LOG}"


@tool("lookup_hpe_advisory")
def lookup_hpe_advisory(component: str) -> str:
    """
    Looks up HPE Security Advisories and Customer Advisories for a given component.
    In production: queries HPE PSIRT database / HPE Support Center API.
    Returns relevant advisories, firmware update recommendations, and known issues.
    """
    advisories = {
        "smart_array_p408": (
            "HPE Customer Advisory: c08245132\n"
            "Smart Array P408i-a Controller — BBU Capacitor Degradation\n"
            "Affected FW: < 7.24.23.0  |  Fix: Upgrade to FW 7.26.00.0\n"
            "Symptom: Random cache battery fault alerts after >3 years operation.\n"
            "Risk: Write-back cache disabled, severe I/O performance degradation.\n"
            "Action: Schedule controller firmware update. Replace BBU module if > 36 months old.\n"
            "HPE Parts: BB460A (Smart Array cache battery kit)"
        ),
        "ilo6_thermal": (
            "HPE Advisory: a00125843en\n"
            "iLO 6 — CPU Thermal Throttling During High Memory Bandwidth Workloads\n"
            "Affected iLO FW: < 1.52  |  Fix: iLO 6 FW 1.55 (improved thermal algorithm)\n"
            "Symptom: CPU throttles to P2/P3 at temperatures below BIOS critical threshold.\n"
            "Action: Update iLO firmware. Check heat-sink seating and thermal paste (>2 years)."
        ),
        "connectx7_100g": (
            "HPE Advisory: a00137661en\n"
            "Mellanox ConnectX-7 FlexibleLOM — 100GbE Auto-Negotiation Regression\n"
            "Affected FW: 28.37.x  |  Fix: FW 28.39.1002 + HPE SPP 2025.03\n"
            "Symptom: Port falls back to 25GbE under sustained high-bandwidth RDMA load.\n"
            "Action: Update NIC firmware via iLO SPP (Service Pack for ProLiant)."
        ),
    }
    for key, val in advisories.items():
        if key.lower() in component.lower():
            return val
    return f"No specific advisory found for '{component}'. Check https://support.hpe.com/hpesc/public/home"


# ═══════════════════════════════════════════════════════════════════════════════
# AGENTS  —  Each agent is a specialist with deep domain knowledge
# ═══════════════════════════════════════════════════════════════════════════════

ilo_hardware_agent = Agent(
    role="HPE iLO Hardware Fault Analyst",
    goal=(
        "Analyse the HPE iLO 6 Integrated Management Log to identify ALL hardware-level "
        "fault events — thermal, power, storage controller, NIC, and firmware — on the "
        "affected server node. Establish a precise hardware event timeline."
    ),
    backstory=(
        "You are a Level-3 HPE ProLiant Hardware Specialist with 15 years of field experience "
        "servicing Gen8 through Gen11 servers. You know the iLO 6 IML inside-out — you can "
        "decode every event severity, cross-reference it against HPE Customer Advisories, "
        "and understand exactly what 'Smart Array BBU fault' means for system stability. "
        "You have replaced hundreds of Smart Array controllers, BBU modules, and heat-sinks. "
        "You think in terms of hardware-software interaction: a thermal throttle at the iLO layer "
        "is never just a temperature number — it is a performance cliff that cascades into the OS."
    ),
    tools=[fetch_ilo_event_log, lookup_hpe_advisory],
    llm=llm,
    verbose=True,
)

linux_os_agent = Agent(
    role="Linux Kernel & Systems Reliability Engineer",
    goal=(
        "Analyse Linux kernel, systemd, and application-layer logs to identify OS-level failures: "
        "OOM kills, I/O wait storms, filesystem errors, NFS timeouts, and service crashes. "
        "Establish the OS event timeline and identify which kernel subsystems failed first."
    ),
    backstory=(
        "You are a Linux kernel engineer who spent 8 years at a hyperscaler maintaining "
        "ProLiant-based bare-metal fleets. You live in dmesg and journal logs. "
        "You know that when you see 'hpsa controller lockup' in the kernel log, it is "
        "almost always the Smart Array firmware or a BBU issue — not a kernel bug. "
        "You understand the OOM killer's scoring algorithm and can tell from the VSZ/RSS "
        "numbers which processes were leaking. You have deep familiarity with NFS over RDMA, "
        "iSCSI multipath failover, and how storage path failures cascade into application crashes."
    ),
    tools=[fetch_linux_kernel_log],
    llm=llm,
    verbose=True,
)

network_agent = Agent(
    role="HPE Network Fabric & RoCEv2 Engineer",
    goal=(
        "Analyse network switch, NIC, and RDMA fabric logs to identify network-layer failures: "
        "link degradation, PFC stalls, RDMA packet drops, iSCSI session drops, and multipath failures. "
        "Determine whether the network was a root cause or a victim of upstream failures."
    ),
    backstory=(
        "You are a data centre network architect specialising in HPE Aruba fabric and Mellanox/NVIDIA "
        "ConnectX NICs. You have designed and debugged dozens of RoCEv2 / RDMA networks for HPC "
        "and storage workloads. You know that a PFC (Priority Flow Control) stall on a lossless "
        "Ethernet fabric can freeze an entire storage path — and that this usually starts with "
        "a misconfigured ECN threshold or a NIC firmware bug under sustained load. "
        "You can distinguish a NIC auto-negotiation regression from a bad cable or a switch "
        "config error by reading the exact sequence of log events."
    ),
    tools=[fetch_network_switch_log, lookup_hpe_advisory],
    llm=llm,
    verbose=True,
)

storage_san_agent = Agent(
    role="HPE Storage & SAN Systems Engineer",
    goal=(
        "Analyse HPE Nimble array, iSCSI, NFS, and Brocade FC switch logs to identify storage-layer "
        "failures: I/O latency spikes, cache degradation, volume throttling, session drops, "
        "disk SMART failures, and FC zoning issues. Quantify the storage impact on the cluster."
    ),
    backstory=(
        "You are an HPE Nimble Storage and SAN specialist with 12 years of experience supporting "
        "enterprise storage in HPE Synergy and ProLiant environments. You can read InfoSight logs "
        "and immediately identify whether elevated latency is caused by a cache tier problem, "
        "a network bottleneck, or a failing disk. You know that Nimble's CASL architecture "
        "is sensitive to network jitter — a 25GbE degradation on the iSCSI path will immediately "
        "show up as cache miss ratio degradation and command timeouts. "
        "You have an instinct for SMART attribute progressions: when reallocated sector count "
        "jumps by 847 in minutes, that disk is in imminent failure mode."
    ),
    tools=[fetch_san_storage_log],
    llm=llm,
    verbose=True,
)

correlation_agent = Agent(
    role="Multi-Layer Incident Correlation Analyst",
    goal=(
        "Synthesise findings from iLO hardware, Linux OS, network, and storage agents into a "
        "single unified root-cause analysis. Build a cross-layer event timeline, identify the "
        "PRIMARY root cause, secondary causes, and cascading effects. Classify each event as "
        "root cause / contributing factor / downstream symptom."
    ),
    backstory=(
        "You are a Principal Site Reliability Engineer who has led major incident post-mortems "
        "at HPE's largest enterprise customers. You think in systems: you know that a root cause "
        "rarely lives in one layer. When a Smart Array BBU fails and disables write-back cache, "
        "the resulting I/O storm floods memory, triggers OOM, kills NFS mounts, and crashes apps — "
        "all within minutes. Your job is to see that chain clearly, reconstruct it from fragmented "
        "logs across four different systems, and present it so that a junior engineer can follow "
        "the causality without ambiguity. You never confuse correlation with causation: you always "
        "look for the timestamp ordering and the physical mechanism that links events."
    ),
    tools=[],
    llm=llm,
    verbose=True,
)

remediation_agent = Agent(
    role="HPE ProLiant Remediation & Recovery Specialist",
    goal=(
        "Produce a prioritised, step-by-step HPE remediation runbook for the identified root cause "
        "and all contributing issues. Include immediate recovery steps, medium-term fixes, and "
        "long-term preventive measures — all using HPE-specific tools, CLI commands, and iLO procedures."
    ),
    backstory=(
        "You are HPE's go-to remediation expert. You have authored dozens of HPE internal runbooks "
        "for Smart Array failures, iLO firmware recovery, NIC firmware rollbacks, and SAN path "
        "restoration. You know the exact iLO CLI commands to force a server reset, the HPE SPP "
        "(Service Pack for ProLiant) workflow for firmware updates, and how to use HPE OneView "
        "to orchestrate a rolling firmware update without downtime. "
        "Your runbooks are known for being executable under stress at 3 AM — clear, numbered, "
        "with expected outputs and rollback steps for everything."
    ),
    tools=[lookup_hpe_advisory],
    llm=llm,
    verbose=True,
)


# ═══════════════════════════════════════════════════════════════════════════════
# TASKS
# ═══════════════════════════════════════════════════════════════════════════════

task_ilo_analysis = Task(
    description=(
        "Fetch and analyse the iLO 6 Integrated Management Log for node 'proliant-node-01'. "
        "Look up any relevant HPE advisories for: 'smart_array_p408', 'ilo6_thermal', 'connectx7_100g'. "
        "Produce a structured hardware fault report with: "
        "(1) Chronological hardware event timeline with exact timestamps. "
        "(2) Severity classification for each event (INFO / WARNING / CRITICAL / FATAL). "
        "(3) Specific hardware components implicated (controller, BBU, NIC, thermal). "
        "(4) Relevant HPE advisories and firmware gaps. "
        "(5) Your assessment of which hardware fault most likely triggered the incident."
    ),
    expected_output=(
        "A structured iLO Hardware Fault Report with timestamped event timeline, "
        "component-level severity assessment, HPE advisory cross-references, "
        "and a clear hardware root-cause hypothesis."
    ),
    agent=ilo_hardware_agent,
)

task_os_analysis = Task(
    description=(
        "Fetch and analyse the Linux kernel + systemd logs for node 'proliant-node-01'. "
        "Produce a structured OS failure report with: "
        "(1) Kernel event timeline (timestamps, subsystems, error codes). "
        "(2) I/O subsystem analysis: hpsa driver errors, block I/O wait, EXT4 filesystem events. "
        "(3) Memory pressure analysis: OOM killer events (which processes killed, why, RSS sizes). "
        "(4) Service-level impact: which systemd units failed and why. "
        "(5) NFS and storage path failures from the OS perspective. "
        "(6) Whether the OS failures appear to be caused by a hardware/storage problem upstream."
    ),
    expected_output=(
        "A structured Linux OS Failure Report with kernel timeline, I/O analysis, "
        "OOM kill details, service failure chain, and a verdict on whether the OS "
        "was a root cause or a downstream victim."
    ),
    agent=linux_os_agent,
)

task_network_analysis = Task(
    description=(
        "Fetch and analyse network logs for 'aruba-cx-tor-01' (Top-of-Rack switch + HPE FlexibleLOM). "
        "Look up advisories for 'connectx7_100g'. "
        "Produce a structured network fault report with: "
        "(1) Network event timeline (link events, speed changes, drops). "
        "(2) RoCEv2 / RDMA analysis: PFC stalls, ECN events, packet drop counts and impact. "
        "(3) iSCSI path analysis: which sessions dropped, when, and in what order. "
        "(4) Multipath degradation: how many paths remained available during the incident. "
        "(5) Whether the 100GbE -> 25GbE link degradation was a cause or effect of the incident. "
        "(6) NIC firmware advisory relevance."
    ),
    expected_output=(
        "A structured Network Fabric Fault Report with timeline, RDMA/PFC analysis, "
        "iSCSI session analysis, multipath impact assessment, and verdict on "
        "network as cause vs. victim."
    ),
    agent=network_agent,
)

task_storage_analysis = Task(
    description=(
        "Fetch and analyse storage/SAN logs for 'hpe-nimble-af40-01' (Nimble array + Brocade FC). "
        "Produce a structured storage fault report with: "
        "(1) Storage event timeline (latency, cache hit ratio, queue depth, SMART events). "
        "(2) iSCSI session analysis: timeout pattern, which initiators affected, sequence of failures. "
        "(3) NFS export analysis: stale filehandle events, affected clients. "
        "(4) Disk health: SMART attribute analysis for drive WDC-X731-004 (bay 4). "
        "(5) Nimble cache analysis: write-through forced mode — impact on I/O latency. "
        "(6) FC fabric events: PLOGI failures and zoning issues and their significance. "
        "(7) Correlation with iLO Smart Array BBU fault (if visible in storage logs)."
    ),
    expected_output=(
        "A structured Storage & SAN Fault Report with I/O timeline, cache analysis, "
        "disk health assessment, session failure sequence, and verdict on storage "
        "as root cause contributor."
    ),
    agent=storage_san_agent,
)

task_correlation = Task(
    description=(
        "You have received four specialist reports from the iLO hardware agent, Linux OS agent, "
        "network fabric agent, and storage/SAN agent. "
        "Synthesise all findings into a definitive Root Cause Analysis (RCA) document: "
        "\n"
        "(1) UNIFIED TIMELINE: Merge all four agent timelines into a single chronological "
        "cross-layer event sequence (use the actual timestamps from the logs). "
        "Mark each event's layer: [iLO] [OS] [NET] [SAN]. "
        "\n"
        "(2) ROOT CAUSE IDENTIFICATION: Identify the single primary root cause — "
        "the first failure that, if prevented, would have stopped the entire cascade. "
        "Explain the physical/logical mechanism that links it to all subsequent failures. "
        "\n"
        "(3) CASCADE CHAIN: Draw the cause-effect chain: "
        "Root Cause -> Contributing Factors -> Cascading Symptoms -> Business Impact. "
        "\n"
        "(4) EVENT CLASSIFICATION TABLE: For every significant event in the unified timeline, "
        "classify it as: ROOT CAUSE / CONTRIBUTING FACTOR / CASCADING SYMPTOM / COLLATERAL. "
        "\n"
        "(5) IMPACT SUMMARY: State the total system downtime, services affected, data at risk, "
        "and whether data loss occurred or was prevented."
    ),
    expected_output=(
        "A definitive Root Cause Analysis document with unified cross-layer timeline, "
        "primary root cause identification with mechanism explanation, "
        "cascade chain, event classification table, and impact summary."
    ),
    agent=correlation_agent,
    context=[task_ilo_analysis, task_os_analysis, task_network_analysis, task_storage_analysis],
)

task_remediation = Task(
    description=(
        "Based on the Root Cause Analysis, produce a complete HPE Remediation Runbook "
        "with three phases: "
        "\n"
        "PHASE 1 — IMMEDIATE RECOVERY (next 30 minutes): "
        "Steps to restore the server and services right now. "
        "Include exact iLO CLI / Redfish API commands, Linux commands, and expected outputs. "
        "Include iLO-based server health check commands (using iLO REST / hpssacli / ssacli). "
        "\n"
        "PHASE 2 — ROOT CAUSE FIX (next 48 hours): "
        "Permanent fix for each identified root cause and contributing factor. "
        "Reference HPE advisories, firmware update procedures (HPE SPP workflow), "
        "Smart Array controller replacement steps, BBU module replacement, NIC FW update. "
        "\n"
        "PHASE 3 — PREVENTION & MONITORING (next 2 weeks): "
        "Changes to prevent recurrence: iLO alerting thresholds, HPE InfoSight proactive health, "
        "SMART monitoring cron job, NFS/iSCSI multipath validation checklist, "
        "HPE OneView firmware compliance policy. "
        "\n"
        "For each step: specify the tool/interface, exact command or procedure, "
        "expected output, and rollback procedure if the step fails."
    ),
    expected_output=(
        "A three-phase HPE Remediation Runbook: Immediate Recovery, Root Cause Fix, "
        "and Prevention & Monitoring — with exact HPE CLI commands, Redfish API calls, "
        "advisory references, and rollback procedures."
    ),
    agent=remediation_agent,
    context=[task_correlation],
)


# ═══════════════════════════════════════════════════════════════════════════════
# CREW
# ═══════════════════════════════════════════════════════════════════════════════

incident_crew = Crew(
    agents=[
        ilo_hardware_agent,
        linux_os_agent,
        network_agent,
        storage_san_agent,
        correlation_agent,
        remediation_agent,
    ],
    tasks=[
        task_ilo_analysis,
        task_os_analysis,
        task_network_analysis,
        task_storage_analysis,
        task_correlation,
        task_remediation,
    ],
    process=Process.sequential,
    verbose=True,
)


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    sep = "=" * 78
    print(f"\n{sep}")
    print("  HPE SERVER INCIDENT TRIAGE — MULTI-AGENT LOG CORRELATION SYSTEM")
    print("  CrewAI  |  Amazon Bedrock  |  6 Specialist Agents  |  4 Log Sources")
    print(sep)
    print("""
  Story: "The ProLiant Cluster Meltdown — 3 AM on a Friday"

  A production HPE ProLiant DL380 Gen11 cluster has gone dark.
  Servers are rebooting, Postgres is dead, shared NFS mounts are gone,
  and 4,203 I/O operations were in-flight when the node reset.

  Six AI agents will simultaneously analyse:
    - HPE iLO 6 Integrated Management Log (thermal, storage, NIC events)
    - Linux kernel + systemd journal (OOM kills, I/O errors, service failures)
    - Aruba ToR switch + Mellanox ConnectX-7 (RDMA, iSCSI, link events)
    - HPE Nimble AF40 + Brocade FC switch (latency, cache, disk, sessions)

  Then correlate all findings into a definitive Root Cause Analysis
  and produce a 3-phase HPE Remediation Runbook.

  Agents:
    1. iLO Hardware Fault Analyst          [iLO IML + HPE Advisory lookup]
    2. Linux Kernel & SRE                  [kernel/systemd logs]
    3. Network Fabric & RoCEv2 Engineer    [switch/NIC logs + advisory]
    4. HPE Storage & SAN Engineer          [Nimble/FC logs]
    5. Multi-Layer Correlation Analyst     [cross-layer RCA synthesis]
    6. Remediation & Recovery Specialist   [HPE runbook generation]
""")
    print(f"{sep}\n")

    result = incident_crew.kickoff()

    print(f"\n{sep}")
    print("  FINAL OUTPUT — COMPLETE INCIDENT TRIAGE REPORT")
    print(sep)
    print(result)
    print(f"\n{sep}")
    print("  Incident triage complete.")
    print(f"  Timestamp: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(sep + "\n")


if __name__ == "__main__":
    main()
