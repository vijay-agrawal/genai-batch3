# Role, Goal & Backstory in Agentic AI Frameworks
### A Study Guide — Multi-Agent Systems & CrewAI
### HPE Use Case: Distributed Log Troubleshooting

---

## 1. Introduction

In multi-agent AI frameworks like **CrewAI**, **AutoGen**, and **LangGraph**, every AI agent is defined by three foundational attributes that shape how the underlying Large Language Model (LLM) reasons, communicates, and makes decisions:

| Attribute | Core Question | Analogy |
|-----------|--------------|---------|
| **Role** | *Who are you?* | Job title |
| **Goal** | *What are you optimising for?* | KPI / objective |
| **Backstory** | *How do you think, and what do you value?* | Resume + character |

These three elements work together to **prime the LLM's context window** — steering tone, reasoning style, domain focus, and risk tolerance without needing to hardcode any logic.

> **Key Insight (HPE Context):** LLMs are generalists. Without grounding, an agent asked to "analyse server logs" might give vague, surface-level output. But when you give it a Role (HPE ProLiant Systems Reliability Engineer), a Goal (correlate hardware fault events across an iLO cluster within a 30-minute blast radius), and a Backstory (experienced with iLO RIBCL event logs, HPE Smart Array controller errors, and ProLiant POST fault codes), the model activates a much richer, domain-specific reasoning pattern.

---

## 2. How the Framework Technically Leverages These Attributes

### 2.1 They Become the System Prompt

When you define an agent in CrewAI, the framework **automatically compiles** your `role`, `goal`, and `backstory` into a **structured system prompt** that is injected at the top of every LLM call made by that agent. You write Python — the framework translates it into prompt instructions.

Here is what that compiled prompt looks like under the hood:

```
You are {role}.
Your personal goal is: {goal}
Some context about your background: {backstory}
Your personal goal is to complete your task to the absolute best of your abilities.
You ONLY have access to the following tools and should NEVER make up tools that are not listed here:
...
```

### 2.2 The Internal Prompt Structure (XML/Structured Format)

CrewAI structures the full agent context using a layered prompt, which conceptually looks like this:

```xml
<agent_context>

  <identity>
    <role>HPE Infrastructure Log Analyst</role>
    <goal>
      Ingest syslog streams from HPE ProLiant servers, Aruba switches, and
      Nimble storage arrays; correlate error patterns across components;
      and surface the root-cause event with a confidence score and
      remediation recommendation within 5 minutes of alert firing.
    </goal>
    <backstory>
      You are a senior SRE at HPE with deep expertise in iLO event logs,
      HPE Smart Array controller fault codes, Aruba CX switch syslog
      formats, and Nimble OS alert taxonomy. You have triaged hundreds of
      cascading failure incidents and know that a single bad NIC firmware
      version can trigger alerts in storage, switching, and OS layers
      simultaneously. You always check timestamps first, then correlate
      across layers before attributing blame.
    </backstory>
  </identity>

  <task>
    <description>
      The following log bundle spans the last 30 minutes across 4 ProLiant
      servers, 2 Aruba CX 6300 switches, and 1 Nimble AF40 array.
      Identify the root cause of the storage latency spike at 14:23 UTC.
    </description>
    <expected_output>
      A ranked list of candidate root causes with supporting log evidence,
      affected components, blast-radius assessment, and recommended fix.
    </expected_output>
  </task>

  <tools>
    <tool name="iLO_event_log_fetcher" />
    <tool name="aruba_syslog_parser" />
    <tool name="nimble_alert_query" />
    <tool name="log_timeline_correlator" />
  </tools>

  <conversation_history>
    <!-- Prior agent outputs, task context, memory -->
  </conversation_history>

</agent_context>
```

In practice, CrewAI serialises this as a structured string (not literal XML), but the **logical hierarchy is exactly this** — identity first, then task, then tools, then history.

### 2.3 Equivalent JSON Representation

When working with the raw Anthropic / OpenAI API directly (without a framework), developers often pass agent configuration as a JSON object used to build the system prompt:

```json
{
  "agent": {
    "role": "HPE ProLiant Systems Reliability Engineer",
    "goal": "Correlate hardware fault events across iLO, Smart Array, and OS-level logs to identify cascading failure root causes before they impact SLAs",
    "backstory": "You are an SRE specialising in HPE Gen10/Gen11 ProLiant hardware. You are fluent in iLO RIBCL XML event formats, IML (Integrated Management Log) codes, Smart Array controller error taxonomy, and HPE Agentless Management Service (AMS) telemetry. You have resolved over 200 P1 incidents involving memory DIMMs, NIC failures, and storage path degradation. You never attribute an alert to a component without cross-referencing at least two independent log sources.",
    "tools": ["iLO_log_fetcher", "smart_array_diagnostics", "os_event_log_parser"],
    "llm": "claude-sonnet-4-6",
    "verbose": true,
    "allow_delegation": false
  }
}
```

This JSON is then **interpolated into a prompt template** at runtime, so the LLM receives a fully-formed system prompt — not a raw JSON object. The agent never "sees" JSON; it sees the rendered natural language prompt that JSON produces.

### 2.4 The Python API (CrewAI)

```python
from crewai import Agent, Task, Crew

hardware_log_analyst = Agent(
    role="HPE ProLiant Systems Reliability Engineer",
    goal="""Correlate hardware fault events across iLO, Smart Array, and
            OS-level logs to identify cascading failure root causes before
            they breach the 15-minute SLA response window""",
    backstory="""You are a senior SRE specialising in HPE Gen10/Gen11 ProLiant
                 hardware. You are fluent in iLO RIBCL XML event formats,
                 IML (Integrated Management Log) fault codes, HPE Smart Array
                 controller error taxonomy, and Agentless Management Service
                 telemetry. You have resolved over 200 P1 incidents involving
                 memory DIMM failures, NIC link degradation, and storage path
                 loss. You always cross-reference at least two independent log
                 sources before attributing blame to any single component.""",
    tools=[ilo_log_fetcher_tool, smart_array_tool, os_event_log_tool],
    llm="claude-sonnet-4-6",
    verbose=True
)
```

### 2.5 What Each Attribute Controls at Inference Time

```
┌──────────────────────────────────────────────────────────────────┐
│                     LLM SYSTEM PROMPT                            │
├──────────────────┬───────────────────────────────────────────────┤
│  ROLE            │ Sets vocabulary, domain expertise, authority  │
│                  │ level, and communication register             │
├──────────────────┼───────────────────────────────────────────────┤
│  GOAL            │ Defines the objective function — what the     │
│                  │ model is optimising its output toward         │
├──────────────────┼───────────────────────────────────────────────┤
│  BACKSTORY       │ Shapes reasoning style, risk tolerance,       │
│                  │ personality, heuristics, and edge-case        │
│                  │ handling (e.g. "always cross-reference two    │
│                  │ log sources before attributing a fault")      │
└──────────────────┴───────────────────────────────────────────────┘
```

---

## 3. HPE Scenario: AI-Assisted Log Triage Across a Data Centre Cluster

Imagine an HPE GreenLake environment experiencing intermittent storage latency spikes affecting 12 ProLiant servers. A CrewAI-powered pipeline automatically ingests logs from iLO, the OS layer, Aruba CX switches, and Nimble storage — with four specialised agents collaborating to root-cause the incident.

---

### Agent 1 — The Hardware Event Analyst

```python
Agent(
    role="HPE iLO & IML Hardware Event Analyst",
    goal="""Parse iLO event logs and Integrated Management Logs (IML)
            across all servers in the blast radius, extract fault codes,
            and produce a timestamped hardware event timeline""",
    backstory="""You are an HPE Certified Systems Engineer with 10 years
                 of experience reading iLO RIBCL XML dumps and IML fault
                 entries. You know that IML codes 1719 (storage degraded)
                 and 2007 (NIC link failure) are frequent precursors to
                 cascading outages. You always sort events by severity and
                 timestamp before drawing any conclusions, and you flag
                 any DIMM correctable error rate above 10 per hour as a
                 critical escalation signal."""
)
```

**What this unlocks:**
The agent fluently interprets HPE-specific IML codes, sorts by event timestamp, and flags known HPE precursor patterns — not generic log keywords.

**How the framework leverages it:**
The `role` primes HPE hardware vocabulary (iLO, IML, RIBCL). The `goal` anchors output to a *timestamped timeline* rather than a prose summary. The `backstory`'s specific fault codes (1719, 2007) inject pattern-matching knowledge that a generic prompt would miss entirely.

---

### Agent 2 — The Network Fabric Analyst

```python
Agent(
    role="Aruba CX Network Fabric Analyst",
    goal="""Correlate Aruba CX switch syslog events with server NIC
            events to determine whether the storage latency is caused by
            fabric congestion, spanning-tree recalculation, or physical
            link errors on uplinks to the Nimble array""",
    backstory="""You are a network engineer with deep expertise in Aruba
                 CX 6300 and 8360 switch syslog formats. You know that
                 a rapid sequence of LACP PDU timeout messages followed
                 by a spanning-tree topology change (TCN) is the classic
                 signature of a flapping uplink causing storage traffic
                 interruptions. You correlate MAC address tables and
                 interface error counters before concluding fabric health
                 is clean."""
)
```

**What this unlocks:**
The agent looks for Aruba-specific syslog patterns (LACP, STP TCN events) and ties fabric events back to the storage latency window — not generic network troubleshooting.

**How the framework leverages it:**
The `backstory` injects a specific Aruba failure signature (LACP timeout → STP TCN → storage disruption) that teaches the model a concrete, testable hypothesis to either confirm or rule out. The `goal` keeps the agent focused on the storage-latency question rather than drifting into general network health.

---

### Agent 3 — The Storage Platform Analyst

```python
Agent(
    role="HPE Nimble Storage Platform Analyst",
    goal="""Query Nimble OS alert history and volume performance metrics
            to determine whether the latency spike originates from the
            storage array itself (e.g. cache miss storm, failed drive
            rebuild) or from upstream fabric/host issues""",
    backstory="""You are a storage engineer specialising in HPE Nimble
                 AF-series and HF-series arrays. You are fluent in Nimble
                 OS alert codes, CASL architecture behaviour, and the
                 telemetry exposed via the Nimble API. You know that a
                 cache miss rate above 5% on an AF array during a rebuild
                 is a reliable indicator of array-side latency, and that
                 host-side latency without corresponding array-side alerts
                 almost always points to fabric or initiator issues. You
                 always check the array's dedupe/compression queue depth
                 before clearing storage as the root cause."""
)
```

**What this unlocks:**
The agent applies Nimble-specific thresholds (cache miss %, rebuild behaviour) and uses the absence of array-side alerts as a meaningful signal — a nuance that generic log analysis misses.

**How the framework leverages it:**
This is where `backstory` does something powerful: it encodes a **decision heuristic**. "Host-side latency without array-side alerts almost always points to fabric" gives the model an inference rule that prevents it from false-attributing the issue to storage when the real cause is network.

---

### Agent 4 — The Incident Report Synthesiser

```python
Agent(
    role="HPE Site Reliability Incident Commander",
    goal="""Synthesise findings from hardware, network, and storage
            analysts into a structured P1 incident report that on-call
            engineers can act on immediately, including root cause,
            blast radius, remediation steps, and preventive actions""",
    backstory="""You are an SRE lead at HPE with 8 years of experience
                 writing post-incident reports for GreenLake managed
                 services customers. You write for an audience of
                 on-call engineers under pressure — clear, concise,
                 no jargon without definition, action items numbered
                 and owner-tagged. You always include a 'Contributing
                 Factors' section that distinguishes root cause from
                 triggers and from pre-existing risk conditions, because
                 this distinction is what drives durable prevention."""
)
```

**What this unlocks:**
This agent translates raw technical findings into a structured incident report optimised for fast human action — not just a text dump of log analysis.

**How the framework leverages it:**
The same LLM powers all four agents. The *only difference* is the system prompt compiled from role/goal/backstory. The Incident Commander's `backstory` produces structured, actionable reports while the Hardware Analyst's produces technical timelines — genuinely different outputs from the same model.

---

## 4. How the Agents Work Together (The Crew)

```
Storage latency alert fires (14:23 UTC)
              │
              ▼
┌─────────────────────────────────┐
│  Hardware Event Analyst         │  → IML fault timeline + severity ranking
│  (iLO / IML logs, all servers)  │
└─────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────┐
│  Network Fabric Analyst         │  → Fabric event correlation + link health
│  (Aruba CX syslogs)             │
└─────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────┐
│  Storage Platform Analyst       │  → Array-side vs. fabric-side verdict
│  (Nimble OS alerts + metrics)   │
└─────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────┐
│  Incident Report Synthesiser    │  → Structured P1 report with actions
│  (SRE lead persona)             │
└─────────────────────────────────┘
```

Each agent receives the prior agent's output as context, but interprets and acts on it through **its own role/goal/backstory lens** — creating a genuine division of cognitive labour. The framework passes prior outputs as `conversation_history` in each subsequent agent's prompt context.

---

## 5. Summary Comparison Table

| Attribute | Hardware Analyst | Network Analyst | Storage Analyst | Incident Synthesiser |
|-----------|-----------------|-----------------|-----------------|----------------------|
| **Role effect** | HPE IML fault code vocabulary | Aruba CX syslog syntax | Nimble OS alert taxonomy | SRE incident report structure |
| **Goal effect** | Timestamped hardware event timeline | Fabric congestion verdict | Array-side vs. host-side attribution | Actionable P1 report |
| **Backstory effect** | IML code pattern recognition, DIMM thresholds | LACP/STP TCN failure signature | Cache miss thresholds, rebuild behaviour | Root cause vs. trigger distinction |
| **Risk orientation** | Flag hardware precursors early | Rule out fabric before escalating | Clear storage only with array evidence | Concise, owner-tagged actions |

---

## 6. Key Takeaways for HPE Engineers

1. **Role, Goal, and Backstory are compiled into the system prompt** — they are not stored separately; they become natural language instructions the LLM reads before every response.

2. **The same LLM can act as a hardware SRE, network engineer, or storage analyst** based solely on these three attributes — no fine-tuning or separate models required.

3. **Backstory is the most powerful lever for ops workflows** — it encodes HPE-specific fault code patterns, decision heuristics (e.g. "cross-reference two sources"), and risk thresholds that generic prompts miss entirely.

4. **In multi-agent pipelines**, each agent's specialist identity persists across all tasks because the system prompt is rebuilt from the same role/goal/backstory on every API call — no drift between turns.

5. **For distributed log troubleshooting**, this pattern mirrors how real SRE teams divide responsibility across hardware, network, and storage domains — but executes in minutes rather than hours, and leaves a structured audit trail.

---

## 7. HPE-Relevant Tool Integrations

Agents in this pipeline would typically be given access to tools such as:

| Tool | Purpose |
|------|---------|
| `iLO_REST_client` | Fetch IML and iLO event logs via Redfish API |
| `aruba_syslog_query` | Query Aruba Central or local syslog servers |
| `nimble_api_client` | Pull volume latency metrics and array alerts via Nimble REST API |
| `log_timeline_correlator` | Merge multi-source logs onto a unified UTC timeline |
| `jira_incident_creator` | Auto-create P1 Jira tickets with synthesised report |
| `greenlake_telemetry_api` | Access HPE GreenLake Observability metrics |

---

## 8. Further Reading

- [HPE iLO RESTful API Documentation](https://developer.hpe.com/platform/ilo-restful-api/home/)
- [HPE Nimble Storage REST API Guide](https://infosight.hpe.com)
- [Aruba CX Python SDK](https://developer.arubanetworks.com)
- [CrewAI Documentation](https://docs.crewai.com)
- [Anthropic — Building with Claude Agents](https://docs.anthropic.com)

---

*Document prepared for HPE Engineering — Generative AI & Agentic Systems 5-Day Intensive*
