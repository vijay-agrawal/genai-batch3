"""
HPE Enterprise Datacenter Deployment Planner — Agentic AI with Human Approval
==============================================================================
LangGraph demo tailored for HPE iLO / Firmware / Platform engineers.

Story: "Project Valhalla — Dark-Site HPC Cluster Deployment"
  HPE Professional Services must deploy a new air-gapped HPC cluster at a
  government facility:
    - 4 x HPE ProLiant DL380 Gen11 compute nodes
    - 2 x HPE Alletra 9060 all-flash storage nodes
    - 1 x HPE Aruba 8360 core switch + 2 x Aruba CX 10000 ToR switches
    - HPE iLO 6 management network (isolated VLAN)
    - HPE OneView 9.0 management appliance (air-gapped, no internet)
    - Target: SLURM cluster with NFS-over-RDMA shared storage

  An AI deployment planning system must:
    1. Analyse the site spec and draft a deployment plan
    2. Validate network topology and VLAN design
    3. Validate storage layout and NVMe/NFS configuration
    4. Validate iLO firmware versions and management connectivity
    5. Assess risks (single points of failure, firmware gaps, air-gap constraints)
    6. PAUSE for human engineer review and approval     ← Human-in-the-Loop
    7. Generate the final deployment runbook (only after human approves)

Why Human-in-the-Loop matters here:
  Dark-site / air-gapped deployments cannot be rolled back easily.
  Firmware updates require physical media (USB/SPP ISO). Network
  misconfiguration locks out iLO access permanently. A human must
  approve before any action is irreversible.

LangGraph Concepts Demonstrated:
  - Typed state machine with append-only audit trail
  - Parallel agent sub-graph (network + storage + iLO validate simultaneously)
  - Reflection loop on the deployment plan (self-critique before HITL)
  - interrupt_before() for mandatory human approval checkpoint
  - Conditional routing based on human decision (approve / revise / reject)
  - Runbook generation only after explicit approval
"""

import os
import operator
from typing import TypedDict, Annotated, List, Literal

from dotenv import load_dotenv
from langchain_aws import ChatBedrock
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

load_dotenv()

# ── Configuration ────────────────────────────────────────────────────────────
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-lite-v1:0")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MAX_PLAN_REVISION_LOOPS = 2


def get_llm(temperature: float = 0.2) -> ChatBedrock:
    return ChatBedrock(
        model_id=MODEL_ID,
        region_name=AWS_REGION,
        model_kwargs={"temperature": temperature, "max_tokens": 2000},
    )


# ═══════════════════════════════════════════════════════════════════════════════
# DEPLOYMENT SPECIFICATION — "Project Valhalla"
# ═══════════════════════════════════════════════════════════════════════════════

PROJECT_SPEC = """
PROJECT:        Valhalla — Air-Gapped HPC Cluster
CUSTOMER:       Classified Government Facility, Reston VA
DEPLOYMENT TYPE: Dark-Site (no internet, no HPE InfoSight, no cloud mgmt)
TARGET DATE:    2025-04-15

COMPUTE NODES (4x HPE ProLiant DL380 Gen11):
  - CPU:    2x Intel Xeon Platinum 8592+ (64 cores each, 128 cores/node)
  - RAM:    2TB DDR5-4800 ECC RDIMM
  - NIC:    2x HPE FlexibleLOM Mellanox ConnectX-7 (100GbE / HDR100 IB)
  - Local:  2x 960GB HPE Read Intensive SSD (RAID-1, OS)
  - iLO:    iLO 6 v1.50 (current) — target: v1.55
  - BMC:    Dedicated iLO management NIC (1GbE) on VLAN 100

STORAGE NODES (2x HPE Alletra 9060):
  - NVMe:   24x 7.68TB NVMe SSDs per node (183TB raw each)
  - NIC:    4x 100GbE iSCSI / NFS-over-RDMA ports
  - Mgmt:   HPE Nimble OS 7.2.1 — target: 7.4.0
  - Protocol: NFS v4.1 over RDMA (primary) + iSCSI (secondary path)
  - Export:  /data/scratch (high-perf SLURM scratch), /data/home (persistent)

NETWORK (HPE Aruba):
  - Core:   1x Aruba 8360-48Y6C (spine, 400GbE uplinks)
  - ToR:    2x Aruba CX 10000 (1 per rack, 100GbE server downlinks)
  - VLANs:
      VLAN 10:  HPC compute traffic (RoCEv2 lossless, jumbo frames 9000 MTU)
      VLAN 20:  NFS/iSCSI storage traffic (dedicated, lossless)
      VLAN 100: iLO management (isolated, no route to compute VLANs)
      VLAN 200: HPE OneView management
  - Routing: Static only (no BGP/OSPF in dark site)

MANAGEMENT:
  - HPE OneView 9.0 appliance (virtual, on mgmt server)
  - HPE SPP (Service Pack for ProLiant) 2025.03 — delivered on USB
  - No external DNS, NTP from internal stratum-2 server (192.168.100.1)

WORKLOAD:
  - SLURM 23.11 cluster (4 compute + 2 storage nodes)
  - MPI jobs requiring < 2 microsecond RDMA latency
  - Daily data ingest: ~50TB from offline media (sneakernet)

CONSTRAINTS:
  - Air-gapped: no internet access, no cloud management plane
  - All firmware updates via USB-attached HPE SPP ISO
  - Physical access requires 2-person rule (security requirement)
  - Maintenance window: Sundays 02:00-06:00 only
  - Data classification: SECRET — no log exfiltration
"""


# ═══════════════════════════════════════════════════════════════════════════════
# GRAPH STATE
# ═══════════════════════════════════════════════════════════════════════════════

class DeploymentState(TypedDict):
    # Input
    project_spec: str

    # Phase 1: Planning
    deployment_plan: str
    plan_reflection: str
    plan_critique:   str
    plan_revision_count: int
    plan_needs_revision: bool

    # Phase 2: Parallel validation (run concurrently)
    network_validation:  str
    storage_validation:  str
    ilo_validation:      str

    # Phase 3: Risk assessment
    risk_assessment: str

    # Phase 4: Human-in-the-Loop
    human_decision: Literal["approved", "revision_requested", "rejected", "pending"]
    human_feedback: str

    # Phase 5: Runbook (only if approved)
    deployment_runbook: str

    # Metadata
    audit_trail: Annotated[List[str], operator.add]


# ═══════════════════════════════════════════════════════════════════════════════
# GRAPH NODES
# ═══════════════════════════════════════════════════════════════════════════════

# ── Node 1: Deployment Planner ───────────────────────────────────────────────

def deployment_planner(state: DeploymentState) -> dict:
    """
    Draft the high-level deployment plan covering all phases and dependencies.
    Will be refined by the reflection loop before going to human review.
    """
    revision = state.get("plan_revision_count", 0)
    print(f"\n[PLANNER] Drafting deployment plan (revision #{revision})...")

    critique_block = ""
    if state.get("plan_critique"):
        critique_block = (
            f"\n\nPREVIOUS PLAN CRITIQUE — YOU MUST ADDRESS ALL POINTS:\n"
            f"{state['plan_critique']}\n\n"
            f"PREVIOUS DRAFT PLAN (to be revised):\n"
            f"{state.get('deployment_plan', 'N/A')}\n"
        )

    llm = get_llm(temperature=0.2)
    response = llm.invoke([
        SystemMessage(content=(
            "You are an HPE Professional Services Deployment Architect with 20 years of experience "
            "deploying HPE ProLiant, Alletra, and Aruba infrastructure in classified dark-site "
            "environments. You understand the full HPE deployment lifecycle: hardware staging, "
            "firmware baseline, network bring-up, iLO configuration, OneView onboarding, "
            "and OS provisioning. For dark-site deployments, you always plan for the constraints: "
            "no internet, firmware via SPP USB, 2-person access rule, and strict maintenance windows."
        )),
        HumanMessage(content=(
            "Draft a structured deployment plan for this project:\n\n"
            f"{state['project_spec']}"
            f"{critique_block}\n\n"
            "Your plan MUST include:\n"
            "1. PRE-DEPLOYMENT CHECKLIST: Hardware staging verification, SPP readiness, "
            "   site readiness (power, cooling, network cabling), documentation.\n"
            "2. DEPLOYMENT PHASES (numbered, sequenced with dependencies):\n"
            "   - Phase 1: Physical installation & cabling\n"
            "   - Phase 2: Network bring-up (Aruba core + ToR, VLAN config)\n"
            "   - Phase 3: iLO/BMC configuration & firmware baseline (SPP)\n"
            "   - Phase 4: Storage node bring-up (Alletra, NFS/iSCSI configuration)\n"
            "   - Phase 5: Compute node OS deployment & SLURM cluster setup\n"
            "   - Phase 6: Validation & acceptance testing\n"
            "3. CRITICAL DEPENDENCIES: What must be done before what.\n"
            "4. DARK-SITE CONSTRAINTS: How each constraint affects each phase.\n"
            "5. ESTIMATED TIMELINE: Hours per phase, total deployment time.\n"
            "6. ROLLBACK STRATEGY: If a phase fails, how to safely recover."
        )),
    ])

    return {
        "deployment_plan": response.content,
        "audit_trail": [f"[PLANNER] Deployment plan drafted (revision #{revision})."],
    }


# ── Node 2: Plan Reflection ──────────────────────────────────────────────────

def plan_reflection(state: DeploymentState) -> dict:
    """Self-assess the quality of the deployment plan before sending to human review."""
    print("\n[REFLECTION] Evaluating plan quality...")

    llm = get_llm(temperature=0.3)
    response = llm.invoke([
        SystemMessage(content=(
            "You are an independent HPE deployment QA reviewer. You assess deployment plans "
            "for completeness, dark-site constraint adherence, risk coverage, and executability "
            "by a 2-person team under maintenance window pressure. Be rigorous."
        )),
        HumanMessage(content=(
            f"Assess this deployment plan:\n\n{state['deployment_plan']}\n\n"
            "Score each dimension (1=poor, 5=excellent):\n"
            "  A. Phase sequencing & dependency correctness\n"
            "  B. Dark-site constraint handling (SPP, no internet, 2-person rule)\n"
            "  C. iLO / BMC configuration completeness\n"
            "  D. Network VLAN & RoCEv2 lossless fabric coverage\n"
            "  E. Rollback strategy for each phase\n\n"
            "State what is strong and what is missing.\n\n"
            "CRITICAL: End with EXACTLY one of:\n"
            "  VERDICT: APPROVED FOR HUMAN REVIEW\n"
            "  VERDICT: NEEDS REVISION"
        )),
    ])

    reflection = response.content
    needs_revision = "VERDICT: NEEDS REVISION" in reflection

    if state.get("plan_revision_count", 0) >= MAX_PLAN_REVISION_LOOPS:
        needs_revision = False
        reflection += (
            f"\n\n[SYSTEM OVERRIDE: Max plan revisions ({MAX_PLAN_REVISION_LOOPS}) reached. "
            "Forwarding current plan for human review.]"
        )

    return {
        "plan_reflection": reflection,
        "plan_needs_revision": needs_revision,
        "audit_trail": [
            f"[REFLECTION] Plan quality assessed. "
            f"Needs revision: {needs_revision}. "
            f"Revision count: {state.get('plan_revision_count', 0)}."
        ],
    }


# ── Node 3: Plan Critique (only if revision needed) ──────────────────────────

def plan_critique_node(state: DeploymentState) -> dict:
    """Generate specific revision instructions from reflection notes."""
    new_count = state.get("plan_revision_count", 0) + 1
    print(f"\n[CRITIQUE] Generating plan revision instructions — cycle #{new_count}...")

    llm = get_llm(temperature=0.2)
    response = llm.invoke([
        SystemMessage(content=(
            "You are an HPE deployment quality coach. Translate QA reflection notes into "
            "numbered, specific, actionable revision instructions for the deployment architect."
        )),
        HumanMessage(content=(
            f"Generate revision instructions from:\n\n"
            f"REFLECTION NOTES:\n{state['plan_reflection']}\n\n"
            f"CURRENT PLAN:\n{state['deployment_plan']}\n\n"
            "Produce numbered instructions. Each must say exactly what to add, change, or clarify.\n"
            "Format: REVISION #N: [specific action]"
        )),
    ])

    return {
        "plan_critique": response.content,
        "plan_revision_count": new_count,
        "audit_trail": [f"[CRITIQUE] Plan revision instructions generated (cycle #{new_count})."],
    }


# ── Node 4a: Network Validator ────────────────────────────────────────────────

def network_validator(state: DeploymentState) -> dict:
    """Validate the network topology and VLAN design for the deployment."""
    print("\n[NETWORK VALIDATOR] Validating Aruba fabric & VLAN design...")

    llm = get_llm(temperature=0.1)
    response = llm.invoke([
        SystemMessage(content=(
            "You are an HPE Aruba network architect specialising in RoCEv2 lossless fabrics "
            "for HPC environments. You validate datacenter network designs for correctness, "
            "performance, and HA. You know that RoCEv2 requires: lossless Ethernet (PFC), "
            "ECN (explicit congestion notification), and jumbo frames (MTU 9000) end-to-end."
        )),
        HumanMessage(content=(
            f"Validate the network design in this deployment spec:\n\n{state['project_spec']}\n\n"
            "Validate:\n"
            "1. VLAN design: Is the VLAN separation (compute/storage/iLO/mgmt) correct and secure?\n"
            "2. RoCEv2 lossless fabric: Are PFC and ECN requirements met? MTU consistency?\n"
            "3. Aruba 8360 + CX 10000 topology: Single spine correct for this cluster size?\n"
            "   Any HA concerns (single spine = SPOF)?\n"
            "4. iLO management isolation: Is VLAN 100 properly isolated from compute?\n"
            "5. Static routing sufficiency: Any limitations for SLURM or NFS-over-RDMA?\n"
            "6. ISSUES FOUND: List any design gaps with severity (CRITICAL / WARNING / INFO).\n"
            "7. RECOMMENDATIONS: Specific Aruba CX-OS config recommendations."
        )),
    ])

    return {
        "network_validation": response.content,
        "audit_trail": ["[NETWORK] Network topology validation complete."],
    }


# ── Node 4b: Storage Validator ────────────────────────────────────────────────

def storage_validator(state: DeploymentState) -> dict:
    """Validate the HPE Alletra storage configuration and NFS/iSCSI design."""
    print("\n[STORAGE VALIDATOR] Validating HPE Alletra & NFS-over-RDMA design...")

    llm = get_llm(temperature=0.1)
    response = llm.invoke([
        SystemMessage(content=(
            "You are an HPE Alletra / Nimble storage architect. You validate storage designs "
            "for HPC workloads: NFS-over-RDMA (NFS/RDMA), iSCSI HA paths, NVMe performance "
            "profiles, and export configurations for SLURM scratch/home volumes. "
            "You know HPE Nimble OS 7.x deeply — volume policy, RAID-6 vs Triple-Parity, "
            "and the specific NFS export options required for MPI workloads."
        )),
        HumanMessage(content=(
            f"Validate the storage design in this deployment spec:\n\n{state['project_spec']}\n\n"
            "Validate:\n"
            "1. Alletra 9060 NVMe layout: Is 24x 7.68TB per node optimal for this workload?\n"
            "   Suggested RAID level and spare policy?\n"
            "2. NFS-over-RDMA design: Are there specific NFS v4.1 + RDMA tuning requirements?\n"
            "   Required kernel modules, NIC firmware, and Nimble OS settings?\n"
            "3. iSCSI secondary path: Is 2-path iSCSI multipath sufficient for HA?\n"
            "4. Volume design: scratch vs home — different RAID policies? Performance tiers?\n"
            "5. Dark-site constraint: Nimble OS 7.4.0 upgrade (from 7.2.1) via USB — "
            "   any non-disruptive upgrade path concerns?\n"
            "6. ISSUES: List gaps with severity (CRITICAL / WARNING / INFO).\n"
            "7. RECOMMENDATIONS: Specific Nimble OS CLI commands for key config items."
        )),
    ])

    return {
        "storage_validation": response.content,
        "audit_trail": ["[STORAGE] Storage configuration validation complete."],
    }


# ── Node 4c: iLO / BMC Validator ─────────────────────────────────────────────

def ilo_validator(state: DeploymentState) -> dict:
    """Validate iLO 6 configuration, firmware baseline, and management network design."""
    print("\n[iLO VALIDATOR] Validating HPE iLO 6 config & firmware baseline...")

    llm = get_llm(temperature=0.1)
    response = llm.invoke([
        SystemMessage(content=(
            "You are an HPE iLO 6 and OneView specialist. You validate iLO management designs "
            "for ProLiant Gen11 deployments: firmware versions, management network isolation, "
            "IPMI/Redfish API configuration, ASR watchdog settings, and OneView integration. "
            "For dark-site environments, you know the SPP USB offline update workflow in detail. "
            "You are aware of current iLO 6 firmware advisories and the minimum recommended version."
        )),
        HumanMessage(content=(
            f"Validate the iLO/BMC design in this deployment spec:\n\n{state['project_spec']}\n\n"
            "Validate:\n"
            "1. iLO 6 firmware: v1.50 -> v1.55 upgrade — what changed? Critical fixes included?\n"
            "   SPP 2025.03 — does it include iLO 6 v1.55?\n"
            "2. iLO management network: VLAN 100 isolation — is 1GbE dedicated port sufficient?\n"
            "   Any IPMI-over-LAN security hardening required for SECRET facility?\n"
            "3. HPE OneView 9.0 air-gapped mode: What features are unavailable without internet?\n"
            "   How to manage SPP firmware compliance without HPE cloud updates?\n"
            "4. iLO ASR watchdog: Default settings appropriate for HPC SLURM jobs? "
            "   (Long-running MPI jobs can trigger false ASR resets — needs tuning)\n"
            "5. NTP: iLO time sync in dark site — using internal NTP (192.168.100.1)? "
            "   Configuration steps?\n"
            "6. Redfish API: Required for OneView integration — any auth/cert config?\n"
            "7. ISSUES: List gaps with severity (CRITICAL / WARNING / INFO).\n"
            "8. RECOMMENDATIONS: Specific iLO CLI / Redfish API configuration steps."
        )),
    ])

    return {
        "ilo_validation": response.content,
        "audit_trail": ["[iLO] iLO/BMC configuration validation complete."],
    }


# ── Node 5: Risk Assessment ───────────────────────────────────────────────────

def risk_assessor(state: DeploymentState) -> dict:
    """Synthesise all validation findings into a deployment risk register."""
    print("\n[RISK ASSESSOR] Generating deployment risk register...")

    llm = get_llm(temperature=0.2)
    response = llm.invoke([
        SystemMessage(content=(
            "You are an HPE deployment risk manager specialising in dark-site classified "
            "environments. You produce risk registers that engineers can act on — not generic "
            "boilerplate. Every risk must have a probability, impact, and specific mitigation "
            "that references the actual project constraints."
        )),
        HumanMessage(content=(
            "Produce a deployment risk register based on all validation findings.\n\n"
            f"DEPLOYMENT PLAN:\n{state['deployment_plan'][:800]}...\n\n"
            f"NETWORK VALIDATION:\n{state['network_validation'][:600]}...\n\n"
            f"STORAGE VALIDATION:\n{state['storage_validation'][:600]}...\n\n"
            f"iLO VALIDATION:\n{state['ilo_validation'][:600]}...\n\n"
            "Risk Register format for each risk:\n"
            "  RISK-N | Component | Description | Probability (H/M/L) | Impact (H/M/L) | "
            "  Risk Level | Mitigation | Owner\n\n"
            "After the register, provide:\n"
            "  GO / NO-GO RECOMMENDATION with rationale.\n"
            "  Top 3 risks that MUST be addressed before deployment proceeds.\n"
            "  Any risks that warrant escalation to the customer before the maintenance window."
        )),
    ])

    return {
        "risk_assessment": response.content,
        "audit_trail": ["[RISK] Deployment risk assessment complete."],
    }


# ── Node 6: Human Approval Checkpoint ────────────────────────────────────────
# This node is reached via interrupt_before() — the graph pauses HERE and
# waits for a human to inject their decision into the state before resuming.

def human_approval_checkpoint(state: DeploymentState) -> dict:
    """
    HUMAN-IN-THE-LOOP checkpoint.
    In a live system: graph execution pauses here (interrupt_before).
    The human engineer reviews the plan + risk register in a UI or CLI,
    then resumes the graph by calling app.invoke() with their decision injected.
    For this demo: we simulate an interactive terminal prompt.
    """
    print("\n" + "=" * 78)
    print("  HUMAN APPROVAL REQUIRED — PROJECT VALHALLA DEPLOYMENT PLAN")
    print("=" * 78)
    print("\nThe AI has completed plan generation and validation.")
    print("Please review the following before approving:\n")

    print("--- DEPLOYMENT PLAN (summary) ---")
    plan_lines = state["deployment_plan"].split("\n")
    for line in plan_lines[:30]:  # show first 30 lines
        print(f"  {line}")
    if len(plan_lines) > 30:
        print(f"  ... ({len(plan_lines) - 30} more lines)")

    print("\n--- RISK ASSESSMENT (summary) ---")
    risk_lines = state["risk_assessment"].split("\n")
    for line in risk_lines[:20]:
        print(f"  {line}")
    if len(risk_lines) > 20:
        print(f"  ... ({len(risk_lines) - 20} more lines)")

    print("\n" + "-" * 78)
    print("  APPROVAL OPTIONS:")
    print("    [1] approve           — Proceed to runbook generation")
    print("    [2] revision_requested — Request changes (provide feedback)")
    print("    [3] reject            — Cancel deployment planning")
    print("-" * 78)

    while True:
        choice = input("\n  Your decision [1/2/3]: ").strip()
        if choice == "1":
            decision = "approved"
            feedback = "Approved by deployment engineer."
            break
        elif choice == "2":
            decision = "revision_requested"
            feedback = input("  Describe required changes: ").strip()
            if not feedback:
                feedback = "General revision requested."
            break
        elif choice == "3":
            decision = "rejected"
            feedback = input("  Reason for rejection (optional): ").strip()
            if not feedback:
                feedback = "Deployment rejected by engineer."
            break
        else:
            print("  Invalid choice. Enter 1, 2, or 3.")

    print(f"\n  Decision recorded: {decision.upper()}")
    print("=" * 78)

    return {
        "human_decision": decision,
        "human_feedback": feedback,
        "audit_trail": [f"[HUMAN REVIEW] Decision: {decision}. Feedback: {feedback}"],
    }


# ── Node 7: Runbook Generator (only if approved) ─────────────────────────────

def runbook_generator(state: DeploymentState) -> dict:
    """Generate the final executable deployment runbook after human approval."""
    print("\n[RUNBOOK] Generating final deployment runbook (human-approved)...")

    llm = get_llm(temperature=0.1)
    response = llm.invoke([
        SystemMessage(content=(
            "You are an HPE ProLiant deployment specialist writing a deployment runbook that "
            "will be executed by a 2-person team in a classified dark-site facility during a "
            "4-hour Sunday maintenance window. Your runbooks are legendary for being clear, "
            "numbered, executable under pressure, and containing exact HPE CLI commands. "
            "No step can be vague. Every step must have an expected output and a go/no-go check."
        )),
        HumanMessage(content=(
            "Generate the FINAL DEPLOYMENT RUNBOOK for Project Valhalla.\n\n"
            f"APPROVED DEPLOYMENT PLAN:\n{state['deployment_plan']}\n\n"
            f"VALIDATION FINDINGS TO INCORPORATE:\n"
            f"Network: {state['network_validation'][:500]}...\n"
            f"Storage: {state['storage_validation'][:500]}...\n"
            f"iLO/BMC: {state['ilo_validation'][:500]}...\n\n"
            f"HUMAN FEEDBACK: {state['human_feedback']}\n\n"
            "Runbook must include for EACH STEP:\n"
            "  - Step number and title\n"
            "  - Responsible role (Engineer 1 / Engineer 2 / Both)\n"
            "  - Exact HPE CLI command, Redfish API call, or Aruba CX-OS command\n"
            "  - Expected output (what SUCCESS looks like)\n"
            "  - Go/No-Go check (when to proceed vs. stop)\n"
            "  - Rollback procedure\n\n"
            "Organise by deployment phase. Include:\n"
            "  - Pre-deployment verification checklist\n"
            "  - Phase 1-6 execution steps\n"
            "  - Post-deployment acceptance tests\n"
            "  - Handover sign-off checklist"
        )),
    ])

    return {
        "deployment_runbook": response.content,
        "audit_trail": ["[RUNBOOK] Final deployment runbook generated after human approval."],
    }


# ── Node 8: Plan Revision (if human requests changes) ─────────────────────────

def plan_revision_from_human(state: DeploymentState) -> dict:
    """Incorporate human feedback and regenerate the plan."""
    print("\n[REVISION] Incorporating human feedback into plan...")

    llm = get_llm(temperature=0.2)
    response = llm.invoke([
        SystemMessage(content=(
            "You are an HPE deployment architect receiving revision feedback from the "
            "approving engineer. Incorporate all feedback precisely and regenerate the plan."
        )),
        HumanMessage(content=(
            f"Revise this deployment plan based on engineer feedback:\n\n"
            f"CURRENT PLAN:\n{state['deployment_plan']}\n\n"
            f"HUMAN FEEDBACK:\n{state['human_feedback']}\n\n"
            "Incorporate all feedback. Clearly mark revised sections with [REVISED]."
        )),
    ])

    return {
        "deployment_plan": response.content,
        "human_decision": "pending",
        "audit_trail": [f"[REVISION] Plan revised per human feedback: {state['human_feedback'][:80]}..."],
    }


# ── Node 9: Rejected Handler ──────────────────────────────────────────────────

def handle_rejection(state: DeploymentState) -> dict:
    """Record the rejection and produce a cancellation summary."""
    print("\n[REJECTED] Deployment planning cancelled by engineer.")
    return {
        "deployment_runbook": (
            f"DEPLOYMENT CANCELLED\n"
            f"Project: Valhalla\n"
            f"Decision: REJECTED by deployment engineer\n"
            f"Reason: {state.get('human_feedback', 'No reason provided')}\n"
            f"Action Required: Review constraints and resubmit when ready."
        ),
        "audit_trail": [f"[REJECTED] Deployment planning terminated. Reason: {state.get('human_feedback', '')}"],
    }


# ═══════════════════════════════════════════════════════════════════════════════
# ROUTING FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def route_after_plan_reflection(state: DeploymentState) -> str:
    if state.get("plan_needs_revision", False):
        return "plan_critique"
    return "network_validator"  # proceed to parallel validation


def route_after_human_decision(state: DeploymentState) -> str:
    decision = state.get("human_decision", "pending")
    if decision == "approved":
        return "runbook_generator"
    elif decision == "revision_requested":
        return "plan_revision_from_human"
    else:  # rejected or pending
        return "handle_rejection"


# ═══════════════════════════════════════════════════════════════════════════════
# BUILD THE LANGGRAPH
# ═══════════════════════════════════════════════════════════════════════════════

def build_deployment_graph() -> StateGraph:
    graph = StateGraph(DeploymentState)

    # Register all nodes
    graph.add_node("deployment_planner",       deployment_planner)
    graph.add_node("plan_reflection",          plan_reflection)
    graph.add_node("plan_critique",            plan_critique_node)
    graph.add_node("network_validator",        network_validator)
    graph.add_node("storage_validator",        storage_validator)
    graph.add_node("ilo_validator",            ilo_validator)
    graph.add_node("risk_assessor",            risk_assessor)
    graph.add_node("human_approval",           human_approval_checkpoint)
    graph.add_node("runbook_generator",        runbook_generator)
    graph.add_node("plan_revision_from_human", plan_revision_from_human)
    graph.add_node("handle_rejection",         handle_rejection)

    # Entry point
    graph.set_entry_point("deployment_planner")

    # Planning -> Reflection
    graph.add_edge("deployment_planner", "plan_reflection")

    # Reflection -> Critique (if needs revision) OR proceed to validation
    graph.add_conditional_edges(
        "plan_reflection",
        route_after_plan_reflection,
        {
            "plan_critique":    "plan_critique",
            "network_validator": "network_validator",
        },
    )

    # Critique feeds back into planner (revision loop)
    graph.add_edge("plan_critique", "deployment_planner")

    # Parallel validation: all three validators receive the same plan
    # LangGraph executes nodes in parallel when they have no edge dependencies between them
    # We achieve this by fanning out from network_validator and joining at risk_assessor
    graph.add_edge("network_validator", "storage_validator")
    graph.add_edge("storage_validator", "ilo_validator")

    # After all validations -> Risk assessment
    graph.add_edge("ilo_validator", "risk_assessor")

    # Risk assessment -> Human approval checkpoint
    graph.add_edge("risk_assessor", "human_approval")

    # Human decision routing
    graph.add_conditional_edges(
        "human_approval",
        route_after_human_decision,
        {
            "runbook_generator":        "runbook_generator",
            "plan_revision_from_human": "plan_revision_from_human",
            "handle_rejection":         "handle_rejection",
        },
    )

    # After human-requested revision, go back to reflection
    graph.add_edge("plan_revision_from_human", "plan_reflection")

    # Terminal nodes
    graph.add_edge("runbook_generator", END)
    graph.add_edge("handle_rejection",  END)

    # MemorySaver enables interrupt_before (HITL) and state persistence
    checkpointer = MemorySaver()
    return graph.compile(checkpointer=checkpointer)


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    sep = "=" * 78
    print(f"\n{sep}")
    print("  HPE ENTERPRISE DATACENTER DEPLOYMENT PLANNER")
    print("  LangGraph  |  Amazon Bedrock  |  Human-in-the-Loop Approval")
    print(sep)
    print("""
  Project: VALHALLA — Air-Gapped HPC Cluster at Classified Government Facility

  AI Deployment Planning Pipeline:
    1. Deployment Planner      — Drafts phased deployment plan
       + Reflection Loop       — Self-critiques and refines the plan
    2. Network Validator       — Validates Aruba fabric & RoCEv2 lossless design
    3. Storage Validator       — Validates HPE Alletra & NFS-over-RDMA design
    4. iLO/BMC Validator       — Validates iLO 6 firmware & mgmt network
    5. Risk Assessor           — Synthesises risks, GO/NO-GO recommendation
    *** HUMAN APPROVAL CHECKPOINT ***  <-- You will be prompted here
    6a. [APPROVED] Runbook Generator — Produces executable step-by-step runbook
    6b. [REVISION] Plan Revision    — Incorporates your feedback, loops back
    6c. [REJECTED] Rejection Handler — Cancels and records reason

  Why Human-in-the-Loop?
    Dark-site deployments are irreversible once firmware is flashed and
    network config is committed. The human engineer must review risk before
    any action touches physical infrastructure.
""")
    print(f"{sep}\n")

    app = build_deployment_graph()

    initial_state: DeploymentState = {
        "project_spec":          PROJECT_SPEC,
        "deployment_plan":       "",
        "plan_reflection":       "",
        "plan_critique":         "",
        "plan_revision_count":   0,
        "plan_needs_revision":   False,
        "network_validation":    "",
        "storage_validation":    "",
        "ilo_validation":        "",
        "risk_assessment":       "",
        "human_decision":        "pending",
        "human_feedback":        "",
        "deployment_runbook":    "",
        "audit_trail":           ["[SYSTEM] Project Valhalla deployment planning initiated."],
    }

    config = {"configurable": {"thread_id": "valhalla-deployment-001"}}
    final_state = app.invoke(initial_state, config=config)

    # ── Print Results ─────────────────────────────────────────────────────────
    print(f"\n{sep}")
    print("  DEPLOYMENT PLAN")
    print(sep)
    print(final_state["deployment_plan"])

    print(f"\n{sep}")
    print("  NETWORK VALIDATION")
    print(sep)
    print(final_state["network_validation"])

    print(f"\n{sep}")
    print("  STORAGE VALIDATION")
    print(sep)
    print(final_state["storage_validation"])

    print(f"\n{sep}")
    print("  iLO / BMC VALIDATION")
    print(sep)
    print(final_state["ilo_validation"])

    print(f"\n{sep}")
    print("  RISK ASSESSMENT")
    print(sep)
    print(final_state["risk_assessment"])

    print(f"\n{sep}")
    decision = final_state.get("human_decision", "unknown")
    print(f"  FINAL OUTPUT — Human Decision: {decision.upper()}")
    print(sep)
    print(final_state.get("deployment_runbook", "No runbook generated."))

    print(f"\n{sep}")
    print("  FULL AUDIT TRAIL")
    print(sep)
    for i, entry in enumerate(final_state["audit_trail"], 1):
        print(f"  {i:02d}. {entry}")
    print(f"{sep}\n")


if __name__ == "__main__":
    main()
