"""
Attention Mechanism and Next Token Prediction — Interactive Math Walkthrough
===================================================
Streamlit demo for GenAI Training
Step-by-step: Tokens → Embeddings → Q/K/V → Scores → Softmax → Output → [FFN/MLP] → Unembedding (W_U) → softmax → Next Token
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import streamlit as st
import pandas as pd

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Attention Mechanism — Math Walkthrough",
    page_icon="🔍",
    layout="wide",
)

# ── Helpers ───────────────────────────────────────────────────────────────────
def softmax(x, axis=-1):
    x = x - x.max(axis=axis, keepdims=True)
    e = np.exp(x)
    return e / e.sum(axis=axis, keepdims=True)


TOKEN_COLORS = [
    "#4e79a7", "#f28e2b", "#e15759", "#76b7b2",
    "#59a14f", "#edc948", "#b07aa1", "#ff9da7",
    "#9c755f", "#bab0ac",
]


def token_pills(tokens):
    """Render tokens as colored HTML pills."""
    pills = []
    for i, tok in enumerate(tokens):
        color = TOKEN_COLORS[i % len(TOKEN_COLORS)]
        pills.append(
            f'<span style="background:{color};color:white;padding:4px 10px;'
            f'border-radius:14px;margin:3px;display:inline-block;font-weight:600;'
            f'font-size:15px">{tok}</span>'
        )
    return " ".join(pills)


def styled_matrix_df(matrix, row_labels, col_labels):
    """Return a styled pandas DataFrame for display."""
    df = pd.DataFrame(matrix.round(3), index=row_labels, columns=col_labels)
    return df


def plot_heatmap(matrix, row_labels, col_labels, title, cmap="Blues",
                 figsize=None, vmin=None, vmax=None, row_colors=None):
    T, D = matrix.shape
    if figsize is None:
        figsize = (max(4, D * 0.7 + 1), max(3, T * 0.55 + 1))
    fig, ax = plt.subplots(figsize=figsize)
    sns.heatmap(
        matrix, annot=True, fmt=".2f", cmap=cmap,
        xticklabels=col_labels, yticklabels=row_labels,
        ax=ax, linewidths=0.6, linecolor="#cccccc",
        vmin=vmin, vmax=vmax,
        annot_kws={"size": 9},
        cbar_kws={"shrink": 0.8},
    )
    ax.set_title(title, fontsize=12, pad=8, fontweight="bold")
    ax.tick_params(axis="x", labelsize=9, rotation=30)
    ax.tick_params(axis="y", labelsize=9, rotation=0)

    # Color row labels to match token colors
    if row_colors:
        for tick, color in zip(ax.get_yticklabels(), row_colors):
            tick.set_color(color)
            tick.set_fontweight("bold")

    plt.tight_layout()
    return fig


def plot_attention_heatmap_large(attn, tokens):
    """Big centrepiece heatmap with per-cell intensity and token coloring."""
    T = len(tokens)
    fig, ax = plt.subplots(figsize=(max(5, T * 0.9 + 1.5), max(4, T * 0.9 + 1.5)))
    colors_tok = [TOKEN_COLORS[i % len(TOKEN_COLORS)] for i in range(T)]

    im = ax.imshow(attn, cmap="YlOrRd", vmin=0, vmax=1, aspect="auto")

    for i in range(T):
        for j in range(T):
            val = attn[i, j]
            text_color = "white" if val > 0.55 else "black"
            ax.text(j, i, f"{val:.2f}", ha="center", va="center",
                    fontsize=11, fontweight="bold", color=text_color)

    ax.set_xticks(range(T))
    ax.set_yticks(range(T))
    ax.set_xticklabels(tokens, fontsize=11)
    ax.set_yticklabels(tokens, fontsize=11)

    for idx, (xtick, ytick) in enumerate(zip(ax.get_xticklabels(), ax.get_yticklabels())):
        xtick.set_color(colors_tok[idx % len(colors_tok)])
        xtick.set_fontweight("bold")
        ytick.set_color(colors_tok[idx])
        ytick.set_fontweight("bold")

    ax.set_xlabel("Key token  (attends TO →)", fontsize=11, labelpad=8)
    ax.set_ylabel("← Query token  (FROM)", fontsize=11, labelpad=8)
    ax.set_title("Attention Weight Matrix  —  softmax(QKᵀ / √d)",
                 fontsize=13, fontweight="bold", pad=10)
    plt.colorbar(im, ax=ax, fraction=0.04, pad=0.02, label="Attention weight")
    plt.tight_layout()
    return fig


def qkv_arrow_diagram(tokens, embed_dim):
    """Simple diagram: X → Wq/Wk/Wv → Q/K/V."""
    fig, ax = plt.subplots(figsize=(8, 2.4))
    ax.axis("off")
    T = len(tokens)

    boxes = {
        "X":  (0.10, 0.5, f"X\n({T}×{embed_dim})\nEmbeddings",    "#4e79a7"),
        "Wq": (0.33, 0.82, f"W_Q\n({embed_dim}×{embed_dim})",       "#59a14f"),
        "Wk": (0.33, 0.50, f"W_K\n({embed_dim}×{embed_dim})",       "#f28e2b"),
        "Wv": (0.33, 0.18, f"W_V\n({embed_dim}×{embed_dim})",       "#e15759"),
        "Q":  (0.65, 0.82, f"Q\n({T}×{embed_dim})\nQueries",        "#59a14f"),
        "K":  (0.65, 0.50, f"K\n({T}×{embed_dim})\nKeys",           "#f28e2b"),
        "V":  (0.65, 0.18, f"V\n({T}×{embed_dim})\nValues",         "#e15759"),
    }

    for _, (x, y, label, color) in boxes.items():
        ax.add_patch(mpatches.FancyBboxPatch(
            (x - 0.08, y - 0.16), 0.16, 0.32,
            boxstyle="round,pad=0.02", facecolor=color,
            edgecolor="white", linewidth=1.5, alpha=0.88,
        ))
        ax.text(x, y, label, ha="center", va="center",
                fontsize=8, color="white", fontweight="bold")

    # Arrows X → W
    for (wx, wy, _, _) in [boxes["Wq"], boxes["Wk"], boxes["Wv"]]:
        ax.annotate("", xy=(wx - 0.08, wy), xytext=(boxes["X"][0] + 0.08, boxes["X"][1]),
                    arrowprops=dict(arrowstyle="->", color="#aaaaaa", lw=1.5))
    # Arrows W → output
    for src, tgt in [("Wq", "Q"), ("Wk", "K"), ("Wv", "V")]:
        sx, sy = boxes[src][0] + 0.08, boxes[src][1]
        tx, ty = boxes[tgt][0] - 0.08, boxes[tgt][1]
        ax.annotate("", xy=(tx, ty), xytext=(sx, sy),
                    arrowprops=dict(arrowstyle="->", color="#aaaaaa", lw=1.5))
        mx, my = (sx + tx) / 2, (sy + ty) / 2
        ax.text(mx, my + 0.04, "×", ha="center", va="center", fontsize=13, color="#555")

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_title("Projection: X × W_Q / W_K / W_V  →  Q, K, V",
                 fontsize=11, fontweight="bold")
    plt.tight_layout()
    return fig


def score_formula_diagram(tokens, scores, embed_dim):
    """Visualise the score computation Q·Kᵀ / √d."""
    T = len(tokens)
    fig, axes = plt.subplots(1, 3, figsize=(max(10, T * 1.2 + 4), max(3.5, T * 0.7 + 1.5)))

    # Raw scores
    sns.heatmap(scores, annot=True, fmt=".2f", cmap="RdBu_r",
                xticklabels=tokens, yticklabels=tokens,
                ax=axes[0], linewidths=0.5, annot_kws={"size": 8},
                center=0, cbar_kws={"shrink": 0.8})
    axes[0].set_title(f"Raw scores  Q·Kᵀ / √{embed_dim}", fontsize=10, fontweight="bold")
    axes[0].tick_params(axis="x", rotation=35, labelsize=8)
    axes[0].tick_params(axis="y", rotation=0, labelsize=8)

    # Score distribution per query token
    axes[1].set_title("Score distribution per query token", fontsize=10, fontweight="bold")
    for i, tok in enumerate(tokens):
        axes[1].plot(tokens, scores[i], marker="o",
                     label=tok, color=TOKEN_COLORS[i % len(TOKEN_COLORS)], linewidth=2)
    axes[1].axhline(0, color="#cccccc", linewidth=0.8, linestyle="--")
    axes[1].legend(fontsize=7, loc="upper right")
    axes[1].set_xlabel("Key token", fontsize=9)
    axes[1].set_ylabel("Score", fontsize=9)
    axes[1].tick_params(axis="x", rotation=30, labelsize=8)

    # Softmax output
    attn = softmax(scores)
    sns.heatmap(attn, annot=True, fmt=".2f", cmap="YlOrRd",
                xticklabels=tokens, yticklabels=tokens,
                ax=axes[2], linewidths=0.5, annot_kws={"size": 8},
                vmin=0, vmax=1, cbar_kws={"shrink": 0.8})
    axes[2].set_title("After softmax  (each row sums to 1)", fontsize=10, fontweight="bold")
    axes[2].tick_params(axis="x", rotation=35, labelsize=8)
    axes[2].tick_params(axis="y", rotation=0, labelsize=8)

    for ax in [axes[0], axes[2]]:
        for tick_lbl in ax.get_yticklabels():
            idx = tokens.index(tick_lbl.get_text()) if tick_lbl.get_text() in tokens else -1
            if idx >= 0:
                tick_lbl.set_color(TOKEN_COLORS[idx % len(TOKEN_COLORS)])
                tick_lbl.set_fontweight("bold")

    plt.tight_layout()
    return fig


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.image(
        "https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/"
        "Hewlett_Packard_Enterprise_logo.svg/320px-Hewlett_Packard_Enterprise_logo.svg.png",
        width=180,
    )
    st.markdown("## ⚙️ Controls")

    sentence = st.text_area(
        "Input sentence",
        value="Server shutdown occurred because power supply overheated",
        height=90,
    )

    embed_dim = st.select_slider(
        "Embedding dimension (d)",
        options=[4, 6, 8],
        value=4,
        help="Dimensionality of each token's embedding vector.",
    )

    seed = st.number_input("Random seed", min_value=0, max_value=9999,
                           value=42, step=1,
                           help="Change to see different weight initialisations.")

    show_weight_matrices = st.checkbox("Show W_Q / W_K / W_V matrices", value=False)
    show_qkv_matrices    = st.checkbox("Show Q / K / V matrices", value=True)
    show_embeddings      = st.checkbox("Show embedding matrix X", value=False)

    st.markdown("---")
    st.markdown(
        "**Gen AI Lab** — Transformer Internals  \n"
        "Formula: `Attention(Q,K,V) = softmax(QKᵀ/√d)·V`"
    )

# ── Compute ───────────────────────────────────────────────────────────────────
tokens = sentence.strip().split()
MAX_TOKENS = 10
if len(tokens) > MAX_TOKENS:
    st.warning(f"Showing first {MAX_TOKENS} tokens for readability.")
    tokens = tokens[:MAX_TOKENS]

T = len(tokens)
D = embed_dim

rng = np.random.default_rng(seed)

# ⚠️  RANDOM — expected to be learned from data in a real model
# X: token embedding matrix.  In production transformers this is a trained look-up
# table (nn.Embedding) where each row is learned via backpropagation over the
# training corpus.  Here we sample from N(0,1) purely to make the demo runnable
# without loading a real checkpoint.
X   = rng.standard_normal((T, D))

# ⚠️  RANDOM — expected to be learned from data in a real model
# Wq, Wk, Wv: the three projection weight matrices — the *core learnable parameters*
# of every attention head.  During training, gradient descent adjusts these so that
# the resulting Q·Kᵀ dot products capture semantically meaningful relationships
# (e.g. "overheated" attends strongly to "power" and "supply").
# Initialised here with scaled Gaussian noise (σ=0.5) to mimic Xavier-style init.
Wq  = rng.standard_normal((D, D)) * 0.5
Wk  = rng.standard_normal((D, D)) * 0.5
Wv  = rng.standard_normal((D, D)) * 0.5

Q      = X @ Wq
K      = X @ Wk
V      = X @ Wv
scale  = np.sqrt(D)

# ★  KEY OPERATION — the dot product Q·Kᵀ is the heart of the attention mechanism
#
# scores[i, j] = dot(Q[i], K[j]) / √d
#
# Why dot product?
#   A dot product measures *similarity* between two vectors: high value → the
#   query vector for token i is well-aligned with the key vector for token j,
#   meaning "token i should pay attention to token j."
#
# Why divide by √d?
#   As d grows, dot products grow in magnitude (variance scales with d).
#   Dividing by √d keeps variance ≈ 1 so softmax doesn't saturate and
#   gradients remain healthy during training.
#
# This single T×T matrix of dot products drives ALL subsequent routing of
# information between tokens — it is literally what "attention" means.
scores = Q @ K.T / scale

attn   = softmax(scores)
output = attn @ V

tok_colors = [TOKEN_COLORS[i % len(TOKEN_COLORS)] for i in range(T)]
dim_labels = [f"d{i}" for i in range(D)]

# ── Main UI ───────────────────────────────────────────────────────────────────
st.markdown(
    "<h1 style='text-align:center;margin-bottom:0'>🔍 Attention Mechanism</h1>"
    "<h3 style='text-align:center;color:#888;margin-top:4px'>Interactive Math Walkthrough</h3>",
    unsafe_allow_html=True,
)

# Core formula banner
st.markdown(
    """
    <div style="background:linear-gradient(90deg,#1a1a2e,#16213e);
                border-radius:12px;padding:18px 28px;margin:18px 0;text-align:center">
        <span style="color:#e0e0e0;font-size:13px;letter-spacing:1px">CORE FORMULA</span><br>
        <span style="color:#ffd700;font-size:24px;font-family:monospace;font-weight:700">
            Attention(Q, K, V) &nbsp;=&nbsp; softmax( QK<sup>T</sup> / √d ) · V
        </span>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown("---")

# ── STEP 1: Tokenisation ─────────────────────────────────────────────────────
st.markdown("## Step 1 — Tokenisation")

col1, col2 = st.columns([3, 1])
with col1:
    st.markdown(token_pills(tokens), unsafe_allow_html=True)
    st.caption(f"T = **{T}** tokens  ·  embedding dimension d = **{D}**")
with col2:
    st.info(
        "**iLO Analogy**  \n"
        "Each word = one sensor reading ID.  \n"
        "The model reads *all* tokens in parallel — no sequential loop."
    )

# ── STEP 2: Embeddings ───────────────────────────────────────────────────────
st.markdown("## Step 2 — Token Embeddings  `X`")

with st.expander("What are embeddings?", expanded=False):
    st.markdown(
        "Each token is mapped to a **dense numerical vector** of dimension `d`.  \n"
        "Real transformers learn these vectors during training (look-up table).  \n"
        "Here we use **random vectors** to keep the demo self-contained.  \n\n"
        "Shape of `X`: **(T × d)** — one row per token, one column per embedding dimension."
    )

if show_embeddings:
    fig = plot_heatmap(X, tokens, dim_labels,
                       f"X  —  Token Embeddings  ({T} × {D})",
                       cmap="coolwarm", row_colors=tok_colors)
    st.pyplot(fig, use_container_width=False)
else:
    st.dataframe(
        styled_matrix_df(X, tokens, dim_labels).style.background_gradient(cmap="coolwarm", axis=None),
        use_container_width=False,
    )

# ── STEP 3: Weight matrices ───────────────────────────────────────────────────
st.markdown("## Step 3 — Learned Weight Matrices  `W_Q`, `W_K`, `W_V`")

col_a, col_b = st.columns([3, 1])
with col_b:
    st.info(
        "**The magic is here.**  \n"
        "These matrices are **learned during training** via backprop.  \n"
        "They teach each token *how to ask questions* (Q), *what to advertise* (K), "
        "and *what to share* (V)."
    )
with col_a:
    st.markdown("""
| Matrix | Shape | Role | iLO analogy |
|--------|-------|------|-------------|
| **W_Q** | d × d | Transforms each token into a **Query** — *"what am I looking for?"* | "Find me CPU temperature" |
| **W_K** | d × d | Transforms each token into a **Key** — *"what do I offer?"* | Sensor label: "CPU_TEMP" |
| **W_V** | d × d | Transforms each token into a **Value** — *"what data do I carry?"* | Actual sensor reading: 87 °C |
""")

if show_weight_matrices:
    c1, c2, c3 = st.columns(3)
    with c1:
        st.pyplot(plot_heatmap(Wq, dim_labels, dim_labels, "W_Q", cmap="Greens"), use_container_width=True)
    with c2:
        st.pyplot(plot_heatmap(Wk, dim_labels, dim_labels, "W_K", cmap="Oranges"), use_container_width=True)
    with c3:
        st.pyplot(plot_heatmap(Wv, dim_labels, dim_labels, "W_V", cmap="Reds"), use_container_width=True)

# ── STEP 4: Q, K, V projection ────────────────────────────────────────────────
st.markdown("## Step 4 — Compute Q, K, V  via Matrix Multiply")

st.markdown(
    r"""
```
Q = X · W_Q       (shape: T × d)
K = X · W_K       (shape: T × d)
V = X · W_V       (shape: T × d)
```
Each token now has three roles simultaneously — it asks a question (Q),
broadcasts a label (K), and carries a payload (V).
"""
)

st.pyplot(qkv_arrow_diagram(tokens, D), use_container_width=False)

if show_qkv_matrices:
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("**Q — Queries**")
        st.dataframe(
            styled_matrix_df(Q, tokens, dim_labels).style.background_gradient(cmap="Greens", axis=None),
            use_container_width=True,
        )
    with c2:
        st.markdown("**K — Keys**")
        st.dataframe(
            styled_matrix_df(K, tokens, dim_labels).style.background_gradient(cmap="Oranges", axis=None),
            use_container_width=True,
        )
    with c3:
        st.markdown("**V — Values**")
        st.dataframe(
            styled_matrix_df(V, tokens, dim_labels).style.background_gradient(cmap="Reds", axis=None),
            use_container_width=True,
        )

# ── STEP 5: Attention scores ──────────────────────────────────────────────────
st.markdown("## Step 5 — Attention Scores  `Q · Kᵀ / √d`")

col_a, col_b = st.columns([3, 1])
with col_b:
    st.info(
        f"**Why divide by √d = {scale:.2f}?**  \n"
        "With large `d`, dot products grow large → softmax saturates → "
        "gradients vanish.  \n"
        "Dividing by √d keeps the variance ≈ 1."
    )
with col_a:
    st.markdown(
        r"""
```
scores[i, j] = Q[i] · K[j]  /  √d
```
- `scores[i, j]` = how much **token i** (query) wants to attend to **token j** (key)
- High score → the tokens are *relevant* to each other
- This is just a **dot product** — the same GEMM that GPUs are built for
"""
    )

st.pyplot(score_formula_diagram(tokens, scores, D), use_container_width=False)

# ── STEP 6: Softmax ───────────────────────────────────────────────────────────
st.markdown("## Step 6 — Softmax → Attention Weights")

col_a, col_b = st.columns([3, 1])
with col_b:
    st.info(
        "**Row sums**  \n"
        + "  \n".join(
            [f"`{tok}`: **{attn[i].sum():.4f}**" for i, tok in enumerate(tokens)]
        )
    )
with col_a:
    st.markdown(
        r"""
```
attn[i] = softmax(scores[i])   →  all values in [0, 1], row sums to 1
```
Softmax turns *raw scores* into a **probability distribution over tokens**.
Token `i` uses this distribution to decide *how much to listen* to each other token.
"""
    )

# ── STEP 7: Big attention heatmap ─────────────────────────────────────────────
st.markdown("## Step 7 — The Attention Matrix  _(centrepiece)_")

st.markdown(
    "> **Read this matrix:** row = query token, column = key token.  \n"
    "> A bright cell `[i, j]` means token **i** strongly attends to token **j**.  \n"
    "> Each row sums to **1.0**."
)

fig_big = plot_attention_heatmap_large(attn, tokens)
st.pyplot(fig_big, use_container_width=False)

# Highlight the top attending pair
flat_idx = np.unravel_index(np.argmax(attn), attn.shape)
st.success(
    f"**Strongest attention:** `{tokens[flat_idx[0]]}` → `{tokens[flat_idx[1]]}`  "
    f"(weight = {attn[flat_idx]:.3f})"
)

# Per-token top-3 attention
st.markdown("#### Each token's top-3 attended tokens")
rows = []
for i, tok in enumerate(tokens):
    top3_idx = np.argsort(attn[i])[::-1][:3]
    rows.append({
        "Query token": tok,
        "1st": f"{tokens[top3_idx[0]]}  ({attn[i, top3_idx[0]]:.3f})",
        "2nd": f"{tokens[top3_idx[1]]}  ({attn[i, top3_idx[1]]:.3f})",
        "3rd": f"{tokens[top3_idx[2]]}  ({attn[i, top3_idx[2]]:.3f})" if T >= 3 else "—",
    })
st.dataframe(pd.DataFrame(rows).set_index("Query token"), use_container_width=False)

# ── STEP 8: Output ────────────────────────────────────────────────────────────
st.markdown("## Step 8 — Output  =  Attention × V")

col_a, col_b = st.columns([3, 1])
with col_a:
    st.markdown(
        r"""
```
output = attn_weights  @  V        (shape: T × d)
```
Each output row is a **weighted blend of all Value vectors**, weighted by attention.
The token's representation is now *context-aware* — it has absorbed information
from the other tokens it attended to.
"""
    )
with col_b:
    st.info(
        "**Before attention:** each token knew only itself.  \n"
        "**After attention:** `overheated` is enriched with context from "
        "`power`, `supply`, `shutdown`, etc."
    )

fig_out = plot_heatmap(
    output, tokens, dim_labels,
    f"Output  =  Attention × V  ({T} × {D})  — context-aware representations",
    cmap="PuBuGn", row_colors=tok_colors,
)
st.pyplot(fig_out, use_container_width=False)

# ── STEP 9: Summary ───────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("## Step 9 — Full Picture")

st.markdown(
    """
    <div style="background:#f8f9fa;border-left:5px solid #4e79a7;
                border-radius:6px;padding:18px 22px;margin:10px 0">
    <table style="width:100%;border-collapse:collapse">
      <tr style="background:#4e79a7;color:white">
        <th style="padding:8px">Step</th><th style="padding:8px">Operation</th>
        <th style="padding:8px">Shape</th><th style="padding:8px">What it gives you</th>
      </tr>
      <tr><td>1</td><td>Tokenise</td><td>T tokens</td><td>Words → discrete IDs</td></tr>
      <tr style="background:#eef2f7"><td>2</td><td>Embed → X</td><td>T × d</td><td>Each token as a real vector</td></tr>
      <tr><td>3</td><td>Q = X·W_Q</td><td>T × d</td><td>What each token is <em>looking for</em></td></tr>
      <tr style="background:#eef2f7"><td>4</td><td>K = X·W_K</td><td>T × d</td><td>What each token <em>offers</em></td></tr>
      <tr><td>5</td><td>V = X·W_V</td><td>T × d</td><td>The information each token <em>carries</em></td></tr>
      <tr style="background:#eef2f7"><td>6</td><td>scores = QKᵀ/√d</td><td>T × T</td><td>Raw relevance between every pair</td></tr>
      <tr><td>7</td><td>attn = softmax(scores)</td><td>T × T</td><td>Normalised attention distribution</td></tr>
      <tr style="background:#eef2f7"><td>8</td><td>out = attn · V</td><td>T × d</td><td>Context-enriched token representations</td></tr>
    </table>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    **Key insight for  engineers:**
    Every step is a **matrix multiply (GEMM)**.
    GPUs are purpose-built for GEMM → this is why transformers scale so well on  GPU nodes.
    Larger context window = larger T × T attention matrix = more HBM bandwidth required (CXL matters here).
    """,
)

st.caption(
    " GenAI Training"
    "Transformer Internals: Attention Mechanism  |  "
    "Adjust sentence & controls in the sidebar ←"
)

# ── STEP 10: Missing piece — FFN, then Unembedding ────────────────────────────
st.markdown("---")
st.markdown("## Step 10 — The Missing Piece: FFN  +  Unembedding")

st.warning(
    "**⚠️  What a real transformer does between Step 8 and here (skipped in this demo)**\n\n"
    "After the attention output, every transformer block runs a **Feed-Forward Network (FFN / MLP)**:\n\n"
    "```\n"
    "h = GELU( output @ W1 + b1 ) @ W2 + b2     # W1: d→4d,  W2: 4d→d\n"
    "x = LayerNorm( output + h )                 # residual + normalise\n"
    "```\n\n"
    "The FFN is where the model stores **factual knowledge** (the W1/W2 matrices act as a "
    "key-value memory).  It runs independently on each token — no cross-token mixing — "
    "and accounts for ~2/3 of a model's total parameters.  "
    "We skip it here because its output has the same shape `(T × d)` as `output`, "
    "so the unembedding step below looks identical either way."
)

st.markdown(
    r"""
### Unembedding — projecting back to vocabulary space

After `N` transformer blocks (each = Attention + FFN), we take the **last token's**
final hidden vector and multiply by the unembedding matrix `W_U`:

```
logits = output[-1]  @  W_U        # shape: (vocab_size,)
probs  = softmax(logits)           # probability over every word in the vocabulary
```

- `output[-1]` is the last token's context-aware representation — it has "seen" all
  preceding tokens via attention and (in a full model) processed them via FFN.
- `W_U` (shape `d × vocab_size`) maps from model-space back into vocabulary space.
  It is a **learned** matrix — often weight-tied with the input embedding table.
- The highest-probability token is the model's next-word prediction.

---

**⚠️ Are these logits real?  No — they are random noise in this demo.**

Every matrix in the pipeline (`X`, `W_Q`, `W_K`, `W_V`, `W_U`) is sampled from
`np.random.standard_normal(seed)`.  The word that appears top-ranked is a pure
accident of the random seed — change the seed slider and the ranking reshuffles completely.
In a trained model, `W_U` has been adjusted over trillions of tokens so that the dot
product genuinely reflects which word belongs next.

---

**How does dot product → token lookup actually work?**

Each column of `W_U` is a learned *direction* in the model's `d`-dimensional space
that "points toward" one specific vocabulary word.  The dot product

```
logits[j] = dot( output[-1],  W_U[:, j] )
```

measures how strongly the last token's hidden vector aligns with the direction for
word `j`.  High alignment → high logit → that word is a likely next token.

Step by step:

```
1. output[-1]         shape (d,)          — context-enriched vector for last token
2. @ W_U              shape (d, vocab)    — one column per vocabulary word
   = logits           shape (vocab,)      — one score per word

3. probs = softmax(logits)                — convert scores to a probability distribution
                                            (all values 0–1, sum = 1.0)

4. predicted = argmax(probs)             — pick the index with highest probability
5. token = VOCAB[predicted]              — look up that index in the vocabulary list
                                            ← this is the "token lookup"
```

`argmax` is the simplest decoding strategy (greedy).  In practice, models use
**top-k** or **nucleus (top-p) sampling** to pick from the highest-probability
candidates rather than always taking the single best — this produces more natural,
varied text instead of repetitive greedy output.
"""
)

# ── Toy vocabulary (domain-relevant; keeps demo self-contained) ───────────────
VOCAB = [
    "shutdown", "overheated", "temperature", "power", "critical",
    "warning", "normal", "fault", "reboot", "sensor",
    "CPU", "memory", "fan", "alert", "firmware",
    "threshold", "exceeded", "stable", "detected", "failure",
]
VOCAB_SIZE = len(VOCAB)

# ⚠️  W_U is RANDOM here — in a trained model this matrix is learned from data
# and its columns encode "how much does this hidden-state direction vote for word X"
W_U = rng.standard_normal((D, VOCAB_SIZE)) * 0.5

# Take only the last token's hidden vector for next-token prediction
last_hidden = output[-1]                   # shape: (D,)
logits      = last_hidden @ W_U            # shape: (VOCAB_SIZE,)
next_probs  = softmax(logits)              # shape: (VOCAB_SIZE,)

TOP_K = min(8, VOCAB_SIZE)
top_idx   = np.argsort(next_probs)[::-1][:TOP_K]
top_words = [VOCAB[i] for i in top_idx]
top_p     = next_probs[top_idx]

# ── Layout: logits bar + probability bar side by side ─────────────────────────
col_left, col_right = st.columns(2)

with col_left:
    st.markdown(f"#### Raw logits  (`output[-1] @ W_U`)  — last token: `{tokens[-1]}`")
    fig_logits, ax_l = plt.subplots(figsize=(5, 3.5))
    colors_logits = ["#e15759" if v >= 0 else "#4e79a7" for v in logits[top_idx]]
    ax_l.barh(top_words[::-1], logits[top_idx][::-1], color=colors_logits[::-1], edgecolor="white")
    ax_l.axvline(0, color="#999", linewidth=0.8, linestyle="--")
    ax_l.set_xlabel("Logit value", fontsize=9)
    ax_l.set_title("Top-8 raw logits\n(before softmax)", fontsize=10, fontweight="bold")
    ax_l.tick_params(labelsize=9)
    plt.tight_layout()
    st.pyplot(fig_logits, use_container_width=True)

with col_right:
    st.markdown("#### After softmax — next-token probability distribution")
    fig_probs, ax_p = plt.subplots(figsize=(5, 3.5))
    bar_colors = [TOKEN_COLORS[i % len(TOKEN_COLORS)] for i in range(TOP_K)]
    bars = ax_p.barh(top_words[::-1], top_p[::-1], color=bar_colors[::-1], edgecolor="white")
    for bar, p in zip(bars, top_p[::-1]):
        ax_p.text(bar.get_width() + 0.002, bar.get_y() + bar.get_height() / 2,
                  f"{p:.3f}", va="center", fontsize=8)
    ax_p.set_xlim(0, top_p.max() * 1.25)
    ax_p.set_xlabel("Probability", fontsize=9)
    ax_p.set_title("Top-8 next-token probabilities\n(softmax output)", fontsize=10, fontweight="bold")
    ax_p.tick_params(labelsize=9)
    plt.tight_layout()
    st.pyplot(fig_probs, use_container_width=True)

# ── Prediction callout ────────────────────────────────────────────────────────
predicted_token = VOCAB[top_idx[0]]
st.info(
    f"**Predicted next token:** `{predicted_token}`  (p = {top_p[0]:.3f})\n\n"
    f"*Remember: W_U is random in this demo — these probabilities are meaningless.  "
    f"In a trained model (e.g. Llama-3), W_U is learned so that after seeing "
    f'"{" ".join(tokens)}", the highest-probability token would be contextually correct.*'
)

# ── STEP 11: Full pipeline summary including FFN + Unembedding ────────────────
st.markdown("---")
st.markdown("## Step 11 — Complete Transformer Pipeline")

st.markdown(
    """
    <div style="background:linear-gradient(90deg,#1a1a2e,#16213e);
                border-radius:12px;padding:18px 28px;margin:12px 0">
        <p style="color:#aaa;font-size:12px;letter-spacing:1px;margin:0 0 10px 0">
            FULL SINGLE-LAYER BLOCK (repeated N times)
        </p>
        <p style="color:#ffd700;font-size:15px;font-family:monospace;margin:4px 0">
            x &nbsp;→&nbsp; LayerNorm &nbsp;→&nbsp; <b>Multi-Head Attention</b>
            &nbsp;→&nbsp; (+residual)
        </p>
        <p style="color:#ffd700;font-size:15px;font-family:monospace;margin:4px 0">
            &nbsp;&nbsp;→&nbsp; LayerNorm &nbsp;→&nbsp;
            <span style="color:#ff9da7"><b>FFN / MLP</b> ← skipped in this demo</span>
            &nbsp;→&nbsp; (+residual)
        </p>
        <p style="color:#ffd700;font-size:15px;font-family:monospace;margin:4px 0">
            &nbsp;&nbsp;→&nbsp; [repeat N layers, e.g. 32× for Llama-7B]
        </p>
        <p style="color:#ffd700;font-size:15px;font-family:monospace;margin:4px 0">
            &nbsp;&nbsp;→&nbsp; LayerNorm &nbsp;→&nbsp;
            <b>Unembedding (W_U)</b> &nbsp;→&nbsp; softmax &nbsp;→&nbsp;
            <span style="color:#76b7b2">next token ✓</span>
        </p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div style="background:#f8f9fa;border-left:5px solid #59a14f;
                border-radius:6px;padding:18px 22px;margin:10px 0">
    <table style="width:100%;border-collapse:collapse">
      <tr style="background:#59a14f;color:white">
        <th style="padding:8px">Component</th>
        <th style="padding:8px">Operation</th>
        <th style="padding:8px">Shape change</th>
        <th style="padding:8px">Learned weights</th>
      </tr>
      <tr><td>Embedding</td><td>token_id → vector</td><td>T → T × d</td><td>W_E  (vocab × d)</td></tr>
      <tr style="background:#eef2f7"><td>Attention (this demo)</td><td>Q·Kᵀ/√d → softmax → ×V</td><td>T×d → T×d</td><td>W_Q, W_K, W_V</td></tr>
      <tr><td style="color:#e15759;font-weight:600">FFN / MLP ⚠️ skipped</td><td>GELU(x·W1)·W2</td><td>T×d → T×4d → T×d</td><td>W1, W2, b1, b2</td></tr>
      <tr style="background:#eef2f7"><td>Unembedding (this demo)</td><td>last_hidden @ W_U</td><td>d → vocab_size</td><td>W_U  (d × vocab)</td></tr>
      <tr><td>Sampling</td><td>softmax → argmax / top-k</td><td>vocab_size → 1 token</td><td>—</td></tr>
    </table>
    </div>
    """,
    unsafe_allow_html=True,
)

# ═══════════════════════════════════════════════════════════════════════════════
# WHAT HAPPENS NEXT — steps this demo does NOT show
# ═══════════════════════════════════════════════════════════════════════════════
#
# After the attention output (shape T × d) is produced, a full transformer layer
# passes it through two more sub-steps before the result moves to the next layer:
#
# ── 1.  MULTI-LAYER PERCEPTRON  (Feed-Forward Network, FFN) ──────────────────
#
#   output_ffn = GELU( output @ W1 + b1 ) @ W2 + b2
#
#   • Applied *independently* to each token's vector (no cross-token mixing here).
#   • W1 expands the dimension from d → 4d (or higher), W2 projects back to d.
#     This "expand-then-contract" structure lets the network store factual
#     knowledge: research shows individual neurons in W1/W2 can encode specific
#     facts (e.g. "Paris is the capital of France").
#   • Both W1 and W2 are ⚠️ LEARNED weight matrices — the largest share of a
#     transformer's parameters live here (typically ~2/3 of total parameters).
#   • After the FFN, a residual connection (+ LayerNorm) is added, then the
#     result is fed into the next transformer block.
#
#    note: the FFN GEMMs (d → 4d → d) dominate compute at inference time
#   on large models, which is why  GPU nodes with high HBM bandwidth and
#   tensor-core throughput matter more than raw clock speed.
#
# ── 2.  UNEMBEDDING  (final layer only — converts vectors back to token probs) ─
#
#   logits = final_hidden_state @ W_U      (shape: T × vocab_size)
#   probs  = softmax(logits[-1])           (we only care about the LAST token
#                                           when doing next-token prediction)
#
#   • W_U  is the *unembedding matrix* (shape: d × vocab_size).
#     It is the inverse of the token embedding table — it projects from
#     model-dimension space back into vocabulary space.
#   • ⚠️ LEARNED — often tied (shared weights) with the input embedding matrix
#     to reduce parameter count (a technique called "weight tying").
#   • The output is a probability distribution over the entire vocabulary
#     (~32 000 tokens for Llama, ~50 000 for GPT-2).  The next token is
#     sampled from this distribution (greedy, top-k, or nucleus sampling).
#
#   ILO analogy: think of unembedding as translating the model's internal
#   "compressed sensor state" back into a human-readable log message or
#   a specific command token your firmware agent can act on.
#
# ── 3.  RESIDUAL CONNECTIONS  ("skip connections") ──────────────────────────
#
#   x_out = x_in + sublayer(x_in)        ← the "+" is the residual
#
#   • Instead of replacing x_in with the sublayer's output, we ADD the output
#     back to the original input.  The sublayer only needs to learn the
#     *delta* (residual) — a much easier optimisation target.
#
#   • PRIMARY purpose — training stability in deep networks:
#     Gradients can flow directly back through the "+" shortcut path all the
#     way to early layers without passing through every weight matrix.
#     This solves the vanishing-gradient problem that killed deep RNNs.
#     A 96-layer GPT-3 would be untrainable without residual connections.
#
#   • Does it reduce overfitting?  Indirectly, yes — but that is NOT its
#     main job.  The mechanism is:
#       - Training converges faster and to better minima, so you need fewer
#         epochs and less aggressive regularisation.
#       - Deep networks without residuals tend to memorise rather than
#         generalise because gradient signal degrades; residuals keep all
#         layers learning meaningful features.
#     But dedicated anti-overfitting tools (Dropout, weight decay, data
#     augmentation) are separate and are still needed alongside residuals.
#
#   Firmware analogy: think of residuals like a hardware interrupt fallback —
#   if the new logic (sublayer) has nothing important to add, the signal passes
#   through unchanged.  The system is robust to any single layer doing "nothing."
#
# ── 4.  LAYER NORMALISATION  (LayerNorm) ─────────────────────────────────────
#
#   LayerNorm(x) = γ · (x − μ) / (σ + ε)  + β
#
#   where μ, σ are the mean and std computed across the d dimensions of a
#   SINGLE token's vector (not across the batch), γ and β are ⚠️ LEARNED
#   per-dimension scale and shift parameters.
#
#   • PRIMARY purpose — training stability, NOT overfitting prevention:
#     It keeps activations in a well-conditioned range so that weight updates
#     are predictable and learning rates can be set aggressively.
#     Without it, activations explode or vanish as they pass through 96+ layers.
#
#   • Why "Layer" norm and not "Batch" norm?
#     BatchNorm normalises across the batch dimension — fine for fixed-size
#     image grids, but sequences vary in length and batch size 1 (at inference)
#     makes batch statistics meaningless.  LayerNorm normalises within each
#     token vector independently, so it works at any batch size, including 1.
#     This matters enormously for autoregressive inference on an HPE server
#     handling single-request firmware queries.
#
#   • Does it reduce overfitting?  Only as a side-effect:
#     Normalised activations act as mild implicit regularisation (similar to
#     how BatchNorm does), but the effect is small.  Dropout (randomly zeroing
#     activations during training) is the transformer's main anti-overfitting
#     mechanism and is applied separately.
#
#   • Pre-LN vs Post-LN placement:
#     Original "Attention Is All You Need" paper used Post-LN:
#       x → sublayer → (+residual) → LayerNorm
#     Modern models (GPT-2 onward, Llama) use Pre-LN:
#       x → LayerNorm → sublayer → (+residual)
#     Pre-LN is more stable at the start of training (no "warm-up" LR tricks
#     needed) and is now the default in production transformer implementations.
#
# ── Full single-layer transformer block (summary) ────────────────────────────
#
#   x  →  LayerNorm  →  Multi-Head Attention  →  (+residual)   ← Pre-LN style
#      →  LayerNorm  →  FFN (MLP)             →  (+residual)
#      →  [repeat N times, e.g. 32 layers for Llama-7B]
#      →  LayerNorm  →  Unembedding  →  softmax  →  next token
#
#   Quick summary of what each component actually solves:
#   ┌─────────────────────┬──────────────────────────────┬─────────────────────┐
#   │ Component           │ Primary purpose              │ Overfitting impact  │
#   ├─────────────────────┼──────────────────────────────┼─────────────────────┤
#   │ Residual connection │ Vanishing gradient fix       │ Indirect / small    │
#   │ LayerNorm           │ Activation scale stability   │ Indirect / small    │
#   │ Dropout             │ Regularisation               │ Direct / large      │
#   │ Weight decay        │ Regularisation               │ Direct / large      │
#   └─────────────────────┴──────────────────────────────┴─────────────────────┘
#
# ═══════════════════════════════════════════════════════════════════════════════
