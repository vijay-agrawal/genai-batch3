# ====================================
# WHAT IS ÖPIK?
#
# Öpik is a powerful logging and observability tool built for tracking
# and evaluating LLM (Language Model) workflows and other AI-powered
# applications. It is designed to:
#
# 1. Track function calls with the `@track` decorator
#    - This means it logs inputs, outputs, execution time, and more for each tracked function.
# 2. Evaluate the quality of model outputs using built-in LLM scoring.
#    - You can automatically score responses based on helpfulness, accuracy, and other criteria.
# 3. Visualize the performance, usage, and errors in an interactive dashboard.
#    - This allows you to monitor how your models behave, detect issues, and optimize performance.
#
# By integrating Öpik into your code (as shown below), you get:
# - Real-time logging of all important function calls.
# - Automatic trace tracking without additional effort.
#
# To use Öpik, you need an API Key and a Workspace. These can be obtained
# from the Öpik dashboard by signing up/logging in at https://www.comet.com.
#
# Read below for how to get your Öpik API Key and Workspace:
#
# 1. Sign up or log in to Öpik (https://www.comet.com).
# 2. In the top-right corner, click on **Profile → API Keys** and copy your key.
# 3. On the dashboard, your **Workspace name** will be visible in the top-left corner.
#    - Example: "riyabangera999".
#
# These details are required to set up your environment and track logs.
# ====================================

# ====================================
# STEP 1: Import necessary libraries
# ====================================
import os
from pathlib import Path
from dotenv import load_dotenv
import streamlit as st

# LangChain AWS SDK for Bedrock
from langchain_aws import ChatBedrock
from langchain_core.messages import HumanMessage, SystemMessage

# Öpik tracking decorator
from opik import track

# ====================================
# STEP 2: Set up Öpik API Key and Workspace
#
# 👉 HOW TO GET YOUR API KEY:
# 1. Go to https://www.opik.ai
# 2. Log in or sign up with email / GitHub / Google
# 3. On the top right, click your profile icon → "API Keys"
# 4. Copy your API key
#
# 👉 HOW TO GET YOUR WORKSPACE NAME:
# 1. It's shown in the top-left corner of your Öpik dashboard
# 2. Example: "riyabangera999"
#
# You can paste your values directly here or use a .env file
# ====================================
os.environ["OPIK_API_KEY"] = ""  # Replace with your actual Öpik API Key
os.environ["OPIK_WORKSPACE"] = ""          # Replace with your actual workspace name

# ====================================
# STEP 3: Load AWS Bedrock config from .env
# Your .env file should include:
# - AWS_ACCESS_KEY_ID
# - AWS_SECRET_ACCESS_KEY
# - AWS_REGION
# - BEDROCK_MODEL_ID
# ====================================

# Locate .env up to 2 levels up from this file
_here = Path(__file__).resolve().parent
_env_path = next(
    (p / ".env" for p in (_here, _here.parent, _here.parent.parent) if (p / ".env").is_file()),
    None,
)
if _env_path is None:
    print("ERROR: .env file not found in this directory or up to 2 levels up.", flush=True)
    raise SystemExit(1)
load_dotenv(_env_path)

# ====================================
# STEP 4: Streamlit UI Header
# ====================================
st.subheader("HPE GenAI Training: Öpik + AWS Bedrock Chatbot Demo")

with st.sidebar:
    st.subheader("🔑 AWS Bedrock Config")
    st.code(
        f"Region: {os.getenv('AWS_REGION', 'not set')}\n"
        f"Model:  {os.getenv('BEDROCK_MODEL_ID', 'not set')}",
        language=None,
    )

# ====================================
# STEP 5: AWS Bedrock LLM Call
# This function is decorated with @track from Öpik.
# All inputs, outputs, and performance are automatically logged.
# ====================================
@track
def generate_response(input_text: str) -> str:
    # Initialize Bedrock client using LangChain wrapper
    llm = ChatBedrock(
        model_id=os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0"),
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        model_kwargs={"temperature": 0},
    )

    messages = [
        SystemMessage(content="You are a helpful AI assistant. Be concise and friendly."),
        HumanMessage(content=input_text),
    ]

    response = llm.invoke(messages).content

    # Streamlit UI updates
    st.info("**Response:**")
    st.success(response)

    return response  # This return is also logged by Öpik

# ====================================
# STEP 6: User interaction in Streamlit
# Captures input and triggers Bedrock call.
# Everything is auto-tracked by Öpik due to @track.
# ====================================
user_question = st.text_input("Ask any question. Press enter to submit", key="user_question")

if user_question:
    generate_response(user_question)
