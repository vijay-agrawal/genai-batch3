import os
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv


def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env or google-vertexai-serviceaccount-key.json in any parent directory.")
    print(f"Started searching from: {Path(__file__).resolve().parent}")
    exit(1)


# Find project root for loading .env
PROJECT_ROOT = _find_project_root()

## Obtain the endpoint and API key, API version from the "Details" tab in the Azure Foundry portal > Models.
def validate_environment_variables():
    """Validate that all required environment variables are loaded from .env file."""
    required_env_vars = [
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_MODEL_NAME",
    ]

    missing_vars = [var for var in required_env_vars if not os.getenv(var)]

    if missing_vars:
        print("ERROR: Missing required environment variables:")
        for var in missing_vars:
            print(f"  - {var}")
        print("\nPlease ensure all required variables are set in your .env file.")
        exit(1)

    print("✓ All required environment variables are loaded successfully.")


def query_azure_openai(prompt):
    """Query Azure OpenAI API with the given prompt."""
    client = OpenAI(
        base_url=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    )
    model_name = os.getenv("AZURE_OPENAI_MODEL_NAME")

    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": "You are a helpful AI assistant"},
                {"role": "user", "content": prompt}
            ]
        )
        answer = response.choices[0].message.content.strip()
    except Exception as e:
        print(f"ERROR: {e}")
        return None

    print("Prompt:")
    print(prompt)
    print("Response from LLM:")
    print(answer)
    return answer

### MAIN EXECUTION ###

load_dotenv(PROJECT_ROOT / ".env")
validate_environment_variables()
prompt = 'What is the capital of France?'
query_azure_openai(prompt)


###  Exercise: Try with diffferent prompts. Recommended prompts:
### 1. "Who won the latest cricket world cup?"
### 2. "When were the most recent Bihar Vidhan Sabha elections held?"    
### 3. "What is the current weather in Mumbai?"    

## Can you explain why some prompts work and some don't?
## Note: The model's knowledge cutoff date and the nature of the data it was trained on can affect its ability to answer certain questions, especially those related to recent events or real-time information.
## See: https://github.com/HaoooWang/llm-knowledge-cutoff-dates
