import os
import uuid
from pathlib import Path

import chromadb
import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

if not os.getenv("AZURE_OPENAI_ENDPOINT") or not os.getenv("AZURE_OPENAI_API_KEY"):
    st.markdown('<div style="color:#fff;background:#1a3a5c;padding:12px;border-radius:6px">⚠️ AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY must be set in your .env file.</div>', unsafe_allow_html=True)
    st.stop()

st.set_page_config(layout="wide")
st.subheader("Semantic Memory Chatbot — Relevant Context via Vector Search")


@st.cache_resource
def get_clients():
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
    chat_client = OpenAI(base_url=endpoint, api_key=api_key)
    embed_client = OpenAI(base_url=endpoint, api_key=api_key)
    chroma = chromadb.EphemeralClient()
    return chat_client, embed_client, chroma


chat_client, embed_client, chroma_client = get_clients()

# --- Session state ---
if "history" not in st.session_state:
    st.session_state.history = []
if "msg_counter" not in st.session_state:
    st.session_state.msg_counter = 0
if "collection_name" not in st.session_state:
    st.session_state.collection_name = f"session_{uuid.uuid4().hex[:8]}"
if "last_context" not in st.session_state:
    st.session_state.last_context = {"relevant": [], "total": 0, "query": ""}
if "active_system_prompt" not in st.session_state:
    st.session_state.active_system_prompt = (
        "You are a helpful AI assistant. Answer questions truthfully and conversationally."
    )


# --- ChromaDB helpers ---
def get_collection():
    try:
        return chroma_client.get_collection(st.session_state.collection_name)
    except Exception:
        return chroma_client.create_collection(
            name=st.session_state.collection_name,
            metadata={"hnsw:space": "cosine"},  # cosine similarity for text embeddings
        )


def embed(text: str) -> list:
    resp = embed_client.embeddings.create(
        model=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME", "text-embedding-3-small"),
        input=text,
    )
    return resp.data[0].embedding


def store_message(msg_id: str, content: str, role: str, index: int):
    get_collection().add(
        ids=[msg_id],
        embeddings=[embed(content)],
        documents=[content],
        metadatas=[{"role": role, "index": index}],
    )


def retrieve_relevant(query: str, top_k: int) -> list:
    col = get_collection()
    if col.count() == 0:
        return []
    results = col.query(
        query_embeddings=[embed(query)],
        n_results=min(top_k, col.count()),
        include=["documents", "metadatas", "distances"],
    )
    msgs = []
    for doc, meta, dist in zip(
        results["documents"][0], results["metadatas"][0], results["distances"][0]
    ):
        # cosine distance = 1 - cosine_similarity, so similarity = 1 - distance
        msgs.append({
            "role": meta["role"],
            "content": doc,
            "index": meta["index"],
            "similarity": round(1 - dist, 3),
        })
    msgs.sort(key=lambda x: x["index"])  # restore chronological order
    return msgs


# --- Layout ---
chat_col, info_col = st.columns([3, 2])

with info_col:
    st.markdown("### System Prompt")
    system_prompt_input = st.text_area(
        "system_prompt",
        value=st.session_state.active_system_prompt,
        height=120,
        label_visibility="collapsed",
    )
    btn1, btn2 = st.columns(2)
    with btn1:
        if st.button("Apply Prompt", type="primary", use_container_width=True):
            st.session_state.active_system_prompt = system_prompt_input
            st.success("Applied!")
    with btn2:
        if st.button("Clear Chat", use_container_width=True):
            st.session_state.history = []
            st.session_state.msg_counter = 0
            st.session_state.collection_name = f"session_{uuid.uuid4().hex[:8]}"
            st.session_state.last_context = {"relevant": [], "total": 0, "query": ""}
            st.rerun()

    top_k = st.slider("Top-K messages to retrieve", min_value=1, max_value=15, value=5)

    st.markdown("---")
    st.markdown("### Messages Sent to LLM")

    ctx = st.session_state.last_context
    if ctx["relevant"]:
        query_preview = ctx["query"][:55] + "…" if len(ctx["query"]) > 55 else ctx["query"]
        st.caption(
            f"**{len(ctx['relevant'])}** of **{ctx['total']}** history messages retrieved  \n"
            f"Query: _{query_preview}_"
        )
        for msg in ctx["relevant"]:
            role_icon = "👤" if msg["role"] == "user" else "🤖"
            label = f"{role_icon} {msg['role'].capitalize()} · similarity {msg['similarity']:.3f}"
            with st.expander(label, expanded=True):
                st.write(msg["content"])
    elif st.session_state.history:
        st.info("Send another message to see which history is retrieved.")
    else:
        st.info("Start chatting. Only semantically relevant history will be sent to the LLM.")

with chat_col:
    st.markdown("### Chat")
    for msg in st.session_state.history:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

    user_question = st.chat_input("Ask me anything…")

# --- Handle new message (outside columns so rerun redraws both) ---
if user_question:
    # 1. Retrieve relevant history BEFORE adding the current message
    relevant = retrieve_relevant(user_question, top_k=top_k)
    total_history = len(st.session_state.history)

    # 2. Store current user message in ChromaDB and history
    msg_id = uuid.uuid4().hex
    store_message(msg_id, user_question, "user", st.session_state.msg_counter)
    st.session_state.msg_counter += 1
    st.session_state.history.append({"role": "user", "content": user_question})

    # 3. Build LLM payload: system prompt + relevant history + current question
    llm_messages = [{"role": "system", "content": st.session_state.active_system_prompt}]
    for m in relevant:
        llm_messages.append({"role": m["role"], "content": m["content"]})
    llm_messages.append({"role": "user", "content": user_question})

    # 4. Save context for the right-panel display
    st.session_state.last_context = {
        "relevant": relevant,
        "total": total_history,
        "query": user_question,
    }

    # 5. Call the LLM
    try:
        api_response = chat_client.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
            messages=llm_messages,
        )
        response = api_response.choices[0].message.content.strip()
    except Exception as e:
        response = f"Sorry, I encountered an error: {e}"

    # 6. Store assistant response in ChromaDB and history
    resp_id = uuid.uuid4().hex
    store_message(resp_id, response, "assistant", st.session_state.msg_counter)
    st.session_state.msg_counter += 1
    st.session_state.history.append({"role": "assistant", "content": response})

    st.rerun()
