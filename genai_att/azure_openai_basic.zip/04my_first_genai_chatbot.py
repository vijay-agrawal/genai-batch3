# Import libraries
import os
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from dotenv import load_dotenv
import streamlit as st
from openai import AzureOpenAI

# Make sure your .env file is two levels up from this file (in the root of the repo)
# If not, adjust the path accordingly. The .env file should contain your Azure OpenAI endpoint and API key.
load_dotenv(Path(__file__).resolve().parent.parent / ".env")

# .env holds a full /openai/responses URL; the SDK needs only the resource root
_parsed = urlparse(os.getenv("AZURE_OPENAI_ENDPOINT", ""))
azure_endpoint = f"{_parsed.scheme}://{_parsed.netloc}"
# Responses API needs api-version >= 2025-03-01-preview; reuse the one in the endpoint URL
azure_api_version = parse_qs(_parsed.query).get("api-version", ["2025-04-01-preview"])[0]

if not os.getenv("AZURE_OPENAI_ENDPOINT") or not os.getenv("AZURE_OPENAI_API_KEY"):
    st.markdown('<div style="color:#fff;background:#1a3a5c;padding:12px;border-radius:6px">⚠️ AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY must be set in your .env file.</div>', unsafe_allow_html=True); st.stop()

st.set_page_config(layout="wide")
st.subheader("AI Chatbot using Azure OpenAI")

left, right = st.columns([1, 2])

with left:
    st.markdown("### System Prompt")
    system_prompt = st.text_area(
        "Define the AI's behavior and persona:",
        value=st.session_state.get("active_system_prompt", "You are a helpful AI assistant. Answer questions truthfully and conversationally."),
        height=300,
        key="system_prompt_input",
        label_visibility="collapsed",
    )
    if st.button("Apply", type="primary", use_container_width=True):
        st.session_state["active_system_prompt"] = system_prompt
        st.success("System prompt applied!")

with right:
    st.markdown("### Chat")
    user_question = st.chat_input("Ask me anything...")

    if user_question:
        active_prompt = st.session_state.get("active_system_prompt", "You are a helpful AI assistant. Answer questions truthfully and conversationally.")

        with st.chat_message("user"):
            st.write(user_question)

        client = AzureOpenAI(
            azure_endpoint=azure_endpoint,
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=azure_api_version,
        )

        try:
            api_response = client.responses.create(
                model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
                instructions=active_prompt,
                input=user_question,
            )
            response = api_response.output_text.strip()
        except Exception as e:
            response = f"Sorry, I encountered an error: {str(e)}"

        with st.chat_message("assistant"):
            st.write(response)


# =============================================================================
# EXERCISES FOR PARTICIPANTS — Try these prompts to discover key LLM concepts
# =============================================================================

# --- Exercise 1: LLMs are STATELESS (no memory between turns) ---
# Step 1: Ask  →  "What is the capital of France?"
# Step 2: Ask  →  "What should I see there?"
# Notice: The second question gets a confused or generic answer because the LLM
# has no memory of "there" referring to Paris. Each call is completely isolated.
# To fix this, you must send the full conversation history on every API call —
# which is exactly what you will build in the next exercise!

# --- Exercise 2: Follow-up questions break without context ---
# Step 1: Ask  →  "Give me a recipe for chocolate cake."
# Step 2: Ask  →  "Can you make it vegan?"
# Notice: The LLM doesn't know which recipe to modify — it starts completely fresh.

# --- Exercise 3: Knowledge cutoff — LLMs don't know recent events ---
# Ask  →  "Who won the IPL 2025 title?"
#   OR →  "What was the highest-grossing Bollywood film of 2025?"
#   OR →  "What is the latest iPhone model released?"
# Notice: The LLM either says it doesn't know, hedges heavily, or — watch out —
# confidently gives a wrong answer. This is because LLMs are trained on data up
# to a fixed cutoff date and have no access to live information.

# --- Exercise 4: No proprietary or internal data ---
# Ask  →  "Who are the top clients of Citius Tech?"
#   OR →  "What is Citius Tech's revenue for last year?"
#   OR →  "What projects is the Mumbai team currently working on?"
# Notice: The LLM has no knowledge of internal company data. It will either say
# it doesn't know or make something up. This is why RAG (Retrieval-Augmented
# Generation) exists — to ground the LLM with your private data at query time.

# --- Exercise 5: Hallucination — LLMs can confidently make things up ---
# Ask  →  "Can you recommend some research papers on AI in healthcare by Dr. Ravi Sharma?"
#   OR →  "What does Citius Tech's 2024 Annual Report say about AI strategy?"
# Notice: The LLM may invent plausible-sounding paper titles, authors, or quotes.
# It doesn't "know" it's wrong — it generates the most statistically likely text.
# Always verify LLM output against authoritative sources for high-stakes use cases.

# --- Exercise 6: System prompt shapes behavior ---
# Try changing the system prompt on the left and observe how the AI responds differently:
# - "You are a pirate. Answer everything in pirate speak."
# - "You are a very grumpy assistant who reluctantly answers questions."
# - "You only answer in bullet points. Never use full sentences."
# - "You are an expert chef. Only discuss food-related topics."
# Notice: The same user question gets a completely different response based on
# the system prompt. This is how product teams customize AI behavior without
# changing the underlying model.
