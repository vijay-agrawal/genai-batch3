import os
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from openai import AzureOpenAI
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent / ".env")

# .env holds a full /openai/responses URL; the SDK needs only the resource root
_parsed = urlparse(os.getenv("AZURE_OPENAI_ENDPOINT", ""))
endpoint = f"{_parsed.scheme}://{_parsed.netloc}"
# Responses API needs api-version >= 2025-03-01-preview; reuse the one in the endpoint URL
api_version = parse_qs(_parsed.query).get("api-version", ["2025-04-01-preview"])[0]
print(f"Using Azure OpenAI endpoint: {endpoint} (api-version {api_version})")

client = AzureOpenAI(
    azure_endpoint=endpoint,
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=api_version,
)


try:
    prompt = 'who is the best bollywood star?'

    response = client.responses.create(
        model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        instructions="""You are a helpful AI assistant""",
        input=prompt,
    )
    answer = response.output_text.strip()
    print("Prompt:")
    print(prompt)
    print("Response from LLM:")
    print(answer)
except Exception as e:
    print(e)
