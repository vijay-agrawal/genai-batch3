import os
import requests
from typing import TypedDict, Annotated

from dotenv import load_dotenv
from langchain_core.tools import tool
from langchain_core.messages import BaseMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from langchain_openai import AzureChatOpenAI

load_dotenv()

# ---------------------------------------------------------------------------
# How this differs from 01langgraph_simple_weatheragent.py
# ---------------------------------------------------------------------------
# simple_weatheragent uses langchain.agents.create_agent(), a prebuilt ReAct
# loop: LLM -> (tool calls?) -> tool -> LLM -> ... -> END. That loop shape is
# fixed by the library. You can swap the model/tools/prompt, but you cannot
# add a node, add a branch, or make the routing depend on anything other than
# "did the LLM call a tool or not".
#
# This file builds the same LLM<->tool loop explicitly with StateGraph, so
# the assistant node and the routing function are ordinary Python you fully
# control. That means routing can react to the actual content of state, not
# just "tool_calls present or not" - i.e. dynamic reasoning drives which
# branch executes next, not a hardcoded sequence.
#
# Concrete example - branching on tool errors:
# get_weather() can fail in two different ways: an unknown/ambiguous location
# ("Could not find coordinates for 'Springfield'") vs. a live API outage
# (HTTP error). With create_agent() both failures look identical to the
# framework: they're just a ToolMessage, so the LLM always loops back through
# the same fixed path and has to improvise a response from raw text.
#
# With the explicit graph here, route_after_assistant (or a router placed
# after the tool node) can inspect the ToolMessage content and branch
# differently per failure type, e.g.:
#
#   def route_after_tools(state: AgentState):
#       last_message = state["messages"][-1]
#       if "Could not find coordinates" in last_message.content:
#           return "ask_clarifying_question"   # -> node that asks the user
#                                               #    to confirm city/country
#       if "API key is missing" in last_message.content:
#           return "fallback_static_advice"    # -> node that skips the LLM
#                                               #    entirely and returns a
#                                               #    canned "service unavailable"
#                                               #    reply, saving a model call
#       return "assistant"                     # normal case: let the LLM
#                                               #    read the result and answer
#
#   graph.add_conditional_edges("tools", route_after_tools)
#
# Each of "ask_clarifying_question" and "fallback_static_advice" is a plain
# node you add to the graph - something create_agent()'s fixed loop has no
# hook for. This is the "fine-grained control over tool execution patterns"
# and "custom routing" called out below.
# ---------------------------------------------------------------------------

# LangGraph supports a highly flexible and extensible low-level orchestration framework for
# long-running, stateful agents, with capabilities like durable execution, streaming, human-in-the-loop,
# persistence, and custom workflows that mix deterministic and agentic steps.

# By making tools first-class citizens in the graph, and separating the concerns of reasoning and execution, 
# we can create agents that seamlessly integrate LLM reasoning with tool execution,
# and have fine-grained control over the flow of information and execution between them.
# TypedDict / StateGraph / ToolNode are all optional components that can be used to build agents in a more structured way, 

# Here, we define the components (tools, state, model) and then connect them in a graph.
# This allows for more flexible and customizable agent designs, beyond the traditional LLM + tool agent structure.
# For a more traditional agent structure, we can create a simple graph with an LLM node and a tool node, 
# and route between them based on whether the LLM calls a tool or not.
# This separation of "thinking" (LLM) and "acting" (tool calls) is a common pattern in agent design, 
# and langgraph's graph-based approach allows us to implement it in a clean and modular way.


# So with LangGraph, 
# ┌───────────────┐
# │    START      │
# └──────┬────────┘
#        │
#        v
# ┌─────────────────────────────┐
# │ 1) LLM / Assistant Node     │
# │ - read current state        │
# │ - invoke model              │
# │ - append AI response)       │
# └──────────┬──────────────────┘
#            │
#            v
# ┌─────────────────────────────┐
# │ 2) Router / Conditional Edge│
# │ - inspect last AI message   │
# │ - does it contain tool_calls?│
# └───────┬───────────────┬─────┘
#         │ yes           │ no
#         v               v
# ┌──────────────────┐   ┌───────────────┐
# │ 3) Tool Node     │   │ 5) END        │
# │ - execute tools  │   │ - final answer│
# │ - append results │   │   already in  │
# │   as ToolMessage │   │   state       │
# └────────┬─────────┘   └───────────────┘
#          │
#          v
# ┌─────────────────────────────┐
# │ 4) Edge back to LLM node    │
# │ - model sees tool results   │
# │ - may answer or call tools  │
# │   again                     │
# └──────────┬──────────────────┘
#            │
#            └──── loop to step 1
#

# Use this low leverl orchestration framework when:
# you need fine-grained control over tool execution patterns
# you need custom routing
# you need deterministic steps before or after agent steps
# you need branching / loops / map-reduce / subgraphs
# you need human approval checkpoints
# you need checkpointing, resume, time-travel debugging, or fault-tolerant long runs
# you need multiple agents or reusable subgraphs

# ---------------------------------------------------------------------------
# Q: There's no `Agent` class here - just an LLM node and a tool node. So how
#    does "memory" get tied to "a group of tools", and how do tools get
#    grouped under one functionality? Do LLM nodes just behave like an Agent?
#    How would you compose "one agent, multiple tools" further?
# ---------------------------------------------------------------------------
# Short answer: "Agent" in LangGraph isn't a class you instantiate - it's a
# NAME FOR A PATTERN: (LLM bound to some tools) <-> (node that executes those
# same tools), wired in a loop by a router. Everything that "belongs to" an
# agent is plain Python association you wire yourself, not a framework link:
#
# - Tool grouping ("which tools does this agent have?") is nothing but the
#   Python list you build and pass to two places that must stay in sync:
#     tools = [get_weather]              <- the group
#     llm.bind_tools(tools)              <- what the LLM is allowed to call
#     ToolNode(tools)                    <- what the executor is able to run
#   There's no registry connecting them for you - see `tools`, `llm_with_tools`,
#   and `tool_node` further down. Add a tool to one list and forget the other
#   and the LLM can request something the ToolNode can't run, or vice versa.
#
# - Memory is NOT attached to a group of tools at all - it's attached to the
#   GRAPH STATE (AgentState.messages below), which every node - LLM or tool -
#   reads and writes through the same reducer (add_messages). Memory lives at
#   the graph/thread level, not the "agent" level. That's why this agent has
#   no private memory of its own: the tool node and the LLM node are two
#   functions sharing one mutable state object threaded through the graph by
#   LangGraph's runtime. Memory that survives across separate `.invoke()`
#   calls (multi-turn chat) comes from a checkpointer
#   (`graph.compile(checkpointer=...)`); memory that survives across
#   different threads/sessions comes from LangGraph's long-term `Store`.
#   Both are graph-level concerns - still nothing to do with which tools exist.
#
# - Yes: the LLM node behaves AS the agent. Concretely, "an agent" here =
#     one system prompt (role/goal/backstory, see assistant_node)
#   + one LLM instance bound to one tool list (llm_with_tools)
#   + one ToolNode running that same tool list
#   + one router that loops between them until no more tool_calls.
#   That whole closed loop (assistant <-> tools, steps 1-4 in the diagram
#   above) is "one agent". create_agent() in 01langgraph_simple_weatheragent.py
#   builds this exact loop under the hood; here you build it by hand, which
#   is why it looks like "just nodes" instead of an Agent object.
#
# - Composition ("one agent, multiple tools") is exactly what's below: many
#   tools, one list, one bind_tools() call, one ToolNode. To compose further:
#     * More tools for the SAME agent -> add them to `tools` (one list, one
#       functional area). The LLM alone decides which of the N tools to call.
#     * Multiple DIFFERENT agents (e.g. a weather specialist + a calendar
#       specialist), each with its own tool group and its own memory-shaping
#       logic -> build each as its own compiled StateGraph (own assistant
#       node + own ToolNode + own bound tool list), then add each COMPILED
#       GRAPH as a single node inside an outer graph:
#         outer.add_node("weather_agent", weather_app)   # weather_app = a
#         outer.add_node("calendar_agent", calendar_app) # compiled subgraph
#       with a supervisor/router LLM node in the outer graph deciding which
#       specialist node runs next. Each subgraph keeps its own tool list and
#       (optionally) its own state schema, so both tool grouping and memory
#       scoping become explicit per-subgraph choices, not framework magic.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Q: Given memory is "just" shared graph state, how do you actually ISOLATE
#    one agent's memory from another's ("agent specificity") once you have
#    multiple agents? By default everything sharing a graph shares its state.
# ---------------------------------------------------------------------------
# There's no isolation unless you deliberately engineer it. Three independent
# knobs, usually combined:
#
# 1) STRUCTURAL isolation - different state SCHEMA per subgraph.
#    A compiled subgraph can define its own State TypedDict that's totally
#    different from the parent's. LangGraph only shares data between parent
#    and child for KEYS THEY HAVE IN COMMON:
#      - Same key name/type in both (e.g. both use `messages`) -> that key
#        flows through automatically when you do
#        outer.add_node("weather_agent", weather_app) and the two agents'
#        histories merge into one shared thread. This is "shared memory".
#      - Different/private keys (e.g. weather_app has an internal
#        `geocode_cache` the calendar agent never sees) -> those never leave
#        the subgraph. To keep an agent's internal scratchpad fully private,
#        don't add the compiled subgraph directly as a node - wrap it:
#          def weather_agent_node(state: OuterState):
#              # translate outer state -> the subgraph's own isolated input
#              sub_result = weather_app.invoke({"messages": state["messages"]})
#              # pull out only what the outer graph is allowed to see, e.g.
#              # the last AI message - sub_result's internal keys are dropped
#              return {"messages": [sub_result["messages"][-1]]}
#          outer.add_node("weather_agent", weather_agent_node)
#        This function boundary IS the isolation mechanism - whatever you
#        don't return, the rest of the graph never sees.
#
# 2) PARTITIONED isolation within ONE shared schema - separate keys, not
#    separate graphs. If both agents live in the same StateGraph, give each
#    its own key instead of a shared `messages` list:
#      class OuterState(TypedDict):
#          weather_messages: Annotated[list[BaseMessage], add_messages]
#          calendar_messages: Annotated[list[BaseMessage], add_messages]
#      Each agent node only reads/writes its own key -> agent-specific
#      memory without ever leaving the single graph. Cheaper than subgraphs
#      when you don't need each agent independently testable/reusable.
#
# 3) PERSISTENCE isolation - thread_id / namespace, for memory that outlives
#    a single .invoke() call:
#      - Short-term (per-conversation) memory: `graph.compile(checkpointer=...)`
#        persists AgentState keyed by `config["configurable"]["thread_id"]`.
#        Two agents sharing a checkpointer but invoked with DIFFERENT
#        thread_ids get fully isolated persisted histories; same thread_id
#        means shared/merged history. Isolation here = which thread_id you
#        pass in at call time, nothing structural.
#      - Long-term (cross-conversation) memory: LangGraph's `Store`
#        (e.g. InMemoryStore) organizes facts under a NAMESPACE tuple, e.g.
#        store.put(("weather_agent", user_id), key, value) vs.
#        store.put(("calendar_agent", user_id), key, value). Agent-specificity
#        here is purely the namespace convention you choose - the Store
#        enforces nothing about which agent "owns" a namespace, it's just a
#        lookup key you're disciplined about.
#
# None of this file currently needs it - with a single agent there's only one
# state to share with itself. The moment you add a second specialist (a
# calendar agent, say), you must pick one of (1)/(2)/(3) on purpose, or the
# two agents will silently read/write each other's conversation history.
# ---------------------------------------------------------------------------

# ---------------------------
# 1) Tool
# ---------------------------
@tool
def get_weather(location: str) -> str:
    """
    Retrieve current weather information for a location using OpenWeatherMap.
    """
    api_key = os.getenv("OPENWEATHERMAP_API_KEY")
    if not api_key:
        return "OpenWeatherMap API key is missing."

    # Step 1: geocode location
    geo_url = "http://api.openweathermap.org/geo/1.0/direct"
    geo_resp = requests.get(
        geo_url,
        params={"q": location, "limit": 1, "appid": api_key},
        timeout=20,
    )
    geo_resp.raise_for_status()
    geo_data = geo_resp.json()

    if not geo_data:
        return f"Could not find coordinates for '{location}'."

    lat = geo_data[0]["lat"]
    lon = geo_data[0]["lon"]

    # Step 2: current weather
    weather_url = "https://api.openweathermap.org/data/3.0/onecall"
    weather_resp = requests.get(
        weather_url,
        params={"lat": lat, "lon": lon, "appid": api_key, "units": "metric"},
        timeout=20,
    )
    weather_resp.raise_for_status()
    data = weather_resp.json()

    current = data.get("current", {})
    weather_list = current.get("weather", [])
    description = weather_list[0]["description"] if weather_list else "No description"
    humidity = current.get("humidity", "NA")
    uvi = current.get("uvi", "NA")
    temp = current.get("temp", "NA")
    feels_like = current.get("feels_like", "NA")

    return (
        f"Weather for {location}: {description}. "
        f"Temperature: {temp}°C, feels like {feels_like}°C, "
        f"humidity: {humidity}%, UV index: {uvi}."
    )

# This list IS the "tool group" - there is no Agent object holding it.
# It gets handed to two independent places (llm.bind_tools below, and
# ToolNode here) that must agree on its contents; LangGraph doesn't enforce
# that agreement for you.
tools = [get_weather]
tool_node = ToolNode(tools)

# ---------------------------
# 2) State
# ---------------------------
# This is where "memory" actually lives - not on the tools, not on the LLM,
# but on the graph state that flows through every node. Both assistant_node
# and tool_node read/append to the same `messages` list via add_messages.
class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]

# ---------------------------
# 3) Model
# ---------------------------
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    temperature=0,
)

# Binding `tools` to this specific `llm` instance is the actual moment this
# LLM node "becomes" a weather agent - it's just a closure capturing which
# tool schemas get sent to the model, nothing more structural than that.
llm_with_tools = llm.bind_tools(tools)

# ---------------------------
# 4) LLM node
# ---------------------------
# assistant_node + llm_with_tools (its bound tools) + tool_node (the executor
# for those same tools) + route_after_assistant (the loop below) together ARE
# "the agent". There's no separate Agent object to point to - the pattern
# itself, once closed into a loop, is what LangGraph/LangChain call an agent.
def assistant_node(state: AgentState):
    role = "Weather specialist"
    goal = "Provide accurate current weather answers using live tools"
    backstory = "You are a careful meteorological assistant that never invents real-time conditions"
    
    system_prompt = f"""
        Role: {role}
        Goal: {goal}
        Backstory: {backstory}
        Rules:
        - Answer only weather-related questions.
        - Use tools for live weather.
        - If the tool fails, explain the limitation clearly.
    """
    
    system_message = {
        "role": "system",
        "content": system_prompt
    }

    response = llm_with_tools.invoke(
        [system_message] + 
        state["messages"])
    
    return {"messages": [response]}

# ---------------------------
# 5) Router
# ---------------------------
def route_after_assistant(state: AgentState):
    last_message = state["messages"][-1]
    if getattr(last_message, "tool_calls", None):
        return "tools"
    return END

# ---------------------------
# 6) Graph
# ---------------------------
graph = StateGraph(AgentState)

graph.add_node("assistant", assistant_node)
graph.add_node("tools", tool_node)

graph.set_entry_point("assistant")
graph.add_conditional_edges("assistant", route_after_assistant)
graph.add_edge("tools", "assistant")

app = graph.compile()

# ---------------------------
# 7) Run
# ---------------------------
if __name__ == "__main__":
    result = app.invoke(
        {
            "messages": [
                {"role": "user", "content": "How is the weather in Mumbai?"}
            ]
        }
    )


    # The final result will contain the entire conversation history, including tool calls and responses.
    for msg in result["messages"]:
        role = msg.type.upper()

        if role == "AI" and getattr(msg, "tool_calls", None):
            tool_names = [tc["name"] for tc in msg.tool_calls]
            print(f"[AI - TOOL CALL] {tool_names}")
        elif role == "TOOL":
            tool_name = getattr(msg, "name", "unknown_tool")
            print(f"[TOOL - {tool_name}] {msg.content}")
        else:
            print(f"[{role}] {msg.content}")