# RAG Demo — Workshop Questions

Based on the files in `data/` and the vector DB built from them, use these questions to explore
what RAG does well and where it breaks down.

## ⚠️ Before the workshop

`indexer.py` only globs `*.pdf` from `data/` (see line 80: `glob.glob(os.path.join(data_dir, '*.pdf'))`).
The three risk-policy files — `Bank Market Risk Policy.md`, `rbi_risk_basel_extracts.md`,
`VAR Backtesting policy.md` — and both `.docx` files **never get embedded**, even though they sit
in the folder. Any question about VaR limits, Basel/RBI norms, or SEBI disclosures will retrieve
nothing relevant, so the app should say "I don't know" (or, worse, hallucinate from the LLM's own
training data instead of the corpus — see Q13).

Also worth noting: the actual `chroma_db_new` (the store `streamlit_app_rag_pdf_qanda.py` reads
from) wasn't built by `indexer.py` at all — its `source` metadata shows temp-file paths, meaning
it was populated by uploading PDFs through the Streamlit sidebar, with several files uploaded more
than once (duplicate near-identical chunks). Worth reconciling before the session so participants
get consistent results.

Given that, the questions below are scoped to what's actually indexable from the PDFs:
**electricity bill, HDFC Bank annual report extract, and four CVs (kunal, pankaj, pooja, rahul)**.

---

## 7 questions to show RAG's power

1. **What is HDFC Bank's Profit After Tax and Return on Equity for FY24?**
   Exact numbers (₹60,812 Cr PAT, 16.1% ROE) buried in a 14-page report; shows grounded numeric
   retrieval over a generic LLM guess.

2. **What percentage stake does HDFC Bank hold in HDFC Life and HDFC Securities?**
   Pulls two specific figures (50.4%, 95.1%) from a dense subsidiary list.

3. **What was HDFC Securities' net profit in FY24 compared to the previous year?**
   Tests retrieval of a year-over-year comparison (₹950.9 Cr vs ₹777.2 Cr) that requires reading
   the right paragraph, not just keyword matching "profit."

4. **What software and financial systems has Kunal worked with?**
   Tests clean extraction of a bullet list (Tally ERP 9, SAP FICO, QuickBooks, Oracle Financials)
   from a résumé.

5. **How many units of electricity were consumed and what is the total bill amount due?**
   Combines two different fields (580 units, ₹7,630 after due date) from a cluttered, OCR'd bill
   layout.

6. **Which candidate has experience in talent acquisition and recruitment, and how many years?**
   Should surface both Rahul (7 yrs) and content from the Pooja/Amit file, testing multi-document
   retrieval for a role-based query rather than a name lookup.

7. **What is the discount if the electricity bill is paid before the due date?**
   Needs the retriever to find one specific clause (₹63.86 discount, pay by 20-Aug-2025) among
   many similar-looking numbers on the bill.

---

## 7 questions to expose RAG's limitations

8. **What are Pooja's skills?**
   `pooja.pdf` actually contains *two* résumés (Pooja Iyer, TA Lead, **and** Amit Sharma, HR Ops)
   under one filename/source. Watch whether the answer accidentally blends Amit's HR-ops skills
   into "Pooja's" profile — a classic case of source-file granularity being wrong.

9. **What is Pankaj's experience with Python or machine learning?**
   Pankaj's CV mentions only SAS/SQL, no Python/ML at all. See if the model honestly says "not
   mentioned" or hallucinates a plausible-sounding answer by pattern-matching "data analysis."

10. **Compare HDFC Bank's Return on Assets to the industry average for private banks.**
    The doc gives ROA (1.98%) but *not* an industry average. A good failure mode to watch: does
    it say "I don't know" or invent a comparison?

11. **Summarize the full month-by-month electricity consumption trend for the year.**
    The consumption trend is a small chart/table (Jan–Jul figures scattered as bare numbers) that
    a 1000-character chunk boundary is likely to slice apart, causing partial or reordered
    answers.

12. **What is the total combined net worth of all candidates' current employers?**
    A nonsensical cross-document arithmetic question with no real answer in the corpus. Good test
    of whether the system invents a number instead of refusing.

13. **What is the RBI's minimum capital requirement for market risk under Basel norms?**
    This is answered in `rbi_risk_basel_extracts.md`, which (per the note above) was **never
    embedded**. If the app answers fluently anyway, it's proof the LLM is drawing on its own
    pretrained knowledge rather than your documents — the single most important RAG failure mode
    to demonstrate.

14. **Whose résumé shows the strongest candidate for a Talent Acquisition leadership role, and
    why?**
    An evaluative/reasoning question. Retrieval can only fetch facts, not judgment; watch whether
    the answer just restates résumé bullet points verbatim versus doing genuine comparison — and
    whether duplicate chunks (same CV embedded 2–3 times, per the `chroma_db_new` inspection)
    cause one candidate's file to dominate the top-k results and crowd out the others.
