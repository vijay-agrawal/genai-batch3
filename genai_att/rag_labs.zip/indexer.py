import os
from langchain_openai import AzureOpenAIEmbeddings
import warnings
from dotenv import load_dotenv
import glob

load_dotenv()
warnings.filterwarnings("ignore")

REQUIRED_ENV_VARS = [
    "AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME",
    "AZURE_OPENAI_EMBEDDING_KEY",
    "AZURE_OPENAI_EMBEDDING_ENDPOINT",
]
missing = [v for v in REQUIRED_ENV_VARS if not os.getenv(v)]
if missing:
    print(f"ERROR: Missing required environment variables: {', '.join(missing)}")
    print("Make sure your .env file is present and contains all required keys.")
    exit(1)

CHROMA_PATH = os.path.join(os.getcwd(), "chroma_db_new2")

def load_document(file):
    name, extension = os.path.splitext(file)

    if extension == '.pdf':
        from langchain_community.document_loaders import PyPDFLoader
        print(f'Loading {file}')
        loader = PyPDFLoader(file)
    elif extension == '.docx':
        from langchain_community.document_loaders import Docx2txtLoader
        print(f'Loading {file}')
        loader = Docx2txtLoader(file)
    elif extension == '.txt':
        from langchain_community.document_loaders import TextLoader
        loader = TextLoader(file)
    else:
        print('Document format is not supported!')
        return None

    try:
        data = loader.load()
        print(f'File loaded: {os.path.basename(file)}')
        return data
    except Exception as e:
        print(f'Error loading {os.path.basename(file)}: {e}')
        return None

def chunk_data(data, chunk_size=256):
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, 
        chunk_overlap=20  # Added some overlap
    )
    chunks = text_splitter.split_documents(data)
    print(f"Created {len(chunks)} chunks")
    return chunks 

def create_embeddings_chroma(chunks, persist_directory=CHROMA_PATH):
    from langchain_community.vectorstores import Chroma
 
    # Load credentials from environment
    embeddings = AzureOpenAIEmbeddings(
        model=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT")
    )

    try:
        Chroma.from_documents(chunks, embeddings, persist_directory=persist_directory)
        print("Successfully created Chroma vector store")
    except Exception as e:
        print(f"Error creating embeddings: {e}")
        raise

#### MAIN PROCESSING STARTS HERE

data_dir = os.path.join(os.getcwd(), 'ragdemo/data')
print(f'Looking for PDF files in {data_dir}')
pdf_files = glob.glob(os.path.join(data_dir, '*.pdf'))

if not os.path.isdir(data_dir):
    print(f"ERROR: Data folder not found: {data_dir}")
    print(f"Make sure the 'ragdemo/data' folder exists relative to your working directory: {os.getcwd()}")
    exit(1)

if len(pdf_files) < 4:
    print(f"ERROR: Expected at least 4 PDF files in {data_dir}, found {len(pdf_files)}.")
    if pdf_files:
        print(f"  Files found: {[os.path.basename(f) for f in pdf_files]}")
    else:
        print("  No PDF files found in the data folder.")
    exit(1)

print(f'Found {len(pdf_files)} PDF files to process.')

# Load all PDF documents - flatten the structure
all_documents = []  # Renamed for clarity
for pdf_file in pdf_files:
    try:
        print(f'Processing file: {pdf_file}')
        docs = load_document(pdf_file)
        if docs:
            all_documents.extend(docs)  # Use extend instead of append
            print(f"Added: {os.path.basename(pdf_file)}")
    except Exception as e:
        print(f"Error loading {pdf_file}: {e}")

if not all_documents:
    print("No documents loaded successfully!")
    exit(1)

print(f'Loaded {len(all_documents)} document pages...')

# Split the documents into chunks
print('Splitting documents into chunks')
chunks = chunk_data(all_documents, chunk_size=256)

if chunks:
    create_embeddings_chroma(chunks)
    print('Chroma vector db created successfully')
else:
    print('No chunks created - check your documents')