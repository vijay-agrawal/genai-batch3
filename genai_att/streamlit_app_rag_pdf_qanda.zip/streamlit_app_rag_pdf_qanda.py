import os
from urllib.parse import urlparse, parse_qs
from dotenv import load_dotenv
import streamlit as st
from langchain_openai import AzureChatOpenAI
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
import tempfile

load_dotenv()

CHROMA_PATH = os.path.join(os.getcwd(), "chroma_db_new")

st.set_page_config(page_title="PDF chatbot", layout="wide")
st.title("RAG Demo - PDF Q&A")

st.markdown("""
1. **Upload Your Documents**: The system accepts multiple PDF files at once, analyzing the content to provide comprehensive insights.

2. **Ask a Question**: After processing the documents, ask any question related to the content of your uploaded documents for a precise answer.
""")

def main():
    st.header("Ask a question")

    # Initialize embeddings
    # .env holds a full /openai/deployments/.../embeddings request URL; the SDK
    # needs only the resource root (see azure_openai_basic/01test_azure_openai.py)
    _parsed = urlparse(os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT", ""))
    embedding_endpoint = f"{_parsed.scheme}://{_parsed.netloc}"
    embedding_api_version = parse_qs(_parsed.query).get(
        "api-version", [os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15")]
    )[0]

    embeddings = AzureOpenAIEmbeddings(
        azure_deployment=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
        azure_endpoint=embedding_endpoint,
        api_version=embedding_api_version
    )
    
    # Initialize vector store
    vectorstore = Chroma(
        persist_directory=CHROMA_PATH,
        embedding_function=embeddings
    )

    with st.sidebar:
        st.title("Menu:")
        uploaded_files = st.file_uploader(
            "Upload your PDF Files and Click on the Submit & Process Button", 
            accept_multiple_files=True, 
            key="pdf_uploader"
        )
        
        if st.button("Submit & Process", key="process_button") and uploaded_files:
            with st.spinner("Processing..."):
                for uploaded_file in uploaded_files:
                    try:
                        # Create a temporary file to store the uploaded PDF
                        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp_file:
                            tmp_file.write(uploaded_file.getvalue())
                            tmp_file_path = tmp_file.name
                        
                        # Load PDF using PyPDFLoader
                        loader = PyPDFLoader(tmp_file_path)
                        pages = loader.load()
                        
                        # Add metadata to each page
                        for idx, page in enumerate(pages):
                            page.metadata["page_number"] = idx + 1
                            page.metadata["source_file"] = uploaded_file.name
                        
                        # Split into chunks
                        text_splitter = RecursiveCharacterTextSplitter(
                            chunk_size=1000,
                            chunk_overlap=200,
                            length_function=len,
                            separators=["\n\n", "\n", " ", ""]
                        )
                        chunks = text_splitter.split_documents(pages)
                        
                        # Clean up temporary file
                        os.unlink(tmp_file_path)                        
                    
                        # Add to vector store
                        vectorstore.add_documents(chunks)
                        
                        st.success(f"✅ Processed {uploaded_file.name}")
                    
                    except Exception as e:
                        st.error(f"❌ Error processing {uploaded_file.name}: {str(e)}")
                        continue
                
                print("Vector store created/updated")
                st.success("🎉 All documents processed successfully!")

    # Question answering section
    user_question = st.text_input("Ask a Question from the PDF Files", key="user_question")
    
    if user_question:
        with st.spinner("Thinking..."):
            try:
                print("Question: ", user_question)

                # Initialize LLM
                # .env holds a full /openai/... request URL; the SDK needs only the resource root
                # (see azure_openai_basic/01test_azure_openai.py, which uses this same approach)
                _parsed = urlparse(os.getenv("AZURE_OPENAI_ENDPOINT", ""))
                azure_endpoint = f"{_parsed.scheme}://{_parsed.netloc}"
                api_version = parse_qs(_parsed.query).get(
                    "api-version", [os.getenv("AZURE_OPENAI_API_VERSION", "2025-04-01-preview")]
                )[0]

                llm = AzureChatOpenAI(
                    temperature=0,
                    azure_endpoint=azure_endpoint,
                    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
                    api_version=api_version,
                    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
                )

                # Create retriever
                retriever = vectorstore.as_retriever(
                    search_type='similarity', 
                    search_kwargs={'k': 5}
                )

                # Create prompt template
                template = """You are an assistant for question-answering tasks. 
Use the following pieces of retrieved context to answer the question. 
If you don't know the answer, say that you don't know. 
Use three sentences maximum and keep the answer concise.

Context: {context}

Question: {question}

Answer:"""
                
                prompt = ChatPromptTemplate.from_template(template)

                # Helper function to format documents
                def format_docs(docs):
                    return "\n\n".join(doc.page_content for doc in docs)

                # Create the RAG chain using LCEL
                rag_chain = (
                    {"context": retriever | format_docs, "question": RunnablePassthrough()}
                    | prompt
                    | llm
                    | StrOutputParser()
                )

                # Get answer
                answer = rag_chain.invoke(user_question)
                
                # Get source documents for reference
                source_docs = retriever.invoke(user_question)

                print("Answer:", answer)
                
                # Display answer
                st.write("### Reply:")
                st.write(answer)
                
                # Display source documents in expander
                with st.expander("📚 View Source Documents"):
                    for idx, doc in enumerate(source_docs, 1):
                        st.markdown(f"**Source {idx}** - Page {doc.metadata.get('page_number', 'N/A')}")
                        st.text(doc.page_content[:300] + "...")
                        st.divider()
                        
            except Exception as e:
                st.error(f"Error processing question: {str(e)}")
                print(f"Error: {str(e)}")


if __name__ == "__main__":
    main()