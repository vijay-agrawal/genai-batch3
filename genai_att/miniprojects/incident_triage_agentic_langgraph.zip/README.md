# AT&T Incident Triage & RCA Pipeline (LangGraph)

Multi-agent AI system using **LangGraph** with a **critique feedback loop** for telecom incident triage, root cause analysis, and resolution recommendation.

## What It Does

When a production incident is reported, five AI agents collaborate through a LangGraph state graph:

1. **Incident Classifier** — Parses the incident, assigns P1–P4 severity, maps blast radius
2. **Log & Metrics Analyzer** — Analyzes simulated logs, reconstructs timeline, identifies root cause
3. **Resolution Recommender** — Cross-references knowledge base of past incidents, recommends prioritized fix actions
4. **Critique Agent** — Reviews the full analysis for gaps, errors, and completeness. If issues are found, sends agents 2 & 3 back for revision (feedback loop, up to 2 iterations)
5. **Report Generator** — Compiles a final structured JSON incident report

## Critique Feedback Loop

The key differentiator of this architecture is the **critique agent feedback loop**:

```
classify → analyze_logs → recommend_resolution → critique
                                                    │
                                   ┌────────────────┤
                                   │                │
                             [APPROVED]      [REVISION REQUIRED]
                                   │                │
                                   ▼                └──→ analyze_logs (loop)
                            generate_report
                                   │
                                   ▼
                                 [END]
```

The critique agent evaluates:
- Is the severity classification correct?
- Is the root cause hypothesis supported by log evidence?
- Are resolution actions specific and actionable?
- Are rollback plans provided for risky actions?

If gaps are found, the log analyzer and resolution recommender are re-invoked with the critique feedback, producing a more thorough analysis.

## Demo Scenarios

Six pre-built incident scenarios covering different AT&T team domains:

| Incident | Scenario | Teams |
|----------|----------|-------|
| incident_01 | Wireless Activation API failures (Dallas) | App Dev, Integration |
| incident_02 | Billing batch processing failure (nationwide) | DevOps, Billing |
| incident_03 | 5G tower cluster degradation (Houston) | Network Ops, DevOps |
| incident_04 | Salesforce-OMS integration sync outage | Salesforce, Integration |
| incident_05 | CI/CD pipeline rollback stuck (Customer Portal) | DevOps, App Dev |
| incident_06 | IoT fleet mass device disconnection | IoT, DevOps |

Each scenario includes matching **simulated log data** and a **knowledge base of past incidents**.

## Quick Start

### 1. Install dependencies

```bash
cd agentic_langgraph
pip install -r requirements.txt
```

### 2. Configure environment

Uses the project root `.env` file:

```
AZURE_OPENAI_API_KEY=your_key
AZURE_OPENAI_ENDPOINT=your_endpoint
AZURE_OPENAI_DEPLOYMENT_NAME=your_deployment
AZURE_OPENAI_API_VERSION=2024-05-01-preview
AZURE_OPENAI_MODEL_NAME=gpt-4o-mini
```

**Fallback:** Set `OPENAI_API_KEY` and change `api.type` to `openai` in `src/config/config.yaml`.

### 3. Run the app

```bash
streamlit run app.py
```

## Architecture

### LangGraph vs AutoGen

| Aspect | LangGraph (this project) | AutoGen (escalation project) |
|--------|--------------------------|------------------------------|
| **Control flow** | Explicit state graph with conditional edges | Sequential agent chats |
| **Feedback loop** | Built-in via conditional edges | Manual while-loop |
| **State** | Typed shared state (TypedDict) | Chat message history |
| **Observability** | State visible at every node | Debug trace via callbacks |
| **Best for** | Complex workflows with branching/loops | Multi-turn agent conversations |

### State Graph

```python
class IncidentState(TypedDict):
    incident_text: str        # Input
    log_data: dict            # Input
    knowledge_base: dict      # Input
    classification: str       # Agent 1 output
    log_analysis: str         # Agent 2 output
    resolution: str           # Agent 3 output
    critique: str             # Agent 4 output
    report: dict              # Agent 5 output
    critique_approved: bool   # Controls feedback loop
    revision_count: int       # Tracks loop iterations
    debug_trace: list         # Append-only execution log
```

## Technology Stack

- **LangGraph** — State graph orchestration with conditional edges
- **LangChain** — LLM abstraction (AzureChatOpenAI / ChatOpenAI)
- **Azure OpenAI / OpenAI** — LLM backend
- **Streamlit** — Web interface

## Project Structure

```
agentic_langgraph/
├── app.py                              # Streamlit web interface
├── requirements.txt                    # Python dependencies
├── README.md                           # This file
└── src/
    ├── graph/
    │   ├── state.py                    # IncidentState TypedDict
    │   ├── nodes.py                    # Node functions (5 agents)
    │   └── workflow.py                 # LangGraph graph definition + runner
    ├── prompts/
    │   ├── classifier.py               # Incident Classifier prompt
    │   ├── log_analyzer.py             # Log Analyzer + revision prompt
    │   ├── resolution.py               # Resolution Recommender + revision prompt
    │   ├── critique.py                 # Critique Agent prompt
    │   └── report.py                   # Report Generator prompt
    ├── config/
    │   └── config.yaml                 # LLM and workflow configuration
    └── data/
        ├── sample_incidents/           # 6 incident scenarios (JSON)
        └── knowledge_base/
            ├── log_data.json           # Simulated logs per incident
            └── past_incidents.json     # Past incident knowledge base
```
