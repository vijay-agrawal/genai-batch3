"""LangGraph node functions - each node is one agent in the pipeline."""

import json
from langchain_core.messages import SystemMessage, HumanMessage

from src.prompts.classifier import INCIDENT_CLASSIFIER_PROMPT
from src.prompts.log_analyzer import (
    LOG_ANALYZER_PROMPT,
    LOG_ANALYZER_REVISION_PROMPT,
)
from src.prompts.resolution import (
    RESOLUTION_RECOMMENDER_PROMPT,
    RESOLUTION_REVISION_PROMPT,
)
from src.prompts.critique import CRITIQUE_AGENT_PROMPT
from src.prompts.report import REPORT_GENERATOR_PROMPT


def classify_incident(state, llm):
    """Node 1: Incident Classifier - parses and classifies the incident."""
    messages = [
        SystemMessage(content=INCIDENT_CLASSIFIER_PROMPT),
        HumanMessage(
            content=f"""Analyze and classify this telecom incident:

{state['incident_text']}

Provide your full incident classification."""
        ),
    ]

    response = llm.invoke(messages)
    classification = response.content

    return {
        "classification": classification,
        "debug_trace": [f"[Incident Classifier] Classification complete ({len(classification)} chars)"],
    }


def analyze_logs(state, llm):
    """Node 2: Log & Metrics Analyzer - analyzes logs and finds root cause."""
    log_data_str = json.dumps(state["log_data"], indent=2)
    revision_count = state.get("revision_count", 0)

    # If this is a revision, include critique feedback
    if revision_count > 0 and state.get("critique"):
        system_prompt = LOG_ANALYZER_REVISION_PROMPT.format(
            previous_analysis=state.get("log_analysis", ""),
            critique_feedback=state["critique"],
        )
    else:
        system_prompt = LOG_ANALYZER_PROMPT

    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(
            content=f"""Analyze these logs and metrics for the incident.

INCIDENT CLASSIFICATION (from previous agent):
{state['classification']}

SYSTEM LOGS AND METRICS:
{log_data_str}

ORIGINAL INCIDENT:
{state['incident_text']}

Provide your full log analysis with root cause hypothesis."""
        ),
    ]

    response = llm.invoke(messages)
    log_analysis = response.content

    revision_label = f" (revision #{revision_count})" if revision_count > 0 else ""
    return {
        "log_analysis": log_analysis,
        "debug_trace": [f"[Log Analyzer] Analysis complete{revision_label} ({len(log_analysis)} chars)"],
    }


def recommend_resolution(state, llm):
    """Node 3: Resolution Recommender - recommends fix actions."""
    kb_str = json.dumps(state["knowledge_base"], indent=2)
    revision_count = state.get("revision_count", 0)

    if revision_count > 0 and state.get("critique"):
        system_prompt = RESOLUTION_REVISION_PROMPT.format(
            previous_resolution=state.get("resolution", ""),
            critique_feedback=state["critique"],
        )
    else:
        system_prompt = RESOLUTION_RECOMMENDER_PROMPT

    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(
            content=f"""Recommend resolution actions for this incident.

INCIDENT CLASSIFICATION:
{state['classification']}

ROOT CAUSE ANALYSIS:
{state['log_analysis']}

KNOWLEDGE BASE (past incidents and known fixes):
{kb_str}

ORIGINAL INCIDENT:
{state['incident_text']}

Provide your prioritized resolution recommendations."""
        ),
    ]

    response = llm.invoke(messages)
    resolution = response.content

    revision_label = f" (revision #{revision_count})" if revision_count > 0 else ""
    return {
        "resolution": resolution,
        "debug_trace": [f"[Resolution Recommender] Recommendations complete{revision_label} ({len(resolution)} chars)"],
    }


def critique_analysis(state, llm):
    """Node 4: Critique Agent - reviews full pipeline output, decides approve or revise."""
    messages = [
        SystemMessage(content=CRITIQUE_AGENT_PROMPT),
        HumanMessage(
            content=f"""Review the complete incident analysis pipeline output below.

ORIGINAL INCIDENT:
{state['incident_text']}

=== AGENT 1 OUTPUT: INCIDENT CLASSIFICATION ===
{state['classification']}

=== AGENT 2 OUTPUT: LOG & METRICS ANALYSIS ===
{state['log_analysis']}

=== AGENT 3 OUTPUT: RESOLUTION RECOMMENDATIONS ===
{state['resolution']}

This is revision attempt #{state.get('revision_count', 0) + 1} of {state.get('max_revisions', 2) + 1} allowed.

Review all three outputs and provide your verdict: APPROVED or REVISION REQUIRED."""
        ),
    ]

    response = llm.invoke(messages)
    critique = response.content

    approved = "VERDICT: APPROVED" in critique.upper()
    current_revision = state.get("revision_count", 0)

    # Force approval if we've hit max revisions
    if current_revision >= state.get("max_revisions", 2):
        approved = True

    new_revision_count = current_revision if approved else current_revision + 1

    verdict_str = "APPROVED" if approved else f"REVISION REQUIRED (revision {new_revision_count}/{state.get('max_revisions', 2)})"
    return {
        "critique": critique,
        "critique_approved": approved,
        "revision_count": new_revision_count,
        "debug_trace": [f"[Critique Agent] Verdict: {verdict_str}"],
    }


def generate_report(state, llm):
    """Node 5: Report Generator - compiles final structured JSON report."""
    messages = [
        SystemMessage(content=REPORT_GENERATOR_PROMPT),
        HumanMessage(
            content=f"""Compile the final incident report from all agent outputs below.

INCIDENT CLASSIFICATION:
{state['classification']}

LOG & METRICS ANALYSIS:
{state['log_analysis']}

RESOLUTION RECOMMENDATIONS:
{state['resolution']}

CRITIQUE REVIEW:
{state['critique']}

REVISION COUNT: {state.get('revision_count', 0)}

ORIGINAL INCIDENT:
{state['incident_text']}

Generate ONLY valid JSON for the incident report."""
        ),
    ]

    response = llm.invoke(messages)
    raw_response = response.content

    # Parse JSON from response
    import re
    report = {}
    try:
        json_match = re.search(r"\{.*\}", raw_response, re.DOTALL)
        if json_match:
            report = json.loads(json_match.group(0))
        else:
            report = {"error": "No JSON found", "raw_response": raw_response}
    except json.JSONDecodeError as e:
        report = {"error": f"JSON parse error: {str(e)}", "raw_response": raw_response}

    return {
        "report": report,
        "debug_trace": [f"[Report Generator] Final report generated ({len(str(report))} chars)"],
    }
