"""LangGraph state definition for the Incident Triage & RCA pipeline."""

from typing import TypedDict, Annotated
import operator


class IncidentState(TypedDict):
    """State that flows through the LangGraph incident resolution pipeline.

    Each node reads from and writes to this shared state.
    The critique agent's feedback loop uses revision_count and critique_approved
    to control the conditional edge back to log_analyzer.
    """

    # ─── Inputs ───
    incident_text: str          # Raw incident description
    log_data: dict              # Simulated log/metrics data for the incident
    knowledge_base: dict        # Past incidents and known resolutions

    # ─── Agent outputs ───
    classification: str         # Incident Classifier output
    log_analysis: str           # Log & Metrics Analyzer output
    resolution: str             # Resolution Recommender output
    critique: str               # Critique Agent output
    report: dict                # Final Report Generator output (JSON)

    # ─── Control flow ───
    critique_approved: bool     # Whether the critique agent approved the analysis
    revision_count: int         # Number of critique revision loops completed
    max_revisions: int          # Maximum allowed revision loops

    # ─── Observability ───
    debug_trace: Annotated[list, operator.add]  # Append-only debug log across nodes
