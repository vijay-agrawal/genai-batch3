"""LangGraph workflow definition with critique feedback loop.

Graph structure:
    START → classify → analyze_logs → recommend_resolution → critique
                                                               │
                                              ┌────────────────┤
                                              │                │
                                        [APPROVED]      [REVISION REQUIRED]
                                              │                │
                                              ▼                ▼
                                       generate_report    analyze_logs (loop back)
                                              │
                                              ▼
                                             END
"""

import os
import yaml
import functools
from pathlib import Path
from dotenv import load_dotenv
from langgraph.graph import StateGraph, END
from langchain_openai import AzureChatOpenAI, ChatOpenAI

from src.graph.state import IncidentState
from src.graph.nodes import (
    classify_incident,
    analyze_logs,
    recommend_resolution,
    critique_analysis,
    generate_report,
)


def load_config():
    """Load configuration from YAML and inject environment variables."""
    config_path = Path(__file__).parent.parent / "config" / "config.yaml"
    with open(config_path, "r") as f:
        config_str = f.read()

    for key, value in os.environ.items():
        config_str = config_str.replace(f"${{{key}}}", value)

    return yaml.safe_load(config_str)


def create_llm(config):
    """Create the LLM instance based on config (Azure or OpenAI fallback)."""
    api_type = config["api"]["type"]

    if api_type == "azure":
        azure_cfg = config["api"]["azure_openai"]
        endpoint = azure_cfg["endpoint"]

        # Extract base URL if endpoint contains full deployment path
        if "/openai/deployments/" in endpoint:
            base_url = endpoint.split("/openai/deployments/")[0]
        else:
            base_url = endpoint.rstrip("/")

        return AzureChatOpenAI(
            azure_endpoint=base_url,
            azure_deployment=azure_cfg.get("deployment", "gpt-4o-mini"),
            api_key=azure_cfg["api_key"],
            api_version=azure_cfg.get("api_version", "2024-05-01-preview"),
            temperature=0.3,
            max_tokens=2500,
        )
    else:
        openai_cfg = config["api"]["openai"]
        return ChatOpenAI(
            model=openai_cfg.get("model", "gpt-4o-mini"),
            api_key=openai_cfg["api_key"],
            temperature=0.3,
            max_tokens=2500,
        )


def should_revise(state: IncidentState) -> str:
    """Conditional edge: route to revision loop or final report.

    This is the key decision point in the graph:
    - If critique approved → go to report generation
    - If critique says revise AND we haven't hit max → loop back to log analysis
    """
    if state.get("critique_approved", False):
        return "generate_report"
    else:
        return "analyze_logs"


def build_graph(config=None):
    """Build the LangGraph workflow with critique feedback loop.

    Returns a compiled graph ready to invoke.
    """
    if config is None:
        config = load_config()

    llm = create_llm(config)

    # Bind LLM to each node function using functools.partial
    classify_node = functools.partial(classify_incident, llm=llm)
    analyze_node = functools.partial(analyze_logs, llm=llm)
    resolve_node = functools.partial(recommend_resolution, llm=llm)
    critique_node = functools.partial(critique_analysis, llm=llm)
    report_node = functools.partial(generate_report, llm=llm)

    # Build the state graph
    graph = StateGraph(IncidentState)

    # Add nodes
    graph.add_node("classify_incident", classify_node)
    graph.add_node("analyze_logs", analyze_node)
    graph.add_node("recommend_resolution", resolve_node)
    graph.add_node("critique_analysis", critique_node)
    graph.add_node("generate_report", report_node)

    # Set entry point
    graph.set_entry_point("classify_incident")

    # Linear edges: classify → analyze → resolve → critique
    graph.add_edge("classify_incident", "analyze_logs")
    graph.add_edge("analyze_logs", "recommend_resolution")
    graph.add_edge("recommend_resolution", "critique_analysis")

    # Conditional edge: critique → (generate_report OR analyze_logs)
    graph.add_conditional_edges(
        "critique_analysis",
        should_revise,
        {
            "generate_report": "generate_report",
            "analyze_logs": "analyze_logs",
        },
    )

    # Final edge: report → END
    graph.add_edge("generate_report", END)

    return graph.compile()


def run_pipeline(incident_text: str, log_data: dict, knowledge_base: dict, config=None, max_revisions: int = 2):
    """Run the full incident triage pipeline.

    Args:
        incident_text: Raw incident description
        log_data: Simulated log/metrics data
        knowledge_base: Past incidents and known resolutions
        config: Optional config dict (loaded from yaml if not provided)
        max_revisions: Max critique revision loops (default 2)

    Returns:
        Final state dict with all agent outputs
    """
    if config is None:
        config = load_config()

    app = build_graph(config)

    initial_state = {
        "incident_text": incident_text,
        "log_data": log_data,
        "knowledge_base": knowledge_base,
        "classification": "",
        "log_analysis": "",
        "resolution": "",
        "critique": "",
        "report": {},
        "critique_approved": False,
        "revision_count": 0,
        "max_revisions": max_revisions,
        "debug_trace": ["[Pipeline] Starting incident triage pipeline..."],
    }

    # Run the graph
    final_state = app.invoke(initial_state)
    return final_state
