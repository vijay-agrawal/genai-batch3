"""
Telecom Incident Triage & RCA Pipeline - Agentic AI Demo
LangGraph-based multi-agent system with critique feedback loop.
"""

import streamlit as st
import json
import os
import sys
import yaml
import time
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from project root .env
env_path = Path(__file__).parent.parent / ".env"
load_dotenv(dotenv_path=env_path)

# ─── Page Configuration ───
st.set_page_config(
    page_title="AT&T Incident Triage & RCA Pipeline",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ───
st.markdown(
    """
<style>
    .main-header {
        font-size: 2.2rem;
        color: #009FDB;
        text-align: center;
        margin-bottom: 0.3rem;
        font-weight: 700;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #666;
        text-align: center;
        margin-bottom: 2rem;
    }
    .agent-card {
        background-color: #f0f6fa;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        border-left: 4px solid #009FDB;
    }
    .agent-done { border-left-color: #00C853; background-color: #f0faf4; }
    .agent-revision { border-left-color: #FF6B00; background-color: #fff8f0; }
    .priority-p1 { color: #D32F2F; font-weight: bold; font-size: 1.1em; }
    .priority-p2 { color: #FF6B00; font-weight: bold; font-size: 1.1em; }
    .priority-p3 { color: #FBC02D; font-weight: bold; }
    .priority-p4 { color: #388E3C; font-weight: bold; }
    .metric-card {
        background: linear-gradient(135deg, #009FDB 0%, #0057B8 100%);
        color: white;
        padding: 1.2rem;
        border-radius: 0.75rem;
        text-align: center;
    }
    .metric-value { font-size: 1.8rem; font-weight: 700; }
    .metric-label { font-size: 0.85rem; opacity: 0.9; }
    .loop-card {
        background: linear-gradient(135deg, #FF6B00 0%, #E65100 100%);
        color: white;
        padding: 1.2rem;
        border-radius: 0.75rem;
        text-align: center;
    }
    .approved-card {
        background: linear-gradient(135deg, #00C853 0%, #1B5E20 100%);
        color: white;
        padding: 1.2rem;
        border-radius: 0.75rem;
        text-align: center;
    }
</style>
""",
    unsafe_allow_html=True,
)


def load_config():
    """Load configuration from YAML and inject environment variables."""
    config_path = Path(__file__).parent / "src" / "config" / "config.yaml"
    if not config_path.exists():
        st.error(f"Configuration file not found at {config_path}")
        st.stop()

    with open(config_path, "r") as f:
        config_str = f.read()

    for key, value in os.environ.items():
        config_str = config_str.replace(f"${{{key}}}", value)

    return yaml.safe_load(config_str)


def load_sample_incidents():
    """Load all sample incident scenarios."""
    incidents_dir = Path(__file__).parent / "src" / "data" / "sample_incidents"
    incidents = {}
    if incidents_dir.exists():
        for f in sorted(incidents_dir.glob("*.json")):
            with open(f, "r", encoding="utf-8") as fh:
                incidents[f.stem] = json.load(fh)
    return incidents


def load_knowledge_base():
    """Load log data and past incidents."""
    kb_dir = Path(__file__).parent / "src" / "data" / "knowledge_base"
    log_data = {}
    past_incidents = {}

    log_path = kb_dir / "log_data.json"
    past_path = kb_dir / "past_incidents.json"

    if log_path.exists():
        with open(log_path, "r", encoding="utf-8") as f:
            log_data = json.load(f)
    if past_path.exists():
        with open(past_path, "r", encoding="utf-8") as f:
            past_incidents = json.load(f)

    return log_data, past_incidents


def render_graph_diagram():
    """Render the LangGraph workflow diagram in the sidebar."""
    st.code(
        """
  [START]
     |
     v
 +-----------------------+
 | Incident Classifier   |
 +-----------------------+
     |
     v
 +-----------------------+
 | Log & Metrics         |  <----+
 | Analyzer              |       |
 +-----------------------+       |
     |                           |
     v                           |
 +-----------------------+       |
 | Resolution            |       |
 | Recommender           |       |
 +-----------------------+       |
     |                           |
     v                           |
 +-----------------------+       |
 | Critique Agent        |-------+
 | (Review & Feedback)   | REVISION
 +-----------------------+ REQUIRED
     |
     | APPROVED
     v
 +-----------------------+
 | Report Generator      |
 +-----------------------+
     |
     v
   [END]
""",
        language=None,
    )


def render_pipeline_results(final_state):
    """Render the full pipeline results with all agent outputs."""

    st.markdown("---")
    st.markdown("### Agent Pipeline Results")

    # ─── Agent 1: Incident Classifier ───
    with st.expander("Agent 1: Incident Classifier", expanded=True):
        st.markdown('<div class="agent-card agent-done">', unsafe_allow_html=True)
        st.markdown("**Role:** Parse incident, classify severity (P1-P4), identify affected systems, map blast radius")
        st.markdown("</div>", unsafe_allow_html=True)
        st.text(final_state.get("classification", "No output"))

    # ─── Agent 2: Log & Metrics Analyzer ───
    revision_count = final_state.get("revision_count", 0)
    revision_label = f" (revised {revision_count}x)" if revision_count > 0 else ""
    card_class = "agent-revision" if revision_count > 0 else "agent-done"

    with st.expander(f"Agent 2: Log & Metrics Analyzer{revision_label}", expanded=True):
        st.markdown(f'<div class="agent-card {card_class}">', unsafe_allow_html=True)
        st.markdown("**Role:** Analyze logs/metrics, find error patterns, reconstruct timeline, identify root cause")
        if revision_count > 0:
            st.markdown(f"*This agent was revised {revision_count} time(s) based on critique feedback.*")
        st.markdown("</div>", unsafe_allow_html=True)
        st.text(final_state.get("log_analysis", "No output"))

    # ─── Agent 3: Resolution Recommender ───
    with st.expander(f"Agent 3: Resolution Recommender{revision_label}", expanded=True):
        st.markdown(f'<div class="agent-card {card_class}">', unsafe_allow_html=True)
        st.markdown("**Role:** Recommend prioritized remediation actions with rollback plans")
        if revision_count > 0:
            st.markdown(f"*This agent was revised {revision_count} time(s) based on critique feedback.*")
        st.markdown("</div>", unsafe_allow_html=True)
        st.text(final_state.get("resolution", "No output"))

    # ─── Agent 4: Critique Agent ───
    with st.expander("Agent 4: Critique Agent (Feedback Loop)", expanded=True):
        approved = final_state.get("critique_approved", False)
        verdict_class = "agent-done" if approved else "agent-revision"
        st.markdown(f'<div class="agent-card {verdict_class}">', unsafe_allow_html=True)
        st.markdown("**Role:** Review entire analysis for gaps, errors, and completeness. Controls the feedback loop.")
        verdict = "APPROVED" if approved else "REVISION REQUIRED"
        st.markdown(f"**Final Verdict:** {verdict} | **Revisions:** {revision_count}")
        st.markdown("</div>", unsafe_allow_html=True)
        st.text(final_state.get("critique", "No output"))

    # ─── Agent 5: Report Generator ───
    with st.expander("Agent 5: Report Generator (Final Output)", expanded=True):
        st.markdown('<div class="agent-card agent-done">', unsafe_allow_html=True)
        st.markdown("**Role:** Compile all agent outputs into a structured JSON incident report")
        st.markdown("</div>", unsafe_allow_html=True)

        report = final_state.get("report", {})
        if isinstance(report, dict) and "error" not in report:
            # Show the executive summary prominently
            incident_report = report.get("incident_report", report)
            if "executive_summary" in incident_report:
                st.info(f"**Executive Summary:** {incident_report['executive_summary']}")

            st.json(report)
        else:
            st.warning("Report could not be parsed as structured JSON.")
            st.json(report)


def main():
    # ─── Header ───
    st.markdown('<div class="main-header">AT&T Incident Triage & RCA Pipeline</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-header">LangGraph Multi-Agent System with Critique Feedback Loop</div>',
        unsafe_allow_html=True,
    )

    # ─── Sidebar ───
    with st.sidebar:
        st.markdown("### LangGraph Workflow")
        st.markdown(
            """
This demo uses **LangGraph** to orchestrate 5 AI agents
with a **critique feedback loop**:

1. **Incident Classifier** - Severity & blast radius
2. **Log Analyzer** - Root cause hypothesis
3. **Resolution Recommender** - Fix actions
4. **Critique Agent** - Reviews & sends back for revision
5. **Report Generator** - Final structured output

The **Critique Agent** creates a feedback loop:
if the analysis has gaps, it sends agents 2 & 3
back for revision (up to 2 times).
"""
        )

        st.markdown("---")
        st.markdown("### Graph Architecture")
        render_graph_diagram()

        st.markdown("---")
        st.markdown("### Configuration")
        try:
            config = load_config()
            api_type = config["api"]["type"]
            if api_type == "azure":
                model = config["api"]["azure_openai"].get("model", "N/A")
                st.info(f"Provider: Azure OpenAI\nModel: {model}")
            else:
                model = config["api"]["openai"].get("model", "N/A")
                st.info(f"Provider: OpenAI\nModel: {model}")
        except Exception:
            st.warning("Could not load configuration")

        st.markdown("---")
        max_revisions = st.slider("Max critique revisions:", 0, 3, 2)

    # ─── Main Content ───
    incidents = load_sample_incidents()
    log_data_all, past_incidents_all = load_knowledge_base()

    input_mode = st.radio(
        "Select input mode:",
        ["Choose a sample incident", "Enter custom incident"],
        horizontal=True,
    )

    incident_text = ""
    log_data = {}
    knowledge_base = {}

    if input_mode == "Choose a sample incident":
        if incidents:
            options = {k: v["title"] for k, v in incidents.items()}
            selected = st.selectbox(
                "Select an incident scenario:",
                options=list(options.keys()),
                format_func=lambda x: f"{x}: {options[x]}",
            )

            if selected:
                inc = incidents[selected]
                incident_text = inc["incident_text"]
                log_data = log_data_all.get(inc.get("log_data_key", ""), {})
                knowledge_base = past_incidents_all.get(inc.get("knowledge_base_key", ""), {})

                # Show incident summary
                st.markdown("### Incident Details")
                st.text(incident_text)

                col1, col2 = st.columns(2)
                with col1:
                    with st.expander("System Logs & Metrics", expanded=False):
                        st.json(log_data)
                with col2:
                    with st.expander("Past Incidents Knowledge Base", expanded=False):
                        st.json(knowledge_base)
        else:
            st.warning("No sample incidents found in src/data/sample_incidents/")

    else:
        incident_text = st.text_area(
            "Enter the incident description:",
            height=250,
            placeholder="INCIDENT REPORT\nID: INC-2024-XXXXX\nReported By: ...\n\nDescription:\n...",
        )
        st.info("Custom incidents will use empty log data and a generic knowledge base.")
        log_data = {}
        knowledge_base = {"past_incidents": []}

    # ─── Process Button ───
    st.markdown("---")
    col_btn1, col_btn2, col_btn3 = st.columns([1, 2, 1])
    with col_btn2:
        process_btn = st.button(
            "Run Incident Triage Pipeline",
            type="primary",
            use_container_width=True,
            disabled=not incident_text,
        )

    if process_btn and incident_text:
        st.markdown("---")

        progress_bar = st.progress(0)

        # Show agent status cards
        agent_steps = [
            ("Incident Classifier", "Parsing and classifying the incident..."),
            ("Log & Metrics Analyzer", "Analyzing logs, finding root cause..."),
            ("Resolution Recommender", "Cross-referencing knowledge base, recommending fixes..."),
            ("Critique Agent", "Reviewing analysis for gaps and errors..."),
            ("Report Generator", "Compiling final structured report..."),
        ]

        status_cols = st.columns(5)
        status_placeholders = []
        for i, (name, _) in enumerate(agent_steps):
            with status_cols[i]:
                ph = st.empty()
                ph.markdown(f"**{name}**\n\n⏳ Waiting")
                status_placeholders.append(ph)

        start_time = time.time()
        status_placeholders[0].markdown(f"**{agent_steps[0][0]}**\n\n🔄 Running...")
        progress_bar.progress(5)

        try:
            from src.graph.workflow import run_pipeline

            config = load_config()
            final_state = run_pipeline(
                incident_text=incident_text,
                log_data=log_data,
                knowledge_base=knowledge_base,
                config=config,
                max_revisions=max_revisions,
            )

            elapsed = time.time() - start_time

            # Update all statuses to complete
            for i in range(5):
                status_placeholders[i].markdown(f"**{agent_steps[i][0]}**\n\n✅ Done")
            progress_bar.progress(100)

            revision_count = final_state.get("revision_count", 0)
            approved = final_state.get("critique_approved", False)

            st.success(f"Pipeline completed in {elapsed:.1f} seconds")

            # ─── Summary Metrics ───
            st.markdown("### Pipeline Summary")
            mcols = st.columns(4)

            # Extract severity from report if available
            report = final_state.get("report", {})
            inc_report = report.get("incident_report", report)
            severity = inc_report.get("severity", "N/A") if isinstance(inc_report, dict) else "N/A"
            mttr = inc_report.get("resolution_plan", {}).get("estimated_mttr", "N/A") if isinstance(inc_report, dict) else "N/A"

            with mcols[0]:
                sev_class = "priority-p1" if "P1" in str(severity) else "priority-p2" if "P2" in str(severity) else ""
                st.markdown(
                    f'<div class="metric-card"><div class="metric-value">{severity}</div><div class="metric-label">Severity</div></div>',
                    unsafe_allow_html=True,
                )
            with mcols[1]:
                card_class = "loop-card" if revision_count > 0 else "approved-card"
                st.markdown(
                    f'<div class="{card_class}"><div class="metric-value">{revision_count}</div><div class="metric-label">Critique Revisions</div></div>',
                    unsafe_allow_html=True,
                )
            with mcols[2]:
                st.markdown(
                    f'<div class="metric-card"><div class="metric-value">{elapsed:.1f}s</div><div class="metric-label">Pipeline Time</div></div>',
                    unsafe_allow_html=True,
                )
            with mcols[3]:
                st.markdown(
                    f'<div class="{"approved-card" if approved else "loop-card"}"><div class="metric-value">{"Yes" if approved else "No"}</div><div class="metric-label">Critique Approved</div></div>',
                    unsafe_allow_html=True,
                )

            # ─── Full Pipeline Results ───
            render_pipeline_results(final_state)

            # ─── Debug Trace ───
            if "debug_trace" in final_state:
                with st.expander("Debug Trace (Graph Execution Log)", expanded=False):
                    for entry in final_state["debug_trace"]:
                        st.text(entry)

            # ─── Download ───
            st.markdown("---")
            st.markdown("### Export")
            dl_col1, dl_col2 = st.columns(2)
            with dl_col1:
                # Serialize the full state (exclude non-serializable items)
                export_state = {
                    k: v for k, v in final_state.items()
                    if k not in ("log_data", "knowledge_base")
                }
                st.download_button(
                    label="Download Full Pipeline Output (JSON)",
                    data=json.dumps(export_state, indent=2, default=str),
                    file_name=f"incident_triage_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                    mime="application/json",
                )
            with dl_col2:
                if isinstance(report, dict) and "error" not in report:
                    st.download_button(
                        label="Download Incident Report (JSON)",
                        data=json.dumps(report, indent=2, default=str),
                        file_name=f"incident_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                        mime="application/json",
                    )

        except Exception as e:
            st.error(f"Pipeline failed: {str(e)}")
            import traceback
            st.code(traceback.format_exc())


if __name__ == "__main__":
    main()
