# GitHub Copilot Component Map

| Component | Lab artifact | Role |
|---|---|---|
| Repository instructions | `.github/copilot-instructions.md` | Always-on project architecture/coding conventions |
| Portable agent context | `AGENTS.md` | Domain and workflow context |
| Path instructions | `.github/instructions/` | Rules scoped to code vs tests |
| Skill | `.github/skills/order-fallout-enhancement/SKILL.md` | Repeatable enhancement procedure |
| Developer agent | `.github/agents/order-fallout-developer.agent.md` | Specialist implementation role |
| Review agent | `.github/agents/test-reviewer.agent.md` | Specialist review role |
| MCP config | `.vscode/mcp.json`, `.mcp.json` | Connects VS Code/Copilot to local telecom reference tools |
| MCP tools | `mcp_server/server.py` | Supplies current router/policy facts |
| Prompt file | `.github/prompts/implement-enhancement.prompt.md` | Optional explicit reusable task template |
| Tests | `tests/` | Objective acceptance criteria |

## Why separate these?

A single giant prompt mixes:
- domain knowledge;
- coding conventions;
- task procedure;
- role/persona;
- changing enterprise data;
- current requirements.

This lab separates them so they can evolve independently and be version-controlled.
