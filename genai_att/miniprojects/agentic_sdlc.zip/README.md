# Telecom Order Fallout Prevention Agent — GitHub Copilot Customization Lab

This lab demonstrates how **GitHub Copilot in VS Code** can be customized for a real development workflow using version-controlled Markdown files and MCP tools.

The use case is a **Telecom Order Fallout Prevention Agent**.

A telecom order flows through CRM, product catalogue, eligibility, provisioning, billing, and activation systems. Bad combinations are often discovered only downstream. This demo checks an order *before submission* and identifies likely fallout causes.

The lab focuses on the **developer experience with GitHub Copilot**. The runtime is intentionally small.

## What the lab uses

- Python
- FastAPI
- mock Salesforce and ServiceNow adapters
- deterministic fallout checks
- local MCP server exposing current router specifications and policy data
- GitHub Copilot repository instructions
- path-specific instructions
- Agent Skills
- custom agents
- optional reusable prompt file

A production version could extend the same architecture with ML risk scoring, RAG over product/policy documents, LangGraph, real Salesforce APIs, and real ServiceNow APIs.

---

# 1. Enhancement scenario

The starter application already performs a couple of basic checks.

A new enhancement arrives:

> **ENH-101 — Prevent fallout for 1 Gbps 5G Business Internet orders**
>
> A recent router specification update says **XR-500 supports only up to 500 Mbps**.  
> A 1 Gbps order should use **XR-1000**.
>
> In addition:
>
> - a **site-readiness survey** is mandatory for 1 Gbps service;
> - migration from **MPLS** requires approval;
> - changing product specifications and policy facts must not be duplicated as hard-coded business constants;
> - the API should explain each detected risk and corrective action;
> - a remediation task can be created through a mock ServiceNow adapter.

The deliberately problematic order is:

```text
examples/order_high_risk.json
```

---

# 2. Copilot components demonstrated

| Copilot customization | File in this lab | Benefit |
|---|---|---|
| Repository instructions | `.github/copilot-instructions.md` | Always-on architecture, coding and testing rules |
| Cross-agent project guidance | `AGENTS.md` | Shared domain/workflow context |
| Path-specific instructions | `.github/instructions/*.instructions.md` | Different guidance for Python code and tests |
| Agent Skill | `.github/skills/order-fallout-enhancement/SKILL.md` | Reusable procedure for this class of enhancement |
| Custom developer agent | `.github/agents/order-fallout-developer.agent.md` | Specialist implementation role |
| Custom review agent | `.github/agents/test-reviewer.agent.md` | Specialist review role |
| MCP | `.vscode/mcp.json`, `.mcp.json`, `mcp_server/` | Access to current router/policy facts |
| Prompt file | `.github/prompts/implement-enhancement.prompt.md` | Optional reusable task entry point |

A useful mental model is:

```text
Prompt        = what do I want now?
Instructions  = what rules should normally be followed?
Skill         = how does our team perform this kind of task?
Agent         = which specialist role should perform it?
MCP           = what external tools/current data may the agent use?
Tests         = how do we objectively know the change works?
```

---

# 3. Prerequisites

Install:

1. VS Code
2. Python 3.11+
3. GitHub Copilot / GitHub Copilot Chat in VS Code
4. GitHub account with Copilot access

Open the **root folder of this lab** in VS Code.

No real telecom, Salesforce, or ServiceNow credentials are required.

---

# 4. Setup

## Windows PowerShell

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

## macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Run the baseline tests:

```bash
pytest tests/test_baseline.py -q
```

Expected: baseline tests pass.

Now run:

```bash
pytest tests/test_enhancement.py -q
```

Expected **before implementation**: failures.

That is intentional: the tests are executable acceptance criteria for ENH-101.

---

# 5. Run the starter API

Uvicorn is a lightning-fast ASGI web server for Python that runs asynchronous web applications such as FastAPI.
It listens for HTTP requests, passes them to the app (`src.api:app`), and returns the responses; `--reload` restarts it automatically when code changes.

```bash
uvicorn src.api:app --reload
```

Open:

```text
http://127.0.0.1:8000/docs
```

From the Web UI, Call:

```text
POST /analyze-order
```

Click on "Try it Out"
Replace the json with:

```json
{
  "order_id": "ORD-1003",
  "customer_id": "C-9001",
  "service": "5G_BUSINESS_INTERNET",
  "speed_mbps": 1000,
  "router_model": "XR-500",
  "site_survey_completed": false,
  "migration_from": "MPLS",
  "migration_approval_id": null
}
```

The starter code does **not** yet identify all required fallout risks.

---

# 6. Inspect the customization files before coding

## 6.1 Repository-wide instructions

Open:

```text
.github/copilot-instructions.md
```

Notice that Copilot is told:

- not to hard-code changing catalogue/policy facts;
- to keep mandatory constraints deterministic;
- to return evidence and remediation for each risk;
- to keep external integrations behind adapters;
- to run tests after changes.

### Benefit

You no longer need to repeat those rules in every prompt.

---

## 6.2 AGENTS.md

Open:

```text
AGENTS.md
```

It explains:

- the telecom fallout domain;
- architectural boundaries;
- repository layout;
- expected enhancement workflow.

### Benefit

Instead of a giant prompt, a participant can eventually say:

```text
Implement ENH-101.
```

and the stable repository context is already available.

### copilot-instructions.md vs AGENTS.md

| | `.github/copilot-instructions.md` | `AGENTS.md` |
|---|---|---|
| Audience | GitHub Copilot only | Any coding agent (Copilot, Claude Code, Codex, Cursor, etc.) |
| Nature | Tool-specific convention | Open, vendor-neutral convention |
| Typical content | Coding, architecture and testing rules | Domain context, repository layout, workflow |
| Location | Fixed: `.github/` | Repo root, or any subfolder |

Rule of thumb: put rules that every agent must follow in `AGENTS.md`, and Copilot-specific tuning in `copilot-instructions.md`. Copilot reads both, so overlap is harmless, but duplicated rules can drift apart.

### Why is it called AGENTS.md — where are the agents?

"Agents" here means **AI coding agents** (Copilot agent mode, Claude Code, Codex and similar tools). They are not files in this repository. The name reflects who reads the file: the agent, in the same way a `README.md` is written for human readers. Think of it as a README for agents.

### Does it apply to all agents? Can a specific agent have its own .md?

- `AGENTS.md` is the shared baseline. Every agent that supports the convention loads it automatically.
- In a monorepo, a nested `AGENTS.md` in a subfolder adds to or overrides the root one for files in that folder.
- A specific agent can have its own file. In this repo:
  - `.github/agents/order-fallout-developer.agent.md` and `.github/agents/test-reviewer.agent.md` define custom Copilot agents, each with its own role, instructions and tools. They apply only when that agent is selected.
  - `.github/instructions/*.instructions.md` apply only to files matching a glob, such as tests or Python code.
  - Other tools have their own files, for example `CLAUDE.md` for Claude Code.

Broad to narrow: `AGENTS.md` (all agents) → `copilot-instructions.md` (all Copilot chats) → `*.instructions.md` (matching files) → `*.agent.md` (one specific agent).

---

## 6.3 Path-specific instructions

Open:

```text
.github/instructions/python.instructions.md
.github/instructions/tests.instructions.md
```

The Python instructions apply to application code.

The test instructions emphasize validating both:

- the risk condition;
- the corrective recommendation.

### Benefit

Test-specific guidance does not clutter every coding interaction.

---

## 6.4 Agent Skill

Open:

```text
.github/skills/order-fallout-enhancement/SKILL.md
```

It captures the repeatable procedure:

1. read the enhancement;
2. inspect tests;
3. separate stable constraints from changing reference facts;
4. query current reference information;
5. implement through clean boundaries;
6. run tests;
7. summarize results.

### Benefit

The **development process itself** becomes reusable, version-controlled knowledge.

---

## 6.5 Custom agents

Open:

```text
.github/agents/order-fallout-developer.agent.md
.github/agents/test-reviewer.agent.md
```

In Copilot Chat, open the agent picker.

The workspace should expose specialist agents such as:

- **Order Fallout Developer**
- **Test Reviewer**

### Order Fallout Developer (`order-fallout-developer.agent.md`)

The implementation specialist.

- **Role:** implements fallout-prevention enhancements with explainable rules, reference-data boundaries and tests.
- **Tools:** has access to the `telecom-reference` MCP server (`telecom-reference/*`), so it can look up current router and policy facts.
  - The `tools` list in the frontmatter is an allowlist for this agent only.
  - Format: `<mcp-server-name>/<tool-name>`. `telecom-reference` is the server name defined in `.vscode/mcp.json`, which runs `mcp_server/server.py`.
  - `/*` grants every tool from that server, such as `get_router_spec` and `get_policy`. You could name one tool instead, for example `telecom-reference/get_router_spec`.
  - The server must be started (**MCP: List Servers**), otherwise the tools are unavailable to the agent.
- **Workflow:**
  1. read the brief and tests before editing;
  2. separate mandatory constraints from changing reference facts;
  3. query the reference tools instead of hard-coding facts into `src/fallout.py`;
  4. keep API, domain logic, reference providers and adapters separate;
  5. make the smallest coherent change;
  6. run the relevant tests, then the full suite;
  7. report what changed and why.
- **Guardrail:** if an MCP tool is unavailable, it must not invent facts. It states which fact has to come from the reference data.
- It also uses the `order-fallout-enhancement` skill when relevant.

### Test Reviewer (`test-reviewer.agent.md`)

The review specialist.

- **Role:** reviews an implementation against the acceptance criteria, edge cases and architecture.
- **Tools:** none declared, so it only inspects code and tests. It has no MCP access.
- **It checks that:**
  - every requested fallout condition is covered;
  - risk codes are stable;
  - reasons are explainable and remediations actionable;
  - clean orders do not get a false HIGH risk;
  - changing catalogue/policy facts are not hard-coded;
  - external actions stay behind adapters;
  - tests validate behavior, not implementation details.
- **Output:** a concise list of concrete findings with file references. It does not propose a broad rewrite unless the acceptance criteria need one.

### Scope: which files apply when you edit `src/fallout.py`?

There is no mapping from a source file to an agent. Nothing in the repo links `src/fallout.py` to `order-fallout-developer.agent.md`.

What applies automatically to `src/fallout.py`:

- `AGENTS.md` and `.github/copilot-instructions.md` apply to every chat.
- `.github/instructions/python.instructions.md` has `applyTo: "src/**/*.py"`, so it matches `fallout.py`. This is the only file-based mapping.

An `*.agent.md` file has no `applyTo`. It defines a persona that you select in the Copilot Chat agent picker, and it applies only to that chat. Editing `fallout.py` in plain Copilot chat, or under another agent, never loads the developer agent.

| Mechanism | Scope | Trigger |
|---|---|---|
| `AGENTS.md`, `copilot-instructions.md` | Whole repo | Automatic |
| `*.instructions.md` | Files matching `applyTo` | Automatic |
| `*.agent.md` | One chat session | You select it |
| `*.prompt.md` | One task | You run it, for example `/implement-enhancement` |
| `SKILL.md` | On demand | The agent decides it is relevant |

The developer agent's rules, such as keeping changing facts out of `src/fallout.py`, are guidance it follows once selected. They are not enforced by a file mapping.

To make the agent apply to `fallout.py`, you can:

- add a line to `python.instructions.md` or `copilot-instructions.md` telling Copilot to use the Order Fallout Developer agent;
- set an `agent:` field in `implement-enhancement.prompt.md`, which does not name an agent today;
- select the agent yourself each time.

### Benefit

The developer and reviewer do not need to share one generic persona and one giant prompt.

---

# 7. MCP demo: current router and policy facts

The lab contains:

```text
.vscode/mcp.json
.mcp.json
mcp_server/server.py
```

The MCP server is called:

```text
telecom-reference
```

It exposes tools equivalent to:

```text
get_router_spec(model)
get_policy(policy_code)
```

The underlying demo data is:

```text
mcp_server/data/router_specs.json
mcp_server/data/policies.json
```

## Windows

The supplied `.vscode/mcp.json` points to:

```text
.venv\Scripts\python.exe
```

## macOS/Linux

Use the portable `.mcp.json`, or copy the contents of:

```text
.vscode/mcp-macos-linux.example.json
```

into `.vscode/mcp.json`.

## How VS Code finds mcp.json

VS Code does not scan the disk for `mcp.json`. It reads MCP servers from fixed locations:

| Scope | Location | Applies to |
|---|---|---|
| Workspace | `<opened folder>/.vscode/mcp.json` | Only this project |
| User (global) | `mcp.json` in the VS Code user profile folder. Open it with **MCP: Open User Configuration**. | All your workspaces |

- **This lab uses the workspace scope.** VS Code looks in `.vscode/` of the folder you opened (`File > Open Folder`), which is why the file must live in this repo and not in a global VS Code folder. Open the lab folder itself, not a parent folder, or the file is not picked up.
- **It is separate from `settings.json`.** MCP servers are not configured in `settings.json`. They have their own `mcp.json`, in the same `.vscode/` folder as workspace settings or in the user profile folder next to the global `settings.json`.
- **Why it belongs in the repo:** committing it means everyone who clones the lab gets the same `telecom-reference` server. Paths use `${workspaceFolder}`, so they resolve to wherever the repo was cloned.
- **The root `.mcp.json` is not read by VS Code.** It is the portable, project-level convention used by other tools such as Claude Code.
- **Trust prompt:** VS Code asks you to trust a workspace MCP server before it starts it for the first time, because the file makes VS Code run a local command.

## Verify in VS Code

1. Press `Ctrl+Shift+P`.
2. Run **MCP: List Servers**.
3. Locate `telecom-reference`.
4. Start it if necessary.
5. Open Copilot Agent mode.
6. Inspect available tools.


Ask:

```text
Using telecom-reference, tell me:
1. the maximum supported speed of XR-500,
2. a router that supports 1000 Mbps,
3. the prerequisites for a 1 Gbps 5G Business Internet order,
4. whether MPLS migration requires approval.
```

The MCP tool should expose current facts including:

```text
XR-500 -> max 500 Mbps
XR-1000 -> max 1000 Mbps
1 Gbps -> site-readiness survey required
MPLS migration -> approval required
```

### Why this matters

These facts can change independently from the application.

A poor implementation might add:

```python
if router == "XR-500" and speed == 1000:
    ...
```

all over the codebase.

The intended implementation keeps changing facts behind the reference-provider/tool boundary.

---

# 8. Read the enhancement

Open:

```text
lab/ENHANCEMENT.md
```

Also inspect:

```text
tests/test_enhancement.py
```

This is important: the tests are objective acceptance criteria.

---

# 9. Implement ENH-101 with Copilot

Select the **Order Fallout Developer** custom agent.

Use this intentionally short prompt:

```text
Implement ENH-101 from lab/ENHANCEMENT.md.
Use the repository instructions and the order-fallout enhancement skill.
Inspect the acceptance tests first.
Use telecom-reference for current catalogue/policy facts where relevant.
Run the tests when finished.
```

Observe how the customization layers guide the work.

Copilot should be nudged toward:

1. reading the enhancement and tests;
2. discovering that current router/policy facts belong behind a provider;
3. consulting the MCP reference tools/data;
4. detecting all three requested risks;
5. returning corrective actions;
6. avoiding direct ServiceNow logic inside the analyzer;
7. preserving existing tests;
8. running `pytest -q`.

AI output is nondeterministic. Evaluate the implementation against the acceptance criteria, architecture rules, and tests rather than against one exact diff.

---

# 10. Expected business behavior

For `ORD-1003`, the implementation should detect three independent problems.

## Unsupported router

```text
Requested speed: 1000 Mbps
Router: XR-500
Current XR-500 maximum: 500 Mbps
```

Expected risk code:

```text
UNSUPPORTED_ROUTER
```

Expected remediation should recommend a compatible router such as:

```text
XR-1000
```

## Missing site-readiness survey

Expected risk code:

```text
SITE_SURVEY_REQUIRED
```

Expected remediation:

```text
complete/schedule site-readiness survey
```

## Missing MPLS migration approval

Expected risk code:

```text
MPLS_APPROVAL_REQUIRED
```

Expected remediation:

```text
obtain MPLS migration approval
```

---

# 11. Run all tests

After Copilot finishes:

```bash
pytest -q
```

A successful implementation should satisfy:

- baseline behavior;
- all ENH-101 acceptance tests;
- a compliant 1 Gbps order remains LOW risk.

---

# 12. Run the API again

```bash
uvicorn src.api:app --reload
```

Submit:

```text
examples/order_high_risk.json
```

A good response should be conceptually similar to:

```json
{
  "order_id": "ORD-1003",
  "risk_level": "HIGH",
  "risks": [
    {
      "code": "UNSUPPORTED_ROUTER",
      "reason": "XR-500 supports only 500 Mbps",
      "recommended_action": "Use XR-1000 or another router supporting 1000 Mbps"
    },
    {
      "code": "SITE_SURVEY_REQUIRED",
      "reason": "A site-readiness survey is mandatory for 1 Gbps service",
      "recommended_action": "Complete the site-readiness survey"
    },
    {
      "code": "MPLS_APPROVAL_REQUIRED",
      "reason": "MPLS migration requires approval",
      "recommended_action": "Obtain MPLS migration approval"
    }
  ]
}
```

Exact wording can differ.

---

# 13. Demonstrate the review agent

Switch to:

```text
Test Reviewer
```

Ask:

```text
Review the ENH-101 implementation against lab/ENHANCEMENT.md and
tests/test_enhancement.py.

Identify:
- missing acceptance criteria,
- untested edge cases,
- accidental hard-coding,
- architecture violations.

Do not redesign the whole application.
```

### Benefit

The specialist role and review procedure are reusable.

The developer agent changes code.

The reviewer agent challenges the result.

---

# 14. Optional reusable prompt

The lab also includes:

```text
.github/prompts/implement-enhancement.prompt.md
```

Prompt files can package an explicit reusable chat task in supported VS Code environments.

For reusable **capabilities/workflows**, skills are generally the more important concept in this lab.

---

# 15. Compare: without customization vs with customization

## Without customization

A realistic prompt becomes repetitive:

```text
Implement ENH-101.
This is FastAPI.
Do not hard-code router specifications.
Use adapters.
Keep mandatory rules deterministic.
Return evidence and remediation.
Read tests first.
Do not put ServiceNow logic in fallout.py.
Use type hints.
Run pytest.
...
```

Every developer has to remember those expectations.

## With customization

The interaction can be closer to:

```text
Implement ENH-101.
```

because reusable context is stored in:

```text
.github/copilot-instructions.md
AGENTS.md
.github/instructions/
.github/skills/
.github/agents/
.vscode/mcp.json
```

The benefits are:

- shorter prompts;
- consistency across developers;
- architecture guardrails;
- repeatable team workflows;
- specialist roles;
- current enterprise data through tools;
- version-controlled AI-development practices.

---

# 16. How the pieces integrate

```text
                    GitHub Copilot
                          |
       +------------------+------------------+
       |                  |                  |
 Instructions           Skill              Agent
 rules/context       task workflow       specialist role
       |                  |                  |
       +------------------+------------------+
                          |
                         MCP
                 tools + current facts
                          |
             +------------+------------+
             |                         |
      Product catalogue            Policy source
        mock in lab                 mock in lab
                          |
                          v
                    Python changes
                          |
                          v
                        tests
```

For ENH-101:

```text
copilot-instructions.md
  -> do not hard-code changing catalogue facts

SKILL.md
  -> requirements -> current facts -> implementation -> tests

Order Fallout Developer
  -> specialist implementation role

telecom-reference MCP
  -> XR-500 max 500 Mbps
  -> XR-1000 supports 1000 Mbps
  -> survey/approval policies

tests
  -> objective acceptance criteria
```

---

# 17. Instructor discussion prompts

1. What belongs in repository instructions versus a skill?
2. What belongs in an agent definition rather than instructions?
3. Why should router specifications come from data/tools rather than prompts?
4. Which constraints should remain deterministic?
5. Where would ML help when historical fallout data is available?
6. Where would RAG help when policies and product specs are mainly PDFs?
7. Which enterprise systems could become MCP tools?
8. Should an agent automatically create a ServiceNow task, or require approval?
9. Which actions would you allow Copilot to perform and which would you restrict?

---

# 18. Production evolution

A production solution could evolve toward:

```text
Salesforce / CRM order
        |
        v
Order normalizer
        |
        +------> deterministic mandatory rules
        |
        +------> catalogue / eligibility / provisioning tools
        |
        +------> RAG over product + policy documents
        |
        +------> ML fallout probability + likely cause ranking
        |
        v
Agent orchestration
        |
        +--> explain risk
        +--> recommend correction
        +--> request missing data
        +--> create remediation task with governed approval
```

The Copilot customization approach remains useful as the application grows.

---

# Lab outcome

The key lesson is that Copilot customization is not just about writing a longer prompt.

Put stable knowledge in the right reusable layer:

- **Instructions** — persistent rules
- **Skills** — repeatable procedures
- **Agents** — specialist roles
- **MCP/tools** — external capabilities and changing facts
- **Tests** — executable acceptance criteria
