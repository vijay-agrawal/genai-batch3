from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Protocol


class ReferenceProvider(Protocol):
    def get_router_spec(self, model: str) -> dict[str, Any] | None:
        ...

    def get_policy(self, policy_code: str) -> dict[str, Any] | None:
        ...


class FileReferenceProvider:
    # File-backed stand-in for catalogue/policy systems used by the runtime demo.
    # The same data is exposed through MCP so Copilot can inspect authoritative,
    # changing facts while implementing the enhancement.

    def __init__(self, data_dir: Path | None = None) -> None:
        self.data_dir = data_dir or Path(__file__).resolve().parents[1] / "mcp_server" / "data"

    def _read(self, name: str) -> dict[str, Any]:
        return json.loads((self.data_dir / name).read_text(encoding="utf-8"))

    def get_router_spec(self, model: str) -> dict[str, Any] | None:
        return self._read("router_specs.json").get(model)

    def get_policy(self, policy_code: str) -> dict[str, Any] | None:
        return self._read("policies.json").get(policy_code)
