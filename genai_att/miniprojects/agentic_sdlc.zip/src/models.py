from typing import Literal

from pydantic import BaseModel, Field


class TelecomOrder(BaseModel):
    order_id: str
    customer_id: str
    service: str
    speed_mbps: int = Field(gt=0)
    router_model: str
    site_survey_completed: bool = False
    migration_from: str | None = None
    migration_approval_id: str | None = None


class FalloutRisk(BaseModel):
    code: str
    reason: str
    recommended_action: str


class FalloutAnalysis(BaseModel):
    order_id: str
    risk_level: Literal["LOW", "MEDIUM", "HIGH"]
    risks: list[FalloutRisk]
