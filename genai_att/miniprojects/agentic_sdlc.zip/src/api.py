from fastapi import FastAPI

from src.fallout import analyze_order
from src.integrations.servicenow import create_remediation_task
from src.models import FalloutAnalysis, TelecomOrder
from src.reference_provider import FileReferenceProvider

app = FastAPI(title="Telecom Order Fallout Prevention Demo")
references = FileReferenceProvider()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/analyze-order", response_model=FalloutAnalysis)
def analyze(order: TelecomOrder) -> FalloutAnalysis:
    return analyze_order(order, references)


@app.post("/orders/{order_id}/remediation-task")
def remediation(order_id: str, summary: str) -> dict[str, str]:
    return create_remediation_task(order_id=order_id, summary=summary)
