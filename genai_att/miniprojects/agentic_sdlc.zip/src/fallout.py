from src.models import FalloutAnalysis, FalloutRisk, TelecomOrder
from src.reference_provider import ReferenceProvider


def analyze_order(order: TelecomOrder, references: ReferenceProvider) -> FalloutAnalysis:
    # Starter implementation. ENH-101 is intentionally not implemented yet.
    risks: list[FalloutRisk] = []

    if not order.customer_id.strip():
        risks.append(
            FalloutRisk(
                code="CUSTOMER_ID_REQUIRED",
                reason="The order has no customer identifier.",
                recommended_action="Add a valid CRM customer identifier before submission.",
            )
        )

    # Legacy starter rule.
    if order.service == "5G_BUSINESS_INTERNET" and order.speed_mbps > 1000:
        risks.append(
            FalloutRisk(
                code="SPEED_NOT_SUPPORTED",
                reason="The starter service supports speeds up to 1000 Mbps.",
                recommended_action="Select a supported speed tier.",
            )
        )

    risk_level = "HIGH" if risks else "LOW"
    return FalloutAnalysis(order_id=order.order_id, risk_level=risk_level, risks=risks)
