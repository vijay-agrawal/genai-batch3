def get_order_from_salesforce(order_id: str) -> dict[str, str]:
    # Mock only. Production code would use a governed Salesforce adapter.
    return {"order_id": order_id, "source": "mock-salesforce"}
