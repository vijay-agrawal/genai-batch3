def create_remediation_task(order_id: str, summary: str) -> dict[str, str]:
    # Mock only. Production code would use a governed ServiceNow adapter.
    return {
        "task_id": f"RITM-{order_id}",
        "status": "CREATED",
        "summary": summary,
    }
