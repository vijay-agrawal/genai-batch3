# Telecom Order Fallout Prevention — Agent Guidance

## Domain

This repository demonstrates pre-submission fallout prevention for telecom orders.

Orders may fail downstream because of incompatible devices, missing prerequisites, provisioning constraints, contract conditions, migration requirements, or stale product assumptions.

The demo uses a hybrid design:

- deterministic checks for mandatory constraints;
- external reference providers/tools for facts that change independently of application code;
- room for future ML/RAG scoring of probabilistic or previously unseen fallout patterns.

## Core engineering principles

1. Do not duplicate rapidly changing router specifications, product-catalogue data, or policy text inside fallout business logic.
2. Keep mandatory constraints deterministic and explainable.
3. Every risk should contain:
   - a stable risk code;
   - a human-readable reason/evidence;
   - a corrective recommendation.
4. External systems must be accessed through adapters/providers.
5. The demo must remain runnable without real Salesforce or ServiceNow credentials.
6. Preserve backward compatibility unless the enhancement explicitly changes it.
7. Read acceptance tests before implementation.
8. Run tests before considering an enhancement complete.

## Repository layout

- `src/api.py` — FastAPI endpoints
- `src/models.py` — request/response models
- `src/fallout.py` — business analysis
- `src/reference_provider.py` — boundary for changing catalogue/policy facts
- `src/integrations/` — mock enterprise-system adapters
- `mcp_server/` — local MCP server exposing current reference facts
- `tests/` — executable acceptance criteria
- `lab/` — enhancement brief

## Expected enhancement workflow

1. Read the enhancement brief.
2. Inspect current behavior and tests.
3. Separate stable business logic from changing external facts.
4. Query or inspect the authoritative reference source where available.
5. Make the smallest coherent implementation.
6. Add or satisfy tests.
7. Run the full test suite.
8. Summarize assumptions and remaining production gaps.
