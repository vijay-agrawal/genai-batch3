# ENH-101 — Prevent fallout for 1 Gbps 5G Business Internet orders

## Background

Operations has seen downstream failures for 1 Gbps 5G Business Internet orders.

A router specification changed recently. The provisioning policy was also updated.

The application should detect these issues before order submission.

## Example failing order

`examples/order_high_risk.json`

The order requests:

- 5G Business Internet
- 1000 Mbps
- XR-500 router
- no completed site-readiness survey
- migration from MPLS
- no migration approval

## Acceptance criteria

1. Incompatible router -> `UNSUPPORTED_ROUTER`.
2. Remediation recommends a router compatible with requested speed.
3. Missing required site-readiness survey -> `SITE_SURVEY_REQUIRED`.
4. MPLS migration without required approval -> `MPLS_APPROVAL_REQUIRED`.
5. Every risk has an actionable `recommended_action`.
6. A compliant 1 Gbps order remains LOW risk.
7. Changing catalogue/policy facts must be accessed through the reference-provider boundary rather than duplicated as scattered constants in `fallout.py`.
8. Existing 2000 Mbps unsupported-speed behavior continues to work.
9. No live Salesforce, ServiceNow, or telecom API is required.

## Reference information

Current facts are exposed by the local `telecom-reference` MCP server and the file-backed runtime provider.

Do not treat this ticket text as the long-term source of truth for router/policy facts.

## Optional extension

After successful analysis, use the existing mock ServiceNow adapter to create a remediation task containing a risk summary.

Keep task creation separate from the fallout decision function.
