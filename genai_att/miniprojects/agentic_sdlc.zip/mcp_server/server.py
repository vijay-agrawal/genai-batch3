from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

DATA_DIR = Path(__file__).resolve().parent / "data"
mcp = FastMCP("telecom-reference")


def _read(name: str) -> dict[str, Any]:
    return json.loads((DATA_DIR / name).read_text(encoding="utf-8"))


@mcp.tool()
def get_router_spec(model: str) -> dict[str, Any]:
    """Return the current product-catalogue specification for a router model."""
    record = _read("router_specs.json").get(model)
    if record is None:
        return {"found": False, "model": model}
    return {"found": True, "model": model, **record}


@mcp.tool()
def get_policy(policy_code: str) -> dict[str, Any]:
    """Return the current effective telecom-order policy by policy code."""
    record = _read("policies.json").get(policy_code)
    if record is None:
        return {"found": False, "policy_code": policy_code}
    return {"found": True, "policy_code": policy_code, **record}


if __name__ == "__main__":
    mcp.run(transport="stdio")
