from src.fallout import analyze_order
from src.models import TelecomOrder
from src.reference_provider import FileReferenceProvider


def _high_risk_order() -> TelecomOrder:
    return TelecomOrder(
        order_id="ORD-1003",
        customer_id="C-9001",
        service="5G_BUSINESS_INTERNET",
        speed_mbps=1000,
        router_model="XR-500",
        site_survey_completed=False,
        migration_from="MPLS",
        migration_approval_id=None,
    )


def test_enh_101_detects_all_three_fallout_causes() -> None:
    result = analyze_order(_high_risk_order(), FileReferenceProvider())

    codes = {risk.code for risk in result.risks}

    assert result.risk_level == "HIGH"
    assert "UNSUPPORTED_ROUTER" in codes
    assert "SITE_SURVEY_REQUIRED" in codes
    assert "MPLS_APPROVAL_REQUIRED" in codes


def test_enh_101_recommends_a_supported_router() -> None:
    result = analyze_order(_high_risk_order(), FileReferenceProvider())

    router_risk = next(r for r in result.risks if r.code == "UNSUPPORTED_ROUTER")
    assert "XR-1000" in router_risk.recommended_action


def test_enh_101_has_actionable_prerequisite_remediation() -> None:
    result = analyze_order(_high_risk_order(), FileReferenceProvider())

    by_code = {risk.code: risk for risk in result.risks}

    assert "survey" in by_code["SITE_SURVEY_REQUIRED"].recommended_action.lower()
    assert "approval" in by_code["MPLS_APPROVAL_REQUIRED"].recommended_action.lower()


def test_compliant_1_gbps_order_is_not_high_risk() -> None:
    order = TelecomOrder(
        order_id="ORD-1004",
        customer_id="C-9002",
        service="5G_BUSINESS_INTERNET",
        speed_mbps=1000,
        router_model="XR-1000",
        site_survey_completed=True,
        migration_from="MPLS",
        migration_approval_id="APR-7788",
    )

    result = analyze_order(order, FileReferenceProvider())

    assert result.risk_level == "LOW"
    assert result.risks == []
