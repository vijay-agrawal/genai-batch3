from src.fallout import analyze_order
from src.models import TelecomOrder
from src.reference_provider import FileReferenceProvider


def test_clean_500_mbps_order_is_low_risk() -> None:
    order = TelecomOrder(
        order_id="ORD-1001",
        customer_id="C-100",
        service="5G_BUSINESS_INTERNET",
        speed_mbps=500,
        router_model="XR-500",
        site_survey_completed=False,
    )

    result = analyze_order(order, FileReferenceProvider())

    assert result.risk_level == "LOW"
    assert result.risks == []


def test_speed_above_supported_demo_tier_is_high_risk() -> None:
    order = TelecomOrder(
        order_id="ORD-1002",
        customer_id="C-101",
        service="5G_BUSINESS_INTERNET",
        speed_mbps=2000,
        router_model="XR-1000",
        site_survey_completed=True,
    )

    result = analyze_order(order, FileReferenceProvider())

    assert result.risk_level == "HIGH"
    assert "SPEED_NOT_SUPPORTED" in {risk.code for risk in result.risks}
