---
applyTo: "tests/**/*.py"
---

# Test instructions

- Treat tests as executable acceptance criteria.
- Test observable behavior rather than private implementation details.
- For every fallout condition, validate:
  1. the stable risk code;
  2. an appropriate corrective action.
- Include at least one clean/low-risk order.
- Do not use live network services in tests.
- Use in-memory or file-backed fakes for changing catalogue/policy facts.
