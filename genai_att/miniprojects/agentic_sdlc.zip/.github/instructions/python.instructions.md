---
applyTo: "src/**/*.py"
---

# Python application-code instructions

- Use type hints for public functions and methods.
- Keep FastAPI endpoint code thin; domain decisions belong outside the endpoint.
- Isolate changing reference data behind `ReferenceProvider` or another explicit adapter.
- Keep deterministic mandatory rules readable.
- Risk messages must explain both **why** an order is risky and **what should be done**.
- Do not put ServiceNow task-creation logic inside the fallout analyzer.
- Prefer dependency injection over module-level mutable state.
