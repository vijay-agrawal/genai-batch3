---
name: order-fallout-enhancement
description: Implement or review a telecom order-fallout prevention enhancement using deterministic constraints, current reference data, explainable risks, remediation actions, and tests.
---

# Order Fallout Enhancement Skill

Use this workflow when implementing or reviewing an order-fallout enhancement.

## 1. Establish acceptance criteria

Read:
- the enhancement brief;
- relevant tests;
- existing analyzer behavior.

List expected risk codes and remediations before editing.

## 2. Classify requirements

Separate them into:

### Stable deterministic logic

Examples:
- missing required approval;
- missing mandatory site survey.

### Changing reference facts

Examples:
- router maximum supported speed;
- currently approved router for a service tier;
- effective policy prerequisites.

Changing facts should come through a reference provider/tool rather than be copied into business logic.

## 3. Use current reference information

When `telecom-reference` MCP tools are available, use them to inspect current router and policy facts.

Relevant tools:
- `get_router_spec(model)`
- `get_policy(policy_code)`

Do not invent missing catalogue facts.

## 4. Implement through clean boundaries

Prefer:

```text
fallout analyzer
      |
ReferenceProvider
      |
mock/file/MCP-backed source
```

Do not directly couple FastAPI endpoints to reference files.

## 5. Preserve explainability

For every risk return:
- code;
- reason/evidence;
- recommended action.

## 6. Preserve workflow separation

The analyzer may recommend remediation, but the ServiceNow adapter owns task creation.

## 7. Validate

Run:

```bash
pytest -q
```

Check:
- enhancement cases pass;
- baseline behavior still passes;
- changing router/policy facts were not unnecessarily duplicated in business logic.

## 8. Report

Summarize:
- files changed;
- risks detected;
- where current reference facts come from;
- assumptions or production gaps.
