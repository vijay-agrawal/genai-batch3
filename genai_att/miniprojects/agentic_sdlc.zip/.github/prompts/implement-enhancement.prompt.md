---
description: Implement a telecom order fallout enhancement
---

Read `lab/ENHANCEMENT.md`, repository instructions, and relevant tests.

Use the order-fallout enhancement skill.

Implement the enhancement using the smallest coherent change. Use current telecom reference information through the configured tool/provider rather than duplicating rapidly changing catalogue or policy facts in business logic.

Run the tests and summarize the result.
