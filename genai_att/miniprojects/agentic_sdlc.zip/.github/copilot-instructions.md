# GitHub Copilot repository instructions

You are working on a teaching repository for a Telecom Order Fallout Prevention Agent.

## Architecture

- API: FastAPI.
- Domain decisions belong outside the endpoint.
- External-system behavior belongs behind adapters/providers.
- Rapidly changing telecom catalogue, device, or policy facts must not be duplicated as hard-coded business constants when a reference provider/tool exists.
- Mandatory constraints should remain deterministic and explainable.
- Future probabilistic ML/RAG logic should augment, not silently override, mandatory constraints.

## Output contract

Each risk should have:
- a stable machine-readable risk code;
- evidence/reason;
- a recommended corrective action.

Risk aggregation should remain simple and explainable for this lab.

## Development behavior

- Read relevant tests before changing production code.
- Prefer small, focused changes.
- Preserve type hints.
- Do not add dependencies unless necessary.
- Do not call real Salesforce, ServiceNow, or telecom endpoints.
- Never commit secrets.
- Run `pytest -q` after implementation changes.

## Teaching objective

When an enhancement depends on changed router specs or policy facts, demonstrate separation between:
- application reasoning;
- current facts retrieved through a provider/MCP tool.

Do not solve a changing-data problem by copying today's value into several Python `if` statements.
