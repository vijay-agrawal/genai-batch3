"""
Partner Commission Support Optimizer - Streamlit UI
Processes partner support calls using Agentic AI with optional Azure STT.
"""

import streamlit as st
import json
import os
import sys
import yaml
import time
import tempfile
import pandas as pd
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

# Add src to path
sys.path.append(str(Path(__file__).parent / "src"))

from agents.agent_manager import AgentManager
from services.data_service import get_data_service
from services.speech_service import get_speech_service

# Load environment
load_dotenv()

# ─── Page Config ─────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Partner Commission Support Optimizer",
    page_icon="📞",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ──────────────────────────────────────────────────────────────

st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        color: #009FDB;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1rem;
        color: #666;
        text-align: center;
        margin-bottom: 2rem;
    }
    .agent-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        border-left: 4px solid #009FDB;
    }
    .success-box {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        border-radius: 0.25rem;
        padding: 0.75rem;
        margin: 0.5rem 0;
    }
    .error-box {
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        border-radius: 0.25rem;
        padding: 0.75rem;
        margin: 0.5rem 0;
    }
    .warning-box {
        background-color: #fff3cd;
        border: 1px solid #ffc107;
        border-radius: 0.25rem;
        padding: 0.75rem;
        margin: 0.5rem 0;
    }
    .pipeline-stage {
        text-align: center;
        padding: 0.5rem;
        border-radius: 0.3rem;
        font-size: 0.8rem;
        font-weight: bold;
    }
    .stage-active {
        background-color: #ff6b6b;
        color: white;
    }
    .stage-completed {
        background-color: #51cf66;
        color: white;
    }
    .stage-pending {
        background-color: #e9ecef;
        color: #666;
    }
    .metric-card {
        background: linear-gradient(135deg, #009FDB 0%, #0077a8 100%);
        color: white;
        padding: 1rem;
        border-radius: 0.5rem;
        text-align: center;
    }
</style>
""", unsafe_allow_html=True)


# ─── Config & Init ───────────────────────────────────────────────────────────

def load_config():
    config_path = Path("src/config/config.yaml")
    if not config_path.exists():
        st.error(f"Configuration file not found at {config_path}")
        st.stop()
    with open(config_path, "r") as f:
        config_str = f.read()
    for key, value in os.environ.items():
        config_str = config_str.replace(f"${{{key}}}", value)
    return yaml.safe_load(config_str)


@st.cache_resource
def initialize_agent_manager():
    try:
        config = load_config()
        return AgentManager(config)
    except Exception as e:
        st.error(f"Failed to initialize agent manager: {str(e)}")
        st.stop()


def load_sample_transcripts():
    svc = get_data_service()
    return {t["transcript_id"]: t for t in svc.transcripts}


# ─── Pipeline Visualization ──────────────────────────────────────────────────

def render_pipeline(current_stage: str):
    """Render a horizontal pipeline visualization."""
    stages = [
        ("Initial Triage", "initial_triage"),
        ("Agent Review", "agent_review"),
        ("Backend Verification", "backend_verification"),
        ("Escalation Queue", "escalation_queue"),
        ("Manager Approval", "manager_approval"),
        ("Payment Processing", "payment_processing"),
        ("Completed", "completed"),
    ]

    current_idx = next((i for i, (_, key) in enumerate(stages) if key == current_stage), -1)
    cols = st.columns(len(stages))

    for i, (label, key) in enumerate(stages):
        with cols[i]:
            if i < current_idx:
                st.markdown(f'<div class="pipeline-stage stage-completed">{label}</div>', unsafe_allow_html=True)
            elif i == current_idx:
                st.markdown(f'<div class="pipeline-stage stage-active">** {label} **</div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="pipeline-stage stage-pending">{label}</div>', unsafe_allow_html=True)

    if current_idx >= 0:
        st.markdown(f"<p style='text-align:center; color:#ff6b6b; font-weight:bold;'>Stuck at: {stages[current_idx][0]}</p>", unsafe_allow_html=True)


# ─── Commission Comparison Table ─────────────────────────────────────────────

def render_commission_table(comm_data: dict):
    """Render a commission breakdown comparison table."""
    if not comm_data:
        st.info("No commission data available.")
        return

    is_correct = comm_data.get("is_correct", True)
    correct_comm = comm_data.get("correct_commission", 0)
    paid_comm = comm_data.get("paid_commission", 0)
    discrepancy = comm_data.get("discrepancy", 0)

    rows = []

    # Rate rows
    base_rate = comm_data.get("base_rate", "N/A")
    tier_bonus = comm_data.get("tier_bonus", "N/A")
    volume_bonus = comm_data.get("volume_bonus", "N/A")
    effective_rate = comm_data.get("effective_rate", "N/A")

    if isinstance(base_rate, (int, float)):
        rows.append({"Field": "Base Product Rate", "Expected": f"{base_rate*100:.0f}%", "Actual": f"{base_rate*100:.0f}%", "Status": "OK"})
    if isinstance(tier_bonus, (int, float)):
        actual_tier = tier_bonus if is_correct or comm_data.get("root_cause") != "tier_bonus_omitted" else 0
        status = "OK" if actual_tier == tier_bonus else "ERROR"
        rows.append({"Field": "Tier Bonus", "Expected": f"+{tier_bonus*100:.1f}%", "Actual": f"+{actual_tier*100:.1f}%", "Status": status})
    if isinstance(volume_bonus, (int, float)) and volume_bonus > 0:
        actual_vol = volume_bonus if is_correct or comm_data.get("root_cause") != "volume_bonus_missed" else 0
        status = "OK" if actual_vol == volume_bonus else "ERROR"
        rows.append({"Field": "Volume Bonus", "Expected": f"+{volume_bonus*100:.1f}%", "Actual": f"+{actual_vol*100:.1f}%", "Status": status})
    if isinstance(effective_rate, (int, float)):
        rows.append({"Field": "Effective Rate", "Expected": f"{effective_rate*100:.1f}%", "Actual": "See above", "Status": "OK" if is_correct else "ERROR"})

    rows.append({"Field": "Contract Value", "Expected": f"${comm_data.get('contract_value', 0):,.2f}", "Actual": f"${comm_data.get('contract_value', 0):,.2f}", "Status": "OK"})
    rows.append({"Field": "Commission Due", "Expected": f"${correct_comm:,.2f}", "Actual": f"${paid_comm:,.2f}", "Status": "OK" if is_correct else "ERROR"})

    if not is_correct:
        rows.append({"Field": "Discrepancy", "Expected": "$0.00", "Actual": f"${discrepancy:,.2f}", "Status": "ERROR"})

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)


# ─── Main App ────────────────────────────────────────────────────────────────

def main():
    st.markdown('<h1 class="main-header">Partner Commission Support Optimizer</h1>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">AI-powered call analysis, duplicate detection, commission verification & ticket tracking</p>', unsafe_allow_html=True)

    # ── Sidebar ──
    st.sidebar.title("Control Panel")

    # Initialize services
    agent_manager = initialize_agent_manager()
    data_svc = get_data_service()
    speech_svc = get_speech_service()

    # Input mode
    input_mode = st.sidebar.radio(
        "Input Method:",
        ["Select Sample Transcript", "Record Audio", "Upload Audio File", "Enter Ticket Text"],
    )

    transcript_text = ""
    recorded_audio = None

    if input_mode == "Select Sample Transcript":
        transcripts = load_sample_transcripts()
        if transcripts:
            options = {f"{t['transcript_id']} - {t['partner_name']}": tid for tid, t in transcripts.items()}
            selected = st.sidebar.selectbox("Choose a transcript:", list(options.keys()))
            if selected:
                tid = options[selected]
                t = transcripts[tid]
                transcript_text = t["transcript"]
                st.sidebar.markdown(f"**Partner:** {t['partner_name']}")
                st.sidebar.markdown(f"**Date:** {t['call_date']}")
                st.sidebar.markdown(f"**Duration:** {t['duration_seconds']}s")
        else:
            st.sidebar.warning("No sample transcripts. Run `python generate_data.py` first.")

    elif input_mode == "Record Audio":
        st.sidebar.markdown("**Record a call transcript:**")
        try:
            from audio_recorder_streamlit import audio_recorder
            recorded_audio = audio_recorder(
                text="Click to record",
                recording_color="#009FDB",
                neutral_color="#6c757d",
                icon_size="2x",
                pause_threshold=3.0,
            )
            if recorded_audio:
                st.sidebar.audio(recorded_audio, format="audio/wav")
                if speech_svc.available:
                    st.sidebar.success("Recording captured. Click 'Process Call' to transcribe and analyze.")
                else:
                    st.sidebar.warning("Azure Speech key not configured. Set AZURE_SPEECH_KEY in .env for STT.")
        except ImportError:
            st.sidebar.error("Install audio-recorder-streamlit: `pip install audio-recorder-streamlit`")

    elif input_mode == "Upload Audio File":
        uploaded_file = st.sidebar.file_uploader("Upload audio (.wav, .mp3)", type=["wav", "mp3"])
        if uploaded_file:
            if speech_svc.available:
                st.sidebar.success("Azure Speech service ready for transcription.")
            else:
                st.sidebar.warning("Azure Speech key not configured. Set AZURE_SPEECH_KEY in .env for STT.")

    elif input_mode == "Enter Ticket Text":
        transcript_text = st.sidebar.text_area(
            "Enter ticket / transcript text:",
            height=250,
            placeholder="Channel Manager: Thank you for calling...\n\nPartner: Hi, I'm calling about...\n\nOr simply describe the issue:\nPartner PTR-1003 called about sale SL-50015. Commission underpaid by $360...",
        )

    process_btn = st.sidebar.button("Process Call", type="primary", use_container_width=True)

    # ── Processing ──
    if process_btn:
        # Handle recorded audio
        if input_mode == "Record Audio":
            if recorded_audio and speech_svc.available:
                with st.spinner("Transcribing recorded audio with Azure Speech-to-Text..."):
                    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                        tmp.write(recorded_audio)
                        tmp_path = tmp.name
                    try:
                        stt_result = speech_svc.transcribe_audio(tmp_path)
                        transcript_text = stt_result["text"]
                        st.success("Recording transcribed successfully!")
                    except Exception as e:
                        st.error(f"Transcription failed: {e}")
                    finally:
                        os.unlink(tmp_path)
            elif recorded_audio and not speech_svc.available:
                st.error("Cannot transcribe: Azure Speech key not configured. Set AZURE_SPEECH_KEY in .env.")
                return
            else:
                st.warning("Please record audio first.")
                return

        # Handle audio upload
        elif input_mode == "Upload Audio File":
            if uploaded_file and speech_svc.available:
                with st.spinner("Transcribing audio with Azure Speech-to-Text..."):
                    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                        tmp.write(uploaded_file.getbuffer())
                        tmp_path = tmp.name
                    try:
                        stt_result = speech_svc.transcribe_audio(tmp_path)
                        transcript_text = stt_result["text"]
                        st.success("Audio transcribed successfully!")
                    except Exception as e:
                        st.error(f"Transcription failed: {e}")
                    finally:
                        os.unlink(tmp_path)
            elif uploaded_file and not speech_svc.available:
                st.error("Cannot transcribe: Azure Speech key not configured. Set AZURE_SPEECH_KEY in .env.")
                return
            else:
                st.warning("Please upload an audio file.")
                return

        if not transcript_text.strip():
            st.warning("No transcript text to process. Please provide input.")
            return

        # Show transcript
        with st.expander("Call Transcript", expanded=True):
            st.text(transcript_text)

        # Run the agent pipeline
        with st.spinner("Running AI Agent Pipeline..."):
            progress = st.progress(0)
            status = st.empty()

            status.text("Step 1/6: Analyzing transcript...")
            progress.progress(10)

            result = agent_manager.process_call(transcript_text)

            progress.progress(100)
            status.empty()
            progress.empty()

        if "error" in result and "_agent_outputs" not in result:
            st.error(f"Pipeline error: {result['error']}")
            if "_debug_trace" in result:
                with st.expander("Debug Trace"):
                    for line in result["_debug_trace"]:
                        st.text(line)
            return

        # ── Display Results ──

        # Row 1: Extracted Info
        st.markdown("---")
        col1, col2 = st.columns([3, 2])

        extracted = result.get("extracted_info", {})
        with col1:
            st.subheader("Extracted Information")
            info_cols = st.columns(3)
            with info_cols[0]:
                st.metric("Partner", f"{extracted.get('partner_id', 'N/A')}")
                st.caption(extracted.get("partner_name", ""))
            with info_cols[1]:
                st.metric("Sale ID", extracted.get("sale_id", "N/A"))
            with info_cols[2]:
                issue = extracted.get("issue_type", "N/A")
                urgency = extracted.get("urgency", "N/A")
                st.metric("Issue Type", issue.replace("_", " ").title())
                urgency_color = {"high": "red", "medium": "orange", "low": "green"}.get(urgency, "gray")
                st.markdown(f"Urgency: <span style='color:{urgency_color}; font-weight:bold'>{urgency.upper()}</span>", unsafe_allow_html=True)

        with col2:
            st.subheader("Quick Summary")
            summary = result.get("summary", "Processing complete.")
            st.markdown(f'<div class="agent-card">{summary}</div>', unsafe_allow_html=True)

        # Row 2: Duplicate Check + Commission Verification
        st.markdown("---")
        col_dup, col_comm = st.columns(2)

        with col_dup:
            st.subheader("Duplicate Ticket Check")
            dup = result.get("duplicate_check", {})
            if dup.get("duplicates_found"):
                existing = dup.get("existing_tickets", [])
                st.markdown(f'<div class="warning-box">Duplicate tickets found: {", ".join(existing) if isinstance(existing, list) else existing}</div>', unsafe_allow_html=True)
                if dup.get("recommendation"):
                    st.info(f"Recommendation: {dup['recommendation']}")
            else:
                st.markdown('<div class="success-box">No duplicate tickets found. This is a new issue.</div>', unsafe_allow_html=True)

        with col_comm:
            st.subheader("Commission Verification")
            comm = result.get("commission_verification", {})
            if comm:
                is_correct = comm.get("is_correct", True)
                if not is_correct:
                    disc = comm.get("discrepancy", 0)
                    root_cause = comm.get("root_cause", "Unknown")
                    st.markdown(f'<div class="error-box">Discrepancy: ${disc:,.2f} | Root Cause: {root_cause}</div>', unsafe_allow_html=True)
                else:
                    st.markdown('<div class="success-box">Commission is correctly calculated. No discrepancy.</div>', unsafe_allow_html=True)

                render_commission_table(comm)

        # Row 3: Ticket Pipeline
        st.markdown("---")
        st.subheader("Ticket Pipeline Status")
        ticket_status = result.get("ticket_status", {})
        current_stage = ticket_status.get("current_stage", "")

        if current_stage:
            render_pipeline(current_stage)

            info_cols = st.columns(3)
            with info_cols[0]:
                st.metric("Days in System", ticket_status.get("days_in_system", "N/A"))
            with info_cols[1]:
                st.metric("Assigned To", ticket_status.get("assigned_to", "Unassigned"))
            with info_cols[2]:
                st.metric("Bottleneck", ticket_status.get("bottleneck", "None identified"))
        else:
            st.info("No existing ticket found in pipeline. A new ticket would be created.")

        # Row 4: Root Cause Analysis
        st.markdown("---")
        st.subheader("Root Cause Analysis (Backend System Correlation)")
        rca = result.get("rca_findings", {})
        if rca and rca.get("trace_found"):
            st.markdown('<div class="error-box"><strong>Backend System Issue Traced</strong></div>', unsafe_allow_html=True)

            # Show matched backend issues
            backend_issues = rca.get("backend_issues", [])
            if backend_issues:
                issue_rows = []
                for bi in backend_issues:
                    issue_rows.append({
                        "Issue ID": bi.get("issue_id", "N/A"),
                        "Error Code": bi.get("error_code", "N/A"),
                        "System": bi.get("system", "N/A"),
                        "Impact": bi.get("impact", "N/A"),
                        "Severity": bi.get("severity", "N/A"),
                        "Resolved": "Yes" if bi.get("resolved") else "No",
                    })
                st.dataframe(pd.DataFrame(issue_rows), use_container_width=True, hide_index=True)

            # Root cause summary
            rca_summary = rca.get("root_cause_summary", "")
            if rca_summary:
                st.markdown(f'<div class="agent-card"><strong>Root Cause:</strong> {rca_summary}</div>', unsafe_allow_html=True)

            # Ticket update note
            ticket_note = rca.get("ticket_update_note", "")
            if ticket_note:
                st.info(f"**Ticket Update Note (auto-appended):** {ticket_note}")
        elif rca:
            st.markdown('<div class="success-box">No backend system issues found for this order. The issue may require manual investigation.</div>', unsafe_allow_html=True)
        else:
            st.info("RCA data not available.")

        # Row 5: Recommended Actions
        st.markdown("---")
        st.subheader("Recommended Actions")
        actions = result.get("recommended_actions", [])
        if actions:
            for i, action in enumerate(actions, 1):
                st.markdown(f"**{i}.** {action}")
        else:
            st.info("No specific actions recommended at this time.")

        auto_resolve = result.get("auto_resolution_possible", False)
        if auto_resolve:
            st.markdown('<div class="success-box"><strong>Auto-Resolution Eligible:</strong> This issue can be automatically resolved based on the verified data.</div>', unsafe_allow_html=True)

        # Agent Reasoning Trace
        with st.expander("Agent Reasoning Trace"):
            debug_trace = result.get("_debug_trace", [])
            if debug_trace:
                for line in debug_trace:
                    st.text(line)
            else:
                st.info("No debug trace available.")

        # Raw Agent Outputs
        with st.expander("Raw Agent Outputs"):
            agent_outputs = result.get("_agent_outputs", {})
            for agent_name, output in agent_outputs.items():
                st.subheader(agent_name.replace("_", " ").title())
                st.text(output[:2000])

        # Download result
        clean_result = {k: v for k, v in result.items() if not k.startswith("_")}
        st.download_button(
            label="Download Full Report (JSON)",
            data=json.dumps(clean_result, indent=2),
            file_name=f"partner_support_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            mime="application/json",
        )


if __name__ == "__main__":
    main()
