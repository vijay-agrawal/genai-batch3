# Partner Commission Support Optimizer

An AI-powered demo that optimizes how a large telecom company handles partner commission support — replacing slow, manual ticket workflows with an intelligent Agentic AI pipeline that analyzes calls in real time, detects duplicates, verifies commissions, traces backend system errors as root cause, and pinpoints where tickets are stuck.

---

## Business Use Case

Large telecom companies rely on **3rd-party sales partners** (resellers, dealers, agents) to sell their products — fiber, wireless, SD-WAN, VoIP, security bundles, etc. Partners earn **commissions** on every sale based on product rates, partner tier bonuses, and volume incentives.

A dedicated **Partner Support team** handles inbound calls from these partners when issues arise with their commissions. A **Channel Manager** answers the call, understands the problem, and creates a support ticket that moves through a backend verification pipeline.

### Pain Points This Demo Addresses

| Pain Point | Impact | How This Demo Solves It |
|---|---|---|
| **Incorrect commission calculations** — tier bonuses omitted, wrong product rates applied, volume bonuses missed | Partners lose trust; revenue leakage | Agentic AI **recalculates commissions from scratch** using official rules and pinpoints the exact root cause of any discrepancy |
| **Delayed payments** — commissions stuck in backend verification for days or weeks | Partner cash flow issues; repeated escalation calls | **Status Tracker agent** identifies the exact pipeline stage where a ticket is stuck and how long it has been there |
| **Duplicate tickets** — partners call multiple times about the same issue, each time a new ticket is created | Wasted agent time; fragmented ticket history | **Duplicate Detector agent** searches for existing tickets for the same partner + sale combination before creating a new one |
| **Slow manual triage** — channel managers spend time manually looking up partner info, sales records, and commission details | High handle time per call; team overwhelmed | AI pipeline **automates the entire investigation** in seconds — from transcript analysis to resolution recommendation |
| **No visibility into where things are stuck** — partners and channel managers can't see why a ticket isn't progressing | Frustration; repeated status inquiry calls | **Pipeline visualization** shows the exact stage, bottleneck, and recommended next step |
| **No traceability to backend system errors** — commission delays caused by system timeouts, failed ETL jobs, or service outages are invisible to support agents | Agents can't explain *why* things went wrong; resolution requires manual investigation across multiple systems | **RCA Agent** automatically correlates the partner's complaint with backend system error logs (connection timeouts, stale rate caches, batch failures, etc.) and surfaces the root cause in real time |

---

## Architecture

```
              ┌──────────────────────────────────────┐
              │          Partner Call Input           │
              │  Record Audio | Upload | Enter Text   │
              └─────────────────┬────────────────────┘
                                │
                 ┌──────────────▼──────────────┐
                 │   Azure Speech-to-Text      │  (Optional)
                 │   (Azure AI Foundry STT)    │
                 └──────────────┬──────────────┘
                                │
       ┌────────────────────────▼──────────────────────────┐
       │              6-Agent Sequential Pipeline           │
       │                  (Microsoft AutoGen)               │
       │                                                    │
       │  ┌───────────────────────────────────────────┐    │
       │  │ 1. Transcript Analyzer                     │    │
       │  │    Extracts: partner_id, sale_id,          │    │
       │  │    issue_type, urgency, summary            │    │
       │  └─────────────────┬─────────────────────────┘    │
       │                    │                               │
       │  ┌─────────────────▼─────────────────────────┐    │
       │  │ 2. Duplicate Detector                      │    │
       │  │    Searches existing tickets for same       │    │
       │  │    partner + sale combination               │    │
       │  └─────────────────┬─────────────────────────┘    │
       │                    │                               │
       │  ┌─────────────────▼─────────────────────────┐    │
       │  │ 3. Commission Verifier                     │    │
       │  │    Recalculates correct commission,         │    │
       │  │    identifies discrepancy & root cause      │    │
       │  └─────────────────┬─────────────────────────┘    │
       │                    │                               │
       │  ┌─────────────────▼─────────────────────────┐    │
       │  │ 4. Status Tracker                          │    │
       │  │    Finds ticket pipeline stage,             │    │
       │  │    bottleneck, and time stuck                │    │
       │  └─────────────────┬─────────────────────────┘    │
       │                    │                               │
       │  ┌─────────────────▼─────────────────────────┐    │
       │  │ 5. RCA Agent (NEW)                         │    │
       │  │    Correlates with backend_issues.json      │    │
       │  │    Traces system errors → commission impact │    │
       │  │    Auto-generates ticket update note        │    │
       │  └─────────────────┬─────────────────────────┘    │
       │                    │                               │
       │  ┌─────────────────▼─────────────────────────┐    │
       │  │ 6. Resolution Agent                        │    │
       │  │    Synthesizes all findings into JSON       │    │
       │  │    report with recommended actions          │    │
       │  └───────────────────────────────────────────┘    │
       └────────────────────┬──────────────────────────────┘
                            │
               ┌────────────▼─────────────┐
               │      Streamlit UI        │
               │  - Extracted info        │
               │  - Duplicate check       │
               │  - Commission table      │
               │  - Pipeline visualization│
               │  - RCA findings panel    │
               │  - Recommended actions   │
               └──────────────────────────┘
```

### Technology Stack

| Component | Technology |
|---|---|
| Agent Framework | Microsoft AutoGen (ag2) |
| LLM | Azure OpenAI (gpt-4o-mini via Azure AI Foundry) |
| Speech-to-Text | Azure Cognitive Services Speech SDK |
| Text-to-Speech | Azure Cognitive Services Speech SDK (SSML multi-voice) |
| UI | Streamlit |
| Data | Synthetic JSON (generated with Python) |
| Config | YAML with environment variable substitution |

---

## Key Highlights

### 1. Realistic Synthetic Data Pipeline
- **25 partners** across 4 tiers (Platinum/Gold/Silver/Bronze) and 5 regions
- **250 sales** across 10 product lines (Fiber, Wireless, VoIP, SD-WAN, Security)
- **250 commission calculations** — 15-20% intentionally contain errors (tier bonus omitted, wrong product rate, volume bonus missed, incorrect contract value)
- **62 backend system issues** — realistic errors (connection timeouts, stale rate caches, ETL failures, payment gateway timeouts, partner account holds, batch processor failures) linked to sales by order_id
- **48 support tickets** at various pipeline stages, including 7 deliberate duplicate pairs
- **10 realistic call transcripts** covering 8 scenario types (underpayment, delayed payment, duplicate inquiry, clawback dispute, volume bonus, status check, multiple issues, escalation)

### 2. Multi-Voice TTS Audio Generation
- Call transcripts are converted to audio using **Azure AI Foundry TTS** with SSML
- Two distinct voices: `en-US-JennyNeural` (Channel Manager) and `en-US-GuyNeural` (Partner)
- Produces realistic two-party conversation audio files

### 3. Agentic AI with Tool Use (6-Agent Pipeline)
- Each agent has a focused responsibility and access to specific tools
- **Commission Verifier** recalculates from first principles using official product rates, tier bonuses, and volume thresholds — then compares against what was actually paid
- **Duplicate Detector** queries the ticket database to prevent redundant ticket creation
- **Status Tracker** maps tickets to pipeline stages and identifies the specific bottleneck
- **RCA Agent** correlates the partner's complaint with `backend_issues.json` entries by order_id to find the technical root cause (e.g., "connection timeout caused tier bonus to be omitted") and auto-generates a ticket update note

### 4. Real-Time Root Cause Analysis for Human Agents
- When the channel manager enters a ticket (text or recorded audio), the system immediately shows:
  - Which backend system failed (e.g., "Commission Calculation Engine", "Payment Gateway")
  - The exact error code and description
  - How that error impacted the commission (e.g., "tier_bonus_omitted", "delayed_payment")
  - Whether the backend issue is resolved or still open
  - A ready-to-use ticket update note the agent can append
- This eliminates the manual investigation loop and dramatically reduces resolution time

### 5. Browser Audio Recording
- Channel managers can **record audio directly in the browser** using the built-in microphone recorder
- Recording is sent to Azure STT for transcription, then processed through the full 6-agent pipeline
- Also supports uploading pre-recorded audio files (.wav, .mp3)

### 6. Pipeline Visualization
- Horizontal pipeline view: Initial Triage → Agent Review → Backend Verification → Escalation Queue → Manager Approval → Payment Processing → Completed
- Current stage highlighted in red with "stuck at" indicator
- Shows days in system, assigned team, and bottleneck description

### 7. Commission Comparison Table
- Side-by-side breakdown: expected vs. actual for base rate, tier bonus, volume bonus, effective rate, contract value, and commission amount
- Each row flagged as OK or ERROR
- Root cause displayed when discrepancy is found

---

## Project Structure

```
partner_commission_support/
├── app.py                        # Streamlit UI entry point
├── generate_data.py              # Synthetic data + TTS audio generator
├── requirements.txt              # Python dependencies
├── .env                          # Environment variables (Azure keys)
├── .gitignore
├── README.md
└── src/
    ├── agents/
    │   ├── base_agent.py             # Base class for all agents
    │   ├── agent_manager.py          # Pipeline orchestrator (6-agent sequence)
    │   ├── transcript_analyzer.py    # Step 1: Extract info from transcript
    │   ├── duplicate_detector.py     # Step 2: Check for duplicate tickets
    │   ├── commission_verifier.py    # Step 3: Recalculate & verify commission
    │   ├── status_tracker.py         # Step 4: Track pipeline stage & bottleneck
    │   ├── rca_agent.py              # Step 5: Root cause analysis via backend issues
    │   └── resolution_agent.py       # Step 6: Synthesize findings & recommend
    ├── config/
    │   └── config.yaml               # Configuration with env var substitution
    ├── data/
    │   ├── generated/                # JSON data files (output of generate_data.py)
    │   │   ├── partners.json
    │   │   ├── sales_records.json
    │   │   ├── commission_rules.json
    │   │   ├── commission_calculations.json
    │   │   ├── backend_issues.json
    │   │   ├── support_tickets.json
    │   │   └── call_transcripts.json
    │   └── audio/                    # TTS-generated .wav files
    ├── services/
    │   ├── speech_service.py         # Azure STT/TTS wrapper
    │   └── data_service.py           # JSON data loader with query methods
    └── tools/
        ├── commission_tools.py       # Tools: lookup_partner, recalculate_commission, etc.
        └── ticket_tools.py           # Tools: search_tickets, get_ticket_status, search_backend_issues
```

---

## Setup & How to Run

### Prerequisites
- Python 3.10+
- An Azure OpenAI deployment (gpt-4o-mini or similar) via Azure AI Foundry
- (Optional) An Azure Speech resource for STT/TTS

### 1. Install Dependencies

```bash
cd partner_commission_support
pip install -r requirements.txt
```

### 2. Configure Environment Variables

Edit the `.env` file with your Azure credentials:

```env
# Required — Azure OpenAI
API_TYPE=azure
AZURE_OPENAI_API_KEY=your_azure_openai_key
AZURE_OPENAI_ENDPOINT=https://your-resource.cognitiveservices.azure.com/openai/deployments/gpt-4o-mini/chat/completions?api-version=2024-05-01-preview
AZURE_OPENAI_DEPLOYMENT=gpt-4o-mini
AZURE_OPENAI_API_VERSION=2024-05-01-preview
MODEL_NAME=gpt-4o-mini
TEMPERATURE=0.1
MAX_TOKENS=2000

# Optional — Azure Speech (for STT/TTS)
AZURE_SPEECH_KEY=your_azure_speech_key
AZURE_SPEECH_REGION=eastus
```

### 3. Generate Synthetic Data

```bash
python generate_data.py
```

This creates all JSON data files in `src/data/generated/`. If `AZURE_SPEECH_KEY` is configured, it also generates `.wav` audio files in `src/data/audio/` using Azure TTS with two distinct voices.

### 4. Launch the Application

```bash
streamlit run app.py
```

### 5. Using the Demo

1. **Select a sample transcript** from the sidebar dropdown (10 pre-built scenarios)
2. **Or record audio** directly in the browser using the microphone button
3. **Or upload an audio file** (.wav/.mp3) — requires Azure Speech key for STT transcription
4. **Or enter ticket text** — type/paste a transcript or free-form issue description
5. Click **"Process Call"** to run the 6-agent pipeline
6. Review the results:
   - Extracted partner/sale/issue information
   - Duplicate ticket detection results
   - Commission verification breakdown table
   - Pipeline stage visualization showing where the ticket is stuck
   - **Root Cause Analysis** — backend system errors correlated with the complaint, with ticket update note
   - AI-recommended actions
   - Full agent reasoning trace (expandable)

---

## Sample Scenarios Included

| # | Scenario | Issue Type | What the AI Finds |
|---|---|---|---|
| 1 | Tier bonus omitted | Incorrect commission | Tier bonus not applied; calculates exact underpayment |
| 2 | Wrong product rate | Incorrect commission | Different rate used; shows correct vs. applied rate |
| 3 | Payment not received | Delayed payment | Payment stuck in backend verification |
| 4 | Follow-up on existing ticket | Duplicate inquiry | Finds original ticket; shows it's in pending-verification |
| 5 | Volume bonus missing | Incorrect commission | Partner qualifies for volume bonus but it wasn't applied |
| 6 | Clawback dispute | Clawback dispute | Customer flagged as churned but may still be active |
| 7 | Multiple issues | Multiple issues | Both wrong amount AND delayed payment on same sale |
| 8 | Status check | Status inquiry | Reports pipeline stage, days stuck, assigned team |
| 9 | Wrong contract value | Incorrect commission | Commission calculated on different base amount |
| 10 | Escalation / frustration | Incorrect commission | Third call; recommends immediate escalation with supervisor CC |
