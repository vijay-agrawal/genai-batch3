"""
Synthetic Data Generator for Partner Commission Support Optimizer.
Generates partners, sales, commissions, tickets, call transcripts, and TTS audio.
"""

import json
import random
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

DATA_DIR = Path(__file__).parent / "src" / "data" / "generated"
AUDIO_DIR = Path(__file__).parent / "src" / "data" / "audio"
DATA_DIR.mkdir(parents=True, exist_ok=True)
AUDIO_DIR.mkdir(parents=True, exist_ok=True)

random.seed(42)

# ─── Constants ───────────────────────────────────────────────────────────────

PARTNER_COMPANIES = [
    "Apex Wireless Solutions", "Metro Connect Partners", "TechBridge Communications",
    "Summit Telecom Group", "Horizon Digital Services", "BlueLine Networks",
    "Pacific Comm Solutions", "ClearPath Wireless", "Pinnacle Connectivity",
    "FrontRange Telecom", "DataWave Partners", "SilverLink Communications",
    "CrossPoint Networks", "EagleComm Solutions", "NorthStar Digital",
    "RedRock Telecom", "CrystalNet Partners", "TrueBeam Wireless",
    "VantagePoint Comms", "IronBridge Networks", "SkyReach Solutions",
    "GreenField Telecom", "PrimeWave Partners", "ArcLight Communications",
    "SwiftConnect Group"
]

CONTACT_FIRST_NAMES = [
    "James", "Sarah", "Michael", "Jennifer", "Robert", "Lisa", "David",
    "Maria", "Thomas", "Karen", "Richard", "Susan", "Christopher", "Nancy",
    "Daniel", "Patricia", "Matthew", "Linda", "Andrew", "Barbara",
    "Kevin", "Sandra", "Brian", "Donna", "Mark"
]

CONTACT_LAST_NAMES = [
    "Whitfield", "Reynolds", "Chen", "Patel", "Johnson", "Williams", "Garcia",
    "Martinez", "Anderson", "Taylor", "Thomas", "Hernandez", "Moore", "Jackson",
    "Wilson", "Lopez", "Harris", "Clark", "Lewis", "Robinson",
    "Walker", "Young", "King", "Wright", "Scott"
]

TIERS = ["Platinum", "Gold", "Silver", "Bronze"]
TIER_WEIGHTS = [0.10, 0.25, 0.35, 0.30]

REGIONS = ["Northeast", "Southeast", "Midwest", "Southwest", "West"]

CHANNEL_MANAGERS = ["Sarah", "David", "Maria", "James", "Lisa"]

PRODUCTS = {
    "FIBER-500":            {"name": "Fiber 500Mbps",             "min_value": 1200,  "max_value": 6000},
    "FIBER-1G":             {"name": "Fiber 1Gbps",               "min_value": 2400,  "max_value": 9600},
    "FIBER-5G":             {"name": "Fiber 5Gbps",               "min_value": 4800,  "max_value": 14400},
    "WIRELESS-BIZ-UNLTD":   {"name": "Business Unlimited Wireless","min_value": 600,  "max_value": 3600},
    "WIRELESS-BIZ-SHARED":  {"name": "Business Shared Wireless",  "min_value": 360,   "max_value": 2400},
    "VOIP-STANDARD":        {"name": "VoIP Standard",             "min_value": 300,   "max_value": 2400},
    "VOIP-PREMIUM":         {"name": "VoIP Premium",              "min_value": 600,   "max_value": 4800},
    "SD-WAN-BASIC":         {"name": "SD-WAN Basic",              "min_value": 3000,  "max_value": 12000},
    "SD-WAN-ENTERPRISE":    {"name": "SD-WAN Enterprise",         "min_value": 6000,  "max_value": 18000},
    "SECURITY-BUNDLE":      {"name": "Security Bundle",           "min_value": 1500,  "max_value": 9000},
}

COMMISSION_RULES = {
    "product_rates": {
        "FIBER-500":           {"base_rate": 0.08, "description": "8% of contract value"},
        "FIBER-1G":            {"base_rate": 0.10, "description": "10% of contract value"},
        "FIBER-5G":            {"base_rate": 0.12, "description": "12% of contract value"},
        "WIRELESS-BIZ-UNLTD":  {"base_rate": 0.07, "description": "7% of contract value"},
        "WIRELESS-BIZ-SHARED": {"base_rate": 0.06, "description": "6% of contract value"},
        "VOIP-STANDARD":       {"base_rate": 0.05, "description": "5% of contract value"},
        "VOIP-PREMIUM":        {"base_rate": 0.09, "description": "9% of contract value"},
        "SD-WAN-BASIC":        {"base_rate": 0.11, "description": "11% of contract value"},
        "SD-WAN-ENTERPRISE":   {"base_rate": 0.14, "description": "14% of contract value"},
        "SECURITY-BUNDLE":     {"base_rate": 0.10, "description": "10% of contract value"},
    },
    "tier_bonuses": {
        "Platinum": 0.03,
        "Gold":     0.02,
        "Silver":   0.01,
        "Bronze":   0.00,
    },
    "volume_bonuses": {
        "threshold_10": {"min_sales": 10, "bonus": 0.005, "description": "0.5% bonus for 10+ sales/quarter"},
        "threshold_25": {"min_sales": 25, "bonus": 0.01,  "description": "1% bonus for 25+ sales/quarter"},
        "threshold_50": {"min_sales": 50, "bonus": 0.02,  "description": "2% bonus for 50+ sales/quarter"},
    },
    "clawback_rules": {
        "churn_within_90_days":  "full_clawback",
        "churn_within_180_days": "50_percent_clawback",
    },
}

CUSTOMER_COMPANIES = [
    "DataFlow Corp", "Pinnacle Logistics", "Evergreen Healthcare", "Quantum Manufacturing",
    "Silverstone Financial", "BrightPath Education", "Atlas Engineering", "Horizon Retail",
    "NovaTech Solutions", "Meridian Consulting", "Cascade Properties", "Summit Legal Group",
    "BlueSky Media", "IronClad Security", "Vertex Analytics", "Coastal Distributors",
    "Alpine Construction", "Prairie Foods Inc", "MetroStyle Fashion", "TrueNorth Insurance",
]

TICKET_STATUSES = ["open", "in-review", "pending-verification", "escalated", "manager-approval", "payment-processing", "resolved", "duplicate-closed"]
PIPELINE_STAGES = {
    "open":                  "initial_triage",
    "in-review":             "agent_review",
    "pending-verification":  "backend_verification",
    "escalated":             "escalation_queue",
    "manager-approval":      "manager_approval",
    "payment-processing":    "payment_processing",
    "resolved":              "completed",
    "duplicate-closed":      "duplicate_closed",
}
VERIFICATION_TEAMS = ["verification_team_a", "verification_team_b", "verification_team_c"]

ERROR_TYPES = [
    "tier_bonus_omitted",
    "wrong_product_rate",
    "volume_bonus_missed",
    "incorrect_contract_value",
]

# Backend system issue templates — these represent real backend errors
# that can explain why a commission payment was delayed or miscalculated.
BACKEND_ISSUE_TYPES = [
    {
        "error_code": "ERR-CONN-TIMEOUT",
        "system": "Commission Calculation Engine",
        "category": "system_connection_error",
        "description": "Connection timeout while fetching partner tier data from Partner Master DB. Fallback to base rate only.",
        "impact": "tier_bonus_omitted",
    },
    {
        "error_code": "ERR-PROD-NOCOMM",
        "system": "Product Catalog Service",
        "category": "product_not_commissionable",
        "description": "Product type temporarily flagged as non-commissionable during catalog sync. Commission batch skipped this order.",
        "impact": "delayed_payment",
    },
    {
        "error_code": "ERR-RATE-STALE",
        "system": "Rate Card Service",
        "category": "stale_rate_cache",
        "description": "Rate card cache served outdated product rate. Cache TTL expired but refresh failed due to upstream service degradation.",
        "impact": "wrong_product_rate",
    },
    {
        "error_code": "ERR-VOL-SYNC",
        "system": "Volume Tracker Service",
        "category": "volume_count_sync_failure",
        "description": "Partner sales volume count not synced from Sales Ledger. Nightly ETL job failed; volume bonus threshold not evaluated.",
        "impact": "volume_bonus_missed",
    },
    {
        "error_code": "ERR-CONTRACT-MISMATCH",
        "system": "Contract Management System",
        "category": "contract_value_mismatch",
        "description": "Contract amendment not propagated to commission system. Original (lower) contract value used for calculation.",
        "impact": "incorrect_contract_value",
    },
    {
        "error_code": "ERR-PAY-GATEWAY",
        "system": "Payment Gateway",
        "category": "payment_gateway_timeout",
        "description": "Payment gateway returned HTTP 504 during commission disbursement batch. Payment queued for retry but retry window exceeded SLA.",
        "impact": "delayed_payment",
    },
    {
        "error_code": "ERR-DUP-ORDER",
        "system": "Order Deduplication Service",
        "category": "duplicate_order_hold",
        "description": "Order flagged by dedup service as potential duplicate. Automatic hold placed pending manual review; commission blocked.",
        "impact": "delayed_payment",
    },
    {
        "error_code": "ERR-ACTIVATION-LAG",
        "system": "Provisioning System",
        "category": "activation_status_lag",
        "description": "Activation status update delayed from provisioning system. Commission engine saw order as 'pending' during batch run.",
        "impact": "delayed_payment",
    },
    {
        "error_code": "ERR-PARTNER-HOLD",
        "system": "Partner Account Service",
        "category": "partner_account_hold",
        "description": "Partner account placed on temporary compliance hold. All commission disbursements suspended until hold cleared.",
        "impact": "delayed_payment",
    },
    {
        "error_code": "ERR-BATCH-PARTIAL",
        "system": "Commission Batch Processor",
        "category": "batch_partial_failure",
        "description": "Nightly commission batch failed at row 847/1200. Orders after failure point not processed. Batch rerun scheduled but delayed.",
        "impact": "delayed_payment",
    },
]


# ─── Generators ──────────────────────────────────────────────────────────────

def generate_partners(count=25):
    partners = []
    for i in range(count):
        pid = f"PTR-{1001 + i}"
        tier = random.choices(TIERS, weights=TIER_WEIGHTS, k=1)[0]
        first = CONTACT_FIRST_NAMES[i]
        last = CONTACT_LAST_NAMES[i]
        company = PARTNER_COMPANIES[i]
        domain = company.lower().replace(" ", "").replace(",", "")[:15]
        partners.append({
            "partner_id": pid,
            "name": company,
            "tier": tier,
            "contact_name": f"{first} {last}",
            "contact_email": f"{first[0].lower()}.{last.lower()}@{domain}.com",
            "contact_phone": f"555-{random.randint(200,999)}-{random.randint(1000,9999)}",
            "region": random.choice(REGIONS),
            "active_since": f"{random.randint(2019,2024)}-{random.randint(1,12):02d}-{random.randint(1,28):02d}",
            "total_sales_ytd": random.randint(5, 80),
            "commission_account": f"ACH-{random.randint(10000,99999)}",
        })
    return partners


def generate_sales(partners, count=250):
    base_date = datetime(2025, 10, 1)
    sales = []
    for i in range(count):
        sid = f"SL-{50001 + i}"
        partner = random.choice(partners)
        prod_code = random.choice(list(PRODUCTS.keys()))
        prod_info = PRODUCTS[prod_code]
        sale_date = base_date + timedelta(days=random.randint(0, 90))
        contract_value = round(random.randint(prod_info["min_value"], prod_info["max_value"]) / 100) * 100
        activation_offset = random.randint(3, 14)
        status = random.choices(["activated", "pending", "churned"], weights=[0.85, 0.10, 0.05], k=1)[0]
        sales.append({
            "sale_id": sid,
            "partner_id": partner["partner_id"],
            "product_code": prod_code,
            "product_name": prod_info["name"],
            "sale_date": sale_date.strftime("%Y-%m-%d"),
            "customer_name": random.choice(CUSTOMER_COMPANIES),
            "contract_value": contract_value,
            "contract_term_months": random.choice([12, 24, 36]),
            "sale_status": status,
            "activation_date": (sale_date + timedelta(days=activation_offset)).strftime("%Y-%m-%d") if status == "activated" else None,
        })
    return sales


def generate_commissions(partners, sales):
    partner_map = {p["partner_id"]: p for p in partners}
    # Count sales per partner for volume bonus
    partner_sale_counts = {}
    for s in sales:
        partner_sale_counts[s["partner_id"]] = partner_sale_counts.get(s["partner_id"], 0) + 1

    calculations = []
    error_indices = set(random.sample(range(len(sales)), k=int(len(sales) * 0.17)))

    for i, sale in enumerate(sales):
        partner = partner_map[sale["partner_id"]]
        prod_code = sale["product_code"]
        base_rate = COMMISSION_RULES["product_rates"][prod_code]["base_rate"]
        tier_bonus = COMMISSION_RULES["tier_bonuses"][partner["tier"]]
        sale_count = partner_sale_counts[sale["partner_id"]]

        volume_bonus = 0.0
        if sale_count >= 50:
            volume_bonus = 0.02
        elif sale_count >= 25:
            volume_bonus = 0.01
        elif sale_count >= 10:
            volume_bonus = 0.005

        effective_rate = base_rate + tier_bonus + volume_bonus
        correct_commission = round(sale["contract_value"] * effective_rate, 2)

        # Determine if this one should have an error
        is_error = i in error_indices and sale["sale_status"] == "activated"
        error_type = None
        paid_commission = correct_commission

        if is_error:
            error_type = random.choice(ERROR_TYPES)
            if error_type == "tier_bonus_omitted":
                paid_commission = round(sale["contract_value"] * (base_rate + volume_bonus), 2)
            elif error_type == "wrong_product_rate":
                wrong_rate = random.choice([r["base_rate"] for k, r in COMMISSION_RULES["product_rates"].items() if k != prod_code])
                paid_commission = round(sale["contract_value"] * (wrong_rate + tier_bonus + volume_bonus), 2)
            elif error_type == "volume_bonus_missed":
                paid_commission = round(sale["contract_value"] * (base_rate + tier_bonus), 2)
            elif error_type == "incorrect_contract_value":
                wrong_value = sale["contract_value"] + random.choice([-500, -1000, -200, 300])
                paid_commission = round(wrong_value * effective_rate, 2)

        discrepancy = round(paid_commission - correct_commission, 2)
        sale_date = datetime.strptime(sale["sale_date"], "%Y-%m-%d")
        payment_date = sale_date + timedelta(days=random.randint(25, 45))

        payment_status = "paid" if sale["sale_status"] == "activated" else "pending"
        # Some payments delayed
        if payment_status == "paid" and random.random() < 0.08:
            payment_status = "delayed"
            payment_date = None

        calculations.append({
            "calc_id": f"COMM-{70001 + i}",
            "sale_id": sale["sale_id"],
            "partner_id": sale["partner_id"],
            "product_code": prod_code,
            "contract_value": sale["contract_value"],
            "base_rate": base_rate,
            "tier_bonus": tier_bonus,
            "volume_bonus": volume_bonus,
            "effective_rate": effective_rate,
            "calculated_commission": correct_commission,
            "paid_commission": paid_commission,
            "discrepancy": discrepancy,
            "discrepancy_type": error_type,
            "payment_status": payment_status,
            "payment_date": payment_date.strftime("%Y-%m-%d") if payment_date else None,
            "is_correct": not is_error,
        })
    return calculations


def generate_tickets(partners, sales, commissions):
    partner_map = {p["partner_id"]: p for p in partners}
    sale_map = {s["sale_id"]: s for s in sales}
    comm_map = {c["sale_id"]: c for c in commissions}

    # Find commissions with errors for ticket generation
    error_comms = [c for c in commissions if not c["is_correct"]]
    delayed_comms = [c for c in commissions if c["payment_status"] == "delayed"]

    tickets = []
    ticket_num = 90001
    duplicate_pairs = []

    # Create tickets for error commissions
    for comm in error_comms[:30]:
        sale = sale_map.get(comm["sale_id"], {})
        partner = partner_map.get(comm["partner_id"], {})
        created = datetime(2026, 1, random.randint(2, 25))
        status = random.choice(["open", "in-review", "pending-verification", "escalated", "manager-approval"])
        cm = random.choice(CHANNEL_MANAGERS)
        days_in_stage = random.randint(1, 8)

        issue_type = "incorrect_commission"
        desc = (f"Partner reports commission discrepancy on sale {comm['sale_id']}. "
                f"Product: {sale.get('product_name', 'N/A')}. "
                f"Expected ${comm['calculated_commission']:.2f}, received ${comm['paid_commission']:.2f}. "
                f"Discrepancy: ${abs(comm['discrepancy']):.2f}.")

        notes = [
            {"date": created.strftime("%Y-%m-%d"), "author": f"channel_mgr_{cm.lower()}", "text": "Created ticket from partner call."},
            {"date": (created + timedelta(days=1)).strftime("%Y-%m-%d"), "author": "system", "text": f"Auto-assigned to {random.choice(VERIFICATION_TEAMS)}."},
        ]
        if status not in ["open"]:
            notes.append({"date": (created + timedelta(days=2)).strftime("%Y-%m-%d"), "author": random.choice(VERIFICATION_TEAMS), "text": "Pulled commission records. Under review."})
        if status in ["escalated", "manager-approval"]:
            notes.append({"date": (created + timedelta(days=3)).strftime("%Y-%m-%d"), "author": random.choice(VERIFICATION_TEAMS), "text": "Discrepancy confirmed. Escalating for approval."})

        ticket = {
            "ticket_id": f"TKT-{ticket_num}",
            "partner_id": comm["partner_id"],
            "sale_id": comm["sale_id"],
            "created_date": created.strftime("%Y-%m-%d"),
            "created_by": f"channel_mgr_{cm.lower()}",
            "issue_type": issue_type,
            "status": status,
            "priority": random.choice(["high", "medium"]),
            "description": desc,
            "pipeline_stage": PIPELINE_STAGES[status],
            "assigned_to": random.choice(VERIFICATION_TEAMS),
            "last_updated": (created + timedelta(days=days_in_stage)).strftime("%Y-%m-%d"),
            "resolution": None,
            "notes": notes,
        }
        tickets.append(ticket)
        ticket_num += 1

    # Create tickets for delayed payments
    for comm in delayed_comms[:8]:
        sale = sale_map.get(comm["sale_id"], {})
        created = datetime(2026, 1, random.randint(5, 25))
        status = random.choice(["open", "pending-verification", "payment-processing"])
        cm = random.choice(CHANNEL_MANAGERS)

        ticket = {
            "ticket_id": f"TKT-{ticket_num}",
            "partner_id": comm["partner_id"],
            "sale_id": comm["sale_id"],
            "created_date": created.strftime("%Y-%m-%d"),
            "created_by": f"channel_mgr_{cm.lower()}",
            "issue_type": "delayed_payment",
            "status": status,
            "priority": "medium",
            "description": f"Partner reports delayed commission payment for sale {comm['sale_id']}. Sale activated but payment not received after 30+ days.",
            "pipeline_stage": PIPELINE_STAGES[status],
            "assigned_to": random.choice(VERIFICATION_TEAMS),
            "last_updated": (created + timedelta(days=random.randint(1, 5))).strftime("%Y-%m-%d"),
            "resolution": None,
            "notes": [
                {"date": created.strftime("%Y-%m-%d"), "author": f"channel_mgr_{cm.lower()}", "text": "Created ticket from partner call about delayed payment."},
            ],
        }
        tickets.append(ticket)
        ticket_num += 1

    # Create deliberate DUPLICATE tickets (partner called again about same issue)
    for orig_ticket in tickets[:7]:
        dup_created = datetime.strptime(orig_ticket["created_date"], "%Y-%m-%d") + timedelta(days=random.randint(2, 6))
        dup_cm = random.choice([cm for cm in CHANNEL_MANAGERS if cm.lower() != orig_ticket["created_by"].replace("channel_mgr_", "")])
        dup_ticket = {
            "ticket_id": f"TKT-{ticket_num}",
            "partner_id": orig_ticket["partner_id"],
            "sale_id": orig_ticket["sale_id"],
            "created_date": dup_created.strftime("%Y-%m-%d"),
            "created_by": f"channel_mgr_{dup_cm.lower()}",
            "issue_type": orig_ticket["issue_type"],
            "status": "open",
            "priority": orig_ticket["priority"],
            "description": f"[FOLLOW-UP] Partner called again about {orig_ticket['issue_type'].replace('_', ' ')} for sale {orig_ticket['sale_id']}. Original ticket: {orig_ticket['ticket_id']}.",
            "pipeline_stage": "initial_triage",
            "assigned_to": None,
            "last_updated": dup_created.strftime("%Y-%m-%d"),
            "resolution": None,
            "notes": [
                {"date": dup_created.strftime("%Y-%m-%d"), "author": f"channel_mgr_{dup_cm.lower()}", "text": f"Partner called again. Did not reference prior ticket {orig_ticket['ticket_id']}."},
            ],
        }
        tickets.append(dup_ticket)
        duplicate_pairs.append((orig_ticket["ticket_id"], dup_ticket["ticket_id"]))
        ticket_num += 1

    # Add a few resolved tickets for history
    for comm in error_comms[30:35]:
        sale = sale_map.get(comm["sale_id"], {})
        created = datetime(2025, 12, random.randint(1, 20))
        ticket = {
            "ticket_id": f"TKT-{ticket_num}",
            "partner_id": comm["partner_id"],
            "sale_id": comm["sale_id"],
            "created_date": created.strftime("%Y-%m-%d"),
            "created_by": f"channel_mgr_{random.choice(CHANNEL_MANAGERS).lower()}",
            "issue_type": "incorrect_commission",
            "status": "resolved",
            "priority": "medium",
            "description": f"Commission discrepancy resolved for sale {comm['sale_id']}.",
            "pipeline_stage": "completed",
            "assigned_to": random.choice(VERIFICATION_TEAMS),
            "last_updated": (created + timedelta(days=random.randint(5, 12))).strftime("%Y-%m-%d"),
            "resolution": f"Recalculated commission. Adjustment of ${abs(comm['discrepancy']):.2f} issued.",
            "notes": [
                {"date": created.strftime("%Y-%m-%d"), "author": "system", "text": "Ticket created."},
                {"date": (created + timedelta(days=3)).strftime("%Y-%m-%d"), "author": random.choice(VERIFICATION_TEAMS), "text": "Discrepancy confirmed."},
                {"date": (created + timedelta(days=7)).strftime("%Y-%m-%d"), "author": "system", "text": "Adjustment payment processed."},
            ],
        }
        tickets.append(ticket)
        ticket_num += 1

    return tickets


def generate_transcripts(partners, sales, commissions, tickets):
    """Generate realistic call transcripts based on actual data."""
    partner_map = {p["partner_id"]: p for p in partners}
    sale_map = {s["sale_id"]: s for s in sales}
    comm_map = {c["sale_id"]: c for c in commissions}
    # Group tickets by (partner_id, sale_id)
    tickets_by_key = {}
    for t in tickets:
        key = (t["partner_id"], t["sale_id"])
        tickets_by_key.setdefault(key, []).append(t)

    error_comms = [c for c in commissions if not c["is_correct"] and c["sale_id"] in sale_map]
    delayed_comms = [c for c in commissions if c["payment_status"] == "delayed" and c["sale_id"] in sale_map]

    transcripts = []
    tr_num = 1

    # ── Transcript 1: Commission underpayment - tier bonus omitted ──
    comm = next((c for c in error_comms if c["discrepancy_type"] == "tier_bonus_omitted"), error_comms[0])
    partner = partner_map[comm["partner_id"]]
    sale = sale_map[comm["sale_id"]]
    cm = "Sarah"
    transcripts.append(_make_transcript(tr_num, partner, sale, comm, cm,
        f"""Channel Manager: Thank you for calling Partner Support, this is {cm}. How can I help you today?

Partner: Hi {cm}, this is {partner['contact_name']} from {partner['name']}, partner ID {partner['partner_id']}. I'm calling about a commission payment I received for sale {sale['sale_id']}. It was a {sale['product_name']} deal for {sale['customer_name']}, a {sale['contract_value']} dollar contract.

Channel Manager: Let me pull that up. What seems to be the issue with the payment?

Partner: I'm a {partner['tier']} tier partner, so I should be getting the base {comm['base_rate']*100:.0f} percent plus the {comm['tier_bonus']*100:.0f} percent tier bonus. That's {comm['effective_rate']*100:.1f} percent total on the {sale['contract_value']} dollars. That comes to {comm['calculated_commission']:.0f} dollars. But I only received {comm['paid_commission']:.0f} dollars.

Channel Manager: That does sound like there might be a discrepancy. Let me check the commission calculation on our end.

Partner: Yeah, it looks like my tier bonus was completely left off. This is the third time this quarter something like this has happened. I already called about this two days ago and they said they'd look into it but I haven't heard back.

Channel Manager: I apologize for the inconvenience. Let me create a priority ticket for this and make sure it gets expedited. I can see the discrepancy amount is {abs(comm['discrepancy']):.0f} dollars.

Partner: Thank you. I just need this resolved quickly because it affects my cash flow projections for the quarter."""))
    tr_num += 1

    # ── Transcript 2: Wrong product rate ──
    comm2 = next((c for c in error_comms if c["discrepancy_type"] == "wrong_product_rate"), error_comms[1])
    partner2 = partner_map[comm2["partner_id"]]
    sale2 = sale_map[comm2["sale_id"]]
    cm2 = "David"
    transcripts.append(_make_transcript(tr_num, partner2, sale2, comm2, cm2,
        f"""Channel Manager: Partner Support, this is {cm2}. How can I assist you?

Partner: Hey {cm2}, this is {partner2['contact_name']} with {partner2['name']}, my partner ID is {partner2['partner_id']}. I need to dispute a commission payment on sale number {sale2['sale_id']}.

Channel Manager: Sure, let me look into that for you. What's the concern?

Partner: I sold a {sale2['product_name']} package to {sale2['customer_name']}. The contract was for {sale2['contract_value']} dollars. The base rate for {sale2['product_name']} should be {comm2['base_rate']*100:.0f} percent, but it looks like they applied a different rate. My commission came out to {comm2['paid_commission']:.0f} dollars instead of the {comm2['calculated_commission']:.0f} dollars it should have been.

Channel Manager: I see. So you believe an incorrect product rate was used in the calculation?

Partner: Exactly. I've been selling this product line for three years, I know what the rate should be. Can you get this corrected?

Channel Manager: Absolutely. I'm creating a ticket right now and flagging it as a rate discrepancy. We'll get the commission team to review the calculation.

Partner: How long will this take? I've had issues like this before and they took weeks to resolve.

Channel Manager: I'll mark this as high priority. You should hear back within 48 hours. I'll also email you the ticket number for your records."""))
    tr_num += 1

    # ── Transcript 3: Delayed payment ──
    if delayed_comms:
        comm3 = delayed_comms[0]
        partner3 = partner_map[comm3["partner_id"]]
        sale3 = sale_map[comm3["sale_id"]]
    else:
        comm3 = error_comms[2]
        partner3 = partner_map[comm3["partner_id"]]
        sale3 = sale_map[comm3["sale_id"]]
    cm3 = "Maria"
    transcripts.append(_make_transcript(tr_num, partner3, sale3, comm3, cm3,
        f"""Channel Manager: Good morning, Partner Support. This is {cm3}.

Partner: Hi {cm3}, my name is {partner3['contact_name']} from {partner3['name']}. My partner ID is {partner3['partner_id']}. I'm calling because I still haven't received my commission payment for sale {sale3['sale_id']}.

Channel Manager: I'm sorry to hear that. Let me check. When was the sale made?

Partner: The sale was on {sale3['sale_date']} and the customer was activated on {sale3.get('activation_date', 'shortly after')}. It's been well over 30 days and I haven't seen the payment in my account. The contract was worth {sale3['contract_value']} dollars for a {sale3['product_name']} package.

Channel Manager: I can see the sale is showing as activated in our system. Let me check the payment processing status.

Partner: This is really frustrating. I count on these commissions for my business operations. What's causing the delay?

Channel Manager: It appears the payment is stuck in our backend verification process. I'm going to create a ticket and escalate this to the payment processing team. Let me also check if there are any holds on your account.

Partner: There shouldn't be. All my other sales have been paid on time. It's just this one that's stuck.

Channel Manager: I understand. I've created the ticket and I'm marking it as urgent. I'll make sure the payment team reviews this today."""))
    tr_num += 1

    # ── Transcript 4: Duplicate inquiry (partner calling about existing ticket) ──
    existing_tickets = [t for t in tickets if t["status"] not in ["resolved", "duplicate-closed"]]
    if existing_tickets:
        ref_ticket = existing_tickets[0]
        partner4 = partner_map[ref_ticket["partner_id"]]
        sale4 = sale_map.get(ref_ticket["sale_id"], {})
        comm4 = comm_map.get(ref_ticket["sale_id"], {})
    else:
        partner4 = partner_map[error_comms[3]["partner_id"]]
        sale4 = sale_map[error_comms[3]["sale_id"]]
        comm4 = error_comms[3]
        ref_ticket = {"ticket_id": "TKT-90001", "status": "pending-verification", "created_date": "2026-01-08"}
    cm4 = "James"
    transcripts.append(_make_transcript(tr_num, partner4, sale4, comm4 if isinstance(comm4, dict) else {}, cm4,
        f"""Channel Manager: Partner Support, this is {cm4} speaking. How can I help?

Partner: Hi {cm4}, this is {partner4['contact_name']} from {partner4['name']}, partner ID {partner4['partner_id']}. I called about a week ago about a commission issue on sale {ref_ticket.get('sale_id', sale4.get('sale_id', 'N/A'))} and I was told someone would get back to me. Nobody has called or emailed me yet.

Channel Manager: I'm sorry about that. Let me look up your previous ticket.

Partner: I don't have the ticket number, but it was about a {ref_ticket.get('issue_type', 'commission issue').replace('_', ' ')} on that sale. I spoke with someone else last time.

Channel Manager: I can see it here. The ticket was created on {ref_ticket.get('created_date', '2026-01-08')} and it's currently in {ref_ticket.get('status', 'pending-verification').replace('-', ' ')} status.

Partner: What does that mean exactly? Is someone actually working on this? Because from my end it feels like nothing is happening.

Channel Manager: The ticket is currently with our verification team. They need to cross-reference the commission calculation with our backend systems. I understand the wait is frustrating.

Partner: Very frustrating. Can you escalate this? I'm losing money every day this isn't resolved.

Channel Manager: I'm going to add a note to your existing ticket and flag it for escalation. I'll also make sure the verification team knows you've called again."""))
    tr_num += 1

    # ── Transcript 5: Volume bonus not applied ──
    comm5 = next((c for c in error_comms if c["discrepancy_type"] == "volume_bonus_missed"), error_comms[4])
    partner5 = partner_map[comm5["partner_id"]]
    sale5 = sale_map[comm5["sale_id"]]
    cm5 = "Lisa"
    transcripts.append(_make_transcript(tr_num, partner5, sale5, comm5, cm5,
        f"""Channel Manager: Thank you for calling Partner Support, this is {cm5}.

Partner: Hi {cm5}, I'm {partner5['contact_name']} with {partner5['name']}, partner ID {partner5['partner_id']}. I wanted to ask about my volume bonus. I've made over {partner5['total_sales_ytd']} sales this year, which should qualify me for the volume bonus tier, but I don't see it reflected in my recent commission on sale {sale5['sale_id']}.

Channel Manager: Let me check your sales count and the volume bonus thresholds.

Partner: I specifically tracked my numbers to make sure I hit the threshold. The sale was a {sale5['product_name']} for {sale5['contract_value']} dollars. I should be getting the base rate plus my {partner5['tier']} tier bonus plus the volume bonus.

Channel Manager: I can see you do have {partner5['total_sales_ytd']} sales year-to-date, which would qualify for the volume bonus. Let me look at how the commission was calculated.

Partner: Right. So the total should be {comm5['calculated_commission']:.0f} dollars, but I was paid {comm5['paid_commission']:.0f}. Looks like the volume bonus was not applied at all.

Channel Manager: You're right, I can see the discrepancy. I'll create a ticket for this right away and have the commission team recalculate with the volume bonus applied.

Partner: Thank you. This is the kind of thing that really undermines trust. We work hard to hit those thresholds."""))
    tr_num += 1

    # ── Transcript 6: Clawback dispute ──
    churned_sales = [s for s in sales if s["sale_status"] == "churned"]
    if churned_sales:
        sale6 = churned_sales[0]
        partner6 = partner_map[sale6["partner_id"]]
        comm6 = comm_map.get(sale6["sale_id"], error_comms[5])
    else:
        comm6 = error_comms[5]
        partner6 = partner_map[comm6["partner_id"]]
        sale6 = sale_map[comm6["sale_id"]]
    cm6 = "Sarah"
    transcripts.append(_make_transcript(tr_num, partner6, sale6, comm6, cm6,
        f"""Channel Manager: Partner Support, this is {cm6}. How can I help you today?

Partner: Hi {cm6}, this is {partner6['contact_name']} from {partner6['name']}, partner ID {partner6['partner_id']}. I just saw a clawback on my commission statement for sale {sale6['sale_id']} and I need to dispute it.

Channel Manager: I can look into that. What's the concern with the clawback?

Partner: The customer was a {sale6['product_name']} account. They say the customer churned, but I spoke with the customer last week and they said they never cancelled. They just had a billing dispute that got escalated and somehow their service got flagged as churned.

Channel Manager: That does sound like it might be an error. Let me check the customer's account status.

Partner: The contract was for {sale6['contract_value']} dollars and they're trying to claw back the entire commission. That's not right if the customer didn't actually cancel.

Channel Manager: I understand your concern. I'll create a ticket for this and we'll need to verify the customer's actual account status before any clawback is processed. If the customer is indeed still active, we'll reverse the clawback.

Partner: Please do. And if possible, can you put a hold on the clawback until this is resolved? I don't want it deducted from my next payment."""))
    tr_num += 1

    # ── Transcript 7: Multiple issues in one call ──
    comm7 = error_comms[6] if len(error_comms) > 6 else error_comms[0]
    partner7 = partner_map[comm7["partner_id"]]
    sale7 = sale_map[comm7["sale_id"]]
    cm7 = "David"
    transcripts.append(_make_transcript(tr_num, partner7, sale7, comm7, cm7,
        f"""Channel Manager: Partner Support, this is {cm7}.

Partner: {cm7}, hi, this is {partner7['contact_name']} from {partner7['name']}, partner ID {partner7['partner_id']}. I have a couple of issues I need help with today.

Channel Manager: Sure, go ahead.

Partner: First, on sale {sale7['sale_id']}, a {sale7['product_name']} deal for {sale7['contract_value']} dollars, my commission was wrong. I was paid {comm7['paid_commission']:.0f} dollars but it should have been {comm7['calculated_commission']:.0f}. And second, I'm still waiting on payment for that same sale, it seems like even the wrong amount hasn't fully cleared yet.

Channel Manager: That's two separate issues on the same sale. Let me pull up the details.

Partner: Yes. So not only is the amount wrong, but the payment itself is delayed. It's been over 30 days since the sale was activated. I'm a {partner7['tier']} tier partner and I've never had delays like this before.

Channel Manager: I can see the sale and the commission calculation. You're right about the discrepancy. For the payment delay, it looks like the payment is held up in our backend verification queue.

Partner: What verification? The sale has been activated and the customer has been using the service for weeks.

Channel Manager: Sometimes our system requires additional verification for certain contract values. I'm going to create a single ticket covering both issues and mark it as high priority so both the commission amount and the payment delay get addressed together.

Partner: Thank you. I really need this sorted out as soon as possible."""))
    tr_num += 1

    # ── Transcript 8: Status inquiry on existing ticket ──
    if len(existing_tickets) > 1:
        ref_ticket2 = existing_tickets[1]
    else:
        ref_ticket2 = existing_tickets[0] if existing_tickets else tickets[0]
    partner8 = partner_map[ref_ticket2["partner_id"]]
    sale8 = sale_map.get(ref_ticket2["sale_id"], {})
    cm8 = "Maria"
    transcripts.append(_make_transcript(tr_num, partner8, sale8, {}, cm8,
        f"""Channel Manager: Good afternoon, Partner Support. This is {cm8}.

Partner: Hi {cm8}, this is {partner8['contact_name']} from {partner8['name']}, partner ID {partner8['partner_id']}. I'm just calling to check on the status of a ticket I submitted. The ticket number is {ref_ticket2['ticket_id']}.

Channel Manager: Let me pull that up for you. One moment.

Partner: Sure, take your time.

Channel Manager: I have the ticket here. It was created on {ref_ticket2['created_date']} for a {ref_ticket2['issue_type'].replace('_', ' ')} issue on sale {ref_ticket2['sale_id']}. The current status is {ref_ticket2['status'].replace('-', ' ')}.

Partner: And what does that status mean? When can I expect a resolution?

Channel Manager: It means your ticket is currently being worked on by our {ref_ticket2.get('assigned_to', 'verification team')}. Based on the current queue, I'd estimate another 2 to 3 business days for a resolution.

Partner: Okay, that's a bit long but I understand. Can you add a note that I called to follow up? Maybe that'll help prioritize it.

Channel Manager: Absolutely, I'm adding that note now. Is there anything else I can help with today?

Partner: No, that's it. Thank you {cm8}."""))
    tr_num += 1

    # ── Transcript 9: Commission underpayment - incorrect contract value ──
    comm9 = next((c for c in error_comms if c["discrepancy_type"] == "incorrect_contract_value"), error_comms[7] if len(error_comms) > 7 else error_comms[0])
    partner9 = partner_map[comm9["partner_id"]]
    sale9 = sale_map[comm9["sale_id"]]
    cm9 = "James"
    transcripts.append(_make_transcript(tr_num, partner9, sale9, comm9, cm9,
        f"""Channel Manager: Partner Support, {cm9} speaking.

Partner: Hi {cm9}, this is {partner9['contact_name']} from {partner9['name']}, partner ID {partner9['partner_id']}. I need to report a commission issue on sale {sale9['sale_id']}.

Channel Manager: Of course. What's the problem?

Partner: The commission was calculated on the wrong contract value. The actual contract with {sale9['customer_name']} was for {sale9['contract_value']} dollars for a {sale9['product_name']} package with a {sale9['contract_term_months']} month term. But looking at my statement, the commission appears to be based on a different amount.

Channel Manager: Let me look at the commission details for that sale.

Partner: I should be receiving {comm9['calculated_commission']:.0f} dollars based on the correct contract value, but I only got {comm9['paid_commission']:.0f}. The rate looks right, it's the base amount that's off.

Channel Manager: I can see what you mean. The system seems to have used a different contract value for the commission calculation. I'll create a ticket and have the team verify the correct contract value from the original agreement.

Partner: Great, thanks. I have the signed contract if they need a copy for verification."""))
    tr_num += 1

    # ── Transcript 10: General frustration / multiple previous calls ──
    comm10 = error_comms[8] if len(error_comms) > 8 else error_comms[0]
    partner10 = partner_map[comm10["partner_id"]]
    sale10 = sale_map[comm10["sale_id"]]
    cm10 = "Lisa"
    transcripts.append(_make_transcript(tr_num, partner10, sale10, comm10, cm10,
        f"""Channel Manager: Thank you for calling Partner Support, this is {cm10}.

Partner: {cm10}, hi, this is {partner10['contact_name']} from {partner10['name']}, partner ID {partner10['partner_id']}. I'm going to be honest, I'm very frustrated right now.

Channel Manager: I'm sorry to hear that. What can I help you with?

Partner: I've called three times now about sale {sale10['sale_id']}. It's a {sale10['product_name']} deal worth {sale10['contract_value']} dollars. Every time I call, I get told it's being looked into, but nothing happens. My commission is wrong by {abs(comm10['discrepancy']):.0f} dollars and nobody seems to be able to fix it.

Channel Manager: I completely understand your frustration. Let me look at the full history here.

Partner: I was told last time that it was in pending verification. What is being verified? The sale was made months ago and the customer is happily using the service. There's nothing to verify.

Channel Manager: You're right, the verification should not take this long. I'm going to escalate this directly to the commission corrections team with a note that this is your third call. I'll also CC my supervisor.

Partner: I appreciate that. I've been a {partner10['tier']} tier partner for years. I bring in a lot of business. This kind of treatment makes me think about whether it's worth continuing the partnership.

Channel Manager: I completely understand, and I want to make sure we resolve this for you. I'm creating an escalated ticket right now with the highest priority. You should receive a call back within 24 hours from a supervisor."""))
    tr_num += 1

    return transcripts


def generate_backend_issues(sales, commissions):
    """
    Generate backend_issues.json — realistic system errors keyed by sale_id (order_id).
    These represent issues in backend systems that caused commission delays or miscalculations.
    Each sale that has a commission error or delayed payment gets a matching backend issue.
    Some clean sales also get issues (to simulate delays even on correct commissions).
    """
    error_comms = [c for c in commissions if not c["is_correct"]]
    delayed_comms = [c for c in commissions if c["payment_status"] == "delayed"]

    issues = []
    issue_num = 1

    # Map commission error types to backend issue templates
    impact_map = {}
    for tpl in BACKEND_ISSUE_TYPES:
        impact_map.setdefault(tpl["impact"], []).append(tpl)

    # Create issues for every commission error — the backend issue *explains* why the error happened
    for comm in error_comms:
        templates = impact_map.get(comm["discrepancy_type"], BACKEND_ISSUE_TYPES[:2])
        tpl = random.choice(templates)
        sale_date = datetime.strptime(
            next((s["sale_date"] for s in sales if s["sale_id"] == comm["sale_id"]), "2025-11-01"),
            "%Y-%m-%d",
        )
        error_ts = sale_date + timedelta(days=random.randint(1, 5), hours=random.randint(0, 23), minutes=random.randint(0, 59))
        issues.append({
            "issue_id": f"BI-{5001 + issue_num}",
            "order_id": comm["sale_id"],
            "partner_id": comm["partner_id"],
            "error_code": tpl["error_code"],
            "system": tpl["system"],
            "category": tpl["category"],
            "description": tpl["description"],
            "impact": tpl["impact"],
            "severity": random.choice(["critical", "high", "medium"]),
            "timestamp": error_ts.strftime("%Y-%m-%dT%H:%M:%S"),
            "resolved": random.choice([True, False, False]),
            "resolution_notes": "Resolved by system rerun." if random.random() < 0.3 else None,
        })
        issue_num += 1

    # Create issues for delayed payments
    for comm in delayed_comms:
        templates = impact_map.get("delayed_payment", BACKEND_ISSUE_TYPES[1:2])
        tpl = random.choice(templates)
        sale_date = datetime.strptime(
            next((s["sale_date"] for s in sales if s["sale_id"] == comm["sale_id"]), "2025-11-01"),
            "%Y-%m-%d",
        )
        error_ts = sale_date + timedelta(days=random.randint(20, 35), hours=random.randint(0, 23))
        issues.append({
            "issue_id": f"BI-{5001 + issue_num}",
            "order_id": comm["sale_id"],
            "partner_id": comm["partner_id"],
            "error_code": tpl["error_code"],
            "system": tpl["system"],
            "category": tpl["category"],
            "description": tpl["description"],
            "impact": tpl["impact"],
            "severity": random.choice(["high", "medium"]),
            "timestamp": error_ts.strftime("%Y-%m-%dT%H:%M:%S"),
            "resolved": False,
            "resolution_notes": None,
        })
        issue_num += 1

    # Sprinkle a few issues on otherwise-correct sales (transient errors that self-resolved)
    correct_comms = [c for c in commissions if c["is_correct"] and c["payment_status"] == "paid"]
    for comm in random.sample(correct_comms, min(12, len(correct_comms))):
        tpl = random.choice(BACKEND_ISSUE_TYPES)
        sale_date = datetime.strptime(
            next((s["sale_date"] for s in sales if s["sale_id"] == comm["sale_id"]), "2025-11-01"),
            "%Y-%m-%d",
        )
        error_ts = sale_date + timedelta(days=random.randint(1, 10))
        issues.append({
            "issue_id": f"BI-{5001 + issue_num}",
            "order_id": comm["sale_id"],
            "partner_id": comm["partner_id"],
            "error_code": tpl["error_code"],
            "system": tpl["system"],
            "category": tpl["category"],
            "description": tpl["description"],
            "impact": tpl["impact"],
            "severity": "low",
            "timestamp": error_ts.strftime("%Y-%m-%dT%H:%M:%S"),
            "resolved": True,
            "resolution_notes": "Transient error. Auto-resolved on batch retry.",
        })
        issue_num += 1

    return issues


def _make_transcript(num, partner, sale, comm, cm_name, text):
    return {
        "transcript_id": f"TR-{num:03d}",
        "partner_id": partner["partner_id"],
        "partner_name": partner["name"],
        "call_date": f"2026-01-{random.randint(10, 28):02d}",
        "channel_manager": cm_name,
        "duration_seconds": random.randint(180, 360),
        "audio_file": f"call_{num:03d}.wav",
        "transcript": text.strip(),
        "audio_generated": False,
    }


def generate_audio_files(transcripts):
    """Generate TTS audio for each transcript using Azure Speech SDK."""
    speech_key = os.getenv("AZURE_SPEECH_KEY", "")
    speech_region = os.getenv("AZURE_SPEECH_REGION", "eastus")

    if not speech_key or speech_key == "YOUR_AZURE_SPEECH_KEY_HERE":
        print("AZURE_SPEECH_KEY not set. Skipping audio generation.")
        print("To generate audio, set AZURE_SPEECH_KEY in .env and re-run.")
        return

    try:
        import azure.cognitiveservices.speech as speechsdk
    except ImportError:
        print("azure-cognitiveservices-speech not installed. Skipping audio generation.")
        print("Install with: pip install azure-cognitiveservices-speech")
        return

    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=speech_region)
    speech_config.set_speech_synthesis_output_format(
        speechsdk.SpeechSynthesisOutputFormat.Riff16Khz16BitMonoPcm
    )

    for t in transcripts:
        output_path = str(AUDIO_DIR / t["audio_file"])
        print(f"  Generating audio: {t['audio_file']}...")

        ssml = _build_conversation_ssml(t["transcript"])
        audio_config = speechsdk.audio.AudioOutputConfig(filename=output_path)
        synthesizer = speechsdk.SpeechSynthesizer(
            speech_config=speech_config,
            audio_config=audio_config,
        )
        result = synthesizer.speak_ssml_async(ssml).get()

        if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            t["audio_generated"] = True
            print(f"    OK: {t['audio_file']}")
        else:
            print(f"    FAILED: {result.reason}")
            if result.reason == speechsdk.ResultReason.Canceled:
                details = result.cancellation_details
                print(f"    Error: {details.reason} - {details.error_details}")


def _build_conversation_ssml(transcript_text):
    """Build SSML with two voices for channel manager vs partner."""
    lines = transcript_text.strip().split("\n")
    ssml_parts = [
        '<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">'
    ]
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # Escape XML characters
        def xml_escape(s):
            return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

        if line.startswith("Channel Manager:"):
            text = xml_escape(line.replace("Channel Manager:", "").strip())
            if text:
                ssml_parts.append(
                    f'<voice name="en-US-JennyNeural"><prosody rate="0%">{text}</prosody></voice>'
                )
        elif line.startswith("Partner:"):
            text = xml_escape(line.replace("Partner:", "").strip())
            if text:
                ssml_parts.append(
                    f'<voice name="en-US-GuyNeural"><prosody rate="0%">{text}</prosody></voice>'
                )
    ssml_parts.append("</speak>")
    return "\n".join(ssml_parts)


# ─── Main ────────────────────────────────────────────────────────────────────

def main():
    print("=== Partner Commission Support - Synthetic Data Generator ===\n")

    print("1. Generating partners...")
    partners = generate_partners(25)
    with open(DATA_DIR / "partners.json", "w") as f:
        json.dump(partners, f, indent=2)
    print(f"   Created {len(partners)} partners.")

    print("2. Generating commission rules...")
    with open(DATA_DIR / "commission_rules.json", "w") as f:
        json.dump(COMMISSION_RULES, f, indent=2)
    print("   Commission rules saved.")

    print("3. Generating sales records...")
    sales = generate_sales(partners, 250)
    with open(DATA_DIR / "sales_records.json", "w") as f:
        json.dump(sales, f, indent=2)
    print(f"   Created {len(sales)} sales records.")

    print("4. Generating commission calculations...")
    commissions = generate_commissions(partners, sales)
    with open(DATA_DIR / "commission_calculations.json", "w") as f:
        json.dump(commissions, f, indent=2)
    error_count = sum(1 for c in commissions if not c["is_correct"])
    print(f"   Created {len(commissions)} calculations ({error_count} with errors).")

    print("5. Generating backend issues...")
    backend_issues = generate_backend_issues(sales, commissions)
    with open(DATA_DIR / "backend_issues.json", "w") as f:
        json.dump(backend_issues, f, indent=2)
    print(f"   Created {len(backend_issues)} backend issues.")

    print("6. Generating support tickets...")
    tickets = generate_tickets(partners, sales, commissions)
    with open(DATA_DIR / "support_tickets.json", "w") as f:
        json.dump(tickets, f, indent=2)
    dup_count = sum(1 for t in tickets if "FOLLOW-UP" in t.get("description", ""))
    print(f"   Created {len(tickets)} tickets ({dup_count} duplicates).")

    print("7. Generating call transcripts...")
    transcripts = generate_transcripts(partners, sales, commissions, tickets)
    with open(DATA_DIR / "call_transcripts.json", "w") as f:
        json.dump(transcripts, f, indent=2)
    print(f"   Created {len(transcripts)} transcripts.")

    print("\n8. Generating TTS audio files...")
    generate_audio_files(transcripts)
    # Re-save transcripts with audio_generated flags updated
    with open(DATA_DIR / "call_transcripts.json", "w") as f:
        json.dump(transcripts, f, indent=2)

    print("\n=== Data generation complete! ===")
    print(f"Files saved to: {DATA_DIR}")
    print(f"Audio saved to: {AUDIO_DIR}")


if __name__ == "__main__":
    main()
