"""
Azure Speech Service wrapper for STT and TTS.
Uses Azure AI Foundry Speech models via the azure-cognitiveservices-speech SDK.
"""

import os
import time
from pathlib import Path
from typing import Dict, Optional


class SpeechService:
    """Wrapper around Azure Cognitive Services Speech SDK for STT and TTS."""

    def __init__(self):
        self.speech_key = os.getenv("AZURE_SPEECH_KEY", "")
        self.speech_region = os.getenv("AZURE_SPEECH_REGION", "eastus")
        self._sdk = None
        self._available = None

    @property
    def available(self) -> bool:
        if self._available is None:
            try:
                import azure.cognitiveservices.speech as speechsdk
                self._sdk = speechsdk
                self._available = bool(self.speech_key and self.speech_key != "YOUR_AZURE_SPEECH_KEY_HERE")
            except ImportError:
                self._available = False
        return self._available

    def _get_speech_config(self):
        if not self.available:
            raise RuntimeError(
                "Azure Speech SDK not available. Install azure-cognitiveservices-speech "
                "and set AZURE_SPEECH_KEY in .env"
            )
        return self._sdk.SpeechConfig(
            subscription=self.speech_key,
            region=self.speech_region,
        )

    def transcribe_audio(self, audio_file_path: str) -> Dict:
        """
        Transcribe an audio file to text using Azure STT (continuous recognition).
        Returns dict with 'text' (full transcript) and 'segments' (list of recognized chunks).
        """
        sdk = self._sdk
        speech_config = self._get_speech_config()
        speech_config.speech_recognition_language = "en-US"

        audio_config = sdk.audio.AudioConfig(filename=audio_file_path)
        recognizer = sdk.SpeechRecognizer(
            speech_config=speech_config,
            audio_config=audio_config,
        )

        all_results = []
        done = False

        def on_recognized(evt):
            if evt.result.reason == sdk.ResultReason.RecognizedSpeech:
                all_results.append(evt.result.text)

        def on_session_stopped(evt):
            nonlocal done
            done = True

        def on_canceled(evt):
            nonlocal done
            done = True

        recognizer.recognized.connect(on_recognized)
        recognizer.session_stopped.connect(on_session_stopped)
        recognizer.canceled.connect(on_canceled)

        recognizer.start_continuous_recognition()
        while not done:
            time.sleep(0.5)
        recognizer.stop_continuous_recognition()

        full_text = " ".join(all_results)
        return {"text": full_text, "segments": all_results}

    def synthesize_speech(self, text: str, output_path: str,
                          voice_name: str = "en-US-JennyNeural") -> bool:
        """Synthesize text to a WAV file using Azure TTS."""
        sdk = self._sdk
        speech_config = self._get_speech_config()
        speech_config.speech_synthesis_voice_name = voice_name
        speech_config.set_speech_synthesis_output_format(
            sdk.SpeechSynthesisOutputFormat.Riff16Khz16BitMonoPcm
        )
        audio_config = sdk.audio.AudioOutputConfig(filename=output_path)
        synthesizer = sdk.SpeechSynthesizer(
            speech_config=speech_config,
            audio_config=audio_config,
        )
        result = synthesizer.speak_text_async(text).get()
        return result.reason == sdk.ResultReason.SynthesizingAudioCompleted


# Singleton
_instance = None

def get_speech_service() -> SpeechService:
    global _instance
    if _instance is None:
        _instance = SpeechService()
    return _instance
