"""
Data service for loading and querying synthetic partner/sales/commission/ticket data.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime


class DataService:
    def __init__(self):
        self.data_dir = Path(__file__).parent.parent / "data" / "generated"
        self.partners = self._load("partners.json")
        self.sales = self._load("sales_records.json")
        self.rules = self._load("commission_rules.json")
        self.calculations = self._load("commission_calculations.json")
        self.tickets = self._load("support_tickets.json")
        self.transcripts = self._load("call_transcripts.json")
        self.backend_issues = self._load("backend_issues.json")

        # Build lookup maps
        self._partner_map = {p["partner_id"]: p for p in self.partners}
        self._sale_map = {s["sale_id"]: s for s in self.sales}
        self._calc_map = {}
        for c in self.calculations:
            self._calc_map[c["sale_id"]] = c
            self._calc_map[c["calc_id"]] = c

        # Backend issues indexed by order_id (sale_id)
        self._backend_issues_by_order = {}
        for bi in self.backend_issues:
            self._backend_issues_by_order.setdefault(bi["order_id"], []).append(bi)

    def _load(self, filename: str) -> Any:
        path = self.data_dir / filename
        if not path.exists():
            return [] if filename != "commission_rules.json" else {}
        with open(path, "r") as f:
            return json.load(f)

    # ── Partner queries ──

    def get_partner(self, partner_id: str) -> Optional[Dict]:
        return self._partner_map.get(partner_id)

    def get_partner_formatted(self, partner_id: str) -> str:
        p = self.get_partner(partner_id)
        if not p:
            return f"Partner {partner_id} not found."
        return (
            f"Partner ID: {p['partner_id']}\n"
            f"Name: {p['name']}\n"
            f"Tier: {p['tier']}\n"
            f"Contact: {p['contact_name']} ({p['contact_email']})\n"
            f"Region: {p['region']}\n"
            f"Active Since: {p['active_since']}\n"
            f"Total Sales YTD: {p['total_sales_ytd']}\n"
        )

    # ── Sale queries ──

    def get_sale(self, sale_id: str) -> Optional[Dict]:
        return self._sale_map.get(sale_id)

    def get_sale_formatted(self, sale_id: str) -> str:
        s = self.get_sale(sale_id)
        if not s:
            return f"Sale {sale_id} not found."
        return (
            f"Sale ID: {s['sale_id']}\n"
            f"Partner: {s['partner_id']}\n"
            f"Product: {s['product_name']} ({s['product_code']})\n"
            f"Customer: {s['customer_name']}\n"
            f"Sale Date: {s['sale_date']}\n"
            f"Contract Value: ${s['contract_value']:,.2f}\n"
            f"Term: {s['contract_term_months']} months\n"
            f"Status: {s['sale_status']}\n"
            f"Activation Date: {s.get('activation_date', 'N/A')}\n"
        )

    # ── Commission queries ──

    def get_commission(self, sale_id: str) -> Optional[Dict]:
        return self._calc_map.get(sale_id)

    def get_commission_rules_formatted(self) -> str:
        rules = self.rules
        lines = ["=== Commission Rules ===\n", "Product Base Rates:"]
        for prod, info in rules.get("product_rates", {}).items():
            lines.append(f"  {prod}: {info['base_rate']*100:.0f}% - {info['description']}")
        lines.append("\nTier Bonuses:")
        for tier, bonus in rules.get("tier_bonuses", {}).items():
            lines.append(f"  {tier}: +{bonus*100:.1f}%")
        lines.append("\nVolume Bonuses:")
        for key, info in rules.get("volume_bonuses", {}).items():
            lines.append(f"  {info['min_sales']}+ sales: +{info['bonus']*100:.1f}% - {info['description']}")
        return "\n".join(lines)

    def get_commission_formatted(self, sale_id: str) -> str:
        c = self.get_commission(sale_id)
        if not c:
            return f"Commission record for sale {sale_id} not found."
        return (
            f"Calc ID: {c['calc_id']}\n"
            f"Sale ID: {c['sale_id']}\n"
            f"Partner: {c['partner_id']}\n"
            f"Product: {c['product_code']}\n"
            f"Contract Value: ${c['contract_value']:,.2f}\n"
            f"Base Rate: {c['base_rate']*100:.0f}%\n"
            f"Tier Bonus: {c['tier_bonus']*100:.1f}%\n"
            f"Volume Bonus: {c['volume_bonus']*100:.1f}%\n"
            f"Effective Rate: {c['effective_rate']*100:.1f}%\n"
            f"Calculated Commission: ${c['calculated_commission']:,.2f}\n"
            f"Paid Commission: ${c['paid_commission']:,.2f}\n"
            f"Discrepancy: ${c['discrepancy']:,.2f}\n"
            f"Discrepancy Type: {c['discrepancy_type'] or 'None'}\n"
            f"Payment Status: {c['payment_status']}\n"
            f"Payment Date: {c['payment_date'] or 'N/A'}\n"
            f"Is Correct: {c['is_correct']}\n"
        )

    def recalculate_commission(self, sale_id: str) -> str:
        """Recalculate the correct commission and compare with what was paid."""
        sale = self.get_sale(sale_id)
        if not sale:
            return f"Sale {sale_id} not found."

        partner = self.get_partner(sale["partner_id"])
        if not partner:
            return f"Partner {sale['partner_id']} not found."

        comm = self.get_commission(sale_id)
        rules = self.rules

        # Get correct rates
        prod_rate = rules["product_rates"].get(sale["product_code"], {}).get("base_rate", 0)
        tier_bonus = rules["tier_bonuses"].get(partner["tier"], 0)

        # Volume bonus
        sale_count = partner["total_sales_ytd"]
        volume_bonus = 0.0
        if sale_count >= 50:
            volume_bonus = 0.02
        elif sale_count >= 25:
            volume_bonus = 0.01
        elif sale_count >= 10:
            volume_bonus = 0.005

        correct_rate = prod_rate + tier_bonus + volume_bonus
        correct_commission = round(sale["contract_value"] * correct_rate, 2)

        paid = comm["paid_commission"] if comm else 0
        discrepancy = round(paid - correct_commission, 2)

        lines = [
            "=== Commission Recalculation ===",
            f"Sale ID: {sale_id}",
            f"Partner: {partner['name']} ({partner['partner_id']}) - {partner['tier']} Tier",
            f"Product: {sale['product_name']} ({sale['product_code']})",
            f"Contract Value: ${sale['contract_value']:,.2f}",
            "",
            "Rate Breakdown:",
            f"  Base Product Rate: {prod_rate*100:.0f}%",
            f"  Tier Bonus ({partner['tier']}): +{tier_bonus*100:.1f}%",
            f"  Volume Bonus ({sale_count} sales YTD): +{volume_bonus*100:.1f}%",
            f"  Correct Effective Rate: {correct_rate*100:.1f}%",
            "",
            f"Correct Commission: ${correct_commission:,.2f}",
            f"Actually Paid: ${paid:,.2f}",
            f"Discrepancy: ${discrepancy:,.2f}",
        ]

        if comm and not comm["is_correct"]:
            lines.append(f"\nRoot Cause: {(comm['discrepancy_type'] or 'unknown').replace('_', ' ').title()}")
            if comm["discrepancy_type"] == "tier_bonus_omitted":
                lines.append(f"  -> Tier bonus of {tier_bonus*100:.1f}% was not applied to the calculation.")
            elif comm["discrepancy_type"] == "wrong_product_rate":
                lines.append(f"  -> An incorrect product rate was used instead of {prod_rate*100:.0f}%.")
            elif comm["discrepancy_type"] == "volume_bonus_missed":
                lines.append(f"  -> Volume bonus of {volume_bonus*100:.1f}% was not applied despite {sale_count} sales YTD.")
            elif comm["discrepancy_type"] == "incorrect_contract_value":
                lines.append(f"  -> Commission was calculated on a different contract value than ${sale['contract_value']:,.2f}.")
        elif discrepancy == 0:
            lines.append("\nStatus: Commission is CORRECT. No discrepancy found.")
        else:
            lines.append(f"\nStatus: Discrepancy of ${discrepancy:,.2f} detected.")

        return "\n".join(lines)

    # ── Ticket queries ──

    def search_tickets(self, partner_id: str, sale_id: str = None) -> str:
        """Search tickets by partner and optionally sale ID."""
        matches = [t for t in self.tickets if t["partner_id"] == partner_id]
        if sale_id:
            matches = [t for t in matches if t["sale_id"] == sale_id]

        if not matches:
            return f"No tickets found for partner {partner_id}" + (f" and sale {sale_id}" if sale_id else "") + "."

        lines = [f"Found {len(matches)} ticket(s):\n"]
        for t in matches:
            days_open = "N/A"
            try:
                created = datetime.strptime(t["created_date"], "%Y-%m-%d")
                updated = datetime.strptime(t["last_updated"], "%Y-%m-%d")
                days_open = (updated - created).days
            except (ValueError, KeyError):
                pass

            is_dup = "FOLLOW-UP" in t.get("description", "")
            lines.append(
                f"  Ticket: {t['ticket_id']} {'[DUPLICATE]' if is_dup else ''}\n"
                f"    Sale: {t['sale_id']}\n"
                f"    Issue: {t['issue_type']}\n"
                f"    Status: {t['status']}\n"
                f"    Priority: {t['priority']}\n"
                f"    Pipeline Stage: {t['pipeline_stage']}\n"
                f"    Created: {t['created_date']}\n"
                f"    Last Updated: {t['last_updated']} ({days_open} days in system)\n"
                f"    Assigned To: {t.get('assigned_to', 'Unassigned')}\n"
                f"    Description: {t['description'][:150]}...\n"
            )
        return "\n".join(lines)

    def get_ticket_status(self, ticket_id: str) -> str:
        """Get detailed ticket status including pipeline stage and bottleneck."""
        ticket = next((t for t in self.tickets if t["ticket_id"] == ticket_id), None)
        if not ticket:
            return f"Ticket {ticket_id} not found."

        try:
            created = datetime.strptime(ticket["created_date"], "%Y-%m-%d")
            updated = datetime.strptime(ticket["last_updated"], "%Y-%m-%d")
            days_in_system = (updated - created).days
        except (ValueError, KeyError):
            days_in_system = "Unknown"

        pipeline_stages = ["initial_triage", "agent_review", "backend_verification",
                           "escalation_queue", "manager_approval", "payment_processing", "completed"]
        current_stage = ticket["pipeline_stage"]
        stage_index = pipeline_stages.index(current_stage) if current_stage in pipeline_stages else -1

        lines = [
            f"=== Ticket Status: {ticket_id} ===",
            f"Issue Type: {ticket['issue_type']}",
            f"Status: {ticket['status']}",
            f"Priority: {ticket['priority']}",
            f"Pipeline Stage: {current_stage}",
            f"Stage Position: {stage_index + 1}/{len(pipeline_stages)}",
            f"Days in System: {days_in_system}",
            f"Assigned To: {ticket.get('assigned_to', 'Unassigned')}",
            f"Created By: {ticket['created_by']}",
            "",
            "Bottleneck Analysis:",
        ]

        if current_stage == "backend_verification":
            lines.append("  BOTTLENECK: Stuck in backend verification.")
            lines.append(f"  The ticket has been waiting for verification for {days_in_system} days.")
            lines.append("  This stage requires cross-referencing commission data with backend billing systems.")
        elif current_stage == "manager_approval":
            lines.append("  BOTTLENECK: Awaiting manager approval.")
            lines.append("  A discrepancy has been confirmed and needs manager sign-off for correction.")
        elif current_stage == "escalation_queue":
            lines.append("  BOTTLENECK: In escalation queue.")
            lines.append("  The ticket has been escalated but is waiting for a senior agent to pick it up.")
        elif current_stage == "payment_processing":
            lines.append("  BOTTLENECK: Payment processing.")
            lines.append("  The correction has been approved and is in the payment queue.")
        elif current_stage == "initial_triage":
            lines.append("  BOTTLENECK: Not yet triaged.")
            lines.append("  The ticket is waiting to be assigned and reviewed by an agent.")
        else:
            lines.append(f"  Current stage: {current_stage}. Processing normally.")

        lines.append("\nTimeline:")
        for note in ticket.get("notes", []):
            lines.append(f"  [{note['date']}] {note['author']}: {note['text']}")

        if ticket.get("resolution"):
            lines.append(f"\nResolution: {ticket['resolution']}")

        return "\n".join(lines)

    # ── Backend issue queries ──

    def get_backend_issues_by_order(self, order_id: str) -> List[Dict]:
        """Get all backend issues for a given order/sale ID."""
        return self._backend_issues_by_order.get(order_id, [])

    def get_backend_issues_by_partner(self, partner_id: str) -> List[Dict]:
        """Get all backend issues for a given partner."""
        return [bi for bi in self.backend_issues if bi["partner_id"] == partner_id]

    def search_backend_issues(self, order_id: str = None, partner_id: str = None) -> str:
        """Search backend issues by order_id and/or partner_id. Returns formatted text."""
        matches = self.backend_issues
        if order_id:
            matches = [bi for bi in matches if bi["order_id"] == order_id]
        if partner_id:
            matches = [bi for bi in matches if bi["partner_id"] == partner_id]

        if not matches:
            search_desc = []
            if order_id:
                search_desc.append(f"order {order_id}")
            if partner_id:
                search_desc.append(f"partner {partner_id}")
            return f"No backend issues found for {' and '.join(search_desc)}."

        lines = [f"Found {len(matches)} backend issue(s):\n"]
        for bi in matches:
            resolved_str = "RESOLVED" if bi["resolved"] else "UNRESOLVED"
            lines.append(
                f"  Issue: {bi['issue_id']} [{resolved_str}]\n"
                f"    Order ID: {bi['order_id']}\n"
                f"    Partner: {bi['partner_id']}\n"
                f"    Error Code: {bi['error_code']}\n"
                f"    System: {bi['system']}\n"
                f"    Category: {bi['category']}\n"
                f"    Description: {bi['description']}\n"
                f"    Impact: {bi['impact']}\n"
                f"    Severity: {bi['severity']}\n"
                f"    Timestamp: {bi['timestamp']}\n"
                f"    Resolution: {bi.get('resolution_notes') or 'Pending'}\n"
            )
        return "\n".join(lines)

    def get_transcript(self, transcript_id: str) -> Optional[Dict]:
        return next((t for t in self.transcripts if t["transcript_id"] == transcript_id), None)


# Singleton instance
_instance = None

def get_data_service() -> DataService:
    global _instance
    if _instance is None:
        _instance = DataService()
    return _instance
