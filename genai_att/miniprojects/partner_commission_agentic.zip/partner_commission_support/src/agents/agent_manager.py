"""
Agent Manager - orchestrates the 5-agent sequential pipeline for partner support.
"""

from typing import Dict, Any
import json
import re
import autogen
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))

from agents.transcript_analyzer import TranscriptAnalyzerAgent
from agents.duplicate_detector import DuplicateDetectorAgent
from agents.commission_verifier import CommissionVerifierAgent
from agents.status_tracker import StatusTrackerAgent
from agents.rca_agent import RCAAgent
from agents.resolution_agent import ResolutionAgent


class AgentManager:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.llm_config = self._configure_llm()

        # Create agent instances and inject LLM config
        self.transcript_analyzer = TranscriptAnalyzerAgent()
        self.transcript_analyzer.llm_config = self.llm_config

        self.duplicate_detector = DuplicateDetectorAgent()
        self.duplicate_detector.llm_config = self.llm_config

        self.commission_verifier = CommissionVerifierAgent()
        self.commission_verifier.llm_config = self.llm_config

        self.status_tracker = StatusTrackerAgent()
        self.status_tracker.llm_config = self.llm_config

        self.rca_agent = RCAAgent()
        self.rca_agent.llm_config = self.llm_config

        self.resolution_agent = ResolutionAgent()
        self.resolution_agent.llm_config = self.llm_config

        # User proxy with tool execution
        self.user_proxy = autogen.UserProxyAgent(
            name="User_Proxy",
            system_message="I am a channel manager processing partner support calls.",
            code_execution_config=False,
            human_input_mode="NEVER",
            function_map=self._get_function_map(),
        )

    def _configure_llm(self) -> Dict[str, Any]:
        api_type = self.config["api"]["type"]

        if api_type == "azure":
            return {
                "config_list": [
                    {
                        "model": self.config["api"]["azure_openai"]["deployment"],
                        "api_key": self.config["api"]["azure_openai"]["api_key"],
                        "base_url": self.config["api"]["azure_openai"]["api_base"],
                        "api_type": "azure",
                        "api_version": self.config["api"]["azure_openai"]["api_version"],
                    }
                ],
                "temperature": float(
                    self.config.get("agents", {})
                    .get("transcript_analyzer", {})
                    .get("temperature", 0.1)
                ),
                "max_tokens": int(
                    self.config.get("agents", {})
                    .get("transcript_analyzer", {})
                    .get("max_tokens", 2000)
                ),
            }
        else:
            return {
                "config_list": [
                    {
                        "model": self.config["api"]["model"],
                        "api_key": self.config["api"]["openai"]["api_key"],
                    }
                ],
                "temperature": 0.1,
                "max_tokens": 2000,
            }

    def _get_function_map(self) -> Dict[str, Any]:
        try:
            from tools.commission_tools import (
                lookup_partner,
                lookup_sale,
                get_commission_rules,
                lookup_commission_calculation,
                recalculate_commission,
            )
            from tools.ticket_tools import search_tickets, get_ticket_status, search_backend_issues

            return {
                "lookup_partner": lookup_partner,
                "lookup_sale": lookup_sale,
                "get_commission_rules": get_commission_rules,
                "lookup_commission_calculation": lookup_commission_calculation,
                "recalculate_commission": recalculate_commission,
                "search_tickets": search_tickets,
                "get_ticket_status": get_ticket_status,
                "search_backend_issues": search_backend_issues,
            }
        except ImportError as e:
            print(f"Warning: Tool functions not available: {e}")
            return {}

    def process_call(self, transcript_text: str) -> Dict[str, Any]:
        """Process a partner call transcript through the 6-agent pipeline."""

        self._debug_info = []

        def add_debug(message):
            self._debug_info.append(message)
            print(f"DEBUG: {message}")

        try:
            add_debug("=== STARTING PARTNER SUPPORT AGENT PIPELINE (6 agents) ===")

            # Create assistant agents
            analyzer = self.transcript_analyzer.create_assistant()
            dup_detector = self.duplicate_detector.create_assistant()
            comm_verifier = self.commission_verifier.create_assistant()
            tracker = self.status_tracker.create_assistant()
            rca = self.rca_agent.create_assistant()
            resolver = self.resolution_agent.create_assistant()

            add_debug("All 6 agents created successfully.")

            # ── Step 1: Transcript Analysis ──
            add_debug("Step 1: Transcript Analyzer processing...")
            self.user_proxy.initiate_chat(
                analyzer,
                message=f"""Analyze this partner support call transcript and extract key information:

{transcript_text}

Extract: partner_id, partner_name, contact_name, sale_id, product_mentioned, issue_type, urgency, summary, expected_commission, received_commission.""",
                max_turns=1,
            )
            analysis_result = self.user_proxy.chat_messages[analyzer][-1]["content"]
            add_debug(f"Transcript analysis complete: {analysis_result[:200]}...")

            # ── Step 2: Duplicate Detection ──
            add_debug("Step 2: Duplicate Detector checking for existing tickets...")

            # Pre-fetch ticket data for the agent
            from tools.ticket_tools import search_tickets
            partner_id = self._extract_field(analysis_result, "partner_id")
            sale_id = self._extract_field(analysis_result, "sale_id")
            ticket_search_result = ""
            if partner_id:
                ticket_search_result = search_tickets(partner_id, sale_id)

            self.user_proxy.initiate_chat(
                dup_detector,
                message=f"""Based on the transcript analysis below, check for duplicate tickets.

TRANSCRIPT ANALYSIS:
{analysis_result}

EXISTING TICKETS SEARCH RESULT:
{ticket_search_result}

Analyze if this is a duplicate inquiry and report your findings.""",
                max_turns=1,
            )
            dup_result = self.user_proxy.chat_messages[dup_detector][-1]["content"]
            add_debug(f"Duplicate check complete: {dup_result[:200]}...")

            # ── Step 3: Commission Verification ──
            add_debug("Step 3: Commission Verifier recalculating...")

            from tools.commission_tools import recalculate_commission, lookup_partner, lookup_sale
            commission_data = ""
            if sale_id:
                commission_data = recalculate_commission(sale_id)
            partner_data = ""
            if partner_id:
                partner_data = lookup_partner(partner_id)
            sale_data = ""
            if sale_id:
                sale_data = lookup_sale(sale_id)

            self.user_proxy.initiate_chat(
                comm_verifier,
                message=f"""Verify the commission for this partner's sale.

TRANSCRIPT ANALYSIS:
{analysis_result}

PARTNER DETAILS:
{partner_data}

SALE DETAILS:
{sale_data}

COMMISSION RECALCULATION:
{commission_data}

Provide a detailed commission verification report.""",
                max_turns=1,
            )
            comm_result = self.user_proxy.chat_messages[comm_verifier][-1]["content"]
            add_debug(f"Commission verification complete: {comm_result[:200]}...")

            # ── Step 4: Status Tracking ──
            add_debug("Step 4: Status Tracker checking pipeline stage...")

            from tools.ticket_tools import get_ticket_status
            ticket_status_data = ""
            # Try to get status for tickets found in duplicate check
            ticket_ids = re.findall(r"TKT-\d+", dup_result)
            for tid in ticket_ids[:3]:  # Check up to 3 tickets
                ticket_status_data += get_ticket_status(tid) + "\n\n"

            self.user_proxy.initiate_chat(
                tracker,
                message=f"""Track the status of this partner's tickets and identify bottlenecks.

TRANSCRIPT ANALYSIS:
{analysis_result}

DUPLICATE CHECK RESULTS:
{dup_result}

TICKET STATUS DETAILS:
{ticket_status_data if ticket_status_data else "No existing tickets found for this partner/sale combination."}

Report the current pipeline status and bottleneck analysis.""",
                max_turns=1,
            )
            status_result = self.user_proxy.chat_messages[tracker][-1]["content"]
            add_debug(f"Status tracking complete: {status_result[:200]}...")

            # ── Step 5: Root Cause Analysis ──
            add_debug("Step 5: RCA Agent correlating with backend system issues...")

            from tools.ticket_tools import search_backend_issues
            backend_issues_data = ""
            if sale_id:
                backend_issues_data = search_backend_issues(order_id=sale_id)
            if not backend_issues_data or "No backend issues found" in backend_issues_data:
                if partner_id:
                    backend_issues_data += "\n\nBroader partner search:\n" + search_backend_issues(partner_id=partner_id)

            self.user_proxy.initiate_chat(
                rca,
                message=f"""Perform Root Cause Analysis by correlating the partner's complaint with backend system errors.

TRANSCRIPT ANALYSIS:
{analysis_result}

COMMISSION VERIFICATION:
{comm_result}

BACKEND SYSTEM ISSUES FOR THIS ORDER:
{backend_issues_data if backend_issues_data else "No backend issues found for this order_id."}

Determine if a backend system error explains the partner's commission problem. Provide RCA_TRACE_FOUND, matched issues, ROOT_CAUSE_SUMMARY, and TICKET_UPDATE_NOTE.""",
                max_turns=1,
            )
            rca_result = self.user_proxy.chat_messages[rca][-1]["content"]
            add_debug(f"RCA complete: {rca_result[:200]}...")

            # ── Step 6: Resolution ──
            add_debug("Step 6: Resolution Agent synthesizing findings...")
            self.user_proxy.initiate_chat(
                resolver,
                message=f"""Synthesize all findings from the agent pipeline into a final resolution report.

STEP 1 - TRANSCRIPT ANALYSIS:
{analysis_result}

STEP 2 - DUPLICATE CHECK:
{dup_result}

STEP 3 - COMMISSION VERIFICATION:
{comm_result}

STEP 4 - TICKET STATUS & PIPELINE:
{status_result}

STEP 5 - ROOT CAUSE ANALYSIS:
{rca_result}

Produce a JSON report with: extracted_info, duplicate_check, commission_verification, ticket_status, rca_findings, recommended_actions, auto_resolution_possible, priority, and summary.

For rca_findings, include:
- trace_found (boolean)
- backend_issues (list of matched issues with error_code, system, description, impact)
- root_cause_summary (string)
- ticket_update_note (string - the note to append to the support ticket)

Respond ONLY with valid JSON.""",
                max_turns=1,
            )
            resolution_result = self.user_proxy.chat_messages[resolver][-1]["content"]
            add_debug(f"Resolution complete: {resolution_result[:200]}...")

            # Parse the final JSON
            result = self._extract_json(resolution_result)
            add_debug("=== AGENT PIPELINE COMPLETED ===")

            # Attach debug trace and raw agent outputs
            result["_debug_trace"] = self._debug_info.copy()
            result["_agent_outputs"] = {
                "transcript_analysis": analysis_result,
                "duplicate_check": dup_result,
                "commission_verification": comm_result,
                "status_tracking": status_result,
                "root_cause_analysis": rca_result,
                "resolution": resolution_result,
            }

            return result

        except Exception as e:
            add_debug(f"ERROR: {str(e)}")
            return {
                "error": f"Pipeline failed: {str(e)}",
                "_debug_trace": self._debug_info.copy(),
            }

    def _extract_field(self, text: str, field_name: str) -> str:
        """Extract a field value from structured agent output."""
        patterns = [
            rf"\*?\*?{field_name}\*?\*?\s*[:=]\s*[`\"']?([A-Z]{{2,4}}-\d+)",
            rf"{field_name}\s*[:=]\s*(\S+)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip("`\"' ")
        return ""

    def _extract_json(self, response: str) -> Dict[str, Any]:
        """Extract JSON from agent response."""
        try:
            json_match = re.search(r"\{.*\}", response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group(0))
            return {"error": "No JSON found in resolution response", "raw": response}
        except json.JSONDecodeError as e:
            return {"error": f"JSON parse error: {e}", "raw": response}
