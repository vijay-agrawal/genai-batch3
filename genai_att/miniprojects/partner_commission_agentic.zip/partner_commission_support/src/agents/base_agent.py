from typing import Dict, Any, Optional, List, Callable
import autogen


class BaseAgent:
    def __init__(
        self,
        name: str,
        system_message: str,
        llm_config: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Callable]] = None,
    ):
        self.name = name
        self.system_message = system_message
        self.llm_config = llm_config or {
            "temperature": 0.1,
            "max_tokens": 2000,
        }
        self.tools = tools or []

    def create_assistant(self) -> autogen.AssistantAgent:
        """Create an AutoGen AssistantAgent with the agent's configuration."""
        return autogen.AssistantAgent(
            name=self.name,
            system_message=self.system_message,
            llm_config=self.llm_config,
        )
