"""
Ticket-related tool functions for agent use.
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from services.data_service import get_data_service


def search_tickets(partner_id: str, sale_id: str = None) -> str:
    """Search support tickets by partner ID and optionally sale ID."""
    svc = get_data_service()
    return svc.search_tickets(partner_id, sale_id)


def get_ticket_status(ticket_id: str) -> str:
    """Get detailed status of a specific ticket including pipeline stage and bottleneck analysis."""
    svc = get_data_service()
    return svc.get_ticket_status(ticket_id)


def search_backend_issues(order_id: str = None, partner_id: str = None) -> str:
    """Search backend system issues by order_id (sale_id) and/or partner_id.
    Returns details about system errors that may have caused commission delays or miscalculations."""
    svc = get_data_service()
    return svc.search_backend_issues(order_id, partner_id)
