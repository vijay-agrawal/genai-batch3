"""
Commission-related tool functions for agent use.
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from services.data_service import get_data_service


def lookup_partner(partner_id: str) -> str:
    """Look up partner details by ID."""
    svc = get_data_service()
    return svc.get_partner_formatted(partner_id)


def lookup_sale(sale_id: str) -> str:
    """Look up sale record by sale ID."""
    svc = get_data_service()
    return svc.get_sale_formatted(sale_id)


def get_commission_rules() -> str:
    """Get the current commission rules including product rates, tier bonuses, and volume bonuses."""
    svc = get_data_service()
    return svc.get_commission_rules_formatted()


def lookup_commission_calculation(sale_id: str) -> str:
    """Look up the recorded commission calculation for a specific sale."""
    svc = get_data_service()
    return svc.get_commission_formatted(sale_id)


def recalculate_commission(sale_id: str) -> str:
    """Recalculate the correct commission for a sale and compare with what was paid."""
    svc = get_data_service()
    return svc.recalculate_commission(sale_id)
