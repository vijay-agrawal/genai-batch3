"""
Telco Regression Test Optimizer - Streamlit UI
Uses LLM-generated Cypher queries against a Neo4j dependency graph to recommend
which modules need regression testing for a new release.
"""

import streamlit as st
import json
import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
env_path = Path(__file__).parent.parent / ".env"
load_dotenv(dotenv_path=env_path)

sys.path.insert(0, str(Path(__file__).parent))

from src.llm.chain import CypherQueryEngine

# ─── Page Configuration ───
st.set_page_config(
    page_title="Telco Regression Test Optimizer",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ───
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        color: #0057B8;
        text-align: center;
        margin-bottom: 0.3rem;
        font-weight: 700;
    }
    .sub-header {
        font-size: 1.1rem;
        color: #666;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #0057B8 0%, #009FDB 100%);
        color: white;
        padding: 1.2rem;
        border-radius: 0.75rem;
        text-align: center;
        margin-bottom: 0.5rem;
    }
    .metric-value { font-size: 1.8rem; font-weight: 700; }
    .metric-label { font-size: 0.85rem; opacity: 0.9; }
    .savings-card {
        background: linear-gradient(135deg, #00C853 0%, #1B5E20 100%);
        color: white;
        padding: 1.2rem;
        border-radius: 0.75rem;
        text-align: center;
        margin-bottom: 0.5rem;
    }
    .warning-card {
        background: linear-gradient(135deg, #FF6B00 0%, #E65100 100%);
        color: white;
        padding: 1.2rem;
        border-radius: 0.75rem;
        text-align: center;
        margin-bottom: 0.5rem;
    }
    .module-tag {
        display: inline-block;
        padding: 0.3rem 0.7rem;
        border-radius: 1rem;
        font-size: 0.85rem;
        margin: 0.2rem;
        font-weight: 500;
    }
    .module-changed {
        background-color: #ffebee;
        color: #c62828;
        border: 1px solid #ef9a9a;
    }
    .module-impacted {
        background-color: #fff3e0;
        color: #e65100;
        border: 1px solid #ffcc80;
    }
    .module-safe {
        background-color: #e8f5e9;
        color: #2e7d32;
        border: 1px solid #a5d6a7;
    }
</style>
""", unsafe_allow_html=True)


def render_metric_card(label, value, card_class="metric-card"):
    return f"""
    <div class="{card_class}">
        <div class="metric-value">{value}</div>
        <div class="metric-label">{label}</div>
    </div>
    """


# ─── Initialize Clients ───
@st.cache_resource
def init_engine():
    try:
        engine = CypherQueryEngine()
        engine.verify_connectivity()
        return engine
    except Exception:
        return None


def load_release_history():
    data_path = Path(__file__).parent / "src" / "data" / "release_history.json"
    with open(data_path, "r") as f:
        return json.load(f)


# ─── Sidebar: All Modules List ───
def render_sidebar(engine):
    with st.sidebar:
        st.markdown("### All Platform Modules")

        if not engine:
            st.error("Not connected to Neo4j")
            st.markdown("""
            **Setup required:**
            1. Set `NEO4J_URI`, `NEO4J_USERNAME`, `NEO4J_PASSWORD` in `.env`
            2. Run `python setup_graph.py` to build the dependency graph
            """)
            return None

        st.success("Connected to Neo4j")

        # Show graph stats
        summary = engine.get_graph_summary()
        if summary:
            s = summary[0]
            st.metric("Total Modules", s.get("modules", 0))
            st.metric("Releases", s.get("releases", 0))
            st.metric("Dependencies Found", s.get("dependencies", 0))

        st.markdown("---")

        # List all modules
        modules = engine.get_all_modules()
        if modules:
            st.markdown("**Module List:**")
            for m in modules:
                st.markdown(f"- {m['name']}")
        else:
            st.warning("No modules found. Run `python setup_graph.py` first.")
            return None

        st.markdown("---")
        st.markdown("### How It Works")
        st.markdown("""
        1. **50 historical releases** analyzed statistically
        2. **Dependency graph** stored in Neo4j
        3. **LLM generates Cypher** queries on demand
        4. **Get targeted** regression recommendations
        """)

        return modules


# ─── Main Content ───
def render_analysis(engine, all_modules):
    st.markdown("### New Release - Select Affected Modules")
    st.markdown("Select the modules that have code changes in this release. "
                "The system will identify which additional modules need regression testing "
                "based on the dependency graph built from 50 historical releases.")

    module_names = [m["name"] for m in all_modules]

    # Module selection
    col1, col2 = st.columns([3, 1])
    with col1:
        selected_modules = st.multiselect(
            "Modules with code changes in this release",
            module_names,
            help="Select 1-3 modules to see the targeted regression recommendation",
        )
    with col2:
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("Analyze Impact", type="primary", use_container_width=True):
            if selected_modules:
                st.session_state["run_analysis"] = selected_modules

    # Sample scenarios
    st.markdown("**Quick scenarios** (click to try):")
    sc1, sc2, sc3, sc4 = st.columns(4)
    with sc1:
        if st.button("Order + Billing", use_container_width=True):
            st.session_state["run_analysis"] = ["Order Management", "Billing"]
            st.rerun()
    with sc2:
        if st.button("CRM + Auth", use_container_width=True):
            st.session_state["run_analysis"] = ["CRM", "Authentication"]
            st.rerun()
    with sc3:
        if st.button("Network + Provisioning", use_container_width=True):
            st.session_state["run_analysis"] = ["Network Management", "Provisioning"]
            st.rerun()
    with sc4:
        if st.button("Rating + Order + Billing", use_container_width=True):
            st.session_state["run_analysis"] = ["Rating Engine", "Order Management", "Billing"]
            st.rerun()

    # Only show analysis if explicitly triggered by button click
    if "run_analysis" not in st.session_state:
        # Show the dependency graph overview
        st.markdown("---")
        st.markdown("### Dependency Graph Overview")
        st.markdown("This graph was built from 50 historical releases. "
                    "Each arrow shows which modules are impacted when a module changes.")

        graph_data = engine.get_full_dependency_graph()
        if graph_data["edges"]:
            for edge in graph_data["edges"]:
                st.markdown(f"- **{edge['source']}** → {edge['target']} "
                           f"(observed in {edge['weight']} releases)")
        return

    # Retrieve and clear the analysis trigger
    selected_modules = st.session_state.pop("run_analysis")

    # ─── Analysis Results ───
    st.markdown("---")

    # Query Neo4j for impacted modules (Cypher generated by LLM)
    impacted = engine.get_impacted_modules(selected_modules)
    impacted_names = [imp["module"] for imp in impacted]
    all_regression = selected_modules + impacted_names
    skipped = [m for m in module_names if m not in all_regression]

    total = len(module_names)
    regression_count = len(all_regression)
    skipped_count = len(skipped)
    reduction_pct = round((skipped_count / total) * 100, 1)

    # Metrics row
    st.markdown("### Impact Analysis Results")
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.markdown(render_metric_card("Total Modules", total), unsafe_allow_html=True)
    with m2:
        st.markdown(render_metric_card("Need Regression", regression_count, "warning-card"),
                    unsafe_allow_html=True)
    with m3:
        st.markdown(render_metric_card("Can Skip", skipped_count, "savings-card"),
                    unsafe_allow_html=True)
    with m4:
        st.markdown(render_metric_card("Test Reduction", f"{reduction_pct}%", "savings-card"),
                    unsafe_allow_html=True)

    # Module breakdown - visual
    st.markdown("---")
    st.markdown("### Module Breakdown")

    # Changed modules
    st.markdown("**Changed Modules** (code changes in this release):")
    changed_html = ""
    for m in selected_modules:
        changed_html += f'<span class="module-tag module-changed">{m}</span> '
    st.markdown(changed_html, unsafe_allow_html=True)

    # Impacted modules
    if impacted:
        st.markdown("**Impacted Modules** (need regression based on dependency graph):")
        impacted_html = ""
        for imp in impacted:
            impacted_html += f'<span class="module-tag module-impacted">{imp["module"]}</span> '
        st.markdown(impacted_html, unsafe_allow_html=True)

        # Show why each module is impacted
        st.markdown("**Dependency Details:**")
        for imp in impacted:
            sources = ", ".join(imp["impacted_by"])
            st.markdown(f"- **{imp['module']}** — impacted by changes in: {sources} "
                       f"(seen in {imp['max_weight']} historical releases)")
    else:
        st.info("No additional modules impacted. Only the changed modules need regression.")

    # Safe modules
    if skipped:
        st.markdown("**Safe to Skip** (no dependency on changed modules):")
        safe_html = ""
        for m in skipped:
            safe_html += f'<span class="module-tag module-safe">{m}</span> '
        st.markdown(safe_html, unsafe_allow_html=True)

    # Key insight box
    st.markdown("---")
    st.info(
        f"**Optimization Insight:** Instead of running regression on all **{total} modules**, "
        f"you only need to test **{regression_count} modules** ({', '.join(all_regression)}). "
        f"This is a **{reduction_pct}% reduction** in regression scope, saving significant "
        f"testing time and resources."
    )

    # LLM Explanation
    st.markdown("---")
    st.markdown("### AI-Generated Recommendation")
    with st.spinner("Generating detailed recommendation..."):
        explanation = engine.explain_recommendation(
            selected_modules, impacted, total
        )
    st.markdown(explanation)

    # Download button
    st.download_button(
        "Download Recommendation (JSON)",
        json.dumps({
            "changed_modules": selected_modules,
            "impacted_modules": [{"module": i["module"], "impacted_by": i["impacted_by"],
                                   "confidence": i["max_weight"]} for i in impacted],
            "regression_modules": all_regression,
            "skipped_modules": skipped,
            "total_modules": total,
            "reduction_percent": reduction_pct,
        }, indent=2),
        "regression_recommendation.json",
        "application/json",
    )


# ─── Historical Data Tab ───
def render_history():
    st.markdown("### Historical Release Data")
    st.markdown("This is the input data (50 releases) that was analyzed statistically "
                "to build the dependency graph in Neo4j.")

    release_data = load_release_history()
    releases = release_data["releases"]

    # Summary stats
    total_releases = len(releases)
    avg_changed = round(sum(len(r["modules_changed"]) for r in releases) / total_releases, 1)
    avg_failures = round(sum(len(r["test_failures"]) for r in releases) / total_releases, 1)

    c1, c2, c3 = st.columns(3)
    with c1:
        st.metric("Total Releases", total_releases)
    with c2:
        st.metric("Avg. Modules Changed per Release", avg_changed)
    with c3:
        st.metric("Avg. Test Failures per Release", avg_failures)

    st.markdown("---")

    # Show releases in expandable format
    for r in releases:
        changed = ", ".join(r["modules_changed"])
        failures = ", ".join(r["test_failures"])
        extra_failures = [f for f in r["test_failures"] if f not in r["modules_changed"]]

        with st.expander(f"**{r['release_id']}** ({r['date']}) — Changed: {changed}"):
            st.markdown(f"**Modules Changed:** {changed}")
            st.markdown(f"**Regression Run On:** All 12 modules")
            st.markdown(f"**Test Failures:** {failures}")
            if extra_failures:
                st.markdown(f"**Cross-module failures:** {', '.join(extra_failures)}")
            else:
                st.markdown("**Cross-module failures:** None (only changed modules failed)")


# ─── Main App ───
def main():
    st.markdown('<div class="main-header">Telco Regression Test Optimizer</div>',
                unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-header">AI-Powered Module Dependency Analysis using '
        'Historical Release Data + LLM + Neo4j Knowledge Graph</div>',
        unsafe_allow_html=True,
    )

    engine = init_engine()
    all_modules = render_sidebar(engine)

    if not all_modules:
        st.warning("Please connect to Neo4j and run `python setup_graph.py` first.")
        st.markdown("""
        ### Quick Start
        1. Add credentials to your `.env` file:
           ```
           NEO4J_URI=neo4j+s://your-instance.databases.neo4j.io
           NEO4J_USERNAME=neo4j
           NEO4J_PASSWORD=your-password
           AZURE_OPENAI_API_KEY=your-key
           AZURE_OPENAI_EMBEDDING_ENDPOINT=https://your-instance.openai.azure.com/
           AZURE_OPENAI_MODEL_NAME=gpt-4o-mini
           AZURE_OPENAI_API_VERSION=2024-05-01-preview
           AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o-mini
           ```
        2. Build the dependency graph:
           ```
           python setup_graph.py
           ```
           This reads 50 historical releases, analyzes them statistically,
           and stores the dependency graph in Neo4j.
        3. Start the app:
           ```
           streamlit run app.py
           ```
        """)
        return

    # Tabs
    tab1, tab2 = st.tabs([
        "📊 New Release Analysis",
        "📋 Historical Release Data",
    ])

    with tab1:
        render_analysis(engine, all_modules)
    with tab2:
        render_history()


if __name__ == "__main__":
    main()
