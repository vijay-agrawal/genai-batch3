import neo4j
from neo4j import GraphDatabase
from dotenv import load_dotenv
import os


# ── SSL connection troubleshooting ─────────────────────────────────────────────
# Option 1 (try first): change NEO4J_URI prefix in your .env file:
#   neo4j://        → encrypted, full cert validation  (default AuraDB)
#   neo4j+ssc://    → encrypted, cert validation SKIPPED  (self-signed / dev)
#   bolt://         → encrypted, full cert validation  (single-instance server)
#   bolt+ssc://     → encrypted, cert validation SKIPPED  (single-instance + self-signed)
#
# Option 2 (if Option 1 still fails): set NEO4J_TRUST_ALL=true in your .env.
#   This passes TrustAll() to the Python driver, bypassing TLS verification
#   entirely regardless of the URI scheme. Dev/workshop only — never production.
# ───────────────────────────────────────────────────────────────────────────────


load_dotenv()  # loads variables from .env


NEO4J_URI      = os.getenv("NEO4J_URI")
NEO4J_USERNAME     = os.getenv("NEO4J_USERNAME")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")
TRUST_ALL      = os.getenv("NEO4J_TRUST_ALL", "false").lower() == "true"

def test_connection():
    if not all([NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD]):
        raise ValueError("❌ Missing one or more Neo4j env variables")

    driver_kwargs = {"auth": (NEO4J_USERNAME, NEO4J_PASSWORD)}
    if TRUST_ALL:
        driver_kwargs["trusted_certificates"] = neo4j.TrustAll()
        print("⚠️  NEO4J_TRUST_ALL=true: TLS certificate verification is disabled (dev only).")

    driver = GraphDatabase.driver(NEO4J_URI, **driver_kwargs)

    try:
        with driver.session() as session:
            record = session.run("RETURN 1 AS ok").single()
            print("✅ Neo4j connection successful:", record["ok"])
    except Exception as e:
        # Common error messages and fixes:
        #   "certificate verify failed"                → see SSL options at top of file;
        #                                                 try neo4j+ssc:// URI or NEO4J_TRUST_ALL=true
        #   "Unable to retrieve routing information"   → wrong URI scheme or host unreachable;
        #                                                 try bolt+ssc:// for single-instance servers
        #   "authentication failure"                   → wrong NEO4J_USERNAME / NEO4J_PASSWORD in .env
        #   "Connection refused"                       → Neo4j not running or wrong port (default: 7687)
        #   "ServiceUnavailable: Failed to establish"  → firewall blocking port 7687
        print("❌ Neo4j connection failed:", e)
        print("\nSSL fix options:")
        print("  1. Change NEO4J_URI prefix to neo4j+ssc:// (or bolt+ssc:// for single-instance)")
        print("  2. Add NEO4J_TRUST_ALL=true to your .env file")
    finally:
        driver.close()

if __name__ == "__main__":
    test_connection()
