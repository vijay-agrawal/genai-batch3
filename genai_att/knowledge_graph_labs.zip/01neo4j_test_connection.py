from neo4j import GraphDatabase
from dotenv import load_dotenv
import os

load_dotenv()  # loads variables from .env

NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USERNAME = os.getenv("NEO4J_USERNAME")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")

def test_connection():
    if not all([NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD]):
        raise ValueError("❌ Missing one or more Neo4j env variables")

    driver = GraphDatabase.driver(
        NEO4J_URI,
        auth=(NEO4J_USERNAME, NEO4J_PASSWORD)
    )

    try:
        with driver.session() as session:
            record = session.run("RETURN 1 AS ok").single()
            print("✅ Neo4j connection successful:", record["ok"])
    except Exception as e:
        print("❌ Neo4j connection failed")
        print(e)
    finally:
        driver.close()

if __name__ == "__main__":
    test_connection()
