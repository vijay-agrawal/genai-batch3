"""
BLEU vs ROUGE vs BERTScore — Healthcare RAG Evaluation
=======================================================
Three metrics, three different strengths.  Each was designed to catch a
different class of failure in generated text.  In healthcare AI, choosing
the wrong metric can let dangerous errors slip through — or flag correct,
safe answers as failures.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
METRIC OVERVIEW
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  BLEU  (Bilingual Evaluation Understudy, Papineni et al. 2002)
  ─────
  Counts n-gram overlap between candidate and reference.
  Precision-focused: measures how much of the candidate appears in reference.
  Penalises verbosity via brevity penalty.

  Healthcare strength  : catches wrong medication names / dosages that
                         SOUND correct semantically but have zero n-gram
                         overlap with the correct instruction.
  Healthcare weakness  : punishes any rephrasing of clinical findings, even
                         when the meaning is identical (e.g. "MI" vs
                         "myocardial infarction").

  ROUGE  (Recall-Oriented Understudy for Gisting Evaluation, Lin 2004)
  ─────
  Also counts n-gram overlap, but recall-focused:
    ROUGE-1 : unigram recall  — did all key words make it into the summary?
    ROUGE-2 : bigram recall   — were key two-word phrases preserved?
    ROUGE-L : longest common subsequence — structural / ordering fidelity.
  Originally designed for summarisation evaluation.

  Healthcare strength  : evaluating discharge summaries / clinical notes
                         summarisation — did the summary retain ALL critical
                         facts (diagnoses, medications, follow-up plan)?
                         High ROUGE-Recall means nothing important was left out.
  Healthcare weakness  : like BLEU, surface-level only — paraphrased clinical
                         language scores low even when meaning is preserved.

  BERTScore  (Zhang et al. 2019)
  ─────────
  Embeds both texts with a pre-trained transformer (roberta-large by default),
  then greedily matches tokens by cosine similarity.
    Precision : does every candidate token find a close match in the reference?
    Recall    : does every reference token find a close match in the candidate?
    F1        : harmonic mean.

  Healthcare strength  : recognises that "heart attack" = "myocardial infarction",
                         "high blood pressure" = "hypertension", etc.
                         Catches hallucination where surface words overlap but
                         meaning diverges (e.g. wrong drug class, wrong organ).
  Healthcare weakness  : numbers are tricky — "metoprolol 25 mg" and
                         "metoprolol 50 mg" are very close in embedding space
                         even though the dosage difference is clinically critical.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
THE FIVE HEALTHCARE SCENARIOS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1. Paraphrase of a correct diagnosis          BERTScore ✓  BLEU ✗  ROUGE ✗
     → Clinician used "MI" shorthand; LLM answered with "myocardial infarction"
       BLEU / ROUGE penalise; BERTScore recognises equivalence.

  2. Medication dosage error (subtle)           All ↓  (BERTScore catches less)
     → LLM says "metoprolol 25 mg twice daily" vs correct "50 mg once daily".
       Words mostly overlap → BLEU/ROUGE are deceptively high.
       BERTScore is ALSO misleadingly high because embeddings are dosage-blind.
       Teaching point: for dosage-critical instructions, pair with exact-match.

  3. Discharge summary completeness             ROUGE-Recall ✓  BLEU ✗
     → LLM produced a good discharge summary but reordered / rephrased facts.
       ROUGE-Recall shows all facts are present; BLEU collapses.

  4. Full clinical hallucination                All low
     → LLM invented a cardiac cause for what was a pulmonary event.
       Surface medical terms are similar; BERTScore drops hardest.

  5. Partial / incomplete clinical answer       BERTScore Precision ✓ Recall ✗
     → LLM correctly stated the diagnosis but omitted the treatment plan.
       BERTScore Precision is high (no fabrication), Recall is low (info missing).
       ROUGE and BLEU both drop but give no directional diagnosis.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
INSTALL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  pip install bert-score rouge-score nltk
  python -c "import nltk; nltk.download('punkt')"
"""

from bert_score import score as bert_score
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer
import torch

smoother = SmoothingFunction().method1
_rouge = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)


# ──────────────────────────────────────────────────────────────────────────────
# Helper — compute BLEU, ROUGE, and BERTScore for one pair, print a report
# ──────────────────────────────────────────────────────────────────────────────

def evaluate_pair(label: str, reference: str, candidate: str, analysis: str = "") -> dict:
    ref_tokens  = reference.lower().split()
    cand_tokens = candidate.lower().split()

    # ── BLEU ──────────────────────────────────────────────────────────────────
    bleu1 = sentence_bleu([ref_tokens], cand_tokens, weights=(1, 0, 0, 0), smoothing_function=smoother)
    bleu2 = sentence_bleu([ref_tokens], cand_tokens, weights=(0.5, 0.5, 0, 0), smoothing_function=smoother)

    # ── ROUGE ─────────────────────────────────────────────────────────────────
    rouge_scores = _rouge.score(reference, candidate)
    r1_p  = rouge_scores["rouge1"].precision
    r1_r  = rouge_scores["rouge1"].recall
    r1_f  = rouge_scores["rouge1"].fmeasure
    r2_f  = rouge_scores["rouge2"].fmeasure
    rl_f  = rouge_scores["rougeL"].fmeasure

    # ── BERTScore ─────────────────────────────────────────────────────────────
    # rescale_with_baseline=False → raw cosine similarity scores (roberta-large)
    # Baseline rescaling compresses scores too aggressively for heavy paraphrases,
    # causing correct medical synonyms to score near-zero. Raw scores are more
    # interpretable: paraphrases land ~0.87-0.93, unrelated text ~0.70-0.80.
    P, R, F1 = bert_score(
        [candidate], [reference],
        lang="en",
        rescale_with_baseline=False,
        verbose=False,
    )
    bs_p  = P[0].item()
    bs_r  = R[0].item()
    bs_f1 = F1[0].item()

    # ── BERTScore verdict  (raw roberta-large; no baseline rescaling) ─────────
    # Raw scores never reach 0 for natural text — unrelated sentences still share
    # some embedding space. Interpret relative to these empirical bands:
    if bs_f1 >= 0.93:
        verdict = "Excellent  — semantically equivalent"
    elif bs_f1 >= 0.88:
        verdict = "Good       — minor phrasing differences"
    elif bs_f1 >= 0.84:
        verdict = "Acceptable — noticeable gap or omission"
    elif bs_f1 >= 0.80:
        verdict = "Poor       — significant semantic drift"
    else:
        verdict = "Failing    — off-topic or hallucinated"

    # ── Print report ──────────────────────────────────────────────────────────
    w = 78
    print(f"\n{'═' * w}")
    print(f"  {label}")
    print(f"{'─' * w}")
    print(f"  REFERENCE : {reference[:120]}{'...' if len(reference) > 120 else ''}")
    print(f"  CANDIDATE : {candidate[:120]}{'...' if len(candidate) > 120 else ''}")
    print(f"{'─' * w}")
    print(f"  BLEU-1       : {bleu1:.4f}   BLEU-2    : {bleu2:.4f}")
    print(f"  ROUGE-1 F1   : {r1_f:.4f}   (P={r1_p:.3f}  R={r1_r:.3f})")
    print(f"  ROUGE-2 F1   : {r2_f:.4f}   ROUGE-L F1: {rl_f:.4f}")
    print(f"  BERTScore    : P={bs_p:.4f}  R={bs_r:.4f}  F1={bs_f1:.4f}")
    print(f"  BS VERDICT   : {verdict}")
    if analysis:
        print(f"{'─' * w}")
        print(f"  ANALYSIS:")
        for line in analysis.strip().splitlines():
            print(f"  {line}")
    print(f"{'═' * w}")

    return dict(
        label=label, bleu1=bleu1, bleu2=bleu2,
        r1_f=r1_f, r1_p=r1_p, r1_r=r1_r, r2_f=r2_f, rl_f=rl_f,
        bs_p=bs_p, bs_r=bs_r, bs_f1=bs_f1, verdict=verdict,
    )


# ══════════════════════════════════════════════════════════════════════════════
# EXAMPLE 1 — Paraphrase of a correct clinical finding
#             BERTScore HIGH, BLEU LOW, ROUGE LOW
# ══════════════════════════════════════════════════════════════════════════════
#
# The patient record uses abbreviated clinical shorthand ("STEMI", "LVEF 35%").
# The LLM correctly explains these in patient-facing plain language.
# BLEU and ROUGE see almost zero n-gram overlap and flag this as WRONG.
# BERTScore recognises the semantic equivalence — the LLM gave the right answer.
#
# Teaching point: in a patient-facing clinical chatbot, BLEU/ROUGE would reject
# every correctly simplified medical explanation. BERTScore is the right metric.

example1 = dict(
    label="EXAMPLE 1 — Paraphrase: clinical shorthand → patient language  (BERTScore HIGH, BLEU/ROUGE LOW)",
    analysis="""\
The LLM correctly translated clinical language into patient-facing plain English — a CORRECT answer.
BLEU and ROUGE see almost zero n-gram overlap between "myocardial infarction / ejection fraction"
and "heart attack / pumping chamber" → they flag this as WRONG.
BERTScore embeds both sentences: "heart attack" and "myocardial infarction" are
close neighbours in roberta-large's embedding space → F1 stays HIGH.
→ For patient-facing chatbots, BLEU/ROUGE would reject every valid plain-language
  explanation. BERTScore is the right metric here.""",
    reference=(
        "Patient was admitted with an acute myocardial infarction. "
        "Cardiac ultrasound revealed the left ventricle ejection fraction was 35%, "
        "indicating severely impaired heart pumping function. "
        "The patient was commenced on aspirin, clopidogrel, and metoprolol."
    ),
    candidate=(
        "The patient suffered a heart attack and was hospitalised. "
        "A scan of the heart showed the main pumping chamber was functioning at only 35% "
        "of normal capacity, meaning the heart is significantly weakened. "
        "Treatment was started with two blood-thinning medications and a beta-blocker "
        "to reduce strain on the heart."
    ),
)

# ══════════════════════════════════════════════════════════════════════════════
# EXAMPLE 2 — Medication dosage error (subtle hallucination)
#             BLEU MEDIUM, ROUGE MEDIUM, BERTScore ALSO MISLEADINGLY HIGH
# ══════════════════════════════════════════════════════════════════════════════
#
# The correct prescription is metoprolol succinate 50 mg ONCE daily.
# The LLM answered metoprolol tartrate 25 mg TWICE daily.
# This is a clinically dangerous error — different salt formulation, half the
# dose per tablet, and different frequency.
# But the words are so similar that BLEU, ROUGE, AND BERTScore all score high.
#
# Teaching point: all three metrics fail on numeric/entity precision errors.
# For medication safety, supplement with exact-match checks on drug name,
# dose, and frequency — or use RAGAS faithfulness with a clinical LLM judge.

example2 = dict(
    label="EXAMPLE 2 — Medication dosage error  (ALL metrics dangerously HIGH — metrics blind spot)",
    analysis="""\
⚠  DANGEROUS BLIND SPOT — all three metrics score this as mostly correct.
The candidate swapped metoprolol succinate → tartrate (different formulation),
halved the dose (50 mg → 25 mg), and doubled the frequency (once → twice daily).
Clinically these are significant errors, but the sentences share so many words
that BLEU and ROUGE inflate, and embeddings treat similar-sounding doses as near-identical.
→ For medication safety: supplement ALL metrics with exact-match checks on
  drug name, salt form, dose, and frequency — or use RAGAS faithfulness
  with an LLM judge that can reason about clinical correctness.""",
    reference=(
        "Prescribe metoprolol succinate 50 mg orally once daily for heart failure "
        "with reduced ejection fraction. Titrate up every two weeks as tolerated."
    ),
    candidate=(
        "Prescribe metoprolol tartrate 25 mg orally twice daily for heart failure "
        "with reduced ejection fraction. Titrate up every two weeks as tolerated."
    ),
)

# ══════════════════════════════════════════════════════════════════════════════
# EXAMPLE 3 — Discharge summary completeness
#             ROUGE-Recall HIGH, BLEU LOW (paraphrase + reorder)
# ══════════════════════════════════════════════════════════════════════════════
#
# The reference discharge summary has five key clinical facts that MUST appear
# in any safe discharge document: diagnosis, procedure, medications, follow-up,
# and red-flag symptoms.
# The LLM rewrites these clearly but reorders them and uses different phrasing.
# BLEU sees low n-gram overlap and scores poorly.
# ROUGE-1 Recall is high because all the key clinical concepts (unigrams) appear.
# ROUGE-2 is moderate — bigram sequences differ due to reordering.
#
# Teaching point: for discharge summary evaluation, prioritise ROUGE-Recall
# (did the model include EVERY critical fact?) over BLEU precision.
# A patient missing a follow-up instruction is a safety risk regardless of style.

example3 = dict(
    label="EXAMPLE 3 — Discharge summary completeness  (ROUGE-Recall HIGH, BLEU LOW)",
    analysis="""\
The candidate contains ALL five safety-critical facts (diagnosis, IV antibiotics,
discharge meds, follow-up dates, red-flag symptoms) — just reordered and rephrased
into patient-friendly language.
BLEU is LOW because the bigram sequences are completely different after reordering.
ROUGE-1 Recall is HIGH because every key clinical unigram (salbutamol, amoxicillin,
38.5°C, chest X-ray, GP) appears somewhere in the candidate.
ROUGE-L captures ordering fidelity — moderate here due to reordering.
→ For discharge summaries: use ROUGE-Recall as your primary metric.
  A patient missing a follow-up instruction is a safety risk regardless of phrasing style.""",
    reference=(
        "Diagnosis: community-acquired pneumonia. "
        "Treatment: completed 5-day course of IV amoxicillin-clavulanate, transitioned to oral. "
        "Discharge medications: amoxicillin-clavulanate 875 mg twice daily for 7 days, "
        "salbutamol inhaler PRN. "
        "Follow-up: GP appointment within 5 days. Repeat chest X-ray in 6 weeks. "
        "Return to ED if: worsening shortness of breath, fever above 38.5°C, or coughing blood."
    ),
    candidate=(
        "The patient was treated for a lung infection (pneumonia acquired in the community). "
        "During admission, antibiotics were given through a drip for five days, then switched to tablets. "
        "On leaving hospital, take amoxicillin-clavulanate 875 mg twice a day for one week "
        "and use the blue reliever inhaler (salbutamol) when needed. "
        "See your GP within five days and have a follow-up chest X-ray after six weeks. "
        "Go back to the emergency department immediately if you develop worse breathlessness, "
        "a temperature over 38.5 degrees, or blood in your cough."
    ),
)

# ══════════════════════════════════════════════════════════════════════════════
# EXAMPLE 4 — Full clinical hallucination (wrong organ system)
#             ALL metrics LOW (BERTScore lowest)
# ══════════════════════════════════════════════════════════════════════════════
#
# The patient had a pulmonary embolism (lung clot).
# The LLM answered as if it were a myocardial infarction (heart attack).
# Both are acute cardiovascular emergencies with overlapping vocabulary
# (chest pain, shortness of breath, anticoagulation) — so BLEU and ROUGE
# inflate slightly on shared generic terms.
# BERTScore drops hardest because the contextual meaning of the treatment
# pathway (thrombolytics for PE vs PCI for MI) diverges in embedding space.
#
# Teaching point: BERTScore is more robust than BLEU/ROUGE at catching
# "plausible but wrong organ system" hallucinations common in medical LLMs.

example4 = dict(
    label="EXAMPLE 4 — Wrong organ-system hallucination  (ALL LOW, BERTScore lowest)",
    analysis="""\
The LLM described a heart attack (MI) instead of a lung clot (PE) — completely
wrong organ system and treatment pathway.
Both conditions share generic vocabulary (chest pain, anticoagulation, cardiology)
so BLEU and ROUGE inflate slightly on those shared surface terms.
BERTScore drops hardest because "thrombolysis + heparin + rivaroxaban for PE"
and "PCI + stent + dual antiplatelet for MI" land in very different regions of
embedding space — the contextual meaning of the treatment diverges strongly.
→ BERTScore is more robust than BLEU/ROUGE at catching organ-system hallucinations
  that share medical vocabulary with the correct answer.""",
    reference=(
        "Patient diagnosed with massive pulmonary embolism. CT pulmonary angiography "
        "confirmed bilateral clot burden. Treated with systemic thrombolysis (alteplase 100 mg IV). "
        "Anticoagulation started with heparin infusion, bridging to rivaroxaban 15 mg twice daily. "
        "Haematology follow-up in 3 months to assess duration of anticoagulation."
    ),
    candidate=(
        "Patient presented with ST-elevation myocardial infarction. Urgent coronary angiography "
        "showed complete occlusion of the left anterior descending artery. Primary PCI was performed "
        "with drug-eluting stent placement. Dual antiplatelet therapy started: aspirin 100 mg daily "
        "and ticagrelor 90 mg twice daily. Cardiology follow-up in 6 weeks."
    ),
)

# ══════════════════════════════════════════════════════════════════════════════
# EXAMPLE 5 — Partial / incomplete clinical answer
#             BERTScore Precision HIGH, Recall LOW — BLEU/ROUGE both collapse
# ══════════════════════════════════════════════════════════════════════════════
#
# The reference contains the full clinical picture: diagnosis, explanation,
# treatment, monitoring, and lifestyle advice.
# The candidate correctly states the diagnosis and drug but omits monitoring
# requirements and lifestyle advice — clinically incomplete but not wrong.
#
# Teaching point: BERTScore separates this failure mode cleanly:
#   Precision HIGH → what the LLM DID say is semantically correct (no fabrication)
#   Recall    LOW  → the reference contains facts the LLM never mentioned
# BLEU and ROUGE both give a medium-low number with no directional signal:
# you cannot tell from their scores whether the model hallucinated or just
# omitted content.  In healthcare this distinction is critical.

example5 = dict(
    label="EXAMPLE 5 — Incomplete answer (diagnosis correct, treatment plan missing)  (BS Precision HIGH, Recall LOW)",
    analysis="""\
The candidate correctly states the diagnosis and drug — nothing it says is WRONG.
But it omits metformin titration, empagliflozin, glucose monitoring, HbA1c recheck,
diet, exercise, and smoking cessation — a clinically dangerous omission.
BERTScore separates this cleanly:
  Precision HIGH → every token the candidate produced aligns with the reference (no fabrication)
  Recall    LOW  → large portions of the reference have no match in the candidate (facts missing)
BLEU and ROUGE both collapse to a single medium-low number with no directional signal —
you cannot tell from their scores whether the model hallucinated or just omitted content.
→ In healthcare, hallucination ≠ omission: a fabricated drug is a different risk than
  a missing monitoring plan. BERTScore Precision/Recall gives you that distinction.""",
    reference=(
        "Diagnosis: type 2 diabetes mellitus with HbA1c of 9.2%. "
        "Treatment: start metformin 500 mg twice daily with meals, titrate to 1000 mg "
        "twice daily over 4 weeks if tolerated. "
        "Monitoring: fasting blood glucose daily, HbA1c recheck in 3 months. "
        "Lifestyle: Mediterranean diet, 150 minutes of moderate exercise per week, "
        "smoking cessation counselling."
    ),
    candidate=(
        "The patient has type 2 diabetes with poor glucose control (HbA1c 9.2%). "
        "Metformin was prescribed."
    ),
)


# ──────────────────────────────────────────────────────────────────────────────
# Summary table
# ──────────────────────────────────────────────────────────────────────────────

def print_summary(results: list[dict]) -> None:
    w = 90
    print(f"\n\n{'═' * w}")
    print("  SUMMARY TABLE — BLEU vs ROUGE vs BERTScore across all healthcare examples")
    print(f"{'═' * w}")
    print(f"  {'Example':<12} {'BLEU-1':>6} {'BLEU-2':>6} {'R1-F':>6} {'R1-R':>6} {'R2-F':>6} {'RL-F':>6} {'BS-P':>6} {'BS-R':>6} {'BS-F1':>6}")
    print(f"{'─' * w}")
    for r in results:
        short = r["label"].split("—")[0].strip()
        print(
            f"  {short:<12} "
            f"{r['bleu1']:>6.3f} {r['bleu2']:>6.3f} "
            f"{r['r1_f']:>6.3f} {r['r1_r']:>6.3f} {r['r2_f']:>6.3f} {r['rl_f']:>6.3f} "
            f"{r['bs_p']:>6.3f} {r['bs_r']:>6.3f} {r['bs_f1']:>6.3f}"
        )
    print(f"{'═' * w}")

    print("""
METRIC SELECTION GUIDE FOR HEALTHCARE RAG
──────────────────────────────────────────
  Patient-facing explanations of clinical findings  → BERTScore F1
  Discharge / clinical note summarisation           → ROUGE-1 Recall (completeness)
  Medication instruction fidelity                   → Exact-match + RAGAS faithfulness
  Detecting wrong-organ hallucinations              → BERTScore F1
  Diagnosing hallucination vs omission              → BERTScore Precision vs Recall
""")


def main():
    print("\nBLEU vs ROUGE vs BERTScore — Healthcare RAG Evaluation Demo")
    print("(First run downloads roberta-large from HuggingFace — ~500 MB)\n")

    examples = [example1, example2, example3, example4, example5]
    results  = []

    for ex in examples:
        result = evaluate_pair(ex["label"], ex["reference"], ex["candidate"], ex.get("analysis", ""))
        results.append(result)
        input("\n  Press Enter to continue to the next example...")

    print_summary(results)


if __name__ == "__main__":
    main()
