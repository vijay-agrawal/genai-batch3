"""
RAGAS Evaluation Demo — Diagnosing RAG Failures in Healthcare
=============================================================
RAGAS (Retrieval Augmented Generation Assessment) gives us per-component metrics
so we can pinpoint WHERE a clinical RAG pipeline broke down:

  RETRIEVAL metrics  →  Was the right clinical information fetched?
    • context_recall     : fraction of ground-truth facts present in the retrieved chunks
    • context_precision  : fraction of retrieved chunks that were actually relevant

  GENERATION metrics  →  Did the LLM use that information correctly?
    • faithfulness       : does the answer only assert things supported by the context?
    • answer_relevancy   : does the answer actually address the clinical question asked?

Diagnostic grid
───────────────
                        context_recall  faithfulness
  Retrieval problem         LOW            LOW/HIGH     → fix chunking / retrieval
  Generation problem        HIGH           LOW          → fix prompt / LLM / temperature
  Both OK                   HIGH           HIGH         → pipeline healthy

This file demonstrates TWO deliberately broken scenarios against a simulated
clinical knowledge base containing patient records, medication protocols, and
discharge summaries.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW RAGAS WORKS INTERNALLY — LLM-as-a-Judge
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Yes — RAGAS is fundamentally an LLM-as-a-Judge framework.
Rather than comparing text with string matching or BLEU scores,
it uses a second LLM (the "judge") to reason about quality,
just like a human evaluator would.

Each metric is a small, focused LLM pipeline:

  context_recall  (LLM judge)
  ───────────────────────────
  Input : reference (ground-truth answer) + retrieved_contexts
  Step 1: Judge LLM breaks the reference into individual atomic claims.
          e.g. "Patient was diagnosed with pulmonary embolism" /
               "Alteplase 100 mg IV was administered"
  Step 2: For each claim, judge LLM asks:
          "Can this claim be inferred from the retrieved context? Yes/No"
  Score : claims supported by context  ÷  total claims in reference
  → Tells you: did the retriever fetch the documents that contain the answer?

  context_precision  (LLM judge)
  ────────────────────────────────
  Input : user_input + reference + each retrieved chunk individually
  Step 1: For each chunk, judge LLM asks:
          "Is this chunk useful for answering the question? Yes/No"
  Score : weighted precision — relevant chunks ranked higher score more
  → Tells you: was the retrieved context clinical signal or noise?

  faithfulness  (LLM judge, two-step)
  ────────────────────────────────────
  Input : response + retrieved_contexts
  Step 1: Judge LLM extracts every factual claim made in the response.
          e.g. "FAN-1 failed" / "temperature reached 80°C"
  Step 2: For each claim, judge LLM checks:
          "Is this claim directly supported by the context? Yes/No"
  Score : supported claims  ÷  total claims in response
  → Tells you: did the LLM hallucinate clinical facts, or stay grounded in context?

  answer_relevancy  (LLM + Embeddings)
  ─────────────────────────────────────
  Input : response + user_input
  Step 1: Judge LLM generates N synthetic questions that the response
          could plausibly be answering (reverse-engineering the question).
  Step 2: Embedding model encodes each synthetic question and the
          original user_input into vectors.
  Step 3: Cosine similarity between synthetic questions and user_input.
  Score : mean cosine similarity across all synthetic questions
  → Tells you: does the answer actually address what was asked?
    (A response about lab results scores low for a medication question.)

  Summary of what the judge LLM is actually doing:
  ┌──────────────────────┬────────────────────────────────────────┐
  │ Metric               │ Judge LLM task                         │
  ├──────────────────────┼────────────────────────────────────────┤
  │ context_recall       │ Claim extraction + entailment check    │
  │ context_precision    │ Relevance classification per chunk      │
  │ faithfulness         │ Claim extraction + support check        │
  │ answer_relevancy     │ Reverse question generation             │
  └──────────────────────┴────────────────────────────────────────┘

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHICH LLM IS RAGAS USING HERE? — Azure OpenAI configuration
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RAGAS does NOT hard-code any LLM provider. We override it by
passing our own LLM and embeddings at call time:

    result = evaluate(
        dataset,
        metrics=METRICS,
        llm=evaluator_llm,
        embeddings=evaluator_embeddings,
    )

Required .env variables:
    AZURE_OPENAI_ENDPOINT      — Azure AI Foundry endpoint (ends with /v1)
    AZURE_OPENAI_API_KEY       — your Azure API key
    AZURE_OPENAI_MODEL_NAME    — model deployment name (e.g. gpt-4o)
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT — embedding deployment name
                                        (e.g. text-embedding-3-small)

In production clinical settings, use a stronger judge model
than your RAG response model — the judge needs to reliably
detect subtle clinical hallucinations.
"""

import os
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from dotenv import load_dotenv
from ragas import EvaluationDataset, SingleTurnSample, evaluate
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
from ragas.metrics import faithfulness, answer_relevancy, context_recall, context_precision

load_dotenv()

# ──────────────────────────────────────────────────────────────────────────────
# Azure AI Foundry setup (OpenAI-compatible /v1 endpoint — no api-version)
# ──────────────────────────────────────────────────────────────────────────────

_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "").rstrip("/")
# Ensure base_url ends with /v1 exactly once
_base_url = _endpoint if _endpoint.endswith("/v1") else f"{_endpoint}/v1"

evaluator_llm = LangchainLLMWrapper(ChatOpenAI(
    base_url=_base_url,
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    model=os.getenv("AZURE_OPENAI_MODEL_NAME"),
    temperature=0,
))

evaluator_embeddings = LangchainEmbeddingsWrapper(OpenAIEmbeddings(
    base_url=_base_url,
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    model=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "text-embedding-3-small"),
))


# ══════════════════════════════════════════════════════════════════════════════
# EXAMPLE 1 — RETRIEVAL FAILURE
# ══════════════════════════════════════════════════════════════════════════════
#
# Scenario:
#   A clinician asks about the anticoagulation plan for patient MRN-4821 after
#   their confirmed pulmonary embolism on 2026-03-15.
#
#   The retriever returns WRONG chunks — it fetches records for a DIFFERENT
#   patient (MRN-4819) who also had a clotting-related admission, plus a
#   generic DVT protocol from the hospital formulary. The correct PE treatment
#   note for MRN-4821 is NOT retrieved.
#
#   The LLM, seeing no specific PE anticoagulation plan for MRN-4821, can only
#   give a generic protocol-level answer and admits it lacks the patient-specific
#   details.
#
# Expected RAGAS signal:
#   context_recall    → LOW  (key facts: rivaroxaban dose, duration, haematology
#                             follow-up are absent from retrieved context)
#   context_precision → LOW  (retrieved chunks are about wrong patient / generic)
#   faithfulness      → MEDIUM (LLM stays within what context says — the generic
#                             DVT protocol IS in the context)
#   answer_relevancy  → LOW–MEDIUM (mentions anticoagulation but can't answer
#                             the specific patient question)
#
# FIX: add patient MRN as metadata filter on retrieval; improve chunking so
#      each patient's event is a separate chunk with MRN + date fields indexed.

example1_retrieval_failure = SingleTurnSample(
    user_input=(
        "What is the anticoagulation plan for patient MRN-4821 following their "
        "pulmonary embolism diagnosed on 15 March 2026? Include drug, dose, duration, "
        "and any follow-up requirements."
    ),

    # What the retriever actually returned:
    #   Chunk A — Admission note for MRN-4819 (WRONG patient, similar presentation)
    #   Chunk B — Hospital DVT/PE protocol (generic, not patient-specific)
    #   Chunk C — MRN-4821 ED triage note from same day (right patient, wrong document —
    #             triage notes don't contain the treatment plan)
    retrieved_contexts=[
        (
            "ADMISSION NOTE | MRN-4819 | 2026-03-12 | Haematology\n"
            "Patient is a 58-year-old female admitted with left leg DVT confirmed on duplex ultrasound. "
            "No evidence of pulmonary embolism on CTPA. Started on apixaban 10 mg twice daily for 7 days "
            "then 5 mg twice daily. No provoking factors identified; 3-month treatment duration planned. "
            "Thrombophilia screen sent. Follow-up in haematology outpatient clinic in 4 weeks."
        ),
        (
            "HOSPITAL PROTOCOL | Anticoagulation in VTE (DVT/PE) | Version 4.1 | 2025-08\n"
            "For confirmed PE without haemodynamic instability: initiate therapeutic anticoagulation "
            "within 24 hours. First-line options: apixaban (10 mg BD x7 days then 5 mg BD) or "
            "rivaroxaban (15 mg BD x21 days then 20 mg OD). Minimum treatment duration: 3 months. "
            "Provoked PE: 3 months. Unprovoked PE: consider extended therapy after specialist review. "
            "Haematology review for all massive PE, malignancy-associated PE, or recurrent VTE."
        ),
        (
            "ED TRIAGE NOTE | MRN-4821 | 2026-03-15 | Emergency Department\n"
            "58-year-old male presenting with acute onset shortness of breath and right-sided pleuritic "
            "chest pain x 4 hours. O2 sats 91% on air. HR 112, BP 118/74. Wells score 6 — high probability PE. "
            "IV access inserted. CTPA ordered. Referred to respiratory medicine for admission."
        ),
    ],

    # LLM response: cannot answer specifically, falls back to protocol-level guidance
    response=(
        "The retrieved records do not include the specific treatment plan for patient MRN-4821 "
        "following their pulmonary embolism on 15 March 2026. Based on the hospital VTE protocol, "
        "first-line anticoagulation options for confirmed PE include apixaban or rivaroxaban for a "
        "minimum of 3 months. However, the patient-specific drug choice, dose, and follow-up plan "
        "for MRN-4821 are not available in the current context. Please review the respiratory "
        "medicine admission note or discharge summary directly."
    ),

    # The correct answer (what SHOULD have been answered had retrieval worked)
    reference=(
        "Patient MRN-4821 was diagnosed with bilateral pulmonary embolism on CTPA on 15 March 2026. "
        "Anticoagulation started with rivaroxaban 15 mg twice daily with meals for 21 days, "
        "then 20 mg once daily with the evening meal. Duration: 6 months (unprovoked PE). "
        "Haematology outpatient review in 3 months to assess for thrombophilia and determine "
        "whether extended anticoagulation is required. "
        "No thrombolysis required — patient haemodynamically stable."
    ),
)


# ══════════════════════════════════════════════════════════════════════════════
# EXAMPLE 2 — GENERATION FAILURE (hallucination / unfaithfulness)
# ══════════════════════════════════════════════════════════════════════════════
#
# Scenario:
#   A clinician asks about the HbA1c result and medication changes for patient
#   MRN-7203 at their diabetes review on 10 March 2026.
#
#   The retriever works PERFECTLY — it fetches the exact diabetes clinic note
#   and the updated medication reconciliation. But the LLM ignores the context
#   and hallucinates several key clinical details:
#     • Invents a different HbA1c value (says 9.8% instead of 8.4%)
#     • States insulin was started (not true — only metformin was uptitrated)
#     • Invents a renal function concern that doesn't appear in the context
#     • Gets the follow-up interval wrong (says 2 months, context says 3 months)
#
#   This is a generation / hallucination failure — dangerous in a clinical setting.
#
# Expected RAGAS signal:
#   context_recall    → HIGH (the correct clinical facts ARE in the retrieved context)
#   context_precision → HIGH (both retrieved chunks are directly relevant)
#   faithfulness      → LOW  (LLM asserted things not supported by the context)
#   answer_relevancy  → MEDIUM/HIGH (the answer addresses the right topic, just wrong)
#
# FIX: lower temperature, add "only use information from the provided context"
#      instruction, switch to a stronger model, or add a citation-checking step.

example2_generation_failure = SingleTurnSample(
    user_input=(
        "What was patient MRN-7203's HbA1c result at their diabetes review on "
        "10 March 2026, and what medication changes were made?"
    ),

    # Retriever returned PERFECT, highly-relevant chunks
    retrieved_contexts=[
        (
            "DIABETES CLINIC NOTE | MRN-7203 | 2026-03-10 | Endocrinology\n"
            "Patient is a 64-year-old male with type 2 diabetes mellitus diagnosed 2019. "
            "HbA1c today: 8.4% (target <7.5%). Previous HbA1c (Dec 2025): 9.1% — improvement noted. "
            "eGFR 68 mL/min/1.73m² — stable, no change from baseline. "
            "Medication review: metformin uptitrated from 500 mg twice daily to 1000 mg twice daily. "
            "Empagliflozin 10 mg once daily added (cardioprotective benefit, eGFR permits use). "
            "Atorvastatin 40 mg continuing. No insulin initiated — oral agents sufficient at this stage. "
            "Plan: diet and exercise education reinforced. HbA1c recheck in 3 months."
        ),
        (
            "MEDICATION RECONCILIATION | MRN-7203 | 2026-03-10\n"
            "CURRENT MEDICATIONS POST-REVIEW:\n"
            "1. Metformin 1000 mg twice daily with meals (↑ from 500 mg BD)\n"
            "2. Empagliflozin 10 mg once daily (NEW — started today)\n"
            "3. Atorvastatin 40 mg once daily at night (unchanged)\n"
            "4. Ramipril 5 mg once daily (unchanged, for hypertension)\n"
            "STOPPED: nil\n"
            "ALLERGIES: penicillin (rash)"
        ),
    ],

    # LLM hallucinated: wrong HbA1c, invented insulin, invented renal concern,
    # wrong follow-up interval
    response=(
        "At the diabetes review on 10 March 2026, patient MRN-7203's HbA1c was 9.8%, "
        "indicating suboptimal glycaemic control. Due to deteriorating control and concerns "
        "about declining renal function (eGFR below 60), the team decided to start the patient "
        "on basal insulin (insulin glargine 10 units at night) in addition to continuing metformin. "
        "The patient was advised to monitor fasting blood glucose daily and return for repeat "
        "HbA1c and renal function testing in 2 months."
    ),

    # Ground truth derived directly from the clinic note and medication reconciliation
    reference=(
        "Patient MRN-7203's HbA1c at the 10 March 2026 diabetes review was 8.4%, "
        "down from 9.1% in December 2025. "
        "Medication changes: metformin was uptitrated from 500 mg twice daily to 1000 mg twice daily, "
        "and empagliflozin 10 mg once daily was newly added. "
        "No insulin was initiated. eGFR was stable at 68 mL/min/1.73m². "
        "HbA1c recheck planned in 3 months."
    ),
)


# ──────────────────────────────────────────────
# Build dataset and run evaluation
# ──────────────────────────────────────────────

METRICS = [context_recall, context_precision, faithfulness, answer_relevancy]

LABELS = {
    "example1_retrieval_failure":  example1_retrieval_failure,
    "example2_generation_failure": example2_generation_failure,
}


def run_evaluation():
    results = {}

    for label, sample in LABELS.items():
        print(f"\n{'═'*60}")
        print(f"  Evaluating: {label}")
        print(f"{'═'*60}")
        print(f"  Question : {sample.user_input[:80]}...")
        print(f"  Answer   : {sample.response[:80]}...")

        dataset = EvaluationDataset(samples=[sample])
        result = evaluate(
            dataset,
            metrics=METRICS,
            llm=evaluator_llm,
            embeddings=evaluator_embeddings,
        )
        results[label] = result
        print(f"\n  Raw scores: {result}")

    return results


def print_diagnostic_report(results):
    """
    Summarise the scores in the diagnostic grid format and explain what each
    failure mode means for the clinical RAG pipeline.
    """
    print("\n")
    print("╔══════════════════════════════════════════════════════════════════════════╗")
    print("║         RAGAS DIAGNOSTIC REPORT — Clinical RAG Pipeline                 ║")
    print("╠══════════════════════════════════════════════════════════════════════════╣")
    print(f"║ {'Metric':<22} {'Example 1 (Retrieval ✗)':>24} {'Example 2 (Generation ✗)':>24} ║")
    print("╠══════════════════════════════════════════════════════════════════════════╣")

    metric_names = ["context_recall", "context_precision", "faithfulness", "answer_relevancy"]
    labels = list(results.keys())

    for m in metric_names:
        scores = []
        for lbl in labels:
            df = results[lbl].to_pandas()
            val = df[m].iloc[0] if m in df.columns else float("nan")
            scores.append(f"{val:.2f}")
        print(f"║ {m:<22} {scores[0]:>24} {scores[1]:>24} ║")

    print("╠══════════════════════════════════════════════════════════════════════════╣")
    print("║  DIAGNOSIS                                                               ║")
    print("╠══════════════════════════════════════════════════════════════════════════╣")
    print("║  Example 1: context_recall LOW + context_precision LOW                  ║")
    print("║    → RETRIEVAL PROBLEM (wrong patient chunks returned)                  ║")
    print("║    Fix: add MRN metadata filters; improve patient-event chunking         ║")
    print("╠══════════════════════════════════════════════════════════════════════════╣")
    print("║  Example 2: context_recall HIGH + faithfulness LOW                      ║")
    print("║    → GENERATION / HALLUCINATION PROBLEM                                 ║")
    print("║    Fix: lower temperature, 'only use context' prompt, stronger model    ║")
    print("╚══════════════════════════════════════════════════════════════════════════╝")

    print("""
KEY HEALTHCARE TAKEAWAY
───────────────────────
  context_recall / context_precision  →  Mirrors held up to the RETRIEVER.
  faithfulness / answer_relevancy     →  Mirrors held up to the LLM.

  Without this split, a single end-to-end accuracy score is useless for
  debugging — you cannot tell whether to fix the vector DB or the prompt.

  In clinical settings the stakes are higher:
  • Retrieval failure (Example 1) → wrong patient data returned → wrong treatment
    recommendation even if the LLM is well-behaved.
    Root cause: missing metadata filters (patient MRN, encounter date).

  • Generation failure (Example 2) → LLM invents wrong HbA1c, adds insulin that
    was never prescribed, fabricates renal concern.
    Root cause: LLM over-generating; needs stricter grounding instructions.

  RAGAS gives you the diagnostic signal to know WHICH component to fix.
  Retuning the retriever for a generation problem (or vice versa) wastes time
  and leaves patients at risk.
""")


if __name__ == "__main__":
    results = run_evaluation()
    print_diagnostic_report(results)
