import sys
import json
import os
import requests
from dotenv import load_dotenv
import streamlit as st
from openai import AzureOpenAI

load_dotenv()

azure_config = {
    "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "AZURE_OPENAI_MODEL_DEPLOYMENT_NAME": os.getenv("AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"),
    "AZURE_OPENAI_MODEL_NAME": os.getenv("AZURE_OPENAI_MODEL_NAME"),
    "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
    "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION")
}
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

st.title("Agent and function calling demo")

with st.sidebar:
    os.environ["AZURE_OPENAI_ENDPOINT"] = azure_config["AZURE_OPENAI_ENDPOINT"]
    
def generate_response(input_text):
    load_dotenv()
    
    client = AzureOpenAI(
        api_key=azure_config["AZURE_OPENAI_API_KEY"],
        api_version=azure_config["AZURE_OPENAI_API_VERSION"],
        azure_endpoint=azure_config["AZURE_OPENAI_ENDPOINT"],
    )
    
    functions=[
        {
            "name":"get_weather",
            "description":"Retrieve real-time weather information/data about a particular location/place",
            "parameters":{
                "type":"object",
                "properties":{
                    "location":{
                        "type":"string",
                        "description":"the exact location whose real-time weather is to be determined",
                    },
                },
                "required":["location"]
            }
        }
    ] 

    # connect to Stock MCP server
    # get list of tools
    # append it to the functions list above


    with st.spinner('Processing...'):
        initial_response = client.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_MODEL_NAME"),
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": input_text}
            ],
            functions=functions
        )
        
        if (initial_response.choices[0].finish_reason == 'function_call'):
            function_name = initial_response.choices[0].message.function_call.name
            function_argument = json.loads(initial_response.choices[0].message.function_call.arguments)
            function = getattr(sys.modules[__name__], function_name)
            resp = function(**function_argument)
        else:
            resp = initial_response.choices[0].message.content

    st.info(resp)
    
    # Display token usage information
    if hasattr(initial_response, 'usage'):
        st.info(f"Tokens used - Prompt: {initial_response.usage.prompt_tokens}, "
                f"Completion: {initial_response.usage.completion_tokens}, "
                f"Total: {initial_response.usage.total_tokens}")

def get_weather(location):
    print("get weather function called. Parameter passed:", location)
    url = "http://api.openweathermap.org/geo/1.0/direct?q=" + location + "&limit=1&appid=" + OPENWEATHERMAP_API_KEY
    response = requests.get(url)
    get_response = response.json()
    latitude = get_response[0]['lat']
    longitude = get_response[0]['lon']

    url_final = "https://api.openweathermap.org/data/2.5/weather?lat=" + str(latitude) + "&lon=" + str(longitude) + "&appid=" + OPENWEATHERMAP_API_KEY
    final_response = requests.get(url_final)
    final_response_json = final_response.json()
    weather = final_response_json['weather'][0]['description']
    return weather


with st.form("my_form"):
    text = st.text_area("Enter text:", "What's the weather in Mumbai today?")
    submitted = st.form_submit_button("Submit")
    generate_response(text)