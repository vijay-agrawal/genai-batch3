"""
Simple test client for the ICD Lookup MCP Server.
Runs the server as a subprocess and calls its tools via the MCP protocol.
"""

import asyncio
from fastmcp import Client


async def main():
    async with Client("icdlookup_mcpserver.py") as client:
        # List available tools
        tools = await client.list_tools()
        print("Available tools:", [t.name for t in tools])
        print()

        # Test list_available_conditions
        result = await client.call_tool("list_available_conditions", {})
        print("list_available_conditions:")
        print(result.content[0].text)
        print()

        # Test lookup_icd_code with various inputs
        test_cases = [
            "diabetes",
            "high blood pressure",
            "COVID",
            "migraine",
            "unknown condition",
        ]

        for condition in test_cases:
            result = await client.call_tool("lookup_icd_code", {"description": condition})
            print(f"lookup_icd_code('{condition}'):")
            print(" ", result.content[0].text)
        print()


if __name__ == "__main__":
    asyncio.run(main())
