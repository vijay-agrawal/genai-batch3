# ============================================================
# LANGFUSE MONITORING DEMO
# ============================================================
#
# WHAT IS LANGFUSE?
# Langfuse is an open-source LLM observability and evaluation platform.
# It gives you:
#   - Detailed traces of every LLM call (prompt, response, tokens, cost)
#   - Session grouping to track full user conversations
#   - LLM evaluation and scoring
#   - Self-hostable — your data never leaves your infrastructure
#
# HOW LANGFUSE DIFFERS FROM LANGSMITH:
#   LangSmith: Zero-code tracing via env vars (LangChain-native)
#   Langfuse:  Explicit CallbackHandler passed to each chain/graph call
#              → gives you more control; works with any LLM framework
#              → open-source, can be self-hosted (Docker)
#
# HOW TO SET UP LANGFUSE (Cloud):
#   1. Sign up at https://cloud.langfuse.com
#   2. Create a project → Settings → API Keys
#   3. Copy the **Public Key** and **Secret Key**
#   4. Paste them in the sidebar below
#
# HOW TO SELF-HOST (optional):
#   docker compose up   (see https://langfuse.com/docs/deployment/self-host)
#   Then set LANGFUSE_HOST to http://localhost:3000
#
# WHAT TO OBSERVE IN LANGFUSE:
#   - Simple Chatbot: trace per message, see exact prompt & response
#   - LangGraph Demo: nested trace with one span per agent node
#
# AZURE AI FOUNDRY LLM:
#   Uses the OpenAI-compatible endpoint (same as test_azure_openai.py)
#   Env vars:  AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY,
#              AZURE_OPENAI_DEPLOYMENT_NAME
# ============================================================

import os
from pathlib import Path

from dotenv import load_dotenv
import streamlit as st
from typing import TypedDict

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langgraph.graph import StateGraph, END

# Langfuse LangChain callback — this is the integration point
from langfuse import Langfuse
from langfuse.langchain import CallbackHandler

# Locate .env up to 2 levels up from this file
_here = Path(__file__).resolve().parent
_env_path = next(
    (p / ".env" for p in (_here, _here.parent, _here.parent.parent) if (p / ".env").is_file()),
    None,
)
if _env_path is None:
    print("ERROR: .env file not found in this directory or up to 2 levels up.", flush=True)
    raise SystemExit(1)
load_dotenv(_env_path)


# ============================================================
# LANGFUSE CALLBACK HANDLER
#
# Unlike LangSmith (env-var based), Langfuse requires you to
# create a CallbackHandler and pass it in the `config` argument
# of every LangChain/LangGraph invoke() or stream() call.
#
# config={"callbacks": [langfuse_handler]}
#
# Langfuse then intercepts every LLM call, tokenizer call, and
# chain event and streams them to the Langfuse server.
# ============================================================

def build_langfuse_handler(public_key: str, secret_key: str, host: str) -> CallbackHandler:
    """Initialize Langfuse credentials and return a LangChain CallbackHandler (langfuse v4+)."""
    Langfuse(public_key=public_key, secret_key=secret_key, host=host)
    return CallbackHandler()


# ============================================================
# AZURE AI FOUNDRY LLM
# ============================================================

def build_llm() -> ChatOpenAI:
    return ChatOpenAI(
        model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o-mini"),
        base_url=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        temperature=0,
    )


# ============================================================
# LANGGRAPH 3-AGENT CUSTOMER SUPPORT PIPELINE
#
# Identical logic to langsmith_demo.py — the ONLY difference
# is how monitoring is wired in:
#
#   LangSmith  → env vars set once at startup, zero code changes
#   Langfuse   → pass config={"callbacks": [handler]} on each call
#
#   [START]
#      │
#      ▼
#   triage_agent  ──→  expert_agent  ──→  quality_agent  ──→  [END]
#   (Classify)          (Answer)           (Review & Polish)
#
# The Langfuse handler is passed to graph.stream()/invoke() and
# propagates automatically to every node's LLM call inside the graph.
# ============================================================

class SupportState(TypedDict):
    user_query: str
    category: str          # set by triage_agent
    expert_response: str   # set by expert_agent
    final_response: str    # set by quality_agent


def triage_agent(state: SupportState, llm: ChatOpenAI) -> dict:
    """Agent 1: Classify the incoming query into a support category."""
    messages = [
        SystemMessage(content=(
            "You are a customer support triage specialist. "
            "Classify the user query into EXACTLY one of: technical, billing, general. "
            "Reply with only that single word — no punctuation, no explanation."
        )),
        HumanMessage(content=f"Query: {state['user_query']}"),
    ]
    category = llm.invoke(messages).content.strip().lower()
    if category not in ("technical", "billing", "general"):
        category = "general"
    return {"category": category}


def expert_agent(state: SupportState, llm: ChatOpenAI) -> dict:
    """Agent 2: Provide an expert answer tailored to the query category."""
    personas = {
        "technical": (
            "You are a senior technical support engineer. "
            "Provide clear, step-by-step troubleshooting guidance."
        ),
        "billing": (
            "You are a billing and payments specialist. "
            "Be precise about amounts, timelines, and refund policies."
        ),
        "general": (
            "You are a friendly customer service representative. "
            "Be warm, helpful, and direct."
        ),
    }
    system_prompt = personas.get(state["category"], personas["general"])
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=state["user_query"]),
    ]
    response = llm.invoke(messages).content.strip()
    return {"expert_response": response}


def quality_agent(state: SupportState, llm: ChatOpenAI) -> dict:
    """Agent 3: Review the expert draft and produce a polished final response."""
    messages = [
        SystemMessage(content=(
            "You are a quality assurance specialist for customer support. "
            "Review the draft response and improve it to be:\n"
            "  1. Clear and concise\n"
            "  2. Professional yet empathetic\n"
            "  3. Actionable — end with a specific next step\n"
            "Return only the improved response, nothing else."
        )),
        HumanMessage(content=(
            f"Original query: {state['user_query']}\n"
            f"Category: {state['category']}\n\n"
            f"Draft response:\n{state['expert_response']}\n\n"
            "Provide the improved final response:"
        )),
    ]
    final = llm.invoke(messages).content.strip()
    return {"final_response": final}


def build_support_graph(llm: ChatOpenAI):
    """Compile the 3-agent LangGraph support pipeline."""
    graph = StateGraph(SupportState)

    graph.add_node("triage_agent",  lambda s: triage_agent(s, llm))
    graph.add_node("expert_agent",  lambda s: expert_agent(s, llm))
    graph.add_node("quality_agent", lambda s: quality_agent(s, llm))

    graph.set_entry_point("triage_agent")
    graph.add_edge("triage_agent",  "expert_agent")
    graph.add_edge("expert_agent",  "quality_agent")
    graph.add_edge("quality_agent", END)

    return graph.compile()


# ============================================================
# STREAMLIT UI
# ============================================================

st.set_page_config(
    page_title="Langfuse Monitoring Demo",
    page_icon="🪲",
    layout="wide",
)

st.title("🪲 Langfuse Monitoring Demo")
st.caption("Azure AI Foundry  ·  LangChain  ·  LangGraph  ·  Langfuse")

# ── Sidebar: Langfuse config ──────────────────────────────
with st.sidebar:
    st.header("⚙️ Langfuse Setup")
    st.markdown("""
**Steps to get your keys:**
1. Sign up at [cloud.langfuse.com](https://cloud.langfuse.com)
2. **Create a project → Settings → API Keys**
3. Copy the **Public Key** and **Secret Key**
""")

    lf_public_key = st.text_input(
        "Public Key (pk-lf-…)",
        value=os.getenv("LANGFUSE_PUBLIC_KEY", ""),
        type="password",
        help="Find at cloud.langfuse.com → Project Settings → API Keys",
    )
    lf_secret_key = st.text_input(
        "Secret Key (sk-lf-…)",
        value=os.getenv("LANGFUSE_SECRET_KEY", ""),
        type="password",
        help="Shown only once when you create the key",
    )
    lf_host = st.text_input(
        "Host",
        value=os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com"),
        help="Change to http://localhost:3000 for self-hosted Langfuse",
    )

    langfuse_enabled = bool(lf_public_key and lf_secret_key)

    if langfuse_enabled:
        st.success("✅ Langfuse tracing active")
        st.markdown(f"**Host:** `{lf_host}`")
        st.markdown("[Open Langfuse Dashboard →](https://cloud.langfuse.com)")
    else:
        st.warning("⚠️ Enter Public Key and Secret Key to enable monitoring")

    st.divider()
    st.subheader("🔑 Azure LLM Config")
    st.code(
        f"Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT', 'not set')}\n"
        f"Model:    {os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME', 'not set')}",
        language=None,
    )

# ── Build LLM and graph ───────────────────────────────────
try:
    llm = build_llm()
except Exception as e:
    st.error(f"Failed to initialize Azure LLM: {e}")
    st.stop()

@st.cache_resource
def get_support_graph():
    return build_support_graph(build_llm())

support_graph = get_support_graph()

# ── Session ID for grouping chatbot traces ────────────────
if "lf_session_id" not in st.session_state:
    import uuid
    st.session_state.lf_session_id = str(uuid.uuid4())

# Helper: create a fresh handler per interaction
def make_handler(trace_name: str | None = None) -> CallbackHandler | None:
    """Return a Langfuse handler if credentials are configured, else None."""
    if not langfuse_enabled:
        return None
    handler = build_langfuse_handler(
        public_key=lf_public_key,
        secret_key=lf_secret_key,
        host=lf_host,
    )
    return handler


# ── Tabs ─────────────────────────────────────────────────
tab1, tab2 = st.tabs(["💬 Simple Chatbot", "🤖 LangGraph 3-Agent Demo"])


# ─────────────────────────────────────────────────────────
# TAB 1 — SIMPLE CHATBOT
# ─────────────────────────────────────────────────────────
with tab1:
    st.subheader("Simple Chatbot — traced with Langfuse CallbackHandler")
    st.markdown("""
Each message you send creates **one Langfuse trace**.
Open your project in Langfuse to see:
- The exact system prompt and conversation history
- The model's response
- Token usage and latency

**Key difference vs LangSmith:**
```python
# Pass the handler in config — this is the Langfuse integration point
response = llm.invoke(messages, config={"callbacks": [langfuse_handler]})
```

All messages in the same browser session share one **Session ID**, so you
can see the full conversation as a session in the Langfuse dashboard.
""")

    if "lf_chat_history" not in st.session_state:
        st.session_state.lf_chat_history = []

    for msg in st.session_state.lf_chat_history:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

    user_input = st.chat_input("Ask me anything…")

    if user_input:
        st.session_state.lf_chat_history.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.write(user_input)

        lc_messages = [SystemMessage(content="You are a helpful AI assistant. Be concise and friendly.")]
        for m in st.session_state.lf_chat_history:
            if m["role"] == "user":
                lc_messages.append(HumanMessage(content=m["content"]))
            elif m["role"] == "assistant":
                lc_messages.append(AIMessage(content=m["content"]))

        handler = make_handler()
        config = {"callbacks": [handler]} if handler else {}

        with st.chat_message("assistant"):
            with st.spinner("Thinking…"):
                # Pass config={"callbacks": [handler]} — this is what enables Langfuse tracing
                response = llm.invoke(lc_messages, config=config)
                st.write(response.content)

        st.session_state.lf_chat_history.append({"role": "assistant", "content": response.content})

        if langfuse_enabled:
            st.caption(f"✅ Trace logged to Langfuse  |  Session: `{st.session_state.lf_session_id[:8]}…`")


# ─────────────────────────────────────────────────────────
# TAB 2 — LANGGRAPH 3-AGENT DEMO
# ─────────────────────────────────────────────────────────
with tab2:
    st.subheader("LangGraph 3-Agent Customer Support Pipeline")
    st.markdown("""
A query flows through **3 specialised agents**:

| # | Agent | Role |
|---|-------|------|
| 1 | 🔀 **Triage Agent** | Classifies the query: *technical / billing / general* |
| 2 | 🎯 **Expert Agent** | Provides a domain-specific expert answer |
| 3 | ✅ **Quality Agent** | Reviews the draft and produces the final polished response |

**Langfuse integration — the callback propagates to all child nodes:**
```python
# Pass handler to graph.stream() — Langfuse sees every node's LLM call
for event in graph.stream(state, config={"callbacks": [langfuse_handler]}):
    ...
```

In Langfuse, each run shows a **nested trace** with one child span per agent node.
""")

    with st.expander("📊 Graph topology"):
        st.code("""
[START]
   |
   ▼
triage_agent  →  expert_agent  →  quality_agent  →  [END]
(Classify)       (Answer)         (Review & Polish)
""", language=None)

    user_query = st.text_area(
        "Enter your support query:",
        placeholder=(
            "E.g.  My payment failed but I was still charged twice. "
            "How do I get a refund?"
        ),
        height=100,
    )

    if st.button("▶ Run 3-Agent Pipeline", type="primary") and user_query:
        st.divider()

        initial_state: SupportState = {
            "user_query": user_query,
            "category": "",
            "expert_response": "",
            "final_response": "",
        }

        handler = make_handler()
        # Pass the Langfuse handler in config — it propagates to every node's LLM call
        run_config = {"callbacks": [handler]} if handler else {}

        triage_result = expert_result = quality_result = None

        with st.status("Running 3-agent pipeline…", expanded=True) as status:
            for event in support_graph.stream(initial_state, config=run_config):
                for node_name, update in event.items():
                    if node_name == "triage_agent":
                        triage_result = update
                        category = update.get("category", "unknown").upper()
                        st.write(f"✅ **Triage Agent** → category: `{category}`")
                    elif node_name == "expert_agent":
                        expert_result = update
                        st.write("✅ **Expert Agent** → draft response ready")
                    elif node_name == "quality_agent":
                        quality_result = update
                        st.write("✅ **Quality Agent** → final response polished")
            status.update(label="Pipeline complete!", state="complete")

        category    = triage_result.get("category", "") if triage_result else ""
        expert_resp = expert_result.get("expert_response", "") if expert_result else ""
        final_resp  = quality_result.get("final_response", "") if quality_result else ""

        c1, c2, c3 = st.columns(3)
        with c1:
            st.markdown("### 🔀 Triage Agent")
            badge_color = {"technical": "🔵", "billing": "🟡", "general": "🟢"}.get(category, "⚪")
            st.info(f"{badge_color} **{category.upper()}**")

        with c2:
            st.markdown("### 🎯 Expert Agent")
            with st.container(border=True):
                st.write(expert_resp)

        with c3:
            st.markdown("### ✅ Quality Agent")
            st.success(final_resp)

        st.divider()
        st.markdown("### 📤 Final Response (sent to user)")
        st.write(final_resp)

        if langfuse_enabled:
            st.success(
                "✅ Full pipeline trace logged to Langfuse — "
                "open the dashboard to see each agent node as a nested span."
            )

    # ── Side-by-side comparison callout ──────────────────
    st.divider()
    st.markdown("### 🔍 LangSmith vs Langfuse — Integration Comparison")
    col_a, col_b = st.columns(2)
    with col_a:
        st.markdown("**LangSmith** (env-var based)")
        st.code("""
# 1. Set env vars once at startup
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "<key>"
os.environ["LANGCHAIN_PROJECT"] = "my-project"

# 2. Call your chain/graph — tracing is automatic
response = llm.invoke(messages)
result = graph.invoke(state)
""", language="python")

    with col_b:
        st.markdown("**Langfuse** (callback based)")
        st.code("""
# 1. Initialize credentials and create a handler (langfuse v4+)
from langfuse import Langfuse
from langfuse.langchain import CallbackHandler
Langfuse(public_key="pk-lf-...", secret_key="sk-lf-...")
handler = CallbackHandler()

# 2. Pass it in config on every call
response = llm.invoke(
    messages, config={"callbacks": [handler]}
)
result = graph.invoke(
    state, config={"callbacks": [handler]}
)
""", language="python")
