# ============================================================
# LANGSMITH MONITORING DEMO
# ============================================================
#
# WHAT IS LANGSMITH?
# LangSmith is LangChain's observability platform for LLM apps.
# It gives you:
#   - Automatic tracing of ALL LangChain and LangGraph calls
#   - Step-by-step visual debugging of agent chains
#   - Token usage, latency, and cost tracking
#   - Evaluation and regression testing
#
# THE KILLER FEATURE: Zero-code-change tracing!
# Just set 3 environment variables and every LangChain/LangGraph
# call is automatically logged — no decorators, no callbacks needed.
#
# HOW TO SET UP LANGSMITH:
#   1. Sign up at https://smith.langchain.com
#   2. Go to Settings → API Keys → Create API Key
#   3. Copy your API key and paste it in the sidebar below
#   4. That's it — all traces appear in your project dashboard
#
# WHAT TO OBSERVE IN LANGSMITH:
#   - Simple Chatbot: single LLM call per message, full input/output
#   - LangGraph Demo: trace shows all 3 agent nodes, their inputs/outputs,
#     and the total token usage across the pipeline
#
# AZURE AI FOUNDRY LLM:
#   Uses the OpenAI-compatible endpoint (same pattern as test_azure_openai.py)
#   Env vars:  AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY,
#              AZURE_OPENAI_DEPLOYMENT_NAME
# ============================================================

import os
from pathlib import Path

from dotenv import load_dotenv
import streamlit as st
from typing import TypedDict, Literal

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langgraph.graph import StateGraph, END

# Locate .env up to 2 levels up from this file
_here = Path(__file__).resolve().parent
_env_path = next(
    (p / ".env" for p in (_here, _here.parent, _here.parent.parent) if (p / ".env").is_file()),
    None,
)
if _env_path is None:
    print("ERROR: .env file not found in this directory or up to 2 levels up.", flush=True)
    raise SystemExit(1)
load_dotenv(_env_path)


# ============================================================
# LANGSMITH CONFIGURATION
# Setting these three environment variables is ALL that is needed
# to enable full tracing of LangChain and LangGraph workloads.
# ============================================================

def configure_langsmith(api_key: str, project_name: str) -> None:
    os.environ["LANGCHAIN_TRACING_V2"] = "true"
    os.environ["LANGCHAIN_API_KEY"] = api_key
    os.environ["LANGCHAIN_PROJECT"] = project_name


# ============================================================
# AZURE AI FOUNDRY LLM
# Uses the OpenAI-compatible endpoint — identical pattern to
# test_azure_openai.py but wrapped in LangChain's ChatOpenAI
# so tracing works automatically via LangSmith.
# ============================================================

def build_llm() -> ChatOpenAI:
    return ChatOpenAI(
        model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o-mini"),
        base_url=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        temperature=0,
    )


# ============================================================
# LANGGRAPH 3-AGENT CUSTOMER SUPPORT PIPELINE
#
# This graph demonstrates a realistic multi-agent workflow:
#
#   [START]
#      │
#      ▼
#   triage_agent  ──→  expert_agent  ──→  quality_agent  ──→  [END]
#   (Classify)          (Answer)           (Review & Polish)
#
# Agent 1 — Triage:   Classifies the query as technical/billing/general
# Agent 2 — Expert:   Provides a domain-specific detailed answer
# Agent 3 — Quality:  Reviews the draft and produces a polished response
#
# In LangSmith, open the trace to see each node's prompt, response,
# token count, and latency in a single waterfall view.
# ============================================================

class SupportState(TypedDict):
    user_query: str
    category: str          # set by triage_agent
    expert_response: str   # set by expert_agent
    final_response: str    # set by quality_agent


def triage_agent(state: SupportState, llm: ChatOpenAI) -> dict:
    """Agent 1: Classify the incoming query into a support category."""
    messages = [
        SystemMessage(content=(
            "You are a customer support triage specialist. "
            "Classify the user query into EXACTLY one of: technical, billing, general. "
            "Reply with only that single word — no punctuation, no explanation."
        )),
        HumanMessage(content=f"Query: {state['user_query']}"),
    ]
    category = llm.invoke(messages).content.strip().lower()
    if category not in ("technical", "billing", "general"):
        category = "general"
    return {"category": category}


def expert_agent(state: SupportState, llm: ChatOpenAI) -> dict:
    """Agent 2: Provide an expert answer tailored to the query category."""
    personas = {
        "technical": (
            "You are a senior technical support engineer. "
            "Provide clear, step-by-step troubleshooting guidance."
        ),
        "billing": (
            "You are a billing and payments specialist. "
            "Be precise about amounts, timelines, and refund policies."
        ),
        "general": (
            "You are a friendly customer service representative. "
            "Be warm, helpful, and direct."
        ),
    }
    system_prompt = personas.get(state["category"], personas["general"])
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=state["user_query"]),
    ]
    response = llm.invoke(messages).content.strip()
    return {"expert_response": response}


def quality_agent(state: SupportState, llm: ChatOpenAI) -> dict:
    """Agent 3: Review the expert draft and produce a polished final response."""
    messages = [
        SystemMessage(content=(
            "You are a quality assurance specialist for customer support. "
            "Review the draft response and improve it to be:\n"
            "  1. Clear and concise\n"
            "  2. Professional yet empathetic\n"
            "  3. Actionable — end with a specific next step\n"
            "Return only the improved response, nothing else."
        )),
        HumanMessage(content=(
            f"Original query: {state['user_query']}\n"
            f"Category: {state['category']}\n\n"
            f"Draft response:\n{state['expert_response']}\n\n"
            "Provide the improved final response:"
        )),
    ]
    final = llm.invoke(messages).content.strip()
    return {"final_response": final}


def build_support_graph(llm: ChatOpenAI):
    """Compile the 3-agent LangGraph support pipeline."""
    graph = StateGraph(SupportState)

    graph.add_node("triage_agent",  lambda s: triage_agent(s, llm))
    graph.add_node("expert_agent",  lambda s: expert_agent(s, llm))
    graph.add_node("quality_agent", lambda s: quality_agent(s, llm))

    graph.set_entry_point("triage_agent")
    graph.add_edge("triage_agent",  "expert_agent")
    graph.add_edge("expert_agent",  "quality_agent")
    graph.add_edge("quality_agent", END)

    return graph.compile()


# ============================================================
# STREAMLIT UI
# ============================================================

st.set_page_config(
    page_title="LangSmith Monitoring Demo",
    page_icon="🔭",
    layout="wide",
)

st.title("🔭 LangSmith Monitoring Demo")
st.caption("Azure AI Foundry  ·  LangChain  ·  LangGraph  ·  LangSmith")

# ── Sidebar: LangSmith config ─────────────────────────────
with st.sidebar:
    st.header("⚙️ LangSmith Setup")
    st.markdown("""
**Steps to get your API key:**
1. Sign up at [smith.langchain.com](https://smith.langchain.com)
2. **Settings → API Keys → Create API Key**
3. Paste the key below
""")

    langsmith_key = st.text_input(
        "LangSmith API Key",
        value=os.getenv("LANGSMITH_API_KEY", os.getenv("LANGCHAIN_API_KEY", "")),
        type="password",
        help="Find at smith.langchain.com → Settings → API Keys",
    )
    project_name = st.text_input(
        "Project Name",
        value="genai-training-demo",
        help="Traces will be grouped under this project in LangSmith",
    )

    if langsmith_key:
        configure_langsmith(langsmith_key, project_name)
        st.success("✅ LangSmith tracing active")
        st.markdown(f"**Project:** `{project_name}`")
        st.markdown("[Open LangSmith Dashboard →](https://smith.langchain.com)")
    else:
        st.warning("⚠️ Enter your API key to enable monitoring")

    st.divider()
    st.subheader("🔑 Azure LLM Config")
    st.code(
        f"Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT', 'not set')}\n"
        f"Model:    {os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME', 'not set')}",
        language=None,
    )

# ── Build LLM (shared across both tabs) ──────────────────
try:
    llm = build_llm()
except Exception as e:
    st.error(f"Failed to initialize Azure LLM: {e}")
    st.stop()

# ── Tabs ─────────────────────────────────────────────────
tab1, tab2 = st.tabs(["💬 Simple Chatbot", "🤖 LangGraph 3-Agent Demo"])


# ─────────────────────────────────────────────────────────
# TAB 1 — SIMPLE CHATBOT
# ─────────────────────────────────────────────────────────
with tab1:
    st.subheader("Simple Chatbot — auto-traced by LangSmith")
    st.markdown("""
Every message you send generates **one LangSmith trace**.
Open your project in LangSmith to see:
- The exact system prompt and conversation history sent to the model
- The full response
- Token usage and latency

**No extra code needed** — tracing is active the moment `LANGCHAIN_TRACING_V2=true` is set.
""")

    # Persist chat history across Streamlit reruns
    if "ls_chat_history" not in st.session_state:
        st.session_state.ls_chat_history = []

    # Render existing messages
    for msg in st.session_state.ls_chat_history:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

    user_input = st.chat_input("Ask me anything…")

    if user_input:
        st.session_state.ls_chat_history.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.write(user_input)

        # Build full message history for the LLM
        lc_messages = [SystemMessage(content="You are a helpful AI assistant. Be concise and friendly.")]
        for m in st.session_state.ls_chat_history:
            if m["role"] == "user":
                lc_messages.append(HumanMessage(content=m["content"]))
            elif m["role"] == "assistant":
                lc_messages.append(AIMessage(content=m["content"]))

        with st.chat_message("assistant"):
            with st.spinner("Thinking…"):
                # This single call is auto-traced in LangSmith
                response = llm.invoke(lc_messages)
                st.write(response.content)

        st.session_state.ls_chat_history.append({"role": "assistant", "content": response.content})

        if langsmith_key:
            st.caption("✅ Trace logged to LangSmith")


# ─────────────────────────────────────────────────────────
# TAB 2 — LANGGRAPH 3-AGENT DEMO
# ─────────────────────────────────────────────────────────
with tab2:
    st.subheader("LangGraph 3-Agent Customer Support Pipeline")
    st.markdown("""
A query flows through **3 specialised agents**:

| # | Agent | Role |
|---|-------|------|
| 1 | 🔀 **Triage Agent** | Classifies the query: *technical / billing / general* |
| 2 | 🎯 **Expert Agent** | Provides a domain-specific expert answer |
| 3 | ✅ **Quality Agent** | Reviews the draft and produces the final polished response |

In **LangSmith**, the trace for each run shows every agent node as a child span —
click any span to inspect its exact prompt, output, token count, and latency.
""")

    with st.expander("📊 Graph topology"):
        st.code("""
[START]
   |
   ▼
triage_agent  →  expert_agent  →  quality_agent  →  [END]
(Classify)       (Answer)         (Review & Polish)
""", language=None)

    # Cache compiled graph — re-building on every rerun is expensive
    @st.cache_resource
    def get_support_graph():
        return build_support_graph(build_llm())

    support_graph = get_support_graph()

    user_query = st.text_area(
        "Enter your support query:",
        placeholder=(
            "E.g.  My payment failed but I was still charged twice. "
            "How do I get a refund?"
        ),
        height=100,
    )

    if st.button("▶ Run 3-Agent Pipeline", type="primary") and user_query:
        st.divider()

        initial_state: SupportState = {
            "user_query": user_query,
            "category": "",
            "expert_response": "",
            "final_response": "",
        }

        # Stream graph execution so we can show progress in real time.
        # LangSmith captures the entire trace regardless of invoke vs stream.
        triage_result = expert_result = quality_result = None

        with st.status("Running 3-agent pipeline…", expanded=True) as status:
            for event in support_graph.stream(initial_state):
                for node_name, update in event.items():
                    if node_name == "triage_agent":
                        triage_result = update
                        category = update.get("category", "unknown").upper()
                        st.write(f"✅ **Triage Agent** → category: `{category}`")
                    elif node_name == "expert_agent":
                        expert_result = update
                        st.write("✅ **Expert Agent** → draft response ready")
                    elif node_name == "quality_agent":
                        quality_result = update
                        st.write("✅ **Quality Agent** → final response polished")
            status.update(label="Pipeline complete!", state="complete")

        # Retrieve final values from the last update
        category     = triage_result.get("category", "") if triage_result else ""
        expert_resp  = expert_result.get("expert_response", "") if expert_result else ""
        final_resp   = quality_result.get("final_response", "") if quality_result else ""

        # Display each agent's output
        c1, c2, c3 = st.columns(3)
        with c1:
            st.markdown("### 🔀 Triage Agent")
            badge_color = {"technical": "🔵", "billing": "🟡", "general": "🟢"}.get(category, "⚪")
            st.info(f"{badge_color} **{category.upper()}**")

        with c2:
            st.markdown("### 🎯 Expert Agent")
            with st.container(border=True):
                st.write(expert_resp)

        with c3:
            st.markdown("### ✅ Quality Agent")
            st.success(final_resp)

        st.divider()
        st.markdown("### 📤 Final Response (sent to user)")
        st.write(final_resp)

        if langsmith_key:
            st.success(
                "✅ Full pipeline trace available in LangSmith — "
                "each agent node is a separate span with its own prompt and output."
            )
