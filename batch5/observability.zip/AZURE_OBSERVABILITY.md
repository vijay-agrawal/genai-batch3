# Azure AI Foundry & Azure Portal — Observability Reference

Covers native Azure monitoring capabilities for LLM workloads: logs, prompts, token usage, latency, cost, and alerting. For third-party tracing tools used in this repo see `observability/`.

---

## 1. Observability Stack Overview

```
Your App (LangChain / Azure AI SDK / REST)
        │
        ▼
Azure OpenAI Service / Azure AI Foundry
        │
        ├── Diagnostic Settings ──► Log Analytics Workspace
        │                                    │
        │                           KQL queries, Workbooks,
        │                           Alerts, Dashboards
        │
        ├── Azure Monitor Metrics ──► Metrics Explorer
        │                             (token usage, latency, errors)
        │
        ├── AI Foundry Tracing ──► AI Foundry Portal (Traces tab)
        │                          (prompt/response, spans, eval)
        │
        └── Application Insights ──► End-to-end distributed traces
                                      Custom telemetry, Live Metrics
```

---

## 2. Azure OpenAI Diagnostic Logs

### 2.1 Enable Diagnostic Settings

**Azure Portal path:**
`Azure OpenAI resource → Monitoring → Diagnostic settings → + Add diagnostic setting`

| Log category | What it captures |
|---|---|
| `AzureOpenAIRequests` | Every API call: model, deployment, prompt tokens, completion tokens, latency, HTTP status, content filter result |
| `AuditLogs` | Configuration changes, key rotations, RBAC changes |

**Destinations available:**
- **Log Analytics Workspace** — queryable with KQL (recommended)
- **Storage Account** — long-term archival
- **Event Hub** — stream to SIEM / Splunk / Datadog

> **Prompt content logging** is disabled by default for privacy. Enable it in:
> `Azure OpenAI resource → Settings → Network → Allow prompt/completion logging`
> Once enabled, full prompt and completion text appears in `AzureOpenAIRequests`.

### 2.2 Key Fields in `AzureOpenAIRequests`

| Field | Description |
|---|---|
| `TimeGenerated` | UTC timestamp of the request |
| `DeploymentName` | e.g. `gpt-4o-mini` |
| `ModelName` | Underlying model |
| `PromptTokens` | Input token count |
| `CompletionTokens` | Output token count |
| `TotalTokens` | Sum of prompt + completion |
| `DurationMs` | End-to-end latency in ms |
| `ResultCode` | HTTP status (200, 429, 500…) |
| `ContentFilterResults` | Hate/violence/sexual/self-harm filter outcomes |
| `CallerIPAddress` | Source IP |
| `OperationName` | `ChatCompletions_Create`, `Embeddings_Create`, etc. |

---

## 3. Azure Monitor Metrics

Azure Monitor is the central observability service in the Azure Portal. For Azure OpenAI, it provides **real-time and historical metrics** — request counts, latency percentiles, token throughput, error rates, and content filter hits — with no code changes required. All Azure OpenAI platform metrics are free (see §11.2).

**Portal paths:**

| Entry point | Path |
|---|---|
| From your Azure OpenAI resource | `Azure OpenAI resource → Monitoring → Metrics` |
| From your Azure AI Foundry resource | `AI Foundry resource → Monitoring → Metrics` |
| Direct from Azure Monitor | `Azure Portal → Monitor → Metrics → select scope` |

---

### 3.1 Metrics Explorer — Portal Walkthrough

The screenshot below shows the **Azure Monitor Metrics Explorer** opened against an Azure AI Foundry resource (`genai-trng-fdry`), with the metric category dropdown open:

![Azure Monitor Metrics Explorer — Azure OpenAI metric categories](images/azure_monitor_metrics.png)

**What you can see in the dropdown:**

The metrics are grouped into two namespaces under **Cognitive Services standard metrics**:

**AZURE OPENAI — HTTP REQUESTS**

| Metric name | What it measures |
|---|---|
| `Azure OpenAI AvailabilityRate` | % of requests that returned a successful (non-5xx) response |
| `Azure OpenAI Requests` | Total request count; split by deployment, API type, or status code |

**AZURE OPENAI — LATENCY**

| Metric name | What it measures |
|---|---|
| `Normalized Time to First Byte` | Time from request sent to first token received, normalized per token |
| `Time Between Tokens` | Average inter-token interval during streaming — indicates generation throughput |
| `Time to Last Byte` | Full round-trip latency (request to final response byte) |
| `Time to Response` | Time from request to first response byte (TTFB / TTFT) |

---

### 3.2 Using the Metrics Explorer UI

The toolbar at the top of the Metrics Explorer gives you four key tools:

**➕ Add metric**
Click to add a metric to the chart. You will select:
1. **Scope** — your Azure OpenAI or AI Foundry resource (e.g., `genai-trng-fdry`)
2. **Metric Namespace** — `Cognitive Services standard metrics` for built-in Azure OpenAI metrics
3. **Metric** — choose from the categories in §3.1
4. **Aggregation** — Sum, Average, Max, Min, Count

You can overlay multiple metrics on the same chart (e.g., `Azure OpenAI Requests` + `Time to Last Byte`) to correlate request volume with latency.

**🔽 Add filter**
Narrows the metric to a subset of traffic using **dimensions**:

| Dimension | Example use |
|---|---|
| `ModelDeploymentName` | Show metrics for `gpt-4o-mini` only |
| `ApiName` | Separate `ChatCompletions` from `Embeddings` |
| `StatusCode` | Filter to `429` only to watch rate-limit events |
| `Region` | Isolate a single Azure region in multi-region deployments |

**⚡ Apply splitting**
Splits one metric line into **multiple lines, one per dimension value**. Example: split `Azure OpenAI Requests` by `ModelDeploymentName` to see a separate line for each deployment on the same chart — instantly shows which model drives the most traffic.

**📌 Pin to dashboard / Share**
Any configured chart can be pinned to an **Azure Dashboard** for a persistent operations view, or shared as a direct URL link with other team members.

---

### 3.3 Full Metric Reference

| Metric | Namespace | Unit | What to watch |
|---|---|---|---|
| `Azure OpenAI Requests` | HTTP Requests | Count | Total request volume; split by `ModelDeploymentName` |
| `Azure OpenAI AvailabilityRate` | HTTP Requests | % | Service availability; alert if < 99% |
| `Time to Response` | Latency | ms | TTFT (Time to First Token) — streaming responsiveness |
| `Normalized Time to First Byte` | Latency | ms/token | Token-normalised TTFT; catches degradation at high load |
| `Time Between Tokens` | Latency | ms | Inter-token gap during streaming — low = faster generation |
| `Time to Last Byte` | Latency | ms | Full round-trip latency; use P95/P99 aggregation |
| `TokensProcessed` | (via Diagnostic Logs) | Count | Total tokens/min — prompt + completion |
| `HTTPServerErrors` | (via Diagnostic Logs) | Count | 5xx errors — model overload or misconfiguration |
| `ContentFilteredRequests` | (via Diagnostic Logs) | Count | Requests blocked by content safety |
| `ProvisionedUtilization` | (PTU only) | % | PTU utilisation — alert below 30% (waste) or above 90% (throttle risk) |

> **Note:** `TokensProcessed`, `HTTPServerErrors`, and `ContentFilteredRequests` appear in **Diagnostic Logs** (`AzureOpenAIRequests` table in Log Analytics) rather than the Metrics Explorer. Use KQL queries (§4) to chart them.

---

### 3.4 Recommended Charts to Build

| Chart | Metrics | Aggregation | Split by |
|---|---|---|---|
| Request volume over time | `Azure OpenAI Requests` | Sum | `ModelDeploymentName` |
| Availability SLA | `Azure OpenAI AvailabilityRate` | Average | — |
| Latency (P95 proxy) | `Time to Last Byte` | Max | `ModelDeploymentName` |
| Streaming responsiveness | `Time to Response` | Average | `ApiName` |
| Generation speed | `Time Between Tokens` | Average | `ModelDeploymentName` |
| Multi-metric overlay | `Azure OpenAI Requests` + `Time to Last Byte` | Sum + Avg | — |

Set the time range to **Last 4 hours** with **1-minute** granularity for real-time monitoring, or **Last 30 days** with **1-day** granularity for trend analysis.

---

## 4. Log Analytics — KQL Queries

**Portal path:**
`Log Analytics Workspace → Logs`

### 4.1 Request Volume by Model (last 24 h)

```kql
AzureOpenAIRequests
| where TimeGenerated > ago(24h)
| summarize Requests = count() by DeploymentName, bin(TimeGenerated, 1h)
| render timechart
```

### 4.2 Average Latency per Deployment

```kql
AzureOpenAIRequests
| where TimeGenerated > ago(24h)
| summarize
    AvgLatencyMs   = avg(DurationMs),
    P95LatencyMs   = percentile(DurationMs, 95),
    P99LatencyMs   = percentile(DurationMs, 99)
  by DeploymentName
| order by P95LatencyMs desc
```

### 4.3 Token Usage & Estimated Cost

```kql
AzureOpenAIRequests
| where TimeGenerated > ago(7d)
| summarize
    TotalPromptTokens     = sum(PromptTokens),
    TotalCompletionTokens = sum(CompletionTokens),
    TotalTokens           = sum(TotalTokens)
  by DeploymentName, bin(TimeGenerated, 1d)
| render columnchart
```

### 4.4 Error Rate

```kql
AzureOpenAIRequests
| where TimeGenerated > ago(1h)
| summarize
    Total  = count(),
    Errors = countif(ResultCode >= 400)
  by DeploymentName
| extend ErrorRatePct = round(100.0 * Errors / Total, 2)
| order by ErrorRatePct desc
```

### 4.5 Content Filter Hits

```kql
AzureOpenAIRequests
| where TimeGenerated > ago(24h)
| where ContentFilterResults has "filtered"
| project TimeGenerated, DeploymentName, ContentFilterResults, PromptTokens
| order by TimeGenerated desc
```

### 4.6 Rate Limit (429) Spikes

```kql
AzureOpenAIRequests
| where ResultCode == 429
| summarize RateLimitHits = count() by bin(TimeGenerated, 5m), DeploymentName
| render timechart
```

---

## 5. Azure AI Foundry — Built-in Tracing

**Portal path:**
`Azure AI Foundry (ai.azure.com) → Your Project → Tracing`

Azure AI Foundry has native OpenTelemetry-based tracing that records every span in a generative AI call chain.

### 5.1 What Gets Traced Automatically

When you use the **Azure AI Inference SDK** or **Azure AI Projects SDK**, every call is automatically instrumented:

| Span type | Captured data |
|---|---|
| `gen_ai.chat` | Model, input messages, output, token counts, finish reason |
| `gen_ai.embeddings` | Input text, embedding dimensions, tokens |
| Tool calls | Function name, arguments, return value |
| Retrieval steps | Query, retrieved chunks, similarity scores |
| Agent turns | Agent name, step number, tool invocations |

### 5.2 Enable Tracing in Code

```python
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential

project = AIProjectClient(
    endpoint=os.getenv("AZURE_AI_FOUNDRY_ENDPOINT"),
    credential=DefaultAzureCredential(),
)

# Enable tracing — all subsequent SDK calls are traced
project.telemetry.enable()
```

Or with the OpenAI SDK pointed at Azure AI Foundry:

```python
from opentelemetry.sdk.trace import TracerProvider
from azure.monitor.opentelemetry.exporter import AzureMonitorTraceExporter
from opentelemetry.sdk.trace.export import BatchSpanProcessor

exporter = AzureMonitorTraceExporter(connection_string=os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING"))
provider = TracerProvider()
provider.add_span_processor(BatchSpanProcessor(exporter))
```

### 5.3 What the Traces Tab Shows

- **Waterfall view** — each span with start time, duration, parent/child hierarchy
- **Prompt & response text** — full input/output per LLM call
- **Token breakdown** — prompt tokens, completion tokens, per span
- **Model metadata** — deployment name, temperature, max_tokens
- **Error spans** — highlighted in red with exception details
- **Filter / search** — by trace ID, model, time range, status

### 5.4 Evaluations (AI Foundry)

**Portal path:** `AI Foundry → Your Project → Evaluation`

Run automated quality evaluations on logged traces:

| Evaluator | Measures |
|---|---|
| Groundedness | Is the answer supported by the retrieved context? |
| Relevance | Does the answer address the user's question? |
| Coherence | Is the response logically structured? |
| Fluency | Grammar and readability quality |
| Similarity | Cosine similarity vs. a reference answer |
| F1 Score | Token-level overlap with ground truth |
| Violence / Hate / Sexual | Content safety scoring |

Evaluations can run on a **dataset** (batch) or be triggered automatically on **sampled live traffic**.

---

## 6. Application Insights Integration

Application Insights gives you full **distributed tracing** across your entire app stack — not just the LLM calls.

### 6.1 Setup

```bash
pip install azure-monitor-opentelemetry
```

```python
from azure.monitor.opentelemetry import configure_azure_monitor

configure_azure_monitor(
    connection_string=os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING")
)
# All OpenTelemetry-instrumented libraries (LangChain, httpx, etc.) now export here
```

### 6.2 What Application Insights Shows

| Feature | Description |
|---|---|
| **Live Metrics** | Real-time request rate, failure rate, latency |
| **End-to-end transaction** | Full trace from HTTP request → LLM call → DB → response |
| **Dependency tracking** | Azure OpenAI calls appear as `dependencies` with duration |
| **Exceptions** | Stack traces with context |
| **Custom events** | `track_event("UserQuery", {"model": "gpt-4o-mini"})` |
| **Custom metrics** | `track_metric("token_count", total_tokens)` |

### 6.3 Kusto Queries in Application Insights

**Average LLM dependency latency:**

```kql
dependencies
| where name startswith "POST" and target contains "openai.azure.com"
| summarize AvgDurationMs = avg(duration), P95 = percentile(duration, 95)
  by bin(timestamp, 1h)
| render timechart
```

**LLM call failure rate:**

```kql
dependencies
| where target contains "openai.azure.com"
| summarize
    Total   = count(),
    Failed  = countif(success == false)
  by bin(timestamp, 15m)
| extend FailurePct = 100.0 * Failed / Total
| render timechart
```

---

## 7. Content Safety Monitoring

**Portal path:**
`Azure AI Services → Content Safety → Monitoring`

| Signal | Where to find it |
|---|---|
| Filtered request count | `AzureOpenAIRequests` log field `ContentFilterResults` |
| Filter category breakdown | Metric `ContentFilteredRequests` split by `ContentFilterCategory` |
| Custom blocklist hits | `ContentFilterResults` field in diagnostic logs |
| Jailbreak detection | `ContentFilterResults.jailbreak` field |

---

## 8. Alerts

**Portal path:**
`Azure OpenAI resource → Monitoring → Alerts → + Create`

### Recommended Alert Rules

| Alert | Signal | Threshold | Severity |
|---|---|---|---|
| High error rate | `HTTPServerErrors` metric | > 5 in 5 min | 1 (Critical) |
| Rate limit sustained | `AzureOpenAIRequests` with 429 | > 50 in 5 min | 2 (Warning) |
| Latency spike | `LatencyE2E` P95 | > 10 000 ms | 2 (Warning) |
| Token quota near limit | `TokensProcessed` | > 80% of TPM quota | 3 (Informational) |
| PTU underutilisation | `ProvisionedUtilization` | < 30% for 1 h | 4 (Verbose) |
| Content filter spike | `ContentFilteredRequests` | > 10 in 15 min | 2 (Warning) |

Alert actions: email, webhook, Azure Logic App, PagerDuty via Action Groups.

---

## 9. Workbooks & Dashboards

**Pre-built workbook:**
`Azure OpenAI resource → Monitoring → Workbooks → Azure OpenAI Insights`

Includes out-of-the-box views for:
- Token consumption over time
- Request success/failure rates
- Latency percentiles
- Prompt/completion ratio
- Top callers by IP

**Custom dashboard:**
Pin any Metrics Explorer chart or Workbook section to an **Azure Dashboard** for a unified operations view across multiple OpenAI deployments.

---

## 10. Cost Monitoring

**Portal path:**
`Azure Cost Management → Cost Analysis`

- Filter by **Resource**: your Azure OpenAI resource
- Group by **Meter**: `Tokens` — shows prompt vs completion token spend separately
- Set **Budgets** with email alerts at 80% / 100% of monthly budget

**Token-to-cost mapping** (as of training data cutoff; verify current pricing):

| Model | Prompt (per 1M tokens) | Completion (per 1M tokens) |
|---|---|---|
| gpt-4o | ~$2.50 | ~$10.00 |
| gpt-4o-mini | ~$0.15 | ~$0.60 |
| text-embedding-3-small | ~$0.02 | — |

---

## 11. Pricing for Azure Monitoring Features

> Prices are USD, East US region, as of mid-2025. Verify current rates at [azure.microsoft.com/pricing](https://azure.microsoft.com/pricing) before budgeting. All monitoring costs are **in addition to** Azure OpenAI token charges.

### 11.1 Log Analytics Workspace (Diagnostic Logs destination)

The main cost driver for diagnostic logs and Application Insights telemetry.

| Component | Pay-as-you-go | Commitment tiers |
|---|---|---|
| **Data ingestion** | $2.76 / GB | 100 GB/day → $196/day (~$1.96/GB) |
| | | 200 GB/day → $376/day (~$1.88/GB) |
| | | 500 GB/day → $900/day (~$1.80/GB) |
| **Data retention** | First **31 days free** | $0.12 / GB / month after day 31 |
| **Archive tier** | — | $0.023 / GB / month (query-on-demand) |
| **Basic logs** | $0.50 / GB ingested | Queries: $0.007 / GB scanned |
| **Queries** | Free for data in interactive tier | — |

**Typical LLM workload estimate:**
`AzureOpenAIRequests` log rows are ~2–5 KB each. At 100 000 requests/day that is ~200–500 MB/day → roughly **$0.55–$1.40/day** at PAYG rates.

> **Tip:** Use **Basic logs** tier for `AzureOpenAIRequests` if you only need retention/archival and run ad-hoc queries rarely. It cuts ingestion cost by ~82%.

### 11.2 Azure Monitor Metrics

| Component | Price |
|---|---|
| **Platform metrics** (TokensProcessed, LatencyE2E, etc.) | **Free** |
| **Custom metrics** (first 10 time series) | **Free** |
| **Custom metrics** (beyond 10 series) | $0.10 / metric series / month |
| **Metrics queries via API** | Free up to 100M queries/month, then $0.01 / 1 000 queries |

All Azure OpenAI built-in metrics (`TokensProcessed`, `LatencyE2E`, `HTTPServerErrors`, etc.) are **platform metrics — no charge**.

### 11.3 Application Insights

Application Insights is billed through the Log Analytics workspace it is linked to. The workspace rates in §11.1 apply.

| Component | Price |
|---|---|
| **Data ingestion** | Same as Log Analytics ($2.76/GB PAYG) |
| **Free daily allowance** | **5 GB/day** per Application Insights resource |
| **Live Metrics stream** | **Free** |
| **Availability (ping) tests** | **Free** (up to 1 million pings/month) |
| **Multi-step web tests** | $0.10 / test execution |
| **Smart detection** | **Free** |

The 5 GB/day free allowance is generous for most development workloads — only high-volume production apps typically exceed it.

### 11.4 Azure Alerts

| Alert type | Price |
|---|---|
| **Activity log alerts** | **Free** |
| **Metric alerts** (static threshold) | $0.10 / alert rule / month |
| **Metric alerts** (dynamic threshold) | $1.50 / alert rule / month |
| **Log search alerts** | $1.50 / alert rule / month |
| **Smart detection alerts** (App Insights) | **Free** |
| **Action Groups — notifications** | First 1 000 emails/month free, then $1.50 / 1 000 |
| **Action Groups — webhooks** | First 100 000 calls/month free, then $1.50 / 100 000 |

A typical setup of 6 alert rules (§8) costs roughly **$6–$9/month**.

### 11.5 AI Foundry Tracing

| Component | Price |
|---|---|
| **AI Foundry project** | **Free** to create |
| **Trace storage** | Backed by Application Insights → Log Analytics rates (§11.1, §11.3) |
| **Trace ingestion** | ~1–3 KB per span; a 3-agent LangGraph run ≈ 10–20 spans ≈ 30–60 KB |

### 11.6 AI Foundry Evaluations

Evaluations use an LLM as judge — you pay token charges for the evaluator model calls, not a separate evaluation fee.

| Component | Price |
|---|---|
| **Evaluation service** | **Free** |
| **Evaluator LLM token usage** | Standard Azure OpenAI token rates (see §10) |
| **Approximate cost per evaluation row** | ~0.5–2K tokens → $0.001–$0.003 using gpt-4o-mini |

For a 1 000-row evaluation dataset with 5 evaluators, expect **$5–$15** in token costs using gpt-4o-mini.

### 11.7 Azure Workbooks & Dashboards

| Component | Price |
|---|---|
| **Workbooks** | **Free** |
| **Azure Dashboards** | **Free** |
| **Queries run by workbooks** | Charged at Log Analytics query rates (included in workspace) |

### 11.8 Diagnostic Log Destinations (alternatives to Log Analytics)

| Destination | Cost |
|---|---|
| **Log Analytics Workspace** | $2.76/GB ingested (§11.1) |
| **Storage Account (Hot, LRS)** | $0.018/GB/month storage + $0.005/10 000 write ops |
| **Storage Account (Cool, LRS)** | $0.01/GB/month storage (higher retrieval cost) |
| **Event Hub (Standard)** | $0.028 / million events + $9.41 / throughput unit / month |
| **Event Hub (Basic)** | $0.015 / million events + $9.41 / TU / month |

Storage Account is the cheapest option for pure archival. Event Hub is used when forwarding to Splunk, Datadog, or a SIEM.

### 11.9 Azure Content Safety (standalone)

Built-in content filtering in Azure OpenAI is **free** — it runs automatically on every request.
The standalone **Azure AI Content Safety** service (for custom classifiers, image moderation, etc.) has separate pricing:

| Tier | Price |
|---|---|
| Free (F0) | 5 000 text records / month |
| Standard (S0) | $1.00 / 1 000 text records |

### 11.10 Azure Cost Management

**Free.** No charge for the Cost Management + Billing portal, budgets, or cost alerts.

### 11.11 Monitoring Cost Summary — Typical Dev/Training Workload

Assumes ~50 000 LLM requests/day, 1 App Insights resource, 6 alert rules, no PTU:

| Component | Estimated monthly cost |
|---|---|
| Log Analytics ingestion (100 MB/day × 30) | ~$8 |
| Log Analytics retention (beyond 31 days) | $0 (within free window) |
| Azure Monitor platform metrics | $0 |
| Application Insights (within 5 GB/day free) | $0 |
| Alert rules (6 × $1.50 avg) | ~$9 |
| AI Foundry tracing (via App Insights) | $0 (within free allowance) |
| Workbooks / Dashboards | $0 |
| **Total monitoring overhead** | **~$17 / month** |

For a high-volume production workload (millions of requests/day), Log Analytics ingestion becomes the dominant cost — use commitment tiers and Basic logs tier to reduce it.

---

## 12. Azure vs Third-Party Observability — Decision Guide

| Capability | Azure Native | LangSmith | Langfuse | Opik |
|---|---|---|---|---|
| Prompt / response logging | ✅ Diagnostic logs (opt-in) | ✅ Automatic | ✅ Callback | ✅ Decorator |
| Token usage | ✅ Metrics + logs | ✅ | ✅ | ✅ |
| Latency (P95/P99) | ✅ Metrics + KQL | ✅ | ✅ | ✅ |
| Multi-agent span tracing | ✅ AI Foundry Traces | ✅ | ✅ | Partial |
| LangGraph node tracing | ✅ via OTEL | ✅ Native | ✅ Callback | ✗ |
| LLM evaluation / scoring | ✅ AI Foundry Evaluations | ✅ | ✅ | ✅ |
| Content safety logging | ✅ Native | ✗ | ✗ | ✗ |
| Alerting | ✅ Azure Alerts | ✗ | ✗ | ✗ |
| Cost breakdown | ✅ Cost Management | Partial | ✗ | ✗ |
| Self-hostable | ✗ | ✗ | ✅ | ✗ |
| Works without LangChain | ✅ | Limited | ✅ | ✅ |
| Data residency control | ✅ (stays in Azure) | ✗ | ✅ (self-host) | ✗ |

**Recommended combination for Azure-hosted workloads:**
- **Azure Diagnostic Logs + Metrics** — operational health, cost, compliance
- **AI Foundry Tracing** — prompt/response debugging, evaluation
- **LangSmith or Langfuse** — developer-focused trace exploration during development

---

## 13. Quick Reference — Portal Paths

| Task | Azure Portal Path |
|---|---|
| Enable prompt logging | Azure OpenAI → Settings → Network |
| Enable diagnostic logs | Azure OpenAI → Monitoring → Diagnostic settings |
| View raw log data | Log Analytics Workspace → Logs → `AzureOpenAIRequests` |
| View token/latency metrics | Azure OpenAI → Monitoring → Metrics |
| View traces & prompts | ai.azure.com → Project → Tracing |
| Run evaluations | ai.azure.com → Project → Evaluation |
| Set alerts | Azure OpenAI → Monitoring → Alerts |
| View cost by token | Azure Cost Management → Cost Analysis |
| Pre-built dashboards | Azure OpenAI → Monitoring → Workbooks |
