# Hospital ↔ Insurance Payer A2A Demo

A minimal demo of the **Agent-to-Agent (A2A)** pattern applied to a healthcare
claims scenario:

- A **Hospital agent** (LangGraph, backed by Azure OpenAI) reviews a claim
  and decides what to submit.
- An **Insurance Payer agent** runs as a completely separate process (a
  Flask service, simulating "the payer's system" on another port/organization).
  Adjudication itself is done by a **CrewAI agent** that uses tools to look
  up policy/coverage facts and compute the payout, rather than a hard-coded
  rules engine.
- The two only ever talk to each other over HTTP using an A2A-style message
  envelope (agent card + task/message/parts) — neither one imports the
  other's code.

## Architecture

```
┌──────────────────────────────────────────┐   ┌─────────────────────────────────────────┐
│             Hospital System               │   │          Payer System (Insurer)          │
├──────────────────────────────────────────┤   ├─────────────────────────────────────────┤
│ Streamlit UI (streamlit_app.py)           │   │ Flask app (payer_agent/app.py)           │
│   │                                       │   │ Runs on http://localhost:5001            │
│   ▼                                       │   │ GET /.well-known/agent.json              │
│ LangGraph flow (hospital_agent/graph.py)  │   │ POST /tasks/send                         │
│  1. validate_claim                        │   │                                          │
│  2. llm_pre_review (Azure OpenAI LLM)     │   │ CrewAI crew (payer_agent/crew.py)        │
│  3. call_payer_agent  --- A2A --->        │   │  - Researcher agent (Azure OpenAI LLM)   │
│  4. llm_synthesize (Azure OpenAI LLM)     │   │    calls: Lookup Policy,                 │
└──────────────────────────────────────────┘   │    Lookup Procedure Coverage             │
                                                │  - Adjudicator agent (Azure OpenAI LLM)  │
                                                │    calls: Adjudicate Claim ->            │
                                                │    APPROVED / PARTIALLY_APPROVED /       │
                                                │    PENDING_REVIEW / DENIED               │
                                                └─────────────────────────────────────────┘
```

Both sides call the *same* Azure OpenAI deployment in this demo (see
`.env.example`), representing two organizations that would normally each
have their own LLM deployment. On the payer side, only the deterministic
`Adjudicate Claim` tool computes the actual dollar amounts and eligibility
outcome (see "A real reliability finding" below for why) - the LLM's job is
choosing which tool to call, not writing the numbers itself.

### Why this illustrates A2A

- **Separate processes, separate ports:** the payer agent runs standalone on
  `:5001`; the hospital's Streamlit app runs on `:8501`. Neither needs the
  other's source code, only its URL.
- **Agent discovery:** the hospital fetches `/.well-known/agent.json` from
  the payer to learn what it is and what it can do before calling it.
- **Structured task/message envelope:** every request/response is a
  `{id, message: {role, parts: [{type: "data", data: {...}}]}}` object —
  the same shape (task, message, parts) used by the real A2A protocol,
  simplified to run over plain Flask/JSON instead of the full `a2a-sdk` so
  the wire format stays easy to read.
- **Independent evolution:** the payer's adjudication rules
  (`payer_agent/claims_data.py`) can change or the service can be redeployed
  without touching the hospital's LangGraph flow at all.

### Synchronous vs. asynchronous A2A

This demo uses **synchronous** A2A: `call_payer_agent` sends a `POST
/tasks/send` and blocks until the payer responds in the same HTTP
request/response cycle. Since the payer's adjudication is itself a 3-task
CrewAI crew (3 sequential LLM calls), a single claim can easily take
10-60+ seconds depending on the model - this is not the "instant in-memory
rules engine" case anymore, so `hospital_agent/a2a_client.py`'s HTTP timeout
(`PAYER_AGENT_TIMEOUT` in `.env`, default 120s) needs real headroom, not the
usual few-seconds default. Real payer systems can take even longer
(manual review, prior-auth workflows can take minutes/hours), and a blocking
HTTP call doesn't hold up well for that at all.

For a real, long-running claim adjudication you'd want an **asynchronous**
task model instead:

- **Native A2A async support:** the official A2A protocol (via `a2a-sdk`)
  already supports this — tasks can move through `submitted` →
  `working` → `completed` states, with streaming (SSE) or push-notification
  webhooks so the hospital agent isn't stuck holding a connection open. If
  you swap this demo's simplified Flask envelope for the real `a2a-sdk`
  client/server, you get that async task lifecycle for free.
- **Message bus alternative:** if you'd rather decouple the two systems with
  a broker instead of protocol-level async, put a queue (e.g. Kafka,
  RabbitMQ, Azure Service Bus) between them — the hospital publishes a
  "claim submitted" event and the payer publishes a "claim adjudicated"
  event back, with the hospital's LangGraph flow resumed via a webhook or
  a polling/subscriber node instead of a blocking HTTP call.

### The hospital's LangGraph flow

| Step | Node | What it does |
|---|---|---|
| 1 | `validate_claim` | Checks required fields are present before spending an LLM call or a network hop. |
| 2 | `llm_pre_review` | Azure OpenAI reviews the claim for completeness/plausibility and flags issues (e.g. "prior auth may be needed"). |
| 3 | `call_payer_agent` | **The A2A hop.** Sends the claim as an A2A task to the payer agent and receives its adjudication decision. |
| 4 | `llm_synthesize` | Azure OpenAI turns the payer's raw decision into a plain-English summary for billing staff. |

### The payer's CrewAI agent

`payer_agent/crew.py` defines a two-agent CrewAI `Crew` running three chained
tasks:

| Task | Agent | Tool called |
|---|---|---|
| `policy_task` | `Eligibility & Coverage Researcher` | `Lookup Policy` (policy status/plan/deductible, from `claims_data.py`) |
| `coverage_task` | `Eligibility & Coverage Researcher` | `Lookup Procedure Coverage` (covered?, coverage %, prior-auth requirement, max allowed amount) |
| `adjudication_task` | `Insurance Claims Adjudicator` | `Adjudicate Claim` (given the two check results as context, deterministically returns DENIED / PENDING_REVIEW / APPROVED / PARTIALLY_APPROVED plus the dollar amounts) |

Each task's output is constrained to a Pydantic model
(`output_pydantic=PolicyCheckResult` / `CoverageCheckResult` / `ClaimDecision`)
so `/tasks/send` always gets back a predictable JSON shape.

**A real reliability finding from building this demo:** every tool here is
declared with `result_as_answer=True`. Without it, this deployment happily
*calls* each tool with correct arguments, but when asked to write its "final
answer" afterwards it doesn't reliably transcribe the tool's result — it
free-associates a plausible-looking but wrong plan name or dollar amount
instead of copying the real one. `result_as_answer=True` makes the tool's
return value *become* the task output directly, skipping that unreliable
step entirely. This is why the last tool, `Adjudicate Claim`, is a single
call that takes every relevant field as an argument and internally covers
all four outcome branches (ineligible, not covered, needs prior auth,
approved/partial) — so no matter which branch applies, the agent's only job
is to make one correct tool call, and the result is trustworthy by
construction rather than by hoping the model narrates it faithfully.

If you swap in a different/larger model that transcribes tool output
reliably, you can drop `result_as_answer` and let the agents narrate more
freely (e.g. going back to a single `Calculate Payout` tool plus free-text
reasoning for the denial/pending branches).

## Project Structure

```
agent_a2a_azure/
├── payer_agent/
│   ├── app.py            # Flask A2A server: agent card + /tasks/send adjudication endpoint
│   ├── crew.py           # CrewAI claims-adjudicator agent, tools, and ClaimDecision schema
│   └── claims_data.py    # Mock policy + procedure coverage data (used by the crew's tools)
├── hospital_agent/
│   ├── state.py          # LangGraph state (TypedDict)
│   ├── a2a_client.py     # Minimal A2A client (agent card fetch + send_task)
│   └── graph.py          # The 4-node LangGraph flow described above
├── streamlit_app.py       # Hospital claims desk UI
├── requirements.txt
├── .env.example
└── README.md
```

## Requirements

- Python 3.10+
- An Azure OpenAI resource with a chat-completion deployment (e.g. `gpt-4o`),
  used by both the hospital's LangGraph flow and the payer's CrewAI agent

## Setup

1. **Create a virtual environment and install dependencies:**

   ```bash
   cd agent_a2a_azure
   python -m venv venv
   venv\Scripts\activate        # Windows
   # source venv/bin/activate   # macOS/Linux
   pip install -r requirements.txt
   ```

2. **Configure Azure OpenAI credentials:**

   ```bash
   copy .env.example .env       # Windows
   # cp .env.example .env       # macOS/Linux
   ```

   Then edit `.env` with your Azure OpenAI endpoint, API key, API version and
   deployment name. `PAYER_AGENT_URL` can be left as the default
   `http://localhost:5001`.

## Running the Demo

You need **two terminals** — one for each independent "system".

### Terminal 1: Payer Agent (Insurance system)

```bash
cd agent_a2a_azure/payer_agent
python app.py
```

Keep this running. You should see Flask serving on `http://127.0.0.1:5001`.
You can sanity-check it directly:

```bash
curl http://localhost:5001/.well-known/agent.json
```

### Terminal 2: Hospital UI

```bash
cd agent_a2a_azure
streamlit run streamlit_app.py
```

Open the URL Streamlit prints (typically `http://localhost:8501`).

### Try it out

The form comes pre-populated with sample patients/procedures backed by the
payer's mock data (`payer_agent/claims_data.py`). A few scenarios to try:

| Patient / Policy | Procedure | Expected outcome |
|---|---|---|
| POL-1001 (Asha Verma, active) | 45378 - Colonoscopy | `APPROVED` with coinsurance split |
| POL-1002 (Ravi Kumar, active) | 27447 - Knee replacement, no prior auth | `PENDING_REVIEW` (prior auth required) |
| POL-1003 (Meera Nair, lapsed) | any | `DENIED` (policy lapsed) |
| any active policy | 97110 - Therapeutic exercise | `DENIED` (not covered) |

Each submission shows: the raw claim payload sent over A2A, the hospital's
LLM pre-review, the payer's decision (with the sidebar confirming the A2A
connection and an expander showing the raw payer response), and a final
LLM-written summary for billing staff.

## Extending the Demo

- Swap `payer_agent/claims_data.py` for a real database/API call — the
  hospital side needs no changes since it only depends on the payer's A2A
  contract.
- Add more payer skills (e.g. `check_eligibility`, `request_prior_auth`) as
  additional `/tasks/send` skill types, and add corresponding nodes/edges to
  the hospital's LangGraph flow.
- Swap the simplified A2A envelope for the official `a2a-sdk` client/server
  classes if you need full protocol compliance (streaming, push
  notifications, multi-turn tasks).
