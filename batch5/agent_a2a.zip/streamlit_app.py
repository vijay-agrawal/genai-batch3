"""Hospital Claims Desk - Streamlit UI.

The hospital user fills in claim details and submits them. On submit, the
in-process LangGraph flow (hospital_agent.graph) runs:

    validate -> LLM pre-review -> A2A call to the payer agent -> LLM synthesis

The payer agent (payer_agent/app.py) must be running separately (its own
Flask process/port) since it represents a different organization's system.
"""
import os

import requests
import streamlit as st
from dotenv import load_dotenv

from hospital_agent.graph import PAYER_AGENT_URL, run_claim_flow

load_dotenv()

st.set_page_config(page_title="Hospital Claims Desk", page_icon="🏥", layout="centered")

SAMPLE_POLICIES = {
    "POL-1001 - Asha Verma (Gold PPO)": "POL-1001",
    "POL-1002 - Ravi Kumar (Silver HMO)": "POL-1002",
    "POL-1003 - Meera Nair (Bronze PPO, lapsed)": "POL-1003",
}
SAMPLE_PROCEDURES = {
    "45378 - Colonoscopy, diagnostic": "45378",
    "99213 - Office visit, established patient": "99213",
    "27447 - Total knee arthroplasty (prior auth required)": "27447",
    "97110 - Therapeutic exercise (not covered)": "97110",
}

st.title("🏥 Hospital Claims Desk")
st.caption("Submit a claim to the insurance payer agent over A2A.")

with st.sidebar:
    st.subheader("Payer Agent Connection")
    st.code(PAYER_AGENT_URL, language="text")
    try:
        card = requests.get(f"{PAYER_AGENT_URL}/.well-known/agent.json", timeout=2).json()
        st.success(f"Connected: {card['name']} v{card['version']}")
    except Exception:
        st.error("Payer agent unreachable. Start payer_agent/app.py first.")

with st.form("claim_form"):
    st.subheader("Claim Details")
    col1, col2 = st.columns(2)
    with col1:
        policy_label = st.selectbox("Patient / Policy", list(SAMPLE_POLICIES.keys()))
        patient_name = st.text_input("Patient Name", value=policy_label.split(" - ")[1].split(" (")[0])
        claim_date = st.date_input("Claim Date")
    with col2:
        procedure_label = st.selectbox("Procedure", list(SAMPLE_PROCEDURES.keys()))
        billed_amount = st.number_input("Billed Amount ($)", min_value=0.0, value=1200.0, step=50.0)
        prior_auth_number = st.text_input("Prior Authorization # (if obtained)", value="")

    notes = st.text_area("Clinical Notes (optional)", placeholder="e.g. Patient presented with...")
    submitted = st.form_submit_button("Submit Claim to Payer", type="primary")

if submitted:
    claim = {
        "patient_name": patient_name,
        "policy_number": SAMPLE_POLICIES[policy_label],
        "procedure_code": SAMPLE_PROCEDURES[procedure_label],
        "billed_amount": billed_amount,
        "claim_date": str(claim_date),
        "prior_auth_number": prior_auth_number or None,
        "notes": notes,
    }

    with st.expander("Claim payload sent over A2A", expanded=False):
        st.json(claim)

    try:
        with st.spinner("Running hospital agent flow (LLM review -> A2A -> payer)..."):
            result = run_claim_flow(claim)
    except requests.exceptions.ConnectionError:
        st.error("Could not reach the payer agent. Is payer_agent/app.py running on "
                  f"{PAYER_AGENT_URL}?")
        st.stop()
    except requests.exceptions.Timeout:
        st.error(
            "The payer agent didn't respond in time (its CrewAI crew runs several LLM "
            "calls per claim, which can be slow). Check the payer_agent terminal - if it "
            "logged a 200 response after this timed out, just resubmit, or raise "
            "PAYER_AGENT_TIMEOUT in .env."
        )
        st.stop()

    if result.get("validation_error"):
        st.error(f"Claim rejected before submission: {result['validation_error']}")
        st.stop()

    st.subheader("1. Hospital Pre-Review (LLM)")
    st.write(result.get("pre_review_summary", ""))
    flags = result.get("pre_review_flags") or []
    if flags:
        for flag in flags:
            st.warning(flag)

    st.subheader("2. Payer Decision (via A2A)")
    decision = result.get("payer_decision", {})
    status = decision.get("status", "UNKNOWN")
    status_display = {
        "APPROVED": st.success,
        "PARTIALLY_APPROVED": st.warning,
        "PENDING_REVIEW": st.warning,
        "DENIED": st.error,
    }.get(status, st.info)
    status_display(f"**{status}** - {decision.get('reason', '')}")

    if status in ("APPROVED", "PARTIALLY_APPROVED"):
        c1, c2, c3 = st.columns(3)
        c1.metric("Allowed Amount", f"${decision.get('allowed_amount', 0):,.2f}")
        c2.metric("Insurer Pays", f"${decision.get('insurer_pays', 0):,.2f}")
        c3.metric("Patient Owes", f"${decision.get('patient_pays', 0):,.2f}")

    with st.expander("Raw payer response"):
        st.json(decision)

    st.subheader("3. Summary for Billing Staff (LLM synthesis)")
    st.info(result.get("final_summary", ""))
