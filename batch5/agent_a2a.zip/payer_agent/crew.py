"""CrewAI-powered claims adjudicator used by the payer agent.

Rather than a hard-coded if/else rules engine gluing everything together in
Python, the payer's adjudication decision is produced by a small CrewAI crew:
agents look up policy/procedure facts and call an adjudication tool, deciding
*which* checks apply and *why*, while every fact and dollar amount comes
straight out of a tool call via `result_as_answer=True` (see note below)
rather than being retyped by the model.

Why `result_as_answer=True` on every tool: in testing, this deployment calls
tools with the correct arguments, but its own free-text "final answer" step
does not reliably transcribe the tool's result - it re-derives plausible but
wrong numbers instead of copying the real ones. `result_as_answer=True` makes
a tool's return value become the task's output directly, skipping that
unreliable paraphrasing step. If you swap in a different/larger model, you
can drop `result_as_answer` and let the agent narrate more freely.
"""
import os
from typing import Optional

from crewai import Agent, Crew, LLM, Process, Task
from crewai.tools import tool
from dotenv import load_dotenv
from pydantic import BaseModel, Field

from claims_data import get_policy, get_procedure_rule

load_dotenv()

# CrewAI/litellm read Azure config from these AZURE_* env vars.
os.environ.setdefault("AZURE_API_KEY", os.getenv("AZURE_OPENAI_API_KEY", ""))
os.environ.setdefault("AZURE_API_BASE", os.getenv("AZURE_OPENAI_ENDPOINT", "").rstrip("/"))
os.environ.setdefault("AZURE_API_VERSION", os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"))


def _get_llm() -> LLM:
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
    return LLM(
        model=f"azure/{deployment}",
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        base_url=os.getenv("AZURE_OPENAI_ENDPOINT", "").rstrip("/"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
        temperature=0,
    )


class PolicyCheckResult(BaseModel):
    found: bool
    status: Optional[str] = None
    plan: Optional[str] = None
    annual_deductible: float = 0.0
    deductible_met: float = 0.0
    error: Optional[str] = None


class CoverageCheckResult(BaseModel):
    found: bool
    covered: bool = False
    coverage_pct: float = 0.0
    requires_prior_auth: bool = False
    max_allowed_amount: float = 0.0
    description: Optional[str] = None
    error: Optional[str] = None


class ClaimDecision(BaseModel):
    status: str = Field(description="One of APPROVED, PARTIALLY_APPROVED, PENDING_REVIEW, DENIED")
    reason: str = Field(description="Plain-English explanation of the decision")
    plan: Optional[str] = Field(default=None, description="The member's plan name, if a policy was found")
    procedure_description: Optional[str] = Field(default=None)
    allowed_amount: float = 0.0
    insurer_pays: float = 0.0
    patient_pays: float = 0.0


@tool("Lookup Policy", result_as_answer=True)
def lookup_policy(policy_number: str) -> dict:
    """Look up a member's insurance policy by policy number. Returns plan name,
    eligibility status (ACTIVE/LAPSED), annual deductible and how much of it has
    been met, or an error message if the policy number is unknown."""
    policy = get_policy(policy_number)
    return policy or {"error": f"No policy found for '{policy_number}'"}


@tool("Lookup Procedure Coverage", result_as_answer=True)
def lookup_procedure_coverage(procedure_code: str) -> dict:
    """Look up whether a CPT procedure code is covered by the plan. Returns
    whether it's covered, the coverage percentage, whether prior authorization
    is required, and the max allowed amount, or an error message if unknown."""
    rule = get_procedure_rule(procedure_code)
    return rule or {"error": f"No coverage rule found for procedure '{procedure_code}'"}


@tool("Adjudicate Claim", result_as_answer=True)
def adjudicate_claim(policy_found: bool, policy_status: str, plan: str, annual_deductible: float,
                      deductible_met: float, procedure_found: bool, covered: bool, coverage_pct: float,
                      requires_prior_auth: bool, max_allowed_amount: float, procedure_description: str,
                      billed_amount: float, has_prior_auth_number: bool) -> dict:
    """Given the policy check and procedure coverage check results (pass their
    fields straight through) plus the claim's billed_amount and whether a
    prior_auth_number was provided, determine the final claim decision:
    DENIED if the policy was not found or is not ACTIVE; DENIED if the
    procedure was not found or is not covered; PENDING_REVIEW if the
    procedure requires prior authorization and none was provided; otherwise
    computes the allowed amount, insurer's payment and patient's
    out-of-pocket amount (APPROVED, or PARTIALLY_APPROVED if the billed
    amount exceeds the plan's max allowed amount for that procedure)."""
    if not policy_found or policy_status != "ACTIVE":
        return {
            "status": "DENIED",
            "reason": f"Policy is {'unknown' if not policy_found else policy_status}, patient is not eligible.",
            "plan": plan if policy_found else None,
            "procedure_description": None,
            "allowed_amount": 0.0, "insurer_pays": 0.0, "patient_pays": 0.0,
        }

    if not procedure_found or not covered:
        return {
            "status": "DENIED",
            "reason": "Procedure is not covered under this plan.",
            "plan": plan,
            "procedure_description": procedure_description if procedure_found else None,
            "allowed_amount": 0.0, "insurer_pays": 0.0, "patient_pays": 0.0,
        }

    if requires_prior_auth and not has_prior_auth_number:
        return {
            "status": "PENDING_REVIEW",
            "reason": f"Procedure ({procedure_description}) requires prior authorization, which was not provided.",
            "plan": plan,
            "procedure_description": procedure_description,
            "allowed_amount": 0.0, "insurer_pays": 0.0, "patient_pays": 0.0,
        }

    allowed_amount = min(billed_amount, max_allowed_amount)
    remaining_deductible = max(annual_deductible - deductible_met, 0.0)
    amount_after_deductible = max(allowed_amount - remaining_deductible, 0.0)
    insurer_pays = round(amount_after_deductible * coverage_pct, 2)
    patient_pays = round(allowed_amount - insurer_pays, 2)
    status = "APPROVED" if billed_amount <= max_allowed_amount else "PARTIALLY_APPROVED"
    reason = f"Covered at {int(coverage_pct * 100)}% under {plan} after ${remaining_deductible:.2f} remaining deductible."
    if status == "PARTIALLY_APPROVED":
        reason += f" Billed amount exceeds plan max allowed amount of ${max_allowed_amount:.2f}."

    return {
        "status": status,
        "reason": reason,
        "plan": plan,
        "procedure_description": procedure_description,
        "allowed_amount": allowed_amount,
        "insurer_pays": insurer_pays,
        "patient_pays": patient_pays,
    }


def _build_crew(claim: dict) -> Crew:
    llm = _get_llm()

    researcher = Agent(
        role="Eligibility & Coverage Researcher",
        goal="Look up a member's policy status and a procedure's coverage rules using the lookup tools.",
        backstory="A payer-side researcher who checks policy and coverage facts via the lookup tools.",
        tools=[lookup_policy, lookup_procedure_coverage],
        llm=llm,
        function_calling_llm=llm,
        verbose=True,
        allow_delegation=False,
    )

    adjudicator = Agent(
        role="Insurance Claims Adjudicator",
        goal="Call the Adjudicate Claim tool with the right facts to get the final claim decision.",
        backstory="A claims adjudicator who always defers the actual decision/math to the Adjudicate Claim tool.",
        tools=[adjudicate_claim],
        llm=llm,
        function_calling_llm=llm,
        verbose=True,
        allow_delegation=False,
    )

    policy_task = Task(
        description=(
            f"Call the Lookup Policy tool with policy_number='{claim.get('policy_number')}' exactly once."
        ),
        expected_output="Whatever the Lookup Policy tool returns.",
        agent=researcher,
        output_pydantic=PolicyCheckResult,
    )

    coverage_task = Task(
        description=(
            f"Call the Lookup Procedure Coverage tool with procedure_code='{claim.get('procedure_code')}' "
            "exactly once."
        ),
        expected_output="Whatever the Lookup Procedure Coverage tool returns.",
        agent=researcher,
        output_pydantic=CoverageCheckResult,
    )

    adjudication_task = Task(
        description=(
            "Call the Adjudicate Claim tool exactly once, passing through the policy check result "
            "and coverage check result from context, plus "
            f"billed_amount={claim.get('billed_amount')} and "
            f"has_prior_auth_number={bool(claim.get('prior_auth_number'))}."
        ),
        expected_output="Whatever the Adjudicate Claim tool returns.",
        agent=adjudicator,
        context=[policy_task, coverage_task],
        output_pydantic=ClaimDecision,
    )

    return Crew(
        agents=[researcher, adjudicator],
        tasks=[policy_task, coverage_task, adjudication_task],
        process=Process.sequential,
        verbose=True,
    )


def adjudicate_claim_with_crew(claim: dict) -> dict:
    crew = _build_crew(claim)
    result = crew.kickoff()
    decision: ClaimDecision = result.pydantic
    return decision.model_dump()
