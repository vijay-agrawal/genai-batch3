"""Mock payer-side data: member policies and procedure coverage rules.

In a real payer system this would be a claims/eligibility database. Here it's
an in-memory dict so the demo has no external dependencies.
"""

# policy_number -> member + plan info
POLICIES = {
    "POL-1001": {
        "patient_name": "Asha Verma",
        "plan": "Gold PPO",
        "status": "ACTIVE",
        "annual_deductible": 1000.0,
        "deductible_met": 600.0,
    },
    "POL-1002": {
        "patient_name": "Ravi Kumar",
        "plan": "Silver HMO",
        "status": "ACTIVE",
        "annual_deductible": 2500.0,
        "deductible_met": 0.0,
    },
    "POL-1003": {
        "patient_name": "Meera Nair",
        "plan": "Bronze PPO",
        "status": "LAPSED",
        "annual_deductible": 5000.0,
        "deductible_met": 0.0,
    },
}

# procedure_code (CPT) -> coverage rule
PROCEDURE_COVERAGE = {
    "45378": {  # Colonoscopy
        "description": "Colonoscopy, diagnostic",
        "covered": True,
        "coverage_pct": 0.80,
        "requires_prior_auth": False,
        "max_allowed_amount": 2500.0,
    },
    "99213": {  # Office visit
        "description": "Office visit, established patient",
        "covered": True,
        "coverage_pct": 0.90,
        "requires_prior_auth": False,
        "max_allowed_amount": 200.0,
    },
    "27447": {  # Knee replacement
        "description": "Total knee arthroplasty",
        "covered": True,
        "coverage_pct": 0.70,
        "requires_prior_auth": True,
        "max_allowed_amount": 30000.0,
    },
    "97110": {  # Physical therapy
        "description": "Therapeutic exercise",
        "covered": False,
        "coverage_pct": 0.0,
        "requires_prior_auth": False,
        "max_allowed_amount": 0.0,
    },
}


def get_policy(policy_number: str):
    return POLICIES.get(policy_number)


def get_procedure_rule(procedure_code: str):
    return PROCEDURE_COVERAGE.get(procedure_code)
