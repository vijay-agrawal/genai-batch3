"""Insurance Payer Agent.

Runs as an independent Flask service (its own process/port) that exposes a
simplified Agent-to-Agent (A2A) style interface:

  GET  /.well-known/agent.json  -> Agent Card (who am I, what can I do)
  POST /tasks/send               -> Submit a task (the claim) and get back
                                     a synchronous A2A-style task result.

The message/task envelope mirrors the shape used by the real A2A protocol
(task id, message with role + parts, structured "data" parts) but is kept as
plain JSON over Flask instead of pulling in the full a2a-sdk, so the wire
format is easy to read for teaching purposes.

The actual claim adjudication is delegated to a CrewAI agent (see crew.py)
rather than a hard-coded rules engine.
"""
import uuid
from datetime import datetime, timezone

from flask import Flask, jsonify, request

from crew import adjudicate_claim_with_crew

app = Flask(__name__)

AGENT_CARD = {
    "name": "InsurancePayerAgent",
    "description": "Adjudicates health insurance claims submitted by hospital/provider agents, using a CrewAI claims-adjudicator agent.",
    "url": "http://localhost:5001",
    "version": "1.0.0",
    "capabilities": {"streaming": False, "pushNotifications": False},
    "skills": [
        {
            "id": "adjudicate_claim",
            "name": "Adjudicate Claim",
            "description": "Checks policy eligibility and procedure coverage, then approves/denies/pends a claim.",
        }
    ],
}


@app.get("/.well-known/agent.json")
def agent_card():
    return jsonify(AGENT_CARD)


@app.get("/health")
def health():
    return jsonify({"status": "ok", "agent": AGENT_CARD["name"]})


@app.post("/tasks/send")
def tasks_send():
    """A2A-style synchronous task endpoint.

    Expected request body:
    {
      "id": "<task-id>",
      "message": {
        "role": "user",
        "parts": [{"type": "data", "data": {<claim fields>}}]
      }
    }
    """
    body = request.get_json(force=True)
    task_id = body.get("id") or str(uuid.uuid4())
    message = body.get("message", {})
    parts = message.get("parts", [])
    claim = next((p["data"] for p in parts if p.get("type") == "data"), {})

    try:
        decision = adjudicate_claim_with_crew(claim)
    except Exception as exc:
        decision = {
            "status": "ERROR",
            "reason": f"Claims adjudicator agent failed: {exc}",
            "plan": None,
            "procedure_description": None,
            "allowed_amount": 0.0,
            "insurer_pays": 0.0,
            "patient_pays": 0.0,
        }
    decision["adjudicated_at"] = datetime.now(timezone.utc).isoformat()

    return jsonify({
        "id": task_id,
        "status": "completed",
        "message": {
            "role": "agent",
            "parts": [{"type": "data", "data": decision}],
        },
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=True)
