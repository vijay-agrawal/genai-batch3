from typing import List, Optional, TypedDict


class ClaimState(TypedDict, total=False):
    claim: dict                 # raw claim details entered in the Streamlit form
    validation_error: Optional[str]
    pre_review_summary: str
    pre_review_flags: List[str]
    payer_decision: dict         # decision returned by the payer A2A agent
    final_summary: str
