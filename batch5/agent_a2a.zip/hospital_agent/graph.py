"""Hospital-side agentic flow, built with LangGraph.

Nodes:
  1. validate_claim   - sanity-checks the form data before doing any LLM/network work.
  2. llm_pre_review    - Azure OpenAI reviews the claim for completeness/plausibility.
  3. call_payer_agent  - talks to the remote InsurancePayerAgent over A2A (HTTP).
  4. llm_synthesize     - Azure OpenAI turns the payer's raw decision into a clear
                          summary for hospital billing staff.

The A2A hop (step 3) is the only place this process talks to the payer system;
everything else runs locally inside the hospital agent.
"""
import os
from typing import List

from dotenv import load_dotenv
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI
from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field

from .a2a_client import A2AClient
from .state import ClaimState

load_dotenv()

PAYER_AGENT_URL = os.getenv("PAYER_AGENT_URL", "http://localhost:5001")
# The payer's CrewAI crew runs 3 sequential LLM calls per claim (policy check,
# coverage check, adjudication), which can comfortably take well over the
# default HTTP client timeout - so this needs to be generous, not 10s.
PAYER_AGENT_TIMEOUT = int(os.getenv("PAYER_AGENT_TIMEOUT", "120"))
REQUIRED_FIELDS = ["patient_name", "policy_number", "procedure_code", "billed_amount"]


def _get_llm():
    return AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        temperature=0,
    )


class ClaimPreReview(BaseModel):
    summary: str = Field(description="One or two sentence summary of the claim for a billing clerk.")
    flags: List[str] = Field(default_factory=list, description="Any missing info or potential issues noticed.")


def validate_claim(state: ClaimState) -> ClaimState:
    claim = state["claim"]
    missing = [f for f in REQUIRED_FIELDS if not claim.get(f)]
    if missing:
        return {"validation_error": f"Missing required field(s): {', '.join(missing)}"}
    return {"validation_error": None}


def route_after_validation(state: ClaimState) -> str:
    return "llm_pre_review" if not state.get("validation_error") else END


def llm_pre_review(state: ClaimState) -> ClaimState:
    claim = state["claim"]
    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are a hospital billing assistant. Review the claim details below for "
         "completeness and plausibility before it is submitted to the insurance payer. "
         "Note any missing info (like prior authorization for major procedures) as flags."),
        ("human", "{claim}"),
    ])
    llm = _get_llm().with_structured_output(ClaimPreReview)
    result: ClaimPreReview = (prompt | llm).invoke({"claim": claim})
    return {"pre_review_summary": result.summary, "pre_review_flags": result.flags}


def call_payer_agent(state: ClaimState) -> ClaimState:
    claim = state["claim"]
    client = A2AClient(PAYER_AGENT_URL, timeout=PAYER_AGENT_TIMEOUT)
    task_response = client.send_task(claim)
    decision = client.extract_data(task_response)
    return {"payer_decision": decision}


def llm_synthesize(state: ClaimState) -> ClaimState:
    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are a hospital billing assistant. The insurance payer has returned an "
         "adjudication decision for this claim. Write a short, clear summary (3-4 "
         "sentences) for hospital staff explaining the outcome, what the patient owes, "
         "and any next steps (e.g. obtaining prior authorization) if the claim was "
         "denied or pended."),
        ("human",
         "Claim: {claim}\n\nPre-review notes: {pre_review}\n\nPayer decision: {decision}"),
    ])
    llm = _get_llm()
    message = (prompt | llm).invoke({
        "claim": state["claim"],
        "pre_review": {"summary": state.get("pre_review_summary"), "flags": state.get("pre_review_flags")},
        "decision": state["payer_decision"],
    })
    return {"final_summary": message.content}


def build_graph():
    graph = StateGraph(ClaimState)
    graph.add_node("validate_claim", validate_claim)
    graph.add_node("llm_pre_review", llm_pre_review)
    graph.add_node("call_payer_agent", call_payer_agent)
    graph.add_node("llm_synthesize", llm_synthesize)

    graph.add_edge(START, "validate_claim")
    graph.add_conditional_edges("validate_claim", route_after_validation, {
        "llm_pre_review": "llm_pre_review",
        END: END,
    })
    graph.add_edge("llm_pre_review", "call_payer_agent")
    graph.add_edge("call_payer_agent", "llm_synthesize")
    graph.add_edge("llm_synthesize", END)

    return graph.compile()


def run_claim_flow(claim: dict) -> ClaimState:
    app = build_graph()
    return app.invoke({"claim": claim})
