"""Minimal A2A-style client used by the hospital agent to talk to a remote
payer agent over HTTP, without depending on the full a2a-sdk package.

It follows the same envelope shape the payer's Flask endpoints expect:
fetch the agent card, then POST a task whose message carries the claim as a
structured "data" part, and read the decision back out of the response.
"""
import uuid

import requests


class A2AClient:
    def __init__(self, base_url: str, timeout: int = 120):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def get_agent_card(self) -> dict:
        resp = requests.get(f"{self.base_url}/.well-known/agent.json", timeout=self.timeout)
        resp.raise_for_status()
        return resp.json()

    def send_task(self, data: dict) -> dict:
        """Send a claim as an A2A task and return the raw task response."""
        task = {
            "id": str(uuid.uuid4()),
            "message": {
                "role": "user",
                "parts": [{"type": "data", "data": data}],
            },
        }
        resp = requests.post(f"{self.base_url}/tasks/send", json=task, timeout=self.timeout)
        resp.raise_for_status()
        return resp.json()

    @staticmethod
    def extract_data(task_response: dict) -> dict:
        parts = task_response.get("message", {}).get("parts", [])
        return next((p["data"] for p in parts if p.get("type") == "data"), {})
