# Quick Reference Guide

## Common Commands

### Setup
```bash
# Install all dependencies
pip install -r requirements.txt

# Download spaCy models
python -m spacy download en_core_web_sm
python -m spacy download en_core_sci_sm
```

### Running Scripts
```bash
cd notebooks

# Part 1: Basic NER
python 01_basic_ner.py

# Part 2: Dictionary NER
python 02_dictionary_ner.py

# Part 3: Entity Linking
python 03_entity_linking.py

# Part 4: Cypher Generation
python 04_cypher_generation.py
```

## Key Concepts Cheat Sheet

### Named Entity Recognition (NER)
```python
import spacy

# Load model
nlp = spacy.load("en_core_sci_sm")

# Process text
doc = nlp("Patient has diabetes and hypertension")

# Extract entities
for ent in doc.ents:
    print(f"{ent.text} -> {ent.label_}")
```

### Dictionary Matching
```python
from spacy.matcher import PhraseMatcher

# Create matcher
matcher = PhraseMatcher(nlp.vocab, attr="LOWER")

# Add patterns
patterns = [nlp.make_doc("diabetes"), nlp.make_doc("hypertension")]
matcher.add("DISEASE", patterns)

# Find matches
matches = matcher(doc)
```

### Fuzzy Matching
```python
from rapidfuzz import fuzz, process

# Find best match
result = process.extractOne(
    "diabtes",  # Query (with typo)
    ["diabetes", "hypertension", "asthma"],  # Choices
    scorer=fuzz.ratio,
    score_cutoff=80  # Minimum similarity
)
print(result)  # ('diabetes', 87.5, 0)
```

### Semantic Matching
```python
from sentence_transformers import SentenceTransformer
import numpy as np

# Load model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Encode texts
emb1 = model.encode(["high blood pressure"])
emb2 = model.encode(["hypertension"])

# Compute similarity
similarity = np.dot(emb1, emb2.T)
print(f"Similarity: {similarity[0][0]:.3f}")
```

### Negation Detection
```python
def is_negated(entity_span, doc):
    """Check if entity is negated"""
    negation_words = {'no', 'not', 'without', 'denies'}
    
    # Check 5 tokens before entity
    window_start = max(0, entity_span.start - 5)
    
    for i in range(window_start, entity_span.start):
        if doc[i].text.lower() in negation_words:
            return True
    
    return False

# Usage
doc = nlp("Patient denies diabetes")
for ent in doc.ents:
    negated = is_negated(ent, doc)
    print(f"{ent.text}: negated={negated}")
```

## Cypher Query Examples

### Create Node
```cypher
CREATE (p:Patient {
  patient_id: 'P001',
  name: 'John Smith',
  age: 58
})
```

### Create Relationship
```cypher
MATCH (p:Patient {patient_id: 'P001'})
MATCH (d:Disease {disease_id: 'E11'})
CREATE (p)-[:HAS_DIAGNOSIS {
  date: date('2024-01-15'),
  confidence: 0.95
}]->(d)
```

### Query Patients by Disease
```cypher
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d:Disease)
WHERE d.canonical_name = 'Type 2 Diabetes Mellitus'
RETURN p.name, p.age
```

### Find Co-occurring Diseases
```cypher
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d1:Disease)
MATCH (p)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d2:Disease)
WHERE d1.disease_id < d2.disease_id
RETURN d1.canonical_name, d2.canonical_name, count(p) as patients
ORDER BY patients DESC
```

### Find Prescribed Medications
```cypher
MATCH (p:Patient {patient_id: 'P001'})-[r:PRESCRIBED]->(m:Medication)
RETURN m.generic_name, r.dosage, r.frequency
```

## Common Issues & Solutions

### Issue: "No module named 'spacy'"
```bash
pip install spacy
```

### Issue: "Can't find model en_core_sci_sm"
```bash
pip install https://s3-us-west-2.amazonaws.com/ai2-s2-scispacy/releases/v0.5.4/en_core_sci_sm-0.5.4.tar.gz
```

### Issue: "Out of memory" with semantic matching
Reduce batch size or use smaller model:
```python
model = SentenceTransformer('paraphrase-MiniLM-L3-v2')
```

### Issue: Cypher script fails in Neo4j
- Check for quotes in text (escape with \')
- Ensure nodes exist before creating relationships
- Run constraints before data creation

## Useful Links

- spaCy Documentation: https://spacy.io/usage
- Neo4j Cypher Guide: https://neo4j.com/docs/cypher-manual/current/
- RapidFuzz Docs: https://github.com/maxbachmann/RapidFuzz
- Sentence Transformers: https://www.sbert.net/

## Tips & Best Practices

### NER
- Always use domain-specific models for specialized text
- Combine multiple approaches (NER + dictionary + rules)
- Validate results on sample before large-scale processing

### Entity Linking
- Start with exact matching (fastest, most accurate)
- Use fuzzy matching for typos and variations
- Reserve semantic matching for when others fail
- Always set confidence thresholds

### Negation
- Critical in clinical text!
- Use negspacy for production systems
- Consider scope: how far does negation extend?

### Knowledge Graphs
- Design schema before generating data
- Use MERGE for nodes that might already exist
- Add constraints to prevent duplicates
- Include metadata (confidence, dates, sources)

### Performance
- Process in batches for large datasets
- Cache embeddings to avoid recomputation
- Use database indexes for faster queries
- Consider async processing for I/O operations

## Medical Terminology Codes

### ICD-10 (Diagnosis Codes)
- I10: Hypertension
- E11: Type 2 Diabetes Mellitus
- J44.9: COPD
- G43.909: Migraine
- E03.9: Hypothyroidism

### RxNorm (Medication Codes)
- 1191: Aspirin
- 6918: Metoprolol
- 6809: Metformin
- 10180: Sumatriptan
- 8787: Propranolol

### SNOMED CT (Clinical Terms)
- 38341003: Hypertension
- 44054006: Type 2 Diabetes Mellitus
- 13645005: COPD
- 37796009: Migraine
- 40930008: Hypothyroidism

## Keyboard Shortcuts (Neo4j Browser)

- `Ctrl + Enter`: Execute query
- `Ctrl + /`: Toggle comment
- `Ctrl + Space`: Auto-complete
- `Esc`: Clear console

## Color Coding in Output

Throughout the scripts, you'll see emoji indicators:
- 🦠 Disease/Diagnosis
- 💊 Medication
- 📝 Abbreviation
- ✓ Success/Confirmed
- ❌ Negated
- ⚠️  Warning/Low Confidence
