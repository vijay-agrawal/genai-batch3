# Instructor Guide: Clinical Notes to Knowledge Graph Workshop

## Overview
This workshop teaches participants how to extract structured information from clinical notes using NLP and create medical knowledge graphs. The workshop is hands-on, with participants coding along and completing exercises.

**Duration:** 3-4 hours
**Level:** Intermediate
**Prerequisites:** Basic Python, basic NLP concepts (helpful but not required)

## Learning Outcomes
By the end of this workshop, participants will be able to:
1. Apply Named Entity Recognition (NER) to clinical text
2. Understand why domain-specific models matter
3. Implement dictionary-based entity extraction
4. Link entities using exact, fuzzy, and semantic matching
5. Detect negation in clinical text
6. Generate Cypher scripts for Neo4j knowledge graphs

## Workshop Schedule

### Part 0: Setup & Introduction (20 minutes)

#### Setup (10 min)
- Ensure all participants have Python 3.8+ installed
- Walk through `pip install -r requirements.txt`
- Download spaCy models together
- Verify installations

**Instructor Actions:**
- Share screen showing setup commands
- Troubleshoot common issues (proxy, permissions, etc.)
- Have backup: pre-installed environment or cloud notebooks

#### Introduction (10 min)
**Slides to Cover:**
1. What is a knowledge graph? (Show example visualization)
2. Why medical knowledge graphs?
   - Clinical decision support
   - Drug interaction detection
   - Population health analytics
   - Research data linking
3. Workshop objectives
4. Project structure overview

**Instructor Notes:**
- Show a real medical knowledge graph if possible
- Emphasize real-world applications
- Set expectations: this is simplified but demonstrates core concepts

---

### Part 1: Basic NER & Domain Models (45 minutes)

#### Lecture (15 min)
**Key Concepts:**
- What is Named Entity Recognition?
- NER model training: general vs. domain-specific
- Why general models fail on medical text
- Introduction to spaCy and SciSpacy

**Demo:**
- Live code: Load spaCy model
- Run NER on a simple sentence
- Show entity visualization with `displacy`

**Instructor Code:**
```python
import spacy
from spacy import displacy

nlp = spacy.load("en_core_web_sm")
text = "Patient has diabetes and takes metformin 1000mg daily."
doc = nlp(text)

# Show entities
for ent in doc.ents:
    print(f"{ent.text} -> {ent.label_}")

# Visualize
displacy.render(doc, style="ent")
```

#### Hands-On Activity (20 min)
- Participants run `01_basic_ner.py`
- Walk through the output together
- Discuss observations as a group

**Discussion Questions:**
1. What entities did the general model find?
2. What did it miss?
3. Compare general vs. medical model results
4. Why does this difference exist?

**Expected Insights:**
- General model finds dates, numbers, but misses diseases
- Medical model recognizes medical terminology
- Training data determines model capabilities

#### Exercise (10 min)
**Task:** Analyze Patient P002 (migraine patient)
- Participants manually list medical entities
- Compare with model output
- Discuss false positives and false negatives

**Instructor Actions:**
- Walk around and help participants
- Call on volunteers to share findings
- Validate their observations

---

### Part 2: Dictionary-Based Extraction (45 minutes)

#### Lecture (10 min)
**Key Concepts:**
- Medical terminologies (ICD-10, SNOMED, RxNorm)
- Why dictionaries provide high precision
- PhraseMatcher in spaCy
- Combining NER + dictionary approaches

**Live Demo:**
```python
from spacy.matcher import PhraseMatcher

# Show how PhraseMatcher works
matcher = PhraseMatcher(nlp.vocab, attr="LOWER")
terms = ["diabetes", "hypertension", "metformin"]
patterns = [nlp.make_doc(term) for term in terms]
matcher.add("MEDICAL", patterns)

doc = nlp("Patient has diabetes and hypertension.")
matches = matcher(doc)

for match_id, start, end in matches:
    span = doc[start:end]
    print(f"Found: {span.text}")
```

#### Hands-On Activity (20 min)
- Run `02_dictionary_ner.py`
- Examine dictionary structure in JSON
- Observe matcher performance

**Discussion:**
1. How many more entities did dictionary catch?
2. What about abbreviations (HTN, BID)?
3. What are the limitations?

#### Exercise (15 min)
**Task:** Add a new medical term
1. Open `medical_terminologies.json`
2. Add a new disease (e.g., Asthma)
3. Add it to a clinical note
4. Re-run and verify it's caught

**Instructor Actions:**
- Show the JSON structure on screen
- Help with JSON syntax
- Discuss: What if there's a typo?

**Segue to Part 3:** "Dictionary matching is great, but what about typos? That's where fuzzy matching comes in!"

---

### Part 3: Entity Linking Strategies (60 minutes)

#### Lecture (15 min)
**Key Concepts:**
- What is entity linking?
- Three matching strategies:
  1. Exact matching (fastest, most confident)
  2. Fuzzy matching (handles typos)
  3. Semantic matching (understands meaning)
- Negation detection (critical!)
- Waterfall approach

**Live Demos:**

**Fuzzy Matching:**
```python
from rapidfuzz import fuzz, process

# Show Levenshtein distance
print(fuzz.ratio("diabetes", "diabtes"))  # ~87
print(fuzz.ratio("diabetes", "diabetic"))  # ~70

# Find best match
choices = ["diabetes", "hypertension", "asthma"]
result = process.extractOne("diabtes", choices, score_cutoff=80)
print(result)  # ('diabetes', 87.5, 0)
```

**Semantic Matching:**
```python
from sentence_transformers import SentenceTransformer
import numpy as np

model = SentenceTransformer('all-MiniLM-L6-v2')

# Show semantic similarity
emb1 = model.encode(["hypertension"])
emb2 = model.encode(["high blood pressure"])
similarity = np.dot(emb1, emb2.T)
print(f"Similarity: {similarity[0][0]:.3f}")  # High!

emb3 = model.encode(["diabetes"])
similarity2 = np.dot(emb1, emb3.T)
print(f"Similarity: {similarity2[0][0]:.3f}")  # Low!
```

#### Hands-On Activity (25 min)
- Run `03_entity_linking.py`
- Examine test cases
- See waterfall approach in action

**Discussion:**
1. When does each strategy activate?
2. Why use a waterfall approach?
3. How does confidence scoring help?

#### Deep Dive: Negation (10 min)
**Critical Concept:** "No diabetes" ≠ "Diabetes"

**Live Demo:**
```python
text1 = "Patient has diabetes."
text2 = "Patient denies diabetes."

# Show how negation changes meaning
# Discuss scope: "No diabetes or hypertension" - both negated?
```

#### Exercise (10 min)
**Task:** Test custom entities
- Participants add their own test cases
- Try typos, synonyms, negations
- Share interesting results

**Examples to Try:**
```python
test_cases = [
    "diabetic",           # Variation
    "high blood sugar",   # Synonym
    "no chest pain",      # Negation
    "patient denies SOB", # Abbreviation + negation
]
```

---

### Part 4: Cypher Generation (45 minutes)

#### Lecture (15 min)
**Key Concepts:**
- What is a knowledge graph?
- Graph databases vs. relational databases
- Neo4j and Cypher query language
- Schema design for medical graphs

**Show Schema:**
```
(Patient)-[:HAS_DIAGNOSIS]->(Diagnosis)-[:IS_DISEASE]->(Disease)
(Patient)-[:PRESCRIBED]->(Medication)
```

**Cypher Basics:**
```cypher
// Create node
CREATE (p:Patient {name: 'John', age: 58})

// Create relationship
MATCH (p:Patient {name: 'John'})
MATCH (d:Disease {name: 'Diabetes'})
CREATE (p)-[:HAS_DIAGNOSIS]->(d)

// Query
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->(d:Disease)
RETURN p.name, d.name
```

#### Hands-On Activity (20 min)
- Run `04_cypher_generation.py`
- Examine generated script
- Understand node and relationship creation

**Walk Through Code:**
- Show `CypherScriptBuilder` class
- Explain MERGE vs. CREATE
- Discuss property handling

#### Demo: Load into Neo4j (10 min)
**Option 1: Neo4j Desktop**
- Show opening Neo4j Browser
- Paste and execute script
- Visualize resulting graph

**Option 2: Neo4j Aura**
- Show cloud database
- Execute script
- Run sample queries

**Sample Queries to Show:**
```cypher
// All patients
MATCH (p:Patient) RETURN p

// Patients with diabetes
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d:Disease)
WHERE d.canonical_name = 'Type 2 Diabetes Mellitus'
RETURN p.name, p.age

// Co-occurring diseases
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d1:Disease)
MATCH (p)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d2:Disease)
WHERE d1.disease_id < d2.disease_id
RETURN d1.canonical_name, d2.canonical_name, count(p) as patients
ORDER BY patients DESC
```

**Instructor Notes:**
- Have Neo4j pre-installed and ready
- If demo fails, have screenshots as backup
- Emphasize visualization power

---

### Wrap-Up & Q&A (20 minutes)

#### Review Key Takeaways (10 min)
1. NER: Domain models matter
2. Dictionary matching: High precision for known terms
3. Entity linking: Exact → Fuzzy → Semantic
4. Negation: Critical in clinical text
5. Knowledge graphs: Represent complex relationships

#### Real-World Considerations (5 min)
- **Scalability:** Processing millions of notes
- **Accuracy:** Confidence thresholds, HITL review
- **Compliance:** HIPAA, data privacy
- **Integration:** EHR systems, APIs
- **Maintenance:** Updating terminologies, retraining models

#### Next Steps (5 min)
**Advanced Challenges:**
- Add more entity types (symptoms, procedures, labs)
- Implement temporal relationships
- Build a web interface for human review
- Deploy as a production pipeline

**Resources:**
- UMLS for comprehensive medical terminologies
- ClinicalBERT for better medical NER
- MIMIC-III dataset for more clinical notes

#### Q&A
- Open floor for questions
- Collect feedback
- Share contact info for follow-up

---

## Common Questions & Answers

**Q: Which NER model should I use in production?**
A: Depends on use case. SciSpacy is good for research papers. For clinical notes, consider medSpaCy or fine-tune ClinicalBERT on your data.

**Q: How do I handle PHI (Protected Health Information)?**
A: Use de-identification tools first (e.g., Philter, Microsoft Presidio). Never upload real patient data to public clouds without de-identification.

**Q: What if my terminology is not in standard dictionaries?**
A: Build custom dictionaries for your institution. Start with standard terminologies, then add local codes and abbreviations.

**Q: How do I evaluate NER performance?**
A: Human annotation of gold standard, then compute precision, recall, F1. For entity linking, also track accuracy of linked codes.

**Q: Can this scale to millions of notes?**
A: Yes, but requires distributed processing (Spark, Dask), caching, and optimization. Consider batch processing overnight.

---

## Troubleshooting Tips

### Setup Issues
- **Model download fails:** Use direct pip install URLs from spaCy docs
- **Memory errors:** Use smaller models, process in batches
- **Import errors:** Check virtual environment activation

### During Workshop
- **Participants stuck:** Pair them with someone ahead
- **Code doesn't run:** Have backup Colab notebooks
- **Time running short:** Skip exercises, focus on concepts

### Neo4j Issues
- **Can't connect:** Check if service is running
- **Query fails:** Ensure constraints run before data creation
- **Slow queries:** Add indexes on frequently queried properties

---

## Additional Resources for Instructors

### Slide Deck Outline
1. Title slide
2. What is NLP in healthcare?
3. Use cases for medical knowledge graphs
4. Workshop objectives
5. NER basics
6. Why domain models matter (comparison table)
7. Medical terminologies landscape
8. Entity linking strategies (diagram)
9. Negation detection examples
10. Knowledge graph schema
11. Cypher basics
12. Sample queries and results
13. Real-world considerations
14. Next steps and resources
15. Q&A

### Demo Videos to Prepare
- NER in action with displacy
- PhraseMatcher demonstration
- Fuzzy matching with typos
- Semantic similarity visualization
- Neo4j graph visualization
- Running sample queries

### Backup Plans
- Have Colab notebooks ready if local setup fails
- Pre-recorded demos if live demo fails
- Static visualizations if Neo4j unavailable
- Printed handouts with code snippets

---

## Feedback Collection

### Mid-Workshop Check-in (After Part 2)
Quick poll:
1. Pace: Too fast / Just right / Too slow
2. Clarity: Clear / Somewhat clear / Confused
3. Hands-on balance: Too much coding / Good / Too much lecture

### End-of-Workshop Survey
1. What was most valuable?
2. What was least clear?
3. What would you like to see added?
4. Would you recommend this workshop?
5. Suggestions for improvement

---

## Post-Workshop Follow-Up

### Provide to Participants
- All code and data
- Recorded demos (if recorded)
- Additional resources list
- Certificate of completion (if applicable)
- Contact info for questions

### Instructor Reflection
- What went well?
- What could be improved?
- Which concepts needed more time?
- Which exercises were most effective?
- Update materials based on feedback

---

Good luck with the workshop! 🎓🏥
