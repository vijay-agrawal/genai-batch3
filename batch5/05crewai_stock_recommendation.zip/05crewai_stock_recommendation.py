"""
Stock Recommendation Agent using CrewAI and Azure OpenAI.

Analyzes financial data for a specified company/stock, evaluates performance
and market trends, and provides investment recommendations via three specialized agents.
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, LLM
from crewai_tools import ScrapeWebsiteTool, SerperDevTool


def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env or google-vertexai-serviceaccount-key.json in any parent directory.")
    print(f"Started searching from: {Path(__file__).resolve().parent}")
    exit(1)


PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")


def validate_environment_variables():
    """Validate that all required environment variables are loaded from .env file."""
    required_env_vars = [
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_MODEL_NAME",
        "SERPER_API_KEY",
    ]
    missing_vars = [var for var in required_env_vars if not os.getenv(var)]
    if missing_vars:
        print("ERROR: Missing required environment variables:")
        for var in missing_vars:
            print(f"  - {var}")
        print("\nPlease ensure all required variables are set in your .env file.")
        exit(1)
    print("✓ All required environment variables are loaded successfully.")


def build_azure_llm() -> LLM:
    """Build a CrewAI LLM instance backed by the Azure AI Foundry OpenAI-compatible endpoint.

    The Azure AI Foundry endpoint (services.ai.azure.com) is OpenAI-compatible.
    LiteLLM's 'openai' provider is used with a custom api_base instead of the
    'azure' provider, which expects a standard *.openai.azure.com endpoint.
    """
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    # Azure AI Foundry endpoints require the /openai/v1/ suffix for OpenAI compatibility
    endpoint += "/openai/v1/"

    model_name = os.getenv("AZURE_OPENAI_MODEL_NAME")
    os.environ["SERPER_API_KEY"] = os.getenv("SERPER_API_KEY", "")

    return LLM(
        model=f"openai/{model_name}",
        api_base=endpoint,
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        temperature=0,
    )


class StockRecommenderAgents:
    def __init__(self, llm: LLM):
        self.llm = llm

    def finance_news_agent(self, entityname: str) -> Agent:
        return Agent(
            role="Senior Financial Advisor",
            goal=(
                f"Analyze recent market trends, financial news, and economic events about {entityname} "
                "solely using online sources, providing recommendations regarding if buying a stock or "
                "investing in a specific company is a good idea or not."
            ),
            backstory=(
                f"You work at the National Stock Exchange in India and are working to provide the best "
                f"investment recommendations to your customers. You need to analyze all available data and "
                f"recommend profitable stocks and investments about {entityname} without making any assumptions. "
                f"Use reliable websites to generate relevant insights about {entityname} which will be useful "
                f"in determining if we should purchase the stock or not."
            ),
            tools=[ScrapeWebsiteTool(), SerperDevTool()],
            llm=self.llm,
        )

    def summarization_agent(self) -> Agent:
        return Agent(
            role="Summarization Writer",
            goal="Summarize the information gathered by the senior financial advisor into short, easy-to-understand points.",
            backstory="You work as a summary writer who reads a chunk of text and simplifies it into concise bullet points.",
            llm=self.llm,
        )

    def recommendation_agent(self, entityname: str) -> Agent:
        return Agent(
            role="Senior Stock Advisor",
            goal=(
                f"Understand the summary provided and gauge if {entityname} stocks are worth investing in, "
                "then recommend or advise against the investment for your clients."
            ),
            backstory=(
                "You are a senior stock recommender with deep knowledge of Indian stock markets. "
                "You can identify stocks that are good investments in the short and long run and give "
                "concise, actionable recommendations."
            ),
            llm=self.llm,
        )


class StockRecommenderTasks:
    def stock_market_analysis(self, agent: Agent, entityname: str) -> Task:
        return Task(
            description=(
                "Use online search tools to gather recent financial news and market data. "
                f"Focus on key economic indicators, performance of {entityname}, top-performing stocks, "
                "and relevant economic events. Summarize these findings to give an overview of current market conditions."
            ),
            agent=agent,
            expected_output=(
                f"A report summarizing recent financial insights including:\n"
                f"1. **{entityname}**: Is {entityname} a stock worth purchasing?\n"
                f"   - Summary of findings\n"
                f"   - Key financial metrics\n"
                f"   - Recent news highlights"
            ),
        )

    def summarizer(self, agent: Agent) -> Task:
        return Task(
            description=(
                "Use the information provided by the financial analysis task and summarize it into short, "
                "easy-to-understand bullet points from which investment recommendations can be easily derived."
            ),
            agent=agent,
            expected_output="A concise bullet-point summary of the financial analysis findings.",
        )

    def recommender(self, agent: Agent, entityname: str) -> Task:
        return Task(
            description=(
                f"Use the summarized information and determine whether {entityname} stocks are profitable to invest in. "
                "Give specific stock names and sectors that are recommended, with clear buy/hold/sell reasoning."
            ),
            agent=agent,
            expected_output=(
                f"A clear investment recommendation for {entityname} covering:\n"
                f"- Buy / Hold / Avoid verdict\n"
                f"- Short-term outlook\n"
                f"- Long-term outlook\n"
                f"- Key risks to watch"
            ),
        )


class StockRecommenderCrew:
    def __init__(self, entityname: str, llm: LLM):
        self.entityname = entityname
        self.llm = llm

    def run(self):
        agents = StockRecommenderAgents(self.llm)
        tasks = StockRecommenderTasks()

        finance_agent = agents.finance_news_agent(self.entityname)
        summarization_agent = agents.summarization_agent()
        recommendation_agent = agents.recommendation_agent(self.entityname)

        analysis_task = tasks.stock_market_analysis(finance_agent, self.entityname)
        summary_task = tasks.summarizer(summarization_agent)
        recommendation_task = tasks.recommender(recommendation_agent, self.entityname)

        crew = Crew(
            agents=[finance_agent, summarization_agent, recommendation_agent],
            tasks=[analysis_task, summary_task, recommendation_task],
            verbose=True,
            process="sequential",
        )

        return crew.kickoff()


if __name__ == "__main__":
    validate_environment_variables()

    print("## Welcome to the Stock Recommender Crew")
    print("------------------------------------------")
    entityname = input("Enter company or stock name (e.g. Tata Power): ").strip()
    if not entityname:
        print("ERROR: No entity name provided.")
        exit(1)

    llm = build_azure_llm()
    crew = StockRecommenderCrew(entityname, llm)
    result = crew.run()

    print("\n\n##########################################")
    print("##   Here is your Stock Recommendation   ##")
    print("##########################################\n")
    print(result.raw if hasattr(result, "raw") else result)
