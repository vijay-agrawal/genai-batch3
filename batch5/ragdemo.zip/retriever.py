import os
from langchain_openai import AzureChatOpenAI
from langchain_openai import AzureOpenAIEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
import warnings
warnings.filterwarnings("ignore")

from dotenv import load_dotenv

load_dotenv()

CHROMA_PATH = os.path.join(os.getcwd(), "chroma_db_new2")

def load_embeddings_chroma(persist_directory=CHROMA_PATH):
    from langchain_chroma import Chroma

    # Instantiate the same embedding model used during creation
    print('Instantiating the embedding model')

    embeddings = AzureOpenAIEmbeddings(
        model=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT")
    )

    print('Loading Chroma vector database, passing the embedding model to be used to it...')

    # Load the Chroma vector store from the specified directory, using the provided embedding function
    vector_store = Chroma(persist_directory=persist_directory, embedding_function=embeddings) 

    return vector_store  # Return the loaded vector store

def ask_and_get_answer(vector_store, q, k=3):
    """
    Modern approach using LCEL (LangChain Expression Language)
    This works without needing langchain.chains module
    """
    
    # Initialize Azure LLM
    llm = AzureChatOpenAI(
        temperature=0,
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
        model=os.getenv("AZURE_OPENAI_MODEL_NAME")
    )
    
    print('Fetching the retriever for the vector DB')
    retriever = vector_store.as_retriever(search_type='similarity', search_kwargs={'k': k})

    # Create a prompt template
    template = """You are an assistant for question-answering tasks. 
Use the following pieces of retrieved context to answer the question. 
If you don't know the answer, say that you don't know. 
Use three sentences maximum and keep the answer concise.

Context: {context}

Question: {question}

Answer:"""
    
    prompt = ChatPromptTemplate.from_template(template)

    print('Creating the RAG chain using LCEL')
    
    # Helper function to format documents
    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)
    
    # Create the RAG chain using LCEL (LangChain Expression Language)
    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    
    print('Executing the chain with the retriever and the LLM')
    
    # Invoke the chain
    answer = rag_chain.invoke(q)
    
    # Get source documents separately for display
    source_docs = retriever.invoke(q)
    
    # Return in same format as before
    return {
        'answer': answer,
        'context': source_docs,
        'input': q
    }

## MAIN PROCESSING ##

# Load the chroma vector store using the same embedding model as the one used during indexing
vector_store = load_embeddings_chroma()

# Question/Prompt to ask
q = 'What technical skills does Pankaj have?'

# Get the answer from the RAG system (vector store + LLM)
answer = ask_and_get_answer(vector_store, q)

# The response is now a dictionary with 'answer' and 'context' keys
print("\n--- Answer ---")
print(answer['answer'])

print("\n--- Source Documents ---")
for i, doc in enumerate(answer['context'], 1):
    print(f"\nDocument {i}:")
    print(doc.page_content[:200] + "...")  # Print first 200 chars 