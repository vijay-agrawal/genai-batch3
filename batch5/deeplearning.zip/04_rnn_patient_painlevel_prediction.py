# RNN Pain Level Prediction - Healthcare Analytics
# This notebook demonstrates using RNN to classify patient pain levels from clinical notes

# =============================================================================
# BUSINESS PROBLEM
# =============================================================================
#
# CONTEXT — PAIN MANAGEMENT IN HOSPITAL SETTINGS
#   Nurses document patient pain observations in free-text clinical notes
#   multiple times per day. A patient's pain level (1–10 on the Visual Analogue
#   Scale) determines:
#     • Whether to escalate medication dosage
#     • Whether to call the physician for reassessment
#     • Discharge readiness (patients with pain > 4 are typically not discharged)
#     • Staffing priority — high-pain patients require more frequent check-ins
#
#   Manual review of notes is time-consuming and subjective. Two nurses reading
#   the same note may assign different pain scores. An automated model that reads
#   the note alongside structured clinical data (days admitted, treatment type,
#   surgery status) and outputs a standardised pain score helps:
#     1. Flag patients whose documented pain score may be inconsistent with their note
#     2. Prioritise nursing rounds for the highest-pain patients
#     3. Build an audit trail for pain management compliance
#
# WHO USES THIS OUTPUT
#   • Charge nurses — real-time dashboard showing predicted vs documented pain
#   • Clinical informaticists — trend analysis across wards and shifts
#   • Hospital administrators — readmission risk and length-of-stay modelling
#
# =============================================================================
# SAMPLE DATA — WHAT EACH COLUMN MEANS
# =============================================================================
#
#   Patient_Notes  : Free-text written by nurses during their rounds.
#                    These are SHORT notes (1–2 sentences) capturing the
#                    patient's self-reported or observed pain state.
#
#                    Examples:
#                      "Excruciating pain cannot move"   → Pain_Level = 10
#                      "Moderate pain but manageable"    → Pain_Level = 5
#                      "No pain at all today"            → Pain_Level = 1
#                      "Dull aching pain persists"       → Pain_Level = 4
#                      "Sharp shooting pain constantly"  → Pain_Level = 8
#
#   Days_Admitted  : Integer — how many days the patient has been in hospital.
#                    Longer stays may correlate with chronic or post-surgical pain.
#                    Range in this dataset: 1–14 days.
#
#   Treatment_Type : Categorical — the primary treatment the patient is receiving.
#                    Values: 'Surgery', 'Brain Surgery', 'Physical Therapy',
#                            'Medication', 'Emergency'
#                    Post-surgical patients typically report higher short-term pain.
#
#   Surgery_Done   : Binary — whether surgery has been performed ('Yes' / 'No').
#                    Separate from Treatment_Type to capture cases where surgery
#                    was completed but the patient is now in a recovery programme.
#
#   Pain_Level     : Target variable. Integer 1–10 on the Visual Analogue Scale.
#                    1  = No pain (pain free, comfortable)
#                    4  = Mild–moderate (noticeable but tolerable)
#                    7  = Severe (disrupts daily function)
#                    10 = Worst imaginable pain (agony, immobile, screaming)
#
# SAMPLE ROWS (first 5):
#
#   Patient_Notes                    Days  Treatment         Surgery  Pain
#   "I feel a little better today"      7  Surgery           Yes         3
#   "The pain is unbearable"            4  Brain Surgery     Yes         9
#   "I am feeling much better now"      5  Physical Therapy  No          2
#   "Severe pain in my back today"      3  Surgery           Yes         8
#   "Pain has reduced significantly"    8  Medication        No          2
#
# DATA SIZE: 40 synthetic samples (real deployment would need thousands).
#            Small size is intentional — it exposes overfitting clearly,
#            motivating the discussion of embeddings, dropout, and more data.
#
# MODEL TASK (REGRESSION):
#   Given a nurse's note + structured clinical features, predict the
#   continuous pain score in [1.0, 10.0].
#   We treat this as REGRESSION (not classification) because pain is ordinal
#   — being off by 1 is much better than being off by 9 — and regression
#   loss functions (MSE/MAE) encode this proportionality naturally.
# =============================================================================


# RNN Pain Level Prediction - Regression Approach
# This code frames the pain level problem as REGRESSION instead of CLASSIFICATION.
#
# =============================================================================
# WHY REGRESSION IS BETTER THAN CLASSIFICATION FOR PAIN LEVELS
# =============================================================================
#
# CLASSIFICATION assumes the 10 pain levels are 10 independent, unordered
# categories — like predicting dog breed or fruit type. This is wrong for pain:
#
#   PROBLEM 1 — ORDINAL RELATIONSHIP IS IGNORED
#     Pain level 4 is "between" 3 and 5. CrossEntropyLoss penalises predicting
#     4 when the truth is 5 IDENTICALLY to predicting 1 when truth is 5.
#     A model that is consistently off by 1 looks as bad as one that is off by 9.
#     Regression with MSELoss/MAELoss encodes this: a prediction of 4.8 vs truth
#     5.0 incurs far less penalty than a prediction of 1.0 vs truth 5.0.
#
#   PROBLEM 2 — SPURIOUS CLASS BOUNDARIES
#     Is there a meaningful clinical difference between pain level 5 and 6?
#     Classification treats the boundary as a hard cliff; regression allows the
#     model to output 5.3, reflecting genuine clinical uncertainty.
#
#   PROBLEM 3 — WASTED GRADIENT SIGNAL
#     In classification, a near-miss (predict 6, truth 5) and a total miss
#     (predict 1, truth 5) produce similar loss. In regression, the gradient
#     for the near-miss is small and for the total miss is large — the model
#     naturally focuses effort on fixing its worst errors.
#
#   PROBLEM 4 — OUTPUT SPACE MISMATCH
#     Pain is measured on a continuous visual analogue scale (VAS) in clinical
#     practice. Forcing it into 10 discrete bins discards information. A patient
#     who reports "4.5" is rounded arbitrarily to 4 or 5.
#
# WHEN CLASSIFICATION IS STILL APPROPRIATE:
#   • When the classes truly have no natural order (diagnosis type, treatment type)
#   • When you need a hard categorical decision (surgery vs no surgery)
#   • When the downstream system requires a discrete bin (billing codes)
#
# =============================================================================
# HOW DOES THE OUTPUT LAYER WORK DIFFERENTLY IN REGRESSION vs CLASSIFICATION?
# =============================================================================
#
# CLASSIFICATION OUTPUT LAYER:
#   • N neurons, one per class (10 here)
#   • Raw outputs (logits) are passed through SOFTMAX to produce a probability
#     distribution: each value ∈ (0, 1) and all values sum to exactly 1.0
#   • Example: [0.02, 0.03, 0.05, 0.10, 0.60, 0.12, 0.05, 0.02, 0.01, 0.00]
#     → the model is 60% confident the pain level is class 5 (index 4).
#   • CrossEntropyLoss internally applies log-softmax and compares to the true
#     class index. The loss drives the correct class probability toward 1.0 and
#     all others toward 0.0.
#   • PREDICTION: argmax over the 10 probabilities → single integer class.
#
# REGRESSION OUTPUT LAYER:
#   • 1 neuron, NO activation function (raw linear output).
#   • There is no probability distribution. The single neuron directly outputs
#     a scalar: e.g., 6.83.
#   • MSELoss compares this scalar to the true numeric label (e.g., 7.0) and
#     computes (6.83 - 7.0)² = 0.0289. The gradient flows back through the
#     single neuron, nudging its weights to output values closer to 7.0.
#   • The model is NOT being asked "which bucket?" — it is being asked "what
#     number?". No softmax, no argmax, no probability — just a real-valued
#     prediction.
#   • PREDICTION: read the single neuron output directly, optionally clamp to [1, 10].
#
#   Why no activation on the output neuron?
#     ReLU would block negative outputs (unhelpful if pain could theoretically
#     be below 0 in other tasks). Sigmoid would squash to (0,1), requiring manual
#     rescaling. A raw linear unit lets MSELoss drive the value wherever it needs
#     to go — the loss itself provides the "bounds" implicitly because predicting
#     far outside [1, 10] always increases error.
#
# =============================================================================

import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import re
from collections import Counter
import matplotlib.pyplot as plt

torch.manual_seed(42)
np.random.seed(42)

print("RNN Pain Level Regression Model")
print("=" * 50)

# 1. DATA PREPARATION
print("\n1. Loading and Preparing Data...")

data = {
    'Patient_Notes': [
        "I feel a little better today",
        "The pain is unbearable",
        "I am feeling much better now",
        "Severe pain in my back today",
        "Pain has reduced significantly",
        "Terrible pain all over my body",
        "Slight improvement in pain",
        "No pain at all today",
        "Moderate pain but manageable",
        "Excruciating pain cannot move",
        "Pain is getting worse every day",
        "Some relief from medication",
        "Sharp shooting pain constantly",
        "Much better than yesterday",
        "Dull aching pain persists",
        "Perfect no discomfort today",
        "Intense pain disrupts sleep",
        "Gradual improvement in comfort",
        "Agony with every movement",
        "Comfortable and pain free",
        "Mild soreness after physical therapy",
        "Screaming in pain cannot breathe",
        "Barely any pain just slight stiffness",
        "Constant throbbing headache all day",
        "Pain completely gone feeling great",
        "Burning stabbing pain in chest",
        "Tolerable ache manageable with pills",
        "Joints aching badly after surgery",
        "Feeling numb overwhelmed by pain",
        "Almost recovered minor discomfort only",
        "Pain flaring up severely again",
        "Stiff in the morning but improves",
        "No discomfort resting comfortably",
        "Cramps unbearable cannot stand up",
        "Pain reduced after adjustment today",
        "Deep aching pressure in lower back",
        "Significant pain relief after rest",
        "Worst pain since admission today",
        "Feeling sore but generally improving",
        "Excruciating headache light sensitivity",
    ],
    'Days_Admitted': [
        7, 4, 5, 3, 8, 2, 6, 10, 4, 1, 3, 7, 2, 9, 5, 12, 1, 8, 2, 11,
        3, 1, 9, 5, 14, 1, 6, 2, 1, 11, 3, 7, 13, 1, 5, 4, 10, 1, 6, 2,
    ],
    'Treatment_Type': [
        'Surgery', 'Brain Surgery', 'Physical Therapy', 'Surgery',
        'Medication', 'Emergency', 'Surgery', 'Physical Therapy',
        'Medication', 'Emergency', 'Surgery', 'Medication',
        'Emergency', 'Physical Therapy', 'Surgery', 'Physical Therapy',
        'Emergency', 'Medication', 'Emergency', 'Physical Therapy',
        'Physical Therapy', 'Emergency', 'Physical Therapy', 'Medication',
        'Physical Therapy', 'Emergency', 'Medication', 'Surgery',
        'Emergency', 'Physical Therapy', 'Surgery', 'Physical Therapy',
        'Physical Therapy', 'Emergency', 'Medication', 'Surgery',
        'Medication', 'Emergency', 'Surgery', 'Brain Surgery',
    ],
    'Surgery_Done': [
        'Yes', 'Yes', 'No', 'Yes', 'No', 'No', 'Yes', 'No',
        'No', 'No', 'Yes', 'No', 'No', 'No', 'Yes', 'No',
        'No', 'No', 'No', 'No',
        'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Yes',
        'No', 'No', 'Yes', 'No', 'No', 'No', 'No', 'Yes',
        'No', 'No', 'Yes', 'Yes',
    ],
    # Pain levels kept as continuous floats 1.0–10.0.
    # In a real dataset these could be 4.5, 7.2, etc. — we use integers here
    # only because the synthetic data was created that way.
    'Pain_Level': [
        3, 9, 2, 8, 2, 9, 5, 1, 5, 10, 8, 3, 8, 2, 4, 1, 8, 3, 10, 1,
        3, 10, 2, 6, 1, 9, 4, 7, 9, 2, 8, 3, 1, 10, 3, 6, 2, 10, 4, 9,
    ]
}

df = pd.DataFrame(data)
print(f"Dataset shape: {df.shape}")
print(f"Pain level range: {df['Pain_Level'].min()} – {df['Pain_Level'].max()}")
print(f"Pain level mean: {df['Pain_Level'].mean():.2f}, std: {df['Pain_Level'].std():.2f}")

# 2. TEXT PREPROCESSING
print("\n2. Text Preprocessing...")

def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    return text.split()

# ── Build the vocabulary ─────────────────────────────────────────────────────
#
# WHAT IS THE VOCABULARY?
#   The vocabulary is the complete set of UNIQUE words seen across all 40
#   patient notes in the dataset.  It is the model's "dictionary" — every word
#   it can recognise and represent numerically.
#
#   Words NOT in the vocabulary (e.g. a new clinical term in a future note)
#   are "out-of-vocabulary" (OOV).  This model maps them silently to index 0
#   (the <PAD> token), which loses their meaning entirely.
#
# HOW IS IT COMPUTED?
#   Step 1 — collect every word from every note into one flat list:
#     all_words = ["i", "feel", "a", "little", "better", "today",
#                  "the", "pain", "is", "unbearable", ...]   (≈ 200+ tokens)
#
#   Step 2 — Counter(all_words) counts word frequencies:
#     vocab = {"pain": 18, "the": 12, "better": 7, "ache": 2, ...}
#     Duplicate words are collapsed; only unique words remain as keys.
#
#   Step 3 — assign each unique word a stable integer index (1-based):
#     Sorted alphabetically so the mapping is reproducible across runs.
#     Index 0 is reserved for the <PAD> token (used to fill short sequences).
#
#     word_to_idx = { "ache": 1, "after": 2, "agony": 3, ..., "yesterday": N }
#     word_to_idx["<PAD>"] = 0
#
#   Step 4 — build the reverse map for decoding predictions back to text:
#     idx_to_word = { 0: "<PAD>", 1: "ache", 2: "after", 3: "agony", ... }
#
# WHAT DOES vocab_size CONTAIN?
#   vocab_size = number of UNIQUE words (e.g. 130)
#   len(word_to_idx) = vocab_size + 1 (adds the <PAD> token at index 0)
#
# HOW IS IT USED DOWNSTREAM?
#   1. text_to_sequence()  — looks up each word's integer index via word_to_idx.
#   2. VOCAB_SIZE constant — passed to PainLevelRNNRegressor as the one-hot
#      input dimension.  The RNN's input weight matrix W_x has shape
#      (VOCAB_SIZE × hidden_dim), so the vocabulary size directly determines
#      the size of the largest weight matrix in the model.
#   3. F.one_hot()         — inside forward(), each index is converted to a
#      binary vector of length VOCAB_SIZE.  Larger vocab → bigger, sparser vectors.
#   4. idx_to_word         — used only at inference time to decode a stored
#      integer sequence back to readable words for the sample prediction printout.

# Vocabulary size is the number of unique words across all notes, plus 1 for the <PAD> token.
# (123 in this case)
all_words = []
for note in df['Patient_Notes']:
    all_words.extend(preprocess_text(note))

# Counter collapses all tokens to unique words with their frequency counts
vocab = Counter(all_words)
vocab_size = len(vocab)   # number of unique words (excludes <PAD>)

# Assign index 1..N to each word (sorted alphabetically for reproducibility).
# Index 0 is reserved for <PAD> so it can be used as a safe default / filler.
word_to_idx = {word: i+1 for i, word in enumerate(sorted(vocab.keys()))}
word_to_idx['<PAD>'] = 0   # padding token — never a real word

# Reverse map: integer → word, used only when decoding sequences for display
idx_to_word = {i: word for word, i in word_to_idx.items()}

# +1 because word_to_idx includes <PAD> (index 0) on top of the vocab words
print(f"Vocabulary size: {vocab_size + 1}  ({vocab_size} unique words + 1 <PAD> token)")

def text_to_sequence(text, max_length=10):
    words = preprocess_text(text)
    sequence = [word_to_idx.get(word, 0) for word in words]
    if len(sequence) < max_length:
        sequence.extend([0] * (max_length - len(sequence)))
    else:
        sequence = sequence[:max_length]
    return sequence

sequences = [text_to_sequence(note) for note in df['Patient_Notes']]
X_text = np.array(sequences)

# ── DIAGNOSTIC: show how one note becomes a sequence of indices ───────────────
print("\n--- How a patient note becomes RNN input ---")
sample_note  = df['Patient_Notes'].iloc[0]
sample_words = preprocess_text(sample_note)
sample_seq   = text_to_sequence(sample_note)

print(f"\nOriginal note  : '{sample_note}'")
print(f"After cleaning : {sample_words}")
print(f"Word → index   : { {w: word_to_idx[w] for w in sample_words if w in word_to_idx} }")
print(f"Index sequence : {sample_seq}")
print(f"  (zeros at the end are <PAD> tokens filling up to max_length=10)")
print(f"\nAll 40 notes as index sequences — X_text shape: {X_text.shape}")
print(f"  Rows    = {X_text.shape[0]} notes (one per patient)")
print(f"  Columns = {X_text.shape[1]} time steps (max_length=10 words per note)")
print(f"\nFirst 3 rows of X_text (integer word indices, padded to length 10):")
for i in range(3):
    note_preview = df['Patient_Notes'].iloc[i][:45]
    print(f"  [{i}] {X_text[i]}  ← '{note_preview}...'")

le_treatment = LabelEncoder()
le_surgery = LabelEncoder()

X_days = df['Days_Admitted'].values.reshape(-1, 1)
X_treatment = le_treatment.fit_transform(df['Treatment_Type']).reshape(-1, 1)
X_surgery = le_surgery.fit_transform(df['Surgery_Done']).reshape(-1, 1)

# ── DIAGNOSTIC: show the numerical features that combine with text ────────────
X_numerical_preview = np.concatenate([X_days, X_treatment, X_surgery], axis=1)
print(f"\nNumerical features shape: {X_numerical_preview.shape}")
print(f"  Columns: [Days_Admitted, Treatment_Type (encoded), Surgery_Done (encoded)]")
print(f"  First 3 rows:")
for i in range(3):
    print(f"  [{i}] Days={int(X_days[i][0])}, "
          f"Treatment={int(X_treatment[i][0])} ({df['Treatment_Type'].iloc[i]}), "
          f"Surgery={int(X_surgery[i][0])} ({df['Surgery_Done'].iloc[i]})")

# ── DIAGNOSTIC: show what the RNN actually receives after one-hot expansion ───
print(f"\n--- What the RNN receives (after one-hot encoding inside forward()) ---")
print(f"  X_text holds integer indices:  shape {X_text.shape}  dtype int")
print(f"  Inside forward(), F.one_hot() expands each index to a {len(word_to_idx)}-dim binary vector:")
print(f"    shape becomes (batch, max_length, VOCAB_SIZE)")
print(f"             i.e. (batch,        10,       {len(word_to_idx)})")
print(f"\n  Example — index {sample_seq[0]} (word '{idx_to_word.get(sample_seq[0], '<PAD>')}') "
      f"as a one-hot vector of length {len(word_to_idx)}:")
one_hot_example = np.zeros(len(word_to_idx), dtype=int)
one_hot_example[sample_seq[0]] = 1
# Show a compact view: just the non-zero position and its neighbours
idx = sample_seq[0]
lo, hi = max(0, idx-3), min(len(word_to_idx), idx+4)
snippet = list(one_hot_example[lo:hi])
print(f"    [..., {snippet}, ...]  (1 appears only at position {idx})")
print(f"\n  For a full batch of 32 notes the RNN receives a tensor of shape:")
print(f"    (32, 10, {len(word_to_idx)})  =  {32 * 10 * len(word_to_idx):,} floats per forward pass")
print(f"  The RNN steps through time steps 0→9, reading one {len(word_to_idx)}-wide")
print(f"  one-hot vector per step and updating its 32-dim hidden state.")
print(f"  After step 9, rnn_out[:, -1, :] gives the final hidden state — shape (batch, 32).")
print(f"  That is concatenated with the 3 numerical features → shape (batch, 35)")
print(f"  and fed through fc1 → fc2 → fc3 to produce one pain score per patient.")

# REGRESSION TARGET: keep pain levels as continuous floats (1.0 – 10.0).
# Compare with classification where we did:  y = df['Pain_Level'].values - 1
# (converting to 0-indexed integers for CrossEntropyLoss).
# Here we keep the natural scale — the model must predict a real number.
y = df['Pain_Level'].values.astype(np.float32)

print(f"Target shape: {y.shape}, dtype: {y.dtype}")
print(f"Sample targets (first 5): {y[:5]}")

# 3. RNN MODEL DEFINITION
print("\n3. Defining RNN Model...")

class PainLevelRNNRegressor(nn.Module):
    # REGRESSION MODEL CHANGES vs CLASSIFICATION:
    #   • num_classes parameter removed — output is always 1 scalar
    #   • No softmax in forward() — raw linear output is the prediction
    #   • Loss used externally: MSELoss, not CrossEntropyLoss

    def __init__(self, vocab_size, hidden_dim, num_features=3):
        super(PainLevelRNNRegressor, self).__init__()

        # nn.RNN(input_size, hidden_size):
        #   input_size  = vocab_size  — width of each one-hot word vector fed at each time step
        #   hidden_size = hidden_dim  — size of h_t, the running memory vector (32 floats)
        #   batch_first=True          — input tensor shape is (batch, seq_len, input_size)
        #                               instead of PyTorch's default (seq_len, batch, input_size)
        self.rnn = nn.RNN(vocab_size, hidden_dim, batch_first=True)

        # hidden_dim + num_features = 32 + 3 = 35
        # The 32 floats from the final hidden state (note summary) are joined with
        # the 3 clinical features before the FC layers make the pain prediction.
        self.fc1 = nn.Linear(hidden_dim + num_features, 64)
        self.fc2 = nn.Linear(64, 32)

        # OUTPUT LAYER — 1 neuron, no activation.
        # Classification had: nn.Linear(32, num_classes)  → 10 logits → softmax → argmax
        # Regression has:     nn.Linear(32, 1)            → 1 scalar  → use directly
        #
        # The single neuron computes: output = W·x + b
        # W and b are adjusted by MSELoss to minimise (output − true_pain_level)².
        # No probability distribution exists; the output IS the prediction.
        self.fc3 = nn.Linear(32, 1)
        self.relu = nn.ReLU()

    def forward(self, text_seq, numerical_features):
        # One-hot encode word indices — same as classification version
        text_seq = torch.nn.functional.one_hot(text_seq, num_classes=self.rnn.input_size).float()

        # rnn_out shape: (batch, seq_len, hidden_dim) = (batch, 10, 32)
        #   Every row in the time dimension is the hidden state h_t after reading word t.
        #   h_0 = summary after word 0 only
        #   h_1 = summary after words 0-1
        #   ...
        #   h_9 = summary after all 10 words — the complete note encoding
        # The second return value (_) is the final hidden state as a separate tensor;
        # we ignore it here and read it from rnn_out instead (same values, different shape).
        rnn_out, _ = self.rnn(text_seq)

        # Take only the LAST time step's hidden state — shape (batch, 32).
        # This is h_9: the hidden state after the RNN has read the entire note.
        # It is the 32-float "memory" that summarises the full sequence.
        # Steps 0-8 are discarded — they were intermediate working memory only.
        text_features = rnn_out[:, -1, :]

        combined = torch.cat([text_features, numerical_features], dim=1)

        x = self.relu(self.fc1(combined))
        x = self.relu(self.fc2(x))

        # Raw scalar output — shape (batch, 1)
        # No softmax. No argmax. The number itself is the pain prediction.
        x = self.fc3(x)

        # Squeeze to shape (batch,) so it matches the target tensor shape
        return x.squeeze(1)

# VOCAB_SIZE = total number of distinct tokens the model knows about.
# = vocab_size (unique words) + 1 (<PAD> at index 0)
# = len(word_to_idx) because word_to_idx already includes <PAD>.
#
# This value has two concrete effects on the model:
#   1. It sets the WIDTH of each one-hot vector inside forward():
#        F.one_hot(text_seq, num_classes=VOCAB_SIZE)
#      A vocabulary of 131 words → each word is a 131-dim binary vector.
#      Larger vocabulary → larger, more memory-hungry input to the RNN.
#
#   2. It sets the number of COLUMNS in the RNN's input weight matrix W_x:
#        W_x has shape (hidden_dim × VOCAB_SIZE) = (32 × 131) = 4,192 weights.
#      If vocab were 10,000 words, W_x alone would be 320,000 weights —
#      one reason why embedding layers (which reduce this to hidden_dim × embed_dim)
#      are preferred for large vocabularies.
VOCAB_SIZE = len(word_to_idx)

# HIDDEN_DIM — the size of the RNN's hidden state vector.
#
# WHAT IS THE HIDDEN STATE?
#   The hidden state h_t is a fixed-size vector of 32 floats that the RNN
#   maintains as it reads the note word by word.  It is the model's "working
#   memory" — a compressed summary of everything read so far at each step.
#
#   At each time step t the RNN computes:
#
#     h_t = tanh( W_h · h_{t-1}  +  W_x · x_t  +  b )
#                 ──────────────     ───────────
#                 previous memory    current word
#
#   W_h : (32 × 32) weight matrix — how much of the previous state to keep
#   W_x : (32 × VOCAB_SIZE) weight matrix — how to encode the current word
#   b   : bias vector of size 32
#   tanh: squashes values to (-1, +1) so the state doesn't grow unbounded
#
# WHAT DOES IT CONTAIN AFTER READING A NOTE?
#   After processing all 10 time steps, h_10 is a single vector of 32 floats
#   that encodes the "meaning" of the entire note as the model understands it.
#   It is NOT human-readable — each dimension is a learned combination of
#   features the model found useful for predicting pain levels.
#
#   Intuitively, after training the hidden state for
#     "Excruciating pain cannot move"
#   will look very different from
#     "No pain at all today"
#   even though the model was never told what pain words mean — it discovered
#   the pattern purely from the association between note words and pain scores.
#
# WHY 32?
#   32 is a hyperparameter chosen by the developer.  Rules of thumb:
#     • Too small (e.g. 4):  the vector cannot hold enough information to
#       distinguish between similar notes ("moderate pain" vs "mild pain").
#     • Too large (e.g. 512): more expressive, but overfits badly on only
#       32 training samples and trains much more slowly.
#     • 32 is a reasonable middle ground for a ~130-word vocabulary and
#       short notes (≤10 words). Common choices: 16, 32, 64, 128.
#
# HOW IS IT USED?
#   rnn_out[:, -1, :] — we take ONLY the hidden state at the LAST time step.
#   Shape: (batch, 32).  This 32-float summary of the note is then concatenated
#   with the 3 numerical features (Days_Admitted, Treatment_Type, Surgery_Done)
#   to form a 35-float combined vector, which the FC layers project down to a
#   single pain score.  The hidden states at earlier time steps (0–8) are
#   computed but discarded — they were only used as intermediate memory.
HIDDEN_DIM = 32
LEARNING_RATE = 0.001
EPOCHS = 100

model = PainLevelRNNRegressor(VOCAB_SIZE, HIDDEN_DIM)

# LOSS FUNCTION CHANGE:
#   Classification: nn.CrossEntropyLoss() — compares probability distribution to class index
#   Regression:     nn.MSELoss()          — compares single predicted float to true float
#
# MSELoss = mean of (predicted - actual)² across the batch.
# It penalises large errors quadratically: being off by 4 is penalised 16×
# more than being off by 1. This makes the model prioritise fixing its worst predictions.
#
# Alternative: nn.L1Loss() (MAELoss) — uses |predicted - actual| instead of squaring.
# MAE is more robust to outliers (an extreme pain value won't dominate training)
# but provides weaker gradient signal near the correct value (gradient is constant ±1).
# MSELoss is the standard starting point for regression.
criterion = nn.MSELoss()

optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

# ── HOW ARE THE 9,441 PARAMETERS COMPUTED? ───────────────────────────────────
#
# Every learnable number in the model is a "parameter".  Parameters are the
# weights and biases that gradient descent adjusts during training.
# The total count comes from four layers:
#
# ┌─────────────────────────────────────────────────────────────────────────┐
# │ Layer          Formula                          Calculation    Params   │
# ├─────────────────────────────────────────────────────────────────────────┤
# │ RNN            weight_ih  (32 × 123)            32 × 123     = 3,936   │
# │   input →      weight_hh  (32 × 32)             32 × 32      = 1,024   │
# │   hidden       bias_ih    (32,)                              =    32   │
# │                bias_hh    (32,)                              =    32   │
# │                                                 RNN total    = 5,024   │
# ├─────────────────────────────────────────────────────────────────────────┤
# │ fc1            weights    (35 × 64)             35 × 64      = 2,240   │
# │ Linear(35,64)  bias       (64,)                              =    64   │
# │                                                 fc1 total    = 2,304   │
# ├─────────────────────────────────────────────────────────────────────────┤
# │ fc2            weights    (64 × 32)             64 × 32      = 2,048   │
# │ Linear(64,32)  bias       (32,)                              =    32   │
# │                                                 fc2 total    = 2,080   │
# ├─────────────────────────────────────────────────────────────────────────┤
# │ fc3            weights    (32 × 1)              32 × 1       =    32   │
# │ Linear(32,1)   bias       (1,)                               =     1   │
# │                                                 fc3 total    =    33   │
# ├─────────────────────────────────────────────────────────────────────────┤
# │ GRAND TOTAL    5,024 + 2,304 + 2,080 + 33                   = 9,441   │
# └─────────────────────────────────────────────────────────────────────────┘
#
# KEY NUMBERS TO UNDERSTAND:
#
# RNN weight_ih  (32 × 123 = 3,936) — the largest single weight matrix.
#   Rows = hidden_dim (32): one row controls how the current word
#          shifts each of the 32 hidden state dimensions.
#   Cols = VOCAB_SIZE (123): one column per possible word in the vocabulary.
#   This matrix is WHY large vocabularies are expensive in one-hot models:
#   if vocab were 10,000 words, weight_ih alone would be 320,000 parameters.
#   An embedding layer avoids this by reducing input width to embed_dim (e.g. 32).
#
# RNN weight_hh  (32 × 32 = 1,024) — the "memory" weight matrix.
#   Multiplied by the PREVIOUS hidden state h_{t-1} at every time step.
#   Captures how much of the past context to carry forward into the next step.
#   Square matrix because both input and output are hidden_dim-dimensional.
#
# fc1 input width = 35 = hidden_dim (32) + num_features (3).
#   The 32-dim RNN summary is concatenated with the 3 clinical features
#   (Days_Admitted, Treatment_Type, Surgery_Done) before entering fc1.
#   Those extra 3 columns add 3 × 64 = 192 weights compared to a text-only model.
#
# fc3 has only 33 parameters (32 weights + 1 bias) — the final output layer
#   is tiny because it maps from 32 values down to a single pain score.
#   This is the regression bottleneck: all the learned signal must be
#   compressed into one number here.
print(f"Model parameters: {sum(p.numel() for p in model.parameters())}")
print(f"  RNN  weight_ih (32×VOCAB_SIZE) + weight_hh (32×32) + 2 biases  = 5,024")
print(f"  fc1  Linear(35→64):  35×64 + 64 bias                           = 2,304")
print(f"  fc2  Linear(64→32):  64×32 + 32 bias                           = 2,080")
print(f"  fc3  Linear(32→ 1):  32× 1 +  1 bias                           =    33")
print(f"  ─────────────────────────────────────────────────────────────────  ─────")
print(f"  Total                                                            = 9,441")
print(f"Loss function: MSELoss (regression) — replaces CrossEntropyLoss (classification)")

# 4. PREPARE DATA FOR TRAINING
print("\n4. Preparing Training Data...")

X_numerical = np.concatenate([X_days, X_treatment, X_surgery], axis=1)

X_text_train, X_text_test, X_num_train, X_num_test, y_train, y_test = train_test_split(
    X_text, X_numerical, y, test_size=0.2, random_state=42
)

X_text_train = torch.LongTensor(X_text_train)
X_text_test  = torch.LongTensor(X_text_test)
X_num_train  = torch.FloatTensor(X_num_train)
X_num_test   = torch.FloatTensor(X_num_test)

# TENSOR TYPE CHANGE:
#   Classification: torch.LongTensor(y)   — CrossEntropyLoss requires integer class indices
#   Regression:     torch.FloatTensor(y)  — MSELoss requires float targets to compute (pred - true)²
y_train = torch.FloatTensor(y_train)
y_test  = torch.FloatTensor(y_test)

print(f"Training samples: {len(X_text_train)}")
print(f"Test samples: {len(X_text_test)}")
print(f"Target tensor dtype: {y_train.dtype}  (was LongTensor in classification)")

# 5. TRAINING LOOP
print("\n5. Training Model...")

train_losses = []

model.train()
for epoch in range(EPOCHS):
    optimizer.zero_grad()

    # Model now returns shape (batch,) — one float per sample
    predictions = model(X_text_train, X_num_train)

    # MSELoss: compares (batch,) predictions to (batch,) float targets
    # In classification this was: criterion(logits, y_train) where logits=(batch,10), y=(batch,)
    loss = criterion(predictions, y_train)
    loss.backward()
    optimizer.step()
    train_losses.append(loss.item())

    if (epoch + 1) % 20 == 0:
        # Report RMSE alongside MSE loss for human interpretability
        # MSE is in squared pain-level units; RMSE is back in pain-level units (1–10 scale)
        rmse = loss.item() ** 0.5
        print(f"Epoch [{epoch+1}/{EPOCHS}], MSE Loss: {loss.item():.4f}, RMSE: {rmse:.4f}")

# 6. MODEL EVALUATION
print("\n6. Evaluating Model...")

# REGRESSION METRICS — replace accuracy/precision/recall/F1:
#
#   MAE  (Mean Absolute Error):   average |predicted - actual| in pain-level units.
#          Intuitive: "on average the model is off by X pain points."
#
#   RMSE (Root Mean Squared Error): sqrt of mean squared error, also in pain-level units.
#          Penalises large errors more than MAE. A model that occasionally misses by 5
#          will have much higher RMSE than MAE.
#
#   R²   (Coefficient of Determination): answers "how much of the variation in
#          pain levels across patients does the model actually explain?"
#
#          FORMULA:  R² = 1 - SS_res / SS_tot
#
#            SS_res (residual sum of squares) = Σ (actual - predicted)²
#                   Total squared error the model still makes.
#
#            SS_tot (total sum of squares)    = Σ (actual - mean_actual)²
#                   Total squared variation in pain levels if you just predicted
#                   the dataset mean for every patient (the dumbest possible model).
#
#          INTUITION WITH CONCRETE NUMBERS:
#            Suppose the mean pain level in the dataset is 5.5.
#            Patient A has pain = 9.  The dumb baseline guess is 5.5 → error² = 12.25
#            Your model guesses 8.2                                  → error² =  0.64
#            Your model explains most of that gap → high R².
#
#          INTERPRETING THE VALUE:
#            R² = 1.00  Perfect — model predicts every pain level exactly.
#            R² = 0.80  Model explains 80% of pain-level variation; 20% is noise
#                       or missing features (e.g. patient age, medication dose).
#            R² = 0.00  Model is no better than always predicting the mean (5.5).
#                       It has learned nothing useful from the notes or features.
#            R² < 0.00  Model is WORSE than the mean baseline — predictions are
#                       so far off that you'd do better ignoring the model entirely.
#                       Common when training on very little data (our 32 samples).
#
#          WHY R² COMPLEMENTS MAE AND RMSE:
#            MAE/RMSE tell you the error in pain-level units ("off by 1.4 points").
#            R² is unit-free and answers the deeper question: "relative to the
#            natural spread of pain in this patient population, how much did the
#            model reduce uncertainty?" A model with MAE=1.5 looks good on a
#            0–100 scale but terrible on a 1–10 scale; R² captures this context.
#
# WHY NOT ACCURACY/F1 FOR REGRESSION?
#   Those metrics require discrete class predictions. A continuous prediction of 4.83
#   is never exactly equal to a true label of 5, so "accuracy" would always be 0%.
#   Regression metrics measure *closeness*, which is the right question here.

def evaluate_model(y_true, y_pred, split_name=""):
    """Compute MAE, RMSE, and R² for regression evaluation."""
    mae  = mean_absolute_error(y_true, y_pred)
    rmse = mean_squared_error(y_true, y_pred) ** 0.5
    r2   = r2_score(y_true, y_pred)

    print(f"\n{split_name} Results:")
    print(f"  MAE  (avg pain-level error) : {mae:.3f}")
    print(f"  RMSE (penalises big errors) : {rmse:.3f}")
    print(f"  R²   (variance explained)  : {r2:.3f}")
    return mae, rmse, r2

model.eval()
with torch.no_grad():
    train_preds = model(X_text_train, X_num_train).numpy()
    test_preds  = model(X_text_test,  X_num_test).numpy()

# Clamp predictions to valid pain-level range [1, 10].
# Because the output neuron is unconstrained, the model can in principle output
# values like 0.2 or 11.5 — especially early in training or on out-of-distribution
# input. Clamping enforces the clinically meaningful range without distorting gradients
# during training (we only clamp at inference time).
train_preds_clamped = np.clip(train_preds, 1.0, 10.0)
test_preds_clamped  = np.clip(test_preds,  1.0, 10.0)

y_train_np = y_train.numpy()
y_test_np  = y_test.numpy()

evaluate_model(y_train_np, train_preds_clamped, "Training")
evaluate_model(y_test_np,  test_preds_clamped,  "Test")

# 7. SAMPLE PREDICTIONS
print("\n7. Sample Predictions (continuous values)...")

sample_indices = range(len(X_text_test))
for i in sample_indices:
    actual    = y_test[i].item()
    predicted = float(np.clip(test_preds[i], 1.0, 10.0))
    error     = abs(predicted - actual)

    text_seq = X_text_test[i].numpy()
    words = [idx_to_word.get(idx, '<UNK>') for idx in text_seq if idx != 0]
    original_text = ' '.join(words)

    print(f"\nSample {i+1}:")
    print(f"  Text              : '{original_text}'")
    print(f"  Actual pain level : {actual:.1f}")
    print(f"  Predicted         : {predicted:.2f}   (error: {error:.2f})")

# 8. VISUALISATION
print("\n8. Creating Visualisations...")

fig, axes = plt.subplots(1, 3, figsize=(16, 5))

# Plot 1: Training loss (MSE over epochs)
axes[0].plot(train_losses, color='steelblue')
axes[0].set_title('Training Loss (MSE) over Epochs')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('MSE Loss (pain-level²)')
axes[0].grid(True)

# Plot 2: Predicted vs Actual scatter — the key regression diagnostic.
# Points on the diagonal y=x indicate perfect predictions.
# Classification used a bar chart of discrete class counts; regression uses a
# scatter plot because predictions are continuous.
axes[1].scatter(y_test_np, test_preds_clamped, color='tomato', alpha=0.8, edgecolors='black', linewidths=0.5)
min_val, max_val = 1, 10
axes[1].plot([min_val, max_val], [min_val, max_val], 'k--', linewidth=1, label='Perfect prediction')
axes[1].set_xlabel('Actual Pain Level')
axes[1].set_ylabel('Predicted Pain Level')
axes[1].set_title('Predicted vs Actual (Test Set)')
axes[1].legend()
axes[1].grid(True)
axes[1].set_xlim(0.5, 10.5)
axes[1].set_ylim(0.5, 10.5)

# Plot 3: Residuals (prediction error) per sample.
# Residual = predicted − actual. Ideally scattered randomly around 0.
# A systematic bias (residuals consistently positive or negative for high pain levels)
# would reveal a model that under/over-estimates at the extremes of the scale.
residuals = test_preds_clamped - y_test_np
axes[2].bar(range(len(residuals)), residuals, color=['green' if r >= 0 else 'red' for r in residuals], alpha=0.7)
axes[2].axhline(0, color='black', linewidth=1)
axes[2].set_xlabel('Test Sample Index')
axes[2].set_ylabel('Residual (Predicted − Actual)')
axes[2].set_title('Residuals on Test Set')
axes[2].grid(True, axis='y')

plt.tight_layout()
plt.show()

# 9. NEW PATIENT PREDICTION
print("\n9. Predicting for New Patients (continuous output)...")

def predict_new_sample(note, days, treatment, surgery):
    """Return a continuous pain-level prediction in [1, 10]."""
    model.eval()
    with torch.no_grad():
        text_seq = torch.LongTensor([text_to_sequence(note)])
        treatment_encoded = le_treatment.transform([treatment])[0]
        surgery_encoded   = le_surgery.transform([surgery])[0]
        num_features = torch.FloatTensor([[days, treatment_encoded, surgery_encoded]])

        raw_output = model(text_seq, num_features).item()
        # Clamp to [1, 10]: the model has no built-in constraint on its output range
        return float(np.clip(raw_output, 1.0, 10.0))

test_cases = [
    ("I feel great today no pain",    5, "Physical Therapy", "No"),
    ("Horrible pain cannot sleep",    2, "Emergency",        "Yes"),
    ("Getting better slowly",         7, "Medication",       "No"),
]

print("\nNew patient predictions (regression — continuous values):")
for note, days, treatment, surgery in test_cases:
    pred = predict_new_sample(note, days, treatment, surgery)
    print(f"  Note: '{note}'")
    print(f"  → Predicted Pain Level: {pred:.2f}  (classification would have said: {round(pred)})")

print(f"\n{'='*60}")
print("Regression model complete.")
print("Output: continuous pain score in [1.0, 10.0]")
print("Loss:   MSELoss  |  Metrics: MAE, RMSE, R²")
print(f"{'='*60}")

# =============================================================================
# SUMMARY: CLASSIFICATION vs REGRESSION SIDE-BY-SIDE
# =============================================================================
#
#  Aspect              | Classification (04_rnn...)   | Regression (this file)
#  --------------------|------------------------------|-------------------------
#  Target type         | Integer 0–9 (class index)    | Float 1.0–10.0
#  Target tensor       | torch.LongTensor             | torch.FloatTensor
#  Output layer        | Linear(32, 10) → 10 logits   | Linear(32, 1) → 1 scalar
#  Output activation   | Softmax (implicit in loss)   | None (raw linear output)
#  Loss function       | CrossEntropyLoss             | MSELoss
#  Prediction step     | argmax over 10 probabilities | read scalar directly, clamp
#  Metrics             | Accuracy, F1, Precision,     | MAE, RMSE, R²
#                      | Recall                       |
#  Near-miss penalty   | Same as total miss           | Proportionally smaller
#  Output range        | Always one of 10 buckets     | Any float, clamped to [1,10]
#  Clinical meaning    | "This patient is in class 7" | "This patient scores 6.83"
# =============================================================================
