# RNN Pain Level Prediction with Embedding Layer - Healthcare Analytics
# Regression version: predicts a continuous pain score in [1.0, 10.0]
#
# This is a variation of 04_rnn_patient_painlevel_pred.py that replaces
# one-hot encoding with a learned Embedding layer AND reframes the task
# as regression (MSELoss, single output neuron) instead of classification.
#
# KEY CONCEPT: How does the Embedding layer help?
# ─────────────────────────────────────────────────────────────────────
# In the original model, each word is represented as a one-hot vector of
# size vocab_size (e.g., ~130 dimensions). That means:
#   - "pain" → [0, 0, 1, 0, 0, ... ]   (sparse, all zeros except one)
#   - "ache" → [0, 0, 0, 0, 1, ... ]   (equally sparse, no relation to "pain")
#
# The two vectors are orthogonal — mathematically they are equally distant
# from each other as from every other word. The model has no way to know
# that "pain" and "ache" are semantically close.
#
# An Embedding layer maps each word index to a small dense vector, e.g.:
#   - "pain"         → [ 0.82, -0.41,  0.17, ...]   (8 floats)
#   - "ache"         → [ 0.79, -0.38,  0.20, ...]   (nearby in space!)
#   - "comfortable"  → [-0.61,  0.72, -0.55, ...]   (far away)
#
# These vectors are *learned by gradient descent* during training — the
# model nudges them until similar-meaning words end up near each other
# in the 8-dimensional space, purely because that arrangement minimises
# the loss on pain-level prediction.
#
# ┌─────────────────────────────────────────────────────────────────┐
# │  IMPORTANT: This is NOT similarity search / vector search       │
# │                                                                 │
# │  In RAG / vector databases:                                     │
# │    query vector → cosine/dot-product search → retrieve docs     │
# │                                                                 │
# │  Here there is NO retrieval step.                               │
# │                                                                 │
# │  Instead, the embedding vectors are directly fed as INPUT       │
# │  to the RNN. The RNN reads the sequence of dense vectors and    │
# │  learns to compress them into a hidden state that captures      │
# │  the "pain trajectory" of the note.                             │
# │                                                                 │
# │  The mechanism is:                                              │
# │    word index → embedding lookup (dense vector)                 │
# │                → RNN processes sequence of dense vectors        │
# │                → final hidden state → FC layers → pain score    │
# │                                                                 │
# │  Gradient backpropagates all the way through the FC layers,     │
# │  through the RNN, and into the embedding table — so the         │
# │  embeddings become task-specific, not generic.                  │
# └─────────────────────────────────────────────────────────────────┘

import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import re
from collections import Counter
import matplotlib.pyplot as plt

torch.manual_seed(42)
np.random.seed(42)

print("RNN Pain Level Classification Model — with Embedding Layer")
print("=" * 60)

# 1. DATA PREPARATION
print("\n1. Loading and Preparing Data...")

data = {
    'Patient_Notes': [
        "I feel a little better today",
        "The pain is unbearable",
        "I am feeling much better now",
        "Severe pain in my back today",
        "Pain has reduced significantly",
        "Terrible pain all over my body",
        "Slight improvement in pain",
        "No pain at all today",
        "Moderate pain but manageable",
        "Excruciating pain cannot move",
        "Pain is getting worse every day",
        "Some relief from medication",
        "Sharp shooting pain constantly",
        "Much better than yesterday",
        "Dull aching pain persists",
        "Perfect no discomfort today",
        "Intense pain disrupts sleep",
        "Gradual improvement in comfort",
        "Agony with every movement",
        "Comfortable and pain free",
        "Mild soreness after physical therapy",
        "Screaming in pain cannot breathe",
        "Barely any pain just slight stiffness",
        "Constant throbbing headache all day",
        "Pain completely gone feeling great",
        "Burning stabbing pain in chest",
        "Tolerable ache manageable with pills",
        "Joints aching badly after surgery",
        "Feeling numb overwhelmed by pain",
        "Almost recovered minor discomfort only",
        "Pain flaring up severely again",
        "Stiff in the morning but improves",
        "No discomfort resting comfortably",
        "Cramps unbearable cannot stand up",
        "Pain reduced after adjustment today",
        "Deep aching pressure in lower back",
        "Significant pain relief after rest",
        "Worst pain since admission today",
        "Feeling sore but generally improving",
        "Excruciating headache light sensitivity",
    ],
    'Days_Admitted': [
        7, 4, 5, 3, 8, 2, 6, 10, 4, 1, 3, 7, 2, 9, 5, 12, 1, 8, 2, 11,
        3, 1, 9, 5, 14, 1, 6, 2, 1, 11, 3, 7, 13, 1, 5, 4, 10, 1, 6, 2,
    ],
    'Treatment_Type': [
        'Surgery', 'Brain Surgery', 'Physical Therapy', 'Surgery',
        'Medication', 'Emergency', 'Surgery', 'Physical Therapy',
        'Medication', 'Emergency', 'Surgery', 'Medication',
        'Emergency', 'Physical Therapy', 'Surgery', 'Physical Therapy',
        'Emergency', 'Medication', 'Emergency', 'Physical Therapy',
        'Physical Therapy', 'Emergency', 'Physical Therapy', 'Medication',
        'Physical Therapy', 'Emergency', 'Medication', 'Surgery',
        'Emergency', 'Physical Therapy', 'Surgery', 'Physical Therapy',
        'Physical Therapy', 'Emergency', 'Medication', 'Surgery',
        'Medication', 'Emergency', 'Surgery', 'Brain Surgery',
    ],
    'Surgery_Done': [
        'Yes', 'Yes', 'No', 'Yes', 'No', 'No', 'Yes', 'No',
        'No', 'No', 'Yes', 'No', 'No', 'No', 'Yes', 'No',
        'No', 'No', 'No', 'No',
        'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Yes',
        'No', 'No', 'Yes', 'No', 'No', 'No', 'No', 'Yes',
        'No', 'No', 'Yes', 'Yes',
    ],
    'Pain_Level': [
        3, 9, 2, 8, 2, 9, 5, 1, 5, 10, 8, 3, 8, 2, 4, 1, 8, 3, 10, 1,
        3, 10, 2, 6, 1, 9, 4, 7, 9, 2, 8, 3, 1, 10, 3, 6, 2, 10, 4, 9,
    ]
}

df = pd.DataFrame(data)
print(f"Dataset shape: {df.shape}")
print(f"Pain level range: {df['Pain_Level'].min()} – {df['Pain_Level'].max()}")

# 2. TEXT PREPROCESSING
print("\n2. Text Preprocessing...")

def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    return text.split()

all_words = []
for note in df['Patient_Notes']:
    all_words.extend(preprocess_text(note))

vocab = Counter(all_words)
vocab_size = len(vocab)
word_to_idx = {word: i + 1 for i, word in enumerate(vocab.keys())}
word_to_idx['<PAD>'] = 0
idx_to_word = {i: word for word, i in word_to_idx.items()}

print(f"Vocabulary size: {vocab_size + 1}")
print(f"Most common words: {vocab.most_common(5)}")

def text_to_sequence(text, max_length=10):
    words = preprocess_text(text)
    sequence = [word_to_idx.get(word, 0) for word in words]
    if len(sequence) < max_length:
        sequence.extend([0] * (max_length - len(sequence)))
    else:
        sequence = sequence[:max_length]
    return sequence

sequences = [text_to_sequence(note) for note in df['Patient_Notes']]
X_text = np.array(sequences)

le_treatment = LabelEncoder()
le_surgery = LabelEncoder()

X_days = df['Days_Admitted'].values.reshape(-1, 1)
X_treatment = le_treatment.fit_transform(df['Treatment_Type']).reshape(-1, 1)
X_surgery = le_surgery.fit_transform(df['Surgery_Done']).reshape(-1, 1)

# Regression target: keep natural 1–10 float scale.
# Classification used: y = df['Pain_Level'].values - 1  (0-indexed LongTensor)
y = df['Pain_Level'].values.astype(np.float32)

# 3. RNN MODEL WITH EMBEDDING LAYER
print("\n3. Defining RNN Model with Embedding Layer...")

# Embedding dimension: how many floats represent each word.
# 8 is small but sufficient for a 130-word vocabulary.
# Larger corpora typically use 50–300 dimensions.
EMBED_DIM = 8

class PainLevelRNN_Embedding(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim, num_features=3):
        super(PainLevelRNN_Embedding, self).__init__()

        # ── Embedding layer ───────────────────────────────────────────────────
        # nn.Embedding is a trainable lookup table of shape (vocab_size, embed_dim).
        # For each word index in the input sequence it returns a dense vector of
        # `embed_dim` floats.
        #
        # Example (embed_dim=8):
        #   index 5 ("pain") → [ 0.82, -0.41,  0.17, -0.05,  0.63,  0.11, -0.29,  0.54]
        #   index 9 ("ache") → [ 0.79, -0.38,  0.20, -0.03,  0.60,  0.14, -0.25,  0.51]
        #
        # Why is this better than one-hot?
        #   One-hot: 130-dim sparse vector, every pair of words is equally distant.
        #   Embedding: 8-dim dense vector, semantically similar words end up close
        #   together after training because that structure helps minimise pain-level loss.
        #
        # padding_idx=0 tells PyTorch not to update the <PAD> token's vector —
        # it stays as all zeros so padding has no effect on the RNN hidden state.
        # NOT pre-trained. Weights are initialised randomly and learned from
        # scratch during training, jointly with the RNN and classifier weights.
        # (Compare with pre-trained embeddings like Word2Vec / GloVe / FastText,
        # where weights are frozen or fine-tuned from a large external corpus.)
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)

        # ── RNN ───────────────────────────────────────────────────────────────
        # Input to the RNN is now embed_dim (8) instead of vocab_size (~130).
        # Smaller, denser input = faster convergence and better generalisation.
        #
        # The RNN reads the sequence of embedding vectors left-to-right and
        # accumulates context in its hidden state h_t:
        #   h_t = tanh(W_h * h_{t-1} + W_x * embed(word_t) + b)
        #
        # NO similarity search happens here. The embedding vector is simply
        # the numeric input to the RNN at each time step — like pixel values
        # to a CNN. The RNN's job is to compress the sequence into a single
        # hidden state that summarises the clinical note.
        self.rnn = nn.RNN(embed_dim, hidden_dim, batch_first=True)

        # ── Fully-connected regressor ─────────────────────────────────────────
        # Concatenate the RNN's final hidden state with the 3 numerical features,
        # then project down to a single scalar pain score.
        # Classification had: nn.Linear(32, num_classes) → 10 logits → softmax
        # Regression has:     nn.Linear(32, 1)           → 1 scalar  → use directly
        self.fc1 = nn.Linear(hidden_dim + num_features, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)   # single output neuron — no activation
        self.relu = nn.ReLU()

    def forward(self, text_seq, numerical_features):
        # Step 1 — Embedding lookup
        # text_seq shape: (batch, seq_len)  — integer word indices
        # embedded  shape: (batch, seq_len, embed_dim)
        #
        # Each integer index is replaced by its learned dense vector.
        # This is a simple table lookup — O(1), no distance computation,
        # no search. The "intelligence" is baked into the vector values
        # through training, not retrieved at inference time.
        embedded = self.embedding(text_seq)

        # Step 2 — RNN processes the sequence of embedding vectors
        # rnn_out shape: (batch, seq_len, hidden_dim)
        rnn_out, _ = self.rnn(embedded)

        # Step 3 — Take the last time-step's hidden state as the text summary
        text_features = rnn_out[:, -1, :]   # (batch, hidden_dim)

        # Step 4 — Combine text summary with clinical features and regress
        combined = torch.cat([text_features, numerical_features], dim=1)
        x = self.relu(self.fc1(combined))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)          # raw scalar, shape: (batch, 1)
        return x.squeeze(1)      # → (batch,) to match FloatTensor targets

# Model parameters
VOCAB_SIZE = len(word_to_idx)
HIDDEN_DIM = 32
LEARNING_RATE = 0.001
EPOCHS = 100

model = PainLevelRNN_Embedding(VOCAB_SIZE, EMBED_DIM, HIDDEN_DIM)
criterion = nn.MSELoss()   # regression loss — replaces CrossEntropyLoss
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

total_params = sum(p.numel() for p in model.parameters())
embed_params = VOCAB_SIZE * EMBED_DIM
print(f"Model initialized with {total_params} parameters")
print(f"  → Embedding table: {embed_params} params ({VOCAB_SIZE} words × {EMBED_DIM} dims)")
# Compare: original one-hot model fed vocab_size inputs to RNN → RNN weight matrix
# was (vocab_size × hidden_dim). Embedding model feeds embed_dim inputs → much smaller.

# 4. PREPARE DATA FOR TRAINING
print("\n4. Preparing Training Data...")

X_numerical = np.concatenate([X_days, X_treatment, X_surgery], axis=1)

X_text_train, X_text_test, X_num_train, X_num_test, y_train, y_test = train_test_split(
    X_text, X_numerical, y, test_size=0.2, random_state=42
)

X_text_train = torch.LongTensor(X_text_train)
X_text_test  = torch.LongTensor(X_text_test)
X_num_train  = torch.FloatTensor(X_num_train)
X_num_test   = torch.FloatTensor(X_num_test)
# FloatTensor required by MSELoss — classification used LongTensor for CrossEntropyLoss
y_train      = torch.FloatTensor(y_train)
y_test       = torch.FloatTensor(y_test)

print(f"Training samples: {len(X_text_train)}")
print(f"Test samples    : {len(X_text_test)}")

# 5. TRAINING LOOP
print("\n5. Training Model...")

train_losses = []

model.train()
for epoch in range(EPOCHS):
    optimizer.zero_grad()
    predictions = model(X_text_train, X_num_train)   # shape (batch,) — one float per sample
    loss = criterion(predictions, y_train)            # MSE: mean of (pred - actual)²
    loss.backward()
    # Backprop flows: MSELoss → fc layers → RNN → embedding table
    # The embedding vectors for words that appear in training notes are
    # updated each step — pain-relevant words drift together in vector space.
    optimizer.step()
    train_losses.append(loss.item())

    if (epoch + 1) % 20 == 0:
        rmse = loss.item() ** 0.5
        print(f"Epoch [{epoch+1}/{EPOCHS}], MSE: {loss.item():.4f}, RMSE: {rmse:.4f}")

# 6. MODEL EVALUATION
print("\n6. Evaluating Model...")

def evaluate_model(y_true, y_pred, split_name=""):
    """Regression metrics: MAE, RMSE, R²."""
    mae  = mean_absolute_error(y_true, y_pred)
    rmse = mean_squared_error(y_true, y_pred) ** 0.5
    r2   = r2_score(y_true, y_pred)
    print(f"\n{split_name} Results:")
    print(f"  MAE  (avg pain-level error) : {mae:.3f}")
    print(f"  RMSE (penalises big errors) : {rmse:.3f}")
    print(f"  R²   (variance explained)  : {r2:.3f}")
    return mae, rmse, r2

model.eval()
with torch.no_grad():
    train_preds = model(X_text_train, X_num_train).numpy()
    test_preds  = model(X_text_test,  X_num_test).numpy()

# Clamp to valid clinical range at inference time only — does not affect training gradients
train_preds_c = np.clip(train_preds, 1.0, 10.0)
test_preds_c  = np.clip(test_preds,  1.0, 10.0)

y_train_np = y_train.numpy()
y_test_np  = y_test.numpy()

evaluate_model(y_train_np, train_preds_c, "Training")
evaluate_model(y_test_np,  test_preds_c,  "Test")

# 7. PEEK AT LEARNED EMBEDDINGS
# ─────────────────────────────────────────────────────────────────────
# After training we can inspect the embedding table to see whether
# semantically similar words ended up near each other in the 8-D space.
# No similarity search is needed to USE the model — this is just for
# human understanding.
print("\n7. Inspecting Learned Embedding Vectors (sample)...")

pain_words = ['pain', 'ache', 'comfortable', 'unbearable', 'relief', 'severe']
with torch.no_grad():
    for word in pain_words:
        idx = word_to_idx.get(word)
        if idx is not None:
            vec = model.embedding(torch.LongTensor([idx])).squeeze().numpy()
            # Format as fixed-width floats for readability
            vec_str = ', '.join(f'{v:+.2f}' for v in vec)
            print(f"  '{word}': [{vec_str}]")
        else:
            print(f"  '{word}': not in vocabulary")

print("\n  Notice: pain/ache vectors tend to look similar (pain ↔ ache).")
print("  comfortable/relief vectors point in a different direction.")
print("  This structure emerged automatically from gradient descent —")
print("  no similarity search, no pre-trained vectors, no manual labels.")

# 8. SAMPLE PREDICTIONS
print("\n8. Sample Predictions (continuous scores)...")

for i in range(len(X_text_test)):
    actual    = y_test[i].item()
    predicted = float(np.clip(test_preds[i], 1.0, 10.0))
    error     = abs(predicted - actual)
    text_seq  = X_text_test[i].numpy()
    words     = [idx_to_word.get(idx, '<UNK>') for idx in text_seq if idx != 0]
    print(f"\n  Sample {i+1}: '{' '.join(words)}'")
    print(f"    Actual: {actual:.1f}  |  Predicted: {predicted:.2f}  |  Error: {error:.2f}")

# 9. VISUALIZATION
print("\n9. Creating Visualizations...")

fig, axes = plt.subplots(1, 3, figsize=(16, 5))

# Plot 1: training loss (MSE)
axes[0].plot(train_losses, color='steelblue')
axes[0].set_title('RNN + Embedding: Training Loss (MSE)')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('MSE Loss (pain-level²)')
axes[0].grid(True)

# Plot 2: predicted vs actual scatter — regression diagnostic
# Points on y=x diagonal = perfect prediction
axes[1].scatter(y_test_np, test_preds_c, color='tomato', alpha=0.8,
                edgecolors='black', linewidths=0.5)
axes[1].plot([1, 10], [1, 10], 'k--', linewidth=1, label='Perfect prediction')
axes[1].set_xlabel('Actual Pain Level')
axes[1].set_ylabel('Predicted Pain Level')
axes[1].set_title('Predicted vs Actual (Test Set)')
axes[1].legend()
axes[1].grid(True)
axes[1].set_xlim(0.5, 10.5)
axes[1].set_ylim(0.5, 10.5)

# Plot 3: residuals — reveals systematic over/under-estimation
residuals = test_preds_c - y_test_np
axes[2].bar(range(len(residuals)), residuals,
            color=['green' if r >= 0 else 'red' for r in residuals], alpha=0.7)
axes[2].axhline(0, color='black', linewidth=1)
axes[2].set_xlabel('Test Sample Index')
axes[2].set_ylabel('Residual (Predicted − Actual)')
axes[2].set_title('Residuals on Test Set')
axes[2].grid(True, axis='y')

plt.tight_layout()
plt.show()

# 10. NEW PATIENT PREDICTION
print("\n10. Predicting for New Patients...")

def predict_new_sample(note, days, treatment, surgery):
    model.eval()
    with torch.no_grad():
        text_seq          = torch.LongTensor([text_to_sequence(note)])
        treatment_encoded = le_treatment.transform([treatment])[0]
        surgery_encoded   = le_surgery.transform([surgery])[0]
        num_features      = torch.FloatTensor([[days, treatment_encoded, surgery_encoded]])
        # Embedding lookup → RNN → FC → single scalar. No argmax, no search.
        raw = model(text_seq, num_features).item()
        return float(np.clip(raw, 1.0, 10.0))

test_cases = [
    ("I feel great today no pain",  5, "Physical Therapy", "No"),
    ("Horrible pain cannot sleep",  2, "Emergency",        "Yes"),
    ("Getting better slowly",       7, "Medication",       "No"),
]

for note, days, treatment, surgery in test_cases:
    pred = predict_new_sample(note, days, treatment, surgery)
    print(f"  '{note}'  →  Predicted Pain Level: {pred:.2f}")

print(f"\n{'='*60}")
print("RNN + Embedding Pain Level Regression Complete!")
print(f"{'='*60}")

# ═══════════════════════════════════════════════════════════════════════════════
# PART 2 — PRE-TRAINED EMBEDDINGS (GloVe)
# ═══════════════════════════════════════════════════════════════════════════════
#
# CAN WE USE PRE-TRAINED EMBEDDINGS?
# ─────────────────────────────────────────────────────────────────────────────
# Yes. Instead of initialising the embedding table randomly, we initialise it
# with vectors already trained on billions of words (Wikipedia, Common Crawl,
# news articles, etc.).  The vectors encode general-language semantics:
#   GloVe "pain"   ≈ GloVe "ache"   (close in vector space)
#   GloVe "severe" ≈ GloVe "intense" (close)
#   GloVe "comfortable" is far from both
#
# Two strategies once you have a pre-trained embedding matrix:
#
#   Strategy A — FROZEN:
#     embedding.weight.requires_grad = False
#     The embedding table is fixed throughout training.  Only the RNN and FC
#     layers update.  Faster training, fewer parameters.  Good when your
#     vocabulary overlaps well with the pre-training corpus and your dataset
#     is too small to fine-tune embeddings safely.
#
#   Strategy B — FINE-TUNED:
#     embedding.weight.requires_grad = True  (default)
#     GloVe vectors are the starting point; gradient descent adjusts them
#     for our specific pain-level task.  The model can specialise "severe"
#     to mean "high pain" rather than just "strong".
#
# WILL PRE-TRAINED EMBEDDINGS IMPROVE OUTCOMES ON THIS DATASET?
# ─────────────────────────────────────────────────────────────────────────────
# Almost certainly NOT significantly.  Here is why:
#
#   1. Tiny dataset (40 samples).  With so few examples, every model overfits
#      regardless of the starting point of the embeddings.
#
#   2. Small vocabulary (~130 words, max sequence length 10).  The random-
#      embedding model can learn adequate representations for all of them
#      from scratch in 100 epochs.
#
#   3. Domain mismatch.  GloVe is trained on Wikipedia + Gigaword (news).
#      Clinical note language ("excruciating", "throbbing", "stiff after
#      surgery") is underrepresented — the GloVe vectors for these words
#      may not capture their pain-specific meaning.
#      Purpose-built clinical embeddings (BioWordVec, ClinicalBERT) would
#      be a much better fit for medical NLP in production.
#
#   4. Short sequences (≤ 10 words).  The RNN has little context to exploit
#      regardless of which embeddings it starts from.
#
# Pre-trained embeddings tend to help most when:
#   • Your labelled dataset is small but your vocabulary overlaps the
#     pre-training corpus well.
#   • You have many rare words the model cannot learn from scratch.
#   • The task semantics align with general-language semantics
#     (sentiment analysis, topic classification, NLI).
#
# We demonstrate with GloVe-50 (50-dimensional vectors, Wikipedia + Gigaword,
# 6B tokens).  Downloaded automatically via gensim.downloader (~67 MB,
# cached on disk after the first run — subsequent runs are instant).
# ─────────────────────────────────────────────────────────────────────────────

print(f"\n{'='*60}")
print("PART 2 — Pre-Trained Embeddings (GloVe)")
print(f"{'='*60}")

# ── Helper: shared training loop ─────────────────────────────────────────────

def train_and_collect(model_to_train, epochs=EPOCHS, lr=LEARNING_RATE, label=""):
    """Train model on the shared train split; return list of per-epoch MSE losses."""
    opt  = optim.Adam(model_to_train.parameters(), lr=lr)
    crit = nn.MSELoss()   # regression loss
    losses = []
    model_to_train.train()
    for epoch in range(epochs):
        opt.zero_grad()
        preds = model_to_train(X_text_train, X_num_train)   # (batch,) floats
        loss  = crit(preds, y_train)
        loss.backward()
        opt.step()
        losses.append(loss.item())
        if (epoch + 1) % 20 == 0:
            print(f"  [{label}] Epoch {epoch+1}/{epochs}  MSE={loss.item():.4f}  RMSE={loss.item()**0.5:.4f}")
    return losses

def collect_metrics(model_to_eval, X_text, X_num, y_tensor):
    """Return MAE, RMSE, R² and raw predictions for a split."""
    model_to_eval.eval()
    with torch.no_grad():
        preds = np.clip(model_to_eval(X_text, X_num).numpy(), 1.0, 10.0)
    y_np = y_tensor.numpy()
    return {
        'mae'  : mean_absolute_error(y_np, preds),
        'rmse' : mean_squared_error(y_np, preds) ** 0.5,
        'r2'   : r2_score(y_np, preds),
        'preds': preds,
    }

# Re-evaluate the Part-1 random-embedding model so we can include it in the
# comparison table at the end.
m1_train = collect_metrics(model, X_text_train, X_num_train, y_train)
m1_test  = collect_metrics(model, X_text_test,  X_num_test,  y_test)

# ── Load GloVe via gensim ────────────────────────────────────────────────────

GLOVE_DIM = 50  # GloVe-50 uses 50-dimensional vectors

try:
    import gensim.downloader as gensim_dl
    GENSIM_AVAILABLE = True
except ImportError:
    GENSIM_AVAILABLE = False
    print("\n[!] gensim not installed.  Install it with:  pip install gensim")
    print("    Skipping pre-trained embedding comparison.")

if GENSIM_AVAILABLE:
    print("\nLoading GloVe-50 via gensim (first run downloads ~67 MB, then cached)...")
    glove = gensim_dl.load("glove-wiki-gigaword-50")

    # ── Build embedding matrix aligned to our word_to_idx vocabulary ─────────
    # Rows correspond to word indices; row 0 stays all-zeros (PAD token).
    # Words in our vocabulary that are also in GloVe get their GloVe vector.
    # Words not found in GloVe (OOV) keep the zero row — same as padding.
    embedding_matrix = np.zeros((VOCAB_SIZE, GLOVE_DIM), dtype=np.float32)
    found = 0
    oov_words = []
    for word, idx in word_to_idx.items():
        if word in glove:
            embedding_matrix[idx] = glove[word]
            found += 1
        elif word != '<PAD>':
            oov_words.append(word)

    print(f"  GloVe coverage: {found}/{VOCAB_SIZE} vocab words found in GloVe")
    if oov_words:
        print(f"  OOV (zero-initialised): {oov_words}")

    embedding_tensor = torch.FloatTensor(embedding_matrix)

    # ── Model definition ─────────────────────────────────────────────────────

    class PainLevelRNN_GloVe(nn.Module):
        """Same architecture as PainLevelRNN_Embedding but embedding is
        initialised from a pre-trained GloVe matrix instead of randomly.
        Output is a single regression scalar, not class logits.

        freeze=True  → embedding weights are fixed (Strategy A)
        freeze=False → embedding weights are fine-tuned (Strategy B)
        """
        def __init__(self, pretrained_matrix, hidden_dim,
                     freeze=False, num_features=3):
            super().__init__()
            _, embed_sz = pretrained_matrix.shape

            # nn.Embedding.from_pretrained loads the matrix into the weight
            # tensor and optionally sets requires_grad=False (freeze=True).
            self.embedding = nn.Embedding.from_pretrained(
                pretrained_matrix,
                freeze=freeze,      # False → fine-tune; True → keep fixed
                padding_idx=0,
            )
            self.rnn = nn.RNN(embed_sz, hidden_dim, batch_first=True)
            self.fc1 = nn.Linear(hidden_dim + num_features, 64)
            self.fc2 = nn.Linear(64, 32)
            self.fc3 = nn.Linear(32, 1)   # single scalar output — regression
            self.relu = nn.ReLU()

        def forward(self, text_seq, numerical_features):
            embedded      = self.embedding(text_seq)   # pre-trained or fine-tuned lookup
            rnn_out, _    = self.rnn(embedded)
            text_features = rnn_out[:, -1, :]
            combined      = torch.cat([text_features, numerical_features], dim=1)
            x = self.relu(self.fc1(combined))
            x = self.relu(self.fc2(x))
            return self.fc3(x).squeeze(1)   # (batch,) float scalar

    # ── Strategy A: Frozen GloVe ─────────────────────────────────────────────
    print("\n--- Strategy A: GloVe-50 FROZEN (embedding table fixed) ---")
    model_frozen = PainLevelRNN_GloVe(
        embedding_tensor, HIDDEN_DIM, freeze=True
    )
    frozen_params = sum(p.numel() for p in model_frozen.parameters() if p.requires_grad)
    print(f"  Trainable parameters: {frozen_params}  "
          f"(embedding table is frozen — {VOCAB_SIZE * GLOVE_DIM} params excluded)")
    losses_frozen = train_and_collect(model_frozen, label="Frozen GloVe")

    m2_train = collect_metrics(model_frozen, X_text_train, X_num_train, y_train)
    m2_test  = collect_metrics(model_frozen, X_text_test,  X_num_test,  y_test)

    # ── Strategy B: Fine-tuned GloVe ─────────────────────────────────────────
    print("\n--- Strategy B: GloVe-50 FINE-TUNED (embedding table updated) ---")
    model_finetuned = PainLevelRNN_GloVe(
        embedding_tensor, HIDDEN_DIM, freeze=False
    )
    ft_params = sum(p.numel() for p in model_finetuned.parameters() if p.requires_grad)
    print(f"  Trainable parameters: {ft_params}  "
          f"(includes embedding table — starts from GloVe, updated by gradient descent)")
    losses_finetuned = train_and_collect(model_finetuned, label="Fine-tuned GloVe")

    m3_train = collect_metrics(model_finetuned, X_text_train, X_num_train, y_train)
    m3_test  = collect_metrics(model_finetuned, X_text_test,  X_num_test,  y_test)

    # ── Comparison table ─────────────────────────────────────────────────────
    print(f"\n{'='*75}")
    print("MODEL COMPARISON (Regression Metrics)")
    print(f"{'='*75}")
    print(f"{'Model':<30} {'Train MAE':>10} {'Test MAE':>10} {'Test RMSE':>10} {'Test R²':>10}")
    print(f"{'-'*75}")
    rows = [
        ("Random embedding (Part 1)", m1_train['mae'], m1_test['mae'], m1_test['rmse'], m1_test['r2']),
        ("GloVe-50 Frozen",           m2_train['mae'], m2_test['mae'], m2_test['rmse'], m2_test['r2']),
        ("GloVe-50 Fine-tuned",       m3_train['mae'], m3_test['mae'], m3_test['rmse'], m3_test['r2']),
    ]
    for name, tr_mae, te_mae, te_rmse, te_r2 in rows:
        print(f"  {name:<28} {tr_mae:>10.3f} {te_mae:>10.3f} {te_rmse:>10.3f} {te_r2:>10.3f}")
    print(f"{'='*75}")
    print("""
Interpretation:
  • Lower MAE/RMSE = better. Higher R² = better (1.0 is perfect).
  • If GloVe models score similarly to the random model, the dataset is
    too small and domain-specific for GloVe vectors to transfer well.
  • Fine-tuned GloVe may overfit more than frozen GloVe with only 40 samples
    because it has more trainable parameters updating on very little data.
  • For real clinical NLP: use domain-specific embeddings (BioWordVec,
    ClinicalBERT) or fine-tune a medical BERT rather than GloVe.
""")

    # ── Visualisation ─────────────────────────────────────────────────────────
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Loss curves for GloVe strategies (MSE over epochs)
    ax = axes[0]
    ax.plot(losses_frozen,    label='GloVe Frozen',     linewidth=1.5)
    ax.plot(losses_finetuned, label='GloVe Fine-tuned', linewidth=1.5)
    ax.set_title('Pre-trained Embedding: Training Loss (MSE)')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('MSE Loss (pain-level²)')
    ax.legend()
    ax.grid(True)

    # Test MAE bar chart across all 3 models — lower is better
    ax = axes[1]
    model_names = ['Random\nEmbedding', 'GloVe\nFrozen', 'GloVe\nFine-tuned']
    test_maes   = [m1_test['mae'], m2_test['mae'], m3_test['mae']]
    colors      = ['steelblue', 'darkorange', 'seagreen']
    bars = ax.bar(model_names, test_maes, color=colors, width=0.5)
    ax.set_ylabel('Test MAE (pain-level units, lower = better)')
    ax.set_title('Test MAE: Random vs Pre-trained Embeddings')
    for bar, mae in zip(bars, test_maes):
        ax.text(bar.get_x() + bar.get_width() / 2, mae + 0.05,
                f'{mae:.2f}', ha='center', va='bottom', fontweight='bold')
    ax.grid(True, axis='y')

    plt.tight_layout()
    plt.show()
