# LSTM Doctor Notes Classifier — Learned Embedding Layer
#
# This is a direct variation of 07_lstm_doctornotes_classify.py.
# The ONLY architectural change is replacing one-hot word encoding with a
# trainable Embedding layer.  Everything else — data, labels, LSTM stack,
# evaluation — is identical so the two files can be compared side-by-side.
#
# BUSINESS PROBLEM (same as the original)
# ─────────────────────────────────────────────────────────────────────────────
# Automatically classify free-text SOAP physician notes into one of five
# diagnosis categories so billing staff receive an instant suggested code:
#   1. Upper Respiratory Infection  — cough, sore throat, runny nose
#   2. Migraine                     — headache, nausea, dizziness
#   3. Common Cold                  — congestion, sneezing, mild fever
#   4. Flu                          — fever, body aches, fatigue
#   5. COVID-19                     — fever, cough, loss of taste/smell
#
# WHAT CHANGED vs THE ONE-HOT VERSION (07_lstm_doctornotes_classify.py)
# ─────────────────────────────────────────────────────────────────────────────
#
#   Step removed:   tf.keras.utils.to_categorical(X_seq, num_classes=VOCAB_SIZE)
#                   One-hot conversion is no longer needed because the Embedding
#                   layer accepts raw integer indices directly.
#
#   Layer added:    Embedding(VOCAB_SIZE, EMBED_DIM, input_length=MAX_LEN)
#                   as the FIRST layer of the Sequential model.
#
#   Input to LSTM:  changed from VOCAB_SIZE-wide one-hot vectors
#                   to EMBED_DIM-wide dense learned vectors.
#
# ┌────────────────────────────────────────────────────────────────────────────┐
# │  HOW THE EMBEDDING LAYER WORKS IN THIS PIPELINE                           │
# │                                                                            │
# │  Tokeniser assigns each word a unique integer index (1 … VOCAB_SIZE-1).   │
# │  Index 0 is reserved for padding, index 1 is the OOV token.               │
# │                                                                            │
# │  Input to model: integer tensor of shape (batch, MAX_LEN)                 │
# │    e.g. [  7, 43, 12,  0,  0, ... ]   ← word indices, padded to 40       │
# │                                                                            │
# │  Embedding layer: a trainable weight matrix W of shape                    │
# │    (VOCAB_SIZE, EMBED_DIM)                                                 │
# │    Each row = the learned dense vector for one word.                       │
# │    For each index i in the sequence, the layer returns row W[i] —         │
# │    a simple table lookup, not a search or similarity computation.          │
# │                                                                            │
# │  Output of Embedding: (batch, MAX_LEN, EMBED_DIM)                         │
# │    e.g. (32, 40, 32) — same shape the LSTM expects, but dense.            │
# │                                                                            │
# │  LSTM then processes the sequence of 32-dim vectors instead of            │
# │  500-dim one-hot vectors → smaller weight matrices, faster training.      │
# │                                                                            │
# │  Gradient flows all the way back into the embedding table during           │
# │  backprop: words that appear in similar diagnostic contexts drift          │
# │  toward each other in EMBED_DIM-dimensional space automatically.           │
# └────────────────────────────────────────────────────────────────────────────┘
#
# ONE-HOT vs EMBEDDING — SIDE-BY-SIDE
# ─────────────────────────────────────────────────────────────────────────────
#
#   Aspect                  One-hot (07_lstm_...)    Embedding (this file)
#   ─────────────────────── ──────────────────────   ──────────────────────────
#   Input shape to LSTM     (batch, 40, 500)         (batch, 40, 32)
#   Words equidistant?      Yes — all orthogonal     No — similar words cluster
#   LSTM input weight W_x   64 × 500 = 32,000 params 64 × 32 = 2,048 params
#   New layer added         None                     Embedding: 500×32 = 16,000
#   Total model params      larger                   smaller
#   Preprocessing step      to_categorical needed    not needed — raw indices
#   Semantic structure       None                    Emerges from training
#   predict_diagnosis()     must call to_categorical plain integer sequence
#
# Note on total parameter count:
#   One-hot LSTM has a much larger W_x (input weight matrix) because each
#   time step is VOCAB_SIZE-wide.  The Embedding version trades that for a
#   dedicated lookup table (16,000 params) and a much smaller W_x (2,048).
#   Net effect: embedding model has significantly fewer total parameters.
# ─────────────────────────────────────────────────────────────────────────────

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout   # Embedding added
import tensorflow as tf
import os

# ── 1. Load data ──────────────────────────────────────────────────────────────

script_dir = os.path.dirname(os.path.abspath(__file__))
csv_path   = os.path.join(script_dir, "doctornotes.csv")
df         = pd.read_csv(csv_path)

print("Doctor Notes Classifier — Learned Embedding Layer")
print("=" * 55)
print(f"\nDataset: {df.shape[0]} notes, {df['diagnosis'].nunique()} diagnosis classes")
print(f"Class distribution:\n{df['diagnosis'].value_counts().to_string()}")
print("\nSample note:")
print(df['note'].iloc[0])

# ── 2. Tokenise text ──────────────────────────────────────────────────────────

VOCAB_SIZE = 500   # same as original — covers all words + OOV headroom
MAX_LEN    = 40    # same as original — longest note length
EMBED_DIM  = 32    # NEW: each word maps to a 32-float dense vector.
                   # Rule of thumb: ~4th root of vocab size, or 32–64 for small corpora.
                   # Larger embed_dim → more expressive but more parameters to train.

tokenizer = Tokenizer(num_words=VOCAB_SIZE, oov_token="<OOV>")
tokenizer.fit_on_texts(df['note'])

# texts_to_sequences → integer indices; pad_sequences → fixed length (MAX_LEN,)
X_seq = tokenizer.texts_to_sequences(df['note'])
X_seq = pad_sequences(X_seq, maxlen=MAX_LEN, padding='post', truncating='post')
# X_seq shape: (50, 40) — integer indices in range [0, VOCAB_SIZE)

# KEY DIFFERENCE FROM ONE-HOT VERSION:
# In 07_lstm_doctornotes_classify.py the next step was:
#   X = tf.keras.utils.to_categorical(X_seq, num_classes=VOCAB_SIZE)
#   → shape (50, 40, 500)   — 3-D float tensor, memory-heavy
#
# Here we feed X_seq directly to the model as-is:
#   X = X_seq  →  shape (50, 40)   — 2-D integer tensor
# The Embedding layer performs the index → vector mapping internally.
X = X_seq
print(f"\nInteger sequence input shape : {X.shape}  (samples, timesteps)")
print(f"  (one-hot version shape was : ({X.shape[0]}, {MAX_LEN}, {VOCAB_SIZE}))")
print(f"  Memory saving: {X.shape[0]*MAX_LEN*VOCAB_SIZE*4 / 1024:.0f} KB → "
      f"{X.nbytes / 1024:.0f} KB for the input tensor alone")

# ── 3. Encode labels ──────────────────────────────────────────────────────────

label_encoder = LabelEncoder()
y = label_encoder.fit_transform(df['diagnosis'])
print(f"\nLabel classes: {list(label_encoder.classes_)}")

# ── 4. Train / test split ─────────────────────────────────────────────────────

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print(f"\nTrain samples: {len(X_train)}  |  Test samples: {len(X_test)}")

# ── 5. Build model (with Embedding layer) ─────────────────────────────────────
#
# Architecture change from one-hot version:
#   BEFORE:  LSTM(64, input_shape=(MAX_LEN, VOCAB_SIZE))   ← first LSTM sees 500 inputs/step
#   AFTER:   Embedding(...)  →  LSTM(64)                   ← first LSTM sees 32 inputs/step
#
# The Embedding layer replaces both the to_categorical() preprocessing step AND
# the wide input dimension.  It is fully trainable — its weights start random
# and are updated by gradient descent alongside the LSTM and Dense weights.
#
# mask_zero=True tells the Embedding (and downstream LSTM) to ignore padding
# tokens (index 0) — they contribute nothing to the hidden state, avoiding
# the model learning from artificial padding context.

model = Sequential([
    # Embedding: integer index sequence → dense vector sequence
    # Input shape:  (batch, MAX_LEN)              — integer indices
    # Output shape: (batch, MAX_LEN, EMBED_DIM)   — dense float vectors
    # Parameters:   VOCAB_SIZE × EMBED_DIM = 500 × 32 = 16,000
    Embedding(VOCAB_SIZE, EMBED_DIM, input_length=MAX_LEN, mask_zero=True),

    # LSTM stack — identical to one-hot version, just smaller input width
    LSTM(64, return_sequences=True),
    LSTM(32),
    Dense(16, activation='relu'),
    Dropout(0.5),
    Dense(5, activation='softmax'),   # 5 diagnosis classes
])

model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy'],
)

model.summary()

# Print parameter comparison note after summary
print("\nParameter note:")
print(f"  One-hot LSTM input weight W_x : 64 × {VOCAB_SIZE} = {64*VOCAB_SIZE:,} params")
print(f"  Embedding LSTM input weight W_x: 64 × {EMBED_DIM}  = {64*EMBED_DIM:,} params")
print(f"  Embedding table itself         : {VOCAB_SIZE} × {EMBED_DIM} = {VOCAB_SIZE*EMBED_DIM:,} params")
print(f"  Net reduction in LSTM weights  : {64*VOCAB_SIZE - 64*EMBED_DIM:,} params saved")

# ── 6. Train ──────────────────────────────────────────────────────────────────

print("\nTraining model...")
history = model.fit(
    X_train, y_train,
    epochs=10,
    batch_size=8,
    validation_split=0.2,
    verbose=1,
)

# ── 7. Evaluate ───────────────────────────────────────────────────────────────

loss, acc = model.evaluate(X_test, y_test, verbose=0)
print(f"\nTest loss    : {loss:.4f}")
print(f"Test accuracy: {acc:.2f}")

y_pred_probs = model.predict(X_test, verbose=0)
y_pred       = np.argmax(y_pred_probs, axis=1)
class_names  = label_encoder.classes_

print("\nClassification Report:")
print(classification_report(y_test, y_pred,
                             labels=list(range(len(class_names))),
                             target_names=class_names,
                             zero_division=0))

cm = confusion_matrix(y_test, y_pred, labels=list(range(len(class_names))))
print("Confusion Matrix (rows=actual, cols=predicted):")
print(cm)

# ── 8. Visualise ──────────────────────────────────────────────────────────────

fig, axes = plt.subplots(1, 3, figsize=(16, 4))

axes[0].plot(history.history['accuracy'],     label='Train')
axes[0].plot(history.history['val_accuracy'], label='Validation')
axes[0].set_title('Accuracy over Epochs (Embedding)')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('Accuracy')
axes[0].legend()
axes[0].grid(True)

axes[1].plot(history.history['loss'],     label='Train')
axes[1].plot(history.history['val_loss'], label='Validation')
axes[1].set_title('Loss over Epochs (Embedding)')
axes[1].set_xlabel('Epoch')
axes[1].set_ylabel('Loss')
axes[1].legend()
axes[1].grid(True)

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=class_names)
disp.plot(ax=axes[2], colorbar=False, xticks_rotation=30)
axes[2].set_title('Confusion Matrix — Test Set')

plt.tight_layout()
plt.show()

# ── 9. Inspect learned embedding vectors ──────────────────────────────────────
#
# After training we can pull rows out of the Embedding weight matrix to see
# whether clinically similar words drifted toward each other in the 32-D space.
# This is NOT similarity search — it is just inspecting the learned table.
# In production you would skip this block; it is here for teaching purposes.

print("\nInspecting learned embedding vectors (sample words):")
embedding_weights = model.layers[0].get_weights()[0]   # shape (VOCAB_SIZE, EMBED_DIM)
word_index = tokenizer.word_index

sample_words = ['cough', 'fever', 'headache', 'fatigue', 'nausea', 'throat']
for word in sample_words:
    idx = word_index.get(word)
    if idx is not None and idx < VOCAB_SIZE:
        vec = embedding_weights[idx]
        # Show first 6 dimensions for readability
        snippet = ', '.join(f'{v:+.3f}' for v in vec[:6])
        print(f"  '{word}' (idx {idx:3d}): [{snippet}, ...]")
    else:
        print(f"  '{word}': not in vocabulary or index out of range")

print("\n  Words like 'cough'/'fever' should show some similarity;")
print("  'headache'/'nausea' (migraine cluster) should differ from the rest.")
print("  With only 50 training notes structure is subtle but present.")

# ── 10. Predict on a new note ─────────────────────────────────────────────────
#
# KEY DIFFERENCE FROM ONE-HOT VERSION:
#   One-hot predict_diagnosis() called to_categorical() before model.predict().
#   Here we pass the integer sequence directly — the Embedding layer handles
#   the index → vector mapping internally as part of the forward pass.

def predict_diagnosis(note_text):
    seq    = tokenizer.texts_to_sequences([note_text])
    padded = pad_sequences(seq, maxlen=MAX_LEN, padding='post', truncating='post')
    # No to_categorical() here — model accepts integer indices directly
    probs  = model.predict(padded, verbose=0)
    idx    = np.argmax(probs[0])
    return label_encoder.inverse_transform([idx])[0], probs[0][idx]

test_note = "Patient presents with fever, cough, and shortness of breath. Vitals stable."
diagnosis, confidence = predict_diagnosis(test_note)
print(f"\nTest note   : {test_note}")
print(f"Predicted   : {diagnosis}")
print(f"Confidence  : {confidence:.2f}")
