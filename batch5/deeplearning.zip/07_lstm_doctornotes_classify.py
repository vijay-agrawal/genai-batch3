# LSTM Doctor Notes Classifier — One-Hot Word Encoding
#
# BUSINESS PROBLEM
# ─────────────────────────────────────────────────────────────────────────────
# A clinic generates free-text SOAP notes (Subjective / Objective / Assessment /
# Plan — the standard 4-section format physicians use to document a patient visit:
#   Subjective  : what the patient reports — symptoms, history, complaints
#   Objective   : measurable findings — vitals, lab results, physical exam
#   Assessment  : the clinician's diagnosis or differential
#   Plan        : treatment, prescriptions, follow-up instructions)
# and structured encounter summaries
# for every patient visit.  Manually assigning a diagnosis code (ICD-style)
# is time-consuming and error-prone.  This model automatically classifies
# each note into one of five diagnosis categories so that billing staff get
# a suggested code instantly and physicians only need to confirm or override.
#
# The five classes in this dataset:
#   1. Upper Respiratory Infection  — cough, sore throat, runny nose
#   2. Migraine                     — headache, nausea, dizziness
#   3. Common Cold                  — congestion, sneezing, mild fever
#   4. Flu                          — fever, body aches, fatigue
#   5. COVID-19                     — fever, cough, loss of taste/smell
#
# SAMPLE ROWS FROM doctornotes.csv
# ─────────────────────────────────────────────────────────────────────────────
#   note                                                         diagnosis
#   ─────────────────────────────────────────────────────────    ────────────────────────────
#   "Name: Billy Perez\nAge: 58\nSymptoms: cough, sore          Upper Respiratory Infection
#    throat, runny nose\nDx: URI\nRx: Azithromycin..."
#
#   "Patient Donna Golden (35y/o) presents with headache,       Migraine
#    nausea, dizziness. Prescribed Rizatriptan..."
#
#   "Saw Jennifer Miller today. 55yo complaining of fever,      Flu
#    body aches, fatigue. Diagnosed with Flu. Tamiflu..."
#
# ENCODING APPROACH — ONE-HOT WORDS (no Embedding layer)
# ─────────────────────────────────────────────────────────────────────────────
# Each note is first tokenised into a fixed-length sequence of word indices
# (length MAX_LEN=40).  Every index is then replaced by a one-hot vector of
# length VOCAB_SIZE — a vector of all zeros except a single 1 at the word's
# position.  The LSTM therefore receives a 3-D tensor of shape:
#
#   (batch, MAX_LEN, VOCAB_SIZE)
#
# and processes it one one-hot vector per time step.
#
# This is the "raw" representation that an Embedding layer improves upon:
#
#   One-hot (this file):            Embedding layer:
#   ─────────────────────────────   ──────────────────────────────────────
#   VOCAB_SIZE-dim sparse vector    embed_dim-dim dense vector (e.g. 32)
#   Every pair of words equally     Similar words end up near each other
#   distant (orthogonal vectors)    (learned by gradient descent)
#   Input size: 500 floats/step     Input size: 32 floats/step
#   No semantic structure           Semantic structure emerges from training
#
# With only 50 notes and a ~500-word vocabulary the one-hot model is still
# practical.  At scale (large vocab, long documents) the embedding layer
# becomes essential for memory and generalisation.
# ─────────────────────────────────────────────────────────────────────────────

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import tensorflow as tf
import os

# ── 1. Load data ──────────────────────────────────────────────────────────────

script_dir = os.path.dirname(os.path.abspath(__file__))
csv_path   = os.path.join(script_dir, "doctornotes.csv")
df         = pd.read_csv(csv_path)

print("Doctor Notes Classifier — One-Hot Word Encoding")
print("=" * 55)
print(f"\nDataset: {df.shape[0]} notes, {df['diagnosis'].nunique()} diagnosis classes")
print(f"Class distribution:\n{df['diagnosis'].value_counts().to_string()}")
print("\nSample note:")
print(df['note'].iloc[0])

# ── 2. Tokenise text ──────────────────────────────────────────────────────────

# With 50 notes of 16-35 words each, the true vocabulary is ~300-400 words.
# VOCAB_SIZE=500 comfortably covers all unique words plus the OOV token.
# MAX_LEN=40 covers the longest note in the dataset without wasted padding.
VOCAB_SIZE = 500
MAX_LEN    = 40

tokenizer = Tokenizer(num_words=VOCAB_SIZE, oov_token="<OOV>")
tokenizer.fit_on_texts(df['note'])

# texts_to_sequences: each note → list of integer word indices
# pad_sequences: pad/truncate to MAX_LEN so all inputs are the same length
X_seq = tokenizer.texts_to_sequences(df['note'])
X_seq = pad_sequences(X_seq, maxlen=MAX_LEN, padding='post', truncating='post')
# X_seq shape: (50, 40) — integer indices in range [0, VOCAB_SIZE)

# ── 3. One-hot encode every word index ───────────────────────────────────────
#
# tf.keras.utils.to_categorical converts each integer index to a VOCAB_SIZE-dim one-hot vector.
# Result shape: (num_samples, MAX_LEN, VOCAB_SIZE)
#   e.g. index 7 ("cough") → [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, ...]
#
# This is the direct input to the LSTM — no Embedding layer needed.
# Memory: 50 × 40 × 500 × float32 = ~4 MB (manageable for this dataset).
X = tf.keras.utils.to_categorical(X_seq, num_classes=VOCAB_SIZE)
print(f"\nOne-hot encoded input shape: {X.shape}  (samples, timesteps, vocab)")

# ── 4. Encode labels ──────────────────────────────────────────────────────────

label_encoder = LabelEncoder()
y = label_encoder.fit_transform(df['diagnosis'])
print(f"Label classes: {list(label_encoder.classes_)}")

# ── 5. Train / test split ─────────────────────────────────────────────────────

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print(f"\nTrain samples: {len(X_train)}  |  Test samples: {len(X_test)}")

# ── 6. Build model (no Embedding layer) ───────────────────────────────────────
#
# The first LSTM layer receives (MAX_LEN, VOCAB_SIZE) directly.
# Compared to the embedding version, each time-step input is 500-wide
# instead of 32-wide, so the LSTM's input weight matrix W_x is much larger.
# This is the core trade-off: one-hot is simple but memory/compute heavy.

model = Sequential([
    # Input: (batch, MAX_LEN, VOCAB_SIZE) — sequence of one-hot word vectors
    LSTM(64, return_sequences=True, input_shape=(MAX_LEN, VOCAB_SIZE)),
    LSTM(32),
    Dense(16, activation='relu'),
    Dropout(0.5),
    Dense(5, activation='softmax'),   # 5 diagnosis classes
])

model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy'],
)

model.summary()

# ── 7. Train ──────────────────────────────────────────────────────────────────

print("\nTraining model...")
history = model.fit(
    X_train, y_train,
    epochs=10,
    batch_size=8,
    validation_split=0.2,
    verbose=1,
)

# ── 8. Evaluate ───────────────────────────────────────────────────────────────

# 8a. Overall loss & accuracy on the held-out test set
loss, acc = model.evaluate(X_test, y_test, verbose=0)
print(f"\nTest loss    : {loss:.4f}")
print(f"Test accuracy: {acc:.2f}")

# 8b. Per-class precision, recall, F1
#     Accuracy alone is misleading for imbalanced multi-class problems.
#     classification_report breaks down performance per diagnosis.
y_pred_probs = model.predict(X_test, verbose=0)
y_pred       = np.argmax(y_pred_probs, axis=1)
class_names  = label_encoder.classes_

print("\nClassification Report:")
# labels= ensures all 5 classes appear even if some are absent from the small test set
print(classification_report(y_test, y_pred,
                             labels=list(range(len(class_names))),
                             target_names=class_names,
                             zero_division=0))

# 8c. Confusion matrix — shows which diagnoses get confused with each other
cm = confusion_matrix(y_test, y_pred, labels=list(range(len(class_names))))
print("Confusion Matrix (rows=actual, cols=predicted):")
print(cm)

# 8d. Training history — spot overfitting by comparing train vs val accuracy
fig, axes = plt.subplots(1, 3, figsize=(16, 4))

axes[0].plot(history.history['accuracy'],     label='Train')
axes[0].plot(history.history['val_accuracy'], label='Validation')
axes[0].set_title('Accuracy over Epochs')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('Accuracy')
axes[0].legend()
axes[0].grid(True)

axes[1].plot(history.history['loss'],     label='Train')
axes[1].plot(history.history['val_loss'], label='Validation')
axes[1].set_title('Loss over Epochs')
axes[1].set_xlabel('Epoch')
axes[1].set_ylabel('Loss')
axes[1].legend()
axes[1].grid(True)

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=class_names)
disp.plot(ax=axes[2], colorbar=False, xticks_rotation=30)
axes[2].set_title('Confusion Matrix — Test Set')

plt.tight_layout()
plt.show()

# ── 9. Predict on a new note ─────────────────────────────────────────────────

def predict_diagnosis(note_text):
    seq    = tokenizer.texts_to_sequences([note_text])
    padded = pad_sequences(seq, maxlen=MAX_LEN, padding='post', truncating='post')
    # One-hot encode the single note before feeding to the model
    onehot = tf.keras.utils.to_categorical(padded, num_classes=VOCAB_SIZE)
    probs  = model.predict(onehot, verbose=0)
    idx    = np.argmax(probs[0])
    return label_encoder.inverse_transform([idx])[0], probs[0][idx]

test_note = "Patient presents with fever, cough, and shortness of breath. Vitals stable."
diagnosis, confidence = predict_diagnosis(test_note)
print(f"\nTest note   : {test_note}")
print(f"Predicted   : {diagnosis}")
print(f"Confidence  : {confidence:.2f}")
