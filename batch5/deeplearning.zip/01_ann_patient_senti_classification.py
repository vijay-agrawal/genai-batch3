import os
import numpy as np
import pandas as pd
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

df = pd.read_csv(os.path.join(os.path.dirname(__file__), 'patient_pain_data.csv'))

# Preprocessing
vectorizer = TfidfVectorizer(max_features=20)
X_text = vectorizer.fit_transform(df["Patient Notes"]).toarray()

encoder = OneHotEncoder(sparse_output=False, drop="first")
X_treatment = encoder.fit_transform(df[["Treatment Type"]])
X_surgery = (df["Surgery Done"] == "Yes").astype(int).values.reshape(-1, 1)
X_days = df["Days Admitted"].values.reshape(-1, 1)

scaler = StandardScaler()
X_days = scaler.fit_transform(X_days)

# Combine features
X = np.hstack((X_text, X_treatment, X_surgery, X_days))
y = df["Pain Level"].values.reshape(-1, 1)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Convert to tensors for TensorFlow
X_train_tf = X_train.astype(np.float32)
y_train_tf = y_train.astype(np.float32)
X_test_tf = X_test.astype(np.float32)
y_test_tf = y_test.astype(np.float32)

# Define the ANN model using TensorFlow/Keras
model_tf = keras.Sequential([
    layers.Dense(32, activation='relu', input_shape=(X_train_tf.shape[1],)),
    layers.Dense(16, activation='relu'),
    layers.Dense(8, activation='relu'),
    layers.Dense(1, activation='linear')  # Regression output for pain level
])

# Compile the model
model_tf.compile(optimizer='adam', loss='mean_squared_error', metrics=['mae'])

# Train the model
history_tf = model_tf.fit(X_train_tf, y_train_tf, epochs=50, batch_size=5, validation_data=(X_test_tf, y_test_tf), verbose=1)

# Evaluate the model
loss_tf, mae_tf = model_tf.evaluate(X_test_tf, y_test_tf)
print(f"Test Loss: {loss_tf}, Mean Absolute Error: {mae_tf}")


#
# Mean Absolute Error (MAE): 2.41
# On average, your model's pain level predictions are off by about 2.4 units from the actual value. 
# Being off by ~2.4 on a 1-10 scale is fairly rough. 

# Test Loss (MSE): 6.90
# This is the Mean Squared Error. It penalizes larger errors more heavily. 
# The square root (~2.63) gives you a sense of the "typical" error in the same units as pain level, 
# similar to MAE but weighted toward bigger mistakes.
# Why squared?
#It penalizes large errors disproportionately. A prediction off by 4 contributes 16 to MSE, while one off by 2 contributes only 4 — so big misses hurt a lot more.
# MSE itself (6.90) is in squared units, so it's not directly intuitive.
# Take the square root to get RMSE (Root MSE): √6.90 ≈ 2.63 — this is back in the original pain level units and easier to interpret.
# The relationship between MAE and RMSE tells you about your error distribution:

# Case 1: RMSE ≈ MAE (close together)

# Errors are consistent across predictions
# The model is uniformly off by a similar amount for all samples
# No major outlier predictions
# Case 2: RMSE >> MAE (RMSE much higher)

# Some predictions have very large errors pulling RMSE up
# The model works well for most patients but badly misses on a few
# Investigate those outlier cases — they may have unusual features
# Case 3: RMSE < MAE

# This cannot happen mathematically. RMSE is always ≥ MAE.
# The bounds:

# Best case: RMSE = MAE (all errors identical)
# Worst case: RMSE = MAE × √n (one huge error, rest zero)
# Your model:

# Metric	Value
# MAE	2.41
# RMSE	2.63
# Ratio (RMSE/MAE)	1.09
# A ratio of 1.09 is quite close to 1, which means your errors are fairly uniform — the model isn't making wild predictions on a few patients. It's consistently off by ~2.4 units across the board, which suggests the model needs better features or more data rather than outlier handling.



# What to do next:

# Since the error is too high relative to your scale, consider: 
# more data (this is the most likely cause of high error), 
# more features, 
# tuning epochs/architecture, or trying different max_features in TF-IDF