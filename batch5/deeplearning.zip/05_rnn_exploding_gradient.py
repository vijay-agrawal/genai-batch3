import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, Dense
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt

# Set random seed for reproducibility
np.random.seed(42)
tf.random.set_seed(42)

# Generate synthetic ICU patient data
num_samples = 2000  # Number of patients
sequence_length = 48  # 48 hourly readings
num_features = 5  # Heart rate, BP, Oxygen, Temperature, WBC count

# Generate random health records (normalized values between 0 and 1)
X_data = np.random.rand(num_samples, sequence_length, num_features)

# Generate synthetic labels: 0 (No Sepsis), 1 (Sepsis)
y_data = np.random.choice([0, 1], size=(num_samples,))

# Split data into training and testing sets
split_ratio = 0.8
split_index = int(num_samples * split_ratio)

X_train, X_test = X_data[:split_index], X_data[split_index:]
y_train, y_test = y_data[:split_index], y_data[split_index:]

# Define RNN model without gradient clipping (to observe exploding gradients)
model_exploding = Sequential([
    SimpleRNN(64, activation='relu', return_sequences=True, input_shape=(sequence_length, num_features)),
    SimpleRNN(32, activation='relu'),
    Dense(1, activation='sigmoid')  # Binary classification (Sepsis: Yes/No)
])

# Use Adam optimizer without gradient clipping (which may cause exploding gradients)
optimizer_exploding = Adam(learning_rate=0.001)

# Compile the model
model_exploding.compile(optimizer=optimizer_exploding, loss='binary_crossentropy', metrics=['accuracy'])

# Train model and capture loss values
history_exploding = model_exploding.fit(X_train, y_train, epochs=30, batch_size=32, validation_data=(X_test, y_test), verbose=1)

# Plot training loss to observe exploding gradients
plt.figure(figsize=(8, 5))
plt.plot(history_exploding.history['loss'], label="Training Loss")
plt.plot(history_exploding.history['val_loss'], label="Validation Loss")
plt.yscale("log")  # Log scale to better observe divergence
plt.xlabel("Epochs")
plt.ylabel("Loss")
plt.title("Exploding Gradient Effect: Training Loss Over Epochs")
plt.legend()
plt.show()
