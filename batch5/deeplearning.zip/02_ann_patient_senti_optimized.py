import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Load dataset
df = pd.read_csv('genaitraining/deeplearning/patient_pain_data.csv')

# Tokenization and Embedding for Patient Notes
tokenizer = Tokenizer(num_words=5000, oov_token="<OOV>")
tokenizer.fit_on_texts(df["Patient Notes"].astype(str))
X_text = tokenizer.texts_to_sequences(df["Patient Notes"].astype(str))
X_text = pad_sequences(X_text, maxlen=50, padding='post', truncating='post')

encoder = OneHotEncoder(sparse_output=False, drop="first")
X_treatment = encoder.fit_transform(df[["Treatment Type"]])
X_surgery = (df["Surgery Done"] == "Yes").astype(int).values.reshape(-1, 1)
X_days = df["Days Admitted"].values.reshape(-1, 1)

scaler = StandardScaler()
X_days = scaler.fit_transform(X_days)

# Combine features
X = np.hstack((X_treatment, X_surgery, X_days))
y = df["Pain Level"].values.reshape(-1, 1)

# Train-test split
X_train_text, X_test_text, X_train, X_test, y_train, y_test = train_test_split(X_text, X, y, test_size=0.2, random_state=42)

# Convert data to TensorFlow format
X_train_tf = X_train.astype(np.float32)
y_train_tf = y_train.astype(np.float32)
X_test_tf = X_test.astype(np.float32)
y_test_tf = y_test.astype(np.float32)

# Define ANN model with Embeddings
input_text = layers.Input(shape=(50,))
embedding = layers.Embedding(input_dim=5000, output_dim=16, input_length=50)(input_text)
flatten = layers.Flatten()(embedding)

input_numeric = layers.Input(shape=(X_train_tf.shape[1],))
concat = layers.concatenate([flatten, input_numeric])

hidden = layers.Dense(32, activation='relu')(concat)
hidden = layers.Dense(16, activation='relu')(hidden)
hidden = layers.Dense(8, activation='relu')(hidden)
output = layers.Dense(1, activation='linear')(hidden)

model_tf = keras.Model(inputs=[input_text, input_numeric], outputs=output)

# Compile model
model_tf.compile(optimizer='adam', loss='mean_squared_error', metrics=['mae'])

# Train the model
history_tf = model_tf.fit([X_train_text, X_train_tf], y_train_tf, epochs=50, batch_size=5, validation_data=([X_test_text, X_test_tf], y_test_tf), verbose=1)

# Predictions
y_pred = model_tf.predict([X_test_text, X_test_tf])

# Calculate Metrics
mse = mean_squared_error(y_test_tf, y_pred)
mae = mean_absolute_error(y_test_tf, y_pred)

print(f"Test Loss (MSE): {mse:.4f}")
print(f"Mean Absolute Error (MAE): {mae:.4f}")

# Baseline Comparison (Predicting Mean Pain Level)
y_baseline = np.full_like(y_test_tf, np.mean(y_train_tf))
baseline_mse = mean_squared_error(y_test_tf, y_baseline)
baseline_mae = mean_absolute_error(y_test_tf, y_baseline)

print(f"Baseline MSE (Predicting Mean Pain Level): {baseline_mse:.4f}")
print(f"Baseline MAE: {baseline_mae:.4f}")

# Performance Summary
if mae < baseline_mae:
    print("The ANN model outperforms the baseline and makes better predictions!")
else:
    print("The ANN model is not significantly better than predicting the mean pain level. Consider tuning.")
