// Run them on Neo4j Browser Query Console against the patient demo database.
// https://console.neo4j.io/
// These can be run on any Neo4j instance with the patient demo dataset loaded.
// Load the dataset first by running kg/01create_patientdb.cypher
// ======================================================


// ─────────────────────────────────────────────────────────────────────────────
// 1. Patient "clinical snapshot"
// "Give me everything relevant about patient with id P_002 before I see them."
//
// WHY GRAPH BEATS SQL:
//   SQL needs 4–5 JOINs (patients→encounters→diagnoses, encounters→medications,
//   notes→encounters), a GROUP BY across multiple dimensions, and nested
//   subqueries to produce the nested structure (encounters containing their
//   diagnoses, meds, and notes). The output is flat rows that application code
//   must reassemble. Cypher traverses the same relationships naturally and
//   returns a single nested document — no reassembly needed.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Anchor on one patient:
//     MATCH (p:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e:Encounter)
//     Walks from the parameterised patient directly to all their encounters.
//
//   Step 2 — OPTIONAL MATCH branches gather each encounter's sub-data:
//     (e)-[:HAS_DIAGNOSIS]->(d)          → ICD-10 codes for this visit
//     (e)-[pr:PRESCRIBED]->(m)           → medications (dose/freq on the rel.)
//     (n)-[:ABOUT_ENCOUNTER]->(e)        → clinical notes attached to visit
//     OPTIONAL avoids dropping encounters that lack one of these (like SQL LEFT JOIN).
//
//   Step 3 — First WITH aggregates within each encounter:
//     collect(DISTINCT {...}) groups diagnoses, meds, notes into sub-lists
//     so each encounter row carries its own nested arrays.
//     ORDER BY e.date DESC sorts encounters newest-first before the next step.
//
//   Step 4 — Second WITH rolls all encounters into one list per patient:
//     collect({enc_id, date, ..., diagnoses, medications, notes}) AS encounters
//
//   Step 5 — RETURN builds the final JSON-like snapshot document.
// ─────────────────────────────────────────────────────────────────────────────
:param pid => 'P_002'
MATCH (p:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e:Encounter)
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
OPTIONAL MATCH (e)-[pr:PRESCRIBED]->(m:Medication)
OPTIONAL MATCH (n:ClinicalNote)-[:ABOUT_ENCOUNTER]->(e)
WITH p, e,
     collect(DISTINCT {icd10:d.icd10, name:d.name}) AS dx,
     collect(DISTINCT {rxnorm:m.rxnorm, name:m.name, dose:pr.dose, frequency:pr.frequency}) AS meds,
     collect(DISTINCT {note_id:n.note_id, text:substring(n.text,0,180)}) AS notes
ORDER BY e.date DESC
WITH p, collect({
  enc_id:e.enc_id, date:e.date, reason:e.reason,
  bp_systolic:e.bp_systolic, bp_diastolic:e.bp_diastolic, hba1c:e.hba1c,
  diagnoses:dx, medications:meds, notes:notes
}) AS encounters
RETURN {
  patient: {patient_id:p.patient_id, name:p.name, dob:p.dob, sex:p.sex},
  encounters: encounters
} AS patient_snapshot;


// ─────────────────────────────────────────────────────────────────────────────
// 2. "Newly hypertensive" patients in last 90 days (first-ever I10)
// "Which patients were newly diagnosed with hypertension recently?"
//
// WHY GRAPH BEATS SQL:
//   Detecting "first-ever occurrence" in SQL requires a correlated NOT EXISTS
//   subquery or a window function (MIN over a partitioned set) followed by a
//   second pass to exclude anyone with a prior record. Both approaches are
//   verbose. In Cypher, the pattern reads as: "find the earliest I10 encounter,
//   then optionally match any older I10 encounter — if none exist, count = 0."
//   The negative structural test (no prior relationship) is a first-class
//   graph concept.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Traverse to recent I10 diagnoses:
//     MATCH Patient→Encounter→Diagnosis {icd10:'I10'}
//     WHERE e.date >= date() - duration('P90D')   ← last 90 days
//
//   Step 2 — Find each patient's earliest qualifying encounter:
//     WITH p, min(e.date) AS first_i10_date
//     This is a per-patient earliest date, not a global min.
//
//   Step 3 — Check for any PRIOR I10 encounter (the "first-ever" gate):
//     OPTIONAL MATCH the same patient's I10 encounters where date < first_i10_date.
//     OPTIONAL means patients with no prior encounter produce count = 0.
//
//   Step 4 — Filter to true new diagnoses:
//     WHERE prior_count = 0   ← no historical HTN encounters exist
//
//   Step 5 — Return patient name + first diagnosis date, sorted newest first.
// ─────────────────────────────────────────────────────────────────────────────
MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)-[:HAS_DIAGNOSIS]->(d:Diagnosis {icd10:'I10'})
WHERE e.date >= date() - duration('P90D')
WITH p, min(e.date) AS first_i10_date
OPTIONAL MATCH (p)-[:HAD_ENCOUNTER]->(e2:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:'I10'})
WHERE e2.date < first_i10_date
WITH p, first_i10_date, count(e2) AS prior_count
WHERE prior_count = 0
RETURN p.patient_id, p.name, first_i10_date
ORDER BY first_i10_date DESC;


// ─────────────────────────────────────────────────────────────────────────────
// 3. Patients with uncontrolled hypertension (BP > 140/90) in last 30 days
// Use: clinical quality monitoring
//
// WHY GRAPH BEATS SQL:
//   In SQL this is a straightforward JOIN + WHERE, but vital-sign data typically
//   lives in a separate vitals table requiring another JOIN. In the graph model,
//   vitals are stored as properties directly on the Encounter node, so the
//   traversal Patient→Encounter naturally reaches bp_systolic / bp_diastolic
//   without an extra table hop. Schema flexibility also lets you add new vital
//   fields without an ALTER TABLE migration.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Traverse Patient→Encounter:
//     MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)
//
//   Step 2 — Filter encounter by date and both BP thresholds simultaneously:
//     WHERE e.date >= date() - duration('P30D')
//       AND e.bp_systolic > 140
//       AND e.bp_diastolic > 90
//     All three conditions must be true on the same encounter node.
//
//   Step 3 — Return patient and encounter details sorted by most recent.
// ─────────────────────────────────────────────────────────────────────────────
MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)
WHERE e.date >= date() - duration('P30D')
  AND e.bp_systolic > 140
  AND e.bp_diastolic > 90
RETURN p.patient_id, p.name, e.enc_id, e.date, e.bp_systolic, e.bp_diastolic
ORDER BY e.date DESC;


// ─────────────────────────────────────────────────────────────────────────────
// 4. Providers prescribing Metformin (rxnorm:860975) more than 5 times in last 6 months
// Use: identify high-volume prescribers for review
//
// WHY GRAPH BEATS SQL:
//   SQL needs a 3-way JOIN (providers → encounters → medications), a GROUP BY
//   provider_id, and a HAVING clause on the count. Crucially, prescription
//   metadata (dose, frequency) lives on a separate prescriptions join table.
//   In the graph, PRESCRIBED is a direct relationship between Encounter and
//   Medication, and the count is simply how many such relationships exist for a
//   given provider path — no join table required.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Traverse the three-hop path in one MATCH:
//     Provider-[:PROVIDED_CARE]->Encounter-[:PRESCRIBED]->Medication {rxnorm:'860975'}
//     This links provider care delivery directly to a specific drug.
//
//   Step 2 — Temporal filter on the encounter (not the prescription):
//     WHERE e.date >= date() - duration('P180D')   ← ~6 months
//     Note: adjust duration if the demo data predates this window.
//
//   Step 3 — Aggregate per provider:
//     WITH pr, count(e) AS metformin_count
//
//   Step 4 — Post-aggregation filter (equivalent to SQL HAVING):
//     WHERE metformin_count > 5
//
//   Step 5 — Return ranked by prescription volume.
// ─────────────────────────────────────────────────────────────────────────────
MATCH (pr:Provider)-[:PROVIDED_CARE]->(e:Encounter)-[:PRESCRIBED]->(m:Medication {rxnorm:'860975'})
WHERE e.date >= date() - duration('P180D')
WITH pr, count(e) AS metformin_count
WHERE metformin_count > 5
RETURN pr.npi, pr.name, metformin_count
ORDER BY metformin_count DESC;


// ─────────────────────────────────────────────────────────────────────────────
// 5. Facility-level insight: top diagnoses by volume (last 30 days)
// "What conditions are driving patient volume at each facility right now?"
// Use: operational planning, staffing, seasonal demand patterns
//
// WHY GRAPH BEATS SQL:
//   This needs data from three entities: Facility, Encounter, Diagnosis. In SQL
//   that's two JOINs (facilities→encounters via a location FK, encounters→diagnoses
//   via a diagnosis FK), GROUP BY on two columns, and ORDER BY. The row count can
//   balloon before aggregation. In the graph, AT_FACILITY and HAS_DIAGNOSIS are
//   direct relationships; the traversal is explicit about direction, and
//   aggregation never sees more rows than the actual encounter count.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Traverse all three nodes via two relationships:
//     Facility<-[:AT_FACILITY]-Encounter-[:HAS_DIAGNOSIS]->Diagnosis
//     Note the inbound arrow on AT_FACILITY: encounters point TO a facility.
//
//   Step 2 — Temporal filter:
//     WHERE e.date >= date() - duration('P30D')
//
//   Step 3 — Aggregate: count encounters per (facility, diagnosis) pair:
//     WITH f, d, count(e) AS diag_count
//     ORDER BY diag_count DESC   ← sort before RETURN for correct LIMIT behaviour
//
//   Step 4 — Return top 10 rows across all facilities.
// ─────────────────────────────────────────────────────────────────────────────
MATCH (f:Facility)<-[:AT_FACILITY]-(e:Encounter)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
WHERE e.date >= date() - duration('P30D')
WITH f, d, count(e) AS diag_count
ORDER BY diag_count DESC
RETURN f.facility_id, f.name, d.icd10, d.name, diag_count
LIMIT 10;


// ─────────────────────────────────────────────────────────────────────────────
// 6. Provider "practice pattern" — most prescribed meds for each diagnosis
// "How are we treating hypertension or diabetes across providers?"
// Use: clinical variation audit, guideline compliance
//
// WHY GRAPH BEATS SQL:
//   This is where graphs pull clearly ahead. SQL must join providers, encounters,
//   diagnoses, AND medications — four tables, three JOINs — and the result set
//   is a cartesian product that must be de-duplicated. In Cypher, the single
//   MATCH pattern threads the same Encounter node (e) as the hub connecting
//   Provider, Diagnosis, and Medication. No redundant rows; the graph structure
//   enforces that diagnosis and medication belong to the same visit.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Write the hub-and-spoke MATCH pattern:
//     (pr)-[:PROVIDED_CARE]->(e)-[:HAS_DIAGNOSIS]->(d)<-[:HAS_DIAGNOSIS]-(e)-[r:PRESCRIBED]->(m)
//     Reading left-to-right:
//       • pr provided care at encounter e
//       • e has diagnosis d (outbound arrow)
//       • e also has the SAME diagnosis d (inbound arrow reuses the same node)
//       • e has a PRESCRIBED relationship r to medication m
//     The "back arrow" <-[:HAS_DIAGNOSIS]-(e) is the key: it anchors both
//     the diagnosis filter and the prescription to the same encounter node.
//
//   Step 2 — Filter to the two target conditions:
//     WHERE d.icd10 IN ['I10','E11']   ← hypertension and type-2 diabetes
//
//   Step 3 — Aggregate prescription counts per (provider, diagnosis, medication):
//     WITH pr, d, m, count(r) AS presc_count
//
//   Step 4 — Return top 20 combinations sorted by volume.
// ─────────────────────────────────────────────────────────────────────────────
MATCH (pr:Provider)-[:PROVIDED_CARE]->(e:Encounter)-[:HAS_DIAGNOSIS]->(d:Diagnosis)<-[:HAS_DIAGNOSIS]-(e)-[r:PRESCRIBED]->(m:Medication)
WHERE d.icd10 IN ['I10','E11']
WITH pr, d, m, count(r) AS presc_count
ORDER BY presc_count DESC
RETURN pr.npi, pr.name, d.icd10, d.name, m.rxnorm, m.name, presc_count
LIMIT 20;


// ─────────────────────────────────────────────────────────────────────────────
// 7. Clinical notes mentioning Amlodipine (rxnorm:314076) with NLP confidence score
// Use: pharmacovigilance, adverse drug event (ADE) detection
//
// WHY GRAPH BEATS SQL:
//   In SQL, linking free-text notes to medications requires a separate
//   note_medication_mentions table (note_id FK, medication_id FK, mention_text,
//   extraction_method, confidence_score). Querying it means another JOIN.
//   In the graph, MENTIONS is a first-class relationship between ClinicalNote
//   and Medication, and it carries all metadata as relationship properties
//   (ment.mention, ment.method, ment.score). No extra table; relationship
//   properties hold the NLP output inline.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Anchor on a specific medication:
//     MATCH (n:ClinicalNote)-[ment:MENTIONS]->(m:Medication {rxnorm:'314076'})
//     The MENTIONS relationship is the NLP extraction result; ment captures it.
//
//   Step 2 — Project note snippet + all relationship metadata:
//     substring(n.text,0,200)   ← truncate long note text for readability
//     ment.mention              ← exact phrase extracted by NLP
//     ment.method               ← extraction method (regex, NER, LLM, etc.)
//     ment.score                ← confidence / sentiment score
//
//   Step 3 — Sort by confidence descending to surface the strongest signals first.
// ─────────────────────────────────────────────────────────────────────────────
MATCH (n:ClinicalNote)-[ment:MENTIONS]->(m:Medication {rxnorm:'314076'})
RETURN n.note_id, substring(n.text,0,200) AS note_snippet, ment.mention, ment.method, ment.score
ORDER BY ment.score DESC;


// ─────────────────────────────────────────────────────────────────────────────
// 8. Patients with both Hypertension (I10) AND Diabetes (E11) — comorbidity analysis
// "Which patients have both conditions across any of their encounters?"
//
// WHY GRAPH BEATS SQL:
//   SQL needs two subqueries (or a pivot/CASE) on the diagnoses table, joined
//   back to patients, with an INTERSECT or GROUP BY HAVING COUNT(DISTINCT icd10) = 2.
//   In Cypher, the comma between MATCH clauses acts as a set intersection:
//   the same patient node (p) must satisfy BOTH traversal patterns simultaneously.
//   The graph engine finds the overlap without explicit set logic.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Two MATCH patterns sharing the patient anchor (p):
//     (p)-[:HAD_ENCOUNTER]->(e1:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:'I10'})
//     (p)-[:HAD_ENCOUNTER]->(e2:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:'E11'})
//     The comma between them means BOTH must match for the same p.
//
//   Step 2 — Separate encounter variables (e1, e2) allow each diagnosis to come
//     from a different encounter — a patient doesn't need both conditions at the
//     same visit, just somewhere in their history.
//
//   Step 3 — Return distinct patients sorted by name.
//     No aggregation needed — the dual-MATCH already filters to qualifying patients.
// ─────────────────────────────────────────────────────────────────────────────
MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e1:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:'I10'}),
      (p)-[:HAD_ENCOUNTER]->(e2:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:'E11'})
RETURN p.patient_id, p.name
ORDER BY p.name;


// ─────────────────────────────────────────────────────────────────────────────
// 9. Data quality: encounters with a prescription but no diagnosis coded
// "Which encounters have prescribed medications but no associated diagnoses?"
// Use: detect incomplete coding, ingestion gaps
//
// WHY GRAPH BEATS SQL:
//   In SQL, "row with no related row in another table" is a LEFT JOIN … WHERE
//   right_table.id IS NULL pattern. It forces the engine to materialise the
//   full join before filtering nulls. In Cypher, WHERE NOT (e)-[:HAS_DIAGNOSIS]->()
//   is a negative structural predicate — the engine checks for the absence of a
//   relationship directly on the node, short-circuiting as soon as one is found.
//   Missing links are a native graph concept; finding them is idiomatic Cypher.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Anchor on encounters that DO have a prescription:
//     MATCH (e:Encounter)-[:PRESCRIBED]->(:Medication)
//     Only encounters with at least one PRESCRIBED relationship are returned.
//
//   Step 2 — Negative pattern filter:
//     WHERE NOT (e)-[:HAS_DIAGNOSIS]->(:Diagnosis)
//     Excludes encounters that have any HAS_DIAGNOSIS relationship.
//     What remains are encounters with meds but no coded diagnoses.
//
//   Step 3 — Return encounter details for remediation, limited to 50 rows.
// ─────────────────────────────────────────────────────────────────────────────
MATCH (e:Encounter)-[:PRESCRIBED]->(:Medication)
WHERE NOT (e)-[:HAS_DIAGNOSIS]->(:Diagnosis)
RETURN e.enc_id, e.date, e.reason
ORDER BY e.date DESC
LIMIT 50;


// ─────────────────────────────────────────────────────────────────────────────
// 10. Count of encounters per patient in last year
// Use: patient engagement metrics
//
// WHY GRAPH BEATS SQL:
//   Functionally similar to SQL's GROUP BY, but the graph removes the JOIN step
//   entirely. In SQL: SELECT patient_id, COUNT(*) FROM encounters GROUP BY patient_id
//   WHERE date >= ... — still requires the encounters table to carry a patient_id FK.
//   In the graph, HAD_ENCOUNTER is a structural relationship; no FK column needed,
//   and counting its instances per patient is a single traversal with aggregation.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Traverse Patient→Encounter:
//     MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)
//
//   Step 2 — Temporal filter:
//     WHERE e.date >= date() - duration('P365D')   ← last 12 months
//
//   Step 3 — Aggregate encounters per patient:
//     WITH p, count(e) AS encounter_count
//
//   Step 4 — Return sorted highest-engagement patients first.
// ─────────────────────────────────────────────────────────────────────────────
MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)
WHERE e.date >= date() - duration('P365D')
WITH p, count(e) AS encounter_count
RETURN p.patient_id, p.name, encounter_count
ORDER BY encounter_count DESC;


// ─────────────────────────────────────────────────────────────────────────────
// 11. Path traversal: care pathway of variable length (3–5 hops)
// "Show me the full care pathway for patient P_002 up to 5 steps away."
// Use: RAG explainability — "why did the model link this med to this patient?"
//
// WHY GRAPH BEATS SQL:
//   Variable-length path queries across multiple relationship types are NOT
//   expressible in standard SQL without recursive CTEs, which require knowing
//   the schema ahead of time and produce verbose, fragile queries. Cypher's
//   *min..max hop syntax is native and relationship-type-aware. Neo4j Browser
//   also renders the returned path objects as an interactive visual graph —
//   something no SQL tool can do natively.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Anchor on the parameterised patient:
//     MATCH (p:Patient {patient_id:$pid})
//
//   Step 2 — Variable-length path from that anchor:
//     path = (p)-[:HAD_ENCOUNTER]->(:Encounter)-[:HAS_DIAGNOSIS|PRESCRIBED|AT_FACILITY|ABOUT_ENCOUNTER*3..5]->(x)
//     Breaking this down:
//       • First hop is always HAD_ENCOUNTER (fixed)
//       • Then 3–5 additional hops using ANY of the listed relationship types
//         (pipe | means OR between relationship types)
//       • x is any terminal node at the end of the path
//       • path captures the entire chain of nodes and relationships
//
//   Step 3 — RETURN path so Neo4j Browser draws it as a graph visualisation.
//     LIMIT 25 prevents runaway fan-out on dense graphs.
//   Practical note: use in Neo4j Browser to visually inspect pathways.
// ─────────────────────────────────────────────────────────────────────────────
Parameters {
  pid: 'P_002'
};
MATCH (p:Patient {patient_id:$pid})
MATCH path = (p)-[:HAD_ENCOUNTER]->(:Encounter)-[:HAS_DIAGNOSIS|PRESCRIBED|AT_FACILITY|ABOUT_ENCOUNTER*3..5]->(x)
RETURN path
LIMIT 25;


// ─────────────────────────────────────────────────────────────────────────────
// 12. Patient similarity to P_002 using Jaccard index (diagnosis + medication sets)
// "Which patients have the most similar clinical profiles to patient P_002?"
// Use: clinical decision support, case-based reasoning, care management, risk stratification
//
// WHY GRAPH BEATS SQL:
//   Computing Jaccard similarity (|A∩B| / |A∪B|) on multi-entity sets in SQL
//   requires multiple CTEs, INTERSECT, UNION, and careful de-duplication — often
//   10–15 lines of SQL per patient pair, not scalable. In the graph, COLLECT
//   aggregates per-patient code sets in a single traversal, and APOC library
//   functions provide set intersection and union as single function calls.
//   Crucially, the graph naturally traverses Patient→Encounter→Diagnosis AND
//   Patient→Encounter→Medication in the same query without separate subqueries.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Collect the reference patient's diagnosis + medication code sets:
//     MATCH (p0:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e0:Encounter)
//     OPTIONAL MATCH (e0)-[:HAS_DIAGNOSIS]->(d0) / (e0)-[:PRESCRIBED]->(m0)
//     collect(DISTINCT d0.icd10) AS p0_dx, collect(DISTINCT m0.rxnorm) AS p0_meds
//
//   Step 2 — For every other patient, collect their code sets:
//     MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)
//     WHERE p <> p0          ← exclude the reference patient
//     Same OPTIONAL MATCH pattern → dx, meds lists per patient
//
//   Step 3 — Build union sets A (reference) and B (candidate):
//     apoc.coll.toSet(p0_dx + p0_meds) AS A   ← combined ICD+RxNorm codes
//     apoc.coll.toSet(dx + meds) AS B
//
//   Step 4 — Compute Jaccard:
//     inter = size(apoc.coll.intersection(A,B))   ← shared codes
//     uni   = size(apoc.coll.toSet(A + B))         ← all unique codes
//     jaccard_similarity = 1.0 * inter / uni        ← 1.0 forces float division
//     WHERE uni > 0 prevents division-by-zero for patients with no data.
//
//   Step 5 — Return top 10 most similar patients + the shared codes list.
// ─────────────────────────────────────────────────────────────────────────────
Parameters {
  pid: 'P_002'
};
MATCH (p0:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e0:Encounter)
OPTIONAL MATCH (e0)-[:HAS_DIAGNOSIS]->(d0:Diagnosis)
OPTIONAL MATCH (e0)-[:PRESCRIBED]->(m0:Medication)
WITH p0,
     collect(DISTINCT d0.icd10) AS p0_dx,
     collect(DISTINCT m0.rxnorm) AS p0_meds

MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)
WHERE p <> p0
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
OPTIONAL MATCH (e)-[:PRESCRIBED]->(m:Medication)
WITH p0, p0_dx, p0_meds, p,
     collect(DISTINCT d.icd10) AS dx,
     collect(DISTINCT m.rxnorm) AS meds

WITH p, p0_dx, p0_meds, dx, meds,
     apoc.coll.toSet(p0_dx + p0_meds) AS A,
     apoc.coll.toSet(dx + meds) AS B
WITH p, A, B,
     size(apoc.coll.intersection(A,B)) AS inter,
     size(apoc.coll.toSet(A + B)) AS uni
WHERE uni > 0
RETURN p.patient_id, p.name, (1.0*inter/uni) AS jaccard_similarity,
       apoc.coll.intersection(A,B) AS shared_codes
ORDER BY jaccard_similarity DESC
LIMIT 10;


// ─────────────────────────────────────────────────────────────────────────────
// 13. Write: Add a new encounter + diagnosis + prescription (idempotent upsert)
// "A new visit just happened — record it correctly without duplicating data."
// Use: realistic write-path pattern for EHR ingestion pipelines
//
// WHY GRAPH BEATS SQL:
//   SQL INSERT requires strict ordering to satisfy FK constraints: insert patient
//   (if missing), then encounter, then diagnosis, then medications, then the join
//   tables. Each step must check for duplicates with INSERT … ON CONFLICT or
//   MERGE INTO. In Cypher, MERGE handles all of this in one idempotent statement
//   per entity. ON CREATE SET applies properties only on first creation, so
//   re-running the same query is safe. Relationships are created or matched the
//   same way — no separate "association table" inserts.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Find the existing patient (must already exist; MATCH not MERGE):
//     MATCH (p:Patient {patient_id:$pid})
//     Intentional: we don't auto-create patients from encounter feeds.
//
//   Step 2 — Upsert encounter node and link to patient:
//     MERGE (e:Encounter {enc_id:$enc_id})
//     ON CREATE SET e.date = date($date), e.reason = $reason
//     MERGE (p)-[:HAD_ENCOUNTER]->(e)
//     ON CREATE SET only fires when the encounter is new — prevents overwriting
//     existing encounter data on re-ingestion.
//
//   Step 3 — Upsert diagnosis node and link to encounter:
//     MERGE (d:Diagnosis {icd10:$icd10})
//     ON CREATE SET d.name = coalesce($dx_name, 'UNKNOWN')
//     MERGE (e)-[:HAS_DIAGNOSIS]->(d)
//     coalesce() guards against null parameter values at ingestion time.
//
//   Step 4 — Upsert medication node, create/update PRESCRIBED relationship:
//     MERGE (m:Medication {rxnorm:$rxnorm})
//     ON CREATE SET m.name = coalesce($med_name, 'UNKNOWN')
//     MERGE (e)-[r:PRESCRIBED]->(m)
//     SET r.dose = $dose, r.frequency = $freq
//     SET on the relationship always updates dose/frequency (no ON CREATE guard)
//     because prescription details may legitimately change on re-ingestion.
//
//   Step 5 — RETURN IDs for confirmation / audit logging.
// ─────────────────────────────────────────────────────────────────────────────
Parameters {
  pid: 'P_002',
  enc_id: 'ENC_104',
  date: '2026-01-15',
  reason: 'Routine check-up',
  icd10: 'I10',
  dx_name: 'Essential (primary) hypertension',
  rxnorm: '314076',
  med_name: 'Amlodipine',
  dose: '10mg',
  freq: 'OD'
};

MATCH (p:Patient {patient_id:$pid})
MERGE (e:Encounter {enc_id:$enc_id})
ON CREATE SET e.date = date($date), e.reason = $reason
MERGE (p)-[:HAD_ENCOUNTER]->(e)

MERGE (d:Diagnosis {icd10:$icd10})
ON CREATE SET d.name = coalesce($dx_name, 'UNKNOWN')
MERGE (e)-[:HAS_DIAGNOSIS]->(d)

MERGE (m:Medication {rxnorm:$rxnorm})
ON CREATE SET m.name = coalesce($med_name, 'UNKNOWN')
MERGE (e)-[r:PRESCRIBED]->(m)
SET r.dose = $dose, r.frequency = $freq

RETURN p.patient_id, e.enc_id, d.icd10, m.rxnorm;


// ─────────────────────────────────────────────────────────────────────────────
// 14. Delete: Remove a clinical note by note_id
// Use: GDPR/HIPAA right-to-erasure, data correction
//
// WHY GRAPH BEATS SQL:
//   In SQL, deleting a note with FK references requires deleting from all
//   referencing tables first (note_diagnoses, note_medications, etc.) to avoid
//   FK constraint violations — a multi-step, order-dependent operation.
//   DETACH DELETE in Cypher is atomic: it removes the node AND all its
//   relationships in a single operation regardless of how many or what type they
//   are. No need to know the schema of connected relationships ahead of time.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Find the specific note node:
//     MATCH (n:ClinicalNote {note_id:$note_id})
//
//   Step 2 — DETACH DELETE: removes the node and all incident relationships:
//     This covers ABOUT_ENCOUNTER, MENTIONS, and any other relationships
//     that may have been added without requiring query changes.
//
//   Step 3 — RETURN a confirmation string (string concatenation in Cypher).
// ─────────────────────────────────────────────────────────────────────────────
Parameters {
  note_id: 'N_902'
};
MATCH (n:ClinicalNote {note_id:$note_id})
DETACH DELETE n
RETURN 'Deleted note ' + $note_id AS result;


// ─────────────────────────────────────────────────────────────────────────────
// 15. Population health: most common diagnoses across all patients
// "What are the most common diagnoses in our patient population?"
// Use: population health analytics, resource allocation
//
// WHY GRAPH BEATS SQL:
//   SQL: SELECT icd10, COUNT(DISTINCT patient_id) FROM encounters JOIN diagnoses …
//   GROUP BY icd10 ORDER BY count DESC. Functionally similar, but the graph
//   removes the JOIN entirely. The traversal Diagnosis←Encounter←Patient
//   directly counts unique patients per diagnosis node. The DISTINCT in
//   count(DISTINCT p) ensures a patient counted once even if they have the same
//   diagnosis across multiple encounters.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Reverse traversal (Diagnosis is the anchor this time):
//     MATCH (d:Diagnosis)<-[:HAS_DIAGNOSIS]-(e:Encounter)<-[:HAD_ENCOUNTER]-(p:Patient)
//     Starting from Diagnosis and walking backwards to Patient gives the
//     "how many patients have this diagnosis" shape naturally.
//
//   Step 2 — Aggregate unique patients per diagnosis:
//     WITH d, count(DISTINCT p) AS patient_count
//     DISTINCT prevents double-counting patients who received the same diagnosis
//     across multiple encounters.
//
//   Step 3 — Return top 20 diagnoses by patient prevalence.
// ─────────────────────────────────────────────────────────────────────────────
MATCH (d:Diagnosis)<-[:HAS_DIAGNOSIS]-(e:Encounter)<-[:HAD_ENCOUNTER]-(p:Patient)
WITH d, count(DISTINCT p) AS patient_count
RETURN d.icd10, d.name, patient_count
ORDER BY patient_count DESC
LIMIT 20;


// ─────────────────────────────────────────────────────────────────────────────
// 16. Write (repeat of #13 — same idempotent upsert pattern, different run context)
// Kept as a standalone block for classroom / demo purposes.
// See query 13 for full annotation.
// ─────────────────────────────────────────────────────────────────────────────
Parameters {
  pid: 'P_002',
  enc_id: 'ENC_104',
  date: '2026-01-15',
  reason: 'Routine check-up',
  icd10: 'I10',
  dx_name: 'Essential (primary) hypertension',
  rxnorm: '314076',
  med_name: 'Amlodipine',
  dose: '10mg',
  freq: 'OD'
};

MATCH (p:Patient {patient_id:$pid})
MERGE (e:Encounter {enc_id:$enc_id})
ON CREATE SET e.date = date($date), e.reason = $reason
MERGE (p)-[:HAD_ENCOUNTER]->(e)

MERGE (d:Diagnosis {icd10:$icd10})
ON CREATE SET d.name = coalesce($dx_name, 'UNKNOWN')
MERGE (e)-[:HAS_DIAGNOSIS]->(d)

MERGE (m:Medication {rxnorm:$rxnorm})
ON CREATE SET m.name = coalesce($med_name, 'UNKNOWN')
MERGE (e)-[r:PRESCRIBED]->(m)
SET r.dose = $dose, r.frequency = $freq

RETURN p.patient_id, e.enc_id, d.icd10, m.rxnorm;


// ─────────────────────────────────────────────────────────────────────────────
// 17. Cleanup: Merge duplicate Diagnosis nodes (hypertension name variants → I10)
// "After messy ingestion, consolidate 'hypertension', 'HTN', 'high blood pressure'
//  into a single canonical node."
// Use: post-ingestion knowledge graph normalisation
//
// WHY GRAPH BEATS SQL:
//   In SQL, concept deduplication means: UPDATE all FK references across every
//   table that points to the duplicate rows, then DELETE the duplicates — a
//   multi-step transaction that must be written differently for every referencing
//   table. In the graph, APOC's refactor.mergeNodes handles this in one call:
//   it merges all duplicate Diagnosis nodes into one and automatically redirects
//   ALL incoming and outgoing relationships to the surviving node, regardless of
//   relationship type. No need to know what relationships exist.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Find all Diagnosis nodes that are name-variants of hypertension:
//     MATCH (d:Diagnosis)
//     WHERE toLower(d.name) IN ['hypertension', 'high blood pressure', 'htn']
//     toLower() makes the match case-insensitive.
//
//   Step 2 — Collect all matching nodes into a list:
//     WITH collect(d) AS ds
//
//   Step 3 — Call APOC merge procedure:
//     CALL apoc.refactor.mergeNodes(ds, {properties:'discard', mergeRels:true})
//     properties:'discard' → keeps the first node's properties (we overwrite below)
//     mergeRels:true       → all relationships from all nodes redirect to survivor
//
//   Step 4 — Set canonical ICD-10 code and standard name on the merged node:
//     SET node.icd10 = 'I10', node.name = 'Essential (primary) hypertension'
//
//   Prerequisites: APOC plugin must be installed on the Neo4j instance.
//   Check availability: CALL apoc.version() or
//   CALL dbms.functions() YIELD name WHERE name STARTS WITH 'apoc'
// ─────────────────────────────────────────────────────────────────────────────
MATCH (d:Diagnosis)
WHERE toLower(d.name) IN ['hypertension', 'high blood pressure', 'htn']
WITH collect(d) AS ds
CALL apoc.refactor.mergeNodes(ds, {properties:'discard', mergeRels:true}) YIELD node
SET node.icd10 = 'I10', node.name = 'Essential (primary) hypertension'
RETURN node;


// ─────────────────────────────────────────────────────────────────────────────
// 18. Evidence verification: "Is HTN confirmed or just mentioned for patient P_002?"
// Use: GraphRAG grounding — separates coded clinical facts from NLP text mentions
//
// WHY GRAPH BEATS SQL:
//   This is a uniquely graph-native pattern. The graph stores TWO distinct types
//   of evidence for the same clinical concept: (1) a structured HAS_DIAGNOSIS
//   relationship from an Encounter (provider-coded, authoritative), and (2) a
//   MENTIONS relationship from a ClinicalNote (NLP-extracted, probabilistic).
//   In SQL, these live in completely separate tables (diagnoses vs note_mentions)
//   and must be combined with a UNION or separate queries. In the graph, both
//   paths fan out from the same patient traversal in a single query, and the
//   difference in evidence quality is encoded in which relationship type was
//   traversed — not which table was joined.
//   This distinction is critical for GraphRAG: LLMs must cite grounded facts,
//   not speculative NLP extractions, to avoid hallucination.
//
// HOW THE QUERY IS BUILT:
//   Step 1 — Traverse to all patient encounters:
//     MATCH (p:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e:Encounter)
//
//   Step 2 — OPTIONAL MATCH structured diagnosis (authoritative evidence):
//     OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(dx:Diagnosis {icd10:'I10'})
//     dx will be NULL if this encounter does not have a coded I10 diagnosis.
//
//   Step 3 — OPTIONAL MATCH notes attached to each encounter:
//     OPTIONAL MATCH (n:ClinicalNote)-[:ABOUT_ENCOUNTER]->(e)
//
//   Step 4 — OPTIONAL MATCH NLP mentions within those notes (probabilistic evidence):
//     OPTIONAL MATCH (n)-[mn:MENTIONS]->(dxm:Diagnosis {icd10:'I10'})
//     mn carries NLP metadata (confidence score, extraction method, mention text).
//
//   Step 5 — Build evidence summary with explicit type distinction:
//     confirmed: dx IS NOT NULL    ← boolean: was I10 formally coded on this encounter?
//     note_mentions collects NLP hits with their confidence scores.
//
//   Step 6 — RETURN a structured document separating the two evidence types:
//     confirmed_diagnosis_by_encounter  ← structured, provider-coded
//     note_mentions_of_I10              ← probabilistic, NLP-extracted
//     [x IN note_mentions WHERE x.note_id IS NOT NULL] filters out null rows
//     produced by encounters with no attached notes.
// ─────────────────────────────────────────────────────────────────────────────
Parameters {pid: 'P_002'};
MATCH (p:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e:Encounter)
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(dx:Diagnosis {icd10:'I10'})
OPTIONAL MATCH (n:ClinicalNote)-[:ABOUT_ENCOUNTER]->(e)
OPTIONAL MATCH (n)-[mn:MENTIONS]->(dxm:Diagnosis {icd10:'I10'})
WITH p,
     collect(DISTINCT {enc_id:e.enc_id, date:e.date, confirmed: dx IS NOT NULL}) AS enc_dx,
     collect(DISTINCT {note_id:n.note_id, mention:mn.mention, method:mn.method, score:mn.score}) AS note_mentions
RETURN {
  patient_id: p.patient_id,
  confirmed_diagnosis_by_encounter: enc_dx,
  note_mentions_of_I10: [x IN note_mentions WHERE x.note_id IS NOT NULL]
} AS hypertension_evidence;
