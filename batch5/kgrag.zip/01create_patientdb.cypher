// =====================================================
// Neo4j demo dataset (clean + readable + best-practice order)
// - 1) Wipe data (optional)
// - 2) Create constraints + indexes (schema first so data writes are validated and lookup is fast)
// - 3) Create nodes (use CREATE since schema enforces uniqueness)
// - 4) Create relationships (use MATCH + CREATE — clean, avoids accidental re-merge patterns)
// =====================================================


// -----------------------------------------------------
// 0) OPTIONAL: wipe the database (data only, keeps schema)
// -----------------------------------------------------
MATCH (n) DETACH DELETE n;


// -----------------------------------------------------
// 1) CONSTRAINTS (uniqueness / identity)  [create BEFORE data]
// -----------------------------------------------------
CREATE CONSTRAINT patient_id IF NOT EXISTS
FOR (p:Patient) REQUIRE p.patient_id IS UNIQUE;

CREATE CONSTRAINT encounter_id IF NOT EXISTS
FOR (e:Encounter) REQUIRE e.enc_id IS UNIQUE;

CREATE CONSTRAINT diagnosis_icd10 IF NOT EXISTS
FOR (d:Diagnosis) REQUIRE d.icd10 IS UNIQUE;

CREATE CONSTRAINT medication_rxnorm IF NOT EXISTS
FOR (m:Medication) REQUIRE m.rxnorm IS UNIQUE;

CREATE CONSTRAINT provider_npi IF NOT EXISTS
FOR (pr:Provider) REQUIRE pr.npi IS UNIQUE;

CREATE CONSTRAINT facility_id IF NOT EXISTS
FOR (f:Facility) REQUIRE f.facility_id IS UNIQUE;

CREATE CONSTRAINT note_id IF NOT EXISTS
FOR (n:ClinicalNote) REQUIRE n.note_id IS UNIQUE;


// -----------------------------------------------------
// 2) INDEXES (search / filtering)  [create BEFORE workloads]
// -----------------------------------------------------
CREATE INDEX diagnosis_name IF NOT EXISTS
FOR (d:Diagnosis) ON (d.name);

CREATE INDEX medication_name IF NOT EXISTS
FOR (m:Medication) ON (m.name);

CREATE INDEX encounter_date IF NOT EXISTS
FOR (e:Encounter) ON (e.date);


// -----------------------------------------------------
// 3) NODES (use CREATE; uniqueness constraints prevent duplicates)
// -----------------------------------------------------

// 3.1 Patients
// P_001..P_003: single-diagnosis patients; P_004: comorbid (I10 + E11) for query 8
CREATE (:Patient {patient_id:'P_001', name:'Asha Mehta',   dob:date('1988-02-14'), sex:'F'});
CREATE (:Patient {patient_id:'P_002', name:'Ravi Kumar',   dob:date('1975-11-01'), sex:'M'});
CREATE (:Patient {patient_id:'P_003', name:'Neha Singh',   dob:date('1992-07-19'), sex:'F'});
CREATE (:Patient {patient_id:'P_004', name:'Meena Joshi',  dob:date('1980-05-10'), sex:'F'});

// 3.2 Encounters
// Dates pushed to 2026-03/04 so they fall inside 30-day and 90-day windows (today = 2026-04-17)
CREATE (:Encounter {enc_id:'ENC_101', date:date('2026-03-20'), reason:'Follow-up BP',            bp_systolic:150, bp_diastolic:95});
CREATE (:Encounter {enc_id:'ENC_102', date:date('2026-03-25'), reason:'Hypertension review',     bp_systolic:145, bp_diastolic:92});
CREATE (:Encounter {enc_id:'ENC_103', date:date('2026-04-01'), reason:'Diabetes follow-up',      hba1c:8.2});
// P_004 comorbid visit
CREATE (:Encounter {enc_id:'ENC_301', date:date('2026-03-22'), reason:'Hypertension + Diabetes combined care', bp_systolic:155, bp_diastolic:98, hba1c:9.1});

// Extra encounters so PR_002 hits >5 Metformin prescriptions in last 6 months (window: 2025-10-17 to 2026-04-17)
CREATE (:Encounter {enc_id:'ENC_201', date:date('2025-11-15'), reason:'Diabetes routine',        hba1c:8.8});
CREATE (:Encounter {enc_id:'ENC_202', date:date('2025-12-10'), reason:'Diabetes routine',        hba1c:8.5});
CREATE (:Encounter {enc_id:'ENC_203', date:date('2026-01-12'), reason:'Diabetes routine',        hba1c:8.3});
CREATE (:Encounter {enc_id:'ENC_204', date:date('2026-02-08'), reason:'Diabetes routine',        hba1c:8.1});
CREATE (:Encounter {enc_id:'ENC_205', date:date('2026-03-05'), reason:'Diabetes routine',        hba1c:7.9});
CREATE (:Encounter {enc_id:'ENC_206', date:date('2026-04-03'), reason:'Diabetes routine',        hba1c:7.7});

// 3.3 Diagnoses
CREATE (:Diagnosis {icd10:'I10', name:'Essential (primary) hypertension'});
CREATE (:Diagnosis {icd10:'E11', name:'Type 2 diabetes mellitus'});

// 3.4 Medications
CREATE (:Medication {rxnorm:'314076', name:'Amlodipine'});
CREATE (:Medication {rxnorm:'860975', name:'Metformin'});

// 3.5 Providers
CREATE (:Provider {npi:'1234567890', name:'Dr. Priya Nair',  specialty:'Internal Medicine'});
CREATE (:Provider {npi:'9876543210', name:'Dr. Anil Verma',  specialty:'Endocrinology'});

// 3.6 Facilities
CREATE (:Facility {facility_id:'FAC_001', name:'City General Hospital',    city:'Mumbai'});
CREATE (:Facility {facility_id:'FAC_002', name:'Metro Diabetes Clinic',    city:'Pune'});

// 3.7 Clinical notes
CREATE (:ClinicalNote {note_id:'N_901', text:'BP is high. Continue amlodipine.'});
CREATE (:ClinicalNote {note_id:'N_902', text:'Diabetes follow-up: metformin continued. No hypertension symptoms.'});
CREATE (:ClinicalNote {note_id:'N_903', text:'Patient presents with both hypertension and uncontrolled diabetes. Starting amlodipine and metformin combination therapy.'});


// -----------------------------------------------------
// 4) RELATIONSHIPS (MATCH endpoints, then CREATE relationships)
// -----------------------------------------------------

// 4.1 Patient -> Encounter
MATCH (p:Patient {patient_id:'P_001'}), (e:Encounter {enc_id:'ENC_101'}) CREATE (p)-[:HAD_ENCOUNTER]->(e);
MATCH (p:Patient {patient_id:'P_002'}), (e:Encounter {enc_id:'ENC_102'}) CREATE (p)-[:HAD_ENCOUNTER]->(e);
MATCH (p:Patient {patient_id:'P_003'}), (e:Encounter {enc_id:'ENC_103'}) CREATE (p)-[:HAD_ENCOUNTER]->(e);
MATCH (p:Patient {patient_id:'P_004'}), (e:Encounter {enc_id:'ENC_301'}) CREATE (p)-[:HAD_ENCOUNTER]->(e);
// P_003 repeated diabetes visits (for provider metformin volume query)
MATCH (p:Patient {patient_id:'P_003'}), (e:Encounter {enc_id:'ENC_201'}) CREATE (p)-[:HAD_ENCOUNTER]->(e);
MATCH (p:Patient {patient_id:'P_003'}), (e:Encounter {enc_id:'ENC_202'}) CREATE (p)-[:HAD_ENCOUNTER]->(e);
MATCH (p:Patient {patient_id:'P_003'}), (e:Encounter {enc_id:'ENC_203'}) CREATE (p)-[:HAD_ENCOUNTER]->(e);
MATCH (p:Patient {patient_id:'P_004'}), (e:Encounter {enc_id:'ENC_204'}) CREATE (p)-[:HAD_ENCOUNTER]->(e);
MATCH (p:Patient {patient_id:'P_004'}), (e:Encounter {enc_id:'ENC_205'}) CREATE (p)-[:HAD_ENCOUNTER]->(e);
MATCH (p:Patient {patient_id:'P_004'}), (e:Encounter {enc_id:'ENC_206'}) CREATE (p)-[:HAD_ENCOUNTER]->(e);


// 4.2 Encounter -> Diagnosis
MATCH (e:Encounter {enc_id:'ENC_101'}), (d:Diagnosis {icd10:'I10'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);
MATCH (e:Encounter {enc_id:'ENC_102'}), (d:Diagnosis {icd10:'I10'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);
MATCH (e:Encounter {enc_id:'ENC_103'}), (d:Diagnosis {icd10:'E11'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);
// P_004 comorbid: both I10 and E11
MATCH (e:Encounter {enc_id:'ENC_301'}), (d:Diagnosis {icd10:'I10'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);
MATCH (e:Encounter {enc_id:'ENC_301'}), (d:Diagnosis {icd10:'E11'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);
// Repeated diabetes visits
MATCH (e:Encounter {enc_id:'ENC_201'}), (d:Diagnosis {icd10:'E11'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);
MATCH (e:Encounter {enc_id:'ENC_202'}), (d:Diagnosis {icd10:'E11'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);
MATCH (e:Encounter {enc_id:'ENC_203'}), (d:Diagnosis {icd10:'E11'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);
MATCH (e:Encounter {enc_id:'ENC_204'}), (d:Diagnosis {icd10:'E11'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);
MATCH (e:Encounter {enc_id:'ENC_205'}), (d:Diagnosis {icd10:'E11'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);
MATCH (e:Encounter {enc_id:'ENC_206'}), (d:Diagnosis {icd10:'E11'}) CREATE (e)-[:HAS_DIAGNOSIS]->(d);


// 4.3 Encounter -> Medication (with relationship properties)
MATCH (e:Encounter {enc_id:'ENC_101'}), (m:Medication {rxnorm:'314076'}) CREATE (e)-[:PRESCRIBED {dose:'5mg',   frequency:'OD'}]->(m);
MATCH (e:Encounter {enc_id:'ENC_102'}), (m:Medication {rxnorm:'314076'}) CREATE (e)-[:PRESCRIBED {dose:'5mg',   frequency:'OD'}]->(m);
MATCH (e:Encounter {enc_id:'ENC_103'}), (m:Medication {rxnorm:'860975'}) CREATE (e)-[:PRESCRIBED {dose:'500mg', frequency:'BD'}]->(m);
// P_004 comorbid: both medications
MATCH (e:Encounter {enc_id:'ENC_301'}), (m:Medication {rxnorm:'314076'}) CREATE (e)-[:PRESCRIBED {dose:'5mg',   frequency:'OD'}]->(m);
MATCH (e:Encounter {enc_id:'ENC_301'}), (m:Medication {rxnorm:'860975'}) CREATE (e)-[:PRESCRIBED {dose:'500mg', frequency:'BD'}]->(m);
// Repeated Metformin prescriptions by PR_002 (6 encounters → satisfies >5 threshold in query 4)
MATCH (e:Encounter {enc_id:'ENC_201'}), (m:Medication {rxnorm:'860975'}) CREATE (e)-[:PRESCRIBED {dose:'500mg', frequency:'BD'}]->(m);
MATCH (e:Encounter {enc_id:'ENC_202'}), (m:Medication {rxnorm:'860975'}) CREATE (e)-[:PRESCRIBED {dose:'500mg', frequency:'BD'}]->(m);
MATCH (e:Encounter {enc_id:'ENC_203'}), (m:Medication {rxnorm:'860975'}) CREATE (e)-[:PRESCRIBED {dose:'1000mg',frequency:'BD'}]->(m);
MATCH (e:Encounter {enc_id:'ENC_204'}), (m:Medication {rxnorm:'860975'}) CREATE (e)-[:PRESCRIBED {dose:'1000mg',frequency:'BD'}]->(m);
MATCH (e:Encounter {enc_id:'ENC_205'}), (m:Medication {rxnorm:'860975'}) CREATE (e)-[:PRESCRIBED {dose:'1000mg',frequency:'BD'}]->(m);
MATCH (e:Encounter {enc_id:'ENC_206'}), (m:Medication {rxnorm:'860975'}) CREATE (e)-[:PRESCRIBED {dose:'1000mg',frequency:'BD'}]->(m);


// 4.4 Note -> Encounter
MATCH (n:ClinicalNote {note_id:'N_901'}), (e:Encounter {enc_id:'ENC_102'}) CREATE (n)-[:ABOUT_ENCOUNTER]->(e);
MATCH (n:ClinicalNote {note_id:'N_902'}), (e:Encounter {enc_id:'ENC_103'}) CREATE (n)-[:ABOUT_ENCOUNTER]->(e);
MATCH (n:ClinicalNote {note_id:'N_903'}), (e:Encounter {enc_id:'ENC_301'}) CREATE (n)-[:ABOUT_ENCOUNTER]->(e);


// 4.5 Note -> (Diagnosis | Medication) mentions with score/method
MATCH (n:ClinicalNote {note_id:'N_901'}), (m:Medication {rxnorm:'314076'})
CREATE (n)-[:MENTIONS {mention:'amlodipine',  method:'synonym_exact', score:1.0}]->(m);

MATCH (n:ClinicalNote {note_id:'N_901'}), (d:Diagnosis {icd10:'I10'})
CREATE (n)-[:MENTIONS {mention:'bp is high',  method:'fuzzy',         score:0.91}]->(d);

MATCH (n:ClinicalNote {note_id:'N_902'}), (m:Medication {rxnorm:'860975'})
CREATE (n)-[:MENTIONS {mention:'metformin',   method:'synonym_exact', score:1.0}]->(m);

MATCH (n:ClinicalNote {note_id:'N_903'}), (m:Medication {rxnorm:'314076'})
CREATE (n)-[:MENTIONS {mention:'amlodipine',  method:'synonym_exact', score:1.0}]->(m);

MATCH (n:ClinicalNote {note_id:'N_903'}), (m:Medication {rxnorm:'860975'})
CREATE (n)-[:MENTIONS {mention:'metformin',   method:'synonym_exact', score:1.0}]->(m);

MATCH (n:ClinicalNote {note_id:'N_903'}), (d:Diagnosis {icd10:'I10'})
CREATE (n)-[:MENTIONS {mention:'hypertension',method:'synonym_exact', score:1.0}]->(d);

MATCH (n:ClinicalNote {note_id:'N_903'}), (d:Diagnosis {icd10:'E11'})
CREATE (n)-[:MENTIONS {mention:'diabetes',    method:'synonym_exact', score:1.0}]->(d);


// 4.6 Provider -> PROVIDED_CARE -> Encounter
// PR_001 manages hypertension patients
MATCH (pr:Provider {npi:'1234567890'}), (e:Encounter {enc_id:'ENC_101'}) CREATE (pr)-[:PROVIDED_CARE]->(e);
MATCH (pr:Provider {npi:'1234567890'}), (e:Encounter {enc_id:'ENC_102'}) CREATE (pr)-[:PROVIDED_CARE]->(e);
MATCH (pr:Provider {npi:'1234567890'}), (e:Encounter {enc_id:'ENC_301'}) CREATE (pr)-[:PROVIDED_CARE]->(e);
// PR_002 manages diabetes patients — 6 encounters crosses the >5 threshold in query 4
MATCH (pr:Provider {npi:'9876543210'}), (e:Encounter {enc_id:'ENC_103'}) CREATE (pr)-[:PROVIDED_CARE]->(e);
MATCH (pr:Provider {npi:'9876543210'}), (e:Encounter {enc_id:'ENC_201'}) CREATE (pr)-[:PROVIDED_CARE]->(e);
MATCH (pr:Provider {npi:'9876543210'}), (e:Encounter {enc_id:'ENC_202'}) CREATE (pr)-[:PROVIDED_CARE]->(e);
MATCH (pr:Provider {npi:'9876543210'}), (e:Encounter {enc_id:'ENC_203'}) CREATE (pr)-[:PROVIDED_CARE]->(e);
MATCH (pr:Provider {npi:'9876543210'}), (e:Encounter {enc_id:'ENC_204'}) CREATE (pr)-[:PROVIDED_CARE]->(e);
MATCH (pr:Provider {npi:'9876543210'}), (e:Encounter {enc_id:'ENC_205'}) CREATE (pr)-[:PROVIDED_CARE]->(e);
MATCH (pr:Provider {npi:'9876543210'}), (e:Encounter {enc_id:'ENC_206'}) CREATE (pr)-[:PROVIDED_CARE]->(e);


// 4.7 Encounter -> AT_FACILITY -> Facility
MATCH (e:Encounter {enc_id:'ENC_101'}), (f:Facility {facility_id:'FAC_001'}) CREATE (e)-[:AT_FACILITY]->(f);
MATCH (e:Encounter {enc_id:'ENC_102'}), (f:Facility {facility_id:'FAC_001'}) CREATE (e)-[:AT_FACILITY]->(f);
MATCH (e:Encounter {enc_id:'ENC_301'}), (f:Facility {facility_id:'FAC_001'}) CREATE (e)-[:AT_FACILITY]->(f);
MATCH (e:Encounter {enc_id:'ENC_103'}), (f:Facility {facility_id:'FAC_002'}) CREATE (e)-[:AT_FACILITY]->(f);
MATCH (e:Encounter {enc_id:'ENC_201'}), (f:Facility {facility_id:'FAC_002'}) CREATE (e)-[:AT_FACILITY]->(f);
MATCH (e:Encounter {enc_id:'ENC_202'}), (f:Facility {facility_id:'FAC_002'}) CREATE (e)-[:AT_FACILITY]->(f);
MATCH (e:Encounter {enc_id:'ENC_203'}), (f:Facility {facility_id:'FAC_002'}) CREATE (e)-[:AT_FACILITY]->(f);
MATCH (e:Encounter {enc_id:'ENC_204'}), (f:Facility {facility_id:'FAC_002'}) CREATE (e)-[:AT_FACILITY]->(f);
MATCH (e:Encounter {enc_id:'ENC_205'}), (f:Facility {facility_id:'FAC_002'}) CREATE (e)-[:AT_FACILITY]->(f);
MATCH (e:Encounter {enc_id:'ENC_206'}), (f:Facility {facility_id:'FAC_002'}) CREATE (e)-[:AT_FACILITY]->(f);
