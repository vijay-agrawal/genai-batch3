"""
nl2cypher.py

- Takes a natural-language question from the user
- Uses Azure OpenAI Chat Completions to generate a Cypher query
- Grounds generation on the provided Neo4j schema
- Enforces safe, read-only Cypher (MATCH/RETURN only)

Prereqs:
  pip install openai python-dotenv

Env vars needed:
  AZURE_OPENAI_ENDPOINT - Your Azure OpenAI endpoint URL
  AZURE_OPENAI_API_KEY - Your Azure OpenAI API key   
  AZURE_OPENAI_API_VERSION - e.g., "2024-02-15-preview
  AZURE_OPENAI_MODEL_NAME - The deployed model name (e.g., "gpt-4o-azure")
"""

import os
import json
import re
from typing import Optional

from openai import AzureOpenAI
from dotenv import load_dotenv

load_dotenv()


# -----------------------------
# 1) Your extracted schema
# See 06fetch_neo4jschema.cypher to obtain this
# -----------------------------
GRAPH_SCHEMA = {
  "HAS_DIAGNOSIS": {"count": 3, "type": "relationship", "properties": {}},
  "ClinicalNote": {
    "count": 2,
    "relationships": {
      "MENTIONS": {
        "count": 0,
        "properties": {
          "score": {"existence": False, "type": "FLOAT", "array": False, "indexed": False},
          "method": {"existence": False, "type": "STRING", "array": False, "indexed": False},
          "mention": {"existence": False, "type": "STRING", "array": False, "indexed": False}
        },
        "direction": "out",
        "labels": ["Diagnosis", "Medication"]
      },
      "ABOUT_ENCOUNTER": {"count": 0, "properties": {}, "direction": "out", "labels": ["Encounter"]}
    },
    "type": "node",
    "properties": {
      "note_id": {"existence": False, "type": "STRING", "indexed": True, "unique": True},
      "text": {"existence": False, "type": "STRING", "indexed": False, "unique": False}
    },
    "labels": []
  },
  "Medication": {
    "count": 2,
    "relationships": {
      "PRESCRIBED": {
        "count": 3,
        "properties": {
          "dose": {"existence": False, "type": "STRING", "array": False, "indexed": False},
          "frequency": {"existence": False, "type": "STRING", "array": False, "indexed": False}
        },
        "direction": "in",
        "labels": ["Encounter"]
      },
      "MENTIONS": {
        "count": 3,
        "properties": {
          "score": {"existence": False, "type": "FLOAT", "array": False, "indexed": False},
          "method": {"existence": False, "type": "STRING", "array": False, "indexed": False},
          "mention": {"existence": False, "type": "STRING", "array": False, "indexed": False}
        },
        "direction": "in",
        "labels": ["ClinicalNote"]
      }
    },
    "type": "node",
    "properties": {
      "name": {"existence": False, "type": "STRING", "indexed": True, "unique": False},
      "rxnorm": {"existence": False, "type": "STRING", "indexed": True, "unique": True}
    },
    "labels": []
  },
  "PRESCRIBED": {
    "count": 3,
    "type": "relationship",
    "properties": {
      "dose": {"existence": False, "type": "STRING", "array": False, "indexed": False},
      "frequency": {"existence": False, "type": "STRING", "array": False, "indexed": False}
    }
  },
  "Patient": {
    "count": 3,
    "relationships": {
      "HAD_ENCOUNTER": {"count": 0, "properties": {}, "direction": "out", "labels": ["Encounter"]}
    },
    "type": "node",
    "properties": {
      "name": {"existence": False, "type": "STRING", "indexed": False, "unique": False},
      "patient_id": {"existence": False, "type": "STRING", "indexed": True, "unique": True},
      "dob": {"existence": False, "type": "DATE", "indexed": False, "unique": False},
      "sex": {"existence": False, "type": "STRING", "indexed": False, "unique": False}
    },
    "labels": []
  },
  "Encounter": {
    "count": 3,
    "relationships": {
      "HAS_DIAGNOSIS": {"count": 0, "properties": {}, "direction": "out", "labels": ["Diagnosis"]},
      "PRESCRIBED": {
        "count": 0,
        "properties": {
          "dose": {"existence": False, "type": "STRING", "array": False, "indexed": False},
          "frequency": {"existence": False, "type": "STRING", "array": False, "indexed": False}
        },
        "direction": "out",
        "labels": ["Medication"]
      },
      "HAD_ENCOUNTER": {"count": 3, "properties": {}, "direction": "in", "labels": ["Patient"]},
      "ABOUT_ENCOUNTER": {"count": 2, "properties": {}, "direction": "in", "labels": ["ClinicalNote"]}
    },
    "type": "node",
    "properties": {
      "date": {"existence": False, "type": "DATE", "indexed": True, "unique": False},
      "reason": {"existence": False, "type": "STRING", "indexed": False, "unique": False},
      "bp_diastolic": {"existence": False, "type": "INTEGER", "indexed": False, "unique": False},
      "enc_id": {"existence": False, "type": "STRING", "indexed": True, "unique": True},
      "hba1c": {"existence": False, "type": "FLOAT", "indexed": False, "unique": False},
      "bp_systolic": {"existence": False, "type": "INTEGER", "indexed": False, "unique": False}
    },
    "labels": []
  },
  "HAD_ENCOUNTER": {"count": 3, "type": "relationship", "properties": {}},
  "Diagnosis": {
    "count": 2,
    "relationships": {
      "HAS_DIAGNOSIS": {"count": 3, "properties": {}, "direction": "in", "labels": ["Encounter"]},
      "MENTIONS": {
        "count": 3,
        "properties": {
          "score": {"existence": False, "type": "FLOAT", "array": False, "indexed": False},
          "method": {"existence": False, "type": "STRING", "array": False, "indexed": False},
          "mention": {"existence": False, "type": "STRING", "array": False, "indexed": False}
        },
        "direction": "in",
        "labels": ["ClinicalNote"]
      }
    },
    "type": "node",
    "properties": {
      "name": {"existence": False, "type": "STRING", "indexed": True, "unique": False},
      "icd10": {"existence": False, "type": "STRING", "indexed": True, "unique": True}
    },
    "labels": []
  },
  "ABOUT_ENCOUNTER": {"count": 2, "type": "relationship", "properties": {}},
  "MENTIONS": {
    "count": 3,
    "type": "relationship",
    "properties": {
      "score": {"existence": False, "type": "FLOAT", "array": False, "indexed": False},
      "method": {"existence": False, "type": "STRING", "array": False, "indexed": False},
      "mention": {"existence": False, "type": "STRING", "array": False, "indexed": False}
    }
  }
}


# -----------------------------
# 2) System prompt (designed)
# -----------------------------
SYSTEM_PROMPT = """
You are a Neo4j Cypher expert.
Translate the user's natural-language question into a SINGLE Cypher query.

HARD OUTPUT CONTRACT (must follow):
A) Output MUST be ONLY Cypher (no markdown, no explanations, no comments).
B) Read-only queries only (MATCH / OPTIONAL MATCH / WHERE / WITH / RETURN / ORDER BY / LIMIT / SKIP / DISTINCT).
C) NEVER return raw nodes or raw relationships in the final RETURN (e.g., "RETURN p, e, d").
   - Final RETURN must be a SINGLE map (JSON-like) alias such as `result` or `patient_snapshot`.
   - Use property projections like {patient_id:p.patient_id, name:p.name, ...}.
D) Prefer structured, human-consumable output:
   - Use `collect(DISTINCT ...)` to build lists.
   - Use relationship variables (e.g., [pr:PRESCRIBED]) to include relationship properties (dose, frequency).
   - Use `substring(n.text,0,180)` for notes.
E) When the question asks for “everything relevant” about a Patient:
   - Return one object with:
     patient: {patient_id, name, dob, sex}
     encounters: [ {enc_id, date, reason, bp_systolic, bp_diastolic, hba1c,
                    diagnoses:[{icd10,name}], medications:[{rxnorm,name,dose,frequency}],
                    notes:[{note_id,text}] } ... ]
   - Sort encounters by e.date DESC.
   - Use LIMIT 25 on encounters unless user asks otherwise.
F) Parameters:
   - Use $patient_id for patient id unless the user explicitly provides a different parameter name.
   - Use case-insensitive search for free-text with toLower(x) CONTAINS toLower($term).

Use ONLY labels/relationships/properties from the provided schema. Do not invent any.
"""


def build_user_prompt(question: str) -> str:
    schema_json = json.dumps(GRAPH_SCHEMA, indent=2)
    return f"""Convert this question to Cypher.
IMPORTANT: Return a single JSON-like map with projected properties (no raw nodes).
If the question is patient-centric, return a patient_snapshot object.

QUESTION:
{question}

SCHEMA (JSON):
{schema_json}
"""

# -----------------------------
# 3) Small safety validator
# -----------------------------
DISALLOWED = re.compile(
    r"\b(CREATE|MERGE|DELETE|DETACH|SET|REMOVE|DROP|CALL|LOAD\s+CSV|APOC|PERIODIC)\b",
    re.IGNORECASE,
)

def validate_readonly(cypher: str) -> None:
    if DISALLOWED.search(cypher):
        raise ValueError("Generated Cypher contains disallowed write/admin clauses.")


# -----------------------------
# 4) Azure OpenAI call
# -----------------------------
def generate_cypher(question: str) -> Optional[str]:
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    )
    model_name = os.getenv("AZURE_OPENAI_MODEL_NAME")

    if not model_name:
        raise ValueError("Missing env var: AZURE_OPENAI_MODEL_NAME")

    prompt = build_user_prompt(question)

    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.0,
        )
        cypher = response.choices[0].message.content.strip()
        validate_readonly(cypher)
        return cypher
    except Exception as e:
        print(f"ERROR: {e}")
        return None


# -----------------------------
# 5) Pre-built demo questions
# -----------------------------
DEMO_QUESTIONS = [
    # 1. Simple lookup — single-hop
    "What are all the diagnoses recorded for patient P_002?",

    # 2. Multi-hop: Patient → Encounter → Medication + relationship properties
    "Which medications was patient P_001 prescribed, and at what dose and frequency?",

    # 3. Multi-hop via ClinicalNote: note text + MENTIONS score (NLP evidence vs. structured data)
    "Show me all clinical notes that mention Amlodipine, along with the mention text and confidence score.",

    # 4. Comorbidity / intersection query: two separate diagnosis paths meeting at one patient
    "Which patients have been diagnosed with both hypertension (I10) and type 2 diabetes (E11)?",

    # 5. Full patient snapshot — deepest multi-hop: Patient → Encounter → Diagnosis + Medication + ClinicalNote
    "Give me a complete clinical snapshot for patient P_003: all encounters with diagnoses, "
    "medications (dose + frequency), and any linked clinical notes.",
]


# -----------------------------
# 6) CLI entry point
# -----------------------------
def main() -> None:
    print("Neo4j NL → Cypher (Azure OpenAI)")
    print("\nPre-built questions (press Enter to use, or type your own):")
    for i, q in enumerate(DEMO_QUESTIONS, 1):
        # Wrap long questions for readability
        display = q if len(q) <= 90 else q[:87] + "..."
        print(f"  [{i}] {display}")

    print()
    raw = input("Enter a number (1-5) or type your own question: ").strip()

    if not raw:
        print("No question provided.")
        return

    if raw.isdigit() and 1 <= int(raw) <= len(DEMO_QUESTIONS):
        question = DEMO_QUESTIONS[int(raw) - 1]
        print(f"\nUsing: {question}")
    else:
        question = raw

    cypher = generate_cypher(question)
    if cypher is None:
        return

    print("\n--- Generated Cypher ---")
    print("Use :params to set parameter values as needed. For example:")
    print(":params { patient_id: 'P_002' }")
    print(cypher)


if __name__ == "__main__":
    main()
