"""
╔══════════════════════════════════════════════════════════════════════════════╗
║      LANGGRAPH ASSIGNMENT — Patient Triage & Care Pathway Agent             ║
║                         *** SOLUTION FILE ***                               ║
╚══════════════════════════════════════════════════════════════════════════════╝

This file is the complete, working solution to langgraph_patient_triage_assignment.py.
Every TODO is implemented and annotated with a WHY explanation so that reading
the solution teaches as much as running it does.

HOW TO USE THIS FILE
────────────────────
  1. Attempt the assignment yourself first.
  2. Use this file to check your implementation, not as a copy-paste shortcut.
  3. Pay attention to the "KEY DECISIONS" comments — they explain choices
     that are easy to get wrong the first time.

GRAPH TOPOLOGY (reminder)
─────────────────────────

    [START]
       │
       ▼
  intake_node ◄──────────────────────────────────────────┐
       │                                                   │ (retry)
       ▼                                                   │
  completeness_check_node ──── route_after_completeness ──┘
       │ (sufficient)
       ▼
  triage_node ──── route_after_triage ──► critical_node ──┐
                                       ──► urgent_node   ──┤
                                       ──► routine_node  ──┤
                                                           │
                                                           ▼
                                                    care_plan_node
                                                           │
                                                           ▼
                                                   recommendation_node
                                                           │
                                                           ▼
                                                         [END]
"""

# ──────────────────────────────────────────────────────────────────────────────
# IMPORTS
# ──────────────────────────────────────────────────────────────────────────────
import os
from pathlib import Path
from typing import TypedDict, Literal

from dotenv import load_dotenv
from pydantic import BaseModel, Field
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END


# ──────────────────────────────────────────────────────────────────────────────
# ENVIRONMENT SETUP
# ──────────────────────────────────────────────────────────────────────────────

def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env in any parent directory.")
    exit(1)


PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

MAX_RETRIES = 2


def build_llm() -> AzureChatOpenAI:
    return AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")+"/openai/v1/",  # Foundry endpoints need the /openai/v1/ suffix for OpenAI compatibility
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        temperature=0,
    )


# ──────────────────────────────────────────────────────────────────────────────
# ✅ TODO 1 — PatientState: add two missing fields
#
# KEY DECISIONS:
#
# 1. urgency_level uses Literal["critical", "urgent", "routine", "unknown"].
#    Literal restricts the field to a fixed set of string values, which:
#      a) Documents possible values without reading any other code.
#      b) Lets your IDE / type-checker flag a typo like "Critical" instantly.
#    The routing function does exact string comparisons against these values
#    so consistency here is not optional.
#
# 2. "unknown" is the initial sentinel for urgency_level.
#    Before triage_node runs, urgency_level has no meaningful value. We need
#    a safe placeholder so the TypedDict is valid when we build initial_state.
#    "unknown" is never routed to — it only exists in the starting dict.
#
# 3. pathway_output is a plain str (not Literal).
#    All three branch nodes (critical, urgent, routine) write free-form
#    clinical text to this field. No value restriction is appropriate here.
# ──────────────────────────────────────────────────────────────────────────────

class PatientState(TypedDict):
    # ── Input ─────────────────────────────────────────────────────────────
    raw_symptom_report: str

    # ── Set by intake_node ────────────────────────────────────────────────
    structured_symptoms: str
    retry_count: int

    # ── Set by completeness_check_node ────────────────────────────────────
    is_complete: bool

    # ── TODO 1 ✅ — two fields added ──────────────────────────────────────
    urgency_level: Literal["critical", "urgent", "routine", "unknown"]
    pathway_output: str

    # ── Set by routing_agent_node ─────────────────────────────────────────
    routing_reasoning: str           # LLM's clinical rationale for the routing decision

    # ── Set by care_plan_node and recommendation_node ─────────────────────
    care_plan: str
    recommendation: str


# ──────────────────────────────────────────────────────────────────────────────
# PROVIDED NODES (unchanged — study these as reference patterns)
# ──────────────────────────────────────────────────────────────────────────────

def intake_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Structures the free-text symptom report into a clinical intake form.
    Updates: structured_symptoms, retry_count.
    """
    print(f"\n[intake_node] Structuring symptom report "
          f"(attempt {state['retry_count'] + 1})...")

    messages = [
        SystemMessage(content=(
            "You are a clinical intake coordinator. "
            "Extract and structure the key clinical details from the patient's report. "
            "Format your response as:\n"
            "  Chief Complaint: ...\n"
            "  Reported Symptoms: ...\n"
            "  Duration: ...\n"
            "  Severity (self-reported): ...\n"
            "  Relevant History Mentioned: ...\n"
            "  Vitals Mentioned: ...\n"
            "  Missing Critical Information: ...\n"
            "If a field is not mentioned, write 'Not reported'."
        )),
        HumanMessage(content=state["raw_symptom_report"]),
    ]
    structured = llm.invoke(messages).content.strip()
    print(f"  → Structured:\n{structured[:300]}...")

    return {
        "structured_symptoms": structured,
        "retry_count": state["retry_count"] + 1,
    }


def completeness_check_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Checks whether structured intake has enough clinical detail to triage.
    Updates: is_complete.
    """
    print("[completeness_check_node] Checking clinical completeness...")

    if not state["structured_symptoms"] or len(state["structured_symptoms"]) < 80:
        print("  → Incomplete (too short)")
        return {"is_complete": False}

    messages = [
        SystemMessage(content=(
            "You are a triage nurse reviewing a clinical intake form. "
            "Determine whether the form contains enough information to safely "
            "classify urgency (chief complaint + at least one of: duration, "
            "severity description, relevant medical history, or vital signs). "
            "Reply with only YES or NO."
        )),
        HumanMessage(content=state["structured_symptoms"]),
    ]
    answer = llm.invoke(messages).content.strip().upper()
    complete = answer.startswith("YES")
    print(f"  → Complete: {complete}")
    return {"is_complete": complete}


# ──────────────────────────────────────────────────────────────────────────────
# LLM ROUTING AGENT — replacing the original triage_node
#
# THE PROBLEM WITH THE ORIGINAL APPROACH
# ───────────────────────────────────────
# The original triage_node wrote urgency_level to state, then route_after_triage
# simply returned state["urgency_level"]. The routing function had zero
# intelligence — it was just a dictionary lookup. This raises a valid question:
# why have a routing function at all if the actual decision lives in triage_node?
#
# THE LLM ROUTING AGENT PATTERN
# ──────────────────────────────
# Instead of splitting "classify" (node) from "route" (function) into two places
# that are only loosely coupled through a state field, we consolidate into:
#
#   routing_agent_node — one node that calls the LLM with structured output,
#                        receiving back BOTH the routing key AND the reasoning.
#                        Both are written to state: urgency_level + routing_reasoning.
#
#   route_after_routing_agent — a trivial one-liner that reads urgency_level.
#                               The routing function's job is purely mechanical:
#                               map a state value to a node name. The intelligence
#                               already happened in the node.
#
# LangGraph routing functions are called by the graph engine with ONLY the state —
# no LLM, no async, no side effects. They must be fast and pure. This means the
# LLM call belongs in a NODE, not in the routing function itself.
# (You could capture llm via closure and call it inside the routing function,
# but that hides a side effect inside what looks like a pure function, making
# the graph harder to test, trace, and debug.)
#
# WHY with_structured_output INSTEAD OF PARSING A STRING
# ───────────────────────────────────────────────────────
# The original triage_node asked the LLM to "reply with ONE word" then did
# substring search on the response. This works but is fragile:
#   - The LLM might prefix with "Answer:" or add punctuation
#   - There is no way to get the reasoning without a second LLM call
#   - The fallback ("routine") silently masks misclassification
#
# with_structured_output instructs the LLM to return a JSON object matching a
# Pydantic schema. LangChain handles the tool-call mechanics automatically:
#   - The routing key is always one of the three Literal values (validated)
#   - The reasoning is returned in the same call at no extra cost
#   - Validation errors surface explicitly rather than silently falling back
#
# WHAT GETS STORED IN STATE
# ──────────────────────────
# urgency_level    : the routing key, read by route_after_routing_agent
# routing_reasoning: the LLM's clinical rationale — available to care_plan_node
#                    downstream to make the care plan more context-aware
# ──────────────────────────────────────────────────────────────────────────────

class TriageDecision(BaseModel):
    """Structured output schema for the routing agent."""
    urgency_level: Literal["critical", "urgent", "routine"] = Field(
        description=(
            "Urgency classification: "
            "'critical' = immediate life/limb threat; "
            "'urgent' = same-day evaluation needed; "
            "'routine' = scheduled appointment appropriate."
        )
    )
    reasoning: str = Field(
        description=(
            "2-3 sentence clinical rationale explaining which specific symptoms "
            "or findings drove this classification and why."
        )
    )


def routing_agent_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    LLM Routing Agent — classifies urgency and explains the decision.

    Uses with_structured_output so the LLM returns a validated TriageDecision
    object instead of free text that must be parsed.

    Updates: urgency_level, routing_reasoning.
    """
    print("[routing_agent_node] LLM routing agent deciding pathway...")

    routing_llm = llm.with_structured_output(TriageDecision)

    decision: TriageDecision = routing_llm.invoke([
        SystemMessage(content=(
            "You are an emergency department triage physician with 20 years of experience. "
            "Your task is to classify the urgency of a patient's presentation and explain your reasoning.\n\n"
            "Classification levels:\n"
            "  critical — immediate life or limb threat; emergency care required NOW.\n"
            "             Examples: chest pain + diaphoresis, stroke symptoms, anaphylaxis,\n"
            "             respiratory arrest, GCS ≤ 8, major haemorrhage.\n\n"
            "  urgent   — significant risk; same-day evaluation needed.\n"
            "             Examples: high fever, severe pain (≥7/10), psychiatric crisis,\n"
            "             moderate respiratory distress, uncontrolled chronic condition.\n\n"
            "  routine  — non-urgent; suitable for a scheduled appointment.\n"
            "             Examples: mild cold, minor rash, chronic pain follow-up,\n"
            "             prescription refill, routine check-up query.\n\n"
            "Return your classification and a concise clinical rationale."
        )),
        HumanMessage(content=f"Patient intake form:\n{state['structured_symptoms']}"),
    ])

    print(f"  → Urgency level  : {decision.urgency_level}")
    print(f"  → Reasoning      : {decision.reasoning[:120]}...")

    return {
        "urgency_level":     decision.urgency_level,
        "routing_reasoning": decision.reasoning,
    }


# ──────────────────────────────────────────────────────────────────────────────
# ✅ TODO 3 — critical_node
#
# KEY DECISIONS:
#
# 1. System prompt frames the LLM as a trauma physician writing instructions
#    for a first responder who is WITH the patient RIGHT NOW. This framing
#    forces action-oriented, time-sequenced output — not passive analysis.
#
# 2. Four structured sections over free prose.
#    Structured output is more actionable in an emergency and parseable by
#    downstream systems (EHR integration, automated paging, etc.).
#
# 3. "Contraindications" section is clinically critical.
#    Well-meaning bystanders often cause harm (giving water to an unconscious
#    patient, moving someone with a suspected spinal injury). Explicitly
#    listing what NOT to do is as important as what to do.
# ──────────────────────────────────────────────────────────────────────────────

def critical_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Generates an immediate emergency protocol for a CRITICAL case.
    Updates: pathway_output.
    """
    print("[critical_node] Generating CRITICAL emergency protocol...")

    messages = [
        SystemMessage(content=(
            "You are a trauma physician writing an immediate emergency protocol "
            "for a first responder or bystander who is with the patient RIGHT NOW. "
            "Be direct, time-sequenced, and use plain language. "
            "Structure your response with these four numbered sections:\n\n"
            "1. IMMEDIATE ACTIONS (next 0-5 minutes)\n"
            "   What must be done RIGHT NOW to prevent death or deterioration.\n\n"
            "2. EMERGENCY SERVICES\n"
            "   When and how to call 911. What information to give the dispatcher.\n\n"
            "3. CONTRAINDICATIONS\n"
            "   What NOT to do before emergency services arrive.\n\n"
            "4. MONITORING\n"
            "   Which signs to watch for while waiting. When to start CPR or use AED."
        )),
        HumanMessage(content=f"CRITICAL patient presentation:\n{state['structured_symptoms']}"),
    ]

    output = llm.invoke(messages).content.strip()
    print(f"  → Critical protocol generated ({len(output)} chars)")
    return {"pathway_output": f"[CRITICAL PATHWAY]\n{output}"}


# ──────────────────────────────────────────────────────────────────────────────
# ✅ TODO 4 — urgent_node
#
# KEY DECISIONS:
#
# 1. "Red flag symptoms" section is the most important safety element.
#    The patient is not in immediate danger, but could deteriorate. Giving
#    explicit escalation criteria prevents an urgent case from becoming
#    a critical one while the patient waits at home.
#
# 2. Frame as a telephone triage nurse — naturally produces patient-friendly
#    language (not academic medicine) with practical logistics included.
#
# 3. "Care setting" guidance matters — urgent care vs ED vs GP same-day are
#    different resource commitments with very different wait times.
# ──────────────────────────────────────────────────────────────────────────────

def urgent_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Generates a same-day care protocol for an URGENT case.
    Updates: pathway_output.
    """
    print("[urgent_node] Generating URGENT care protocol...")

    messages = [
        SystemMessage(content=(
            "You are an urgent care telephone triage nurse advising a patient "
            "who has called a nurse hotline. They need same-day care but are "
            "not in immediate danger. Be reassuring but clear. "
            "Structure your response with these four sections:\n\n"
            "1. IMMEDIATE COMFORT MEASURES\n"
            "   Safe self-care steps the patient can take RIGHT NOW.\n\n"
            "2. RECOMMENDED CARE SETTING\n"
            "   Urgent care centre, emergency department, or same-day GP? Explain why.\n\n"
            "3. RED FLAG SYMPTOMS — CALL 911 IF ANY OF THESE OCCUR\n"
            "   List 4-6 specific warning signs that require immediate escalation.\n\n"
            "4. WHAT TO BRING TO THE APPOINTMENT\n"
            "   Medication list, symptom timeline, insurance information, etc."
        )),
        HumanMessage(content=f"URGENT patient presentation:\n{state['structured_symptoms']}"),
    ]

    output = llm.invoke(messages).content.strip()
    print(f"  → Urgent protocol generated ({len(output)} chars)")
    return {"pathway_output": f"[URGENT PATHWAY]\n{output}"}


# ──────────────────────────────────────────────────────────────────────────────
# ✅ TODO 5 — routine_node
#
# KEY DECISIONS:
#
# 1. "Upgrade triggers" are the safety net for routine cases.
#    A patient with a mild cough could develop pneumonia. Explicit criteria
#    for when to escalate prevent under-triage from becoming dangerous.
#
# 2. Frame as a primary care nurse on a non-urgent advice line.
#    Calm, empowering language is appropriate — the patient is not seriously
#    ill and should not be alarmed, but must stay informed.
#
# 3. "Expected timeline for booking" addresses a common patient confusion:
#    should I book 2 days or 2 weeks out? Making this explicit prevents both
#    unnecessary ED visits and dangerously delayed appointments.
# ──────────────────────────────────────────────────────────────────────────────

def routine_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Generates a scheduled outpatient recommendation for a ROUTINE case.
    Updates: pathway_output.
    """
    print("[routine_node] Generating ROUTINE outpatient recommendation...")

    messages = [
        SystemMessage(content=(
            "You are a primary care nurse giving advice on a non-urgent patient "
            "advice line. The patient does not need emergency or same-day care. "
            "Be calm, reassuring, and practical. "
            "Structure your response with these four sections:\n\n"
            "1. SELF-CARE FOR THE NEXT 24-48 HOURS\n"
            "   Safe, evidence-based home care steps.\n\n"
            "2. APPOINTMENT TYPE AND BOOKING TIMELINE\n"
            "   Which type of provider and how soon to book.\n\n"
            "3. WHAT TO TRACK BEFORE THE APPOINTMENT\n"
            "   Symptoms or measurements to record for the clinician.\n\n"
            "4. UPGRADE TRIGGERS — SEEK URGENT CARE IF\n"
            "   4-5 specific signs that mean this routine issue needs same-day attention."
        )),
        HumanMessage(content=f"ROUTINE patient presentation:\n{state['structured_symptoms']}"),
    ]

    output = llm.invoke(messages).content.strip()
    print(f"  → Routine protocol generated ({len(output)} chars)")
    return {"pathway_output": f"[ROUTINE PATHWAY]\n{output}"}


# ──────────────────────────────────────────────────────────────────────────────
# ✅ TODO 6 — care_plan_node
#
# KEY DECISIONS:
#
# 1. This node reads TWO state fields: structured_symptoms AND pathway_output.
#    structured_symptoms gives patient-specific clinical context.
#    pathway_output gives the pre-computed urgency-specific advice.
#    The LLM's job here is to SYNTHESISE and FORMAT, not re-analyse from
#    scratch — which would be redundant and risk producing inconsistencies.
#
# 2. Rigid output format with exact section headers.
#    The format mirrors real clinical documentation standards. Rigid headers
#    make the output scannable in an emergency and parseable programmatically
#    (EHR integration, automated paging, audit logging).
#
# 3. urgency_level is injected into the HumanMessage, not just derived.
#    This ensures the "TRIAGE LEVEL" header in the output matches what the
#    routing function actually decided — no risk of the LLM re-classifying.
# ──────────────────────────────────────────────────────────────────────────────

def care_plan_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Convergence point — all three branches route here.
    Synthesises intake + pathway advice into a structured care plan.
    Updates: care_plan.
    """
    print("[care_plan_node] Synthesising structured care plan...")

    messages = [
        SystemMessage(content=(
            "You are a senior clinician documenting a structured care plan "
            "from a triage assessment and pathway recommendation. "
            "Use EXACTLY this format (section headers verbatim):\n\n"
            "TRIAGE LEVEL: <CRITICAL | URGENT | ROUTINE>\n"
            "─────────────────────────────────────────────\n"
            "PRESENTING COMPLAINT:\n"
            "  [One sentence summary of chief complaint]\n\n"
            "IMMEDIATE ACTIONS:\n"
            "  1. [action]\n"
            "  2. [action]\n"
            "  (list 3-5 concrete, time-ordered actions)\n\n"
            "CARE PATHWAY:\n"
            "  [Summary of recommended pathway and rationale]\n\n"
            "MONITORING & ESCALATION TRIGGERS:\n"
            "  • [sign to monitor / threshold to escalate at]\n"
            "  (list 4-6 items)\n\n"
            "ANTICIPATED DISPOSITION:\n"
            "  [Where the patient will be managed and expected outcome]"
        )),
        HumanMessage(content=(
            f"TRIAGE LEVEL: {state['urgency_level'].upper()}\n\n"
            f"CLINICAL INTAKE:\n{state['structured_symptoms']}\n\n"
            f"PATHWAY RECOMMENDATION:\n{state['pathway_output']}"
        )),
    ]

    plan = llm.invoke(messages).content.strip()
    print(f"  → Care plan generated ({len(plan)} chars)")
    return {"care_plan": plan}


# ──────────────────────────────────────────────────────────────────────────────
# ✅ TODO 7 — recommendation_node
#
# KEY DECISIONS:
#
# 1. Input is state["care_plan"], NOT state["structured_symptoms"].
#    The care plan was already validated by care_plan_node. Re-analysing raw
#    symptoms here would be redundant and could produce inconsistencies with
#    the upstream care plan. Always build on the most recent validated output.
#
# 2. "WHEN TO CALL 911" is always present regardless of urgency level.
#    Even a routine case can deteriorate overnight. This section is the
#    safety net that prevents under-triage at the patient communication layer.
#
# 3. System prompt frames the LLM as a "patient educator" not a clinician.
#    This naturally produces simpler vocabulary, active voice, and avoids
#    jargon — exactly right for a patient-facing final output.
# ──────────────────────────────────────────────────────────────────────────────

def recommendation_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Final node — translates the clinical care plan into plain-language
    patient instructions.
    Updates: recommendation.
    """
    print("[recommendation_node] Generating final patient recommendation...")

    messages = [
        SystemMessage(content=(
            "You are a patient educator translating a clinical care plan "
            "into clear, plain-language instructions for the patient. "
            "Avoid medical jargon. Use short sentences and active voice. "
            "Structure your response with these five sections:\n\n"
            "RECOMMENDATION SUMMARY\n"
            "──────────────────────\n"
            "What to do RIGHT NOW:\n"
            "  [1-3 immediate, specific actions]\n\n"
            "Where to go:\n"
            "  [Specific care setting with a brief reason]\n\n"
            "What to tell the doctor:\n"
            "  [3-4 key facts to communicate at the visit]\n\n"
            "Expected next steps:\n"
            "  [What will likely happen at the appointment / in the next 24-48h]\n\n"
            "WHEN TO CALL 911:\n"
            "  [3-4 specific warning signs requiring immediate emergency response]"
        )),
        HumanMessage(content=f"Clinical care plan to translate:\n\n{state['care_plan']}"),
    ]

    recommendation = llm.invoke(messages).content.strip()
    print(f"  → Recommendation generated ({len(recommendation)} chars)")
    return {"recommendation": recommendation}


# ──────────────────────────────────────────────────────────────────────────────
# ✅ TODO 8 — route_after_completeness  (CONDITIONAL EDGE #1 — retry loop)
#
# KEY DECISIONS:
#
# 1. The condition checks BOTH is_complete AND retry_count — not one alone.
#    is_complete alone → infinite loop on genuinely vague input.
#    retry_count alone → bypasses the completeness gate entirely after one run.
#    Both together are required for correctness.
#
# 2. Why compare retry_count < MAX_RETRIES (not retry_count - 1)?
#    intake_node increments retry_count BEFORE returning. After the first
#    run retry_count == 1. With MAX_RETRIES = 2:
#      Run 1: increments to 1 → 1 < 2 is True  → one retry allowed
#      Run 2: increments to 2 → 2 < 2 is False → proceed regardless
#    This gives exactly MAX_RETRIES - 1 retries after the initial attempt.
#
# 3. Return type Literal["retry", "continue"] must EXACTLY match the keys
#    in the mapping dict passed to add_conditional_edges(). A typo produces
#    a runtime KeyError. The Literal annotation makes this visible earlier.
# ──────────────────────────────────────────────────────────────────────────────

def route_after_completeness(state: PatientState) -> Literal["retry", "continue"]:
    """
    CONDITIONAL EDGE #1 — implements the retry loop.
    Returns "retry"    → back to intake_node
    Returns "continue" → forward to triage_node
    """
    if not state["is_complete"] and state["retry_count"] < MAX_RETRIES:
        print(f"  [router] Insufficient data — retrying "
              f"(retry_count={state['retry_count']}, MAX_RETRIES={MAX_RETRIES})")
        return "retry"

    if not state["is_complete"]:
        print(f"  [router] Still insufficient but MAX_RETRIES reached — proceeding anyway")
    else:
        print(f"  [router] Data sufficient — proceeding to triage")

    return "continue"


# ──────────────────────────────────────────────────────────────────────────────
# ✅ TODO 9 — route_after_routing_agent  (CONDITIONAL EDGE #2 — three-way branch)
#
# KEY DECISIONS:
#
# 1. The routing function is now intentionally trivial — one line.
#    All the intelligence (the LLM call, the clinical reasoning) lives in
#    routing_agent_node. The routing function's only job is to map the
#    decision already in state to a node name. Keeping it pure and fast
#    makes the graph easy to test: mock the state, assert the return value.
#
# 2. with_structured_output in routing_agent_node guarantees the value is
#    always one of the three Literal values. The Pydantic validation would
#    have raised before we got here if the LLM returned anything else.
#    The fallback guard below is still worth keeping as a defensive measure
#    for the "unknown" sentinel in the initial state.
#
# 3. Compare this to the old route_after_triage:
#    OLD: routing function returned state["urgency_level"] — looked hardcoded
#         because the LLM decision was hidden inside a separate triage_node.
#    NEW: same mechanical read, but now the LLM, the schema, and the reasoning
#         are all visible together in routing_agent_node. The separation of
#         concerns is explicit: nodes do work, routing functions do dispatch.
# ──────────────────────────────────────────────────────────────────────────────

def route_after_routing_agent(state: PatientState) -> Literal["critical", "urgent", "routine"]:
    """
    CONDITIONAL EDGE #2 — reads the routing decision made by routing_agent_node.

    The intelligence is in routing_agent_node (LLM + structured output).
    This function is deliberately trivial: it dispatches, it does not decide.

    Returns "critical" → critical_node
    Returns "urgent"   → urgent_node
    Returns "routine"  → routine_node
    """
    level = state["urgency_level"]

    # Defensive fallback for the "unknown" sentinel in the initial state
    if level not in ("critical", "urgent", "routine"):
        print(f"  [router] Unexpected urgency_level '{level}' — defaulting to routine")
        level = "routine"

    print(f"  [router] Dispatching to → {level}_node  |  Reason: {state.get('routing_reasoning', '')[:80]}...")
    return level


# ──────────────────────────────────────────────────────────────────────────────
# ✅ TODO 10 — build_graph()
#
# KEY DECISIONS:
#
# 1. Lambda wrappers for LLM-dependent nodes.
#    LangGraph requires node functions to have the signature (state) -> dict.
#    Our nodes take a second argument (llm). The lambda captures llm from the
#    enclosing scope of build_graph() and presents a one-argument callable.
#    Alternative: functools.partial(my_node, llm=llm).
#
# 2. Pass the routing FUNCTION object, not a call to it.
#    add_conditional_edges("node", route_after_completeness, {...})  ← correct
#    add_conditional_edges("node", route_after_completeness(), {...}) ← wrong
#    The second form calls route_after_completeness() immediately with no
#    arguments and would raise a TypeError.
#
# 3. Three edges to one target node implements fan-in without any special API.
#    critical_node, urgent_node, and routine_node all add_edge to care_plan_node.
#    LangGraph has no dedicated "merge" primitive — convergence is just multiple
#    edges pointing at the same destination.
#
# 4. graph.compile() validates the entire topology before the first invoke().
#    Errors here — dangling edges, unreachable nodes, missing conditional keys —
#    are much easier to debug than errors that surface mid-execution.
# ──────────────────────────────────────────────────────────────────────────────

def build_graph(llm: AzureChatOpenAI):
    """
    Assembles and compiles the patient triage StateGraph.
    Returns a compiled LangGraph Runnable.
    """

    # Step 1 — create the StateGraph with our state schema
    graph = StateGraph(PatientState)

    # Step 2 — register all nodes
    # Nodes needing the LLM are wrapped in lambdas so LangGraph sees
    # a single-argument callable: (PatientState) -> dict
    graph.add_node("intake_node",             lambda s: intake_node(s, llm))
    graph.add_node("completeness_check_node", lambda s: completeness_check_node(s, llm))
    graph.add_node("routing_agent_node",      lambda s: routing_agent_node(s, llm))
    graph.add_node("critical_node",           lambda s: critical_node(s, llm))
    graph.add_node("urgent_node",             lambda s: urgent_node(s, llm))
    graph.add_node("routine_node",            lambda s: routine_node(s, llm))
    graph.add_node("care_plan_node",          lambda s: care_plan_node(s, llm))
    graph.add_node("recommendation_node",     lambda s: recommendation_node(s, llm))

    # Step 3 — set the entry point (first node to execute)
    graph.set_entry_point("intake_node")

    # Step 4 — linear edge: intake → completeness check
    graph.add_edge("intake_node", "completeness_check_node")

    # Step 5 — CONDITIONAL EDGE #1: retry loop
    # route_after_completeness returns "retry" or "continue".
    # The mapping translates those string keys to actual node names.
    graph.add_conditional_edges(
        "completeness_check_node",
        route_after_completeness,
        {
            "retry":    "intake_node",          # creates the cycle — loops back
            "continue": "routing_agent_node",   # LLM routing agent decides pathway
        },
    )

    # Step 6 — CONDITIONAL EDGE #2: three-way urgency branch
    # routing_agent_node wrote urgency_level to state via structured output.
    # route_after_routing_agent reads that decision and dispatches to the right node.
    graph.add_conditional_edges(
        "routing_agent_node",
        route_after_routing_agent,
        {
            "critical": "critical_node",
            "urgent":   "urgent_node",
            "routine":  "routine_node",
        },
    )

    # Step 7 — all three branches converge at care_plan_node (fan-in)
    # No special merge primitive needed — just three edges to the same target.
    graph.add_edge("critical_node", "care_plan_node")
    graph.add_edge("urgent_node",   "care_plan_node")
    graph.add_edge("routine_node",  "care_plan_node")

    # Step 8 — linear tail: care plan → recommendation → END
    graph.add_edge("care_plan_node",      "recommendation_node")
    graph.add_edge("recommendation_node", END)

    # Step 9 — compile: validates topology and returns a Runnable
    # Fix any errors here before calling invoke() — they are much easier to
    # debug at compile time than mid-execution.
    return graph.compile()


# ──────────────────────────────────────────────────────────────────────────────
# MAIN  (identical to assignment)
# ──────────────────────────────────────────────────────────────────────────────

SAMPLE_INPUTS = {
    "critical": (
        "I have crushing chest pain radiating to my left arm and jaw that started "
        "20 minutes ago. I'm sweating heavily and feel nauseous. I'm 58 years old "
        "and have a history of high blood pressure. The pain is a 9 out of 10."
    ),
    "urgent": (
        "I've had a high fever of 39.5°C for two days, severe headache, and my neck "
        "feels very stiff. I'm sensitive to light. I'm 24 years old with no major "
        "medical history. Paracetamol isn't bringing the fever down."
    ),
    "routine": (
        "I've had a mild sore throat and runny nose for three days. "
        "No fever, just a bit of fatigue. I think I caught a cold at work."
    ),
    "incomplete": (
        "I feel unwell."
    ),
}


def main():
    print("\n╔══════════════════════════════════════════════════════╗")
    print("║   LangGraph Patient Triage & Care Pathway Agent     ║")
    print("╚══════════════════════════════════════════════════════╝")

    llm = build_llm()
    app = build_graph(llm)

    print("\n── Graph Topology (Mermaid) ──")
    print(app.get_graph().draw_mermaid())

    print("\nInput options:")
    print("  [1] Type your own symptom description")
    print("  [2] Run sample CRITICAL case")
    print("  [3] Run sample URGENT case")
    print("  [4] Run sample ROUTINE case")
    print("  [5] Run INCOMPLETE case (tests the retry loop)")
    choice = input("\nChoose [1-5]: ").strip()

    if choice == "1":
        symptom_report = input("Describe your symptoms: ").strip()
    elif choice == "2":
        symptom_report = SAMPLE_INPUTS["critical"]
        print(f"\nUsing CRITICAL sample:\n  {symptom_report[:80]}...")
    elif choice == "3":
        symptom_report = SAMPLE_INPUTS["urgent"]
        print(f"\nUsing URGENT sample:\n  {symptom_report[:80]}...")
    elif choice == "4":
        symptom_report = SAMPLE_INPUTS["routine"]
        print(f"\nUsing ROUTINE sample:\n  {symptom_report[:80]}...")
    elif choice == "5":
        symptom_report = SAMPLE_INPUTS["incomplete"]
        print(f"\nUsing INCOMPLETE sample:\n  '{symptom_report}'")
    else:
        print("Invalid choice — using URGENT sample.")
        symptom_report = SAMPLE_INPUTS["urgent"]

    if not symptom_report:
        print("ERROR: No symptom report provided.")
        exit(1)

    initial_state: PatientState = {
        "raw_symptom_report": symptom_report,
        "structured_symptoms": "",
        "retry_count": 0,
        "is_complete": False,
        "urgency_level": "unknown",
        "pathway_output": "",
        "routing_reasoning": "",
        "care_plan": "",
        "recommendation": "",
    }

    print("\n── Running Triage Pipeline ──\n")
    final_state = app.invoke(initial_state)

    print("\n" + "═" * 60)
    print("TRIAGE RESULT")
    print("═" * 60)
    print(f"Urgency Level : {final_state['urgency_level'].upper()}")
    print(f"Routing Reason: {final_state['routing_reasoning']}")
    print(f"Intake Retries: {final_state['retry_count'] - 1}")
    print()
    print("── CARE PLAN ──")
    print(final_state["care_plan"])
    print()
    print("── PATIENT RECOMMENDATION ──")
    print(final_state["recommendation"])
    print("═" * 60)


if __name__ == "__main__":
    main()
