"""
╔══════════════════════════════════════════════════════════════════════════════╗
║         LANGGRAPH ASSIGNMENT — Patient Triage & Care Pathway Agent          ║
╚══════════════════════════════════════════════════════════════════════════════╝

OVERVIEW
────────
You will build a clinical triage agent that accepts a patient's free-text
symptom report, classifies urgency, routes the case through a specialised
care pathway, and produces a structured care recommendation.

The workflow mirrors real emergency department triage logic:
  1. Intake       → structure the patient's symptom report
  2. Completeness → do we have enough clinical information?  (retry if not)
  3. Triage       → classify urgency: CRITICAL / URGENT / ROUTINE
  4. Pathway      → specialised protocol per urgency level (three branches)
  5. Care Plan    → unified care plan from the pathway output
  6. Recommend    → final clinical recommendation + disposition

This assignment reinforces every LangGraph construct from the stock demo:

  ┌─────────────────────────────────────────────────────────────────────┐
  │  Construct          │  Where it appears in THIS file                │
  ├─────────────────────────────────────────────────────────────────────┤
  │  TypedDict State    │  PatientState  (partial — you complete it)    │
  │  Nodes              │  6 node functions  (stubs — you implement)    │
  │  Conditional Edges  │  2 routing functions  (you implement both)    │
  │  Cycle / Retry      │  route_after_completeness  (you wire it)      │
  │  Branching          │  route_after_triage  (you wire it)            │
  │  Graph Assembly     │  build_graph()  (skeleton — you complete)     │
  └─────────────────────────────────────────────────────────────────────╝

TARGET GRAPH TOPOLOGY
─────────────────────

    [START]
       │
       ▼
  intake_node ◄──────────────────────────────────────────┐
       │                                                   │ (retry)
       ▼                                                   │
  completeness_check_node ──── route_after_completeness ──┘
       │ (sufficient)
       ▼
  routing_agent_node ── route_after_routing_agent ──► critical_node ──┐
                                                   ──► urgent_node   ──┤
                                                   ──► routine_node  ──┤
                                                           │
                                                           ▼
                                                    care_plan_node
                                                           │
                                                           ▼
                                                   recommendation_node
                                                           │
                                                           ▼
                                                         [END]

WHAT IS PROVIDED (do NOT modify these)
───────────────────────────────────────
  ✓  All imports
  ✓  Environment / LLM setup helpers
  ✓  intake_node          — study this carefully; it shows the node pattern
  ✓  completeness_check_node — shows the LLM quality-gate pattern
  ✓  main()               — entry point; runs when you run this file

WHAT YOU MUST IMPLEMENT  (search for TODO in this file)
────────────────────────────────────────────────────────
  TODO 1  PatientState  — add two missing fields to the state TypedDict
  TODO 2  routing_agent_node — LLM routing agent: classify urgency + capture reasoning
  TODO 3  critical_node — immediate emergency protocol
  TODO 4  urgent_node   — same-day / same-shift care protocol
  TODO 5  routine_node  — scheduled outpatient care protocol
  TODO 6  care_plan_node — merge pathway output into a structured care plan
  TODO 7  recommendation_node — final disposition and patient instructions
  TODO 8  route_after_completeness — routing function (retry loop)
  TODO 9  route_after_routing_agent — routing function (three-way branch)
  TODO 10 build_graph()  — wire all nodes and edges; compile

GRADING CRITERIA
────────────────
  • The graph compiles without errors                          (10 pts)
  • The Mermaid diagram printed at startup matches the topology above (10 pts)
  • The retry loop works: incomplete input loops back          (20 pts)
  • All three triage branches are reached by matching input   (20 pts)
  • care_plan_node produces a structured clinical output       (20 pts)
  • recommendation_node produces a clear patient disposition  (20 pts)

REFERENCE — key LangGraph API calls you will use
──────────────────────────────────────────────────
  graph = StateGraph(PatientState)
  graph.add_node("node_name", lambda s: my_function(s, llm))
  graph.set_entry_point("first_node")
  graph.add_edge("from_node", "to_node")
  graph.add_conditional_edges("from_node", routing_fn, {"key": "target_node"})
  graph.add_edge("last_node", END)
  compiled = graph.compile()
  compiled.get_graph().draw_mermaid()   ← prints the topology diagram
"""

# ──────────────────────────────────────────────────────────────────────────────
# IMPORTS  (do not modify)
# ──────────────────────────────────────────────────────────────────────────────
import os
from pathlib import Path
from typing import TypedDict, Literal

from dotenv import load_dotenv
from pydantic import BaseModel, Field
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END


# ──────────────────────────────────────────────────────────────────────────────
# ENVIRONMENT SETUP  (do not modify)
# ──────────────────────────────────────────────────────────────────────────────

def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env in any parent directory.")
    exit(1)


PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

MAX_RETRIES = 2   # maximum completeness retries before proceeding anyway


def build_llm() -> AzureChatOpenAI:
    return AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")+"/openai/v1/",  # Foundry endpoints need the /openai/v1/ suffix for OpenAI compatibility
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        temperature=0,
    )


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 1 — STATE
#
# PatientState is the single typed container shared across every node.
# Every node receives the full state and returns a PARTIAL dict of updates.
# LangGraph merges those updates into the state before calling the next node.
#
# Field naming convention used here:
#   - Input fields   : set once at the start, never overwritten
#   - Pipeline fields: set by a specific node, read by later nodes
#   - Output fields  : set near the end; form the final answer
# ──────────────────────────────────────────────────────────────────────────────

class PatientState(TypedDict):
    # ── Input ──────────────────────────────────────────────────────────────
    raw_symptom_report: str          # free-text symptom description from patient

    # ── Set by intake_node ─────────────────────────────────────────────────
    structured_symptoms: str         # structured symptom summary (age, complaint, vitals if given)
    retry_count: int                 # tracks how many completeness retries have occurred

    # ── Set by completeness_check_node ─────────────────────────────────────
    is_complete: bool                # True if enough clinical info to triage

    # ── TODO 1 ─────────────────────────────────────────────────────────────
    # Add three more fields that the triage pipeline needs:
    #
    #   Field A:  the urgency classification produced by routing_agent_node.
    #             It must be one of three specific string literals so that
    #             the routing function can do an exact-match comparison.
    #             Hint: use  Literal["critical", "urgent", "routine", "unknown"]
    #
    #   Field B:  the clinical pathway output produced by whichever of the
    #             three branch nodes runs (critical / urgent / routine).
    #             It is a plain string containing the pathway-specific advice.
    #
    #   Field C:  the LLM's clinical reasoning behind the routing decision,
    #             returned by routing_agent_node alongside urgency_level.
    #             Stored so downstream nodes (e.g. care_plan_node) can use it.
    #             It is a plain string.
    #
    # Example skeleton (fill in the types):
    #   urgency_level:     ???
    #   pathway_output:    ???
    #   routing_reasoning: ???
    #
    # YOUR CODE HERE ↓

    # ── Set by care_plan_node and recommendation_node ──────────────────────
    care_plan: str                   # structured care plan
    recommendation: str              # final patient disposition and next steps


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 2 — NODES
#
# Each node is a plain Python function:
#     def my_node(state: PatientState) -> dict:
#         ...
#         return {"field_to_update": new_value}
#
# Rules:
#   • Accept the full state; return ONLY the keys you are updating.
#   • Never mutate the state dict directly — always return a new dict.
#   • If your node needs the LLM, accept it as a second parameter and
#     bind it in build_graph() with:  lambda s: my_node(s, llm)
# ──────────────────────────────────────────────────────────────────────────────

# ── PROVIDED: intake_node ─────────────────────────────────────────────────────
# Study this node carefully — it shows the complete pattern.
def intake_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Parse the patient's free-text symptom report into a structured clinical
    summary.  This is the entry point of the graph.

    Updates: structured_symptoms, retry_count
    """
    print(f"\n[intake_node] Structuring symptom report "
          f"(attempt {state['retry_count'] + 1})...")

    messages = [
        SystemMessage(content=(
            "You are a clinical intake coordinator. "
            "Extract and structure the key clinical details from the patient's report. "
            "Format your response as:\n"
            "  Chief Complaint: ...\n"
            "  Reported Symptoms: ...\n"
            "  Duration: ...\n"
            "  Severity (self-reported): ...\n"
            "  Relevant History Mentioned: ...\n"
            "  Vitals Mentioned: ...\n"
            "  Missing Critical Information: ...\n"
            "If a field is not mentioned, write 'Not reported'."
        )),
        HumanMessage(content=state["raw_symptom_report"]),
    ]
    structured = llm.invoke(messages).content.strip()
    print(f"  → Structured:\n{structured[:300]}...")

    return {
        "structured_symptoms": structured,
        "retry_count": state["retry_count"] + 1,
    }


# ── PROVIDED: completeness_check_node ────────────────────────────────────────
# This node shows the LLM-as-quality-gate pattern.
def completeness_check_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Assess whether the structured symptom report contains enough clinical
    information to make a safe triage decision.

    Minimum required: chief complaint + at least one concrete symptom detail
    (duration, severity, or relevant history).

    Updates: is_complete

    HINT for TODO 8 — this node's output (is_complete) is what your
    route_after_completeness function should inspect.
    """
    print("[completeness_check_node] Checking clinical completeness...")

    # Fast-path: if structured_symptoms is empty or trivially short, it is incomplete
    if not state["structured_symptoms"] or len(state["structured_symptoms"]) < 80:
        print("  → Incomplete (too short)")
        return {"is_complete": False}

    messages = [
        SystemMessage(content=(
            "You are a triage nurse reviewing a clinical intake form. "
            "Determine whether the form contains enough information to safely "
            "classify urgency (chief complaint + at least one of: duration, "
            "severity description, relevant medical history, or vital signs). "
            "Reply with only YES or NO."
        )),
        HumanMessage(content=state["structured_symptoms"]),
    ]
    answer = llm.invoke(messages).content.strip().upper()
    complete = answer.startswith("YES")
    print(f"  → Complete: {complete}")
    return {"is_complete": complete}


# ── TODO 2 — routing_agent_node ──────────────────────────────────────────────
#
# WHY A ROUTING AGENT NODE INSTEAD OF A PLAIN TRIAGE NODE?
# ─────────────────────────────────────────────────────────
# A naive approach asks the LLM for a single word ("CRITICAL"), then parses
# the string with if/elif.  This works but has two problems:
#   1. The routing decision is invisible — it's consumed by the node and the
#      only trace is the urgency_level field, with no explanation of why.
#   2. String parsing is fragile ("CRITICAL." vs "CRITICAL" vs "Critical risk").
#
# The LLM Routing Agent pattern fixes both:
#   • Use with_structured_output(TriageDecision) — the LLM returns a validated
#     Pydantic object, never a free-form string that needs parsing.
#   • The object contains BOTH the routing key AND the clinical reasoning.
#   • Both are stored in state, so downstream nodes and the final output can
#     explain HOW the urgency level was determined.
#
# LangGraph routing functions (the functions passed to add_conditional_edges)
# must be fast, pure, and side-effect-free — no LLM calls inside them.
# The LLM call belongs here, in a NODE.  The routing function simply reads
# the decision that this node already wrote to state.
#
# PROVIDED — TriageDecision schema (do not modify)
# ─────────────────────────────────────────────────
# This Pydantic model is the structured output contract between the LLM and
# the rest of the graph.  with_structured_output will validate that the LLM
# always returns exactly these two fields with the correct types.

class TriageDecision(BaseModel):
    urgency_level: Literal["critical", "urgent", "routine"] = Field(
        description=(
            "Urgency classification: "
            "'critical' = immediate life/limb threat; "
            "'urgent' = same-day evaluation needed; "
            "'routine' = scheduled appointment appropriate."
        )
    )
    reasoning: str = Field(
        description=(
            "2-3 sentence clinical rationale explaining which specific symptoms "
            "or findings drove this classification and why."
        )
    )


def routing_agent_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    LLM Routing Agent — classifies urgency and captures the reasoning.

    Uses llm.with_structured_output(TriageDecision) so the LLM returns a
    validated TriageDecision object (not free text).

    Updates: urgency_level, routing_reasoning

    HINT — create a structured-output LLM like this:
        routing_llm = llm.with_structured_output(TriageDecision)

    HINT — invoke it exactly like a regular LLM:
        decision: TriageDecision = routing_llm.invoke([
            SystemMessage(content="You are a triage physician..."),
            HumanMessage(content=state["structured_symptoms"]),
        ])

    HINT — decision.urgency_level is already lowercase ("critical" / "urgent" /
    "routine") because Pydantic validates it against the Literal type.
    No if/elif parsing needed.

    HINT — return BOTH fields so they are available to downstream nodes:
        return {
            "urgency_level":     decision.urgency_level,
            "routing_reasoning": decision.reasoning,
        }
    """
    print("[routing_agent_node] LLM routing agent deciding pathway...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 2: implement routing_agent_node")


# ── TODO 3 — critical_node ────────────────────────────────────────────────────
def critical_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Reached ONLY when urgency_level == "critical".

    Generate an immediate emergency response protocol covering:
      1. Immediate actions (first 0-5 minutes) — what to do RIGHT NOW
      2. Emergency services — when and how to call 911 / activate rapid response
      3. Contraindications — what NOT to do before EMS arrives
      4. Monitoring — what signs to watch for while waiting

    Updates: pathway_output

    HINT — the system prompt should frame the LLM as a trauma / emergency
    physician writing instructions for the on-scene responder.

    HINT — use state["structured_symptoms"] for the clinical input.
    """
    print("[critical_node] Generating CRITICAL emergency protocol...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 3: implement critical_node")


# ── TODO 4 — urgent_node ──────────────────────────────────────────────────────
def urgent_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Reached ONLY when urgency_level == "urgent".

    Generate a same-day care protocol covering:
      1. Immediate comfort / safety measures the patient can take now
      2. Recommended care setting (urgent care, ED, GP same-day)
      3. Red flag symptoms — when to escalate to emergency immediately
      4. What information to bring to the appointment

    Updates: pathway_output

    HINT — frame the LLM as an urgent care nurse providing telephone triage.
    """
    print("[urgent_node] Generating URGENT care protocol...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 4: implement urgent_node")


# ── TODO 5 — routine_node ────────────────────────────────────────────────────
def routine_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Reached ONLY when urgency_level == "routine".

    Generate a scheduled outpatient care recommendation covering:
      1. Self-care measures for the next 24-48 hours
      2. Appropriate appointment type (GP, specialist, telehealth)
      3. Expected timeline for booking
      4. Warning signs that would require upgrading to urgent care

    Updates: pathway_output

    HINT — frame the LLM as a primary care nurse advising a patient
    who called a non-urgent advice line.
    """
    print("[routine_node] Generating ROUTINE outpatient recommendation...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 5: implement routine_node")


# ── TODO 6 — care_plan_node ───────────────────────────────────────────────────
def care_plan_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Convergence point — all three pathway branches flow into this node.

    Synthesise the pathway_output into a formal, structured care plan using
    this exact format:

      TRIAGE LEVEL: <CRITICAL | URGENT | ROUTINE>
      ─────────────────────────────────────────────
      PRESENTING COMPLAINT:
        ...
      IMMEDIATE ACTIONS:
        1. ...
        2. ...
      CARE PATHWAY:
        ...
      MONITORING & ESCALATION TRIGGERS:
        ...
      ANTICIPATED DISPOSITION:
        ...

    Updates: care_plan

    HINT — you have access to both state["pathway_output"] (the branch advice)
    and state["structured_symptoms"] (the clinical intake).
    Use both to make the plan concrete and patient-specific.
    """
    print("[care_plan_node] Synthesising structured care plan...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 6: implement care_plan_node")


# ── TODO 7 — recommendation_node ─────────────────────────────────────────────
def recommendation_node(state: PatientState, llm: AzureChatOpenAI) -> dict:
    """
    Final node — produces the patient-facing recommendation and disposition.

    Structure your output as:

      RECOMMENDATION SUMMARY
      ──────────────────────
      What to do RIGHT NOW:   ...
      Where to go:            ...
      What to tell the doctor:...
      Expected next steps:    ...
      WHEN TO CALL 911:       ...

    This is what gets printed to the patient (or care coordinator).

    Updates: recommendation

    HINT — use state["care_plan"] as your input.  The LLM should translate the
    clinical care plan into clear, plain-language patient instructions.
    """
    print("[recommendation_node] Generating final patient recommendation...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 7: implement recommendation_node")


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 3 — CONDITIONAL EDGES  (routing functions)
#
# A routing function:
#   • Accepts the full state
#   • Returns a STRING key
#   • The key is looked up in the mapping dict you provide to
#     graph.add_conditional_edges() to find the next node
#
# Return type annotation ( Literal["a", "b"] ) is optional but recommended —
# it documents the possible return values for the reader.
# ──────────────────────────────────────────────────────────────────────────────

# ── TODO 8 — route_after_completeness ────────────────────────────────────────
def route_after_completeness(state: PatientState) -> Literal["retry", "continue"]:
    """
    Implements the RETRY LOOP.

    Decision logic:
      • If is_complete is False AND retry_count < MAX_RETRIES → return "retry"
        (routes back to intake_node for another attempt)
      • Otherwise → return "continue"
        (routes forward to triage_node, even if still incomplete, to avoid
        infinite loops)

    Print a message explaining which branch was chosen — it helps during debugging.

    HINT — the mapping you will pass to add_conditional_edges():
        {
            "retry":    "intake_node",
            "continue": "routing_agent_node",
        }
    """
    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 8: implement route_after_completeness")


# ── TODO 9 — route_after_routing_agent ───────────────────────────────────────
def route_after_routing_agent(state: PatientState) -> Literal["critical", "urgent", "routine"]:
    """
    Implements the THREE-WAY BRANCH based on the routing agent's decision.

    This function is intentionally trivial — all the intelligence already
    happened inside routing_agent_node (the LLM call + structured output).
    The routing function's only job is to dispatch: read urgency_level from
    state and return it as the routing key.

    HINT — routing functions must be pure and side-effect-free (no LLM calls).
    The LLM call belongs in routing_agent_node, not here.

    HINT — routing_agent_node used with_structured_output(TriageDecision),
    which validates urgency_level against Literal["critical","urgent","routine"].
    So state["urgency_level"] is already a valid key — no if/elif needed.
    You may add a fallback guard for the "unknown" sentinel just in case.

    HINT — also print state["routing_reasoning"] so students can see the LLM's
    rationale for the routing decision in the console output.

    HINT — the mapping you will pass to add_conditional_edges():
        {
            "critical": "critical_node",
            "urgent":   "urgent_node",
            "routine":  "routine_node",
        }
    """
    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 9: implement route_after_routing_agent")


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 4 — GRAPH ASSEMBLY
#
# Wire all nodes and edges into a StateGraph, then compile it.
# ──────────────────────────────────────────────────────────────────────────────

# ── TODO 10 — build_graph ─────────────────────────────────────────────────────
def build_graph(llm: AzureChatOpenAI):
    """
    Assemble the triage graph.

    Step-by-step instructions
    ─────────────────────────
    1. Create the graph:
           graph = StateGraph(PatientState)

    2. Register all nodes.  Nodes that need the LLM must be wrapped in a lambda
       so their signature is (state) -> dict as LangGraph requires:
           graph.add_node("intake_node",             lambda s: intake_node(s, llm))
           graph.add_node("completeness_check_node", lambda s: completeness_check_node(s, llm))
           graph.add_node("routing_agent_node",      lambda s: routing_agent_node(s, llm))
           graph.add_node("critical_node",           lambda s: critical_node(s, llm))
           # ... add the remaining four nodes

    3. Set the entry point (the first node the graph will call):
           graph.set_entry_point("intake_node")

    4. Add a linear edge from intake_node to completeness_check_node:
           graph.add_edge("intake_node", "completeness_check_node")

    5. Add CONDITIONAL EDGE #1 — retry loop:
           graph.add_conditional_edges(
               "completeness_check_node",      # source node
               route_after_completeness,       # routing function
               {
                   "retry":    "intake_node",          # loop back
                   "continue": "routing_agent_node",   # LLM routing agent decides next
               },
           )

    6. Add CONDITIONAL EDGE #2 — three-way branch:
           graph.add_conditional_edges(
               "routing_agent_node",
               route_after_routing_agent,
               {
                   "critical": "critical_node",
                   "urgent":   "urgent_node",
                   "routine":  "routine_node",
               },
           )

    7. All three branches converge at care_plan_node:
           graph.add_edge("critical_node", "care_plan_node")
           graph.add_edge("urgent_node",   "care_plan_node")
           graph.add_edge("routine_node",  "care_plan_node")

    8. Linear tail — care_plan → recommendation → END:
           graph.add_edge("care_plan_node",      "recommendation_node")
           graph.add_edge("recommendation_node", END)

    9. Compile and return:
           return graph.compile()
    """
    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 10: implement build_graph()")


# ──────────────────────────────────────────────────────────────────────────────
# MAIN  (do not modify)
# ──────────────────────────────────────────────────────────────────────────────

SAMPLE_INPUTS = {
    "critical": (
        "I have crushing chest pain radiating to my left arm and jaw that started "
        "20 minutes ago. I'm sweating heavily and feel nauseous. I'm 58 years old "
        "and have a history of high blood pressure. The pain is a 9 out of 10."
    ),
    "urgent": (
        "I've had a high fever of 39.5°C for two days, severe headache, and my neck "
        "feels very stiff. I'm sensitive to light. I'm 24 years old with no major "
        "medical history. Paracetamol isn't bringing the fever down."
    ),
    "routine": (
        "I've had a mild sore throat and runny nose for three days. "
        "No fever, just a bit of fatigue. I think I caught a cold at work."
    ),
    "incomplete": (
        # Intentionally vague — should trigger the retry loop
        "I feel unwell."
    ),
}


def main():
    print("\n╔══════════════════════════════════════════════════════╗")
    print("║   LangGraph Patient Triage & Care Pathway Agent     ║")
    print("╚══════════════════════════════════════════════════════╝")

    llm = build_llm()
    app = build_graph(llm)

    # ── Print graph topology (Mermaid) ─────────────────────────────────────
    print("\n── Graph Topology (Mermaid) ──")
    print(app.get_graph().draw_mermaid())

    # ── Choose input mode ──────────────────────────────────────────────────
    print("\nInput options:")
    print("  [1] Type your own symptom description")
    print("  [2] Run sample CRITICAL case")
    print("  [3] Run sample URGENT case")
    print("  [4] Run sample ROUTINE case")
    print("  [5] Run INCOMPLETE case (tests the retry loop)")
    choice = input("\nChoose [1-5]: ").strip()

    if choice == "1":
        symptom_report = input("Describe your symptoms: ").strip()
    elif choice == "2":
        symptom_report = SAMPLE_INPUTS["critical"]
        print(f"\nUsing CRITICAL sample:\n  {symptom_report[:80]}...")
    elif choice == "3":
        symptom_report = SAMPLE_INPUTS["urgent"]
        print(f"\nUsing URGENT sample:\n  {symptom_report[:80]}...")
    elif choice == "4":
        symptom_report = SAMPLE_INPUTS["routine"]
        print(f"\nUsing ROUTINE sample:\n  {symptom_report[:80]}...")
    elif choice == "5":
        symptom_report = SAMPLE_INPUTS["incomplete"]
        print(f"\nUsing INCOMPLETE sample:\n  '{symptom_report}'")
    else:
        print("Invalid choice — using URGENT sample.")
        symptom_report = SAMPLE_INPUTS["urgent"]

    if not symptom_report:
        print("ERROR: No symptom report provided.")
        exit(1)

    # ── Build initial state ────────────────────────────────────────────────
    initial_state: PatientState = {
        "raw_symptom_report": symptom_report,
        "structured_symptoms": "",
        "retry_count": 0,
        "is_complete": False,
        "urgency_level": "unknown",
        "pathway_output": "",
        "care_plan": "",
        "recommendation": "",
    }

    # ── Run the graph ──────────────────────────────────────────────────────
    print("\n── Running Triage Pipeline ──\n")
    final_state = app.invoke(initial_state)

    # ── Display results ────────────────────────────────────────────────────
    print("\n" + "═" * 60)
    print("TRIAGE RESULT")
    print("═" * 60)
    print(f"Urgency Level : {final_state['urgency_level'].upper()}")
    print(f"Intake Retries: {final_state['retry_count'] - 1}")   # -1 because first run is not a retry
    print()
    print("── CARE PLAN ──")
    print(final_state["care_plan"])
    print()
    print("── PATIENT RECOMMENDATION ──")
    print(final_state["recommendation"])
    print("═" * 60)


if __name__ == "__main__":
    main()


# ──────────────────────────────────────────────────────────────────────────────
# EXTENSION CHALLENGES  (optional, for fast finishers)
# ──────────────────────────────────────────────────────────────────────────────
#
# CHALLENGE A — Checkpointing (Human-in-the-Loop prep)
#   Add a MemorySaver checkpointer to build_graph() so that the graph state
#   is persisted between calls.  Then modify main() to accept a thread_id so
#   the same patient session can be resumed across multiple interactions.
#   Reference: from langgraph.checkpoint.memory import MemorySaver
#              app = graph.compile(checkpointer=MemorySaver())
#              config = {"configurable": {"thread_id": "patient-001"}}
#              app.invoke(state, config=config)
#
# CHALLENGE B — Streaming Output
#   Replace app.invoke() in main() with app.stream() to print each node's
#   output as it is produced rather than waiting for the full pipeline.
#   Reference:
#       for event in app.stream(initial_state):
#           node_name, node_output = next(iter(event.items()))
#           print(f"\n[{node_name}] output: {str(node_output)[:200]}")
#
# CHALLENGE C — Parallel Pathway Nodes
#   Instead of routing to ONE branch node, fan out to ALL THREE in parallel
#   (each produces a different perspective on the case).  Use a fan-in node
#   to merge the three outputs before care_plan_node.
#   Hint: LangGraph supports parallel edges natively — just add multiple edges
#   from triage_node to different target nodes without a conditional edge.
#   Use Annotated[list[str], operator.add] in the state to collect outputs.
#
# CHALLENGE D — Add a Specialist Referral Node
#   After care_plan_node, add a conditional edge:
#     • If urgency_level is "critical" or "urgent" → referral_node
#       (generates a specialist referral letter)
#     • If "routine" → recommendation_node directly
#   This adds a second conditional edge and a new branch to your graph.
