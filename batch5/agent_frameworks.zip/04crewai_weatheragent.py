import os
import requests
from dotenv import load_dotenv
from crewai import Agent, LLM
from crewai.tools import tool
from torchgen import model

load_dotenv()

@tool("get_weather")
def get_weather(location: str) -> str:
    """Retrieve current weather information for a location."""
    api_key = os.getenv("OPENWEATHERMAP_API_KEY")
    geo_resp = requests.get(
        "http://api.openweathermap.org/geo/1.0/direct",
        params={"q": location, "limit": 1, "appid": api_key},
        timeout=20,
    )
    geo_resp.raise_for_status()
    geo_data = geo_resp.json()
    lat = geo_data[0]["lat"]
    lon = geo_data[0]["lon"]

    weather_resp = requests.get(
        "https://api.openweathermap.org/data/3.0/onecall",
        params={"lat": lat, "lon": lon, "appid": api_key, "units": "metric"},
        timeout=20,
    )
    weather_resp.raise_for_status()
    data = weather_resp.json()

    current = data["current"]
    desc = current["weather"][0]["description"]
    return (
        f"Weather for {location}: {desc}. "
        f"Temperature: {current['temp']}°C, feels like {current['feels_like']}°C, "
        f"humidity: {current['humidity']}%, UV index: {current['uvi']}."
    )


# crewAI uses liteLLM under the hood, which is OpenAI-compatible. 
# Need to append "/openai/v1/" to the Azure AI  endpoint to make it work with the OpenAI client.
llm = LLM(
    model=f"openai/{os.getenv('AZURE_OPENAI_MODEL_NAME')}",
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    base_url=os.getenv("AZURE_OPENAI_ENDPOINT")+"/openai/v1/",
    temperature=0
)

agent = Agent(
    role="Weather Specialist",
    goal="Answer current weather questions accurately using tools.",
    backstory="You are a careful weather assistant who uses live tools instead of guessing.",
    tools=[get_weather],
    llm=llm,
    verbose=True
)

if __name__ == "__main__":
    result = agent.kickoff("How is the weather in Mumbai?")
    print(result)