import os
import requests

from dotenv import load_dotenv
from langchain_core.tools import tool
from langchain_openai import AzureChatOpenAI
from langchain.agents import create_agent

load_dotenv()

# LangGraph's create_agent() is a simple API used for single Agents
# It does not offer multi agent/Agentic AI orchestration features like the more flexible graph-based API in langgraph.graph, but is a simpler way to create traditional LLM + tool agents.
# See langgraph_customizable_weatheragent.py for an example of using the more flexible graph-based API to create a similar agent with more customizable control over the orchestration and flow between LLM and tools.

# ---------------------------
# 1) Tool
# ---------------------------
@tool
def get_weather(location: str) -> str:
    """
    Retrieve current weather information for a location using OpenWeatherMap.
    """
    api_key = os.getenv("OPENWEATHERMAP_API_KEY")
    if not api_key:
        return "OpenWeatherMap API key is missing."

    # Step 1: geocode location
    geo_url = "http://api.openweathermap.org/geo/1.0/direct"
    geo_resp = requests.get(
        geo_url,
        params={"q": location, "limit": 1, "appid": api_key},
        timeout=20,
    )
    geo_resp.raise_for_status()
    geo_data = geo_resp.json()

    if not geo_data:
        return f"Could not find coordinates for '{location}'."

    lat = geo_data[0]["lat"]
    lon = geo_data[0]["lon"]

    # Step 2: current weather
    weather_url = "https://api.openweathermap.org/data/3.0/onecall"
    weather_resp = requests.get(
        weather_url,
        params={"lat": lat, "lon": lon, "appid": api_key, "units": "metric"},
        timeout=20,
    )
    weather_resp.raise_for_status()
    data = weather_resp.json()

    current = data.get("current", {})
    weather_list = current.get("weather", [])
    description = weather_list[0]["description"] if weather_list else "No description"
    humidity = current.get("humidity", "NA")
    uvi = current.get("uvi", "NA")
    temp = current.get("temp", "NA")
    feels_like = current.get("feels_like", "NA")

    return (
        f"Weather for {location}: {description}. "
        f"Temperature: {temp}°C, feels like {feels_like}°C, "
        f"humidity: {humidity}%, UV index: {uvi}."
    )


tools = [get_weather]

# ---------------------------
# 2) Model
# ---------------------------
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    temperature=0,
)

# ---------------------------
# 3) Prompt / Agent
# ---------------------------
role = "Weather specialist"
goal = "Provide accurate current weather answers using live tools"
backstory = "You are a careful meteorological assistant that never invents real-time conditions"

system_prompt = f"""
Role: {role}
Goal: {goal}
Backstory: {backstory}

Rules:
- Answer only weather-related questions.
- Use tools for live weather.
- If the tool fails, explain the limitation clearly.
"""

agent = create_agent(
    model=llm,
    tools=tools,
    system_prompt=system_prompt,
    name="weather_agent",
)

# ---------------------------
# 4) Run
# ---------------------------
if __name__ == "__main__":
    result = agent.invoke(
        {
            "messages": [
                {"role": "user", "content": "How is the weather in Mumbai?"}
            ]
        }
    )

    # The final result contains the conversation history, including tool calls and tool responses.
    for msg in result["messages"]:
        role = msg.type.upper()

        if role == "AI" and getattr(msg, "tool_calls", None):
            tool_names = [tc["name"] for tc in msg.tool_calls]
            print(f"[AI - TOOL CALL] {tool_names}")
        elif role == "TOOL":
            tool_name = getattr(msg, "name", "unknown_tool")
            print(f"[TOOL - {tool_name}] {msg.content}")
        else:
            print(f"[{role}] {msg.content}")