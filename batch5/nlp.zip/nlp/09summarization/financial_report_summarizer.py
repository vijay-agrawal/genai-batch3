# =============================================================================
# Financial Report Summarization — General-Purpose vs. Finance-Tuned Models
# =============================================================================
#
# WHAT IS ABSTRACTIVE SUMMARIZATION?
# ────────────────────────────────────
# There are two broad approaches to summarization:
#
#   Extractive: Selects and stitches together verbatim sentences from the
#               source. Fast, faithful, but often choppy and redundant.
#               (Think of a highlighter on a printed report.)
#
#   Abstractive: Reads the full text and WRITES a new, shorter version in
#                the model's own words — compressing meaning, resolving
#                co-references, dropping boilerplate. This is what humans
#                do when they write an executive summary.
#                Both models in this demo are abstractive.
#
# REAL-WORLD USE CASE
# ────────────────────
# Equity analysts, fund managers, and retail investors receive hundreds of
# quarterly earnings reports, press releases, and conference-call transcripts
# every earnings season. Reading each one in full is impossible. Companies
# like Bloomberg, Refinitiv, and S&P Global use AI summarization pipelines
# to auto-generate 3–5 sentence digests that surface the key numbers and
# guidance before a human analyst digs deeper.
#
# This demo replicates that pipeline using two locally-run models:
#   1. DistilBART-CNN  — a general-purpose news summarizer
#   2. Financial PEGASUS — fine-tuned specifically on earnings call transcripts
#
# =============================================================================
# ARCHITECTURE 1 — BART & DistilBART
# =============================================================================
#
# BART (Lewis et al., Facebook AI, 2019) stands for
# "Bidirectional and Auto-Regressive Transformer".
#
# Its key innovation is a noisy-channel pre-training strategy. During
# pre-training the model is given a CORRUPTED version of a document and
# must reconstruct the original clean text. Five corruption techniques:
#
#   1. Token masking    — random tokens replaced with [MASK]
#   2. Token deletion   — random tokens removed entirely
#   3. Text infilling   — a span of k tokens replaced by ONE [MASK]
#   4. Sentence permutation — sentences shuffled into random order
#   5. Document rotation — document rotated to start at a random token
#
# Because the model must reconstruct coherent prose from broken inputs,
# it learns robust representations of both syntax and semantics — much
# stronger than a model trained only on classification labels.
#
# Architecture (encoder + decoder):
#
#   Input text (corrupted) → [BART Encoder: bidirectional Transformer]
#                                          ↓  context vectors
#                            [BART Decoder: autoregressive Transformer]
#                                          ↓
#                            Output text (reconstructed / summarized)
#
# The encoder reads the ENTIRE input bidirectionally (no masking), building
# a rich context vector for every token. The decoder then generates output
# left-to-right, attending to its own previous outputs (self-attention) AND
# to all encoder context vectors (cross-attention) at every step.
#
# After pre-training, BART-large was fine-tuned on CNN/DailyMail — a dataset
# of ~300,000 news articles paired with human-written bullet summaries.
# This fine-tuning teaches it the "news summary" register: factual, third-
# person, lead-sentence structure.
#
# DistilBART-CNN-6-6 (Shleifer & Rush, HuggingFace, 2020):
#   ┌──────────────────────────────────────────────────────┐
#   │ Teacher : BART-large-CNN  (12 enc + 12 dec layers)   │
#   │ Student : DistilBART      ( 6 enc +  6 dec layers)   │
#   │ Method  : Layer-dropping — keep every other layer    │
#   │           then fine-tune student to match teacher    │
#   │           outputs via knowledge distillation         │
#   ├──────────────────────────────────────────────────────┤
#   │ Parameters : ~306M   (BART-large: ~406M)             │
#   │ Model size : ~1.2 GB on disk                         │
#   │ Speed      : ~1.5–2× faster than BART-large          │
#   │ Quality    : ~95% of BART-large on ROUGE benchmarks  │
#   └──────────────────────────────────────────────────────┘
#
# LIMITATION for financial text:
#   DistilBART was fine-tuned on news articles (CNN/DailyMail), not on
#   earnings reports. It will produce fluent prose but may:
#     • Misweight financial numbers vs. narrative context
#     • Omit guidance/outlook (rare in news, common in earnings reports)
#     • Treat ₹ / EPS / EBITDA as generic noise rather than key signals
#
# =============================================================================
# ARCHITECTURE 2 — PEGASUS & Financial-PEGASUS
# =============================================================================
#
# PEGASUS (Zhang et al., Google, 2019) stands for
# "Pre-training with Extracted Gap-sentences for Abstractive SUmmarization
# Sequence-to-sequence models".
#
# The key insight: design a pre-training objective that DIRECTLY mimics
# the summarization task, rather than a generic denoising task.
#
# Gap Sentences Generation (GSG) — the PEGASUS pre-training objective:
#
#   Step 1: Score every sentence in a document by its relevance/importance
#           using ROUGE with respect to the remaining sentences.
#   Step 2: Remove the top-k most important sentences ("gap sentences")
#           and replace them with [MASK1], [MASK2], … in the source.
#   Step 3: Concatenate the masked source and train the model to GENERATE
#           the removed gap sentences as the "pseudo-summary".
#
#   Original document:
#     S1: "Revenue rose 18% YoY to ₹4,812 Cr."
#     S2: "Operating margin expanded 120 bps to 24.3%."   ← selected as gap
#     S3: "Deal wins in North America drove the growth."
#     S4: "The board declared a ₹15 interim dividend."    ← selected as gap
#
#   Model input : "S1 [MASK1] S3 [MASK2]"
#   Model target: "S2 + S4"
#
#   Because the most informative sentences ARE the summary, GSG pre-training
#   is perfectly aligned with the downstream task. PEGASUS needs far fewer
#   fine-tuning examples to reach high quality compared to BART or T5.
#
# Architecture: Standard encoder-decoder Transformer
#   PEGASUS-large: 568M parameters (~2.2 GB)
#   Pre-trained on C4 + HuggingFace News (750M+ documents)
#
# Financial-Summarization-PEGASUS
# (human-centered-summarization, HuggingFace Hub):
#   ┌──────────────────────────────────────────────────────────────┐
#   │ Base  : google/pegasus-large (568M params)                   │
#   │ Data  : ECTSum dataset — 2,425 earnings conference call (ECC)│
#   │         transcripts paired with expert-written bullet digests│
#   │         sourced from financial newswires                      │
#   │ Domain vocabulary the model has learned:                     │
#   │   EPS · EBITDA · gross margin · YoY · QoQ · order book ·    │
#   │   guidance · dividend · buyback · headcount · utilisation    │
#   ├──────────────────────────────────────────────────────────────┤
#   │ Parameters : 568M   Model size : ~2.2 GB on disk            │
#   │ Runs on    : CPU (slow ~3–5 min) or GPU (fast ~20s)          │
#   │ For faster CPU demo, set: max_length=128, min_length=48       │
#   └──────────────────────────────────────────────────────────────┘
#
# WHY DOMAIN-SPECIFIC FINE-TUNING MATTERS HERE
# ──────────────────────────────────────────────
# Earnings reports have a very different structure from news articles:
#   • Dense tables of numbers with units (₹ Cr, %, bps, million shares)
#   • Forward-looking guidance language (conditional, hedged)
#   • Regulatory boilerplate that must be ignored
#   • Specialist jargon (utilisation rate, attrition, deal TCV)
#   • Key signal often buried in paragraph 4 of 8
# A model fine-tuned on ECC transcripts has seen thousands of examples of
# what analysts consider the "important" part of such reports — it has
# learned an implicit financial relevance ranking that general models lack.
#
# =============================================================================

from transformers import pipeline, PegasusTokenizer

# =============================================================================
# QUARTERLY EARNINGS REPORT — MERIDIAN INFOTECH LIMITED
# (Fictional company — for educational demonstration only)
# =============================================================================
#
# In a real pipeline this text would be parsed from a PDF press release or
# a regulatory filing (BSE / NSE announcement). Here it is embedded directly
# to keep the demo self-contained and reproducible.

FINANCIAL_REPORT = """
MERIDIAN INFOTECH LIMITED
Q3 FY2025 EARNINGS PRESS RELEASE
For the quarter ended December 31, 2024

Bengaluru, January 14, 2025 — Meridian Infotech Limited (BSE: 532479, NSE: MERIDIAN),
a global IT services and digital transformation company, today announced its consolidated
financial results for the third quarter of fiscal year 2025.

FINANCIAL HIGHLIGHTS — Q3 FY2025

Revenue from operations for Q3 FY2025 stood at ₹4,812 crore, an increase of 17.8% year-on-
year (YoY) and 4.1% quarter-on-quarter (QoQ) in rupee terms. In constant currency (CC)
terms, revenue grew 13.2% YoY and 3.6% QoQ, reflecting robust demand across all service
lines despite a stronger rupee against major trading currencies.

Earnings Before Interest, Tax, Depreciation and Amortisation (EBITDA) for the quarter came
in at ₹1,169 crore, with an EBITDA margin of 24.3%, expanding 120 basis points (bps) YoY
and 40 bps QoQ. The margin improvement was driven by operational efficiency initiatives,
reduced sub-contractor costs, and a favourable revenue mix shift toward higher-value digital
engineering engagements.

Profit After Tax (PAT) for Q3 FY2025 was ₹892 crore, up 21.4% YoY, resulting in diluted
Earnings Per Share (EPS) of ₹14.87, compared to ₹12.25 in Q3 FY2024.

The Board of Directors has declared an interim dividend of ₹6.00 per equity share of face
value ₹2 each for FY2025, subject to shareholder approval.

Free cash flow for the quarter was ₹1,043 crore, representing a conversion rate of 117% of
PAT, reflecting strong collections and disciplined working capital management. Cash and
investments on the balance sheet stood at ₹7,218 crore as of December 31, 2024.

SEGMENT PERFORMANCE

The Digital Engineering & Cloud Services segment, which now constitutes 41% of total
revenue, grew 26% YoY in CC terms, driven by large-scale cloud migration mandates and
AI-enabled platform modernisation projects across North America and continental Europe.

The Enterprise Applications & ERP segment grew 9% YoY in CC terms, with renewed interest
in SAP S/4HANA migrations following regulatory deadlines set by European clients for 2027
compliance.

The Business Process Services (BPS) segment declined 2.1% YoY in CC terms as clients
continued to automate routine back-office workflows, partially offset by growth in
knowledge-process outsourcing (KPO) offerings.

DEAL WINS AND ORDER BOOK

Total contract value (TCV) of large deal wins in Q3 FY2025 reached $680 million across
11 deals, including three mega-deals each exceeding $100 million TCV. The 12-month
executable order book now stands at $3.4 billion, the highest in the company's history,
providing strong revenue visibility for the next four quarters.

Notable wins include a $220 million, five-year cloud transformation engagement with a
Fortune 500 US healthcare insurer; a $135 million digital supply-chain overhaul for a
European automotive group; and a $112 million AI-led finance transformation for a
UK-based global bank.

PEOPLE AND OPERATIONS

Total headcount as of December 31, 2024 was 87,412, a net addition of 1,847 employees
during the quarter. Voluntary attrition on a trailing twelve-month (TTM) basis improved to
14.2%, down from 17.6% in Q3 FY2024, reflecting improved employee engagement scores and
retention programmes. Utilisation (excluding trainees) stood at 83.4%, near the high end
of the company's optimal 80–84% band.

GUIDANCE AND OUTLOOK

Based on the Q3 performance and strong deal momentum, management revised FY2025 full-year
revenue growth guidance upward to 15.5%–16.5% in CC terms (previously 14.0%–15.0%). EBITDA
margin guidance for the full year is maintained at 23.5%–24.5%, with Q4 expected to see
slight pressure from seasonal furloughs in the first two weeks of January and annual salary
revision accruals.

MD & CEO Mr. Arjun Menon commented: "Our Q3 results demonstrate the strength of our
differentiated positioning at the intersection of cloud, AI, and industry-specific process
expertise. The record deal TCV and order book give us confidence in sustaining double-digit
growth through FY2026. We remain focused on margin resilience even as we invest in our AI
capability platform, Meridian NexusAI, which is now embedded in over 60 active client
engagements."

CFO Ms. Priya Srinivasan added: "Cash generation remained exemplary with free cash flow
exceeding PAT for the third consecutive quarter. Our pristine balance sheet, with net cash
of ₹7,218 crore, positions us to pursue strategic tuck-in acquisitions in the $50–200
million range in AI engineering and cloud-native development, while also returning capital
through dividends."

KEY RISKS

Management acknowledged the following risks to the outlook: (1) macroeconomic slowdown in
the US and Eurozone that could delay discretionary technology spending; (2) currency
headwinds if the Indian rupee appreciates further against the USD and EUR; (3) wage
inflation from competition for AI/ML talent; and (4) longer sales cycles for AI
transformation deals compared to traditional IT outsourcing.

Results will be discussed in the investor earnings call today at 5:30 PM IST.

###

About Meridian Infotech Limited:
Meridian Infotech is a global technology services company headquartered in Bengaluru, India,
serving over 320 clients across 28 countries. The company specialises in digital
engineering, cloud services, enterprise applications, and AI-led business transformation.
"""

# =============================================================================
# MODEL 1 — DistilBART-CNN-6-6 (General-Purpose News Summarizer)
# =============================================================================
#
# Pipeline "summarization" wraps the model's generate() call with sensible
# defaults. Key parameters for financial reports:
#
#   max_length  – Hard cap on output tokens. 180 ≈ 4–6 sentences, enough
#                 to cover revenue, margin, EPS, and guidance.
#   min_length  – Prevents the model from collapsing to 1–2 sentences when
#                 the text is long. 80 ≈ 2 full sentences minimum.
#   length_penalty – Controls the beam-search length preference.
#                    > 1.0 encourages longer outputs; < 1.0 shorter ones.
#   num_beams   – Beam search width. 4 is the standard for quality
#                 summarization (accuracy/speed balance).
#   early_stopping – Stop beam search when all beams hit EOS token.
#
# DistilBART-CNN tokenizer max input: 1024 tokens (~750 words).
# The financial report above (~800 words) will be truncated slightly.
# For longer documents, chunk-and-merge or use longformer-based models.

print("=" * 70)
print("  Loading Model 1: DistilBART-CNN-6-6  (~306M params, ~1.2 GB)")
print("  General-purpose | Fine-tuned on CNN/DailyMail news articles")
print("=" * 70)
print("  First run downloads the model (~1.2 GB). Subsequent runs use cache.\n")

distilbart_summarizer = pipeline(
    "summarization",
    model="sshleifer/distilbart-cnn-6-6",
    device=-1,   # CPU
)

distilbart_result = distilbart_summarizer(
    FINANCIAL_REPORT,
    max_length=180,
    min_length=80,
    length_penalty=2.0,
    num_beams=4,
    early_stopping=True,
    truncation=True,       # truncates input to model's max 1024 tokens
)

print("MODEL 1 — DistilBART-CNN (General-Purpose News Summarizer)")
print("-" * 70)
print(distilbart_result[0]["summary_text"])
print()

# =============================================================================
# MODEL 2 — Financial-Summarization-PEGASUS (Finance-Specific)
# =============================================================================
#
# This model's pre-training (GSG) + fine-tuning on ECTSum means it has seen
# thousands of earnings call digests. It implicitly knows:
#   • Revenue and EPS are almost always in the summary
#   • Guidance revisions are high-signal events worth including
#   • Boilerplate about company history should be omitted
#   • Deal TCV and order book matter to analysts
#
# Input token limit: 512 tokens (PEGASUS default).
# The report is truncated at 512 tokens; the model still covers Q3 numbers,
# margins, and guidance which appear in the first ~450 tokens.
#
# If running on CPU this step may take 2–4 minutes. On a GPU it takes ~20s.

print("=" * 70)
print("  Loading Model 2: Financial-Summarization-PEGASUS  (~568M params, ~2.2 GB)")
print("  Finance-specific | Fine-tuned on ECTSum earnings call transcripts")
print("=" * 70)
print("  First run downloads the model (~2.2 GB). Subsequent runs use cache.")
print("  CPU inference may take 2–4 minutes. Please wait...\n")

fin_pegasus_summarizer = pipeline(
    "summarization",
    model="human-centered-summarization/financial-summarization-pegasus",
    tokenizer=PegasusTokenizer.from_pretrained(
        "human-centered-summarization/financial-summarization-pegasus",
    ),
    device=-1,   # CPU
)

fin_pegasus_result = fin_pegasus_summarizer(
    FINANCIAL_REPORT,
    max_length=128,
    min_length=48,
    length_penalty=2.0,
    num_beams=4,
    early_stopping=True,
    truncation=True,       # truncates input to model's max 512 tokens
)

print("MODEL 2 — Financial-Summarization-PEGASUS (Finance-Specific)")
print("-" * 70)
print(fin_pegasus_result[0]["summary_text"])
print()

# =============================================================================
# SIDE-BY-SIDE COMPARISON
# =============================================================================

print("=" * 70)
print("  SIDE-BY-SIDE COMPARISON")
print("=" * 70)

bart_text   = distilbart_result[0]["summary_text"]
peg_text    = fin_pegasus_result[0]["summary_text"]

bart_words  = len(bart_text.split())
peg_words   = len(peg_text.split())
src_words   = len(FINANCIAL_REPORT.split())

print(f"\nSource report   : ~{src_words} words")
print(f"DistilBART      :  {bart_words} words  "
      f"(compression ratio {src_words // max(bart_words, 1)}:1)")
print(f"Financial PEGASUS: {peg_words} words  "
      f"(compression ratio {src_words // max(peg_words, 1)}:1)")

print("\n" + "-"*70)
print("DistilBART summary:")
print(f"  {bart_text}")
print("\n" + "-"*70)
print("Financial-PEGASUS summary:")
print(f"  {peg_text}")

# =============================================================================
# WHAT TO OBSERVE IN THE OUTPUTS
# =============================================================================
#
# DistilBART (trained on news) tends to:
#   ✓ Produce fluent, readable prose — it has seen millions of news articles
#   ✓ Latch onto narrative sentences ("the company announced…")
#   ✗ Sometimes echo the boilerplate "About the company" section
#   ✗ May miss EBITDA margin, EPS, or guidance — these appear lower in the
#     report and the CNN/DailyMail corpus rarely features such detail
#   ✗ Treats ₹ amounts and basis-point figures as generic text noise
#
# Financial-PEGASUS (trained on earnings calls) tends to:
#   ✓ Prioritise revenue, PAT, margins, and EPS — the analyst's checklist
#   ✓ Include guidance revision — a high-signal event for market pricing
#   ✓ Reference deal TCV and order book — standard in ECC transcripts
#   ✗ Shorter output — ECC digests are typically bullet-style, so the model
#     may produce compressed, telegram-like prose
#   ✗ May occasionally hallucinate a specific number if the source was
#     truncated at the 512-token limit (always cross-check key figures)
#
# =============================================================================
# EVALUATION — HOW IS SUMMARIZATION QUALITY MEASURED?
# =============================================================================
#
# ROUGE (Recall-Oriented Understudy for Gisting Evaluation):
#
#   ROUGE-1 : Overlap of individual words (unigrams) between model
#              summary and reference summary.
#   ROUGE-2 : Overlap of consecutive word pairs (bigrams).
#              Higher ROUGE-2 means the model preserves key phrases.
#   ROUGE-L : Longest common subsequence — captures fluency and order.
#
#   Typical benchmark scores (CNN/DailyMail, higher = better):
#     DistilBART-CNN-6-6           : R1=42.8  R2=20.4  RL=31.0
#     BART-large-CNN (teacher)     : R1=44.1  R2=21.3  RL=40.9
#     PEGASUS-large (XSum)         : R1=47.2  R2=24.6  RL=39.3
#
#   For financial reports, no public ROUGE benchmark exists for these exact
#   models. In practice, financial analysts evaluate summaries by checking:
#     1. Are all key numbers present? (revenue, PAT, EPS, margin)
#     2. Is the guidance revision captured?
#     3. Are any numbers hallucinated or wrong?
#     4. Is the boilerplate omitted?
#
# =============================================================================
# PRACTICAL PIPELINE DESIGN FOR LONG REPORTS (> 512 / 1024 TOKENS)
# =============================================================================
#
# Most real financial reports (annual reports, 10-K filings) are 20,000–
# 100,000 words — far beyond these models' input windows. Two strategies:
#
#   Strategy A — Chunking (Map-Reduce):
#     1. Split the document into overlapping chunks of 400 tokens.
#     2. Summarize each chunk independently.
#     3. Concatenate chunk summaries.
#     4. Run a final summarization pass over the concatenated chunk summaries.
#     Pro: Simple, parallelisable.
#     Con: Cross-chunk context is lost; the final pass gets an odd input.
#
#   Strategy B — Hierarchical Summarization:
#     1. Parse the report into semantic sections (financials, outlook, risks).
#     2. Summarize each section individually.
#     3. Combine section summaries using a different prompt/model.
#     Pro: Sections stay coherent; output is structured.
#     Con: Requires a parser or layout-aware PDF extractor.
#
#   Strategy C — Long-context Models:
#     LongT5, LongBART, or LED (Longformer Encoder-Decoder) extend the
#     input window to 4,096–16,384 tokens using sparse attention.
#     Pro: No chunking needed for most real reports.
#     Con: Larger models, more GPU memory required.
#
# =============================================================================
