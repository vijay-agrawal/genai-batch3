# pip install spacy && python -m spacy download en_core_web_sm

# =============================================================================
# HOW SPACY DOES POS TAGGING
# =============================================================================
#
# POS tagging is a SUPERVISED learning task. spaCy's tagger is trained on
# human-annotated corpora where every word in every sentence has been manually
# labelled with its correct part-of-speech tag.
#
# --- Training Data ---
# en_core_web_sm is trained primarily on OntoNotes 5.0, a large corpus of
# newswire, broadcast, web text, and conversational speech. Linguists annotated
# each token with Penn Treebank POS tags (e.g. NN, VBZ, JJ). The model sees
# millions of (token, context, correct-tag) examples during training.
#
# --- Model Architecture ---
# spaCy uses a transition-based / feed-forward neural network architecture:
#
#   1. Tok2Vec (shared encoder)
#      Each token is first converted into a dense vector by combining:
#        - A word embedding (looked up from a vocabulary table)
#        - Subword features via character-level CNN — helps with unknown words,
#          typos, and morphological variants (e.g. "running" vs "runner")
#      A small CNN (or Transformer in larger models) then mixes context from
#      neighbouring tokens into each token's representation.
#
#   2. POS Tagger head
#      A single feed-forward layer sits on top of the Tok2Vec output.
#      For each token it outputs a probability distribution over all possible
#      POS tags and picks the highest-scoring one.
#      Loss during training: categorical cross-entropy against the gold label.
#
# --- Why context matters ---
# The word "flies" means different things in:
#   "Time flies like an arrow."  (VERB)
#   "Fruit flies like a banana." (NOUN)
# The CNN/Transformer mixes surrounding token vectors so the tagger sees the
# full local context, not just the isolated word, when making its decision.
#
# --- Two levels of tags ---
#   pos_  — Universal Dependencies coarse tags (NOUN, VERB, ADJ, ADV, …)
#            consistent across languages; good for cross-lingual work.
#   tag_  — Penn Treebank fine-grained tags (NN vs NNS vs NNP, VB vs VBZ …)
#            English-specific; carries morphological detail (number, tense).
#
# --- Accuracy ---
# en_core_web_sm reaches ~97% token-level POS accuracy on OntoNotes test data.
# Larger models (en_core_web_trf, backed by RoBERTa) push this above 98%.
#
# --- Not unsupervised ---
# Unsupervised POS induction (clustering words by distributional context) exists
# in research but is far less accurate (~85-90%) and produces arbitrary tag
# inventories that don't match linguistic conventions. spaCy ships supervised
# models because labelled corpora exist for most major languages and the
# accuracy gap is significant.
# =============================================================================

import spacy

nlp = spacy.load("en_core_web_sm")

# ---------------------------------------------------------------------------
# Part-of-Speech (POS) Tagging with spaCy
# Each token gets two POS labels:
#   pos_  — coarse-grained (NOUN, VERB, ADJ, …)
#   tag_  — fine-grained Penn Treebank tag (NN, VBZ, JJ, …)
# ---------------------------------------------------------------------------

sentences = [
    "The quick brown fox jumps over the lazy dog.",
    "She was prescribed Ibuprofen 200mg for severe headaches.",
    "Natural language processing enables computers to understand human text.",
]

for sentence in sentences:
    doc = nlp(sentence)
    print(f"\nSentence: {sentence}")
    print(f"{'Token':<20} {'POS':<10} {'Tag':<10} {'Dependency':<15} {'Explanation'}")
    print("-" * 75)
    for token in doc:
        print(
            f"{token.text:<20} {token.pos_:<10} {token.tag_:<10} "
            f"{token.dep_:<15} {spacy.explain(token.tag_)}"
        )

# ---------------------------------------------------------------------------
# Use case: extract only nouns and verbs from a sentence
# ---------------------------------------------------------------------------
text = "The scientist carefully analyzed the experimental results in the laboratory."
doc = nlp(text)

print(f"\n--- Filtered POS: Nouns & Verbs ---")
print(f"Sentence: {text}")
nouns = [t.text for t in doc if t.pos_ == "NOUN"]
verbs = [t.text for t in doc if t.pos_ == "VERB"]
print(f"Nouns : {nouns}")
print(f"Verbs : {verbs}")

# ---------------------------------------------------------------------------
# Use case: noun chunks (base noun phrases)
# ---------------------------------------------------------------------------
print(f"\n--- Noun Chunks ---")
for chunk in doc.noun_chunks:
    print(f"  {chunk.text!r:<35} root={chunk.root.text!r}, dep={chunk.root.dep_}")


# =============================================================================
# HEALTHCARE EXAMPLES
# =============================================================================

# ---------------------------------------------------------------------------
# 1. PHRASE DETECTION
#    Detect clinically meaningful multi-word phrases using noun chunks and
#    POS patterns.  A bare noun chunk like "pressure" becomes "blood pressure"
#    only when the adjective/noun modifier is included — POS lets us keep the
#    full phrase together.
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
print("HEALTHCARE USE CASE 1: Phrase Detection")
print("=" * 70)

clinical_notes = [
    "Patient reports chest pain and shortness of breath for three days.",
    "History of type 2 diabetes and chronic kidney disease stage 3.",
    "She was started on a beta blocker after the acute myocardial infarction.",
    "Blood pressure was elevated at 160 over 90 mmHg during the visit.",
]

for note in clinical_notes:
    doc = nlp(note)
    # Noun chunks capture multi-word clinical phrases intact
    phrases = [chunk.text for chunk in doc.noun_chunks]
    # Also pull standalone adjective+noun sequences missed by chunker
    print(f"\nNote: {note}")
    print(f"  Clinical phrases detected: {phrases}")


# ---------------------------------------------------------------------------
# 2. QUERY REWRITING
#    Patients write in natural language ("my chest hurts when I run").
#    POS tagging lets us strip stop words, keep content words (NOUN, VERB,
#    ADJ, ADV), and reorder them into a structured clinical search query.
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
print("HEALTHCARE USE CASE 2: Query Rewriting")
print("=" * 70)

CONTENT_POS = {"NOUN", "VERB", "ADJ", "ADV", "PROPN", "NUM"}

patient_queries = [
    "my chest really hurts when I breathe deeply",
    "I have been feeling very dizzy and nauseous since yesterday",
    "my left knee is swollen and extremely painful after running",
    "child has a high fever and keeps vomiting",
]

for query in patient_queries:
    doc = nlp(query)
    # Keep only medically meaningful content words; drop pronouns & auxiliaries
    keywords = [
        t.lemma_.lower()
        for t in doc
        if t.pos_ in CONTENT_POS
        and not t.is_stop
        and t.is_alpha
        and t.dep_ not in {"nsubj", "aux", "auxpass"}
    ]
    clinical_query = " ".join(keywords)
    print(f"\n  Patient query  : {query}")
    print(f"  Clinical query : {clinical_query}")


# ---------------------------------------------------------------------------
# 3. ENTITY-ATTRIBUTE EXTRACTION
#    Extract (drug, dose, frequency) and (symptom, severity, duration) tuples
#    by walking the dependency tree.  POS tags anchor which tokens are the
#    head entity (NOUN/PROPN) vs. its modifiers (NUM, ADJ, ADV).
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
print("HEALTHCARE USE CASE 3: Entity-Attribute Extraction")
print("=" * 70)

import re

prescriptions = [
    "Prescribe Metformin 500mg twice daily for type 2 diabetes.",
    "Patient takes Lisinopril 10mg once daily for hypertension.",
    "Administer Ibuprofen 400mg every six hours as needed for pain.",
    "Start Atorvastatin 20mg at bedtime to manage high cholesterol.",
]

# Simple POS-guided pattern: PROPN/NOUN followed by NUM token for dose
def extract_drug_dose(text):
    doc = nlp(text)
    results = []
    tokens = list(doc)
    for i, tok in enumerate(tokens):
        # Drug candidate: proper noun or noun with a capital letter
        if tok.pos_ in {"PROPN", "NOUN"} and tok.text[0].isupper():
            # Look ahead for a numeric token (dose)
            for j in range(i + 1, min(i + 4, len(tokens))):
                if tokens[j].pos_ == "NUM" or re.match(r"\d+\w*", tokens[j].text):
                    results.append({"drug": tok.text, "dose": tokens[j].text})
                    break
    return results

for rx in prescriptions:
    extractions = extract_drug_dose(rx)
    print(f"\n  Text       : {rx}")
    print(f"  Extracted  : {extractions}")


# ---------------------------------------------------------------------------
# 4. FILTERING MISMATCHED ASSOCIATIONS
#    NER alone can link an attribute (e.g. "200mg") to the wrong entity when
#    multiple entities appear in one sentence.  POS + dependency distance lets
#    us keep only associations where the attribute is syntactically close to
#    (i.e. modifies) the correct head noun.
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
print("HEALTHCARE USE CASE 4: Filtering Mismatched Associations")
print("=" * 70)

ambiguous_sentences = [
    # Two drugs + two doses — naive NER may cross-link them
    "The patient was given Aspirin 81mg and Metformin 500mg.",
    # Severity word 'severe' should attach to 'headache', not 'Ibuprofen'
    "She took Ibuprofen 400mg for her severe headache.",
    # 'chronic' modifies 'pain', not the drug
    "Oxycodone 5mg was prescribed for chronic back pain.",
]

def extract_with_dep_filter(text):
    # --- Key concepts used in this function ---
    #
    # tok  : one word/punctuation unit in the sentence (a spaCy Token object).
    #        e.g. for "Aspirin 81 mg" the tokens are ["Aspirin", "81", "mg"].
    #        Each token knows its text, POS tag, and its place in the dep tree.
    #
    # head : every token in the dependency tree has exactly one "head" — the
    #        token it grammatically depends on.  Think of it as the token's
    #        "parent" in a family tree.
    #        e.g. in "severe headache", "severe" is an adjective that modifies
    #        "headache", so  severe.head == headache.
    #
    # Dependency tree (dep tree):
    #   A tree where each token points to the word it modifies (its head).
    #   The root is the main verb.  All other tokens hang off it via labelled
    #   edges like nummod (numeric modifier), amod (adjective modifier), etc.
    #
    #   "She took Ibuprofen 400 mg for her severe headache."
    #
    #        took  ← ROOT
    #       /    \
    #    She   Ibuprofen   for
    #              |         \
    #             400       headache
    #              |        /      \
    #             mg      her    severe
    #
    #   Reading the edge "400 → mg" means: 400 is a nummod (numeric modifier)
    #   of mg.  But we WANT to link 400 to Ibuprofen (its drug), and the tree
    #   doesn't have that edge directly.  That's the core problem this function
    #   works around.

    doc = nlp(text)
    pairs = []
    tokens = list(doc)

    # -----------------------------------------------------------------------
    # Loop goal: visit every token and ask two questions:
    #   Q1. Is this token a number/dose (like "81", "400", "5")?
    #       If yes → find the drug it belongs to, record (drug, dose) pair.
    #   Q2. Is this token an adjective (like "severe", "chronic")?
    #       If yes → find the noun it modifies, record (noun, adjective) pair.
    # -----------------------------------------------------------------------
    for i, tok in enumerate(tokens):

        # --- Q1: dose detection ---
        # A token is a dose candidate if spaCy labels it NUM, or if it simply
        # starts with a digit (catches tokens like "81mg" if not split).
        if tok.pos_ == "NUM" or re.match(r"\d+\w*", tok.text):
            head = tok.head  # the token this number grammatically depends on

            # Ideal case: the dep tree links the number directly to the drug.
            #   "5 → nummod → Oxycodone"  →  head = Oxycodone  ✓
            #
            # Problem case: spaCy splits "81mg" into ["81", "mg"] and then
            # attaches 81 to "mg" (the unit), NOT to "Aspirin" (the drug):
            #   "81 → nummod → mg → npadvmod → given"
            # Here tok.head = "mg" (all lowercase), so the uppercase check
            # below fails and we'd miss the drug entirely without the fallback.

            if head.pos_ in {"PROPN", "NOUN"} and head.text[0].isupper():
                # Case 1: dep tree gives us the drug directly — trust it.
                drug = head.text
            else:
                # Case 2: dep tree head is a unit ("mg") or a verb ("given").
                # Fall back to a simple left-scan: in prescription text the
                # drug name always appears just before the dose, so scan up to
                # 3 tokens to the left for the nearest capitalized noun.
                drug = None
                for k in range(i - 1, max(i - 4, -1), -1):
                    candidate = tokens[k]
                    if candidate.pos_ in {"PROPN", "NOUN"} and candidate.text[0].isupper():
                        drug = candidate.text
                        break  # nearest one wins; don't keep scanning

            if drug:
                # Rebuild the full dose string: "81" + "mg" → "81mg".
                # After splitting, the unit token is always at position i+1.
                next_tok = tokens[i + 1] if i + 1 < len(tokens) else None
                dose = (tok.text + next_tok.text
                        if next_tok and re.match(r"^[a-z]+$", next_tok.text)
                        else tok.text)
                pairs.append((drug, dose, "dose"))

        # --- Q2: adjective/modifier detection ---
        # spaCy's dep tree reliably links adjectives to the noun they modify
        # via the "amod" (adjectival modifier) edge.  tok.head is the noun.
        # Example: "severe → amod → headache"  →  head = headache
        if tok.pos_ == "ADJ":
            head = tok.head
            if head.pos_ in {"NOUN", "PROPN"}:
                pairs.append((head.text, tok.text, "modifier"))

    return pairs

for sentence in ambiguous_sentences:
    pairs = extract_with_dep_filter(sentence)
    print(f"\n  Sentence : {sentence}")
    print(f"  Correctly associated pairs:")
    for entity, attr, kind in pairs:
        print(f"    {kind:<10} → entity='{entity}'  attribute='{attr}'")
