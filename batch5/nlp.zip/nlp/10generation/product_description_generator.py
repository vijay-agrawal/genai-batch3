# =============================================================================
# Text Generation with Flan-T5 — E-commerce Product Description Generator
# =============================================================================
#
# WHAT IS TEXT GENERATION?
# ─────────────────────────
# Unlike classification (predicting a label) or NER (finding named spans),
# text generation produces entirely NEW text token-by-token. The model reads
# a prompt and then repeatedly asks: "Given everything so far, what word
# should come next?" — sampling from a probability distribution over the
# entire vocabulary at each step until a stopping condition is met.
#
# REAL-WORLD USE CASE
# ───────────────────
# E-commerce platforms deal with thousands of new product listings daily.
# Writing compelling, SEO-friendly descriptions manually is expensive and
# slow. Companies like Amazon, Flipkart, and Shopify now use generative AI
# to auto-draft product copy from structured feature bullets — a copywriter
# then reviews and polishes the draft. This demo replicates that workflow.
#
# =============================================================================
# ARCHITECTURE: T5 — Text-to-Text Transfer Transformer
# =============================================================================
#
# T5 (Google, 2019) reframes every NLP task as a TEXT → TEXT problem.
# Instead of having separate model heads for classification, summarization,
# translation, Q&A, etc., T5 uses a single unified interface:
#   Input : a natural-language instruction + source text
#   Output: the answer as free text
#
# This means the same model can be prompted to:
#   "summarize: ..."        → returns a summary
#   "translate English to French: ..." → returns French text
#   "generate a product description for: ..." → returns marketing copy
#
# Architecture — Encoder-Decoder (unlike GPT which is decoder-only):
#
#   ┌─────────────────────────────────────────────────────────┐
#   │  ENCODER  (reads and encodes the full prompt)           │
#   │  ┌───────────────────────────────────────────────────┐  │
#   │  │  Token Embeddings + Relative Position Encodings  │  │
#   │  │  ↓                                               │  │
#   │  │  [Self-Attention → FFN] × N layers               │  │
#   │  │  ↓                                               │  │
#   │  │  Context vector  (rich representation of input)  │  │
#   │  └───────────────────────────────────────────────────┘  │
#   │         ↓  (cross-attention bridge)                     │
#   │  DECODER  (generates output tokens one at a time)       │
#   │  ┌───────────────────────────────────────────────────┐  │
#   │  │  [Masked Self-Attention → Cross-Attention → FFN]  │  │
#   │  │   × N layers                                      │  │
#   │  │  ↓                                                │  │
#   │  │  Vocabulary logits → softmax → next token         │  │
#   │  └───────────────────────────────────────────────────┘  │
#   └─────────────────────────────────────────────────────────┘
#
# WHY ENCODER + DECODER?
#   • The encoder builds a thorough bidirectional understanding of the
#     ENTIRE prompt (it can look left and right simultaneously).
#   • The decoder generates output left-to-right, attending to both its own
#     previous outputs AND the encoder's context via cross-attention.
#   • This separation is ideal for tasks where input and output are
#     structurally different (e.g., features → prose), unlike GPT (decoder-
#     only) which is better suited to open-ended continuation tasks.
#
# FLAN-T5 — Instruction-Tuned Variant
# ─────────────────────────────────────
# Flan-T5 (Google, 2022) is T5 fine-tuned on 1,800+ NLP tasks expressed as
# natural-language instructions ("Flan" = Finetuned LANguage models). This
# makes it able to follow zero-shot prompts without task-specific fine-tuning.
#
# Model sizes (all runnable on a laptop CPU):
#   flan-t5-small  :  60M parameters  (~240 MB)   ← fastest
#   flan-t5-base   : 250M parameters  (~990 MB)   ← used here (balance)
#   flan-t5-large  : 780M parameters  (~3.0 GB)
#   flan-t5-xl     : 3B  parameters   (~12  GB)   ← GPU recommended
#
# Compare: GPT-4 ≈ 1.8 trillion parameters, Claude 3.5 Sonnet ≈ hundreds of B
# Flan-T5-base is ~7,000× smaller than GPT-4 yet handles structured generation
# tasks well when prompts are clear.
#
# =============================================================================
# GENERATION PARAMETERS EXPLAINED
# =============================================================================
#
# max_new_tokens  – Hard cap on output length. Prevents runaway generation.
#
# do_sample       – If False → always picks the single highest-probability
#                   token (greedy decoding). Deterministic but repetitive.
#                   If True  → samples from the probability distribution,
#                   introducing variety.
#
# temperature     – Scales the logits before softmax.
#   temperature < 1.0 : sharpens the distribution → model sticks to safe,
#                       high-probability words → more predictable output.
#   temperature = 1.0 : unmodified distribution (raw model output).
#   temperature > 1.0 : flattens the distribution → model explores rare
#                       words → more creative but potentially incoherent.
#   Typical range: 0.3 (conservative copy) – 0.9 (creative writing).
#
# top_p (nucleus sampling) – Instead of sampling from the full vocabulary,
#   restrict to the smallest set of tokens whose cumulative probability ≥ p.
#   Example: top_p=0.9 means only consider tokens that together make up 90%
#   of the probability mass. This filters out very unlikely/nonsense tokens
#   while preserving diversity among plausible choices.
#   Range: 0.0–1.0 (1.0 = no restriction, same as without top_p).
#
# num_beams       – Beam search: keeps the N most promising partial sequences
#   in parallel, backtracking to pick the globally best-scoring completion.
#   num_beams=1 = greedy. num_beams=4 = higher quality, ~4× slower.
#   Beam search is deterministic (best used without do_sample).
#
# =============================================================================

from transformers import pipeline

print("Loading Flan-T5-base (250M params) — downloading ~990 MB on first run...")
print("Subsequent runs use the cached model and start instantly.\n")

# Flan-T5-base via the text2text-generation pipeline.
# Set device=-1 to force CPU (works on any laptop without a GPU).
generator = pipeline(
    "text2text-generation",
    model="google/flan-t5-base",
    device=-1,           # CPU
)

# ---------------------------------------------------------------------------
# Product catalogue — structured feature data (as a retailer would have it)
# ---------------------------------------------------------------------------

products = [
    {
        "name": "Sony WH-1000XM5 Wireless Headphones",
        "category": "Consumer Electronics",
        "features": [
            "30-hour battery life",
            "industry-leading noise cancellation",
            "multipoint Bluetooth connection for two devices",
            "ultra-lightweight 250 g design",
            "quick-charge: 3 min charge = 3 hours playback",
        ],
    },
    {
        "name": "Prestige IRIS 750W Mixer Grinder",
        "category": "Kitchen Appliances",
        "features": [
            "750W powerful motor",
            "3 stainless steel jars (1.5L, 1.0L, 0.4L)",
            "3-speed control with incher button",
            "ergonomic handles with locking lids",
            "ISI certified, 2-year warranty",
        ],
    },
    {
        "name": "Wildcraft Trailblazer 45L Hiking Backpack",
        "category": "Sports & Outdoors",
        "features": [
            "45-litre capacity with separate laptop sleeve",
            "air mesh back panel for ventilation",
            "integrated rain cover",
            "padded hip-belt and adjustable shoulder straps",
            "multiple organisation pockets",
        ],
    },
    {
        "name": "boAt Airdopes 141 True Wireless Earbuds",
        "category": "Consumer Electronics",
        "features": [
            "42-hour total playtime with charging case",
            "10mm drivers with BEAST mode for low latency gaming",
            "IPX4 water resistance",
            "instant voice assistant access",
            "under ₹1,500 budget-friendly price",
        ],
    },
]


def build_prompt(product: dict) -> str:
    """
    Convert structured product data into a natural-language instruction
    that Flan-T5 understands. Clear, imperative prompts ("Write a ...
    that highlights ...") work best for instruction-tuned models.
    """
    features_text = ", ".join(product["features"])
    return (
        f"Write a compelling e-commerce product description for "
        f"'{product['name']}' in the {product['category']} category. "
        f"Highlight these key features: {features_text}. "
        f"Keep the tone enthusiastic and informative, suitable for an "
        f"online shopping page."
    )


# ---------------------------------------------------------------------------
# Generation 1 — Greedy decoding (deterministic, no sampling)
# Use case: when you need consistent, reproducible output (A/B testing,
# audit trails, catalogue systems where the same product always gets the
# same description).
# ---------------------------------------------------------------------------

print("=" * 70)
print("  MODE 1 — Greedy Decoding (deterministic, num_beams=4)")
print("  Best for: consistency, reproducibility, formal product catalogues")
print("=" * 70)

for product in products:
    prompt = build_prompt(product)
    result = generator(
        prompt,
        max_new_tokens=120,
        num_beams=4,          # beam search for coherent output
        early_stopping=True,
    )
    description = result[0]["generated_text"]
    print(f"\nProduct : {product['name']}")
    print(f"Category: {product['category']}")
    print(f"Output  : {description}")
    print("-" * 70)

# ---------------------------------------------------------------------------
# Generation 2 — Sampling with temperature (creative, varied output)
# Use case: generating multiple description variants for A/B testing,
# personalised product pages, or fresh copy on page refreshes.
# ---------------------------------------------------------------------------

print("\n" + "=" * 70)
print("  MODE 2 — Temperature Sampling (creative, varied)")
print("  Best for: A/B testing variants, personalised pages, ad copy")
print("=" * 70)

# Pick one product and generate three distinct variants
demo_product = products[0]   # Sony headphones
prompt = build_prompt(demo_product)

print(f"\nProduct : {demo_product['name']}")
print(f"Generating 3 variants with temperature=0.8, top_p=0.92 ...\n")

for variant_num in range(1, 4):
    result = generator(
        prompt,
        max_new_tokens=120,
        do_sample=True,
        temperature=0.8,     # slightly creative
        top_p=0.92,          # nucleus sampling
    )
    print(f"Variant {variant_num}: {result[0]['generated_text']}")
    print()

# ---------------------------------------------------------------------------
# Generation 3 — Temperature effect comparison (conservative vs creative)
# ---------------------------------------------------------------------------

print("=" * 70)
print("  MODE 3 — Temperature Comparison on the same prompt")
print("  Shows how temperature controls creativity vs. predictability")
print("=" * 70)

demo_product = products[2]   # Wildcraft backpack
prompt = build_prompt(demo_product)

print(f"\nProduct : {demo_product['name']}\n")

for temp in [0.3, 0.7, 1.2]:
    result = generator(
        prompt,
        max_new_tokens=100,
        do_sample=True,
        temperature=temp,
        top_p=0.9,
    )
    label = {0.3: "Conservative (safe words, reliable)",
             0.7: "Balanced     (recommended default)",
             1.2: "Creative     (diverse, may ramble)"}[temp]
    print(f"temp={temp}  [{label}]")
    print(f"  → {result[0]['generated_text']}\n")

# =============================================================================
# WHY GENERATIVE NLP MATTERS — AND WHAT TO WATCH OUT FOR
# =============================================================================
#
# STRENGTHS OF SMALL LOCAL MODELS (Flan-T5-base)
# ───────────────────────────────────────────────
# 1. Privacy: All computation is on-device. Product data never leaves
#    the company's servers — critical for unreleased products or pricing.
#
# 2. Zero API cost: No per-token billing. Suitable for high-volume catalogue
#    generation (millions of SKUs).
#
# 3. Latency: No network round-trip. Generation happens in ~1-3 seconds
#    on a modern laptop CPU — fast enough for real-time page personalisation.
#
# 4. Customisable: Flan-T5-base can be fine-tuned on YOUR product catalogue
#    in a few hours on a single GPU to align with brand tone and vocabulary.
#
# LIMITATIONS TO BE AWARE OF
# ───────────────────────────
# 1. Factual hallucination: The model generates plausible-sounding text
#    but has no access to ground truth. It may invent specs not in the
#    prompt. Always ground generation in explicit feature lists (as done
#    here) and have a human review step.
#
# 2. Repetition: Without repetition penalties, small models can loop.
#    The 'repetition_penalty' parameter (e.g., 1.3) discourages reuse of
#    recent tokens.
#
# 3. Context window: Flan-T5-base supports up to 512 tokens input.
#    Long prompts (many feature bullets, brand guidelines) must be trimmed.
#
# 4. Quality ceiling: For nuanced, brand-voice-consistent copy, a larger
#    model or fine-tuned variant will outperform the base model. Flan-T5-base
#    is best used as a first-draft engine, not a final-copy engine.
#
# NEXT STEPS ON THE GENERATION LADDER
# ─────────────────────────────────────
# flan-t5-small  (60M)  → Fits on microcontrollers; minimal quality
# flan-t5-base   (250M) → This demo; good for structured tasks on CPU
# flan-t5-large  (780M) → Noticeably better prose; still CPU-feasible
# flan-t5-xl     (3B)   → Approaches GPT-3.5 quality on many tasks; GPU
# Llama-3.2-1B          → Tiny open decoder-only LLM; strong for chat
# Llama-3.2-3B          → Better quality, laptop GPU friendly
# GPT-4o / Claude       → Cloud API; highest quality, no local compute
#
# =============================================================================
