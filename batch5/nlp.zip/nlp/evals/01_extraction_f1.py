# =============================================================================
# F1 / Precision / Recall — Evaluating Extraction Tasks
# =============================================================================
#
# WHAT ARE PRECISION, RECALL, AND F1?
# ─────────────────────────────────────
# These are the fundamental metrics for classification and span-extraction tasks.
#
#   True Positives  (TP): Correctly predicted positive instances
#   False Positives (FP): Predicted positive, actually negative (over-prediction)
#   False Negatives (FN): Predicted negative, actually positive (missed)
#
#   Precision = TP / (TP + FP)   "Of everything I predicted, how much was right?"
#   Recall    = TP / (TP + FN)   "Of everything true, how much did I find?"
#   F1        = 2 × P × R / (P + R)  — harmonic mean, balances P and R
#
# CHOOSING BETWEEN PRECISION AND RECALL
# ───────────────────────────────────────
# The right tradeoff depends entirely on the cost of each error type:
#
#   High Recall priority (minimize FN):
#     • Medical diagnosis — missing a cancer is worse than a false alarm
#     • Fraud detection — missing fraud is worse than investigating a false lead
#     • Security threat detection — a missed attack is worse than a false positive
#
#   High Precision priority (minimize FP):
#     • Search engine results — irrelevant results waste user time
#     • Medical treatment recommendation — prescribing unnecessary treatment has risks
#     • Legal document review — flagging too many false-positive privileged docs
#
# F1 VARIANTS
# ────────────
#   Micro F1   — aggregate TP/FP/FN across ALL classes, then compute F1
#                (dominated by frequent classes; good for overall accuracy)
#   Macro F1   — compute F1 per class, then average
#                (treats all classes equally; better for class imbalance)
#   Weighted F1— compute F1 per class weighted by class support
#
# TOKEN-LEVEL F1 (for Extractive QA)
# ────────────────────────────────────
# SQuAD (Stanford QA benchmark) popularised token-level F1 for comparing
# predicted answer spans to gold answer spans. Each token is treated as
# a binary prediction:
#
#   Hypothesis : "the Battle of Hastings"
#   Reference  : "the Battle of Hastings in 1066"
#   Common     : "the", "Battle", "of", "Hastings" → 4 tokens
#   Precision  : 4/4 = 1.0   (all predicted tokens are correct)
#   Recall     : 4/6 = 0.67  (missed "in" and "1066")
#   F1         : 0.80
#
# =============================================================================
# INSTALL
# =============================================================================
# pip install scikit-learn
# =============================================================================

from collections import Counter
from sklearn.metrics import (
    precision_score, recall_score, f1_score,
    classification_report, confusion_matrix
)
import numpy as np

def print_section(title):
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)

# =============================================================================
# USE-CASE 1 — Named Entity Recognition (NER)
# =============================================================================
# NER systems extract entities (PERSON, ORG, GPE, DATE, MONEY, etc.) from text.
# Evaluation uses the CoNLL-2003 scheme:
#   • An entity is correct only if BOTH the span AND the label are correct.
#   • Partial span matches do NOT count as correct (strict evaluation).
#
# Use-case: A legal contract AI extracts parties, dates, and monetary values.
# Downstream risk: if the AI misses a party name or wrong-labels a date as an
# amount, the contract analysis system may produce incorrect outputs.

print_section("USE-CASE 1 — Named Entity Recognition (Legal Contract)")

# Format: (start, end, label) — represents entity spans in the document
# "Acme Corporation entered into an agreement with BioSynth Labs on
#  January 15, 2024, for a sum of $4.5 million."

gold_entities = {
    ("Acme Corporation", "ORG"),
    ("BioSynth Labs", "ORG"),
    ("January 15, 2024", "DATE"),
    ("$4.5 million", "MONEY"),
}

def ner_prf(predicted, gold, label=""):
    tp = len(predicted & gold)
    fp = len(predicted - gold)
    fn = len(gold - predicted)
    p  = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    r  = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * p * r / (p + r) if (p + r) > 0 else 0.0
    print(f"\n  {label}")
    print(f"    TP={tp}  FP={fp}  FN={fn}")
    print(f"    Precision={p:.3f}  Recall={r:.3f}  F1={f1:.3f}")
    missed    = gold - predicted
    spurious  = predicted - gold
    if missed:    print(f"    Missed  : {missed}")
    if spurious:  print(f"    Spurious: {spurious}")

# System A — good extractor, but wrong label on the amount
system_a_pred = {
    ("Acme Corporation", "ORG"),
    ("BioSynth Labs", "ORG"),
    ("January 15, 2024", "DATE"),
    ("$4.5 million", "CARDINAL"),   # wrong label: CARDINAL instead of MONEY
}

# System B — misses one ORG, finds everything else correctly
system_b_pred = {
    ("Acme Corporation", "ORG"),
    # BioSynth Labs missed
    ("January 15, 2024", "DATE"),
    ("$4.5 million", "MONEY"),
}

# System C — perfect
system_c_pred = gold_entities.copy()

# System D — over-predicts (hallucinates extra entities)
system_d_pred = {
    ("Acme Corporation", "ORG"),
    ("BioSynth Labs", "ORG"),
    ("January 15, 2024", "DATE"),
    ("$4.5 million", "MONEY"),
    ("2024", "DATE"),              # spurious — already captured in the full date
    ("BioSynth", "ORG"),           # spurious partial span
}

ner_prf(system_a_pred, gold_entities, "System A — wrong entity type on amount")
ner_prf(system_b_pred, gold_entities, "System B — misses one ORG (BioSynth Labs)")
ner_prf(system_c_pred, gold_entities, "System C — perfect extraction")
ner_prf(system_d_pred, gold_entities, "System D — over-predicts (hallucinated entities)")

print("""
  INSIGHT:
    System A and B both score F1 ≈ 0.75 but for different reasons:
      A: precision issue — found all entities but mislabelled one
      B: recall issue — correctly labelled everything it found but missed one
    In legal/financial NER, recall matters more (missing a party is worse than
    a label error). In data entry automation, precision matters (a wrong label
    corrupts the database).

    System D shows the precision-recall tradeoff: extracting more may raise
    recall but at the cost of precision — noisy extractions create downstream
    problems.
""")

# =============================================================================
# USE-CASE 2 — Extractive Question Answering (Token-Level F1)
# =============================================================================
# In extractive QA (SQuAD-style), the model selects a span from the context
# paragraph as the answer. Exact Match (EM) = 1 only if the prediction matches
# the reference exactly. Token F1 gives partial credit for overlapping tokens.
#
# Use-case: A medical QA system answers clinician questions from EHR notes.

print_section("USE-CASE 2 — Extractive QA Token-Level F1  (Medical)")

def normalize_tokens(text):
    """Lowercase, remove punctuation, split to tokens — standard SQuAD normalization."""
    import re, string
    text = text.lower()
    text = re.sub(f"[{re.escape(string.punctuation)}]", " ", text)
    return text.split()

def token_f1(prediction, reference):
    pred_tokens = normalize_tokens(prediction)
    ref_tokens  = normalize_tokens(reference)
    pred_counts = Counter(pred_tokens)
    ref_counts  = Counter(ref_tokens)
    common = sum((pred_counts & ref_counts).values())
    if common == 0:
        return 0.0, 0.0, 0.0
    p = common / len(pred_tokens)
    r = common / len(ref_tokens)
    f1 = 2 * p * r / (p + r)
    return p, r, f1

def exact_match(prediction, reference):
    return int(normalize_tokens(prediction) == normalize_tokens(reference))

qa_cases = [
    {
        "question": "What is the patient's eGFR?",
        "gold":     "eGFR of 28",
        "predictions": {
            "Exact match":            "eGFR of 28",
            "Partial (value only)":   "28",
            "Partial (range)":        "eGFR of 28 mL/min",
            "Wrong (BNP instead)":    "1,240 pg/mL",
            "Empty / no answer":      "",
        }
    },
    {
        "question": "What medication was held and why?",
        "gold":     "lisinopril was held given eGFR of 28",
        "predictions": {
            "Correct full span":           "lisinopril was held given eGFR of 28",
            "Partially correct (drug ok, reason missing)": "lisinopril was held",
            "Paraphrase (same meaning, different words)":  "lisinopril was discontinued due to impaired kidney function",
            "Incorrect medication":        "furosemide was held given eGFR of 28",
        }
    },
    {
        "question": "What is the daily fluid restriction?",
        "gold":     "1.5L/day",
        "predictions": {
            "Exact":           "1.5L/day",
            "Unit variant":    "1.5 litres per day",
            "Numeric only":    "1.5",
            "Wrong value":     "2L/day",
        }
    },
]

for case in qa_cases:
    print(f"\n  Q: {case['question']}")
    print(f"     Gold answer: \"{case['gold']}\"")
    print(f"     {'Prediction':<50} EM    P      R      F1")
    print(f"     {'-'*50} ----  -----  -----  -----")
    for label, pred in case["predictions"].items():
        p, r, f1 = token_f1(pred, case["gold"])
        em = exact_match(pred, case["gold"])
        pred_display = f'"{pred}"' if pred else "(no answer)"
        print(f"     {label:<50} {em}     {p:.3f}  {r:.3f}  {f1:.3f}")

print("""
  INSIGHT:
    "Paraphrase" for the medication question scores F1=0.0 despite being
    clinically correct — "discontinued due to impaired kidney function" shares
    almost no tokens with "was held given eGFR of 28".
    This is why BERTScore (semantic similarity) is used alongside token F1
    for open-domain QA. See 04_semantic_bertscore.py.

    Token F1 > EM always (EM is strictest). Both should be reported:
      EM  → measures perfect retrieval
      F1  → measures partial credit / span boundary errors
""")

# =============================================================================
# USE-CASE 3 — Multi-Label Text Classification (Clinical Coding)
# =============================================================================
# ICD-10 coding assigns diagnosis codes to clinical notes. A note may have
# multiple codes (multi-label). Evaluation uses micro/macro F1.
#
# Use-case: An automated medical coding assistant assigns ICD-10 codes to
# discharge summaries for billing and epidemiological tracking.

print_section("USE-CASE 3 — Multi-Label Classification (ICD-10 Medical Coding)")

# 5 ICD-10 codes: E11 (T2DM), I10 (HTN), N18 (CKD), I50 (Heart Failure), J18 (Pneumonia)
# Each patient's note is one sample; 1 = code present, 0 = not present

# Columns: [E11_T2DM, I10_HTN, N18_CKD, I50_HF, J18_Pneumonia]
gold_codes = np.array([
    [1, 1, 1, 1, 0],   # Patient 1: DM + HTN + CKD + Heart Failure
    [1, 0, 0, 0, 1],   # Patient 2: DM + Pneumonia
    [0, 1, 0, 1, 0],   # Patient 3: HTN + Heart Failure
    [1, 1, 1, 0, 0],   # Patient 4: DM + HTN + CKD
    [0, 0, 0, 1, 1],   # Patient 5: Heart Failure + Pneumonia
    [1, 1, 0, 0, 0],   # Patient 6: DM + HTN
])

# System A — conservative (misses some codes, high precision)
pred_conservative = np.array([
    [1, 1, 0, 1, 0],   # Missed N18_CKD
    [1, 0, 0, 0, 0],   # Missed J18_Pneumonia
    [0, 1, 0, 1, 0],   # Correct
    [1, 1, 0, 0, 0],   # Missed N18_CKD
    [0, 0, 0, 1, 0],   # Missed J18_Pneumonia
    [1, 1, 0, 0, 0],   # Correct
])

# System B — aggressive (catches more codes, more FP)
pred_aggressive = np.array([
    [1, 1, 1, 1, 1],   # FP: J18_Pneumonia (not in note)
    [1, 1, 0, 0, 1],   # FP: I10_HTN
    [1, 1, 0, 1, 0],   # FP: E11_T2DM
    [1, 1, 1, 1, 0],   # FP: I50_HF
    [0, 0, 0, 1, 1],   # Correct
    [1, 1, 0, 0, 0],   # Correct
])

code_labels = ["E11_T2DM", "I10_HTN", "N18_CKD", "I50_HF", "J18_Pneumonia"]

for name, pred in [("Conservative system", pred_conservative), ("Aggressive system", pred_aggressive)]:
    print(f"\n  {name}:")
    print(classification_report(
        gold_codes, pred,
        target_names=code_labels,
        zero_division=0
    ))

print("""
  INSIGHT:
    Conservative system: Higher precision (bills only what it's confident about),
    lower recall (misses real diagnoses → underbilling and incomplete records).

    Aggressive system: Higher recall (catches more real codes), but lower precision
    (adds spurious codes → overbilling, potential insurance fraud liability).

    In medical coding:
      • Recall matters for epidemiological completeness (CMS quality measures)
      • Precision matters for billing accuracy (OIG compliance)
      • Both systems need human review — the AI raises candidates, a certified
        medical coder (CPC) makes the final determination.

    Report BOTH micro F1 (overall accuracy) AND macro F1 (per-code balance).
    Rare codes like J18_Pneumonia need macro F1 to avoid being hidden in averages.
""")

# =============================================================================
# USE-CASE 4 — Information Extraction (Relation Extraction)
# =============================================================================
# Relation extraction identifies (subject, relation, object) triples from text.
# Used in knowledge graph construction, drug-interaction detection, and
# supply-chain risk analysis.
#
# Use-case: A pharma company extracts drug-disease treatment relationships from
# scientific abstracts to populate a knowledge graph.

print_section("USE-CASE 4 — Relation Extraction (Drug-Disease Triples)")

# Each triple: (drug, relation, disease/condition)
gold_triples = {
    ("metformin",     "treats",          "type 2 diabetes"),
    ("lisinopril",    "treats",          "hypertension"),
    ("atorvastatin",  "treats",          "hyperlipidemia"),
    ("furosemide",    "treats",          "heart failure"),
    ("metformin",     "contraindicated", "severe renal impairment"),
    ("lisinopril",    "contraindicated", "pregnancy"),
}

system_extractions = {
    "System A — good coverage, one label error": {
        ("metformin",     "treats",          "type 2 diabetes"),
        ("lisinopril",    "treats",          "hypertension"),
        ("atorvastatin",  "treats",          "hyperlipidemia"),
        ("furosemide",    "treats",          "heart failure"),
        ("metformin",     "treats",          "severe renal impairment"),   # wrong: "treats" not "contraindicated"
        ("lisinopril",    "contraindicated", "pregnancy"),
    },
    "System B — high recall, many spurious triples": {
        ("metformin",     "treats",          "type 2 diabetes"),
        ("lisinopril",    "treats",          "hypertension"),
        ("atorvastatin",  "treats",          "hyperlipidemia"),
        ("furosemide",    "treats",          "heart failure"),
        ("metformin",     "contraindicated", "severe renal impairment"),
        ("lisinopril",    "contraindicated", "pregnancy"),
        ("metformin",     "treats",          "obesity"),            # spurious
        ("furosemide",    "treats",          "hypertension"),       # spurious
        ("atorvastatin",  "treats",          "diabetes"),           # spurious
    },
    "System C — conservative, only high-confidence triples": {
        ("metformin",     "treats",          "type 2 diabetes"),
        ("lisinopril",    "treats",          "hypertension"),
        ("atorvastatin",  "treats",          "hyperlipidemia"),
        # Missed: furosemide, metformin contraindicated, lisinopril contraindicated
    },
}

for name, pred_set in system_extractions.items():
    tp = len(pred_set & gold_triples)
    fp = len(pred_set - gold_triples)
    fn = len(gold_triples - pred_set)
    p  = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    r  = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * p * r / (p + r) if (p + r) > 0 else 0.0
    print(f"\n  {name}")
    print(f"    TP={tp}  FP={fp}  FN={fn}")
    print(f"    Precision={p:.3f}  Recall={r:.3f}  F1={f1:.3f}")
    spurious = pred_set - gold_triples
    missed   = gold_triples - pred_set
    if spurious: print(f"    Spurious: {spurious}")
    if missed:   print(f"    Missed  : {missed}")

print("""
  INSIGHT:
    Relation extraction errors compound downstream: a spurious "treats" triple
    between metformin and obesity could mislead clinicians if the knowledge
    graph is used in clinical decision support without human review.

    For knowledge graph population, Precision is often prioritised over Recall:
    a sparse but accurate graph is safer than a dense graph with hallucinated edges.

    Best practice: use System B for discovery (high recall, human review),
    System C for automated ingestion (high precision, lower human cost).
""")

# =============================================================================
# USE-CASE 5 — Sentiment Classification (Multi-Class)
# =============================================================================
# Standard multi-class F1 for sentiment analysis. Shows confusion matrix
# and how class imbalance affects macro vs micro F1.

print_section("USE-CASE 5 — Sentiment Classification (Customer Support)")

# 3 classes: 0=Negative, 1=Neutral, 2=Positive
# 30 customer support ticket labels

y_true = [0,0,0,0,0, 0,0,0,0,0,   # 10 Negative
          1,1,1,1,1, 1,1,1,1,1,   # 10 Neutral
          2,2,2,2,2, 2,2,2,2,2]   # 10 Positive

# System predictions — weak on neutral class
y_pred = [0,0,0,2,0, 0,0,1,0,0,   # Negative: mostly right, 1 FP neutral, 1 FP positive
          0,1,1,1,2, 1,0,1,2,1,   # Neutral: several confused with Neg/Pos
          2,2,2,1,2, 2,2,2,2,2]   # Positive: mostly right, 1 confused with neutral

class_names = ["Negative", "Neutral", "Positive"]

print("\n  Classification Report:")
print(classification_report(y_true, y_pred, target_names=class_names))

cm = confusion_matrix(y_true, y_pred)
print("  Confusion Matrix (rows=true, cols=predicted):")
print(f"                  {'  '.join(f'{n:>10}' for n in class_names)}")
for i, row in enumerate(cm):
    print(f"  {class_names[i]:<12}  {'  '.join(f'{v:>10}' for v in row)}")

print(f"""
  INSIGHT:
    Micro F1  = {f1_score(y_true, y_pred, average='micro'):.3f}  (overall accuracy across all samples)
    Macro F1  = {f1_score(y_true, y_pred, average='macro'):.3f}  (average across classes — equally weighted)
    Weighted F1 = {f1_score(y_true, y_pred, average='weighted'):.3f}  (weighted by class support)

    All three metrics agree here (balanced classes). In imbalanced datasets
    (e.g., 80% negative, 15% neutral, 5% positive — common in ticket systems),
    they diverge significantly:
      • Micro F1 would be dominated by the Negative class
      • Macro F1 equally penalises poor Positive performance
      • Weighted F1 would be between the two

    For SLA-driven support routing, Recall on Negative is critical
    (missed angry customers escalate). For CSAT dashboards, all three classes
    matter equally — use Macro F1.
""")
