"""
BLEU and ROUGE Evaluation Metrics — Healthcare NLP Examples

BLEU  → Measures PRECISION  → catches HALLUCINATIONS (things added that shouldn't be there)
ROUGE → Measures RECALL     → catches OMISSIONS      (things missing that should be there)
"""

import nltk
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from nltk.tokenize import word_tokenize
from rouge_score import rouge_scorer
from collections import Counter
import math

nltk.download('punkt',     quiet=True)
nltk.download('punkt_tab', quiet=True)


# =============================================================================
# HELPERS
# =============================================================================

def tokenize(text):
    return word_tokenize(text.lower())

def pause(prompt="  [Press Enter to continue...]"):
    input(f"\n{prompt}\n")

def header(title):
    print("\n" + "=" * 65)
    print(f"  {title}")
    print("=" * 65)

def section(title):
    print(f"\n  --- {title} ---")


def ngram_overlap(ref_tokens, hyp_tokens, n):
    """Return (matched, ref_total, hyp_total) for n-grams."""
    def ngrams(tokens):
        return [tuple(tokens[i:i+n]) for i in range(len(tokens) - n + 1)]
    ref_c = Counter(ngrams(ref_tokens))
    hyp_c = Counter(ngrams(hyp_tokens))
    matched = sum(min(cnt, ref_c[ng]) for ng, cnt in hyp_c.items())
    return matched, len(ngrams(ref_tokens)), len(ngrams(hyp_tokens))


def show_overlap(ref_tok, hyp_tok):
    """Print BLEU (precision) and ROUGE (recall) overlap tables separately."""
    rows = []
    for n, bleu_label, rouge_label in [
        (1, "Unigrams (BLEU-1)", "Unigrams (ROUGE-1)"),
        (2, "Bigrams  (BLEU-2)", "Bigrams  (ROUGE-2)"),
    ]:
        m, ref_n, hyp_n = ngram_overlap(ref_tok, hyp_tok, n)
        prec   = m / hyp_n if hyp_n else 0
        recall = m / ref_n if ref_n else 0
        rows.append((bleu_label, rouge_label, m, hyp_n, ref_n, prec, recall))

    print()
    print(f"  BLEU — Precision (how much of the output is valid?)")
    print(f"  {'':22}  {'Matched / Hyp':>14}  {'Precision':>10}")
    print(f"  {'-'*50}")
    for bleu_label, _, m, hyp_n, _, prec, _ in rows:
        print(f"  {bleu_label:<22}  {f'{m} / {hyp_n}':>14}  {prec:>10.3f}")

    print()
    print(f"  ROUGE — Recall (how much of the reference was kept?)")
    print(f"  {'':22}  {'Matched / Ref':>14}  {'Recall':>8}")
    print(f"  {'-'*48}")
    for _, rouge_label, m, _, ref_n, _, recall in rows:
        print(f"  {rouge_label:<22}  {f'{m} / {ref_n}':>14}  {recall:>8.3f}")


def show_lcs(ref_tok, hyp_tok):
    """Print just the ROUGE-L result."""
    m, n = len(ref_tok), len(hyp_tok)
    dp = [[0]*(n+1) for _ in range(m+1)]
    for i in range(1, m+1):
        for j in range(1, n+1):
            dp[i][j] = dp[i-1][j-1]+1 if ref_tok[i-1]==hyp_tok[j-1] else max(dp[i-1][j], dp[i][j-1])
    lcs = dp[m][n]
    recall    = lcs / m
    precision = lcs / n
    denom     = precision + recall
    f1        = 2 * precision * recall / denom if denom else 0
    print(f"  ROUGE-L (LCS length={lcs})  →  Recall: {recall:.3f}  Precision: {precision:.3f}  F1: {f1:.3f}")


def compute_bleu(reference_text, hypothesis_text):
    ref = tokenize(reference_text)
    hyp = tokenize(hypothesis_text)
    sf  = SmoothingFunction().method1
    b1  = sentence_bleu([ref], hyp, weights=(1,0,0,0), smoothing_function=sf)
    b2  = sentence_bleu([ref], hyp, weights=(0,1,0,0), smoothing_function=sf)
    b4  = sentence_bleu([ref], hyp,                    smoothing_function=sf)
    bp  = min(1.0, math.exp(1 - len(ref)/len(hyp))) if len(hyp) < len(ref) else 1.0
    print(f"  BLEU-1: {b1:.3f}   BLEU-2: {b2:.3f}   BLEU-4 (combined): {b4:.3f}   BP: {bp:.3f}")
    return b4


def compute_rouge(reference_text, hypothesis_text):
    scorer = rouge_scorer.RougeScorer(['rouge1','rouge2','rougeL'], use_stemmer=False)
    scores = scorer.score(reference_text, hypothesis_text)
    print(f"  ROUGE-1  →  Recall: {scores['rouge1'].recall:.3f}  Precision: {scores['rouge1'].precision:.3f}  F1: {scores['rouge1'].fmeasure:.3f}")
    print(f"  ROUGE-2  →  Recall: {scores['rouge2'].recall:.3f}  Precision: {scores['rouge2'].precision:.3f}  F1: {scores['rouge2'].fmeasure:.3f}")
    print(f"  ROUGE-L  →  Recall: {scores['rougeL'].recall:.3f}  Precision: {scores['rougeL'].precision:.3f}  F1: {scores['rougeL'].fmeasure:.3f}")
    return scores


# =============================================================================
# OPENING: WHY DO THESE METRICS EXIST?
# =============================================================================

header("BLEU & ROUGE — Why Healthcare AI Needs Both")

print("""
  When an AI generates clinical text, two types of errors can harm patients:

    HALLUCINATION  → model ADDS something that isn't real
                     e.g., inventing a finding that wasn't in the X-ray
                     Caught by BLEU  (precision: how much of the output is valid?)

    OMISSION       → model DROPS something critical
                     e.g., forgetting to mention a life-saving medication
                     Caught by ROUGE (recall: how much of the truth was kept?)

  We'll see both failure modes through two real clinical scenarios.
""")

pause()


# =============================================================================
# EXAMPLE 1: RADIOLOGY REPORT  →  BLEU matters most
# =============================================================================

header("EXAMPLE 1 — Radiology Report (AI vs Radiologist)")

print("""
  An AI vision-language model reads a chest X-ray and generates a findings report.
  We compare it to what the radiologist actually wrote.
""")

radiology_reference  = "There is a small pleural effusion on the right side with no evidence of pneumothorax or consolidation."
radiology_hypothesis = "A small pleural effusion is seen on the right side with no pneumothorax or consolidation present."

print(f"  RADIOLOGIST : {radiology_reference}")
print(f"  AI OUTPUT   : {radiology_hypothesis}")
print("""
  The AI paraphrased — same clinical meaning, different phrasing.
  "no evidence of pneumothorax" → "no pneumothorax"

  Question: do the scores reflect that this paraphrase is acceptable?
""")

pause()

ref_tok = tokenize(radiology_reference)
hyp_tok = tokenize(radiology_hypothesis)

section("N-gram Overlap")
show_overlap(ref_tok, hyp_tok)
print()
show_lcs(ref_tok, hyp_tok)

pause()

section("BLEU & ROUGE Scores")
bleu_radiology  = compute_bleu(radiology_reference, radiology_hypothesis)
print()
rouge_radiology = compute_rouge(radiology_reference, radiology_hypothesis)

r1 = rouge_radiology['rouge1'].recall
r2 = rouge_radiology['rouge2'].recall
rl = rouge_radiology['rougeL'].recall
print(f"""
  READING THE SCORES:
    BLEU-4 {'high' if bleu_radiology >= 0.6 else 'moderate'} ({bleu_radiology:.2f})  → no hallucinated findings. Good.
    ROUGE-1 high ({r1:.2f})    → most words from the reference are present. Good.
    ROUGE-2 dips ({r2:.2f})    → bigrams like "evidence of pneumothorax" don't match.
                           But this is PARAPHRASE, not OMISSION — acceptable.
    ROUGE-L high ({rl:.2f})    → overall word order preserved. Good.

  BLEU-4 to ROUGE-2 gap is modest → model paraphrased safely.
""")

pause()


# =============================================================================
# EXAMPLE 2: DISCHARGE SUMMARY  →  ROUGE matters most
# =============================================================================

header("EXAMPLE 2 — Discharge Summary (AI vs Doctor)")

print("""
  A patient survives a heart attack (Acute MI) and is discharged.
  The AI auto-generates the discharge summary from clinical notes.

  Missing ONE medication here — clopidogrel — can cause stent thrombosis
  within days. This is a life-or-death omission.
""")

discharge_reference  = "Patient was admitted with acute MI. Treated with PCI. Discharged on aspirin, clopidogrel, and atorvastatin. Follow-up in 2 weeks with cardiologist."
discharge_hypothesis = "Patient had a heart attack and was treated. Discharged on aspirin and atorvastatin. Follow-up scheduled."

print(f"  DOCTOR    : {discharge_reference}")
print(f"  AI OUTPUT : {discharge_hypothesis}")
print("""
  Spot what the AI dropped:
    ✗  "acute MI"      → replaced with vague "heart attack"
    ✗  "PCI"           → replaced with vague "treated"
    ✗  "clopidogrel"   → GONE. Critical antiplatelet medication.
    ✗  "2 weeks"       → follow-up timeline dropped
    ✗  "cardiologist"  → specialist type dropped
""")

pause()

ref_tok_d = tokenize(discharge_reference)
hyp_tok_d = tokenize(discharge_hypothesis)

section("N-gram Overlap")
show_overlap(ref_tok_d, hyp_tok_d)
print()
show_lcs(ref_tok_d, hyp_tok_d)

pause()

section("BLEU & ROUGE Scores")
bleu_discharge  = compute_bleu(discharge_reference, discharge_hypothesis)
print()
rouge_discharge = compute_rouge(discharge_reference, discharge_hypothesis)

print("""
  READING THE SCORES:
    BLEU low (~0.30)     → vague words ("heart attack", "treated") don't match.
    ROUGE-1 mid (~0.55)  → common function words still match, masking the problem.
    ROUGE-2 LOW (~0.25)  → *** ALARM *** critical phrases entirely absent.
    ROUGE-L mid (~0.50)  → broad structure ok, clinical content missing.

  ROUGE-2 recall is the alarm bell here.
  Low ROUGE-1 AND low ROUGE-2 together = OMISSION, not paraphrase.
  → In production, a ROUGE-2 recall below 0.50 should block auto-release.
""")

pause()


# =============================================================================
# COMPARISON & TAKEAWAYS
# =============================================================================

header("Side-by-Side Comparison")

print(f"""
  {'Metric':<22} {'Radiology':<16} {'Discharge':<16}  Verdict
  {'-'*70}
  {'BLEU (combined)':<22} {bleu_radiology:<16.3f} {bleu_discharge:<16.3f}  Ex1 ✅  Ex2 ⚠️
  {'ROUGE-1 (recall)':<22} {rouge_radiology['rouge1'].recall:<16.3f} {rouge_discharge['rouge1'].recall:<16.3f}  Ex1 ✅  Ex2 ⚠️
  {'ROUGE-2 (recall)':<22} {rouge_radiology['rouge2'].recall:<16.3f} {rouge_discharge['rouge2'].recall:<16.3f}  Ex1 ⚠️  Ex2 ❌
  {'ROUGE-L (recall)':<22} {rouge_radiology['rougeL'].recall:<16.3f} {rouge_discharge['rougeL'].recall:<16.3f}  Ex1 ✅  Ex2 ⚠️
""")

print("""
  THREE RULES TO REMEMBER:

  1. Use BLEU when fabrication is dangerous  (radiology, translation).
     Use ROUGE when omission is dangerous    (discharge summaries, clinical notes).
     Best practice: always compute both.

  2. The ROUGE-1 → ROUGE-2 gap tells you WHAT went wrong:
       ROUGE-1 high, ROUGE-2 moderate  →  paraphrase  (usually acceptable)
       ROUGE-1 low,  ROUGE-2 low       →  omission    (potentially dangerous)

  3. These metrics don't catch negation flips:
       "no pleural effusion" vs "pleural effusion"  ← one word, fatal difference
     Supplement with NER-based entity checks for clinical deployments.
""")
