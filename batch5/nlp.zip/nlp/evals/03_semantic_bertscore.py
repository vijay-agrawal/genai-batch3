# =============================================================================
# BERTScore — Semantic Similarity for Text Generation Evaluation
# =============================================================================
#
# WHAT IS BERTScore?
# ──────────────────
# BERTScore (Zhang et al., 2019) computes similarity between generated and
# reference text using contextual embeddings from a pretrained BERT model,
# rather than counting word overlaps (as BLEU and ROUGE do).
#
# WHY BERTScore OVER BLEU/ROUGE?
# ───────────────────────────────
#
#   BLEU/ROUGE weakness:
#     "The automobile was parked near the building."
#     "The car was parked beside the structure."
#     → BLEU ≈ 0.10  (almost no word overlap)
#     → BERTScore ≈ 0.92  (car≈automobile, beside≈near, structure≈building)
#
#   BERTScore captures:
#     • Synonyms and paraphrases ("car" ≈ "automobile")
#     • Morphological variants ("running" ≈ "ran")
#     • Context-sensitive meaning (BERT embeddings are contextual)
#
# HOW BERTSCORE WORKS
# ────────────────────
# Given hypothesis H = {h₁, h₂, ..., hₙ} and reference R = {r₁, r₂, ..., rₘ}:
#
# 1. Encode every token in H and R using a pretrained BERT model.
#    Each token gets a dense vector (768d for BERT-base).
#
# 2. Compute pairwise cosine similarity between all (hᵢ, rⱼ) pairs.
#    This produces an n×m similarity matrix.
#
# 3. Greedy matching (like a soft alignment):
#
#    Precision (P): For each hᵢ, find the most similar rⱼ
#                   P = (1/|H|) Σᵢ max_j cos(hᵢ, rⱼ)
#
#    Recall (R):    For each rⱼ, find the most similar hᵢ
#                   R = (1/|R|) Σⱼ max_i cos(hᵢ, rⱼ)
#
#    F1 = 2PR/(P+R)  — harmonic mean as usual
#
# 4. Importance weighting (optional): IDF weights down common function words
#    ("the", "is") and up rare content words ("hypertension", "EBITDA").
#
# INTERPRETING BERTSCORE
# ───────────────────────
# BERTScore F1 is typically in the range 0.80–1.00 (not 0–1 like ROUGE).
# High baseline due to shared vocabulary across all English text.
# Use relative comparisons, not absolute thresholds:
#   • F1 > 0.95  : Near-identical or synonymous
#   • F1 0.90–0.95 : Good paraphrase quality
#   • F1 0.85–0.90 : Some meaning preserved, notable differences
#   • F1 < 0.85  : Significant semantic divergence
#
# =============================================================================
# INSTALL
# =============================================================================
# pip install bert-score transformers torch
#
# First run downloads the model (bert-base-uncased ~440MB, rescaling stats).
# Subsequent runs use the cache (~/.cache/huggingface).
# =============================================================================

from bert_score import score as bertscore
from rouge_score import rouge_scorer
import sacrebleu
from sacrebleu.metrics import BLEU

rouge = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
bleu_metric = BLEU(effective_order=True)

def print_section(title):
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)

def compare_all_metrics(label, hypothesis, reference, model_type="bert-base-uncased", lang="en"):
    """Compute BERTScore, ROUGE, and BLEU for side-by-side comparison."""
    # BERTScore
    P, R, F1 = bertscore([hypothesis], [reference], model_type=model_type, lang=lang, verbose=False)
    bs_p, bs_r, bs_f1 = P[0].item(), R[0].item(), F1[0].item()

    # ROUGE
    r_scores = rouge.score(reference, hypothesis)
    r1 = r_scores["rouge1"].fmeasure
    r2 = r_scores["rouge2"].fmeasure
    rl = r_scores["rougeL"].fmeasure

    # BLEU (sentence-level)
    bl = bleu_metric.corpus_score([hypothesis], [[reference]]).score

    print(f"\n  [{label}]")
    print(f"    Hypothesis : {hypothesis[:90]}{'...' if len(hypothesis)>90 else ''}")
    print(f"    Reference  : {reference[:90]}{'...' if len(reference)>90 else ''}")
    print(f"    BERTScore  P={bs_p:.3f}  R={bs_r:.3f}  F1={bs_f1:.3f}")
    print(f"    ROUGE      R1={r1:.3f}  R2={r2:.3f}  RL={rl:.3f}")
    print(f"    BLEU       {bl:.1f}/100")

# =============================================================================
# USE-CASE 1 — Paraphrase Quality (Semantic Similarity)
# =============================================================================
# Paraphrase detection and quality scoring is used in:
#   • Data augmentation pipelines (paraphrase training examples)
#   • Plagiarism detection (is this a disguised copy?)
#   • FAQ deduplication (are these two questions asking the same thing?)
#
# BERTScore excels here because paraphrases by definition use different words
# to express the same meaning — exactly what BLEU/ROUGE miss.

print_section("USE-CASE 1 — Paraphrase Quality Assessment")
print("\n  Reference: 'The patient was admitted to the hospital due to chest pain.'")
print()

ref_paraphrase = "The patient was admitted to the hospital due to chest pain."

paraphrase_cases = [
    ("Exact copy (baseline)",
     "The patient was admitted to the hospital due to chest pain."),

    ("High-quality paraphrase (synonym swap)",
     "The patient was hospitalised because of thoracic discomfort."),

    ("Good paraphrase (structural change)",
     "Chest pain led to the patient being admitted to hospital."),

    ("Acceptable paraphrase (meaning preserved, fewer details)",
     "The patient was hospitalised with chest pain."),

    ("Partial paraphrase (subject changed)",
     "The doctor admitted the patient due to chest pain."),

    ("Unrelated sentence",
     "Revenue grew 18% year-on-year driven by strong digital engineering demand."),
]

for label, hyp in paraphrase_cases:
    compare_all_metrics(label, hyp, ref_paraphrase)

print("""
  INSIGHT:
    "Hospitalised because of thoracic discomfort" scores low on BLEU/ROUGE
    (different words) but high on BERTScore (BERT knows thoracic ≈ chest,
    hospitalised ≈ admitted to hospital).
    "Subject changed" (doctor admitted vs patient admitted) shows BERTScore
    is not perfect — it matches tokens contextually but doesn't deeply parse
    semantic roles like agent vs patient.
""")

# =============================================================================
# USE-CASE 2 — Dialogue / Chatbot Response Evaluation
# =============================================================================
# Evaluating conversational AI is hard: there are dozens of valid responses
# to any user message. BLEU is nearly useless (< 5 for good chatbot responses),
# ROUGE is marginally better, BERTScore correlates better with human judgement.
#
# Use-case: A customer support bot's responses are evaluated against a
# model answer written by an expert agent.
#
# ADEM (2017) and BERTScore (2019) are the standard automatic metrics here.
# Human evaluation (Likert scale: relevance, fluency, factuality) remains gold standard.

print_section("USE-CASE 2 — Conversational AI Response Evaluation")

dialogues = [
    {
        "context":   "I can't log into my account. I've tried resetting my password but it still doesn't work.",
        "reference": "I'm sorry to hear you're having trouble logging in. Let me escalate this to our technical support team who can investigate your account directly. Could you please provide your account email address?",
        "responses": {
            "Good — relevant, empathetic, actionable": (
                "Apologies for the login issue. I'll connect you with our tech support team to look into your account. "
                "Can you share the email address associated with your account?"
            ),
            "Partially relevant — missing escalation step": (
                "Sorry you're having trouble. Please try clearing your browser cache and cookies, "
                "then attempt to reset your password again."
            ),
            "Off-topic — wrong department scripted response": (
                "Thank you for contacting us! Our business hours are Monday to Friday, 9 AM to 6 PM. "
                "We look forward to assisting you."
            ),
            "Hallucinated — claims account is locked without knowing": (
                "Your account has been temporarily locked due to multiple failed login attempts. "
                "It will automatically unlock after 24 hours."
            ),
        }
    }
]

for d in dialogues:
    print(f"\n  Context: {d['context']}")
    print(f"\n  Expert reference response:")
    print(f"    {d['reference']}")
    print()
    for label, response in d["responses"].items():
        compare_all_metrics(label, response, d["reference"])

print("""
  INSIGHT:
    "Partially relevant" scores moderate on all metrics — it shares the apology
    and login-issue framing but suggests a different action.
    "Off-topic" scores very low on all metrics (correctly identified as irrelevant).
    "Hallucinated" is dangerous — it gives false information confidently.
    BERTScore catches it as low-relevance but cannot flag it as factually wrong.
    Chatbot evaluation requires:
      • BERTScore for semantic relevance
      • Factual consistency check (does the response contradict known facts?)
      • Safety classifiers (does the response hallucinate security-sensitive info?)
""")

# =============================================================================
# USE-CASE 3 — Summarization: Where BERTScore > ROUGE
# =============================================================================
# Demonstrates the specific case where an abstractive paraphrase summary is
# semantically correct but lexically different — BERTScore rewards it,
# ROUGE punishes it.

print_section("USE-CASE 3 — Abstractive Summarization (Semantic vs Lexical)")

fin_reference = (
    "Meridian Infotech's Q3 revenue rose 17.8% to ₹4,812 crore, EBITDA margin "
    "expanded to 24.3%, and management raised full-year CC growth guidance to 15.5-16.5%."
)

summaries = [
    ("Extractive (copies reference phrases directly)",
     "Revenue rose 17.8% to ₹4,812 crore with EBITDA margin at 24.3%. "
     "Management raised full-year CC growth guidance to 15.5-16.5%."),

    ("Abstractive paraphrase (same facts, different words)",
     "Meridian posted an 18% top-line jump to ₹4,812 Cr with operating margin "
     "at 24.3%, prompting an upgrade of its annual constant-currency revenue target to 15.5–16.5%."),

    ("Abstractive — omits guidance (incomplete but correct)",
     "Meridian reported strong Q3 results with revenue up ~18% YoY to ₹4,812 crore "
     "and EBITDA margins improving to 24.3%."),

    ("Semantically wrong — inverted direction",
     "Meridian Infotech's Q3 revenue fell 17.8% to ₹4,812 crore and EBITDA margin "
     "contracted to 24.3%, leading management to cut annual growth guidance."),
]

for label, hyp in summaries:
    compare_all_metrics(label, hyp, fin_reference)

print("""
  INSIGHT:
    The "abstractive paraphrase" uses "top-line jump" instead of "revenue rose",
    "operating margin" instead of "EBITDA margin", "prompting an upgrade" instead
    of "management raised". ROUGE heavily penalises this. BERTScore rewards it.

    The "semantically wrong — inverted" summary has high ROUGE (same numbers
    appear) but BERTScore correctly downgrades it (the embedding context of
    "fell" vs "rose" is meaningfully different in BERT's representation space).

    Neither metric is foolproof:
    • Use ROUGE when exact phrasing matters (regulatory filings, templates)
    • Use BERTScore when semantic correctness matters more than word choice
    • Combine both for robust summarization evaluation
""")

# =============================================================================
# USE-CASE 4 — Cross-Lingual Evaluation
# =============================================================================
# mBERT and XLM-RoBERTa enable BERTScore across language pairs.
# Useful for: MT evaluation, multilingual summarization, cross-lingual QA.
#
# Here we evaluate a Spanish translation of an English reference sentence
# using multilingual BERTScore (model: xlm-roberta-base).

print_section("USE-CASE 4 — Cross-Lingual BERTScore (EN ↔ ES)")

cross_lingual_cases = [
    {
        "label": "Correct translation (high semantic similarity expected)",
        "en_ref": "The patient must take two tablets of metformin 500mg twice daily with meals.",
        "es_hyp": "El paciente debe tomar dos tabletas de metformina 500mg dos veces al día con las comidas.",
    },
    {
        "label": "Good translation, different phrasing",
        "en_ref": "The patient must take two tablets of metformin 500mg twice daily with meals.",
        "es_hyp": "El paciente ha de administrarse dos comprimidos de metformina 500 mg con alimentos, dos veces por día.",
    },
    {
        "label": "Wrong dose in translation (50mg instead of 500mg)",
        "en_ref": "The patient must take two tablets of metformin 500mg twice daily with meals.",
        "es_hyp": "El paciente debe tomar dos tabletas de metformina 50mg dos veces al día con las comidas.",
    },
    {
        "label": "Completely wrong (different medication and instruction)",
        "en_ref": "The patient must take two tablets of metformin 500mg twice daily with meals.",
        "es_hyp": "El paciente debe evitar el consumo de alcohol y mantenerse hidratado.",
    },
]

for case in cross_lingual_cases:
    P, R, F1 = bertscore(
        [case["es_hyp"]], [case["en_ref"]],
        model_type="xlm-roberta-base",
        lang="es",
        verbose=False
    )
    print(f"\n  [{case['label']}]")
    print(f"    EN ref : {case['en_ref']}")
    print(f"    ES hyp : {case['es_hyp']}")
    print(f"    XLM-RoBERTa BERTScore  P={P[0]:.3f}  R={R[0]:.3f}  F1={F1[0]:.3f}")

print("""
  INSIGHT:
    Cross-lingual BERTScore uses XLM-RoBERTa which was trained on 100 languages
    in a shared embedding space — semantically similar sentences across languages
    are close in this space regardless of surface form.

    The wrong-dose translation (50mg vs 500mg) scores slightly lower than the
    correct one — numerals are often represented similarly in embeddings, so the
    difference is subtle. This shows why cross-lingual evaluation for clinical
    text MUST also include terminology-level checks (regex or terminology DB
    matching) in addition to neural metrics.
""")

# =============================================================================
# USE-CASE 5 — Choosing the Right Metric: Summary Guidance
# =============================================================================

print_section("USE-CASE 5 — Which Metric for Which Task?")

print("""
  ┌────────────────────────────────┬─────────┬───────┬───────────┐
  │ Task / Domain                  │  BLEU   │ ROUGE │ BERTScore │
  ├────────────────────────────────┼─────────┼───────┼───────────┤
  │ Machine translation            │ Primary │  —    │ Supplement│
  │ Code generation                │ BLEU /  │  —    │ Supplement│
  │                                │ pass@k  │       │           │
  │ News summarization             │  —      │Primary│ Supplement│
  │ Financial summarization        │  —      │Primary│ Supplement│
  │ Medical summarization          │  —      │Primary│ Supplement│
  │ Dialogue / chatbot response    │  Weak   │ Weak  │  Primary  │
  │ Paraphrase quality             │  Weak   │ Weak  │  Primary  │
  │ Open-ended text generation     │  Weak   │ Weak  │  Primary  │
  │ Cross-lingual evaluation       │  —      │  —    │  Primary  │
  │                                │         │       │ (mBERT/   │
  │                                │         │       │ XLM-R)    │
  ├────────────────────────────────┼─────────┼───────┼───────────┤
  │ Factual correctness            │  None   │ None  │  None     │
  │ (use: TRUE, SummaC, FactScore) │         │       │           │
  │ Safety / harm                  │  None   │ None  │  None     │
  │ (use: classifier, human review)│         │       │           │
  └────────────────────────────────┴─────────┴───────┴───────────┘

  GENERAL BEST PRACTICE (2024+):
    1. Always report multiple metrics — no single metric tells the full story.
    2. Include a human evaluation study (even small: n=50, 3 annotators)
       alongside automatic metrics.
    3. For high-stakes domains (medical, legal, financial):
       automatic metrics are screening tools, not validation.
    4. Report the metric library, model, and version — scores are not
       comparable across implementations.
    5. Consider COMET / BLEURT for translation; TRUE / SummaC for factuality.
""")
