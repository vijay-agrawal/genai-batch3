# Assignment 2: TF-IDF vs Embeddings vs Hybrid Retrieval

## Part 1: TF-IDF vs Embeddings

For the following documents and queries, compare TF-IDF with embeddings. Which one offers better results? For which queries?

```python
DOCUMENTS: List[str] = [
    "Discharge summary: Patient diagnosed with acute myocardial infarction ICD-10 I21.9. Troponin-I elevated. Started antiplatelet therapy.",
    "Cardiology note: Patient had heart attack last year with chest pain history. Cardiac enzymes previously elevated.",
    "Outpatient diabetes review: Type 2 diabetes mellitus ICD-10 E11.9. HbA1c 8.4 percent. Metformin continued.",
    "Endocrinology note: Poor glycemic control in diabetes. Blood sugar remains high over three months.",
    "Pulmonary admission: Community acquired pneumonia ICD-10 J18.9. Productive cough, fever, and infiltrates on chest X-ray.",
    "Respiratory infection note: Lower lung infection with fever and cough. Antibiotics prescribed.",
    "Lab report: HbA1c measured at 8.4 percent indicating poor long-term glucose control.",
    "Lab report: Troponin-I positive suggesting myocardial injury.",
]

QUERIES: List[str] = [
    "Find records with ICD-10 I21.9",
    "Show patients with HbA1c 8.4 percent",
    "Find documents containing ICD-10 E11.9",
    "Search for Troponin-I positive",
]
```

---

## Part 2: Hybrid Retrieval (TF-IDF + Embeddings)

For the documents and queries below, explore Hybrid Retrieval (TF-IDF + embeddings) and analyze whether hybrid retrieval performs better than TF-IDF alone.

```python
DOCUMENTS: List[Dict[str, str]] = [
    {
        "id": "D1",
        "text": "Discharge summary: Patient diagnosed with acute myocardial infarction ICD-10 I21.9. Troponin-I elevated. Aspirin started."
    },
    {
        "id": "D2",
        "text": "Cardiology note: Patient had heart attack with chest pain and elevated cardiac enzymes."
    },
    {
        "id": "D3",
        "text": "Outpatient diabetes review: Type 2 diabetes mellitus ICD-10 E11.9. HbA1c 8.4 percent. Metformin continued."
    },
    {
        "id": "D4",
        "text": "Endocrinology follow-up: Poor glycemic control in diabetes. Blood sugar remains high over the last three months."
    },
    {
        "id": "D5",
        "text": "Pulmonary admission: Community acquired pneumonia ICD-10 J18.9. Fever, productive cough, lung infiltrates seen on imaging."
    },
    {
        "id": "D6",
        "text": "Respiratory infection note: Lower lung infection with fever and cough. Antibiotics prescribed."
    },
    {
        "id": "D7",
        "text": "Lab report: HbA1c measured at 8.4 percent indicating poor long-term glucose control."
    },
    {
        "id": "D8",
        "text": "Lab report: Troponin-I positive suggesting myocardial injury."
    },
    {
        "id": "D9",
        "text": "Administrative coding sheet: ICD-10 I21.9 confirmed for inpatient billing."
    }
]

QUERIES = [
    "Find ICD-10 I21.9 cases",
    "Show HbA1c 8.4 records",
    "heart attack patient",
    "lung infection with fever",
]
```
