# =============================================================================
# Dimensionality Reduction — Visualising Text in 2-D
# =============================================================================
#
# -----------------------------------------------------------------------------
# BUSINESS VALUE
# -----------------------------------------------------------------------------
# Text features (TF-IDF, embeddings) can have tens of thousands of dimensions.
# Dimensionality reduction delivers value in two distinct ways:
#
#   1. VISUALISATION — compress to 2-D/3-D so humans can *see* whether the
#      model has learned meaningful structure.  A scatter plot where "Sports"
#      articles cluster away from "Finance" articles is instant, intuitive
#      evidence that your features are working.  This builds stakeholder trust
#      and catches problems (e.g. label noise, topic bleed) before deployment.
#
#   2. SPEED & MEMORY — reducing 50,000 TF-IDF features to 100–300 principal
#      components can cut training time by 10-100× with minimal accuracy loss,
#      enabling faster iteration and cheaper cloud bills.
#
# -----------------------------------------------------------------------------
# COMMON USE-CASES
# -----------------------------------------------------------------------------
#   • Content moderation — visualise flagged vs. safe posts to spot edge cases
#     and check whether borderline content sits near the correct cluster.
#   • Customer support — cluster support tickets to discover recurring themes;
#     feed reduced vectors into a faster routing model.
#   • E-commerce search — compress product embeddings so nearest-neighbour
#     search runs in milliseconds at scale (ANN indexes love low dimensions).
#   • Document deduplication — near-duplicate detection is faster in a reduced
#     space (e.g. identifying near-identical legal contracts or news rewrites).
#   • Anomaly detection — unusual documents (fraud, mis-classified items) often
#     appear as outliers in a 2-D projection before any label is available.
#   • Model debugging — when a classifier underperforms on a slice, plotting
#     that slice in 2-D reveals whether the issue is feature overlap or data
#     quality.
#
# -----------------------------------------------------------------------------
# WHERE THIS FITS IN AN NLP PIPELINE
# -----------------------------------------------------------------------------
#
#   Raw Text
#      ↓
#   Preprocessing  (tokenise, clean, normalise)
#      ↓
#   Feature Extraction  (TF-IDF / word2vec / sentence-transformers)
#      ↓
#   *** DIMENSIONALITY REDUCTION  ←  YOU ARE HERE ***
#      ├─ For visualisation  →  2-D/3-D plot (exploratory / stakeholder demo)
#      └─ For modelling      →  reduced dense matrix fed to downstream model
#      ↓
#   Downstream Task  (classification, clustering, semantic search, …)
#      ↓
#   Evaluation / Deployment
#
# Reduction sits *after* feature extraction and *before* the downstream model.
# It is optional — skip it when your feature space is already compact (e.g.
# 768-dim sentence embeddings going into a fine-tuned transformer head), but
# valuable when features are sparse and very high-dimensional (e.g. raw TF-IDF).
#
# High-dimensional text vectors (TF-IDF, word embeddings) are impossible to
# plot directly. Dimensionality reduction compresses them into 2-D or 3-D
# while trying to preserve the structure that matters most.
#
# This demo uses the same news-article corpus as the classifier demos and
# compares two popular algorithms side-by-side:
#
#   1. PCA  — Principal Component Analysis
#   2. UMAP — Uniform Manifold Approximation and Projection
#
# =============================================================================
# CONCEPT: PCA (Principal Component Analysis)
# =============================================================================
#
# PCA is a linear method. It finds the directions (principal components) along
# which the data varies the most, then projects every point onto the top-k of
# those directions.
#
# Intuition — imagine a cloud of points in 3-D that looks like a flat pancake
# tilted in space. PCA finds the two axes of the pancake (the directions of
# maximum spread) and "drops" the cloud onto those two axes.
#
# Maths (simplified):
#   1. Centre the data: X ← X - mean(X)
#   2. Compute the covariance matrix: C = X^T X / (n-1)
#   3. Eigendecompose C: C = V Λ V^T
#   4. The columns of V are the principal components (sorted by eigenvalue).
#   5. Project: X_2d = X · V[:, :2]
#
# Strengths:
#   • Deterministic and fast — O(n · d²) for n samples, d features
#   • Preserves global, linear structure (relative distances of cluster centres)
#   • "Explained variance ratio" tells you how much information is retained
#
# Limitations:
#   • Only captures linear relationships — curved manifolds are flattened
#   • Dense clusters with non-linear internal structure look like blobs
#
#   Examples of non-linear structure PCA struggles with:
#
#   1. Disease progression (healthcare)
#      Imagine 10,000 patient records with features: HbA1c, fasting glucose,
#      BMI, age, and systolic BP.  The clinical thresholds are:
#
#        Stage          HbA1c    Fasting glucose   Typical BMI
#        Normal         < 5.7%   < 100 mg/dL       22–25
#        Pre-diabetic   5.7–6.4% 100–125 mg/dL     26–30
#        Diabetic       ≥ 6.5%   ≥ 126 mg/dL       30–35
#
#      As the disease advances, these three variables rise together but
#      not in a straight line — BMI plateaus while HbA1c keeps climbing,
#      and glucose spikes non-linearly near the diabetic threshold.
#      PCA finds the single axis of maximum spread (roughly "sicker →
#      healthier") and projects all three stages onto it; pre-diabetic
#      patients land right on top of the normal group, making early
#      intervention targets invisible.  UMAP preserves the curved
#      progression arc and keeps the three stages as distinct islands —
#      a care manager scanning the 2-D plot can immediately circle the
#      ~2,000 pre-diabetic patients for outreach.
#
#   2. Insurance fraud rings
#      A health insurer processes 500,000 claims/month.  Roughly 1–2%
#      (~6,000 claims) are fraudulent.  A typical fraud ring looks like:
#
#        • 1 provider billing CPT code 99215 (complex office visit)
#          for 40+ patients/day — physically impossible
#        • Claims submitted within a 3-day window, all for $285
#        • Patients share the same ZIP code and referred by the same GP
#
#      In a dataset with 50 features (claim amount, CPT code, days since
#      last claim, provider ID, patient age, …), the fraud ring is a tiny,
#      ultra-tight cluster of ~200 points.  PCA maximises overall variance,
#      which is dominated by the 494,000 legitimate claims spread across
#      a wide range of amounts and codes.  The fraud ring gets squashed
#      into the edge of the legitimate cloud and is invisible.  UMAP's
#      local neighbourhood graph (n_neighbors=15) recognises that those
#      200 points are extremely close to each other and far from everything
#      else; it pulls them into an isolated island in 2-D that an analyst
#      spots instantly — no threshold tuning needed.
#
#   3. Treatment response subgroups (healthcare)
#      A clinical trial of 3,000 patients on a cholesterol drug measures
#      LDL reduction after 12 weeks.  Patients split into three groups:
#
#        Subgroup          % of patients   LDL drop   Key marker
#        Responders        45%             −40–55%     PCSK9 variant present
#        Partial resp.     35%             −15–39%     heterozygous variant
#        Non-responders    20%             < 15%       wild-type gene
#
#      The separation depends on a combination of genetic marker + dosage
#      history (patients who missed doses cluster differently even within
#      the same genetic group).  This creates a curved surface: dosage
#      compliance bends the responder cluster toward the partial-responder
#      cluster for patients with the PCSK9 variant but low adherence.
#      PCA projects everything onto "average LDL drop" and the three
#      subgroups collapse into one smeared blob — a doctor sees no
#      actionable structure.  UMAP unrolls the surface: the three
#      subgroups appear as separate clusters, and the low-adherence
#      responders appear as a visible bridge between group 1 and group 2,
#      directly informing a dosage-compliance intervention.
#
# =============================================================================
# CONCEPT: UMAP (Uniform Manifold Approximation and Projection)
# =============================================================================
#
# UMAP is a non-linear method rooted in Riemannian geometry and topology.
# It builds a fuzzy graph of nearest-neighbour relationships in high-D space,
# then optimises a low-D layout that best preserves that graph.
#
# Intuition — imagine the data lies on a curved surface (manifold) embedded in
# high-D space. PCA would cut through the surface; UMAP "unrolls" it.
#
# Key hyperparameters:
#   n_neighbors  — how many neighbours to consider when building the graph.
#                  Small → preserves local clusters tightly.
#                  Large → preserves global structure (like PCA).
#   min_dist     — minimum distance between points in 2-D.
#                  Small → tighter, more separated clusters.
#                  Large → more uniform, less clumped layout.
#
# Strengths:
#   • Captures non-linear and local structure that PCA misses
#   • Typically produces cleaner visual separation of semantic clusters
#   • Scales well to millions of points (stochastic gradient optimisation)
#
# Limitations:
#   • Non-deterministic (set random_state for reproducibility)
#   • Hyperparameter-sensitive — different n_neighbors → different pictures
#   • Distances between clusters are NOT always meaningful across runs
#
# =============================================================================
# WHAT TO LOOK FOR IN THE PLOT
# =============================================================================
#
# Both methods project the same TF-IDF matrix (28 articles × vocabulary words)
# down to 2-D.  You should observe:
#
#   • Three clearly separated regions: sports / entertainment / politics
#   • PCA axes represent the directions of maximum variance (labelled PC1/PC2)
#   • UMAP axes are abstract — only the *relative positions* of points matter
#   • UMAP clusters tend to be tighter and more separated than PCA clusters
#
# =============================================================================

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import PCA
from sklearn.preprocessing import normalize

try:
    import umap
    UMAP_AVAILABLE = True
except ImportError:
    UMAP_AVAILABLE = False

# ---------------------------------------------------------------------------
# Corpus — same articles used in the classifier demos
# ---------------------------------------------------------------------------

texts = [
    # Sports (0–7)
    "The football team won the championship after a thrilling final match.",
    "Rohit Sharma scored a brilliant century to lead India to victory.",
    "The tennis star claimed her third Grand Slam title of the season.",
    "Manchester United signed a new striker for a record transfer fee.",
    "The Olympics opening ceremony drew millions of viewers worldwide.",
    "The basketball player broke the all-time scoring record last night.",
    "Spain's national team clinched the World Cup with a stunning goal.",
    "The marathon runner set a new world record at the Berlin race.",

    # Entertainment (8–19)
    "The blockbuster film grossed over a billion dollars at the box office.",
    "The pop star announced a world tour starting next month in London.",
    "The award-winning actress received an Oscar for her role in the drama.",
    "A new streaming series broke viewership records on its premiere weekend.",
    "The music album debuted at number one on charts in fifteen countries.",
    "Hollywood director unveiled the trailer for his highly anticipated sequel.",
    "The comedian's stand-up special became the most-watched show on the platform.",
    "The fashion icon launched a new clothing line at Milan Fashion Week.",
    "The celebrity couple confirmed their engagement, with fans celebrating on social media.",
    "A viral video of the actress's red carpet look sent social media into a frenzy.",
    "The reality TV star's wedding was watched by millions on the streaming platform.",
    "Celebrity gossip dominated social media after the singer confirmed the romance.",

    # Politics (20–27)
    "The prime minister announced a new budget focused on infrastructure spending.",
    "Parliament passed the landmark climate bill after months of debate.",
    "The senator called for an independent inquiry into the defence contract.",
    "Diplomatic talks between the two nations resumed after a year-long freeze.",
    "The opposition party filed a motion of no confidence against the cabinet.",
    "Voters went to the polls in a closely contested gubernatorial election.",
    "The president signed an executive order on immigration policy reform.",
    "United Nations delegates agreed on a new global trade framework.",
]

labels = ["sports"] * 8 + ["entertainment"] * 12 + ["politics"] * 8

# ---------------------------------------------------------------------------
# Step 1 — TF-IDF vectorisation
# ---------------------------------------------------------------------------

print("=" * 62)
print("Step 1 — TF-IDF vectorisation")
print("=" * 62)

vectorizer = TfidfVectorizer(stop_words="english", max_features=500)
X = vectorizer.fit_transform(texts).toarray()       # (28, vocab_size)
X = normalize(X)                                    # L2-normalise rows

print(f"  Corpus size : {len(texts)} documents")
print(f"  Vocabulary  : {X.shape[1]} terms (after stop-word removal)")
print(f"  Matrix shape: {X.shape}  (documents × terms)")

# ---------------------------------------------------------------------------
# Step 2 — PCA
# ---------------------------------------------------------------------------

print()
print("=" * 62)
print("Step 2 — PCA: reduce to 2 dimensions")
print("=" * 62)

pca = PCA(n_components=2, random_state=42)
X_pca = pca.fit_transform(X)

var1, var2 = pca.explained_variance_ratio_ * 100
print(f"  PC1 explains {var1:.1f}% of total variance")
print(f"  PC2 explains {var2:.1f}% of total variance")
print(f"  Combined     {var1 + var2:.1f}% retained in 2-D projection")
print()
print("  Interpretation: the remaining ~{:.0f}% of variance is lost — high-".format(
    100 - var1 - var2))
print("  dimensional text rarely compresses losslessly into 2 components.")

# Show per-category spread in PCA space
colour_map = {"sports": "tab:blue", "entertainment": "tab:orange", "politics": "tab:green"}
label_array = np.array(labels)

print()
print("  Cluster centres in PCA space:")
for cat in ["sports", "entertainment", "politics"]:
    mask = label_array == cat
    centre = X_pca[mask].mean(axis=0)
    print(f"    {cat:<14s}  PC1={centre[0]:+.3f}  PC2={centre[1]:+.3f}")

# --- What do PC1 and PC2 actually capture? ---
feature_names = vectorizer.get_feature_names_out()
pc1_load = pca.components_[0]
pc2_load = pca.components_[1]

print()
print("  What drives PC1?  (the words with the largest weights)")
print("    High PC1 →", list(feature_names[np.argsort(pc1_load)[-6:][::-1]]))
print("    Low  PC1 →", list(feature_names[np.argsort(pc1_load)[:6]]))
print()
print("  What drives PC2?")
print("    High PC2 →", list(feature_names[np.argsort(pc2_load)[-6:][::-1]]))
print("    Low  PC2 →", list(feature_names[np.argsort(pc2_load)[:6]]))

print()
print("  Real-world connection")
print("  ─────────────────────────────────────────────────────────")
print("  Imagine you run a news app (BBC, Google News, Flipboard).")
print("  Every incoming article is turned into a TF-IDF vector —")
print("  effectively a fingerprint of its vocabulary.")
print()
print("  PCA shows that just TWO numbers (PC1, PC2) are enough to")
print("  pull Sports / Entertainment / Politics into separate")
print("  corners of a 2-D map:")
print()
print("    Sports       → dominated by player names, match results,")
print("                   tournament words (century, champion, goal)")
print("    Entertainment→ dominated by showbiz words (Oscar, tour,")
print("                   streaming, celebrity, fashion, album)")
print("    Politics     → dominated by governance words (parliament,")
print("                   senator, executive, diplomatic, budget)")
print()
print("  Because the clusters don't overlap, a simple distance rule")
print("  ('which cluster centre am I closest to?') can route a new")
print("  article to the right section of the app — no manual tagging")
print("  needed.  This is the foundation of automated content")
print("  categorisation used by every major news platform.")

# ---------------------------------------------------------------------------
# Step 3 — UMAP (optional — requires `pip install umap-learn`)
# ---------------------------------------------------------------------------

print()
print("=" * 62)
print("Step 3 — UMAP: reduce to 2 dimensions")
print("=" * 62)

if UMAP_AVAILABLE:
    reducer = umap.UMAP(
        n_components=2,
        n_neighbors=5,      # small corpus → use small neighbourhood
        min_dist=0.3,
        metric="cosine",    # cosine distance is natural for TF-IDF vectors
        random_state=42,
    )
    X_umap = reducer.fit_transform(X)
    print("  UMAP parameters:")
    print("    n_neighbors = 5    (neighbourhood size for graph construction)")
    print("    min_dist    = 0.3  (minimum 2-D distance between points)")
    print("    metric      = cosine")
    print()
    print("  Cluster centres in UMAP space:")
    for cat in ["sports", "entertainment", "politics"]:
        mask = label_array == cat
        centre = X_umap[mask].mean(axis=0)
        print(f"    {cat:<14s}  UMAP1={centre[0]:+.3f}  UMAP2={centre[1]:+.3f}")
else:
    print("  umap-learn is NOT installed.")
    print("  Install it with:  pip install umap-learn")
    print("  Skipping UMAP — only the PCA plot will be saved.")

# ---------------------------------------------------------------------------
# Step 4 — Plot
# ---------------------------------------------------------------------------

print()
print("=" * 62)
print("Step 4 — Generating plot")
print("=" * 62)

n_plots = 2 if UMAP_AVAILABLE else 1
fig, axes = plt.subplots(1, n_plots, figsize=(7 * n_plots, 6))
if n_plots == 1:
    axes = [axes]

# --- shared helpers ---

# Representative words shown on each cluster centroid
cluster_keywords = {
    "sports":        "goal / match\nchampion / player",
    "entertainment": "Oscar / album\nstreaming / celebrity",
    "politics":      "parliament / senator\nbudget / diplomatic",
}

def scatter_ax(ax, X2d, xlabel, ylabel, title, extra_note=""):
    """Draw a labelled 2-D scatter plot on *ax*."""
    for cat, colour in colour_map.items():
        mask = label_array == cat
        ax.scatter(
            X2d[mask, 0], X2d[mask, 1],
            c=colour, label=cat, s=80, alpha=0.85, edgecolors="white", linewidths=0.5,
        )
        # annotate each point with a short doc index
        for idx in np.where(mask)[0]:
            ax.annotate(
                str(idx),
                (X2d[idx, 0], X2d[idx, 1]),
                fontsize=7, color="dimgray",
                xytext=(3, 3), textcoords="offset points",
            )
        # mark cluster centroid with a star + keyword label
        centre = X2d[mask].mean(axis=0)
        ax.scatter(*centre, marker="*", s=350, c=colour, zorder=6,
                   edgecolors="black", linewidths=0.6)
        ax.annotate(
            f"{cat.upper()}\n{cluster_keywords[cat]}",
            centre, fontsize=8, fontweight="bold", color="black",
            xytext=(10, 10), textcoords="offset points",
            bbox=dict(boxstyle="round,pad=0.3", fc="white", alpha=0.7, ec=colour),
            arrowprops=dict(arrowstyle="-", color=colour, lw=1.2),
        )

    ax.set_xlabel(xlabel, fontsize=11)
    ax.set_ylabel(ylabel, fontsize=11)
    ax.set_title(title, fontsize=13, fontweight="bold")
    ax.legend(loc="best", fontsize=9)
    ax.grid(True, linestyle="--", alpha=0.4)
    if extra_note:
        ax.text(
            0.01, 0.01, extra_note,
            transform=ax.transAxes, fontsize=8,
            verticalalignment="bottom", color="gray",
        )

# --- PCA subplot ---
scatter_ax(
    axes[0], X_pca,
    xlabel=f"PC1  ({var1:.1f}% variance)",
    ylabel=f"PC2  ({var2:.1f}% variance)",
    title="PCA — 2-D projection of TF-IDF vectors",
    extra_note=f"Total variance retained: {var1 + var2:.1f}%",
)

# --- UMAP subplot ---
if UMAP_AVAILABLE:
    scatter_ax(
        axes[1], X_umap,
        xlabel="UMAP dimension 1",
        ylabel="UMAP dimension 2",
        title="UMAP — 2-D projection of TF-IDF vectors",
        extra_note="n_neighbors=5  min_dist=0.3  metric=cosine",
    )

fig.suptitle(
    "Dimensionality Reduction: News Articles (28 docs × TF-IDF)",
    fontsize=14, y=1.02,
)
plt.tight_layout()
out_path = "04_dimensionality_reduction.png"
plt.savefig(out_path, dpi=150, bbox_inches="tight")
print(f"  Plot saved → {out_path}")
plt.show()          # opens an interactive window

# ---------------------------------------------------------------------------
# Step 5 — Key takeaways
# ---------------------------------------------------------------------------

print()
print("=" * 62)
print("Key takeaways")
print("=" * 62)
print()
print("  PCA")
print("  ─────────────────────────────────────────────────────────")
print("  • Linear projection — only captures variance, not curves")
print(f"  • Keeps {var1 + var2:.0f}% of variance in 2 components")
print("  • Fast and deterministic — same result every run")
print("  • Cluster centres are well-separated; individual points")
print("    may overlap within a cluster")
print()
print("  UMAP" if UMAP_AVAILABLE else "  UMAP  (not installed — install umap-learn to enable)")
if UMAP_AVAILABLE:
    print("  ─────────────────────────────────────────────────────────")
    print("  • Non-linear — can 'unroll' curved manifolds")
    print("  • Tighter, more visually distinct clusters than PCA")
    print("  • n_neighbors controls local vs. global structure tradeoff")
    print("  • Distances *between* clusters are not directly comparable")
    print("  • Non-deterministic — fix random_state for reproducibility")
print()
print("  Rule of thumb")
print("  ─────────────────────────────────────────────────────────")
print("  Use PCA first (fast sanity-check); switch to UMAP when")
print("  clusters overlap or you suspect non-linear structure.")
print()
print("  Connecting the dots — what this achieves in practice")
print("  ─────────────────────────────────────────────────────────")
print("  1. CONTENT ROUTING  — new article → TF-IDF vector →")
print("     project to 2-D → nearest cluster = section label.")
print("     No human editor needed for initial categorisation.")
print()
print("     ┌─ Why not just use a TF-IDF classifier instead? ───────")
print("     │")
print("     │  If you already have labelled training data, a TF-IDF")
print("     │  classifier (Naive Bayes, Logistic Regression, SVM)")
print("     │  WILL outperform nearest-centroid routing in 2-D space.")
print("     │  The classifier operates in the full high-dimensional")
print("     │  vocabulary and uses the labels directly — it has more")
print("     │  signal, so it makes fewer mistakes.")
print("     │")
print("     │  Dimensionality reduction earns its place in four")
print("     │  situations where a classifier cannot:")
print("     │")
print("     │  a) NO LABELS YET — DR + clustering lets you discover")
print("     │     natural groupings before you invest in labelling.")
print("     │     You can see 'there are 3 clusters' visually, then")
print("     │     label just the centroid of each one to bootstrap.")
print("     │")
print("     │  b) AUDITING A CLASSIFIER — after training, project")
print("     │     the test set into 2-D and colour by prediction.")
print("     │     Misclassified points appear in the wrong-colour")
print("     │     region, revealing *why* the model is confused")
print("     │     (e.g. sports/entertainment overlap on 'star').")
print("     │")
print("     │  c) COLD-START / NEW CATEGORIES — a new category")
print("     │     (e.g. 'health') has no training data yet.  Plot")
print("     │     incoming articles; if they form a visible cluster")
print("     │     separate from existing ones, you know it is worth")
print("     │     labelling and adding to the classifier.")
print("     │")
print("     │  d) COMPUTE AT SCALE — similarity search on a 2-D or")
print("     │     50-D vector is orders of magnitude faster than on")
print("     │     a 50,000-word vocabulary.  Production recommenders")
print("     │     (Spotify, Netflix) reduce embeddings before nearest-")
print("     │     neighbour search for exactly this reason.")
print("     │")
print("     │  Rule: use a classifier for prediction; use DR for")
print("     │  exploration, debugging, and unsupervised scenarios.")
print("     └────────────────────────────────────────────────────────")
print()
print("  2. ANOMALY DETECTION — an article that falls far from")
print("     every cluster centre is ambiguous or cross-category")
print("     (e.g. 'athlete retires, enters politics').  Flag it")
print("     for manual review rather than auto-routing.")
print()
print("  3. MODEL DEBUGGING — if 'sports' and 'entertainment'")
print("     overlap in PCA space, your vocabulary shares celebrity-")
print("     athlete words ('star', 'record', 'fans').  Fix:")
print("     engineer better features or gather more training data.")
print()
print("  4. RECOMMENDATION ENGINE — articles close together in")
print("     2-D share vocabulary, so 'users who read article 3")
print("     (tennis) also liked article 6 (basketball)' is a")
print("     natural similarity signal for a 'Read next' feature.")
