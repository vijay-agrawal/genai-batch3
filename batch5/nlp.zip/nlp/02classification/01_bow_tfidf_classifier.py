# =============================================================================
# Bag of Words & TF-IDF -- Clinical Note Specialty Routing
# =============================================================================
#
# This demo classifies an unstructured clinical note into one of four specialty
# queues:
#   "cardiology"  |  "oncology"  |  "psychiatry"  |  "emergency"
#
# Real-world use case:
#   Hospital EHR systems receive thousands of unstructured clinical notes daily.
#   Automatically routing them to the correct specialty team reduces manual
#   triage time, speeds up consultations, and ensures the right clinician
#   reviews the note first -- cutting delays in patient care.
#
#   Examples of where this is deployed today:
#     - Apollo Hospitals intelligent note-routing system
#     - NHS Digital clinical coding support tool
#     - Epic/Cerner EHR auto-categorisation pipelines
#
# Two classical NLP pipelines are compared side-by-side:
#   1. Bag of Words  (CountVectorizer)  + Multinomial Naive Bayes
#   2. TF-IDF        (TfidfVectorizer)  + Multinomial Naive Bayes
#
# =============================================================================
# CONCEPT: Bag of Words (BoW)
# =============================================================================
#
# The simplest way to turn text into numbers: ignore word order and grammar,
# just count how many times each word appears.
#
# Example -- two clinical notes:
#   A: "Patient presents with chest pain and elevated troponin on ECG"
#   B: "Patient reports low mood and passive suicidal ideation this week"
#
# Vocabulary (all unique words across A and B, stop words removed):
#   ['chest', 'ecg', 'elevated', 'ideation', 'mood', 'pain',
#    'patient', 'presents', 'reports', 'suicidal', 'troponin']
#
# BoW vectors (raw counts):
#   A: [1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1]  <- 'chest', 'troponin', 'ECG' present
#   B: [0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0]  <- 'suicidal', 'mood', 'ideation' present
#
# A classifier learns: 'troponin', 'ECG', 'chest'   -> cardiology
#                      'suicidal', 'mood', 'ideation' -> psychiatry
#
# Limitation: common words like "patient", "history", "noted" appear in every
# clinical note and inflate counts without carrying any specialty signal.
#
# =============================================================================
# CONCEPT: TF-IDF (Term Frequency - Inverse Document Frequency)
# =============================================================================
#
# TF-IDF down-weights words common across ALL notes ("patient", "admitted",
# "history") and up-weights rare, specialty-specific terms.
#
# TF  (Term Frequency)        = count(word in note) / total words in note
# IDF (Inverse Doc Frequency) = log( total notes / notes containing word )
# TF-IDF score                = TF x IDF
#
# Intuition using clinical examples:
#   "patient"    appears in every note  -> IDF near 0 -> TF-IDF near 0  (ignored)
#   "troponin"   appears only in cardiac notes  -> IDF high -> TF-IDF high
#   "FOLFOX"     appears only in oncology notes -> IDF high -> TF-IDF high
#   "PHQ-9"      appears only in psychiatry notes -> IDF high -> TF-IDF high
#   "GCS"        appears only in emergency notes -> IDF high -> TF-IDF high
#
# The effect: a note that mentions "troponin" twice scores it much higher than
# a note that mentions "patient" ten times, because troponin is genuinely rare
# and diagnostic whereas "patient" tells the classifier nothing about specialty.
#
# =============================================================================
# CONCEPT: Multinomial Naive Bayes Classifier
# =============================================================================
#
# Naive Bayes uses Bayes theorem to pick the most likely class:
#
#   P(class | words) is proportional to P(class) x product of P(word | class)
#
# During training it learns two things per class:
#   P(cardiology)              -- what fraction of training notes are cardiology?
#   P("troponin" | cardiology) -- in cardiology notes, how often does "troponin" appear?
#
# At prediction time it multiplies these probabilities for every word in the
# new note, then picks the specialty with the highest combined score.
#
# "Naive" means it assumes all words are statistically independent of each
# other. "Chest" and "pain" co-occur constantly in real notes, but the model
# treats them as if they provide independent evidence. Despite this simplifying
# assumption, Naive Bayes works very well for routing tasks because different
# specialties use strongly distinct vocabularies -- oncology notes rarely
# contain "troponin" and cardiology notes rarely contain "FOLFOX".
#
# Multinomial Naive Bayes is specifically designed for count-based features
# (word frequencies), making it a natural match for BoW and TF-IDF vectors.
# 
#
# =============================================================================
# CONCEPT: scikit-learn Pipeline
# =============================================================================
#
# sklearn.pipeline.Pipeline chains multiple processing steps into one object
# that behaves like a single estimator. This matters for three reasons:
#
#   1. Prevents data leakage -- the vectorizer vocabulary is fitted only on
#      training data and applied consistently to test data. Without a pipeline
#      it is easy to accidentally fit the vectorizer on the full dataset first,
#      which leaks test-set information into the model.
#
#   2. Makes cross-validation correct -- each CV fold refits the vectorizer
#      only on that fold's training split, not on the held-out portion.
#
#   3. Serialises cleanly -- pickle the pipeline and you get vectorizer +
#      classifier bundled together, ready to deploy as a single artefact.
#
# In this demo, two pipelines are built:
#   Pipeline 1:  CountVectorizer  ->  MultinomialNB   (Bag of Words)
#   Pipeline 2:  TfidfVectorizer  ->  MultinomialNB   (TF-IDF)
#
# Each step is a tuple of (name, estimator). The final step must implement
# fit() and predict(); all earlier steps must implement fit_transform().
#
# =============================================================================
# WHAT DOES THE NAIVE BAYES CLASSIFIER ACTUALLY RECEIVE AS INPUT?
# =============================================================================
#
# The NB classifier never sees raw text. The vectorizer step converts text to
# numbers first; NB only ever receives a numeric matrix.
#
# Concretely, given the 4 training notes in this demo:
#
#   note 0: "Patient presents with chest pain and elevated troponin on ECG"
#   note 1: "Patient reports low mood and passive suicidal ideation this week"
#   note 2: "Patient undergoing chemotherapy reports nausea and fatigue"
#   note 3: "Patient brought in after road traffic accident with multiple fractures"
#
# After CountVectorizer builds a vocabulary of all unique tokens, each note
# becomes a row of integer word counts (simplified excerpt):
#
#              accident  chemotherapy  chest  ecg  elevated  fatigue  fractures  ...
#   note 0  [    0            0          1     1      1        0         0       ...]
#   note 1  [    0            0          0     0      0        0         0       ...]
#   note 2  [    0            1          0     0      0        1         0       ...]
#   note 3  [    1            0          0     0      0        0         1       ...]
#
# This is a sparse matrix of shape (4 notes x ~35 unique words).
# "Sparse" because most cells are 0 -- each note uses only a small fraction of
# the full vocabulary. scikit-learn stores this as scipy.sparse.csr_matrix to
# avoid allocating memory for all the zeros.
#
# For TfidfVectorizer the structure is the same but cell values are
# floating-point TF-IDF scores instead of raw counts:
#
#              accident  chemotherapy  chest   ecg   elevated  fatigue  fractures ...
#   note 0  [   0.0         0.0        0.53   0.53    0.53      0.0       0.0    ...]
#   note 1  [   0.0         0.0        0.0    0.0     0.0       0.0       0.0    ...]
#   note 2  [   0.0         0.58       0.0    0.0     0.0       0.58      0.0    ...]
#   note 3  [   0.45        0.0        0.0    0.0     0.0       0.0       0.45   ...]
#
# Specialty-specific terms ("troponin", "chemotherapy", "fractures") score
# higher than tokens shared across notes ("patient", "reports") because their
# IDF is high -- they appear in few notes so they carry more discriminating power.
#
# What Naive Bayes does with this matrix:
#
#   During fit():
#     For each class label, sums the column values across all notes of that class
#     to estimate how characteristic each word is of that specialty.
#     Stores log P(word | class) for every (word, class) combination.
#
#   During predict():
#     For a new note's sparse row vector, looks up the log-probability of each
#     non-zero word under every class, sums them up, adds log P(class), and
#     returns the class with the highest total log-probability.
#
# Formally, the inputs to the classifier are:
#   X  -- scipy.sparse.csr_matrix, shape (n_samples, n_vocabulary_words)
#          each row is one note; each column is one vocabulary word
#   y  -- list of string labels, length n_samples
#          e.g. ["cardiology", "psychiatry", "oncology", "emergency"]
#
# =============================================================================
# CONCEPT: Training and Test Data
# =============================================================================
#
# The labelled dataset is split into two non-overlapping subsets:
#
#   Training set (75% of data by default in this demo):
#     The model sees these examples during training. The vectorizer builds its
#     vocabulary here, and Naive Bayes estimates its per-word probabilities here.
#
#   Test set (25% of data):
#     Held back entirely during training. After training is complete, the model
#     predicts labels for these unseen notes. Comparing predictions against true
#     labels gives an honest estimate of real-world performance.
#
# Note: this demo uses only 4 notes in total (3 training, 1 test). Results will
# be volatile -- a single wrong prediction changes accuracy by 100%. In
# production you would need hundreds of labelled notes per specialty to get
# stable, meaningful accuracy estimates.
#
# =============================================================================
# CONCEPT: Evaluation Metrics
# =============================================================================
#
# A single metric is rarely enough; the right choice depends on the clinical
# cost of each error type. The key metrics for a multi-class routing model are:
#
# ACCURACY  = correct predictions / total predictions
#   Simplest metric, but misleading when classes are imbalanced.
#   If 90% of notes are cardiology, a model that always predicts "cardiology"
#   achieves 90% accuracy while completely failing the other three specialties.
#
# PRECISION (per class)  = true positives / (true positives + false positives)
#   Of all notes the model routes to psychiatry, how many actually belong there?
#   Low precision means notes are wrongly sent to a specialty team, wasting
#   clinician time on irrelevant cases.
#
# RECALL (per class)  = true positives / (true positives + false negatives)
#   Of all genuine psychiatry notes, how many did the model correctly route there?
#   Low recall means real psychiatry cases slip through to the wrong team,
#   delaying care. In a clinical safety context, low recall is usually the more
#   dangerous error -- a missed urgent case causes more harm than a misrouted one.
#
# F1 SCORE  = 2 x (precision x recall) / (precision + recall)
#   The harmonic mean of precision and recall. Useful when both matter and you
#   want one number per class. It penalises extreme imbalances -- a model that
#   achieves 100% precision but 10% recall scores an F1 of only 0.18.
#
# AUC (Area Under the ROC Curve):
#   Applies to binary or one-vs-rest multi-class classification. An AUC of 1.0
#   is a perfect classifier; 0.5 is random chance. Useful when you care about
#   how well the model ranks confidence scores, not just whether the top
#   prediction is correct. Helpful for setting thresholds for human review.
#
# scikit-learn's classification_report() prints precision, recall, and F1 for
# each class, plus macro-averaged (all classes equally weighted) and
# weighted-averaged (weighted by class frequency) summary rows.
#
# =============================================================================
# CONCEPT: Feature Importance and Interpretability
# =============================================================================
#
# A major advantage of BoW/TF-IDF + Naive Bayes over deep learning models is
# full transparency: you can inspect exactly which words drove each prediction.
#
# From a trained MultinomialNB model:
#   classifier.feature_log_prob_[class_index]
#     -- array of log P(word | class) for every word in the vocabulary.
#     -- The highest values identify the words that most strongly signal that class.
#
# Example learned signals:
#   cardiology  -> 'troponin', 'ecg', 'ejection', 'stenosis', 'stent'
#   oncology    -> 'chemotherapy', 'folfox', 'tumour', 'metastasis', 'cycle'
#   psychiatry  -> 'suicidal', 'phq', 'ideation', 'mood', 'sertraline'
#   emergency   -> 'gcs', 'trauma', 'fracture', 'accident', 'intubated'
#
# This interpretability is clinically valuable. If a routing decision is
# challenged ("why was this note sent to oncology?"), you can point to the
# exact tokens that raised its score -- supporting audit, compliance, and
# clinician trust in the system.
#
# =============================================================================
# LIMITATIONS OF BAG-OF-WORDS / TF-IDF APPROACHES
# =============================================================================
#
# 1. OUT-OF-VOCABULARY (OOV)
#    The vectorizer locks its vocabulary at training time. Any word in a new
#    note that was not seen during training is silently dropped before
#    classification. A note mentioning a newly approved drug ("semaglutide")
#    would lose that token entirely, potentially causing misrouting.
#
# 2. NO UNDERSTANDING OF NEGATION
#    "No chest pain" and "chest pain" produce nearly identical feature vectors
#    because both contain the tokens "chest" and "pain". The model cannot
#    distinguish a symptom from its denial -- a critical failure in clinical
#    triage where negated findings must not trigger the same routing action as
#    confirmed ones.
#
# 3. ABBREVIATION AMBIGUITY
#    The same abbreviation means different things across specialties:
#      "MS"  = multiple sclerosis (neurology), mitral stenosis (cardiology),
#              or morphine sulphate (palliative care)
#      "PCA" = patient-controlled analgesia (pain) or posterior cerebral artery
#              (neurosurgery)
#    The model has no mechanism to resolve these by context; whichever meaning
#    appeared most often in training will dominate regardless of clinical setting.
#
# 4. NO SEMANTIC UNDERSTANDING
#    "MI" and "myocardial infarction" are two completely separate vocabulary
#    tokens. A model trained on notes that write "MI" will not recognise
#    "myocardial infarction" as a cardiac signal, and vice versa. TF-IDF has no
#    concept of synonyms, abbreviation expansion, or clinical equivalence.
#
# 5. WORD ORDER IS LOST
#    "Patient has no history of chest pain" and "Patient has chest pain, no
#    prior history" contain the same tokens and produce identical BoW/TF-IDF
#    vectors despite having different clinical meaning. Sentence structure and
#    context are invisible to these representations.
#
# 6. SMALL TRAINING DATA SENSITIVITY
#    With only a handful of notes per specialty, the model is extremely
#    sensitive to the random train/test split. A single atypical note in the
#    test set can move accuracy by 25-50 percentage points, making evaluation
#    results unreliable at this scale.
#
# =============================================================================
# THE NEXT LEVEL: WORD EMBEDDINGS
# =============================================================================
#
# Instead of sparse word-count vectors, map every word to a dense 300-dim
# vector trained on billions of medical texts. This addresses several of the
# limitations above:
#
#   "MI" and "myocardial infarction" become close neighbours in vector space --
#   the model recognises them as equivalent without needing both in training data.
#
#   "breathlessness" and "dyspnoea" are treated as near-synonyms automatically,
#   because they appear in similar contexts across the training corpus.
#
#   "Lisinopril" and "Ramipril" (both ACE inhibitors) cluster together, so the
#   model generalises across brand/generic names for the same drug class.
#
#   Word order can be partially preserved using sentence embeddings -- either
#   averaging word vectors or using a transformer encoder -- enabling the model
#   to distinguish "no chest pain" from "chest pain".
#
# See 02_word_embeddings_classifier.py for this step.
#
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

# Define the training data
notes = [
    "Patient presents with chest pain and elevated troponin on ECG",
    "Patient reports low mood and passive suicidal ideation this week",
    "Patient undergoing chemotherapy reports nausea and fatigue",
    "Patient brought in after road traffic accident with multiple fractures"
]

labels = ["cardiology", "psychiatry", "oncology", "emergency"]

# Split the data into training and test sets
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(notes, labels, test_size=0.25, random_state=42)

# Create a pipeline with TF-IDF Vectorizer and Multinomial Naive Bayes
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer()),
    ('classifier', MultinomialNB())
])

# Train the model
pipeline.fit(X_train, y_train)

# Evaluate the model
accuracy = pipeline.score(X_test, y_test)
print(f"Model accuracy: {accuracy:.2f}")

# Predict on new data
new_notes = [
    "Patient complains of severe chest pain and shortness of breath",
    "Patient exhibits signs of depression and anxiety"
]
predictions = pipeline.predict(new_notes)
for note, prediction in zip(new_notes, predictions):
    print(f"Note: {note}\nPredicted Specialty: {prediction}\n")
