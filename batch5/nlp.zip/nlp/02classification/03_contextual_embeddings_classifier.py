# =============================================================================
# Contextual Embeddings for Text Classification
# DistilBERT [CLS] Token + Logistic Regression
# =============================================================================
#
# This demo builds directly on 02_word_embeddings_classifier.py.
#
# Remaining limitation of static (mean) word vectors from demo 02:
#   A static embedding gives ONE fixed vector to a word regardless of the
#   sentence it appears in. "run" has the same 300-dim GloVe vector whether
#   it means "sprint down the flank", "run for president", or "run of a show
#   on Broadway". The mean document vector mixes all word senses equally and
#   cannot tell them apart. This is the POLYSEMY problem.
#
# What contextual embeddings add:
#   DistilBERT generates a DIFFERENT 768-dim vector for EVERY token,
#   conditioned on ALL surrounding tokens via self-attention. The word "run"
#   in a sports sentence gets a different vector than in a political sentence,
#   because the model has read — and mixed in — the full context.
#
#   For classification we use the [CLS] special token: it is prepended to
#   every input and its final hidden state aggregates full-sentence meaning.
#   This 768-dim [CLS] vector is our document representation, fed to a
#   Logistic Regression classifier trained on the same 28 labelled examples.
#
#   DistilBERT is used as a FROZEN feature extractor here — no fine-tuning.
#   Only the Logistic Regression head is trained. Even without fine-tuning,
#   BERT-family representations are rich enough to outperform static GloVe
#   on context-sensitive classifications.
#
# =============================================================================
# HOW BERT BUILDS CONTEXTUAL WORD VECTORS
# =============================================================================
#
# Input:   [CLS] The senator announced her run for the presidency . [SEP]
#
# Step 1 — WordPiece tokenisation
#   Text is split into sub-word tokens. "presidency" might stay whole or
#   split as ["presid", "##ency"]. Each token is embedded as a 768-dim vector
#   (token embedding + position embedding).
#
# Step 2 — 6 Transformer encoder layers, each containing:
#   a) Multi-Head Self-Attention (12 heads, head_dim=64)
#      Every token "attends to" every other token. For the token "run":
#        - In the sports sentence:   it attends to "midfielder", "flank", "goal"
#          These high-attention neighbours PUSH "run" toward sports meaning.
#        - In the politics sentence: it attends to "senator", "announced", "presidency"
#          These push "run" toward candidacy meaning.
#   b) Feed-Forward layer (768 -> 3072 -> 768) applied token-wise.
#   c) Residual connections + LayerNorm around each sub-layer.
#
# After 6 layers, each token position holds a 768-dim vector that is a
# weighted mixture of ALL positions in the sequence — the entire sentence
# has been "baked in" to every token's representation.
#
# Step 3 — Extract [CLS] vector as document representation
#   Position 0 ([CLS]) has been attended to by every layer from all heads.
#   Its final hidden state is a 768-dim summary of the full sentence meaning.
#   This single vector is fed to a 3-way Logistic Regression classifier.
#
# =============================================================================
# Q: DOES BERT START FROM A FIXED VECTOR AND THEN ADJUST IT WITH CONTEXT?
# =============================================================================
#
# Short answer: YES — and that is exactly the right mental model.
#
# BERT has TWO distinct stages inside it, and understanding them clarifies
# how it relates to the GloVe approach in demo 02.
#
# --- Stage 1: Static token embedding lookup  (same idea as GloVe) ---
#
#   BERT contains a learned embedding matrix of shape (vocab_size, 768).
#   vocab_size for distilbert-base-uncased is 30,522 WordPiece tokens.
#
#   When "run" is tokenised to token-ID 2448, BERT looks up row 2448 of
#   this matrix and returns a fixed 768-dim vector. At this stage it is
#   completely context-free — exactly like looking up "run" in GloVe.
#   If you stopped here, BERT would be no better than GloVe.
#
#   Two important differences from GloVe even at this stage:
#     1. These embeddings were NOT trained standalone (like GloVe was with
#        co-occurrence statistics). They were trained END-TO-END jointly
#        with the 6 transformer layers during masked-language-model (MLM)
#        pre-training. So the initial embedding already "knows" it will be
#        transformed by attention — it is shaped to be a good starting point
#        for the layers above, not a final representation.
#     2. BERT uses sub-word (WordPiece) tokens, so "presidency" might split
#        into ["presid", "##ency"], each with its own base embedding. GloVe
#        has no vector for unknown words; BERT always has sub-word pieces.
#
# --- Stage 2: Contextual transformation through 6 encoder layers ---
#
#   The 768-dim base vectors flow into 6 stacked Transformer encoder blocks.
#   Each block applies multi-head self-attention + feed-forward + residual:
#
#     Layer 0  input:  "run" = static_embedding["run"]  (context-free)
#     Layer 0  output: "run" = f(static_embedding["run"],
#                                 static_embedding["senator"],
#                                 static_embedding["presidency"], ...)
#                            ← first contextual update
#     Layer 1  output: "run" = g(layer0_output["run"],
#                                 layer0_output["senator"],
#                                 layer0_output["presidency"], ...)
#                            ← deeper contextual update
#     ...
#     Layer 5  output: "run" = final, fully contextualised 768-dim vector
#
#   After each layer, every token's vector has absorbed more and more
#   information from its neighbours. By Layer 5 the "run" vector in
#   "senator ... run for the presidency" is fundamentally different from
#   the same word's vector in "midfielder ... run down the flank".
#
# --- Analogy: First draft vs. edited manuscript ---
#
#   Stage 1 (token lookup) = a writer's FIRST DRAFT of a word's meaning —
#     the dictionary definition, context-free.
#
#   Stage 2 (6 transformer layers) = an editor reads the FULL paragraph,
#     goes back to each word, and revises its meaning based on everything
#     around it — six rounds of increasingly deep revision.
#
#   GloVe only has Stage 1 (first draft, never revised).
#   BERT has Stage 1 (first draft) + Stage 2 (six editorial passes).
#
# --- Why this matters for the demo ---
#
#   When we extract the vector for "run" in Part 1 below:
#     GloVe: we get the row from its embedding table — Stage 1 output only.
#             Same for every sentence. Cosine similarity = 1.000.
#     BERT:  we get the Layer-5 output — Stage 1 AND Stage 2 combined.
#             Different per sentence. Cosine similarity = 0.45-0.53.
#
# --- Summary: the three-demo progression ---
#
#   TF-IDF  + Naive Bayes          vocabulary lookup, context-blind
#   GloVe   + Logistic Regression  semantic similarity, still context-blind
#   BERT    + Logistic Regression  Stage-1 lookup PLUS Stage-2 contextual
#                                  transformation — polysemy resolved
#
# =============================================================================

import numpy as np
import torch
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.linear_model import LogisticRegression
from sklearn.metrics.pairwise import cosine_similarity as cos_sim
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from transformers import AutoTokenizer, AutoModel
import spacy

print("Loading models (first run downloads ~268 MB DistilBERT)...")
nlp      = spacy.load("en_core_web_md")
_tok     = AutoTokenizer.from_pretrained("distilbert-base-uncased")
_bert    = AutoModel.from_pretrained("distilbert-base-uncased")
_bert.eval()
print("Models loaded.\n")

# ---------------------------------------------------------------------------
# Helpers: BERT inference (use module-level _tok/_bert to avoid sklearn clone)
# ---------------------------------------------------------------------------

def _bert_encode(text):
    """Run DistilBERT on text; return last_hidden_state (seq_len, 768)."""
    enc = _tok(text, return_tensors="pt", truncation=True, max_length=512)
    with torch.no_grad():
        out = _bert(**enc)
    return out.last_hidden_state[0], _tok.convert_ids_to_tokens(enc["input_ids"][0])


def bert_cls_vector(text):
    """[CLS] hidden state — 768-dim contextual document representation."""
    hidden, _ = _bert_encode(text)
    return hidden[0].numpy()                                    # position 0 = [CLS]


def bert_word_vector(sentence, word):
    """
    Contextual embedding of `word` inside `sentence`.
    Finds the first token whose cleaned form (stripping ## prefix) matches
    the target word, handling WordPiece sub-word tokenisation.
    """
    hidden, tokens = _bert_encode(sentence)
    word_lower = word.lower()
    for i, t in enumerate(tokens):
        clean = t.replace("##", "")
        if clean == word_lower:
            return hidden[i].numpy()
    return hidden[0].numpy()                                    # fallback: [CLS]

# ---------------------------------------------------------------------------
# Custom vectorizers
# ---------------------------------------------------------------------------

class MeanWordVectorizer(BaseEstimator, TransformerMixin):
    """Static GloVe mean of token vectors (from demo 02)."""
    def __init__(self, nlp_model):
        self.nlp_model = nlp_model
    def fit(self, X, y=None):
        return self
    def transform(self, X):
        return np.array([self.nlp_model(text).vector for text in X])


class BertClsVectorizer(BaseEstimator, TransformerMixin):
    """DistilBERT [CLS] token — 768-dim contextual document vector."""
    def fit(self, X, y=None):
        return self
    def transform(self, X):
        return np.array([bert_cls_vector(text) for text in X])

# ---------------------------------------------------------------------------
# Training data — identical to demos 01 and 02 (fair comparison)
# ---------------------------------------------------------------------------

train_texts = [
    # Sports
    "The football team won the championship after a thrilling final match.",
    "Rohit Sharma scored a brilliant century to lead India to victory.",
    "The tennis star claimed her third Grand Slam title of the season.",
    "Manchester United signed a new striker for a record transfer fee.",
    "The Olympics opening ceremony drew millions of viewers worldwide.",
    "The basketball player broke the all-time scoring record last night.",
    "Spain's national team clinched the World Cup with a stunning goal.",
    "The marathon runner set a new world record at the Berlin race.",

    # Entertainment
    "The blockbuster film grossed over a billion dollars at the box office.",
    "The pop star announced a world tour starting next month in London.",
    "The award-winning actress received an Oscar for her role in the drama.",
    "A new streaming series broke viewership records on its premiere weekend.",
    "The music album debuted at number one on charts in fifteen countries.",
    "Hollywood director unveiled the trailer for his highly anticipated sequel.",
    "The comedian's stand-up special became the most-watched show on the platform.",
    "The fashion icon launched a new clothing line at Milan Fashion Week.",
    "The celebrity couple confirmed their engagement, with fans celebrating on social media.",
    "A viral video of the actress's red carpet look sent social media into a frenzy.",
    "The reality TV star's wedding was watched by millions on the streaming platform.",
    "Celebrity gossip dominated social media after the singer confirmed the romance.",

    # Politics
    "The prime minister announced a new budget focused on infrastructure spending.",
    "Parliament passed the landmark climate bill after months of debate.",
    "The senator called for an independent inquiry into the defence contract.",
    "Diplomatic talks between the two nations resumed after a year-long freeze.",
    "The opposition party filed a motion of no confidence against the cabinet.",
    "Voters went to the polls in a closely contested gubernatorial election.",
    "The president signed an executive order on immigration policy reform.",
    "United Nations delegates agreed on a new global trade framework.",
]

train_labels = (
    ["sports"] * 8
    + ["entertainment"] * 12
    + ["politics"] * 8
)

# ---------------------------------------------------------------------------
# Three classification pipelines (one per demo)
# ---------------------------------------------------------------------------

tfidf_pipe = Pipeline([
    ("vec", TfidfVectorizer(stop_words="english")),
    ("clf", MultinomialNB()),
])
tfidf_pipe.fit(train_texts, train_labels)

glove_pipe = Pipeline([
    ("vec", MeanWordVectorizer(nlp)),
    ("clf", LogisticRegression(max_iter=1000, C=0.5)),
])
glove_pipe.fit(train_texts, train_labels)

print("Encoding 28 training articles with DistilBERT...")
bert_pipe = Pipeline([
    ("vec", BertClsVectorizer()),
    ("clf", LogisticRegression(max_iter=1000, C=0.1)),
])
bert_pipe.fit(train_texts, train_labels)
print("Done.\n")

# ---------------------------------------------------------------------------
# Helper: three-way side-by-side comparison
# ---------------------------------------------------------------------------

def compare(article, true_label, note):
    t_pred  = tfidf_pipe.predict([article])[0]
    g_pred  = glove_pipe.predict([article])[0]
    b_pred  = bert_pipe.predict([article])[0]
    t_proba = tfidf_pipe.predict_proba([article])[0]
    g_proba = glove_pipe.predict_proba([article])[0]
    b_proba = bert_pipe.predict_proba([article])[0]
    classes = tfidf_pipe.classes_

    vt = "CORRECT" if t_pred == true_label else "WRONG  "
    vg = "CORRECT" if g_pred == true_label else "WRONG  "
    vb = "CORRECT" if b_pred == true_label else "WRONG  "

    ts = "  ".join(f"{c}={p:.2f}" for c, p in zip(classes,              t_proba))
    gs = "  ".join(f"{c}={p:.2f}" for c, p in zip(glove_pipe.classes_,  g_proba))
    bs = "  ".join(f"{c}={p:.2f}" for c, p in zip(bert_pipe.classes_,   b_proba))

    print(f"  Note      : {note}")
    print(f"  Article   : {article}")
    print(f"  True label: {true_label}")
    print(f"  TF-IDF    : {vt} => {t_pred:<15}  ({ts})")
    print(f"  GloVe+LR  : {vg} => {g_pred:<15}  ({gs})")
    print(f"  BERT +LR  : {vb} => {b_pred:<15}  ({bs})")

# =============================================================================
# PART 1 — Polysemy: same word, different contexts, different BERT vectors
# =============================================================================
#
# We take the single word "run" and put it into three sentences where it has
# completely different meanings:
#
#   Sports:        "run" = sprint down the pitch (physical movement)
#   Politics:      "run" = candidacy for election  (metaphorical campaign)
#   Entertainment: "run" = duration of a show on Broadway (temporal span)
#
# GloVe gives "run" ONE fixed 300-dim vector, regardless of sentence.
# When we extract the "run" token vector from each sentence, it is IDENTICAL.
# Cosine similarity between any two = 1.000 (same point in vector space).
#
# DistilBERT gives "run" a DIFFERENT 768-dim vector in each sentence, because
# self-attention has mixed in the surrounding tokens. The similarity between
# the sports "run" and the politics "run" will be noticeably below 1.
#
# =============================================================================

target_word = "run"
polysemy_sentences = {
    "sports":        "The midfielder's blistering run down the flank set up the opening goal.",
    "politics":      "The senator announced her run for the presidency backed by major donors.",
    "entertainment": "The musical's record-breaking run on Broadway earned multiple Tony awards.",
}

print("=" * 70)
print(f"  PART 1 -- Polysemy: the word '{target_word}' in three different contexts")
print("=" * 70)

for domain, sent in polysemy_sentences.items():
    print(f"\n  {domain.upper()}: {sent}")

print(f"""
  All three sentences contain the word '{target_word}' with completely
  different meanings. GloVe maps '{target_word}' to the same point in
  vector space every time. BERT reads the full sentence first, so its
  '{target_word}' vector shifts to reflect the actual meaning used.
""")

# GloVe: extract the "run" token from spaCy Doc (same vector every time)
glove_run = {}
for domain, sent in polysemy_sentences.items():
    for token in nlp(sent):
        if token.text.lower() == target_word:
            glove_run[domain] = token.vector
            break

# BERT: extract contextual embedding of "run" from each sentence
bert_run = {domain: bert_word_vector(sent, target_word)
            for domain, sent in polysemy_sentences.items()}

domains = list(polysemy_sentences.keys())

print(f"  Cosine similarity of '{target_word}' vectors between context pairs:")
print(f"  {'Context pair':<34}  GloVe   BERT")
print(f"  {'-'*34}  ------  ------")

for i, d1 in enumerate(domains):
    for j, d2 in enumerate(domains):
        if j <= i:
            continue
        g_sim = cos_sim([glove_run[d1]], [glove_run[d2]])[0][0]
        b_sim = cos_sim([bert_run[d1]],  [bert_run[d2]])[0][0]
        pair  = f"{d1} vs {d2}"
        note  = "<-- identical!" if g_sim > 0.99 else ""
        print(f"  {pair:<34}  {g_sim:.3f}   {b_sim:.3f}  {note}")

print("""
  GloVe: similarity = 1.000 for every pair. The vector is fixed at training
  time and carries no information about the sentence. Every document that
  contains "run" gets the SAME 300-dim contribution from that word.

  BERT: similarity is clearly below 1. Self-attention has shaped the vector
  differently for each context, encoding the meaning used in THAT sentence.
""")

# =============================================================================
# PART 2 — Classification: cross-domain vocabulary challenge
# =============================================================================
#
# Each article below uses prominent vocabulary from a DIFFERENT domain's
# training data. This is the real-world scenario that breaks TF-IDF and
# confuses static GloVe (because the word vectors were learned from the
# original domain and still pull toward it).
#
# BERT is expected to handle these better because it classifies the SENTENCE
# as a whole, not individual words in isolation.
#
# =============================================================================

print("=" * 70)
print("  PART 2 -- BEFORE vs AFTER: cross-domain vocabulary challenge")
print("=" * 70)
print("""
  Each article uses key words that belong to a DIFFERENT domain in the
  training data. TF-IDF is fooled by the surface words. Static GloVe is
  pulled by those words' learned vectors toward the wrong class. BERT reads
  the full sentence and classifies by the overall meaning, not individual
  word identities.
""")

# ---------------------------------------------------------------------------
# Example 1 — POLITICS article using SPORTS vocabulary
#
# "team", "scored", "victory", "defeat" are ALL strong sports signals in
# the training data. Here they are used as political metaphors:
#   team       = government/cabinet     (not a football team)
#   scored     = achieved/won           (not a goal)
#   victory    = political win          (not a match result)
#   defeat     = electoral loss         (not a game score)
#
# TF-IDF: sees "team" and "scored" from sports training → leans sports.
# GloVe:  sports word vectors pull the document mean toward sports space.
# BERT:   "prime minister" + "opposition" + "budget vote" establish a
#         political context; "team scored victory" is understood as a
#         metaphor, not a literal sporting event.
# ---------------------------------------------------------------------------

print("\n--- Example 1: Politics article using sports vocabulary as metaphor ---\n")
compare(
    article="The prime minister's team scored a decisive victory over the opposition in the budget vote.",
    true_label="politics",
    note="'team', 'scored', 'victory' are sports training words used politically",
)

# ---------------------------------------------------------------------------
# Example 2 — ENTERTAINMENT article using SPORTS and POLITICS vocabulary
#
# "arena"    → sports venue in common usage
# "record-breaking" → training: "broke the all-time scoring record" (sports)
# "campaign" → training: politics ("opposition party", "cabinet")
#
# TF-IDF: "record" pulls toward sports, "campaign" pulls toward politics.
# GloVe:  same cross-pull between domains — confused document vector.
# BERT:   "rapper" + "sold-out tour" + "global phenomenon" establish an
#         entertainment context; "arena tour" and "campaign" are understood
#         as entertainment/marketing terms, not sports or politics.
# ---------------------------------------------------------------------------

print("\n--- Example 2: Entertainment article using sports and political vocabulary ---\n")
compare(
    article="The rapper's sold-out arena tour was a record-breaking campaign that became a global phenomenon.",
    true_label="entertainment",
    note="'arena', 'record-breaking', 'campaign' all have sports/politics training associations",
)

# ---------------------------------------------------------------------------
# Example 3 — SPORTS article with NO overlap with training vocabulary at all
#
# Every content word in this sentence is absent from the TF-IDF training
# vocabulary. It first appeared in demo 02 where BOTH TF-IDF and GloVe
# returned the wrong class (entertainment=0.43) because:
#
#   TF-IDF: "stadium", "roared", "home", "side", "equalised", "dying",
#           "minutes" — none of these appear in training → zero features
#           → falls back to the class prior → picks the wrong class.
#
#   GloVe:  "equalised" (British spelling) may have no GloVe vector, and
#           even with "stadium" pushing slightly toward sports, there is
#           insufficient sports signal to overcome the prior → still wrong.
#
#   BERT:   DistilBERT was pre-trained on billions of web documents and has
#           deep knowledge that "stadium" + "equalised" + "home side" +
#           "dying minutes" is unmistakably football. It does NOT need the
#           exact words to have appeared in our 28 training examples — it
#           transfers this knowledge from pre-training. The [CLS] vector
#           lands firmly in sports territory → correct.
#
# This is the core advantage of BERT over all previous approaches: the
# pre-trained representations carry world knowledge that zero-shots to
# new vocabulary instantly.
# ---------------------------------------------------------------------------

print("\n--- Example 3: Sports article with zero training-vocabulary overlap ---\n")
print("    (same article that BOTH TF-IDF and GloVe got wrong in demo 02)\n")
compare(
    article="The stadium roared as the home side equalised in the dying minutes.",
    true_label="sports",
    note="Every content word is out-of-vocabulary for TF-IDF; GloVe also had no signal (demo 02)",
)

# =============================================================================
# SUMMARY: The progression across all three demos
# =============================================================================

print("\n" + "=" * 70)
print("  Summary: the three-demo progression")
print("=" * 70)
print("""
  Demo 01 - TF-IDF + Naive Bayes
    Represents text as a sparse bag of word counts. Words not seen in
    training carry zero signal. No understanding of meaning whatsoever.
    Fast, interpretable, zero external dependencies.

  Demo 02 - Static GloVe mean + Logistic Regression
    Every word is a 300-dim point in semantic space. Unknown words can
    still contribute via their pre-trained vectors (synonymy solved).
    BUT every word has ONE fixed vector regardless of sentence context.
    "bank" (financial) and "bank" (river) produce the same vector.

  Demo 03 - DistilBERT [CLS] + Logistic Regression
    Each word gets a DIFFERENT vector depending on the full sentence.
    Polysemy is resolved: "run for president" vs "run down the flank"
    produce different "run" vectors. The [CLS] vector captures the
    whole-sentence meaning as a single 768-dim point.
    Trade-off: ~268 MB model, GPU-accelerated inference for production.

  What BERT still does NOT solve perfectly:
    - Very small labelled datasets (28 examples is extremely few; a
      production system needs 500-5000 to fully exploit BERT's capacity).
    - Tasks requiring knowledge beyond the training corpus cutoff.
    - Extremely long documents (max 512 tokens per sequence).
    - These remaining gaps are where Large Language Models and RAG enter.
""")
