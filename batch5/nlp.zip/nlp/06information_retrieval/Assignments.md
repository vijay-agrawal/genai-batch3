03_...

Yes — everything is in-memory only. Nothing is saved to disk. Here's the full flow:

Step 1 — NumPy array in RAM (line 373)


embeddings = model.encode(texts, ...)   # returns a numpy float32 array
                                         # shape: (30 docs × 384 dims)
embeddings is just a Python variable holding a NumPy array in RAM.

Step 2 — Copied into FAISS index in RAM (lines 386, 393)


flat_index.add(embeddings)   # FAISS copies the vectors into its own internal memory
ivf_index.add(embeddings)    # same — both indices live in RAM
FAISS takes ownership of those vectors inside its C++ memory structure. The original embeddings numpy array and the FAISS index are two separate copies in RAM.

When the script exits, both are gone.

In production you would persist them to disk, e.g.:


# Save
np.save("embeddings.npy", embeddings)
faiss.write_index(flat_index, "flat.index")

# Load later — no re-encoding needed
embeddings = np.load("embeddings.npy")
flat_index = faiss.read_index("flat.index")
That is the actual "encode documents once offline" pattern — this demo simulates it but skips the persistence step since the corpus is only 30 documents.