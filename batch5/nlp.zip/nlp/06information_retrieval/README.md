# Encoding Architectures in Information Retrieval

## The Problem: Finding the Right Document

You have a large collection of text and a user who has a question. The task is to **find the text that best answers it** — without reading every piece of text at query time.

In these demos the collection is 30 clinical document snippets: discharge summaries, drug monographs, lab reports, and treatment protocols covering diabetes, cardiology, oncology, and more. A **document** is simply any discrete unit of text that can be stored and retrieved — it could be a paragraph, a full article, a database row, a patient note, a PDF page, or a single sentence. The only requirement is that each document can be given a relevance score for a given query.

```
Query: "heart attack emergency treatment"
                    │
              [retrieval system]
                    │
         #1  Acute Myocardial Infarction — STEMI Protocol      score 0.91
         #2  Cardiac Biomarkers in Chest Pain Evaluation        score 0.74
         #3  Venous Thromboembolism Treatment                   score 0.41
         …
```

Another example from the demos — a query in plain lay language:

```
Query: "clot in the lung blood thinner"
                    │
              [retrieval system]
                    │
         #1  Venous Thromboembolism Treatment          ← "clot" = DVT/PE
         #2  CT Pulmonary Angiography for PE Diagnosis ← "lung" context
         #3  Atrial Fibrillation Anticoagulation       ← "blood thinner" = anticoagulant
```

**Retrieval vs Generation — a critical distinction:**
Retrieval **finds** existing text from a fixed collection and returns it ranked by relevance. It does not create new content. Generation (what a large language model does) **writes** new text in response to a prompt — it synthesises, summarises, and reasons, but it has no access to your private corpus unless you first retrieve the relevant documents and pass them in. In a RAG (Retrieval-Augmented Generation) pipeline, retrieval always comes first; generation comes second and uses what retrieval found.

---
## Demo Files in This Folder

| File | Method | Key Concept |
|------|--------|-------------|
| [01_tfidf_demo.py](01_tfidf_demo.py) | TF-IDF | Sparse vectors, term statistics, vocabulary mismatch |
| [02_bm25_demo.py](02_bm25_demo.py) | BM25 | TF saturation, length normalization, k1/b tuning |
| [03_dense_ann_demo.py](03_dense_ann_demo.py) | Bi-Encoder + FAISS ANN | Dense embeddings, approximate nearest neighbor, semantic search |
| [clinical_trial_reranker_demo.py](clinical_trial_reranker_demo.py) | Cross-Encoder Reranker | Two-stage pipeline, nDCG evaluation |
| [clinical_trial_search_ndcg.py](clinical_trial_search_ndcg.py) | TF-IDF + nDCG | Evaluation metrics for ranked retrieval |

---

## Techniques Demonstrated

**TF-IDF** ([01_tfidf_demo.py](01_tfidf_demo.py)) — A classical sparse retrieval method that scores documents by how frequently a term appears in a document (TF) weighted against how rare it is across the corpus (IDF). Simple and fast, but limited by vocabulary mismatch: it cannot match "heart attack" to "myocardial infarction."

**BM25** ([02_bm25_demo.py](02_bm25_demo.py)) — An improved sparse ranking function that adds TF saturation (repeated terms give diminishing returns) and document length normalization on top of IDF weighting. It remains the industry standard for first-stage keyword retrieval in production search systems.

**Bi-Encoder + FAISS ANN** ([03_dense_ann_demo.py](03_dense_ann_demo.py)) — A neural dense retrieval approach where queries and documents are encoded independently into dense vectors using a transformer, and similarity is computed via approximate nearest neighbor search. Handles semantic synonyms and paraphrase that keyword methods miss entirely.

---

## 1. Encode / Encoding

**Encoding** is the process of converting raw input (text, images, audio) into a fixed-size numerical vector that a machine learning model can work with.

```
"metformin reduces HbA1c"  →  [0.12, -0.87, 0.43, ..., 0.09]
                                        768 numbers
```

The resulting vector is called an **embedding**. Points that are close together in this high-dimensional space are considered semantically similar.

**Why it matters in IR:** Once a document is encoded into a vector, you can find similar documents by comparing vectors — no keyword overlap required. "Heart attack" and "myocardial infarction" can embed near each other even though they share zero words.

---

## 2. Autoencoder

**What does "auto" mean?**  
"Auto" means *self*. The network is trained using the input as its own label — it learns to reproduce its own input without any human-provided labels. That is why it is called *self*-supervised.

An autoencoder is a neural network trained to **compress** input into a smaller representation and then **reconstruct** it back to the original.

```
Input → Encoder (includes bottleneck) → Latent Vector (Embedding) → Decoder → Output
```

More specifically

```
Input (high-dim)  →  Encoder  →  Bottleneck  →  Decoder  →  Reconstructed Input
   "discharge          [dense     (latent          [dense        "discharge
    summary"           layers]     vector)          layers]       summary" (approx)
```


So:

👉 Encoder = all layers up to and including the bottleneck
👉 Latent vector = output of the final encoder layer (smallest dimension)


The bottleneck forces the network to learn the most important features — it cannot memorize, it must generalize.

| Part | Role |
|------|------|
| **Encoder** | Compresses input → latent vector |
| **Bottleneck** | A layer with far fewer neurons than the input — the narrow point that forces compression |
| **Latent vector** | The numerical output of the bottleneck layer — this *is* the embedding |
| **Decoder** | Reconstructs input from the latent vector |

**Is the latent vector the same as an embedding?**  
Yes. The latent vector *is* an embedding — a compressed numerical representation of the input. "Latent" emphasizes that it captures hidden structure in the data. "Embedding" is the broader term used whenever input is mapped to a dense vector, regardless of how that mapping was trained. All latent vectors are embeddings, but not all embeddings come from autoencoders.

**What is the bottleneck technically?**  
It is simply a layer (or a pair of layers) where the number of neurons is much smaller than the input dimension — e.g., 3 neurons for a 784-pixel image. It is not a special layer type; the "bottleneck" is an architectural constraint. Any information that cannot fit through those few neurons is discarded, which forces the encoder to keep only the most essential features.

**Training signal:** Reconstruction error — how different is the output from the input? No labeled data needed (self-supervised).

**Healthcare uses:**
- Anomaly detection in lab results (normal patient profiles → low reconstruction error; abnormal → high error)
- Dimensionality reduction for EHR data with hundreds of lab features
- De-noising clinical notes with typos or OCR errors

**Limitation for IR:** Autoencoders are trained to reconstruct, not to make semantically similar inputs produce similar vectors. They are rarely used directly for retrieval. Bi-encoders (below) are trained specifically for that purpose.

---

## 2a. Popular Autoencoder Models

| Category | Model | Key Idea |
|---|---|---|
| **Classic** | Vanilla Autoencoder | Basic encoder-bottleneck-decoder MLP |
| **Classic** | Sparse Autoencoder (SAE) | Adds L1 penalty to force sparse activations in the bottleneck |
| **Classic** | Denoising Autoencoder (DAE) | Trained to reconstruct from a corrupted version of the input |
| **Variational** | VAE (Kingma & Welling, 2013) | Learns a latent *distribution* (μ, σ) instead of a point vector — enables generative sampling |
| **Variational** | β-VAE | Stronger disentanglement by upweighting the KL term in the loss |
| **Variational** | VQ-VAE (Vector Quantized) | Discrete latent space; used in image and audio generation |
| **Transformer-based** | BERT | MLM training is autoencoder-flavoured (reconstruct masked tokens) but has no explicit decoder |
| **Transformer-based** | BART | Explicit encoder-decoder; trained to reconstruct corrupted text; used for summarisation and translation |
| **Transformer-based** | T5 | Text-to-text encoder-decoder; same spirit as BART |
| **Transformer-based** | MAE (Masked Autoencoder) | Vision transformer trained to reconstruct masked image patches (He et al., 2021) |
| **Diffusion-adjacent** | Stable Diffusion VAE | Compresses images to a latent space; diffusion happens in that latent space, not pixel space |

**Practical guide by use case:**

| Use Case | Go-To Model |
|---|---|
| NLP embeddings | BERT-style MLM pretraining |
| Text generation / summarisation | BART, T5 |
| Image compression / generation | VAE, VQ-VAE |
| Vision pretraining (self-supervised) | MAE |
| Anomaly detection in tabular / clinical data | Denoising Autoencoder |

---

## 2b. Are Bi-Encoder Models Trained Using Autoencoders?

**No** — bi-encoder models are not trained using autoencoder mechanisms. Here is what actually trains them:

**Stage 1 — BERT pretraining (autoencoder-flavoured, but not a true autoencoder)**

| Pretraining Task | What it does | Autoencoder connection |
|---|---|---|
| **Masked Language Modeling (MLM)** | Randomly mask 15% of tokens; predict them back | Superficially similar (corrupt → reconstruct), but there is no bottleneck and no separate decoder architecture |
| **Next Sentence Prediction (NSP)** | Predict whether two sentences are consecutive | Unrelated to autoencoders |

MLM is a *cloze-style* self-supervised task. The model fills in gaps using bidirectional context, not by compressing through a narrow bottleneck.

**Stage 2 — Sentence-transformer fine-tuning (contrastive learning)**

This is the step that makes the model useful for retrieval. A pretrained BERT is fine-tuned with contrastive losses using (query, positive document, negative document) triplets:

| Loss | What it does |
|---|---|
| **Triplet Loss** | Pull anchor closer to positive, push it away from negative |
| **Multiple Negatives Ranking Loss** | Treat every other positive in the batch as a negative (in-batch negatives) |
| **InfoNCE / NT-Xent** | Maximise the probability that the positive ranks above all negatives |

**Key distinction from autoencoders:**

| | Autoencoder | Bi-Encoder Training |
|---|---|---|
| **Goal** | Reconstruct input | Align similar pairs, separate dissimilar ones |
| **Decoder needed?** | Yes | No |
| **Supervision** | Self-supervised (reconstruction error) | Self / weakly supervised (similarity pairs) |
| **Output used for** | Bottleneck features or generation | Direct vector similarity search |

The embedding vector in a bi-encoder is not a bottleneck — it is a *similarity-optimised* representation trained to be directly comparable across queries and documents.

---

## 3. Bi-Encoder

A bi-encoder uses **two independent encoding passes** — one for the query, one for the document — and computes similarity between the resulting vectors.

```
Query: "heart attack treatment"          Document: "STEMI PCI aspirin protocol"
           │                                              │
    ┌──────▼──────┐                              ┌───────▼──────┐
    │  Transformer │                              │  Transformer  │
    │   Encoder    │  ← same weights being trained │   Encoder     │
    └──────┬──────┘                              └───────┬──────┘
           │                                             │
       q_vector                                      d_vector
    [0.2, 0.8, ...]                               [0.3, 0.7, ...]
           │                                             │
           └──────────── cosine_similarity ──────────────┘
                                0.87  ← relevance score
```

**Key property: documents can be encoded offline.**  
Encode all 10 million clinical notes once, store the vectors. At query time, only encode the query (milliseconds), then search the pre-built vector index.

**Training:** Contrastive learning — explained in detail in the next section.

**Healthcare examples:**
- Semantic search over PubMed abstracts
- Patient-facing symptom → clinical guideline matching
- Similar-patient retrieval from EHR database

**Tradeoffs:**

| | |
|---|---|
| ✅ Fast at query time (ANN search, ~1ms for millions of docs) | |
| ✅ Documents pre-indexed offline | |
| ✅ Handles synonyms and paraphrase | |
| ❌ No interaction between query and document tokens during encoding | |
| ❌ Misses fine-grained relevance signals (exact negation, numeric values) | |
| ❌ Requires domain fine-tuning for medical jargon | |

---

## 3a. Contrastive Learning (how bi-encoders are trained)

Contrastive learning teaches a model what *similar* and *dissimilar* mean by showing it pairs of examples and telling it which are close and which are far — without ever defining the content of those concepts explicitly.

**The core idea:** instead of predicting a label ("this is a cardiology document"), the model is trained to predict *relationships* ("these two texts are about the same thing; those two are not").

### The Training Setup

You need a dataset of triplets:

```
Anchor (query)          Positive (relevant)         Negative (irrelevant)
─────────────────────   ──────────────────────────  ──────────────────────────
"metformin HbA1c"   →   "Metformin reduces blood    "Aspirin antiplatelet
                         glucose in type 2 DM"       therapy in STEMI"
```

All three are encoded into vectors. The loss function then:
- **Pulls** the anchor and positive vectors closer together
- **Pushes** the anchor and negative vectors further apart

```
Before training:                    After training:

  anchor ●                            anchor ●──── positive ●
                                              (close)
  positive ●   negative ●
                                      negative ●
                                              (far)
```

### The Loss Function: InfoNCE / NT-Xent (Noise-Contrastive Estimation)

The most common contrastive loss in modern sentence transformers:

```
Loss = − log(  exp(sim(anchor, positive) / τ)
               ─────────────────────────────────────────────────
               exp(sim(anchor, positive) / τ) + Σ exp(sim(anchor, negativeᵢ) / τ)  )
```

- `sim` = cosine similarity between two vectors
- `τ` (tau) = temperature — controls how sharply the model distinguishes hard vs easy negatives  
- The denominator sums over all negatives in the batch (in-batch negatives)

In plain English: *maximize the probability that the positive ranks above all negatives.*

### Hard Negatives vs Easy Negatives

| Type | Example in healthcare | Effect on training |
|---|---|---|
| **Easy negative** | Query "insulin dosing" vs doc "colonoscopy prep" | Model already separates these; minimal learning signal |
| **Hard negative** | Query "insulin dosing in CKD" vs doc "insulin dosing in T2DM" | Similar-looking but subtly different — forces the model to learn fine distinctions |

Hard negatives are critical for building high-quality medical embeddings. A general model trained on web text uses easy negatives; Clinical-BERT and BioLORD are trained with hard negatives mined from medical ontologies (e.g., UMLS synonyms vs near-synonyms).

### Why Not Just Use Labeled Data?

| Approach | Data needed | What you get |
|---|---|---|
| Supervised classification | (text, label) pairs | Categories — not comparable across docs |
| Contrastive learning | (anchor, positive, negative) triplets | A *metric space* — distances mean something |

Contrastive learning produces vectors where distance is meaningful. You can rank any two documents by similarity without retraining. This is what makes the bi-encoder output useful for retrieval.

### In-Batch Negatives (the efficiency trick)

Training with true triplets is expensive. In practice, within a batch of N (query, positive) pairs, every *other* positive in the batch is treated as a negative for the current query. This gives N−1 negatives for free per training step and is why large batch sizes dramatically improve contrastive learning quality.

---

## 4. Cross-Encoder

A cross-encoder feeds the **query and document together as a single input** and uses full attention across all tokens of both.

```
Input:  [CLS] heart attack treatment [SEP] STEMI PCI aspirin protocol [SEP]
               ↑ query tokens                ↑ document tokens
                        │
               ┌────────▼────────┐
               │   Transformer   │
               │  (full joint    │
               │   attention)    │
               └────────┬────────┘
                        │
                  relevance score
                      0.94
```

Every query token can attend to every document token. This is far more expressive than comparing independent vectors, but it means you **cannot pre-compute document representations** — the document must be re-encoded for every new query.

**Training:** Trained on (query, document, label) pairs with binary or graded relevance labels.

**Healthcare examples:**
- Reranking a shortlist of 100 candidate clinical trials for a patient
- Medical question answering: scoring candidate answers from retrieved passages
- Clinical decision support: ranking differential diagnoses by evidence quality

**Tradeoffs:**

| | |
|---|---|
| ✅ Highest retrieval quality — full cross-attention between query and doc | |
| ✅ Handles negation, co-reference, and subtle relevance signals | |
| ❌ Cannot pre-index — must run at query time for every (query, doc) pair | |
| ❌ ~100× slower than bi-encoder at scale | |
| ❌ Impractical for first-stage retrieval over large corpora | |

---

## 5. BM25 (Best Match 25)

BM25 is a **sparse keyword-based ranking function** — the industry standard for first-stage retrieval in search engines. It does not use neural networks or embeddings. Instead, it scores documents by counting and weighting term occurrences.

```
BM25(term, doc) = IDF(term)  ×  TF(term, doc) × (k1 + 1)
                               ─────────────────────────────────────────
                               TF(term, doc) + k1 × (1 − b + b × |doc|/avgdl)
```

**The two key improvements over plain TF-IDF:**

| Mechanism | What it does | Why it matters in clinical text |
|---|---|---|
| **TF saturation** (k1) | Term frequency contribution levels off after a few occurrences | A discharge summary mentioning "hypertension" 20× (boilerplate template) should not outrank a focused note mentioning it twice in a diagnostic context |
| **Length normalization** (b) | Penalizes long documents relative to corpus average | A 5,000-word operative note and a 200-word lab result should compete fairly |

**Where the "25" comes from:** BM25 is the 25th iteration of the *Best Match* series of probabilistic retrieval models developed at Okapi/City University London in the 1990s. The number has no special mathematical meaning.

**Why it appears alongside bi-encoders:** BM25 excels at exact term matching (drug names, ICD codes, lab values); bi-encoders excel at semantic synonyms. They fail on different queries, so combining them in Stage 1 captures more relevant documents than either alone.

---

## Comparison Table

| | Autoencoder | Bi-Encoder | Cross-Encoder |
|---|---|---|---|
| **Input** | Single item | Query OR document (separate) | Query + Document (joint) |
| **Output** | Reconstructed input | Dense vector | Relevance score |
| **Training signal** | Reconstruction error | Contrastive (similar/dissimilar pairs) | Labeled relevance pairs |
| **Pre-indexable** | Yes (encoder half) | Yes ✅ | No ❌ |
| **Query-time speed** | Fast | Fast (~1ms with ANN) | Slow (~100ms per doc) |
| **Retrieval quality** | Not designed for IR | Good | Best |
| **Use in IR pipeline** | Feature extraction / anomaly detection | **Stage 1: Retrieve** | **Stage 2: Rerank** |

---

## The Two-Stage IR Pipeline (How They Work Together)

The standard production architecture combines bi-encoder speed with cross-encoder quality:

```
User Query
    │
    ▼
┌─────────────────────────────────────────┐
│  STAGE 1 — RETRIEVAL (recall-focused)   │
│                                         │
│  BM25 (sparse)  +  Bi-Encoder (dense)  │
│         └──────────┬──────────┘         │
│               Fused Top-100             │
│  (milliseconds, runs over full corpus)  │
└─────────────────────┬───────────────────┘
                      │ 100 candidates
                      ▼
┌─────────────────────────────────────────┐
│  STAGE 2 — RERANKING (precision-focused)│
│                                         │
│         Cross-Encoder Reranker          │
│  (runs on shortlist only — practical)   │
└─────────────────────┬───────────────────┘
                      │ Top-10 results
                      ▼
                Final Results
```

**Why BM25 + Bi-Encoder in Stage 1?**  
BM25 is strong on exact medical terms and drug names. Bi-encoder is strong on semantic synonyms and paraphrase. Their errors are complementary — combining them catches more relevant documents than either alone.

---

## Evaluation Metrics

**Evaluation metrics** (Precision@k, Recall@k, MAP, MRR, nDCG, etc.) are retrieval-agnostic. They take a ranked list of document IDs and compare it against relevance judgments. They have no knowledge of *how* those documents were retrieved — whether by keyword matching, semantic embeddings, or a human expert writing a list by hand. The same metric formulas benchmark TF-IDF, BM25, bi-encoders, cross-encoders, and LLM-based retrievers equally. That is precisely what makes them useful.

| Type | Examples | How matching works |
|---|---|---|
| **Keyword-based (sparse)** | TF-IDF, BM25 | Exact term overlap — "heart attack" only matches documents containing those words |
| **Semantic (dense)** | Bi-encoder + FAISS, cross-encoder | Embedding similarity — "heart attack" can match documents about "myocardial infarction" or "STEMI" |

The standard workflow in IR research is: swap out the retrieval system (sparse → dense → hybrid), keep the metrics unchanged, compare the numbers. A dense model retrieves a document about "STEMI" for the query "heart attack treatment" even though neither word appears verbatim — and nDCG rewards it for doing so, because the relevance judgment says that document is relevant.

The demos in this folder follow exactly this pattern: `retriever_evals.py` evaluates TF-IDF, BM25, and a mock dense system using the same metric implementations throughout.

**Why ROUGE, BLEU, and BERTScore are not used here:**

These metrics were designed for *generation* tasks (translation, summarisation) where the system produces a text output that can be compared word-by-word against a reference text. They are the wrong tool for retrieval:

| Metric | Designed for | Why it breaks for retrieval |
|---|---|---|
| **BLEU** | Machine translation | Measures n-gram overlap between a generated sentence and reference sentences. A retrieved document is not a "sentence" — it is a ranked document ID. There is nothing to diff character-by-character against a query. |
| **ROUGE** | Summarisation | Same problem: compares word overlap between a generated summary and a reference summary. Retrieval returns a ranked list, not a generated string. |
| **BERTScore** | Text generation quality | Computes token-level semantic similarity between a generated output and a reference string. Again assumes the system *wrote* something. It cannot express "did the right document appear in position 1 vs position 5?" |

The core mismatch: generation metrics ask *"how close is what the system wrote to the correct answer?"* Retrieval metrics ask *"did the relevant documents appear near the top of the ranked list?"* Rank position matters in retrieval — returning the right document at rank 10 is worse than at rank 1, and no generation metric captures that.

---


