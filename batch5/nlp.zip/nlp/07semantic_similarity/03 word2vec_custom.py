# Demo: Training Word2Vec from scratch (Skip-gram) on a custom corpus
#
# This illustrates how corpus size affects embedding quality:
#   - Part 1: tiny corpus (4 sentences) — embeddings are nearly meaningless because
#             Word2Vec has almost no co-occurrence signal to learn from.
#   - Part 2: artificially enlarged corpus (same sentences repeated 100x, more epochs)
#             — shows that quantity and repetition improve vector geometry, though
#             real diversity is far more valuable than simple repetition.
#
# NOTE: This is NOT fine-tuning a pretrained model. Word2Vec vectors are initialized
# randomly and trained entirely from the provided sentences. There is no pretrained
# knowledge here — unlike loading Google's word2vec-google-news-300 or similar.
# Meaningful embeddings typically require millions of sentences of diverse text.

from gensim.models import Word2Vec

# Sample corpus (tokenized sentences)
sentences = [
    ["the", "dog", "barks", "loudly", "at", "night"],
    ["the", "cat", "meows", "at", "dawn"],
    ["dogs", "and", "cats", "are", "common", "pets"],
    ["the", "king", "and", "queen", "rule", "the", "kingdom"]
]

# Train Word2Vec using Skip-gram
model = Word2Vec(sentences, vector_size=100, window=2, sg=1, min_count=1, workers=4, epochs=10)

# Get word embeddings
print("Vector for 'dog':", model.wv["dog"])

# Find similar words
print("Most similar words to 'dog':", model.wv.most_similar("dog"))


# Much larger corpus
sentences2 = [
    ["the", "dog", "barks", "loudly", "at", "night"],
    ["the", "dog", "barks", "at", "strangers"],
    ["my", "dog", "barks", "when", "excited"],
    ["dogs", "bark", "to", "communicate"],
    ["the", "cat", "meows", "at", "dawn"],
    ["cats", "meow", "for", "attention"],
    ["the", "cat", "meows", "softly"],
    ["dogs", "and", "cats", "are", "common", "pets"],
    ["dogs", "are", "loyal", "pets"],
    ["cats", "are", "independent", "pets"],
    ["the", "king", "and", "queen", "rule", "the", "kingdom"],
    ["the", "dog", "chases", "the", "cat"],
    ["dogs", "love", "to", "play", "fetch"],
    ["cats", "like", "to", "sleep"],
] * 100  # Repeat to simulate more data

# Train with more epochs
model2 = Word2Vec(sentences2, vector_size=100, window=2, sg=1, min_count=1, workers=4, epochs=50)

print("Most similar words to 'dog', with a larger corpus:", model2.wv.most_similar("dog", topn=5))