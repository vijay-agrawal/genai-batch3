# =============================================================================
# Latent Dirichlet Allocation (LDA) - Topic Modeling
# =============================================================================
#
# CONCEPT:
#   LDA is a generative probabilistic model that discovers hidden "topics"
#   within a collection of documents. It assumes each document is a mixture
#   of topics, and each topic is a mixture of words. For example, a news
#   article about Tesla could be 70% "technology" and 30% "economy".
#
# Note this technique is different than classification
# Classification techniques in the nlp/classification folder use labeled training data, 
# predict from predefined categories, and are explicitly designed to be compared against each other 
# as a step-by-step progression. 
# Why LDA is different:
# Unsupervised — no labels, no predefined categories. It discovers structure rather than learning to predict known classes.
# Generative / probabilistic — models how documents are produced, not how to discriminate between classes.
# Topic modeling, not classification — the output is probability distributions over latent topics, not a predicted label.
# Different toolchain — Gensim + corpora/BoW format, vs. sklearn pipelines throughout the classification series.

# HOW IT WORKS:
#   1. Each document is represented as a probability distribution over topics.
#   2. Each topic is represented as a probability distribution over words.
#   3. LDA works backwards — given observed words, it infers the latent topic
#      structure that most likely produced them, using Bayesian inference
#      (typically via Gibbs sampling or variational Bayes).
#
# KEY PARAMETERS:
#   - num_topics : How many topics to discover (set manually).
#   - passes     : Number of training passes over the corpus (more = better
#                  convergence, slower training).
#   - alpha      : Controls document-topic density (low = documents focus on
#                  fewer topics).
#   - eta (beta) : Controls topic-word density (low = topics focus on fewer
#                  words).
#
# TECHNOLOGY — Gensim:
#   This script uses the Gensim library, a Python NLP toolkit optimized for
#   topic modeling. Key Gensim components used here:
#   - corpora.Dictionary : Maps words to integer IDs.
#   - doc2bow            : Converts a document to Bag-of-Words (word ID, count)
#                          format required by LDA.
#   - LdaModel           : Trains the LDA model on the BoW corpus.
#
# STOPWORD REMOVAL (NLTK):
#   Common words like "the", "and", "is" carry no topical signal and are
#   removed before training. NLTK provides a standard English stopword list.
#   Removing them forces LDA to focus on semantically meaningful words.
#
# USE-CASE — News Article Topic Discovery:
#   This script applies LDA to a small set of news headlines spanning two
#   domains: technology (AI, Apple, Tesla) and economics (inflation, interest
#   rates, stock market). With num_topics=2, LDA is expected to separate these
#   themes automatically — without any labeling — demonstrating unsupervised
#   topic discovery. Results are visualized as word clouds, one per topic,
#   where word size reflects its probability weight within that topic.
#
# CAN LDA BE USED FOR NER (Named Entity Recognition)?
#   No — LDA cannot perform NER. NER and LDA solve fundamentally different problems:
#
#   NER asks: "Is the word 'Apple' in this sentence a company or a fruit?"
#     → Requires understanding word position, context, and entity type (PERSON,
#       ORG, LOCATION, etc.)
#
#   LDA asks: "Across this corpus, which words tend to appear together?"
#     → Has no awareness of individual words in context — it works on
#       document-level word frequency (Bag-of-Words), discarding word order
#       and sentence structure entirely.
#
#   LDA would tell you that "Apple" and "Tesla" co-occur in a technology topic,
#   but it cannot label them as organizations, distinguish them from the fruit
#   "apple", or identify where they appear in a sentence.
#
# WHAT ABOUT N-GRAMS — Does LDA gain word-order awareness?
#   Partially, but not enough for NER.
#
#   Gensim's Phrases model can detect frequent bigrams/trigrams and treat them
#   as single tokens before LDA training. For example:
#     "New York" → "New_York"   "interest rates" → "interest_rates"
#   This is done by training a Phrases model on the corpus, then applying it
#   to convert token lists before building the dictionary/corpus for LDA.
#
#   What n-grams ADD:
#   - Multi-word expressions are kept intact ("machine_learning", "New_York")
#   - Topics become more interpretable — "interest_rates" is clearer than
#     "interest" and "rates" appearing separately.
#   - Reduces ambiguity for common compound terms.
#
#   What n-grams DON'T fix:
#   - Word order is still discarded after n-gram detection. "New_York is
#     beautiful" and "beautiful New_York" produce the same BoW vector.
#   - No positional context within a sentence — LDA still sees a bag of tokens,
#     some of which happen to be multi-word.
#   - No entity type labeling — "New_York" becomes a topic feature, not a
#     LOCATION. "Apple" and "apple_pie" are still just co-occurrence signals.
#   - Cannot distinguish "Apple" (company) from "apple" (fruit) by context,
#     because sentence-level semantics are never modeled.
#
#   BOTTOM LINE: N-grams make LDA topics richer and more readable, but they
#   do not make LDA capable of NER. NER requires sentence-level positional
#   context and entity-type classification — things BoW fundamentally cannot
#   provide regardless of n-gram size.
#
# LDA vs. spaCy — Technology and Capability:
#
#   TECHNOLOGY:
#   ┌─────────────────┬────────────────────────────────────────────────────┐
#   │ LDA (Gensim)    │ spaCy                                              │
#   ├─────────────────┼────────────────────────────────────────────────────┤
#   │ Probabilistic   │ Neural network (CNN/transformer-based pipelines)   │
#   │ Bayesian model  │ Trained on annotated corpora (OntoNotes, etc.)     │
#   │ Bag-of-Words    │ Processes full sentences with token/positional ctx │
#   │ Unsupervised    │ Supervised (pre-trained or fine-tuned)             │
#   │ No word order   │ Full linguistic pipeline: tokenize → POS → NER    │
#   └─────────────────┴────────────────────────────────────────────────────┘
#
#   CAPABILITY:
#   ┌─────────────────────────────┬────────────┬────────────┐
#   │ Task                        │ LDA        │ spaCy      │
#   ├─────────────────────────────┼────────────┼────────────┤
#   │ Discover hidden topics      │ YES        │ No         │
#   │ Named Entity Recognition    │ No         │ YES        │
#   │ Part-of-speech tagging      │ No         │ YES        │
#   │ Sentence / word structure   │ No         │ YES        │
#   │ Unsupervised (no labels)    │ YES        │ No         │
#   │ Works on large corpus       │ YES        │ YES        │
#   │ Interpretable topics        │ YES        │ N/A        │
#   └─────────────────────────────┴────────────┴────────────┘
#
#   WHEN TO USE WHICH:
#   - Use LDA when you have a large collection of documents and want to
#     discover what themes exist without any labeled data.
#   - Use spaCy when you need to extract specific entities (people, orgs,
#     places, dates) from text, understand sentence grammar, or build an NLP
#     pipeline that needs linguistic structure.
#   - They are complementary: you could use spaCy to extract entities first,
#     then run LDA on the remaining content words to find themes.
#
# LDA vs. TF-IDF:
#   Both are Bag-of-Words techniques — neither models word order or sentence
#   structure. But they serve very different purposes.
#
#   TF-IDF (Term Frequency–Inverse Document Frequency):
#     - Scores how important a word is to a specific document relative to the
#       whole corpus. A word that appears often in one doc but rarely elsewhere
#       gets a high score.
#     - Output: a high-dimensional sparse vector per document (one dimension
#       per vocabulary word). The vector space can have tens of thousands of
#       dimensions for a real corpus.
#     - No latent structure — it does not group words into themes or reduce
#       dimensionality conceptually. It just re-weights raw counts.
#     - Primary uses: keyword extraction, document retrieval/search (cosine
#       similarity between TF-IDF vectors), and as input features to a
#       downstream classifier (e.g. logistic regression on TF-IDF vectors).
#
#   LDA:
#     - Discovers latent topics — groups of words that co-occur across
#       documents — and represents each document as a low-dimensional mixture
#       of those topics (e.g. 70% tech, 30% economics).
#     - Output: a short probability vector per document (length = num_topics,
#       typically 10–200), plus a word distribution per topic.
#     - Reduces dimensionality semantically — "AI", "machine_learning", and
#       "neural_network" collapse into one "tech" topic dimension.
#     - Primary uses: exploratory analysis, corpus summarization, content
#       recommendation, and surfacing hidden themes with no labeled data.
#
#   COMPARISON:
#   ┌──────────────────────────────┬─────────────────────┬──────────────────────┐
#   │ Aspect                       │ TF-IDF              │ LDA                  │
#   ├──────────────────────────────┼─────────────────────┼──────────────────────┤
#   │ Technique                    │ Statistical weighting│ Probabilistic model  │
#   │ Output per document          │ Sparse word vector  │ Topic distribution   │
#   │ Output dimensionality        │ Vocabulary size (hi)│ num_topics (low)     │
#   │ Finds latent themes          │ No                  │ YES                  │
#   │ Keyword importance           │ YES                 │ No (topic words only)│
#   │ Unsupervised                 │ YES                 │ YES                  │
#   │ Used as classifier input     │ YES (common)        │ Sometimes            │
#   │ Document retrieval / search  │ YES (core use case) │ No                   │
#   │ Interpretable themes         │ No                  │ YES                  │
#   │ Word order aware             │ No                  │ No                   │
#   └──────────────────────────────┴─────────────────────┴──────────────────────┘
#
#   WHEN TO USE WHICH:
#   - Use TF-IDF when you need to find the most distinctive keywords in a
#     document, build a search/retrieval system, or create features for a
#     supervised classifier.
#   - Use LDA when you want to understand what broad themes run through a
#     corpus without any labels — exploration and summarization at scale.
#   - They are complementary: TF-IDF filtering (dropping very common or very
#     rare words) can be applied before LDA to improve topic quality.
# =============================================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
from gensim import corpora
from gensim.models import LdaModel
from wordcloud import WordCloud

# Download NLTK stopwords (if running for the first time)
nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

# Sample documents
documents = [
    "Apple releases a new iPhone while Tesla launches an electric car.",
    "The stock market is seeing a downturn due to inflation concerns.",
    "Tesla and other automakers are focusing on electric vehicles.",
    "Technology companies like Apple and Google are investing in AI.",
    "The economy is affected by rising interest rates and inflation.",
    "AI is transforming the way companies operate and innovate.",
    "New government policies impact the automobile industry.",
    "Machine learning and AI are the future of technology."
]

# Preprocessing: Tokenization + Lowercasing + Stopword Removal
texts = [
    [word.lower() for word in doc.split() if word.lower() not in stop_words]
    for doc in documents
]

# Create a dictionary and corpus
dictionary = corpora.Dictionary(texts)
corpus = [dictionary.doc2bow(text) for text in texts]

# Train LDA model (2 topics for demonstration)
lda_model = LdaModel(corpus, num_topics=2, id2word=dictionary, passes=10, random_state=42)

# Extract topics
topics = lda_model.print_topics(num_words=5)
topics_df = pd.DataFrame({"Topic": [f"Topic {i+1}" for i in range(len(topics))], 
                          "Words": [topic[1] for topic in topics]})

# Display extracted topics
print("\nExtracted Topics:")
print(topics_df)

# Generate word clouds for topics
fig, axes = plt.subplots(1, 2, figsize=(12, 6))
for i, topic in enumerate(lda_model.show_topics(num_topics=2, num_words=10, formatted=False)):
    topic_words = dict(topic[1])
    wordcloud = WordCloud(width=400, height=400, background_color='white').generate_from_frequencies(topic_words)
    axes[i].imshow(wordcloud, interpolation='bilinear')
    axes[i].set_title(f"Topic {i+1}")
    axes[i].axis("off")

plt.show()

# =============================================================================
# DOES LDA HAVE "WEIGHTS" THAT GET TRAINED?
# =============================================================================
# LDA does not have weights in the neural-network sense (no gradient descent,
# no backpropagation). Instead, it learns two sets of probability distributions:
#
#   φ (phi) — Topic-word distributions
#     For each topic, a probability distribution over every word in the
#     vocabulary. e.g. Topic 1 might assign: P("AI")=0.15, P("Tesla")=0.12 …
#     Shape: (num_topics × vocabulary_size)
#     This is the closest analogue to "weights" — it encodes what each topic
#     means in terms of words.
#
#   θ (theta) — Document-topic distributions
#     For each training document, a probability distribution over topics.
#     e.g. Doc 3 might be: P(Topic1)=0.72, P(Topic2)=0.28
#     Shape: (num_documents × num_topics)
#     These are discarded after training; only φ is saved in the model file.
#
# Training algorithm (Variational Bayes in Gensim's default):
#   LDA starts with random φ and θ, then iterates (for `passes` epochs):
#     E-step: given current φ, estimate the best θ for every document.
#     M-step: given the updated θ, re-estimate φ to maximise the corpus
#             likelihood.
#   This continues until the distributions stop changing significantly.
#   Dirichlet priors (alpha, eta) act as regularisers — they bias the model
#   toward sparse distributions (few dominant topics per doc / few dominant
#   words per topic) without hard constraints.
#
# So yes — LDA is "trained", but its parameters are probability tables, not
# real-valued weight matrices. There is no activation function, no loss
# gradient. The model is entirely defined by φ once training is complete.
#
# =============================================================================
# HOW DOES LDA HANDLE OUT-OF-VOCABULARY (OOV) WORDS?
# =============================================================================
# The training Dictionary maps every seen word to an integer ID. Any word that
# was NOT in the training corpus has no ID — it is simply absent from the
# vocabulary.
#
# At inference time, dictionary.doc2bow(new_tokens) silently drops all tokens
# with no ID. They do not appear in the BoW vector at all. The model then
# infers a topic distribution using only the vocabulary words that *did* match.
#
# Consequences:
#   - No error is raised, and no special <UNK> token is inserted.
#   - If a new document consists mostly of OOV words (very different domain),
#     the BoW vector will be sparse/empty and the returned topic distribution
#     will fall back toward the model's prior (alpha) — essentially uniform
#     uncertainty rather than a confident assignment.
#   - Rare words pruned from the dictionary during training (via
#     dictionary.filter_extremes) are also treated as OOV at inference.
#
# This is a fundamental limitation of BoW models: there is no subword
# fallback (unlike BPE tokenisers in transformers) and no semantic
# interpolation via embeddings (unlike word2vec/GloVe). A word either exists
# in the dictionary or it contributes nothing.
#
# =============================================================================
# INFERENCE ON A NEW DOCUMENT
# =============================================================================
# Once the model is trained, you can pass any new document through it.
# The model returns a probability distribution over all topics — this tells
# you how much each topic contributes to the document.
# Only φ (the topic-word distributions learned during training) is used here;
# θ for the new document is inferred on the fly without updating the model.

new_doc = "Elon Musk's company is pushing boundaries in electric vehicles and AI."

# Preprocess the new document exactly like the training data
new_tokens = [word.lower() for word in new_doc.split() if word.lower() not in stop_words]

# Convert to BoW using the *training* dictionary (unknown words are silently ignored)
new_bow = dictionary.doc2bow(new_tokens)

# Infer topic distribution
topic_distribution = lda_model.get_document_topics(new_bow)

print("\nNew document:")
print(f"  \"{new_doc}\"")
print("\nTopic distribution:")
for topic_id, prob in sorted(topic_distribution, key=lambda x: -x[1]):
    top_words = lda_model.show_topic(topic_id, topn=5)
    top_words_str = ", ".join(word for word, _ in top_words)
    print(f"  Topic {topic_id + 1} ({prob:.1%}): {top_words_str}")

dominant_topic_id = max(topic_distribution, key=lambda x: x[1])[0]
print(f"\nDominant topic: Topic {dominant_topic_id + 1}")

# =============================================================================
# CAN LDA DETECT A NEW / UNSEEN TOPIC?
# =============================================================================
# No — LDA cannot discover new topics at inference time.
# The number of topics is fixed when you call LdaModel(..., num_topics=N).
# Every document — including ones from a completely different domain — is
# forced to be expressed as a mixture of those N existing topics.
#
# Example: this model was trained on tech and economics text with num_topics=2.
# Feed it a document about cooking recipes and it will still return two
# probabilities that sum to 1.0. It has no mechanism to say "neither".
#
# WHY? LDA's generative assumption is that every document was produced by
# sampling from the fixed topic set. It has no "reject" or "other" bucket.
# The Dirichlet prior ensures all topic probabilities are positive and sum
# to 1, so a confident assignment is always produced regardless of fit.
#
# =============================================================================
# DOES A PROBABILITY THRESHOLD HELP?
# =============================================================================
# Partially — a threshold is a useful *heuristic*, not a true solution.
#
# Idea: if the model is confident about a document, one topic will dominate
# with a high probability (e.g. 0.85). If the document doesn't fit any
# existing topic, the model is uncertain and probabilities will be spread
# more evenly (e.g. 0.55 / 0.45 for 2 topics).
#
# So you can flag a document as "uncertain / possible new topic" when:
#   max(topic_probabilities) < threshold
#
# Choosing a threshold:
#   - Too high (e.g. 0.9): many valid documents flagged as uncertain.
#   - Too low  (e.g. 0.5): off-topic documents slip through undetected.
#   - A value around 0.6–0.7 is a common starting point; tune on held-out data.
#
# IMPORTANT caveats:
#   1. get_document_topics() by default omits topics with probability < 0.01.
#      For a 2-topic model the two probabilities already sum to ~1, so this
#      barely matters. For a model with many topics (e.g. 20), unseen-domain
#      documents spread probability thinly across many topics — none exceeds
#      the threshold — making the heuristic more reliable.
#   2. OOV words make this worse: if most words are OOV, the BoW vector is
#      nearly empty and the model falls back to the alpha prior (near-uniform),
#      which looks identical to a genuine new topic. You can't tell whether
#      low confidence is due to a new topic or simply missing vocabulary.
#   3. This is NOT the same as training a dedicated "other" topic or using an
#      outlier-detection model. It is a post-hoc signal, not a learned boundary.
#
# Better alternatives when new-topic detection matters:
#   - Re-train LDA periodically on the expanded corpus (online LDA supports
#     this incrementally via lda_model.update()).
#   - Use a separate anomaly/outlier detector on the topic-distribution vector.
#   - Switch to a non-parametric model (HDP — Hierarchical Dirichlet Process)
#     which can grow the number of topics automatically as new data arrives.

# =============================================================================
# DEMO — THRESHOLD-BASED NEW TOPIC DETECTION
# =============================================================================

CONFIDENCE_THRESHOLD = 0.60  # flag documents whose best topic is below this

def infer_topic(doc, lda, dictionary, stop_words, threshold):
    tokens = [w.lower() for w in doc.split() if w.lower() not in stop_words]
    bow = dictionary.doc2bow(tokens)
    # minimum_probability=0 forces all topics to be returned, even near-zero
    # ones — important so the probabilities actually sum to 1 and the threshold
    # comparison is meaningful.
    dist = lda.get_document_topics(bow, minimum_probability=0)
    best_topic_id, best_prob = max(dist, key=lambda x: x[1])
    top_words = ", ".join(w for w, _ in lda.show_topic(best_topic_id, topn=5))
    uncertain = best_prob < threshold
    return best_topic_id, best_prob, top_words, uncertain

test_docs = [
    # fits training topics well
    ("KNOWN TOPIC",  "Rising inflation and interest rates are hurting the stock market."),
    ("KNOWN TOPIC",  "Apple and Google announce a new AI chip for mobile devices."),
    # completely outside training domain — should trigger uncertainty
    ("NEW TOPIC?",   "The chef prepared a delicious pasta with fresh tomatoes and basil."),
    ("NEW TOPIC?",   "The team scored three goals in the second half of the football match."),
]

print("\n--- Threshold-based new-topic detection (threshold={:.0%}) ---".format(CONFIDENCE_THRESHOLD))
for label, doc in test_docs:
    tid, prob, words, uncertain = infer_topic(doc, lda_model, dictionary, stop_words, CONFIDENCE_THRESHOLD)
    flag = "UNCERTAIN — possible new topic" if uncertain else f"Topic {tid + 1}"
    print(f"\n[{label}] \"{doc}\"")
    print(f"  Best topic prob : {prob:.1%}  →  {flag}")
    print(f"  Top topic words : {words}")
