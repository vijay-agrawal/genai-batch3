import spacy

# 1. Load an English NER model (you can also use a custom finance model)
#IMPORTANT: Make sure to run 'python -m spacy download en_core_web_sm' if not already done.
nlp = spacy.load("en_core_web_sm")

text = """
Bharat Dynamics Limited (BDL) — the moment of truth has struck! Today BDL surged ~2% after clinching a staggering ₹ 2,461.62 crore order from the Indian Army.
Investors are riding a wave of renewed confidence — as BDL’s order book balloons, the stock feels like a rocket primed for lift-off.
This deal doesn’t just push quarterly numbers — it signals strategic strength and long-term defence pedigree.
Market sentiment has flipped bullish overnight; scepticism fades as the order underlines government trust and order-flow visibility.
If momentum holds, BDL could rewrite expectations — and reward early believers handsomely.
"""

doc = nlp(text)

print("Named Entities:")
for ent in doc.ents:
    print(f"{ent.text:<35} {ent.label_}")


