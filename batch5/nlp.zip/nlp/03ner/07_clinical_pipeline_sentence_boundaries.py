# pip install spacy && python -m spacy download en_core_web_sm
#
# Demo: Sentence segmentation as context boundaries in clinical NLP
# Pipeline: Tokenization -> Sentence Segmentation -> NER
#
# Key insight: processing the full note at once finds all drug/dosage entities
# but loses clinical context (prescribed vs contraindicated vs as-needed).
# Sentence segmentation creates boundaries that preserve that context.
#
# Practical example of the key insight
# -------------------------------------
# Suppose the physician note contains two mentions of Penicillin:
#
#   "Patient is currently on Penicillin 500mg twice daily."   <- sentence A
#   "Patient is allergic to Penicillin — avoid prescribing."  <- sentence B
#
# Flat NER (whole note at once) sees:
#   Penicillin -> DRUG
#   Penicillin -> DRUG
#   500mg      -> DOSAGE
#   twice daily -> FREQ
#
# Both DRUG hits look identical — the model cannot tell that one is an active
# prescription and the other is a safety warning.  An automated system that
# blindly extracted "Penicillin = active drug" from this list could cause a
# life-threatening medication error.
#
# Sentence-level NER recovers the distinction:
#   Sentence A context = ONGOING        -> Penicillin 500mg, twice daily
#   Sentence B context = CONTRAINDICATED -> Penicillin (no dosage — it must not be given)
#
# The sentence boundary is the unit of clinical meaning.  Without it, NER
# produces a bag of entity labels with no way to act on them safely.

import spacy

nlp = spacy.load("en_core_web_sm")

# ---------------------------------------------------------------------------
# EntityRuler — rule-based NER component
# ---------------------------------------------------------------------------
# spaCy's NLP pipeline is a sequence of components: tokenizer -> tagger ->
# parser -> NER -> ... Each component annotates the Doc object in turn.
#
# The built-in NER (en_core_web_sm) was trained on general web text, so it
# recognises labels like ORG, PERSON, DATE, MONEY — but has no concept of
# DRUG, DOSAGE, or clinical frequency.
#
# EntityRuler fills that gap with hand-authored rules instead of ML training:
#   - A "rule" is a dict with a target label and a token pattern list.
#   - Each token in the pattern is matched by its attributes (LOWER, IS_DIGIT,
#     TEXT regex, POS, etc.).  All attributes in a token dict must match for
#     that token to be accepted.
#   - Patterns are matched left-to-right across the token sequence, so a
#     two-token pattern like [IS_DIGIT, "mg"] catches "500 mg" as one span.
#
# Placement — before="ner":
#   Inserting the ruler BEFORE the statistical NER means our clinical rules
#   run first.  Spans already labelled by the ruler are skipped by the NER,
#   so the NER cannot overwrite them.  (The alternative, placing it after,
#   would let the NER overwrite our rules unless overwrite_ents=True is set.)
#
# overwrite_ents=True:
#   If a token range was already tagged by an upstream component, the ruler
#   replaces it.  Here it's defensive — ensures no stale annotation blocks
#   our clinical labels.
# ---------------------------------------------------------------------------
ruler = nlp.add_pipe("entity_ruler", before="ner", config={"overwrite_ents": True})
ruler.add_patterns([
    # Each pattern is {"label": <entity type>, "pattern": [<token matchers>]}
    # LOWER matches the lowercased form, so "Metformin" / "METFORMIN" both hit.

    # ---- Known drugs ----
    {"label": "DRUG", "pattern": [{"LOWER": "metformin"}]},
    {"label": "DRUG", "pattern": [{"LOWER": "lisinopril"}]},
    {"label": "DRUG", "pattern": [{"LOWER": "penicillin"}]},
    {"label": "DRUG", "pattern": [{"LOWER": "aspirin"}]},
    {"label": "DRUG", "pattern": [{"LOWER": "ibuprofen"}]},
    {"label": "DRUG", "pattern": [{"LOWER": "atorvastatin"}]},

    # ---- Dosages ----
    # spaCy's tokenizer splits "500mg" into two tokens: ["500", "mg"].
    # A two-token pattern bridges that split: IS_DIGIT matches "500",
    # then LOWER matches "mg" — together they form one DOSAGE span.
    {"label": "DOSAGE", "pattern": [{"IS_DIGIT": True}, {"LOWER": "mg"}]},

    # ---- Frequency qualifiers ----
    # Multi-word expressions need one dict per token in the pattern list.
    # "twice daily" needs two dicts; "daily" alone needs one.
    {"label": "FREQ", "pattern": [{"LOWER": "twice"}, {"LOWER": "daily"}]},
    {"label": "FREQ", "pattern": [{"LOWER": "once"},  {"LOWER": "daily"}]},
    {"label": "FREQ", "pattern": [{"LOWER": "daily"}]},
    {"label": "FREQ", "pattern": [{"LOWER": "as"},    {"LOWER": "needed"}]},
])

# ---------------------------------------------------------------------------
# Physician note — one sentence per line so spaCy's sentence segmenter
# sees a clean sentence boundary after each period.
# ---------------------------------------------------------------------------
physician_note = (
    "Patient: John D., 68M. Chief complaint: chest pain and shortness of breath. "
    "Patient has a history of hypertension and Type 2 Diabetes. "
    "Currently on Metformin 500mg twice daily for diabetes management. "
    "Blood pressure remains elevated; initiating Lisinopril 10mg once daily. "
    "Patient reports allergic reaction to Penicillin 250mg in the past — avoid prescribing. "
    "EKG shows mild arrhythmia; adding Aspirin 81mg daily. "
    "Also started Atorvastatin 20mg daily for elevated LDL. "
    "If pain worsens, consider Ibuprofen 400mg as needed (use with caution given age)."
)

# ---------------------------------------------------------------------------
# Heuristic: map sentence keywords to a clinical context label
# ---------------------------------------------------------------------------
CONTEXT_KEYWORDS = {
    "PRESCRIBED":      ["initiating", "adding", "started", "prescribed"],
    "ONGOING":         ["currently on", "taking", "continues"],
    # CONTRAINDICATED — a drug is contraindicated when it must NOT be given to
    # a specific patient because it would cause harm.  The harm could be:
    #   - Allergy: patient's immune system reacts adversely (hives, anaphylaxis)
    #   - Drug interaction: the drug amplifies or blocks another the patient takes
    #   - Condition conflict: the drug worsens an existing disease
    #     (e.g., aspirin is contraindicated in active stomach ulcers)
    # In the note below, Penicillin is contraindicated because the patient had
    # an allergic reaction to it in the past — giving it again risks anaphylaxis.
    # Detecting this label correctly is safety-critical: a system that mistakes
    # a contraindicated drug for an active prescription could trigger a fatal order.
    "CONTRAINDICATED": ["allergic", "avoid", "reaction", "contraindicated"],
    "CONDITIONAL":     ["if", "consider", "as needed", "may", "when"],
}

def classify_sentence_context(text: str) -> str:
    lower = text.lower()
    for ctx, keywords in CONTEXT_KEYWORDS.items():
        if any(kw in lower for kw in keywords):
            return ctx
        
    # NOTE: this heuristic above is very simple and has many limitations — 
    # it serves only to illustrate the value of sentence boundaries for context recovery. 
    #  In a production system, a more robust approach would be needed to handle the complexities
    #  of clinical language.
    
    # LIMITATION 1 — first-match wins, not best-match.
    # The loop returns as soon as any keyword hits, so a sentence that contains
    # signals for two contexts (e.g. "currently on aspirin, but avoid ibuprofen")
    # gets whichever context appears first in CONTEXT_KEYWORDS — silently wrong.
    # Enhancement: score every context (count keyword hits), then pick the
    # highest scorer, or use a multi-label classifier that can return all
    # applicable contexts for a sentence.

    # LIMITATION 2 — no negation handling.
    # "not prescribed", "never started", "denies taking" all contain PRESCRIBED /
    # ONGOING keywords and will be mis-classified.
    # Enhancement: run negspaCy (pip install negspacy) before this function.
    # negspaCy attaches a ._.negex flag to each entity; check that flag and
    # invert the context label when the governing verb is negated.

    # LIMITATION 3 — substring match misses paraphrases and synonyms.
    # "commence", "begin", "initiate" mean the same as "start" but won't match.
    # Enhancement: expand the keyword lists with a medical synonym lexicon
    # (e.g. UMLS), or replace keyword matching entirely with a sentence
    # embedding similarity check against prototypical phrases per context.

    # LIMITATION 4 — no syntactic scope — keywords anywhere in the sentence fire.
    # "avoid prescribing aspirin to patients allergic to ibuprofen" tags the
    # sentence as CONTRAINDICATED, but the drug in focus (aspirin) is actually
    # being discussed as something to avoid, while ibuprofen is the allergy.
    # Enhancement: use spaCy's dependency parse to find the verb that governs
    # the drug token (doc[drug_token].head), then classify based on that verb
    # and its modifiers rather than scanning the whole sentence.

    # LIMITATION 5 — ignores document structure (sections).
    # Clinical notes are divided into labelled sections: "Allergies:",
    # "Current Medications:", "Assessment:", "Plan:".  A sentence in the
    # Allergies section is contraindicated by definition; one in Plan is
    # likely prescribed.  Keyword matching cannot exploit this.
    # Enhancement: add a section-detection pre-pass (regex on section headers)
    # and use the section label as a strong prior before inspecting keywords.
    return "INFORMATIONAL"

CLINICAL = {"DRUG", "DOSAGE", "FREQ"}

# ---------------------------------------------------------------------------
# STEP 1 — Tokenization
# ---------------------------------------------------------------------------
print("=" * 70)
print("STEP 1: TOKENIZATION")
print("=" * 70)
doc = nlp(physician_note)
for sent in list(doc.sents)[:2]:
    tokens = [t.text for t in sent if not t.is_space]
    print(f"\nSentence : {sent.text.strip()}")
    print(f"Tokens ({len(tokens)}): {tokens}")

# ---------------------------------------------------------------------------
# STEP 2 — Sentence Segmentation
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
print("STEP 2: SENTENCE SEGMENTATION")
print("=" * 70)
sentences = list(doc.sents)
print(f"\nPhysician note split into {len(sentences)} sentences:\n")
for i, sent in enumerate(sentences, 1):
    print(f"  [{i}] {sent.text.strip()}")

# ---------------------------------------------------------------------------
# STEP 3a — NER on the whole note (no sentence boundaries)
#            Entities found, but clinical context is lost.
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
print("STEP 3a: NER — whole note (no sentence boundaries)")
print("         Problem: entities found, but clinical context is lost")
print("=" * 70)
ents_flat = [(e.text, e.label_) for e in doc.ents if e.label_ in CLINICAL]
print(f"\n  {'Entity':<22} {'Label'}")
print("  " + "-" * 35)
for text, label in ents_flat:
    print(f"  {text:<22} {label}")
print()
print("  --> Cannot distinguish which drugs are prescribed, contraindicated,")
print("      or conditional — every entity looks identical in the flat list.")

# ---------------------------------------------------------------------------
# STEP 3b — NER sentence by sentence (with context boundaries)
#            Each sentence is a context unit; clinical intent is recoverable.
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
print("STEP 3b: NER — sentence by sentence (with context boundaries)")
print("         Benefit: each sentence reveals clinical action")
print("=" * 70)

results = []
for sent in doc.sents:
    sent_doc = nlp(sent.text.strip())
    ents = [(e.text, e.label_) for e in sent_doc.ents if e.label_ in CLINICAL]
    if not ents:
        continue
    ctx = classify_sentence_context(sent.text)
    results.append((sent.text.strip(), ctx, ents))

for sent_text, ctx, ents in results:
    drugs   = [t for t, l in ents if l == "DRUG"]
    dosages = [t for t, l in ents if l == "DOSAGE"]
    freqs   = [t for t, l in ents if l == "FREQ"]
    print(f"\n  Sentence : {sent_text}")
    print(f"  Context  : [{ctx}]")
    if drugs:   print(f"  Drug(s)  : {drugs}")
    if dosages: print(f"  Dosage(s): {dosages}")
    if freqs:   print(f"  Frequency: {freqs}")

# ---------------------------------------------------------------------------
# STEP 4 — Structured medication list derived from sentence-level NER
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
print("STEP 4: STRUCTURED OUTPUT — medication list with clinical context")
print("=" * 70)
print(f"\n  {'Drug':<16} {'Dosage':<10} {'Frequency':<14} Context")
print("  " + "-" * 58)
for _, ctx, ents in results:
    drugs   = [t for t, l in ents if l == "DRUG"]
    dosages = [t for t, l in ents if l == "DOSAGE"]
    freqs   = [t for t, l in ents if l == "FREQ"]
    for drug in drugs:
        dosage = dosages[0] if dosages else "—"
        freq   = freqs[0]   if freqs   else "—"
        print(f"  {drug:<16} {dosage:<10} {freq:<14} {ctx}")

print()
print("  --> Sentence boundaries turned a flat entity list into a structured,")
print("      context-aware medication record ready for downstream processing.")
