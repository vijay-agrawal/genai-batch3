from transformers import pipeline, AutoTokenizer, AutoModelForTokenClassification

# d4data/biomedical-ner-all is a DistilBERT model fine-tuned on the MACCROBAT
# biomedical dataset. It recognizes 44 clinical entity types (Disease_disorder,
# Medication, Sign_symptom, Diagnostic_procedure, Lab_value, etc.) out of the box —
# no custom training required.
#
# Unlike a generic model that would mislabel 'Citius' as TECH_COMPANY,
# a domain-specific model correctly understands healthcare entity boundaries.

# Label mapping: collapses fine-grained model labels into 4 clinical categories
LABEL_MAP = {
    "Disease_disorder":       "PROBLEM",
    "Sign_symptom":           "PROBLEM",
    "Medication":             "DRUG",
    "Therapeutic_procedure":  "TREATMENT",
    "Diagnostic_procedure":   "TEST",
    "Lab_value":              "TEST",
}

_tokenizer = AutoTokenizer.from_pretrained("d4data/biomedical-ner-all")
_model = AutoModelForTokenClassification.from_pretrained("d4data/biomedical-ner-all")

# aggregation_strategy="simple" controls how multi-token entities are merged.
# The pipeline internally works at the subword (WordPiece) token level:
#
#   Step 1 — Forward pass:
#       The model produces a logit vector of shape [num_labels] for every token.
#
#   Step 2 — Softmax → per-token probabilities:
#       softmax(logits) converts raw scores to probabilities that sum to 1.
#       The predicted label for each token is argmax of that distribution.
#       The score for that token = softmax(logits)[predicted_label_index],
#       i.e. how confident the model is that THIS label is correct for THIS token.
#
#   Step 3 — BIO tag grouping (aggregation_strategy="simple"):
#       Consecutive B- / I- tokens belonging to the same entity type are merged
#       into a single span. The span's final score is the AVERAGE of the
#       per-token softmax scores across all tokens in the span.
#       e.g. "Type" (0.97) + "2" (0.91) + "Diabetes" (0.95) → score ≈ 0.94
#
#   A score close to 1.0 means the model is very confident; near 0.5 means
#   it was almost a coin-flip between two labels.
_ner = pipeline("ner", model=_model, tokenizer=_tokenizer, aggregation_strategy="simple")


def extract_medical_entities(text):
    """
    Extract medical entities from clinical text using a pre-trained NER model.

    Args:
        text (str): The clinical note text

    Returns:
        dict: Dictionary of extracted entities by type (PROBLEM, TREATMENT, DRUG, TEST)
    """
    results = _ner(text)

    entities = {"PROBLEM": [], "TREATMENT": [], "DRUG": [], "TEST": []}

    for entity in results:
        entity_type = LABEL_MAP.get(entity.get('entity_group'))
        entity_text = entity.get('word').strip()
        if entity_type:
            entities[entity_type].append(entity_text)

    return entities


def generate_structured_summary(entities):
    """
    Generate a structured summary from the extracted entities.

    Args:
        entities (dict): Dictionary of categorized entities

    Returns:
        str: A structured summary
    """
    structured_text = ""
    if entities["PROBLEM"]:
        structured_text += f"Problems: {', '.join(entities['PROBLEM'])}. "
    if entities["TREATMENT"]:
        structured_text += f"Treatments: {', '.join(entities['TREATMENT'])}. "
    if entities["DRUG"]:
        structured_text += f"Drugs: {', '.join(entities['DRUG'])}. "
    if entities["TEST"]:
        structured_text += f"Tests: {', '.join(entities['TEST'])}. "
    return structured_text


if __name__ == "__main__":
    # --- Demo 1: Raw entity labels on a healthcare company text ---
    # Shows that the model correctly identifies clinical entities and does NOT
    # mislabel 'Citius' (a healthcare company) as a tech company.
    citius_text = (
        "Citius Pharmaceuticals is developing Mino-Lok to treat catheter-related "
        "bloodstream infections. The drug showed efficacy against severe bacterial "
        "infections in clinical trials, with patients reporting reduced fever and pain."
    )
    print("=== Raw Entity Labels (d4data/biomedical-ner-all) ===")
    for entity in _ner(citius_text):
        print(f"  {entity['word']!r:45s} -> {entity['entity_group']}  (score: {entity['score']:.2f})")

    # --- Demo 2: Structured extraction mapped to PROBLEM / DRUG / TREATMENT / TEST ---
    note = (
        "Patient is a 60-year-old with Type 2 Diabetes. Reports dizziness over "
        "the last 3 weeks. Prescribed Ibuprofen 200mg. Recommended diet modifications."
    )
    print("\n=== Structured Entity Extraction (Clinical Note) ===")
    entities = extract_medical_entities(note)
    for entity_type, items in entities.items():
        if items:
            print(f"{entity_type}: {', '.join(items)}")

    summary = generate_structured_summary(entities)
    print("\nStructured Summary:")
    print(summary)
