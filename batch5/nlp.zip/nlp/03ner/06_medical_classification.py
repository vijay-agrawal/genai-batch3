"""
Medical NER Demo using OpenMed-NER-PharmaDetect-PubMed-v2-109M

Model: https://huggingface.co/OpenMed/OpenMed-NER-PharmaDetect-PubMed-v2-109M
Task:  Chemical/Drug Named Entity Recognition in biomedical text
Tags:  B-CHEM / I-CHEM  (BIO tagging scheme)

The model identifies pharmaceutical/chemical entities (drugs, compounds,
active ingredients) mentioned in clinical and research text.
"""

from transformers import pipeline
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich import box
from rich.rule import Rule
from pathlib import Path

# ── Model ─────────────────────────────────────────────────────────────────────
MODEL_NAME = "OpenMed/OpenMed-NER-PharmaDetect-PubMed-v2-109M"

console = Console(force_terminal=True)

# ── Example texts ─────────────────────────────────────────────────────────────
EXAMPLES = [
    {
        "title": "Example 1 – Oncology Treatment Protocol",
        "text": (
            "A 58-year-old male patient diagnosed with non-small cell lung carcinoma "
            "was enrolled in a phase III clinical trial. The treatment regimen consisted "
            "of carboplatin combined with paclitaxel administered intravenously every "
            "three weeks. After four cycles, the patient developed grade 2 peripheral "
            "neuropathy, and the oncology team introduced bevacizumab as an adjunct "
            "antiangiogenic agent. Dexamethasone was prescribed pre-infusion to mitigate "
            "hypersensitivity reactions, while ondansetron was used for chemotherapy-induced "
            "nausea. The patient showed partial response after six months of therapy, "
            "prompting consideration of erlotinib as a maintenance option."
        ),
    },
    {
        "title": "Example 2 – Diabetes & Cardiovascular Comorbidity Management",
        "text": (
            "The patient, a 67-year-old woman with type 2 diabetes mellitus and "
            "hypertension, presented for routine follow-up. Her current medications "
            "included metformin 1000 mg twice daily for glycaemic control, along with "
            "empagliflozin, an SGLT-2 inhibitor with demonstrated cardiovascular benefits. "
            "Lisinopril was continued for blood pressure management and renal protection, "
            "while atorvastatin was prescribed to address dyslipidaemia. "
            "Due to persistent HbA1c elevation, semaglutide was initiated as a GLP-1 "
            "receptor agonist. The patient was also maintained on low-dose aspirin "
            "for secondary prevention of cardiovascular events, and clopidogrel had "
            "been prescribed following a prior coronary stent placement."
        ),
    },
]

# ── Highlight colours per label ────────────────────────────────────────────────
LABEL_STYLE = {
    "CHEM": "bold white on dark_blue",      # drugs / chemicals
}

HTML_LABEL_COLOR = {
    "CHEM": ("#d0e8ff", "#1a3a6e"),          # (bg, text)
}


# ── Pipeline ──────────────────────────────────────────────────────────────────
def load_pipeline() -> pipeline:
    console.print(f"\n[bold cyan]Loading model:[/] {MODEL_NAME}", end="  ")
    pipe = pipeline(
        task="token-classification",
        model=MODEL_NAME,
        aggregation_strategy="simple",
    )
    console.print("[bold green]OK[/]\n")
    return pipe


def merge_subwords(entities: list) -> list:
    """Merge consecutive BERT sub-word tokens (##xxx) into whole-word entities."""
    merged = []
    for ent in entities:
        word = ent["word"]
        if merged and word.startswith("##"):
            prev = merged[-1]
            prev["word"] += word[2:]          # strip ## and append
            prev["end"] = ent["end"]
            prev["score"] = (prev["score"] + ent["score"]) / 2
        else:
            merged.append(dict(ent))           # copy to avoid mutating pipeline output
    return merged


# ── Terminal visualisation ────────────────────────────────────────────────────
def highlight_text_terminal(text: str, entities: list) -> Text:
    """Return a Rich Text object with entity spans highlighted."""
    rich_text = Text()
    cursor = 0
    for ent in sorted(entities, key=lambda e: e["start"]):
        start, end = ent["start"], ent["end"]
        label = ent["entity_group"]
        style = LABEL_STYLE.get(label, "bold red")
        # plain text before this entity
        rich_text.append(text[cursor:start])
        # entity span
        rich_text.append(text[start:end], style=style)
        cursor = end
    rich_text.append(text[cursor:])
    return rich_text


def entities_table(entities: list) -> Table:
    table = Table(box=box.SIMPLE_HEAVY, show_header=True, header_style="bold magenta")
    table.add_column("#", style="dim", width=4)
    table.add_column("Entity", style="bold")
    table.add_column("Label", justify="center")
    table.add_column("Confidence", justify="right")
    table.add_column("Span", style="dim")

    for i, ent in enumerate(entities, 1):
        conf = ent["score"]
        conf_str = f"[green]{conf:.3f}[/]" if conf >= 0.90 else f"[yellow]{conf:.3f}[/]"
        table.add_row(
            str(i),
            ent["word"],
            f"[bold cyan]{ent['entity_group']}[/]",
            conf_str,
            f"{ent['start']}–{ent['end']}",
        )
    return table


# ── HTML visualisation ────────────────────────────────────────────────────────
HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Medical NER Demo – OpenMed PharmaDetect</title>
<style>
  body {{
    font-family: Georgia, serif;
    max-width: 900px;
    margin: 40px auto;
    background: #f7f9fc;
    color: #1a1a2e;
    line-height: 1.7;
  }}
  h1 {{ color: #0d3b66; border-bottom: 2px solid #0d3b66; padding-bottom: 8px; }}
  h2 {{ color: #1a3a6e; margin-top: 2em; }}
  .paragraph {{
    background: #fff;
    padding: 20px 24px;
    border-radius: 8px;
    box-shadow: 0 1px 4px rgba(0,0,0,.1);
    margin: 12px 0;
  }}
  .entity-CHEM {{
    background: #d0e8ff;
    color: #1a3a6e;
    border-radius: 4px;
    padding: 1px 5px;
    font-weight: 600;
    border: 1px solid #7ab8f5;
    cursor: default;
  }}
  .entity-CHEM::after {{
    content: " DRUG";
    font-size: 0.65em;
    vertical-align: super;
    color: #2a5aa0;
    font-weight: normal;
  }}
  table {{ border-collapse: collapse; width: 100%; margin-top: 12px; }}
  th {{ background: #0d3b66; color: #fff; padding: 8px 12px; text-align: left; }}
  td {{ padding: 6px 12px; border-bottom: 1px solid #dde; }}
  tr:hover {{ background: #eef4ff; }}
  .conf-high {{ color: #207a3f; font-weight: bold; }}
  .conf-low  {{ color: #a05a00; }}
  .legend {{ display: flex; gap: 16px; margin: 12px 0; flex-wrap: wrap; }}
  .legend-item {{ display: flex; align-items: center; gap: 6px; font-size: .9em; }}
  .legend-swatch {{ width: 16px; height: 16px; border-radius: 3px; }}
  .model-info {{ background: #e8f0fe; padding: 10px 16px; border-radius: 6px;
                 border-left: 4px solid #0d3b66; font-size: .9em; }}
</style>
</head>
<body>
<h1>Medical NER Demo</h1>
<div class="model-info">
  <strong>Model:</strong> {model}<br>
  <strong>Task:</strong> Chemical / Drug Named Entity Recognition in biomedical text<br>
  <strong>Entity type detected:</strong> <span class="entity-CHEM">DRUG / CHEM</span>
</div>

<div class="legend">
  <div class="legend-item">
    <div class="legend-swatch" style="background:#d0e8ff;border:1px solid #7ab8f5"></div>
    CHEM – Pharmaceutical / Chemical compound
  </div>
</div>

{examples}

</body>
</html>
"""

EXAMPLE_HTML_TEMPLATE = """\
<h2>{title}</h2>
<div class="paragraph">{highlighted}</div>
<table>
  <tr><th>#</th><th>Entity</th><th>Label</th><th>Confidence</th><th>Character span</th></tr>
  {rows}
</table>
"""


def highlight_text_html(text: str, entities: list) -> str:
    html = ""
    cursor = 0
    for ent in sorted(entities, key=lambda e: e["start"]):
        start, end = ent["start"], ent["end"]
        label = ent["entity_group"]
        html += text[cursor:start]
        html += f'<span class="entity-{label}" title="{label} | conf: {ent["score"]:.3f}">{text[start:end]}</span>'
        cursor = end
    html += text[cursor:]
    return html


def build_html(results: list) -> str:
    examples_html = ""
    for res in results:
        text = res["text"]
        entities = res["entities"]
        rows = ""
        for i, ent in enumerate(entities, 1):
            conf_class = "conf-high" if ent["score"] >= 0.90 else "conf-low"
            rows += (
                f'<tr><td>{i}</td>'
                f'<td>{ent["word"]}</td>'
                f'<td>{ent["entity_group"]}</td>'
                f'<td class="{conf_class}">{ent["score"]:.3f}</td>'
                f'<td>{ent["start"]}–{ent["end"]}</td></tr>\n  '
            )
        examples_html += EXAMPLE_HTML_TEMPLATE.format(
            title=res["title"],
            highlighted=highlight_text_html(text, entities),
            rows=rows,
        )
    return HTML_TEMPLATE.format(model=MODEL_NAME, examples=examples_html)


# ── Main ─────────────────────────────────────────────────────────────────────
def main():
    pipe = load_pipeline()
    results = []

    for ex in EXAMPLES:
        console.print(Rule(f"[bold]{ex['title']}[/bold]", style="blue"))

        entities = merge_subwords(pipe(ex["text"]))

        # ── terminal output ──
        console.print(Panel(
            highlight_text_terminal(ex["text"], entities),
            title="[bold]Annotated Text[/bold]",
            border_style="blue",
            padding=(1, 2),
        ))
        console.print(entities_table(entities))
        console.print(f"[dim]  {len(entities)} chemical/drug entities detected[/dim]\n")

        results.append({"title": ex["title"], "text": ex["text"], "entities": entities})

    # ── save HTML report ──
    out_path = Path(__file__).with_name("06_medical_ner_report.html")
    out_path.write_text(build_html(results), encoding="utf-8")
    console.print(Panel(
        f"[bold green]HTML report saved →[/] [underline]{out_path}[/underline]",
        border_style="green",
    ))


if __name__ == "__main__":
    main()
