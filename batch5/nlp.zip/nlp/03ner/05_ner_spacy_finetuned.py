import spacy
from spacy.training.example import Example
import random

# Load pre-trained English model
nlp = spacy.load("en_core_web_sm")

# Training data with new entity "TECH_COMPANY"
# Positive examples: known tech companies labeled as TECH_COMPANY
# Negative examples: non-tech companies with empty entities list,
# teaching the model that not every organization is a TECH_COMPANY
TRAIN_DATA = [
    ("OpenAI is developing new AI models.", {"entities": [(0, 6, "TECH_COMPANY")]}),
    ("Google and Microsoft are competing in AI.", {"entities": [(0, 6, "TECH_COMPANY"), (11, 20, "TECH_COMPANY")]}),
    ("Tesla is a leader in AI-powered robotics.", {"entities": [(0, 5, "TECH_COMPANY")]}),
    ("Apple is launching a new AI chip.", {"entities": [(0, 5, "TECH_COMPANY")]}),
    ("Meta is investing in the metaverse and AI.", {"entities": [(0, 4, "TECH_COMPANY")]}),
    # Negative examples: non-tech companies, including ones with the same
    # "X is investing in Y" sentence pattern used in the test, so the model
    # learns it's the ENTITY itself that matters — not just the sentence structure.
    ("Athena is investing in healthcare.", {"entities": []}),
    ("Pfizer is investing in new drug research.", {"entities": []}),
    ("Novartis is investing in cancer treatment.", {"entities": []}),
    ("UnitedHealth is investing in patient care.", {"entities": []}),
    ("Johnson & Johnson released a new vaccine.", {"entities": []}),
    ("Mayo Clinic provides world-class medical care.", {"entities": []}),
    ("Walmart is expanding its grocery delivery service.", {"entities": []}),
]

# Get the Named Entity Recognition (NER) pipeline
ner = nlp.get_pipe("ner")

# Add the new entity label
ner.add_label("TECH_COMPANY")

# Disable other pipeline components to only train NER
unaffected_pipes = [pipe for pipe in nlp.pipe_names if pipe != "ner"]

# Training the model
with nlp.disable_pipes(*unaffected_pipes):
    optimizer = nlp.resume_training()

    for _ in range(50):  # More epochs needed to build a strong decision boundary
        random.shuffle(TRAIN_DATA)
        for text, annotations in TRAIN_DATA:
            doc = nlp.make_doc(text)
            example = Example.from_dict(doc, annotations)
            nlp.update([example], drop=0.3)  # Dropout helps prevent overfitting

# Save the updated model (optional)
nlp.to_disk("custom_ner_model")

# Test the trained model
test_text = "OpenAI and Tesla are investing in generative AI. Citius is investing in healthcare"
doc = nlp(test_text)

print("Recognized Entities:")
print([(ent.text, ent.label_) for ent in doc.ents])

# Should detect "OpenAI" and "Tesla" as TECH_COMPANY
# Should NOT detect "Citius" as TECH_COMPANY,
# demonstrating the model learned to differentiate based on context and entity itself.

# Note that the initial demo was labeling Citius also as TECH_COMPANY,
# which was a sign of overfitting to the sentence pattern.
# With the added negative examples and more training epochs,
# the model should now correctly ignore Citius.
