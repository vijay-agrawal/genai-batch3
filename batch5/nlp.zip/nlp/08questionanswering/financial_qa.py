# =============================================================================
# Extractive Question Answering — Quarterly Financial Report (Indian Company)
# Model: deepset/roberta-base-squad2  (125M parameters, ~500 MB)
# =============================================================================
#
# WHY A DIFFERENT MODEL FROM medical_qa.py?
# ───────────────────────────────────────────
# medical_qa.py uses MiniLM (22M params) — ultra-compact, ideal for
# well-structured clinical notes with clear, short answer spans.
#
# This demo uses RoBERTa-base (125M params) — a stronger encoder that handles
# the denser, number-heavy language of financial disclosures better.
# Financial reports contain long, nested sentences like:
#   "Revenue from operations for Q3 FY2025 stood at ₹4,812 crore, an
#    increase of 17.8% year-on-year (YoY) and 4.1% quarter-on-quarter (QoQ)
#    in rupee terms."
# RoBERTa's larger hidden size (768 vs 384) and more attention heads (12 vs 12
# but with full 768-dim keys/values) give it more capacity to model the
# multiple clause boundaries and numerical comparisons in such sentences.
#
# REAL-WORLD USE CASE
# ────────────────────
# Retail investors and junior analysts receive quarterly earnings press
# releases, investor presentations, and conference-call transcripts often
# running to 10-20 pages. An AI QA system embedded in a brokerage app
# (like Zerodha Kite, Groww, or Bloomberg Terminal) lets users ask natural-
# language questions about the filing and get the exact figure — faster than
# CTRL+F and more precise than asking a generative chatbot that might
# hallucinate a number.
#
# =============================================================================
# ARCHITECTURE — RoBERTa (deepset/roberta-base-squad2)
# =============================================================================
#
# RoBERTa (Liu et al., Facebook AI, 2019) stands for
# "Robustly Optimized BERT Pretraining Approach".
#
# It is architecturally identical to BERT-base but pre-trained very differently:
#
#   BERT pre-training choices (2018):        RoBERTa corrections (2019):
#   ─────────────────────────────────        ───────────────────────────
#   Static masking (same mask each epoch)  → Dynamic masking (new mask each epoch)
#   Next Sentence Prediction (NSP) task    → NSP removed entirely (found harmful)
#   Trained for 1M steps on 16GB data      → Trained for 500K steps on 160GB data
#   Short sequences mixed in               → Full-length 512-token sequences only
#   Small batch size (256)                 → Large batch size (8,000)
#
#   Key finding: BERT was significantly UNDERTRAINED. With the same architecture
#   and more data/compute, BERT's design was already near-optimal. RoBERTa proved
#   that training decisions matter as much as architecture decisions.
#
# Architecture (identical to BERT-base):
#   • 12 Transformer encoder layers
#   • 768 hidden dimensions
#   • 12 attention heads  (head_dim = 64)
#   • ~125M parameters, ~500 MB on disk
#   • Byte-Pair Encoding (BPE) tokenizer with 50,265 vocab (vs BERT's WordPiece)
#     BPE handles rare financial terms, currency symbols (₹, €), and numeric
#     compounds like "QoQ" more gracefully than WordPiece.
#
# Fine-tuned on SQuAD 2.0:
#   SQuAD 2.0 F1  — RoBERTa-base: ~86   vs   BERT-base: ~79
#   The ~7-point F1 gain from RoBERTa's pre-training improvements translates
#   to noticeably fewer wrong span extractions on complex financial sentences.
#
# =============================================================================
# THE SPAN-PREDICTION MECHANISM (same principle as MiniLM, larger scale)
# =============================================================================
#
# Input packing:
#   <s> [question tokens] </s> </s> [context tokens] </s>
#   (RoBERTa uses <s>/<s> separators instead of BERT's [CLS]/[SEP])
#
# Forward pass:
#   All 512 (or fewer) tokens pass through 12 layers of self-attention.
#   Each of the 12 heads in each layer computes:
#       Attention(Q, K, V) = softmax( QK^T / sqrt(64) ) · V
#   so every token's representation is updated by attending to every other
#   token. By layer 12, each context token's hidden state h_i (768-dim)
#   encodes: "what this token means, given the question that was asked."
#
# QA head:
#   start_logit_i = W_start · h_i    (scalar)
#   end_logit_i   = W_end   · h_i    (scalar)
#   Answer = context[ argmax(start_logits) : argmax(end_logits) + 1 ]
#
# =============================================================================
# THE "INFERENCE-TIME REASONING" ILLUSION
# =============================================================================
#
# When you ask "What is the revised full-year revenue guidance?" and the model
# correctly returns "15.5%–16.5% in CC terms" — it appears to have:
#   1. Located the guidance section
#   2. Distinguished the old guidance from the revised one
#   3. Understood "CC terms" as the relevant qualification
#
# None of these steps involve symbolic reasoning. What actually happens:
#
#   During SQuAD 2.0 fine-tuning, the model processed ~130,000 examples.
#   Many examples followed patterns like:
#     Q: "What is the revised [metric]?"
#     Context: "management revised [metric] guidance upward to [X] (previously [Y])"
#     Answer: [X]
#   The model learned: when "revised" appears in the question, attend strongly
#   to "revised ... to [number/range]" structures in the context, and prefer
#   the span AFTER "to" over the span after "previously".
#
#   This heuristic generalises well to unseen financial reports because the
#   language of earnings disclosures is highly formulaic — guidance revisions,
#   YoY comparisons, and deal announcements follow near-identical sentence
#   templates across companies and quarters.
#
# Where it breaks down:
#   • Implicit arithmetic: "What was the QoQ margin improvement?"
#     The answer requires 24.3% - 23.9% = 40 bps — the model can only
#     return a span, not compute. It may return "40 bps" if that phrase
#     appears literally, but will fail if the subtraction isn't in the text.
#   • Comparative across multiple sections: "Which segment grew the fastest?"
#     requires ranking three growth figures — the model may latch onto
#     the first or most salient mention, not the maximum.
#   • Coreference over long distances: "What did she announce?" in a
#     context where "she" = "the CFO" from paragraph 1 and the announcement
#     is in paragraph 5 often fails.
#
# For these cases, retrieval-augmented generation (RAG) with a larger LLM
# as the reader — or a fine-tuned financial reasoning model — is required.
#
# =============================================================================

from transformers import pipeline

MODEL_ID = "deepset/roberta-base-squad2"

print("Loading RoBERTa-base QA model (125M params, ~500 MB) ...")
print("First run downloads the model. Subsequent runs use cache.\n")

qa = pipeline("question-answering", model=MODEL_ID, device=-1)

# =============================================================================
# QUARTERLY EARNINGS REPORT — KIRAN AUTOMOTIVE LIMITED
# Q2 FY2025 Results (fictional company, for educational purposes only)
# =============================================================================

FINANCIAL_CONTEXT = """
KIRAN AUTOMOTIVE LIMITED
Q2 FY2025 UNAUDITED FINANCIAL RESULTS
For the quarter and half-year ended September 30, 2024

Mumbai, October 22, 2024 — Kiran Automotive Limited (BSE: 500208,
NSE: KIRANAUTO), one of India's leading two-wheeler and three-wheeler
manufacturers, today reported its unaudited standalone and consolidated
financial results for the second quarter (Q2) of fiscal year 2025.

FINANCIAL PERFORMANCE — Q2 FY2025

Total revenue from operations was Rs. 11,847 crore in Q2 FY2025,
up 14.3% year-on-year from Rs. 10,364 crore in Q2 FY2024. On a
quarter-on-quarter basis, revenue grew 6.8% compared to Rs. 11,093 crore
in Q1 FY2025, driven by a strong festive season demand in September and
a sharp recovery in rural markets following above-normal monsoon rainfall.

EBITDA for Q2 FY2025 was Rs. 2,251 crore, with an EBITDA margin of 19.0%,
expanding 150 basis points year-on-year (Q2 FY2024: 17.5%) owing to lower
commodity costs, particularly aluminium and steel, and improved operating
leverage on higher volumes.

Profit Before Tax (PBT) stood at Rs. 2,108 crore. Profit After Tax (PAT)
was Rs. 1,587 crore, an increase of 22.7% year-on-year, resulting in
diluted Earnings Per Share (EPS) of Rs. 56.80 for the quarter
(Q2 FY2024: Rs. 46.30).

The Board of Directors declared an interim dividend of Rs. 120 per equity
share of face value Rs. 10 each for FY2025.

VOLUMES AND PRODUCT MIX

Total vehicle dispatches in Q2 FY2025 were 13.28 lakh units, up 11.2%
year-on-year. Two-wheeler dispatches grew 12.4% YoY to 12.41 lakh units,
with motorcycles outpacing scooters by a ratio of 60:40 in the domestic
market. The premium motorcycle segment (above Rs. 1.5 lakh) grew 31% YoY,
reflecting the premiumisation trend in urban demand. Three-wheeler
dispatches stood at 87,000 units, up 4.1% YoY, with commercial cargo
variants showing higher traction than passenger auto-rickshaws.

Exports accounted for 18.3% of total dispatches, with Africa and Southeast
Asia as the primary markets. International revenue grew 9.1% in rupee terms
and 6.3% in constant currency terms.

GUIDANCE AND OUTLOOK

Management upgraded FY2025 full-year volume guidance to 52-54 lakh units
from the earlier guidance of 49-51 lakh units, citing strong festive season
sell-through, a healthy product pipeline including three new electric vehicle
launches planned for H2 FY2025, and improving rural sentiment.

EBITDA margin guidance for the full year is maintained at 18.5%-19.5%.
The company expects Q3 FY2025 revenue growth of 10-12% year-on-year,
aided by the ongoing festive momentum and fleet renewal demand from
three-wheeler operators.

DEBT AND CAPITAL ALLOCATION

The company is net debt-free. Cash and cash equivalents on the balance
sheet stood at Rs. 9,140 crore as of September 30, 2024.
Capital expenditure guidance for FY2025 is Rs. 1,800 crore, primarily
directed at electric vehicle manufacturing lines at the new Pune facility
and R&D investment in battery management systems.

MANAGEMENT COMMENTARY

Managing Director Mr. Vikram Kiran said: "Q2 was our best quarter in
six years on both revenue and profitability. The festive cycle validated
our premiumisation strategy, and our EV pipeline positions us well for
the energy transition. With a net debt-free balance sheet and record
order backlog in the commercial three-wheeler segment, we enter H2 with
confidence."

CFO Ms. Deepa Nair said: "The 150 bps EBITDA margin expansion reflects
the structural benefit of lower commodity costs and disciplined cost
management. We expect margins to sustain in the 18.5%-19.5% band for
the full year. The interim dividend of Rs. 120 per share reflects our
commitment to returning capital while preserving flexibility for EV capex."
"""

# =============================================================================
# PRE-SET QUESTIONS — demonstrating span extraction on financial text
# =============================================================================

preset_questions = [
    "By what percentage did Profit After Tax increase year-on-year?",
    "What interim dividend was declared by the Board?",
    "What is the revised full-year volume guidance?",
]

print("=" * 70)
print("  FINANCIAL QA — Kiran Automotive Limited Q2 FY2025 Results")
print("=" * 70)
print()

for question in preset_questions:
    result = qa(question=question, context=FINANCIAL_CONTEXT)
    print(f"Q: {question}")
    print(f"A: {result['answer']}")
    print(f"   (confidence: {min(result['score'], 1.0):.2%})")
    print()

# =============================================================================
# INTERACTIVE MODE — ask your own question
# =============================================================================

print("-" * 70)
print("Try asking your own question about the earnings report above.")
print("Examples:")
print("  - What was the EBITDA margin in Q2 FY2025?")
print("  - How many vehicles were dispatched in Q2 FY2025?")
print("  - What is the company's cash position?")
print("  - What did the CFO say about margins?")
print("  - What is the capex guidance for FY2025?")
print("-" * 70)

while True:
    user_question = input("\nYour question (or press Enter to quit): ").strip()
    if not user_question:
        print("Exiting. Goodbye.")
        break
    result = qa(question=user_question, context=FINANCIAL_CONTEXT)
    print(f"A: {result['answer']}")
    print(f"   (confidence: {min(result['score'], 1.0):.2%})")

# =============================================================================
# MODEL COMPARISON SUMMARY
# =============================================================================
#
#                     MiniLM (medical_qa.py)    RoBERTa (this file)
#                     ─────────────────────────  ───────────────────
# Parameters          22M                        125M
# Disk size           ~88 MB                     ~500 MB
# Hidden dim          384                        768
# Encoder layers      6                          12
# SQuAD 2.0 F1        ~76                        ~86
# CPU inference       very fast (~0.1s/query)    fast (~0.3s/query)
# Best suited for     short, structured notes    dense financial prose
#
# When to use which:
#   • MiniLM for high-throughput, latency-sensitive apps (mobile, edge).
#   • RoBERTa-base for higher accuracy when the text has complex sentences,
#     numbers, or requires disambiguation of similar entities in the same doc.
#   • Neither is suitable for multi-document or multi-hop questions
#     ("Compare Q2 FY2025 margins to Q2 FY2024" requires two-step lookup).
#     For those tasks, consider Longformer, or a RAG pipeline with a small LLM.
#
# =============================================================================
