# =============================================================================
# Extractive Question Answering — Medical Patient Record
# Model: deepset/minilm-uncased-squad2  (22M parameters, ~88 MB)
# =============================================================================
#
# WHAT IS EXTRACTIVE QUESTION ANSWERING?
# ────────────────────────────────────────
# Unlike generative QA (where a model writes a new answer from scratch),
# extractive QA finds the exact span of text in a provided context that
# answers the question.
#
#   Input : question + context document
#   Output: a substring copied verbatim from the context
#
# This is directly useful for clinical and legal settings where you need
# the answer to be traceable back to a specific sentence in a source record.
#
# REAL-WORLD USE CASE
# ────────────────────
# Hospital information systems receive thousands of unstructured clinical
# notes, discharge summaries, and pathology reports daily. A clinician
# reviewing a patient's history before an emergency procedure may have only
# 60 seconds to find: "What anticoagulants is this patient currently on?"
# Extractive QA surfaces the exact sentence — no hallucination, no
# fabrication, full auditability.
#
# =============================================================================
# ARCHITECTURE — MiniLM (deepset/minilm-uncased-squad2)
# =============================================================================
#
# MiniLM (Wang et al., Microsoft, 2020) is a family of compact models
# distilled from large Transformer teachers using a technique called
# "deep self-attention distillation":
#
#   Instead of matching the teacher's output logits (standard KD), MiniLM
#   forces the student to reproduce the teacher's ATTENTION DISTRIBUTIONS
#   in the LAST transformer layer — specifically the query-key dot-product
#   matrices (the "self-attention relation").
#
#   Why attention matrices?
#   The final-layer attention heads encode the highest-level relational
#   reasoning the teacher has learned. Matching them forces the student
#   to learn WHAT the teacher attends to, not just WHAT it outputs.
#   This yields better knowledge transfer per parameter than logit matching.
#
# MiniLM-L6 architecture (used here):
#   • 6 Transformer encoder layers   (BERT-base has 12)
#   • 384 hidden dimensions           (BERT-base has 768)
#   • 12 attention heads
#   • 22M parameters, ~88 MB on disk  (BERT-base: 110M, ~440 MB)
#   • SQuAD 2.0 F1 score: ~76         (BERT-base: ~79)
#   • Inference speed: ~4-5× faster than BERT-base on CPU
#
# Fine-tuned on SQuAD 2.0:
#   The Stanford Question Answering Dataset v2 includes 100,000+ question-
#   context pairs where some questions are intentionally unanswerable. Fine-
#   tuning on SQuAD 2.0 teaches the model to also return a low confidence
#   score and refuse to answer when the context doesn't support an answer.
#
# =============================================================================
# HOW THE MODEL ANSWERS A QUESTION — THE MECHANICS
# =============================================================================
#
# Step 1 — Tokenisation and packing
#   The question and context are concatenated with special tokens:
#
#   [CLS] What anticoagulants is the patient on? [SEP]
#         The patient is on warfarin 5mg daily ... [SEP]
#   └──────────────── single input sequence ────────────────┘
#
#   Segment IDs mark which tokens belong to the question (0) vs context (1).
#   This tells the model the two roles even though they share one sequence.
#
# Step 2 — Bidirectional self-attention across the full sequence
#   Every token can attend to every other token — question tokens attend to
#   context tokens AND context tokens attend to question tokens simultaneously
#   in every layer. This is what allows the model to "match" question intent
#   against context evidence without any explicit retrieval step.
#
#   Example: For "What anticoagulants is the patient on?",
#   the word "anticoagulants" in the question will develop high attention
#   weights toward "warfarin", "heparin", "aspirin" etc. in the context,
#   because during SQuAD fine-tuning the model learned these co-occurrences.
#
# Step 3 — QA output head (two linear layers)
#   On top of the last Transformer layer sits a thin linear head with 2×H
#   weights, projecting each hidden state h_i (dim=384) to two scalar logits:
#
#       start_logit_i = W_start · h_i
#       end_logit_i   = W_end   · h_i
#
#   After softmax over all context token positions:
#
#       start_prob = softmax(start_logits)   ← probability that token i starts the answer
#       end_prob   = softmax(end_logits)     ← probability that token i ends the answer
#
#   Best answer span = tokens[ argmax(start_prob) : argmax(end_prob) + 1 ]
#   Score (confidence) = start_prob[best_start] × end_prob[best_end]
#
# =============================================================================
# WHAT THIS IS NOT — "INFERENCE-TIME REASONING"
# =============================================================================
#
# When you ask "What procedure was performed on Day 2?" and the model returns
# "percutaneous coronary intervention (PCI)" — it can LOOK like reasoning.
# Here is what is actually happening:
#
#   ✗ The model does NOT read the text, understand time, and reason:
#     "Day 2 → scan for procedures → PCI is a procedure → return PCI."
#
#   ✓ What actually happens is learned statistical pattern matching:
#     During SQuAD fine-tuning the model saw tens of thousands of examples
#     like:
#       Q: "What was done on [date]?"
#       Context: "On [date], the surgeon performed [X]."
#       Answer span: "[X]"
#     It learned that "What ... on Day N" questions are typically answered
#     by a noun phrase following "performed", "administered", or "underwent"
#     that appears near the temporal reference "Day N" in the context.
#     At inference it applies this learned heuristic — no true causal
#     reasoning, no medical ontology lookup, no logical inference chain.
#
# Why does this matter practically?
#   • Questions phrased very differently from the training distribution
#     may fool the model (it returns a wrong span confidently).
#   • The model has no medical knowledge — it cannot catch a logically
#     impossible answer (e.g., a drug contradicted by an allergy in the notes).
#   • Confidence scores (start × end probability) are imperfectly calibrated
#     but are the best signal for "should a human review this answer?"
#
# =============================================================================

from transformers import pipeline

MODEL_ID = "deepset/minilm-uncased-squad2"

print("Loading MiniLM QA model (22M params, ~88 MB) ...")
print("First run downloads the model. Subsequent runs use cache.\n")

qa = pipeline("question-answering", model=MODEL_ID, device=-1)

# =============================================================================
# PATIENT RECORD — Sunita Bose (fictional, for educational purposes only)
# =============================================================================

MEDICAL_CONTEXT = """
PATIENT ADMISSION AND DISCHARGE RECORD

Patient Name   : Sunita Bose
Age / Sex      : 58 years / Female
MRN            : KH-2024-04471
Ward           : Cardiac ICU, Bed 7
Admitting Unit : Department of Cardiology, Kalpana Hospital, Kolkata
Attending Physician: Dr. Arjun Ghosh, MD (Cardiology), DM

ADMISSION (Day 1 — 14 November 2024):
The patient presented to the emergency department at 03:15 AM with acute
crushing chest pain radiating to the left arm, associated with profuse
sweating and shortness of breath of two-hour duration. She has a known history
of Type 2 Diabetes Mellitus (on Metformin 1000mg twice daily) and
hypertension (on Amlodipine 5mg once daily). She is a non-smoker and has
no prior cardiac history. Her family history is significant for coronary
artery disease in her father, who died of a heart attack at age 65.

On examination: BP 156/94 mmHg, HR 112 bpm (irregular), SpO2 92% on room air.
ECG showed ST-segment elevation in leads II, III, and aVF, consistent with
an inferior ST-Elevation Myocardial Infarction (STEMI). Troponin I was
markedly elevated at 4.8 ng/mL (normal < 0.04). The patient was immediately
loaded with Aspirin 325mg, Ticagrelor 180mg, and Heparin 5000 units IV bolus.
The catheterisation laboratory (cath lab) was activated.

HOSPITAL STAY (Day 2 — 15 November 2024):
Emergency coronary angiography revealed a 95% occlusion of the Right Coronary
Artery (RCA). The patient underwent percutaneous coronary intervention (PCI)
with deployment of a drug-eluting stent in the mid-RCA. Post-procedure TIMI 3
flow was restored and the procedure was completed without complications.
The patient was shifted to the Cardiac ICU for monitoring. Echocardiography
performed in the afternoon showed an ejection fraction (EF) of 48%, with
inferior wall hypokinesia. She was started on Atorvastatin 80mg once daily
and Ramipril 2.5mg once daily in addition to dual antiplatelet therapy.

HOSPITAL STAY (Day 3 — 16 November 2024):
The patient remained haemodynamically stable. Chest pain had completely
resolved. Repeat ECG showed evolving inferior Q-waves with no new changes.
Repeat troponin trended down to 1.2 ng/mL. Fasting blood glucose was 184
mg/dL; her Metformin was withheld for 48 hours post-contrast (standard
protocol) and insulin sliding scale was initiated. Cardiac rehabilitation
nursing counselling was provided regarding dietary modification, physical
activity, and smoking avoidance. She was transferred from the CICU to the
general cardiology ward.

HOSPITAL STAY (Day 4 — 17 November 2024):
The patient was ambulating independently in the corridor without symptoms.
Repeat echocardiography showed mild improvement in inferior wall motion.
Dietary consultation was completed. The diabetes team reviewed and
recommended resuming Metformin at 500mg twice daily on Day 6 post-contrast
with dose uptitration at the 6-week follow-up visit.

DISCHARGE (Day 5 — 18 November 2024):
The patient was discharged in stable condition after five days of
hospitalisation. The total length of stay was five days.

DISCHARGE MEDICATIONS:
1. Aspirin 75mg once daily (lifelong, antiplatelet)
2. Ticagrelor 90mg twice daily (for 12 months, dual antiplatelet)
3. Atorvastatin 80mg once daily (lifelong, statin)
4. Ramipril 5mg once daily (ACE inhibitor, cardiac remodelling)
5. Amlodipine 5mg once daily (continue, antihypertensive)
6. Metformin 500mg twice daily (resume from Day 6 post-discharge)
7. Pantoprazole 40mg once daily (gastroprotection with dual antiplatelet)

FOLLOW-UP INSTRUCTIONS:
The patient is advised to attend the outpatient cardiology clinic in 4 weeks
for clinical review and repeat echocardiography. She should present
immediately to any emergency department if she experiences recurrent chest
pain, palpitations, or syncope. The stent requires dual antiplatelet therapy
(Aspirin + Ticagrelor) for a minimum of 12 months; she must not discontinue
these without cardiology advice even if she requires a surgical procedure.

PRIMARY DIAGNOSIS   : Inferior ST-Elevation Myocardial Infarction (STEMI)
SECONDARY DIAGNOSES : Type 2 Diabetes Mellitus, Essential Hypertension
PROCEDURE           : Emergency PCI with drug-eluting stent, Right Coronary Artery
"""

# =============================================================================
# PRE-SET QUESTIONS — demonstrating span extraction on clinical text
# =============================================================================

preset_questions = [
    "What diagnosis was confirmed by the ECG findings?",
    "What procedure was performed on Day 2?",
    "What statin was prescribed at discharge?",
]

print("=" * 70)
print("  MEDICAL QA — Patient Record: Sunita Bose")
print("=" * 70)
print()

for question in preset_questions:
    result = qa(question=question, context=MEDICAL_CONTEXT)
    print(f"Q: {question}")
    print(f"A: {result['answer']}")
    print(f"   (confidence: {min(result['score'], 1.0):.2%})")
    print()

# =============================================================================
# INTERACTIVE MODE — ask your own question
# =============================================================================

print("-" * 70)
print("Try asking your own question about the patient record above.")
print("Examples:")
print("  - How long was the patient hospitalised?")
print("  - What was the patient's ejection fraction?")
print("  - What should the patient do if chest pain recurs?")
print("  - What was the troponin level on admission?")
print("-" * 70)

while True:
    user_question = input("\nYour question (or press Enter to quit): ").strip()
    if not user_question:
        print("Exiting. Goodbye.")
        break
    result = qa(question=user_question, context=MEDICAL_CONTEXT)
    print(f"A: {result['answer']}")
    print(f"   (confidence: {min(result['score'], 1.0):.2%})")

# =============================================================================
# PRACTICAL NOTES ON CONFIDENCE SCORES
# =============================================================================
#
# The pipeline reports score = softmax(start)[i] × softmax(end)[j] for the
# best (i, j) span. In practice:
#   score > 0.70  → usually reliable; safe to surface to a clinician
#   score 0.30–0.70 → borderline; flag for human review
#   score < 0.30  → the model could not find a good span; treat as "unknown"
#
# SQuAD 2.0 fine-tuning specifically trains the model to assign a low
# score to a null/no-answer span, so very low scores are a meaningful signal
# that the question is unanswerable from the provided context.
#
# Limitation for clinical use:
# This model was NOT trained on clinical text. It will produce reasonable
# extractions for well-structured notes like the one above, but may struggle
# with abbreviated clinical shorthand ("SOB", "c/o", "Rx", "Hx") unless the
# notes are pre-expanded. A model like BioBERT or ClinicalBERT fine-tuned on
# MIMIC-III clinical notes would be better suited for production clinical QA.
# =============================================================================
