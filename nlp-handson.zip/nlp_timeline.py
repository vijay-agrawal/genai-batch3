import matplotlib.pyplot as plt

# --- Data for the Timeline ---
# Using approximate years for key milestones.
# Format: (Year, Milestone Name, description [optional])
events_data = [
    (1995, "BoW / TF-IDF", "(Peak Usage / Foundational)"),
    (2003, "LDA", "(Topic Modeling)"),
    (2010, "Gensim", "(Popular NLP Library/Toolkit)"),
    (2013, "Word2Vec", "(Semantic Embeddings)"),
    (2015, "spaCy", "(Efficient NLP Library)"),
    (2015.5, "RNNs / LSTMs", "(Sequence Modeling Peak)"),
    (2017, "Transformer", "('Attention Is All You Need')"),
    (2018, "BERT", "(Pre-trained Transformers)"),
    (2019, "GPT Series", "(Large Generative Models)"),
    (2021, "LLMs Proliferation", "(Current Era)")
]

# --- IMPORTANT: Sort events by year ---
events_data.sort(key=lambda x: x[0])

# --- Prepare data for non-linear plotting ---
# Use the index (order) of events for x-positions
x_positions = list(range(len(events_data)))
# Get the actual years (as strings for labels)
years_str = [str(int(year)) for year, name, desc in events_data]
# Combine name and description for labels
names = [f"{name}\n{desc}" for year, name, desc in events_data]

# --- Plotting ---
plt.style.use('seaborn-v0_8-whitegrid')
fig, ax = plt.subplots(figsize=(14, 5), constrained_layout=True)
ax.set_title("NLP Evolution Timeline (Events Spaced Evenly)", fontsize=16)
ax.set_xlabel("Year (Note: Axis spacing is not linear)", fontsize=10)

# Draw the central timeline horizontal line
ax.axhline(0, color='black', linewidth=1.5, alpha=0.8)

# Plot the event markers on the timeline using index-based positions
ax.plot(x_positions, [0]*len(x_positions), marker='o', markersize=8, linestyle='', color='royalblue', label='Key Milestone')

# Add event labels with alternating positions and connecting lines
# Increase the base_level to create more vertical space between boxes and axis
base_level = 1.5  # Increased from 1 to 1.5
levels = []
for i in range(len(x_positions)):
    levels.append(base_level)
    base_level *= -1  # Alternate position

for i, (x_pos, name) in enumerate(zip(x_positions, names)):
    level = levels[i]
    # Draw vertical line from marker to text position
    ax.vlines(x_pos, 0, level, color='tab:grey', linestyle='dashed', linewidth=0.8)
    # Add the text label at the index-based position
    ax.text(x_pos, level, name,
            ha='center',
            va='bottom' if level > 0 else 'top',
            fontsize=9,
            linespacing=1.3,
            bbox=dict(boxstyle='round,pad=0.3', fc='white', alpha=0.8, ec='lightgrey'))

# --- Formatting the Plot ---
# Set x-axis limits based on the number of events
ax.set_xlim(-0.5, len(events_data) - 0.5)

# --- Set x-axis ticks and labels ---
ax.set_xticks(x_positions)
ax.set_xticklabels(years_str)

# Add more padding between x-axis labels and the plot
plt.setp(ax.get_xticklabels(), rotation=30, ha='right', rotation_mode='anchor')

# Remove y-axis details
ax.yaxis.set_visible(False)
ax.spines[['left', 'right', 'top']].set_visible(False)

# Set y-axis limits to add more space for the text boxes
# Adjust these values to increase vertical space in both directions
ax.set_ylim(-2.5, 2.5)  # Added to ensure proper spacing

# Add a subtle background
ax.set_facecolor('#f8f8f8')

print("Generating plot with non-linear spacing...")
plt.show()
print("Plot displayed.")