# Healthcare EDA Assignment 1

## Overview
This comprehensive assignment is designed to teach exploratory data analysis (EDA) skills for complex healthcare data with deeply nested JSON structures. The package includes synthetic patient data and a hands-on Jupyter notebook assignment.

## Package Contents

### 1. `healthcare_data.json`
Synthetic healthcare data containing:
- **6 patients** with complete medical records
- **13 total visits** across various departments
- **Deeply nested JSON structure** with 3-4 levels of nesting
- **Both structured and unstructured data**:
  - Structured: Demographics, vitals, lab results, diagnoses, medications, billing
  - Unstructured: Clinical notes with embedded patterns

#### Data Hierarchy:
```
patients (list)
├── patient_id
├── demographics
│   ├── name, age, gender
│   └── contact
│       └── address
├── insurance
├── medical_history
│   ├── chronic_conditions (list)
│   ├── allergies (list)
│   └── family_history (text)
└── visits (list) ★ NESTED LEVEL 1
    ├── visit_id, date, type, department
    ├── provider (dict)
    ├── vitals (dict)
    ├── lab_results (list) ★ NESTED LEVEL 2
    │   └── test_name, value, unit, status
    ├── diagnoses (list) ★ NESTED LEVEL 2
    │   └── icd10_code, description, status
    ├── medications_prescribed (list) ★ NESTED LEVEL 2
    │   └── name, dosage, frequency, rx_number
    ├── clinical_notes (text with patterns)
    └── billing (dict)
```

### 2. `healthcare_eda_assignment.ipynb`
Comprehensive Jupyter notebook with:
- **8 parts** covering different EDA techniques
- **Hands-on exercises** with TODO sections
- **Progressive difficulty** from basic to advanced
- **Clear instructions and hints** for each task

## Learning Objectives

By completing this assignment, students will be able to:

1. **Navigate complex nested JSON structures** in healthcare data
2. **Flatten nested data** to create analysis-ready dataframes
3. **Explode nested lists** to achieve proper granularity
4. **Extract patterns from unstructured text** using regex
5. **Aggregate data** across multiple hierarchical levels
6. **Engineer features** from nested information
7. **Discover actionable insights** from healthcare data

## Key Skills Covered

### 1. Data Structure Manipulation
- Flattening nested dictionaries
- Exploding nested lists
- Handling multiple levels of nesting
- Creating analysis-ready dataframes

### 2. Regex Pattern Extraction
Students will extract:
- **Dietary recommendations** from clinical notes (pattern: `DIET: ...`)
- **Follow-up timing** (pattern: `F/U: ...`)
- **Medication mentions** throughout unstructured text

### 3. Advanced Aggregation
- Creating the `has_diabetes` feature by aggregating diagnosis codes across all patient visits
- Calculating patient-level metrics from visit-level data
- Computing medication complexity scores
- Tracking longitudinal trends

### 4. Feature Engineering
- Boolean flags from nested diagnoses
- Patient-level summary statistics
- Risk stratification scores
- Treatment effectiveness metrics

### 5. Insights Discovery
Students uncover 7 key insights:
1. **Diabetes progression patterns** - tracking disease development
2. **Treatment effectiveness** - identifying successful interventions
3. **Comorbidity patterns** - understanding co-occurring conditions
4. **High-risk patient identification** - creating risk scores
5. **Healthcare utilization and costs** - analyzing cost-effectiveness
6. **Distribution patterns** (NEW) - using density plots to reveal bimodal populations and group differences
7. **Outlier detection** (NEW) - using box plots to identify high-risk patients and variability patterns

### 6. Statistical Visualization
- **Density plots (KDE)**: Reveal distribution shapes, skewness, and distinct subpopulations
- **Box plots**: Identify outliers, compare medians, and assess variability (IQR)
- **Violin plots**: Combine distribution shape with quartile information
- **Statistical metrics**: Calculate and interpret skewness and kurtosis

## Data Patterns Embedded

The synthetic data contains realistic patterns for students to discover:

### Clinical Patterns
- **Disease progression**: Prediabetes → Type 2 diabetes over time
- **Treatment response**: Patients with improving HbA1c and glucose levels
- **Comorbidities**: High prevalence of hypertension and hyperlipidemia with diabetes
- **Weight loss correlation**: Patients losing weight show better glucose control

### Regex Patterns in Clinical Notes
- `DIET: [recommendation]` - Dietary interventions
- `F/U: [timeframe]` - Follow-up schedules
- `BP: [reading]` - Blood pressure readings
- Medication names with dosages (e.g., "Metformin 500mg")

### Temporal Patterns
- Visit frequency: 2-3 month intervals for diabetic patients
- Lab value trends: Improving or worsening over time
- Medication adjustments: Changes based on lab results

### Distribution Patterns (for Density/Box Plot Analysis)
- **BMI**: Right-skewed distribution, diabetic patients cluster around overweight/obese range
- **Glucose**: Bimodal distribution in diabetic patients (well-controlled vs poorly-controlled subgroups)
- **Blood Pressure**: Diabetic patients show shifted distribution toward higher values
- **Outliers**: Specific patients consistently outside normal ranges across multiple metrics
- **Department Variations**: Different departments show distinct patient population characteristics
- **Temporal Improvement**: Distribution narrowing over sequential visits indicates treatment effectiveness

## Setup Instructions

### Prerequisites
```bash
pip install pandas numpy matplotlib seaborn jupyter
```

### Running the Assignment
```bash
jupyter notebook healthcare_eda_assignment.ipynb
```

Ensure `healthcare_data.json` is in the same directory.

## Assignment Structure

### Part 1: Initial Data Exploration (15 minutes)
- Understand JSON structure
- Create basic patient-level dataframe

### Part 2: Flattening Nested JSON (30 minutes)
- Flatten visits data
- Create visit-level dataframe
- **Key challenge**: Multiple levels of nesting

### Part 3: Exploding Nested Lists (30 minutes)
- Explode lab results to test-level granularity
- Create analysis-ready lab dataframe
- **Key challenge**: Double-nested iteration

### Part 4: Regex Pattern Extraction (45 minutes)
- Extract dietary recommendations
- Extract follow-up schedules
- Extract medication mentions
- **Key challenge**: Designing effective regex patterns

### Part 5: Advanced Aggregation (60 minutes)
- Create `has_diabetes` feature by checking ALL visits
- Calculate average glucose levels per patient
- Compute medication complexity scores
- **Key challenge**: Multi-level aggregation with missing data handling

### Part 6: Insights Discovery (90 minutes)
- Discover 5 key insights with supporting analysis
- **Key challenge**: Connecting patterns across multiple data levels

### Part 7: Distribution Analysis with Visualizations (90 minutes)
- **Insight 6**: Density plots for distribution patterns
- **Insight 7**: Box plots for outlier detection and group comparisons
- Violin plots and statistical metrics
- Patient journey timelines and correlation heatmaps
- **Key challenge**: Interpreting distribution characteristics and identifying actionable outliers

### Part 8: Bonus Challenges (Optional)
- Patient summary reports
- Intervention recommendations
- NLP sentiment analysis

**Total Time**: Approximately 5-7 hours

## Assessment Criteria

### Technical Skills (70%)
- Data manipulation accuracy
- Regex pattern effectiveness
- Aggregation correctness
- Code quality and documentation

### Analytical Skills (30%)
- Insight quality and depth
- Supporting evidence
- Clinical reasoning
- Actionable recommendations


### Common Pitfalls:

1. **Forgetting to handle missing data** (e.g., visits with no lab results)
2. **Incorrect nesting in loops** when flattening
3. **Overly greedy regex patterns** capturing too much text
4. **Only checking first visit** for has_diabetes feature instead of all visits
5. **Not converting data types** (e.g., dates, numeric values)


## Real-World Applications

This assignment prepares students for:
- **Healthcare analytics roles** requiring nested data processing
- **EHR data analysis** with similar structures
- **Population health management** using patient-level data
- **Clinical research** with complex data hierarchies
- **Healthcare product analytics** at health tech companies

## Additional Resources

### Documentation:
- Pandas `json_normalize()` function
- Python `re` module for regex
- Healthcare data standards (HL7, FHIR)

### Further Practice:
- MIMIC-III dataset (more advanced)
- Synthea synthetic data generator
- Public healthcare datasets from CMS


## Quick Start Checklist

- [ ] Install required Python packages
- [ ] Download all three files to the same directory
- [ ] Open Jupyter notebook
- [ ] Run first cell to verify data loads correctly
- [ ] Begin working through parts sequentially
- [ ] Reference solutions guide only after attempting tasks
- [ ] Complete reflection questions at the end

**Good luck with your EDA assignment!**
