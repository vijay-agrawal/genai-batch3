# Citius Healthcare - Semantic Search Assignment

## Overview

This assignment teaches students to use Natural Language Processing (NLP) and semantic similarity to search through unstructured clinical text. Students learn to answer questions like "How many patients have back pain?" where patients might describe symptoms using different terms ("lumbar discomfort", "lower back ache", "spinal pain", etc.).

## Why Semantic Search Matters in Healthcare

### The Problem with Keyword Search

Traditional keyword search fails when:
- **Synonyms** are used: "back pain" vs "lumbar discomfort" vs "spinal ache"
- **Related concepts** need to be found: searching "respiratory issues" should find "wheezing", "shortness of breath", "dyspnea"
- **Phrases are described differently**: "chest tightness" vs "chest pressure" vs "chest discomfort"
- **Medical terminology varies**: clinical terms vs patient descriptions

### The Semantic Search Solution

Semantic search uses **sentence embeddings** (vectors that capture meaning) to:
- Find text by meaning, not just matching words
- Understand synonyms and related concepts automatically
- Handle variations in medical terminology
- Identify similar cases for clinical decision support

## Package Contents

### 1. **Enhanced Dataset** (`citius_healthcare_data_enhanced.json`)
- **10 patients** with diverse conditions
- **18 clinical visits** with detailed notes
- **Rich symptom descriptions** including:
  - Back pain (multiple variations)
  - Respiratory complaints (asthma, wheezing)
  - Chest pain/discomfort
  - Headaches and migraines
  - Muscle pain and myalgia
  - Fibromyalgia
  - Knee osteoarthritis
  - Metabolic conditions (diabetes)

### 2. **Starter Notebook** (`semantic_search_assignment_starter.ipynb`)
Comprehensive notebook with 9 parts:
- Part 1: Understanding embeddings with simple examples
- Part 2: Extracting and preparing clinical text
- Part 3: Building semantic search functions
- Part 4: Answering 5 clinical questions
- Part 5: Threshold analysis and optimization
- Part 6: Advanced multi-symptom queries
- Part 7: Comparison with keyword search
- Part 8: Building a question-answering system
- Part 9: Evaluation and visualization

### 3. **Solutions Guide** (`semantic_search_solutions.md`)
Complete solutions with:
- Detailed code implementations
- Expected outputs and answer keys
- Teaching notes and discussion points
- Common pitfalls and how to address them

## Learning Objectives

By completing this assignment, students will:

1. **Understand Sentence Embeddings**
   - How text is converted to numerical vectors
   - Why embeddings capture semantic meaning
   - What makes embeddings useful for similarity

2. **Implement Semantic Search**
   - Load and use pre-trained models (SentenceTransformers)
   - Calculate cosine similarity between texts
   - Build search functions with threshold filtering

3. **Apply to Healthcare Problems**
   - Search clinical notes for symptoms
   - Count patients with specific conditions
   - Find similar patient cases
   - Identify symptom co-occurrence patterns

4. **Optimize and Evaluate**
   - Select appropriate similarity thresholds
   - Balance precision vs recall
   - Compare semantic vs keyword approaches
   - Visualize semantic clusters

## Technical Stack

### Required Libraries
```bash
pip install sentence-transformers pandas numpy matplotlib seaborn scikit-learn umap-learn
```

### Key Technologies
- **sentence-transformers**: Pre-trained embedding models
- **Model**: `all-MiniLM-L6-v2` (384-dimensional embeddings)
- **Similarity Metric**: Cosine similarity
- **Visualization**: UMAP for dimensionality reduction

## Assignment Structure

### Time Estimate: 3-4 hours

**Part 1: Introduction (30 minutes)**
- Load model and understand embeddings
- Visualize similarity matrix for example sentences
- Learn about the 384-dimensional vector space

**Part 2-3: Setup and Search Function (45 minutes)**
- Extract clinical notes into DataFrame
- Generate embeddings for all notes (~18 embeddings)
- Build reusable semantic search function

**Part 4: Answer Clinical Questions (60 minutes)**
- Question 1: How many patients have back pain?
- Question 2: Which patients have respiratory complaints?
- Question 3: Find patients with muscle pain/aches
- Question 4: Which patients mentioned chest discomfort?
- Question 5: Find patients with headaches

**Part 5-6: Advanced Analysis (45 minutes)**
- Threshold optimization and visualization
- Multi-symptom searches (patients with BOTH symptoms)
- Symptom co-occurrence analysis

**Part 7: Comparative Analysis (30 minutes)**
- Implement keyword search
- Compare semantic vs keyword results
- Identify cases missed by keywords

**Part 8-9: Synthesis (30 minutes)**
- Build question-answering system
- Generate summary reports
- Visualize semantic clusters with UMAP

## Expected Results

### Question Answers (at threshold 0.35-0.40):

| Question | Expected Answer |
|----------|----------------|
| Back pain patients | 2-3 patients |
| Respiratory complaints | 1-2 patients |
| Muscle pain/aches | 2-3 patients |
| Chest discomfort | 1-2 patients |
| Headaches | 1 patient |

### Key Findings Students Should Discover:

1. **Semantic search finds 2-4x more relevant cases than keyword search**
   - Catches "lumbar discomfort" when searching "back pain"
   - Finds "myalgia" when searching "muscle aches"
   - Identifies "chest tightness" when searching "chest pain"

2. **Optimal threshold is 0.35-0.40**
   - Below 0.30: Too many false positives
   - Above 0.50: Misses relevant cases
   - Sweet spot balances precision and recall

3. **Symptom co-occurrence patterns**
   - Back pain often co-occurs with muscle aches
   - Headaches may co-occur with neck pain
   - Chest pain correlates with respiratory issues in some patients

4. **Clinical note clusters**
   - UMAP visualization shows clear separation between symptom categories
   - Similar conditions cluster together in semantic space
   - Demonstrates how embeddings capture clinical meaning

## Real-World Applications

### Clinical Decision Support
- Find similar past cases to help with diagnosis
- Identify patients who might benefit from specific treatments
- Detect patterns in symptom presentation

### Population Health Management
- Identify patient cohorts for research studies
- Track symptom prevalence across populations
- Monitor emerging health trends

### Quality Improvement
- Find adverse events mentioned in notes
- Identify patients with uncontrolled symptoms
- Track treatment response patterns

### Medical Coding & Billing
- Suggest appropriate ICD-10 codes based on note content
- Ensure comprehensive documentation
- Identify missed diagnoses

## Teaching Tips

### Before Assignment
1. **Explain embeddings conceptually**: "Like GPS coordinates for words/sentences"
2. **Demonstrate with simple example**: Show how "cat" and "kitten" are close in vector space
3. **Discuss healthcare context**: Why medical terminology varies so much

### During Assignment
1. **Emphasize threshold experimentation**: No single "right" threshold
2. **Encourage exploration**: Try different query phrasings
3. **Discuss edge cases**: When might semantic search fail?

### Discussion Points
1. "Why is this better than regex or keywords?"
2. "What's the computational cost of semantic search?"
3. "How would you deploy this in production?"
4. "What about protected health information (PHI)?"

### Common Issues
1. **Model loading slow**: First download takes time, subsequent runs fast
2. **Threshold confusion**: Help students visualize score distributions
3. **False positives**: Discuss precision vs recall trade-offs
4. **Computing limitations**: For large datasets, consider batch processing

## Extensions for Advanced Students

### 1. Medical-Specific Models
- Fine-tune on clinical text (MIMIC-III)
- Try BioBERT or ClinicalBERT
- Compare performance to general-purpose models

### 2. Hybrid Search
- Combine semantic + keyword search
- Use semantic for recall, keywords for precision
- Implement re-ranking algorithms

### 3. Named Entity Recognition
- Extract symptom entities with spaCy
- Combine NER + semantic search
- Build structured symptom database

### 4. Temporal Analysis
- Track how symptoms change over time
- Identify chronic vs acute patterns
- Predict symptom progression

### 5. Production Deployment
- Build REST API with FastAPI
- Implement caching for common queries
- Add authentication and logging
- Containerize with Docker

## Comparison to First EDA Assignment

### First Assignment (Nested JSON EDA)
- **Focus**: Data manipulation, aggregation, flattening
- **Skills**: pandas, regex, visualization
- **Output**: Structured features from nested data
- **Time**: 5-7 hours

### This Assignment (Semantic Search)
- **Focus**: NLP, semantic similarity, unstructured text
- **Skills**: embeddings, similarity search, thresholding
- **Output**: Text-based search and Q&A system
- **Time**: 3-4 hours

### Together They Cover:
- **Structured data** (demographics, vitals, labs) ✓
- **Semi-structured data** (diagnosis codes, medications) ✓
- **Unstructured data** (clinical notes, free text) ✓

## Assessment Rubric

**Technical Implementation (50 points)**
- Model loading and embeddings generation: 10 points
- Semantic search function: 15 points
- Clinical questions answered correctly: 15 points
- Threshold analysis and visualization: 10 points

**Analysis & Insights (30 points)**
- Comparison with keyword search: 10 points
- Multi-symptom analysis: 10 points
- Summary report and visualizations: 10 points

**Code Quality (10 points)**
- Comments and documentation: 5 points
- Organization and readability: 5 points

**Reflection (10 points)**
- Understanding of semantic search advantages: 5 points
- Recognition of limitations: 5 points

**Total: 100 points**

## Prerequisites

### Knowledge
- Basic Python programming
- pandas fundamentals
- Understanding of similarity/distance metrics (helpful)

### From Previous Assignment (helpful but not required)
- Working with nested JSON
- Healthcare data structures
- Clinical terminology basics

## Submission Checklist

- [ ] Model successfully loaded
- [ ] Embeddings generated for all clinical notes
- [ ] Semantic search function implemented and tested
- [ ] All 5 clinical questions answered with patient counts
- [ ] Threshold analysis completed with visualization
- [ ] Comparison with keyword search performed
- [ ] Multi-symptom search implemented
- [ ] Summary report generated
- [ ] UMAP visualization created (bonus)
- [ ] Reflection questions answered
- [ ] Code well-commented

## Additional Resources

### Documentation
- [sentence-transformers Documentation](https://www.sbert.net/)
- [Cosine Similarity Explained](https://en.wikipedia.org/wiki/Cosine_similarity)
- [UMAP for Visualization](https://umap-learn.readthedocs.io/)

### Research Papers
- "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks" (2019)
- "Clinical BERT: Application in Extracting Clinical Concepts from Medical Records" (2019)

### Healthcare NLP Resources
- ClinicalBERT models
- MIMIC-III dataset
- i2b2 NLP challenges

## Future Enhancements

This assignment could be extended with:
1. **Larger dataset**: 100+ patients with diverse conditions
2. **More symptom categories**: Pain scales, severity indicators
3. **Temporal data**: Track symptom evolution over months/years
4. **Medication analysis**: Find drug-symptom associations
5. **Adverse events**: Detect complications in free text

---

**Version**: 1.0  
**Created for**: Citius Healthcare Analytics Training  
**Dataset**: Enhanced version with 10 patients, 18 visits  
**Total Assignment Time**: 3-4 hours  
**Difficulty**: Intermediate

---

## Quick Start

1. Ensure enhanced dataset is in working directory
2. Install requirements: `pip install sentence-transformers pandas numpy matplotlib seaborn`
3. Open `semantic_search_assignment_starter.ipynb`
4. Follow instructions in notebook
5. Compare work to `semantic_search_solutions.md` after completion

**Happy semantic searching!** 🔍🏥
