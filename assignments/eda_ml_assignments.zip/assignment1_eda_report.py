import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.stats import chi2_contingency, f_oneway
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
import warnings
warnings.filterwarnings('ignore')

# Set style for better visualizations
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

def load_and_explore_data():
    """Load the dataset and perform initial exploration"""
    print("="*60)
    print("STEP 1: INITIAL DATA EXPLORATION")
    print("="*60)
    
    # Load the dataset
    df = pd.read_csv('mumbai_loan_dataset.csv')
    
    print(f"Dataset Shape: {df.shape}")
    print(f"Memory Usage: {df.memory_usage().sum() / 1024:.2f} KB")
    
    print("\nColumn Information:")
    print(df.info())
    
    print("\nMissing Values:")
    
    # Detect and treat missing values
    #      
    
    print("\nData Types:")
    print(df.dtypes.value_counts())
    
    return df

def analyze_target_variable(df):
    """Analyze the target variable distribution"""
    print("\n" + "="*60)
    print("STEP 2: TARGET VARIABLE ANALYSIS")
    print("="*60)
    
    target_dist = df['loan_approved'].value_counts()
    target_pct = df['loan_approved'].value_counts(normalize=True)
    
    print("Loan Approval Distribution:")
    print(f"Approved (1): {target_dist[1]} ({target_pct[1]:.2%})")
    print(f"Rejected (0): {target_dist[0]} ({target_pct[0]:.2%})")
    
    # Check for class imbalance
    # print imbalance ratio

    #if imbalance_ratio > 1.5:
    #    print("⚠️  Dataset shows class imbalance - consider techniques like SMOTE, class weighting, or stratified sampling")
    
    # Visualize target distribution
    
    # Bar plot for loan approval counts/distribution
    
    # Pie chart for rejected and approved loans
    
    return df

def detect_and_handle_outliers(df):
    """Detect and handle outliers using various methods"""
    print("\n" + "="*60)
    print("STEP 3: OUTLIER DETECTION AND TREATMENT")
    print("="*60)
    
    # Select numerical columns for outlier detection
    
    # Create subplots for box plots

    # Remove empty subplots
    
    # Outlier treatment strategies
    print("\n" + "-"*40)
    print("OUTLIER TREATMENT STRATEGIES")
    print("-"*40)
    
    # If mor than 5% are outliers, cap outliers at 5th and 95th percentile

    # If 1-5% are outliers (moderate), use IQR capping
    
    print(f"\nOutlier treatment completed. Dataset shape remains: {df_treated.shape}")
    
    return df_treated, outlier_summary

def correlation_analysis(df):
    """Perform comprehensive correlation analysis"""
    print("\n" + "="*60)
    print("STEP 4: CORRELATION ANALYSIS")
    print("="*60)
    
    # Select numerical columns
    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    
    # Calculate correlation matrix
    corr_matrix = df[numerical_cols].corr()
    
    print("Correlation Matrix (Pearson):")
    print(corr_matrix.round(3))
    
    # Visualize correlation matrix
    plt.figure(figsize=(14, 10))
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
    sns.heatmap(corr_matrix, mask=mask, annot=True, cmap='coolwarm', center=0,
                square=True, fmt='.2f', cbar_kws={"shrink": .8})
    plt.title('Correlation Matrix - Numerical Variables')
    plt.tight_layout()
    plt.show()
    
    # Find highly correlated pairs
    print("\n" + "-"*40)
    print("HIGHLY CORRELATED FEATURE PAIRS")
    print("-"*40)

    ## TODO: FIll code here
    # 
        
    # Correlation with target variable
    print("\n" + "-"*40)
    print("CORRELATION WITH TARGET VARIABLE")
    print("-"*40)
    
    print("Correlation with loan_approved:")

    #TODO: Analyze correlations and print top correlated features, do dimensionality reduction    
    return corr_matrix, high_corr_pairs

def anova_analysis(df):
    """Perform ANOVA analysis for categorical variables"""
    print("\n" + "="*60)
    print("STEP 5: ANOVA ANALYSIS (CATEGORICAL vs NUMERICAL)")
    print("="*60)
    
    categorical_cols = df.select_dtypes(include=['object']).columns.tolist()
    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    numerical_cols = [col for col in numerical_cols if col != 'loan_approved']
    
    anova_results = {}
    
    for cat_col in categorical_cols:
        print(f"\nANOVA Analysis for: {cat_col}")
        print("-" * 40)
        
        for num_col in numerical_cols[:5]:  # Test top 5 numerical columns
            try:
                # Create groups for ANOVA - collect numerical values for each category
                groups = []

                #TODO create groups here
                # 
                                
                # Perform one-way ANOVA only if we have at least 2 groups with data
                
            except Exception as e:
                print(f"  {num_col}: Error - {str(e)}")
    
    # Summary
    print("\n" + "-"*40)
    print("SIGNIFICANCE LEVELS")
    print("-"*40)
    print("*** p < 0.001 (highly significant)")
    print("**  p < 0.01  (very significant)") 
    print("*   p < 0.05  (significant)")
    print("ns  p >= 0.05 (not significant)")
    
    return anova_results

def hypothesis_testing(df):
    """Perform hypothesis testing: t-tests and chi-squared tests"""
    print("\n" + "="*60)
    print("STEP 6: HYPOTHESIS TESTING")
    print("="*60)
    
    # T-tests for numerical variables
    print("T-TESTS (Approved vs Rejected)")
    print("-" * 40)
    
    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    numerical_cols = [col for col in numerical_cols if col not in ['loan_approved', 'loan_tenure']]
    
    approved = df[df['loan_approved'] == 1]
    rejected = df[df['loan_approved'] == 0]
    
    t_test_results = {}
    
    for col in numerical_cols:
        approved_values = approved[col].dropna()
        rejected_values = rejected[col].dropna()
        
        # TODO: Perform independent t-test


        significance = "***" if p_value < 0.001 else "**" if p_value < 0.01 else "*" if p_value < 0.05 else "ns"
        effect_size = "Large" if abs(cohens_d) > 0.8 else "Medium" if abs(cohens_d) > 0.5 else "Small"
        
        print(f"{col}:")
        print(f"  Approved mean: {approved_values.mean():.2f}")
        print(f"  Rejected mean: {rejected_values.mean():.2f}")
        print(f"  t={t_stat:.3f}, p={p_value:.4f} {significance}")
        print(f"  Effect size (Cohen's d): {cohens_d:.3f} ({effect_size})")
        print()
    
    # Chi-squared tests for categorical variables
    print("CHI-SQUARED TESTS (Categorical vs Target)")
    print("-" * 40)
    
    categorical_cols = df.select_dtypes(include=['object']).columns.tolist()
    chi2_results = {}
    
    for col in categorical_cols:
        # Create contingency table
        
        # TODO: Perform chi-squared test

        
        
        chi2_results[col] = {
            'chi2_stat': chi2_stat,
            'p_value': p_value,
            'contingency_table': contingency_table
        }
        
        significance = "***" if p_value < 0.001 else "**" if p_value < 0.01 else "*" if p_value < 0.05 else "ns"
        effect_size = "Large" if cramers_v > 0.3 else "Medium" if cramers_v > 0.1 else "Small"
        
        print(f"{col}:")
        print(f"  χ²={chi2_stat:.3f}, p={p_value:.4f} {significance}")
        print(f"  Cramer's V: {cramers_v:.3f} ({effect_size})")
        print(f"  Contingency Table:")
        print(contingency_table)
        print()
    
    return t_test_results, chi2_results

def feature_engineering(df):
    """Perform feature engineering: encoding, binning, scaling"""
    print("\n" + "="*60)
    print("STEP 7: FEATURE ENGINEERING")
    print("="*60)
    
    df_processed = df.copy()
    
    # 1. ONE-HOT ENCODING
    print("1. ONE-HOT ENCODING")
    print("-" * 20)
    
    categorical_cols = df_processed.select_dtypes(include=['object']).columns.tolist()
    print(f"Categorical columns to encode: {categorical_cols}")
    
    # TODO: Apply one-hot encoding
    
    print(f"Shape before encoding: {df_processed.shape}")
    print(f"Shape after encoding: {df_encoded.shape}")
    print(f"New columns created: {df_encoded.shape[1] - df_processed.shape[1]}")
    
    # 2. BINNING
    print("\n2. BINNING")
    print("-" * 20)
    
    # TODO: Age binning
    
    # TODO: Income binning

    # TODO: Credit score binning

    # TODO: Debt-to-income ratio binning
    
    print("Binning completed for:")
    print("- age -> age_group")
    print("- annual_income -> income_bracket")  
    print("- credit_score -> credit_category")
    print("- debt_to_income_ratio -> debt_risk_level")
    
    # Show binning results
    binned_cols = ['age_group', 'income_bracket', 'credit_category', 'debt_risk_level']
    for col in binned_cols:
        print(f"\n{col} distribution:")
        print(df_encoded[col].value_counts())
    
    # Apply one-hot encoding to binned categorical variables
    df_final = pd.get_dummies(df_encoded, columns=binned_cols, prefix=binned_cols, drop_first=True)
    
    # 3. MIN-MAX SCALING
    print("\n3. MIN-MAX SCALING")
    print("-" * 20)
    
    # Select numerical columns for scaling (exclude target and already binned features)
    numerical_cols = df_final.select_dtypes(include=[np.number]).columns.tolist()
    cols_to_scale = [col for col in numerical_cols if col not in ['loan_approved'] + 
                    [col for col in numerical_cols if any(binned in col for binned in binned_cols)]]
    
    print(f"Columns to scale: {cols_to_scale}")
    
    scaler = MinMaxScaler()

    # TODO: Catty out minmax scaling
        
    print("Min-Max scaling completed.")
    print(f"All scaled columns now have values between 0 and 1.")
    
    # Show scaling results
    print("\nScaling verification (min, max values):")
    for col in cols_to_scale[:5]:  # Show first 5 columns
        print(f"{col}: min={df_final[col].min():.3f}, max={df_final[col].max():.3f}")
    
    print(f"\nFinal dataset shape after all transformations: {df_final.shape}")
    
    return df_final, scaler

def analyze_skewness(df):
    """Analyze and visualize skewness in the dataset"""
    print("\n" + "="*60)
    print("STEP 8: SKEWNESS ANALYSIS")
    print("="*60)
    
    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    numerical_cols = [col for col in numerical_cols if col != 'loan_approved'][:6]  # Top 6 for visualization
    
    skewness_results = {}
    
    # Calculate skewness
    print("SKEWNESS VALUES:")
    print("-" * 20)
    for col in numerical_cols:
        # TODO Calculate skewness
        print(f"{col}: {skew_val:.3f} ({skew_interpretation}, {skew_direction})")
    
    # Visualize distributions
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    axes = axes.flatten()
    
    for i, col in enumerate(numerical_cols):
        if i < len(axes):
            # Histogram with KDE
            axes[i].hist(df[col].dropna(), bins=30, alpha=0.7, density=True, color='skyblue')
            df[col].dropna().plot(kind='kde', ax=axes[i], color='red', linewidth=2)
            axes[i].set_title(f'{col}\nSkewness: {df[col].skew():.3f}')
            axes[i].set_xlabel(col)
            axes[i].set_ylabel('Density')
    
    plt.tight_layout()
    plt.show()
    
    # Recommendations for skewness treatment
    print("\n" + "-"*40)
    print("SKEWNESS TREATMENT RECOMMENDATIONS")
    print("-"*40)
    
    for col, skew_val in skewness_results.items():
        if abs(skew_val) > 1:
            if skew_val > 0:
                print(f"{col}: Highly right-skewed → Try log transformation, square root, or Box-Cox")
            else:
                print(f"{col}: Highly left-skewed → Try exponential transformation or reflection + log")
        elif abs(skew_val) > 0.5:
            print(f"{col}: Moderately skewed → Consider transformation or use robust algorithms")
        else:
            print(f"{col}: Approximately normal → No transformation needed")
    
    return skewness_results

def feature_importance_summary(df, t_test_results, chi2_results, corr_matrix):
    """Summarize feature importance across different analyses"""
    print("\n" + "="*60)
    print("STEP 9: FEATURE IMPORTANCE SUMMARY")
    print("="*60)
    
    importance_scores = {}
    
    # From correlation analysis
    target_corr = df.select_dtypes(include=[np.number]).corrwith(df['loan_approved'])
    for feature, corr_val in target_corr.items():
        if feature != 'loan_approved':
            importance_scores[feature] = {'correlation': abs(corr_val)}
    
    # From t-tests
    for feature, results in t_test_results.items():
        if feature in importance_scores:
            # Use p-value inverse and effect size
            p_val_score = 1 - results['p_value'] if results['p_value'] < 1 else 0
            effect_score = abs(results['cohens_d']) / 2  # Normalize effect size
            importance_scores[feature]['t_test'] = (p_val_score + effect_score) / 2
    
    # From chi-squared tests
    for feature, results in chi2_results.items():
        importance_scores[feature] = {'chi_square': 1 - results['p_value'] if results['p_value'] < 1 else 0,
                                    'cramers_v': results['cramers_v']}
    
    # Calculate composite importance score
    print("FEATURE IMPORTANCE RANKING:")
    print("-" * 30)
    
    feature_rankings = []
    
    for feature, scores in importance_scores.items():
        composite_score = 0
        count = 0
        
        if 'correlation' in scores:
            composite_score += scores['correlation']
            count += 1
        if 't_test' in scores:
            composite_score += scores['t_test']
            count += 1
        if 'chi_square' in scores:
            composite_score += (scores['chi_square'] + scores['cramers_v']) / 2
            count += 1
        
        if count > 0:
            composite_score /= count
            feature_rankings.append((feature, composite_score, scores))
    
    # Sort by composite score
    feature_rankings.sort(key=lambda x: x[1], reverse=True)
    
    print("Rank | Feature | Composite Score | Details")
    print("-" * 60)
    for i, (feature, score, details) in enumerate(feature_rankings[:10], 1):
        details_str = ", ".join([f"{k}: {v:.3f}" for k, v in details.items()])
        print(f"{i:2d}   | {feature[:15]:<15} | {score:.3f}          | {details_str}")
    
    # Feature selection recommendations
    print("\n" + "-"*40)
    print("FEATURE SELECTION RECOMMENDATIONS")
    print("-"*40)
    
    high_importance = [f for f, s, _ in feature_rankings if s > 0.3]
    medium_importance = [f for f, s, _ in feature_rankings if 0.1 <= s <= 0.3]
    low_importance = [f for f, s, _ in feature_rankings if s < 0.1]
    
    print(f"High Importance ({len(high_importance)}): {', '.join(high_importance[:5])}")
    print(f"Medium Importance ({len(medium_importance)}): {', '.join(medium_importance[:5])}")
    print(f"Low Importance ({len(low_importance)}): Consider removing these features")
    
    return feature_rankings

def generate_eda_report(df_original, df_final, outlier_summary, skewness_results, feature_rankings):
    """Generate a comprehensive EDA report"""
    print("\n" + "="*60)
    print("COMPREHENSIVE EDA REPORT")
    print("="*60)
    
    report = {
        'dataset_overview': {
            'original_shape': df_original.shape,
            'final_shape': df_final.shape,
            'features_created': df_final.shape[1] - df_original.shape[1],
            'target_distribution': df_original['loan_approved'].value_counts().to_dict()
        },
        'data_quality': {
            'missing_values': df_original.isnull().sum().sum(),
            'duplicate_rows': df_original.duplicated().sum(),
            'outliers_detected': sum([info['count'] for info in outlier_summary.values()])
        },
        'key_insights': [],
        'recommendations': []
    }
    
    # Key insights
    approval_rate = df_original['loan_approved'].mean()
    high_corr_features = len([f for f, s, _ in feature_rankings if s > 0.3])
    
    report['key_insights'] = [
        f"Loan approval rate: {approval_rate:.1%}",
        f"Dataset has {'class imbalance' if abs(approval_rate - 0.5) > 0.2 else 'balanced classes'}",
        f"Identified {high_corr_features} highly important features",
        f"Created {df_final.shape[1] - df_original.shape[1]} new features through engineering",
        f"Detected outliers in {len(outlier_summary)} variables",
    ]
    
    # Recommendations
    report['recommendations'] = [
        "Use cross-validation for model evaluation due to dataset size",
        "Consider ensemble methods to handle feature interactions",
        "Apply SMOTE if class imbalance affects model performance",
        "Monitor for overfitting with the engineered features",
        "Use feature selection to reduce dimensionality",
        "Consider non-linear models due to complex relationships"
    ]
    
    print("\nDATASET OVERVIEW:")
    print(f"- Original dataset: {report['dataset_overview']['original_shape']}")
    print(f"- Final dataset: {report['dataset_overview']['final_shape']}")
    print(f"- Features created: {report['dataset_overview']['features_created']}")
    print(f"- Approval rate: {approval_rate:.1%}")
    
    print(f"\nDATA QUALITY:")
    print(f"- Missing values: {report['data_quality']['missing_values']}")
    print(f"- Duplicate rows: {report['data_quality']['duplicate_rows']}")
    print(f"- Outliers detected: {report['data_quality']['outliers_detected']}")
    
    print(f"\nKEY INSIGHTS:")
    for insight in report['key_insights']:
        print(f"- {insight}")
    
    print(f"\nRECOMMENDATIONS:")
    for rec in report['recommendations']:
        print(f"- {rec}")
    
    return report

def main():
    """Main function to run the complete EDA pipeline"""
    print("MUMBAI LOAN APPROVAL DATASET - COMPREHENSIVE EDA")
    print("="*80)
    
    try:
        # Step 1: Load and explore data
        df = load_and_explore_data()
        
        # Step 2: Analyze target variable
        df = analyze_target_variable(df)
        
        # Step 3: Detect and handle outliers
        df_treated, outlier_summary = detect_and_handle_outliers(df)
        
        # Step 4: Correlation analysis
        corr_matrix, high_corr_pairs = correlation_analysis(df_treated)
        
        # Step 5: ANOVA analysis
        anova_results = anova_analysis(df_treated)
        
        # Step 6: Hypothesis testing
        t_test_results, chi2_results = hypothesis_testing(df_treated)
        
        # Step 7: Feature engineering
        df_final, scaler = feature_engineering(df_treated)
        
        # Step 8: Skewness analysis
        skewness_results = analyze_skewness(df)
        
        # Step 9: Feature importance summary
        feature_rankings = feature_importance_summary(df_treated, t_test_results, chi2_results, corr_matrix)
        
        # Step 10: Generate comprehensive report
        report = generate_eda_report(df, df_final, outlier_summary, skewness_results, feature_rankings)
        
        # Save the processed dataset
        df_final.to_csv('mumbai_loan_dataset_processed.csv', index=False)
        print(f"\nProcessed dataset saved as 'mumbai_loan_dataset_processed.csv'")
        print(f"Ready for machine learning modeling!")
        
        return df_final, report
        
    except Exception as e:
        print(f"Error in EDA pipeline: {str(e)}")
        import traceback
        traceback.print_exc()
        return None, None

if __name__ == "__main__":
    # Run the complete EDA pipeline
    processed_data, eda_report = main()