import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import warnings
import os
warnings.filterwarnings('ignore')

##
## EDA and ML Assignment 2: Impact of Transformations on Model Performance
##
## Dataset: Synthetic dataset of # days in hospital, medical costs, response times, severity scores, and patient age
## Target: Length of hospital stay (in days)
#    
## Objective: Show how log transformations improve model performance
##
# # Instructions:
## 1. Load the dataset
## 2. Split the data into training and test sets
## 3. Select an appropriate model  (do not do any EDA)
#  4. Train the model
#  5. print evaluation metrics
#  6. Carry out EDA: analyze and treat outliers, distributions, skewness, correlations 
#  7. Apply  transformations such as  min max scaling, standardization, log transformation as needed
#  8. Retrain the model on transformed data
# 9. print evaluation metrics of the new model
# 10. Compare model performance before and after transformations, present results visually and in tabular format
# 11. Write a summary of your findings and insights

def load_data(filename='hospital_stay_data.csv'):
    """Load data from CSV file"""
    if not os.path.exists(filename):
        print(f"Error: {filename} not found!")
        return None
    
    data = pd.read_csv(filename)
    print(f"✅ Data loaded successfully from {filename}")
    print(f"Shape: {data.shape}")
    print(f"Columns: {list(data.columns)}")
    return data

def main():
    # Load data
    print("\n1. Loading data...")
    data = load_data('hospital_stay_data.csv')
    if data is None:
        return
    
    print(f"\nDataset overview:")
    print(data.head())
    
    # Split data

    # train the model


    # Score and Evaluate models

    # Carry out EDA and transformations
    
    # Retrain and evaluate model
    
    # Compare results


if __name__ == "__main__":
    main()