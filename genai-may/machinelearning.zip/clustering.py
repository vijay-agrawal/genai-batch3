"""
============================================================
  CUSTOMER SEGMENTATION: THREE APPROACHES COMPARED
  Rule-Based  vs  Supervised ML  vs  Clustering
============================================================

BUSINESS PROBLEM
----------------
A marketing team has data on 60 customers and wants to group them
into meaningful segments so they can personalise campaigns.

The critical constraint: WE HAVE NO LABELS.
No one has sat down and decided who belongs to which group.
This is the reality for most real-world segmentation tasks.

We will try three approaches and see which one actually works.
"""

import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# STEP 1: CREATE THE DATASET
# ============================================================
# In a real scenario you would load a CSV.
# We generate data here so we know the "ground truth" — but
# the algorithms (especially clustering) will NOT be given
# these labels. We only reveal them at the end to verify.

np.random.seed(42)

print("=" * 65)
print("  GENERATING CUSTOMER DATASET")
print("=" * 65)

# --- Segment A: Students ---
# Young, low income, but surprisingly high tech spend
# (they prioritise gadgets even on tight budgets)
students = pd.DataFrame({
    'Income':     np.random.randint(15_000, 25_000, 20),
    'Age':        np.random.randint(18, 25, 20),
    'Tech_Spend': np.random.randint(2_000, 2_500, 20),
    'True_Segment': 'Student'
})

# --- Segment B: Executives ---
# Older, very high income, and ALSO high tech spend
# KEY TRAP: Tech_Spend overlaps completely with Students!
# Any rule based only on Tech_Spend will confuse these two groups.
executives = pd.DataFrame({
    'Income':     np.random.randint(85_000, 120_000, 20),
    'Age':        np.random.randint(45, 60, 20),
    'Tech_Spend': np.random.randint(2_000, 2_500, 20),
    'True_Segment': 'Executive'
})

# --- Segment C: Frugal Savers ---
# Middle age, moderate income, low tech spend
savers = pd.DataFrame({
    'Income':     np.random.randint(40_000, 60_000, 20),
    'Age':        np.random.randint(30, 50, 20),
    'Tech_Spend': np.random.randint(200, 800, 20),
    'True_Segment': 'Saver'
})

df = pd.concat([students, executives, savers], ignore_index=True)

print(f"\nDataset created: {len(df)} customers, {df.shape[1]} features")
print("\nSample rows (True_Segment is the hidden ground truth):")
print(df.groupby('True_Segment')[['Income', 'Age', 'Tech_Spend']].mean().round(0))
print("""
NOTICE THE TRAP:
  Students avg Tech_Spend ≈ Executives avg Tech_Spend  (~$2,250 each)
  Only Income + Age together reveal the true difference.
  Any single-feature rule will fail on this data.
""")

input("Press ENTER to see Approach 1: Rule-Based Segmentation...")

# ============================================================
# APPROACH 1: RULE-BASED SEGMENTATION
# ============================================================
print("\n" + "=" * 65)
print("  APPROACH 1: RULE-BASED SEGMENTATION")
print("=" * 65)
print("""
A business analyst looks at the data and writes IF/ELSE rules.
This is the most common first attempt in the real world.

Typical thought process:
  "High tech spend → Tech Enthusiast"
  "Low income      → Budget Shopper"
  "High income     → Premium Customer"

Let's see how well this works...
""")

df_rules = df.copy()

# --- Rule attempt 1: Single feature (Tech_Spend only) ---
print("--- Rule Attempt 1: Segment by Tech_Spend alone ---")

def rule_v1(row):
    if row['Tech_Spend'] > 1500:
        return 'Tech Enthusiast'
    else:
        return 'Non-Tech'

df_rules['Rule_V1'] = df_rules.apply(rule_v1, axis=1)
print(df_rules.groupby('Rule_V1')[['Income', 'Age', 'Tech_Spend']].mean().round(0))
print("\nCompare to true segments:")
print(pd.crosstab(df_rules['True_Segment'], df_rules['Rule_V1']))
print("""
PROBLEM: 'Tech Enthusiast' bucket contains BOTH Students AND Executives.
The rule can't tell a 19-year-old student from a 55-year-old executive
because they spend the same amount on tech.
""")

# --- Rule attempt 2: Two features (Tech_Spend + Income) ---
print("--- Rule Attempt 2: Add Income threshold ---")

def rule_v2(row):
    if row['Tech_Spend'] > 1500 and row['Income'] > 50_000:
        return 'Wealthy Tech Buyer'
    elif row['Tech_Spend'] > 1500 and row['Income'] <= 50_000:
        return 'Budget Tech Buyer'
    else:
        return 'Non-Tech Saver'

df_rules['Rule_V2'] = df_rules.apply(rule_v2, axis=1)
print(df_rules.groupby('Rule_V2')[['Income', 'Age', 'Tech_Spend']].mean().round(0))
print("\nCompare to true segments:")
print(pd.crosstab(df_rules['True_Segment'], df_rules['Rule_V2']))
print("""
BETTER, but still problems:
  - Threshold of $50k is arbitrary. Why not $45k? Or $60k?
  - Every new dataset needs the thresholds re-tuned manually.
  - With 10+ features this becomes a nightmare of nested IF statements.
  - These thresholds encode our assumptions — we might be wrong.
""")

# --- Rule attempt 3: Three features ---
print("--- Rule Attempt 3: Use all three features with fine-tuned thresholds ---")

def rule_v3(row):
    if row['Tech_Spend'] > 1500 and row['Income'] > 70_000 and row['Age'] > 40:
        return 'Executive'
    elif row['Tech_Spend'] > 1500 and row['Income'] < 30_000 and row['Age'] < 30:
        return 'Student'
    elif row['Tech_Spend'] < 1000:
        return 'Saver'
    else:
        return 'Unclassified'   # <-- notice this bucket appears when rules don't cover all cases

df_rules['Rule_V3'] = df_rules.apply(rule_v3, axis=1)
rule_counts = df_rules['Rule_V3'].value_counts()
print(f"\nSegment counts: \n{rule_counts}")
print(f"\nCustomers left UNCLASSIFIED: {rule_counts.get('Unclassified', 0)}")
print("\nCompare to true segments:")
print(pd.crosstab(df_rules['True_Segment'], df_rules['Rule_V3']))

correct_v3 = (df_rules['Rule_V3'] == df_rules['True_Segment']).sum()
print(f"\nRule-Based Accuracy (V3): {correct_v3}/{len(df_rules)} = {correct_v3/len(df_rules)*100:.1f}%")
print("""
SUMMARY OF RULE-BASED PROBLEMS:
  1. Thresholds are arbitrary and require manual tuning per dataset.
  2. Rules don't scale — 10 features means hundreds of combinations.
  3. New customer types break old rules; rules must be rewritten.
  4. 'Unclassified' buckets appear when reality doesn't fit your rules.
  5. Rules bake in human bias — we only find what we already expect.
""")

input("Press ENTER to see Approach 2: Supervised ML Classification...")

# ============================================================
# APPROACH 2: SUPERVISED ML CLASSIFICATION
# ============================================================
print("\n" + "=" * 65)
print("  APPROACH 2: SUPERVISED ML CLASSIFICATION")
print("=" * 65)
print("""
What if we train a Decision Tree instead of hand-coding rules?
A classifier learns thresholds automatically from labelled examples.

THE FUNDAMENTAL PROBLEM:
  Supervised learning requires labelled training data.
  But we're trying to DISCOVER the labels — that's the whole task!

  This is a circular dependency:
    → To train a classifier, you need labelled data.
    → To get labelled data, you need to know the segments.
    → To know the segments... you need a classifier.

To illustrate this trap, we'll simulate two realistic scenarios:
  A) Someone manually labels a small sample (expensive & biased).
  B) Someone uses rule-based labels as training data (garbage in, garbage out).
""")

# --- Scenario A: Manual labelling (small sample) ---
print("--- Scenario A: Train on manually labelled subset (25% of data) ---")
print("(Imagine a human reviewer labelled 15 customers out of 60)\n")

# Use true labels for the lucky 25% that got manually reviewed
small_labeled = df.sample(frac=0.25, random_state=1)
X_small = small_labeled[['Income', 'Age', 'Tech_Spend']]
y_small = small_labeled['True_Segment']

X_all = df[['Income', 'Age', 'Tech_Spend']]
y_all = df['True_Segment']

dt_small = DecisionTreeClassifier(max_depth=4, random_state=42)
dt_small.fit(X_small, y_small)
preds_small = dt_small.predict(X_all)
acc_small = (preds_small == y_all).mean()

print(f"Trained on {len(small_labeled)} labelled samples, predicting all {len(df)} customers.")
print(f"Accuracy: {acc_small*100:.1f}%")
print(f"""
PROBLEM: {len(small_labeled)} labels is not enough.
  Who did the labelling? On what criteria? With what biases?
  The model is only as good as the tiny labelled set it saw.
  Labelling at scale (millions of customers) is prohibitively expensive.
""")

# --- Scenario B: Use rule-based labels as training data ---
print("--- Scenario B: Train on rule-generated labels (using Rule V3) ---")
print("(A common hack: use the rule engine output as 'ground truth')\n")

# We use Rule V3 output as pseudo-labels, but exclude 'Unclassified'
labeled_by_rules = df_rules[df_rules['Rule_V3'] != 'Unclassified'].copy()
X_rule_train = labeled_by_rules[['Income', 'Age', 'Tech_Spend']]
y_rule_train = labeled_by_rules['Rule_V3']

dt_rules = DecisionTreeClassifier(max_depth=4, random_state=42)
dt_rules.fit(X_rule_train, y_rule_train)

# Predict on everyone including those the rules couldn't classify
preds_rule = dt_rules.predict(X_all)
acc_rule = (preds_rule == y_all).mean()

print(f"Trained on {len(labeled_by_rules)} rule-labelled samples.")
print(f"Accuracy against true segments: {acc_rule*100:.1f}%")
print(f"""
PROBLEM: The ML model inherits ALL the errors from the rule engine.
  If Rule V3 mislabelled a customer, the Decision Tree learned that mistake.
  This is 'garbage in, garbage out' — a classifier cannot be better
  than the labels it was trained on.
  You haven't solved the problem; you've just added a layer of complexity.
""")

# --- Scenario C: Full supervision (cheating — to show the upper bound) ---
print("--- Scenario C: Full supervision (CHEATING — using all true labels) ---")
print("(This is impossible in practice — shown only as theoretical upper bound)\n")

X_train, X_test, y_train, y_test = train_test_split(
    X_all, y_all, test_size=0.3, random_state=42, stratify=y_all
)
dt_full = DecisionTreeClassifier(max_depth=5, random_state=42)
dt_full.fit(X_train, y_train)
preds_full = dt_full.predict(X_test)
acc_full = (preds_full == y_test).mean()

print(f"Accuracy with full labels (impossible in real life): {acc_full*100:.1f}%")
print("""
Even with perfect labels, supervised ML is the WRONG tool here because:
  → In real segmentation there ARE no pre-defined labels.
  → Adding a new customer type requires re-labelling and re-training.
  → The model can only predict segments it was trained on — it cannot
     discover new, unexpected customer patterns.
""")

input("Press ENTER to see Approach 3: Clustering (Unsupervised)...")

# ============================================================
# APPROACH 3: K-MEANS CLUSTERING (UNSUPERVISED)
# ============================================================
print("\n" + "=" * 65)
print("  APPROACH 3: K-MEANS CLUSTERING")
print("=" * 65)
print("""
K-Means asks one simple question:
  'Given these data points, what is the most natural way to group them?'

No labels needed. No rules written. No human bias baked in.
The algorithm finds the structure that is already in the data.

HOW K-MEANS WORKS (intuition):
  1. Randomly place K 'centroids' (cluster centres) in the data space.
  2. Assign every customer to the nearest centroid.
  3. Move each centroid to the average position of its assigned customers.
  4. Repeat steps 2-3 until assignments stop changing.

The result: K groups where customers within a group are as similar
as possible, and customers across groups are as different as possible.
""")

# Features only — the algorithm never sees True_Segment
features = df[['Income', 'Age', 'Tech_Spend']]

# Scale to 0-1 so Income (0-120k) doesn't overpower Age (18-60)
# Without scaling, a $1 difference in income would count more than
# a 40-year difference in age, simply because the units are different.
scaler = MinMaxScaler()
scaled_features = scaler.fit_transform(features)

print("Step 1: Features scaled to [0, 1] range so all dimensions are equal.")
print(f"  Income range before scaling: {features['Income'].min()} – {features['Income'].max()}")
print(f"  Age range before scaling:    {features['Age'].min()} – {features['Age'].max()}")
print("  After scaling both are 0.0 – 1.0, so neither dominates the distance calculation.\n")

# --- Finding the right K using the Elbow Method ---
print("Step 2: Finding the right number of clusters using the Elbow Method.")
print("  We run K-Means for K=1..8 and plot the inertia (total within-cluster variance).")
print("  The 'elbow' — where adding more clusters gives diminishing returns — is our K.\n")

inertias = []
k_range = range(1, 9)
for k in k_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(scaled_features)
    inertias.append(km.inertia_)

plt.figure(figsize=(8, 4))
plt.plot(k_range, inertias, 'bo-', linewidth=2, markersize=8)
plt.axvline(x=3, color='red', linestyle='--', label='Chosen K=3 (elbow)')
plt.title('Elbow Method — Choosing the Number of Clusters', fontsize=13, fontweight='bold')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('Inertia (Within-Cluster Variance)')
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()
print("  The curve bends sharply at K=3 — strong evidence of 3 natural groups.\n")

# --- Run K-Means with K=3 ---
print("Step 3: Running K-Means with K=3...")
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
df['Cluster_ID'] = kmeans.fit_predict(scaled_features)

# Describe each discovered cluster by its mean feature values
cluster_profiles = df.groupby('Cluster_ID')[['Income', 'Age', 'Tech_Spend']].mean().round(0)
print("\nCluster profiles discovered (NO labels used):")
print(cluster_profiles)

# Map cluster IDs to descriptive names based on the profile
# (This naming step is the only human judgement required — and it's done AFTER discovery)
cluster_name_map = {}
for cid, row in cluster_profiles.iterrows():
    if row['Income'] > 70_000:
        cluster_name_map[cid] = 'Executive'
    elif row['Tech_Spend'] < 1_000:
        cluster_name_map[cid] = 'Saver'
    else:
        cluster_name_map[cid] = 'Student'

df['Cluster_Name'] = df['Cluster_ID'].map(cluster_name_map)

print("\nClusters named by a human after reviewing the profiles:")
for cid, name in cluster_name_map.items():
    print(f"  Cluster {cid} → '{name}'")

print("""
IMPORTANT: The algorithm discovered the groups.
The human only gave them a name at the end.
This is fundamentally different from rule-based or supervised approaches
where the human has to define the groups upfront.
""")

# --- Verify against true segments ---
print("Step 4: Verifying against ground truth (which the algorithm never saw)...")
accuracy_clustering = (df['Cluster_Name'] == df['True_Segment']).mean()
print(f"\nClustering accuracy vs true segments: {accuracy_clustering*100:.1f}%")
print("\nCluster vs True Segment breakdown:")
print(pd.crosstab(df['True_Segment'], df['Cluster_Name']))

input("\nPress ENTER to see the visualisations and final comparison...")

# ============================================================
# VISUALISATIONS
# ============================================================

# --- Plot 1: Why rules fail — the Tech_Spend trap ---
fig, axes = plt.subplots(1, 2, figsize=(15, 6))
fig.suptitle('Why Single-Feature Rules Fail', fontsize=14, fontweight='bold')

colors_true = {'Student': '#3498db', 'Executive': '#e74c3c', 'Saver': '#2ecc71'}
for segment, grp in df.groupby('True_Segment'):
    axes[0].scatter(grp['Income'], grp['Tech_Spend'],
                    label=segment, color=colors_true[segment], s=80, alpha=0.8)
axes[0].set_title('True Segments (hidden in practice)', fontsize=11)
axes[0].set_xlabel('Income ($)')
axes[0].set_ylabel('Tech Spend ($)')
axes[0].axhline(y=1500, color='black', linestyle='--', linewidth=1.5, label='Rule threshold: $1500')
axes[0].legend()
axes[0].annotate('Students & Executives\nare IDENTICAL here!',
                 xy=(50000, 2250), fontsize=9, color='black',
                 bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.7))

# Rule V1 result — the failure
rule_colors = {'Tech Enthusiast': 'purple', 'Non-Tech': 'gray'}
for label, grp in df_rules.groupby('Rule_V1'):
    axes[1].scatter(grp['Income'], grp['Tech_Spend'],
                    label=label, color=rule_colors[label], s=80, alpha=0.8)
axes[1].set_title("Rule V1 Result: 'Tech_Spend > $1500'\n(Students + Executives merged!)", fontsize=11)
axes[1].set_xlabel('Income ($)')
axes[1].set_ylabel('Tech Spend ($)')
axes[1].axhline(y=1500, color='black', linestyle='--', linewidth=1.5)
axes[1].legend()

plt.tight_layout()
plt.show()

# --- Plot 2: Clustering result vs True segments ---
fig, axes = plt.subplots(1, 2, figsize=(15, 6))
fig.suptitle('Clustering vs Ground Truth', fontsize=14, fontweight='bold')

cluster_colors = {0: '#e74c3c', 1: '#3498db', 2: '#2ecc71'}
for cid, grp in df.groupby('Cluster_ID'):
    axes[0].scatter(grp['Income'], grp['Tech_Spend'],
                    label=f"Cluster {cid} ({cluster_name_map[cid]})",
                    color=cluster_colors[cid], s=80, alpha=0.8)
# Plot centroids
centers_original = scaler.inverse_transform(kmeans.cluster_centers_)
axes[0].scatter(centers_original[:, 0], centers_original[:, 2],
                s=250, c='black', marker='X', zorder=5, label='Centroids')
axes[0].set_title('K-Means Clustering Result\n(No labels used)', fontsize=11)
axes[0].set_xlabel('Income ($)')
axes[0].set_ylabel('Tech Spend ($)')
axes[0].legend()

for segment, grp in df.groupby('True_Segment'):
    axes[1].scatter(grp['Income'], grp['Tech_Spend'],
                    label=segment, color=colors_true[segment], s=80, alpha=0.8)
axes[1].set_title('True Segments (ground truth)\n(Hidden from algorithm)', fontsize=11)
axes[1].set_xlabel('Income ($)')
axes[1].set_ylabel('Tech Spend ($)')
axes[1].legend()

plt.tight_layout()
plt.show()

# --- Plot 3: 3D view — why clustering succeeds where rules fail ---
fig = plt.figure(figsize=(14, 6))
fig.suptitle('The 3D View Clustering Uses (Rules Only See 2D Slices)', fontsize=13, fontweight='bold')

ax1 = fig.add_subplot(121, projection='3d')
for cid, grp in df.groupby('Cluster_ID'):
    ax1.scatter(grp['Income'], grp['Age'], grp['Tech_Spend'],
                color=cluster_colors[cid], s=60, alpha=0.8,
                label=f"Cluster {cid} ({cluster_name_map[cid]})")
ax1.set_xlabel('Income')
ax1.set_ylabel('Age')
ax1.set_zlabel('Tech Spend')
ax1.set_title('Clustering sees ALL dimensions\nsimultaneously')
ax1.legend(fontsize=8)

ax2 = fig.add_subplot(122, projection='3d')
for segment, grp in df.groupby('True_Segment'):
    ax2.scatter(grp['Income'], grp['Age'], grp['Tech_Spend'],
                color=colors_true[segment], s=60, alpha=0.8, label=segment)
ax2.set_xlabel('Income')
ax2.set_ylabel('Age')
ax2.set_zlabel('Tech Spend')
ax2.set_title('True Segments\n(ground truth)')
ax2.legend(fontsize=8)

plt.tight_layout()
plt.show()

# ============================================================
# FINAL COMPARISON SUMMARY
# ============================================================
print("\n" + "=" * 65)
print("  FINAL COMPARISON")
print("=" * 65)

summary = pd.DataFrame({
    'Approach': [
        'Rule-Based (V3)',
        'Supervised ML (small labels)',
        'Supervised ML (rule labels)',
        'Supervised ML (cheat — full labels)',
        'K-Means Clustering'
    ],
    'Labels Required': ['None (but rules = hidden labels)', 'Yes — 25% manually labelled',
                        'Yes — from rule engine', 'Yes — ALL data labelled', 'NONE'],
    'Accuracy': [
        f"{correct_v3/len(df)*100:.1f}%",
        f"{acc_small*100:.1f}%",
        f"{acc_rule*100:.1f}%",
        f"{acc_full*100:.1f}%",
        f"{accuracy_clustering*100:.1f}%"
    ]
})

print(summary.to_string(index=False))

print(f"""
KEY TAKEAWAYS
=============

1.  RULE-BASED FAILS because:
    - Thresholds are arbitrary and brittle.
    - Rules encode human assumptions (we only find what we expect).
    - Every new feature combination requires new rules.
    - Produces 'Unclassified' buckets when reality doesn't fit the rules.

2.  SUPERVISED ML FAILS HERE because:
    - The whole point is to DISCOVER segments — we can't label what we
      don't yet know exists.
    - Using rule-based labels just inherits all their errors.
    - Cannot detect NEW, previously unknown customer types.

3.  CLUSTERING WINS because:
    - Requires ZERO labels — no human bias baked in upfront.
    - Finds natural groupings across ALL features simultaneously.
    - In 3D (Income × Age × Tech_Spend), Students and Executives
      separate cleanly — even though Tech_Spend alone cannot tell them apart.
    - Discovers segments you didn't know existed — a huge advantage
      in real-world marketing, fraud detection, and anomaly detection.
    - Scales to hundreds of features without rewriting any logic.

4.  WHEN TO USE EACH:
    - Rules:          You have strong domain knowledge AND the segments
                      are simple, stable, and legally must be explainable.
    - Supervised ML:  You already HAVE labelled examples (e.g. spam/not-spam).
    - Clustering:     You want to DISCOVER structure from unlabelled data —
                      customer segmentation, document grouping, anomaly detection.
""")
