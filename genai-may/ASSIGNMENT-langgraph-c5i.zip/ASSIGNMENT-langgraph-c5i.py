"""
╔══════════════════════════════════════════════════════════════════════════════╗
║      LANGGRAPH ASSIGNMENT — C5i Competitive Intelligence Pipeline Agent     ║
╚══════════════════════════════════════════════════════════════════════════════╝

OVERVIEW
────────
You will build a Competitive Intelligence (CI) pipeline agent for C5i Analytics.
The agent accepts a raw news article or press release, extracts structured event
data, classifies its strategic priority, routes it through a specialised analysis
pathway, and produces a client-ready CI brief section.

The workflow mirrors C5i's real analyst process:
  1. Intake       → extract structured competitive event data from the article
  2. Completeness → do we have enough CI information to analyse?  (retry if not)
  3. Routing      → classify priority: HIGH_IMPACT / MONITOR / ROUTINE
  4. Pathway      → specialised analysis per priority level (three branches)
  5. Brief Section→ unified CI brief section from the pathway output
  6. Recommend    → final client recommendation + action items

This assignment reinforces every LangGraph construct from the stock demo:

  ┌─────────────────────────────────────────────────────────────────────┐
  │  Construct          │  Where it appears in THIS file                │
  ├─────────────────────────────────────────────────────────────────────┤
  │  TypedDict State    │  ArticleState  (partial — you complete it)    │
  │  Nodes              │  6 node functions  (stubs — you implement)    │
  │  Conditional Edges  │  2 routing functions  (you implement both)    │
  │  Cycle / Retry      │  route_after_completeness  (you wire it)      │
  │  Branching          │  route_after_routing_agent  (you wire it)     │
  │  Graph Assembly     │  build_graph()  (skeleton — you complete)     │
  └─────────────────────────────────────────────────────────────────────┘

TARGET GRAPH TOPOLOGY
─────────────────────

    [START]
       │
       ▼
  intake_node ◄──────────────────────────────────────────────────────┐
       │                                                               │ (retry)
       ▼                                                               │
  completeness_check_node ──── route_after_completeness ─────────────┘
       │ (sufficient)
       ▼
  routing_agent_node ── route_after_routing_agent ──► high_impact_node ──┐
                                                   ──► monitor_node      ──┤
                                                   ──► routine_node      ──┤
                                                           │
                                                           ▼
                                                    brief_section_node
                                                           │
                                                           ▼
                                               client_recommendation_node
                                                           │
                                                           ▼
                                                         [END]

WHAT IS PROVIDED (do NOT modify these)
───────────────────────────────────────
  ✓  All imports
  ✓  Environment / LLM setup helpers
  ✓  intake_node          — study this carefully; it shows the node pattern
  ✓  completeness_check_node — shows the LLM quality-gate pattern
  ✓  main()               — entry point; runs when you run this file

WHAT YOU MUST IMPLEMENT  (search for TODO in this file)
────────────────────────────────────────────────────────
  TODO 1  ArticleState  — add three missing fields to the state TypedDict
  TODO 2  routing_agent_node — LLM routing agent: classify priority + capture reasoning
  TODO 3  high_impact_node — immediate strategic alert + deep competitive analysis
  TODO 4  monitor_node   — trend-tracking + watch-list protocol
  TODO 5  routine_node   — standard event logging + summary
  TODO 6  brief_section_node — merge pathway output into a structured CI brief section
  TODO 7  client_recommendation_node — final action items and client recommendations
  TODO 8  route_after_completeness — routing function (retry loop)
  TODO 9  route_after_routing_agent — routing function (three-way branch)
  TODO 10 build_graph()  — wire all nodes and edges; compile

GRADING CRITERIA
────────────────
  • The graph compiles without errors                          (10 pts)
  • The Mermaid diagram printed at startup matches the topology above (10 pts)
  • The retry loop works: incomplete input loops back          (20 pts)
  • All three priority branches are reached by matching input (20 pts)
  • brief_section_node produces a structured CI brief section  (20 pts)
  • client_recommendation_node produces clear action items    (20 pts)

REFERENCE — key LangGraph API calls you will use
──────────────────────────────────────────────────
  graph = StateGraph(ArticleState)
  graph.add_node("node_name", lambda s: my_function(s, llm))
  graph.set_entry_point("first_node")
  graph.add_edge("from_node", "to_node")
  graph.add_conditional_edges("from_node", routing_fn, {"key": "target_node"})
  graph.add_edge("last_node", END)
  compiled = graph.compile()
  compiled.get_graph().draw_mermaid()   ← prints the topology diagram
"""

# ──────────────────────────────────────────────────────────────────────────────
# IMPORTS  (do not modify)
# ──────────────────────────────────────────────────────────────────────────────
import os
from pathlib import Path
from typing import TypedDict, Literal

from dotenv import load_dotenv
from pydantic import BaseModel, Field
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END


# ──────────────────────────────────────────────────────────────────────────────
# ENVIRONMENT SETUP  (do not modify)
# ──────────────────────────────────────────────────────────────────────────────

def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env in any parent directory.")
    exit(1)


PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

MAX_RETRIES = 2   # maximum completeness retries before proceeding anyway


def build_llm() -> AzureChatOpenAI:
    return AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        temperature=0,
    )


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 1 — STATE
#
# ArticleState is the single typed container shared across every node.
# Every node receives the full state and returns a PARTIAL dict of updates.
# LangGraph merges those updates into the state before calling the next node.
#
# Field naming convention used here:
#   - Input fields   : set once at the start, never overwritten
#   - Pipeline fields: set by a specific node, read by later nodes
#   - Output fields  : set near the end; form the final answer
# ──────────────────────────────────────────────────────────────────────────────

class ArticleState(TypedDict):
    # ── Input ──────────────────────────────────────────────────────────────
    raw_article_text: str              # raw news article or press release

    # ── Set by intake_node ─────────────────────────────────────────────────
    structured_event_data: str         # structured extraction (company, event type, date, geography)
    retry_count: int                   # tracks how many completeness retries have occurred

    # ── Set by completeness_check_node ─────────────────────────────────────
    is_complete: bool                  # True if enough CI info to classify priority

    # ── TODO 1 ─────────────────────────────────────────────────────────────
    # Add three more fields that the CI pipeline needs:
    #
    #   Field A:  the priority classification produced by routing_agent_node.
    #             It must be one of three specific string literals so that
    #             the routing function can do an exact-match comparison.
    #             Hint: use  Literal["high_impact", "monitor", "routine", "unknown"]
    #
    #   Field B:  the pathway-specific analysis produced by whichever of the
    #             three branch nodes runs (high_impact / monitor / routine).
    #             It is a plain string containing the pathway-specific output.
    #
    #   Field C:  the LLM's strategic reasoning behind the routing decision,
    #             returned by routing_agent_node alongside priority_level.
    #             Stored so downstream nodes (e.g. brief_section_node) can use it.
    #             It is a plain string.
    #
    # Example skeleton (fill in the types):
    #   priority_level:    ???
    #   pathway_output:    ???
    #   routing_reasoning: ???
    #
    # YOUR CODE HERE ↓

    # ── Set by brief_section_node and client_recommendation_node ──────────
    brief_section: str                 # structured CI brief section
    client_recommendation: str         # final action items and recommended next steps


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 2 — NODES
#
# Each node is a plain Python function:
#     def my_node(state: ArticleState) -> dict:
#         ...
#         return {"field_to_update": new_value}
#
# Rules:
#   • Accept the full state; return ONLY the keys you are updating.
#   • Never mutate the state dict directly — always return a new dict.
#   • If your node needs the LLM, accept it as a second parameter and
#     bind it in build_graph() with:  lambda s: my_node(s, llm)
# ──────────────────────────────────────────────────────────────────────────────

# ── PROVIDED: intake_node ─────────────────────────────────────────────────────
# Study this node carefully — it shows the complete pattern.
def intake_node(state: ArticleState, llm: AzureChatOpenAI) -> dict:
    """
    Extract and structure the key competitive intelligence data from the raw
    article text.  This is the entry point of the graph.

    Updates: structured_event_data, retry_count
    """
    print(f"\n[intake_node] Extracting CI event data "
          f"(attempt {state['retry_count'] + 1})...")

    messages = [
        SystemMessage(content=(
            "You are a Competitive Intelligence extraction specialist at C5i Analytics. "
            "Extract and structure the key CI facts from the article provided. "
            "Format your response as:\n"
            "  Company Name: ...\n"
            "  Company Type: competitor | partner | client | unknown\n"
            "  Sector: ...\n"
            "  Event Type: product_launch | acquisition | partnership | executive_change | "
            "funding | market_exit | pricing_change | regulatory | other\n"
            "  Event Summary: ...\n"
            "  Event Date: YYYY-MM-DD or Not mentioned\n"
            "  Geography: ...\n"
            "  Key Quote: ...\n"
            "  Missing Critical Information: ...\n"
            "If a field is not mentioned, write 'Not reported'."
        )),
        HumanMessage(content=state["raw_article_text"]),
    ]
    structured = llm.invoke(messages).content.strip()
    print(f"  → Structured:\n{structured[:300]}...")

    return {
        "structured_event_data": structured,
        "retry_count": state["retry_count"] + 1,
    }


# ── PROVIDED: completeness_check_node ────────────────────────────────────────
# This node shows the LLM-as-quality-gate pattern.
def completeness_check_node(state: ArticleState, llm: AzureChatOpenAI) -> dict:
    """
    Assess whether the structured event data contains enough CI information
    to make a reliable priority classification.

    Minimum required: at least one named company + a concrete action or event
    (not just vague market commentary).

    Updates: is_complete

    HINT for TODO 8 — this node's output (is_complete) is what your
    route_after_completeness function should inspect.
    """
    print("[completeness_check_node] Checking CI data completeness...")

    # Fast-path: if structured_event_data is empty or trivially short, it is incomplete
    if not state["structured_event_data"] or len(state["structured_event_data"]) < 80:
        print("  → Incomplete (too short)")
        return {"is_complete": False}

    messages = [
        SystemMessage(content=(
            "You are a CI data quality reviewer at C5i Analytics. "
            "Determine whether the extracted event data contains enough information "
            "to classify its strategic priority: it must name at least one company "
            "and describe a concrete business action (acquisition, launch, price change, "
            "leadership move, etc.). Vague market commentary without a named actor is "
            "NOT sufficient. "
            "Reply with only YES or NO."
        )),
        HumanMessage(content=state["structured_event_data"]),
    ]
    answer = llm.invoke(messages).content.strip().upper()
    complete = answer.startswith("YES")
    print(f"  → Complete: {complete}")
    return {"is_complete": complete}


# ── TODO 2 — routing_agent_node ──────────────────────────────────────────────
#
# WHY A ROUTING AGENT NODE INSTEAD OF A PLAIN CLASSIFIER NODE?
# ─────────────────────────────────────────────────────────────
# A naive approach asks the LLM for a single word ("HIGH_IMPACT"), then parses
# the string with if/elif.  This works but has two problems:
#   1. The routing decision is invisible — it's consumed by the node and the
#      only trace is the priority_level field, with no explanation of why.
#   2. String parsing is fragile ("HIGH_IMPACT." vs "HIGH IMPACT" vs "High").
#
# The LLM Routing Agent pattern fixes both:
#   • Use with_structured_output(PriorityDecision) — the LLM returns a validated
#     Pydantic object, never a free-form string that needs parsing.
#   • The object contains BOTH the routing key AND the strategic reasoning.
#   • Both are stored in state, so downstream nodes and the final output can
#     explain HOW the priority level was determined.
#
# LangGraph routing functions (the functions passed to add_conditional_edges)
# must be fast, pure, and side-effect-free — no LLM calls inside them.
# The LLM call belongs here, in a NODE.  The routing function simply reads
# the decision that this node already wrote to state.
#
# PROVIDED — PriorityDecision schema (do not modify)
# ─────────────────────────────────────────────────
# This Pydantic model is the structured output contract between the LLM and
# the rest of the graph.  with_structured_output will validate that the LLM
# always returns exactly these two fields with the correct types.

class PriorityDecision(BaseModel):
    priority_level: Literal["high_impact", "monitor", "routine"] = Field(
        description=(
            "Strategic priority classification: "
            "'high_impact' = major competitive move requiring immediate client alert "
            "(acquisition, significant market entry, executive leadership change at C-suite); "
            "'monitor' = notable development to track but no immediate client action needed "
            "(pilot programme, rumoured deal, minor product launch); "
            "'routine' = standard market activity for periodic reporting "
            "(minor variant discontinuation, scheduled results, incremental pricing tweak)."
        )
    )
    reasoning: str = Field(
        description=(
            "2-3 sentence strategic rationale explaining which specific facts "
            "or signals drove this priority classification and why it matters "
            "(or does not matter) to C5i's clients."
        )
    )


def routing_agent_node(state: ArticleState, llm: AzureChatOpenAI) -> dict:
    """
    LLM Routing Agent — classifies strategic priority and captures the reasoning.

    Uses llm.with_structured_output(PriorityDecision) so the LLM returns a
    validated PriorityDecision object (not free text).

    Updates: priority_level, routing_reasoning

    HINT — create a structured-output LLM like this:
        routing_llm = llm.with_structured_output(PriorityDecision)

    HINT — invoke it exactly like a regular LLM:
        decision: PriorityDecision = routing_llm.invoke([
            SystemMessage(content="You are a Senior CI Analyst at C5i Analytics..."),
            HumanMessage(content=state["structured_event_data"]),
        ])

    HINT — decision.priority_level is already lowercase ("high_impact" / "monitor" /
    "routine") because Pydantic validates it against the Literal type.
    No if/elif parsing needed.

    HINT — return BOTH fields so they are available to downstream nodes:
        return {
            "priority_level":    decision.priority_level,
            "routing_reasoning": decision.reasoning,
        }
    """
    print("[routing_agent_node] LLM routing agent classifying CI priority...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 2: implement routing_agent_node")


# ── TODO 3 — high_impact_node ────────────────────────────────────────────────
def high_impact_node(state: ArticleState, llm: AzureChatOpenAI) -> dict:
    """
    Reached ONLY when priority_level == "high_impact".

    Generate an immediate strategic alert covering:
      1. What happened — the core competitive event in 1-2 sentences
      2. Why it matters — strategic implications for C5i's clients in this sector
      3. Affected clients — which client verticals / categories are most exposed
      4. Recommended immediate actions — what clients should do in the next 48 hours

    Updates: pathway_output

    HINT — frame the LLM as a Senior CI Analyst at C5i writing an urgent
    alert bulletin for client distribution within the hour.

    HINT — use state["structured_event_data"] for the CI input.
    """
    print("[high_impact_node] Generating HIGH IMPACT strategic alert...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 3: implement high_impact_node")


# ── TODO 4 — monitor_node ────────────────────────────────────────────────────
def monitor_node(state: ArticleState, llm: AzureChatOpenAI) -> dict:
    """
    Reached ONLY when priority_level == "monitor".

    Generate a watch-list tracking note covering:
      1. Event summary — what was reported and how credible the signal is
      2. Why to watch — what this could become if confirmed or expanded
      3. Signals to track — specific data points, announcements, or dates to monitor
      4. Client relevance — which clients should be made aware and why

    Updates: pathway_output

    HINT — frame the LLM as a CI Analyst writing a weekly tracker entry
    for the C5i internal watch-list database.
    """
    print("[monitor_node] Generating MONITOR watch-list entry...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 4: implement monitor_node")


# ── TODO 5 — routine_node ────────────────────────────────────────────────────
def routine_node(state: ArticleState, llm: AzureChatOpenAI) -> dict:
    """
    Reached ONLY when priority_level == "routine".

    Generate a standard event log entry covering:
      1. Event log line — one-line summary for the CI database
      2. Classification — event_type, company_type, confidence level
      3. Periodic report note — which monthly/quarterly brief this belongs in
      4. No-action rationale — why no immediate client alert is needed

    Updates: pathway_output

    HINT — frame the LLM as a CI data analyst logging the event into
    C5i's structured competitive event tracker.
    """
    print("[routine_node] Generating ROUTINE event log entry...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 5: implement routine_node")


# ── TODO 6 — brief_section_node ──────────────────────────────────────────────
def brief_section_node(state: ArticleState, llm: AzureChatOpenAI) -> dict:
    """
    Convergence point — all three pathway branches flow into this node.

    Synthesise the pathway_output into a formal CI brief section using
    this exact format:

      PRIORITY LEVEL: <HIGH IMPACT | MONITOR | ROUTINE>
      ─────────────────────────────────────────────────
      COMPANY / EVENT:
        ...
      EVENT SUMMARY:
        ...
      STRATEGIC SIGNIFICANCE:
        ...
      CLIENT IMPACT:
        ...
      RECOMMENDED ACTIONS:
        1. ...
        2. ...
      CONFIDENCE: <high | medium | low>

    Updates: brief_section

    HINT — you have access to both state["pathway_output"] (the branch analysis)
    and state["structured_event_data"] (the structured CI extraction).
    Use both to make the brief section concrete and client-specific.
    """
    print("[brief_section_node] Synthesising CI brief section...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 6: implement brief_section_node")


# ── TODO 7 — client_recommendation_node ─────────────────────────────────────
def client_recommendation_node(state: ArticleState, llm: AzureChatOpenAI) -> dict:
    """
    Final node — produces the client-facing recommendation and action items.

    Structure your output as:

      CLIENT RECOMMENDATION
      ──────────────────────
      Priority:               <HIGH IMPACT | MONITOR | ROUTINE>
      What happened:          ...
      Why it matters to you:  ...
      Recommended actions:    ...
      Watch for:              ...
      Next review:            ...

    This is what gets sent to the C5i client (or included in the weekly brief).

    Updates: client_recommendation

    HINT — use state["brief_section"] as your input.  The LLM should translate
    the analyst brief section into clear, commercially actionable client language.
    """
    print("[client_recommendation_node] Generating final client recommendation...")

    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 7: implement client_recommendation_node")


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 3 — CONDITIONAL EDGES  (routing functions)
#
# A routing function:
#   • Accepts the full state
#   • Returns a STRING key
#   • The key is looked up in the mapping dict you provide to
#     graph.add_conditional_edges() to find the next node
#
# Return type annotation ( Literal["a", "b"] ) is optional but recommended —
# it documents the possible return values for the reader.
# ──────────────────────────────────────────────────────────────────────────────

# ── TODO 8 — route_after_completeness ────────────────────────────────────────
def route_after_completeness(state: ArticleState) -> Literal["retry", "continue"]:
    """
    Implements the RETRY LOOP.

    Decision logic:
      • If is_complete is False AND retry_count < MAX_RETRIES → return "retry"
        (routes back to intake_node for another attempt)
      • Otherwise → return "continue"
        (routes forward to routing_agent_node, even if still incomplete, to avoid
        infinite loops)

    Print a message explaining which branch was chosen — it helps during debugging.

    HINT — the mapping you will pass to add_conditional_edges():
        {
            "retry":    "intake_node",
            "continue": "routing_agent_node",
        }
    """
    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 8: implement route_after_completeness")


# ── TODO 9 — route_after_routing_agent ───────────────────────────────────────
def route_after_routing_agent(state: ArticleState) -> Literal["high_impact", "monitor", "routine"]:
    """
    Implements the THREE-WAY BRANCH based on the routing agent's decision.

    This function is intentionally trivial — all the intelligence already
    happened inside routing_agent_node (the LLM call + structured output).
    The routing function's only job is to dispatch: read priority_level from
    state and return it as the routing key.

    HINT — routing functions must be pure and side-effect-free (no LLM calls).
    The LLM call belongs in routing_agent_node, not here.

    HINT — routing_agent_node used with_structured_output(PriorityDecision),
    which validates priority_level against Literal["high_impact","monitor","routine"].
    So state["priority_level"] is already a valid key — no if/elif needed.
    You may add a fallback guard for the "unknown" sentinel just in case.

    HINT — also print state["routing_reasoning"] so you can see the LLM's
    rationale for the routing decision in the console output.

    HINT — the mapping you will pass to add_conditional_edges():
        {
            "high_impact": "high_impact_node",
            "monitor":     "monitor_node",
            "routine":     "routine_node",
        }
    """
    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 9: implement route_after_routing_agent")


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 4 — GRAPH ASSEMBLY
#
# Wire all nodes and edges into a StateGraph, then compile it.
# ──────────────────────────────────────────────────────────────────────────────

# ── TODO 10 — build_graph ─────────────────────────────────────────────────────
def build_graph(llm: AzureChatOpenAI):
    """
    Assemble the CI pipeline graph.

    Step-by-step instructions
    ─────────────────────────
    1. Create the graph:
           graph = StateGraph(ArticleState)

    2. Register all nodes.  Nodes that need the LLM must be wrapped in a lambda
       so their signature is (state) -> dict as LangGraph requires:
           graph.add_node("intake_node",             lambda s: intake_node(s, llm))
           graph.add_node("completeness_check_node", lambda s: completeness_check_node(s, llm))
           graph.add_node("routing_agent_node",      lambda s: routing_agent_node(s, llm))
           graph.add_node("high_impact_node",        lambda s: high_impact_node(s, llm))
           # ... add the remaining four nodes

    3. Set the entry point (the first node the graph will call):
           graph.set_entry_point("intake_node")

    4. Add a linear edge from intake_node to completeness_check_node:
           graph.add_edge("intake_node", "completeness_check_node")

    5. Add CONDITIONAL EDGE #1 — retry loop:
           graph.add_conditional_edges(
               "completeness_check_node",      # source node
               route_after_completeness,       # routing function
               {
                   "retry":    "intake_node",          # loop back
                   "continue": "routing_agent_node",   # LLM routing agent decides next
               },
           )

    6. Add CONDITIONAL EDGE #2 — three-way branch:
           graph.add_conditional_edges(
               "routing_agent_node",
               route_after_routing_agent,
               {
                   "high_impact": "high_impact_node",
                   "monitor":     "monitor_node",
                   "routine":     "routine_node",
               },
           )

    7. All three branches converge at brief_section_node:
           graph.add_edge("high_impact_node", "brief_section_node")
           graph.add_edge("monitor_node",     "brief_section_node")
           graph.add_edge("routine_node",     "brief_section_node")

    8. Linear tail — brief_section → client_recommendation → END:
           graph.add_edge("brief_section_node",        "client_recommendation_node")
           graph.add_edge("client_recommendation_node", END)

    9. Compile and return:
           return graph.compile()
    """
    # YOUR CODE HERE ↓
    raise NotImplementedError("TODO 10: implement build_graph()")


# ──────────────────────────────────────────────────────────────────────────────
# MAIN  (do not modify)
# ──────────────────────────────────────────────────────────────────────────────

SAMPLE_INPUTS = {
    "high_impact": (
        "Mumbai, 14 March 2026 — Hindustan Unilever Limited today announced the "
        "acquisition of Havmor Ice Cream Pvt. Ltd. for ₹2,400 crore, marking its "
        "first foray into the premium Indian frozen desserts segment. The deal is "
        "expected to close in Q3 2026 pending CCI approval. In a separate "
        "development, HUL confirmed that MD Sanjiv Mehta will transition to an "
        "advisory role effective 1 June 2026, with Rohit Jawa appointed as MD & CEO."
    ),
    "monitor": (
        "Industry sources suggest Reliance Retail may be in advanced talks to acquire "
        "a majority stake in a leading quick-commerce startup, though no official "
        "announcement has been made. The deal, if confirmed, could value the startup "
        "at upwards of $500 million and significantly bolster Reliance's last-mile "
        "delivery capability ahead of the festive season."
    ),
    "routine": (
        "Marico quietly discontinued its Parachute Advansed Jasmine hair oil variant "
        "from modern trade channels in Maharashtra. The SKU accounted for a small "
        "fraction of Parachute Advansed's overall sales. No official statement was "
        "issued by the company."
    ),
    "incomplete": (
        # Intentionally vague — should trigger the retry loop
        "There are some changes happening in the FMCG sector."
    ),
}


def main():
    print("\n╔══════════════════════════════════════════════════════╗")
    print("║   LangGraph C5i Competitive Intelligence Pipeline   ║")
    print("╚══════════════════════════════════════════════════════╝")

    llm = build_llm()
    app = build_graph(llm)

    # ── Print graph topology (Mermaid) ─────────────────────────────────────
    print("\n── Graph Topology (Mermaid) ──")
    print(app.get_graph().draw_mermaid())

    # ── Choose input mode ──────────────────────────────────────────────────
    print("\nInput options:")
    print("  [1] Paste your own article or news snippet")
    print("  [2] Run sample HIGH IMPACT case  (HUL acquisition)")
    print("  [3] Run sample MONITOR case      (Reliance quick-commerce rumour)")
    print("  [4] Run sample ROUTINE case      (Marico SKU discontinuation)")
    print("  [5] Run INCOMPLETE case          (tests the retry loop)")
    choice = input("\nChoose [1-5]: ").strip()

    if choice == "1":
        article_text = input("Paste article text: ").strip()
    elif choice == "2":
        article_text = SAMPLE_INPUTS["high_impact"]
        print(f"\nUsing HIGH IMPACT sample:\n  {article_text[:80]}...")
    elif choice == "3":
        article_text = SAMPLE_INPUTS["monitor"]
        print(f"\nUsing MONITOR sample:\n  {article_text[:80]}...")
    elif choice == "4":
        article_text = SAMPLE_INPUTS["routine"]
        print(f"\nUsing ROUTINE sample:\n  {article_text[:80]}...")
    elif choice == "5":
        article_text = SAMPLE_INPUTS["incomplete"]
        print(f"\nUsing INCOMPLETE sample:\n  '{article_text}'")
    else:
        print("Invalid choice — using MONITOR sample.")
        article_text = SAMPLE_INPUTS["monitor"]

    if not article_text:
        print("ERROR: No article text provided.")
        exit(1)

    # ── Build initial state ────────────────────────────────────────────────
    initial_state: ArticleState = {
        "raw_article_text":    article_text,
        "structured_event_data": "",
        "retry_count":         0,
        "is_complete":         False,
        "priority_level":      "unknown",
        "pathway_output":      "",
        "brief_section":       "",
        "client_recommendation": "",
    }

    # ── Run the graph ──────────────────────────────────────────────────────
    print("\n── Running CI Pipeline ──\n")
    final_state = app.invoke(initial_state)

    # ── Display results ────────────────────────────────────────────────────
    print("\n" + "═" * 60)
    print("CI PIPELINE RESULT")
    print("═" * 60)
    print(f"Priority Level : {final_state['priority_level'].upper()}")
    print(f"Intake Retries : {final_state['retry_count'] - 1}")   # -1 because first run is not a retry
    print()
    print("── CI BRIEF SECTION ──")
    print(final_state["brief_section"])
    print()
    print("── CLIENT RECOMMENDATION ──")
    print(final_state["client_recommendation"])
    print("═" * 60)


if __name__ == "__main__":
    main()


# ──────────────────────────────────────────────────────────────────────────────
# EXTENSION CHALLENGES  (optional, for fast finishers)
# ──────────────────────────────────────────────────────────────────────────────
#
# CHALLENGE A — Checkpointing (session continuity)
#   Add a MemorySaver checkpointer to build_graph() so that graph state is
#   persisted between calls.  Then modify main() to accept a session_id so
#   the same CI session can be resumed (e.g., to add follow-up articles).
#   Reference: from langgraph.checkpoint.memory import MemorySaver
#              app = graph.compile(checkpointer=MemorySaver())
#              config = {"configurable": {"thread_id": "ci-session-001"}}
#              app.invoke(state, config=config)
#
# CHALLENGE B — Streaming Output
#   Replace app.invoke() in main() with app.stream() to print each node's
#   output as it is produced rather than waiting for the full pipeline.
#   Reference:
#       for event in app.stream(initial_state):
#           node_name, node_output = next(iter(event.items()))
#           print(f"\n[{node_name}] output: {str(node_output)[:200]}")
#
# CHALLENGE C — Multi-Article Batch Mode
#   Instead of processing a single article, accept a list of articles and
#   fan them out across parallel graph invocations.  Collect all brief
#   sections and feed them into a final aggregation node that generates a
#   complete weekly CI brief (Executive Summary + all events).
#
# CHALLENGE D — Confidence-Based Escalation
#   After brief_section_node, add a conditional edge:
#     • If priority_level is "high_impact" AND confidence is "low"
#       (because the article was incomplete but MAX_RETRIES was hit)
#       → escalation_node (flags the item for human analyst review)
#     • Otherwise → client_recommendation_node directly
#   This adds a second conditional edge and a human-in-the-loop branch.
