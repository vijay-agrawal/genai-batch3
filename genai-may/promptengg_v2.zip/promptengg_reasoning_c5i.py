"""
promptengg_reasoning_c5i.py
───────────────────────────────────────────────────────────────────────────────
Prompt Engineering demos — Reasoning & Summarization using Azure OpenAI.
C5i Analytics — Weekly Market Monitor pipeline context.

WHAT THIS FILE COVERS
─────────────────────
1.  Reasoning Types    — deductive, inductive, abductive, analogical
2.  Summarization      — extractive vs abstractive

Run: python promptengg_reasoning_c5i.py
Prereqs: .env with AZURE_OPENAI_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_MODEL_NAME
"""

import os
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv


def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env in any parent directory.")
    exit(1)

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# ── Azure OpenAI client ───────────────────────────────────────────────────────
client = OpenAI(
    base_url=os.getenv("AZURE_OPENAI_OPENAI_ENDPOINT", ""),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)
MODEL = os.getenv("AZURE_OPENAI_MODEL_NAME")

# ── ANSI colours for readable console output ─────────────────────────────────
CYAN   = "\033[1;36m"
GREEN  = "\033[1;32m"
YELLOW = "\033[1;33m"
RED    = "\033[1;31m"
MAGENTA= "\033[1;35m"
WHITE  = "\033[1;97m"   # bright bold white — used for scenario descriptions
RESET  = "\033[0m"


# ── Helper — call Azure OpenAI with configurable params ─────────────────────
def ask(
    user_prompt: str,
    system_prompt: str = "You are a helpful competitive intelligence analyst.",
    temperature: float = 0.7,
    max_tokens: int = 512,
) -> str:
    """
    Thin wrapper around the Azure OpenAI chat completions API.
    temperature : 0.0 = deterministic/factual,  1.0 = creative/varied
    max_tokens  : hard cap on output length
    """
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_prompt},
        ],
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return response.choices[0].message.content.strip()


def section(title: str):
    print(f"\n{'═'*66}")
    print(f"  {title}")
    print(f"{'═'*66}")

def label(tag: str, text: str, colour: str = CYAN):
    print(f"{colour}[{tag}]{RESET}")
    print(text.strip())
    print()

def pause():
    input(f"{CYAN}  ── Press Enter to continue ──{RESET}\n")

def scenario(text: str):
    """Print the demo description in prominent bright-white so it stands out."""
    print(f"{WHITE}")
    for line in text.strip().splitlines():
        print(f"  {line}")
    print(f"{RESET}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 1 — REASONING TYPES
#
# LLMs can be steered toward four distinct reasoning patterns by how you frame
# the prompt.  Understanding which type fits your task leads to more accurate,
# trustworthy outputs.
#
#  Deductive   — from general rules → certain conclusion     ("must be true")
#  Inductive   — from specific cases → probable general rule ("likely true")
#  Abductive   — from observation   → best explanation       ("probably caused by")
#  Analogical  — map known situation → new similar situation ("works like")
# ═══════════════════════════════════════════════════════════════════════════════
section("DEMO 1 — Reasoning Types  (Deductive / Inductive / Abductive / Analogical)")
scenario("""
LLMs can be steered toward four distinct reasoning patterns by how you frame
the prompt.  Choosing the right type leads to more accurate, trustworthy output.

  Deductive   — from general rules → certain conclusion     ("must be true")
  Inductive   — from specific cases → probable general rule ("likely true")
  Abductive   — from observation   → best explanation       ("probably caused by")
  Analogical  — map known situation → new similar situation ("works like")
""")

# ── Deductive reasoning ───────────────────────────────────────────────────────
# General rule + specific fact → certain conclusion.
# Best for: threat classification, escalation policy, automated CI triage.
deductive_prompt = """
Use deductive reasoning to answer the following.

Rule 1: Any competitor that acquires a last-mile delivery or quick-commerce asset
        in a category our client directly competes in must be classified as a
        TIER 1 THREAT requiring a board-level response within 30 days.

Rule 2: Any competitor that undergoes a C-suite leadership change (CEO/MD) within
        90 days of a major acquisition must be flagged for strategic intent
        re-assessment — new leadership may accelerate or redirect the acquired
        asset's deployment.

Fact: On 14 March 2026, HUL acquired Havmor Ice Cream for ₹2,400 crore, entering
      the premium frozen desserts segment. On 1 June 2026, HUL MD Sanjiv Mehta
      transitions to an advisory role; Rohit Jawa is appointed as MD & CEO.
      Our client is ITC Limited, which competes with HUL across biscuits, noodles,
      personal care, and staples but has no frozen desserts presence.

What conclusions can you draw with certainty about the threat classification and
required CI response actions? Walk through each rule explicitly.
"""
label("Deductive — prompt", deductive_prompt, YELLOW)
deductive_resp = ask(deductive_prompt, temperature=0.0, max_tokens=300)
label("Deductive — response (certain conclusions from rules)", deductive_resp, GREEN)
pause()

# ── Inductive reasoning ───────────────────────────────────────────────────────
# Specific observations → probable general pattern.
# Best for: spotting category-wide trends, forming market hypotheses.
inductive_prompt = """
Use inductive reasoning. You are given competitive observations across the
Indian FMCG sector during Q1 2026. Identify the most likely general pattern
or hypothesis.

Observations:
- Nestle India announced a 12% price increase for Maggi noodles citing wheat
  and palm oil cost inflation (March 2026).
- HUL raised prices on Surf Excel and Vim by 8–10% citing rising petrochemical
  feedstock costs (February 2026).
- Britannia increased biscuit prices by 6% across its premium range citing
  wheat flour cost increases (January 2026).
- ITC's FMCG division flagged commodity cost headwinds in its Q3 FY2026
  earnings call and hinted at selective pricing action.
- Dabur India implemented a 5% price increase on its fruit juice portfolio
  citing pulp and packaging cost increases (March 2026).

What general pattern or hypothesis do these observations suggest?
State your confidence level and what additional data would strengthen the hypothesis.
"""
label("Inductive — prompt", inductive_prompt, YELLOW)
inductive_resp = ask(inductive_prompt, temperature=0.0, max_tokens=300)
label("Inductive — response (probable pattern from cases)", inductive_resp, CYAN)
pause()

# ── Abductive reasoning ───────────────────────────────────────────────────────
# Incomplete observations → the single best / most likely explanation.
# Best for: inferring competitor strategic intent from fragmented signals.
abductive_prompt = """
Use abductive reasoning (inference to the best explanation).

The C5i intelligence team has observed the following Reliance Retail activities
over the past 6 months:
  • Hired 40+ dark store operations managers from Swiggy Instamart and Blinkit
  • Signed a distribution partnership with Delhivery covering 500+ Tier 2 cities
  • Quietly registered the trademark "JioMart Express" in India
  • Launched a pilot of 15-minute grocery delivery in Mumbai using 200 dark stores
  • Made a reported acquisition approach to a quick-commerce startup at $500M valuation
  • Increased JioMart app marketing spend by an estimated 3× quarter-on-quarter

Among all possible explanations, what is the single most likely strategic
intent behind these moves?
Explain why this explanation fits the evidence better than the alternatives.
"""
label("Abductive — prompt", abductive_prompt, YELLOW)
abductive_resp = ask(abductive_prompt, temperature=0.0, max_tokens=300)
label("Abductive — response (best explanation from incomplete signals)", abductive_resp, MAGENTA)
pause()

# ── Analogical reasoning ──────────────────────────────────────────────────────
# Map structure/lessons from a known domain onto an unfamiliar one.
# Best for: explaining CI concepts to non-analyst stakeholders.
analogical_prompt = """
Use analogical reasoning to explain the following concept to a client executive
with no background in competitive intelligence or retail economics.

Concept to explain: How a "platform flywheel" works in quick-commerce — specifically
why Reliance Retail's entry into 15-minute delivery becomes harder to displace the
more dark stores it opens and the more customers it acquires.

Use an analogy from everyday life (not business or tech) that makes the mechanism
intuitive. Clearly label (a) what maps to what in the analogy, and (b) where the
analogy breaks down.
"""
label("Analogical — prompt", analogical_prompt, YELLOW)
analogical_resp = ask(analogical_prompt, temperature=0.5, max_tokens=300)
label("Analogical — response (familiar concept mapped to new domain)", analogical_resp, CYAN)
pause()

print(f"{YELLOW}KEY LESSON:{RESET}")
print("  Deductive  → apply known rules to reach certain conclusions  (threat triage, escalation)")
print("  Inductive  → generalise from cases to form hypotheses        (trend analysis, research)")
print("  Abductive  → find the best explanation for observations      (competitor intent, root cause)")
print("  Analogical → transfer insight across domains                 (stakeholder comms, strategy)")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 2 — SUMMARIZATION STYLES  (Extractive vs Abstractive)
#
#  Extractive  — selects and returns verbatim sentences/phrases from the source.
#                Faithful to original wording; no new text introduced.
#                Best for: legal/compliance docs, evidence quotation, audit trails.
#
#  Abstractive — paraphrases and synthesises; may use words not in the source.
#                More fluent and concise; slight risk of meaning drift.
#                Best for: client-facing briefs, executive summaries, watch-lists.
# ═══════════════════════════════════════════════════════════════════════════════
pause()
section("DEMO 2 — Summarization Styles  (Extractive vs Abstractive)")
scenario("""
Extractive  — copies verbatim sentences/phrases directly from the source.
              Fully faithful; no new words introduced.
              Best for: audits, legal/compliance docs, evidence quotation in CI reports.

Abstractive — paraphrases and synthesises; may use words not in the source.
              More fluent and concise; slight risk of meaning drift.
              Best for: client-facing CI briefs, executive summaries, watch-list narratives.
""")

ci_report = """
C5i WEEKLY MARKET MONITOR — CONFIDENTIAL
Date: 14 March 2026   |   Vertical: Indian FMCG   |   Prepared for: ITC Limited

COMPETITIVE DEVELOPMENTS — WEEK ENDING 14 MARCH 2026

1. HUL Acquires Havmor Ice Cream (₹2,400 Crore)
Hindustan Unilever Limited announced the acquisition of Havmor Ice Cream Pvt. Ltd.
for ₹2,400 crore on 14 March 2026, marking its first entry into the premium Indian
frozen desserts segment. The deal is expected to close in Q3 2026 pending CCI approval.
Havmor holds an estimated 12% share of the organised premium ice cream market in
western India. HUL's distribution network of 9 million retail outlets will provide
immediate scale. ITC has no current presence in the frozen desserts category.

2. HUL Leadership Transition
HUL confirmed that MD Sanjiv Mehta will transition to an advisory role from
1 June 2026. Rohit Jawa (currently President, Unilever South Asia) takes over
as MD & CEO. Jawa is known for an aggressive digital and direct-to-consumer
growth philosophy at Unilever's South Asia operations.

3. Nestle India — Maggi Price Increase (+12%)
Nestle India announced a 12% price increase for its Maggi noodles range effective
April 2026, citing rising wheat flour and palm oil costs. Maggi holds approximately
60% of the Indian instant noodles market. ITC's Yippee! is the #2 player with an
estimated 22% share. Nestle's move creates a pricing window for ITC Yippee! to hold
prices or offer promotions to capture share.

4. Reliance Retail — Quick Commerce Acquisition Rumour
Industry sources indicate Reliance Retail is in advanced talks to acquire a leading
quick-commerce startup at a reported valuation of $500 million. No official confirmation
has been made. The move would complement Reliance's JioMart Express pilot (15-minute
delivery, currently active in Mumbai and Bengaluru).

5. Nestle India × BigBasket Distribution Partnership
Nestle India signed a distribution partnership with BigBasket effective 3 March 2026,
covering Nestle products for 10-minute delivery across 45 Tier 2 and Tier 3 cities
via BigBasket's Superstore rapid delivery service.

ANALYST RECOMMENDATION
ITC should prioritise two near-term responses: (1) evaluate a quick-commerce
distribution partnership to counter Nestle's BigBasket reach, and (2) assess
a selective Yippee! price hold or promotional campaign to exploit the Maggi
price gap opening in April.
"""

# ── Extractive summarization ──────────────────────────────────────────────────
extractive_prompt = f"""
Perform EXTRACTIVE summarization of the CI report below.

Rules:
- Copy sentences or short phrases VERBATIM from the report — do not paraphrase or add any new words.
- Select only the most strategically significant sentences for our client ITC Limited.
- Limit to 5 bullet points maximum.
- Each bullet must be a direct quote (exact wording) from the text.

CI Report:
{ci_report}
"""

label("Extractive summarization — prompt instruction", extractive_prompt, YELLOW)
extractive_resp = ask(extractive_prompt, temperature=0.0, max_tokens=300)
label("Extractive — verbatim sentences lifted from source", extractive_resp, CYAN)
pause()

# ── Abstractive summarization ─────────────────────────────────────────────────
abstractive_prompt = f"""
Write an ABSTRACTIVE summary of the CI report below for a senior ITC executive
who was not present at the analyst briefing.

Requirements:
- Synthesise and paraphrase — do NOT copy verbatim sentences.
- Use plain commercial language; avoid raw numbers where a brief interpretation is clearer.
- Cover: the most significant competitive development, key threats to ITC, and
  the immediate recommended response.
- Maximum 100 words.

CI Report:
{ci_report}
"""

label("Abstractive summarization — prompt instruction", abstractive_prompt, YELLOW)
abstractive_resp = ask(abstractive_prompt, temperature=0.3, max_tokens=200)
label("Abstractive — synthesised, paraphrased summary", abstractive_resp, GREEN)
pause()

print(f"{YELLOW}KEY LESSON:{RESET}")
print("  Extractive  → zero paraphrase, fully traceable to source — use for audits, evidence, compliance")
print("  Abstractive → fluent synthesis, may introduce slight drift — use for comms, briefings, UX")
print("  In CI pipelines, prefer extractive when traceability matters; abstractive for readability.")
print("  For highest safety: extractive first, then abstractive over the extracted quotes.")


print(f"\n{'═'*66}")
print("  All demos complete.")
print(f"{'═'*66}\n")
