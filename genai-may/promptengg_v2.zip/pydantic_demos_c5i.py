"""
pydantic_demos_c5i.py
───────────────────────────────────────────────────────────────────────────────
Pydantic demos in the Competitive Intelligence domain using Azure OpenAI.
C5i Analytics — Weekly Market Monitor pipeline context.

WHAT THIS FILE COVERS
─────────────────────
1. Basic Pydantic model — CompetitiveEvent schema with auto type coercion
2. Validation Error     — Bad data caught before it reaches the CI database
3. Optional fields      — Sensible defaults for incomplete event records
4. Nested models        — CIRecord with embedded CompanyProfile and EventDetails
5. Custom validators    — CI-specific rules (impact score range, date format, summary length)
6. Serialization        — model → JSON and JSON → model round-trip
7. LLM + Pydantic (Extraction)  — LLM reads a news article and pulls out
                        facts that already exist in the text (reading task)
8. LLM + Pydantic (Generation)  — LLM reads a competitive scenario and reasons
                        about threat level, implications, and actions (thinking task)

KEY DIFFERENCE BETWEEN DEMO 7 AND DEMO 8
─────────────────────────────────────────
Demo 7 is EXTRACTION: the LLM acts like a reader — all the answers (company,
event type, date, geography, etc.) are already present in the news article;
it just needs to find and format them.

Demo 8 is GENERATION / REASONING: the LLM acts like an analyst — it must
JUDGE the threat level, PLAN recommended actions, IDENTIFY watch items, and
DECIDE whether an immediate response is required. None of these exist verbatim
in the input text; the LLM has to reason them out.

Both use the identical Pydantic-as-contract pattern (LLM → JSON → Pydantic
validation → typed object). The difference is purely in what you ask the LLM
to do with the input.

RUN
───
pip install pydantic openai python-dotenv
python pydantic_demos_c5i.py

Prereqs: .env with AZURE_OPENAI_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_MODEL_NAME
"""

# ── Standard + third-party imports ───────────────────────────────────────────
import json
import re
import os
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

# Pydantic v2 imports
# BaseModel  → base class every schema inherits from
# Field      → attach metadata (description, default, constraints) to a field
# field_validator → decorator for custom field-level validation logic
# ValidationError → raised when incoming data fails schema rules
from pydantic import BaseModel, Field, field_validator, ValidationError

from openai import OpenAI

# ── Locate .env and load credentials ─────────────────────────────────────────
def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env in any parent directory.")
    exit(1)

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# ── Azure OpenAI client (used in Demo 7 and Demo 8 only) ─────────────────────
llm_client = OpenAI(
    base_url=os.getenv("AZURE_OPENAI_OPENAI_ENDPOINT", ""),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)
MODEL = os.getenv("AZURE_OPENAI_MODEL_NAME")


def strip_markdown_json(text: str) -> str:
    """
    LLMs often wrap JSON in markdown fences like:
        ```json
        { ... }
        ```
    Pydantic's model_validate_json expects raw JSON with no surrounding text.
    This helper strips those fences so validation works correctly.
    """
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 1 — Basic Pydantic Model (CompetitiveEvent)
#
# Key concept: define a class that inherits BaseModel.
# Each class attribute becomes a validated, typed field.
# Pydantic will COERCE compatible types (e.g. "7" → 7 for an int field).
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 1 — Basic CompetitiveEvent Model (type coercion)")
print("═" * 60)
print("Story: The C5i news ingestion pipeline receives event data from an")
print("external news API. The API returns 'impact_score' as the string '7'")
print("instead of an integer. Pydantic quietly fixes this — no manual casting.\n")

class CompetitiveEvent(BaseModel):
    # str field — must be a string (or coercible to one)
    event_id: str

    # str field
    company_name: str

    # str field
    event_type: str

    # int field — "7" as a string will be silently coerced to 7
    impact_score: int


# Simulate data arriving from a news API where impact_score came back as a string
raw_data = {
    "event_id": "EVT-2026-0341",
    "company_name": "Hindustan Unilever Limited",
    "event_type": "acquisition",
    "impact_score": "7",    # <-- string, will be coerced to int automatically
}

event = CompetitiveEvent(**raw_data)
print(f"✔ Event ingested successfully:")
print(f"  Event ID      : {event.event_id}")
print(f"  Company       : {event.company_name}")
print(f"  Event Type    : {event.event_type}")
print(f"  Impact Score  : {event.impact_score}  ← was the string '7', coerced to int {type(event.impact_score).__name__}")
print(f"\n  Full model repr: {event}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 2 — Validation Error
#
# Key concept: if incoming data is INCOMPATIBLE (not coercible), Pydantic
# raises a ValidationError with a clear, structured error message.
# This is critical in production — bad data is caught BEFORE it reaches your
# CI database or client deliverable.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 2 — Validation Error (bad data caught at the gate)")
print("═" * 60)
print("Story: The same news API sends a garbled record — impact_score is the")
print("word 'high' instead of a number. Pydantic refuses to accept it and")
print("tells us exactly which field failed and why.\n")

bad_data = {
    "event_id": "EVT-2026-0342",
    "company_name": "Nestle India",
    "event_type": "pricing_change",
    "impact_score": "high",     # <-- cannot be converted to int → ValidationError
}

try:
    bad_event = CompetitiveEvent(**bad_data)
except ValidationError as e:
    # e.errors() returns a structured list of all validation failures
    print("✘ Event rejected — validation failed (expected):")
    for err in e.errors():
        # loc  → which field failed
        # msg  → human-readable reason
        print(f"  Field : {err['loc']}")
        print(f"  Error : {err['msg']}")
    print("\n  ↳ The bad record never reached the CI database. Pipeline integrity preserved.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 3 — Optional Fields & Default Values
#
# Key concept: wrap a type with Optional[X] to allow None, and use
# Field(default=...) to provide fallback values.
# This is useful when LLM output or news feeds may omit certain keys.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 3 — Optional Fields & Defaults")
print("═" * 60)
print("Story: A breaking news flash comes in — company name and action are")
print("confirmed, but event date, geography, and analyst assignment are not")
print("yet known. The model accepts partial data and fills in sensible defaults.\n")

class CIEventFull(BaseModel):
    event_id: str
    company_name: str
    event_type: str
    impact_score: int

    # Optional fields — these will default to None / given value if absent
    event_date: Optional[str] = None              # may not be reported yet
    geography: Optional[str] = None               # may be unknown initially
    analyst_assigned: Optional[str] = None        # not yet routed
    confidence: str = Field(default="medium", description="high | medium | low")
    requires_follow_up: bool = False              # default: routine tracking

# Minimal payload — only required fields supplied
breaking = CIEventFull(
    event_id="EVT-2026-0343",
    company_name="Reliance Retail",
    event_type="acquisition",
    impact_score=8,
)
print(f"✔ Breaking news event logged with minimal info:")
print(f"  Event ID          : {breaking.event_id}")
print(f"  Company           : {breaking.company_name}")
print(f"  Event Date        : {breaking.event_date}  ← defaulted to None (not yet confirmed)")
print(f"  Geography         : {breaking.geography}  ← not yet known")
print(f"  Analyst Assigned  : {breaking.analyst_assigned}  ← not yet routed")
print(f"  Confidence        : {breaking.confidence}  ← defaulted to medium")
print(f"  Follow-up Needed? : {breaking.requires_follow_up}  ← assumed routine")

# Full payload — record completed after analyst review
verified = CIEventFull(
    event_id="EVT-2026-0344",
    company_name="Hindustan Unilever Limited",
    event_type="acquisition",
    impact_score=9,
    event_date="2026-03-14",
    geography="India",
    analyst_assigned="Priya Sharma",
    confidence="high",
    requires_follow_up=True,
)
print(f"\n✔ Another event — fully documented after analyst verification:")
print(f"  Event ID          : {verified.event_id}")
print(f"  Company           : {verified.company_name}")
print(f"  Event Date        : {verified.event_date}")
print(f"  Geography         : {verified.geography}")
print(f"  Analyst           : {verified.analyst_assigned}  ← routed for follow-up")
print(f"  Confidence        : {verified.confidence}  ← all fields confirmed")
print(f"  Follow-up Needed? : {verified.requires_follow_up}  ← flagged for next brief")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 4 — Nested Models
#
# Key concept: embed one Pydantic model inside another to represent
# hierarchical / relational data (e.g. a CI record HAS a company profile,
# HAS event details). Pydantic validates the nested model recursively.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 4 — Nested Models (CompanyProfile + EventDetails inside CIRecord)")
print("═" * 60)
print("Story: The C5i database stores a full competitive record — company")
print("metadata and event details are separate sub-records that get joined")
print("when the analyst generates the client brief.")
print("Each sub-record is its own Pydantic model, validated independently.\n")

class CompanyProfile(BaseModel):
    """Company metadata stored in the C5i reference database."""
    company_name: str
    sector: str
    hq_country: str
    estimated_market_share_pct: Optional[float] = None  # may be unknown

class EventDetails(BaseModel):
    """Core details of a single competitive event."""
    event_type: str
    event_summary: str
    event_date: Optional[str] = None
    geography: Optional[str] = None
    source: str

class CIRecord(BaseModel):
    record_id: str
    company: CompanyProfile         # ← nested Pydantic model
    event: EventDetails             # ← another nested model
    impact_score: int
    analyst: str
    client: str

# Pydantic handles nested dict → nested model conversion automatically
ci_data = {
    "record_id": "CI-2026-0099",
    "company": {                    # dict is auto-converted to CompanyProfile model
        "company_name": "Hindustan Unilever Limited",
        "sector": "FMCG",
        "hq_country": "India",
        "estimated_market_share_pct": 18.4,
    },
    "event": {                      # dict is auto-converted to EventDetails model
        "event_type": "acquisition",
        "event_summary": "HUL acquired Havmor Ice Cream for ₹2,400 crore to enter premium frozen desserts.",
        "event_date": "2026-03-14",
        "geography": "India",
        "source": "HUL press release, BSE filing",
    },
    "impact_score": 9,
    "analyst": "Priya Sharma",
    "client": "ITC Limited",
}

record = CIRecord(**ci_data)
print(f"✔ Full CI record built with nested sub-models:")
print(f"  Record ID  : {record.record_id}")
print(f"  Company    → {record.company.company_name} | {record.company.sector} | "
      f"~{record.company.estimated_market_share_pct}% share")
print(f"  Event      → {record.event.event_type} on {record.event.event_date} | {record.event.geography}")
print(f"  Summary    : {record.event.event_summary}")
print(f"  Source     : {record.event.source}")
print(f"  Impact     : {record.impact_score}/10  |  Analyst: {record.analyst}  |  Client: {record.client}")
print(f"\n  ↳ record.company and record.event are full Pydantic objects, not plain dicts.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 5 — Custom Field Validators
#
# Key concept: @field_validator lets you add domain-specific rules that go
# beyond type checking.  Example: impact_score must be 1-10, event_date must
# be YYYY-MM-DD, event_summary must be ≤ 30 words.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 5 — Custom Field Validators")
print("═" * 60)
print("Story: Junior analysts sometimes submit records with impact scores out")
print("of range, dates in the wrong format ('March 2026' instead of ISO 8601),")
print("or event summaries that are too long. Custom validators catch these")
print("before they corrupt the C5i database.\n")

class ValidatedCIEvent(BaseModel):
    record_id: str
    impact_score: int       # must be 1-10
    event_date: str         # must be YYYY-MM-DD
    event_summary: str      # must be ≤ 30 words

    # Validator for 'impact_score' — must be within the 1-10 CI scoring rubric
    @field_validator("impact_score")
    @classmethod
    def check_impact_score(cls, v):
        if not (1 <= v <= 10):
            raise ValueError(f"impact_score {v} is outside the valid range 1–10")
        return v

    # Validator for 'event_date' — must be strict ISO 8601 format
    @field_validator("event_date")
    @classmethod
    def check_date_format(cls, v):
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
            raise ValueError(
                f"event_date '{v}' must be in YYYY-MM-DD format (e.g. '2026-03-14'), not '{v}'"
            )
        return v

    # Validator for 'event_summary' — CI database enforces 30-word cap
    @field_validator("event_summary")
    @classmethod
    def check_summary_length(cls, v):
        word_count = len(v.split())
        if word_count > 30:
            raise ValueError(
                f"event_summary exceeds 30 words ({word_count} words found). Shorten it."
            )
        return v

# Valid event record
try:
    valid_ev = ValidatedCIEvent(
        record_id="CI-2026-0100",
        impact_score=7,
        event_date="2026-03-10",
        event_summary="Nestle India raised Maggi noodle prices by 12% citing wheat and palm oil inflation.",
    )
    print(f"✔ Clean event record — accepted:")
    print(f"  {valid_ev}")
except ValidationError as e:
    print(f"Unexpected error: {e}")

# Invalid event — score out of range, bad date format, summary too long
print("\n✘ Corrupted event record (score=15, date='March 2026', summary=38 words) — rejected:")
try:
    bad_ev = ValidatedCIEvent(
        record_id="CI-2026-0101",
        impact_score=15,                     # fails: out of 1-10 range
        event_date="March 2026",             # fails: not YYYY-MM-DD
        event_summary=(
            "Nestle India has announced a very significant and strategically important "
            "price increase of twelve percent for its Maggi instant noodles range across "
            "all retail formats and channels throughout the entire country of India."
        ),  # fails: 38 words, exceeds 30-word limit
    )
except ValidationError as e:
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
    print("\n  ↳ All three domain-specific rules fired. Record blocked from database.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 6 — Serialization: model → JSON and JSON → model
#
# Key concept: Pydantic models have built-in methods for serialization.
#   model.model_dump()       → Python dict
#   model.model_dump_json()  → JSON string
#   Model.model_validate()   → parse dict/JSON into model (Pydantic v2)
#
# This is essential for storing CI records in a database, sending over HTTP
# to the brief generator, or logging structured audit events.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 6 — Serialization (model ↔ JSON)")
print("═" * 60)
print("Story: The CI record from Demo 4 (HUL Havmor acquisition) needs to be")
print("saved to the C5i events database and later retrieved for a client brief.")
print("Pydantic converts the model to JSON for storage and rebuilds an identical")
print("typed object when reading it back.\n")

# Reuse CIRecord from Demo 4
as_dict = record.model_dump()
print("① model_dump() — Python dict (ready for a database insert):")
print(json.dumps(as_dict, indent=2, ensure_ascii=False))

# model → JSON string
as_json = record.model_dump_json(indent=2)
print("\n② model_dump_json() — JSON string (ready to send over HTTP, first 300 chars):")
print(as_json[:300] + "…")

# JSON string → model (round-trip)
restored = CIRecord.model_validate_json(as_json)
print(f"\n③ model_validate_json() — restored from JSON back to a typed object:")
print(f"  Company: {restored.company.company_name}, Event: {restored.event.event_type}, "
      f"Impact: {restored.impact_score}/10")
print(f"  ↳ Round-trip complete — same data, fully validated Pydantic object.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 7 — LLM Integration: Extract Structured Data from a News Article
#
# Key concept: the LLM acts as a READER / EXTRACTOR.
# The news article already contains all the facts (company, event type, date,
# geography, price change). The LLM's job is simply to find them and format
# them as JSON matching the Pydantic schema.
#
# This is an EXTRACTION task — not reasoning or judgment.
# Every value in the output schema can be directly traced back to a sentence
# in the input article.
#
# Flow:
#   News article (free text)
#       → Azure OpenAI LLM (prompted to return JSON)
#           → JSON string
#               → Pydantic model (validate + use safely)
#
# This is the CORE pattern in any CI ingestion pipeline — Pydantic acts as
# the contract between the LLM output and your database.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 7 — LLM as Extractor: News Article → Structured CI Event")
print("(LLM reads facts that already exist in the text — no reasoning needed)")
print("═" * 60)
print("Story: A press release arrives as plain text. We need the competitive")
print("event in structured form to load into the C5i events database. The LLM")
print("reads the article and extracts facts — company, event type, date,")
print("geography, deal value — as JSON.\n")

# ── Pydantic schema for the LLM to populate ──────────────────────────────────
class CIEventExtraction(BaseModel):
    """Schema we expect the LLM to fill from a news article."""
    company_name: str
    event_type: str                          # acquisition, pricing_change, etc.
    event_summary: str                       # ≤ 30 words
    event_date: Optional[str] = None         # YYYY-MM-DD or null
    geography: Optional[str] = None
    deal_value_inr_crore: Optional[float] = None   # for M&A events; null otherwise
    source_quote: str                        # verbatim sentence from the article

# ── Sample news article (unstructured text) ──────────────────────────────────
news_article = """
Nestle India Raises Maggi Prices by 12%
Mumbai, 10 March 2026

Nestle India today announced a 12% price increase for its Maggi noodles range,
effective 1 April 2026, citing sustained increases in wheat flour and palm oil
procurement costs over the past two quarters.

Nestle India CEO Suresh Narayanan stated: "The price adjustment is unavoidable
given commodity inflation that has persisted for six months. We have absorbed
as much cost pressure as possible before passing it to consumers."

The increase applies across all retail formats and channels in India. Maggi
holds approximately 60% of the Indian instant noodles market. ITC's Yippee!
is the #2 brand with an estimated 22% share.
"""

# ── System prompt that instructs the LLM to return structured JSON ────────────
system_prompt_extraction = """You are a Competitive Intelligence extraction engine for C5i Analytics.
Extract the primary competitive event from the provided article and return ONLY
valid JSON (no markdown, no explanation) with these exact keys:
{
  "company_name": "<string>",
  "event_type": "<string — one of: acquisition | pricing_change | product_launch | partnership | executive_change | funding | other>",
  "event_summary": "<string, max 30 words>",
  "event_date": "<YYYY-MM-DD or null>",
  "geography": "<string or null>",
  "deal_value_inr_crore": <number or null>,
  "source_quote": "<verbatim sentence from the article that best describes the event>"
}
Do NOT fabricate details not present in the article. Use null for missing fields.
"""

# ── Call Azure OpenAI ─────────────────────────────────────────────────────────
print(f"Calling Azure OpenAI model: {MODEL}")
print(f"Input article:\n{news_article.strip()}\n")

response7 = llm_client.chat.completions.create(
    model=MODEL,
    messages=[
        {"role": "system", "content": system_prompt_extraction},
        {"role": "user",   "content": news_article},
    ],
    temperature=0.0,
    max_tokens=512,
)

raw_llm_output = response7.choices[0].message.content.strip()
print(f"Raw LLM output:\n{raw_llm_output}\n")

# ── Parse and validate with Pydantic ─────────────────────────────────────────
try:
    extracted = CIEventExtraction.model_validate_json(strip_markdown_json(raw_llm_output))
    print("✔ Pydantic-validated extraction (facts pulled from article):")
    print(f"  Company        : {extracted.company_name}")
    print(f"  Event Type     : {extracted.event_type}")
    print(f"  Summary        : {extracted.event_summary}")
    print(f"  Event Date     : {extracted.event_date}")
    print(f"  Geography      : {extracted.geography}")
    print(f"  Deal Value     : {extracted.deal_value_inr_crore}")
    print(f"  Source Quote   : \"{extracted.source_quote}\"")
    print(f"\n  ↳ All values came from the article — LLM just extracted them.")
except ValidationError as e:
    print("LLM output failed Pydantic validation:")
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
except json.JSONDecodeError as e:
    print(f"LLM did not return valid JSON: {e}")
    print(f"Raw output was: {raw_llm_output}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 8 — LLM as Strategic Analyst (Schema-Driven Output)
#
# Key concept: the LLM acts as a CI ANALYST / REASONER.
# Unlike Demo 7 (extraction), here the LLM must JUDGE and DECIDE:
#   • threat_level          — low / medium / high  (not stated in the input)
#   • strategic_implications — analysis the LLM must reason out
#   • recommended_actions   — steps the LLM recommends for the client
#   • requires_immediate_response — true/false decision (requires judgment)
#
# This is a GENERATION / REASONING task. None of the output fields exist
# verbatim in the input — the LLM applies domain knowledge to produce them.
#
# The Pydantic pattern is identical to Demo 7; only the LLM's role changes.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 8 — LLM as Analyst: Competitive Scenario → Strategic Assessment")
print("(LLM judges threat level, plans actions, flags risks — not just extraction)")
print("═" * 60)
print("Story: A CI analyst enters a competitive scenario. Instead of pulling")
print("out facts, the LLM must reason: how severe is this threat? What should")
print("our client do? What signals should we watch next week? The answers don't")
print("exist in the text — the LLM has to think them through.\n")

class CIStrategicAssessment(BaseModel):
    """Structured assessment that feeds directly into the client brief generator."""
    competitor: str
    threat_level: str                       # "low" | "medium" | "high" — LLM must judge this
    rationale: str                          # brief explanation of the threat level
    strategic_implications: list[str]       # implications for our client — LLM must reason these
    recommended_actions: list[str]          # concrete steps — LLM must plan these
    watch_items: list[str]                  # signals to monitor next week — LLM must identify these
    requires_immediate_response: bool       # true/false — LLM must decide this

system_prompt_assessment = """You are a Senior Competitive Intelligence Analyst at C5i Analytics
with 15 years of experience covering FMCG in India. You advise Fortune 500 clients
on competitive strategy.

Given a competitive scenario, return ONLY valid JSON (no markdown) matching:
{
  "competitor": "<string>",
  "threat_level": "<low|medium|high>",
  "rationale": "<1-2 sentences explaining the threat level>",
  "strategic_implications": ["<implication for our client>", ...],
  "recommended_actions": ["<concrete action step>", ...],
  "watch_items": ["<signal or development to monitor next week>", ...],
  "requires_immediate_response": <true|false>
}

Base your assessment on market dynamics, competitive position, and strategic frameworks.
Do NOT fabricate data not present in the scenario. Ground every implication in the facts given.
"""

competitive_scenario = """
Our client is Swiggy Instamart, currently the #2 player in Indian quick-commerce.

Competitive development: Reliance Retail has announced it is piloting 'JioMart Express',
a 15-minute grocery delivery service, in Mumbai and Bengaluru. The pilot is backed by
Reliance's existing JioMart dark store network of 200 locations across the two cities.
The service covers FMCG grocery categories including packaged foods, personal care,
and home care — identical to Swiggy Instamart's core category set. Reliance has also
reportedly acquired a quick-commerce startup for $500M to accelerate rollout.
"""

print(f"Scenario:\n{competitive_scenario.strip()}\n")

response8 = llm_client.chat.completions.create(
    model=MODEL,
    messages=[
        {"role": "system", "content": system_prompt_assessment},
        {"role": "user",   "content": competitive_scenario},
    ],
    temperature=0.0,
    max_tokens=600,
)

raw8 = response8.choices[0].message.content.strip()
print(f"Raw LLM output:\n{raw8}\n")

try:
    assessment = CIStrategicAssessment.model_validate_json(strip_markdown_json(raw8))
    print("✔ Validated Strategic Assessment (LLM reasoned, not just extracted):")
    print(f"  Competitor              : {assessment.competitor}")
    print(f"  Threat Level            : {assessment.threat_level.upper()}  ← LLM judged this from the scenario")
    print(f"  Rationale               : {assessment.rationale}")
    print(f"  Strategic Implications  :  ← LLM inferred these for our client")
    for imp in assessment.strategic_implications:
        print(f"    • {imp}")
    print(f"  Recommended Actions     :  ← LLM planned these steps")
    for action in assessment.recommended_actions:
        print(f"    → {action}")
    print(f"  Watch Items             :  ← LLM identified these signals")
    for item in assessment.watch_items:
        print(f"    ⚠ {item}")
    print(f"  Immediate Response?     : {assessment.requires_immediate_response}  ← LLM made this decision")
    print(f"\n  ↳ None of these were stated in the scenario — LLM reasoned them out.")
except ValidationError as e:
    print("Validation error on strategic assessment:")
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
except json.JSONDecodeError as e:
    print(f"JSON parse error: {e}\nRaw: {raw8}")


print("\n" + "═" * 60)
print("All demos complete.")
print("═" * 60)
