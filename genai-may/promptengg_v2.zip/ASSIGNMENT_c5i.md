# Prompt Engineering Assignments
### C5i — Generative AI & Agentic Systems Training
**Module: Prompt Engineering in Production Systems**

---

> **Pre-requisites:** Complete `promptengg.py` and `pydantic_demos.py` demos before starting.

---

## Learning Objectives

By the end of these three assignments you will be able to:

- Extract **structured data from unstructured text** using LLM-driven parsing with precise output format control
- **Validate LLM-generated JSON** with Pydantic and implement retry loops that use the validation error as a feedback signal
- Design **role-aware, template-driven document generation** pipelines that produce client-ready deliverables from structured inputs

---

# Assignment 1 — Competitive Intelligence Extractor: Unstructured → Structured

## Background

C5i's Competitive Intelligence (CI) team processes hundreds of news articles,
press releases, and analyst reports every week to track competitor activity
across client verticals. Today this is done manually — analysts read each article
and copy key facts into a spreadsheet.

You are building an **LLM-powered extraction pipeline** that reads raw, unstructured
article text and outputs a consistent JSON record for each event detected.

This assignment tests your ability to:

- Write a **system prompt** that drives reliable structured extraction
- Use **output format control** (JSON with a defined schema) to constrain the LLM
- Handle **ambiguous or missing fields** gracefully (null vs fabricated values)
- Apply **XML delimiters** to separate the article text from your instructions

---

## What the Extractor Must Do

```
Given an unstructured article, extract every competitive event mentioned.
Each event is a distinct, atomic business action by a named company.

For each event, extract:

  Company Intelligence
  ────────────────────
  • company_name        : Name of the company taking the action
  • company_type        : "competitor" | "partner" | "client" | "unknown"
  • sector              : Primary sector (e.g., "FMCG", "Pharma", "Retail", "Tech")

  Event Details
  ─────────────
  • event_type          : One of: "product_launch" | "acquisition" | "partnership" |
                          "executive_change" | "funding" | "market_exit" | "pricing_change" |
                          "regulatory" | "other"
  • event_summary       : One sentence describing what happened (≤ 30 words)
  • event_date          : ISO 8601 date (YYYY-MM-DD) or null if not mentioned
  • geography           : Country or region affected, or null

  Metadata
  ────────
  • confidence          : "high" | "medium" | "low"
                          high   = date + company + action all explicit in text
                          medium = company + action clear, date inferred or missing
                          low    = one or more key fields inferred by the model
  • source_quote        : The verbatim sentence(s) from the article that support this event
```

The output must be a **JSON array** — one object per event. If no events are found,
return an empty array `[]`. Do **not** fabricate details not present in the article.
Use `null` for missing optional fields.

---

## Sample Articles

### Article A — Clear, multi-event press release

```
HUL Expands Presence with ₹2,400 Crore Ice Cream Acquisition
Mumbai, 14 March 2026

Hindustan Unilever Limited today announced the acquisition of Havmor Ice Cream
Pvt. Ltd. for ₹2,400 crore, marking its first foray into the premium Indian
frozen desserts segment. The deal is expected to close in Q3 2026 pending
CCI approval.

In a separate development, HUL also confirmed that Sanjiv Mehta will transition
from his role as Managing Director to an advisory position effective 1 June 2026,
with Rohit Jawa, currently President of South Asia at Unilever, taking over as MD & CEO.

HUL's shares rose 3.4% on the Bombay Stock Exchange following the announcement.
```

### Article B — Vague, inferred details

```
Industry sources suggest Reliance Retail may be in advanced talks to acquire a
majority stake in a leading quick-commerce startup, though no official
announcement has been made. The deal, if confirmed, could value the startup
at upwards of $500 million and significantly bolster Reliance's last-mile
delivery capability ahead of the festive season.
```

### Article C — No competitive events

```
A new study published in the Journal of Consumer Behaviour found that Indian
urban consumers between the ages of 25 and 35 spend an average of 6.2 hours
per week researching products online before making a purchase decision.
The study surveyed 4,000 respondents across 12 cities.
```

---

## Starter Code

```python
"""
assignment1_ci_extractor.py
────────────────────────────
C5i Competitive Intelligence — Unstructured Article to Structured JSON Extractor
"""

import json

# paste the Setup block here

EXTRACTION_SYSTEM_PROMPT = """
You are a Competitive Intelligence extraction engine for C5i Analytics.

YOUR TASK
─────────
Read the article provided inside <article> tags and extract every distinct
competitive event into a JSON array. Each array element represents ONE event.

OUTPUT FORMAT
─────────────
Return ONLY a valid JSON array. No explanation, no markdown fences, no preamble.
If no events are present, return: []

Each object in the array must have EXACTLY these keys:
{
  "company_name":    string,
  "company_type":    "competitor" | "partner" | "client" | "unknown",
  "sector":          string,
  "event_type":      "product_launch" | "acquisition" | "partnership" |
                     "executive_change" | "funding" | "market_exit" |
                     "pricing_change" | "regulatory" | "other",
  "event_summary":   string (≤ 30 words),
  "event_date":      "YYYY-MM-DD" | null,
  "geography":       string | null,
  "confidence":      "high" | "medium" | "low",
  "source_quote":    string
}

STRICT RULES
────────────
1. Do NOT invent facts. If a field is not in the article, set it to null.
2. Each event must be a single, atomic business action. Split compound events
   (e.g., acquisition + leadership change) into separate objects.
3. source_quote must be copied verbatim from the article — do not paraphrase.
4. event_summary must be ≤ 30 words. No corporate jargon.
5. confidence rules:
   - high   : date + company + action all explicitly stated
   - medium : company + action clear; date missing or only inferred
   - low    : any key field inferred or uncertain
"""


def extract_events(article_text: str) -> list[dict]:
    """Send one article through the extractor and return parsed event list."""

    user_message = f"""Extract all competitive events from the article below.

<article>
{article_text}
</article>
"""

    # TODO: Call the LLM using the converse API (see promptengg.py for the pattern)
    # Use EXTRACTION_SYSTEM_PROMPT as the system prompt.
    # Parse the response text as JSON before returning.

    raw_response = ""  # replace with actual LLM call
    events = json.loads(raw_response)
    return events


def main():
    articles = {
        "Article A — HUL Acquisition & Leadership": """
HUL Expands Presence with ₹2,400 Crore Ice Cream Acquisition
Mumbai, 14 March 2026

Hindustan Unilever Limited today announced the acquisition of Havmor Ice Cream
Pvt. Ltd. for ₹2,400 crore, marking its first foray into the premium Indian
frozen desserts segment. The deal is expected to close in Q3 2026 pending
CCI approval.

In a separate development, HUL also confirmed that Sanjiv Mehta will transition
from his role as Managing Director to an advisory position effective 1 June 2026,
with Rohit Jawa, currently President of South Asia at Unilever, taking over as MD & CEO.
""",
        "Article B — Reliance Retail Rumour": """
Industry sources suggest Reliance Retail may be in advanced talks to acquire a
majority stake in a leading quick-commerce startup, though no official
announcement has been made. The deal, if confirmed, could value the startup
at upwards of $500 million.
""",
        "Article C — No Events": """
A new study published in the Journal of Consumer Behaviour found that Indian
urban consumers between the ages of 25 and 35 spend an average of 6.2 hours
per week researching products online before making a purchase decision.
""",
    }

    for title, article in articles.items():
        print(f"\n{'─' * 60}")
        print(f"Processing: {title}")
        print("─" * 60)
        events = extract_events(article)
        print(json.dumps(events, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
```

---

## Tasks

### Task 1A — Run the baseline extractor

Complete the `extract_events` function and run it on all three articles.

**Verify for Article A:**
- Are exactly 2 events returned (acquisition + executive change)?
- Are `event_date` values `"2026-03-14"` and `"2026-06-01"` respectively?
- Is `source_quote` verbatim from the article, not paraphrased?
- Is `confidence` `"high"` for the acquisition (date + company + action all present)?

**Verify for Article B:**
- Is `confidence` `"low"` (speculation, no date, unnamed target company)?
- Is `event_date` null?

**Verify for Article C:**
- Is the output `[]`?

---

### Task 1B — Stress-test ambiguity handling

Run the extractor on these additional inputs. Document the result and any prompt
adjustments needed:

```
Input 1 — Multiple companies, mixed roles
─────────────────────────────────────────
"Zomato and Blinkit, now a Zomato subsidiary, announced a joint warehouse
expansion initiative with logistics partner Delhivery, investing ₹800 crore
across 12 new dark stores in Tier 2 cities by December 2026."

Expected: 1 event (partnership/expansion). Zomato = competitor,
Delhivery = partner. Geography = India (Tier 2 cities).

Input 2 — Date ambiguity
────────────────────────
"Earlier this year, Marico silently discontinued its Parachute Advansed
Jasmine variant from modern trade channels in Maharashtra."

Expected: event_date = null (no specific date), confidence = "medium".
Do NOT fabricate a date like "2026-01-01".

Input 3 — Non-English company name in an English article
─────────────────────────────────────────────────────────
"Meiji Holdings (明治ホールディングス) has entered the Indian premium chocolate
segment through a distribution partnership with Spencer's Retail."
```

**For each input:** Document whether the extractor produced the expected output.
If not, identify which prompt rule was violated or missing, and fix it.

---

### Task 1C — Prevent hallucination of missing fields

Run the extractor on this deliberately sparse article:

```
"A major FMCG player is reportedly planning a significant price increase
for its personal care portfolio in the coming months."
```

**Observe:** Does the LLM invent a company name? An event date? A specific percentage?

Add a prompt reinforcement rule that prevents field fabrication and retest.
Document the before/after responses.

---

### Task 1D — Batch processing with error recovery

Wrap `extract_events` in a function that processes a list of articles, catches
`json.JSONDecodeError`, and logs failures without crashing the pipeline:

```python
def process_batch(articles: list[str]) -> tuple[list[dict], list[int]]:
    """
    Returns (all_events, failed_indices).
    all_events: flat list of all extracted events across all articles.
    failed_indices: list of article indices where JSON parsing failed.
    """
    # TODO: implement
```

Test it with a list that includes one article that causes the LLM to return
malformed JSON (e.g., an extremely long article where the LLM truncates mid-array).

---

### Deliverable

Submit `assignment1_ci_extractor.py` with:
- Complete, working extraction pipeline
- All four tasks implemented and tested
- A comment block at the top listing every prompt rule you added or modified,
  and which test case drove that change

---

---

# Assignment 2 — Pydantic Validation Loop: Catching and Correcting LLM Output

## Background

The extractor from Assignment 1 returns JSON that *mostly* conforms to the schema.
In production, "mostly" is not good enough: a pipeline that silently accepts
`"event_date": "March 2026"` instead of `"2026-03-14"` will produce corrupted
records in the C5i analytics database.

This assignment builds a **Pydantic validation layer** that:
1. Defines the exact schema for a `CompetitiveEvent` record
2. Validates every record the LLM returns
3. On validation failure, feeds the error back to the LLM with a **correction prompt**
4. Retries up to N times before marking the record as unresolvable

This pattern — *validate → error-as-prompt → retry* — is one of the most
practical and reusable techniques in production LLM systems.

---

## Pydantic Schema

```python
from pydantic import BaseModel, Field, field_validator, model_validator
from typing import Literal, Optional
from datetime import date
import re

CompanyType = Literal["competitor", "partner", "client", "unknown"]
EventType   = Literal[
    "product_launch", "acquisition", "partnership", "executive_change",
    "funding", "market_exit", "pricing_change", "regulatory", "other"
]
Confidence  = Literal["high", "medium", "low"]


class CompetitiveEvent(BaseModel):
    company_name  : str   = Field(..., min_length=2, max_length=100)
    company_type  : CompanyType
    sector        : str   = Field(..., min_length=2, max_length=50)
    event_type    : EventType
    event_summary : str   = Field(..., max_length=250)
    event_date    : Optional[date] = None   # enforces YYYY-MM-DD parsing
    geography     : Optional[str]  = None
    confidence    : Confidence
    source_quote  : str   = Field(..., min_length=10)

    @field_validator("event_summary")
    @classmethod
    def summary_word_limit(cls, v: str) -> str:
        if len(v.split()) > 30:
            raise ValueError(
                f"event_summary exceeds 30 words ({len(v.split())} words found). "
                "Shorten it."
            )
        return v

    @field_validator("event_date", mode="before")
    @classmethod
    def parse_date_string(cls, v):
        if v is None:
            return None
        if isinstance(v, str):
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
                raise ValueError(
                    f"event_date '{v}' is not in YYYY-MM-DD format. "
                    "Use ISO 8601 (e.g. 2026-03-14) or null."
                )
        return v

    @model_validator(mode="after")
    def confidence_matches_completeness(self) -> "CompetitiveEvent":
        has_date    = self.event_date is not None
        has_geo     = self.geography  is not None
        if self.confidence == "high" and not (has_date and has_geo):
            raise ValueError(
                "confidence='high' requires both event_date and geography to be present. "
                f"Found: event_date={'present' if has_date else 'null'}, "
                f"geography={'present' if has_geo else 'null'}. "
                "Change confidence to 'medium' or 'low', or add the missing fields."
            )
        return self
```

---

## The Correction Prompt Pattern

When Pydantic raises a `ValidationError`, the error message is structured and
machine-readable. Feed it back to the LLM as a correction task:

```python
CORRECTION_SYSTEM_PROMPT = """
You are a JSON correction assistant. You will be given:
1. An original JSON object that failed schema validation
2. The exact Pydantic validation error messages

YOUR TASK: Return a corrected version of the JSON object that satisfies every
validation rule described in the error messages.

RULES:
- Return ONLY the corrected JSON object. No explanation, no markdown fences.
- Fix only what the error messages identify. Do not change other fields.
- If a date is in the wrong format (e.g. "March 2026"), convert it to YYYY-MM-DD.
  If the exact day is unknown, use null — do NOT guess a day.
- If event_summary exceeds 30 words, rewrite it shorter while preserving meaning.
- If confidence='high' but date or geography is missing, downgrade confidence.
"""
```

---

## Starter Code

```python
"""
assignment2_pydantic_validation.py
────────────────────────────────────
C5i CI Pipeline — Pydantic Validation Loop with LLM-Driven Correction
"""

import json
from pydantic import ValidationError
# paste CompetitiveEvent schema here
# paste Setup block here

MAX_RETRIES = 3


def validate_event(raw_dict: dict) -> CompetitiveEvent:
    """Validate a single event dict. Raises ValidationError on failure."""
    return CompetitiveEvent(**raw_dict)


def correct_event(raw_dict: dict, error: ValidationError) -> dict:
    """
    Ask the LLM to fix a dict that failed Pydantic validation.
    Returns the corrected dict (still as raw dict — caller validates again).
    """
    correction_prompt = f"""The following JSON object failed schema validation.

ORIGINAL JSON:
{json.dumps(raw_dict, indent=2, default=str)}

VALIDATION ERRORS:
{error}

Return the corrected JSON object only.
"""
    # TODO: Call the LLM with CORRECTION_SYSTEM_PROMPT + correction_prompt
    # Parse and return the corrected dict
    corrected_text = ""  # replace with actual LLM call
    return json.loads(corrected_text)


def validate_with_retry(raw_dict: dict) -> tuple[CompetitiveEvent | None, list[str]]:
    """
    Try to validate raw_dict. On failure, ask the LLM to correct it and retry.
    Returns (validated_event_or_None, list_of_error_messages_per_attempt).
    """
    errors = []
    current = raw_dict

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            event = validate_event(current)
            return event, errors
        except ValidationError as e:
            errors.append(f"Attempt {attempt}: {e}")
            if attempt < MAX_RETRIES:
                print(f"  Validation failed (attempt {attempt}). Asking LLM to correct...")
                current = correct_event(current, e)

    return None, errors


def process_and_validate(article_text: str) -> dict:
    """
    Full pipeline: extract events from article, then validate each one.
    Returns a report dict with 'valid', 'corrected', and 'failed' lists.
    """
    # TODO: call extract_events() from Assignment 1
    # For each raw event dict, call validate_with_retry()
    # Categorise results into valid / corrected (passed after retry) / failed
    pass


if __name__ == "__main__":
    # Test articles with deliberate schema violations
    test_article = """
    Nestle India announced a 12% price increase for its Maggi noodles range
    effective April 2026, citing rising wheat and palm oil costs. The decision
    follows similar moves by HUL and ITC in Q1. Nestle's India CEO Suresh Narayanan
    described the increase as "unavoidable given commodity inflation". A separate
    Nestle press release confirmed a new distribution partnership with BigBasket
    covering 45 Tier 2 and Tier 3 cities across India, under which Nestle products
    will be available for 10-minute delivery via BigBasket's Superstore service.
    The deal was signed on 3rd March 2026.
    """
    report = process_and_validate(test_article)
    print(json.dumps(report, indent=2, default=str))
```

---

## Tasks

### Task 2A — Wire up the validation pipeline

Complete `correct_event` and `process_and_validate`. Run the test article and verify:
- The `pricing_change` event (Nestle price hike) passes validation
- The `partnership` event (Nestle + BigBasket) passes with `event_date = date(2026, 3, 3)`
- The `pricing_change` event for HUL/ITC (mentioned but no date or detail) is either
  extracted as a separate low-confidence event or correctly omitted

---

### Task 2B — Force validation failures and observe the correction loop

Construct a raw event dict with deliberate violations and feed it directly to
`validate_with_retry` (bypass the extractor):

```python
bad_events = [
    # Violation 1: wrong date format
    {
        "company_name": "Hindustan Unilever",
        "company_type": "competitor",
        "sector": "FMCG",
        "event_type": "pricing_change",
        "event_summary": "HUL increased prices for its personal care range.",
        "event_date": "March 2026",       # ← should be YYYY-MM-DD or null
        "geography": "India",
        "confidence": "high",
        "source_quote": "HUL raised prices in March 2026."
    },
    # Violation 2: event_summary too long
    {
        "company_name": "ITC Limited",
        "company_type": "competitor",
        "sector": "FMCG",
        "event_type": "product_launch",
        "event_summary": (
            "ITC has launched a completely new range of premium biscuits under "
            "the Sunfeast brand targeting urban millennial consumers who prefer "
            "high-protein low-sugar snack options and are willing to pay a premium."
        ),  # ← 37 words, exceeds 30-word limit
        "event_date": "2026-02-15",
        "geography": "India",
        "confidence": "high",
        "source_quote": "ITC launched a new Sunfeast premium biscuit range."
    },
    # Violation 3: confidence='high' but date and geography both null
    {
        "company_name": "Dabur India",
        "company_type": "competitor",
        "sector": "FMCG",
        "event_type": "acquisition",
        "event_summary": "Dabur acquired a herbal beverage startup.",
        "event_date": None,
        "geography": None,
        "confidence": "high",  # ← invalid: high requires date + geography
        "source_quote": "Dabur announced the acquisition of a herbal beverage startup."
    },
]
```

For each bad event:
1. Record the Pydantic error message from attempt 1
2. Record the corrected dict returned by the LLM after attempt 1
3. Record whether attempt 2 passed validation — if not, explain why

---

### Task 2C — Multi-violation record (requires 2 correction rounds)

Design one event dict that has **two independent violations** (e.g., bad date
format AND summary too long). Observe:

1. Does the LLM fix both violations in one correction pass, or only one?
2. If only one is fixed, does the second correction pass fix the remaining violation?
3. How many retries were needed to reach a valid record?

**Questions to answer in your submission:**
- Is it more reliable to instruct the LLM to fix all errors in one pass, or to
  fix one error at a time and re-validate?
- What is the trade-off between `MAX_RETRIES = 3` and cost/latency in production?

---

### Task 2D — Schema evolution: add a required `impact_score` field

Add a new required field to `CompetitiveEvent`:

```python
impact_score: int = Field(..., ge=1, le=10,
    description="Estimated strategic impact from 1 (minor) to 10 (major)")
```

The extractor was not told about this field, so all existing extractions will
fail validation with `"Field required"`.

1. Update `EXTRACTION_SYSTEM_PROMPT` in Assignment 1 to instruct the LLM to
   include `impact_score` in every event, with a clear rubric
   (e.g., acquisition of >₹1000 crore = 8–10, pricing change = 3–5).
2. Rerun the pipeline on Article A. Verify `impact_score` is present and
   within the valid range.
3. Discuss: what is the risk of adding a subjective scored field to a CI pipeline?

---

### Deliverable

Submit `assignment2_pydantic_validation.py` with:
- Complete `correct_event`, `validate_with_retry`, and `process_and_validate`
- All four tasks' test cases included as a runnable `if __name__ == "__main__"` block
- Inline comments explaining each validation rule you added and why

---

---

# Assignment 3 — Client Intelligence Brief Generator: Structured Data → Document

## Background

C5i's analysts deliver weekly **Competitive Intelligence Briefs** to clients
across FMCG, Retail, and Pharma verticals. Each brief is a 2–3 page document
that synthesises the week's competitive events into a structured narrative:
trends, strategic implications, and a recommended watch-list.

Currently analysts spend 4–6 hours per brief manually writing the narrative from
their event tracker spreadsheets. You are building an **LLM-driven brief generator**
that takes the validated structured events from Assignments 1 and 2 and produces
a polished, client-ready document.

This assignment tests your ability to:

- Apply **role prompting** to achieve a consistent professional voice and tone
- Use **template-driven output** to ensure document structure is reproducible
- Implement **section-specific sub-prompts** to control the depth and focus
  of each part of the document
- Handle **multi-company, multi-event synthesis** (grouping, trends, implications)

---

## Brief Structure

```
═══════════════════════════════════════════════════════════════
      C5i COMPETITIVE INTELLIGENCE BRIEF
      Weekly Market Monitor — [Client Name] | [Vertical]
      Issue #[N] — Week of [Date Range]
═══════════════════════════════════════════════════════════════

EXECUTIVE SUMMARY
  3–4 sentences: the most strategically significant development this week
  and its immediate implication for the client.

KEY EVENTS THIS WEEK
  A numbered list of all events, grouped by event_type.
  Each entry: Company | Event Type | Summary | Date | Geography | Impact

TREND ANALYSIS
  2–3 paragraphs identifying patterns across this week's events.
  Each paragraph covers one trend with supporting evidence from the events list.
  Example trends: "Pricing pressure across packaged foods", "M&A consolidation
  in quick commerce", "Leadership churn in legacy FMCG".

STRATEGIC IMPLICATIONS FOR [CLIENT]
  3–5 bullet points. Each bullet: one implication + one recommended action.
  Written from the perspective of the client's competitive position.

WATCH LIST
  3 companies or developments to monitor next week.
  For each: Company | Why to watch | Signal to look for

═══════════════════════════════════════════════════════════════
PREPARED BY: C5i Analytics | CONFIDENTIAL
NOT FOR DISTRIBUTION OUTSIDE [CLIENT NAME]
═══════════════════════════════════════════════════════════════
```

---

## Starter Code

```python
"""
assignment3_brief_generator.py
────────────────────────────────
C5i Competitive Intelligence — Structured Events to Client Brief
"""

import json
from datetime import date

# paste Setup block here
# paste CompetitiveEvent Pydantic model here (or import from assignment2)


BRIEF_WRITER_SYSTEM_PROMPT = """
You are a Senior Competitive Intelligence Analyst at C5i Analytics, a global
analytics firm. You write weekly Competitive Intelligence Briefs for Fortune 500
clients across FMCG, Retail, and Pharma verticals.

YOUR VOICE AND TONE
────────────────────
• Executive, precise, and commercially aware — not academic
• Confident with recommendations — clients pay for your point of view, not
  just a summary of what happened
• Neutral on company names (no PR language like "leading player" unless
  quoting a source) — state facts and draw implications
• Jargon-free enough for a CMO to read, specific enough for a strategy team

WHAT YOU MUST NEVER DO
───────────────────────
• Do not fabricate events not present in the input data
• Do not attribute statements to named individuals unless they appear in source_quote
• Do not speculate about stock prices, financial outcomes, or regulatory decisions
  beyond what is stated in the event data
• Do not reference events from outside the provided data window

SECTION LENGTH TARGETS
───────────────────────
• Executive Summary   : 60–80 words
• Key Events          : One line per event (20–30 words each)
• Trend Analysis      : 150–200 words total across 2–3 paragraphs
• Strategic Implications: 5 bullets, 25–40 words each
• Watch List          : 3 entries, 2–3 sentences each
"""


def generate_executive_summary(events: list[dict], client: str, vertical: str) -> str:
    prompt = f"""
You are writing the Executive Summary section of a CI brief for {client},
a company in the {vertical} sector.

The events data for this week is:
<events>
{json.dumps(events, indent=2, default=str)}
</events>

Write the Executive Summary section ONLY (60–80 words). Identify the single
most strategically significant event and state its implication for {client}.
Do not use a heading — return just the paragraph text.
"""
    # TODO: Call LLM with BRIEF_WRITER_SYSTEM_PROMPT as system
    return ""


def generate_key_events_table(events: list[dict]) -> str:
    prompt = f"""
Format the following events as a numbered list for the "Key Events This Week"
section of a CI brief. Group events by event_type (e.g., all acquisitions
together, then all executive_changes, etc.).

For each event use this format:
  [N]. [Company] | [Event Type] | [Summary] | [Date or 'Date not confirmed'] | [Geography or 'Unknown']

Events data:
<events>
{json.dumps(events, indent=2, default=str)}
</events>

Return only the formatted list. No introduction or conclusion.
"""
    # TODO: Call LLM with BRIEF_WRITER_SYSTEM_PROMPT as system
    return ""


def generate_trend_analysis(events: list[dict], vertical: str) -> str:
    prompt = f"""
Write the Trend Analysis section of a CI brief covering the {vertical} vertical.
Analyse the following events and identify 2–3 meaningful patterns or trends.

Each trend should:
- Have a clear, concise name (e.g., "Pricing Pressure in Packaged Foods")
- Be supported by at least 2 specific events from the data
- Include a forward-looking sentence about whether the trend is likely to intensify

Total length: 150–200 words across 2–3 paragraphs. No bullet points — prose only.

Events data:
<events>
{json.dumps(events, indent=2, default=str)}
</events>
"""
    # TODO: Call LLM with BRIEF_WRITER_SYSTEM_PROMPT as system
    return ""


def generate_strategic_implications(
    events: list[dict], client: str, client_profile: str
) -> str:
    prompt = f"""
Write the Strategic Implications section for {client}.

Client profile: {client_profile}

Write exactly 5 bullet points. Each bullet must:
- Name a specific implication arising from this week's events (not generic advice)
- Follow with a concrete recommended action for {client}
- Be 25–40 words

Format each bullet as: • [Implication]: [Recommended Action]

Events data:
<events>
{json.dumps(events, indent=2, default=str)}
</events>
"""
    # TODO: Call LLM with BRIEF_WRITER_SYSTEM_PROMPT as system
    return ""


def generate_watch_list(events: list[dict], client: str) -> str:
    prompt = f"""
Write the Watch List section for a CI brief for {client}.

Select 3 companies or developments from this week's data that deserve monitoring
next week. For each entry provide:
  Company/Development | Why to watch | Specific signal to look for next week

Format: a short paragraph (2–3 sentences) per entry, preceded by a bold label.

Events data:
<events>
{json.dumps(events, indent=2, default=str)}
</events>
"""
    # TODO: Call LLM with BRIEF_WRITER_SYSTEM_PROMPT as system
    return ""


def generate_brief(
    events: list[dict],
    client: str,
    vertical: str,
    client_profile: str,
    issue_number: int,
    week_ending: date,
) -> str:
    """Assemble the full CI brief from section generators."""

    week_start = week_ending.replace(day=week_ending.day - 6)

    header = f"""
{'═' * 63}
      C5i COMPETITIVE INTELLIGENCE BRIEF
      Weekly Market Monitor — {client} | {vertical}
      Issue #{issue_number} — Week of {week_start.strftime('%d %b')}–{week_ending.strftime('%d %b %Y')}
{'═' * 63}
"""

    # TODO: Call each section generator and assemble the full document
    # Sections: Executive Summary, Key Events, Trend Analysis,
    #           Strategic Implications, Watch List, Footer

    footer = f"""
{'═' * 63}
PREPARED BY: C5i Analytics | CONFIDENTIAL
NOT FOR DISTRIBUTION OUTSIDE {client.upper()}
{'═' * 63}
"""

    return header + "\n[TODO: assemble sections]\n" + footer


# ── Sample data for testing ────────────────────────────────────────────────────

SAMPLE_EVENTS = [
    {
        "company_name": "Hindustan Unilever Limited",
        "company_type": "competitor",
        "sector": "FMCG",
        "event_type": "acquisition",
        "event_summary": "HUL acquired Havmor Ice Cream for ₹2,400 crore to enter premium frozen desserts.",
        "event_date": "2026-03-14",
        "geography": "India",
        "confidence": "high",
        "source_quote": "Hindustan Unilever Limited today announced the acquisition of Havmor Ice Cream Pvt. Ltd. for ₹2,400 crore",
        "impact_score": 8,
    },
    {
        "company_name": "Hindustan Unilever Limited",
        "company_type": "competitor",
        "sector": "FMCG",
        "event_type": "executive_change",
        "event_summary": "HUL MD Sanjiv Mehta moves to advisory role; Rohit Jawa appointed MD & CEO from June 2026.",
        "event_date": "2026-06-01",
        "geography": "India",
        "confidence": "high",
        "source_quote": "Sanjiv Mehta will transition from his role as Managing Director to an advisory position effective 1 June 2026",
        "impact_score": 6,
    },
    {
        "company_name": "Nestle India",
        "company_type": "competitor",
        "sector": "FMCG",
        "event_type": "pricing_change",
        "event_summary": "Nestle raised Maggi noodle prices by 12% citing wheat and palm oil cost inflation.",
        "event_date": "2026-03-10",
        "geography": "India",
        "confidence": "high",
        "source_quote": "Nestle India announced a 12% price increase for its Maggi noodles range effective April 2026",
        "impact_score": 5,
    },
    {
        "company_name": "Nestle India",
        "company_type": "competitor",
        "sector": "FMCG",
        "event_type": "partnership",
        "event_summary": "Nestle partnered with BigBasket for 10-minute delivery across 45 Tier 2 and 3 cities.",
        "event_date": "2026-03-03",
        "geography": "India",
        "confidence": "high",
        "source_quote": "a new distribution partnership with BigBasket covering 45 Tier 2 and Tier 3 cities across India",
        "impact_score": 7,
    },
    {
        "company_name": "Reliance Retail",
        "company_type": "competitor",
        "sector": "Retail",
        "event_type": "acquisition",
        "event_summary": "Reliance Retail in reported advanced talks to acquire a quick-commerce startup at $500M valuation.",
        "event_date": None,
        "geography": "India",
        "confidence": "low",
        "source_quote": "Industry sources suggest Reliance Retail may be in advanced talks to acquire a majority stake in a leading quick-commerce startup",
        "impact_score": 7,
    },
]

CLIENT_PROFILE = """
ITC Limited — FMCG division. Key categories: biscuits (Sunfeast), noodles
(Yippee!), personal care (Fiama, Vivel), staples (Aashirvaad). Primary
competitors: HUL, Nestle, Britannia, Dabur. Currently investing in premiumisation
and direct-to-consumer channels. Concerned about price competition and e-commerce
channel shifts following competitor quick-commerce moves.
"""

if __name__ == "__main__":
    brief = generate_brief(
        events=SAMPLE_EVENTS,
        client="ITC Limited",
        vertical="FMCG",
        client_profile=CLIENT_PROFILE,
        issue_number=14,
        week_ending=date(2026, 3, 14),
    )
    print(brief)
```

---

## Tasks

### Task 3A — Generate the full brief

Complete all section generators and `generate_brief`. Run it on `SAMPLE_EVENTS`
with client = **ITC Limited**.

**Quality checks:**
- Executive Summary: Does it correctly identify HUL's Havmor acquisition as the
  lead story and connect it to ITC's frozen desserts exposure?
- Key Events: Are all 5 events listed? Are the acquisition events grouped together?
- Trend Analysis: Does it identify "pricing pressure" (Nestle + implied HUL) as
  one trend and "e-commerce channel shift" (Nestle-BigBasket + Reliance) as another?
- Strategic Implications: Are all 5 bullets specific to ITC (Yippee! vs Maggi,
  quick-commerce gap, etc.) rather than generic FMCG advice?
- Watch List: Is the Reliance Retail acquisition rumour flagged (it's unconfirmed)?

---

### Task 3B — Tone and voice consistency test

Run `generate_brief` a second time with the same input at `temperature=0.7`.
Compare the two briefs on:

| Dimension | Run 1 | Run 2 |
|---|---|---|
| Executive Summary word count | | |
| Any fabricated facts (events not in input)? | | |
| Any PR-style language ("leading player", "exciting move")? | | |
| Strategic Implications: specific to ITC or generic? | | |
| Tone: executive/analytical or journalistic/narrative? | | |

**Questions to answer:**
- Does the system prompt reliably enforce tone, or does temperature override it?
- Which section was most variable across runs? Why might that section be harder
  to constrain with prompting alone?

---

### Task 3C — Change the client persona and observe content shift

Run the same `SAMPLE_EVENTS` through `generate_brief` with a different client:

```python
BRITANNIA_PROFILE = """
Britannia Industries — biscuits, bread, dairy. Primary competitors: ITC Sunfeast,
Parle, HUL. No presence in noodles or frozen foods. Strong modern trade distribution.
Looking to expand quick-commerce footprint. Sensitive to commodity cost inflation
(wheat, palm oil) as key cost drivers.
"""

brief_britannia = generate_brief(
    events=SAMPLE_EVENTS,
    client="Britannia Industries",
    vertical="FMCG",
    client_profile=BRITANNIA_PROFILE,
    issue_number=14,
    week_ending=date(2026, 3, 14),
)
```

**Compare** the Strategic Implications section for ITC vs Britannia:
- Are the implications genuinely different, or does the LLM produce generic FMCG advice?
- Does the Nestle-BigBasket event get a different framing for Britannia (distribution
  threat) vs ITC (channel competition)?
- What prompt change would make the client-specific tailoring more reliable?

---

### Task 3D — Handle low-confidence and missing-date events

The Reliance Retail event has `confidence = "low"` and `event_date = null`.

The brief must handle these gracefully:
1. In **Key Events**, unconfirmed events should be visually distinguished
   (e.g., prefixed with `[UNCONFIRMED]`).
2. In **Trend Analysis**, the LLM should not state the Reliance acquisition as fact.
3. In **Watch List**, it should appear as a primary watch item precisely because
   it is unconfirmed.

Add instructions to the relevant section prompts to enforce this behaviour.
Test by temporarily setting all events to `confidence = "low"` and verifying
the brief reflects appropriate uncertainty throughout.

---

### Task 3E — Multi-vertical brief (extension)

C5i also produces **cross-vertical** briefs that cover FMCG and Retail in
a single document. Add a new client config:

```python
CROSS_VERTICAL_EVENTS = SAMPLE_EVENTS + [
    {
        "company_name": "Meesho",
        "company_type": "competitor",
        "sector": "Retail",
        "event_type": "funding",
        "event_summary": "Meesho raised $300M Series G targeting profitability in Tier 3 cities.",
        "event_date": "2026-03-12",
        "geography": "India",
        "confidence": "high",
        "source_quote": "Meesho announced a $300 million Series G funding round.",
        "impact_score": 8,
    },
]
```

Modify `generate_brief` to accept an optional `verticals: list[str]` parameter.
When multiple verticals are provided, add a **Cross-Vertical Signals** section
between Trend Analysis and Strategic Implications that flags events where a
development in one vertical has implications for the other.

---

### Deliverable

Submit `assignment3_brief_generator.py` with:
- All section generators fully implemented
- Tasks 3A through 3D completed and runnable
- A sample output file `sample_brief_itc.txt` containing the generated brief
  from Task 3A
- A 150-word reflection (as a docstring at the top of the file) addressing:
  *Where does this pipeline still require human review before the brief is
  sent to the client, and why?*

---

---

## Overall Grading Rubric

| Criterion | Weight | Description |
|---|---|---|
| **Extraction accuracy** | 20% | Assignment 1: correct field extraction, null vs fabricated, multi-event splitting |
| **Validation robustness** | 25% | Assignment 2: Pydantic schema enforced, correction loop converges, retries logged |
| **Document quality** | 25% | Assignment 3: sections meet length targets, tone is consistent, client-specific tailoring works |
| **Prompt engineering craft** | 20% | Prompts are precise, minimal, and demonstrate deliberate technique (XML delimiters, role prompting, format control) |
| **Observation depth** | 10% | Written answers show genuine understanding of *why* the LLM behaved as it did |

---

## Key Takeaways

```
Assignment 1 teaches you:
  → Output format control (JSON) is the foundation of any LLM data pipeline
  → XML delimiters prevent the article text from contaminating your instructions
  → null over fabrication is a design decision you must make explicit in the prompt

Assignment 2 teaches you:
  → Pydantic is not just type safety — it is a feedback signal for the LLM
  → The validate → error-as-prompt → retry loop is one of the most reusable
    patterns in production LLM engineering
  → Schema evolution (adding fields) forces you to update extraction prompts —
    schema and prompt are tightly coupled

Assignment 3 teaches you:
  → Section-specific sub-prompts give more control than one giant document prompt
  → Role prompting sets the voice, but temperature and length constraints set
    the discipline — both are needed
  → Client-specific tailoring requires explicit client context in the prompt,
    not just the event data

All three point to the same conclusion:
  Structured output + validation + document generation is a complete, reusable
  pattern for knowledge-work automation. The quality ceiling is determined by
  how precisely you specify the schema, the validation rules, and the editorial
  voice — not by the LLM alone.
```
