# =============================================================================
# Word Embeddings for Text Classification
# Mean GloVe Vector (spaCy en_core_web_md) + Logistic Regression
# =============================================================================
#
# This demo builds directly on 01_tfidf_classifier.py.
# It replaces the TF-IDF sparse count vector with a DENSE SEMANTIC VECTOR
# by averaging the pre-trained GloVe word vectors of every word in the
# article, then feeding that single 300-dimensional vector (dimension values averaged over all words in the document)
# to a LogisticRegression classifier. Note the 300 dimensions become the "features" that the classifier learns weights for, 
# instead of the thousands of word features in TF-IDF.
#
# The "before and after" section demonstrates three articles that are
# DELIBERATELY designed to expose TF-IDF's three core weaknesses, and shows
# how word embeddings overcome each one.
#
# TF-IDF WEAKNESS 1 — SYNONYMY
# ─────────────────────────────────────────────────────────────────────────────
#   TF-IDF is a VOCABULARY LOOK-UP: a word only contributes signal if that
#   exact string appeared in the training corpus. It has no concept of meaning.
#
#   If the training data always says "scored a goal" but the test article says
#   "netted a hat-trick", TF-IDF sees unknown tokens and produces a zero vector.
#   The model has learned nothing about football — it only learned the specific
#   words it was shown.
#
#   Real example in this file:
#     Training vocabulary : "scored", "goal", "team", "championship", "match"
#     Test article uses   : "netted", "hat-trick", "winger", "Premier League"
#     TF-IDF result       : all-zero feature vector → wrong prediction
#     Embeddings result   : vector("netted") ≈ vector("scored") in GloVe space
#                           → document vector lands in the sports cluster → correct
#
#   In c5i work this hits hard in customer feedback and social listening:
#   customers say "knackered", "bust", "dead on arrival" for the same product
#   defect — none of which may appear in the training labels.
#
# TF-IDF WEAKNESS 2 — SEMANTIC PARAPHRASE
# ─────────────────────────────────────────────────────────────────────────────
#   Even when entire SENTENCES are paraphrased — same meaning, completely
#   different words — TF-IDF sees zero overlap and produces a zero vector.
#
#   This is a superset of synonymy: it is not just one word being replaced
#   but the whole vocabulary of a topic being expressed differently.
#
#   Real example in this file:
#     Training vocabulary : "parliament", "party", "minister", "budget", "debate"
#     Test article uses   : "lawmakers", "fiscal", "legislation", "partisan"
#     TF-IDF result       : all-zero vector → defaults to majority-class prior
#     Embeddings result   : "lawmakers" near "parliament", "fiscal" near "budget"
#                           → document vector in politics cluster → correct
#
#   In c5i work this affects marketing analytics: an earnings call transcript
#   may use "cost efficiency programme" while the training labels said
#   "restructuring" — TF-IDF misses the link; embeddings do not.
#
# TF-IDF WEAKNESS 3 — OUT-OF-VOCABULARY DOMAIN SLANG / NEOLOGISMS
# ─────────────────────────────────────────────────────────────────────────────
#   Language evolves. New products, platforms, and cultural terms appear
#   constantly. A model trained even six months ago will never have seen them.
#   TF-IDF silently discards every unknown token; the document vector degrades
#   proportionally to how new the vocabulary is.
#
#   Real example in this file:
#     Training vocabulary : "pop star", "album", "charts", "singer", "music"
#     Test article uses   : "rapper", "mixtape", "Grammy", "viral", "TikTok"
#     TF-IDF result       : near-zero vector → wrong prediction
#     Embeddings result   : "rapper" near "singer", "mixtape" near "album",
#                           "Grammy" near "award" → still lands in entertainment
#
#   In c5i work this is critical for digital shelf analytics and social
#   listening: brand names, SKU codes, and platform-specific slang ("collab",
#   "duet", "haul") arrive faster than retraining cycles allow.
#
# ROOT CAUSE OF ALL THREE WEAKNESSES
# ─────────────────────────────────────────────────────────────────────────────
#   All three failures share the same root cause: TF-IDF represents words as
#   INDEPENDENT ATOMIC SYMBOLS with no relationship to each other.
#   "netted" and "scored" are as different as "netted" and "parliament" —
#   they are just two different strings.
#
#   Word embeddings fix this by placing words in a SHARED GEOMETRIC SPACE
#   where distance encodes semantic similarity. Words that appear in similar
#   contexts during pre-training end up near each other — so synonyms,
#   paraphrases, and even unseen slang land close to known words, and the
#   averaged document vector still falls in the right neighbourhood.
#
# Requirement (run once if not already done):
#   python -m spacy download en_core_web_md
#
# =============================================================================
# HOW MEAN WORD VECTORS WORK
# =============================================================================
#
# Step 1 — Tokenise
#   spaCy splits text into word tokens: ["The", "squad", "netted", ...]
#
# Step 2 — Look up each token's pre-trained GloVe vector
#   spaCy's en_core_web_md contains 300-dimensional GloVe vectors for
#   ~20,000 common English words, trained on Common Crawl (billions of
#   web pages). Each word is a POINT in 300-dimensional space, and words
#   with similar meaning are geometrically CLOSE to each other:
#
#     vector("squad")  is close to  vector("team")
#     vector("netted") is close to  vector("scored")
#     vector("strike") is close to  vector("goal")
#     vector("rapper") is close to  vector("singer")
#
#   This is the key property that BoW / TF-IDF completely lacks.
#
# Step 3 — Average all token vectors
#   document_vector = mean( v_token1, v_token2, ..., v_tokenN )
#
#   This collapses the whole article into one 300-dimensional point that
#   approximates the semantic "centre of gravity" of the text.
#   spaCy computes this automatically via  doc.vector.
#
# Step 4 — Train Logistic Regression on the document vectors
#   Logistic Regression learns one 300-dimensional weight vector per class.
#   At prediction time it scores each class and picks the highest.
#
# Why Logistic Regression instead of Naive Bayes?
#   Naive Bayes requires non-negative features (word counts are always >= 0).
#   GloVe embedding dimensions are signed floats that CAN be negative.
#   Logistic Regression handles signed, continuous features natively and
#   is the standard pairing for dense vector document representations.
#
# =============================================================================

import textwrap

import numpy as np
import spacy
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

# Load the medium spaCy model — has 300-dim GloVe vectors for ~20k words.
# If not yet downloaded:  python -m spacy download en_core_web_md
nlp = spacy.load("en_core_web_md")

# ---------------------------------------------------------------------------
# Custom scikit-learn transformer: list of strings → (n, 300) numpy array
# ---------------------------------------------------------------------------

class MeanWordVectorizer(BaseEstimator, TransformerMixin):
    """
    Converts each document to the mean of its token GloVe vectors.
    doc.vector in spaCy already computes this mean, so transform is trivial.
    """
    def __init__(self, nlp_model):
        self.nlp_model = nlp_model

    def fit(self, X, y=None):
        return self                        # nothing to learn — vectors are pre-trained

    def transform(self, X):
        # shape: (n_documents, 300)
        return np.array([self.nlp_model(text).vector for text in X])

# ---------------------------------------------------------------------------
# Training data — same corpus as 01_article_classification.py
# (keeping it identical makes the before/after comparison fair)
# ---------------------------------------------------------------------------

train_texts = [
    # Sports
    "The football team won the championship after a thrilling final match.",
    "Rohit Sharma scored a brilliant century to lead India to victory.",
    "The tennis star claimed her third Grand Slam title of the season.",
    "Manchester United signed a new striker for a record transfer fee.",
    "The Olympics opening ceremony drew millions of viewers worldwide.",
    "The basketball player broke the all-time scoring record last night.",
    "Spain's national team clinched the World Cup with a stunning goal.",
    "The marathon runner set a new world record at the Berlin race.",

    # Entertainment
    "The blockbuster film grossed over a billion dollars at the box office.",
    "The pop star announced a world tour starting next month in London.",
    "The award-winning actress received an Oscar for her role in the drama.",
    "A new streaming series broke viewership records on its premiere weekend.",
    "The music album debuted at number one on charts in fifteen countries.",
    "Hollywood director unveiled the trailer for his highly anticipated sequel.",
    "The comedian's stand-up special became the most-watched show on the platform.",
    "The fashion icon launched a new clothing line at Milan Fashion Week.",
    "The celebrity couple confirmed their engagement, with fans celebrating on social media.",
    "A viral video of the actress's red carpet look sent social media into a frenzy.",
    "The reality TV star's wedding was watched by millions on the streaming platform.",
    "Celebrity gossip dominated social media after the singer confirmed the romance.",

    # Politics
    "The prime minister announced a new budget focused on infrastructure spending.",
    "Parliament passed the landmark climate bill after months of debate.",
    "The senator called for an independent inquiry into the defence contract.",
    "Diplomatic talks between the two nations resumed after a year-long freeze.",
    "The opposition party filed a motion of no confidence against the cabinet.",
    "Voters went to the polls in a closely contested gubernatorial election.",
    "The president signed an executive order on immigration policy reform.",
    "United Nations delegates agreed on a new global trade framework.",
]

train_labels = (
    ["sports"] * 8
    + ["entertainment"] * 12
    + ["politics"] * 8
)

# ---------------------------------------------------------------------------
# Pipeline A — TF-IDF + Naive Bayes  (from demo 01, kept for comparison)
# ---------------------------------------------------------------------------

tfidf_pipeline = Pipeline([
    ("vectorizer", TfidfVectorizer(stop_words="english")),
    ("classifier", MultinomialNB()),
])
tfidf_pipeline.fit(train_texts, train_labels)

# ---------------------------------------------------------------------------
# Pipeline B — Mean GloVe vector + Logistic Regression  (this demo)
# ---------------------------------------------------------------------------

embedding_pipeline = Pipeline([
    ("vectorizer", MeanWordVectorizer(nlp)),
    ("classifier", LogisticRegression(max_iter=1000, C=0.5)),
])
embedding_pipeline.fit(train_texts, train_labels)

# ---------------------------------------------------------------------------
# Helper: compare predictions side-by-side for one article
# ---------------------------------------------------------------------------

def compare(article, true_label, shortcoming, key_words, explanation):
    tfidf_pred  = tfidf_pipeline.predict([article])[0]
    tfidf_proba = tfidf_pipeline.predict_proba([article])[0]
    emb_pred    = embedding_pipeline.predict([article])[0]
    emb_proba   = embedding_pipeline.predict_proba([article])[0]

    tfidf_classes = tfidf_pipeline.classes_
    emb_classes   = embedding_pipeline.classes_

    verdict_t = "CORRECT" if tfidf_pred == true_label else "WRONG  "
    verdict_e = "CORRECT" if emb_pred   == true_label else "WRONG  "

    t_scores = "  ".join(f"{c}={p:.2f}" for c, p in zip(tfidf_classes, tfidf_proba))
    e_scores = "  ".join(f"{c}={p:.2f}" for c, p in zip(emb_classes,   emb_proba))

    # Wrap explanation text at ~72 chars for readability
    wrapped = textwrap.fill(explanation, width=72, subsequent_indent="                ")

    print(f"  Shortcoming : {shortcoming}")
    print(f"  Article     : {article}")
    print(f"  Key words   : {key_words}")
    print(f"  True label  : {true_label}")
    print(f"  Explanation : {wrapped}")
    print(f"  TF-IDF      : {verdict_t} => {tfidf_pred:<15}  ({t_scores})")
    print(f"  Embeddings  : {verdict_e} => {emb_pred:<15}  ({e_scores})")

# =============================================================================
# PROOF: synonymous words are close in GloVe vector space
# =============================================================================
# Before the classification comparison, let's make the core claim concrete.
# cosine similarity = 1.0 means identical direction, 0.0 means unrelated.
# TF-IDF treats every word below as a COMPLETELY DIFFERENT, UNRELATED feature.

print("=" * 70)
print("  GloVe vector similarity - words TF-IDF treats as completely unrelated")
print("=" * 70)

# Only pairs where the GloVe similarity is meaningful (>= 0.2).
# Low-similarity pairs would be misleading to show here.
word_pairs = [
    # sports  (used in Example 1)
    ("netted",      "scored"),
    # politics (used in Example 2)
    ("lawmakers",   "parliament"),
    ("legislation", "bill"),
    ("fiscal",      "budget"),
    # entertainment (used in Example 3)
    ("mixtape",     "album"),
    ("rapper",      "singer"),
]

for w1, w2 in word_pairs:
    sim = nlp(w1).similarity(nlp(w2))
    bar = "#" * int(sim * 20)
    print(f"  {w1:<14} vs {w2:<12}  similarity={sim:.2f}  [{bar:<20}]")

print()
print("  TF-IDF score for every pair above: 0.00 (treated as completely unrelated)")
print("  GloVe cosine similarity: ranges from moderate to very high (see bars above)")

# =============================================================================
# BEFORE & AFTER: three articles exposing TF-IDF's weaknesses
# =============================================================================

print("\n" + "=" * 70)
print("  BEFORE vs AFTER - TF-IDF vs Mean Word Embeddings")
print("=" * 70)
print("""
  NOTE — Why does TF-IDF predict "Entertainment" for every example?
  ─────────────────────────────────────────────────────────────────
  All three test articles use words that were never seen during training
  (out-of-vocabulary). TF-IDF produces an all-zero feature vector for
  them, leaving Naive Bayes with zero signal.

  With no signal, Naive Bayes falls back to the CLASS PRIOR — the
  fraction of training examples that belong to each class:

    Sports        =  8 / 28  =  29%
    Entertainment = 12 / 28  =  43%   ← largest class → wins every time
    Politics      =  8 / 28  =  29%

  This is not a meaningful prediction; it is the model guessing the
  most common class because it has learned nothing from the article.
""")

# ---------------------------------------------------------------------------
# Example 1 — SYNONYMY  (Sports)
#
# The training corpus uses specific football words: "scored", "goal", "team",
# "championship", "match". This test article covers the same topic — a footballer
# scoring multiple goals in a top-flight league — but uses DIFFERENT words
# for each concept. None of them appear in the TF-IDF vocabulary.
#
# Training vocabulary has : scored, goal, team, championship, match
# This article uses       : netted, hat-trick, winger, club, Premier League
#
# TF-IDF: every key sports word in this article is out-of-vocabulary.
#   All feature values = 0. Model has no signal, returns near-uniform
#   probabilities, and picks the wrong class.
#
# Embeddings: vector("netted") is almost identical to vector("scored") — a
#   verified cosine similarity of 1.00 (see proof section above).
#   "winger" lives close to "player/striker" in GloVe space, and
#   "Premier League" is close to "championship/World Cup".
#   The averaged document vector lands firmly in the sports region.
# ---------------------------------------------------------------------------

print("\n--- Example 1: Synonymy ---")
print("    (sports article using different words for the same concepts)\n")
compare(
    article="The winger netted a hat-trick, propelling his club to the top of the Premier League.",
    true_label="sports",
    shortcoming="Synonymy",
    key_words="netted=scored(sim 1.00)  winger=player  Premier League=championship",
    explanation=(
        "Every sports word here (netted, hat-trick, winger, Premier League) is "
        "absent from the TF-IDF training vocabulary. The feature vector is entirely "
        "zero, so Naive Bayes has no signal and falls back to the class prior. "
        "Entertainment has the highest prior (12/28 = 43%), so it wins by default — "
        "not because the article resembles entertainment content."
    ),
)

# ---------------------------------------------------------------------------
# Example 2 — SEMANTIC PARAPHRASE  (Politics)
#
# The article expresses a clear political idea using vocabulary that does
# NOT appear in the training set.
#
# Training vocabulary has : parliament, party, minister, cabinet, budget, debate
# This article uses       : lawmakers, fiscal, legislation, partisan, disagreements
#
# TF-IDF: none of these article words exist in its learned vocabulary.
#   Features are all zero → near-uniform probabilities → wrong prediction.
#
# Embeddings: "lawmakers"  lives near "parliament/senator" in GloVe space,
#             "fiscal"     lives near "budget/financial",
#             "legislation"lives near "bill/law",
#             "partisan"   lives near "party/political"
#   The document vector settles into the politics neighbourhood → correct.
# ---------------------------------------------------------------------------

print("\n--- Example 2: Semantic paraphrase ---")
print("    (politics expressed in entirely different vocabulary from training)\n")
compare(
    article="Lawmakers clashed over fiscal legislation amid bitter partisan disagreements.",
    true_label="politics",
    shortcoming="Semantic paraphrase",
    key_words="lawmakers=parliament  fiscal=budget  legislation=bill  partisan=party",
    explanation=(
        "None of the political vocabulary (lawmakers, fiscal, legislation, partisan, "
        "disagreements) appears in the training corpus, so the TF-IDF vector is again "
        "all zeros. Naive Bayes defaults to the same Entertainment prior (12/28 = 43%) "
        "for the same reason as Example 1 — it has learned nothing from this article "
        "and is simply guessing the most common class."
    ),
)

# ---------------------------------------------------------------------------
# Example 3 — OUT-OF-VOCABULARY DOMAIN SLANG  (Entertainment)
#
# The article is clearly about the music / entertainment industry but uses
# genre-specific slang that was never in the training corpus.
#
# Training vocabulary has : pop star, album, charts, singer, music
# This article uses       : rapper, mixtape, platinum, Grammy, viral, TikTok
#
# TF-IDF: "rapper", "mixtape", "platinum", "Grammy" are all out-of-vocabulary.
#   The only weak signal is words like "debut" — not enough for a clear call.
#   Prediction is wrong or highly uncertain.
#
# Embeddings: "rapper"  is very close to "singer/pop star" in GloVe space,
#             "mixtape" is close to "album/record",
#             "Grammy"  is close to "Oscar/award" (both prestigious ceremonies),
#             "platinum"is close to "hit/popular/sold"
#   The document vector remains firmly in entertainment territory → correct.
# ---------------------------------------------------------------------------

print("\n--- Example 3: Out-of-vocabulary domain slang ---")
print("    (entertainment industry jargon not present in training data)\n")
compare(
    article="The Grammy-winning rapper's debut mixtape went double platinum after going viral.",
    true_label="entertainment",
    shortcoming="Out-of-vocabulary slang",
    key_words="rapper=singer  mixtape=album  Grammy=Oscar  platinum=hit",
    explanation=(
        "The domain slang (rapper, mixtape, Grammy, platinum, viral) is all "
        "out-of-vocabulary, producing another all-zero TF-IDF vector. Naive Bayes "
        "once again defaults to the Entertainment prior and predicts Entertainment — "
        "which happens to be the correct label, but for the wrong reason. TF-IDF "
        "did not understand the article; it just guessed the most common class and "
        "got lucky."
    ),
)

print("\n" + "=" * 70)
print("  Summary")
print("=" * 70)
print("""
  TF-IDF is a vocabulary lookup: a word either exists in training or it does
  not. Unknown words contribute zero signal, regardless of their meaning.

  Mean word embeddings work in semantic space: words close in meaning produce
  similar vectors, so the document vector captures the topic even when the
  exact training words were never used. This is why embedding-based classifiers
  generalise far better to real-world text, which is endlessly varied.

  The trade-off: embeddings require a large pre-trained model (en_core_web_md
  is ~43 MB; Google News Word2Vec is ~1.7 GB), while TF-IDF has zero external
  dependencies and can be trained entirely from your own data.
""")
