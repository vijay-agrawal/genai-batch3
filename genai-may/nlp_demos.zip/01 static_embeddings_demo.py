"""
=============================================================================
STATIC WORD EMBEDDINGS DEMO — Word2Vec (Google News) via Gensim
=============================================================================

WHAT ARE STATIC EMBEDDINGS?
-----------------------------
Static (or non-contextual) embeddings assign a FIXED vector to every word,
regardless of the sentence it appears in. The word "bank" always gets the
same vector, whether you mean a riverbank or a financial institution.

HOW IS WORD2VEC TRAINED?
-------------------------
Word2Vec (Mikolov et al., 2013) is trained with a shallow neural network
using one of two objectives:

  • CBOW (Continuous Bag of Words):
        Predict the CENTER word from its surrounding context words.
        Input: context words → Output: target word.

  • Skip-Gram:
        Predict the SURROUNDING context words from a center word.
        Input: target word → Output: context words.
        (Better for rare words; the Google News model uses Skip-Gram.)

  Training trick: Negative Sampling — instead of softmaxing over the entire
  vocabulary (millions of words), it trains binary classifiers that
  distinguish real context pairs from random "negative" pairs.

THE GOOGLE NEWS PRETRAINED MODEL:
----------------------------------
  • Model type  : Skip-Gram Word2Vec
  • Corpus      : ~100 billion words from Google News articles (~3M unique
                  words/phrases after pruning)
  • Vocabulary  : ~3,000,000 word tokens + n-grams (e.g. "New_York")
  • Dimensions  : 300 (each word = a vector of 300 float32 values)
  • Context     : Window size of 5 (5 words left + 5 words right = 10 words)
                  The model has NO MEMORY beyond this window. It never sees
                  the full document — only local sliding windows.
  • File size   : ~1.6 GB compressed (.bin.gz)

IMPORTANT — EMBEDDING WEIGHTS vs. INFERENCE LOOKUP:
-----------------------------------------------------
  During TRAINING, the network learns a weight matrix W of shape:
        [vocabulary_size × embedding_dimensions]  →  e.g. [3,000,000 × 300]

  Each row i in W is the embedding vector for word i.

  During INFERENCE (at runtime), there is NO matrix multiplication.
  It is purely a TABLE LOOKUP:
        embedding("king") = W[index_of("king")]   ← just fetch row 27,419

  This is why static embeddings are extremely fast and memory-efficient
  at inference time. The entire "model" is this frozen lookup table.

  Contrast this with contextual models (BERT, GPT) where every token runs
  through multiple transformer layers even at inference — much heavier.

LIMITATION — POLYSEMY (SAME WORD, DIFFERENT MEANINGS):
-------------------------------------------------------
  Because every word gets ONE fixed vector, words with multiple meanings
  (polysemous words) collapse all their meanings into a single point in
  vector space. This is the core weakness of static embeddings.

  Example: "bank" in
    "I sat on the river BANK"      ← geography / nature meaning
    "I went to the BANK to deposit" ← financial institution meaning
  Both sentences produce the IDENTICAL embedding for "bank".
  The model cannot tell them apart.

  This is solved by CONTEXTUAL embeddings (ELMo, BERT, GPT) which generate
  a different vector for the same token depending on the full sentence context.

=============================================================================
"""

import numpy as np
import gensim.downloader as api
from scipy.spatial.distance import cosine

# ─────────────────────────────────────────────────────────────────────────────
# 1. LOAD PRETRAINED STATIC EMBEDDINGS
#    gensim.downloader caches the model locally after the first download.
#    Using 'fasttext-wiki-news-subwords-300' (300-dimensional, ~960 MB).
#    See the model-choice comments below for alternatives and size trade-offs.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("Loading pretrained FastText model (Wikipedia News, 300 dimensions)...")
print("This may take a minute on first run — model is ~960 MB.")
print("=" * 70)

# ─────────────────────────────────────────────────────────────────────────────
# STATIC EMBEDDING MODEL CHOICES
#
# ── Why is Google's Word2Vec model so large (~1.6 GB)? ───────────────────────
# Word2Vec stores a plain matrix of shape [vocab_size × embedding_dim].
# There are NO sub-word tricks — every surface form gets its own row.
#
#   Google News Word2Vec:
#     Vocabulary  ≈ 3,000,000 words (one row per unique word/phrase)
#     Embedding dim = 300
#     Parameters  = 3,000,000 × 300 = 900,000,000 float32 numbers
#     Raw size    = 900 M × 4 bytes ≈ 3.6 GB   → ~1.5–2 GB after compression
#
# Because every token is stored whole, the vocabulary must be huge to handle
# the long tail of English (plurals, proper nouns, domain terms, etc.).
#
# ── Alternative models and why they are smaller ──────────────────────────────
#
# 1. FastText  (used below — recommended for this demo)
#    - Represents each word as its character n-grams (sub-word units).
#    - Vocabulary is kept much smaller because rare / unseen words are
#      reconstructed from their n-gram components at query time.
#    - "fasttext-wiki-news-subwords-300"  → ~960 MB  (300-dim, 1 M vocab)
#    - Bonus: handles misspellings and morphological variants gracefully.
#    - Change the api.load() call below to switch to FastText.
#
# 2. GloVe  (Global Vectors for Word Representation)
#    - Still token-level (same matrix layout as Word2Vec), but trained on
#      co-occurrence statistics rather than a skip-gram objective.
#    - "glove-wiki-gigaword-100"  → ~128 MB  (100-dim, 400 K vocab)
#    - "glove-wiki-gigaword-300"  → ~376 MB  (300-dim, 400 K vocab)
#
# 3. BPE (Byte-Pair Encoding) — used inside transformer tokenizers
#    - Merges frequent byte/character pairs iteratively until a target
#      vocabulary size is reached (typically 30 K–50 K merge rules).
#    - Not stored as a standalone embedding file; the embedding matrix lives
#      inside models like BERT/GPT.  Vocab is tiny (~50 K) but the hidden
#      dimension and number of layers dominate the file size there.
#    - Advantages: fixed vocab size, handles any language, no OOV words.
#
# ── Quick size comparison ────────────────────────────────────────────────────
#   Model                              Vocab      Dim   ~Size
#   word2vec-google-news-300           3 M words  300   1.6 GB
#   fasttext-wiki-news-subwords-300    1 M vocab  300   ~960 MB
#   glove-wiki-gigaword-300            400 K      300   ~376 MB
#   glove-wiki-gigaword-100            400 K      100   ~128 MB
#   (BPE lives inside transformer checkpoints — not a standalone file)
# ─────────────────────────────────────────────────────────────────────────────

# Using FastText sub-word embeddings for this demo.
# FastText reconstructs vectors for unknown words from character n-grams,
# making it more robust than pure Word2Vec for real-world text.
# To try Google Word2Vec instead, replace the model name with:
#   "word2vec-google-news-300"
model = api.load("fasttext-wiki-news-subwords-300")

vocab_size = len(model)
dims = model.vector_size

print(f"\nModel loaded successfully!")
print(f"  Vocabulary size : {vocab_size:,} words")
print(f"  Embedding dims  : {dims}")
print(f"  Type of lookup  : dict-like index → numpy float32 array")

# ─────────────────────────────────────────────────────────────────────────────
# 2. SHOW WHAT AN EMBEDDING ACTUALLY IS
#    At inference this is a row-fetch from the weight matrix — no computation.
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("SECTION 1 — What does an embedding look like?")
print("=" * 70)

demo_word = "king"
vec = model[demo_word]  # ← pure lookup: model.vectors[model.key_to_index["king"]]

print(f"\nWord      : '{demo_word}'")
print(f"Vector    : shape={vec.shape}, dtype={vec.dtype}")
print(f"First 10 dims: {np.round(vec[:10], 4)}")
print(f"\nNote: These 300 numbers encode the word's meaning as learned from")
print(f"co-occurrence statistics across 100 billion news words.")
print(f"At inference, fetching this vector costs O(1) — it is a table lookup.")

# ─────────────────────────────────────────────────────────────────────────────
# 3. SEMANTIC SIMILARITY — words that should be close/far
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("SECTION 2 — Semantic similarity between words")
print("(cosine similarity: 1.0 = identical direction, 0.0 = orthogonal)")
print("=" * 70)

pairs = [
    ("king",    "queen"),
    ("man",     "woman"),
    ("dog",     "cat"),
    ("doctor",  "hospital"),
    ("paris",   "france"),
    ("happy",   "sad"),
    ("car",     "airplane"),
    ("king",    "potato"),   # completely unrelated
]

for w1, w2 in pairs:
    sim = model.similarity(w1, w2)
    bar = "█" * int(sim * 30)
    print(f"  {w1:12s} ↔ {w2:12s}  sim={sim:.4f}  {bar}")

# ─────────────────────────────────────────────────────────────────────────────
# 4. ANALOGY — classic Word2Vec property: king - man + woman ≈ queen
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("SECTION 3 — Word analogies (vector arithmetic)")
print("(king - man + woman = ?)")
print("=" * 70)

analogies = [
    (["king"],   ["man"],    ["woman"],   "queen"),
    (["paris"],  ["france"], ["germany"], "berlin"),
    (["doctor"], ["man"],    ["woman"],   "nurse"),
]

for positive, negative, add, expected in analogies:
    results = model.most_similar(positive=positive + add, negative=negative, topn=3)
    top_word, top_score = results[0]
    print(f"\n  {positive[0]} - {negative[0]} + {add[0]} = ?")
    for word, score in results:
        marker = " ← expected" if word.lower() == expected else ""
        print(f"    {word:15s}  {score:.4f}{marker}")

# ─────────────────────────────────────────────────────────────────────────────
# 5. INDIA-SPECIFIC ANALOGIES — city → landmark & city → food
#    These show that the same vector arithmetic works across cultures.
#    Google News covered India extensively, so city/landmark/food terms
#    often appear as multi-word tokens (e.g. "Taj_Mahal", "Gateway_of_India").
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("SECTION 3b — India-specific analogies (city : landmark :: city : ?)")
print("           and (city : street food :: city : ?)")
print("=" * 70)

def safe_analogy(model, positive, negative, topn=5):
    """Run analogy only if all words are in vocabulary; warn otherwise."""
    missing = [w for w in positive + negative if w not in model]
    if missing:
        print(f"    [skipped — not in vocab: {missing}]")
        return []
    return model.most_similar(positive=positive, negative=negative, topn=topn)

# ── City → Landmark ──────────────────────────────────────────────────────────
print("\n  CITY → LANDMARK  (Agra : Taj_Mahal :: Mumbai : ?)")
print("  Logic: vector(Taj_Mahal) - vector(Agra) + vector(Mumbai)")
results = safe_analogy(model,
                       positive=["Taj_Mahal", "Mumbai"],
                       negative=["Agra"], topn=5)
for word, score in results:
    print(f"    {word:25s}  {score:.4f}")

print()
print("  Cross-check — Agra : Taj_Mahal :: Delhi : ?")
print("  Logic: vector(Taj_Mahal) - vector(Agra) + vector(Delhi)")
results = safe_analogy(model,
                       positive=["Taj_Mahal", "Delhi"],
                       negative=["Agra"], topn=5)
for word, score in results:
    print(f"    {word:25s}  {score:.4f}")

# ── City → Street Food ───────────────────────────────────────────────────────
print()
print("  CITY → STREET FOOD  (Pune : Misal_Pav :: Mumbai : ?)")
print("  Logic: vector(Misal_Pav) - vector(Pune) + vector(Mumbai)")
results = safe_analogy(model,
                       positive=["Vada_Pav", "Mumbai"],
                       negative=["Pune"], topn=5)
for word, score in results:
    print(f"    {word:25s}  {score:.4f}")

# ── Bonus: Country → Capital ─────────────────────────────────────────────────
print()
print("  BONUS — Country → Capital  (India : New_Delhi :: Pakistan : ?)")
results = safe_analogy(model,
                       positive=["New_Delhi", "Pakistan"],
                       negative=["India"], topn=3)
for word, score in results:
    print(f"    {word:25s}  {score:.4f}")

print("""
  Takeaway: Word2Vec's vector arithmetic is language- and culture-agnostic.
  As long as the training corpus mentioned "Taj_Mahal" near "Agra" often
  enough, the geometric relationship city → landmark is captured.
  Words missing from the Google News vocab (like regional street-food names)
  simply have no vector — that is the OOV limitation of static embeddings.
""")

# ─────────────────────────────────────────────────────────────────────────────
# 6. MOST SIMILAR WORDS
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("SECTION 4 — Nearest neighbours in embedding space")
print("=" * 70)

for word in ["bank", "python", "apple", "virus"]:
    neighbors = model.most_similar(word, topn=5)
    print(f"\n  Nearest to '{word}':")
    for nbr, score in neighbors:
        print(f"    {nbr:20s}  {score:.4f}")

# ─────────────────────────────────────────────────────────────────────────────
# 7. THE CORE LIMITATION — POLYSEMY / CONTEXT BLINDNESS
#
#    Static embeddings assign ONE vector per word token.
#    The word "bank" means something completely different in:
#       (a) "I sat on a river bank"         → geographic feature
#       (b) "I went to the bank to deposit" → financial institution
#
#    Because the model never reads full sentences at inference — it only
#    does a lookup — BOTH sentences produce the IDENTICAL "bank" vector.
#    There is no mechanism to separate meanings.
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("SECTION 5 — THE POLYSEMY PROBLEM (core static embedding limitation)")
print("=" * 70)

print("""
  Sentences:
    S1: "I sat on a river bank"
    S2: "I went to the bank to deposit money"

  In a static model, 'bank' has ONE fixed vector for BOTH sentences.
  Below we show what that single vector is closest to — it reflects the
  DOMINANT sense in the training corpus (financial news >> river references
  in Google News), so the geographic meaning is poorly represented.
""")

bank_vec   = model["bank"]
river_vec  = model["river"]
money_vec  = model["money"]
deposit_vec = model["deposit"]
finance_vec = model["finance"]

sim_river   = 1 - cosine(bank_vec, river_vec)
sim_money   = 1 - cosine(bank_vec, money_vec)
sim_deposit = 1 - cosine(bank_vec, deposit_vec)
sim_finance = 1 - cosine(bank_vec, finance_vec)

print(f"  Static 'bank' vector similarity to:")
print(f"    'river'   : {sim_river:.4f}  (geographic sense)")
print(f"    'money'   : {sim_money:.4f}  (financial sense)")
print(f"    'deposit' : {sim_deposit:.4f}  (financial sense)")
print(f"    'finance' : {sim_finance:.4f}  (financial sense)")

print("""
  Observation: the single 'bank' vector is much closer to financial words
  because Google News is dominated by financial content. The geographic
  meaning is nearly lost — even though it is equally valid in English.

  *** The embedding is the SAME regardless of which sentence you use. ***
  Static models are sentence-blind at the word level.
""")

# ─────────────────────────────────────────────────────────────────────────────
# 8. MORE POLYSEMY EXAMPLES
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("SECTION 6 — More polysemy examples (same word, different meanings)")
print("=" * 70)

polysemous = {
    "bat":   ("sports equipment",    ["cricket", "baseball", "hit"],
              "flying animal",       ["wing", "cave", "nocturnal"]),
    "light": ("not heavy",           ["weight", "feather", "easy"],
              "illumination",        ["lamp", "bright", "dark"]),
    "spring":("season",              ["summer", "autumn", "winter"],
              "coiled mechanism",    ["coil", "bounce", "elastic"]),
}

for word, (sense1, words1, sense2, words2) in polysemous.items():
    vec = model[word]
    avg1 = np.mean([model[w] for w in words1 if w in model], axis=0)
    avg2 = np.mean([model[w] for w in words2 if w in model], axis=0)
    s1 = 1 - cosine(vec, avg1)
    s2 = 1 - cosine(vec, avg2)
    print(f"\n  '{word}'")
    print(f"    sim to '{sense1}' cluster {words1}: {s1:.4f}")
    print(f"    sim to '{sense2}' cluster {words2}: {s2:.4f}")
    dominant = sense1 if s1 > s2 else sense2
    print(f"    → Static vector leans toward: '{dominant}' sense")

# ─────────────────────────────────────────────────────────────────────────────
# 9. SUMMARY
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)
print("""
  Static Embeddings (Word2Vec, GloVe, FastText):
  ┌──────────────────┬────────────────────────────────────────────────────┐
  │ Training         │ Shallow NN on local context windows (skip-gram /   │
  │                  │ CBOW) with negative sampling                        │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Corpus           │ Google News ~100B words (Word2Vec)                  │
  │                  │ Wikipedia + Gigaword ~6B words (GloVe)              │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Context window   │ Fixed small window (typically 5–10 tokens).        │
  │                  │ NO full-document or cross-sentence understanding.   │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Dimensions       │ Typically 100 – 300 float32 values per word        │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Inference        │ Pure table lookup — O(1), no matrix multiply.      │
  │                  │ The model IS the weight matrix (rows = word vecs). │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Strength         │ Fast, compact, captures semantic + syntactic        │
  │                  │ regularities, enables analogy arithmetic            │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Weakness         │ ONE vector per word type — context-blind.          │
  │                  │ "bank" (river) = "bank" (finance) forever.         │
  │                  │ Out-of-vocabulary words have no vector.            │
  └──────────────────┴────────────────────────────────────────────────────┘

  Solution → Contextual Embeddings (ELMo, BERT, GPT):
    Each TOKEN gets a different vector based on the full sentence context.
    "bank" in "river bank" ≠ "bank" in "bank deposit".
    Achieved via multi-layer transformer self-attention — much heavier at
    inference (not a lookup, but millions of float ops per token).
""")

# Test your Understanding


# Embedding Lookup:
# During inference, static embeddings perform a simple table lookup. 
# Why is this approach memory-efficient, and how does it differ from the computational requirements of contextual models like BERT?

# Polysemy Limitation:
# Static embeddings assign a single vector to a word, leading to issues with polysemy. 
# How does this limitation affect downstream NLP tasks?
# What are some strategies to mitigate this issue without switching to contextual embeddings?

# Context Window:
# The Google News Word2Vec model uses a context window of 5 words on either side of the target word. 
# How does this window size influence the quality of embeddings, and what trade-offs are involved in choosing a larger or smaller window?

# Embedding Dimensions:
# The Google News Word2Vec model uses 300-dimensional embeddings. 
# What are the advantages and disadvantages of using higher-dimensional embeddings,
# and how does the choice of dimensionality impact the model's performance and storage requirements?

# ANSWERS


# Embedding Lookup:
# Static embeddings are memory-efficient because they store precomputed vectors in a lookup table. 
# During inference, retrieving a word's embedding is a simple table lookup operation, which is computationally inexpensive. 
# In contrast, contextual models like BERT require multiple layers of computation (e.g., self-attention and feed-forward layers)
#  for every token, making them computationally heavier.

# Polysemy Limitation:
# The limitation of polysemy in static embeddings affects tasks like sentiment analysis or question answering, 
# where the meaning of a word depends on its context. 
# For example, the word "bank" in "river bank" vs. "financial bank" would have the same vector, leading to potential 
# misinterpretations. 
# Strategies to mitigate this include using subword embeddings (e.g., FastText) or combining
# static embeddings with additional context-aware features.
#
# Mitigation Techniques:
#
# 1. Subword Embeddings (FastText):
#    FastText represents words as bags of character n-grams, which helps with morphological variants
#    (e.g., "play", "playing", "played") but does not resolve polysemy — "bank" still maps to one vector.
#    It partially helps with rare word forms but is not a direct fix for sense ambiguity.
#
# 2. Sense-Specific Embeddings (Multi-Prototype Embeddings):
#    Train separate vectors for each sense of a word by clustering the contexts in which a word appears
#    and assigning a distinct embedding per cluster. At inference, the appropriate sense vector is selected
#    based on the surrounding context.
#    Example: Huang et al. (2012) multi-prototype word embeddings.
#
# 3. Contextual Embeddings (ELMo, BERT, GPT):
#    The most effective mitigation — these models generate a different vector for each occurrence of a word
#    depending on its full surrounding context. "bank" in "river bank" and "financial bank" will produce
#    distinct vectors because the model reads the entire sentence.
#    Trade-off: much higher compute cost compared to static lookup.
#
# 4. Combining Static Embeddings with Context Features:
#    Augment static embeddings at inference time by concatenating them with context-derived features
#    (e.g., average of surrounding word vectors, TF-IDF weighted context, or a lightweight context encoder).
#    This adds a degree of sense disambiguation without retraining.
#
# 5. Word Sense Disambiguation (WSD) as a Pre-processing Step:
#    Apply a WSD model (e.g., Lesk algorithm, supervised WSD with WordNet) to label each word token
#    with its specific sense before lookup. Maintain separate embeddings per sense label.
#    Example: "bank_finance" and "bank_river" as distinct vocabulary entries.
#
# 6. Retrofitting / Post-hoc Specialization:
#    After training static embeddings, use semantic lexicons (WordNet, FrameNet) to pull synonymous senses
#    closer together and push antonymous or distinct senses apart in the vector space.
#    Example: Faruqui et al. (2015) retrofitting algorithm.

# Context Window:
# The context window size influences the quality of embeddings by determining how much surrounding information
# is used to learn word relationships.
# A larger window captures broader context but may dilute the importance of nearby words, while a smaller window focuses
# on local context but may miss long-range dependencies.
# The choice depends on the task and the nature of the data.
#
# Mitigation Techniques:
#
# 1. Dynamic/Weighted Context Windows (Word2Vec skip-gram):
#    Word2Vec samples the window size uniformly from [1, max_window] per training step, so words closer to the target
#    receive more influence over many iterations. This naturally down-weights distant context without discarding it.
#
# 2. Dependency-Based Windows:
#    Instead of a fixed linear window, syntactic parse trees define context — words that are syntactically related
#    (subject-verb, modifier-noun) are treated as neighbors regardless of linear distance.
#    This captures functional/syntactic similarity better than positional windows (e.g., using word2vecf or spaCy).
#
# 3. Multi-Scale / Ensemble Embeddings:
#    Train multiple embeddings with different window sizes (e.g., 2, 5, 15) and concatenate or average them.
#    This preserves both local syntactic and global semantic signals in a single representation.
#    Example: embedding = concat(embed_window2[word], embed_window10[word])
#
# 4. Sub-word Embeddings (FastText):
#    FastText trains on character n-grams, so rare or morphologically complex words still get useful representations
#    even when the window doesn't provide enough co-occurrence data for the full word form.
#
# 5. Positional Decay Weighting (GloVe):
#    GloVe's co-occurrence matrix weights each co-occurrence at distance d by 1/d, giving the model a natural
#    preference for nearby context without ignoring distant words entirely.
#
# 6. Contextual Embeddings (ELMo, BERT, GPT):
#    The fundamental fix — attention mechanisms have no fixed window, allowing every token to attend to every other
#    token in the sequence. This eliminates the window trade-off entirely, at the cost of higher compute.

# Embedding Dimensions:
# Higher-dimensional embeddings can capture more nuanced relationships between words, 
# improving performance on complex tasks. 
# However, they require more memory and computational resources, and they risk overfitting when the training data is limited. 
# Lower-dimensional embeddings are faster and more memory-efficient but may lose some semantic detail. 
# The choice of dimensionality is a trade-off between expressiveness and efficiency.
