"""
=============================================================================
CONTEXTUAL EMBEDDINGS DEMO — BERT + Sentence-Transformers
=============================================================================

WHAT ARE CONTEXTUAL EMBEDDINGS?
---------------------------------
Unlike static embeddings (Word2Vec, GloVe) that give every word a FIXED
vector, contextual embeddings produce a DIFFERENT vector for the same token
depending on the full sentence surrounding it.

  "I sat on the river BANK"       → bank gets vector A
  "I went to the BANK to deposit" → bank gets vector B   (A ≠ B)

HOW BERT WORKS (in brief):
---------------------------
  BERT (Devlin et al., 2018) is a Transformer encoder pretrained with two
  objectives on BookCorpus + English Wikipedia (~3.3B words):

  1. Masked Language Modeling (MLM):
       15 % of tokens are masked → model predicts the original token.
       Forces every token to attend to ALL other tokens in the sentence.

  2. Next Sentence Prediction (NSP):
       Given two sentences A, B, predict if B follows A in the corpus.
       (Later models like RoBERTa dropped NSP — MLM alone is sufficient.)

  Architecture — bert-base-uncased:
    • 12 Transformer encoder layers (blocks)
    • 12 attention heads per layer
    • Hidden size  : 768  (each token's vector at every layer is 768-dim)
    • Feed-forward : 3072
    • Parameters   : ~110 million
    • Vocabulary   : 30,522 WordPiece sub-word tokens

WHY SELF-ATTENTION MAKES EMBEDDINGS CONTEXTUAL:
------------------------------------------------
  In each Transformer layer every token queries every other token (all-to-all
  attention). The result for token i is a WEIGHTED SUM of all other tokens'
  values — the weights depend on how relevant each token is to token i.

  So after Layer 1, "bank" in "river bank" is already blended with "river",
  while "bank" in "bank deposit" is blended with "deposit".  By Layer 12
  the two representations are geometrically far apart in 768-D space.

INFERENCE COST vs STATIC EMBEDDINGS:
--------------------------------------
  Static (Word2Vec) : O(1) table lookup. No compute.
  BERT              : O(L × H²) per token, where L = #layers, H = hidden size.
                      For bert-base that is 12 × 768² ≈ 7 million FLOPs per
                      token — orders of magnitude heavier, but contextual.

=============================================================================
"""

import numpy as np
import torch
from transformers import BertTokenizer, BertModel
from sentence_transformers import SentenceTransformer
from scipy.spatial.distance import cosine

# ─────────────────────────────────────────────────────────────────────────────
# HELPER — cosine similarity (1 = identical direction, 0 = orthogonal)
# ─────────────────────────────────────────────────────────────────────────────
def cos_sim(a, b):
    return float(1 - cosine(a, b))

# ─────────────────────────────────────────────────────────────────────────────
# 1. LOAD BERT
#    First call downloads ~440 MB of weights and caches them locally.
#    Subsequent runs load from cache (~1-2 seconds).
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("Loading bert-base-uncased …")
print("(~440 MB on first run, cached after that)")
print("=" * 70)

MODEL_NAME = "bert-base-uncased"
tokenizer  = BertTokenizer.from_pretrained(MODEL_NAME)
bert       = BertModel.from_pretrained(MODEL_NAME)
bert.eval()                           # no dropout at inference

print(f"\nBERT loaded.")
print(f"  Layers      : {bert.config.num_hidden_layers}")
print(f"  Hidden size : {bert.config.hidden_size}")
print(f"  Attn heads  : {bert.config.num_attention_heads}")
print(f"  Vocab size  : {bert.config.vocab_size:,}")
print(f"  Parameters  : {sum(p.numel() for p in bert.parameters()):,}")


# ─────────────────────────────────────────────────────────────────────────────
# UTILITY — extract the last-layer vector for a specific word token
#
#   BERT tokenises with WordPiece, which may split a word into sub-tokens
#   (e.g. "playing" → ["play", "##ing"]).  We average over sub-token vectors
#   to get a single word-level representation.
# ─────────────────────────────────────────────────────────────────────────────
def get_word_embedding(sentence: str, target_word: str) -> np.ndarray:
    """
    Returns the last-layer contextual embedding for `target_word` in
    `sentence`.  If the word appears multiple times, uses the first occurrence.
    """
    inputs     = tokenizer(sentence, return_tensors="pt")
    token_ids  = inputs["input_ids"][0].tolist()
    tokens     = tokenizer.convert_ids_to_tokens(token_ids)

    # Locate the sub-tokens that correspond to target_word
    target_ids  = tokenizer.encode(target_word, add_special_tokens=False)
    target_toks = tokenizer.convert_ids_to_tokens(target_ids)

    # Find the start position of the target sub-token sequence in the sentence
    n = len(target_toks)
    start_idx = None
    for i in range(len(tokens) - n + 1):
        if tokens[i : i + n] == target_toks:
            start_idx = i
            break

    if start_idx is None:
        raise ValueError(f"'{target_word}' not found in tokenised sentence.\n"
                         f"  Sentence tokens: {tokens}")

    with torch.no_grad():
        outputs = bert(**inputs)

    # outputs.last_hidden_state shape: [1, seq_len, 768]
    hidden = outputs.last_hidden_state[0]          # [seq_len, 768]
    word_vec = hidden[start_idx : start_idx + n].mean(dim=0)   # avg sub-tokens
    return word_vec.numpy()


# ─────────────────────────────────────────────────────────────────────────────
# 2. CORE DEMONSTRATION — POLYSEMY RESOLUTION
#
#    This is the EXACT problem static embeddings cannot solve.
#    We measure how different BERT's vectors are for the same word in
#    two sentences with clearly different meanings.
# ─────────────────────────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("SECTION 1 — Polysemy: same word, DIFFERENT contextual vectors")
print("=" * 70)

polysemy_examples = [
    {
        "word": "bank",
        "sense_a": "I sat on the grassy bank of the river watching the water flow.",
        "sense_b": "She went to the bank to deposit her salary cheque.",
        "label_a": "geographic / river",
        "label_b": "financial institution",
    },
    {
        "word": "bat",
        "sense_a": "The cricket bat cracked as he played the perfect cover drive.",
        "sense_b": "A bat flew silently out of the cave into the moonlit sky.",
        "label_a": "sports equipment",
        "label_b": "flying mammal",
    },
    {
        "word": "spring",
        "sense_a": "The flowers bloomed everywhere as spring arrived after a long winter.",
        "sense_b": "The old clock stopped because its spring had worn out.",
        "label_a": "season",
        "label_b": "mechanical coil",
    },
    {
        "word": "light",
        "sense_a": "She carried a light backpack that barely weighed two kilograms.",
        "sense_b": "The lighthouse beam sent a beam of light across the dark ocean.",
        "label_a": "not heavy",
        "label_b": "illumination / photons",
    },
    {
        "word": "python",
        "sense_a": "He wrote the data pipeline entirely in python using pandas.",
        "sense_b": "The python coiled silently around the branch, waiting to strike.",
        "label_a": "programming language",
        "label_b": "large snake",
    },
]

print(f"\n{'Word':10s}  {'Sense A':25s}  {'Sense B':25s}  {'Sim(A,B)':>8s}  Verdict")
print("-" * 90)

for ex in polysemy_examples:
    vec_a = get_word_embedding(ex["sense_a"], ex["word"])
    vec_b = get_word_embedding(ex["sense_b"], ex["word"])
    sim   = cos_sim(vec_a, vec_b)
    verdict = "DISTINCT ✓" if sim < 0.85 else "similar (hard case)"
    print(f"  {ex['word']:8s}  {ex['label_a']:25s}  {ex['label_b']:25s}  {sim:8.4f}  {verdict}")

print("""
  Interpretation:
    Low similarity (< 0.85) = BERT produced genuinely different vectors
    for the same surface word — polysemy resolved via context.
    A static embedding would give similarity = 1.000 for ALL rows above
    because there is only ONE vector per word type.
""")


# ─────────────────────────────────────────────────────────────────────────────
# 3. LAYER-BY-LAYER EVOLUTION
#
#    BERT has 12 layers.  Early layers encode syntax; later layers encode
#    semantics.  Watch how two senses of "bank" diverge across layers.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("SECTION 2 — How 'bank' representations diverge across BERT layers")
print("(lower layers → more similar; upper layers → more distinct)")
print("=" * 70)

sentence_geo = "I sat on the grassy bank of the river watching the water flow."
sentence_fin = "She went to the bank to deposit her salary cheque."

inputs_geo  = tokenizer(sentence_geo, return_tensors="pt")
inputs_fin  = tokenizer(sentence_fin, return_tensors="pt")

# We need all hidden states, not just the last layer
with torch.no_grad():
    out_geo = bert(**inputs_geo, output_hidden_states=True)
    out_fin = bert(**inputs_fin, output_hidden_states=True)

# out.hidden_states is a tuple of 13 tensors: embedding layer + 12 BERT layers
# shape of each: [1, seq_len, 768]

def token_position(sentence, word):
    """Return the index of the first token corresponding to `word`."""
    ids    = tokenizer(sentence, return_tensors="pt")["input_ids"][0].tolist()
    tokens = tokenizer.convert_ids_to_tokens(ids)
    target = tokenizer.convert_ids_to_tokens(
                 tokenizer.encode(word, add_special_tokens=False))
    for i in range(len(tokens) - len(target) + 1):
        if tokens[i : i + len(target)] == target:
            return i, i + len(target)
    raise ValueError(f"'{word}' not found in tokens: {tokens}")

start_geo, end_geo = token_position(sentence_geo, "bank")
start_fin, end_fin = token_position(sentence_fin, "bank")

print(f"\n  Layer   sim(geo-bank, fin-bank)   Bar")
print(f"  " + "-" * 50)
for layer_idx, (h_geo, h_fin) in enumerate(
        zip(out_geo.hidden_states, out_fin.hidden_states)):
    v_geo = h_geo[0, start_geo:end_geo].mean(0).numpy()
    v_fin = h_fin[0, start_fin:end_fin].mean(0).numpy()
    sim   = cos_sim(v_geo, v_fin)
    bar   = "█" * int(sim * 40)
    label = "embedding" if layer_idx == 0 else f"layer {layer_idx:2d}"
    print(f"  {label:12s}  {sim:.4f}                  {bar}")

print("""
  Key insight:
    • At the embedding layer (layer 0) the two "bank" tokens start IDENTICAL
      — this is the static WordPiece embedding, shared across all contexts.
    • Each self-attention layer blends in information from surrounding tokens.
    • By layer 12 the two representations are clearly separated in vector
      space, because "river/grassy/water" vs "deposit/salary/cheque" pulled
      them in opposite directions.
""")


# ─────────────────────────────────────────────────────────────────────────────
# 4. SENTENCE-LEVEL SIMILARITY — sentence-transformers
#
#    BERT's [CLS] token is a rough sentence embedding, but models fine-tuned
#    specifically for semantic similarity (e.g. all-MiniLM-L6-v2) are much
#    better.  Sentence-Transformers wraps these for easy use.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("SECTION 3 — Sentence-level semantic similarity")
print("(using sentence-transformers / all-MiniLM-L6-v2, 384-dim)")
print("=" * 70)

print("\nLoading sentence-transformer model …")
st_model = SentenceTransformer("all-MiniLM-L6-v2")

sentence_groups = [
    {
        "title": "Paraphrase detection",
        "sentences": [
            "The doctor gave the patient some medicine.",
            "The physician prescribed medication to the ill person.",   # paraphrase
            "The chef prepared a delicious pasta dish.",                # unrelated
        ]
    },
    {
        "title": "Context-sensitive similarity (static embeddings would tie)",
        "sentences": [
            "I need to check my bank balance online.",          # financial bank
            "The kids played on the muddy river bank.",         # geographic bank
            "She transferred money between bank accounts.",     # financial bank
        ]
    },
    {
        "title": "Question–Answer matching",
        "sentences": [
            "What is the capital of France?",
            "Paris is the capital city of France.",             # answer
            "Germany is a country in central Europe.",          # distractor
        ]
    },
    {
        "title": "Code–comment alignment",
        "sentences": [
            "Sort a list of integers in ascending order",
            "def sort_asc(lst): return sorted(lst)",            # matching code
            "Calculate the factorial of a number",              # unrelated
        ]
    },
]

for group in sentence_groups:
    print(f"\n  [{group['title']}]")
    sents = group["sentences"]
    vecs  = st_model.encode(sents)
    anchor = sents[0]
    anchor_vec = vecs[0]
    for s, v in zip(sents[1:], vecs[1:]):
        sim = cos_sim(anchor_vec, v)
        bar = "█" * int(sim * 40)
        print(f"    anchor : {anchor[:55]}")
        print(f"    target : {s[:55]}")
        print(f"    sim    : {sim:.4f}  {bar}")
        print()


# ─────────────────────────────────────────────────────────────────────────────
# 5. CONTEXTUAL EMBEDDINGS FOR RETRIEVAL
#
#    A concrete practical example: given a query, rank passages by semantic
#    similarity.  Static embeddings would fail on vocabulary mismatch;
#    contextual embeddings capture meaning even without shared keywords.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("SECTION 4 — Semantic retrieval (query → ranked passages)")
print("Contextual embeddings generalise beyond keyword overlap")
print("=" * 70)

query = "What medication helps reduce high blood pressure?"

passages = [
    "Lisinopril is an ACE inhibitor commonly prescribed to treat hypertension.",   # relevant — no shared keywords with query
    "Doctors recommend regular exercise and a low-sodium diet for blood pressure.", # relevant — partial overlap
    "Aspirin is used to relieve mild pain and reduce fever.",                       # medical but off-topic
    "The stock market hit a record high after positive earnings reports.",           # completely unrelated
    "Beta-blockers such as metoprolol are used to manage high blood pressure.",     # very relevant
    "Python is a versatile programming language used in data science.",              # unrelated
]

print(f"\n  Query: \"{query}\"\n")
q_vec  = st_model.encode([query])[0]
p_vecs = st_model.encode(passages)

ranked = sorted(zip(passages, p_vecs), key=lambda x: cos_sim(q_vec, x[1]), reverse=True)

for rank, (passage, pvec) in enumerate(ranked, 1):
    sim = cos_sim(q_vec, pvec)
    bar = "█" * int(sim * 40)
    print(f"  #{rank}  sim={sim:.4f}  {bar}")
    print(f"       \"{passage[:70]}\"")
    print()

print("""
  Notice: the top-ranked passage (Lisinopril / ACE inhibitor) shares almost
  NO keywords with the query ("medication", "blood pressure" aside), yet the
  contextual embedding recognises it as the most relevant answer.

  Static Word2Vec would rank it lower because it depends on word overlap
  and cannot generalise "antihypertensive medication" to "ACE inhibitor".
""")


# ─────────────────────────────────────────────────────────────────────────────
# 6. CONTEXTUAL vs STATIC — DIRECT COMPARISON ON POLYSEMY
#
#    We reconstruct the exact "bank" experiment from static_embeddings_demo.py
#    and show the numbers side by side.
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("SECTION 5 — Head-to-head: Static Word2Vec vs BERT on 'bank'")
print("=" * 70)

print("""
  STATIC WORD2VEC  (from static_embeddings_demo.py):
    bank ↔ river   : ~0.32   (geographic sense, weak signal)
    bank ↔ money   : ~0.48   (financial sense, stronger)
    bank ↔ deposit : ~0.53   (financial sense)
    The single vector is BIASED toward finance because Google News is mostly
    financial. The geographic meaning is underrepresented.

  BERT (contextual):
""")

# Geographic context
geo_contexts = [
    "I sat on the grassy bank of the river watching the water flow.",
    "The children played on the muddy bank beside the stream.",
    "He fished from the rocky bank where the river curved sharply.",
]

# Financial context
fin_contexts = [
    "She went to the bank to deposit her monthly salary.",
    "The bank approved his loan application after reviewing his credit score.",
    "Interest rates at the bank were higher than expected this quarter.",
]

geo_vecs = [get_word_embedding(s, "bank") for s in geo_contexts]
fin_vecs = [get_word_embedding(s, "bank") for s in fin_contexts]

# Compare geo-bank to fin-bank
cross_sims = [cos_sim(g, f) for g in geo_vecs for f in fin_vecs]
within_geo  = [cos_sim(geo_vecs[i], geo_vecs[j])
               for i in range(len(geo_vecs))
               for j in range(i+1, len(geo_vecs))]
within_fin  = [cos_sim(fin_vecs[i], fin_vecs[j])
               for i in range(len(fin_vecs))
               for j in range(i+1, len(fin_vecs))]

print(f"    Avg similarity — geographic 'bank' vs geographic 'bank' : {np.mean(within_geo):.4f}")
print(f"    Avg similarity — financial  'bank' vs financial  'bank' : {np.mean(within_fin):.4f}")
print(f"    Avg similarity — geographic 'bank' vs financial  'bank' : {np.mean(cross_sims):.4f}")

print("""
  Reading this:
    • High WITHIN-sense similarity → BERT is consistent for each meaning.
    • Low CROSS-sense similarity   → BERT separates the two meanings cleanly.
    • A static model would show 1.000 / 1.000 / 1.000 (all identical).
""")


# ─────────────────────────────────────────────────────────────────────────────
# 7. SUMMARY
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 70)
print("SUMMARY")
print("=" * 70)
print("""
  Contextual Embeddings (BERT / Sentence-Transformers):
  ┌──────────────────┬────────────────────────────────────────────────────┐
  │ Architecture     │ Multi-layer Transformer encoder (12 or 24 layers)  │
  │                  │ — self-attention lets every token attend to every  │
  │                  │   other token in the sentence                       │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Training         │ Masked LM + Next Sentence Prediction on 3.3 B      │
  │                  │ words (BookCorpus + Wikipedia)                      │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Output           │ One 768-dim vector per token per sentence —        │
  │                  │ DIFFERENT for the same token in different contexts  │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Polysemy         │ Solved: "bank" (river) ≠ "bank" (finance)         │
  │                  │ Vectors are pulled toward the surrounding context   │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Sentence sim     │ Fine-tuned sentence models (all-MiniLM-L6-v2)     │
  │                  │ give dense 384-dim sentence vectors for retrieval,  │
  │                  │ clustering, and semantic search                     │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Inference cost   │ Heavy: O(L × H²) per token vs O(1) for static     │
  │                  │ bert-base ≈ 7 M FLOPs/token; GPT-4 >> that        │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │ Key advantage    │ Meaning from context, not just word identity.      │
  │                  │ Enables: NLI, QA, semantic search, NER, summarise  │
  └──────────────────┴────────────────────────────────────────────────────┘

  Static vs Contextual — when to use which:
    Use STATIC (Word2Vec/GloVe) when:
      • You need millisecond lookup latency at scale
      • Vocabulary is domain-specific and polysemy is rare
      • Memory / compute is highly constrained

    Use CONTEXTUAL (BERT / ST) when:
      • Meaning depends on sentence context (almost always true)
      • You need semantic similarity beyond keyword matching
      • Tasks: search, QA, NLI, classification, named entity recognition
""")

# TEST YOUR UNDERSTANDING — QUESTIONS 

# #Self-Attention Mechanism:
# How does the self-attention mechanism in BERT ensure that the embeddings for the word "bank" 
# differ in the sentences "I sat on the river bank" and "I went to the bank to deposit money"? Can you explain the mathematical operation that makes this possible?

# Inference Cost:
# The demo mentions that BERT's inference cost is significantly higher than static embeddings like Word2Vec. What are the factors contributing to this cost, and how does the architecture of BERT (e.g., number of layers, hidden size) influence it?

# WordPiece Tokenization:
# In the demo, it is mentioned that BERT uses WordPiece tokenization. How does this approach handle out-of-vocabulary (OOV) words, and what impact does it have on the quality of embeddings for rare or unseen words?

# Cosine Similarity:
# The demo uses cosine similarity to compare embeddings. Why is cosine similarity preferred over other distance metrics (e.g., Euclidean distance) for comparing high-dimensional vectors like embeddings?

# Sentence-Transformers:
# The demo uses Sentence-Transformers for generating sentence-level embeddings. How does the architecture of Sentence-Transformers differ from BERT, and why is it more efficient for tasks like semantic similarity or clustering?
# These questions are designed to test both the theoretical understanding and the ability to connect the demo concepts to broader NLP principles.



## ANSWERS
#
# Self-Attention Mechanism:
# The self-attention mechanism in BERT ensures that embeddings for the word "bank" differ in different contexts 
# by computing a weighted sum of all token representations in the sentence. 
# Each token queries every other token, and the weights (attention scores) are determined by the relevance of other
#  tokens to the current token. For example, in "river bank," the word "river" will have a high attention weight 
# for "bank," while in "bank deposit," the word "deposit" will have a higher weight. 
# This blending of context-specific information results in unique embeddings for the same word in different contexts.


# Inference Cost:
# BERT's inference cost is higher because it involves multiple layers of computation. Specifically:
# Each token passes through 12 Transformer encoder layers in bert-base-uncased.
# Each layer performs multi-head self-attention and feed-forward operations, which involve matrix 
# multiplications and scaling with the hidden size (768 dimensions).
# The cost is proportional to 
# O(L×H-squared) per token, where L is the number of layers and H is the hidden size.
# For bert-base, this results in approximately 7 million floating-point operations (FLOPs) per token, 
# which is significantly higher than the O(1) cost of static embeddings that require

# WordPiece Tokenization:
# WordPiece tokenization handles out-of-vocabulary (OOV) words by breaking them into smaller subword units. 
# For example, an unknown word like "unhappiness" might be split into ["un", "##happiness"]. 
# Each subword has its own embedding, and the embeddings are combined (e.g., averaged) to represent the full word.
#  This approach ensures that even rare or unseen words can be represented using known subword embeddings, 
# improving the model's robustness.


# Cosine Similarity:
# Cosine similarity is preferred for comparing high-dimensional vectors like embeddings because it measures the 
# angle between vectors rather than their magnitude.
# This makes it invariant to the scale of the vectors, focusing purely on their direction in the vector space. 
# In NLP, this is useful because embeddings often encode semantic meaning in their direction, 
# and the magnitude may not be meaningful.

# Sentence-Transformers:
# Sentence-Transformers differ from BERT in that they are fine-tuned specifically for sentence-level tasks like 
# semantic similarity. 
# While BERT processes each sentence independently, Sentence-Transformers use a Siamese or triplet network 
# structure to directly optimize for similarity tasks. 
# This allows them to generate sentence embeddings that can be compared efficiently, 
# making them more suitable for clustering or retrieval tasks. 
# Additionally, Sentence-Transformers are optimized for speed and can process multiple sentences in parallel.
