# LSTM Customer Support Ticket Classifier — Learned Embedding Layer
#
# This is a direct variation of 07_lstm_doctornotes_classify.py.
# The ONLY architectural change is replacing one-hot word encoding with a
# trainable Embedding layer.  Everything else — data, labels, LSTM stack,
# evaluation — is identical so the two files can be compared side-by-side.
#
# BUSINESS PROBLEM (same as the original)
# ─────────────────────────────────────────────────────────────────────────────
# Automatically classify free-text customer support notes into one of five
# issue categories for instant routing and analytics:
#   1. Product Quality Issue    — defects, damage, not-as-described complaints
#   2. Billing/Pricing Dispute  — incorrect charges, missing discounts, invoice errors
#   3. Delivery/Logistics Problem — late, missing, or misdelivered orders
#   4. Technical Support Request — app/website errors, integration failures
#   5. Account Management Issue  — subscription, login, account settings problems
#
# WHAT CHANGED vs THE ONE-HOT VERSION (07_lstm_doctornotes_classify.py)
# ─────────────────────────────────────────────────────────────────────────────
#
#   Step removed:   tf.keras.utils.to_categorical(X_seq, num_classes=VOCAB_SIZE)
#                   One-hot conversion is no longer needed because the Embedding
#                   layer accepts raw integer indices directly.
#
#   Layer added:    Embedding(VOCAB_SIZE, EMBED_DIM, input_length=MAX_LEN)
#                   as the FIRST layer of the Sequential model.
#
#   Input to LSTM:  changed from VOCAB_SIZE-wide one-hot vectors
#                   to EMBED_DIM-wide dense learned vectors.
#
# ┌────────────────────────────────────────────────────────────────────────────┐
# │  HOW THE EMBEDDING LAYER WORKS IN THIS PIPELINE                           │
# │                                                                            │
# │  Tokeniser assigns each word a unique integer index (1 … VOCAB_SIZE-1).   │
# │  Index 0 is reserved for padding, index 1 is the OOV token.               │
# │                                                                            │
# │  Input to model: integer tensor of shape (batch, MAX_LEN)                 │
# │    e.g. [  7, 43, 12,  0,  0, ... ]   ← word indices, padded to 40       │
# │                                                                            │
# │  Embedding layer: a trainable weight matrix W of shape                    │
# │    (VOCAB_SIZE, EMBED_DIM)                                                 │
# │    Each row = the learned dense vector for one word.                       │
# │    For each index i in the sequence, the layer returns row W[i] —         │
# │    a simple table lookup, not a search or similarity computation.          │
# │                                                                            │
# │  Output of Embedding: (batch, MAX_LEN, EMBED_DIM)                         │
# │    e.g. (32, 40, 32) — same shape the LSTM expects, but dense.            │
# │                                                                            │
# │  LSTM then processes the sequence of 32-dim vectors instead of            │
# │  500-dim one-hot vectors → smaller weight matrices, faster training.      │
# │                                                                            │
# │  Gradient flows all the way back into the embedding table during           │
# │  backprop: words that appear in similar issue contexts drift               │
# │  toward each other in EMBED_DIM-dimensional space automatically.           │
# └────────────────────────────────────────────────────────────────────────────┘
#
# ONE-HOT vs EMBEDDING — SIDE-BY-SIDE
# ─────────────────────────────────────────────────────────────────────────────
#
#   Aspect                  One-hot (07_lstm_...)    Embedding (this file)
#   ─────────────────────── ──────────────────────   ──────────────────────────
#   Input shape to LSTM     (batch, 40, 500)         (batch, 40, 32)
#   Words equidistant?      Yes — all orthogonal     No — similar words cluster
#   LSTM input weight W_x   64 × 500 = 32,000 params 64 × 32 = 2,048 params
#   New layer added         None                     Embedding: 500×32 = 16,000
#   Total model params      larger                   smaller
#   Preprocessing step      to_categorical needed    not needed — raw indices
#   Semantic structure       None                    Emerges from training
#   predict_issue_category() must call to_categorical plain integer sequence
# ─────────────────────────────────────────────────────────────────────────────
#
# =============================================================================
# IS THIS STATIC OR TRAINED? PRE-TRAINED OR FROM SCRATCH?
# =============================================================================
#
# SHORT ANSWER
# ─────────────────────────────────────────────────────────────────────────────
#   • NOT static       — the embedding vectors change every training step.
#   • NOT pre-trained  — there is no GloVe / Word2Vec / FastText file loaded.
#   • TRAINED HERE, FROM SCRATCH, on this 50-note dataset only.
#
# The single line that decides this:
#
#   Embedding(VOCAB_SIZE, EMBED_DIM, input_length=MAX_LEN, mask_zero=True)
#
# Keras initialises the weight matrix (500 × 32 = 16,000 numbers) with small
# random floats. No external file is read. The `trainable` flag defaults to
# True, so the matrix is updated by backprop every training step exactly like
# any other weight matrix in the model.
#
# To make it static (freeze it), you would write:
#   Embedding(..., trainable=False)
# To use pre-trained vectors, you would write:
#   Embedding(..., weights=[glove_matrix], trainable=False)  # frozen GloVe
#   Embedding(..., weights=[glove_matrix], trainable=True)   # fine-tuned GloVe
# Neither of those is done here.
#
# =============================================================================
# HOW THE EMBEDDING TRAINING ACTUALLY WORKS
# =============================================================================
#
# The embedding table is just a weight matrix W of shape (500, 32).
# Row i of W is the current vector for word i.
# Training updates W the same way it updates any other layer — via the chain
# rule of calculus applied backwards through the network (backpropagation).
#
# One training step, step by step:
#
#   1. FORWARD PASS
#      A batch of 8 notes is fed as integer sequences, e.g.:
#        note_0: [7, 43, 12, 89, 0, 0, ...]   ← "damaged broken parts missing..."
#        note_1: [15, 7, 22, 0, 0, 0, ...]    ← "charged twice billing..."
#
#      The Embedding layer does a table lookup: for each integer index it
#      returns the corresponding row of W.
#        index 7  ("damaged")  → W[7]  = [+0.12, -0.34, +0.07, ...]  (32 floats)
#        index 43 ("broken")   → W[43] = [-0.05, +0.21, -0.19, ...]  (32 floats)
#
#      These 32-float vectors are fed into the LSTM, which processes the
#      sequence and produces a hidden state. The Dense+Softmax layers turn
#      that into predicted class probabilities.
#
#   2. COMPUTE LOSS
#      The predicted probabilities are compared to the true label.
#      e.g. note_0 is "Product Quality Issue" (class 3).
#      If the model predicted class 1 (Billing), the cross-entropy loss is high.
#
#   3. BACKWARD PASS (backpropagation)
#      The loss gradient flows backwards:
#        Dense layers → LSTM → Embedding table
#
#      For each word index that appeared in this batch, the gradient tells
#      the embedding table: "word 7 ('damaged') contributed to the wrong
#      prediction — nudge W[7] in the direction that reduces the loss."
#
#      Concretely, only the rows of W corresponding to words that appeared
#      in the current batch are updated. If "damaged" did not appear in any
#      note in this batch, W[7] is unchanged this step.
#
#   4. WEIGHT UPDATE
#      Adam optimizer adjusts W[7], W[43], etc. by a small step in the
#      gradient direction. After 100+ such steps across many batches and
#      epochs, the rows of W have drifted from their initial random positions
#      to positions that help classify support tickets correctly.
#
# =============================================================================
# HOW DOES IT LEARN SEMANTIC MEANING FROM ONLY 50 NOTES?
# =============================================================================
#
# The honest answer: it does NOT learn rich general-purpose semantic meaning.
# What it learns is narrow, task-specific clustering — and that is enough
# for this classification problem.
#
# WHY IT CAN STILL WORK
# ─────────────────────────────────────────────────────────────────────────────
# The task has a strong co-occurrence signal even at 50 samples:
#
#   Words like "damaged", "defective", "broken", "fault", "substandard"
#   ALL appear exclusively in Product Quality notes (10 notes × ~15 words).
#   They all receive similar gradient signals every time they appear.
#   After training their vectors end up roughly in the same region of the
#   32-D space — not because the model "understands" they mean similar things,
#   but because they always predict the same class and the loss penalises them
#   identically when the class is wrong.
#
#   Visualised informally:
#
#     Initial (random):        After 10 epochs:
#     damaged  •               damaged  •─┐
#     defective   •            defective  ├── Product Quality cluster
#     broken        •          broken  •──┘
#     billing •                billing  •──┐
#     invoice    •             invoice     ├── Billing cluster
#     charge        •          charge  •───┘
#
# WHAT IT CANNOT LEARN FROM 50 NOTES
# ─────────────────────────────────────────────────────────────────────────────
#   1. Synonymy between words it has never seen together in the same note.
#      "damaged" and "faulty" might end up far apart if they never co-occurred.
#
#   2. Generalisation to out-of-vocabulary words.
#      A new note saying "item arrived crushed" — if "crushed" was not in the
#      50 training notes, it maps to the OOV token and its meaning is lost.
#
#   3. Syntactic or negation awareness.
#      "not damaged" and "damaged" will produce very similar embeddings because
#      the embedding layer has no memory — it maps each word independently.
#      The LSTM is responsible for handling negation at the sequence level.
#
# CONTRAST WITH PRE-TRAINED GLOVE / WORD2VEC
# ─────────────────────────────────────────────────────────────────────────────
#   GloVe is trained on billions of web pages. Its vectors encode rich
#   general-purpose semantics:
#     vector("damaged") ≈ vector("broken") ≈ vector("defective")
#   even before seeing a single support ticket.
#
#   In this demo the embeddings start random and only learn from 40 training
#   notes. The resulting vectors are useful for THIS classification task
#   but would be meaningless for any other task. Loading pre-trained GloVe
#   vectors (see rnn_customer_satisfaction_regression_embedding.py, Part 2)
#   would give the model a head-start of pre-learned semantic structure —
#   particularly valuable when training data is this small.
#
# RULE OF THUMB
# ─────────────────────────────────────────────────────────────────────────────
#   Trained-from-scratch embeddings are worth using when:
#     • You have at least a few thousand labelled examples, OR
#     • Your vocabulary is highly domain-specific and GloVe has poor coverage
#       (e.g. product SKU codes, medical drug names, internal jargon).
#
#   Pre-trained embeddings (frozen or fine-tuned) are almost always better
#   when you have limited data and general English vocabulary — which is
#   exactly the situation in this 50-note demo.
# =============================================================================
#
# =============================================================================
# HOW THE LSTM ADDS CONTEXT-AWARE MEANING ON TOP OF THE EMBEDDINGS
# =============================================================================
#
# The Embedding layer maps each word to a fixed vector independently — it has
# no memory. "not" always maps to the same 32-float vector regardless of what
# comes before or after it. The LSTM is what introduces context.
#
# THE CORE PROBLEM THE LSTM SOLVES — NEGATION
# ─────────────────────────────────────────────────────────────────────────────
# Consider these two support notes:
#
#   A: "product not at all impressive"
#   B: "product not at all defective"
#
# From the Embedding layer's perspective:
#
#   Note A embedding sequence:
#     "product"    → W[87]  = [+0.21, -0.14, ...]
#     "not"        → W[12]  = [-0.08, +0.33, ...]   ← same vector in both notes
#     "at"         → W[5]   = [+0.01, -0.02, ...]   ← same vector in both notes
#     "all"        → W[9]   = [+0.04, +0.07, ...]   ← same vector in both notes
#     "impressive" → W[201] = [+0.55, +0.61, ...]   ← positive-leaning (if trained)
#
#   Note B embedding sequence:
#     "product"    → W[87]  = [+0.21, -0.14, ...]   ← same
#     "not"        → W[12]  = [-0.08, +0.33, ...]   ← same
#     "at"         → W[5]   = [+0.01, -0.02, ...]   ← same
#     "all"        → W[9]   = [+0.04, +0.07, ...]   ← same
#     "defective"  → W[67]  = [-0.48, -0.53, ...]   ← negative-leaning (if trained)
#
# The Embedding layer alone gives contradictory signals:
#   Note A ends with a positive word ("impressive") → might look like a compliment
#   Note B ends with a negative word ("defective")  → might look like a complaint
#
# But semantically it is the opposite:
#   A: "not at all impressive" = mild dissatisfaction  → Product Quality Issue
#   B: "not at all defective"  = the product is fine   → NOT a quality complaint
#
# HOW THE LSTM READS THE SEQUENCE TO RESOLVE THIS
# ─────────────────────────────────────────────────────────────────────────────
# The LSTM processes the sequence left-to-right, maintaining a hidden state
# h_t that carries a running summary of everything read so far.
#
#   Step 0 — reads "product":
#     h_0 encodes: "we are talking about a product"
#
#   Step 1 — reads "not":
#     The forget gate sees "not" and partially suppresses the current context.
#     The input gate writes a "negation flag" signal into the cell state c_1.
#     h_1 encodes: "negation is in play"
#
#   Step 2 — reads "at":
#     h_2 encodes: "negation still active, intensifier building"
#
#   Step 3 — reads "all":
#     h_3 encodes: "strong negation — 'not at all'"
#
#   Step 4 — reads "impressive" (Note A):
#     The LSTM sees a positive word THROUGH the lens of the accumulated
#     "strong negation" in c_3/h_3. The output is a hidden state h_4 that
#     reflects: "something positive was said, but it was negated strongly."
#     → The classifier maps this to mild dissatisfaction.
#
#   Step 4 — reads "defective" (Note B):
#     The LSTM sees a negative word THROUGH the same "strong negation" context.
#     h_4 now reflects: "something negative was said, but it was negated."
#     → The classifier maps this to "product is actually fine — probably not
#        a quality complaint."
#
# Without the LSTM's hidden state carrying the "not at all" context forward,
# both notes would look completely different to a bag-of-words model and
# the word "defective" alone would trigger a quality complaint regardless of
# the negation that preceded it.
#
# ─────────────────────────────────────────────────────────────────────────────
# NOTE ON THIS DEMO SPECIFICALLY
# ─────────────────────────────────────────────────────────────────────────────
# With only 50 training notes, the LSTM will not learn negation perfectly.
# These nuanced patterns require hundreds of contrasting examples to reinforce
# reliably. The example above illustrates the MECHANISM the LSTM is capable of
# — what it would learn given sufficient data — not what this 50-note model
# actually achieves. Think of it as the architectural potential, not the
# guaranteed outcome here.
#
# =============================================================================
# LSTM CONTEXT LENGTH LIMIT — HOW MUCH CAN IT ACTUALLY REMEMBER?
# =============================================================================
#
# SHORT ANSWER: ~50–200 tokens in practice, depending on how long-range the
# dependency is. Beyond that, the LSTM's memory degrades noticeably even though
# there is no hard cutoff in the architecture.
#
# WHY THERE IS A LIMIT — THE VANISHING GRADIENT PROBLEM
# ─────────────────────────────────────────────────────────────────────────────
# During backpropagation, the gradient of the loss must travel backwards
# through every time step. At each step it is multiplied by the LSTM's
# gate weights. Most of these weights are less than 1 in magnitude (gates
# are sigmoid-activated: outputs in (0, 1)).
#
# Repeated multiplication of values < 1 causes the gradient to shrink
# exponentially with sequence length:
#
#   After  10 steps: gradient × 0.9^10  ≈ 0.35   — still meaningful
#   After  50 steps: gradient × 0.9^50  ≈ 0.005  — almost gone
#   After 100 steps: gradient × 0.9^100 ≈ 0.00003 — effectively zero
#
# When the gradient reaching an early time step is effectively zero, the
# weights that control how the LSTM processes that step receive no update
# signal. The model stops learning from those early tokens — they are
# functionally invisible to the loss function.
#
# WHY LSTM IS BETTER THAN SIMPLE RNN BUT STILL LIMITED
# ─────────────────────────────────────────────────────────────────────────────
# The LSTM's cell state (c_t) was specifically designed to fight this.
# The forget gate controls how much of c_{t-1} to preserve:
#
#   c_t = f_t * c_{t-1}  +  i_t * ĉ_t
#          ─────────────
#          if f_t ≈ 1.0, old cell state passes through mostly unchanged
#          → gradient can flow back through this "highway" without shrinking
#
# This is a significant improvement over SimpleRNN, which has NO cell state
# and loses early context very quickly (~10–15 tokens). But the cell state
# highway is not perfect:
#   • f_t is also a learned sigmoid — it can drift toward 0 under certain
#     inputs, closing the highway for that step.
#   • Even with f_t ≈ 1, information from step 0 competes with fresh
#     information written at every subsequent step. Eventually early signals
#     get diluted below the noise threshold.
#
# PRACTICAL LIMIT IN THIS FILE
# ─────────────────────────────────────────────────────────────────────────────
# MAX_LEN = 40 words per note. At 40 tokens, the LSTM handles context well —
# this is well within its reliable range. The two-layer LSTM stack (64 → 32
# hidden units) further helps: the second LSTM reads the first LSTM's
# compressed hidden states, which already encode multi-word patterns,
# effectively extending usable context.
#
# For reference, context length limits across architectures:
#
#   Architecture      Practical context limit    Mechanism
#   ─────────────     ───────────────────────    ──────────────────────────────
#   SimpleRNN         ~10–15 tokens              Single hidden state, severe
#                                                vanishing gradient
#   LSTM / GRU        ~50–200 tokens             Cell state highway reduces
#                                                (but does not eliminate) decay
#   Transformer       512–128,000+ tokens        Self-attention: every token
#   (BERT, GPT etc.)                             directly attends to every other
#                                                token — no sequential decay
#
# For support tickets of 10–40 words, LSTM is entirely adequate.
# For longer documents — multi-paragraph complaints, call transcripts,
# clinical notes spanning several paragraphs — a Transformer-based model
# (BERT, GPT) would be the appropriate choice.
# =============================================================================

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout   # Embedding added
import tensorflow as tf

# ── 1. Create inline dataset ──────────────────────────────────────────────────

data = {
    'note': [
        # Product Quality Issue (10 samples)
        "Customer Sarah Kim reports product arrived damaged broken parts missing from box",
        "Client David Brown age 41 complains product quality inferior not matching advertised specs",
        "Order for Jessica Martinez contained defective unit with manufacturing fault noted",
        "Tom Wilson submitted feedback product material substandard tears easily after use",
        "Emma Johnson contacted support about product color fading after first wash quality complaint",
        "Robert Garcia reports product performance below expectations quality defect in component",
        "Jennifer Lee returned item citing major quality issue product stopped working day one",
        "Customer Michael Davis reports packaging damage led to broken product on arrival",
        "Samantha Chen submitted quality complaint product dimensions wrong not as described",
        "Chris Anderson reported product safety concern defective electrical component found",
        # Billing/Pricing Dispute (10 samples)
        "Customer James Thompson age 55 charged twice for same order billing duplicate error",
        "Client Maria Gonzalez reports promotional code discount not applied to invoice",
        "Order number 78923 for Kevin Smith shows incorrect price mismatch from advertised deal",
        "Patricia Wilson called about unauthorized recurring charge on credit card billing",
        "Customer Daniel Chen disputes subscription renewal charge was supposed to be cancelled",
        "Susan Martinez reports wrong tax amount billed on recent purchase needs correction",
        "Christopher Johnson age 33 disputes overcharge of twenty dollars on last order",
        "Amanda Davis submitted billing complaint about unexpected service charge on statement",
        "Brandon Lee reports invoice shows higher price than confirmed at checkout billing",
        "Melissa Brown called about loyalty reward points not converted to discount billing",
        # Delivery/Logistics Problem (10 samples)
        "Customer Ashley Garcia reports package delayed one week past promised delivery date",
        "Client Ryan Johnson order marked delivered but package never arrived missing",
        "Stephanie Anderson contacted support package delivered to wrong address neighbor received",
        "Tyler Martinez reports box arrived severely damaged contents crushed during shipping",
        "Nicole Wilson order placed three weeks ago still not shipped logistics failure",
        "Customer Justin Thompson reports shipment lost no tracking update for ten days",
        "Rebecca Smith called about items missing from delivery only partial order arrived",
        "Austin Davis reports delivery window missed courier did not attempt delivery",
        "Amanda Chen submitted complaint about repeated rescheduling of delivery appointment",
        "Brandon Wilson reports wrong product delivered items do not match order confirmation",
        # Technical Support Request (10 samples)
        "Customer Jake Brown age 29 reports website login not working password reset failed",
        "Client Olivia Martinez app crashes immediately on launch cannot place order technical",
        "Customer portal for Nathan Garcia not loading spinning indefinitely technical glitch",
        "Emma Thompson reports mobile app sync failing customer data not updating properly",
        "Customer Lucas Anderson cannot access account after recent platform update technical",
        "Isabella Johnson reports payment method not accepted at checkout integration error",
        "Noah Wilson called about API connection failure impacting order submission technical",
        "Sophia Davis reports smart device firmware update bricking unit needs technical help",
        "Liam Martinez submitted request for help configuring product integration setup",
        "Ava Chen reports recurring error message blocking access to loyalty dashboard technical",
        # Account Management Issue (10 samples)
        "Customer Michael Brown reports subscription not renewing despite valid payment method",
        "Client Grace Wilson cannot update shipping address in account management settings",
        "Customer William Martinez unable to save new preferences changes not persisting",
        "Chloe Davis reports account locked out after too many login attempts management",
        "Ethan Anderson reports rewards points balance incorrect missing from recent activity",
        "Mia Garcia called about cancellation request not processing subscription still active",
        "Alexander Thompson reports account merge from old to new email address failed",
        "Lily Johnson age 31 reports referral credit not applied to account after signup",
        "James Wilson submitted complaint about data privacy settings not saving correctly",
        "Charlotte Martinez reports account reactivation after pause not working subscription",
    ],
    'issue_category': (
        ['Product Quality Issue'] * 10 +
        ['Billing/Pricing Dispute'] * 10 +
        ['Delivery/Logistics Problem'] * 10 +
        ['Technical Support Request'] * 10 +
        ['Account Management Issue'] * 10
    )
}

df = pd.DataFrame(data)

print("Customer Support Ticket Classifier — Learned Embedding Layer")
print("=" * 55)
print(f"\nDataset: {df.shape[0]} notes, {df['issue_category'].nunique()} issue categories")
print(f"Class distribution:\n{df['issue_category'].value_counts().to_string()}")
print("\nSample note:")
print(df['note'].iloc[0])

# ── 2. Tokenise text ──────────────────────────────────────────────────────────

VOCAB_SIZE = 500   # same as original — covers all words + OOV headroom
MAX_LEN    = 40    # same as original — longest note length
EMBED_DIM  = 32    # NEW: each word maps to a 32-float dense vector.
                   # Rule of thumb: ~4th root of vocab size, or 32–64 for small corpora.
                   # Larger embed_dim → more expressive but more parameters to train.

tokenizer = Tokenizer(num_words=VOCAB_SIZE, oov_token="<OOV>")
tokenizer.fit_on_texts(df['note'])

# texts_to_sequences → integer indices; pad_sequences → fixed length (MAX_LEN,)
X_seq = tokenizer.texts_to_sequences(df['note'])
X_seq = pad_sequences(X_seq, maxlen=MAX_LEN, padding='post', truncating='post')
# X_seq shape: (50, 40) — integer indices in range [0, VOCAB_SIZE)

# KEY DIFFERENCE FROM ONE-HOT VERSION:
# In 07_lstm_doctornotes_classify.py the next step was:
#   X = tf.keras.utils.to_categorical(X_seq, num_classes=VOCAB_SIZE)
#   → shape (50, 40, 500)   — 3-D float tensor, memory-heavy
#
# Here we feed X_seq directly to the model as-is:
#   X = X_seq  →  shape (50, 40)   — 2-D integer tensor
# The Embedding layer performs the index → vector mapping internally.
X = X_seq
print(f"\nInteger sequence input shape : {X.shape}  (samples, timesteps)")
print(f"  (one-hot version shape was : ({X.shape[0]}, {MAX_LEN}, {VOCAB_SIZE}))")
print(f"  Memory saving: {X.shape[0]*MAX_LEN*VOCAB_SIZE*4 / 1024:.0f} KB → "
      f"{X.nbytes / 1024:.0f} KB for the input tensor alone")

# ── 3. Encode labels ──────────────────────────────────────────────────────────

label_encoder = LabelEncoder()
y = label_encoder.fit_transform(df['issue_category'])
print(f"\nLabel classes: {list(label_encoder.classes_)}")

# ── 4. Train / test split ─────────────────────────────────────────────────────

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print(f"\nTrain samples: {len(X_train)}  |  Test samples: {len(X_test)}")

# ── 5. Build model (with Embedding layer) ─────────────────────────────────────
#
# Architecture change from one-hot version:
#   BEFORE:  LSTM(64, input_shape=(MAX_LEN, VOCAB_SIZE))   ← first LSTM sees 500 inputs/step
#   AFTER:   Embedding(...)  →  LSTM(64)                   ← first LSTM sees 32 inputs/step
#
# mask_zero=True tells the Embedding (and downstream LSTM) to ignore padding
# tokens (index 0) — they contribute nothing to the hidden state.

model = Sequential([
    # Embedding: integer index sequence → dense vector sequence
    # Input shape:  (batch, MAX_LEN)              — integer indices
    # Output shape: (batch, MAX_LEN, EMBED_DIM)   — dense float vectors
    # Parameters:   VOCAB_SIZE × EMBED_DIM = 500 × 32 = 16,000
    Embedding(VOCAB_SIZE, EMBED_DIM, input_length=MAX_LEN, mask_zero=True),

    # LSTM stack — identical to one-hot version, just smaller input width
    LSTM(64, return_sequences=True),
    LSTM(32),
    Dense(16, activation='relu'),
    Dropout(0.5),
    Dense(5, activation='softmax'),   # 5 issue categories
])

model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy'],
)

model.summary()

# Print parameter comparison note after summary
print("\nParameter note:")
print(f"  One-hot LSTM input weight W_x : 64 × {VOCAB_SIZE} = {64*VOCAB_SIZE:,} params")
print(f"  Embedding LSTM input weight W_x: 64 × {EMBED_DIM}  = {64*EMBED_DIM:,} params")
print(f"  Embedding table itself         : {VOCAB_SIZE} × {EMBED_DIM} = {VOCAB_SIZE*EMBED_DIM:,} params")
print(f"  Net reduction in LSTM weights  : {64*VOCAB_SIZE - 64*EMBED_DIM:,} params saved")

# ── 6. Train ──────────────────────────────────────────────────────────────────

print("\nTraining model...")
history = model.fit(
    X_train, y_train,
    epochs=10,
    batch_size=8,
    validation_split=0.2,
    verbose=1,
)

# ── 7. Evaluate ───────────────────────────────────────────────────────────────

loss, acc = model.evaluate(X_test, y_test, verbose=0)
print(f"\nTest loss    : {loss:.4f}")
print(f"Test accuracy: {acc:.2f}")

y_pred_probs = model.predict(X_test, verbose=0)
y_pred       = np.argmax(y_pred_probs, axis=1)
class_names  = label_encoder.classes_

print("\nClassification Report:")
print(classification_report(y_test, y_pred,
                             labels=list(range(len(class_names))),
                             target_names=class_names,
                             zero_division=0))

cm = confusion_matrix(y_test, y_pred, labels=list(range(len(class_names))))
print("Confusion Matrix (rows=actual, cols=predicted):")
print(cm)

# ── 8. Visualise ──────────────────────────────────────────────────────────────

fig, axes = plt.subplots(1, 3, figsize=(16, 4))

axes[0].plot(history.history['accuracy'],     label='Train')
axes[0].plot(history.history['val_accuracy'], label='Validation')
axes[0].set_title('Accuracy over Epochs (Embedding)')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('Accuracy')
axes[0].legend()
axes[0].grid(True)

axes[1].plot(history.history['loss'],     label='Train')
axes[1].plot(history.history['val_loss'], label='Validation')
axes[1].set_title('Loss over Epochs (Embedding)')
axes[1].set_xlabel('Epoch')
axes[1].set_ylabel('Loss')
axes[1].legend()
axes[1].grid(True)

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=class_names)
disp.plot(ax=axes[2], colorbar=False, xticks_rotation=30)
axes[2].set_title('Confusion Matrix — Test Set')

plt.tight_layout()
plt.show()

# ── 9. Inspect learned embedding vectors ──────────────────────────────────────
#
# After training we can pull rows out of the Embedding weight matrix to see
# whether semantically similar words drifted toward each other in the 32-D space.

print("\nInspecting learned embedding vectors (sample words):")
embedding_weights = model.layers[0].get_weights()[0]   # shape (VOCAB_SIZE, EMBED_DIM)
word_index = tokenizer.word_index

sample_words = ['damaged', 'billing', 'delivery', 'technical', 'account', 'quality']
for word in sample_words:
    idx = word_index.get(word)
    if idx is not None and idx < VOCAB_SIZE:
        vec = embedding_weights[idx]
        # Show first 6 dimensions for readability
        snippet = ', '.join(f'{v:+.3f}' for v in vec[:6])
        print(f"  '{word}' (idx {idx:3d}): [{snippet}, ...]")
    else:
        print(f"  '{word}': not in vocabulary or index out of range")

print("\n  Words like 'damaged'/'quality' should show some similarity;")
print("  'billing'/'invoice' (financial cluster) should differ from 'delivery'.")
print("  With only 50 training notes structure is subtle but present.")

# ── 10. Predict on a new support note ─────────────────────────────────────────
#
# KEY DIFFERENCE FROM ONE-HOT VERSION:
#   One-hot predict_issue_category() called to_categorical() before model.predict().
#   Here we pass the integer sequence directly — the Embedding layer handles
#   the index → vector mapping internally as part of the forward pass.

def predict_issue_category(note_text):
    seq    = tokenizer.texts_to_sequences([note_text])
    padded = pad_sequences(seq, maxlen=MAX_LEN, padding='post', truncating='post')
    # No to_categorical() here — model accepts integer indices directly
    probs  = model.predict(padded, verbose=0)
    idx    = np.argmax(probs[0])
    return label_encoder.inverse_transform([idx])[0], probs[0][idx]

test_note = "Customer reports order never arrived and tracking shows no updates for two weeks"
issue, confidence = predict_issue_category(test_note)
print(f"\nTest note   : {test_note}")
print(f"Predicted   : {issue}")
print(f"Confidence  : {confidence:.2f}")
