# pip install spacy && python -m spacy download en_core_web_sm
import spacy

model = spacy.load("en_core_web_sm")

# ---------------------------------------------------------------------------
# The two use cases below run through the base spaCy model to show it is NOT 
# suited for clinical/biomedical text.
# ---------------------------------------------------------------------------

# --- Use case 1: Healthcare company text ---
# Expected: clinical entities like Medication,
# Disease_disorder, Sign_symptom, etc.
# What spaCy gives: only generic labels (ORG, PRODUCT, …) — misses all
# medical entities entirely.
citius_text = (
    "Citius Pharmaceuticals is developing Mino-Lok to treat catheter-related "
    "bloodstream infections. The drug showed efficacy against severe bacterial "
    "infections in clinical trials, with patients reporting reduced fever and pain."
)
print("\n=== Use Case 1: Healthcare Company Text (en_core_web_sm) ===")
print("Problem: base model only sees generic labels; all medical entities are missed.")
for e in model(citius_text).ents:
    print(f"  {e.text!r:45s} -> {e.label_}")
print("  (no MEDICATION / DISEASE / SYMPTOM labels — base model has none of these)")

# --- Use case 2: Clinical note ---
# Expected: PROBLEM=Type 2 Diabetes / dizziness,
# DRUG=Ibuprofen 200mg, TREATMENT=diet modifications.
# What spaCy gives: DATE/CARDINAL/ORG at best; core clinical facts go unlabelled.
note = (
    "Patient is a 60-year-old with Type 2 Diabetes. Reports dizziness over "
    "the last 3 weeks. Prescribed Ibuprofen 200mg. Recommended diet modifications."
)
print("\n=== Use Case 2: Clinical Note (en_core_web_sm) ===")
print("Problem: base model misses the diagnosis, drug, symptom, and treatment.")
for e in model(note).ents:
    print(f"  {e.text!r:45s} -> {e.label_}")
print("  (Type 2 Diabetes, dizziness, Ibuprofen, diet modifications all unlabelled)")
