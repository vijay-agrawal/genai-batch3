# LSTM Customer Support Ticket Classifier — One-Hot Word Encoding
#
# BUSINESS PROBLEM
# ─────────────────────────────────────────────────────────────────────────────
# A retail and CPG brand captures free-text interaction notes from customer
# support agents and automated chat systems for every customer contact. Each
# note describes the customer's issue in their own words. Manually assigning an
# issue category (for routing, SLA tracking, and analytics) is slow and
# inconsistent across agents. This model automatically classifies each note into
# one of five issue categories so the support team gets an instant routing
# suggestion and analysts can monitor issue trends in real time.
#
# The five classes in this dataset:
#   1. Product Quality Issue    — defects, damage, not-as-described complaints
#   2. Billing/Pricing Dispute  — incorrect charges, missing discounts, invoice errors
#   3. Delivery/Logistics Problem — late, missing, or misdelivered orders
#   4. Technical Support Request — app/website errors, integration failures
#   5. Account Management Issue  — subscription, login, account settings problems
#
# SAMPLE ROWS
# ─────────────────────────────────────────────────────────────────────────────
#   note                                                         issue_category
#   ─────────────────────────────────────────────────────────    ─────────────────────────
#   "Customer Sarah Kim reports product arrived damaged         Product Quality Issue
#    broken parts missing from box"
#
#   "Client James Thompson charged twice for same order        Billing/Pricing Dispute
#    billing duplicate error"
#
#   "Customer Ashley Garcia reports package delayed one        Delivery/Logistics Problem
#    week past promised delivery date"
#
# ENCODING APPROACH — ONE-HOT WORDS (no Embedding layer)
# ─────────────────────────────────────────────────────────────────────────────
# Each note is tokenised into a fixed-length sequence of word indices
# (length MAX_LEN=40). Every index is then replaced by a one-hot vector of
# length VOCAB_SIZE. The LSTM therefore receives a 3-D tensor of shape:
#
#   (batch, MAX_LEN, VOCAB_SIZE)
#    ─────  ───────  ──────────
#      │       │         └─ 500  — width of each one-hot word vector
#      │       └─────────── 40   — time steps (words per note)
#      └─────────────────── ?    — how many notes are processed at once
#                                  (this is the BATCH — explained below)

#
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import tensorflow as tf

# ── 1. Create inline dataset ──────────────────────────────────────────────────

data = {
    'note': [
        # Product Quality Issue (10 samples)
        "Customer Sarah Kim reports product arrived damaged broken parts missing from box",
        "Client David Brown age 41 complains product quality inferior not matching advertised specs",
        "Order for Jessica Martinez contained defective unit with manufacturing fault noted",
        "Tom Wilson submitted feedback product material substandard tears easily after use",
        "Emma Johnson contacted support about product color fading after first wash quality complaint",
        "Robert Garcia reports product performance below expectations quality defect in component",
        "Jennifer Lee returned item citing major quality issue product stopped working day one",
        "Customer Michael Davis reports packaging damage led to broken product on arrival",
        "Samantha Chen submitted quality complaint product dimensions wrong not as described",
        "Chris Anderson reported product safety concern defective electrical component found",
        # Billing/Pricing Dispute (10 samples)
        "Customer James Thompson age 55 charged twice for same order billing duplicate error",
        "Client Maria Gonzalez reports promotional code discount not applied to invoice",
        "Order number 78923 for Kevin Smith shows incorrect price mismatch from advertised deal",
        "Patricia Wilson called about unauthorized recurring charge on credit card billing",
        "Customer Daniel Chen disputes subscription renewal charge was supposed to be cancelled",
        "Susan Martinez reports wrong tax amount billed on recent purchase needs correction",
        "Christopher Johnson age 33 disputes overcharge of twenty dollars on last order",
        "Amanda Davis submitted billing complaint about unexpected service charge on statement",
        "Brandon Lee reports invoice shows higher price than confirmed at checkout billing",
        "Melissa Brown called about loyalty reward points not converted to discount billing",
        # Delivery/Logistics Problem (10 samples)
        "Customer Ashley Garcia reports package delayed one week past promised delivery date",
        "Client Ryan Johnson order marked delivered but package never arrived missing",
        "Stephanie Anderson contacted support package delivered to wrong address neighbor received",
        "Tyler Martinez reports box arrived severely damaged contents crushed during shipping",
        "Nicole Wilson order placed three weeks ago still not shipped logistics failure",
        "Customer Justin Thompson reports shipment lost no tracking update for ten days",
        "Rebecca Smith called about items missing from delivery only partial order arrived",
        "Austin Davis reports delivery window missed courier did not attempt delivery",
        "Amanda Chen submitted complaint about repeated rescheduling of delivery appointment",
        "Brandon Wilson reports wrong product delivered items do not match order confirmation",
        # Technical Support Request (10 samples)
        "Customer Jake Brown age 29 reports website login not working password reset failed",
        "Client Olivia Martinez app crashes immediately on launch cannot place order technical",
        "Customer portal for Nathan Garcia not loading spinning indefinitely technical glitch",
        "Emma Thompson reports mobile app sync failing customer data not updating properly",
        "Customer Lucas Anderson cannot access account after recent platform update technical",
        "Isabella Johnson reports payment method not accepted at checkout integration error",
        "Noah Wilson called about API connection failure impacting order submission technical",
        "Sophia Davis reports smart device firmware update bricking unit needs technical help",
        "Liam Martinez submitted request for help configuring product integration setup",
        "Ava Chen reports recurring error message blocking access to loyalty dashboard technical",
        # Account Management Issue (10 samples)
        "Customer Michael Brown reports subscription not renewing despite valid payment method",
        "Client Grace Wilson cannot update shipping address in account management settings",
        "Customer William Martinez unable to save new preferences changes not persisting",
        "Chloe Davis reports account locked out after too many login attempts management",
        "Ethan Anderson reports rewards points balance incorrect missing from recent activity",
        "Mia Garcia called about cancellation request not processing subscription still active",
        "Alexander Thompson reports account merge from old to new email address failed",
        "Lily Johnson age 31 reports referral credit not applied to account after signup",
        "James Wilson submitted complaint about data privacy settings not saving correctly",
        "Charlotte Martinez reports account reactivation after pause not working subscription",
    ],
    'issue_category': (
        ['Product Quality Issue'] * 10 +
        ['Billing/Pricing Dispute'] * 10 +
        ['Delivery/Logistics Problem'] * 10 +
        ['Technical Support Request'] * 10 +
        ['Account Management Issue'] * 10
    )
}

df = pd.DataFrame(data)

print("Customer Support Ticket Classifier — One-Hot Word Encoding")
print("=" * 55)
print(f"\nDataset: {df.shape[0]} notes, {df['issue_category'].nunique()} issue categories")
print(f"Class distribution:\n{df['issue_category'].value_counts().to_string()}")
print("\nSample note:")
print(df['note'].iloc[0])

# ── 2. Tokenise text ──────────────────────────────────────────────────────────

# With 50 notes of 12-18 words each, the true vocabulary is ~300-400 words.
# VOCAB_SIZE=500 comfortably covers all unique words plus the OOV token.
# MAX_LEN=40 covers the longest note in the dataset without wasted padding.
VOCAB_SIZE = 500
MAX_LEN    = 40

tokenizer = Tokenizer(num_words=VOCAB_SIZE, oov_token="<OOV>")
tokenizer.fit_on_texts(df['note'])

# texts_to_sequences: each note → list of integer word indices
# pad_sequences: pad/truncate to MAX_LEN so all inputs are the same length
X_seq = tokenizer.texts_to_sequences(df['note'])
X_seq = pad_sequences(X_seq, maxlen=MAX_LEN, padding='post', truncating='post')
# X_seq shape: (50, 40) — integer indices in range [0, VOCAB_SIZE)

# ── 3. One-hot encode every word index ───────────────────────────────────────
#
# tf.keras.utils.to_categorical converts each integer index to a VOCAB_SIZE-dim one-hot vector.
# Result shape: (num_samples, MAX_LEN, VOCAB_SIZE)
#   e.g. index 7 ("quality") → [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, ...]
#
# This is the direct input to the LSTM — no Embedding layer needed.
X = tf.keras.utils.to_categorical(X_seq, num_classes=VOCAB_SIZE)
print(f"\nOne-hot encoded input shape: {X.shape}  (samples, timesteps, vocab)")

# ── 4. Encode labels ──────────────────────────────────────────────────────────

label_encoder = LabelEncoder()
y = label_encoder.fit_transform(df['issue_category'])
print(f"Label classes: {list(label_encoder.classes_)}")

# ── 5. Train / test split ─────────────────────────────────────────────────────

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print(f"\nTrain samples: {len(X_train)}  |  Test samples: {len(X_test)}")

# ── 6. Build model (no Embedding layer) ───────────────────────────────────────
#
# The first LSTM layer receives (MAX_LEN, VOCAB_SIZE) directly.
# Compared to the embedding version, each time-step input is 500-wide
# instead of 32-wide, so the LSTM's input weight matrix W_x is much larger.
# This is the core trade-off: one-hot is simple but memory/compute heavy.

model = Sequential([
    # Input: (batch, MAX_LEN, VOCAB_SIZE) — sequence of one-hot word vectors
    LSTM(64, return_sequences=True, input_shape=(MAX_LEN, VOCAB_SIZE)),
    LSTM(32),
    Dense(16, activation='relu'),
    Dropout(0.5),
    Dense(5, activation='softmax'),   # 5 issue categories
])

model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy'],
)

model.summary()

# ── 7. Train ──────────────────────────────────────────────────────────────────

# ── WHAT IS A BATCH? ─────────────────────────────────────────────────────────
#
# The model cannot process all 40 training notes at once and update its weights
# once per epoch. Instead, training is broken into BATCHES — small groups of
# notes that are processed together before each weight update.
#
# With batch_size=8 and 40 training notes:
#   Epoch 1, step 1 → process notes  0– 7  → compute loss → update weights
#   Epoch 1, step 2 → process notes  8–15  → compute loss → update weights
#   Epoch 1, step 3 → process notes 16–23  → compute loss → update weights
#   Epoch 1, step 4 → process notes 24–31  → compute loss → update weights
#   Epoch 1, step 5 → process notes 32–39  → compute loss → update weights
#   ── end of epoch 1 ──  (5 weight updates happened, not just 1)
#
# WHAT DOES ONE BATCH LOOK LIKE IN MEMORY?
#   Each note is already one-hot encoded to shape (40, 500).
#   A batch of 8 notes stacks them into a 3-D tensor:
#
#     shape: (8, 40, 500)
#             │   │    └─ 500-dim one-hot vector for each word
#             │   └────── 40 time steps (words per note)
#             └────────── 8 notes in this batch
#
#   Concretely for batch 1 (notes 0–7):
#
#     batch[0] = "Customer Sarah Kim reports product arrived damaged..."
#                → (40, 500) tensor  [time-step 0 = one-hot for "customer",
#                                     time-step 1 = one-hot for "sarah", ...]
#     batch[1] = "Client David Brown age 41 complains product quality..."
#                → (40, 500) tensor
#     ...
#     batch[7] = "Customer Michael Davis reports packaging damage..."
#                → (40, 500) tensor
#
#   The LSTM reads each of these 8 tensors in parallel — one hidden state
#   per note — and at the end of the sequence, the loss across all 8
#   predictions is averaged and used for a single gradient update.
#
# WHY NOT PROCESS ALL 40 NOTES AT ONCE (batch_size=40)?
#   You could. For 40 notes it would work fine. But in real deployments
#   with thousands of tickets, the full dataset would not fit in GPU memory.
#   Batching is also beneficial for training:
#
#   MEMORY  : only 8 × 40 × 500 = 160,000 floats in memory at once, not
#             40 × 40 × 500 = 800,000. Scales to millions of samples.
#
#   GRADIENT NOISE : each batch gives a slightly different gradient estimate
#             (because it samples a subset of examples). This noise helps
#             the optimiser escape sharp local minima and generalise better.
#             A batch of 8 is noisier than a batch of 40 — often beneficial
#             for small datasets like this one.
#
#   SPEED   : on a GPU, processing 8 notes simultaneously is faster than
#             8 sequential forward passes because matrix operations
#             parallelise across the batch dimension.
#
# WHY batch_size=8 HERE?
#   We have 40 training notes (80% of 50). batch_size=8 gives 5 steps per
#   epoch — enough gradient updates per epoch to make meaningful progress
#   on this small dataset. A larger batch (e.g. 32) would give only 1–2
#   steps per epoch, which trains too slowly on 40 samples.
# ─────────────────────────────────────────────────────────────────────────────

print("\nTraining model...")
history = model.fit(
    X_train, y_train,
    epochs=10,
    batch_size=8,       # process 8 notes at a time; 5 weight updates per epoch
    validation_split=0.2,
    verbose=1,
)

# ── 8. Evaluate ───────────────────────────────────────────────────────────────

# 8a. Overall loss & accuracy on the held-out test set
loss, acc = model.evaluate(X_test, y_test, verbose=0)
print(f"\nTest loss    : {loss:.4f}")
print(f"Test accuracy: {acc:.2f}")

# 8b. Per-class precision, recall, F1
y_pred_probs = model.predict(X_test, verbose=0)
y_pred       = np.argmax(y_pred_probs, axis=1)
class_names  = label_encoder.classes_

print("\nClassification Report:")
print(classification_report(y_test, y_pred,
                             labels=list(range(len(class_names))),
                             target_names=class_names,
                             zero_division=0))

# 8c. Confusion matrix — shows which issue types get confused with each other
cm = confusion_matrix(y_test, y_pred, labels=list(range(len(class_names))))
print("Confusion Matrix (rows=actual, cols=predicted):")
print(cm)

# 8d. Training history — spot overfitting by comparing train vs val accuracy
fig, axes = plt.subplots(1, 3, figsize=(16, 4))

axes[0].plot(history.history['accuracy'],     label='Train')
axes[0].plot(history.history['val_accuracy'], label='Validation')
axes[0].set_title('Accuracy over Epochs')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('Accuracy')
axes[0].legend()
axes[0].grid(True)

axes[1].plot(history.history['loss'],     label='Train')
axes[1].plot(history.history['val_loss'], label='Validation')
axes[1].set_title('Loss over Epochs')
axes[1].set_xlabel('Epoch')
axes[1].set_ylabel('Loss')
axes[1].legend()
axes[1].grid(True)

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=class_names)
disp.plot(ax=axes[2], colorbar=False, xticks_rotation=30)
axes[2].set_title('Confusion Matrix — Test Set')

plt.tight_layout()
plt.show()

# ── 9. Predict on a new support note ─────────────────────────────────────────

def predict_issue_category(note_text):
    seq    = tokenizer.texts_to_sequences([note_text])
    padded = pad_sequences(seq, maxlen=MAX_LEN, padding='post', truncating='post')
    # One-hot encode the single note before feeding to the model
    onehot = tf.keras.utils.to_categorical(padded, num_classes=VOCAB_SIZE)
    probs  = model.predict(onehot, verbose=0)
    idx    = np.argmax(probs[0])
    return label_encoder.inverse_transform([idx])[0], probs[0][idx]

test_note = "Customer reports order never arrived and tracking shows no updates for two weeks"
issue, confidence = predict_issue_category(test_note)
print(f"\nTest note   : {test_note}")
print(f"Predicted   : {issue}")
print(f"Confidence  : {confidence:.2f}")
