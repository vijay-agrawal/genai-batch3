"""
=============================================================================
INFORMATION RETRIEVAL DEMO 3 — Dense Bi-Encoder + ANN (Approximate Nearest Neighbor)
c5i Business Context: CPG, Retail, Pharma, Marketing Analytics
=============================================================================

THE PROGRESSION: TF-IDF → BM25 → DENSE ANN
─────────────────────────────────────────────────────────────────────────────
Each generation of retrieval technology fixes a specific failure of the one
before it. Understanding the progression explains WHY dense retrieval exists
and WHERE it is worth the extra infrastructure cost.

  DEMO 1 — TF-IDF (Bag of Words)
  ────────────────────────────────
  Words are independent atomic tokens. A document scores highly if the
  EXACT query words appear in it, weighted by how rare those words are.

  Failure mode (c5i example):
    Query   : "revenue declined this quarter"
    Document: "Q3 sales dropped significantly below forecast"
    TF-IDF  : score = 0   (zero word overlap)
    Reality : the document is a perfect match

  DEMO 2 — BM25 (Best Match 25)
  ────────────────────────────────
  Adds TF saturation (diminishing returns for repeated words) and document-
  length normalisation. Better than TF-IDF in practice — still lexical.

  Same failure mode:
    "revenue declined" vs "sales dropped" — BM25 still scores 0.
    BM25 fixes how we COUNT words; it does not fix the vocabulary mismatch.

  DEMO 3 — Dense Bi-Encoder + ANN  ← THIS FILE
  ────────────────────────────────
  A neural language model (Transformer) encodes the MEANING of text as a
  dense vector. Semantically similar text ends up close in vector space,
  regardless of surface word overlap.

    "revenue declined this quarter"   → vector A
    "sales dropped significantly"     → vector B
    cosine(A, B) ≈ 0.87              → retrieved correctly

  The model is trained with CONTRASTIVE LEARNING on millions of (query,
  relevant-document) pairs, so it learns that "revenue" and "sales",
  "declined" and "dropped", "channel" and "medium" are interchangeable
  in meaning even though they share no characters.

─────────────────────────────────────────────────────────────────────────────
FUNCTIONAL IMPORTANCE FOR c5i CLIENTS
─────────────────────────────────────────────────────────────────────────────
c5i works with Fortune 500 CPG, pharma, retail, and marketing clients whose
knowledge bases contain:

  • Thousands of campaign performance reports using varied financial vocabulary
    ("ROI", "return", "efficiency", "payoff", "margin lift")
  • Product catalog entries where the same attribute appears as "premium",
    "high-end", "superior grade", "top-tier" across different brands/vendors
  • Customer feedback in raw colloquial language: "product keeps breaking",
    "junk", "falls apart", "not durable" — none of which match the formal
    label "Product Quality Issue" in a TF-IDF index
  • Clinical and regulatory documents using technical terminology that analysts
    query in lay language: "does this drug cause liver problems" should match
    "hepatotoxicity risk documented in Phase III trial"

  TF-IDF and BM25 fail on all of these because they require the query and
  the document to share vocabulary. Dense retrieval bridges the gap.

─────────────────────────────────────────────────────────────────────────────
c5i USE-CASES WHERE DENSE RETRIEVAL IS THE RIGHT TOOL
─────────────────────────────────────────────────────────────────────────────

  1. DIGITAL SHELF ANALYTICS — Cross-brand product search
     A category manager searches for "biodegradable packaging options".
     Relevant shelf documents say "eco-friendly wrapping", "compostable
     materials", "sustainable packaging". Zero word overlap with TF-IDF.
     Dense retrieval finds them all.

  2. MARKETING MIX MODELLING — Campaign report retrieval
     A modeller asks "which channels drove the most incremental sales last
     summer". Reports say "above-the-line spend yielded highest attribution
     coefficient in Q3". TF-IDF: 0 matches. Dense: correct documents surface.

  3. CUSTOMER ANALYTICS — Complaint categorisation and routing
     An analyst searches for "customers unhappy with delivery speed".
     Tickets say "package took forever", "slow shipping ruined the experience",
     "courier was terrible". Dense retrieval handles the paraphrase; BM25 fails.

  4. PHARMA — Lay-to-clinical language bridging
     Medical affairs team builds a self-service portal for brand teams.
     User queries: "does this product cause stomach pain". Documents say
     "gastrointestinal adverse events reported". Dense bridges the gap.

  5. INTERNAL KNOWLEDGE SEARCH — MLOps / LLMOps documentation
     Engineers ask "how do I monitor model quality over time". Internal
     wikis say "production drift detection", "model performance degradation",
     "data distribution shift". Dense retrieval surfaces them; keyword search
     fails unless engineers remember the exact jargon.

─────────────────────────────────────────────────────────────────────────────
RATIONALE: WHEN TO USE DENSE OVER BM25
─────────────────────────────────────────────────────────────────────────────
  USE DENSE WHEN:
    • Queries come from end-users who use lay/colloquial language
    • Your corpus uses varied vocabulary across documents or brands
    • Queries are conceptual ("what is our pricing strategy in pharma")
    • You need cross-lingual retrieval (client docs in French/German)
    • Acronym expansion matters ("HTN" = "hypertension", "MMM" = "marketing
      mix modelling", "NPS" = "Net Promoter Score")

  STAY WITH BM25 WHEN:
    • Queries contain exact identifiers: SKU codes, invoice numbers, drug
      names (metformin ≠ methotrexate — dense models may confuse them)
    • Precise numerical matching matters: "eGFR < 30", "CPM $2.40"
    • Corpus vocabulary is already consistent and controlled
    • Latency or infrastructure budget doesn't allow a vector index

  BEST PRACTICE: RUN BOTH (HYBRID RETRIEVAL)
    Stage 1: BM25 + Dense in parallel → union of candidates (100-200 docs)
    Stage 2: Cross-encoder reranks the union → precise top-10
    This is the production architecture used in enterprise search and RAG
    pipelines. See 04_rerankers.py for the cross-encoder stage.

─────────────────────────────────────────────────────────────────────────────
ARCHITECTURE
─────────────────────────────────────────────────────────────────────────────
              Query                          Document
                │                               │
        ┌───────▼────────┐             ┌────────▼───────┐
        │  Transformer   │             │  Transformer   │
        │  Encoder       │             │  Encoder       │
        │  (shared       │             │  (same weights)│
        │   weights)     │             └────────┬───────┘
        └───────┬────────┘                      │
                │                               │
            q_vector                       d_vector
         (384-dim float)               (384-dim float)
                │                               │
                └────── cosine_similarity ───────┘
                                 score

  WHY "BI"-ENCODER?
  Query and document are encoded INDEPENDENTLY. Documents are encoded ONCE
  at index build time and stored. At query time only the query is encoded
  (~2ms), then vector search returns top-k instantly.

  THIS DEMO uses all-MiniLM-L6-v2: fast, 80MB, good general-purpose
  quality. For c5i production, fine-tune on domain-specific (query, document)
  pairs from client data for meaningful accuracy gains.

─────────────────────────────────────────────────────────────────────────────
THIS DEMO
─────────────────────────────────────────────────────────────────────────────
  Corpus : 30 business documents across CPG, Retail, Pharma, Marketing,
           Customer Analytics, and MLOps domains
  Queries: 5 queries using lay/colloquial language — designed to expose
           cases where BM25 fails and dense retrieval succeeds
  Steps  : Encode → FAISS index → Dense search → BM25 comparison →
           Recall@k → Embedding space visualisation

  Run:  python 03_dense_ann_demo.py
  Deps: pip install sentence-transformers faiss-cpu umap-learn matplotlib
        rank-bm25 scikit-learn seaborn
=============================================================================
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# SentenceTransformer (Hugging Face / UKP Lab)
# ─────────────────────────────────────────────────────────────────────────────
# A pre-trained BERT-family model fine-tuned with CONTRASTIVE LEARNING so that
# semantically similar sentences land close together in vector space.
#
# How it differs from plain BERT:
#   Plain BERT        → produces one vector PER TOKEN; no obvious "sentence" vector
#   SentenceTransformer → pools token vectors into ONE fixed-size vector (e.g. 384-d
#                         for MiniLM) that represents the whole sentence's MEANING
#
# Training signal (contrastive / bi-encoder):
#   Given pairs (anchor, positive, negative), the model is trained to minimise
#   distance(anchor, positive) and maximise distance(anchor, negative).
#   Result: "customers are leaving" and "churn prediction" end up near each other
#   even though they share no words — because they appeared in similar contexts
#   across millions of sentence pairs.
#
# Model used here: "all-MiniLM-L6-v2"
#   • 6-layer MiniLM (distilled from larger BERT) — fast enough for a demo
#   • Trained on 1B+ sentence pairs from web, Reddit, Wikipedia, NLI datasets
#   • Output: 384-dimensional unit-norm vector per sentence
#   • Good balance of speed and semantic quality for English business text
#
# Why this matters for c5i:
#   A campaign analyst writing "social media ads not delivering value" and a
#   data engineer tagging a doc "paid social underperformance" will get matched
#   — without any shared keywords — because both phrases map to the same region
#   of the 384-d semantic space.
# ─────────────────────────────────────────────────────────────────────────────
try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    raise SystemExit("Missing dep: pip install sentence-transformers")

try:
    import faiss
except ImportError:
    raise SystemExit("Missing dep: pip install faiss-cpu")

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity as sklearn_cosine
    from rank_bm25 import BM25Okapi
    HAVE_SPARSE = True
except ImportError:
    HAVE_SPARSE = False
    print("[WARN] scikit-learn or rank-bm25 not installed — skipping comparison table")

# ─────────────────────────────────────────────────────────────────────────────
# CORPUS — 30 c5i business documents across six domains
# Each document is representative of real content c5i clients search across:
# campaign reports, shelf analytics, customer feedback, pharma, CX, MLOps.
# ─────────────────────────────────────────────────────────────────────────────
DOCUMENTS = [
    # ── Marketing Mix Modelling ───────────────────────────────────────────────
    {
        "id": "MMM01", "domain": "Marketing Analytics",
        "title": "TV Spend Attribution Q3",
        "text": (
            "Above-the-line television advertising delivered the highest incremental revenue "
            "contribution in Q3, with an attribution coefficient of 0.42 per thousand GRPs. "
            "Diminishing returns set in above a weekly spend threshold of two million dollars. "
            "The halo effect on e-commerce conversion was measurable for up to three weeks "
            "after the flight ended. Recommended spend reallocation reduces TV budget by 15% "
            "and reinvests in digital mid-funnel to improve overall marketing ROI."
        ),
    },
    {
        "id": "MMM02", "domain": "Marketing Analytics",
        "title": "Paid Social Efficiency Report",
        "text": (
            "Paid social media channels showed declining return on ad spend across all CPG "
            "brands in the portfolio this fiscal year. Cost per incremental unit sold rose 34% "
            "year on year as audience saturation increased on major platforms. "
            "Retargeting campaigns outperformed prospecting by a factor of 2.4x on conversion "
            "rate. Budget reallocation toward influencer partnerships and connected TV "
            "is projected to recover efficiency losses by Q2."
        ),
    },
    {
        "id": "MMM03", "domain": "Marketing Analytics",
        "title": "Promotional Price Elasticity Analysis",
        "text": (
            "Price elasticity modelling for the snacks category revealed that a 10% temporary "
            "price reduction yields a 28% volume uplift during the promotion window. "
            "Post-promotion dip erases approximately 40% of the uplift over two subsequent "
            "weeks as pantry loading effects unwind. Everyday low price strategy outperforms "
            "high-low promotion strategy for brand equity metrics over a 12-month horizon. "
            "Deep discounts above 25% accelerate private label switching among price-sensitive "
            "consumers in the value segment."
        ),
    },
    {
        "id": "MMM04", "domain": "Marketing Analytics",
        "title": "Cross-Channel Attribution Methodology",
        "text": (
            "Last-touch attribution systematically undervalues upper-funnel channels including "
            "display advertising, programmatic video, and brand search campaigns. "
            "Data-driven attribution using Shapley value allocation distributes credit more "
            "equitably across the customer journey touchpoints. "
            "Out-of-home advertising contribution is frequently invisible to digital attribution "
            "models and requires marketing mix modelling for proper measurement. "
            "Incrementality testing via geo holdout experiments provides ground-truth validation "
            "for attribution model outputs."
        ),
    },
    {
        "id": "MMM05", "domain": "Marketing Analytics",
        "title": "Brand Health Tracker Methodology",
        "text": (
            "Brand health tracking measures aided and unaided awareness, consideration, "
            "preference, and purchase intent on a monthly rolling basis. "
            "Net Promoter Score declined four points following the product recall event, "
            "recovering to baseline within six months with targeted reputation repair campaigns. "
            "Share of voice correlation with market share follows an S-curve: brands below "
            "a 20% share of voice threshold experience accelerating market share erosion. "
            "Emotional brand equity scores are stronger predictors of long-term sales than "
            "rational attribute ratings."
        ),
    },
    # ── Digital Shelf Analytics ───────────────────────────────────────────────
    {
        "id": "DSA01", "domain": "Digital Shelf",
        "title": "Content Quality Score Methodology",
        "text": (
            "Digital shelf content quality is scored across five dimensions: title completeness, "
            "image count and resolution, bullet point count, A-plus content presence, and "
            "customer review volume. Products scoring below 70 out of 100 on the content index "
            "show 23% lower conversion rates compared to fully optimised listings. "
            "Missing pack size and ingredient information are the most common content gaps "
            "identified across the health and beauty category on major e-commerce platforms."
        ),
    },
    {
        "id": "DSA02", "domain": "Digital Shelf",
        "title": "Out-of-Stock Velocity Monitoring",
        "text": (
            "Out-of-stock events on e-commerce platforms are more damaging than physical retail "
            "because the algorithm penalises the listing after the stockout resolves. "
            "Search rank recovery following an out-of-stock event takes on average 11 days "
            "on the major grocery platforms. "
            "Real-time inventory monitoring with 4-hour alerts allows supply chain teams to "
            "initiate emergency replenishment before the listing drops from the top-10 results. "
            "Category leaders maintain in-stock rates above 98% as a baseline operational target."
        ),
    },
    {
        "id": "DSA03", "domain": "Digital Shelf",
        "title": "Competitor Price Tracking Retail",
        "text": (
            "Automated price surveillance across 12 major e-commerce platforms tracks "
            "competitor SKU prices, promotional frequency, and bundling strategies daily. "
            "Category captain brands price within 3% of the category median to avoid triggering "
            "platform algorithmic price parity enforcement. "
            "Private label pricing undercuts national brands by 28% on average in the ambient "
            "grocery category, narrowing to 18% in premium sub-categories. "
            "Flash sale detection algorithms identify competitor discount events within two hours "
            "enabling rapid promotional response decisions."
        ),
    },
    {
        "id": "DSA04", "domain": "Digital Shelf",
        "title": "Search Rank Optimisation Strategy",
        "text": (
            "Organic search rank on e-commerce platforms is determined by a combination of "
            "sales velocity, content quality score, customer ratings, and fulfillment performance. "
            "Keyword integration in product titles improves search visibility by 31% on average "
            "in the personal care category according to controlled A-B testing. "
            "Sponsored product advertising boosts organic rank as a secondary benefit through "
            "increased sales velocity signals fed back to the ranking algorithm. "
            "Category-specific keyword lists refreshed monthly capture seasonal search intent shifts."
        ),
    },
    {
        "id": "DSA05", "domain": "Digital Shelf",
        "title": "Customer Review Sentiment Analysis",
        "text": (
            "Customer review analysis using NLP models identifies the top recurring product "
            "complaints and praise themes at scale across hundreds of thousands of reviews. "
            "Packaging damage during shipping accounts for 31% of one and two star reviews "
            "in the fragile goods category, pointing to a fulfillment rather than product issue. "
            "Positive reviews most frequently cite value for money, fast delivery, and product "
            "efficacy as the top three satisfaction drivers. "
            "Review velocity monitoring detects negative sentiment spikes within 24 hours of "
            "a product formulation change or supply chain substitution event."
        ),
    },
    # ── Customer Analytics ────────────────────────────────────────────────────
    {
        "id": "CX01", "domain": "Customer Analytics",
        "title": "Churn Prediction Model Retail",
        "text": (
            "Customer churn prediction models built on 18 months of transaction history achieve "
            "an AUC of 0.84 for the loyalty programme base. "
            "Declining purchase frequency combined with zero email engagement over 60 days "
            "is the strongest leading indicator of lapsing behaviour identified in the model. "
            "Proactive retention outreach to high-value customers in the top churn risk decile "
            "reduces lapse rate by 22% compared to control groups. "
            "Customers acquired via promotional deep discounts churn at 2.3x the rate of "
            "full-price acquired customers within the first 12 months."
        ),
    },
    {
        "id": "CX02", "domain": "Customer Analytics",
        "title": "NPS Driver Analysis Telecom",
        "text": (
            "Net Promoter Score driver analysis reveals that first-call resolution is the single "
            "strongest predictor of promoter classification in the broadband customer base. "
            "Customers who wait more than three minutes on hold are four times more likely to "
            "submit a detractor score regardless of the eventual resolution outcome. "
            "Proactive outage notifications reduce complaint volumes by 40% compared to "
            "reactive communication-only protocols. "
            "Agent empathy ratings correlate more strongly with NPS than technical resolution "
            "quality scores in post-call survey analysis."
        ),
    },
    {
        "id": "CX03", "domain": "Customer Analytics",
        "title": "Customer Lifetime Value Segmentation",
        "text": (
            "Customer lifetime value segmentation divides the active base into five tiers based "
            "on predicted three-year revenue contribution per customer. "
            "The top 20% of customers by CLV account for 68% of total contribution margin, "
            "justifying differential service and retention investment. "
            "Category expansion cross-sell is the highest ROI CLV growth lever for mid-tier "
            "customers who purchase from only one or two categories currently. "
            "Price sensitivity analysis shows high-CLV customers are 40% less sensitive to "
            "promotional pricing than the average customer, supporting premium pricing strategies."
        ),
    },
    {
        "id": "CX04", "domain": "Customer Analytics",
        "title": "Support Ticket Volume Reduction",
        "text": (
            "Support ticket deflection analysis identified that 43% of inbound contacts concern "
            "order status queries that could be resolved by an improved self-service tracking page. "
            "Improving the returns process reduced post-purchase support contacts by 28% in the "
            "pilot region over a three-month period. "
            "Predictive routing using machine learning classifiers reduces average handle time "
            "by 19% by matching ticket category to the most qualified available agent. "
            "Proactive shipment delay notifications sent before customers notice the delay "
            "reduce inbound enquiries by 35% and improve satisfaction scores."
        ),
    },
    {
        "id": "CX05", "domain": "Customer Analytics",
        "title": "Product Quality Complaint Patterns",
        "text": (
            "Analysis of 120,000 customer support interactions reveals that product defects, "
            "damage on arrival, and packaging failures collectively account for 38% of all "
            "complaint volume in the household goods category. "
            "Complaint rate spikes correlate with manufacturing batch changes with a 14-day lag, "
            "enabling rapid quality signal detection before formal QA escalations. "
            "Social media complaint volume predicts inbound support ticket volume with a "
            "3-day leading indicator relationship. "
            "Resolution speed is the primary determinant of whether a complaining customer "
            "remains in the active base or churns within 90 days."
        ),
    },
    # ── CPG & Retail Category Management ─────────────────────────────────────
    {
        "id": "CPG01", "domain": "CPG Retail",
        "title": "Category Range Review Process",
        "text": (
            "Annual range review processes evaluate SKU contribution, shelf productivity, "
            "and consumer need state coverage to determine listings, delistings, and new product "
            "introductions for the forthcoming planogram cycle. "
            "SKUs below the category average gross margin threshold and with distribution below "
            "50% of target stores are primary delisting candidates. "
            "Innovation pipeline products require minimum 12-week sales velocity data from "
            "trial store clusters before national ranging decisions are finalised. "
            "Shopper decision tree analysis determines the correct shelf adjacency and flow "
            "to minimise lost sales from poor navigation."
        ),
    },
    {
        "id": "CPG02", "domain": "CPG Retail",
        "title": "Sustainable Packaging Transition",
        "text": (
            "Transitioning primary packaging from virgin plastic to 50% recycled content "
            "reduces scope 3 carbon emissions by an estimated 18% for the beverage portfolio. "
            "Consumer acceptance testing shows no statistically significant difference in "
            "purchase intent between current and sustainable packaging formats at equivalent "
            "price points in blind concept testing. "
            "Retailer sustainability scorecards increasingly gate new product ranging decisions, "
            "creating a commercial imperative to accelerate packaging transition timelines. "
            "Unit cost increase of 4-7% for recycled content materials is partially offset "
            "by reduced extended producer responsibility levies."
        ),
    },
    {
        "id": "CPG03", "domain": "CPG Retail",
        "title": "Private Label Competitive Response",
        "text": (
            "Private label share in the ambient grocery category reached 38% in value terms, "
            "gaining 6 percentage points over three years at the expense of mid-tier national "
            "brands caught between premium and economy price positions. "
            "Defending volume share requires sharpening the value proposition through "
            "pack size optimisation, relevant innovation, and consistent promotional presence. "
            "Consumer research confirms that quality perception gap between national brand and "
            "retailer own-label has narrowed significantly in commodity-adjacent categories. "
            "Brand building investment sustains a price premium of 12-18% only when paired "
            "with consistent product superiority and meaningful product news."
        ),
    },
    {
        "id": "CPG04", "domain": "CPG Retail",
        "title": "New Product Launch Velocity Tracking",
        "text": (
            "New product launch performance is evaluated against a 13-week velocity benchmark "
            "derived from successful launches in the same category over the prior five years. "
            "Distribution build rate is the primary early warning metric: products achieving "
            "less than 60% of target distribution by week 8 rarely recover to forecast. "
            "Trial rate from first-time buyers and repeat purchase rate at week 12 together "
            "predict whether a launch will achieve year-one revenue targets within 20% accuracy. "
            "In-store execution quality, measured by on-shelf availability and display compliance, "
            "explains 30% of launch performance variance independent of the product itself."
        ),
    },
    {
        "id": "CPG05", "domain": "CPG Retail",
        "title": "Trade Spend Optimisation Framework",
        "text": (
            "Trade promotional expenditure accounts for 18-24% of gross revenue in most CPG "
            "categories, making trade spend ROI optimisation the largest single lever for "
            "improving net revenue realisation. "
            "Event-level profitability analysis reveals that 40% of promotional events "
            "destroy value when full supply chain and retailer margin costs are included. "
            "Retailer-specific promotional calendars aligned to shopper mission timing "
            "outperform generic promotional activity by 35% on volume uplift per dollar spent. "
            "Shifting from scan-back to performance-linked trade terms improves accountability "
            "and reduces unearned promotional allowances."
        ),
    },
    # ── Pharma ────────────────────────────────────────────────────────────────
    {
        "id": "PH01", "domain": "Pharma",
        "title": "GLP-1 Receptor Agonist Market Access",
        "text": (
            "GLP-1 receptor agonists face formulary access barriers due to premium pricing "
            "and payer concerns about long-term budget impact for obesity indications. "
            "Outcomes-based contracts linking reimbursement to weight loss milestones at "
            "12 months are gaining traction with self-insured employers and regional payers. "
            "Patient persistence on injectable GLP-1 therapy is significantly lower than "
            "on oral medications, reducing real-world cost-effectiveness versus clinical trial data. "
            "Combination therapy evidence with SGLT2 inhibitors is expanding the clinical "
            "use case and supporting premium pricing negotiations with payers."
        ),
    },
    {
        "id": "PH02", "domain": "Pharma",
        "title": "Adverse Event Signal Detection",
        "text": (
            "Pharmacovigilance signal detection uses disproportionality analysis on spontaneous "
            "adverse event reports in the FDA FAERS database and EudraVigilance. "
            "Reporting odds ratio and information component metrics identify unexpected safety "
            "signals requiring expedited clinical review and potential label update. "
            "Social media listening complements spontaneous reporting by capturing patient "
            "experiences not reported through formal channels including fatigue and mood changes. "
            "Machine learning classification of free-text adverse event narratives accelerates "
            "triage and Medical Dictionary for Regulatory Activities coding workflows."
        ),
    },
    {
        "id": "PH03", "domain": "Pharma",
        "title": "Patient Adherence Digital Programme",
        "text": (
            "Medication adherence rates for chronic disease therapies average 50% at 12 months, "
            "representing a significant gap between clinical trial and real-world effectiveness. "
            "Digital adherence programmes using SMS reminders, connected device integration, "
            "and personalised education content improve persistence by 18-24% in pilot cohorts. "
            "Patients who experience side effects in the first four weeks are at highest risk "
            "of early discontinuation and require proactive clinical support interventions. "
            "Simplifying dosing regimens from twice daily to once daily increases adherence "
            "by approximately 15% independent of drug class or therapeutic area."
        ),
    },
    {
        "id": "PH04", "domain": "Pharma",
        "title": "Real World Evidence Generation Strategy",
        "text": (
            "Real world evidence studies using claims data, electronic health records, and "
            "patient registries supplement randomised controlled trial findings for regulatory "
            "submissions and payer value dossiers. "
            "Comparative effectiveness analyses comparing treatment sequences in oncology "
            "inform treatment guideline updates and market access negotiations. "
            "Propensity score matching and instrumental variable methods are required to "
            "control confounding in observational database studies. "
            "Patient reported outcome measures collected via digital applications provide "
            "quality of life endpoints that clinical measures alone cannot capture."
        ),
    },
    {
        "id": "PH05", "domain": "Pharma",
        "title": "Oncology Biomarker Testing Access",
        "text": (
            "Comprehensive genomic profiling adoption remains below 40% for eligible advanced "
            "non-small cell lung cancer patients despite guideline recommendations. "
            "Turnaround time from biopsy to biomarker result exceeds 14 days at 60% of "
            "community oncology sites, delaying targeted therapy initiation. "
            "Liquid biopsy using circulating tumour DNA offers a faster and less invasive "
            "alternative for patients where tissue biopsy is clinically challenging. "
            "Payer prior authorisation requirements for biomarker-matched therapies add "
            "average 8-day delays to treatment initiation in the US market."
        ),
    },
    # ── MLOps / LLMOps ───────────────────────────────────────────────────────
    {
        "id": "ML01", "domain": "MLOps",
        "title": "Production Model Drift Detection",
        "text": (
            "Data distribution shift in production machine learning systems degrades model "
            "performance silently without triggering operational alerts in most monitoring setups. "
            "Population stability index monitoring on input features detects covariate shift "
            "before prediction quality metrics decline measurably. "
            "Concept drift in customer behaviour models is most pronounced after major external "
            "events such as economic shocks, competitor launches, or platform algorithm changes. "
            "Automated retraining pipelines triggered by drift thresholds reduce mean time to "
            "model recovery from weeks to hours in mature MLOps organisations."
        ),
    },
    {
        "id": "ML02", "domain": "MLOps",
        "title": "LLM Evaluation and Quality Assurance",
        "text": (
            "Evaluating large language model outputs in production requires a combination of "
            "automated metrics and human evaluation panels sampling responses at regular intervals. "
            "Hallucination rate, factual grounding score, and response relevance are the "
            "three primary quality dimensions for enterprise LLM deployments in regulated industries. "
            "Retrieval augmented generation architectures reduce hallucination rates by anchoring "
            "responses to a curated, versioned knowledge base rather than parametric memory. "
            "Red team adversarial testing should be conducted before each major model version "
            "upgrade to identify new failure modes introduced by capability improvements."
        ),
    },
    {
        "id": "ML03", "domain": "MLOps",
        "title": "Feature Store Architecture Enterprise",
        "text": (
            "A centralised feature store ensures consistent feature definitions between model "
            "training and online serving, eliminating training-serving skew as a source of "
            "production performance degradation. "
            "Time-travel functionality in the feature store prevents data leakage by ensuring "
            "only features available at the prediction timestamp are used during training. "
            "Feature reuse across multiple models reduces data engineering duplication and "
            "accelerates new model development timelines by 40% in mature platform teams. "
            "Point-in-time correct joins for event-driven features require careful implementation "
            "to avoid look-ahead bias in historical performance evaluations."
        ),
    },
    {
        "id": "ML04", "domain": "MLOps",
        "title": "Model Governance and Explainability",
        "text": (
            "Model governance frameworks require documented evidence of fairness testing, "
            "performance benchmarking, and business owner sign-off before production deployment. "
            "SHAP values provide local and global feature importance explanations that satisfy "
            "regulatory and audit requirements for credit and insurance decision models. "
            "Model cards standardise the documentation of training data, intended use cases, "
            "known limitations, and performance across demographic subgroups. "
            "Automated bias detection testing against protected characteristics must be integrated "
            "into the CI-CD pipeline before any model serving customer-facing decisions."
        ),
    },
    {
        "id": "ML05", "domain": "MLOps",
        "title": "RAG Pipeline Architecture for Enterprise",
        "text": (
            "Retrieval augmented generation combines a vector search index with a language model "
            "to answer questions grounded in a private enterprise knowledge base. "
            "Chunking strategy, embedding model selection, and retrieval top-k are the three "
            "hyperparameters with the largest impact on end-to-end answer quality. "
            "Hybrid retrieval combining BM25 sparse and dense vector search consistently "
            "outperforms either method alone on enterprise question answering benchmarks. "
            "Re-ranking the retrieval candidates with a cross-encoder before generation "
            "reduces irrelevant context and hallucination rates in production deployments."
        ),
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# QUERIES — deliberately use colloquial / paraphrased language to expose
# where BM25 fails and dense retrieval succeeds.
# Each query note explains the semantic gap being tested.
# ─────────────────────────────────────────────────────────────────────────────
QUERIES = [
    {
        "id": "Q1",
        "text": "social media ads not delivering value for money",
        "note": (
            "Lay language for paid social efficiency. "
            "Target docs use 'return on ad spend', 'cost per incremental unit', 'efficiency losses'. "
            "Zero word overlap with query — BM25 should fail; dense should retrieve MMM02."
        ),
    },
    {
        "id": "Q2",
        "text": "customers are leaving and we need to stop them",
        "note": (
            "Colloquial phrasing for churn. "
            "Target docs use 'lapse', 'churn', 'retention', 'lapsing behaviour'. "
            "Dense should bridge 'leaving' → 'churn' / 'lapsing'."
        ),
    },
    {
        "id": "Q3",
        "text": "product keeps breaking after a short time",
        "note": (
            "Consumer complaint language for product quality. "
            "Target docs use 'defects', 'damage', 'complaint volume', 'quality signal'. "
            "BM25 matches nothing; dense should retrieve CX05."
        ),
    },
    {
        "id": "Q4",
        "text": "AI model predictions getting worse over time",
        "note": (
            "Engineering lay language for model drift. "
            "Target docs use 'distribution shift', 'performance degradation', 'covariate shift'. "
            "Dense should retrieve ML01 despite zero exact word overlap."
        ),
    },
    {
        "id": "Q5",
        "text": "eco friendly packaging consumer acceptance",
        "note": (
            "Marketing/sustainability query. "
            "Target doc CPG02 uses 'sustainable packaging', 'recycled content', 'consumer acceptance testing'. "
            "'eco friendly' and 'sustainable'/'recycled' share no characters — semantic bridging required."
        ),
    },
]

DOMAINS = list(dict.fromkeys(d["domain"] for d in DOCUMENTS))
DOMAIN_COLORS = {
    d: plt.cm.tab10(i / len(DOMAINS)) for i, d in enumerate(DOMAINS)
}


# ─────────────────────────────────────────────────────────────────────────────
# ENCODE DOCUMENTS
# ─────────────────────────────────────────────────────────────────────────────
def encode_corpus(docs, model_name="all-MiniLM-L6-v2"):
    print(f"\n[Loading sentence-transformer model: {model_name}]")
    model = SentenceTransformer(model_name)
    texts = [d["text"] for d in docs]
    print(f"[Encoding {len(texts)} business documents ...]")
    embeddings = model.encode(texts, show_progress_bar=True, normalize_embeddings=True)
    return model, embeddings.astype(np.float32)


# ─────────────────────────────────────────────────────────────────────────────
# BUILD FAISS INDICES
# ─────────────────────────────────────────────────────────────────────────────
def build_faiss_indices(embeddings):
    dim = embeddings.shape[1]
    n   = embeddings.shape[0]

    flat_index = faiss.IndexFlatIP(dim)   # Inner Product = cosine for normalised vecs
    flat_index.add(embeddings)

    nlist     = max(4, int(np.sqrt(n)))
    ivf_index = faiss.IndexIVFFlat(
        faiss.IndexFlatIP(dim), dim, nlist, faiss.METRIC_INNER_PRODUCT
    )
    ivf_index.train(embeddings)
    ivf_index.add(embeddings)
    ivf_index.nprobe = max(2, nlist // 2)

    print(f"\nFAISS Flat index : {flat_index.ntotal} vectors, dim={dim}")
    print(f"FAISS IVF  index : {ivf_index.ntotal} vectors, nlist={nlist}, nprobe={ivf_index.nprobe}")
    return flat_index, ivf_index


# ─────────────────────────────────────────────────────────────────────────────
# DENSE SEARCH
# ─────────────────────────────────────────────────────────────────────────────
def dense_search(query_text, model, index, docs, top_k=5):
    q_emb = model.encode([query_text], normalize_embeddings=True).astype(np.float32)
    scores, indices = index.search(q_emb, top_k)
    hits = []
    for rank, (idx, score) in enumerate(zip(indices[0], scores[0])):
        if idx >= 0:
            hits.append({
                "rank"    : rank + 1,
                "doc_id"  : docs[idx]["id"],
                "title"   : docs[idx]["title"],
                "domain"  : docs[idx]["domain"],
                "score"   : float(score),
                "snippet" : docs[idx]["text"][:110] + "...",
            })
    return hits


# ─────────────────────────────────────────────────────────────────────────────
# BM25 SEARCH (for comparison)
# ─────────────────────────────────────────────────────────────────────────────
def bm25_search(docs, query_text, top_k=5):
    if not HAVE_SPARSE:
        return []
    tokenized = [d["text"].lower().split() for d in docs]
    bm25      = BM25Okapi(tokenized)
    scores    = bm25.get_scores(query_text.lower().split())
    top_idx   = np.argsort(scores)[::-1][:top_k]
    return [
        {"rank": r + 1, "doc_id": docs[i]["id"], "title": docs[i]["title"],
         "score": scores[i]}
        for r, i in enumerate(top_idx)
    ]


# ─────────────────────────────────────────────────────────────────────────────
# RECALL@k: ANN vs Exact
# ─────────────────────────────────────────────────────────────────────────────
def compute_ann_recall(model, flat_index, ivf_index, docs, k=10):
    texts      = [d["text"] for d in docs]
    embeddings = model.encode(texts, normalize_embeddings=True).astype(np.float32)
    total      = 0
    for q_emb in embeddings:
        q = q_emb.reshape(1, -1)
        _, exact_ids = flat_index.search(q, k)
        _, ann_ids   = ivf_index.search(q, k)
        total += len(set(exact_ids[0]) & set(ann_ids[0])) / k
    return total / len(embeddings)


# ─────────────────────────────────────────────────────────────────────────────
# VISUALISATION 1 — Embedding space (UMAP or PCA fallback)
# ─────────────────────────────────────────────────────────────────────────────
def plot_embedding_space(embeddings, docs, query_embeddings=None, query_texts=None):
    try:
        import umap
        reducer = umap.UMAP(n_components=2, random_state=42, n_neighbors=8, min_dist=0.2)
        method  = "UMAP"
    except ImportError:
        from sklearn.decomposition import PCA
        reducer = PCA(n_components=2, random_state=42)
        method  = "PCA"
        print("[WARN] umap-learn not installed — using PCA for 2D projection")

    all_vecs  = embeddings if query_embeddings is None else np.vstack([embeddings, query_embeddings])
    projected = reducer.fit_transform(all_vecs)
    doc_proj  = projected[:len(embeddings)]
    q_proj    = projected[len(embeddings):] if query_embeddings is not None else None

    fig, ax = plt.subplots(figsize=(13, 8))
    for i, doc in enumerate(docs):
        color = DOMAIN_COLORS[doc["domain"]]
        ax.scatter(doc_proj[i, 0], doc_proj[i, 1], color=color, s=90, zorder=3, alpha=0.85)
        ax.annotate(doc["id"], (doc_proj[i, 0], doc_proj[i, 1]),
                    fontsize=6, alpha=0.7, ha="center", va="bottom")

    if q_proj is not None and query_texts is not None:
        for i, (qp, _) in enumerate(zip(q_proj, query_texts)):
            ax.scatter(qp[0], qp[1], marker="*", s=280, color="black", zorder=5)
            ax.annotate(f"Q{i+1}", (qp[0], qp[1]),
                        fontsize=9, fontweight="bold", ha="center", va="bottom", color="black")

    legend_patches = [mpatches.Patch(color=DOMAIN_COLORS[d], label=d) for d in DOMAINS]
    if query_embeddings is not None:
        legend_patches.append(mpatches.Patch(color="black", label="Queries (★)"))
    ax.legend(handles=legend_patches, loc="upper right", fontsize=8, title="Domain")
    ax.set_title(
        f"c5i Business Document Embedding Space ({method} 2D projection)\n"
        "Documents from the same business domain cluster together; queries (★) land near relevant docs",
        fontsize=11,
    )
    ax.set_xlabel(f"{method} Dimension 1")
    ax.set_ylabel(f"{method} Dimension 2")
    plt.tight_layout()
    plt.savefig("dense_embedding_space.png", dpi=150)
    print("  [saved] dense_embedding_space.png")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# VISUALISATION 2 — Pairwise domain similarity heatmap
# ─────────────────────────────────────────────────────────────────────────────
def plot_domain_similarity(embeddings, docs):
    try:
        import seaborn as sns
    except ImportError:
        print("[WARN] seaborn not installed — skipping heatmap")
        return

    domain_vecs = {}
    for emb, doc in zip(embeddings, docs):
        domain_vecs.setdefault(doc["domain"], []).append(emb)
    centroids = {d: np.mean(vecs, axis=0) for d, vecs in domain_vecs.items()}
    domains   = list(centroids.keys())
    mat       = np.array([centroids[d] for d in domains])
    sim       = mat @ mat.T   # cosine sim (normalised vectors)

    _, ax = plt.subplots(figsize=(9, 7))
    sns.heatmap(sim, xticklabels=domains, yticklabels=domains,
                cmap="RdYlGn", vmin=0.0, vmax=1.0,
                annot=True, fmt=".2f", ax=ax, linewidths=0.5)
    ax.set_title(
        "Inter-Domain Semantic Similarity (Centroid Cosine)\n"
        "High values = domains share vocabulary; low values = dense retrieval needed to bridge them",
        fontsize=10,
    )
    plt.xticks(rotation=35, ha="right", fontsize=8)
    plt.yticks(rotation=0, fontsize=8)
    plt.tight_layout()
    plt.savefig("dense_domain_similarity.png", dpi=150)
    print("  [saved] dense_domain_similarity.png")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# PRINT COMPARISON TABLE
# ─────────────────────────────────────────────────────────────────────────────
def print_comparison(queries, model, flat_index, docs):
    sep = "─" * 86
    for q in queries:
        dense_hits = dense_search(q["text"], model, flat_index, docs, top_k=5)
        bm25_hits  = bm25_search(docs, q["text"], top_k=5)

        print(f"\n{sep}")
        print(f"QUERY [{q['id']}]: {q['text']}")
        print(f"NOTE : {q['note']}")
        print(f"{'DENSE (Bi-Encoder)':^42}  {'BM25 (Sparse)':^40}")
        print(f"{'─'*42}  {'─'*40}")
        for i in range(min(3, max(len(dense_hits), len(bm25_hits)))):
            dh    = dense_hits[i] if i < len(dense_hits) else {}
            bh    = bm25_hits[i]  if i < len(bm25_hits)  else {}
            d_str = (f"#{dh['rank']} [{dh['doc_id']}] {dh['title'][:24]:<24} {dh['score']:.3f}"
                     if dh else " " * 42)
            b_str = (f"#{bh['rank']} [{bh['doc_id']}] {bh['title'][:24]:<24} {bh['score']:.3f}"
                     if bh else " " * 42)
            same  = "  " if (dh.get("doc_id") == bh.get("doc_id")) else "!!"
            print(f"  {d_str}  {same}  {b_str}")
    print()


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
def main():
    print("=" * 86)
    print("DEMO 3 — Dense Bi-Encoder + ANN  |  c5i Business Document Retrieval")
    print(f"Corpus : {len(DOCUMENTS)} documents across CPG, Retail, Marketing, Pharma, CX, MLOps")
    print(f"Queries: {len(QUERIES)} colloquial queries designed to expose BM25 vocabulary gaps")
    print("=" * 86)

    model, embeddings = encode_corpus(DOCUMENTS)
    print(f"\nEmbedding shape: {embeddings.shape}  ({embeddings.shape[0]} docs × {embeddings.shape[1]} dims)")

    flat_index, ivf_index = build_faiss_indices(embeddings)

    print("\n── Dense Bi-Encoder vs BM25 Comparison  (!! = different top-3) ──")
    print_comparison(QUERIES, model, flat_index, DOCUMENTS)

    print("[Computing ANN Recall@10 (IVF vs Exact) ...]")
    recall = compute_ann_recall(model, flat_index, ivf_index, DOCUMENTS, k=10)
    print(f"\nANN Recall@10 : {recall:.3f}  ({recall*100:.1f}% of exact top-10 results returned by IVF)")

    print("\n── Building visualisations ──")
    query_texts      = [q["text"] for q in QUERIES]
    query_embeddings = model.encode(query_texts, normalize_embeddings=True).astype(np.float32)
    plot_embedding_space(embeddings, DOCUMENTS, query_embeddings, query_texts)
    plot_domain_similarity(embeddings, DOCUMENTS)

    print("\nKEY TAKEAWAYS (c5i context)")
    print("─" * 86)
    print("1. 'Social media ads not delivering value' retrieves paid social efficiency docs — zero word overlap.")
    print("2. 'Customers are leaving' retrieves churn prediction docs — colloquial → technical bridging.")
    print("3. 'Product keeps breaking' retrieves quality complaint docs — consumer language → analytics language.")
    print("4. 'AI model predictions worse' retrieves drift detection docs — lay → MLOps jargon bridging.")
    print("5. 'Eco friendly packaging' retrieves sustainable packaging docs — synonym bridging.")
    print()
    print("── RECOMMENDED PRODUCTION ARCHITECTURE FOR c5i CLIENT DEPLOYMENTS ──")
    print("  Stage 1 : BM25 (exact identifiers, SKUs, drug names) +")
    print("            Dense ANN (semantic, paraphrase, lay language) → fused candidate set (~100 docs)")
    print("  Stage 2 : Cross-encoder reranks the candidate set → precise top-10 for LLM context")
    print("  See 04_rerankers.py for the cross-encoder (Stage 2) implementation.")


if __name__ == "__main__":
    main()
