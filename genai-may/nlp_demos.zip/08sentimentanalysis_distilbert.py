# =============================================================================
# DistilBERT Architecture Overview
# =============================================================================
#
# DistilBERT is a distilled (compressed) version of BERT developed by Hugging
# Face. It retains ~97% of BERT's language understanding while being 40%
# smaller and 60% faster, making it practical for real-world inference.
#
# --- Transformer Encoder (no decoder) ---
# DistilBERT uses only the encoder stack of the Transformer architecture
# (as introduced in "Attention Is All You Need", Vaswani et al. 2017).
# The decoder is absent because the task is classification, not generation.
#
# --- Size & Layers ---
#   • Parameters  : ~66 million  (BERT-base has ~110 million)
#   • Model file size on disk : ~268 MB (float32) / ~134 MB (float16 quantized)
#     Compare: BERT-base ≈ 440 MB, GPT-2 medium ≈ 1.5 GB, LLaMA-7B ≈ 13 GB
#   • Encoder layers (Transformer blocks) : 6  (BERT-base has 12)
#   • Hidden size (d_model)               : 768
#   • Feed-forward intermediate size      : 3072
#   • Attention heads                     : 12
#
# --- Embeddings ---
# The input to the first encoder layer is the sum of three embeddings:
#   1. Token Embedding    – maps each WordPiece token ID → 768-dim vector
#   2. Position Embedding – encodes the absolute position (0–511) of each token
#   3. (No segment/type embedding in DistilBERT – removed during distillation)
# Max sequence length supported: 512 tokens.
#
# --- Multi-Head Self-Attention (per encoder layer) ---
#
# [Simple explanation]
# Imagine you're reading the sentence "The stock surged despite weak earnings."
# To understand "surged", you naturally glance at other words — "stock" tells
# you the subject, "despite" hints at contrast, "weak earnings" gives the
# surprising context. You do this from multiple angles at once:
#   - One part of your brain tracks WHO (stock)
#   - Another tracks the CONTRAST signal (despite)
#   - Another tracks the CAUSE (weak earnings)
# Multi-head attention does exactly this: it runs 12 independent "readers"
# (heads) on the same sentence simultaneously. Each head learns to focus on
# a different relationship pattern. Their findings are then merged into one
# rich understanding of each word. That is why it is called "multi-head" —
# many readers, each with a different lens, all working in parallel.
#
# What is a "relationship pattern" mathematically?
# Each head has its own learned weight matrices Wq, Wk, Wv (unique per head).
# These project the same 768-dim input vector into a different 64-dim subspace.
# The attention score between token i and token j in a given head is:
#   score(i,j) = dot( Wq · token_i,  Wk · token_j ) / sqrt(64)
# After softmax this becomes a probability: "how much should token i attend
# to token j in this subspace?" Because every head has different Wq and Wk,
# each head carves out a different geometric subspace and therefore notices
# different inter-token signals. Empirical probing studies on BERT/DistilBERT
# show that different heads specialise in:
#   - Syntactic subject-verb agreement  (e.g. "stock" ↔ "surged")
#   - Coreference links                 (e.g. "BDL" ↔ "it" later in the text)
#   - Negation scope                    (e.g. "not" modifies the next adjective)
#   - Local proximity                   (neighbouring tokens attending to each other)
# None of these patterns are hand-coded — the model discovers them from
# gradient descent during pre-training on billions of text examples.
#
# [Technical detail]
# Each of the 6 encoder blocks contains a Multi-Head Self-Attention sub-layer:
#   • 12 attention heads, each with head_dim = 768 / 12 = 64
#   • Each head computes scaled dot-product attention:
#       Attention(Q, K, V) = softmax(QK^T / sqrt(64)) · V
#     where Q (query), K (key), V (value) are linear projections of the input.
#   • The 12 head outputs are concatenated and projected back to 768 dims.
#   • Self-attention lets every token "look at" every other token in the
#     sequence simultaneously, capturing long-range context without recurrence.
#
# --- Feed-Forward Sub-layer ---
# After attention, each encoder block applies a position-wise FFN:
#   FFN(x) = GELU(x · W1 + b1) · W2 + b2
#   (768 → 3072 → 768), with residual connections and LayerNorm around both
#   the attention and FFN sub-layers.
#
# --- Why DistilBERT is suitable for Sentiment Analysis ---
#   1. Bidirectional context: The encoder reads the full sentence left-to-right
#      AND right-to-left simultaneously, so sentiment-bearing words like
#      "staggering", "bullish", or "scepticism" are understood in full context.
#   2. Pre-trained on large corpora: DistilBERT inherits BERT's rich language
#      representations from masked-language-model pre-training on Wikipedia +
#      BookCorpus (~3.3 B words), giving strong out-of-the-box semantics.
#   3. Fine-tuned on SST-2: The checkpoint used below is further trained on the
#      Stanford Sentiment Treebank (SST-2), a binary sentiment benchmark, so it
#      already understands positive/negative polarity in natural language.
#   4. Speed vs. accuracy trade-off: For a batch of short financial headlines,
#      DistilBERT's reduced depth (6 vs. 12 layers) provides near-BERT quality
#      with half the inference time — ideal for quick NLP demos and pipelines.
#   5. [CLS] token for classification: The hidden state of the special [CLS]
#      token at position 0 aggregates the full-sentence representation and is
#      passed to a linear classifier head → POSITIVE / NEGATIVE label + score.
# =============================================================================

from transformers import pipeline

# Load DistilBERT fine-tuned on SST-2 (binary sentiment: POSITIVE / NEGATIVE).
# The model card: distilbert/distilbert-base-uncased-finetuned-sst-2-english
# revision pin ensures reproducible results across library updates.
sentiment_pipeline = pipeline("sentiment-analysis", 
                model="distilbert/distilbert-base-uncased-finetuned-sst-2-english", 
                revision="714eb0f")

lines = [
    "Bharat Dynamics Limited (BDL) — the moment of truth has struck! Today BDL surged ~2% after clinching a staggering ₹ 2,461.62 crore order from the Indian Army.",
    "Investors are riding a wave of renewed confidence — as BDL’s order book balloons, the stock feels like a rocket primed for lift-off.",
    "This deal doesn’t just push quarterly numbers — it signals strategic strength and long-term defence pedigree.",
    "Market sentiment has flipped bullish overnight; scepticism fades as the order underlines government trust and order-flow visibility.",
    "If momentum holds, BDL could rewrite expectations — and reward early believers handsomely."
]

for i, line in enumerate(lines, start=1):
    result = sentiment_pipeline(line)[0]
    print(f"Line {i}: {line}  {result['label']} (score={result['score']:.3f})")
