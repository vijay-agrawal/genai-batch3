import os
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI

load_dotenv(Path(__file__).parent.parent / ".env")

# Demonstration of using AzureChatOpenAI
try:

    azure_chat_model = AzureChatOpenAI(
        # Use 'azure_endpoint' for the base URL
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME") ,    
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
    )
    
    prompt = "What is the capital of France?"

    chat_response = azure_chat_model.invoke(
        [
            {"role": "system", "content": "You are a helpful assistant for general knowledge."},
            {"role": "user", "content": prompt}
        ]
    )

    print("Prompt:", prompt)
    print("AzureChatOpenAI Response:")
    print(chat_response.content.strip())

except Exception as e:
    print("Error using AzureChatOpenAI:", e)
