import os
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent.parent / ".env")

print(f"Using Azure OpenAI endpoint: {os.getenv('AZURE_OPENAI_OPENAI_ENDPOINT')}")

client = OpenAI(
    base_url=os.getenv("AZURE_OPENAI_OPENAI_ENDPOINT", ""),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)


try:
    prompt = 'who is the best bollywood star?'

    response = client.chat.completions.create(
        model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME") ,
        messages=[
            {"role": "system", "content":
                """ You are a helpful AI assistant who answers questions about cricket and sports in general.
            Do not answer questions about other topics."""
             },
            {"role": "user", "content": prompt}
        ])
    answer = response.choices[0].message.content.strip()
    print("Prompt:")
    print(prompt)
    print("Response from LLM:")
    print(answer)
except Exception as e:
    print(e)


except Exception as e:
    print("Error using AzureChatOpenAI:", e)
