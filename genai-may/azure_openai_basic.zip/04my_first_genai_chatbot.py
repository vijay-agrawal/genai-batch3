# Import libraries
import os
from dotenv import load_dotenv
import streamlit as st
from openai import AzureOpenAI

load_dotenv()

st.subheader("AI Chatbot using Azure OpenAI")

# Chat input
user_question = st.chat_input("Ask me anything...")

if user_question:
    # Display user message
    with st.chat_message("user"):
        st.write(user_question)

    # Set up Azure OpenAI client
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION")
    )

    try:
        # Get response from Azure OpenAI
        api_response = client.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_MODEL_NAME"),
            messages=[
                {"role": "system", "content": "You are a helpful AI assistant. Answer questions truthfully and conversationally."},
                {"role": "user", "content": user_question}
            ]
        )
        response = api_response.choices[0].message.content.strip()
    except Exception as e:
        response = f"Sorry, I encountered an error: {str(e)}"

    # Display assistant response
    with st.chat_message("assistant"):
        st.write(response)


# =============================================================================
# EXERCISES FOR PARTICIPANTS — Try these prompts to discover key LLM concepts
# =============================================================================

# --- Exercise 1: LLMs are STATELESS (no memory between turns) ---
# Step 1: Ask  →  "What is the capital of France?"
# Step 2: Ask  →  "What should I see there?"
# Notice: The second question gets a confused or generic answer because the LLM
# has no memory of "there" referring to Paris. Each call is completely isolated.
# To fix this, you must send the full conversation history on every API call —
# which is exactly what you will build in the next exercise!

# --- Exercise 2: Follow-up questions break without context ---
# Step 1: Ask  →  "Give me a recipe for chocolate cake."
# Step 2: Ask  →  "Can you make it vegan?"
# Notice: The LLM doesn't know which recipe to modify — it starts completely fresh.

# --- Exercise 3: Knowledge cutoff — LLMs don't know recent events ---
# Ask  →  "Who won the IPL 2025 title?"
#   OR →  "What was the highest-grossing Bollywood film of 2025?"
#   OR →  "What is the latest iPhone model released?"
# Notice: The LLM either says it doesn't know, hedges heavily, or — watch out —
# confidently gives a wrong answer. This is because LLMs are trained on data up
# to a fixed cutoff date and have no access to live information.

# --- Exercise 4: No proprietary or internal data ---
# Ask  →  "Who are the top clients of Citius Tech?"
#   OR →  "What is Citius Tech's revenue for last year?"
#   OR →  "What projects is the Mumbai team currently working on?"
# Notice: The LLM has no knowledge of internal company data. It will either say
# it doesn't know or make something up. This is why RAG (Retrieval-Augmented
# Generation) exists — to ground the LLM with your private data at query time.

# --- Exercise 5: Hallucination — LLMs can confidently make things up ---
# Ask  →  "Can you recommend some research papers on AI in healthcare by Dr. Ravi Sharma?"
#   OR →  "What does Citius Tech's 2024 Annual Report say about AI strategy?"
# Notice: The LLM may invent plausible-sounding paper titles, authors, or quotes.
# It doesn't "know" it's wrong — it generates the most statistically likely text.
# Always verify LLM output against authoritative sources for high-stakes use cases.

