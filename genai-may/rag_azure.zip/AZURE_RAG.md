# Azure RAG: Complete Guide to All Options

This guide covers every supported way to implement Retrieval-Augmented Generation (RAG) on Azure, grounded in the demos in this folder. The **data/** directory contains the actual documents used throughout — resume PDFs, a financial statement, and regulatory/policy documents. All examples use these files and their metadata.

---

## Data in This Project

### `data/` folder contents

| File | Type | Key metadata |
|---|---|---|
| `kunal.pdf` | Resume | candidate_name: Kunal Sharma |
| `pankaj_cv.pdf` | Resume | candidate_name: Pankaj Gupta |
| `pooja.pdf` | Resume | candidate_name: Pooja Mehta |
| `rahul.pdf` | Resume | candidate_name: Rahul Verma |
| `hdfc_financial_statement_2024.pdf` | Financial statement | company: HDFC, year: 2024 |
| `electricity_bill.pdf` | Utility bill | doc_type: utility |
| `rbi_risk_basel_extracts.md` | Regulatory | doc_type: regulation, category: risk |
| `Bank Market Risk Policy.md` | Policy | doc_type: policy, category: market_risk |
| `VAR Backtesting policy.md` | Policy | doc_type: policy, category: var |
| `regulations.docx` | Regulatory | doc_type: regulation |
| `regulations2.docx` | Regulatory | doc_type: regulation |

### Metadata registry (from `rag_metadatafilter_demo.py`)

The `CANDIDATE_REGISTRY` maps each resume filename to display metadata:

```python
CANDIDATE_REGISTRY = {
    "kunal":     {"name": "Kunal Sharma",  "linkedin": "https://www.linkedin.com/in/kunal-sharma"},
    "pankaj_cv": {"name": "Pankaj Gupta",  "linkedin": "https://www.linkedin.com/in/pankaj-gupta"},
    "pooja":     {"name": "Pooja Mehta",   "linkedin": "https://www.linkedin.com/in/pooja-mehta"},
    "rahul":     {"name": "Rahul Verma",   "linkedin": "https://www.linkedin.com/in/rahul-verma"},
}
```

For non-resume documents a `doc_type` field drives filtering:

```python
DOC_TYPE_REGISTRY = {
    "hdfc_financial_statement_2024": {"doc_type": "financial", "company": "HDFC", "year": 2024},
    "rbi_risk_basel_extracts":       {"doc_type": "regulation", "category": "risk"},
    "Bank Market Risk Policy":       {"doc_type": "policy",     "category": "market_risk"},
    "VAR Backtesting policy":        {"doc_type": "policy",     "category": "var"},
    "regulations":                   {"doc_type": "regulation"},
    "regulations2":                  {"doc_type": "regulation"},
    "electricity_bill":              {"doc_type": "utility"},
}
```

---

## Azure AI Offerings Overview

| Service | What it is | Primary RAG role |
|---|---|---|
| **Azure AI Search** | Managed search service with vector, keyword, and hybrid search | Index + retrieval engine |
| **Azure OpenAI Service** | Hosted GPT/embedding models | Embeddings + generation |
| **Azure AI Foundry** | Unified portal for building AI apps and agents | Orchestration, evaluation, deployment |
| **Foundry Knowledge Bases** | Managed RAG data store inside Foundry (formerly "Grounding with Data") | Serverless RAG store |
| **Azure AI Foundry Agents** | Agent framework with built-in tool use | End-to-end conversational RAG |
| **Azure Blob Storage** | Object storage | Document source for ingestion pipelines |

---

## RAG Options at a Glance

| # | Option | Best for | Managed? |
|---|---|---|---|
| 1 | Azure OpenAI "Add Your Data" (OYD) | Quick no-code RAG | Fully managed |
| 2 | Azure AI Search + Azure OpenAI (code-driven) | Full control, metadata filtering | Semi-managed |
| 3 | Azure AI Foundry Knowledge Base | Serverless RAG, agent grounding | Fully managed |
| 4 | Azure AI Foundry Agents + Knowledge Base | Conversational agents with RAG | Fully managed |
| 5 | Azure AI Search via Foundry Connections | Enterprise-scale, custom pipelines | Semi-managed |
| 6 | Self-managed: Azure OpenAI + ChromaDB (current demos) | Local dev / custom vectorstore | Self-managed |

---

## Option 1 — Azure OpenAI "Add Your Data" (On Your Data)

The fastest path. Upload the PDFs and docs from `data/` directly in Azure AI Studio and Azure wires up an AI Search index and RAG pipeline automatically — no code required.

**Architecture:** `data/*.pdf` → Blob Storage → AI Search Index → Azure OpenAI Chat Completions (with `data_sources`)

### Step-by-step UI setup

#### Step 1 — Upload data to Blob Storage

1. Go to **portal.azure.com** → create or open a **Storage Account**.
2. Inside the Storage Account, create a **Blob Container** (e.g., `hr-docs`).
3. Upload all files from the `data/` folder:
   - Resume PDFs: `kunal.pdf`, `pankaj_cv.pdf`, `pooja.pdf`, `rahul.pdf`
   - Financial: `hdfc_financial_statement_2024.pdf`
   - Policy/regulatory: `Bank Market Risk Policy.md`, `VAR Backtesting policy.md`, `rbi_risk_basel_extracts.md`, `regulations.docx`, `regulations2.docx`
4. Click **Upload** and confirm all 10+ files are listed in the container.

#### Step 2 — Open Azure OpenAI Studio

1. Navigate to **oai.azure.com** → **Chat** playground.
2. In the **Setup** panel (right side), click the **Add your data** tab.
3. Click **Add a data source**.

#### Step 3 — Connect data source

1. **Select data source**: `Azure Blob Storage`.
2. Select your subscription, the Storage Account, and the `hr-docs` container.
3. Toggle **Add vector search to this search resource** → ON.
4. Select or create an **Azure AI Search** resource.
5. **Index name**: `hr-docs-index`.
6. Click **Next**.

#### Step 4 — Configure chunking

1. **Chunk size**: `1000` tokens (good for multi-page PDFs like the HDFC financial statement and policy docs).
2. **Chunk overlap**: `200` tokens (preserves context across chunks, as used in `streamlit_app_rag_pdf_qanda.py`).
3. **Use semantic search**: ON.
4. Click **Next**.

#### Step 5 — Field mapping

1. **Content field**: the extracted text field (auto-detected for PDFs).
2. **Title field**: `source_file` (the filename — e.g., `kunal.pdf`).
3. Check **Include all fields as metadata** to retain `page_number` and `source_file` per chunk.
4. Click **Next** → **Save and close**.

#### Step 6 — Test retrieval

1. In the Chat playground, try:
   - `What are Kunal's technical skills?`
   - `What does the HDFC financial statement say about net profit in 2024?`
   - `Summarise the VAR backtesting policy.`
2. Expand the **citations** panel to verify the source file and page number are shown.

#### Step 7 — Deploy as API

1. Click **Deploy to** → **A new web app** or **View code** to get a Python snippet with `data_sources` in the `chat.completions` call.

---

## Option 2 — Azure AI Search + Azure OpenAI (Code-Driven, Full Control)

This is the production-grade upgrade for `rag_metadatafilter_demo.py` and `indexer.py`. Replaces local ChromaDB with Azure AI Search, giving hybrid search, OData metadata filtering, and semantic ranking.

**Architecture:** `data/*.pdf` → AI Search Index (vector + metadata fields) → OData `$filter` query → Azure OpenAI chat completion

### Step-by-step UI setup

#### Step 1 — Create Azure AI Search resource

1. **portal.azure.com** → **Create a resource** → search `Azure AI Search` → **Create**.
2. Fill in:
   - **Resource group**: `rg-ragdemo`
   - **Service name**: `hr-docs-search`
   - **Region**: East US (same region as your Azure OpenAI resource)
   - **Pricing tier**: `Basic` for this demo; `Standard` for production workloads
3. Click **Review + create** → **Create**. Wait ~2 minutes.

#### Step 2 — Create the Index schema

1. Open your AI Search resource → **Indexes** → **+ Add index**.
2. **Index name**: `hr-docs-index`.
3. Add the following fields (click **+ Add field** for each):

   | Field name | Type | Retrievable | Filterable | Searchable | Sortable |
   |---|---|---|---|---|---|
   | `id` | Edm.String | ✓ | — | — | — |
   | `content` | Edm.String | ✓ | — | ✓ | — |
   | `filename` | Edm.String | ✓ | ✓ | — | ✓ |
   | `candidate_name` | Edm.String | ✓ | ✓ | ✓ | ✓ |
   | `linkedin_url` | Edm.String | ✓ | — | — | — |
   | `doc_type` | Edm.String | ✓ | ✓ | — | ✓ |
   | `company` | Edm.String | ✓ | ✓ | — | — |
   | `year` | Edm.Int32 | ✓ | ✓ | — | ✓ |
   | `category` | Edm.String | ✓ | ✓ | — | — |
   | `page_number` | Edm.Int32 | ✓ | ✓ | — | ✓ |
   | `content_vector` | Collection(Edm.Single) | — | — | — | — |

4. For `content_vector`:
   - Click the field → enable **Vector search**.
   - **Dimensions**: `1536` (for `text-embedding-ada-002`) or `1536` (for `text-embedding-3-small`, used in `rag_metadatafilter_demo.py`).
   - **Algorithm**: HNSW (`m=4`, `efConstruction=400`).
5. Click **Save**.

#### Step 3 — Configure Vector Search profile and Vectorizer

1. In the index editor → **Vector Search** tab.
2. **Vector profiles** → **+ Add** → name `hr-docs-vector-profile` → select HNSW.
3. **Vectorizers** → **+ Add**:
   - **Name**: `azure-openai-vectorizer`
   - **Kind**: `azureOpenAI`
   - **Resource URI**: your Azure OpenAI endpoint
   - **Deployment ID**: `text-embedding-3-small` (matching `AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME` in `.env`)
   - **Model name**: `text-embedding-3-small`
4. Assign the vectorizer to the `content_vector` field.
5. Click **Save**.

#### Step 4 — Upload data via Import wizard

1. Back on the index page, click **Import data**.
2. **Data source**: `Azure Blob Storage` → select the `hr-docs` container.
3. **Enrichment**: enable **Extract text from images (OCR)** if needed for scanned PDFs.
4. **Customize target index**: the wizard auto-detects fields. Map:
   - `metadata_storage_name` → `filename`
   - `content` → `content`
5. **Indexer name**: `hr-docs-indexer`. Schedule: `Once`.
6. Click **Submit**.
7. After the indexer completes, open **Search explorer** → run `*` → confirm all documents appear.

#### Step 5 — Add metadata via a custom indexer (for candidate names)

The blob indexer does not know that `kunal.pdf` maps to "Kunal Sharma". Add this enrichment via the **Custom Web API skill** or post-index update. The simplest approach is to run a one-time Python script after indexing:

```python
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential

CANDIDATE_REGISTRY = {
    "kunal.pdf":     {"candidate_name": "Kunal Sharma",  "doc_type": "resume", "linkedin_url": "https://www.linkedin.com/in/kunal-sharma"},
    "pankaj_cv.pdf": {"candidate_name": "Pankaj Gupta",  "doc_type": "resume", "linkedin_url": "https://www.linkedin.com/in/pankaj-gupta"},
    "pooja.pdf":     {"candidate_name": "Pooja Mehta",   "doc_type": "resume", "linkedin_url": "https://www.linkedin.com/in/pooja-mehta"},
    "rahul.pdf":     {"candidate_name": "Rahul Verma",   "doc_type": "resume", "linkedin_url": "https://www.linkedin.com/in/rahul-verma"},
    "hdfc_financial_statement_2024.pdf": {"doc_type": "financial", "company": "HDFC", "year": 2024},
}

client = SearchClient(
    endpoint=os.getenv("AZURE_SEARCH_ENDPOINT"),
    index_name="hr-docs-index",
    credential=AzureKeyCredential(os.getenv("AZURE_SEARCH_API_KEY"))
)

# Fetch all docs, update metadata fields based on filename
results = client.search("*", select=["id", "filename"])
updates = []
for doc in results:
    fname = doc.get("filename", "")
    meta = CANDIDATE_REGISTRY.get(fname, {"doc_type": "other"})
    updates.append({"id": doc["id"], **meta})

client.merge_documents(documents=updates)
```

#### Step 6 — Test metadata-filtered vector search in Search Explorer

1. **Search explorer** → **JSON view**.
2. Query for Kunal's skills with a candidate filter:
   ```json
   {
     "search": "technical skills programming languages",
     "vectorQueries": [{
       "kind": "text",
       "text": "technical skills programming languages",
       "fields": "content_vector",
       "k": 5
     }],
     "filter": "candidate_name eq 'Kunal Sharma'",
     "select": "candidate_name,filename,page_number,content",
     "top": 5
   }
   ```
3. Query for financial documents only:
   ```json
   {
     "search": "net profit revenue 2024",
     "vectorQueries": [{"kind": "text", "text": "net profit revenue 2024", "fields": "content_vector", "k": 5}],
     "filter": "doc_type eq 'financial' and year eq 2024",
     "select": "filename,company,year,content",
     "top": 5
   }
   ```
4. Query for policy documents:
   ```json
   {
     "search": "backtesting methodology confidence interval",
     "filter": "doc_type eq 'policy' and category eq 'var'",
     "select": "filename,category,content",
     "top": 5
   }
   ```

#### Step 7 — Enable Semantic Ranking

1. AI Search resource → **Semantic ranker** → enable free tier.
2. In the index → **Semantic configurations** → **+ Add**:
   - **Name**: `hr-docs-semantic-config`
   - **Title field**: `filename`
   - **Content fields**: `content`
   - **Keyword fields**: `candidate_name`, `doc_type`, `category`
3. Add to queries: `"queryType": "semantic"` and `"semanticConfiguration": "hr-docs-semantic-config"`.

#### Step 8 — Replace ChromaDB in `rag_metadatafilter_demo.py`

```python
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from azure.core.credentials import AzureKeyCredential

search_client = SearchClient(
    endpoint=os.getenv("AZURE_SEARCH_ENDPOINT"),
    index_name="hr-docs-index",
    credential=AzureKeyCredential(os.getenv("AZURE_SEARCH_API_KEY"))
)

# Equivalent to: vectorstore.as_retriever(search_kwargs={"filter": {"candidate_name": {"$eq": "Kunal Sharma"}}})
results = search_client.search(
    search_text=question,
    vector_queries=[VectorizedQuery(vector=embedding, fields="content_vector", k_nearest_neighbors=5)],
    filter="candidate_name eq 'Kunal Sharma'",
    select=["candidate_name", "linkedin_url", "filename", "page_number", "content"]
)
```

---

## Option 3 — Azure AI Foundry Knowledge Base

Azure AI Foundry's managed **Knowledge Base** handles chunking, embedding, indexing, and retrieval end-to-end. Ideal for this project's mixed document set (resumes + financial + policy).

**Architecture:** Foundry Project → Knowledge Base (backed by AI Search) → Grounding API → Azure OpenAI Agent/Chat

### Step-by-step UI setup

#### Step 1 — Create an Azure AI Foundry Project

1. Go to **ai.azure.com** → sign in.
2. Click **+ New project**.
3. Fill in:
   - **Project name**: `hr-docs-rag`
   - **Hub**: create a new hub (provisions Azure OpenAI + AI Search in the same resource group)
   - **Region**: East US
4. Click **Create project**. Wait ~3 minutes.

#### Step 2 — Navigate to Knowledge Bases

1. Left sidebar → **Knowledge bases** (under **Build**).
2. Click **+ New knowledge base**.

#### Step 3 — Configure the Knowledge Base

1. **Name**: `hr-docs-kb`.
2. **Description**: `Resumes for Kunal Sharma, Pankaj Gupta, Pooja Mehta, Rahul Verma; HDFC financial statement 2024; RBI risk/Basel extracts; bank market risk and VAR backtesting policies`.
3. **Embedding model**: `text-embedding-3-small` (matching the deployment in `rag_metadatafilter_demo.py`).
4. Click **Next**.

#### Step 4 — Add data source

1. **Data source type**: `Upload files`.
2. Upload all files from `data/`:
   - Resumes: `kunal.pdf`, `pankaj_cv.pdf`, `pooja.pdf`, `rahul.pdf`
   - Financial: `hdfc_financial_statement_2024.pdf`
   - Policy: `Bank Market Risk Policy.md`, `VAR Backtesting policy.md`
   - Regulatory: `rbi_risk_basel_extracts.md`, `regulations.docx`, `regulations2.docx`
3. Alternatively, point to the Blob container if already uploaded there.
4. Click **Next**.

#### Step 5 — Configure chunking

1. **Chunking method**: `Fixed-size`.
2. **Chunk size**: `500` tokens (matching `chunk_size=500` in `rag_metadatafilter_demo.py`).
3. **Overlap**: `50` tokens (matching `chunk_overlap=50`).
4. **Parse mode**: `auto` — Foundry detects PDF vs. DOCX vs. Markdown automatically.
5. Click **Next**.

#### Step 6 — Add metadata fields

1. Under **Metadata fields**, click **+ Add field** for each:

   | Field name | Type | Filterable | Retrievable |
   |---|---|---|---|
   | `candidate_name` | String | ✓ | ✓ |
   | `linkedin_url` | String | — | ✓ |
   | `doc_type` | String | ✓ | ✓ |
   | `company` | String | ✓ | ✓ |
   | `year` | Integer | ✓ | ✓ |
   | `category` | String | ✓ | ✓ |
   | `filename` | String | ✓ | ✓ |

2. For resume PDFs, set:
   - `kunal.pdf` → `candidate_name=Kunal Sharma`, `doc_type=resume`
   - `pankaj_cv.pdf` → `candidate_name=Pankaj Gupta`, `doc_type=resume`
   - `pooja.pdf` → `candidate_name=Pooja Mehta`, `doc_type=resume`
   - `rahul.pdf` → `candidate_name=Rahul Verma`, `doc_type=resume`
3. For `hdfc_financial_statement_2024.pdf`: `doc_type=financial`, `company=HDFC`, `year=2024`.
4. For policy docs: `doc_type=policy`, with `category=market_risk` or `category=var`.
5. Click **Next** → **Create**.

#### Step 7 — Monitor ingestion

1. The Knowledge Base page shows: **Pending → Processing → Ready**.
2. **Documents** tab → verify all 10+ files appear with status **Indexed**.
3. Click **Test** and enter:
   - `What are Pankaj's skills?` — should return chunks from `pankaj_cv.pdf`
   - `Net profit in HDFC 2024` — should return chunks from `hdfc_financial_statement_2024.pdf`
   - `VAR backtesting confidence level` — should return chunks from `VAR Backtesting policy.md`

#### Step 8 — Test retrieval with filters

1. **Test** panel → **Advanced options**.
2. Filter: `doc_type eq 'resume' and candidate_name eq 'Rahul Verma'`.
3. Top K: `5`.
4. Query: `work experience and projects` — should return only Rahul's resume chunks.

---

## Option 4 — Azure AI Foundry Agents + Knowledge Base

The most capable option. A Foundry Agent automatically decides when to query the `hr-docs-kb`, handles multi-turn HR assistant conversations, and can combine RAG with code execution to analyse financial data.

**Architecture:** User message → Foundry Agent → (auto) Knowledge Base tool call → Grounded HR/finance response

### Step-by-step UI setup

#### Step 1 — Prerequisite

Ensure `hr-docs-kb` from Option 3 is in **Ready** state.

#### Step 2 — Open the Agents playground

1. **ai.azure.com** → your project → **Agents** (under **Build**).
2. Click **+ New agent**.

#### Step 3 — Configure the Agent

1. **Agent name**: `HR & Finance RAG Agent`.
2. **Model deployment**: `gpt-4o` (or `gpt-4o-mini` to match `AZURE_OPENAI_DEPLOYMENT_NAME` in `.env`).
3. **Instructions**:
   ```
   You are an expert HR assistant and financial analyst.

   For candidate/resume questions, use the knowledge base to retrieve relevant
   resume sections and filter by candidate_name when a specific person is mentioned.
   Always cite the candidate's name and provide their LinkedIn URL when available.

   For financial questions about HDFC, filter by doc_type=financial.

   For risk, policy, or regulatory questions, filter by doc_type=policy or
   doc_type=regulation and use the category field when relevant (market_risk, var, risk).

   Always cite the source filename and page number in your response.
   ```
4. **Temperature**: `0`.

#### Step 4 — Add Knowledge Base as a tool

1. **Tools** → **+ Add tool** → **Knowledge base**.
2. Select `hr-docs-kb`.
3. Configure:
   - **Max retrieval results**: `5`
   - **Semantic search**: ON
   - **Enable metadata filtering**: ON
4. Click **Save**.

#### Step 5 — Add Code Interpreter (for financial analysis)

1. **+ Add tool** → **Code Interpreter**.
2. This allows the agent to write Python to compute ratios or summarise tables from retrieved HDFC financial statement chunks — e.g., calculate year-over-year growth from retrieved numbers.

#### Step 6 — Test the agent

Try these multi-turn queries:

```
User: Compare the technical skills of Kunal and Pankaj.
Agent: [retrieves from both kunal.pdf and pankaj_cv.pdf, compares]

User: Which of them has more experience?
Agent: [uses conversation context, no new query needed]

User: What does the HDFC annual report say about capital adequacy?
Agent: [switches to doc_type=financial filter, retrieves from hdfc_financial_statement_2024.pdf]

User: How does that compare to the RBI Basel requirements?
Agent: [retrieves from rbi_risk_basel_extracts.md, synthesises both sources]
```

#### Step 7 — Deploy as API

1. **Deploy** → **Deploy as API**. Note the Agent ID.
2. Call from code:
   ```python
   from azure.ai.projects import AIProjectClient
   from azure.identity import DefaultAzureCredential

   client = AIProjectClient.from_connection_string(
       conn_str=os.getenv("AZURE_AI_PROJECT_CONNECTION_STRING"),
       credential=DefaultAzureCredential()
   )
   agent  = client.agents.get_agent(agent_id="your-agent-id")
   thread = client.agents.create_thread()
   client.agents.create_message(
       thread_id=thread.id, role="user",
       content="What are Pooja Mehta's key strengths based on her resume?"
   )
   run = client.agents.create_and_process_run(thread_id=thread.id, assistant_id=agent.id)
   msgs = client.agents.list_messages(thread_id=thread.id)
   print(msgs.data[0].content[0].text.value)
   ```

---

## Option 5 — Azure AI Search via Foundry Connections (Enterprise Pipeline)

For teams who already have the AI Search index from Option 2 and want to add Prompt Flow orchestration, evaluation against a golden dataset, and managed endpoint deployment.

**Architecture:** `hr-docs-index` (AI Search) → Foundry Connection → Prompt Flow (embed → search → generate) → managed endpoint

### Step-by-step UI setup

#### Step 1 — Add AI Search as a Foundry Connection

1. **ai.azure.com** → your project → **Settings** → **Connections**.
2. **+ New connection** → **Azure AI Search**.
3. Fill in:
   - **Name**: `hr-docs-search-connection`
   - **Endpoint**: your AI Search endpoint (e.g., `https://hr-docs-search.search.windows.net`)
   - **API key**: AI Search admin key
4. **Create connection**.

#### Step 2 — Create a Prompt Flow from the RAG template

1. Left sidebar → **Prompt flow** → **+ Create**.
2. Select **RAG template** → **Clone**.
3. The template creates nodes: `embed_query` → `vector_search` → `generate_prompt` → `chat`.

#### Step 3 — Configure the `vector_search` node

1. Click `vector_search`.
2. **Connection**: `hr-docs-search-connection`.
3. **Index name**: `hr-docs-index`.
4. **Vector field**: `content_vector`.
5. **Text field**: `content`.
6. **Top K**: `5`.
7. **Filter expression**: wire to an input variable:
   ```
   ${inputs.odata_filter}
   ```

#### Step 4 — Configure the `embed_query` node

1. **Connection**: your Azure OpenAI connection.
2. **Deployment**: `text-embedding-3-small`.
3. **Input**: `${inputs.query}`.

#### Step 5 — Configure the `generate_prompt` node

Update the Jinja2 template to include metadata:
```jinja2
You are an expert HR assistant and financial analyst.

Retrieved context:
{% for doc in vector_search.output %}
--- Source: {{ doc.filename }} | Candidate: {{ doc.candidate_name or "N/A" }} | Page: {{ doc.page_number }} ---
{{ doc.content }}

{% endfor %}

Question: {{ inputs.query }}

Answer concisely. Cite the source filename for each fact.
```

#### Step 6 — Add metadata filtering as flow inputs

1. **Inputs** → **+ Add input**:
   - `query` (string) — e.g., `"What are Rahul's Python skills?"`
   - `odata_filter` (string, optional) — e.g., `"candidate_name eq 'Rahul Verma'"`
2. For the `hr-docs` dataset, these are the typical filter strings:

   | Use case | `odata_filter` value |
   |---|---|
   | Specific candidate | `candidate_name eq 'Pooja Mehta'` |
   | All resumes | `doc_type eq 'resume'` |
   | HDFC financials | `doc_type eq 'financial' and company eq 'HDFC'` |
   | Risk/policy docs | `doc_type eq 'policy' or doc_type eq 'regulation'` |
   | VAR policy only | `doc_type eq 'policy' and category eq 'var'` |

#### Step 7 — Evaluate against a golden dataset

1. Create a `golden_qa.jsonl` evaluation file:
   ```jsonl
   {"query": "What programming languages does Kunal know?", "odata_filter": "candidate_name eq 'Kunal Sharma'", "expected": "Python, Java"}
   {"query": "What is HDFC's net profit for 2024?", "odata_filter": "doc_type eq 'financial'", "expected": "..."}
   {"query": "What confidence level is used in VAR backtesting?", "odata_filter": "category eq 'var'", "expected": "99%"}
   ```
2. **Evaluate** tab → upload this file → run evaluation.
3. Review metrics: groundedness, relevance, retrieval precision per document type.

#### Step 8 — Deploy

1. **Deploy** → fill in endpoint name → **Deploy** as a managed online endpoint.
2. The endpoint accepts `{"query": "...", "odata_filter": "..."}` and returns grounded answers.

---

## Option 6 — Self-Managed: Azure OpenAI + ChromaDB (Current Demos)

This is exactly what the demos in this folder implement:

| Script | What it does |
|---|---|
| `indexer.py` | Loads all PDFs from `data/`, chunks them, embeds with Azure OpenAI, stores in ChromaDB |
| `retriever.py` | Loads ChromaDB, runs similarity search, calls Azure OpenAI LLM via LCEL chain |
| `retriever_withsteps.py` | Same as `retriever.py` but prints each step — useful for teaching |
| `rag_metadatafilter_demo.py` | Full Streamlit app: indexes resumes with `CANDIDATE_REGISTRY` metadata, filters by `candidate_name` |
| `streamlit_app_rag_pdf_qanda.py` | Upload-your-own PDF Streamlit app with page-level metadata |

**Architecture:** `data/*.pdf` → PyPDFLoader → RecursiveCharacterTextSplitter → AzureOpenAIEmbeddings → ChromaDB → similarity_search with metadata filter → AzureChatOpenAI

### Key parameters (from the demo code)

```python
# indexer.py / rag_metadatafilter_demo.py
chunk_size    = 500    # tokens per chunk
chunk_overlap = 50     # overlap between chunks

# streamlit_app_rag_pdf_qanda.py
chunk_size    = 1000
chunk_overlap = 200
```

### ChromaDB metadata filter syntax (current demos)

```python
# Filter by candidate — used in rag_metadatafilter_demo.py
search_kwargs["filter"] = {"candidate_name": {"$eq": "Kunal Sharma"}}

# Filter by doc type (extend for financial/policy docs)
search_kwargs["filter"] = {"doc_type": {"$eq": "financial"}}

# Combined filter
search_kwargs["filter"] = {
    "$and": [
        {"doc_type": {"$eq": "policy"}},
        {"category": {"$eq": "var"}}
    ]
}
```

### Limitation

ChromaDB is local and non-persistent across deployments. The `rag_metadatafilter_demo.py` wipes and re-creates `chroma_resumes_metadata/` on startup. Migrate to Options 2–5 for any production or shared deployment.

---

## Comparison: When to Use Which Option

| Scenario | Recommended Option |
|---|---|
| Quick demo — upload `data/` PDFs, get answers immediately | Option 1 (OYD) |
| Need metadata filtering by candidate, doc_type, year | Option 2 (AI Search code-driven) |
| Serverless, managed RAG without manual index config | Option 3 (Foundry Knowledge Base) |
| Multi-turn HR + finance assistant crossing document types | Option 4 (Foundry Agents + KB) |
| Existing AI Search index + evaluation + batch testing | Option 5 (Foundry Connections + Prompt Flow) |
| Local dev / teaching — this repo's current setup | Option 6 (ChromaDB + Azure OpenAI) |

---

## Metadata Filtering: ChromaDB vs Azure AI Search

The current demos use ChromaDB filter syntax. When migrating to AI Search, translate as follows:

| ChromaDB (current) | Azure AI Search OData |
|---|---|
| `{"candidate_name": {"$eq": "Kunal Sharma"}}` | `candidate_name eq 'Kunal Sharma'` |
| `{"doc_type": {"$eq": "resume"}}` | `doc_type eq 'resume'` |
| `{"year": {"$eq": 2024}}` | `year eq 2024` |
| `{"$and": [{"doc_type": {"$eq": "policy"}}, {"category": {"$eq": "var"}}]}` | `doc_type eq 'policy' and category eq 'var'` |
| `{"$or": [{"doc_type": {"$eq": "policy"}}, {"doc_type": {"$eq": "regulation"}}]}` | `doc_type eq 'policy' or doc_type eq 'regulation'` |

---

## Chunking Strategy for This Dataset

| Document type | File(s) | Recommended strategy | Chunk size | Overlap |
|---|---|---|---|---|
| Resume PDFs (short, structured) | `kunal.pdf`, `pankaj_cv.pdf`, `pooja.pdf`, `rahul.pdf` | RecursiveCharacterTextSplitter | 500 tokens | 50 tokens |
| Multi-page financial report | `hdfc_financial_statement_2024.pdf` | Fixed-size | 1000 tokens | 200 tokens |
| Policy markdown (structured sections) | `Bank Market Risk Policy.md`, `VAR Backtesting policy.md` | Sentence/section-based | 512 tokens | 64 tokens |
| Regulatory extracts | `rbi_risk_basel_extracts.md` | Fixed-size | 512 tokens | 64 tokens |
| Word documents | `regulations.docx`, `regulations2.docx` | RecursiveCharacterTextSplitter | 1000 tokens | 200 tokens |

---

## Key Environment Variables Reference

### Azure OpenAI (from `rag_metadatafilter_demo.py` / `retriever.py`)
```
AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/v1
AZURE_OPENAI_API_KEY=<key>
AZURE_OPENAI_API_VERSION=2024-02-01
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o-mini
AZURE_OPENAI_MODEL_NAME=gpt-4o-mini
AZURE_OPENAI_EMBEDDING_ENDPOINT=https://<resource>.openai.azure.com/openai/deployments/text-embedding-3-small/embeddings
AZURE_OPENAI_EMBEDDING_API_KEY=<key>
AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME=text-embedding-3-small
```

### Azure AI Search (for Options 2 and 5)
```
AZURE_SEARCH_ENDPOINT=https://hr-docs-search.search.windows.net
AZURE_SEARCH_API_KEY=<admin-or-query-key>
AZURE_SEARCH_INDEX_NAME=hr-docs-index
```

### Azure AI Foundry (for Options 3, 4, and 5)
```
AZURE_AI_PROJECT_CONNECTION_STRING=<region>.api.azureml.ms;<subscription-id>;<resource-group>;<project-name>
```

---

## Ingestion Flow Summary (all options)

```
data/ folder
├── kunal.pdf, pankaj_cv.pdf, pooja.pdf, rahul.pdf   (resumes)
├── hdfc_financial_statement_2024.pdf                 (financial)
├── Bank Market Risk Policy.md                        (policy)
├── VAR Backtesting policy.md                         (policy)
├── rbi_risk_basel_extracts.md                        (regulation)
├── regulations.docx, regulations2.docx               (regulation)
└── electricity_bill.pdf                              (utility)
         │
         ▼
  Load: PyPDFLoader / Docx2txtLoader / TextLoader
         │
         ▼
  Chunk: RecursiveCharacterTextSplitter
  (chunk_size=500, overlap=50 for resumes;
   chunk_size=1000, overlap=200 for financial docs)
         │
         ▼
  Attach metadata per chunk:
  candidate_name, linkedin_url, doc_type, company, year, category, filename, page_number
         │
         ▼
  Embed: AzureOpenAIEmbeddings (text-embedding-3-small)
         │
         ▼
  Store:
  ├── Option 6: ChromaDB (local, chroma_resumes_metadata/)
  └── Options 1–5: Azure AI Search index (hr-docs-index)
         │
         ▼
  Retrieve: vector similarity + metadata filter
  ├── ChromaDB: {"candidate_name": {"$eq": "Kunal Sharma"}}
  └── AI Search: filter="candidate_name eq 'Kunal Sharma'"
         │
         ▼
  Context assembly → Azure OpenAI chat completion
  (gpt-4o-mini / gpt-4o)
         │
         ▼
  Grounded answer with source citations
  (filename + page_number + candidate_name)
```
