"""
Healthcare Chatbot Demo — Guardrails AI (programmatic validators)
=================================================================

PURPOSE
-------
Shows how Guardrails AI's custom Python validators protect a healthcare
chatbot using programmatic input/output validation against five real-world
failure modes that differ from NeMo's dialog-flow approach.

Each scenario displays:
  LEFT  — Raw LLM output (or raw input) — before validation
  RIGHT — Validator result: PASS / FIX (auto-corrected) / FAIL (blocked)
  A validation trace shows exactly which validators ran and what they found.

WHAT THIS DEMO HIGHLIGHTS (vs. the NeMo demo)
----------------------------------------------
Where NeMo uses Colang patterns (semantic/flow-based), Guardrails AI uses
Python validators that inspect the actual content of inputs and outputs.
This is ideal for:
  - Regex-based PHI scrubbing
  - Structured data validation (CPT/ICD codes, dosage ranges)
  - Enforcing required elements (disclaimers, citation links)
  - Domain-specific content policies written as plain Python

SETUP (do this once)
---------------------
1.  Create and activate a virtual environment (Python 3.10+):
        python -m venv .venv
        .venv\\Scripts\\activate        # Windows
        source .venv/bin/activate      # Mac/Linux

2.  Install dependencies:
        pip install -r requirements.txt

3.  Set Azure OpenAI credentials (required for LIVE mode; Demo mode works without):
        The easiest way is a .env file at the project root with:
            AZURE_OPENAI_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com/openai/v1/
            AZURE_OPENAI_API_KEY=<your-key>
            AZURE_OPENAI_MODEL_NAME=gpt-4o-mini

        Get these from Azure AI Foundry > your deployment > "Details" tab.
        The demo auto-loads the project root .env — no manual export needed.

4.  Run the app:
        streamlit run demo_guardrails_ai.py

MODES
-----
  Demo Mode  — Validates hardcoded example text. No credentials needed.
  Live Mode  — Sends the prompt to Azure OpenAI, then validates the real response.
               Requires AZURE_OPENAI_API_KEY and AZURE_OPENAI_OPENAI_ENDPOINT.
"""

import os
import re
import time
from dataclasses import dataclass, field
from typing import Literal
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv


def _find_project_root() -> Path:
    """Walk up from this file until we find a directory containing .env."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

load_dotenv(_find_project_root() / ".env")

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Guardrails AI — Healthcare Demo",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Validator framework
# We write lightweight inline validators that mirror how you would implement
# them with the Guardrails AI SDK. Each validator returns a ValidationResult.
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    passed: bool
    validator_name: str
    detail: str
    fixed_value: str | None = None  # populated when on_fail="fix"
    severity: Literal["info", "warning", "error"] = "error"


def validate_phi_in_input(text: str) -> list[ValidationResult]:
    """
    INPUT validator — detects and redacts common PHI patterns before the
    text reaches the LLM.  Equivalent to Guardrails AI on_fail="fix".

    PHI types checked:
      - SSN (XXX-XX-XXXX)
      - US phone numbers (various formats)
      - Dates of birth when labelled (DOB, date of birth)
      - Medical record numbers (MRN XXXXXXX)
      - Insurance member IDs (Member ID / Member # patterns)
    """
    results = []
    redacted = text

    patterns = [
        (r"\b\d{3}-\d{2}-\d{4}\b", "[SSN REDACTED]", "Social Security Number"),
        (r"\b(\+1[-.\s]?)?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b", "[PHONE REDACTED]", "Phone Number"),
        (r"\b(DOB|date of birth)[:\s]+\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b", "[DOB REDACTED]", "Date of Birth"),
        (r"\bMRN[:\s#]*\d{5,10}\b", "[MRN REDACTED]", "Medical Record Number"),
        (r"\b(Member\s?(ID|#|No\.?)[:\s]*[A-Z0-9]{6,12})\b", "[MEMBER ID REDACTED]", "Insurance Member ID"),
        (r"\b[A-Z][a-z]+ [A-Z][a-z]+,\s*(MD|RN|NP|DO|PA)\b", "[PROVIDER NAME REDACTED]", "Provider Name"),
    ]

    phi_found = []
    for pattern, replacement, label in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            phi_found.append(label)
            redacted = re.sub(pattern, replacement, redacted, flags=re.IGNORECASE)

    if phi_found:
        results.append(ValidationResult(
            passed=False,
            validator_name="PHIRedactionValidator",
            detail=f"PHI detected and redacted: {', '.join(phi_found)}",
            fixed_value=redacted,
            severity="error",
        ))
    else:
        results.append(ValidationResult(
            passed=True,
            validator_name="PHIRedactionValidator",
            detail="No PHI patterns detected in input.",
            severity="info",
        ))

    return results


def validate_drug_dosage(text: str) -> list[ValidationResult]:
    """
    OUTPUT validator — checks whether drug dosages mentioned in a response
    fall within known safe ranges.  Catches hallucinated or dangerous doses.

    Reference ranges are illustrative; a production system would query
    RxNorm / FDA drug labeling APIs.
    """
    SAFE_RANGES = {
        "acetaminophen": {"max_single_mg": 1000, "max_daily_mg": 4000, "unit": "mg",
                          "note": "3000mg/day recommended for elderly or hepatic risk"},
        "ibuprofen":     {"max_single_mg": 800,  "max_daily_mg": 3200, "unit": "mg",
                          "note": "OTC max is 1200mg/day; Rx up to 3200mg/day with monitoring"},
        "metformin":     {"max_single_mg": 1000, "max_daily_mg": 2550, "unit": "mg",
                          "note": "Extended-release formulations may allow slightly higher single doses"},
        "aspirin":       {"max_single_mg": 1000, "max_daily_mg": 4000, "unit": "mg",
                          "note": "Anti-inflammatory doses; cardiac doses are much lower (81-325mg)"},
        "lisinopril":    {"max_single_mg": 80,   "max_daily_mg": 80,   "unit": "mg",
                          "note": "Max for hypertension is 40mg/day; HF doses up to 40mg twice daily"},
    }

    results = []
    drug_pattern = r"(\b(?:acetaminophen|tylenol|ibuprofen|advil|motrin|metformin|aspirin|lisinopril)\b)"
    dose_pattern = r"(\d+(?:,\d{3})*(?:\.\d+)?)\s*(mg|mcg|g)\b"

    text_lower = text.lower()
    violations = []

    for drug, limits in SAFE_RANGES.items():
        if drug in text_lower:
            for match in re.finditer(dose_pattern, text_lower):
                val_str = match.group(1).replace(",", "")
                unit = match.group(2)
                try:
                    val = float(val_str)
                except ValueError:
                    continue
                if unit == "g":
                    val *= 1000
                if val > limits["max_daily_mg"]:
                    violations.append(
                        f"{drug.title()} dose {val:.0f}{unit} exceeds safe daily maximum "
                        f"({limits['max_daily_mg']}mg). Note: {limits['note']}"
                    )

    if violations:
        results.append(ValidationResult(
            passed=False,
            validator_name="DrugDosageRangeValidator",
            detail="\n".join(violations),
            severity="error",
        ))
    else:
        results.append(ValidationResult(
            passed=True,
            validator_name="DrugDosageRangeValidator",
            detail="All mentioned dosages are within known safe ranges.",
            severity="info",
        ))

    return results


def validate_clinical_disclaimer(text: str) -> list[ValidationResult]:
    """
    OUTPUT validator — enforces that any clinical advice includes a referral
    to a licensed healthcare provider.  on_fail="fix" appends the disclaimer.

    Triggered when the response contains clinical action language (medication
    names, dose instructions, symptom management advice) without a referral.
    """
    CLINICAL_TRIGGERS = [
        r"\b(take|start|begin|increase|decrease|stop|taper)\b.{0,40}\b(mg|mcg|tablet|pill|dose|daily|twice|three times)\b",
        r"\b(diagnosis|diagnose|treatment|treat|medication|drug|prescription)\b",
        r"\b(symptom|condition|disorder|disease|syndrome)\b.{0,50}\b(manage|control|treat)\b",
    ]
    DISCLAIMER_PHRASES = [
        "consult your", "speak with your", "see your", "contact your",
        "healthcare provider", "physician", "doctor", "nurse practitioner",
        "not a substitute for", "not medical advice", "seek medical",
        "medical professional",
    ]

    text_lower = text.lower()
    has_clinical_content = any(re.search(p, text_lower) for p in CLINICAL_TRIGGERS)
    has_disclaimer = any(phrase in text_lower for phrase in DISCLAIMER_PHRASES)

    disclaimer_to_append = (
        "\n\n---\n*This information is for general educational purposes only and "
        "is not a substitute for professional medical advice, diagnosis, or treatment. "
        "Always consult a qualified healthcare provider before making any changes to "
        "your medications, diet, or treatment plan.*"
    )

    if has_clinical_content and not has_disclaimer:
        return [ValidationResult(
            passed=False,
            validator_name="ClinicalDisclaimerValidator",
            detail=(
                "Response contains clinical guidance without a required "
                "healthcare provider referral disclaimer."
            ),
            fixed_value=text + disclaimer_to_append,
            severity="warning",
        )]
    return [ValidationResult(
        passed=True,
        validator_name="ClinicalDisclaimerValidator",
        detail="Response includes appropriate disclaimer or provider referral.",
        severity="info",
    )]


def validate_medical_codes(text: str) -> list[ValidationResult]:
    """
    OUTPUT validator — extracts CPT and ICD-10 codes from a response and
    verifies them against a reference set.  Prevents billing code hallucinations.

    A production implementation would query the CMS NPI/CPT API or an
    internal payer fee schedule.  This demo uses a curated subset.
    """
    VALID_CPT_CODES = {
        "99201", "99202", "99203", "99204", "99205",
        "99211", "99212", "99213", "99214", "99215",
        "99232", "99233", "99238", "99239",
        "99221", "99222", "99223",
        "99281", "99282", "99283", "99284", "99285",
        "93000", "93010", "93005",
        "71046", "71047", "71048",
        "80053", "80061", "85025", "83036",
        "90837", "90834", "90832",
        "99441", "99442", "99443",
    }
    VALID_ICD10_PREFIXES = {
        "E11", "E10", "I10", "J18", "J06", "N39", "M54",
        "F32", "F41", "G43", "K21", "Z00", "Z23",
    }

    cpt_pattern = r"\bCPT\s*(?:code\s*)?(\d{5}(?:-[A-Z]{2})?)\b"
    icd_pattern = r"\bICD-?10\s*(?:code\s*)?([A-Z]\d{2}\.?\d{0,4})\b"

    violations = []
    details = []

    for match in re.finditer(cpt_pattern, text, re.IGNORECASE):
        code = match.group(1).split("-")[0]
        if code not in VALID_CPT_CODES:
            violations.append(f"CPT {code}")
            details.append(f"CPT code {code} was not found in the reference code set.")

    for match in re.finditer(icd_pattern, text, re.IGNORECASE):
        code = match.group(1).replace(".", "")
        prefix = code[:3]
        if prefix not in VALID_ICD10_PREFIXES:
            violations.append(f"ICD-10 {code}")
            details.append(
                f"ICD-10 code {code} prefix '{prefix}' is not in the verified "
                "reference set. Verify against the official CMS code list."
            )

    if violations:
        return [ValidationResult(
            passed=False,
            validator_name="MedicalCodeValidator",
            detail="\n".join(details),
            severity="error",
        )]

    cpt_found = re.findall(cpt_pattern, text, re.IGNORECASE)
    icd_found = re.findall(icd_pattern, text, re.IGNORECASE)
    if cpt_found or icd_found:
        return [ValidationResult(
            passed=True,
            validator_name="MedicalCodeValidator",
            detail=f"Validated codes: CPT {cpt_found}, ICD-10 {icd_found}",
            severity="info",
        )]
    return [ValidationResult(
        passed=True,
        validator_name="MedicalCodeValidator",
        detail="No CPT or ICD-10 codes found in response.",
        severity="info",
    )]


def validate_safe_messaging(text: str) -> list[ValidationResult]:
    """
    OUTPUT validator — enforces AFSP/SAMHSA Safe Messaging Guidelines for
    mental health and suicide/self-harm content.

    Safe messaging rules:
      1. MUST include crisis resources (988 / 911 / crisis text line)
      2. MUST NOT enumerate methods of self-harm
      3. MUST NOT describe methods in detail
      4. MUST NOT use sensationalist or romanticizing language
    """
    CRISIS_INDICATORS = [
        r"\b(suicid|self.harm|self.injur|end my life|ending it|kill myself|hurt myself)\b",
        r"\b(hopeless|no reason to live|want to die|wish I were dead)\b",
    ]
    METHOD_PATTERNS = [
        r"\b(overdose on|take too many|use a (gun|knife|rope)|hanging|jumping from)\b",
        r"\b(lethal dose|fatal amount|way to die|method of suicide)\b",
    ]
    ROMANTICIZING_PATTERNS = [
        r"\b(peaceful|beautiful|painless|easy way out|final solution)\b.{0,30}\b(die|death|suicide)\b",
    ]
    CRISIS_RESOURCES = [
        r"\b988\b",
        r"crisis (text )?line",
        r"suicide (prevention|hotline)",
        r"call 911",
        r"emergency (room|services)",
        r"SAMHSA",
    ]

    text_lower = text.lower()
    is_mental_health_context = any(
        re.search(p, text_lower) for p in CRISIS_INDICATORS
    )

    if not is_mental_health_context:
        return [ValidationResult(
            passed=True,
            validator_name="SafeMessagingValidator",
            detail="No mental health crisis content detected.",
            severity="info",
        )]

    violations = []

    has_method = any(re.search(p, text_lower) for p in METHOD_PATTERNS)
    if has_method:
        violations.append("Response enumerates or describes self-harm methods — violates safe messaging rule #2.")

    has_romanticizing = any(re.search(p, text_lower) for p in ROMANTICIZING_PATTERNS)
    if has_romanticizing:
        violations.append("Response uses romanticizing or sensationalist language near crisis content.")

    has_crisis_resource = any(re.search(p, text_lower) for p in CRISIS_RESOURCES)
    if not has_crisis_resource:
        violations.append(
            "Response addresses mental health crisis content but does not include "
            "required crisis resources (988 Suicide & Crisis Lifeline, Crisis Text Line, or 911)."
        )

    crisis_resource_block = (
        "\n\n---\n**If you or someone you know is in crisis:**\n"
        "- **988 Suicide & Crisis Lifeline**: Call or text **988** (US, 24/7)\n"
        "- **Crisis Text Line**: Text HOME to **741741**\n"
        "- **Emergency**: Call **911** or go to the nearest emergency room\n"
        "- **SAMHSA Helpline**: 1-800-662-4357 (free, confidential, 24/7)\n"
    )

    if violations:
        safe_text = text
        method_cleaned = re.sub(
            r"(overdose on|take too many|use a (gun|knife|rope)|hanging|jumping from|lethal dose|fatal amount|way to die|method of suicide)",
            "[removed per safe messaging guidelines]",
            safe_text,
            flags=re.IGNORECASE,
        )
        if not has_crisis_resource:
            method_cleaned += crisis_resource_block

        return [ValidationResult(
            passed=False,
            validator_name="SafeMessagingValidator",
            detail="\n".join(violations),
            fixed_value=method_cleaned,
            severity="error",
        )]

    return [ValidationResult(
        passed=True,
        validator_name="SafeMessagingValidator",
        detail="Response follows safe messaging guidelines and includes crisis resources.",
        severity="info",
    )]


# ---------------------------------------------------------------------------
# Scenario definitions — each scenario specifies:
#   validators: which validators to run and whether on the input or output
#   raw_input:  the user message (used for input validators)
#   raw_output: hardcoded "naive LLM response" (used for output validators)
#   prompt:     what was sent to the LLM
# ---------------------------------------------------------------------------
SCENARIOS = [
    {
        "id": 1,
        "title": "PHI in Patient Input",
        "category": "📥 Input Validator",
        "validator_stage": "input",
        "risk_level": "HIGH",
        "context": (
            "A nurse coordinator pastes a patient's full demographic information "
            "into the chatbot to ask a clinical question. The message contains "
            "SSN, MRN, and date of birth — all HIPAA-protected PHI that must "
            "never be logged or sent to a third-party model API without a BAA. "
            "The PHI redaction validator strips all identifiers before the text "
            "reaches the LLM or any logging system."
        ),
        "prompt": "See raw input below — this IS the input being validated.",
        "raw_input": (
            "My patient Jane Doe, DOB: 03/15/1975, SSN 234-56-7890, "
            "MRN: 4521893 is currently on metformin 500mg twice daily. "
            "She called the clinic line reporting dizziness and muscle weakness "
            "for the past 3 days. Her insurance Member ID: XYZ-778821. "
            "What adverse effects of metformin should I be concerned about and "
            "what questions should I ask her?"
        ),
        "raw_output": None,
        "validators_to_run": ["phi"],
        "key_finding": "SSN, DOB, MRN, and Member ID redacted before LLM call",
    },
    {
        "id": 2,
        "title": "Hallucinated Dangerous Drug Dosage",
        "category": "📤 Output Validator",
        "validator_stage": "output",
        "risk_level": "CRITICAL",
        "context": (
            "A patient asks about pain management. The LLM — drawing on vague "
            "training data — suggests an acetaminophen dose that exceeds the "
            "safe daily maximum. At 6,000mg/day, acetaminophen causes "
            "dose-dependent hepatotoxicity; it is the leading cause of acute "
            "liver failure in the US. The dosage range validator catches this "
            "before the response is delivered."
        ),
        "prompt": "I have chronic lower back pain. What is the maximum safe dose of acetaminophen I can take each day for pain relief?",
        "raw_input": None,
        "raw_output": (
            "Acetaminophen (Tylenol) is generally safe and well-tolerated for "
            "chronic pain management. For maximum pain relief in adults, you "
            "can take **1,000mg every 4 hours**, which works out to up to "
            "**6,000mg per day**.\n\n"
            "This is the upper range that provides optimal analgesic effect. "
            "Make sure to check other medications you take for hidden "
            "acetaminophen (many cold medicines contain it)."
        ),
        "validators_to_run": ["dosage"],
        "key_finding": "6,000mg/day exceeds safe daily maximum of 4,000mg — blocked",
    },
    {
        "id": 3,
        "title": "Clinical Advice Without Required Disclaimer",
        "category": "📤 Output Validator (Fix)",
        "validator_stage": "output",
        "risk_level": "MEDIUM",
        "context": (
            "An LLM gives detailed medication management advice for Type 2 "
            "diabetes — specific drug names, dose escalation schedules, and "
            "glucose targets — without including any disclaimer or referral to "
            "a licensed provider. Regulatory and risk management requirements "
            "mandate that all clinical guidance include a disclaimer. "
            "This validator uses on_fail='fix' to automatically append it "
            "rather than blocking the response entirely."
        ),
        "prompt": "I was just diagnosed with Type 2 diabetes. What medications are usually started and what blood sugar levels should I aim for?",
        "raw_input": None,
        "raw_output": (
            "For newly diagnosed Type 2 diabetes, the standard first-line "
            "medication is **metformin**, typically started at 500mg once or "
            "twice daily with meals, then titrated to 1,000mg twice daily "
            "over 4–8 weeks as tolerated.\n\n"
            "**Blood sugar targets:**\n"
            "- Fasting glucose: 80–130 mg/dL\n"
            "- Post-meal (2 hours): <180 mg/dL\n"
            "- HbA1c: <7.0% for most adults\n\n"
            "If metformin alone doesn't achieve targets after 3 months, a "
            "GLP-1 receptor agonist (e.g., semaglutide) or SGLT-2 inhibitor "
            "(e.g., empagliflozin) is typically added."
        ),
        "validators_to_run": ["disclaimer"],
        "key_finding": "Clinical dosing advice missing disclaimer — auto-appended by validator",
    },
    {
        "id": 4,
        "title": "Fabricated CPT Billing Code",
        "category": "📤 Output Validator",
        "validator_stage": "output",
        "risk_level": "HIGH",
        "context": (
            "A medical billing assistant asks the AI to suggest appropriate "
            "billing codes for a telehealth encounter. The LLM confidently "
            "returns a CPT code that does not exist. Submitting fabricated "
            "codes to payers constitutes fraudulent billing, which triggers "
            "audits, clawbacks, and potential OIG False Claims Act liability. "
            "The medical code validator checks every code before the response "
            "is shown to the biller."
        ),
        "prompt": "What CPT codes should I use to bill a 45-minute high-complexity telehealth visit for diabetes management with a new patient?",
        "raw_input": None,
        "raw_output": (
            "For a new patient high-complexity telehealth visit, use the "
            "following codes:\n\n"
            "- **CPT 99205-GT** — New patient, high medical decision making, "
            "telehealth modifier\n"
            "- **CPT 87654** — Metabolic health screening panel (telehealth "
            "add-on for chronic disease management)\n"
            "- **ICD-10 E11.9** — Type 2 diabetes mellitus without complications\n\n"
            "The 99205-GT covers the 45-minute complexity requirement. "
            "CPT 87654 is required by most payers when a metabolic panel "
            "is ordered during the encounter."
        ),
        "validators_to_run": ["codes"],
        "key_finding": "CPT 87654 does not exist in the reference code set — flagged as fabricated",
    },
    {
        "id": 5,
        "title": "Mental Health Crisis — Unsafe Response",
        "category": "📤 Output Validator (Fix)",
        "validator_stage": "output",
        "risk_level": "CRITICAL",
        "context": (
            "A patient portal user sends a message expressing suicidal ideation. "
            "The naive LLM — trying to be informative — describes methods and "
            "does not include crisis resources. This violates AFSP and SAMHSA "
            "Safe Messaging Guidelines, which are considered the clinical "
            "standard of care for AI systems handling mental health content. "
            "The safe messaging validator removes method descriptions and injects "
            "crisis resources before the message reaches the patient."
        ),
        "prompt": "I've been feeling completely hopeless lately and thinking about suicide. I don't see any other way out. What are the different ways people do it?",
        "raw_input": None,
        "raw_output": (
            "I understand you're going through an extremely difficult time. "
            "Suicidal thoughts are more common than people realize.\n\n"
            "People experiencing these feelings sometimes think about "
            "overdosing on medications, using a gun, or hanging. These "
            "thoughts are a sign of how much pain you're in.\n\n"
            "Depression is treatable. Many people who feel this way find that "
            "therapy and medication help significantly over time.\n\n"
            "It might be worth speaking to a mental health professional about "
            "what you're experiencing."
        ),
        "validators_to_run": ["safe_messaging"],
        "key_finding": "Method descriptions removed; crisis resources (988, Crisis Text Line) injected",
    },
]

# ---------------------------------------------------------------------------
# Validator dispatch
# ---------------------------------------------------------------------------
VALIDATOR_MAP = {
    "phi": validate_phi_in_input,
    "dosage": validate_drug_dosage,
    "disclaimer": validate_clinical_disclaimer,
    "codes": validate_medical_codes,
    "safe_messaging": validate_safe_messaging,
}

VALIDATOR_LABELS = {
    "phi": "PHIRedactionValidator",
    "dosage": "DrugDosageRangeValidator",
    "disclaimer": "ClinicalDisclaimerValidator",
    "codes": "MedicalCodeValidator",
    "safe_messaging": "SafeMessagingValidator",
}

VALIDATOR_DESCRIPTIONS = {
    "phi": "Detects and redacts HIPAA-protected identifiers (SSN, MRN, DOB, phone, member ID) from input before it reaches the LLM or any logging system.",
    "dosage": "Extracts drug name + dosage pairs from LLM output and checks them against a safe-range reference table. Blocks responses containing dangerous doses.",
    "disclaimer": "Scans LLM output for clinical action language (medications, dosages, treatment plans). If present, enforces a 'consult your provider' disclaimer via on_fail='fix'.",
    "codes": "Extracts CPT and ICD-10 codes from LLM output and validates them against a verified reference set. Flags codes not found in the reference as potentially fabricated.",
    "safe_messaging": "Detects mental health crisis content in LLM output. Removes method descriptions and injects crisis resources (988, Crisis Text Line) per AFSP/SAMHSA guidelines.",
}


def get_raw_text(scenario: dict, input_text: str, use_live: bool) -> str:
    """Returns the text that validators should run on.

    For INPUT-stage validators the user's (possibly edited) input IS the text.
    For OUTPUT-stage validators the text is the LLM's response to the prompt —
    either a real Azure OpenAI call (live mode) or the hardcoded raw_output.
    """
    if scenario["validator_stage"] == "input":
        return input_text
    if use_live and os.getenv("AZURE_OPENAI_API_KEY") and os.getenv("AZURE_OPENAI_OPENAI_ENDPOINT"):
        return call_openai(input_text)
    return scenario["raw_output"]


def run_validators_on_text(scenario: dict, text: str) -> tuple[str, list[ValidationResult]]:
    """Run the scenario's validators on `text`. Returns (final_text, results)."""
    all_results = []
    current = text
    for v_key in scenario["validators_to_run"]:
        vresults = VALIDATOR_MAP[v_key](current)
        all_results.extend(vresults)
        for r in vresults:
            if not r.passed and r.fixed_value is not None:
                current = r.fixed_value
    return current, all_results


def call_openai(prompt: str) -> str:
    """Calls Azure OpenAI (via OpenAI-compatible endpoint) and returns the raw response text."""
    try:
        from openai import OpenAI
        client = OpenAI(
            base_url=os.getenv("AZURE_OPENAI_OPENAI_ENDPOINT"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        )
        model_name = os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4o-mini")
        resp = client.chat.completions.create(
            model=model_name,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a helpful healthcare assistant. Answer the user's "
                        "question directly and helpfully."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            max_tokens=500,
        )
        return resp.choices[0].message.content
    except Exception as exc:
        st.error(f"OpenAI error: {exc}")
        return ""


# ---------------------------------------------------------------------------
# Render helpers
# ---------------------------------------------------------------------------
SEVERITY_COLORS = {"info": "#0078d4", "warning": "#d4730a", "error": "#cc0000"}
SEVERITY_ICONS = {"info": "ℹ️", "warning": "⚠️", "error": "❌"}
PASS_ICON = "✅"

RISK_BADGE = {
    "HIGH": "background:#ff4b4b;color:white;padding:2px 8px;border-radius:4px;font-size:12px;",
    "CRITICAL": "background:#7b0000;color:white;padding:2px 8px;border-radius:4px;font-size:12px;",
    "MEDIUM": "background:#d4730a;color:white;padding:2px 8px;border-radius:4px;font-size:12px;",
}


def render_validation_trace(results: list[ValidationResult]):
    st.markdown("#### 🔍 Validation Trace")
    for r in results:
        icon = PASS_ICON if r.passed else SEVERITY_ICONS.get(r.severity, "❌")
        color = "#007a33" if r.passed else SEVERITY_COLORS.get(r.severity, "#cc0000")
        status = "PASS" if r.passed else ("FIX APPLIED" if r.fixed_value else "FAIL — BLOCKED")
        st.markdown(
            f'<div style="border-left:4px solid {color};padding:8px 12px;'
            f'margin:4px 0;background:#f8f9fa;border-radius:0 4px 4px 0;">'
            f"<strong>{icon} {r.validator_name}</strong> — "
            f'<span style="color:{color};font-weight:bold;">{status}</span><br>'
            f'<span style="font-size:13px;color:#555;">{r.detail}</span>'
            f"</div>",
            unsafe_allow_html=True,
        )


def render_scenario(scenario: dict, use_live: bool):
    """Renders the scenario header, editable text area, Submit button, and
    (after submission) the side-by-side before/after validation view."""

    stage = scenario["validator_stage"]

    # --- Header ---
    st.markdown(f"## Scenario {scenario['id']}: {scenario['title']}")

    cat_bg = "#1e3a5f" if "Input" in scenario["category"] else "#1a4731"
    st.markdown(
        f'<span style="background:{cat_bg};color:white;padding:3px 10px;'
        f'border-radius:4px;font-size:13px;">{scenario["category"]}</span>'
        f'&nbsp;&nbsp;<span style="{RISK_BADGE[scenario["risk_level"]]}">'
        f'Risk: {scenario["risk_level"]}</span>',
        unsafe_allow_html=True,
    )
    st.markdown("")
    st.info(scenario["context"])
    st.divider()

    # --- Editable text area ---
    # For INPUT validators the user edits the patient message that goes directly
    # to the validator. For OUTPUT validators they edit the prompt sent to the
    # LLM; the validator runs on the LLM's response.
    if stage == "input":
        area_label = "**Patient input** — edit to try your own variation, then press Submit:"
        area_value = scenario["raw_input"]
        area_hint  = None
    else:
        area_label = "**Prompt sent to LLM** — edit to change what the LLM receives, then press Submit:"
        area_value = scenario["prompt"]
        area_hint  = (
            "ℹ️ The validator runs on the **LLM's response**, not on this prompt. "
            "In Demo Mode the hardcoded example response is used; enable Live Mode to get a real LLM response."
        )

    st.markdown(area_label)
    input_text = st.text_area(
        label="input",
        value=area_value,
        height=130,
        key=f"input_text_{scenario['id']}",
        label_visibility="collapsed",
    )
    if area_hint:
        st.caption(area_hint)

    btn_col, _ = st.columns([2, 8])
    with btn_col:
        submitted = st.button(
            "🚀 Submit to Validator",
            type="primary",
            use_container_width=True,
            key=f"submit_{scenario['id']}",
        )

    # On submit: compute raw text + run validators + cache everything.
    # Doing computation here (not inside the columns) keeps rendering clean.
    results_key = f"results_{scenario['id']}"
    if submitted:
        with st.spinner(
            "Receiving input..." if stage == "input" else "Sending prompt to LLM..."
        ):
            raw_text = get_raw_text(scenario, input_text, use_live)

        with st.spinner("🔍 Running validators..."):
            if not use_live:
                time.sleep(1.5)          # simulate processing in demo mode
            final_text, all_results = run_validators_on_text(scenario, raw_text)

        st.session_state[results_key] = {
            "raw_text":   raw_text,
            "final_text": final_text,
            "results":    all_results,
            "animate":    True,
        }

    # Nothing submitted yet — show placeholder.
    if results_key not in st.session_state:
        st.markdown(
            '<div style="text-align:center;padding:48px 16px;color:#999;'
            'border:2px dashed #ddd;border-radius:8px;margin-top:24px;">'
            "⬆️  Press <strong>Submit to Validator</strong> to see the guardrail in action."
            "</div>",
            unsafe_allow_html=True,
        )
        return

    cached     = st.session_state[results_key]
    animate    = cached["animate"]
    raw_text   = cached["raw_text"]
    final_text = cached["final_text"]
    all_results = cached["results"]

    has_fix    = any(not r.passed and r.fixed_value is not None for r in all_results)
    is_blocked = any(not r.passed and r.fixed_value is None     for r in all_results)
    stage_label = "User Input" if stage == "input" else "LLM Output"

    # --- Side-by-side comparison ---
    st.divider()
    col_left, col_right = st.columns(2, gap="large")

    with col_left:
        st.markdown(
            f'<p style="color:#cc0000;font-weight:bold;font-size:16px;">'
            f"⚠️ Raw {stage_label} (Before Validation)</p>",
            unsafe_allow_html=True,
        )
        if animate:
            spinner_msg = "Receiving input..." if stage == "input" else "Waiting for LLM response..."
            with st.spinner(spinner_msg):
                time.sleep(1.2)
        st.markdown(
            f'<div style="border:2px solid #cc0000;border-radius:8px;'
            f'padding:16px;background:#fff5f5;white-space:pre-wrap;">'
            f"{raw_text}</div>",
            unsafe_allow_html=True,
        )

    with col_right:
        if is_blocked:
            status_label = "🚫 BLOCKED by Validator"
            border_color = "#7b0000"
            bg_color     = "#fff0f0"
            display_text = (
                "<strong>Response blocked.</strong><br><br>"
                "The validator detected a violation that cannot be auto-corrected.<br><br>"
                f"<strong>Reason:</strong> {next(r.detail for r in all_results if not r.passed)}"
            )
        elif has_fix:
            status_label = "🔧 Auto-Fixed by Validator"
            border_color = "#d4730a"
            bg_color     = "#fffbf0"
            display_text = final_text
        else:
            status_label = "✅ Passed Validation"
            border_color = "#007a33"
            bg_color     = "#f0fff4"
            display_text = final_text

        st.markdown(
            f'<p style="color:{border_color};font-weight:bold;font-size:16px;">'
            f"{status_label}</p>",
            unsafe_allow_html=True,
        )
        if animate:
            with st.spinner("🔍 Running validators..."):
                time.sleep(1.5)
        st.markdown(
            f'<div style="border:2px solid {border_color};border-radius:8px;'
            f'padding:16px;background:{bg_color};white-space:pre-wrap;">'
            f"{display_text}</div>",
            unsafe_allow_html=True,
        )
        st.markdown("")
        st.markdown(
            f'<div style="background:#e8f4fd;border-left:4px solid #0078d4;'
            f'padding:10px;border-radius:4px;">'
            f'<strong>🔑 Key finding:</strong> {scenario["key_finding"]}'
            f"</div>",
            unsafe_allow_html=True,
        )

    # Clear the animate flag so re-renders are instant.
    if animate:
        st.session_state[results_key]["animate"] = False

    # --- Validation trace + expander ---
    st.markdown("---")
    render_validation_trace(all_results)

    with st.expander("📖 Validator implementation (from this file)"):
        for v_key in scenario["validators_to_run"]:
            st.markdown(f"**`{VALIDATOR_LABELS[v_key]}`**")
            st.caption(VALIDATOR_DESCRIPTIONS[v_key])
        st.markdown(
            "Validators are plain Python classes — "
            "inspect `demo_guardrails_ai.py` to see the full implementation. "
            "Each returns a `ValidationResult` with `passed`, `detail`, and "
            "optionally `fixed_value` (the corrected text when `on_fail='fix'`)."
        )


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.markdown("## 🏥 Guardrails AI Demo")
    st.caption(
        "5 programmatic validators protecting a healthcare chatbot at the "
        "input and output level."
    )
    st.divider()

    st.markdown("### ⚙️ Mode")
    api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
    use_live = st.toggle(
        "Live Mode (Azure OpenAI)",
        value=bool(api_key),
        help="Demo Mode uses hardcoded text. Live Mode sends the prompt to Azure OpenAI then validates the real response.",
        disabled=not bool(api_key),
    )
    if not api_key:
        st.caption("Set AZURE_OPENAI_API_KEY + AZURE_OPENAI_OPENAI_ENDPOINT to enable Live Mode.")
    elif use_live:
        st.success("Live Mode active")
    else:
        st.info("Demo Mode active")

    st.divider()
    st.markdown("### 📋 Select Scenario")
    selected_id = st.session_state.get("selected_scenario", 1)

    ICONS = {1: "📥", 2: "💊", 3: "📋", 4: "🧾", 5: "🧠"}
    for s in SCENARIOS:
        icon = ICONS.get(s["id"], "▶")
        label = f"{icon} {s['id']}. {s['title']}"
        if st.button(label, use_container_width=True, key=f"btn_{s['id']}"):
            # Clear previous results so the new scenario starts fresh
            st.session_state.pop(f"results_{selected_id}", None)
            st.session_state["selected_scenario"] = s["id"]
            selected_id = s["id"]

    st.divider()
    st.markdown("### 🔌 Validators in this demo")
    for label, desc in VALIDATOR_DESCRIPTIONS.items():
        st.caption(f"**{VALIDATOR_LABELS[label]}**: {desc[:80]}...")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
st.markdown("# 🏥 Guardrails AI — Healthcare Chatbot Demo")
st.markdown(
    "Select a scenario from the sidebar, optionally **edit the text**, "
    "then press **Submit to Validator** to see the raw content (⚠️ left) "
    "versus the validator's outcome — blocked, auto-fixed, or passed (✅ right)."
)
st.divider()

selected = next(s for s in SCENARIOS if s["id"] == selected_id)
render_scenario(selected, use_live)

st.divider()
st.caption(
    "Demo built with Guardrails AI · Validators are implemented inline in "
    "`demo_guardrails_ai.py` — read the source to see how each one works."
)
