"""
09_llm_intent.py  — c5i CPG Brand Analytics: GraphRAG Runner

What this does:
- Takes a natural-language CPG analytics question
- Detects anchors (brand_id, sku_id, campaign_id, channel_id, retailer_id)
- Routes to 1+ Cypher queries (Neo4j) to build an Evidence Pack (nested JSON)
- Calls Azure OpenAI with a *grounded* prompt:
    - The LLM MUST answer using only the Evidence Pack
    - Outputs an answer + citations [camp:CAMP_...], [sku:SKU_...], [ch:CH_...], etc.

Intents:
  BRAND_SUMMARY       — full brand snapshot: campaigns, channels, SKUs, markets
  CAMPAIGN_ATTRIBUTION — attribution for a specific campaign or channel
  NEWLY_LISTED        — SKUs gaining first-ever retail distribution
  RETAIL_DISTRIBUTION — shelf coverage: distribution gaps, top SKUs by retailer
  CONSUMER_INSIGHTS   — segment purchase patterns, retailer affinity
  REVIEW_EVIDENCE     — confirmed campaign lift vs digital shelf review sentiment

Prereqs:
  pip install neo4j pandas python-dotenv openai

Env vars needed:
  NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD
  AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_VERSION, AZURE_OPENAI_MODEL_NAME

Optional:
  DEMO_BID=BR_001
  DEMO_CHANNEL_ID=CH_002
  DEMO_SKU_ID=SKU_002
"""

from __future__ import annotations

import os
import re
import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import pandas as pd
from dotenv import load_dotenv
from neo4j import GraphDatabase
from openai import AzureOpenAI

load_dotenv()


# =====================================================
# Cypher queries (c5i CPG schema)
# =====================================================

Q_BRAND_SNAPSHOT = """
MATCH (b:Brand {brand_id:$bid})<-[:PROMOTES]-(c:Campaign)
OPTIONAL MATCH (c)-[uc:USES_CHANNEL]->(ch:Channel)
OPTIONAL MATCH (c)-[:TARGETS_MARKET]->(mk:Market)
OPTIONAL MATCH (c)-[dl:DROVE_LIFT]->(s:SKU)<-[:HAS_SKU]-(b)
WITH b, c,
     collect(DISTINCT {channel_id:ch.channel_id, name:ch.name, type:ch.type,
                       spend:uc.spend, impressions:uc.impressions}) AS channels,
     collect(DISTINCT {market_id:mk.market_id, name:mk.name, region:mk.region}) AS markets,
     collect(DISTINCT {sku_id:s.sku_id, name:s.name,
                       lift_pct:dl.sales_lift_pct, roi:dl.roi,
                       attributed_revenue:dl.attributed_revenue}) AS lifts
ORDER BY c.start_date DESC
WITH b, collect({
  campaign_id:c.campaign_id, name:c.name,
  start_date:c.start_date, end_date:c.end_date,
  budget:c.budget, objective:c.objective,
  channels:channels, markets:markets, sales_lifts:lifts
})[0..$limit] AS campaigns
RETURN {
  brand: {brand_id:b.brand_id, name:b.name, category:b.category, manufacturer:b.manufacturer},
  campaigns: campaigns
} AS brand_snapshot;
"""

Q_CAMPAIGN_ATTRIBUTION = """
MATCH (c:Campaign {campaign_id:$campaign_id})
OPTIONAL MATCH (c)-[uc:USES_CHANNEL]->(ch:Channel)
OPTIONAL MATCH (c)-[:TARGETS_MARKET]->(mk:Market)
OPTIONAL MATCH (c)-[dl:DROVE_LIFT]->(s:SKU)<-[:HAS_SKU]-(b:Brand)
OPTIONAL MATCH (c)-[:PROMOTES]->(brand:Brand)
WITH c, brand,
     collect(DISTINCT {channel_id:ch.channel_id, name:ch.name, type:ch.type,
                       spend:uc.spend, impressions:uc.impressions, grps:uc.grps}) AS channels,
     collect(DISTINCT {market_id:mk.market_id, name:mk.name, region:mk.region}) AS markets,
     collect(DISTINCT {sku_id:s.sku_id, brand:b.name,
                       lift_pct:dl.sales_lift_pct, roi:dl.roi,
                       attributed_revenue:dl.attributed_revenue}) AS lifts
RETURN {
  campaign: {campaign_id:c.campaign_id, name:c.name, start_date:c.start_date,
             end_date:c.end_date, budget:c.budget, objective:c.objective},
  brand: {brand_id:brand.brand_id, name:brand.name},
  channels: channels,
  markets: markets,
  sales_lifts: lifts
} AS campaign_attribution;
"""

Q_NEWLY_LISTED = """
MATCH (s:SKU)-[la:LISTED_AT]->(r:Retailer)
WHERE la.listed_since >= date() - duration({days:$days})
WITH s, min(la.listed_since) AS first_list_date
OPTIONAL MATCH (s)-[la2:LISTED_AT]->(r2:Retailer)
WHERE la2.listed_since < first_list_date
WITH s, first_list_date, count(la2) AS prior_count
WHERE prior_count = 0
MATCH (b:Brand)-[:HAS_SKU]->(s)
RETURN s.sku_id AS sku_id, s.name AS sku_name,
       b.brand_id AS brand_id, b.name AS brand,
       first_list_date
ORDER BY first_list_date DESC;
"""

Q_RETAILER_DISTRIBUTION = """
MATCH (r:Retailer)<-[la:LISTED_AT]-(s:SKU)<-[:HAS_SKU]-(b:Brand)
RETURN r.retailer_id AS retailer_id, r.name AS retailer_name, r.channel_type,
       b.brand_id AS brand_id, b.name AS brand_name,
       s.sku_id AS sku_id, s.name AS sku_name,
       la.distribution_pct AS distribution_pct,
       la.shelf_position AS shelf_position,
       la.avg_price AS avg_price
ORDER BY r.retailer_id, la.distribution_pct DESC;
"""

Q_CONSUMER_INSIGHTS = """
MATCH (sg:ConsumerSegment)-[pch:PURCHASES]->(s:SKU)<-[:HAS_SKU]-(b:Brand)
OPTIONAL MATCH (sg)-[:SHOPS_AT]->(r:Retailer)
WITH sg,
     collect(DISTINCT {sku_id:s.sku_id, sku_name:s.name, brand:b.name,
                       purchase_frequency:pch.purchase_frequency,
                       avg_basket_size:pch.avg_basket_size}) AS purchases,
     collect(DISTINCT {retailer_id:r.retailer_id, name:r.name}) AS retail_affinity
RETURN {
  segment_id: sg.segment_id,
  segment_name: sg.name,
  persona: sg.persona,
  age_range: sg.age_range,
  income_tier: sg.income_tier,
  purchases: purchases,
  retail_affinity: retail_affinity
} AS segment_profile;
"""

Q_REVIEW_EVIDENCE = """
MATCH (s:SKU {sku_id:$sku_id})
OPTIONAL MATCH (c:Campaign)-[dl:DROVE_LIFT]->(s)
OPTIONAL MATCH (rv:Review)-[:ABOUT_SKU]->(s)
OPTIONAL MATCH (rv)-[mn:MENTIONS]->(s)
WITH s, c, dl, rv, mn
ORDER BY coalesce(c.start_date, date('2000-01-01')) DESC
WITH s,
     collect(DISTINCT {
       campaign_id:c.campaign_id, campaign_name:c.name,
       lift_pct:dl.sales_lift_pct, roi:dl.roi,
       attributed_revenue:dl.attributed_revenue
     }) AS lift_evidence,
     collect(DISTINCT {
       review_id:rv.review_id, source:rv.source, rating:rv.rating,
       snippet:substring(rv.text, 0, 180),
       sentiment:mn.sentiment, score:mn.score, aspect:mn.aspect
     }) AS review_evidence
RETURN {
  sku_id: s.sku_id,
  sku_name: s.name,
  lift_evidence: lift_evidence,
  review_evidence: [r IN review_evidence WHERE r.review_id IS NOT NULL]
} AS sku_evidence;
"""


# =====================================================
# Utilities
# =====================================================

def _json_safe(obj: Any) -> Any:
    if hasattr(obj, "iso_format"):
        try:
            return obj.iso_format()
        except Exception:
            return str(obj)
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(x) for x in obj]
    return obj


def run_query(driver, cypher: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    params = params or {}
    with driver.session() as session:
        rows = session.run(cypher, **params).data()
    return _json_safe(rows)


def first_value(rows: List[Dict[str, Any]], key: str) -> Any:
    return rows[0].get(key) if rows else None


# =====================================================
# Anchor detection + intent routing
# =====================================================

@dataclass
class Anchors:
    brand_id:    Optional[str] = None
    sku_id:      Optional[str] = None
    campaign_id: Optional[str] = None
    channel_id:  Optional[str] = None
    retailer_id: Optional[str] = None
    segment_id:  Optional[str] = None


def detect_anchors(question: str) -> Anchors:
    q = question.strip()

    def first(pattern: str) -> Optional[str]:
        m = re.search(pattern, q, flags=re.IGNORECASE)
        return m.group(0).upper() if m else None

    return Anchors(
        brand_id=first(r"\bBR_\d+\b"),
        sku_id=first(r"\bSKU_\d+\b"),
        campaign_id=first(r"\bCAMP_\d+\b"),
        channel_id=first(r"\bCH_\d+\b"),
        retailer_id=first(r"\bRET_\d+\b"),
        segment_id=first(r"\bSEG_\d+\b"),
    )


def route(question: str, anchors: Anchors) -> str:
    q = question.lower()

    if any(k in q for k in ["evidence", "confirm", "review", "sentiment", "lift vs", "what do customers"]):
        return "REVIEW_EVIDENCE"

    if any(k in q for k in ["campaign", "attribution", "drove", "drove lift", "channel spend", "media mix",
                             "roi", "impressions", "grps", "spend on"]):
        return "CAMPAIGN_ATTRIBUTION"

    if any(k in q for k in ["newly listed", "new distribution", "new sku", "first listed",
                             "distribution gain", "first time listed", "gained distribution"]):
        return "NEWLY_LISTED"

    if any(k in q for k in ["consumer", "segment", "purchase", "loyalty", "buyer", "who buys", "shopping at"]):
        return "CONSUMER_INSIGHTS"

    if any(k in q for k in ["retailer", "distribution", "shelf", "listing", "store", "planogram",
                             "where is", "stocked at", "coverage"]):
        return "RETAIL_DISTRIBUTION"

    if any(k in q for k in ["summary", "snapshot", "overview", "everything", "brand profile",
                             "brand portfolio", "full picture"]):
        return "BRAND_SUMMARY"

    if anchors.brand_id:
        return "BRAND_SUMMARY"
    if anchors.campaign_id or anchors.channel_id:
        return "CAMPAIGN_ATTRIBUTION"
    if anchors.sku_id:
        return "REVIEW_EVIDENCE"
    if anchors.segment_id:
        return "CONSUMER_INSIGHTS"
    if anchors.retailer_id:
        return "RETAIL_DISTRIBUTION"

    return "RETAIL_DISTRIBUTION"


# =====================================================
# Evidence pack builder
# =====================================================

def build_evidence_pack(driver, question: str) -> Dict[str, Any]:
    anchors = detect_anchors(question)
    intent  = route(question, anchors)

    evidence: Dict[str, Any] = {
        "question":    question,
        "intent":      intent,
        "anchors":     {k: v for k, v in anchors.__dict__.items() if v},
        "facts":       {},
        "provenance":  {"source": "neo4j", "queries_used": []},
    }

    default_bid        = os.getenv("DEMO_BID",        "BR_001")
    default_channel_id = os.getenv("DEMO_CHANNEL_ID", "CH_002")
    default_sku_id     = os.getenv("DEMO_SKU_ID",     "SKU_002")
    default_camp_id    = "CAMP_001"

    if intent == "BRAND_SUMMARY":
        bid = anchors.brand_id or default_bid
        rows = run_query(driver, Q_BRAND_SNAPSHOT, {"bid": bid, "limit": 5})
        evidence["facts"]["brand_snapshot"] = first_value(rows, "brand_snapshot")
        evidence["provenance"]["queries_used"].append("Q_BRAND_SNAPSHOT")

    elif intent == "CAMPAIGN_ATTRIBUTION":
        camp_id = anchors.campaign_id or default_camp_id
        rows = run_query(driver, Q_CAMPAIGN_ATTRIBUTION, {"campaign_id": camp_id})
        evidence["facts"]["campaign_attribution"] = first_value(rows, "campaign_attribution")
        evidence["provenance"]["queries_used"].append("Q_CAMPAIGN_ATTRIBUTION")

        # Attach brand snapshot for context
        if evidence["facts"]["campaign_attribution"]:
            brand_info = evidence["facts"]["campaign_attribution"].get("brand", {})
            bid = brand_info.get("brand_id") or (anchors.brand_id or default_bid)
            rows2 = run_query(driver, Q_BRAND_SNAPSHOT, {"bid": bid, "limit": 3})
            evidence["facts"]["brand_snapshot_brief"] = first_value(rows2, "brand_snapshot")
            evidence["provenance"]["queries_used"].append("Q_BRAND_SNAPSHOT")

    elif intent == "NEWLY_LISTED":
        rows = run_query(driver, Q_NEWLY_LISTED, {"days": 90})
        evidence["facts"]["newly_listed_skus"] = rows
        evidence["provenance"]["queries_used"].append("Q_NEWLY_LISTED")

    elif intent == "RETAIL_DISTRIBUTION":
        rows = run_query(driver, Q_RETAILER_DISTRIBUTION)
        evidence["facts"]["retailer_distribution"] = rows
        evidence["provenance"]["queries_used"].append("Q_RETAILER_DISTRIBUTION")

    elif intent == "CONSUMER_INSIGHTS":
        rows = run_query(driver, Q_CONSUMER_INSIGHTS)
        evidence["facts"]["consumer_segments"] = [first_value([r], "segment_profile") for r in rows]
        evidence["provenance"]["queries_used"].append("Q_CONSUMER_INSIGHTS")

    elif intent == "REVIEW_EVIDENCE":
        sku_id = anchors.sku_id or default_sku_id
        rows = run_query(driver, Q_REVIEW_EVIDENCE, {"sku_id": sku_id})
        evidence["facts"]["sku_evidence"] = first_value(rows, "sku_evidence")
        evidence["provenance"]["queries_used"].append("Q_REVIEW_EVIDENCE")

        # Also attach brand snapshot for context
        if anchors.brand_id:
            rows2 = run_query(driver, Q_BRAND_SNAPSHOT, {"bid": anchors.brand_id, "limit": 3})
            evidence["facts"]["brand_snapshot_brief"] = first_value(rows2, "brand_snapshot")
            evidence["provenance"]["queries_used"].append("Q_BRAND_SNAPSHOT")

    else:
        rows = run_query(driver, Q_RETAILER_DISTRIBUTION)
        evidence["facts"]["retailer_distribution"] = rows
        evidence["provenance"]["queries_used"].append("Q_RETAILER_DISTRIBUTION")

    return evidence


# =====================================================
# Azure OpenAI grounded answer generator
# =====================================================

def call_azure_openai_grounded(question: str, evidence_pack: Dict[str, Any]) -> str:
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    )
    model_name = os.getenv("AZURE_OPENAI_MODEL_NAME")

    system = """
You are a CPG brand analytics advisor at c5i.ai, serving Fortune 500 clients.
You MUST answer using ONLY the provided EVIDENCE PACK JSON.
If the evidence pack does not contain enough information, say: "Insufficient evidence in the evidence pack."
You MUST include citations wherever you state facts, using these formats:
  - Campaign citation:         [camp:CAMP_...]
  - SKU citation:              [sku:SKU_...]
  - Channel citation:          [ch:CH_...]
  - Review citation:           [rev:REV_...]
  - Retailer citation:         [ret:RET_...]
  - Consumer segment citation: [seg:SEG_...]

Do NOT invent IDs or data.
Keep the answer concise and structured.
Use business language appropriate for CPG brand managers, media planners, and insights teams.
Structure your response with clear headers for: Summary, Key Findings, Evidence, Recommendations.
"""

    user = f"""
QUESTION:
{question}

EVIDENCE PACK (JSON):
{json.dumps(evidence_pack, indent=2)}
"""

    response = client.chat.completions.create(
        model=model_name,
        temperature=0,
        max_tokens=1000,
        messages=[
            {"role": "system", "content": system.strip()},
            {"role": "user",   "content": user.strip()},
        ],
    )
    return response.choices[0].message.content.strip()


# =====================================================
# Optional: DataFrames for analytics views
# =====================================================

def maybe_make_dataframes(evidence_pack: Dict[str, Any]) -> Dict[str, pd.DataFrame]:
    dfs: Dict[str, pd.DataFrame] = {}
    intent = evidence_pack.get("intent")
    facts  = evidence_pack.get("facts", {})

    if intent == "NEWLY_LISTED":
        rows = facts.get("newly_listed_skus", [])
        dfs["newly_listed_skus"] = pd.DataFrame(rows)

    if intent == "RETAIL_DISTRIBUTION":
        rows = facts.get("retailer_distribution", [])
        dfs["retailer_distribution"] = pd.DataFrame(rows)

    if intent == "CONSUMER_INSIGHTS":
        segments = facts.get("consumer_segments", [])
        # Flatten: one row per segment × SKU purchase
        flat = []
        for seg in (segments or []):
            if not isinstance(seg, dict):
                continue
            for pch in seg.get("purchases", []):
                flat.append({
                    "segment_id":   seg.get("segment_id"),
                    "segment_name": seg.get("segment_name"),
                    "income_tier":  seg.get("income_tier"),
                    **pch
                })
        dfs["consumer_purchases"] = pd.DataFrame(flat)

    if intent == "CAMPAIGN_ATTRIBUTION":
        attr = facts.get("campaign_attribution", {})
        if isinstance(attr, dict):
            lifts = attr.get("sales_lifts", [])
            dfs["campaign_lifts"] = pd.DataFrame(lifts)
            channels = attr.get("channels", [])
            dfs["campaign_channels"] = pd.DataFrame(channels)

    return dfs


# =====================================================
# CLI runner
# =====================================================

def main() -> None:
    neo4j_uri      = os.getenv("NEO4J_URI",      "bolt://localhost:7687")
    neo4j_user     = os.getenv("NEO4J_USER",     "neo4j")
    neo4j_password = os.getenv("NEO4J_PASSWORD",  "")

    if not neo4j_password:
        raise RuntimeError("NEO4J_PASSWORD env var is missing.")

    driver = GraphDatabase.driver(neo4j_uri, auth=(neo4j_user, neo4j_password))

    try:
        print("\nc5i CPG Analytics GraphRAG Runner (Neo4j + Azure OpenAI)\n")
        print("Example questions you can try:")
        print("  - 'Show brand summary for BR_001 (FreshBrew Coffee)'")
        print("  - 'Does FreshBrew Bold (SKU_002) have confirmed campaign lift? Show review evidence.'")
        print("  - 'List SKUs newly listed at retailers in last 90 days'")
        print("  - 'Show attribution for campaign CAMP_004 — channels, markets, and sales lift'")
        print("  - 'Retailer distribution: where are our SKUs listed and at what shelf coverage?'")
        print("  - 'Which consumer segments purchase FreshBrew and shop at mass retailers?'\n")

        question = input("Ask a question: ").strip()
        if not question:
            question = "Show brand summary for BR_001 — all campaigns, channels, markets, and SKU lifts."

        evidence_pack = build_evidence_pack(driver, question)

        print("\n--- Evidence Pack (retrieved from Neo4j) ---")
        print(json.dumps(evidence_pack, indent=2))

        dfs = maybe_make_dataframes(evidence_pack)
        if dfs:
            print("\n--- DataFrame previews ---")
            for name, df in dfs.items():
                print(f"\n[{name}]")
                if df.empty:
                    print("(empty)")
                else:
                    print(df.head(10).to_string(index=False))

        print("\n--- Grounded Answer (Azure OpenAI) ---")
        answer = call_azure_openai_grounded(question, evidence_pack)
        print(answer)

    finally:
        driver.close()


if __name__ == "__main__":
    main()
