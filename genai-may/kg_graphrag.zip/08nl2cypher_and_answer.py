"""
08nl2cypher_and_answer.py  — c5i CPG Analytics: NL → Cypher → Answer (v2)

Adds:
- Auto-retry once if Neo4j execution fails (LLM fixes Cypher using the error)
- Richer parameter extraction for CPG analytics:
    * brand_id (BR_###)
    * sku_id (SKU_###)
    * campaign_id (CAMP_###)
    * channel_id (CH_###)
    * retailer_id (RET_###)
    * segment_id (SEG_###)
    * channel type keywords (TV, Digital, Shopper, OOH)
    * date ranges (ISO, 'last N days', between/after/before)
    * numeric thresholds for roi, sales_lift_pct, budget, distribution_pct

Prereqs:
  pip install openai neo4j python-dotenv python-dateutil

Env vars required:
  AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_VERSION, AZURE_OPENAI_MODEL_NAME
  NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD
"""

import os
import re
import json
import datetime as dt
from typing import Optional, Tuple, Dict, Any, List

from dotenv import load_dotenv
from openai import AzureOpenAI
from neo4j import GraphDatabase
from dateutil import parser as dateparser

load_dotenv()


# =====================================================
# 1) c5i CPG Graph Schema
# =====================================================
GRAPH_SCHEMA = {
  "Brand": {
    "type": "node", "count": 2,
    "properties": {
      "brand_id":     {"type": "STRING", "unique": True,  "indexed": True},
      "name":         {"type": "STRING", "unique": False, "indexed": True},
      "category":     {"type": "STRING"},
      "manufacturer": {"type": "STRING"}
    },
    "relationships": {
      "HAS_SKU":  {"direction": "out", "labels": ["SKU"],      "properties": {}},
      "PROMOTES": {"direction": "in",  "labels": ["Campaign"], "properties": {}}
    }
  },
  "SKU": {
    "type": "node", "count": 6,
    "properties": {
      "sku_id":    {"type": "STRING", "unique": True,  "indexed": True},
      "name":      {"type": "STRING", "unique": False, "indexed": True},
      "pack_size": {"type": "STRING"},
      "upc":       {"type": "STRING", "unique": True}
    },
    "relationships": {
      "HAS_SKU":    {"direction": "in",  "labels": ["Brand"],           "properties": {}},
      "LISTED_AT":  {"direction": "out", "labels": ["Retailer"],
        "properties": {
          "listed_since": {"type": "DATE"}, "shelf_position": {"type": "STRING"},
          "distribution_pct": {"type": "FLOAT"}, "avg_price": {"type": "FLOAT"}
        }
      },
      "DROVE_LIFT": {"direction": "in",  "labels": ["Campaign"],
        "properties": {
          "sales_lift_pct": {"type": "FLOAT"}, "roi": {"type": "FLOAT"},
          "attributed_revenue": {"type": "INTEGER"}
        }
      },
      "APPLIED_TO": {"direction": "in",  "labels": ["Promotion"],       "properties": {}},
      "ABOUT_SKU":  {"direction": "in",  "labels": ["Review"],          "properties": {}},
      "MENTIONS":   {"direction": "in",  "labels": ["Review"],
        "properties": {
          "sentiment": {"type": "STRING"}, "score": {"type": "FLOAT"},
          "aspect": {"type": "STRING"}, "method": {"type": "STRING"}
        }
      },
      "PURCHASES":  {"direction": "in",  "labels": ["ConsumerSegment"],
        "properties": {"purchase_frequency": {"type": "STRING"}, "avg_basket_size": {"type": "INTEGER"}}
      }
    }
  },
  "Retailer": {
    "type": "node", "count": 3,
    "properties": {
      "retailer_id":  {"type": "STRING", "unique": True,  "indexed": True},
      "name":         {"type": "STRING", "unique": False, "indexed": True},
      "banner":       {"type": "STRING"},
      "channel_type": {"type": "STRING"}
    },
    "relationships": {
      "LISTED_AT":   {"direction": "in", "labels": ["SKU"],             "properties": {}},
      "AT_RETAILER": {"direction": "in", "labels": ["Promotion"],       "properties": {}},
      "SHOPS_AT":    {"direction": "in", "labels": ["ConsumerSegment"], "properties": {}}
    }
  },
  "Channel": {
    "type": "node", "count": 4,
    "properties": {
      "channel_id": {"type": "STRING", "unique": True,  "indexed": True},
      "name":       {"type": "STRING", "unique": False, "indexed": True},
      "type":       {"type": "STRING"}
    },
    "relationships": {
      "USES_CHANNEL": {"direction": "in", "labels": ["Campaign"],
        "properties": {"spend": {"type": "INTEGER"}, "impressions": {"type": "INTEGER"}, "grps": {"type": "FLOAT"}}
      }
    }
  },
  "Market": {
    "type": "node", "count": 3,
    "properties": {
      "market_id": {"type": "STRING", "unique": True,  "indexed": True},
      "name":      {"type": "STRING", "unique": False, "indexed": True},
      "region":    {"type": "STRING"},
      "dma_code":  {"type": "STRING"}
    },
    "relationships": {
      "TARGETS_MARKET": {"direction": "in", "labels": ["Campaign"], "properties": {}}
    }
  },
  "Campaign": {
    "type": "node", "count": 4,
    "properties": {
      "campaign_id": {"type": "STRING", "unique": True,  "indexed": True},
      "name":        {"type": "STRING", "unique": False, "indexed": True},
      "start_date":  {"type": "DATE",   "indexed": True},
      "end_date":    {"type": "DATE"},
      "budget":      {"type": "INTEGER"},
      "objective":   {"type": "STRING"}
    },
    "relationships": {
      "PROMOTES":       {"direction": "out", "labels": ["Brand"],   "properties": {}},
      "USES_CHANNEL":   {"direction": "out", "labels": ["Channel"],
        "properties": {"spend": {"type": "INTEGER"}, "impressions": {"type": "INTEGER"}, "grps": {"type": "FLOAT"}}
      },
      "TARGETS_MARKET": {"direction": "out", "labels": ["Market"],  "properties": {}},
      "DROVE_LIFT":     {"direction": "out", "labels": ["SKU"],
        "properties": {"sales_lift_pct": {"type": "FLOAT"}, "roi": {"type": "FLOAT"},
                       "attributed_revenue": {"type": "INTEGER"}}
      }
    }
  },
  "ConsumerSegment": {
    "type": "node", "count": 4,
    "properties": {
      "segment_id":  {"type": "STRING", "unique": True,  "indexed": True},
      "name":        {"type": "STRING", "unique": False, "indexed": True},
      "persona":     {"type": "STRING"},
      "age_range":   {"type": "STRING"},
      "income_tier": {"type": "STRING"}
    },
    "relationships": {
      "PURCHASES": {"direction": "out", "labels": ["SKU"],
        "properties": {"purchase_frequency": {"type": "STRING"}, "avg_basket_size": {"type": "INTEGER"}}
      },
      "SHOPS_AT":  {"direction": "out", "labels": ["Retailer"], "properties": {}}
    }
  },
  "Review": {
    "type": "node", "count": 5,
    "properties": {
      "review_id": {"type": "STRING",  "unique": True,  "indexed": True},
      "text":      {"type": "STRING"},
      "rating":    {"type": "INTEGER"},
      "date":      {"type": "DATE",    "indexed": True},
      "source":    {"type": "STRING"}
    },
    "relationships": {
      "ABOUT_SKU": {"direction": "out", "labels": ["SKU"],          "properties": {}},
      "MENTIONS":  {"direction": "out", "labels": ["SKU", "Brand"],
        "properties": {"sentiment": {"type": "STRING"}, "score": {"type": "FLOAT"}, "aspect": {"type": "STRING"}}
      }
    }
  },
  "Promotion": {
    "type": "node", "count": 2,
    "properties": {
      "promo_id":    {"type": "STRING", "unique": True,  "indexed": True},
      "name":        {"type": "STRING"},
      "type":        {"type": "STRING"},
      "start_date":  {"type": "DATE",   "indexed": True},
      "end_date":    {"type": "DATE"},
      "discount_pct":{"type": "FLOAT"}
    },
    "relationships": {
      "APPLIED_TO":  {"direction": "out", "labels": ["SKU"],      "properties": {}},
      "AT_RETAILER": {"direction": "out", "labels": ["Retailer"], "properties": {}}
    }
  },
  "HAS_SKU":        {"type": "relationship", "properties": {}},
  "LISTED_AT":      {"type": "relationship", "properties": {
    "listed_since": {"type": "DATE"}, "shelf_position": {"type": "STRING"},
    "distribution_pct": {"type": "FLOAT"}, "avg_price": {"type": "FLOAT"}
  }},
  "PROMOTES":       {"type": "relationship", "properties": {}},
  "USES_CHANNEL":   {"type": "relationship", "properties": {
    "spend": {"type": "INTEGER"}, "impressions": {"type": "INTEGER"}, "grps": {"type": "FLOAT"}
  }},
  "TARGETS_MARKET": {"type": "relationship", "properties": {}},
  "DROVE_LIFT":     {"type": "relationship", "properties": {
    "sales_lift_pct": {"type": "FLOAT"}, "roi": {"type": "FLOAT"}, "attributed_revenue": {"type": "INTEGER"}
  }},
  "PURCHASES":      {"type": "relationship", "properties": {
    "purchase_frequency": {"type": "STRING"}, "avg_basket_size": {"type": "INTEGER"}
  }},
  "SHOPS_AT":       {"type": "relationship", "properties": {}},
  "ABOUT_SKU":      {"type": "relationship", "properties": {}},
  "MENTIONS":       {"type": "relationship", "properties": {
    "sentiment": {"type": "STRING"}, "score": {"type": "FLOAT"}, "aspect": {"type": "STRING"}
  }},
  "APPLIED_TO":     {"type": "relationship", "properties": {}},
  "AT_RETAILER":    {"type": "relationship", "properties": {}}
}


# =====================================================
# 2) Prompts
# =====================================================
SYSTEM_PROMPT_CYPHER = """
You are a Neo4j Cypher expert for a CPG brand analytics graph (c5i.ai use-case).
Translate the user's natural-language question into a SINGLE Cypher query.

ABSOLUTE RULES:
1) Output MUST be ONLY Cypher text.
   - DO NOT use markdown, backticks, or language tags.
2) READ-ONLY ONLY:
   Allowed: MATCH, OPTIONAL MATCH, WHERE, WITH, RETURN, ORDER BY, LIMIT, SKIP, DISTINCT
   Disallowed: CREATE, MERGE, DELETE, DETACH, SET, REMOVE, DROP, CALL, LOAD CSV, APOC, PERIODIC COMMIT
3) Final RETURN must NOT return raw nodes/relationships.
   - Return exactly ONE JSON-like map aliased as `result`.
   - Use property projections only.

OUTPUT SHAPE (default for brand-centric / "everything relevant"):
Use a TWO-STAGE aggregation:
  Stage 1 (per campaign): collect channels (with uc:USES_CHANNEL), markets, SKU lifts
  Stage 2 (per brand): collect campaign objects sorted by start_date DESC

Template:
MATCH (b:Brand {brand_id:$brand_id})<-[:PROMOTES]-(c:Campaign)
OPTIONAL MATCH (c)-[uc:USES_CHANNEL]->(ch:Channel)
OPTIONAL MATCH (c)-[:TARGETS_MARKET]->(mk:Market)
OPTIONAL MATCH (c)-[dl:DROVE_LIFT]->(s:SKU)<-[:HAS_SKU]-(b)
WITH b, c,
     collect(DISTINCT {channel_id:ch.channel_id, name:ch.name, type:ch.type,
                       spend:uc.spend, impressions:uc.impressions}) AS channels,
     collect(DISTINCT {market_id:mk.market_id, name:mk.name, region:mk.region}) AS markets,
     collect(DISTINCT {sku_id:s.sku_id, name:s.name,
                       lift_pct:dl.sales_lift_pct, roi:dl.roi}) AS lifts
ORDER BY c.start_date DESC
WITH b, collect({
  campaign_id:c.campaign_id, name:c.name, start_date:c.start_date, end_date:c.end_date,
  budget:c.budget, objective:c.objective,
  channels:channels, markets:markets, sales_lifts:lifts
})[0..25] AS campaigns
RETURN {
  brand: {brand_id:b.brand_id, name:b.name, category:b.category},
  campaigns: campaigns
} AS result

PARAMETERS:
- Use PROVIDED parameter names exactly as given in AVAILABLE_PARAMS.
- DATE fields (start_date, end_date, listed_since): use date($param_name) for string params.

Use ONLY labels/relationships/properties from the schema. Do not invent any.
"""

SYSTEM_PROMPT_CYPHER_FIX = """
You are a Neo4j Cypher debugger for a CPG analytics graph.
Given the question, schema, attempted Cypher, available parameters, and a Neo4j error,
output a corrected SINGLE Cypher query that:
- Is READ-ONLY (MATCH/OPTIONAL MATCH/WHERE/WITH/RETURN/ORDER BY/LIMIT/SKIP/DISTINCT only)
- Outputs ONLY Cypher text (no markdown, no backticks)
- Returns exactly ONE JSON-like map aliased as `result`
- Uses a two-stage aggregation for nested lists
- Uses relationship variable [uc:USES_CHANNEL] when spend/impressions/grps are needed
- Uses only schema items and provided parameter names

Output ONLY the corrected Cypher.
"""

SYSTEM_PROMPT_ANSWER = """
You are a CPG brand analytics advisor at c5i.ai, serving Fortune 500 clients across
CPG, pharma, retail, and tech/media/telecom.
You will be given the user's question, the executed Cypher, and Neo4j results (JSON-like).

Rules:
- Use ONLY the provided results. Do not invent facts.
- If data is missing, say so.
- Provide a concise, actionable summary with sections relevant to the question:

  Brand / SKU summary
  Recent campaigns (most recent first)
  Channel mix & media spend
  Sales lift & ROI (from MMM attribution)
  Digital shelf review sentiment
  Key insights and recommended actions (3-5 items derived from data)

- Use business language appropriate for CPG brand managers and analytics teams.
Output plain text. No markdown code fences.
"""


def build_user_prompt_for_cypher(question: str, params: Dict[str, Any]) -> str:
    return f"""QUESTION:
{question}

AVAILABLE_PARAMS (names + values):
{json.dumps(params, indent=2, default=str)}

SCHEMA (JSON):
{json.dumps(GRAPH_SCHEMA, indent=2)}
"""


def build_user_prompt_for_fix(question: str, cypher: str, params: Dict[str, Any], neo4j_error: str) -> str:
    return f"""QUESTION:
{question}

ATTEMPTED CYPHER:
{cypher}

AVAILABLE_PARAMS (names + values):
{json.dumps(params, indent=2, default=str)}

NEO4J ERROR:
{neo4j_error}

SCHEMA (JSON):
{json.dumps(GRAPH_SCHEMA, indent=2)}
"""


def build_user_prompt_for_answer(question: str, cypher: str, results_json: str) -> str:
    return f"""QUESTION:
{question}

CYPHER EXECUTED:
{cypher}

NEO4J RESULTS (JSON):
{results_json}
"""


# =====================================================
# 3) Safety validator
# =====================================================
DISALLOWED = re.compile(
    r"\b(CREATE|MERGE|DELETE|DETACH|SET|REMOVE|DROP|CALL|LOAD\s+CSV|APOC|PERIODIC)\b",
    re.IGNORECASE,
)
CODE_FENCE_RE = re.compile(r"^\s*```(?:cypher|sql|text)?\s*|\s*```\s*$", re.IGNORECASE | re.MULTILINE)

def strip_code_fences(text: str) -> str:
    return re.sub(CODE_FENCE_RE, "", text).strip()

def validate_readonly(cypher: str) -> None:
    if "```" in cypher:
        raise ValueError("Cypher contains markdown code fences.")
    if DISALLOWED.search(cypher):
        raise ValueError("Generated Cypher contains disallowed write/admin clauses.")


# =====================================================
# 4) Azure OpenAI helpers
# =====================================================
def get_azure_client_and_model() -> Tuple[AzureOpenAI, str]:
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    )
    model_name = os.getenv("AZURE_OPENAI_MODEL_NAME")
    if not model_name:
        raise ValueError("Missing env var: AZURE_OPENAI_MODEL_NAME")
    return client, model_name


def llm_chat(client: AzureOpenAI, model_name: str, system: str, user: str, temperature: float = 0.0) -> str:
    response = client.chat.completions.create(
        model=model_name,
        messages=[
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ],
        temperature=temperature,
    )
    return response.choices[0].message.content.strip()


# =====================================================
# 5) Neo4j helpers
# =====================================================
def get_neo4j_driver():
    NEO4J_URI      = os.getenv("NEO4J_URI")
    NEO4J_USER     = os.getenv("NEO4J_USER")
    NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")
    if not all([NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD]):
        raise ValueError("Missing one or more Neo4j env variables")
    return GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))


def neo4j_connection_test(driver) -> None:
    with driver.session() as session:
        record = session.run("RETURN 1 AS ok").single()
        print("Neo4j connection successful:", record["ok"])


def run_cypher(driver, cypher: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
    with driver.session() as session:
        result = session.run(cypher, params)
        return [r.data() for r in result]


# =====================================================
# 6) CPG parameter extraction
# =====================================================
BRAND_ID_RE    = re.compile(r"\bBR_\d{3}\b",   re.IGNORECASE)
SKU_ID_RE      = re.compile(r"\bSKU_\d{3}\b",  re.IGNORECASE)
CAMPAIGN_ID_RE = re.compile(r"\bCAMP_\d{3}\b", re.IGNORECASE)
CHANNEL_ID_RE  = re.compile(r"\bCH_\d{3}\b",   re.IGNORECASE)
RETAILER_ID_RE = re.compile(r"\bRET_\d{3}\b",  re.IGNORECASE)
SEGMENT_ID_RE  = re.compile(r"\bSEG_\d{3}\b",  re.IGNORECASE)

CHANNEL_TYPE_RE = re.compile(
    r"\b(TV|television|digital|social|digital\s+social|shopper|OOH|out.of.home|print)\b",
    re.IGNORECASE
)

DATE_ISO_RE      = re.compile(r"\b(20\d{2}-\d{2}-\d{2})\b")
LAST_N_DAYS_RE   = re.compile(r"\blast\s+(\d{1,3})\s+days\b",                             re.IGNORECASE)
BETWEEN_DATES_RE = re.compile(r"\bbetween\s+(20\d{2}-\d{2}-\d{2})\s+and\s+(20\d{2}-\d{2}-\d{2})\b", re.IGNORECASE)
AFTER_DATE_RE    = re.compile(r"\b(after|since)\s+(20\d{2}-\d{2}-\d{2})\b",               re.IGNORECASE)
BEFORE_DATE_RE   = re.compile(r"\b(before|until)\s+(20\d{2}-\d{2}-\d{2})\b",              re.IGNORECASE)

# Numeric thresholds for CPG metrics
THRESH_RE = re.compile(
    r"\b(?P<field>roi|sales_lift_pct|sales_lift|lift|budget|spend|distribution_pct|distribution|impressions)\b"
    r"\s*(?P<op>>=|<=|>|<|=|above|below|over|under)\s*"
    r"(?P<val>\d+(?:\.\d+)?)\b",
    re.IGNORECASE,
)


def _to_iso_date(d: dt.date) -> str:
    return d.isoformat()


def extract_params(question: str) -> Dict[str, Any]:
    q = question.strip()
    params: Dict[str, Any] = {}

    # Entity IDs
    m = BRAND_ID_RE.search(q)
    if m:
        params["brand_id"] = m.group(0).upper()

    m = SKU_ID_RE.search(q)
    if m:
        params["sku_id"] = m.group(0).upper()

    m = CAMPAIGN_ID_RE.search(q)
    if m:
        params["campaign_id"] = m.group(0).upper()

    m = CHANNEL_ID_RE.search(q)
    if m:
        params["channel_id"] = m.group(0).upper()

    m = RETAILER_ID_RE.search(q)
    if m:
        params["retailer_id"] = m.group(0).upper()

    m = SEGMENT_ID_RE.search(q)
    if m:
        params["segment_id"] = m.group(0).upper()

    # Channel type keyword (maps to Channel.type)
    m = CHANNEL_TYPE_RE.search(q)
    if m:
        raw = m.group(1).lower()
        if "tv" in raw or "tele" in raw:
            params["channel_type"] = "TV"
        elif "dig" in raw or "social" in raw:
            params["channel_type"] = "Digital"
        elif "shop" in raw:
            params["channel_type"] = "Shopper"
        elif "ooh" in raw or "out" in raw:
            params["channel_type"] = "OOH"

    # Date ranges
    m = BETWEEN_DATES_RE.search(q)
    if m:
        params["start_date"] = m.group(1)
        params["end_date"]   = m.group(2)

    m = AFTER_DATE_RE.search(q)
    if m and "start_date" not in params:
        params["start_date"] = m.group(2)

    m = BEFORE_DATE_RE.search(q)
    if m and "end_date" not in params:
        params["end_date"] = m.group(2)

    m = LAST_N_DAYS_RE.search(q)
    if m:
        n = int(m.group(1))
        today = dt.date.today()
        params["start_date"] = _to_iso_date(today - dt.timedelta(days=n))
        params["end_date"]   = _to_iso_date(today)
        params["days"]       = n

    if "start_date" not in params and "end_date" not in params:
        iso_dates = DATE_ISO_RE.findall(q)
        if len(iso_dates) >= 2:
            params["start_date"] = iso_dates[0]
            params["end_date"]   = iso_dates[1]

    # Numeric thresholds (roi, lift, budget, distribution_pct, spend)
    for match in THRESH_RE.finditer(q):
        field_raw = match.group("field").lower()
        op        = match.group("op").lower()
        val_str   = match.group("val")
        val = float(val_str) if "." in val_str else int(float(val_str))

        # Normalize field names
        if field_raw in ("sales_lift", "lift"):
            field = "sales_lift_pct"
        elif field_raw == "distribution":
            field = "distribution_pct"
        else:
            field = field_raw

        # Normalize op words
        if op in ("above", "over"):
            op = ">"
        elif op in ("below", "under"):
            op = "<"

        if op in (">", ">="):
            params[f"min_{field}"] = val
        elif op in ("<", "<="):
            params[f"max_{field}"] = val
        elif op == "=":
            params[f"eq_{field}"] = val

    # Free-text search term
    if re.search(r"\b(contains|mention|mentions|like|search|find)\b", q, re.IGNORECASE):
        quoted = re.findall(r"['\"]([^'\"]{2,})['\"]", q)
        if quoted:
            params["term"] = quoted[0]

    return params


# =====================================================
# 7) Auto-retry execution with LLM fix
# =====================================================
def execute_with_retry(
    client: AzureOpenAI,
    model_name: str,
    driver,
    question: str,
    cypher: str,
    params: Dict[str, Any],
    max_attempts: int = 2
) -> Tuple[str, List[Dict[str, Any]]]:

    cur_cypher = cypher
    last_err: Optional[str] = None

    for attempt in range(1, max_attempts + 1):
        try:
            rows = run_cypher(driver, cur_cypher, params)
            return cur_cypher, rows
        except Exception as e:
            last_err = str(e)
            if attempt >= max_attempts:
                raise

            fix_prompt = build_user_prompt_for_fix(question, cur_cypher, params, last_err)
            fixed = llm_chat(client, model_name, SYSTEM_PROMPT_CYPHER_FIX, fix_prompt, temperature=0.0)
            fixed = strip_code_fences(fixed)
            validate_readonly(fixed)
            cur_cypher = fixed

    raise RuntimeError(f"Neo4j execution failed after retries: {last_err}")


# =====================================================
# 8) Main
# =====================================================
def main() -> None:
    print("c5i CPG Analytics: NL → Cypher → Neo4j (+auto-retry) → Answer (Azure OpenAI)")

    question = input("\nAsk a question about brands, campaigns, SKUs, or retail distribution: ").strip()
    if not question:
        print("No question provided.")
        return

    params = extract_params(question)

    client, model_name = get_azure_client_and_model()
    driver = get_neo4j_driver()

    try:
        neo4j_connection_test(driver)

        cypher_prompt = build_user_prompt_for_cypher(question, params)
        cypher = llm_chat(client, model_name, SYSTEM_PROMPT_CYPHER, cypher_prompt, temperature=0.0)
        validate_readonly(cypher)

        print("\n--- Generated Cypher (attempt 1) ---")
        print(cypher)

        missing = [p for p in re.findall(r"\$(\w+)", cypher) if p not in params]
        if missing:
            print("\nNote: Cypher references parameters not detected in the question:", sorted(set(missing)))

        final_cypher, rows = execute_with_retry(
            client=client, model_name=model_name, driver=driver,
            question=question, cypher=cypher, params=params, max_attempts=2,
        )

        if final_cypher != cypher:
            print("\n--- Fixed Cypher (after Neo4j error) ---")
            print(final_cypher)

        results_json = json.dumps(rows, indent=2, default=str)

        answer_prompt = build_user_prompt_for_answer(question, final_cypher, results_json)
        final_answer  = llm_chat(client, model_name, SYSTEM_PROMPT_ANSWER, answer_prompt, temperature=0.2)

        print("\n==============================")
        print("FINAL ANSWER")
        print("==============================")
        print(final_answer)

    except Exception as e:
        print(f"\nERROR: {e}")
    finally:
        driver.close()


if __name__ == "__main__":
    main()
