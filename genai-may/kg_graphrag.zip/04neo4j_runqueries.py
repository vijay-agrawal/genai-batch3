"""
04neo4j_runqueries.py  — c5i CPG Brand & Digital Shelf Analytics

Connects to Neo4j using the official Python driver and runs 5 practical queries
from the c5i CPG schema. Mirrors what c5i delivers to Fortune 500 CPG clients:
  - Marketing mix model attribution
  - Digital shelf distribution analytics (c5i Compete)
  - Retailer distribution footprint
  - Channel ROI patterns
  - Review sentiment vs campaign evidence grounding

Install:
  pip install neo4j pandas python-dotenv

Env vars:
  NEO4J_URI=bolt://localhost:7687
  NEO4J_USER=neo4j
  NEO4J_PASSWORD=neo4j_password

  DEMO_BID=BR_001
  DEMO_CHANNEL_ID=CH_002
  DEMO_SKU_ID=SKU_002
"""

from __future__ import annotations

import os
import json
from typing import Any, Dict, List, Optional

import pandas as pd
from neo4j import GraphDatabase
from dotenv import load_dotenv


# -------------------------------------------------------
# Cypher queries (5)
# -------------------------------------------------------

# Use-case A: Brand "Campaign Attribution Snapshot"
# GraphRAG grounding query — multi-hop Brand ← Campaign → Channel + Market + SKU
Q1_BRAND_CAMPAIGN_SNAPSHOT = """
MATCH (b:Brand {brand_id:$bid})<-[:PROMOTES]-(c:Campaign)
OPTIONAL MATCH (c)-[uc:USES_CHANNEL]->(ch:Channel)
OPTIONAL MATCH (c)-[:TARGETS_MARKET]->(mk:Market)
OPTIONAL MATCH (c)-[dl:DROVE_LIFT]->(s:SKU)<-[:HAS_SKU]-(b)
WITH b, c,
     collect(DISTINCT {channel_id:ch.channel_id, name:ch.name, type:ch.type,
                       spend:uc.spend, impressions:uc.impressions, grps:uc.grps}) AS channels,
     collect(DISTINCT {market_id:mk.market_id, name:mk.name, region:mk.region}) AS markets,
     collect(DISTINCT {sku_id:s.sku_id, name:s.name,
                       lift_pct:dl.sales_lift_pct, roi:dl.roi,
                       attributed_revenue:dl.attributed_revenue}) AS lifts
ORDER BY c.start_date DESC
WITH b, collect({
  campaign_id:c.campaign_id, name:c.name,
  start_date:c.start_date, end_date:c.end_date,
  budget:c.budget, objective:c.objective,
  channels:channels, markets:markets, sales_lifts:lifts
})[0..$limit] AS campaigns
RETURN {
  brand: {brand_id:b.brand_id, name:b.name, category:b.category,
          manufacturer:b.manufacturer},
  campaigns: campaigns
} AS brand_snapshot;
"""

# Use-case B: "Distribution Gain" cohort — first-ever retail listing in last N days
# Mirrors "newly diagnosed" cohort — first-occurrence detection across the retail graph
Q2_NEWLY_LISTED_LAST_N_DAYS = """
MATCH (s:SKU)-[la:LISTED_AT]->(r:Retailer)
WHERE la.listed_since >= date() - duration({days:$days})
WITH s, min(la.listed_since) AS first_list_date
OPTIONAL MATCH (s)-[la2:LISTED_AT]->(r2:Retailer)
WHERE la2.listed_since < first_list_date
WITH s, first_list_date, count(la2) AS prior_count
WHERE prior_count = 0
MATCH (b:Brand)-[:HAS_SKU]->(s)
RETURN s.sku_id AS sku_id, s.name AS sku_name, b.brand_id AS brand_id,
       b.name AS brand, first_list_date
ORDER BY first_list_date DESC;
"""

# Use-case C: Retailer distribution footprint
# Digital shelf analytics — c5i Compete: which SKUs are where and at what shelf weight?
Q3_RETAILER_DISTRIBUTION = """
MATCH (r:Retailer)<-[la:LISTED_AT]-(s:SKU)<-[:HAS_SKU]-(b:Brand)
RETURN r.retailer_id AS retailer_id, r.name AS retailer_name, r.channel_type,
       b.brand_id AS brand_id, b.name AS brand_name,
       s.sku_id AS sku_id, s.name AS sku_name,
       la.distribution_pct AS distribution_pct,
       la.shelf_position AS shelf_position,
       la.avg_price AS avg_price,
       la.listed_since AS listed_since
ORDER BY r.retailer_id, la.distribution_pct DESC;
"""

# Use-case D: Channel ROI attribution patterns — MMM output
# Equivalent to "provider prescribing patterns" — who is delivering the most value?
Q4_CHANNEL_ROI_PATTERNS = """
MATCH (ch:Channel {channel_id:$channel_id})<-[uc:USES_CHANNEL]-(c:Campaign)
MATCH (c)-[:PROMOTES]->(b:Brand)
OPTIONAL MATCH (c)-[dl:DROVE_LIFT]->(s:SKU)<-[:HAS_SKU]-(b)
WITH ch, c, b, uc,
     collect(DISTINCT {sku_id:s.sku_id, sku_name:s.name,
                       lift_pct:dl.sales_lift_pct, roi:dl.roi,
                       rev:dl.attributed_revenue}) AS lifts
ORDER BY c.start_date DESC
RETURN {
  channel: {channel_id:ch.channel_id, name:ch.name, type:ch.type},
  campaigns: collect({
    campaign_id:c.campaign_id, name:c.name, brand:b.name,
    spend:uc.spend, impressions:uc.impressions, grps:uc.grps,
    lifts:lifts
  })[0..$topk]
} AS channel_attribution;
"""

# Use-case E: Confirmed campaign lift vs review sentiment evidence
# GraphRAG grounding — two evidence streams: MMM attribution + digital shelf reviews
Q5_LIFT_VS_REVIEW_EVIDENCE = """
MATCH (s:SKU {sku_id:$sku_id})
OPTIONAL MATCH (c:Campaign)-[dl:DROVE_LIFT]->(s)
OPTIONAL MATCH (rv:Review)-[:ABOUT_SKU]->(s)
OPTIONAL MATCH (rv)-[mn:MENTIONS]->(s)
WITH s, c, dl, rv, mn
ORDER BY coalesce(c.start_date, date('2000-01-01')) DESC
WITH s,
     collect(DISTINCT {
       campaign_id:c.campaign_id, campaign_name:c.name,
       lift_pct:dl.sales_lift_pct, roi:dl.roi,
       attributed_revenue:dl.attributed_revenue
     }) AS lift_evidence,
     collect(DISTINCT {
       review_id:rv.review_id, source:rv.source, rating:rv.rating,
       snippet:substring(rv.text, 0, 180),
       sentiment:mn.sentiment, score:mn.score, aspect:mn.aspect
     }) AS review_evidence
RETURN {
  sku_id: s.sku_id,
  sku_name: s.name,
  lift_evidence: lift_evidence,
  review_evidence: [r IN review_evidence WHERE r.review_id IS NOT NULL]
} AS sku_evidence;
"""


# -------------------------------------------------------
# Helpers: Neo4j result -> Python types safe for JSON
# -------------------------------------------------------

def _json_safe(obj: Any) -> Any:
    if hasattr(obj, "iso_format"):
        try:
            return obj.iso_format()
        except Exception:
            return str(obj)
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(x) for x in obj]
    return obj


def run_query(driver, cypher: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    params = params or {}
    with driver.session() as session:
        rows = session.run(cypher, **params).data()
    return _json_safe(rows)


def first_value(rows: List[Dict[str, Any]], key: str) -> Any:
    if not rows:
        return None
    return rows[0].get(key)


def to_dataframe(rows: List[Dict[str, Any]]) -> pd.DataFrame:
    return pd.DataFrame(rows)


# -------------------------------------------------------
# Demo runner
# -------------------------------------------------------

def main() -> None:

    load_dotenv()
    NEO4J_URI = os.getenv("NEO4J_URI")
    NEO4J_USER = os.getenv("NEO4J_USER")
    NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")
    if not all([NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD]):
        raise ValueError("Missing one or more Neo4j env variables")

    driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

    # Demo anchors — override via env vars or edit here
    bid         = os.getenv("DEMO_BID",        "BR_001")   # FreshBrew Coffee
    channel_id  = os.getenv("DEMO_CHANNEL_ID", "CH_002")   # Digital & Social
    sku_id      = os.getenv("DEMO_SKU_ID",     "SKU_002")  # FreshBrew Bold

    try:
        # 1) Nested JSON: Brand Campaign Attribution Snapshot
        rows = run_query(driver, Q1_BRAND_CAMPAIGN_SNAPSHOT, {"bid": bid, "limit": 5})
        brand_snapshot = first_value(rows, "brand_snapshot")
        print("\n=== 1) Brand Campaign Attribution Snapshot (Nested JSON) ===")
        print(json.dumps(brand_snapshot, indent=2))

        # 2) DataFrame: Newly Listed SKUs — distribution gains in last 90 days
        rows = run_query(driver, Q2_NEWLY_LISTED_LAST_N_DAYS, {"days": 90})
        df_new = to_dataframe(rows)
        print("\n=== 2) Newly Listed SKUs — Distribution Gain Cohort (DataFrame) ===")
        print(df_new.head(10).to_string(index=False))

        # 3) DataFrame: Retailer Distribution Footprint
        rows = run_query(driver, Q3_RETAILER_DISTRIBUTION)
        df_dist = to_dataframe(rows)
        print("\n=== 3) Retailer Distribution Footprint (DataFrame) ===")
        print(df_dist.head(15).to_string(index=False))

        # 4) Nested JSON: Channel ROI Attribution Patterns
        rows = run_query(driver, Q4_CHANNEL_ROI_PATTERNS, {"channel_id": channel_id, "topk": 10})
        channel_attr = first_value(rows, "channel_attribution") or {}
        print("\n=== 4) Channel ROI Attribution Patterns (Nested JSON) ===")
        print(json.dumps({"channel_id": channel_id, "channel_attribution": channel_attr}, indent=2))

        # 4b) Flatten channel campaigns to DataFrame
        campaigns_flat = channel_attr.get("campaigns", []) if isinstance(channel_attr, dict) else []
        if campaigns_flat:
            df_ch = pd.DataFrame(campaigns_flat)
            print("\n=== 4b) Channel Campaigns Flat (DataFrame) ===")
            print(df_ch[["campaign_id", "name", "brand", "spend", "impressions"]].to_string(index=False))

        # 5) Nested JSON: Campaign Lift vs Review Sentiment Evidence
        rows = run_query(driver, Q5_LIFT_VS_REVIEW_EVIDENCE, {"sku_id": sku_id})
        evidence = first_value(rows, "sku_evidence")
        print("\n=== 5) Campaign Lift vs Review Sentiment Evidence (Nested JSON) ===")
        print(json.dumps(evidence, indent=2))

    finally:
        driver.close()


if __name__ == "__main__":
    main()
