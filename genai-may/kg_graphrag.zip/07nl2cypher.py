"""
07nl2cypher.py  — c5i CPG Brand Analytics: NL → Cypher

- Takes a natural-language question from the user
- Uses Azure OpenAI Chat Completions to generate a Cypher query
- Grounds generation on the c5i CPG graph schema
- Enforces safe, read-only Cypher (MATCH/RETURN only)

Prereqs:
  pip install openai python-dotenv

Env vars needed:
  AZURE_OPENAI_ENDPOINT
  AZURE_OPENAI_API_KEY
  AZURE_OPENAI_API_VERSION
  AZURE_OPENAI_MODEL_NAME
"""

import os
import json
import re
from typing import Optional

from openai import AzureOpenAI
from dotenv import load_dotenv

load_dotenv()


# -------------------------------------------------------
# 1) c5i CPG Graph Schema
#    Generated via 06fetch_neo4jschema.cypher on the CPG dataset
# -------------------------------------------------------
GRAPH_SCHEMA = {
  "Brand": {
    "type": "node", "count": 2,
    "properties": {
      "brand_id":     {"type": "STRING", "unique": True,  "indexed": True},
      "name":         {"type": "STRING", "unique": False, "indexed": True},
      "category":     {"type": "STRING", "unique": False, "indexed": False},
      "manufacturer": {"type": "STRING", "unique": False, "indexed": False}
    },
    "relationships": {
      "HAS_SKU":  {"direction": "out", "labels": ["SKU"],      "properties": {}},
      "PROMOTES": {"direction": "in",  "labels": ["Campaign"], "properties": {}}
    }
  },
  "SKU": {
    "type": "node", "count": 6,
    "properties": {
      "sku_id":    {"type": "STRING", "unique": True,  "indexed": True},
      "name":      {"type": "STRING", "unique": False, "indexed": True},
      "pack_size": {"type": "STRING", "unique": False, "indexed": False},
      "upc":       {"type": "STRING", "unique": True,  "indexed": True}
    },
    "relationships": {
      "HAS_SKU":    {"direction": "in",  "labels": ["Brand"],           "properties": {}},
      "LISTED_AT":  {
        "direction": "out", "labels": ["Retailer"],
        "properties": {
          "listed_since":    {"type": "DATE"},
          "shelf_position":  {"type": "STRING"},
          "distribution_pct":{"type": "FLOAT"},
          "avg_price":       {"type": "FLOAT"}
        }
      },
      "DROVE_LIFT": {
        "direction": "in", "labels": ["Campaign"],
        "properties": {
          "sales_lift_pct":     {"type": "FLOAT"},
          "roi":                {"type": "FLOAT"},
          "attributed_revenue": {"type": "INTEGER"}
        }
      },
      "APPLIED_TO": {"direction": "in",  "labels": ["Promotion"],       "properties": {}},
      "ABOUT_SKU":  {"direction": "in",  "labels": ["Review"],          "properties": {}},
      "MENTIONS":   {
        "direction": "in", "labels": ["Review"],
        "properties": {
          "sentiment": {"type": "STRING"},
          "score":     {"type": "FLOAT"},
          "aspect":    {"type": "STRING"},
          "method":    {"type": "STRING"}
        }
      },
      "PURCHASES":  {
        "direction": "in", "labels": ["ConsumerSegment"],
        "properties": {
          "purchase_frequency": {"type": "STRING"},
          "avg_basket_size":    {"type": "INTEGER"}
        }
      }
    }
  },
  "Retailer": {
    "type": "node", "count": 3,
    "properties": {
      "retailer_id":  {"type": "STRING", "unique": True,  "indexed": True},
      "name":         {"type": "STRING", "unique": False, "indexed": True},
      "banner":       {"type": "STRING", "unique": False, "indexed": False},
      "channel_type": {"type": "STRING", "unique": False, "indexed": False}
    },
    "relationships": {
      "LISTED_AT":  {"direction": "in", "labels": ["SKU"],             "properties": {}},
      "AT_RETAILER":{"direction": "in", "labels": ["Promotion"],       "properties": {}},
      "SHOPS_AT":   {"direction": "in", "labels": ["ConsumerSegment"], "properties": {}}
    }
  },
  "Channel": {
    "type": "node", "count": 4,
    "properties": {
      "channel_id": {"type": "STRING", "unique": True,  "indexed": True},
      "name":       {"type": "STRING", "unique": False, "indexed": True},
      "type":       {"type": "STRING", "unique": False, "indexed": False}
    },
    "relationships": {
      "USES_CHANNEL": {
        "direction": "in", "labels": ["Campaign"],
        "properties": {
          "spend":       {"type": "INTEGER"},
          "impressions": {"type": "INTEGER"},
          "grps":        {"type": "FLOAT"}
        }
      }
    }
  },
  "Market": {
    "type": "node", "count": 3,
    "properties": {
      "market_id": {"type": "STRING", "unique": True,  "indexed": True},
      "name":      {"type": "STRING", "unique": False, "indexed": True},
      "region":    {"type": "STRING", "unique": False, "indexed": False},
      "dma_code":  {"type": "STRING", "unique": False, "indexed": False}
    },
    "relationships": {
      "TARGETS_MARKET": {"direction": "in", "labels": ["Campaign"], "properties": {}}
    }
  },
  "Campaign": {
    "type": "node", "count": 4,
    "properties": {
      "campaign_id": {"type": "STRING", "unique": True,  "indexed": True},
      "name":        {"type": "STRING", "unique": False, "indexed": True},
      "start_date":  {"type": "DATE",   "unique": False, "indexed": True},
      "end_date":    {"type": "DATE",   "unique": False, "indexed": False},
      "budget":      {"type": "INTEGER","unique": False, "indexed": False},
      "objective":   {"type": "STRING", "unique": False, "indexed": False}
    },
    "relationships": {
      "PROMOTES":       {"direction": "out", "labels": ["Brand"],   "properties": {}},
      "USES_CHANNEL":   {"direction": "out", "labels": ["Channel"],
        "properties": {"spend": {"type": "INTEGER"}, "impressions": {"type": "INTEGER"}, "grps": {"type": "FLOAT"}}
      },
      "TARGETS_MARKET": {"direction": "out", "labels": ["Market"],  "properties": {}},
      "DROVE_LIFT":     {"direction": "out", "labels": ["SKU"],
        "properties": {"sales_lift_pct": {"type": "FLOAT"}, "roi": {"type": "FLOAT"}, "attributed_revenue": {"type": "INTEGER"}}
      }
    }
  },
  "ConsumerSegment": {
    "type": "node", "count": 4,
    "properties": {
      "segment_id":  {"type": "STRING", "unique": True,  "indexed": True},
      "name":        {"type": "STRING", "unique": False, "indexed": True},
      "persona":     {"type": "STRING", "unique": False, "indexed": False},
      "age_range":   {"type": "STRING", "unique": False, "indexed": False},
      "income_tier": {"type": "STRING", "unique": False, "indexed": False}
    },
    "relationships": {
      "PURCHASES": {
        "direction": "out", "labels": ["SKU"],
        "properties": {"purchase_frequency": {"type": "STRING"}, "avg_basket_size": {"type": "INTEGER"}}
      },
      "SHOPS_AT": {"direction": "out", "labels": ["Retailer"], "properties": {}}
    }
  },
  "Review": {
    "type": "node", "count": 5,
    "properties": {
      "review_id": {"type": "STRING",  "unique": True,  "indexed": True},
      "text":      {"type": "STRING",  "unique": False, "indexed": False},
      "rating":    {"type": "INTEGER", "unique": False, "indexed": False},
      "date":      {"type": "DATE",    "unique": False, "indexed": True},
      "source":    {"type": "STRING",  "unique": False, "indexed": False}
    },
    "relationships": {
      "ABOUT_SKU": {"direction": "out", "labels": ["SKU"],          "properties": {}},
      "MENTIONS":  {
        "direction": "out", "labels": ["SKU", "Brand"],
        "properties": {"sentiment": {"type": "STRING"}, "score": {"type": "FLOAT"}, "aspect": {"type": "STRING"}}
      }
    }
  },
  "Promotion": {
    "type": "node", "count": 2,
    "properties": {
      "promo_id":    {"type": "STRING", "unique": True,  "indexed": True},
      "name":        {"type": "STRING", "unique": False, "indexed": False},
      "type":        {"type": "STRING", "unique": False, "indexed": False},
      "start_date":  {"type": "DATE",   "unique": False, "indexed": True},
      "end_date":    {"type": "DATE",   "unique": False, "indexed": False},
      "discount_pct":{"type": "FLOAT",  "unique": False, "indexed": False}
    },
    "relationships": {
      "APPLIED_TO":  {"direction": "out", "labels": ["SKU"],      "properties": {}},
      "AT_RETAILER": {"direction": "out", "labels": ["Retailer"], "properties": {}}
    }
  },
  # Relationship type entries
  "HAS_SKU":        {"type": "relationship", "properties": {}},
  "LISTED_AT":      {"type": "relationship", "properties": {
    "listed_since": {"type": "DATE"}, "shelf_position": {"type": "STRING"},
    "distribution_pct": {"type": "FLOAT"}, "avg_price": {"type": "FLOAT"}
  }},
  "PROMOTES":       {"type": "relationship", "properties": {}},
  "USES_CHANNEL":   {"type": "relationship", "properties": {
    "spend": {"type": "INTEGER"}, "impressions": {"type": "INTEGER"}, "grps": {"type": "FLOAT"}
  }},
  "TARGETS_MARKET": {"type": "relationship", "properties": {}},
  "DROVE_LIFT":     {"type": "relationship", "properties": {
    "sales_lift_pct": {"type": "FLOAT"}, "roi": {"type": "FLOAT"}, "attributed_revenue": {"type": "INTEGER"}
  }},
  "PURCHASES":      {"type": "relationship", "properties": {
    "purchase_frequency": {"type": "STRING"}, "avg_basket_size": {"type": "INTEGER"}
  }},
  "SHOPS_AT":       {"type": "relationship", "properties": {}},
  "ABOUT_SKU":      {"type": "relationship", "properties": {}},
  "MENTIONS":       {"type": "relationship", "properties": {
    "sentiment": {"type": "STRING"}, "score": {"type": "FLOAT"}, "aspect": {"type": "STRING"}
  }},
  "APPLIED_TO":     {"type": "relationship", "properties": {}},
  "AT_RETAILER":    {"type": "relationship", "properties": {}}
}


# -------------------------------------------------------
# 2) System prompt
# -------------------------------------------------------
SYSTEM_PROMPT = """
You are a Neo4j Cypher expert for a CPG brand analytics graph used by c5i.ai clients.
Translate the user's natural-language question into a SINGLE Cypher query.

HARD OUTPUT CONTRACT (must follow):
A) Output MUST be ONLY Cypher (no markdown, no explanations, no comments).
B) Read-only queries only (MATCH / OPTIONAL MATCH / WHERE / WITH / RETURN / ORDER BY / LIMIT / SKIP / DISTINCT).
C) NEVER return raw nodes or raw relationships in the final RETURN.
   - Final RETURN must be a SINGLE map aliased as `result` or a descriptive alias.
   - Use property projections like {brand_id:b.brand_id, name:b.name, ...}.
D) Prefer structured, human-consumable output:
   - Use `collect(DISTINCT ...)` to build lists.
   - Use relationship variables (e.g., [uc:USES_CHANNEL]) to include relationship properties (spend, impressions, grps).
   - Use `substring(rv.text, 0, 180)` for review text.
E) When the question asks for "everything relevant" about a Brand:
   - Return one object with:
     brand: {brand_id, name, category, manufacturer}
     campaigns: [ {campaign_id, name, start_date, end_date, budget, objective,
                   channels:[{channel_id, name, type, spend, impressions}],
                   markets:[{market_id, name, region}],
                   sales_lifts:[{sku_id, name, lift_pct, roi}]} ]
   - Sort campaigns by c.start_date DESC.
   - Use LIMIT 25 on campaigns unless user asks otherwise.
F) Parameters:
   - Use $brand_id for brand id unless the user provides a different parameter name.
   - Campaign.start_date and LISTED_AT.listed_since are DATE; for ranges:
     c.start_date >= date($start_date) AND c.start_date <= date($end_date)

Use ONLY labels/relationships/properties from the provided schema. Do not invent any.
"""


def build_user_prompt(question: str) -> str:
    schema_json = json.dumps(GRAPH_SCHEMA, indent=2)
    return f"""Convert this question to Cypher.
IMPORTANT: Return a single JSON-like map with projected properties (no raw nodes).
If the question is brand-centric, return a brand_snapshot object.

QUESTION:
{question}

SCHEMA (JSON):
{schema_json}
"""


# -------------------------------------------------------
# 3) Safety validator
# -------------------------------------------------------
DISALLOWED = re.compile(
    r"\b(CREATE|MERGE|DELETE|DETACH|SET|REMOVE|DROP|CALL|LOAD\s+CSV|APOC|PERIODIC)\b",
    re.IGNORECASE,
)

def validate_readonly(cypher: str) -> None:
    if DISALLOWED.search(cypher):
        raise ValueError("Generated Cypher contains disallowed write/admin clauses.")


# -------------------------------------------------------
# 4) Azure OpenAI call
# -------------------------------------------------------
def generate_cypher(question: str) -> Optional[str]:
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    )
    model_name = os.getenv("AZURE_OPENAI_MODEL_NAME")
    if not model_name:
        raise ValueError("Missing env var: AZURE_OPENAI_MODEL_NAME")

    prompt = build_user_prompt(question)
    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user",   "content": prompt},
            ],
            temperature=0.0,
        )
        cypher = response.choices[0].message.content.strip()
        validate_readonly(cypher)
        return cypher
    except Exception as e:
        print(f"ERROR: {e}")
        return None


# -------------------------------------------------------
# 5) Pre-built demo questions (c5i CPG analytics)
# -------------------------------------------------------
DEMO_QUESTIONS = [
    # 1. Simple lookup — brand → campaign → channel (single-hop chain)
    "What campaigns promoted brand BR_001 and which channels were used for each?",

    # 2. Distribution gain — new listings (like 'newly diagnosed' cohort)
    "Which SKUs were newly listed at any retailer for the first time in the last 90 days?",

    # 3. Review sentiment — MENTIONS relationship with NLP score
    "Show me all reviews that mention FreshBrew Bold (SKU_002), with the sentiment and aspect.",

    # 4. Consumer comorbidity — segments that purchase both FreshBrew Original and NutriBar
    "Which consumer segments purchase both FreshBrew Original (SKU_001) and NutriBar Chocolate Crunch (SKU_004)?",

    # 5. Full brand snapshot — deepest multi-hop traversal
    "Give me a complete brand snapshot for BR_001: all campaigns with channels, markets, "
    "sales lifts (ROI and lift %), and which SKUs were supported.",
]


# -------------------------------------------------------
# 6) CLI entry point
# -------------------------------------------------------
def main() -> None:
    print("c5i CPG Analytics: NL → Cypher (Azure OpenAI)\n")
    print("Pre-built questions (press Enter to use, or type your own):")
    for i, q in enumerate(DEMO_QUESTIONS, 1):
        display = q if len(q) <= 90 else q[:87] + "..."
        print(f"  [{i}] {display}")

    print()
    raw = input("Enter a number (1-5) or type your own question: ").strip()
    if not raw:
        print("No question provided.")
        return

    if raw.isdigit() and 1 <= int(raw) <= len(DEMO_QUESTIONS):
        question = DEMO_QUESTIONS[int(raw) - 1]
        print(f"\nUsing: {question}")
    else:
        question = raw

    cypher = generate_cypher(question)
    if cypher is None:
        return

    print("\n--- Generated Cypher ---")
    print("Set parameters as needed, e.g.: :params { brand_id: 'BR_001' }")
    print(cypher)


if __name__ == "__main__":
    main()
