from neo4j import GraphDatabase
from dotenv import load_dotenv
import os


# NOTE: If you are running into connection issues, try the following:
# If SSL Cert validation issue, replace "neo4j://" with "neo4j+ssc://" in your NEO4J_URI 
# to skip cert verification (dev only, not recommended for production).


load_dotenv()  # loads variables from .env


NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USER = os.getenv("NEO4J_USER")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")

def test_connection():
    if not all([NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD]):
        raise ValueError("❌ Missing one or more Neo4j env variables")

    # Default driver — uses settings from the URI scheme (see comments above).
    #
    # To disable certificate verification (self-signed certs / dev environments):
    #   import neo4j
    #   driver = GraphDatabase.driver(NEO4J_URI, auth=(...),
    #       trusted_certificates=neo4j.TrustAll())
    #
    # To pin a custom CA certificate:
    #   driver = GraphDatabase.driver(NEO4J_URI, auth=(...),
    #       trusted_certificates=neo4j.TrustCustomCAs("/path/to/ca.pem"))
    #
    # To set a connection timeout (default is 30 s):
    #   driver = GraphDatabase.driver(NEO4J_URI, auth=(...), connection_timeout=10)
    driver = GraphDatabase.driver(
        NEO4J_URI,
        auth=(NEO4J_USER, NEO4J_PASSWORD)
    )

    try:
        with driver.session() as session:
            record = session.run("RETURN 1 AS ok").single()
            print("✅ Neo4j connection successful:", record["ok"])
    except Exception as e:
        # Common error messages and fixes:
        #   "Unable to retrieve routing information" → wrong URI scheme or host unreachable;
        #       try replacing neo4j:// with bolt:// for single-instance servers
        #   "certificate verify failed" → see SSL tips at top of file
        #   "authentication failure" → wrong NEO4J_USER / NEO4J_PASSWORD in .env
        #   "Connection refused" → Neo4j is not running, or wrong port (default bolt: 7687)
        #   "ServiceUnavailable: Failed to establish connection" → firewall blocking port 7687
        print("❌ Neo4j connection failed. If SSL Cert validation is the issue, try replacing 'neo4j://' with 'neo4j+ssc://' in your NEO4J_URI to skip cert verification (dev only, not recommended for production).")
        print(e)
    finally:
        driver.close()

if __name__ == "__main__":
    test_connection()
