import os
from openai import AzureOpenAI
from dotenv import load_dotenv

## Obtain the endpoint and API key, API version from the "Details" tab in the Azure Foundry portal > Models.
def validate_environment_variables():
    """Validate that all required environment variables are loaded from .env file."""
    required_env_vars = [
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_MODEL_NAME",
        "AZURE_OPENAI_API_VERSION",
    ]

    missing_vars = [var for var in required_env_vars if not os.getenv(var)]

    if missing_vars:
        print("ERROR: Missing required environment variables:")
        for var in missing_vars:
            print(f"  - {var}")
        print("\nPlease ensure all required variables are set in your .env file.")
        exit(1)

    print("✓ All required environment variables are loaded successfully.")


def query_azure_openai(prompt):
    """Query Azure OpenAI API with the given prompt."""
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    )
    model_name = os.getenv("AZURE_OPENAI_MODEL_NAME")

    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": "You are a helpful AI assistant"},
                {"role": "user", "content": prompt}
            ]
        )
        answer = response.choices[0].message.content.strip()
    except Exception as e:
        print(f"ERROR: {e}")
        return None

    print("Prompt:")
    print(prompt)
    print("Response from LLM:")
    print(answer)
    return answer

### MAIN EXECUTION ###

load_dotenv()
validate_environment_variables()
prompt = (
    "You are a CPG analytics advisor at c5i.ai. "
    "A brand manager asks: 'Our FreshBrew Bold digital campaign delivered 18.7% sales lift and 4.1x ROI. "
    "How does this compare to industry benchmarks for digital-only CPG campaigns, "
    "and what would you recommend for the next planning cycle?'"
)
query_azure_openai(prompt)

