// For LLM to be able to generate cypher query from Natural Language question, it needs to know the schema of the neo4j database.
// Since neo4j is schema-less, use the following to obtain the schema information:
// node labels, relationship types, properties on them and relations between them. 

//copy paste the schema JSON output from the neo4j queries below, into the prompt for LLM


//Option 1: Use apoc procedures to fetch the schema information
CALL apoc.meta.schema()
YIELD value
RETURN value;

//Option 2: Use built-in commands to fetch constraints and indexes
CALL db.labels() YIELD label
WITH collect(label) AS labels
CALL db.relationshipTypes() YIELD relationshipType
WITH labels, collect(relationshipType) AS relTypes
CALL db.schema.nodeTypeProperties()
YIELD nodeType, propertyName, propertyTypes, mandatory
WITH labels, relTypes,
     collect({
       nodeType: nodeType,
       property: propertyName,
       types: propertyTypes,
       mandatory: mandatory
     }) AS nodeProps
CALL db.schema.relTypeProperties()
YIELD relType, propertyName, propertyTypes, mandatory
WITH labels, relTypes, nodeProps,
     collect({
       relType: relType,
       property: propertyName,
       types: propertyTypes,
       mandatory: mandatory
     }) AS relProps
CALL db.schema.visualization()
YIELD nodes, relationships
RETURN {
  labels: labels,
  relationshipTypes: relTypes,
  nodeTypeProperties: nodeProps,
  relTypeProperties: relProps,
  connectivity: {nodes: nodes, relationships: relationships}
} AS schema;



SHOW CONSTRAINTS;
SHOW INDEXES;
