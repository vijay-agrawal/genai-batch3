// =====================================================
// c5i.ai CPG Brand & Digital Shelf Analytics — Cypher Query Library
// Run against: 01create_c5i_cpg_db.cypher dataset
// Neo4j Browser: https://console.neo4j.io/
// =====================================================


// 1. Brand "Campaign Attribution Snapshot"
// "Give me everything relevant about FreshBrew Coffee before the brand review."
// Why graph: multi-hop Brand ← Campaign → Channel + Market + SKU in one traversal
:param bid => 'BR_001'
MATCH (b:Brand {brand_id:$bid})<-[:PROMOTES]-(c:Campaign)
OPTIONAL MATCH (c)-[uc:USES_CHANNEL]->(ch:Channel)
OPTIONAL MATCH (c)-[:TARGETS_MARKET]->(mk:Market)
OPTIONAL MATCH (c)-[dl:DROVE_LIFT]->(s:SKU)<-[:HAS_SKU]-(b)
WITH b, c,
     collect(DISTINCT {channel_id:ch.channel_id, name:ch.name, type:ch.type,
                       spend:uc.spend, impressions:uc.impressions}) AS channels,
     collect(DISTINCT {market_id:mk.market_id, name:mk.name, region:mk.region}) AS markets,
     collect(DISTINCT {sku_id:s.sku_id, name:s.name, lift_pct:dl.sales_lift_pct, roi:dl.roi}) AS lifts
ORDER BY c.start_date DESC
WITH b, collect({
  campaign_id:c.campaign_id, name:c.name, start_date:c.start_date, end_date:c.end_date,
  budget:c.budget, objective:c.objective,
  channels:channels, markets:markets, sales_lifts:lifts
}) AS campaigns
RETURN {
  brand: {brand_id:b.brand_id, name:b.name, category:b.category, manufacturer:b.manufacturer},
  campaigns: campaigns
} AS brand_snapshot;


// 2. "Distribution Gain" — SKUs with first-ever retail listing in last 90 days
// "Which SKUs gained new distribution recently?"
// Mirrors clinical "newly diagnosed" — first-ever occurrence detection across retail landscape
// Why graph: detects *first* listing across all retailer links, not just date filtering
MATCH (s:SKU)-[la:LISTED_AT]->(r:Retailer)
WHERE la.listed_since >= date() - duration('P90D')
WITH s, min(la.listed_since) AS first_list_date
OPTIONAL MATCH (s)-[la2:LISTED_AT]->(r2:Retailer)
WHERE la2.listed_since < first_list_date
WITH s, first_list_date, count(la2) AS prior_count
WHERE prior_count = 0
MATCH (b:Brand)-[:HAS_SKU]->(s)
RETURN s.sku_id AS sku_id, s.name AS sku_name, b.name AS brand, first_list_date
ORDER BY first_list_date DESC;


// 3. Digital Shelf Alert: SKUs with distribution below 50% at key retailers (last 30 days)
// "Which SKUs have weak shelf presence right now?"
// Use: c5i Compete digital shelf monitoring — identify SKUs needing trade investment
MATCH (s:SKU)-[la:LISTED_AT]->(r:Retailer)
WHERE la.listed_since >= date() - duration('P30D')
   OR la.distribution_pct < 50.0
RETURN s.sku_id, s.name AS sku_name, r.retailer_id, r.name AS retailer,
       la.distribution_pct, la.shelf_position, la.avg_price
ORDER BY la.distribution_pct ASC;


// 4. High-ROI campaigns: campaigns delivering ROI > 3× in last 180 days
// "Which campaigns are our best performers? Who prescribes the most?"
// Use: MMM model outputs — identify what media is working
// Requires relationship property filtering (DROVE_LIFT.roi) + temporal filter
MATCH (c:Campaign)-[dl:DROVE_LIFT]->(s:SKU)<-[:HAS_SKU]-(b:Brand)
WHERE c.start_date >= date() - duration('P180D')
  AND dl.roi > 3.0
RETURN c.campaign_id, c.name AS campaign, b.name AS brand, s.sku_id, s.name AS sku,
       dl.sales_lift_pct AS lift_pct, dl.roi,
       dl.attributed_revenue AS attributed_revenue
ORDER BY dl.roi DESC;


// 5. Retailer-level: top SKUs by distribution % across all retailers
// "What is our distribution footprint by retailer right now?"
// Use: operational planning, retail account management, distribution analytics
// Graph: aggregates across Brand → SKU → Retailer links without complex joins
MATCH (r:Retailer)<-[la:LISTED_AT]-(s:SKU)<-[:HAS_SKU]-(b:Brand)
WITH r, b, s, la
ORDER BY la.distribution_pct DESC
RETURN r.retailer_id, r.name AS retailer, r.channel_type,
       b.brand_id, b.name AS brand,
       s.sku_id, s.name AS sku_name,
       la.distribution_pct, la.avg_price
LIMIT 15;


// 6. Channel attribution pattern: how do campaigns use channels for each brand?
// "How are we investing in media for FreshBrew vs NutriBar?"
// Use: media planning, channel mix optimization — c5i MMM
// Traverses Campaign → Channel (with spend) + Brand, exposes media mix variation
MATCH (c:Campaign)-[uc:USES_CHANNEL]->(ch:Channel)
MATCH (c)-[:PROMOTES]->(b:Brand)
OPTIONAL MATCH (c)-[dl:DROVE_LIFT]->(s:SKU)
WITH b, ch, c, uc,
     collect(DISTINCT {sku_id:s.sku_id, lift_pct:dl.sales_lift_pct, roi:dl.roi}) AS lifts,
     count(dl) AS lift_count
ORDER BY uc.spend DESC
RETURN b.brand_id, b.name AS brand, ch.channel_id, ch.name AS channel, ch.type AS channel_type,
       c.campaign_id, c.name AS campaign, uc.spend, uc.impressions, uc.grps, lift_count
LIMIT 20;


// 7. Review sentiment: FreshBrew Original (SKU_001) review mentions with NLP scores
// "What are customers saying about FreshBrew Original? Any negative sentiment trends?"
// Use: c5i Compete digital shelf — review monitoring, VOCI (Voice of Consumer Insights)
// Direct linkage via MENTIONS relationship with sentiment + aspect properties
MATCH (rv:Review)-[mn:MENTIONS]->(s:SKU {sku_id:'SKU_001'})
RETURN rv.review_id, rv.source, rv.rating,
       substring(rv.text, 0, 200) AS review_snippet,
       mn.sentiment, mn.score, mn.aspect
ORDER BY mn.score DESC;


// 8. Multi-channel campaigns: which campaigns used BOTH TV AND Digital?
// "Which campaigns had a full-funnel media mix?"
// Comorbidity equivalent — meets at Campaign node that links to both channel types
// Use: full-funnel analysis, media synergy measurement
MATCH (c:Campaign)-[:USES_CHANNEL]->(ch1:Channel {type:'TV'}),
      (c)-[:USES_CHANNEL]->(ch2:Channel {type:'Digital'})
MATCH (c)-[:PROMOTES]->(b:Brand)
RETURN c.campaign_id, c.name AS campaign, b.name AS brand,
       c.budget, c.objective, c.start_date, c.end_date
ORDER BY c.start_date DESC;


// 9. Data quality: SKUs listed at retailers with NO campaign supporting them
// "Which SKUs are on shelf but have no media behind them?"
// Equivalent to "encounters with meds but no diagnosis" — detect missing links
// Use: portfolio coverage gap analysis, prioritize under-supported SKUs
MATCH (s:SKU)-[:LISTED_AT]->(r:Retailer)
WHERE NOT (s)<-[:DROVE_LIFT]-(:Campaign)
MATCH (b:Brand)-[:HAS_SKU]->(s)
RETURN s.sku_id, s.name AS sku_name, b.name AS brand, r.name AS retailer
ORDER BY s.sku_id;


// 10. Consumer engagement: SKU purchase frequency per segment in last year
// "Which consumer segments are most engaged with our portfolio?"
// Use: customer analytics, loyalty insights — c5i customer analytics offering
MATCH (sg:ConsumerSegment)-[pch:PURCHASES]->(s:SKU)<-[:HAS_SKU]-(b:Brand)
RETURN sg.segment_id, sg.name AS segment, sg.persona, b.name AS brand,
       s.sku_id, s.name AS sku_name,
       pch.purchase_frequency, pch.avg_basket_size
ORDER BY sg.segment_id, pch.avg_basket_size DESC;


// 11. Path traversal: Attribution path from Campaign to Retailers (3–5 hops)
// "Show me the full marketing-to-shelf pathway for CAMP_002."
// Use: explainability — how did this campaign reach consumers at which retailers?
Parameters {
  cid: 'CAMP_002'
};
MATCH (c:Campaign {campaign_id:$cid})
MATCH path = (c)-[:PROMOTES|USES_CHANNEL|TARGETS_MARKET|DROVE_LIFT|LISTED_AT|AT_RETAILER*2..5]->(x)
RETURN path
LIMIT 30;
// Use Neo4j Browser for visual path inspection


// 12. Brand portfolio similarity by shared channels + markets (Jaccard)
// "Which brands have a similar media + geographic footprint to BR_001?"
// Use: competitive benchmarking, planning analogues, budget allocation decisions
Parameters {
  bid: 'BR_001'
};
MATCH (b0:Brand {brand_id:$bid})<-[:PROMOTES]-(c0:Campaign)
OPTIONAL MATCH (c0)-[:USES_CHANNEL]->(ch0:Channel)
OPTIONAL MATCH (c0)-[:TARGETS_MARKET]->(mk0:Market)
WITH b0,
     collect(DISTINCT ch0.channel_id) AS b0_channels,
     collect(DISTINCT mk0.market_id) AS b0_markets

MATCH (b:Brand)<-[:PROMOTES]-(c:Campaign)
WHERE b <> b0
OPTIONAL MATCH (c)-[:USES_CHANNEL]->(ch:Channel)
OPTIONAL MATCH (c)-[:TARGETS_MARKET]->(mk:Market)
WITH b0, b0_channels, b0_markets, b,
     collect(DISTINCT ch.channel_id) AS channels,
     collect(DISTINCT mk.market_id) AS markets

WITH b, b0_channels, b0_markets, channels, markets,
     apoc.coll.toSet(b0_channels + b0_markets) AS A,
     apoc.coll.toSet(channels + markets) AS B
WITH b, A, B,
     size(apoc.coll.intersection(A,B)) AS inter,
     size(apoc.coll.toSet(A + B)) AS uni
WHERE uni > 0
RETURN b.brand_id, b.name AS brand,
       (1.0*inter/uni) AS jaccard_similarity,
       apoc.coll.intersection(A,B) AS shared_channels_markets
ORDER BY jaccard_similarity DESC
LIMIT 10;


// 13. Write: Add a new campaign + channel allocation + market target (real ingest)
// "A new Q3 campaign was just approved — add it to the graph."
Parameters {
  bid: 'BR_001',
  cid: 'CAMP_005',
  name: 'FreshBrew Summer Push',
  start: '2026-06-01',
  end: '2026-08-31',
  budget: 600000,
  objective: 'awareness',
  channel_id: 'CH_002',
  spend: 350000,
  impressions: 15000000,
  market_id: 'MKT_003'
};

MATCH (b:Brand {brand_id:$bid})
MERGE (c:Campaign {campaign_id:$cid})
ON CREATE SET c.name=$name, c.start_date=date($start), c.end_date=date($end),
              c.budget=$budget, c.objective=$objective
MERGE (c)-[:PROMOTES]->(b)

MATCH (ch:Channel {channel_id:$channel_id})
MERGE (c)-[uc:USES_CHANNEL]->(ch)
SET uc.spend=$spend, uc.impressions=$impressions

MATCH (mk:Market {market_id:$market_id})
MERGE (c)-[:TARGETS_MARKET]->(mk)

RETURN b.brand_id, c.campaign_id, ch.name AS channel, mk.name AS market;


// 14. Delete: Remove a review (GDPR / data quality cleanup)
Parameters {
  review_id: 'REV_004'
};
MATCH (rv:Review {review_id:$review_id})
DETACH DELETE rv
RETURN 'Deleted review ' + $review_id AS result;


// 15. Aggregate: Total spend and average ROI by channel type (MMM summary)
// "What is our total media investment and efficiency by channel?"
// Use: c5i Marketing Mix Model readout — budget allocation decisions
MATCH (c:Campaign)-[uc:USES_CHANNEL]->(ch:Channel)
OPTIONAL MATCH (c)-[dl:DROVE_LIFT]->(:SKU)
WITH ch.type AS channel_type, ch.name AS channel_name,
     sum(uc.spend) AS total_spend,
     avg(dl.roi) AS avg_roi,
     count(DISTINCT c) AS campaign_count
RETURN channel_type, channel_name, total_spend, round(avg_roi*100)/100 AS avg_roi,
       campaign_count
ORDER BY total_spend DESC;


// 16. Review evidence: confirmed campaign lift vs review sentiment for SKU_002
// "Does FreshBrew Bold have campaign lift backing its shelf performance? What do reviews say?"
// Separates hard MMM attribution evidence from softer consumer NLP signals
// Core GraphRAG grounding pattern — two evidence streams in one query
Parameters { sku_id: 'SKU_002' };
MATCH (s:SKU {sku_id:$sku_id})
OPTIONAL MATCH (c:Campaign)-[dl:DROVE_LIFT]->(s)
OPTIONAL MATCH (rv:Review)-[:ABOUT_SKU]->(s)
OPTIONAL MATCH (rv)-[mn:MENTIONS]->(s)
WITH s, c, dl, rv, mn
ORDER BY coalesce(c.start_date, date('2000-01-01')) DESC
WITH s,
     collect(DISTINCT {campaign_id:c.campaign_id, name:c.name,
                       lift_pct:dl.sales_lift_pct, roi:dl.roi}) AS lift_evidence,
     collect(DISTINCT {review_id:rv.review_id, rating:rv.rating,
                       snippet:substring(rv.text,0,180),
                       sentiment:mn.sentiment, score:mn.score, aspect:mn.aspect}) AS review_evidence
RETURN {
  sku_id: s.sku_id,
  sku_name: s.name,
  lift_evidence: lift_evidence,
  review_evidence: [r IN review_evidence WHERE r.review_id IS NOT NULL]
} AS sku_evidence;


// 17. Fix duplicate brand nodes (real-world ingestion cleanup using APOC)
// Use: normalise inconsistent brand names ingested from multiple data sources
// APOC required: CALL apoc.version() to check availability
MATCH (b:Brand)
WHERE toLower(b.name) IN ['freshbrew', 'fresh brew coffee', 'freshbrew coffee']
WITH collect(b) AS brands
CALL apoc.refactor.mergeNodes(brands, {properties:'discard', mergeRels:true}) YIELD node
SET node.brand_id = 'BR_001', node.name = 'FreshBrew Coffee'
RETURN node;


// 18. Consumer + retailer overlap: which segments shop at retailers
//     where a SKU has distribution gaps (below 50%)?
// "Which high-value segments are we losing due to poor shelf coverage?"
// Use: consumer-to-distribution gap linkage — actionable trade investment brief
// Why graph: connects Consumer → Retailer → SKU distribution in one traversal
MATCH (sg:ConsumerSegment)-[:SHOPS_AT]->(r:Retailer)<-[la:LISTED_AT]-(s:SKU)
WHERE la.distribution_pct < 50.0
MATCH (b:Brand)-[:HAS_SKU]->(s)
RETURN sg.segment_id, sg.name AS segment, sg.income_tier,
       r.name AS retailer, s.name AS sku_name, b.name AS brand,
       la.distribution_pct AS distribution_pct
ORDER BY sg.income_tier DESC, la.distribution_pct ASC;
