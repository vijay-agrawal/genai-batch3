// =====================================================
// c5i.ai CPG Brand & Digital Shelf Analytics Graph
// =====================================================
//
// USE-CASE
// --------
// c5i.ai serves Fortune 500 CPG clients (e.g. GlobalCPG Inc.) who need to
// understand *why* their brands grow or decline by connecting data across
// four traditionally siloed domains:
//
//   1. Marketing Mix Modelling (MMM)  — which campaigns, channels, and
//      markets drove incremental sales lift and ROI for each SKU.
//   2. Digital Shelf / Compete       — retailer distribution, shelf position,
//      pricing, and consumer review sentiment per SKU.
//   3. Consumer Segmentation          — which shopper personas buy which SKUs,
//      at which retailers, and at what frequency.
//   4. Trade Promotions               — which discounts were applied to which
//      SKUs at which retailers and when.
//
// A brand manager's typical question cuts across ALL four domains, e.g.:
//   "For FreshBrew Bold, which campaign drove the highest ROI,
//    which consumer segment buys it most often, what do reviews say
//    about it, and where is it under-distributed?"
//
//
// KEY ENTITIES (Nodes)
// --------------------
//   Brand           — a brand family (e.g. FreshBrew Coffee)
//   SKU             — a specific product variant with UPC (e.g. FreshBrew Bold 12-ct)
//   Campaign        — a marketing campaign with budget, dates, and objective
//   Channel         — a media channel used for advertising (TV, Digital, Shopper, OOH)
//   Market          — a geographic DMA (Designated Market Area)
//   Retailer        — a trade customer / store banner (MegaMart, FreshGrocer, QuickMart)
//   ConsumerSegment — a shopper persona defined by demographics and buying behaviour
//   Review          — a consumer review from a digital shelf source (Amazon, Walmart.com)
//   Promotion       — a trade promotion (BOGO, TPR) applied to a SKU at a retailer
//
//
// KEY RELATIONSHIPS (Edges)
// -------------------------
//   Brand     -[HAS_SKU]->        SKU          brand owns its product variants
//   Campaign  -[PROMOTES]->       Brand        campaign is scoped to a brand
//   Campaign  -[USES_CHANNEL]->   Channel      spend, impressions, GRPs per channel
//   Campaign  -[TARGETS_MARKET]-> Market       geographic reach of the campaign
//   Campaign  -[DROVE_LIFT]->     SKU          MMM attribution: lift%, ROI, revenue
//   SKU       -[LISTED_AT]->      Retailer     distribution, shelf position, avg price
//   ConsumerSeg-[PURCHASES]->     SKU          purchase frequency, basket size
//   ConsumerSeg-[SHOPS_AT]->      Retailer     preferred retailer per segment
//   Review    -[ABOUT_SKU]->      SKU          review is for a specific SKU
//   Review    -[MENTIONS]->       SKU/Brand    NLP-tagged sentiment, score, aspect
//   Promotion -[APPLIED_TO]->     SKU          promo targets a specific SKU
//   Promotion -[AT_RETAILER]->    Retailer     promo runs at a specific retailer
//
//
// WHY A KNOWLEDGE GRAPH — NOT SQL OR VECTOR DB?
// -----------------------------------------------
// The core analytical questions require traversing 4-6 hops across heterogeneous
// entities in a single query. This is where graphs outperform the alternatives:
//
//   vs. SQL (relational):
//     The query "campaign → channel → market → SKU lift → retailer distribution
//     → consumer segment → review sentiment" requires 6+ JOINs across 9 tables.
//     SQL performance degrades with join depth; schema changes (e.g. adding a new
//     relationship type) require ALTER TABLE and migration. In a graph, adding a
//     new relationship type is a single CREATE and requires no schema change.
//     Relationship properties (spend, lift_pct, roi on edges) are first-class in
//     Neo4j; in SQL they require bridge tables with composite keys.
//
//   vs. Vector DB (RAG / semantic search):
//     Vector DBs excel at fuzzy retrieval — finding the most semantically similar
//     documents to a query. But CPG analytics questions are *structural*, not
//     semantic: "Which SKUs does CAMP_001 drive lift for, and what is the ROI?"
//     has an exact, deterministic answer that lives in relationships, not embeddings.
//     A vector DB has no native concept of traversal or path; you would need to
//     embed and retrieve entire subgraphs, losing precision and explainability.
//     Graphs also make attribution chains auditable — you can show exactly which
//     edges justify an answer, which is critical for client-facing MMM reporting.
//
//   Where graphs win in this domain:
//     • Multi-hop traversal is native (Cypher pattern matching vs. recursive SQL CTEs)
//     • Relationship properties carry MMM outputs (ROI, lift) without bridge tables
//     • Schema flexibility: add ConsumerJourney or CompetitorBrand nodes with no migration
//     • NL → Cypher is more reliable than NL → SQL for path queries because
//       Cypher maps directly to the mental model of the analyst ("campaign drove lift on SKU")
//     • Graph visualisation makes brand-campaign-retail networks immediately interpretable
//       to non-technical CPG stakeholders
//
//
// Load order:
//   1) Wipe data (optional)
//   2) Constraints + indexes (schema first)
//   3) Nodes
//   4) Relationships
// =====================================================

// HOW TO RUN?
// Goto https://console.neo4j.io, create an account with your personal gmail account, 
// Create a free Neo4j AuraDB instance, and run this script in the Cypher query editor.
//

// -----------------------------------------------------
// 0) OPTIONAL: wipe the database (data only, keeps schema)
// -----------------------------------------------------
MATCH (n) DETACH DELETE n;


// -----------------------------------------------------
// 1) CONSTRAINTS (uniqueness / identity)
// -----------------------------------------------------
CREATE CONSTRAINT brand_id IF NOT EXISTS
FOR (b:Brand) REQUIRE b.brand_id IS UNIQUE;

CREATE CONSTRAINT sku_id IF NOT EXISTS
FOR (s:SKU) REQUIRE s.sku_id IS UNIQUE;

CREATE CONSTRAINT sku_upc IF NOT EXISTS
FOR (s:SKU) REQUIRE s.upc IS UNIQUE;

CREATE CONSTRAINT retailer_id IF NOT EXISTS
FOR (r:Retailer) REQUIRE r.retailer_id IS UNIQUE;

CREATE CONSTRAINT channel_id IF NOT EXISTS
FOR (ch:Channel) REQUIRE ch.channel_id IS UNIQUE;

CREATE CONSTRAINT market_id IF NOT EXISTS
FOR (mk:Market) REQUIRE mk.market_id IS UNIQUE;

CREATE CONSTRAINT campaign_id IF NOT EXISTS
FOR (c:Campaign) REQUIRE c.campaign_id IS UNIQUE;

CREATE CONSTRAINT segment_id IF NOT EXISTS
FOR (sg:ConsumerSegment) REQUIRE sg.segment_id IS UNIQUE;

CREATE CONSTRAINT review_id IF NOT EXISTS
FOR (rv:Review) REQUIRE rv.review_id IS UNIQUE;

CREATE CONSTRAINT promo_id IF NOT EXISTS
FOR (pr:Promotion) REQUIRE pr.promo_id IS UNIQUE;


// -----------------------------------------------------
// 2) INDEXES (search / filtering)
// -----------------------------------------------------
CREATE INDEX brand_name IF NOT EXISTS
FOR (b:Brand) ON (b.name);

CREATE INDEX sku_name IF NOT EXISTS
FOR (s:SKU) ON (s.name);

CREATE INDEX campaign_start_date IF NOT EXISTS
FOR (c:Campaign) ON (c.start_date);

CREATE INDEX review_date IF NOT EXISTS
FOR (rv:Review) ON (rv.date);

CREATE INDEX promo_start_date IF NOT EXISTS
FOR (pr:Promotion) ON (pr.start_date);


// -----------------------------------------------------
// 3) NODES
// -----------------------------------------------------

// 3.1 Brands (two c5i CPG client brand families)
CREATE (:Brand {brand_id:'BR_001', name:'FreshBrew Coffee',  category:'Beverage',          manufacturer:'GlobalCPG Inc.'});
CREATE (:Brand {brand_id:'BR_002', name:'NutriBar',          category:'Health & Nutrition', manufacturer:'GlobalCPG Inc.'});


// 3.2 SKUs (product variants)
// BR_001 SKUs — established + newly launched
CREATE (:SKU {sku_id:'SKU_001', name:'FreshBrew Original Pods 12-ct',  pack_size:'12-ct', upc:'UPC_100001'});
CREATE (:SKU {sku_id:'SKU_002', name:'FreshBrew Bold Pods 12-ct',      pack_size:'12-ct', upc:'UPC_100002'});
CREATE (:SKU {sku_id:'SKU_003', name:'FreshBrew Decaf Pods 12-ct',     pack_size:'12-ct', upc:'UPC_100003'});
CREATE (:SKU {sku_id:'SKU_006', name:'FreshBrew Extra Bold Pods 24-ct',pack_size:'24-ct', upc:'UPC_100004'}); // newly listed
// BR_002 SKUs
CREATE (:SKU {sku_id:'SKU_004', name:'NutriBar Chocolate Crunch 6-pk', pack_size:'6-pk',  upc:'UPC_200001'});
CREATE (:SKU {sku_id:'SKU_005', name:'NutriBar Vanilla Almond 6-pk',   pack_size:'6-pk',  upc:'UPC_200002'}); // newly listed


// 3.3 Retailers (trade channels c5i's CPG clients sell through)
CREATE (:Retailer {retailer_id:'RET_001', name:'MegaMart',    banner:'MegaMart Supercenter', channel_type:'mass'});
CREATE (:Retailer {retailer_id:'RET_002', name:'FreshGrocer', banner:'FreshGrocer',          channel_type:'grocery'});
CREATE (:Retailer {retailer_id:'RET_003', name:'QuickMart',   banner:'QuickMart Pharmacy',   channel_type:'drug'});


// 3.4 Media Channels (used in Marketing Mix Models)
CREATE (:Channel {channel_id:'CH_001', name:'Television',        type:'TV'});
CREATE (:Channel {channel_id:'CH_002', name:'Digital & Social',  type:'Digital'});
CREATE (:Channel {channel_id:'CH_003', name:'Shopper Marketing', type:'Shopper'});
CREATE (:Channel {channel_id:'CH_004', name:'Out-of-Home',       type:'OOH'});


// 3.5 Markets (geographic DMAs — core c5i MMM geography)
CREATE (:Market {market_id:'MKT_001', name:'New York Metro',    region:'Northeast', dma_code:'DMA_501'});
CREATE (:Market {market_id:'MKT_002', name:'Chicago Metro',     region:'Midwest',   dma_code:'DMA_602'});
CREATE (:Market {market_id:'MKT_003', name:'Los Angeles Metro', region:'West',      dma_code:'DMA_803'});


// 3.6 Campaigns (dates anchored so 90-day window from 2026-05-11 = 2026-02-10+)
// CAMP_001 & CAMP_002 are within 90 days; CAMP_003 is older; CAMP_004 is most recent
CREATE (:Campaign {campaign_id:'CAMP_001', name:'FreshBrew Q1 Brand Launch',    start_date:date('2026-01-15'), end_date:date('2026-03-31'), budget:700000,  objective:'awareness'});
CREATE (:Campaign {campaign_id:'CAMP_002', name:'FreshBrew Spring Refresh',     start_date:date('2026-03-01'), end_date:date('2026-04-30'), budget:450000,  objective:'conversion'});
CREATE (:Campaign {campaign_id:'CAMP_003', name:'NutriBar Awareness Push',      start_date:date('2025-10-01'), end_date:date('2025-11-30'), budget:520000,  objective:'awareness'});
CREATE (:Campaign {campaign_id:'CAMP_004', name:'FreshBrew Bold Digital Blitz', start_date:date('2026-04-10'), end_date:date('2026-05-20'), budget:250000,  objective:'trial'});


// 3.7 Consumer Segments (c5i customer analytics personas)
CREATE (:ConsumerSegment {segment_id:'SEG_001', name:'Premium Coffee Enthusiasts',  persona:'early adopter',       age_range:'35-54', income_tier:'high'});
CREATE (:ConsumerSegment {segment_id:'SEG_002', name:'Health-Conscious Millennials', persona:'health seeker',        age_range:'25-40', income_tier:'mid'});
CREATE (:ConsumerSegment {segment_id:'SEG_003', name:'Value Seekers',               persona:'deal hunter',          age_range:'30-55', income_tier:'low'});
CREATE (:ConsumerSegment {segment_id:'SEG_004', name:'Competitor Loyalists',        persona:'competitor customer',  age_range:'30-50', income_tier:'mid'});


// 3.8 Reviews (digital shelf reviews — c5i Compete product data)
CREATE (:Review {review_id:'REV_001', text:'FreshBrew Original is my daily go-to — perfect flavor, always consistent.',       rating:5, date:date('2026-03-10'), source:'Amazon'});
CREATE (:Review {review_id:'REV_002', text:'FreshBrew Bold is too intense for me, had to switch back to Original.',           rating:2, date:date('2026-04-05'), source:'Walmart.com'});
CREATE (:Review {review_id:'REV_003', text:'NutriBar Choco Crunch is great pre-workout fuel, love the texture.',              rating:4, date:date('2026-02-28'), source:'Target.com'});
CREATE (:Review {review_id:'REV_004', text:'FreshBrew price went up again — disappointed, might switch brands.',              rating:3, date:date('2026-04-20'), source:'Amazon'});
CREATE (:Review {review_id:'REV_005', text:'NutriBar Vanilla Almond is delicious and actually nutritious — highly recommend.',rating:5, date:date('2026-04-15'), source:'Amazon'});


// 3.9 Promotions (trade promotions — c5i pricing & promo analytics)
CREATE (:Promotion {promo_id:'PROMO_001', name:'FreshBrew BOGO Deal',        type:'BOGO', start_date:date('2026-03-01'), end_date:date('2026-03-31'), discount_pct:50.0});
CREATE (:Promotion {promo_id:'PROMO_002', name:'NutriBar Spring 20% Off',    type:'TPR',  start_date:date('2026-04-01'), end_date:date('2026-04-30'), discount_pct:20.0});


// -----------------------------------------------------
// 4) RELATIONSHIPS
// -----------------------------------------------------

// 4.1 Brand -> HAS_SKU -> SKU
MATCH (b:Brand {brand_id:'BR_001'}), (s:SKU {sku_id:'SKU_001'}) CREATE (b)-[:HAS_SKU]->(s);
MATCH (b:Brand {brand_id:'BR_001'}), (s:SKU {sku_id:'SKU_002'}) CREATE (b)-[:HAS_SKU]->(s);
MATCH (b:Brand {brand_id:'BR_001'}), (s:SKU {sku_id:'SKU_003'}) CREATE (b)-[:HAS_SKU]->(s);
MATCH (b:Brand {brand_id:'BR_001'}), (s:SKU {sku_id:'SKU_006'}) CREATE (b)-[:HAS_SKU]->(s);
MATCH (b:Brand {brand_id:'BR_002'}), (s:SKU {sku_id:'SKU_004'}) CREATE (b)-[:HAS_SKU]->(s);
MATCH (b:Brand {brand_id:'BR_002'}), (s:SKU {sku_id:'SKU_005'}) CREATE (b)-[:HAS_SKU]->(s);


// 4.2 SKU -> LISTED_AT -> Retailer
// Established listings (pre-2026-02-10, outside the 90-day window)
MATCH (s:SKU {sku_id:'SKU_001'}), (r:Retailer {retailer_id:'RET_001'})
CREATE (s)-[:LISTED_AT {listed_since:date('2025-06-01'), shelf_position:'eye level',    distribution_pct:95.0, avg_price:12.99}]->(r);
MATCH (s:SKU {sku_id:'SKU_001'}), (r:Retailer {retailer_id:'RET_002'})
CREATE (s)-[:LISTED_AT {listed_since:date('2025-08-15'), shelf_position:'eye level',    distribution_pct:88.0, avg_price:13.49}]->(r);
MATCH (s:SKU {sku_id:'SKU_001'}), (r:Retailer {retailer_id:'RET_003'})
CREATE (s)-[:LISTED_AT {listed_since:date('2025-09-01'), shelf_position:'mid shelf',    distribution_pct:72.0, avg_price:14.99}]->(r);
MATCH (s:SKU {sku_id:'SKU_002'}), (r:Retailer {retailer_id:'RET_001'})
CREATE (s)-[:LISTED_AT {listed_since:date('2025-07-01'), shelf_position:'mid shelf',    distribution_pct:80.0, avg_price:12.99}]->(r);
MATCH (s:SKU {sku_id:'SKU_002'}), (r:Retailer {retailer_id:'RET_002'})
CREATE (s)-[:LISTED_AT {listed_since:date('2025-10-15'), shelf_position:'bottom shelf', distribution_pct:55.0, avg_price:13.49}]->(r);
MATCH (s:SKU {sku_id:'SKU_003'}), (r:Retailer {retailer_id:'RET_003'})
CREATE (s)-[:LISTED_AT {listed_since:date('2025-11-01'), shelf_position:'bottom shelf', distribution_pct:40.0, avg_price:14.99}]->(r);
MATCH (s:SKU {sku_id:'SKU_004'}), (r:Retailer {retailer_id:'RET_001'})
CREATE (s)-[:LISTED_AT {listed_since:date('2025-08-01'), shelf_position:'eye level',    distribution_pct:85.0, avg_price:7.99}]->(r);
MATCH (s:SKU {sku_id:'SKU_004'}), (r:Retailer {retailer_id:'RET_002'})
CREATE (s)-[:LISTED_AT {listed_since:date('2025-09-15'), shelf_position:'mid shelf',    distribution_pct:75.0, avg_price:8.49}]->(r);
// Newly listed (within 90 days — key for distribution gain queries)
MATCH (s:SKU {sku_id:'SKU_005'}), (r:Retailer {retailer_id:'RET_001'})
CREATE (s)-[:LISTED_AT {listed_since:date('2026-03-01'), shelf_position:'mid shelf',    distribution_pct:35.0, avg_price:8.99}]->(r);
MATCH (s:SKU {sku_id:'SKU_006'}), (r:Retailer {retailer_id:'RET_002'})
CREATE (s)-[:LISTED_AT {listed_since:date('2026-02-20'), shelf_position:'bottom shelf', distribution_pct:28.0, avg_price:18.99}]->(r);


// 4.3 Campaign -> PROMOTES -> Brand
MATCH (c:Campaign {campaign_id:'CAMP_001'}), (b:Brand {brand_id:'BR_001'}) CREATE (c)-[:PROMOTES]->(b);
MATCH (c:Campaign {campaign_id:'CAMP_002'}), (b:Brand {brand_id:'BR_001'}) CREATE (c)-[:PROMOTES]->(b);
MATCH (c:Campaign {campaign_id:'CAMP_003'}), (b:Brand {brand_id:'BR_002'}) CREATE (c)-[:PROMOTES]->(b);
MATCH (c:Campaign {campaign_id:'CAMP_004'}), (b:Brand {brand_id:'BR_001'}) CREATE (c)-[:PROMOTES]->(b);


// 4.4 Campaign -> USES_CHANNEL -> Channel (with spend/impressions/GRPs — MMM inputs)
MATCH (c:Campaign {campaign_id:'CAMP_001'}), (ch:Channel {channel_id:'CH_001'})
CREATE (c)-[:USES_CHANNEL {spend:500000, grps:120.0,  impressions:null}]->(ch);
MATCH (c:Campaign {campaign_id:'CAMP_001'}), (ch:Channel {channel_id:'CH_002'})
CREATE (c)-[:USES_CHANNEL {spend:200000, grps:null,   impressions:5000000}]->(ch);
MATCH (c:Campaign {campaign_id:'CAMP_002'}), (ch:Channel {channel_id:'CH_002'})
CREATE (c)-[:USES_CHANNEL {spend:300000, grps:null,   impressions:8000000}]->(ch);
MATCH (c:Campaign {campaign_id:'CAMP_002'}), (ch:Channel {channel_id:'CH_003'})
CREATE (c)-[:USES_CHANNEL {spend:150000, grps:null,   impressions:null}]->(ch);
MATCH (c:Campaign {campaign_id:'CAMP_003'}), (ch:Channel {channel_id:'CH_001'})
CREATE (c)-[:USES_CHANNEL {spend:400000, grps:80.0,   impressions:null}]->(ch);
MATCH (c:Campaign {campaign_id:'CAMP_003'}), (ch:Channel {channel_id:'CH_004'})
CREATE (c)-[:USES_CHANNEL {spend:120000, grps:null,   impressions:null}]->(ch);
MATCH (c:Campaign {campaign_id:'CAMP_004'}), (ch:Channel {channel_id:'CH_002'})
CREATE (c)-[:USES_CHANNEL {spend:250000, grps:null,   impressions:12000000}]->(ch);


// 4.5 Campaign -> TARGETS_MARKET -> Market
MATCH (c:Campaign {campaign_id:'CAMP_001'}), (mk:Market {market_id:'MKT_001'}) CREATE (c)-[:TARGETS_MARKET]->(mk);
MATCH (c:Campaign {campaign_id:'CAMP_001'}), (mk:Market {market_id:'MKT_002'}) CREATE (c)-[:TARGETS_MARKET]->(mk);
MATCH (c:Campaign {campaign_id:'CAMP_002'}), (mk:Market {market_id:'MKT_001'}) CREATE (c)-[:TARGETS_MARKET]->(mk);
MATCH (c:Campaign {campaign_id:'CAMP_002'}), (mk:Market {market_id:'MKT_002'}) CREATE (c)-[:TARGETS_MARKET]->(mk);
MATCH (c:Campaign {campaign_id:'CAMP_002'}), (mk:Market {market_id:'MKT_003'}) CREATE (c)-[:TARGETS_MARKET]->(mk);
MATCH (c:Campaign {campaign_id:'CAMP_003'}), (mk:Market {market_id:'MKT_002'}) CREATE (c)-[:TARGETS_MARKET]->(mk);
MATCH (c:Campaign {campaign_id:'CAMP_003'}), (mk:Market {market_id:'MKT_003'}) CREATE (c)-[:TARGETS_MARKET]->(mk);
MATCH (c:Campaign {campaign_id:'CAMP_004'}), (mk:Market {market_id:'MKT_001'}) CREATE (c)-[:TARGETS_MARKET]->(mk);
MATCH (c:Campaign {campaign_id:'CAMP_004'}), (mk:Market {market_id:'MKT_003'}) CREATE (c)-[:TARGETS_MARKET]->(mk);


// 4.6 Campaign -> DROVE_LIFT -> SKU (MMM attribution outputs)
// DROVE_LIFT = Marketing Mix Model (MMM) attribution result.
// It records the incremental sales impact a campaign caused on a specific SKU,
// as measured after the campaign runs (not a forecast).
//   sales_lift_pct    : % increase in SKU unit sales attributable to this campaign
//   roi               : revenue returned per $1 of campaign spend on that SKU
//   attributed_revenue: total incremental $ revenue credited to the campaign for that SKU
// One campaign can DROVE_LIFT multiple SKUs (e.g. a brand campaign lifts all its SKUs)
// and one SKU can be lifted by multiple campaigns (one edge per campaign–SKU pair).
MATCH (c:Campaign {campaign_id:'CAMP_001'}), (s:SKU {sku_id:'SKU_001'})
CREATE (c)-[:DROVE_LIFT {sales_lift_pct:12.5, roi:2.8, attributed_revenue:1250000}]->(s);
MATCH (c:Campaign {campaign_id:'CAMP_001'}), (s:SKU {sku_id:'SKU_002'})
CREATE (c)-[:DROVE_LIFT {sales_lift_pct:8.2,  roi:1.9, attributed_revenue:520000}]->(s);
MATCH (c:Campaign {campaign_id:'CAMP_002'}), (s:SKU {sku_id:'SKU_001'})
CREATE (c)-[:DROVE_LIFT {sales_lift_pct:7.5,  roi:2.1, attributed_revenue:680000}]->(s);
MATCH (c:Campaign {campaign_id:'CAMP_002'}), (s:SKU {sku_id:'SKU_002'})
CREATE (c)-[:DROVE_LIFT {sales_lift_pct:15.3, roi:3.2, attributed_revenue:820000}]->(s);
MATCH (c:Campaign {campaign_id:'CAMP_003'}), (s:SKU {sku_id:'SKU_004'})
CREATE (c)-[:DROVE_LIFT {sales_lift_pct:10.1, roi:2.3, attributed_revenue:920000}]->(s);
MATCH (c:Campaign {campaign_id:'CAMP_004'}), (s:SKU {sku_id:'SKU_002'})
CREATE (c)-[:DROVE_LIFT {sales_lift_pct:18.7, roi:4.1, attributed_revenue:960000}]->(s);


// 4.7 ConsumerSegment -> PURCHASES -> SKU (c5i customer analytics)
MATCH (sg:ConsumerSegment {segment_id:'SEG_001'}), (s:SKU {sku_id:'SKU_001'})
CREATE (sg)-[:PURCHASES {purchase_frequency:'weekly',    avg_basket_size:3}]->(s);
MATCH (sg:ConsumerSegment {segment_id:'SEG_001'}), (s:SKU {sku_id:'SKU_002'})
CREATE (sg)-[:PURCHASES {purchase_frequency:'monthly',   avg_basket_size:2}]->(s);
MATCH (sg:ConsumerSegment {segment_id:'SEG_002'}), (s:SKU {sku_id:'SKU_004'})
CREATE (sg)-[:PURCHASES {purchase_frequency:'weekly',    avg_basket_size:4}]->(s);
MATCH (sg:ConsumerSegment {segment_id:'SEG_002'}), (s:SKU {sku_id:'SKU_001'})
CREATE (sg)-[:PURCHASES {purchase_frequency:'monthly',   avg_basket_size:2}]->(s);
MATCH (sg:ConsumerSegment {segment_id:'SEG_003'}), (s:SKU {sku_id:'SKU_001'})
CREATE (sg)-[:PURCHASES {purchase_frequency:'monthly',   avg_basket_size:2}]->(s);
MATCH (sg:ConsumerSegment {segment_id:'SEG_004'}), (s:SKU {sku_id:'SKU_002'})
CREATE (sg)-[:PURCHASES {purchase_frequency:'bi-weekly', avg_basket_size:2}]->(s);


// 4.8 ConsumerSegment -> SHOPS_AT -> Retailer
MATCH (sg:ConsumerSegment {segment_id:'SEG_001'}), (r:Retailer {retailer_id:'RET_001'}) CREATE (sg)-[:SHOPS_AT]->(r);
MATCH (sg:ConsumerSegment {segment_id:'SEG_001'}), (r:Retailer {retailer_id:'RET_002'}) CREATE (sg)-[:SHOPS_AT]->(r);
MATCH (sg:ConsumerSegment {segment_id:'SEG_002'}), (r:Retailer {retailer_id:'RET_002'}) CREATE (sg)-[:SHOPS_AT]->(r);
MATCH (sg:ConsumerSegment {segment_id:'SEG_002'}), (r:Retailer {retailer_id:'RET_001'}) CREATE (sg)-[:SHOPS_AT]->(r);
MATCH (sg:ConsumerSegment {segment_id:'SEG_003'}), (r:Retailer {retailer_id:'RET_001'}) CREATE (sg)-[:SHOPS_AT]->(r);
MATCH (sg:ConsumerSegment {segment_id:'SEG_003'}), (r:Retailer {retailer_id:'RET_003'}) CREATE (sg)-[:SHOPS_AT]->(r);
MATCH (sg:ConsumerSegment {segment_id:'SEG_004'}), (r:Retailer {retailer_id:'RET_001'}) CREATE (sg)-[:SHOPS_AT]->(r);


// 4.9 Review -> ABOUT_SKU -> SKU
MATCH (rv:Review {review_id:'REV_001'}), (s:SKU {sku_id:'SKU_001'}) CREATE (rv)-[:ABOUT_SKU]->(s);
MATCH (rv:Review {review_id:'REV_002'}), (s:SKU {sku_id:'SKU_002'}) CREATE (rv)-[:ABOUT_SKU]->(s);
MATCH (rv:Review {review_id:'REV_003'}), (s:SKU {sku_id:'SKU_004'}) CREATE (rv)-[:ABOUT_SKU]->(s);
MATCH (rv:Review {review_id:'REV_004'}), (s:SKU {sku_id:'SKU_001'}) CREATE (rv)-[:ABOUT_SKU]->(s);
MATCH (rv:Review {review_id:'REV_005'}), (s:SKU {sku_id:'SKU_005'}) CREATE (rv)-[:ABOUT_SKU]->(s);


// 4.10 Review -> MENTIONS -> SKU (with sentiment + aspect — Compete/digital shelf NLP)
MATCH (rv:Review {review_id:'REV_001'}), (s:SKU {sku_id:'SKU_001'})
CREATE (rv)-[:MENTIONS {sentiment:'positive', score:0.95, aspect:'flavor',    method:'nlp_model'}]->(s);
MATCH (rv:Review {review_id:'REV_002'}), (s:SKU {sku_id:'SKU_002'})
CREATE (rv)-[:MENTIONS {sentiment:'negative', score:0.82, aspect:'intensity', method:'nlp_model'}]->(s);
MATCH (rv:Review {review_id:'REV_003'}), (s:SKU {sku_id:'SKU_004'})
CREATE (rv)-[:MENTIONS {sentiment:'positive', score:0.88, aspect:'taste',     method:'nlp_model'}]->(s);
MATCH (rv:Review {review_id:'REV_004'}), (s:SKU {sku_id:'SKU_001'})
CREATE (rv)-[:MENTIONS {sentiment:'negative', score:0.75, aspect:'price',     method:'nlp_model'}]->(s);
MATCH (rv:Review {review_id:'REV_005'}), (s:SKU {sku_id:'SKU_005'})
CREATE (rv)-[:MENTIONS {sentiment:'positive', score:0.96, aspect:'taste',     method:'nlp_model'}]->(s);


// 4.11 Promotion -> APPLIED_TO -> SKU
MATCH (pr:Promotion {promo_id:'PROMO_001'}), (s:SKU {sku_id:'SKU_001'}) CREATE (pr)-[:APPLIED_TO]->(s);
MATCH (pr:Promotion {promo_id:'PROMO_002'}), (s:SKU {sku_id:'SKU_004'}) CREATE (pr)-[:APPLIED_TO]->(s);


// 4.12 Promotion -> AT_RETAILER -> Retailer
MATCH (pr:Promotion {promo_id:'PROMO_001'}), (r:Retailer {retailer_id:'RET_001'}) CREATE (pr)-[:AT_RETAILER]->(r);
MATCH (pr:Promotion {promo_id:'PROMO_002'}), (r:Retailer {retailer_id:'RET_002'}) CREATE (pr)-[:AT_RETAILER]->(r);
