# Knowledge Graph Schema — BFSI Hybrid RAG
**Graph Database:** Neo4j compatible  
**Export files:** kg_nodes.json, kg_edges.json, kg_schema_cypher.txt

---

## Node Types

| Node Type | Description | Key Properties |
|-----------|-------------|----------------|
| Customer | Bank customer entity | customer_id, segment, churn_risk, churn_score |
| Product | Bank product (savings, loan, card etc.) | product_id, name, category |
| RiskSignal | Identified churn/credit risk indicator | name, threshold, weight |
| RetentionOffer | Approved retention intervention | offer_id, name, risk_level |
| Complaint | Customer complaint record | complaint_id, severity, resolved |
| ServiceInteraction | Touch-point with customer | interaction_id, type, sentiment, outcome |
| Policy | Internal policy document | doc_id, version, owner |
| RegulatoryRule | External regulatory constraint | rule_id, source, applicability |

---

## Relationship Types

| Relationship | From | To | Properties |
|---|---|---|---|
| HAS_PRODUCT | Customer | Product | status, since_date |
| EXHIBITS_RISK | Customer | RiskSignal | detected_date, value |
| ELIGIBLE_FOR_OFFER | Customer | RetentionOffer | eligibility_reason |
| RAISED_COMPLAINT | Customer | Complaint | date, severity |
| HAD_INTERACTION | Customer | ServiceInteraction | date, outcome |
| GOVERNED_BY | RetentionOffer | Policy | section_ref |
| CONSTRAINED_BY | RetentionOffer | RegulatoryRule | constraint_type |
| LINKED_TO_RISK | Complaint | RiskSignal | contribution_weight |
| MANAGED_BY | Customer | RelationshipManager | since_date |

---

## Key Graph Paths for Demo Queries

### Churn Evidence Path (Demo Step 6)
```
(Customer {churn_score > 0.7}) 
  -[:EXHIBITS_RISK]-> (RiskSignal)
  -[:LINKED_TO_RISK]-> (Complaint)
  -[:RAISED_COMPLAINT]-> (Customer)
  -[:ELIGIBLE_FOR_OFFER]-> (RetentionOffer)
  -[:GOVERNED_BY]-> (Policy)
```

### Compliance Check Path
```
(RetentionOffer) -[:CONSTRAINED_BY]-> (RegulatoryRule)
```

### Full Customer Context Path
```
(Customer) -[:HAS_PRODUCT]-> (Product)
(Customer) -[:EXHIBITS_RISK]-> (RiskSignal)
(Customer) -[:RAISED_COMPLAINT]-> (Complaint)
(Customer) -[:HAD_INTERACTION]-> (ServiceInteraction)
(Customer) -[:ELIGIBLE_FOR_OFFER]-> (RetentionOffer)
```
