# Credit Risk Management Policy
**Document ID:** CRMP-2024-01  
**Version:** 3.0  
**Effective Date:** 1 January 2024  
**Owner:** Chief Risk Officer

---

## 1. Scope

This policy applies to all consumer and commercial credit exposures including personal loans, home loans, credit cards, and SME lending. It defines risk appetites, thresholds, and escalation protocols.

---

## 2. Credit Risk Tiers

| Risk Category | Credit Score | NPA Probability | Treatment |
|---------------|-------------|-----------------|-----------|
| Prime | 750 – 850 | < 2% | Standard processing; eligible for preferential rates |
| Near Prime | 700 – 749 | 2–5% | Standard processing; no unsecured products >15L without approval |
| Subprime | 650 – 699 | 5–15% | Restricted credit; secured products only; enhanced monitoring |
| High Risk | < 650 | > 15% | No new credit; existing portfolio review mandatory |

---

## 3. Exposure Limits

- Retail unsecured: Maximum INR 40 lakh per customer
- Home loan: Maximum 80% LTV; up to INR 5 crore without committee; beyond requires Credit Committee
- Credit card: Maximum credit limit 3x monthly income or INR 5 lakh, whichever is lower
- SME: Exposure above INR 25 lakh requires Business Banking Credit approval

---

## 4. Concentration Risk Limits

- No single geography (city) to exceed 25% of retail loan book
- No single sector (SME) to exceed 15% of total SME exposure
- Loan-to-deposit ratio (LDR) must not exceed 85%

---

## 5. NPA Management

- 30-day overdue: Early Warning Signal; trigger collection call
- 60-day overdue: Downgrade to Special Mention Account (SMA-1); flag to Credit Risk team
- 90-day overdue: NPA classification; initiate recovery proceedings per SARFAESI Act 2002

---

## 6. AI-Assisted Risk Scoring

AI-generated risk scores are advisory. Mandatory human review is required for:
- Loan applications above INR 10 lakh
- Any customer whose AI risk score contradicts bureau score by more than 100 points
- Customers in High Risk category where credit extension is recommended by AI

AI risk recommendations must display confidence intervals and must not be used as the sole basis for credit decisions.

---

*Approved by: Chief Risk Officer, Board Risk Committee*  
*Next Review: 1 January 2025*
