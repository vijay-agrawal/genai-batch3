# Investment Product Suitability Policy
**Document ID:** ISP-2024-01  
**Version:** 2.0  
**Effective Date:** 1 March 2024  
**Owner:** Wealth Management Head / Chief Compliance Officer

---

## 1. Regulatory Basis

This policy is issued in compliance with:
- SEBI (Investment Advisers) Regulations, 2013
- AMFI Guidelines on Suitability Assessment
- IRDAI Guidelines on Insurance Mis-selling Prevention 2023
- RBI Guidelines on Bancassurance 2019

---

## 2. Mandatory Suitability Assessment

Before recommending any investment product (mutual funds, insurance, structured products, demat/trading), the advisor must complete a Suitability Assessment capturing:

1. **Risk Appetite:** Conservative / Moderate / Aggressive
2. **Investment Horizon:** Short (<2yr) / Medium (2-5yr) / Long (>5yr)
3. **Liquidity Requirement:** High / Medium / Low
4. **Income and Net Worth:** Verified from annual income band
5. **Financial Knowledge:** Novice / Intermediate / Sophisticated

---

## 3. Product-Suitability Matrix

| Product | Min Risk Appetite | Min Horizon | Min Knowledge |
|---------|------------------|-------------|---------------|
| Liquid Mutual Fund | Conservative | Short | Novice |
| Debt Fund | Conservative | Medium | Novice |
| Balanced/Hybrid Fund | Moderate | Medium | Intermediate |
| Equity Fund | Aggressive | Long | Intermediate |
| Direct Equity/Demat | Aggressive | Long | Sophisticated |
| ULIP | Moderate | Long | Intermediate |
| Term Insurance | Any | Any | Novice |

---

## 4. AI Recommendations for Investment Products

AI-generated next-best-action recommendations for investment products:

- **Must display:** Suitability score based on customer profile
- **Must not:** Promise specific returns or compare to benchmark guarantees
- **Must not:** Recommend a product category for which the customer failed suitability assessment
- **Require:** Certified Investment Advisor review before customer communication
- **Require:** Customer to sign updated suitability form if product category is new

---

## 5. Mis-Selling Prevention

The following triggers auto-flag a recommendation for Compliance review:
- Customer age > 70 and recommended product risk appetite is Aggressive
- Customer income band < 5L and recommended product is Equity Fund > INR 1L SIP
- Customer has active complaint about an investment product
- AI confidence score < 70% for any investment recommendation

---

*Approved by: Wealth Management Head, Chief Compliance Officer*  
*Next Review: 1 March 2025*
