# Complaint Management & Escalation SOP
**Document ID:** CMS-SOP-2024-02  
**Version:** 1.4  
**Effective Date:** 1 June 2024  
**Owner:** Customer Experience Head

---

## 1. Complaint Categories and Resolution TAT

| Category | Severity | Resolution TAT | Escalation if Breached |
|----------|----------|---------------|------------------------|
| Transaction Dispute | HIGH | 7 working days | Regional Customer Head |
| Card Blocked / Fraud | HIGH | 3 working days | Fraud Management Unit |
| Unauthorized Charges | HIGH | 5 working days | Grievance Officer |
| Loan / Interest Rate | MEDIUM | 10 working days | Branch Manager |
| App / Digital Issue | MEDIUM | 5 working days | Digital Banking Head |
| KYC / Documentation | LOW | 7 working days | Branch Operations |
| General Service | LOW | 3 working days | Branch Manager |

---

## 2. Repeat Complaint Protocol

A complaint is classified as a **Repeat Complaint** if the same customer raises a similar issue within 60 days of a previous complaint being marked as resolved.

Repeat complaints trigger:
1. Automatic escalation to Grievance Officer
2. Root cause analysis (RCA) mandatory within 5 days
3. Customer satisfaction call by Branch Manager within 48 hours
4. Churn risk flag raised in CRM

---

## 3. Regulatory Escalation

Complaints that remain unresolved beyond the TAT or are escalated by the customer to:
- **RBI Ombudsman:** Must be acknowledged within 5 days; full case file to be prepared
- **SEBI SCORES portal:** For investment product complaints; 21-day resolution window
- **IRDAI Grievance Portal:** For insurance complaints; 14-day resolution window
- **Consumer Forum / NCDRC:** Legal team to be involved immediately

---

## 4. AI-Assisted Complaint Triage

AI systems may assist in:
- Classifying complaint severity and type
- Identifying repeat complaints
- Suggesting resolution templates

AI systems must **not**:
- Make promises of resolution outcomes to customers
- Classify a regulatory complaint as internal to avoid escalation
- Override escalation triggers based on predicted resolution probability

---

## 5. Compensation Guidelines

Customer compensation for bank error:
- Wrongful card blocking: INR 500 per day or actual loss, whichever is higher (per RBI Card Guidelines 2022)
- Delayed refund beyond TAT: Interest at savings rate per day
- Data breach (if applicable): As per IT Act 2000 and RBI Cybersecurity Framework

---

*Approved by: Customer Experience Head, Chief Compliance Officer*  
*Next Review: 1 June 2025*
