# Customer Retention Policy
**Document ID:** CRP-2024-03  
**Version:** 2.1  
**Effective Date:** 1 April 2024  
**Owner:** Chief Customer Officer

---

## 1. Purpose and Scope

This policy governs all customer retention activities undertaken by Relationship Managers (RMs), Branch Banking teams, and the Customer Experience Centre. It applies to all retail, premium, HNI, SME, and youth segment customers identified as being at risk of attrition.

---

## 2. Churn Risk Classification

Customers are classified into three risk tiers based on a composite score:

| Tier | Churn Score | Response SLA | Escalation |
|------|-------------|--------------|------------|
| LOW | 0.00 – 0.35 | 7 business days | None |
| MEDIUM | 0.35 – 0.70 | 48 hours | Branch Manager |
| HIGH / CRITICAL | 0.70 – 1.00 | 24 hours | Senior RM + Regional Head |

A CRITICAL flag is automatically raised when churn score exceeds 0.85 AND any of the following co-occur:
- Three or more complaints in the past 12 months
- Balance drop greater than 40% in six months
- Competitor mention detected in interaction notes

---

## 3. Permitted Retention Levers

Retention offers must be drawn exclusively from the **Approved Retention Offer Register** maintained by the Product team. RMs are **not permitted** to:

- Promise returns on investment products
- Offer rate concessions beyond the approved rate band without Credit Committee approval
- Waive fees cumulatively exceeding INR 25,000 per customer per year without Branch Manager sign-off
- Make verbal commitments that are not logged in CRM within 4 hours

---

## 4. Human-in-the-Loop (HITL) Requirements

All AI-generated Next-Best-Action recommendations must pass through a HITL gate before customer communication:

| Recommendation Type | Approver |
|--------------------|----------|
| Re-engagement outreach | RM self-approval |
| Fee waiver < INR 5,000 | Branch Manager |
| Rate concession on loan/FD | Credit Committee |
| Investment advice or product switch | Certified Advisor + Compliance |
| Escalated retention offer (churn score >0.85) | Regional Head |

---

## 5. PII and Data Handling

During AI-assisted recommendation generation:
- Customer name, PAN, Aadhaar, and account numbers must be masked in all AI prompts
- Interaction summaries shared with AI systems must use anonymized customer identifiers
- AI-generated outputs must be reviewed for unintended PII exposure before logging to CRM

---

## 6. Prohibited Actions

The following actions are prohibited regardless of customer churn risk:

1. Offering any product for which the customer has not passed suitability assessment (SEBI requirement for investment products)
2. Sharing customer data with third-party fintech partners for retention without explicit consent
3. Providing preferential treatment on regulated products (insurance, mutual funds) without IRDAI/SEBI compliance
4. Making retention offers contingent on withdrawal of regulatory complaints

---

## 7. Audit and Monitoring

All retention interactions must be:
- Logged in the CRM with offer ID, approver name, and customer response
- Available for audit for a minimum of 7 years (as per RBI record-keeping norms)
- Reviewed quarterly by the Compliance team for policy adherence

---

*Approved by: Chief Customer Officer, Chief Compliance Officer*  
*Next Review Date: 1 April 2025*
