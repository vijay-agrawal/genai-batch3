# SEBI and AMFI Investment Product Regulatory Summary
**Reference Document for AI-Assisted Recommendation Systems**

---

## 1. SEBI (Investment Advisers) Regulations, 2013

- Only SEBI-registered Investment Advisers (RIA) may charge fees for investment advice.
- Banks operating as distributors must disclose upfront and trail commissions to clients.
- Suitability obligation: advisers must ensure recommended products are suitable for the client's financial situation, risk tolerance, and investment objective.
- Conflict of interest disclosure: mandatory where adviser or distributor earns commission from recommended product.

## 2. Mutual Fund — Key Regulations (SEBI MF Reg 1996, Updated 2024)

- Exit load: funds may charge exit load only if disclosed in SID (Scheme Information Document). Current SEBI cap: 2% for equity funds within 1 year.
- KYC mandatory for all MF investments. CKYC (Central KYC) number to be used.
- Risk-O-Meter: all funds must display standardized risk label (Low / Moderate / High / Very High / Extreme Risk).
- SIP cancellation: must be processed within 30 days of request.
- AI recommendation of MF schemes must display Risk-O-Meter rating and benchmark comparison.

## 3. Insurance — IRDAI Guidelines (2023)

- Need-based selling: insurance must be recommended based on actual customer need, not sales targets.
- Free-look period: 15 days for regular policies; 30 days for policies sold through distance marketing.
- Surrender charges: must be disclosed upfront in policy document.
- Bancassurance: bank staff recommending insurance must hold valid IRDAI certification (IC38 or equivalent).
- AI systems recommending insurance: must include disclaimer that recommendation is subject to suitability assessment and final policy issuance by the insurer.

## 4. Demat and Trading — SEBI Guidelines

- Margin requirements: customers must be informed of margin shortfall within same trading day.
- Risk disclosure: mandatory execution of Risk Disclosure Document (RDD) before trading account activation.
- Inactive accounts: demat accounts inactive >12 months must be frozen; reactivation requires written request.

## 5. AI and Robo-Advisory — SEBI Consultation Paper 2024

- Robo-advisory platforms must be SEBI-registered as Investment Advisers.
- Algorithm must be audited annually by an independent external auditor.
- Explainability: every AI recommendation must be explainable in plain language to the client.
- Model risk: banks and RIAs must maintain a model risk management framework for AI-based systems.
- Human override: clients must have a clearly disclosed pathway to request human advisor review.

---

*This is a regulatory reference summary. Authoritative guidance resides in official SEBI/IRDAI/AMFI publications.*
