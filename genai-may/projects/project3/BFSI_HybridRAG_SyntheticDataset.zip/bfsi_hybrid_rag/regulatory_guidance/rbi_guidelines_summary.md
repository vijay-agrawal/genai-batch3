# RBI Regulatory Guidance Summary — BFSI Customer Interactions
**Reference Document for AI-Assisted Systems**  
**Compiled from:** RBI Master Directions, Circulars, and Guidelines (2022–2024)

---

## 1. Know Your Customer (KYC) — Master Direction 2016 (Updated 2023)

- Full KYC required for all account holders. Video-KYC (V-CIP) now accepted for savings and current accounts.
- Risk-based KYC: Low-risk customers re-KYC every 10 years; Medium-risk every 8 years; High-risk every 2 years.
- Accounts with KYC pending beyond 6 months must be restricted to credits only. No debits permitted.
- AI systems must flag KYC expiry at 90-day, 30-day, and 7-day intervals.

## 2. Customer Grievance Redressal — Guidelines 2023

- All scheduled commercial banks must maintain a Board-approved Grievance Redressal Policy.
- Complaints must be acknowledged within 3 working days.
- Internal resolution within 30 days for all complaints; failing which, customer may approach the RBI Ombudsman.
- Compensation for delayed resolution: savings bank interest rate per day on the amount involved.
- Banks must publish quarterly complaint data on their website.

## 3. Fair Practices Code — Personal and SME Lending

- Loan rejection must be communicated in writing with the primary reason.
- Interest rate reset: borrowers must be informed at least one month in advance.
- Prepayment penalty: banks cannot levy pre-payment charges on floating rate loans to individual borrowers.
- No misleading advertisements about loan eligibility, rates, or EMI.

## 4. Credit Card Guidelines — 2022

- Credit card issuance requires explicit consent; no auto-upgrade to higher variant without written consent.
- Billing cycle disputes must be resolved within 7 working days.
- Wrongful card blocking: bank liable to pay INR 500 per day of wrongful blocking.
- Annual fee must be disclosed upfront; no hidden charges.
- One-Time Password (OTP) mandatory for all card-not-present transactions above INR 2,000.

## 5. Interest Rate and Deposit Guidelines

- Savings deposit interest paid minimum quarterly (banks may pay more frequently).
- Premature FD withdrawal: bank may levy penalty not exceeding 1% on applicable rate.
- Senior citizens entitled to 0.25%–0.50% additional FD interest (bank discretion).
- Differential rates for different tenors permissible; no discrimination within same tenor bucket.

## 6. Data Privacy and Customer Consent

- Banks must obtain explicit consent before sharing customer data with subsidiaries, business partners, or fintech entities.
- Customer financial data used for cross-sell / upsell must be disclosed in the bank's Privacy Policy.
- Right to opt-out of marketing communications must be provided and honoured within 10 business days.
- Data breach: RBI must be notified within 6 hours of discovery; customers within 24 hours.

---

*This document is a summary for AI system grounding. For authoritative guidance, always refer to the original RBI circulars.*
