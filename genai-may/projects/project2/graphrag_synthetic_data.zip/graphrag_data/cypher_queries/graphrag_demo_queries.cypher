// =============================================================================
// GRAPHRAG DEMO CYPHER QUERIES
// Knowledge Graph: Customer, Product & Competitor Intelligence
// Neo4j Graph Database
// =============================================================================

// =============================================================================
// QUERY 1: Core GraphRAG Demo Question
// "Which competitor is gaining among value-conscious parents, and what product
// attributes are driving the shift?"
// =============================================================================

MATCH (seg:CustomerSegment {name: 'ValueParents'})
      -[:SWITCHES_TO]->(comp:Competitor)
      -[:WINS_ON]->(attr:Attribute)
WITH seg, comp, attr
MATCH (comp)-[:BELONGS_TO|IS_BRAND]->(p:Product)
      -[:TARGETS_SEGMENT]->(seg)
RETURN seg.name AS Segment,
       comp.name AS Competitor,
       comp.growth_rate_yoy_percent AS GrowthRate_YoY,
       collect(DISTINCT attr.attribute_name) AS WinningAttributes,
       comp.market_share_pct_in_segment AS SegmentShare
ORDER BY comp.growth_rate_yoy_percent DESC;

// Expected result: FreshStart | 40.5% YoY | [price, packaging_ease, taste, promotions, doctor_recommendation] | 31.2%


// =============================================================================
// QUERY 2: Evidence Chain for GraphRAG Explanation
// "Show the evidence chain for why FreshStart is gaining in ValueParents segment"
// =============================================================================

MATCH path = (seg:CustomerSegment {name: 'ValueParents'})
             -[:DRIVEN_BY]->(need:NeedState)
             <-[:SATISFIES]-(attr:Attribute)
             <-[:WINS_ON]-(comp:Competitor {name: 'FreshStart'})
             -[:RUNS_CAMPAIGN]->(camp:Campaign)
             -[:TARGETS]->(seg)
RETURN path,
       seg.name AS Segment,
       need.need_name AS NeedState,
       attr.attribute_name AS WinningAttribute,
       comp.name AS Competitor,
       camp.campaign_name AS SupportingCampaign,
       camp.conversion_rate_pct AS ConversionRate;

// This query returns graph paths showing the full causal chain:
// ValueParents → price_sensitivity → price → FreshStart → FreshStart PricePromise 2024


// =============================================================================
// QUERY 3: Unmet Need Connecting Multiple Complaint Types
// "Which unmet need connects complaints about price, packaging, and competitor switching?"
// =============================================================================

MATCH (theme:ReviewTheme)
WHERE theme.theme_name IN ['price_increase_frustration', 'packaging_usability', 'shrinkflation_detection']
MATCH (theme)-[:LINKED_TO_NEED]->(need:NeedState)
MATCH (need)<-[:DRIVEN_BY]-(seg:CustomerSegment)
MATCH (need)-[:SATISFIED_BY]->(prod:Product)
MATCH (prod)-[:BELONGS_TO]->(brand:Brand)
RETURN theme.theme_name AS Complaint,
       need.need_name AS UnderlyingNeed,
       seg.name AS AffectedSegment,
       prod.canonical_name AS BenefitingProduct,
       brand.canonical_name AS BenefitingBrand,
       theme.volume AS MentionVolume
ORDER BY theme.volume DESC;

// This shows the single unmet need "affordable_honest_value" connects:
// price frustration + packaging complaints + shrinkflation → FreshStart DailyBoost


// =============================================================================
// QUERY 4: Segment-Competitor-Attribute-Channel Full Path
// Multi-hop traversal showing the complete switching pathway
// =============================================================================

MATCH (seg:CustomerSegment)
      -[:SWITCHES_TO {primary_trigger: 'price_increase'}]->(comp:Competitor)
WITH seg, comp
MATCH (comp)-[:WINS_ON]->(attr:Attribute)
WITH seg, comp, collect(attr.attribute_name) AS attrs
MATCH (comp)<-[:IS_BRAND]-(brand:Brand)
MATCH (brand)-[:DISTRIBUTED_IN {strength: 'strong'}]->(chan:Channel)
WHERE chan.channel_name = 'Supermarket'
MATCH (camp:Campaign)-[:PROMOTES]->(prod:Product)-[:BELONGS_TO]->(brand)
WHERE camp.campaign_type = 'Trade Promotion'
RETURN seg.name AS Segment,
       comp.name AS Competitor,
       attrs AS WinningAttributes,
       chan.channel_name AS WinningChannel,
       camp.campaign_name AS EnablingCampaign,
       camp.conversion_rate_pct AS Conversion,
       comp.market_share_pct_in_segment AS SegmentShare;


// =============================================================================
// QUERY 5: Which brands are gaining in which segments and through which channels?
// =============================================================================

MATCH (seg:CustomerSegment)
      -[:PREFERS]->(prod:Product)
      -[:BELONGS_TO]->(brand:Brand)
WITH seg, brand, prod
MATCH (prod)-[:DISTRIBUTED_IN]->(chan:Channel)
OPTIONAL MATCH (brand)-[:COMPETES_WITH]->(comp:Competitor)
RETURN seg.name AS Segment,
       brand.canonical_name AS Brand,
       prod.canonical_name AS LeadProduct,
       brand.market_share_trend AS ShareTrend,
       collect(DISTINCT chan.channel_name) AS ActiveChannels,
       comp.name AS MainCompetitorBeaten
ORDER BY seg.name, brand.market_share_overall DESC;


// =============================================================================
// QUERY 6: Doctor Recommendation Network Effect
// Which brands benefit most from physician recommendations per segment?
// =============================================================================

MATCH (seg:CustomerSegment)
      -[:DRIVEN_BY {rank: 1}|{rank: 2}|{rank: 3}]->(need:NeedState {need_category: 'trust'})
WITH seg, need
MATCH (need)-[:SATISFIED_BY]->(prod:Product)
WHERE prod.doctor_recommendation_rate > 0.4
MATCH (prod)-[:BELONGS_TO]->(brand:Brand)
MATCH (camp:Campaign {campaign_type: 'Influencer/HCP'})-[:TARGETS]->(seg)
MATCH (camp)-[:PROMOTES]->(prod)
RETURN seg.name AS Segment,
       need.need_name AS TrustNeed,
       brand.canonical_name AS Brand,
       prod.canonical_name AS Product,
       prod.doctor_recommendation_rate AS DrRecommendRate,
       camp.campaign_name AS HCPCampaign,
       camp.kpi_value_achieved AS CampaignResult
ORDER BY prod.doctor_recommendation_rate DESC;


// =============================================================================
// QUERY 7: Entity Resolution Check Query
// Find all aliases for a canonical entity (for entity resolution demo)
// =============================================================================

MATCH (brand:Brand)
WHERE brand.canonical_name IN ['NutriKids', 'FreshStart', 'VitaPlus', 'QuickNutrish']
RETURN brand.canonical_name AS CanonicalName,
       brand.aliases AS KnownAliases,
       size(brand.aliases) AS AliasCount
ORDER BY AliasCount DESC;

// Also check products
MATCH (prod:Product)
RETURN prod.canonical_name AS CanonicalProduct,
       prod.aliases AS KnownAliases
ORDER BY prod.canonical_name;


// =============================================================================
// QUERY 8: Review Theme to Strategy Path
// Connect social listening themes to strategic competitive actions
// =============================================================================

MATCH (theme:ReviewTheme {sentiment: 'negative'})
      -[:ABOUT]->(brand:Brand {canonical_name: 'NutriKids'})
WITH theme, brand
MATCH (theme)-[:LINKED_TO_NEED]->(need:NeedState)
MATCH (comp:Competitor)-[:WINS_ON]->(attr:Attribute)
      -[:ADDRESSES_NEED]->(need)
RETURN theme.theme_name AS NegativeTheme,
       theme.volume AS Volume,
       theme.trend AS Trend,
       need.need_name AS UnderlyingNeed,
       comp.name AS BenefitingCompetitor,
       attr.attribute_name AS CompetitorWinningAttribute
ORDER BY theme.volume DESC
LIMIT 10;


// =============================================================================
// QUERY 9: GraphRAG vs Vector-RAG Demo - Relationship-heavy question
// "Which unmet need connects price complaints, packaging complaints, and competitor switching?"
// (This is what vector-only RAG cannot answer without graph traversal)
// =============================================================================

// Step 1: Find all review themes with negative sentiment about NutriKids
MATCH (theme:ReviewTheme)-[:MENTIONS {sentiment_direction: 'negative'}]->(brand:Brand {canonical_name: 'NutriKids'})
WHERE theme.volume > 2000

// Step 2: Traverse to underlying NeedStates
MATCH (theme)-[:LINKED_TO_NEED]->(need:NeedState)

// Step 3: Find which competitors satisfy those needs
MATCH (need)<-[:ADDRESSES_NEED]-(attr:Attribute)<-[:WINS_ON]-(comp:Competitor)

// Step 4: Find which segment is switching based on those needs
MATCH (seg:CustomerSegment)-[:DRIVEN_BY]->(need)
MATCH (seg)-[:SWITCHES_TO]->(comp)

// Return the full path
RETURN theme.theme_name AS ReviewTheme,
       theme.volume AS Mentions,
       need.need_name AS SharedUnmetNeed,
       comp.name AS CompetitorCapturing,
       seg.name AS AffectedSegment,
       comp.growth_rate_yoy_percent AS CompetitorGrowth
ORDER BY theme.volume DESC;


// =============================================================================
// QUERY 10: Temporal Market Share Movement (for temporal KG future scope)
// =============================================================================

MATCH (brand:Brand)
WITH brand,
     brand.market_share_Q1_2023 AS q1_23,
     brand.market_share_Q2_2023 AS q2_23,
     brand.market_share_Q3_2023 AS q3_23,
     brand.market_share_Q4_2023 AS q4_23,
     brand.market_share_Q1_2024 AS q1_24
RETURN brand.canonical_name AS Brand,
       q1_23, q2_23, q3_23, q4_23, q1_24,
       (q1_24 - q1_23) AS ShareGain_YoY_pp
ORDER BY (q1_24 - q1_23) DESC;


// =============================================================================
// QUERY 11: Shortest Path Between Competitor Gain and Consumer Complaint
// Core GraphRAG path explainability query
// =============================================================================

MATCH (complaint:ReviewTheme {theme_name: 'price_increase_frustration'}),
      (gain:Competitor {name: 'FreshStart'})
MATCH path = shortestPath((complaint)-[*..6]-(gain))
RETURN path, length(path) AS PathLength,
       [node IN nodes(path) | coalesce(node.name, node.theme_name, node.need_name, node.attribute_name, node.canonical_name)] AS PathNodes,
       [rel IN relationships(path) | type(rel)] AS PathRelationships;

// This is the core GraphRAG explainability demo - shows the graph path as evidence chain
