"""
Neo4j Graph Load Script
Customer, Product & Competitor Knowledge Graph
Run with: python neo4j_graph_loader.py
Requires: pip install neo4j
Update NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD before running.
"""

from neo4j import GraphDatabase
import json

NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "password"

driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

# ─────────────────────────────────────────
# NODE DATA
# ─────────────────────────────────────────

SEGMENTS = [
    {"segment_id": "SEG001", "name": "ValueParents",       "size_percent": 38.2, "primary_channel": "Supermarket", "primary_purchase_driver": "price",                "switch_propensity_score": 0.44},
    {"segment_id": "SEG002", "name": "HealthConscious",    "size_percent": 22.7, "primary_channel": "Pharmacy",    "primary_purchase_driver": "ingredient_transparency","switch_propensity_score": 0.18},
    {"segment_id": "SEG003", "name": "BusyProfessional",   "size_percent": 19.4, "primary_channel": "Online_D2C",  "primary_purchase_driver": "convenience",            "switch_propensity_score": 0.14},
    {"segment_id": "SEG004", "name": "SeniorWellness",     "size_percent": 19.7, "primary_channel": "Pharmacy",    "primary_purchase_driver": "doctor_recommendation",  "switch_propensity_score": 0.12},
]

BRANDS = [
    {"brand_id": "BR001", "canonical_name": "NutriKids",    "market_position": "Premium",              "market_share_overall": 32.1, "nps_score": 48, "aliases": ["Nutri Kids","NK","NutriKid","Nutri-Kids"]},
    {"brand_id": "BR002", "canonical_name": "FreshStart",   "market_position": "Value",                "market_share_overall": 18.4, "nps_score": 72, "aliases": ["Fresh Start","FS","Fresh-Start","FreshStart Nutrition"]},
    {"brand_id": "BR003", "canonical_name": "VitaPlus",     "market_position": "Premium-Health",       "market_share_overall": 14.7, "nps_score": 87, "aliases": ["Vita Plus","VP","Vita+","VitaPlus India"]},
    {"brand_id": "BR004", "canonical_name": "QuickNutrish", "market_position": "Convenience-Premium",  "market_share_overall": 6.3,  "nps_score": 80, "aliases": ["Quick Nutrish","QN","Quick-Nutrish"]},
]

PRODUCTS = [
    {"product_id": "NK-GP-001", "canonical_name": "NutriKids GrowPack",       "brand_id": "BR001", "category": "Children Nutrition", "target_age_range": "3-12", "mrp_inr_500g": 620, "taste_score": 3.8, "packaging_ease": 2.9, "doctor_recommendation_rate": 0.44, "value_for_money": 3.2, "ingredient_transparency": 3.0},
    {"product_id": "NK-PF-002", "canonical_name": "NutriKids ProFormula",     "brand_id": "BR001", "category": "Children Nutrition", "target_age_range": "6-15", "mrp_inr_500g": 840, "taste_score": 3.6, "packaging_ease": 3.1, "doctor_recommendation_rate": 0.28, "value_for_money": 3.0, "ingredient_transparency": 2.7},
    {"product_id": "FS-DB-001", "canonical_name": "FreshStart DailyBoost",   "brand_id": "BR002", "category": "Children Nutrition", "target_age_range": "3-12", "mrp_inr_500g": 390, "taste_score": 4.2, "packaging_ease": 4.4, "doctor_recommendation_rate": 0.41, "value_for_money": 4.7, "ingredient_transparency": 3.5},
    {"product_id": "VP-OB-001", "canonical_name": "VitaPlus OmegaBlend",     "brand_id": "BR003", "category": "Children Nutrition", "target_age_range": "4-16", "mrp_inr_500ml": 1050,"taste_score": 3.9, "packaging_ease": 4.0, "doctor_recommendation_rate": 0.72, "value_for_money": 3.3, "ingredient_transparency": 4.9},
    {"product_id": "VP-SC-002", "canonical_name": "VitaPlus SeniorCare",     "brand_id": "BR003", "category": "Senior Nutrition",   "target_age_range": "55+",  "mrp_inr_60tab": 580, "ease_of_swallow": 4.6,                        "doctor_recommendation_rate": 0.68, "value_for_money": 4.0, "ingredient_transparency": 4.8},
    {"product_id": "QN-OTG-001","canonical_name": "QuickNutrish On-the-Go",  "brand_id": "BR004", "category": "Adult Nutrition",    "target_age_range": "22-50","mrp_inr_30sach": 790,"taste_score": 4.5, "convenience_score": 4.9, "doctor_recommendation_rate": 0.22, "value_for_money": 3.8, "ingredient_transparency": 3.5},
]

NEED_STATES = [
    {"need_id": "NS001", "need_name": "price_sensitivity",        "need_category": "functional", "prevalence_score": 0.82},
    {"need_id": "NS002", "need_name": "ingredient_transparency",  "need_category": "functional", "prevalence_score": 0.61},
    {"need_id": "NS003", "need_name": "convenience_maximizing",   "need_category": "functional", "prevalence_score": 0.74},
    {"need_id": "NS004", "need_name": "clinical_evidence",        "need_category": "functional", "prevalence_score": 0.55},
    {"need_id": "NS005", "need_name": "community_belonging",      "need_category": "social",     "prevalence_score": 0.48},
    {"need_id": "NS006", "need_name": "joint_health",             "need_category": "functional", "prevalence_score": 0.71},
    {"need_id": "NS007", "need_name": "cognitive_development",    "need_category": "functional", "prevalence_score": 0.63},
    {"need_id": "NS008", "need_name": "product_fit_for_age",      "need_category": "functional", "prevalence_score": 0.67},
    {"need_id": "NS009", "need_name": "doctor_trust",             "need_category": "emotional",  "prevalence_score": 0.78},
    {"need_id": "NS010", "need_name": "affordable_honest_value",  "need_category": "emotional",  "prevalence_score": 0.69},
]

REVIEW_THEMES = [
    {"theme_id": "RT001", "theme_name": "price_increase_frustration",  "sentiment": "negative", "volume": 8420, "trend": "rising",  "linked_brand": "NutriKids"},
    {"theme_id": "RT002", "theme_name": "freshstart_momentum",         "sentiment": "positive", "volume": 12310,"trend": "rising",  "linked_brand": "FreshStart"},
    {"theme_id": "RT003", "theme_name": "vitaplus_clean_label_buzz",   "sentiment": "positive", "volume": 5670, "trend": "rising",  "linked_brand": "VitaPlus"},
    {"theme_id": "RT004", "theme_name": "packaging_usability_complaint","sentiment": "negative","volume": 3210, "trend": "rising",  "linked_brand": "NutriKids"},
    {"theme_id": "RT005", "theme_name": "subscription_convenience",    "sentiment": "positive", "volume": 4890, "trend": "rising",  "linked_brand": "QuickNutrish"},
    {"theme_id": "RT006", "theme_name": "competitor_switching_signals", "sentiment": "positive","volume": 6750, "trend": "rising",  "linked_brand": "FreshStart"},
    {"theme_id": "RT007", "theme_name": "vitaplus_senior_discovery",   "sentiment": "positive", "volume": 2340, "trend": "rising",  "linked_brand": "VitaPlus"},
    {"theme_id": "RT008", "theme_name": "artificial_additives_concern","sentiment": "negative", "volume": 4120, "trend": "rising",  "linked_brand": "NutriKids"},
    {"theme_id": "RT009", "theme_name": "mommy_network_effect",        "sentiment": "positive", "volume": 9810, "trend": "rising",  "linked_brand": "FreshStart"},
    {"theme_id": "RT010", "theme_name": "shrinkflation_detection",     "sentiment": "negative", "volume": 3890, "trend": "rising",  "linked_brand": "NutriKids"},
]

CHANNELS = [
    {"channel_id": "CH001", "channel_name": "Supermarket",        "channel_type": "offline"},
    {"channel_id": "CH002", "channel_name": "Pharmacy",           "channel_type": "offline"},
    {"channel_id": "CH003", "channel_name": "Online_D2C",         "channel_type": "online"},
    {"channel_id": "CH004", "channel_name": "Online_Marketplace",  "channel_type": "online"},
    {"channel_id": "CH005", "channel_name": "WhatsApp_Community",  "channel_type": "social"},
]

ATTRIBUTES = [
    {"attr_id": "AT001", "attribute_name": "price",                     "attribute_category": "price"},
    {"attr_id": "AT002", "attribute_name": "packaging_ease",            "attribute_category": "experience"},
    {"attr_id": "AT003", "attribute_name": "taste",                     "attribute_category": "product"},
    {"attr_id": "AT004", "attribute_name": "DHA_content",               "attribute_category": "product"},
    {"attr_id": "AT005", "attribute_name": "doctor_recommendation_rate","attribute_category": "trust"},
    {"attr_id": "AT006", "attribute_name": "subscription_model",        "attribute_category": "experience"},
    {"attr_id": "AT007", "attribute_name": "clean_label",               "attribute_category": "trust"},
    {"attr_id": "AT008", "attribute_name": "clinical_evidence",         "attribute_category": "trust"},
    {"attr_id": "AT009", "attribute_name": "convenience_format",        "attribute_category": "experience"},
    {"attr_id": "AT010", "attribute_name": "age_appropriate_formula",   "attribute_category": "product"},
    {"attr_id": "AT011", "attribute_name": "promotions",                "attribute_category": "price"},
    {"attr_id": "AT012", "attribute_name": "community_recommendation",  "attribute_category": "social"},
]

CAMPAIGNS = [
    {"campaign_id": "CAM001", "campaign_name": "NutriKids GrowStrong 2023",        "brand": "NutriKids",    "campaign_type": "Brand Awareness",  "budget_lakhs": 220, "conversion_rate_pct": 2.1,  "outcome": "limited_conversion"},
    {"campaign_id": "CAM003", "campaign_name": "FreshStart PricePromise 2024 Q1",  "brand": "FreshStart",   "campaign_type": "Trade Promotion",   "budget_lakhs": 95,  "conversion_rate_pct": 7.2,  "outcome": "highly_effective_NutriKids_switching"},
    {"campaign_id": "CAM004", "campaign_name": "FreshStart DocRecommends 2024",    "brand": "FreshStart",   "campaign_type": "Influencer/HCP",    "budget_lakhs": 60,  "conversion_rate_pct": 5.5,  "outcome": "recommendation_rate_up_13pp"},
    {"campaign_id": "CAM005", "campaign_name": "VitaPlus ScienceFirst 2023",       "brand": "VitaPlus",     "campaign_type": "Content Marketing", "budget_lakhs": 180, "conversion_rate_pct": 3.1,  "outcome": "high_premium_consideration"},
    {"campaign_id": "CAM006", "campaign_name": "VitaPlus SeniorCare Launch 2024",  "brand": "VitaPlus",     "campaign_type": "Product Launch",    "budget_lakhs": 130, "conversion_rate_pct": 6.8,  "outcome": "exceptional_launch_42pct_share"},
    {"campaign_id": "CAM007", "campaign_name": "QuickNutrish SubscriptionFirst",   "brand": "QuickNutrish", "campaign_type": "Acquisition",       "budget_lakhs": 75,  "conversion_rate_pct": 9.1,  "outcome": "68pct_subscription_signup"},
    {"campaign_id": "CAM010", "campaign_name": "FreshStart MommyCircle 2024",      "brand": "FreshStart",   "campaign_type": "Community/Referral","budget_lakhs": 35,  "conversion_rate_pct": 14.1, "outcome": "viral_mommy_network_effect"},
]

# ─────────────────────────────────────────
# RELATIONSHIPS
# ─────────────────────────────────────────

SEGMENT_DRIVEN_BY = [
    # (segment_name, need_name, rank, importance_score)
    ("ValueParents",     "price_sensitivity",       1, 4.8),
    ("ValueParents",     "affordable_honest_value", 2, 4.5),
    ("ValueParents",     "doctor_trust",            3, 4.3),
    ("ValueParents",     "community_belonging",     4, 3.9),
    ("HealthConscious",  "ingredient_transparency", 1, 4.9),
    ("HealthConscious",  "doctor_trust",            2, 4.8),
    ("HealthConscious",  "clinical_evidence",       3, 4.7),
    ("HealthConscious",  "cognitive_development",   4, 4.2),
    ("BusyProfessional", "convenience_maximizing",  1, 4.9),
    ("BusyProfessional", "product_fit_for_age",     2, 4.7),
    ("SeniorWellness",   "doctor_trust",            1, 4.9),
    ("SeniorWellness",   "product_fit_for_age",     2, 4.8),
    ("SeniorWellness",   "joint_health",            3, 4.4),
]

SEGMENT_PREFERS = [
    # (segment_name, product_canonical, share_pct, trend, primary_driver)
    ("ValueParents",    "FreshStart DailyBoost",    31.2, "rising",  "price"),
    ("ValueParents",    "NutriKids GrowPack",        28.4, "falling", "brand_inertia"),
    ("HealthConscious", "VitaPlus OmegaBlend",      38.9, "rising",  "clinical_evidence"),
    ("HealthConscious", "NutriKids ProFormula",     21.3, "falling", "prior_brand_loyalty"),
    ("BusyProfessional","QuickNutrish On-the-Go",  28.4, "rising",  "convenience"),
    ("SeniorWellness",  "VitaPlus SeniorCare",      42.1, "rising",  "age_appropriate"),
]

SEGMENT_SWITCHES_TO = [
    # (segment_name, competitor_name, switch_rate_pct, primary_trigger, time_period)
    ("ValueParents",    "FreshStart",   44.1, "price_increase_and_shrinkflation", "Q1-2024"),
    ("HealthConscious", "VitaPlus",     18.4, "artificial_additive_discovery",    "2023-2024"),
    ("BusyProfessional","QuickNutrish", 14.2, "convenience_format_disruption",    "2023-2024"),
    ("SeniorWellness",  "VitaPlus",     11.8, "age_appropriate_product_launch",   "Q1-2024"),
]

COMPETITOR_WINS_ON = [
    # (competitor_name, attribute_name, in_segment, score)
    ("FreshStart",   "price",                    "ValueParents",    4.7),
    ("FreshStart",   "packaging_ease",           "ValueParents",    4.4),
    ("FreshStart",   "taste",                    "ValueParents",    4.2),
    ("FreshStart",   "promotions",               "ValueParents",    4.8),
    ("FreshStart",   "doctor_recommendation_rate","ValueParents",   4.1),
    ("FreshStart",   "community_recommendation", "ValueParents",    4.5),
    ("VitaPlus",     "clean_label",              "HealthConscious", 4.9),
    ("VitaPlus",     "clinical_evidence",        "HealthConscious", 4.7),
    ("VitaPlus",     "DHA_content",              "HealthConscious", 4.8),
    ("VitaPlus",     "doctor_recommendation_rate","HealthConscious",4.9),
    ("VitaPlus",     "age_appropriate_formula",  "SeniorWellness",  4.9),
    ("QuickNutrish", "convenience_format",       "BusyProfessional",4.9),
    ("QuickNutrish", "subscription_model",       "BusyProfessional",4.7),
    ("QuickNutrish", "taste",                    "BusyProfessional",4.5),
]

PRODUCT_DISTRIBUTED_IN = [
    # (product_canonical, channel_name, strength)
    ("NutriKids GrowPack",      "Supermarket",        "strong"),
    ("NutriKids GrowPack",      "Pharmacy",           "moderate"),
    ("NutriKids GrowPack",      "Online_Marketplace", "moderate"),
    ("NutriKids ProFormula",    "Pharmacy",           "strong"),
    ("NutriKids ProFormula",    "Online_Marketplace", "moderate"),
    ("FreshStart DailyBoost",   "Supermarket",        "strong"),
    ("FreshStart DailyBoost",   "Online_Marketplace", "strong"),
    ("FreshStart DailyBoost",   "Pharmacy",           "weak"),
    ("VitaPlus OmegaBlend",     "Pharmacy",           "strong"),
    ("VitaPlus OmegaBlend",     "Online_Marketplace", "strong"),
    ("VitaPlus OmegaBlend",     "Online_D2C",         "moderate"),
    ("VitaPlus SeniorCare",     "Pharmacy",           "strong"),
    ("VitaPlus SeniorCare",     "Online_Marketplace", "moderate"),
    ("QuickNutrish On-the-Go",  "Online_D2C",         "strong"),
    ("QuickNutrish On-the-Go",  "Online_Marketplace", "moderate"),
]

REVIEW_THEME_MENTIONS_BRAND = [
    ("price_increase_frustration",   "NutriKids",    -0.79),
    ("freshstart_momentum",          "FreshStart",    0.78),
    ("vitaplus_clean_label_buzz",    "VitaPlus",      0.86),
    ("packaging_usability_complaint","NutriKids",    -0.81),
    ("subscription_convenience",     "QuickNutrish",  0.84),
    ("competitor_switching_signals", "FreshStart",    0.72),
    ("artificial_additives_concern", "NutriKids",    -0.82),
    ("mommy_network_effect",         "FreshStart",    0.81),
    ("shrinkflation_detection",      "NutriKids",    -0.85),
]

# ─────────────────────────────────────────
# LOADER FUNCTIONS
# ─────────────────────────────────────────

def load_nodes(tx, label, items, merge_key):
    for item in items:
        props = ", ".join([f"{k}: ${k}" for k in item])
        tx.run(f"MERGE (n:{label} {{{merge_key}: ${merge_key}}}) SET n += {{{props}}}", **item)

def load_relationships(session):
    with session.begin_transaction() as tx:

        # Product -> Brand
        for p in PRODUCTS:
            tx.run("""
                MATCH (prod:Product {product_id: $pid}), (brand:Brand {brand_id: $bid})
                MERGE (prod)-[:BELONGS_TO]->(brand)
            """, pid=p["product_id"], bid=p["brand_id"])

        # Segment DRIVEN_BY NeedState
        for seg, need, rank, score in SEGMENT_DRIVEN_BY:
            tx.run("""
                MATCH (s:CustomerSegment {name: $seg}), (n:NeedState {need_name: $need})
                MERGE (s)-[r:DRIVEN_BY]->(n)
                SET r.rank = $rank, r.importance_score = $score
            """, seg=seg, need=need, rank=rank, score=score)

        # Segment PREFERS Product
        for seg, prod, share, trend, driver in SEGMENT_PREFERS:
            tx.run("""
                MATCH (s:CustomerSegment {name: $seg}), (p:Product {canonical_name: $prod})
                MERGE (s)-[r:PREFERS]->(p)
                SET r.share_pct = $share, r.trend = $trend, r.primary_driver = $driver
            """, seg=seg, prod=prod, share=share, trend=trend, driver=driver)

        # Segment SWITCHES_TO Competitor (Brand)
        for seg, comp, rate, trigger, period in SEGMENT_SWITCHES_TO:
            tx.run("""
                MATCH (s:CustomerSegment {name: $seg}), (b:Brand {canonical_name: $comp})
                MERGE (s)-[r:SWITCHES_TO]->(b)
                SET r.switch_rate_pct = $rate, r.primary_trigger = $trigger, r.time_period = $period
            """, seg=seg, comp=comp, rate=rate, trigger=trigger, period=period)

        # Competitor (Brand) WINS_ON Attribute
        for comp, attr, seg, score in COMPETITOR_WINS_ON:
            tx.run("""
                MATCH (b:Brand {canonical_name: $comp}), (a:Attribute {attribute_name: $attr})
                MERGE (b)-[r:WINS_ON]->(a)
                SET r.in_segment = $seg, r.score = $score
            """, comp=comp, attr=attr, seg=seg, score=score)

        # Product DISTRIBUTED_IN Channel
        for prod, chan, strength in PRODUCT_DISTRIBUTED_IN:
            tx.run("""
                MATCH (p:Product {canonical_name: $prod}), (c:Channel {channel_name: $chan})
                MERGE (p)-[r:DISTRIBUTED_IN]->(c)
                SET r.strength = $strength
            """, prod=prod, chan=chan, strength=strength)

        # ReviewTheme MENTIONS Brand
        for theme, brand, sentiment in REVIEW_THEME_MENTIONS_BRAND:
            tx.run("""
                MATCH (rt:ReviewTheme {theme_name: $theme}), (b:Brand {canonical_name: $brand})
                MERGE (rt)-[r:MENTIONS]->(b)
                SET r.sentiment = $sentiment
            """, theme=theme, brand=brand, sentiment=sentiment)

        tx.commit()

def main():
    with driver.session() as session:
        print("Loading CustomerSegment nodes...")
        session.execute_write(load_nodes, "CustomerSegment", SEGMENTS, "segment_id")
        print("Loading Brand nodes...")
        session.execute_write(load_nodes, "Brand", BRANDS, "brand_id")
        print("Loading Product nodes...")
        session.execute_write(load_nodes, "Product", PRODUCTS, "product_id")
        print("Loading NeedState nodes...")
        session.execute_write(load_nodes, "NeedState", NEED_STATES, "need_id")
        print("Loading ReviewTheme nodes...")
        session.execute_write(load_nodes, "ReviewTheme", REVIEW_THEMES, "theme_id")
        print("Loading Channel nodes...")
        session.execute_write(load_nodes, "Channel", CHANNELS, "channel_id")
        print("Loading Attribute nodes...")
        session.execute_write(load_nodes, "Attribute", ATTRIBUTES, "attr_id")
        print("Loading Campaign nodes...")
        session.execute_write(load_nodes, "Campaign", CAMPAIGNS, "campaign_id")
        print("Loading relationships...")
        load_relationships(session)
        print("Graph load complete!")
        print("Nodes: CustomerSegment(4), Brand(4), Product(6), NeedState(10), ReviewTheme(10), Channel(5), Attribute(12), Campaign(7)")
        print("Relationships: BELONGS_TO, DRIVEN_BY, PREFERS, SWITCHES_TO, WINS_ON, DISTRIBUTED_IN, MENTIONS")

if __name__ == "__main__":
    main()
    driver.close()
