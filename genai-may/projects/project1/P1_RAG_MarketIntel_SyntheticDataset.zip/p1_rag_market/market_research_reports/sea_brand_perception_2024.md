# SEA Urban Brand Perception Study 2024
**Study ID:** BP-SEA-URB-2024  
**Date:** November 2024  
**Markets Covered:** Singapore, Kuala Lumpur, Bangkok, Jakarta, Ho Chi Minh City  
**Sample Size:** 1,800 (SEC A/B urban adults 18-45)  
**Research Agency:** c5i Research  
**Study Type:** Brand Perception / Competitive Intelligence  
**Document Type:** Market Research Report  
**Brands Covered:** Brand A, Brand B, Brand C, Brand E  
**Metadata Tags:** sea|brand_perception|2024|personal_care|sustainability|competitive

---

## Executive Summary

The SEA urban personal care premium market has fundamentally shifted toward sustainability as a brand entry requirement. This study confirms that consumers in Singapore, Malaysia, and Thailand now treat eco-credentials as a baseline expectation — not a differentiator. Brands without credible sustainability stories are losing premium shelf space and consumer trust. Brand E is the clear beneficiary; Brand A is the clearest at-risk incumbent.

---

## Section 1: SEA Category Context

### 1.1 Premium vs Mass Market Split

Premium personal care (>SGD 8/USD 6 per unit) now accounts for 44% of SEA urban value sales, up from 31% in 2021. The mass-to-premium trading-up trend is most pronounced in Singapore (54% premium) and Malaysia (41%).

### 1.2 Sustainability as Category Entry Criterion

When asked what criteria would disqualify a brand from consideration in the premium segment:

| Disqualifier | % Respondents (Singapore) | % Respondents (Malaysia) | % Respondents (Thailand) |
|-------------|--------------------------|--------------------------|--------------------------|
| Non-recyclable packaging | 71% | 64% | 58% |
| No cruelty-free claim | 68% | 61% | 52% |
| No ingredient transparency | 54% | 48% | 44% |
| No sustainability roadmap | 49% | 42% | 38% |

**Implication:** A brand without at least one credible sustainability claim is now disqualified from consideration by a majority of premium segment consumers in Singapore and Malaysia.

---

## Section 2: Brand Performance in SEA

### 2.1 Brand Funnel (SEA Urban Premium Segment, 2024)

| Brand | Aided Awareness | Consideration | Purchase | Repeat Purchase | Premium Perception Score (1-10) |
|-------|-----------------|---------------|---------|-----------------|----------------------------------|
| Brand E | 64% | 58% | 41% | 67% | 8.9 |
| Brand B | 71% | 54% | 38% | 61% | 7.4 |
| Brand A | 79% | 29% | 18% | 32% | 4.2 |
| Brand C | 41% | 11% | 7% | 28% | 2.8 |

**Key finding:** Despite Brand A's highest aided awareness, its consideration rate (29%) is the second lowest — indicating awareness does not convert due to brand perception mismatch with SEA premium expectations.

### 2.2 Sustainability Score Comparison

| Brand | Sustainability Score (Consumer-Rated, 1-10) | Certification Held | Carbon Neutral Claim |
|-------|---------------------------------------------|-------------------|----------------------|
| Brand E | 9.2 | ISO 14001, Leaping Bunny | Yes (2024) |
| Brand B | 8.1 | Rainforest Alliance Certified ingredients | Committed by 2026 |
| Brand A | 2.8 | None declared | No |
| Brand C | 1.5 | None declared | No |

---

## Section 3: Brand E Deep-Dive

Brand E is the fastest growing brand in SEA urban premium, growing 34.1% YoY. Key success factors:

1. **Carbon-neutral hero SKU (2024):** First in category to achieve verified carbon neutrality. Strong press and consumer awareness (67% aided awareness of the claim among SEA premium buyers).
2. **Transparent ingredient labeling:** QR code on pack links to full ingredient sourcing page — 28% of buyers scanned in-store.
3. **Premium D2C experience:** SEA website conversion rate 4.2% vs category average 1.8%.
4. **Influencer x Sustainability:** Partnerships with sustainability-focused micro-influencers (avg 45K followers, authenticity-first content).

---

## Section 4: Risks and Opportunity Map

| Brand | Primary SEA Risk | Primary SEA Opportunity |
|-------|-----------------|-------------------------|
| Brand A | Perception as non-premium, non-sustainable mass brand | Could reposition if sustainability roadmap is credible and fast |
| Brand B | Brand E competition in premium; price ceiling in mass | Well-positioned; execution risk only |
| Brand E | Brand B in India; price sensitivity limiting addressable market | India premium e-commerce entry Q2 2025 |
| Brand C | No meaningful SEA presence; irrelevant to premium consumers | Rural SEA markets (Vietnam rural) potentially addressable |

---

*Study Conducted By: c5i Research*  
*Methodology: Online panel (CAWI) + in-store intercepts + social listening overlay*  
*Confidence Level: High*
