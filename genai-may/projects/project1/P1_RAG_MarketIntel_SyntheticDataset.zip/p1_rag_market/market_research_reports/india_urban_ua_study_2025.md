# India Urban Personal Care — Usage & Attitude Study 2025
**Study ID:** UA-IND-URB-2025  
**Date:** March 2025  
**Markets Covered:** Mumbai, Delhi, Bengaluru, Hyderabad, Pune, Chennai  
**Sample Size:** 2,400 (SEC A/B urban adults 18-55)  
**Research Agency:** c5i Research  
**Study Type:** Usage & Attitude  
**Document Type:** Market Research Report  
**Brands Covered:** Brand A, Brand B, Brand C, Brand D, Brand E  
**Metadata Tags:** ua_study|india_urban|2025|personal_care|all_brands|gen_z|segmentation

---

## Executive Summary

The India Urban personal care market is undergoing a structural shift driven by the ascent of Gen Z as a primary purchasing cohort. This study of 2,400 urban adults reveals three decisive trends: (1) Gen Z is now applying non-traditional purchase criteria (sustainability, digital-first, authentic brand voice) that legacy brands have not adapted to; (2) Brand A is experiencing a measurable erosion of relevance among the 18-25 segment; and (3) Brand B is the fastest-growing brand in aided consideration among urban youth.

**Key headline metrics (2025 vs 2023 comparison):**
- Brand A: urban aided awareness 71% (down from 79%); Gen Z purchase preference 22% (down from 38%)
- Brand B: urban aided awareness 62% (up from 47%); Gen Z purchase preference 54% (up from 31%)
- Brand C: urban aided awareness 49% (flat); Gen Z purchase preference 12% (down from 14%)

---

## Section 1: Category Overview

### 1.1 Category Penetration

Personal care category penetration in urban India stands at 94% among SEC A/B households. Frequency of use is daily for 78% of respondents. Category is characterized by habitual purchase with moderate switching — 31% of respondents switched primary brand in the past 12 months, up from 22% in 2023.

### 1.2 Purchase Channel Distribution (Urban, 2025)

| Channel | % Volume Share | YoY Change |
|---------|---------------|------------|
| E-Commerce (Amazon, Flipkart, Nykaa) | 23% | +4pp |
| Q-Commerce (Blinkit, Zepto, Swiggy Instamart) | 11% | +5pp |
| Modern Trade (Supermarkets, Hypermarkets) | 28% | -2pp |
| General Trade (Kirana stores) | 31% | -5pp |
| D2C / Brand App | 7% | +3pp |

**Implication:** Q-commerce is the fastest growing channel. Brands not optimized for q-commerce availability risk losing repeat purchase moments. Brand A's reported out-of-stock rate of 28% on q-commerce platforms represents a material conversion gap.

### 1.3 Switching Triggers (Top 5, Urban)

1. Quality dissatisfaction (34% of switchers)
2. Price increase without perceived value improvement (28%)
3. Peer/influencer recommendation of alternative (24%)
4. New product from competitor (18%)
5. Packaging change (9%)

---

## Section 2: Brand Performance Metrics

### 2.1 Brand Funnel (Urban, 2025 Q1)

| Brand | Aided Awareness | Unaided Awareness | Consideration | Purchase Intent | Recent Purchase | Loyalty (Sole Brand) |
|-------|-----------------|-------------------|---------------|-----------------|-----------------|----------------------|
| Brand A | 71% | 38% | 48% | 36% | 29% | 12% |
| Brand B | 62% | 29% | 51% | 43% | 32% | 18% |
| Brand C | 49% | 19% | 28% | 21% | 16% | 7% |
| Brand D | 41% | 11% | 22% | 18% | 14% | 4% |
| Brand E | 28% | 9% | 31% | 27% | 11% | 9% |

**Notable finding:** Brand B has overtaken Brand A in consideration (51% vs 48%) and purchase intent (43% vs 36%) — the first time in brand tracker history a challenger has led Brand A on both metrics in urban India.

### 2.2 Brand Attribute Associations (Unaided, Top 3 per Brand)

**Brand A:** Trusted (52%), Reliable (41%), Affordable (38%)  
**Brand B:** Modern (61%), Sustainable (48%), Quality (44%)  
**Brand C:** Affordable (68%), Available everywhere (54%), Family brand (39%)  
**Brand D:** Good deals/promotions (49%), Value for money (41%), Accessible (28%)  
**Brand E:** Premium (72%), Eco-friendly (66%), Innovative (58%)

**Brand A Gap Analysis:** Brand A is not associated with innovation, modernity, sustainability, or digital — the four attributes Gen Z consumers rank highest in purchase decisions.

---

## Section 3: Segment Deep-Dive — Gen Z (18-25 Urban)

### 3.1 Gen Z Purchase Criteria Ranking

| Rank | Criteria | % Rating as "Most Important" |
|------|----------|------------------------------|
| 1 | Authentic brand voice / values | 68% |
| 2 | Sustainable packaging | 61% |
| 3 | Available on apps / q-commerce | 54% |
| 4 | Competitive price | 47% |
| 5 | Widely available offline | 29% |

*Note: Price and offline availability, the top criteria for Gen X and Boomers, rank 4th and 5th for Gen Z.*

### 3.2 Gen Z Brand Preference Shifts (2023 vs 2025)

| Brand | Gen Z Preference 2023 | Gen Z Preference 2025 | Change |
|-------|-----------------------|-----------------------|--------|
| Brand A | 38% | 22% | **-16pp** |
| Brand B | 31% | 54% | **+23pp** |
| Brand C | 14% | 12% | -2pp |
| Brand D | 19% | 24% | +5pp |
| Brand E | N/A | 31% | New entrant |

**Brand A's Gen Z decline (-16pp) is the largest recorded drop for any brand in any segment in this study's history.**

### 3.3 Gen Z Qualitative Themes (Focus Group Synthesis)

Focus groups with 60 Gen Z participants in Mumbai and Delhi surfaced consistent themes:

- **"Uncle brand" perception:** Brand A is consistently described as the brand their parents use. "My dad buys Brand A" was a recurring phrase indicating the brand has become age-associated.
- **Sustainability gap:** Gen Z participants were aware that Brand A has made no public sustainability commitments. "They still use plastic that doesn't even have a recycle symbol" (Delhi respondent, 22F).
- **Digital absence:** Brand A has no loyalty app, no rewards program, and low social media presence. Gen Z sees this as disrespect: "They don't care about how we shop."
- **Campaign inauthenticity:** Reactions to Brand A's #FreshStartChallenge were negative — creators were seen as "old for the challenge" and content felt "sponsored, not real."
- **Brand B as the natural alternative:** Unprompted, Brand B was mentioned as the Gen Z default. "Brand B just gets it. Sustainable, on Blinkit, and actually good."

---

## Section 4: Channel and Occasion Analysis

### 4.1 Purchase Occasion by Channel (Gen Z Urban)

| Occasion | Primary Channel |
|----------|----------------|
| Daily replenishment | Q-commerce (Blinkit/Zepto) |
| Planned monthly stock-up | E-commerce (Amazon/Nykaa) |
| Impulse/trial | Modern trade |
| Gifting | D2C / Brand website |
| Convenience fallback | Kirana (General trade) |

**Implication for Brand A:** Weakest in the two highest-frequency Gen Z channels (q-commerce and e-commerce). Strongest in kirana, which Gen Z increasingly avoids.

---

## Section 5: Key Recommendations

1. **Brand A: Urgently address Gen Z relevance** — digital-first go-to-market, sustainability commitment, micro-influencer investment, loyalty app development
2. **Brand A: Fix q-commerce availability** — 28% OOS rate is a direct revenue leak; addressable within 90 days through distribution management
3. **Brand B: Protect and expand rural** — significant rural distribution gap (9.4% share vs Brand A's 31.5%) limits total addressable market
4. **Brand C: Consider aspirational line extension** — rural premiumisation trend creates window for a mid-tier product
5. **Brand E: India e-commerce launch readiness** — strong SEA playbook should translate to India premium e-commerce

---

*Study Conducted By: c5i Research*  
*Methodology: Structured CAPI interviews + online panel + qualitative focus groups*  
*Confidence Level: High (National Urban SEC A/B representative sample)*
