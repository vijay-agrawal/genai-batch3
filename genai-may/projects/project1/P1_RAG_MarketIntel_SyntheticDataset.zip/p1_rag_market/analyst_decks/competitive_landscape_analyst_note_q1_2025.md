# Analyst Note: Personal Care Competitive Landscape India & SEA
**Document ID:** AN-PC-2025-Q1  
**Date:** January 2025  
**Document Type:** Analyst Note  
**Study Type:** Competitive Intelligence  
**Brands Covered:** Brand A, Brand B, Brand C, Brand D, Brand E  
**Markets:** India Urban, India Rural, SEA Urban  
**Author:** c5i Research Analytics Team  
**Metadata Tags:** analyst_note|competitive|india|sea|2025|all_brands|market_share

---

## Investment & Strategy Summary

### Brand-by-Brand Analyst View

**Brand A — NEUTRAL / UNDERPERFORM RISK**

Brand A remains the market share leader in India (blended 29.8% across urban+rural) but the trajectory is negative. The brand is facing a structural trap: its heritage strengths (trust, wide distribution, affordability) are valued by segments with declining purchasing power growth (Gen X, Boomers, rural mass), while the high-growth segment (Gen Z urban) finds the brand irrelevant. Without a credible Gen Z engagement strategy — digital, sustainability, influencer — in the next 12 months, we expect Brand A to lose its urban consideration leadership to Brand B by Q4 2025.

Key risk factors:
- Gen Z preference declining at -5pp/quarter (Brand Tracker Wave 4-6 trajectory)
- Q-commerce OOS rate 28% — structural revenue leak
- No loyalty program, no sustainability commitments, no premium product with traction
- Campaign efficiency declining — cost per consideration point up 34% since 2023

**Brand B — OUTPERFORM**

Brand B is executing near-perfectly against the highest-growth segment and channel combination (Gen Z + digital/e-commerce). Revenue growth of 21.4% YoY is above category by 17pp. Brand B's Gen Z affinity score of 8.4/10 is effectively a moat that Brand A cannot close quickly. Primary risk: general trade and rural distribution gaps limit total addressable market. If Brand B solves rural reach in 2025-26, it could challenge Brand A's overall share leadership within 3 years.

**Brand C — STABLE / RURAL FORTRESS**

Brand C's 38.2% rural share is a significant structural asset. Urban performance is weak but not deteriorating rapidly. The rural premiumisation trend (Category Trend Note CT003) represents the primary medium-term risk — a well-priced aspirational product from Brand A or Brand B could erode Brand C's rural dominance. No evidence of Brand C product innovation in pipeline.

**Brand D — NEUTRAL / PROMOTION-DEPENDENT**

Brand D shows volume growth through aggressive e-commerce price promotion but limited brand equity building. Repeat purchase rate (28%) well below category (43%) suggests trial is not converting to loyalty. Risk of being commoditized and squeezed from above by Brand B and below by private label.

**Brand E — STRONG BUY (SEA) / INDIA WATCH**

Brand E is the fastest-growing brand in the study universe (34.1% YoY in SEA). Sustainability-first positioning is perfectly aligned with SEA premium segment requirements. India e-commerce entry planned Q2 2025 — if executed with the same playbook as SEA, could take meaningful share from Brand B in the premium segment.

---

## Key Questions for Next Quarter Monitoring

1. Does Brand A launch a credible sustainability initiative before end of 2025?
2. Does Brand B expand general trade and rural distribution materially?
3. Does Brand E India e-commerce entry gain traction (3-month post-launch check)?
4. Does Brand C respond to rural premiumisation threat with a mid-tier product?

---

## Data Appendix: Market Share Summary (Latest Available)

| Brand | India Urban % | India Rural % | SEA Urban % | Revenue INR Cr | YoY Growth % |
|-------|--------------|--------------|-------------|---------------|-------------|
| Brand A | 28.3 | 31.5 | 14.2 | 4,200 | -1.8 |
| Brand B | 22.1 | 9.4 | 18.7 | 2,800 | +21.4 |
| Brand C | 14.6 | 38.2 | 4.1 | 3,100 | +4.2 |
| Brand D | 10.2 | 8.1 | 9.8 | 1,400 | +6.8 |
| Brand E | 4.8 | 1.2 | 22.4 | 900 | +34.1 |

*Sources: Retail Audit Q1 2025, Brand Tracker Wave 6, Company disclosed financials where available.*

---

*This document is a c5i Research internal analyst note for client use only. Not for redistribution.*
