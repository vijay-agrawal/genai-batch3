import os
import glob
from urllib.parse import urlparse
from dotenv import load_dotenv
import streamlit as st
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_openai import AzureOpenAIEmbeddings, AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

load_dotenv()

# ── Candidate metadata registry ───────────────────────────────────────────────
# Map filename (without extension) → display name + LinkedIn URL
CANDIDATE_REGISTRY = {
    "kunal":     {"name": "Kunal Sharma",   "linkedin": "https://www.linkedin.com/in/kunal-sharma"},
    "pankaj_cv": {"name": "Pankaj Gupta",   "linkedin": "https://www.linkedin.com/in/pankaj-gupta"},
    "pooja":     {"name": "Pooja Mehta",    "linkedin": "https://www.linkedin.com/in/pooja-mehta"},
    "rahul":     {"name": "Rahul Verma",    "linkedin": "https://www.linkedin.com/in/rahul-verma"},
}

DATA_DIR    = os.path.join(os.path.dirname(__file__), "data")
CHROMA_PATH = os.path.join(os.path.dirname(__file__), "chroma_resumes_metadata")
COLLECTION  = "resumes_with_metadata"


# ── Azure OpenAI helpers ───────────────────────────────────────────────────────

def _embedding_base_url(full_url: str) -> str:
    """Extract base URL (scheme + host) from the full embedding endpoint."""
    parsed = urlparse(full_url)
    return f"{parsed.scheme}://{parsed.netloc}/"


def get_embeddings():
    full_endpoint = os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT", "")
    base_endpoint = _embedding_base_url(full_endpoint) if full_endpoint else ""
    return AzureOpenAIEmbeddings(
        azure_endpoint=base_endpoint,
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
        azure_deployment=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME", "text-embedding-3-small"),
        api_version="2023-05-15",
    )


def get_llm():
    llm = AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        model=os.getenv("AZURE_OPENAI_MODEL_NAME"),
        max_tokens=500,
        temperature=0.7
    )
    return llm

# ── Indexing ───────────────────────────────────────────────────────────────────

def index_resumes(embeddings):
    """Load resume PDFs, attach metadata, chunk, and store in ChromaDB."""
    resume_files = [
        f for f in glob.glob(os.path.join(DATA_DIR, "*.pdf"))
        if os.path.splitext(os.path.basename(f))[0] in CANDIDATE_REGISTRY
    ]

    if not resume_files:
        st.error(f"No resume PDFs found in {DATA_DIR}")
        st.stop()

    all_chunks = []
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)

    for pdf_path in resume_files:
        filename     = os.path.basename(pdf_path)
        file_key     = os.path.splitext(filename)[0]
        candidate    = CANDIDATE_REGISTRY[file_key]

        pages = PyPDFLoader(pdf_path).load()
        chunks = splitter.split_documents(pages)

        for chunk in chunks:
            chunk.metadata["candidate_name"] = candidate["name"]
            chunk.metadata["linkedin_url"]   = candidate["linkedin"]
            chunk.metadata["filename"]        = filename

        all_chunks.extend(chunks)

    vectorstore = Chroma.from_documents(
        documents=all_chunks,
        embedding=embeddings,
        collection_name=COLLECTION,
        persist_directory=CHROMA_PATH,
    )
    return vectorstore



# ── RAG query ─────────────────────────────────────────────────────────────────

def run_query(question: str, vectorstore, candidate_filter: str | None):
    """Retrieve chunks (with optional metadata filter) and generate an LLM answer."""
    search_kwargs = {"k": 5}
    if candidate_filter:
        search_kwargs["filter"] = {"candidate_name": {"$eq": candidate_filter}}

    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs=search_kwargs,
    )
    docs = retriever.invoke(question)

    if not docs:
        return "No relevant information found for the given query and filters.", []

    context = "\n\n".join(
        f"[{doc.metadata.get('candidate_name', 'Unknown')}] {doc.page_content}"
        for doc in docs
    )

    prompt = ChatPromptTemplate.from_template(
        """You are an expert HR assistant. Use the resume excerpts below to answer the question.
If the answer is not found in the context, say so clearly. Be concise.

Context:
{context}

Question: {question}

Answer:"""
    )

    llm    = get_llm()
    chain  = prompt | llm
    answer = chain.invoke({"context": context, "question": question}).content
    return answer, docs


# ── Streamlit UI ───────────────────────────────────────────────────────────────

# Clear any persisted vector DB from a previous run on startup
if "app_initialized" not in st.session_state:
    import shutil
    if os.path.exists(CHROMA_PATH):
        shutil.rmtree(CHROMA_PATH)
    st.session_state["app_initialized"] = True

st.set_page_config(page_title="Resume RAG – Metadata Filter Demo", layout="wide")
st.title("Resume RAG with Metadata Filtering")
st.caption("Ask questions about candidates. Optionally filter by candidate name to narrow retrieval.")

# Sidebar ─────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("Candidates")
    for info in CANDIDATE_REGISTRY.values():
        st.markdown(f"- {info['name']}")

    st.divider()

    if st.button("Index Documents", type="primary"):
        import shutil
        with st.spinner("Indexing PDFs…"):
            if os.path.exists(CHROMA_PATH):
                shutil.rmtree(CHROMA_PATH)
            embeddings = get_embeddings()
            vs = index_resumes(embeddings)
            st.session_state["vectorstore"] = vs
        st.success("Indexing complete!")

# Main area ───────────────────────────────────────────────────────────────────

if "vectorstore" not in st.session_state:
    st.warning("No index found. Click **Index Documents** in the sidebar to build the vector store.")
    st.stop()

vectorstore = st.session_state["vectorstore"]
total_docs = vectorstore._collection.count()
st.info(f"Vector store ready — {total_docs} chunks indexed from {len(CANDIDATE_REGISTRY)} resumes.")

# Filter dropdown just above chat input
all_names      = ["All candidates"] + [v["name"] for v in CANDIDATE_REGISTRY.values()]
selected_label = st.selectbox("Filter by candidate:", all_names)
candidate_filter = None if selected_label == "All candidates" else selected_label

question = st.text_input("Ask a question about the candidates:", placeholder="e.g. What are Kunal's skills?")

if st.button("Search", type="primary") and question:
    with st.spinner("Retrieving and generating answer…"):
        answer, docs = run_query(question, vectorstore, candidate_filter)

    # ── LLM Answer ──────────────────────────────────────────────────────────
    st.subheader("LLM Answer")
    st.markdown(answer)

    st.divider()

    # ── Retrieved Chunks + Metadata ─────────────────────────────────────────
    st.subheader(f"Retrieved Chunks ({len(docs)} found)")

    if not docs:
        st.warning("No chunks were retrieved. Try a different query or remove the candidate filter.")
    else:
        for i, doc in enumerate(docs, 1):
            meta = doc.metadata
            with st.expander(
                f"Chunk {i} — {meta.get('candidate_name', 'Unknown')}  |  "
                f"Page {meta.get('page', meta.get('page_number', '?'))}  |  "
                f"{meta.get('filename', '')}"
            ):
                # Metadata table
                col1, col2, col3 = st.columns(3)
                col1.metric("Candidate", meta.get("candidate_name", "—"))
                col2.metric("File", meta.get("filename", "—"))
                col3.metric("Page", str(meta.get("page", meta.get("page_number", "—"))))

                linkedin = meta.get("linkedin_url", "")
                if linkedin:
                    st.markdown(f"LinkedIn: [{linkedin}]({linkedin})")

                st.markdown("**Chunk text:**")
                st.text(doc.page_content)
