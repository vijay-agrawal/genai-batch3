# ABC Bank Limited - Market Risk Management Policy 2024

**Document Control:**
- **Policy Owner:** Chief Risk Officer
- **Approved by:** Board Risk Management Committee
- **Effective Date:** January 1, 2024
- **Review Frequency:** Annual
- **Version:** 5.0
- **Classification:** Internal - Confidential

---

## 1. Executive Summary

This policy establishes the market risk management framework for ABC Bank Limited ("the Bank"). It defines risk appetite, governance structure, measurement methodologies, limits, and controls to ensure prudent management of market risk arising from trading and non-trading activities.

**Scope:** This policy applies to all market risk exposures across:
- Treasury and Markets Division (Trading Book)
- Asset-Liability Management (Banking Book interest rate risk)
- Overseas branches and subsidiaries engaged in market-facing activities

---

## 2. Market Risk Appetite Statement

### 2.1 Board-Approved Risk Appetite

The Board has approved the following risk appetite for market risk:

**Quantitative Metrics:**

| Metric | Limit | Rationale |
|--------|-------|-----------|
| Daily 99% VaR | Max ₹75 crore | Not to exceed 2% of Tier 1 capital |
| Stressed VaR | Max ₹150 crore | Not to exceed 4% of Tier 1 capital |
| Maximum Single-Day Loss | ₹100 crore | Risk event trigger requiring immediate Board notification |
| Expected Shortfall (97.5%) | Max ₹200 crore | For FRTB compliance (future) |
| Annual VaR Breaches | ≤ 4 exceptions | Green zone per Basel / RBI norms |

**Qualitative Principles:**

1. Market risk-taking is **not** the Bank's core competency; primary focus is customer-driven flow trading
2. Proprietary trading must be limited to highly liquid instruments (Government Securities, AAA corporate bonds, Nifty/Bank Nifty derivatives)
3. No exposure to exotic derivatives without prior Board approval
4. Market risk capital consumption should not exceed 15% of total Pillar 1 capital requirements

### 2.2 Risk Appetite Monitoring

- Chief Risk Officer (CRO) reports risk appetite utilization to Board quarterly
- Early warning thresholds set at 80% of limits
- Breaches require immediate escalation and management action plan within 48 hours

---

## 3. Governance Framework

### 3.1 Board Risk Management Committee (BRMC)

**Responsibilities:**
- Approve market risk policy and risk appetite annually
- Review significant VaR breaches, stress test results, and limit exceptions quarterly
- Assess adequacy of capital allocation for market risk
- Approve new products with market risk implications

**Composition:** 3 independent directors (including Chairman), CEO, CRO

**Meeting Frequency:** Quarterly (minimum)

### 3.2 Asset-Liability Committee (ALCO)

**Responsibilities:**
- Set and monitor position limits for Treasury desks
- Approve hedging strategies for interest rate and FX risk
- Review monthly VaR and stress test reports
- Approve deviations from limits (within delegated authority)

**Composition:** CEO (Chairman), CFO, CRO, Head of Treasury, Head of Retail Banking, Head of Corporate Banking

**Meeting Frequency:** Fortnightly

### 3.3 Market Risk Committee (MRC)

**Responsibilities:**
- Daily monitoring of VaR, P&L, and limit utilization
- Approve intraday limit breaches and extensions
- Investigate and document all VaR exceptions within 24 hours
- Coordinate with Front Office on risk mitigation actions

**Composition:** CRO (Chairman), Head of Market Risk, Head of Treasury, Senior Traders

**Meeting Frequency:** Daily (9:00 AM and 4:30 PM)

### 3.4 Independent Risk Function

**Market Risk Department (reporting to CRO):**
- Independent of Front Office and Treasury
- Performs daily VaR calculation, backtesting, and stress testing
- Validates pricing models and risk sensitivities
- Maintains risk systems (Murex, Bloomberg MARS) and data integrity
- Escalates limit breaches and exceptions

**Staffing:** 12 FTE with expertise in quantitative finance, risk modeling, and regulations

---

## 4. Market Risk Measurement

### 4.1 Value-at-Risk (VaR)

**Primary Methodology:** Historical Simulation

**Parameters:**
- Confidence Level: 99% (one-tailed)
- Holding Period: 10 days (regulatory); 1 day (management)
- Observation Period: 252 trading days (~1 year)
- Data Update: Daily

**Calculation Process:**
1. Capture end-of-day positions from front office systems (Murex, Bloomberg FXGO)
2. Obtain historical risk factor returns (yield curves, FX rates, equity indices, implied volatilities) from Bloomberg
3. Revalue portfolio using each of the past 252 days' risk factor changes
4. Sort simulated P&L outcomes and identify 3rd worst loss (99th percentile)
5. Report 1-day VaR for management; scale to 10-day VaR using √10 for regulatory capital

**Coverage:**
- Interest Rate Risk: Government bonds, corporate bonds, interest rate swaps, FRAs
- Equity Risk: Exchange-traded stocks, equity derivatives (Nifty, Bank Nifty), equity-linked notes
- Foreign Exchange Risk: Spot FX, FX forwards, FX options (major currencies: USD, EUR, GBP, JPY, AED)
- Commodity Risk: Limited to gold (physical and derivatives)

**Model Validation:** Annual review by independent Model Validation Unit covering:
- Backtesting performance (exceptions vs. expected)
- Sensitivity to look-back window and historical period choice
- Benchmark against parametric VaR and Monte Carlo VaR

### 4.2 Stressed VaR

**Stress Period Selection:**
- 12-month window identified from historical data that would produce maximum portfolio loss
- Current stress period: June 2008 - May 2009 (Global Financial Crisis)
- Reassessed annually by Market Risk Committee

**Calculation:** Same as VaR but using risk factor returns from the identified stress period

### 4.3 Sensitivity Measures

In addition to VaR, the Bank calculates:

**Interest Rate Risk:**
- PV01 (Price Value of a Basis Point): Sensitivity to 1 bp parallel shift
- Key Rate Durations: Sensitivity to 1 bp change at specific maturity points (2Y, 5Y, 10Y)
- Convexity: Second-order sensitivity for large rate movements

**Equity Risk:**
- Delta: Sensitivity to 1% move in underlying equity/index
- Gamma: Rate of change of delta (for options)
- Vega: Sensitivity to 1% change in implied volatility (for options)

**Foreign Exchange Risk:**
- Net Open Position by currency
- Delta-equivalent exposure for FX options

**Aggregation:** Sensitivities reported at desk level, asset class level, and bank-wide level daily

### 4.4 Backtesting

**Daily Backtesting:**
- Compare actual daily P&L to 1-day 99% VaR estimate
- P&L calculated on a clean basis (excluding fees, commissions, new trades)
- Exception recorded when loss exceeds VaR

**Exception Analysis:**
- For each exception, Market Risk prepares memo within 24 hours explaining:
  - Which risk factors drove the loss
  - Whether exception was due to model deficiency or genuine tail event
  - Proposed remedial actions (limit reductions, model enhancements)

**RBI Reporting:** All exceptions reported to RBI within 2 business days

**Backtesting Performance (2023):**
- Total Exceptions: 3 (Green Zone)
- Multiplication Factor: 3.00 (minimum)

---

## 5. Risk Limits Framework

### 5.1 VaR Limits

**Bank-wide Limits:**

| Level | 1-Day 99% VaR Limit | 10-Day VaR Limit |
|-------|---------------------|------------------|
| Total Bank | ₹12 crore | ₹75 crore |
| Treasury (Trading Book) | ₹10 crore | ₹63 crore |
| Overseas Branches | ₹2 crore | ₹12 crore |

**Desk-Level Limits (1-Day VaR):**

| Desk | Limit (₹ Crore) |
|------|-----------------|
| G-Sec Trading | 4.0 |
| Corporate Bond Trading | 3.0 |
| Equity Derivatives | 2.5 |
| FX Trading | 1.5 |
| Proprietary Trading | 1.0 |

### 5.2 Position Limits

**Interest Rate Products:**
- Modified Duration: Max 5.0 years on G-Sec portfolio
- PV01: Max ₹25 lakhs per 1 bp move
- Single Issuer (Corporate Bonds): Max ₹500 crore or 10% of portfolio

**Equity Products:**
- Single Stock Exposure: Max ₹100 crore
- Nifty Futures: Max 2000 lots (₹1500 crore notional)
- Options Delta: Max 5000 Nifty equivalents
- Options Vega: Max ₹2 crore per 1% vol change

**Foreign Exchange:**
- Net Open Position per currency: Max USD 50 million equivalent
- Aggregate Net Open Position (all currencies): Max USD 100 million
- Intraday FX Position: Max USD 75 million

**Stop-Loss Limits:**
- Desk Level: ₹5 crore daily loss triggers mandatory risk reduction
- Trader Level: ₹1 crore daily loss triggers review and potential position closure
- Monthly Cumulative Loss: ₹15 crore triggers trading suspension and investigation

### 5.3 Concentration Limits

- No single risk factor should contribute > 40% of total VaR
- Top 5 risk factors should not exceed 75% of total VaR
- Reviewed monthly by ALCO

### 5.4 Limit Breach Protocol

**Intraday Breaches:**
1. Trader notifies Desk Head and Market Risk immediately
2. Desk Head has 2 hours to bring exposure within limit or obtain ALCO approval
3. If not resolved, CRO mandates position reduction

**End-of-Day Breaches:**
1. Market Risk sends automated alert to Desk Head, CRO, and CFO
2. Desk Head submits action plan by next morning
3. ALCO reviews in next meeting (within 14 days)
4. Persistent breaches (>3 consecutive days) reported to BRMC

---

## 6. Stress Testing

### 6.1 Regulatory Stress Tests (Monthly)

The Bank conducts the following RBI-mandated scenarios:

**Interest Rate Stress:**
- +200 bps parallel shift
- -200 bps parallel shift
- Steepening: Short end +100 bps, Long end +300 bps
- Flattening: Short end -50 bps, Long end +150 bps

**Equity Stress:**
- Nifty 50: -30%
- Bank Nifty: -40%
- Sectoral collapse: -50% in highest concentration sector

**FX Stress:**
- USD/INR: +20%
- Concurrent equity fall: -20%

**Commodity Stress:**
- Gold: ±25%

### 6.2 Bank-Specific Scenarios (Quarterly)

Developed by Market Risk and validated by Risk Committee:

**Scenario 1: Replay of 2013 Taper Tantrum**
- 10Y G-Sec yield: +150 bps over 2 months
- INR depreciation: +15%
- Equity market correction: -15%
- Corporate bond spreads: +75 bps

**Scenario 2: Global Risk-Off**
- FII outflows trigger INR weakness (+20%)
- India VIX spikes to 45
- Government bond sell-off (+100 bps in 10Y yield)
- Liquidity crunch: Bid-ask spreads widen 5x

**Scenario 3: Domestic Political/Fiscal Event**
- Sovereign rating downgrade concerns
- 10Y G-Sec yield: +200 bps
- Banking stocks: -35%
- FX intervention by RBI (USD/INR volatility doubles)

### 6.3 Reverse Stress Testing (Annual)

**Objective:** Identify scenarios that would:
- Reduce CET1 ratio below 8.5% (internal threshold above 7% minimum)
- Cause losses exceeding ₹500 crore

**Recent Findings (2023):**
- Combination of +300 bps rate shock + 40% equity crash + 25% INR depreciation would cause ~₹650 crore loss
- Mitigation: Enhanced monitoring of correlation risks, dynamic hedging program

---

## 7. Hedging and Risk Mitigation

### 7.1 Strategic Hedges

The Bank maintains strategic hedges for:

**Interest Rate Risk (Banking Book):**
- Receive-fixed interest rate swaps to hedge floating-rate assets (loans)
- Target: Reduce interest rate gap from ₹15,000 crore to ₹8,000 crore

**Foreign Exchange Risk:**
- Natural hedge: Match USD assets (export finance) with USD liabilities (FCNR deposits)
- Residual FX risk hedged using FX forwards

**Equity Risk:**
- Limited use of index futures to hedge equity-linked notes sold to UHNI clients

### 7.2 Hedge Effectiveness Testing

- Monthly regression analysis of hedge vs. hedged item
- Effectiveness ratio must be within 80%-125%
- Ineffective hedges redesigned or discontinued

### 7.3 Prohibited Instruments

The Bank **does not** trade in:
- Credit default swaps (CDS) - except for hedging loan book, subject to ALCO approval
- Exotic options (digital, barrier, lookback) - unless client-driven and back-to-backed
- Leveraged derivatives (>1x notional)
- Cryptocurrencies or crypto derivatives

---

## 8. Pricing and Valuation

### 8.1 Mark-to-Market (MTM) Principles

**Daily MTM:**
- All trading book positions marked to market daily at 4:00 PM IST close prices
- Sources: NSE/BSE closing prices (equities), FIMMDA (bonds), Bloomberg (FX, swaps)

**Valuation Adjustments:**
- Credit Valuation Adjustment (CVA): Applied to OTC derivatives based on counterparty credit risk
- Funding Valuation Adjustment (FVA): Applied to uncollateralized derivatives
- Model Risk Reserve: 1% of MTM for complex models (options, structured products)

### 8.2 Independent Price Verification (IPV)

**Process:**
- Middle Office (Finance) independently verifies Front Office marks daily
- Tolerance: ±5 bps for bonds, ±2% for equities, ±3% for FX forwards
- Discrepancies escalated to CFO and CRO

**Frequency:**
- Daily for positions > ₹50 crore
- Weekly for smaller positions
- Monthly deep-dive for entire portfolio

### 8.3 Fair Value Hierarchy

- **Level 1:** Quoted prices in active markets (90% of portfolio)
- **Level 2:** Observable inputs (yield curves, FX forwards) - 8% of portfolio
- **Level 3:** Unobservable inputs (illiquid corporate bonds, structured products) - 2% of portfolio

Level 3 positions require senior management sign-off and monthly ALCO review.

---

## 9. Model Risk Management

### 9.1 Model Inventory

All market risk models registered in Model Inventory System:

| Model ID | Model Name | Vendor/In-house | Last Validated |
|----------|------------|-----------------|----------------|
| MRM-001 | Historical Simulation VaR | In-house (Python) | Jan 2024 |
| MRM-002 | Black-Scholes Option Pricer | Bloomberg OVME | Mar 2023 |
| MRM-003 | Interest Rate Swap Pricer | Murex | Jun 2023 |
| MRM-004 | FX Forward Pricer | In-house (Excel) | Nov 2023 |

### 9.2 Model Validation

**Annual Validation by Independent Unit:**
- Conceptual soundness (theory, assumptions)
- Mathematical accuracy (implementation, coding)
- Empirical performance (backtesting, benchmarking)
- Data quality and integrity
- Limitations and appropriate use

**Validation Report:**
- Rating: Approved / Conditional Approval / Restricted Use / Reject
- Recommendations for enhancements
- Timeline for remediation

### 9.3 Model Change Control

All model changes (formula, parameters, data) require:
1. Change request form with business justification
2. Approval from Model Risk Manager
3. Testing in parallel environment (min 30 days)
4. Sign-off from CRO before production deployment

---

## 10. Reporting

### 10.1 Daily Reports

**To Desk Heads and ALCO (by 9:00 AM next day):**
- VaR by desk and asset class
- Actual P&L vs. VaR
- Limit utilization (%)
- New limit breaches and exceptions

### 10.2 Monthly Reports

**To ALCO and BRMC:**
- VaR trending (time series charts)
- Stress test results with heatmaps
- Backtesting performance and exceptions analysis
- Top 10 risk factors and concentrations
- Model performance and validation status

### 10.3 Regulatory Reports

**To RBI:**
- Market Risk Capital (Form MR-1): Quarterly
- Stress Test Results (Form STR-1): Semi-annually
- VaR Exceptions: Within 2 business days of occurrence
- Annual ICAAP: Market risk assessment and capital adequacy

---

## 11. Business Continuity and Disaster Recovery

### 11.1 Risk System Availability

- Target Uptime: 99.5% during trading hours
- Real-time replication to Disaster Recovery (DR) site (Hyderabad)
- DR activation within 4 hours (RTO)
- Data loss tolerance: Max 15 minutes (RPO)

### 11.2 Contingency Procedures

**In case of system failure:**
1. Switch to manual position tracking (Excel templates)
2. Use Bloomberg PORT for approximate VaR calculation
3. Desk Heads impose 50% reduction in position limits
4. Resume automated systems before next day's trading

**Backup Data Sources:**
- Primary: Bloomberg
- Secondary: Refinitiv Eikon
- Tertiary: NSE/BSE direct feeds

---

## 12. Training and Competency

### 12.1 Mandatory Training

**Front Office (Annual):**
- Market risk fundamentals and VaR concepts
- Limit framework and breach protocol
- Product-specific training (options Greeks, bond convexity)

**Risk and Middle Office (Annual):**
- Advanced quantitative methods
- Regulatory updates (Basel, RBI, SEBI)
- Risk systems and tools (Murex, Python)

### 12.2 Certification Requirements

- Market Risk Analysts: FRM (GARP) or CFA Level 2
- Traders: NISM certification (relevant modules)
- Risk Managers: Minimum 5 years experience in market risk

---

## 13. Policy Review and Updates

This policy is reviewed annually by the CRO and approved by the BRMC. Ad-hoc updates may be made for:
- Regulatory changes (RBI, SEBI, Basel)
- Material changes in business model or risk profile
- Lessons learned from risk events or near-misses

**Next Review Date:** December 31, 2024

---

## Annexure A: Definitions

- **Trading Book:** Positions held with intent to trade or hedge other trading book positions
- **Banking Book:** All positions not in the trading book (loans, investment securities HTM)
- **Clean P&L:** P&L excluding fees, commissions, and new business
- **Exception:** Day when actual loss exceeds VaR estimate

---

**Approved by:**

_________________________  
**Mr. Rajesh Kumar**  
Chief Risk Officer

_________________________  
**Ms. Priya Sharma**  
Chairperson, Board Risk Management Committee

**Date:** January 15, 2024

---

*This policy is confidential and for internal use only. Unauthorized distribution is prohibited.*