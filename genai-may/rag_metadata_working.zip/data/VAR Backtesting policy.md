# VaR Backtesting Policy and Traffic Light Framework

**ABC Bank Limited**  
**Document Owner:** Head of Market Risk  
**Approved by:** Chief Risk Officer  
**Effective Date:** January 1, 2024  
**Version:** 3.0

---

## 1. Purpose and Scope

This policy establishes the framework for backtesting Value-at-Risk (VaR) model performance at ABC Bank Limited. Backtesting is a critical validation tool that compares actual trading outcomes against VaR estimates to ensure the model adequately captures market risk.

**Objectives:**
- Verify statistical accuracy of VaR model (99% confidence level should result in ~1% exception rate)
- Identify model weaknesses or calibration issues
- Comply with RBI and Basel requirements for internal models
- Determine capital multiplication factors based on performance
- Trigger remedial actions for poor model performance

**Scope:** Applies to all VaR models used for:
- Regulatory capital calculation (10-day, 99% VaR)
- Internal risk management (1-day, 99% VaR)
- Trading book positions across all asset classes

---

## 2. Backtesting Methodology

### 2.1 Definition of VaR Exception

A **VaR exception (or breach)** occurs when the actual trading loss on a given day exceeds the VaR estimate for that day.

**Formula:**
```
Exception = TRUE if: (Actual P&L) < (-VaR estimate)
```

**Example:**
- VaR estimate for Day T: ₹8 crore (at 99% confidence, we expect losses to exceed this only 1% of the time)
- Actual P&L on Day T: -₹10 crore loss
- **Result:** Exception recorded, as loss exceeded VaR

### 2.2 P&L Calculation for Backtesting

**Clean P&L Approach:**

For backtesting, we use "clean" or "hypothetical" P&L that includes:
- Mark-to-market changes on positions held at prior day's close
- Actual market movements on Day T
- Excludes: Intraday trades, fees, commissions, reserves

**Rationale:** Clean P&L isolates the impact of market movements on the overnight position, which is what VaR is designed to estimate.

**Example:**

```
Position at close on Day T-1: 1000 lots Nifty Futures at 21,000
VaR estimate for Day T: ₹6 crore

Day T Market Movement: Nifty falls from 21,000 to 20,500 (-500 points)
Clean P&L = 1000 lots × 75 units/lot × (-500 points) = -₹3.75 crore

Comparison:
-₹3.75 crore loss < ₹6 crore VaR → No exception

If Nifty had fallen to 19,200 (-1,800 points):
Clean P&L = 1000 lots × 75 × (-1,800) = -₹13.5 crore
-₹13.5 crore loss > ₹6 crore VaR → Exception!
```

### 2.3 Frequency and Observation Period

**Daily Backtesting:**
- Performed every business day by 10:00 AM (after EOD positions and P&L finalized)
- Results logged in Risk Management Information System (RMIS)

**Rolling Window:**
- Exceptions counted over trailing 250 business days (~1 year)
- Updated daily, oldest day drops off as new day is added
- Traffic light zone determined based on current 250-day window

---

## 3. Basel Traffic Light Framework

### 3.1 Zone Classification

The Basel Committee (and RBI) uses a traffic light approach to assess VaR model performance based on the number of exceptions in the past 250 days.

| Zone | Number of Exceptions | Implication |
|------|---------------------|-------------|
| **Green Zone** | 0 to 4 | Model performing adequately; minimum capital multiplication factor |
| **Yellow Zone** | 5 to 9 | Model performance questionable; increased multiplication factor and monitoring |
| **Red Zone** | 10 or more | Model inadequate; maximum multiplication factor, mandatory review, potential RBI restrictions |

### 3.2 Statistical Basis

At 99% confidence level, we expect:
- **Expected exceptions:** 2.5 exceptions per 250 days (1% × 250 = 2.5)
- **Green Zone (0-4):** Within normal statistical variation
- **Yellow Zone (5-9):** Marginally higher than expected, warrants investigation
- **Red Zone (10+):** Statistically significant evidence of model failure (p-value < 0.05 using binomial test)

**Cumulative Binomial Probability (at 99% VaR over 250 days):**

| Exceptions | Probability | Cumulative | Interpretation |
|-----------|-------------|------------|----------------|
| 0 | 8.1% | 8.1% | Unlikely but possible |
| 1 | 20.5% | 28.6% | Reasonable |
| 2 | 25.7% | 54.3% | Most likely |
| 3 | 21.5% | 75.8% | Reasonable |
| 4 | 13.4% | 89.2% | Upper end of normal |
| 5 | 6.7% | 95.9% | Yellow zone begins |
| ... | ... | ... | ... |
| 10 | 0.08% | 99.96% | Red zone: model likely flawed |

### 3.3 Capital Multiplication Factors

The multiplication factor determines the capital charge:

**Formula:**
```
Market Risk Capital = Multiplication Factor × max(VaRₜ₋₁, VaRₐᵥ𝓰₆₀)
                     + Multiplication Factor × max(SVaRₜ₋₁, SVaRₐᵥ𝓰₆₀)
```

**Multiplication Factor Schedule:**

| Number of Exceptions | Zone | Multiplication Factor |
|---------------------|------|----------------------|
| 0 | Green | 3.00 |
| 1 | Green | 3.00 |
| 2 | Green | 3.00 |
| 3 | Green | 3.00 |
| 4 | Green | 3.00 |
| 5 | Yellow | 3.40 |
| 6 | Yellow | 3.50 |
| 7 | Yellow | 3.65 |
| 8 | Yellow | 3.75 |
| 9 | Yellow | 3.85 |
| 10+ | Red | 4.00 |

**Impact Example:**

```
Scenario: Bank has 6 exceptions (Yellow Zone)

Current VaRₜ₋₁: ₹70 crore
VaRₐᵥ𝓰₆₀: ₹65 crore

Green Zone Capital (factor 3.00): 3.00 × ₹70 cr = ₹210 crore
Yellow Zone Capital (factor 3.50): 3.50 × ₹70 cr = ₹245 crore

Additional Capital Required: ₹35 crore (16.7% increase)
```

---

## 4. Exception Analysis and Documentation

### 4.1 Immediate Actions (Same Day)

**Step 1: Exception Identification (by 10:00 AM)**
- Market Risk team identifies exception through automated RMIS alert
- Preliminary review of which positions/risk factors caused the breach

**Step 2: Notification (by 11:00 AM)**
- Email alert to: CRO, Head of Market Risk, Desk Head, Trader
- Include: Date, VaR estimate, Actual P&L, Excess loss

**Step 3: Initial Assessment (by 4:00 PM same day)**
- Market Risk Analyst prepares preliminary analysis:
  - Which market movements drove the loss?
  - Was the market move captured in VaR historical data?
  - Were there any data errors or system issues?

### 4.2 Detailed Exception Report (T+1)

**Within 24 hours of exception**, Market Risk prepares comprehensive memo covering:

#### Section 1: Exception Summary
- Date of exception
- VaR estimate vs. Actual P&L
- Desk/portfolio affected
- Current zone status (Green/Yellow/Red)

#### Section 2: Root Cause Analysis

**Potential Causes:**

**a) Genuine Tail Event**
- Market moved more than historical data suggested (e.g., unprecedented COVID-19 crash)
- Model is working correctly; this is expected ~1% of the time
- **Action:** None required if within statistical norms (Green Zone)

**b) Model Deficiency**
- Risk factor not captured (e.g., basis risk between cash and futures)
- Correlation breakdown (assumed +0.7 correlation, actual was -0.3)
- Fat tail risk underestimated by historical simulation
- **Action:** Model enhancement required

**c) Volatility Regime Change**
- Recent volatility higher than historical 250-day window
- Historical simulation using stale data from low-volatility period
- **Action:** Consider shorter observation window or volatility scaling

**d) Data or System Error**
- Incorrect position or price feed
- Calculation error in VaR or P&L
- **Action:** Fix process, restate if material

**e) New/Complex Instrument**
- Newly introduced product not adequately modeled
- Greeks or sensitivities mis-estimated
- **Action:** Enhance model or restrict product until validated

#### Section 3: Risk Factor Attribution

Break down the loss by risk factor:

**Example:**

| Risk Factor | Contribution to Loss (₹ Cr) | % of Total |
|-------------|---------------------------|-----------|
| 10Y G-Sec yield +25 bps | -4.5 | 45% |
| Nifty -3.2% | -3.2 | 32% |
| USD/INR +1.8% | -1.5 | 15% |
| Corporate spread widening | -0.8 | 8% |
| **Total** | **-10.0** | **100%** |

Compare this attribution to VaR's implied risk factor contributions to identify gaps.

#### Section 4: Impact Assessment

- Effect on capital (if entering Yellow/Red zone)
- Effect on risk appetite utilization
- Reputational impact (if requiring RBI disclosure)

#### Section 5: Remedial Actions

**Immediate (T+1 to T+5):**
- Reduce positions if systemic model issue identified
- Implement temporary limit reductions (e.g., 20% cut) pending investigation
- Enhanced monitoring (twice-daily risk reporting)

**Short-term (T+5 to T+30):**
- Model enhancements (e.g., incorporate new risk factor, adjust observation period)
- Recalibration and testing in parallel environment
- Independent model validation review

**Long-term (T+30 to T+90):**
- Structural model changes (e.g., switch from historical simulation to Monte Carlo)
- System upgrades (more granular data, faster computation)
- Revise risk appetite if persistent Yellow/Red zone

#### Section 6: Sign-Offs

- **Prepared by:** Market Risk Analyst
- **Reviewed by:** Head of Market Risk
- **Approved by:** Chief Risk Officer

### 4.3 RBI Reporting

**Timeline:** Within **2 business days** of exception

**Reporting Format:** Email to RBI Department of Banking Supervision using template in Annexure A

**Required Information:**
- Bank name and exception date
- VaR estimate and actual loss
- Brief explanation of cause
- Remedial actions taken
- Current zone status (updated exception count)

---

## 5. Yellow Zone Protocol

### 5.1 Entry into Yellow Zone (5th Exception)

**Trigger:** 5th exception recorded in trailing 250 days

**Immediate Actions (T+1):**
1. **Escalation:** CRO notifies CEO and BRMC Chairman
2. **Multiplication Factor Increase:** Capital charge increases from 3.00 to 3.40 (effective immediately)
3. **RBI Notification:** Within 2 business days

**Enhanced Monitoring (Effective T+2):**
- Daily VaR and P&L reporting to ALCO
- Weekly risk dashboards to BRMC
- Fortnightly model performance reviews by Model Validation Unit

### 5.2 Action Plan (T+7)

**Market Risk Committee develops action plan addressing:**

1. **Model Review:**
   - Independent validation of VaR methodology
   - Benchmark against alternative approaches (parametric, Monte Carlo)
   - Assess need for model enhancements

2. **Risk Mitigation:**
   - Implement 10-20% reduction in VaR limits (temporary)
   - Review large or concentrated positions
   - Consider hedging strategies

3. **Process Improvements:**
   - Data quality checks (automated validation rules)
   - System upgrades (real-time risk calculations)
   - Training for traders and risk analysts

**Action Plan Approval:** Submitted to ALCO within 7 days, approved within 14 days

### 5.3 Monthly Reviews

**While in Yellow Zone:**
- Market Risk presents update to ALCO monthly
- Track progress on action plan items
- Assess trajectory (improving vs. worsening)

**Exit from Yellow Zone:**
- Automatically exit when exception count falls below 5 in trailing 250 days
- Multiplication factor reverts to 3.00
- Maintain enhanced monitoring for additional 90 days (post-exit stabilization period)

---

## 6. Red Zone Protocol

### 6.1 Entry into Red Zone (10th Exception)

**Trigger:** 10th exception recorded in trailing 250 days

**Severity:** Red Zone indicates **statistically significant model failure**. Probability of 10+ exceptions if model is accurate: <0.05% (1 in 2000 chance).

**Immediate Actions (T+1):**

1. **Emergency Escalation:**
   - CRO convenes emergency ALCO meeting (within 24 hours)
   - CEO notifies Board Chairman
   - Prepare communication to RBI (within 2 business days)

2. **Capital Charge:**
   - Multiplication factor increases to 4.00 (33% increase vs. Green Zone)
   - Recalculate Pillar 1 capital; may impact capital ratios

3. **Trading Restrictions:**
   - **Option 1 (Moderate):** Immediate 50% reduction in VaR limits
   - **Option 2 (Severe):** Suspend proprietary trading, client trades only
   - Decision by CRO in consultation with CEO

### 6.2 Mandatory Model Review (T+7)

**RBI Expectation:** Comprehensive model review completed within 30 days

**Review Scope:**

1. **External Validation:**
   - Engage external consulting firm (Deloitte, PwC, Oliver Wyman)
   - Benchmark against industry best practices
   - Assess all aspects: data, methodology, implementation, governance

2. **Root Cause Deep Dive:**
   - Why did model fail repeatedly?
   - Are failures clustered (specific risk factor/desk) or widespread?
   - Is there fundamental flaw in methodology?

3. **Remediation Plan:**
   - Model enhancements (e.g., switch to stressed historical simulation)
   - Data improvements (more granular, higher frequency)
   - System upgrades
   - Governance strengthening (independent validation, controls)

**Deliverable:** Comprehensive report to BRMC and RBI within 30 days

### 6.3 Regulatory Interaction

**RBI Actions (Possible):**

- Request on-site inspection of risk management function
- Require parallel run of alternative VaR model (e.g., standardized approach) for capital calculation
- Impose additional capital buffers (Pillar 2 add-on)
- Restrict use of internal models; mandate standardized approach
- Require senior management accountability (CRO explanation)

**Bank's Response:**
- Cooperate fully with RBI supervisors
- Provide all requested data, documentation, and access
- Implement RBI recommendations within specified timelines
- Regular progress updates (monthly) until exit from Red Zone

### 6.4 Exit from Red Zone

**Conditions for Exit:**

1. Exception count falls below 10 in trailing 250 days (automatic numerical exit)
2. **AND** Root cause addressed (model enhancements validated)
3. **AND** BRMC satisfied with model performance
4. **AND** RBI approval obtained (if model restrictions were imposed)

**Post-Exit:**
- Remain in Yellow Zone (if exceptions 5-9) with enhanced monitoring
- Multiplication factor reduces to Yellow Zone level (3.40 - 3.85)
- Gradual restoration of trading limits over 6 months (subject to continued good performance)

---

## 7. Governance and Accountability

### 7.1 Roles and Responsibilities

**Market Risk Analyst:**
- Perform daily backtesting
- Prepare exception reports (T+1)
- Maintain exception log and zone tracking

**Head of Market Risk:**
- Review and approve exception reports
- Oversee remedial action implementation
- Report to CRO and ALCO

**Chief Risk Officer:**
- Accountable for VaR model performance
- Approve action plans for Yellow/Red zones
- Interface with RBI on model issues
- Recommend trading restrictions if needed

**Model Validation Unit:**
- Annual validation of VaR model
- Ad-hoc reviews for Yellow/Red zone entries
- Independent assessment of model changes

**Board Risk Management Committee:**
- Oversee backtesting framework
- Review exception trends quarterly
- Approve major model changes
- Hold CRO accountable for persistent poor performance

### 7.2 Performance Metrics

**Key Risk Indicators (KRIs) for Backtesting:**

| Metric | Green Threshold | Yellow Threshold | Red Threshold |
|--------|----------------|------------------|---------------|
| Exception Count (250 days) | 0-4 | 5-9 | 10+ |
| Exception Rate (%) | 0-1.6% | 2.0-3.6% | 4.0%+ |
| Consecutive Exceptions | 0-1 | 2 | 3+ |
| Average Excess Loss (when exception occurs) | <2x VaR | 2-3x VaR | >3x VaR |
| Zone Duration (days in Yellow/Red) | N/A | <90 days | >90 days |

**Reporting:** KRIs included in monthly Market Risk Dashboard to ALCO and BRMC

---

## 8. Documentation and Record-Keeping

### 8.1 Exception Log

Maintain centralized log of all exceptions with:
- Date of exception
- VaR estimate and actual P&L
- Desk/portfolio
- Root cause category (tail event, model deficiency, data error, etc.)
- Remedial actions taken
- Current zone status

**System:** RMIS database with audit trail

**Retention:** Minimum 7 years (RBI requirement)

### 8.2 Exception Reports

All exception reports (T+1 memos) archived in:
- Risk Management SharePoint site
- Accessible to Internal Audit, External Auditors, RBI inspectors

### 8.3 Zone Change Notifications

Maintain log of all zone changes with:
- Date of entry/exit
- Exception count at entry/exit
- Capital multiplication factor change
- Action plan references
- RBI correspondence

---

## 9. Policy Review and Continuous Improvement

### 9.1 Annual Policy Review

- CRO reviews policy annually (by December 31)
- Incorporate RBI/Basel regulatory changes
- Lessons learned from past year's exceptions
- Best practices from industry peers

### 9.2 Benchmark Analysis

- Quarterly comparison to peer banks (anonymized data shared via IBA/FEDAI)
- Assess if ABC Bank's exception rate is in line with industry
- Identify if systematic issues affect entire banking sector (e.g., regime change post-COVID)

### 9.3 Continuous Model Enhancement

- Ongoing research into advanced techniques:
  - Filtered Historical Simulation (volatility-weighted)
  - Extreme Value Theory (EVT) for tail risk
  - Machine Learning for risk factor selection
- Pilot new approaches in parallel environment before deployment

---

## Annexure A: RBI Exception Reporting Template

**To:** Department of Banking Supervision, Reserve Bank of India  
**Subject:** VaR Exception Notification - [Bank Name] - [Date]

Dear Sir/Madam,

We wish to inform you of a VaR exception recorded on [Date] for our trading book positions.

**Exception Details:**

- **Date of Exception:** [DD-MM-YYYY]
- **VaR Estimate (99%, 1-day):** ₹[XX] crore
- **Actual Clean P&L:** -₹[YY] crore (loss)
- **Excess Loss:** ₹[ZZ] crore

**Current Backtesting Status:**

- **Exception Count (trailing 250 days):** [N] exceptions
- **Zone Classification:** [Green / Yellow / Red]
- **Capital Multiplication Factor:** [3.00 / 3.40-3.85 / 4.00]

**Root Cause Analysis:**

[Brief explanation of why exception occurred - e.g., interest rate shock, equity market crash, volatility regime change, model limitation]

**Remedial Actions:**

[Actions taken or planned - e.g., position reduction, model enhancement, enhanced monitoring]

We remain available for any clarifications or additional information.

Yours sincerely,

[Name]  
Chief Risk Officer  
[Bank Name]  
[Contact Details]

---

**Approved by:**

_________________________  
**Mr. Anil Verma**  
Chief Risk Officer

**Date:** January 10, 2024

---

*This policy is for internal use only. Unauthorized distribution is prohibited.*