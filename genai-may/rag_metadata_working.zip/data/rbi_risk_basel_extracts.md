# RBI Market Risk Guidelines - Basel Framework Extracts

**Document Reference:** DBR.No.BP.BC.102/21.04.098/2023-24  
**Date:** March 2024  
**Applicability:** All Scheduled Commercial Banks (excluding RRBs)

---

## 1. Overview of Market Risk Capital Requirements

Market risk is defined as the risk of losses in on-balance sheet and off-balance sheet positions arising from movements in market prices. Banks must hold capital against market risk arising from:

- Interest rate related instruments and equities in the trading book
- Foreign exchange risk and commodities risk throughout the bank (both banking and trading book)

---

## 2. Value-at-Risk (VaR) Framework

### 2.1 VaR Parameters

Banks using internal models for market risk capital must calculate VaR using the following parameters:

- **Holding Period:** 10 trading days
- **Confidence Level:** 99% (one-tailed)
- **Observation Period:** Minimum of 1 year historical data (250 trading days)
- **Data Update Frequency:** At least quarterly; monthly preferred

### 2.2 VaR Methodology Requirements

Banks may use parametric (variance-covariance), historical simulation, or Monte Carlo methods, subject to RBI approval. The methodology must:

- Capture non-linear risks (options, embedded optionality)
- Account for concentration risk in less liquid positions
- Include all material risk factors: interest rates, equity prices, FX rates, commodity prices, volatility

### 2.3 Stressed VaR (SVaR)

In addition to standard VaR, banks must calculate Stressed VaR using:

- Same confidence level (99%) and holding period (10 days)
- Historical data from a continuous 12-month period of significant financial stress relevant to the bank's portfolio
- The stress period must be identified and approved by the bank's risk management committee and validated independently

**Capital Charge = max(VaRₜ₋₁, mc × VaRₐᵥ𝓰) + max(SVaRₜ₋₁, ms × SVaRₐᵥ𝓰)**

Where:
- mc and ms are multiplication factors (minimum 3, increased for backtesting performance)
- VaRₐᵥ𝓰 is the average of daily VaR over preceding 60 business days
- SVaRₐᵥ𝓰 is the average of daily Stressed VaR over preceding 60 business days

---

## 3. Standardised Approach to Market Risk

Banks not approved for internal models must use the Standardised Approach:

### 3.1 Interest Rate Risk

- **Maturity Method:** Securities allocated to time bands, capital charge based on duration-weighted positions and offsetting rules
- **Time Bands:** 0-1 month, 1-3 months, 3-6 months, 6-12 months, 1-2 years, 2-3 years, 3-4 years, 4-5 years, 5-7 years, 7-10 years, 10-15 years, 15-20 years, >20 years

### 3.2 Equity Risk

- **Specific Risk:** 9% for liquid, diversified portfolios; 11% for individual securities
- **General Market Risk:** 8% of net position

### 3.3 Foreign Exchange Risk

- **Capital Charge:** 8% of the higher of net long or net short position in each currency, plus net position in gold

---

## 4. Fundamental Review of the Trading Book (FRTB)

RBI has issued draft guidelines for FRTB implementation, expected to be fully effective by April 2026:

### 4.1 Revised Boundary Between Banking and Trading Books

- Instruments must be held with clear trading intent
- Presumptive lists of trading book and banking book instruments
- Enhanced documentation requirements for internal transfers

### 4.2 Sensitivity-Based Approach (SA)

Replacing current standardised approach with risk factor-based methodology:

- **Delta Risk:** Sensitivities to underlying risk factors (interest rate, credit spread, equity, FX, commodity)
- **Vega Risk:** Sensitivities to implied volatility
- **Curvature Risk:** Captures incremental risks not explained by delta

### 4.3 Internal Models Approach (IMA)

Expected Shortfall (ES) at 97.5% confidence level replaces VaR:

- ES captures tail risk beyond VaR threshold
- Separate ES calculations for liquid and non-liquid horizons
- Enhanced P&L attribution testing requirements

---

## 5. Backtesting Requirements

### 5.1 Daily Backtesting

Banks using internal models must perform daily backtesting:

- Compare actual daily P&L to VaR estimates
- Count exceptions (days when loss exceeds VaR)
- Report exceptions to RBI within 2 business days

### 5.2 Multiplication Factor

Based on backtesting results over preceding 250 days:

| Number of Exceptions | Zone | Multiplication Factor |
|---------------------|------|----------------------|
| 0-4 | Green | 3.00 |
| 5 | Yellow | 3.40 |
| 6 | Yellow | 3.50 |
| 7 | Yellow | 3.65 |
| 8 | Yellow | 3.75 |
| 9 | Yellow | 3.85 |
| 10+ | Red | 4.00 |

Yellow and Red zones trigger mandatory review and potential restriction of model use.

---

## 6. Stress Testing

### 6.1 Regulatory Stress Tests

Banks must conduct monthly stress tests covering:

- **Interest Rate Shock:** +/- 200 basis points parallel shift; steepening/flattening scenarios
- **Equity Market Crash:** 30% decline in domestic equity indices; 40% for international
- **Currency Crisis:** 20% depreciation of INR against major currencies
- **Commodity Shock:** 40% movement in key commodity prices

### 6.2 Bank-Specific Scenarios

Banks must develop scenarios based on:

- Portfolio-specific vulnerabilities
- Concentrations in particular risk factors
- Historical worst-case scenarios for the bank
- Forward-looking macroeconomic stress (recession, liquidity crisis)

Results must be reported to the Board quarterly and to RBI semi-annually.

---

## 7. Governance and Model Validation

### 7.1 Independent Validation

Internal models must be validated annually by a unit independent of model development:

- Assess conceptual soundness and mathematical accuracy
- Verify data integrity and system implementation
- Review model performance and limitations
- Recommend model improvements or restrictions

### 7.2 Regulatory Approval

Banks seeking to use internal models must apply to RBI with:

- Comprehensive documentation of methodology
- Evidence of at least 1 year of parallel run with regulatory reporting
- Proof of adequate risk management infrastructure
- Board-approved risk management framework

---

**Effective Date:** April 1, 2024  
**Supersedes:** DBR.No.BP.BC.85/21.04.098/2021-22

---

*This is a summary extract. Banks must refer to complete RBI Master Circular on Market Risk and Basel III Capital Regulations for full compliance requirements.*