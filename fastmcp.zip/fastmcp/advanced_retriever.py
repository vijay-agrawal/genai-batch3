import chromadb
from chromadb.utils import embedding_functions
import re
from collections import defaultdict, Counter
import math
import threading

# --------------------------------------------------
# Global cache objects (lightweight, built on demand)
# --------------------------------------------------
_bm25_index = None
_bm25_lock = threading.Lock()
_collection = None

SECTION_PRIORITY = {
    "simple": ["purpose", "scope"],
    "procedural": ["steps", "decision_points", "documentation"],
    "escalation": ["decision_points", "contraindications", "steps"],
    "multi": ["decision_points", "steps", "contraindications", "purpose"],
    "specific": ["steps", "decision_points", "contraindications"],
}

# --------------------------------------------------
# Basic utilities
# --------------------------------------------------

def load_collection(persist_dir="./chroma_index"):
    global _collection
    if _collection is None:
        client = chromadb.PersistentClient(path=persist_dir)
        embedder = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="sentence-transformers/all-MiniLM-L6-v2"
        )
        _collection = client.get_collection(name="sops", embedding_function=embedder)
    return _collection


def classify_query(query):
    q = query.lower()
    if re.search(r"purpose|scope|definition|what is", q):
        return "simple"
    if re.search(r"escalat|contraindicat|safety|risk", q):
        return "escalation"
    if re.search(r"across|compare|multiple sop|coordinate|integrat", q):
        return "multi"
    if re.search(r"rare|atypical|edge", q):
        return "escalation"  # treat rare as safety-critical
    if re.search(r"\bhow to|procedure|step|perform|administer|adjust\b", q):
        return "procedural"
    if re.search(r"eGFR|CrCl|HbA1c|INR|PTT|metformin|insulin", q):
        return "specific"
    return "procedural"  # default bias towards procedural content


# --------------------------------------------------
# BM25 (lightweight in-memory for lexical fusion)
# --------------------------------------------------

def build_bm25_index(collection):
    global _bm25_index
    if _bm25_index is not None:
        return _bm25_index
    with _bm25_lock:
        if _bm25_index is not None:
            return _bm25_index
        # Fetch all docs (paginate)
        all_ids = []
        all_docs = []
        all_meta = []
        batch = 1000
        offset = 0
        while True:
            res = collection.get(include=["documents", "metadatas"], limit=batch, offset=offset)
            if not res["ids"]:
                break
            all_ids.extend(res["ids"])
            all_docs.extend(res["documents"])
            all_meta.extend(res["metadatas"])
            if len(res["ids"]) < batch:
                break
            offset += batch
        # Tokenize & build frequencies
        token_docs = []
        df = Counter()
        token_pattern = re.compile(r"[a-z0-9]+")
        for doc in all_docs:
            toks = token_pattern.findall(doc.lower())
            token_docs.append(toks)
            for t in set(toks):
                df[t] += 1
        N = len(all_docs)
        avgdl = sum(len(toks) for toks in token_docs) / float(N or 1)
        k1 = 1.5
        b = 0.75
        _bm25_index = {
            "ids": all_ids,
            "docs": all_docs,
            "metas": all_meta,
            "tokens": token_docs,
            "df": df,
            "N": N,
            "avgdl": avgdl,
            "k1": k1,
            "b": b
        }
    return _bm25_index


def bm25_search(query, top_k=30):
    idx = build_bm25_index(load_collection())
    token_pattern = re.compile(r"[a-z0-9]+")
    q_tokens = token_pattern.findall(query.lower())
    if not q_tokens:
        return []
    scores = []
    for i, toks in enumerate(idx["tokens"]):
        score = 0.0
        dl = len(toks) or 1
        tf_counts = Counter(toks)
        for qt in q_tokens:
            df = idx["df"].get(qt, 0)
            if df == 0:
                continue
            idf = math.log(1 + (idx["N"] - df + 0.5) / (df + 0.5))
            tf = tf_counts.get(qt, 0)
            num = tf * (idx["k1"] + 1)
            denom = tf + idx["k1"] * (1 - idx["b"] + idx["b"] * dl / idx["avgdl"])
            score += idf * num / (denom or 1)
        if score > 0:
            scores.append((score, i))
    scores.sort(reverse=True)
    out = []
    for sc, i in scores[:top_k]:
        out.append({
            "id": idx["ids"][i],
            "text": idx["docs"][i],
            "metadata": idx["metas"][i],
            "lexical_score": sc
        })
    return out


# --------------------------------------------------
# Core semantic retrieval + enhancements
# --------------------------------------------------

def semantic_candidates(query, n=40, where=None):
    col = load_collection()
    params = {"query_texts": [query], "n_results": n}
    if where:
        params["where"] = where
    res = col.query(**params)
    out = []
    for rank, (cid, doc, meta) in enumerate(zip(res['ids'][0], res['documents'][0], res['metadatas'][0])):
        out.append({
            'id': cid,
            'text': doc,
            'metadata': meta,
            'dense_rank': rank
        })
    return out


def section_type_filter(qtype):
    return SECTION_PRIORITY.get(qtype, [])


def apply_section_priority(qtype, items):
    priolist = section_type_filter(qtype)
    scored = []
    for it in items:
        meta = it['metadata']
        st = meta.get('section_type', 'other')
        base = 1.0 / (1 + it.get('dense_rank', 0))
        if st in priolist:
            bonus = 1.2 + 0.15 * (len(priolist) - priolist.index(st))
        else:
            bonus = 0.8
        if meta.get('has_placeholders'):
            bonus *= 0.75
        it['score'] = base * bonus
        scored.append(it)
    return scored


def sibling_expand(items, max_per_sop=3):
    # group by sop + section_path then include neighbor chunks if same section
    by_id = {it['id']: it for it in items}
    col = load_collection()
    # Build index of chunks we already have to avoid duplicates
    existing_ids = set(by_id.keys())
    expanded = list(items)
    # Only expand steps
    steps = [it for it in items if it['metadata'].get('section_type') == 'steps']
    # Map (sop_id, section_path) -> list of candidate chunk indices (need chunk_index)
    for it in steps:
        m = it['metadata']
        sop = m.get('sop_id')
        path = m.get('section_path')
        chunk_index = m.get('chunk_index')
        if chunk_index is None:
            continue
        for neighbor in [chunk_index - 1, chunk_index + 1]:
            where = {
                'sop_id': sop,
                'section_path': path,
                'chunk_index': neighbor
            }
            try:
                # Chroma doesn't support compound equality filter easily for multiple keys, so approximate by sop_id then filter in Python
                res = col.get(where={'sop_id': sop})
            except Exception:
                continue
            for cid, doc, meta in zip(res['ids'], res['documents'], res['metadatas']):
                if meta.get('section_path') != path:
                    continue
                if meta.get('chunk_index') != neighbor:
                    continue
                if cid in existing_ids:
                    continue
                if sum(1 for x in expanded if x['metadata'].get('sop_id') == sop) >= max_per_sop:
                    continue
                expanded.append({'id': cid, 'text': doc, 'metadata': meta, 'dense_rank': it.get('dense_rank', 999), 'score': it.get('score', 0.2) * 0.9})
                existing_ids.add(cid)
    return expanded


def mmr(query_vec, doc_vecs, lambda_=0.65, top_k=8):
    # simple cosine with pre-normalized vectors assumption (Chroma returns only docs presently; skipping for brevity)
    # Placeholder: perform diversity by text length & section type heuristics.
    # If real embeddings needed, extend ingestion to store vectors.
    selected = []
    candidate_ids = list(range(len(doc_vecs)))
    # Use pseudo relevance = precomputed score; redundancy = same section_type penalty
    while candidate_ids and len(selected) < top_k:
        best = None
        best_score = -1e9
        for i in candidate_ids:
            item = doc_vecs[i]
            rel = item.get('score', 0.0)
            redundancy = 0.0
            for s in selected:
                if s['metadata'].get('section_type') == item['metadata'].get('section_type'):
                    redundancy = max(redundancy, 0.4)  # simple penalty
                if s['metadata'].get('sop_id') == item['metadata'].get('sop_id'):
                    redundancy = max(redundancy, 0.3)
            mmr_score = lambda_ * rel - (1 - lambda_) * redundancy
            if mmr_score > best_score:
                best_score = mmr_score
                best = i
        selected.append(doc_vecs[best])
        candidate_ids.remove(best)
    return selected


def dependency_expand(items, limit=2):
    # naive expansion: if text contains SOP-XYZ mention, try retrieving decision_points from that SOP
    col = load_collection()
    pattern = re.compile(r'SOP-\d{3}')
    mentioned = set()
    for it in items:
        for m in pattern.findall(it['text']):
            mentioned.add(m)
        deps_field = it['metadata'].get('dependencies')
        if deps_field:
            for token in re.findall(r'SOP-\d{3}', deps_field):
                mentioned.add(token)
    extra = []
    for sop in list(mentioned)[:limit]:
        try:
            res = col.get(where={'sop_id': sop})
        except Exception:
            continue
        for cid, doc, meta in zip(res['ids'], res['documents'], res['metadatas']):
            if meta.get('section_type') in ('decision_points', 'contraindications'):
                extra.append({'id': cid, 'text': doc, 'metadata': meta, 'dense_rank': 999, 'score': 0.55})
    return items + extra


def whole_sop_fallback(query, original_items, min_needed=3):
    if len(original_items) >= min_needed:
        return original_items
    # Aggregate by sop_id and pull purpose + steps first chunk
    col = load_collection()
    try:
        res = col.query(query_texts=[query], n_results=80)
    except Exception:
        return original_items
    added = []
    seen_sop = set(it['metadata'].get('sop_id') for it in original_items)
    for cid, doc, meta in zip(res['ids'][0], res['documents'][0], res['metadatas'][0]):
        sop = meta.get('sop_id')
        if sop in seen_sop:
            continue
        if meta.get('section_type') in ('purpose', 'scope', 'steps'):
            added.append({'id': cid, 'text': doc, 'metadata': meta, 'dense_rank': 999, 'score': 0.4})
        if len(added) + len(original_items) >= min_needed:
            break
    return original_items + added


# --------------------------------------------------
# Orchestrator
# --------------------------------------------------

def retrieve(query, scenario=None, top_k=8, persist_dir="./chroma_index2"):
    load_collection(persist_dir)
    qtype = scenario or classify_query(query)

    # Section-type pre-filter attempt (only for simple purpose queries)
    where = None
    if qtype == 'simple':
        where = {'section_type': {'$in': ['purpose', 'scope']}}

    dense_cands = semantic_candidates(query, n=50 if qtype in ('multi','procedural','escalation') else 30, where=where)

    if not dense_cands and where:
        # fallback to global if filtered empty
        dense_cands = semantic_candidates(query, n=40)

    dense_scored = apply_section_priority(qtype, dense_cands)

    # Lexical fusion for specific term or escalation
    lexical = []
    if qtype in ('specific', 'escalation', 'multi'):
        lexical = bm25_search(query, top_k=40)
        # map lexical to same structure
        for rank, item in enumerate(lexical):
            # mild additional boost
            item['score'] = (1.0 / (1 + rank)) * 1.1
            item['dense_rank'] = 999 + rank

    # Merge (id -> best)
    merged = {}
    for it in dense_scored + lexical:
        cid = it['id']
        if not cid:
            continue
        if cid not in merged or it.get('score',0) > merged[cid].get('score',0):
            merged[cid] = it
    merged_list = list(merged.values())

    # Sibling expansion for procedural queries
    if qtype == 'procedural':
        merged_list = sibling_expand(merged_list)

    # Dependency expansion for escalation / multi
    if qtype in ('escalation', 'multi'):
        merged_list = dependency_expand(merged_list)

    # Diversity & final selection via pseudo MMR
    merged_list.sort(key=lambda x: x.get('score',0), reverse=True)
    final = mmr(None, merged_list, top_k=top_k)

    # Whole-SOP fallback if sparse
    final = whole_sop_fallback(query, final, min_needed=3)

    # Build citation format
    outputs = []
    for it in final[:top_k]:
        m = it['metadata']
        citation = f"{m.get('sop_id', m.get('source_file'))} :: {m.get('section_title')} ({m.get('section_type')})"
        outputs.append({
            'id': it['id'],
            'text': it['text'],
            'metadata': dict(m, score=round(it.get('score',0),4), query_type=qtype),
            'citation': citation
        })
    return outputs


if __name__ == '__main__':
    tests = [
        "What is the purpose of peri-procedural diabetes management?",
        "How to adjust insulin before procedure?",
        "Escalation steps if renal risk and insulin brittle?",
        "Coordinate diabetes and renal function SOP across procedures",
        "eGFR threshold for metformin restart"
    ]
    for q in tests:
        res = retrieve(q, top_k=5)
        print(f"\nQuery: {q}\n{'-'*70}")
        for r in res:
            print(r['citation'], '|', r['metadata'].get('score'), '\n', r['text'][:160].replace('\n',' '))
            print('-'*40)
