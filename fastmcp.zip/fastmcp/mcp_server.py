"""SOP MCP Server Orchestration

Adds advanced retrieval + answer generation orchestration tools.
"""
from fastmcp import FastMCP  # tool decorators auto-exposed

# Legacy simple retriever (kept for backward compatibility)
from retriever import query_sops as simple_query

# Advanced pipeline
from advanced_retriever import retrieve as advanced_retrieve
from answer_generator import generate_with_llm, build_answer

import os
import chromadb

# ----------------------
# 1. Initialize MCP server
# ----------------------
mcp = FastMCP(
    name="SOP-MCP")

# ----------------------
# 2. Tools
# ----------------------
@mcp.tool
def search_sop(query: str, top_k: int = 5, mode: str = "advanced", scenario: str | None = None):
    """Retrieve SOP chunks.

    mode: 'advanced' (hierarchical, hybrid, diversification) or 'simple' (legacy semantic only).
    scenario: Optional override for classification (simple, procedural, escalation, multi, specific).
    """
    if mode == "simple":
        return simple_query(query, top_k=top_k)
    results = advanced_retrieve(query, scenario=scenario, top_k=top_k)
    return results

# @mcp.tool
# def answer_sop(query: str, top_k: int = 8, scenario: str | None = None, llm: bool = True):
#     """End-to-end answer generation.

#     llm=True attempts Azure/OpenAI; falls back to template if unavailable.
#     scenario optional override for retrieval classification.
#     """
#     chunks = advanced_retrieve(query, scenario=scenario, top_k=top_k)
#     if llm:
#         resp = generate_with_llm(query, chunks)
#     else:
#         resp = build_answer(query, chunks)
#     resp["chunks"] = chunks  # attach raw evidence
#     return resp


@mcp.tool
def web_search(query: str):
    """Web search for relevant and valid online sources for information not in SOPs."""
    return {
        "answer": "Did not find relevant and validated source online.",
        "chunks": []
    }


@mcp.tool
def summarize_sop(query: str, top_k: int = 6, mode: str = "advanced", llm: bool = True):
    """Return a lightweight summary context for UI or follow-up prompts. Uses LLM (Azure/OpenAI) if available, else template."""
    chunks = search_sop(query=query, top_k=top_k, mode=mode)
    if llm:
        # Use LLM for summarization (Azure/OpenAI)
        summary = generate_with_llm(query, chunks, prompt="summarization_prompt")
        return {"summary": summary, "citations": [c['citation'] for c in chunks]}
    else:
        context = "\n\n".join([f"[{c['citation']}] {c['text']}" for c in chunks])
        return {"context": context, "citations": [c['citation'] for c in chunks]}
# ----------------------
# sop_read tool: Return full SOP text and all steps for a given SOP ID
import glob

@mcp.tool
def sop_read(sop_id: str):
    """Read the entire SOP file and return all steps/text for the given SOP ID."""
    # SOP files are in ./sops/SOP-XXX.md
    sop_path = f"./sops/{sop_id}.md"
    try:
        with open(sop_path, "r", encoding="utf-8") as f:
            content = f.read()
        return {"sop_id": sop_id, "content": content}
    except Exception as e:
        return {"error": f"Could not read SOP {sop_id}: {str(e)}"}

@mcp.tool
def cross_reference_sops(query: str, top_k: int = 10):
    """Multi-SOP integration retrieval (forces multi scenario)."""
    return advanced_retrieve(query, scenario="multi", top_k=top_k)

@mcp.tool
def list_available_sops(limit: int = 500):
    """Enumerate distinct SOP IDs present in vector store (best-effort)."""
    try:
        client = chromadb.PersistentClient(path="./chroma_index")
        col = client.get_collection("sops")
        # naive scan
        res = col.get(include=["metadatas"], limit=limit)
        seen = {}
        for m in res.get('metadatas', []):
            sid = m.get('sop_id') or m.get('source_file')
            if not sid:
                continue
            if sid not in seen:
                seen[sid] = {
                    'sop_id': sid,
                    'category': m.get('category'),
                    'version': m.get('version'),
                    'sample_section': m.get('section_title')
                }
        return list(seen.values())
    except Exception as e:
        return {"error": str(e)}

@mcp.tool
def validate_answer(answer: str):
    """Precise citation and content validation.
    Checks:
    - At least one bracketed citation present
    - Each atomic claim has a citation
    - Optionally, citations match known SOP sections (if citation_map available)
    - No uncited factual claims
    """
    import re
    # Find all bracketed citations
    citations = re.findall(r'\[[^\]]+\]', answer)
    if not citations:
        return {"valid": False, "reason": "No bracketed citations found"}
    # Check for uncited sentences (simple heuristic: sentences without [SOP-XXX])
    sentences = re.split(r'(?<=[.!?])\s+', answer)
    uncited = [s for s in sentences if s.strip() and '[' not in s]
    if uncited:
        return {"valid": False, "reason": f"Uncited factual claims detected: {uncited}"}
    # Optionally: verify citation format (e.g., [SOP-XXX SectionTitle])
    invalid_format = [c for c in citations if not re.match(r'\[SOP-\d{3,} .+\]', c)]
    if invalid_format:
        return {"valid": False, "reason": f"Invalid citation format: {invalid_format}"}
    return {"valid": True, "reason": "ok"}


# # ----------------------
# # 3. Resources
# # ----------------------
# @mcp.resource
# def sop_metadata():
#     """
#     Expose SOP metadata (from YAML front matter)
#     """
#     # Stub for MVP; can load real YAML front matter
#     return {
#         "SOP-123": {"title": "Hand Hygiene Protocol", "version": "2.1", "department": "Infection Control"},
#         "SOP-124": {"title": "Patient Discharge SOP", "version": "3.0", "department": "Cardiology"}
#     }

# @mcp.resource
# def citation_map():
#     """
#     Chunk ID → SOP file + section mapping
#     """
#     # Stub for MVP
#     return {
#         "SOP-123#chunk-0": {"file": "SOP-123.md", "section": "Procedure"},
#         "SOP-124#chunk-1": {"file": "SOP-124.md", "section": "Steps"}
#     }

# ----------------------
# 4. Prompts
# ----------------------
@mcp.prompt("qa_prompt")
def qa_prompt():
    return """
You are a compliance assistant. 
Answer using ONLY the SOP chunks retrieved. 
Always cite the SOP name and section in [brackets]. 
If information is missing, respond with "Not found in SOPs".
"""

@mcp.prompt("summarization_prompt")
def summarization_prompt():
    return """
Summarize the following SOP section into clear, numbered steps. 
Keep it concise and maintain regulatory tone. Cite SOP at the end.
"""

@mcp.prompt("cross_reference_prompt")
def cross_reference_prompt():
    return """
Compare and synthesize across SOPs. 
Resolve conflicts by preferring the latest SOP (metadata last_updated). 
Provide citations for every fact.
"""

@mcp.prompt("guardrails_prompt")
def guardrails_prompt():
    return """
Reject answers that lack citations or contain hallucinations. 
Verify all citations exist in the citation_map resource.
"""

# ----------------------
# 5. Run MCP server
# ----------------------
if __name__ == "__main__":
    mcp.run(transport="stdio")