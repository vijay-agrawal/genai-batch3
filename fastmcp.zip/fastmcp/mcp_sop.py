# from fastmcp import FastMCP

# mcp = FastMCP("mcp_sop", description="A service to handle clinical SOP related queries.")

# @mcp.tool
# def 

# if __name__ == "__main__":
#     mcp.run(transport="stdio")