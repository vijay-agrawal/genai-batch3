import re
import os
from textwrap import dedent

REFUSAL_TEMPLATE = (
    "Requested information is not explicitly covered in available SOP content. "
    "Do not proceed based solely on this system; escalate per escalation guidelines."
)

def detect_low_coverage(retrieved, query):
    if not retrieved:
        return True, "no_chunks"
    # If all chunks are purpose/scope for a procedural / escalation style query
    procedural_signals = re.search(r"how to|step|adjust|perform|administer|escalat|contraindicat", query.lower())
    if procedural_signals:
        non_generic = [c for c in retrieved if c['metadata'].get('section_type') not in ('purpose','scope')]
        if len(non_generic) == 0:
            return True, "only_generic"
    return False, "ok"

def group_by_sop(retrieved):
    groups = {}
    for c in retrieved:
        sop = c['metadata'].get('sop_id') or c['metadata'].get('source_file')
        groups.setdefault(sop, []).append(c)
    return groups

def build_answer(query, retrieved):
    low, reason = detect_low_coverage(retrieved, query)
    if low:
        return {"answer": REFUSAL_TEMPLATE, "reason": reason, "citations": []}

    qtype = retrieved[0]['metadata'].get('query_type')  # they all carry qtype

    if qtype == 'simple':
        # Summarize purpose/scope
        purpose_chunks = [c for c in retrieved if c['metadata'].get('section_type') in ('purpose','scope')]
        core = purpose_chunks[:2] or retrieved[:2]
        summary_lines = []
        for c in core:
            txt = c['text'].strip().split('\n')[0]
            summary_lines.append(txt)
        body = ' '.join(summary_lines)
        answer = f"Purpose/Scope Summary: {body}"[:900]
    elif qtype == 'procedural':
        steps = [c for c in retrieved if c['metadata'].get('section_type') == 'steps']
        if not steps:
            steps = retrieved
        ordered = steps[:6]
        bullet_steps = []
        for s in ordered:
            line = s['text'].strip().split('\n')[0]
            bullet_steps.append(f"- {line[:180]}")
        answer = "Procedure Outline:\n" + '\n'.join(bullet_steps)
    elif qtype == 'escalation':
        dec = [c for c in retrieved if c['metadata'].get('section_type') == 'decision_points']
        contra = [c for c in retrieved if c['metadata'].get('section_type') == 'contraindications']
        lines = []
        for d in dec[:3]:
            lines.append("Decision: " + d['text'].split('\n')[0][:200])
        for ct in contra[:3]:
            lines.append("Contraindication: " + ct['text'].split('\n')[0][:200])
        answer = "Escalation / Safety:\n" + '\n'.join(lines)
    elif qtype == 'multi':
        groups = group_by_sop(retrieved)
        segs = []
        for sop_id, chunks in list(groups.items())[:4]:
            steps = [c for c in chunks if c['metadata'].get('section_type') == 'steps'][:1]
            dec = [c for c in chunks if c['metadata'].get('section_type') == 'decision_points'][:1]
            purpose = [c for c in chunks if c['metadata'].get('section_type') in ('purpose','scope')][:1]
            combined = steps + dec + purpose
            text = ' | '.join(c['text'].split('\n')[0][:160] for c in combined)
            segs.append(f"{sop_id}: {text}")
        answer = "Integrated Summary:\n" + '\n'.join(segs)
    else:  # specific or fallback
        top = retrieved[:5]
        lines = [c['text'].split('\n')[0][:200] for c in top]
        answer = "Key Points:\n" + '\n'.join(f"- {l}" for l in lines)

    citations = []
    for c in retrieved:
        m = c['metadata']
        cite = f"{m.get('sop_id', m.get('source_file'))}:{m.get('section_title')}"[:120]
        if cite not in citations:
            citations.append(cite)
        if len(citations) >= 12:
            break

    return {"answer": answer, "citations": citations, "reason": "ok"}


# ------------------------------
# Azure/OpenAI LLM integration
# ------------------------------

LLM_SYSTEM_PROMPT = (
    "You are a clinical SOP retrieval assistant. You MUST only answer using the provided SOP CHUNKS. "
    "If a requested action, step, dose, or escalation is not explicitly present, state that it is not specified and advise escalation per policy. "
    "Always cite sources inline as [SOP-ID SectionTitle] right after each distinct factual segment. Return a concise structured answer." 
)

def _format_context_blocks(retrieved):
    blocks = []
    for i, c in enumerate(retrieved, 1):
        meta = c['metadata']
        header = f"[{i}] {meta.get('sop_id', meta.get('source_file'))} | {meta.get('section_title')} | {meta.get('section_type')}"
        text = c['text'].strip()
        blocks.append(f"{header}\n{text}")
    return "\n\n".join(blocks)

def generate_with_llm(query, retrieved, force_template_fallback=False, max_tokens=600):
    """Generate an answer using Azure OpenAI if configured; fallback to OpenAI; else local template."""
    if force_template_fallback:
        return build_answer(query, retrieved)

    # Safety / coverage check first
    low, _ = detect_low_coverage(retrieved, query)
    if low:
        return build_answer(query, retrieved)  # refusal path already handled

    context_blocks = _format_context_blocks(retrieved)
    qtype = retrieved[0]['metadata'].get('query_type') if retrieved else 'unknown'

    user_prompt = dedent(f"""
    Query Type: {qtype}
    User Query: {query}

    Provided SOP Chunks (treat as authoritative; do NOT invent beyond these):
    {context_blocks}

    Instructions:
    - Answer ONLY with information grounded in the chunks.
    - For multi-SOP logic, explicitly integrate and note any dependencies.
    - If a critical detail (dose, timing) is missing: say 'Not specified in provided SOP content.'
    - Provide structured sections: Summary, Key Steps / Decisions, Escalation / Safety (if applicable), Gaps / Not Specified.
    - Inline cite each sentence or bullet using [SOP-ID SectionTitle].
    - Keep answer under ~550 tokens.
    """)

    AZURE_KEY = os.environ.get("AZURE_OPENAI_API_KEY")
    AZURE_ENDPOINT = os.environ.get("AZURE_OPENAI_ENDPOINT")
    AZURE_DEPLOYMENT = os.environ.get("AZURE_OPENAI_MODEL_NAME")
    OPENAI_KEY = os.environ.get("OPENAI_API_KEY")

    # Try Azure first
    try:
        if AZURE_KEY and AZURE_ENDPOINT and AZURE_DEPLOYMENT:
            from openai import AzureOpenAI
            client = AzureOpenAI(
                api_key=AZURE_KEY,
                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-03-15-preview"),
                azure_endpoint=AZURE_ENDPOINT
            )
            resp = client.chat.completions.create(
                model=AZURE_DEPLOYMENT,
                messages=[
                    {"role": "system", "content": LLM_SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=max_tokens,
                temperature=0.2
            )
            answer_text = resp.choices[0].message.content
            return {"answer": answer_text, "citations": _extract_citations(answer_text), "reason": "azure_openai"}
    except Exception as e:
        # Fall through to OpenAI / template
        pass

    # Try standard OpenAI
    try:
        if OPENAI_KEY:
            from openai import OpenAI
            client = OpenAI(api_key=OPENAI_KEY)
            model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
            resp = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": LLM_SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=max_tokens,
                temperature=0.2
            )
            answer_text = resp.choices[0].message.content
            return {"answer": answer_text, "citations": _extract_citations(answer_text), "reason": "openai"}
    except Exception:
        pass

    # Fallback
    return build_answer(query, retrieved)


def _extract_citations(answer_text):
    cites = []
    for m in re.findall(r"\[(SOP-\d{3}[^\]]*)\]", answer_text):
        if m not in cites:
            cites.append(m)
        if len(cites) >= 20:
            break
    return cites

if __name__ == '__main__':
    # simple smoke test
    from advanced_retriever import retrieve
    q = "How to adjust insulin prior to procedure?"
    chunks = retrieve(q, top_k=6)
    resp = build_answer(q, chunks)
    print(resp['answer'])
    print('Citations:', resp['citations'])
