import os
import yaml
import re
import hashlib
import chromadb
from chromadb.utils import embedding_functions

# ----------------------
# 1. Helper: Parse front matter
# ----------------------
def parse_front_matter(text):
    """
    Extract YAML front matter from Markdown text.
    Returns: (metadata dict, remaining text)
    """
    fm_pattern = r"^---\s*\n(.*?)\n---\s*\n(.*)$"
    match = re.match(fm_pattern, text, re.DOTALL)
    if match:
        front_matter = yaml.safe_load(match.group(1))
        body = match.group(2)
        return front_matter, body
    else:
        return {}, text

# ----------------------
# 2. Improved: Section parsing & smart chunking
# ----------------------

HEADING_RE = re.compile(r'^(#{1,6})\s+(.*)$')

def parse_sections(markdown_body):
    """Return list of section dicts with hierarchy (level,title,path,content)."""
    lines = markdown_body.splitlines()
    sections = []
    stack = []  # list of (level, title)
    current = {"level": None, "title": None, "content_lines": []}

    def flush():
        if current["title"] is not None:
            path_titles = [t for _, t in stack]
            sections.append({
                "level": current["level"],
                "title": current["title"],
                "path": " > ".join(path_titles),
                "content": "\n".join(current["content_lines"]).strip()
            })
            current["content_lines"] = []

    for line in lines:
        m = HEADING_RE.match(line)
        if m:
            flush()
            level = len(m.group(1))
            title = m.group(2).strip()
            # maintain stack hierarchy
            while stack and stack[-1][0] >= level:
                stack.pop()
            stack.append((level, title))
            current["level"] = level
            current["title"] = title
        else:
            current["content_lines"].append(line)
    flush()
    return sections

def token_len(text):
    # Approximate token length without external dependency
    return len(text.split())

def smart_chunk_text(text, target_tokens=250, overlap_tokens=40):
    if not text.strip():
        return []
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    chunks = []
    cur = []
    cur_tokens = 0
    for sent in sentences:
        tl = token_len(sent)
        if cur and cur_tokens + tl > target_tokens:
            chunks.append(" ".join(cur).strip())
            # overlap tail
            if overlap_tokens > 0:
                tail = []
                t = 0
                for s in reversed(cur):
                    t += token_len(s)
                    tail.insert(0, s)
                    if t >= overlap_tokens:
                        break
                cur = tail
                cur_tokens = sum(token_len(x) for x in cur)
            else:
                cur = []
                cur_tokens = 0
        cur.append(sent)
        cur_tokens += tl
    if cur:
        chunks.append(" ".join(cur).strip())
    return chunks

def classify_section_type(title):
    t = (title or "").lower()
    if "purpose" in t: return "purpose"
    if "scope" in t: return "scope"
    if "role" in t: return "roles"
    if "precondition" in t: return "preconditions"
    if "step" in t or "procedure" in t: return "steps"
    if "decision" in t or "escalation" in t: return "decision_points"
    if "contraindication" in t: return "contraindications"
    if "document" in t: return "documentation"
    if "reference" in t: return "references"
    return "other"

def stable_id(sop_id, section_path, sec_idx, chunk_idx, text):
    h = hashlib.sha1(text.encode('utf-8')).hexdigest()[:8]
    safe_path = (section_path or 'root').replace(' > ', '_').replace(' ', '_')[:40]
    return f"{sop_id}::{safe_path}::{sec_idx}-{chunk_idx}-{h}"

# ----------------------
# 3. Build vector store with Chroma
# ----------------------
def build_index(sop_folder, persist_dir="./chroma_index"):
    client = chromadb.PersistentClient(path=persist_dir)
    embedder = embedding_functions.SentenceTransformerEmbeddingFunction(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )
    collection = client.get_or_create_collection(
        name="sops",
        embedding_function=embedder
    )

    for file in os.listdir(sop_folder):
        if not file.endswith('.md'):
            continue
        path = os.path.join(sop_folder, file)
        with open(path, 'r', encoding='utf-8') as f:
            text = f.read()

        front_matter, body = parse_front_matter(text)
        sop_id = front_matter.get('sop_id') or front_matter.get('id') or file.replace('.md','')
        sections = parse_sections(body)

        ids = []
        docs = []
        metas = []

        for s_idx, sec in enumerate(sections):
            section_type = classify_section_type(sec['title'])
            mini_chunks = smart_chunk_text(sec['content']) or [sec['content']] if sec['content'] else []
            for c_idx, chunk in enumerate(mini_chunks):
                if not chunk.strip():
                    continue
                cid = stable_id(sop_id, sec['path'], s_idx, c_idx, chunk)
                has_placeholders = ('<' in chunk and '>' in chunk)
                meta_flat = {}
                for k,v in front_matter.items():
                    if isinstance(v, list):
                        meta_flat[k] = ' '.join(str(x) for x in v)
                    else:
                        meta_flat[k] = v
                meta_flat.update({
                    'sop_id': sop_id,
                    'source_file': file,
                    'section_title': sec['title'],
                    'section_path': sec['path'],
                    'section_level': sec['level'],
                    'section_type': section_type,
                    'chunk_index': c_idx,
                    'has_placeholders': has_placeholders,
                    'text_preview': chunk[:120]
                })
                ids.append(cid)
                docs.append(chunk)
                metas.append(meta_flat)

        # intra-file duplicate filtering
        seen = set()
        f_ids, f_docs, f_metas = [], [], []
        for cid, doc, meta in zip(ids, docs, metas):
            sig = hashlib.md5(doc.encode('utf-8')).hexdigest()
            if sig in seen:
                continue
            seen.add(sig)
            f_ids.append(cid)
            f_docs.append(doc)
            f_metas.append(meta)

        if f_ids:
            collection.add(ids=f_ids, documents=f_docs, metadatas=f_metas)
        print(f"Indexed {len(f_ids)} chunks from {file} (was {len(ids)} before dedupe)")

    print("✅ Indexing complete (improved)!")


if __name__ == "__main__":
    build_index(sop_folder="./sops", persist_dir="./chroma_index2")
