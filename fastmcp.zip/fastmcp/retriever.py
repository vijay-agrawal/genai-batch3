import chromadb
from chromadb.utils import embedding_functions
import re
from collections import defaultdict

# ----------------------
# 1. Load vector store
# ----------------------
def load_collection(persist_dir = "./chroma_index"):
    client = chromadb.PersistentClient(path=persist_dir)
    embedder = embedding_functions.SentenceTransformerEmbeddingFunction(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )
    return client.get_collection(name="sops", embedding_function=embedder)

# ----------------------
# 2. Query function
# ----------------------
def classify_query(query: str) -> str:
    q = query.lower()
    if re.search(r"is it safe|not described|outside|not covered", q):
        return "hallucinate/refusal"
    if re.search(r"rare|atypical|edge", q):
        return "edge-case"
    if re.search(r"coordinated|related|multi-hop|multiple sop|across", q):
        return "multi-hop"
    if "multiple conditions" in q or "adjust" in q or "adapt" in q:
        return "complex"
    return "simple"

SECTION_PRIORITY = {
    "edge-case": ["contraindications", "decision_points", "documentation", "steps"],
    "complex": ["decision_points", "steps", "contraindications", "documentation"],
    "multi-hop": ["decision_points", "steps", "contraindications", "purpose", "scope"],
    "simple": ["steps", "purpose", "scope", "roles"],
}

def score_result(qtype, meta, rank_index):
    # Base inverse rank
    score = 1.0 / (1 + rank_index)
    st = meta.get("section_type", "other")
    if qtype in SECTION_PRIORITY:
        priolist = SECTION_PRIORITY[qtype]
        if st in priolist:
            score *= (1.5 + 0.2 * (len(priolist) - priolist.index(st)))
    # Penalize placeholder chunks
    if meta.get("has_placeholders"):
        score *= 0.75
    return score

def format_citation(meta):
    return f"{meta.get('sop_id', meta.get('source_file'))} :: {meta.get('section_title')}" + (f" ({meta.get('section_type')})" if meta.get('section_type') else "")

def query_sops(
    query,
    top_k = 5,
    persist_dir = "./chroma_index",
    initial_k = 30,
    per_sop_limit = 3
):
    """
    Adaptive semantic retrieval using enriched metadata.
    Steps:
      1. Classify query type.
      2. Retrieve a larger candidate pool (initial_k).
      3. Re-score based on section_type priority & placeholders.
      4. For multi-hop, ensure diversity across sop_ids.
      5. Return top_k with formatted citations.
    """
    qtype = classify_query(query)
    if qtype == "hallucinate/refusal":
        return [{
            "id": None,
            "text": "Requested action or scenario is not explicitly covered in available SOP content. Do not proceed based solely on this system. Escalate per escalation guidelines.",
            "metadata": {"response_type": qtype},
            "citation": "N/A"
        }]

    collection = load_collection(persist_dir)
    results = collection.query(query_texts=[query], n_results=initial_k)

    candidates = []
    # Flatten results
    for idx, (cid, doc, meta) in enumerate(zip(results['ids'][0], results['documents'][0], results['metadatas'][0])):
        score = score_result(qtype, meta, idx)
        candidates.append((score, cid, doc, meta))

    # Sort by score desc
    candidates.sort(key=lambda x: x[0], reverse=True)

    # Diversity control for multi-hop: cap per SOP early
    final = []
    per_sop_counts = defaultdict(int)
    for score, cid, doc, meta in candidates:
        sop = meta.get('sop_id') or meta.get('source_file')
        if qtype == 'multi-hop':
            if per_sop_counts[sop] >= per_sop_limit:
                continue
        final.append((score, cid, doc, meta))
        per_sop_counts[sop] += 1
        if len(final) >= top_k:
            break

    outputs = []
    for score, cid, doc, meta in final:
        outputs.append({
            'id': cid,
            'text': doc,
            'metadata': {**meta, 'score': round(score,4), 'query_type': qtype},
            'citation': format_citation(meta)
        })

    return outputs

# ----------------------
# 3. Example usage
# ----------------------
if __name__ == "__main__":
    queries = [
        "What are the key steps for insulin adjustment?",
        "How is Anticoagulation coordinated with renal SOP?",
        "What to do in rare atypical insulin scenarios?",
        "Is it safe to change dosing not described?"
    ]
    for q in queries:
        res = query_sops(q, top_k=4)
        print(f"\n🔎 Query: {q}\n{'='*60}")
        for r in res:
            print(f"Type={r['metadata'].get('query_type')} Score={r['metadata'].get('score')} Citation={r['citation']}")
            print(r['text'][:200].replace('\n',' '))
            print('-'*60)