
# Clinical SOP Project MCP Server

## Overview

This project provides a Medical Clinical Protocol (MCP) server for retrieving, searching, and generating answers from a large set of Standard Operating Procedures (SOPs). It supports advanced retrieval, answer generation, and integration with AI assistants.

## Setup

1. **Clone the repository (if needed):**
   ```powershell
   git clone <your-repo-url>
   cd mcpdemo
   ```

2. **Create and activate a virtual environment (optional but recommended):**
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate
   ```

3. **Install dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```

4. **Ingest SOPs (Index/Chunk the documents in /sop folder):**
   ```powershell
   python ingest_sops.py
   ```

## Usage

### Start the MCP Server

```powershell
python mcp_server.py
```

The server will start and expose endpoints for SOP retrieval, search, and answer generation.

### API Endpoints

- `/search_sop` — Search SOPs by query
- `/sop_read` — Read full SOP by ID
- `/summarize_sop` — Get summary of SOPs
- `/validate_answer` — Validate answer citations
- `/web_search` — Search for external sources

Refer to `mcp_server.py` for endpoint details.

## SOP Management

- SOPs are stored in the `sops/` directory as markdown files (`SOP-XXX.md`).
- Metadata is managed in `sop_metadata.json`.
- Use `ingest_sops.py` to index new or updated SOPs.

## Advanced Retrieval

- `advanced_retriever.py` implements hybrid and hierarchical search.
- `retriever.py` provides basic semantic search.

## Step-by-Step Setup

1. **Clone the repository:**
   ```powershell
   git clone <your-repo-url>
   cd mcpdemo
   ```

2. **Create and activate a virtual environment:**
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate
   ```

3. **Install dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```

4. **Ingest SOPs into the index (run only if SOPs or index are new/updated):**
   ```powershell
   python ingest_sops.py
   ```

5. **Start the MCP server:**
   ```powershell
   python mcp_server.py
   ```

## Connecting MCP Server to GitHub Copilot as a Tool

1. Enable MCP server access - VS Code Settings -> Search MCP -> Enable
2. CTRL+SHIFT+p to open comman pallete
3. Search for "MCP: Add server"
4. Select command (stdio) (we're running it on transport=stdio. for remote connection it would be http)
5. Put the command as `python mcp_server.py`
6. Keep the server ID and select workspace (the MCP tools will be available only in that workspace)
7. A mcp.json file will open for config.. Change the command in this way:

``python
	"servers": {
		"server_id": {
			"type": "stdio",
			"command": "your path to project folder\\venv\\Scripts\\python.exe",
			"args": [
				"your path to project folder\\mcp_server.py"
			]
		}
}
``

8. In copilot, select the tool icon, and the tools list should show the MCP id and list down 6 tools defined in the mcp_server.py.
