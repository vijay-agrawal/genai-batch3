"""
Main Entry Point
================
Orchestrates the full pipeline:
  1. Generate (or load) dataset
  2. Preprocess and split
  3. Build vocabulary
  4. Load GloVe embeddings
  5. Train & evaluate Model A (frozen GloVe) and Model B (fine-tuned GloVe)
  6. (Optional) Train Model C (Attention LSTM – requires student implementation)
  7. Run LIME explanations on a sample of test messages
  8. Save JSON predictions for the entire test set

Run:
    python main.py --glove data/glove.6B.100d.txt

Arguments:
    --data     : path to patient_feedback.csv  (default: data/patient_feedback.csv)
    --glove    : path to GloVe .txt or .zip    (required)
    --dim      : GloVe dimension (50|100|200|300, default: 100)
    --epochs   : training epochs               (default: 20)
    --batch    : batch size                    (default: 64)
    --device   : cpu | cuda | mps              (default: auto-detect)
    --models   : comma-separated subset of: lstm-glove,lstm-finetuned,lstm-attention
    --lime     : enable LIME explainability    (slow, optional)
    --out      : output directory              (default: outputs/)
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch
from torch.utils.data import DataLoader

# Add parent of starter/ to path so modules resolve correctly
sys.path.insert(0, str(Path(__file__).parent))

from dataset import (
    FeedbackDataset,
    build_vocab,
    compute_class_weights,
    load_glove,
    load_splits,
)
from evaluate import evaluate_model, print_comparison_table
from models import build_model, count_parameters
from predict import Predictor
from preprocess import PreprocessingPipeline
from train import Trainer, plot_history


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Patient Feedback Classifier")
    p.add_argument("--data",   default="data/patient_feedback.csv")
    p.add_argument("--glove",  required=True,
                   help="Path to GloVe vectors (.txt or .zip)")
    p.add_argument("--dim",    type=int, default=100,
                   choices=[50, 100, 200, 300])
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch",  type=int, default=64)
    p.add_argument("--device", default=None)
    p.add_argument("--models", default="lstm-glove,lstm-finetuned",
                   help="Comma-separated list of models to train")
    p.add_argument("--lime",   action="store_true",
                   help="Generate LIME explanations (slow)")
    p.add_argument("--out",    default="outputs")
    return p.parse_args()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    args = parse_args()

    # Device
    if args.device is None:
        device = (
            "cuda" if torch.cuda.is_available()
            else "mps" if torch.backends.mps.is_available()
            else "cpu"
        )
    else:
        device = args.device
    print(f"\nUsing device: {device}")

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # 1. Preprocessing & splitting
    # ------------------------------------------------------------------
    print("\n[1] Preprocessing & splitting dataset ...")
    pipeline = PreprocessingPipeline(
        fix_ocr        = True,
        expand_abbrevs = True,
        clean_email    = True,
        normalise      = True,
    )
    data_path = Path(args.data)
    if not data_path.exists():
        sys.exit(
            f"Dataset not found at {data_path}.\n"
            "Run:  python data/generate_dataset.py"
        )
    train_df, val_df, test_df = load_splits(data_path, pipeline=pipeline)

    # ------------------------------------------------------------------
    # 2. Vocabulary
    # ------------------------------------------------------------------
    print("\n[2] Building vocabulary ...")
    vocab = build_vocab(train_df["text_clean"].tolist(), min_freq=2)

    # ------------------------------------------------------------------
    # 3. GloVe embeddings
    # ------------------------------------------------------------------
    print(f"\n[3] Loading GloVe ({args.dim}d) ...")
    embedding_matrix = load_glove(args.glove, vocab, embedding_dim=args.dim)

    # ------------------------------------------------------------------
    # 4. DataLoaders
    # ------------------------------------------------------------------
    print("\n[4] Creating DataLoaders ...")
    make_ds = lambda df: FeedbackDataset(df, vocab, max_len=40)
    train_ds, val_ds, test_ds = make_ds(train_df), make_ds(val_df), make_ds(test_df)

    train_loader = DataLoader(train_ds, batch_size=args.batch, shuffle=True)
    val_loader   = DataLoader(val_ds,   batch_size=args.batch)
    test_loader  = DataLoader(test_ds,  batch_size=args.batch)

    class_weights = compute_class_weights(train_df)

    # ------------------------------------------------------------------
    # 5. Train each requested model
    # ------------------------------------------------------------------
    model_names = [m.strip() for m in args.models.split(",")]
    all_metrics: list[dict] = []

    for model_name in model_names:
        print(f"\n{'='*60}")
        print(f"  Training: {model_name}")
        print(f"{'='*60}")

        model = build_model(
            name             = model_name,
            embedding_matrix = embedding_matrix,
            hidden_dim       = 128,
            num_layers       = 2,
            num_classes      = 4,
            dropout          = 0.3,
        )
        count_parameters(model)

        trainer = Trainer(
            model          = model,
            train_loader   = train_loader,
            val_loader     = val_loader,
            class_weights  = class_weights,
            lr             = 1e-3,
            checkpoint_dir = out_dir / "checkpoints",
            device         = device,
        )
        history = trainer.fit(epochs=args.epochs, early_stop_patience=5)

        plot_history(
            history,
            save_path=str(out_dir / f"training_curves_{model_name}.png"),
        )

        # ------------------------------------------------------------------
        # 6. Evaluate on test set
        # ------------------------------------------------------------------
        metrics = evaluate_model(
            model      = model,
            loader     = test_loader,
            test_df    = test_df,
            device     = device,
            model_name = model_name,
            save_dir   = str(out_dir),
        )
        all_metrics.append(metrics)

        # ------------------------------------------------------------------
        # 7. Generate JSON predictions for the full test set
        # ------------------------------------------------------------------
        print(f"\n[7] Generating JSON predictions for test set ...")
        predictor = Predictor(
            model      = model,
            vocab      = vocab,
            pipeline   = pipeline,
            max_len    = 40,
            device     = device,
            use_lime   = args.lime,
            model_name = model_name,
        )
        ids = test_df["message_id"].tolist() if "message_id" in test_df.columns else None
        batch_output = predictor.predict_batch(
            raw_texts   = test_df["text"].tolist(),
            message_ids = ids,
        )
        pred_path = out_dir / f"predictions_{model_name}.json"
        pred_path.write_text(batch_output.model_dump_json(indent=2), encoding="utf-8")
        print(f"  Predictions saved → {pred_path}")

        # Show a few examples
        print("\n  Sample predictions:")
        for r in batch_output.results[:3]:
            print(f"    [{r.predicted_label.value:>8}  {r.confidence:.0%}] "
                  f"{r.original_text[:70]}")

    # ------------------------------------------------------------------
    # 8. Comparison table (if more than one model trained)
    # ------------------------------------------------------------------
    if len(all_metrics) > 1:
        print_comparison_table(all_metrics)

    print(f"\nAll outputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()
