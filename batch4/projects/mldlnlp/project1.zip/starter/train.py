"""
Training Loop
=============
Trains a model for the specified number of epochs with:
  - Weighted cross-entropy loss (handles class imbalance)
  - Early stopping on validation macro-F1
  - Checkpoint saving (best model by val-F1)
  - Learning-rate scheduling

TODO (Student Task 6):
    The training step is stubbed out.  Implement `train_one_epoch()` so that:
      a) It iterates over the DataLoader, computes loss, back-propagates, and
         steps the optimiser.
      b) For AttentionLSTMClassifier, the forward() returns (logits, weights) —
         your training step must handle both model signatures.
      c) Accumulate and return the average loss and accuracy for the epoch.

Usage:
    from train import Trainer
    trainer = Trainer(model, train_loader, val_loader, class_weights=wts)
    history = trainer.fit(epochs=20)
"""

from __future__ import annotations

import copy
import time
from pathlib import Path
from typing import Optional

import torch
import torch.nn as nn
from sklearn.metrics import f1_score
from torch.optim import AdamW
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader
from tqdm import tqdm


# ---------------------------------------------------------------------------
# Trainer
# ---------------------------------------------------------------------------

class Trainer:
    """
    Generic trainer that works with all three model variants.

    Parameters
    ----------
    model         : an nn.Module (LSTMClassifier, FineTunedLSTMClassifier,
                    or AttentionLSTMClassifier)
    train_loader  : DataLoader for the training split
    val_loader    : DataLoader for the validation split
    class_weights : 1-D tensor of per-class loss weights (from compute_class_weights())
    lr            : initial learning rate
    checkpoint_dir: directory to save the best model weights
    device        : 'cuda' / 'mps' / 'cpu'
    """

    def __init__(
        self,
        model:         nn.Module,
        train_loader:  DataLoader,
        val_loader:    DataLoader,
        class_weights: Optional[torch.Tensor] = None,
        lr:            float      = 1e-3,
        checkpoint_dir: str | Path = "checkpoints",
        device:        str        = "cpu",
    ):
        self.device        = device
        self.model         = model.to(device)
        self.train_loader  = train_loader
        self.val_loader    = val_loader
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        weights = class_weights.to(device) if class_weights is not None else None
        self.criterion = nn.CrossEntropyLoss(weight=weights)
        self.optimiser = AdamW(
            filter(lambda p: p.requires_grad, model.parameters()),
            lr=lr, weight_decay=1e-4
        )
        self.scheduler = ReduceLROnPlateau(
            self.optimiser, mode="max", factor=0.5, patience=3, verbose=True
        )

        self.history: list[dict] = []
        self._best_f1    = -1.0
        self._best_state = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _is_attention_model(self) -> bool:
        """Returns True if model.forward() returns (logits, weights)."""
        from models import AttentionLSTMClassifier
        return isinstance(self.model, AttentionLSTMClassifier)

    def _forward(self, batch: dict) -> torch.Tensor:
        """
        Call model.forward() and always return just the logits tensor.
        Handles both single-return (logits) and dual-return (logits, weights).
        """
        ids    = batch["input_ids"].to(self.device)
        result = self.model(ids)
        if isinstance(result, tuple):   # AttentionLSTMClassifier
            logits, _ = result
        else:
            logits = result
        return logits

    # ------------------------------------------------------------------
    # Training step  (TO BE IMPLEMENTED)
    # ------------------------------------------------------------------

    def train_one_epoch(self) -> tuple[float, float]:
        """
        Run one full pass over the training DataLoader.

        Returns
        -------
        avg_loss : float   – mean cross-entropy loss over all batches
        accuracy : float   – fraction of correctly classified samples

        TODO (Student Task 6):
        Replace the `raise NotImplementedError` with a proper implementation.

        Template:
            self.model.train()
            total_loss, correct, total = 0.0, 0, 0

            for batch in tqdm(self.train_loader, desc="  train", leave=False):
                labels = batch["label"].to(self.device)

                self.optimiser.zero_grad()
                logits = self._forward(batch)           # use the helper above
                loss   = self.criterion(logits, labels)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=5.0)
                self.optimiser.step()

                total_loss += loss.item() * len(labels)
                preds       = logits.argmax(dim=1)
                correct    += (preds == labels).sum().item()
                total      += len(labels)

            return total_loss / total, correct / total
        """
        raise NotImplementedError("Implement train_one_epoch() – see docstring above.")

    # ------------------------------------------------------------------
    # Validation step  (provided – no changes needed)
    # ------------------------------------------------------------------

    @torch.no_grad()
    def evaluate(self, loader: DataLoader) -> tuple[float, float, float]:
        """
        Evaluate on the given loader.

        Returns
        -------
        avg_loss     : float
        accuracy     : float
        macro_f1     : float  – unweighted macro-F1 across all classes
        """
        self.model.eval()
        total_loss, correct, total = 0.0, 0, 0
        all_preds, all_labels = [], []

        for batch in loader:
            labels = batch["label"].to(self.device)
            logits = self._forward(batch)
            loss   = self.criterion(logits, labels)

            total_loss += loss.item() * len(labels)
            preds       = logits.argmax(dim=1)
            correct    += (preds == labels).sum().item()
            total      += len(labels)
            all_preds.extend(preds.cpu().tolist())
            all_labels.extend(labels.cpu().tolist())

        macro_f1 = f1_score(all_labels, all_preds, average="macro", zero_division=0)
        return total_loss / total, correct / total, macro_f1

    # ------------------------------------------------------------------
    # Main fit loop
    # ------------------------------------------------------------------

    def fit(self, epochs: int = 20, early_stop_patience: int = 5) -> list[dict]:
        no_improve = 0

        for epoch in range(1, epochs + 1):
            t0 = time.time()

            train_loss, train_acc = self.train_one_epoch()
            val_loss,   val_acc, val_f1 = self.evaluate(self.val_loader)

            self.scheduler.step(val_f1)

            row = dict(
                epoch      = epoch,
                train_loss = train_loss,
                train_acc  = train_acc,
                val_loss   = val_loss,
                val_acc    = val_acc,
                val_f1     = val_f1,
                elapsed    = time.time() - t0,
            )
            self.history.append(row)

            print(
                f"Epoch {epoch:3d} | "
                f"train_loss={train_loss:.4f} acc={train_acc:.3f} | "
                f"val_loss={val_loss:.4f} acc={val_acc:.3f} F1={val_f1:.4f} | "
                f"{row['elapsed']:.1f}s"
            )

            # Checkpoint
            if val_f1 > self._best_f1:
                self._best_f1    = val_f1
                self._best_state = copy.deepcopy(self.model.state_dict())
                ckpt = self.checkpoint_dir / f"{self.model.__class__.__name__}_best.pt"
                torch.save(self._best_state, ckpt)
                no_improve = 0
                print(f"  ✓ New best val F1 = {val_f1:.4f} – checkpoint saved → {ckpt}")
            else:
                no_improve += 1
                if no_improve >= early_stop_patience:
                    print(f"  Early stopping at epoch {epoch} (no improvement for {early_stop_patience} epochs).")
                    break

        # Restore best weights
        if self._best_state is not None:
            self.model.load_state_dict(self._best_state)

        return self.history


# ---------------------------------------------------------------------------
# History plotting utility
# ---------------------------------------------------------------------------

def plot_history(history: list[dict], save_path: Optional[str] = None) -> None:
    """Plot train/val loss and val F1 over epochs."""
    import matplotlib.pyplot as plt

    epochs     = [r["epoch"]     for r in history]
    train_loss = [r["train_loss"] for r in history]
    val_loss   = [r["val_loss"]   for r in history]
    val_f1     = [r["val_f1"]    for r in history]

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    axes[0].plot(epochs, train_loss, label="train")
    axes[0].plot(epochs, val_loss,   label="val")
    axes[0].set_title("Loss"); axes[0].legend(); axes[0].set_xlabel("Epoch")

    axes[1].plot(epochs, val_f1, color="green")
    axes[1].set_title("Val Macro-F1"); axes[1].set_xlabel("Epoch")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Training curves saved → {save_path}")
    else:
        plt.show()
