"""
Evaluation Utilities
====================
Computes and displays:
  - Classification report (precision, recall, F1 per class + macro/weighted)
  - Confusion matrix
  - Per-source-type performance breakdown (pdf / nursing_note / email)
  - Class-specific warnings when urgent recall is below threshold

Use this module to compare Model A (frozen GloVe) vs Model B (fine-tuned)
and document results in your report.

Usage:
    from evaluate import evaluate_model, print_comparison_table
    metrics_a = evaluate_model(model_a, test_loader, test_df)
    metrics_b = evaluate_model(model_b, test_loader, test_df)
    print_comparison_table([metrics_a, metrics_b], names=["Model A", "Model B"])
"""

from __future__ import annotations

from typing import Optional

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import torch
import torch.nn as nn
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from torch.utils.data import DataLoader

from dataset import IDX_TO_LABEL, LABEL_TO_IDX

LABEL_NAMES = [IDX_TO_LABEL[i] for i in range(len(IDX_TO_LABEL))]
URGENT_IDX  = LABEL_TO_IDX["urgent"]
URGENT_RECALL_THRESHOLD = 0.80   # safety requirement


# ---------------------------------------------------------------------------
# Core evaluation
# ---------------------------------------------------------------------------

@torch.no_grad()
def get_predictions(
    model:  nn.Module,
    loader: DataLoader,
    device: str = "cpu",
) -> tuple[list[int], list[int], list[float]]:
    """
    Run inference and collect (true_labels, predicted_labels, max_probabilities).
    Works with both single-return and (logits, weights) return signatures.
    """
    model.eval()
    all_true, all_pred, all_conf = [], [], []

    for batch in loader:
        ids    = batch["input_ids"].to(device)
        labels = batch["label"]

        result = model(ids)
        logits = result[0] if isinstance(result, tuple) else result
        probs  = torch.softmax(logits, dim=-1).cpu()
        preds  = probs.argmax(dim=-1)
        confs  = probs.max(dim=-1).values

        all_true.extend(labels.tolist())
        all_pred.extend(preds.tolist())
        all_conf.extend(confs.tolist())

    return all_true, all_pred, all_conf


def evaluate_model(
    model:      nn.Module,
    loader:     DataLoader,
    test_df:    pd.DataFrame,
    device:     str  = "cpu",
    model_name: str  = "model",
    save_dir:   Optional[str] = None,
) -> dict:
    """
    Full evaluation of a trained model on the test set.

    Parameters
    ----------
    model      : trained PyTorch model
    loader     : DataLoader for the test set (same order as test_df)
    test_df    : DataFrame with 'label' and 'source' columns (for breakdown analysis)
    save_dir   : if set, saves confusion matrix PNG here

    Returns
    -------
    dict with keys: accuracy, macro_f1, weighted_f1, urgent_recall,
                    per_class_f1, per_source_f1, report_str
    """
    true_labels, pred_labels, confidences = get_predictions(model, loader, device)

    acc          = sum(t == p for t, p in zip(true_labels, pred_labels)) / len(true_labels)
    macro_f1     = f1_score(true_labels, pred_labels, average="macro",    zero_division=0)
    weighted_f1  = f1_score(true_labels, pred_labels, average="weighted", zero_division=0)
    per_class_f1 = f1_score(true_labels, pred_labels, average=None,       zero_division=0)
    urgent_rec   = recall_score(true_labels, pred_labels, labels=[URGENT_IDX],
                                average="micro", zero_division=0)

    report_str = classification_report(
        true_labels, pred_labels, target_names=LABEL_NAMES, zero_division=0
    )

    print(f"\n{'='*60}")
    print(f"  {model_name.upper()}")
    print(f"{'='*60}")
    print(f"  Accuracy        : {acc:.4f}")
    print(f"  Macro F1        : {macro_f1:.4f}")
    print(f"  Weighted F1     : {weighted_f1:.4f}")
    print(f"  Urgent Recall   : {urgent_rec:.4f}", end="")
    if urgent_rec < URGENT_RECALL_THRESHOLD:
        print(f"  ⚠  BELOW SAFETY THRESHOLD ({URGENT_RECALL_THRESHOLD})")
    else:
        print()
    print()
    print(report_str)

    # Per-source breakdown
    per_source = _per_source_breakdown(test_df, pred_labels)
    print("  Per-source macro-F1:")
    for src, f1 in per_source.items():
        print(f"    {src:<18} {f1:.4f}")

    # Confusion matrix
    cm = confusion_matrix(true_labels, pred_labels)
    _plot_confusion_matrix(cm, model_name, save_dir)

    return dict(
        model_name   = model_name,
        accuracy     = acc,
        macro_f1     = macro_f1,
        weighted_f1  = weighted_f1,
        urgent_recall= urgent_rec,
        per_class_f1 = {LABEL_NAMES[i]: float(f1) for i, f1 in enumerate(per_class_f1)},
        per_source_f1= per_source,
        report_str   = report_str,
        avg_confidence = float(np.mean(confidences)),
    )


# ---------------------------------------------------------------------------
# Per-source analysis
# ---------------------------------------------------------------------------

def _per_source_breakdown(
    test_df:    pd.DataFrame,
    pred_labels: list[int],
) -> dict[str, float]:
    """Compute macro-F1 separately for each data source."""
    results = {}
    test_df = test_df.copy()
    test_df["pred"] = [IDX_TO_LABEL[p] for p in pred_labels]

    source_col = "source_det" if "source_det" in test_df.columns else "source"
    for src in test_df[source_col].unique():
        mask  = test_df[source_col] == src
        if mask.sum() < 5:
            continue
        true_s = [LABEL_TO_IDX[l] for l in test_df.loc[mask, "label"]]
        pred_s = [LABEL_TO_IDX[l] for l in test_df.loc[mask, "pred"]]
        results[src] = f1_score(true_s, pred_s, average="macro", zero_division=0)

    return results


# ---------------------------------------------------------------------------
# Visualisation
# ---------------------------------------------------------------------------

def _plot_confusion_matrix(
    cm:         np.ndarray,
    model_name: str,
    save_dir:   Optional[str],
) -> None:
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=LABEL_NAMES, yticklabels=LABEL_NAMES, ax=ax
    )
    ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    ax.set_title(f"Confusion Matrix – {model_name}")
    plt.tight_layout()

    if save_dir:
        from pathlib import Path
        Path(save_dir).mkdir(parents=True, exist_ok=True)
        path = Path(save_dir) / f"confusion_{model_name.replace(' ', '_')}.png"
        plt.savefig(path, dpi=150)
        print(f"  Confusion matrix saved → {path}")
        plt.close()
    else:
        plt.show()


# ---------------------------------------------------------------------------
# Comparison table
# ---------------------------------------------------------------------------

def print_comparison_table(
    metrics_list: list[dict],
    names:        Optional[list[str]] = None,
) -> None:
    """
    Prints a summary table comparing multiple model evaluations side by side.

    Example output:
        Metric              Model A    Model B    Model C
        ----------------    -------    -------    -------
        Accuracy            0.7812     0.8134     0.8321
        Macro F1            0.7203     0.7891     0.8012
        Urgent Recall       0.6500     0.8200     0.8700
        Avg Confidence      0.7810     0.8100     0.8050
    """
    if names is None:
        names = [m["model_name"] for m in metrics_list]

    metrics_to_show = [
        ("accuracy",       "Accuracy"),
        ("macro_f1",       "Macro F1"),
        ("weighted_f1",    "Weighted F1"),
        ("urgent_recall",  "Urgent Recall"),
        ("avg_confidence", "Avg Confidence"),
    ]

    col_w = 12
    header = f"{'Metric':<22}" + "".join(f"{n:>{col_w}}" for n in names)
    print(f"\n{'='*len(header)}")
    print(header)
    print("-" * len(header))

    for key, label in metrics_to_show:
        row = f"{label:<22}"
        for m in metrics_list:
            val = m.get(key, float("nan"))
            flag = "  ⚠" if key == "urgent_recall" and val < URGENT_RECALL_THRESHOLD else ""
            row += f"{val:>{col_w}.4f}{flag}"
        print(row)

    # Per-class F1
    print()
    for cls in LABEL_NAMES:
        row = f"  F1({cls}){'':<{14 - len(cls)}}"
        for m in metrics_list:
            val = m.get("per_class_f1", {}).get(cls, float("nan"))
            row += f"{val:>{col_w}.4f}"
        print(row)
    print("=" * len(header))
