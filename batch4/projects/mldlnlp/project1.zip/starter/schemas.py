"""
Output Schemas (Pydantic v2)
============================
Every prediction produced by the system must conform to these schemas.
Pydantic will validate the data at runtime and raise descriptive errors
when a field is missing, has the wrong type, or violates a constraint.

Students: Do NOT modify this file.  Your prediction code must produce
          objects that satisfy these models.
"""

from __future__ import annotations

from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class SentimentLabel(str, Enum):
    POSITIVE = "positive"
    NEGATIVE = "negative"
    NEUTRAL  = "neutral"
    URGENT   = "urgent"


class SourceType(str, Enum):
    PDF          = "pdf"
    EMAIL        = "email"
    NURSING_NOTE = "nursing_note"
    UNKNOWN      = "unknown"


# ---------------------------------------------------------------------------
# Sub-models
# ---------------------------------------------------------------------------

class PreprocessingInfo(BaseModel):
    """Documents every transformation applied to the raw text."""
    original_text:         str
    cleaned_text:          str
    detected_source:       SourceType
    abbreviations_expanded: List[str] = Field(
        default_factory=list,
        description="List of 'abbrev → expansion' strings, e.g. 'pt → patient'"
    )
    ocr_corrections:       List[str] = Field(
        default_factory=list,
        description="List of likely OCR fix descriptions, e.g. '1 → i'"
    )
    email_header_removed:  bool = False
    word_count_before:     int  = Field(ge=0)
    word_count_after:      int  = Field(ge=0)

    @field_validator("word_count_after")
    @classmethod
    def after_not_greater_than_before(cls, v: int, info) -> int:
        # After expansion abbreviations may increase count, so only warn, don't fail
        return v


class TokenWeight(BaseModel):
    """A single token and its attribution weight (positive = pushes toward predicted class)."""
    token:  str
    weight: float = Field(description="Attribution score in [-1, 1] range; magnitude = importance")


class ClassificationReasoning(BaseModel):
    """Human-interpretable explanation of why this label was chosen."""
    top_influential_tokens: List[TokenWeight] = Field(
        min_length=1,
        description="Top tokens driving the prediction, ranked by |weight|"
    )
    explanation: str = Field(
        min_length=10,
        description="One or two sentences summarising the classification rationale"
    )
    confidence_flags: List[str] = Field(
        default_factory=list,
        description=(
            "Any factors that may reduce reliability, e.g. "
            "['contains_abbreviations', 'ocr_noise_detected', 'short_text', 'low_confidence']"
        )
    )


# ---------------------------------------------------------------------------
# Primary output model
# ---------------------------------------------------------------------------

class ClassificationOutput(BaseModel):
    """
    Full structured output for a single patient feedback message.

    Example usage:
        output = ClassificationOutput(
            message_id="MSG-00001",
            original_text="pt c/o sob x2d...",
            predicted_label=SentimentLabel.URGENT,
            confidence=0.87,
            class_probabilities={
                SentimentLabel.POSITIVE: 0.03,
                SentimentLabel.NEGATIVE: 0.07,
                SentimentLabel.NEUTRAL:  0.03,
                SentimentLabel.URGENT:   0.87,
            },
            preprocessing_info=PreprocessingInfo(...),
            reasoning=ClassificationReasoning(...),
        )
        # Pydantic will raise ValidationError if any constraint is violated.
        print(output.model_dump_json(indent=2))
    """

    message_id:          str
    original_text:       str
    predicted_label:     SentimentLabel
    confidence:          float = Field(ge=0.0, le=1.0)
    class_probabilities: Dict[SentimentLabel, float]
    preprocessing_info:  PreprocessingInfo
    reasoning:           ClassificationReasoning
    model_name:          str  = "lstm-glove"   # e.g. "lstm-glove", "lstm-finetuned"
    model_version:       str  = "1.0.0"

    @field_validator("class_probabilities")
    @classmethod
    def probabilities_sum_to_one(cls, v: Dict[SentimentLabel, float]) -> Dict[SentimentLabel, float]:
        total = sum(v.values())
        if abs(total - 1.0) > 1e-2:
            raise ValueError(f"class_probabilities must sum to 1.0, got {total:.4f}")
        return v

    @field_validator("class_probabilities")
    @classmethod
    def all_labels_present(cls, v: Dict[SentimentLabel, float]) -> Dict[SentimentLabel, float]:
        missing = set(SentimentLabel) - set(v.keys())
        if missing:
            raise ValueError(f"Missing class probabilities for: {missing}")
        return v

    @model_validator(mode="after")
    def confidence_matches_predicted(self) -> "ClassificationOutput":
        """confidence must equal the probability of the predicted label."""
        predicted_prob = self.class_probabilities.get(self.predicted_label, None)
        if predicted_prob is None:
            raise ValueError("predicted_label not found in class_probabilities")
        if abs(self.confidence - predicted_prob) > 1e-2:
            raise ValueError(
                f"confidence ({self.confidence:.4f}) must match "
                f"class_probabilities[{self.predicted_label}] ({predicted_prob:.4f})"
            )
        return self


# ---------------------------------------------------------------------------
# Batch output model
# ---------------------------------------------------------------------------

class BatchClassificationOutput(BaseModel):
    """Wraps multiple predictions with aggregate statistics."""

    results:            List[ClassificationOutput]
    total_processed:    int = Field(ge=1)
    label_distribution: Dict[SentimentLabel, int]
    average_confidence: float = Field(ge=0.0, le=1.0)
    processing_notes:   Optional[str] = None

    @model_validator(mode="after")
    def distribution_matches_results(self) -> "BatchClassificationOutput":
        from collections import Counter
        actual = Counter(r.predicted_label for r in self.results)
        for lbl, cnt in self.label_distribution.items():
            if actual.get(lbl, 0) != cnt:
                raise ValueError(
                    f"label_distribution[{lbl}]={cnt} does not match "
                    f"count in results ({actual.get(lbl, 0)})"
                )
        return self

    @model_validator(mode="after")
    def total_matches_results(self) -> "BatchClassificationOutput":
        if self.total_processed != len(self.results):
            raise ValueError(
                f"total_processed ({self.total_processed}) != len(results) ({len(self.results)})"
            )
        return self


# ---------------------------------------------------------------------------
# Quick self-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json

    dummy = ClassificationOutput(
        message_id="MSG-00001",
        original_text="pt c/o sob x2d - no response from rn",
        predicted_label=SentimentLabel.URGENT,
        confidence=0.82,
        class_probabilities={
            SentimentLabel.POSITIVE: 0.03,
            SentimentLabel.NEGATIVE: 0.10,
            SentimentLabel.NEUTRAL:  0.05,
            SentimentLabel.URGENT:   0.82,
        },
        preprocessing_info=PreprocessingInfo(
            original_text="pt c/o sob x2d - no response from rn",
            cleaned_text="patient complains of shortness of breath for 2 days no response from nurse",
            detected_source=SourceType.NURSING_NOTE,
            abbreviations_expanded=["pt -> patient", "c/o -> complains of",
                                    "sob -> shortness of breath", "rn -> nurse"],
            word_count_before=9,
            word_count_after=14,
        ),
        reasoning=ClassificationReasoning(
            top_influential_tokens=[
                TokenWeight(token="shortness of breath", weight=0.71),
                TokenWeight(token="no response",         weight=0.52),
                TokenWeight(token="2 days",              weight=0.38),
            ],
            explanation=(
                "The message describes an unresolved respiratory symptom over two days "
                "with no nursing response — strong indicators of an urgent safety concern."
            ),
            confidence_flags=["contains_abbreviations"],
        ),
    )
    print(json.loads(dummy.model_dump_json(indent=2)))
    print("\nSchema self-test passed.")
