"""
Prediction & Explainability
============================
Provides:
  1. Single message prediction → ClassificationOutput (Pydantic-validated)
  2. Batch prediction          → BatchClassificationOutput
  3. Token-level explanations via:
       a) Attention weights (Model C only)
       b) LIME (works with any model)

TODO (Student Task 7 – LIME Integration):
    Complete the `explain_with_lime()` function.
    You need to:
      a) Define a `predict_proba(texts: list[str]) -> np.ndarray` closure that:
           - Runs the preprocessing pipeline on each text
           - Tokenises using the vocabulary
           - Runs model inference
           - Returns a (N, num_classes) probability matrix
      b) Create a lime.lime_text.LimeTextExplainer and call explain_instance().
      c) Extract the top-k feature importances from the explanation object and
         return them as a list of TokenWeight objects.

Usage:
    from predict import Predictor
    predictor = Predictor(model, vocab, pipeline, device="cpu")

    # Single prediction
    output = predictor.predict("pt c/o sob x2d rn not responding")
    print(output.model_dump_json(indent=2))

    # Batch prediction
    batch = predictor.predict_batch(df["text"].tolist(), message_ids=df["message_id"].tolist())
    print(batch.model_dump_json(indent=2))
"""

from __future__ import annotations

import uuid
from collections import Counter
from typing import Optional

import numpy as np
import torch
import torch.nn as nn

from dataset import IDX_TO_LABEL, LABEL_TO_IDX, Vocabulary
from preprocess import PreprocessingPipeline
from schemas import (
    BatchClassificationOutput,
    ClassificationOutput,
    ClassificationReasoning,
    PreprocessingInfo,
    SentimentLabel,
    SourceType,
    TokenWeight,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _probs_to_class_dict(probs: np.ndarray) -> dict[SentimentLabel, float]:
    return {
        SentimentLabel(IDX_TO_LABEL[i]): float(probs[i])
        for i in range(len(IDX_TO_LABEL))
    }


def _low_confidence_flag(confidence: float, threshold: float = 0.60) -> list[str]:
    if confidence < threshold:
        return ["low_confidence"]
    return []


def _preprocessing_flags(proc) -> list[str]:
    flags: list[str] = []
    if proc.abbreviations_expanded:
        flags.append("contains_abbreviations")
    if proc.ocr_corrections:
        flags.append("ocr_noise_detected")
    if proc.word_count_after < 4:
        flags.append("very_short_text")
    return flags


# ---------------------------------------------------------------------------
# Attention-based explanation (Model C)
# ---------------------------------------------------------------------------

@torch.no_grad()
def explain_with_attention(
    model:     nn.Module,
    input_ids: torch.Tensor,   # (1, L)
    tokens:    list[str],
    top_k:     int = 6,
) -> list[TokenWeight]:
    """
    Extract attention weights from AttentionLSTMClassifier and return
    the top-k most attended tokens as TokenWeight objects.
    """
    from models import AttentionLSTMClassifier
    if not isinstance(model, AttentionLSTMClassifier):
        return []

    model.eval()
    _, weights = model(input_ids)       # weights: (1, L)
    w = weights.squeeze(0).cpu().numpy()

    # Pair tokens with weights, skip PAD
    token_weights = [
        TokenWeight(token=tok, weight=float(w[i]))
        for i, tok in enumerate(tokens)
        if tok != "<PAD>"
    ]
    token_weights.sort(key=lambda x: abs(x.weight), reverse=True)
    return token_weights[:top_k]


# ---------------------------------------------------------------------------
# LIME-based explanation (any model)
# ---------------------------------------------------------------------------

def explain_with_lime(
    raw_text:  str,
    model:     nn.Module,
    vocab:     Vocabulary,
    pipeline:  PreprocessingPipeline,
    device:    str,
    top_k:     int = 6,
    num_samples: int = 300,
) -> list[TokenWeight]:
    """
    Use LIME to explain a single prediction.

    Returns a list of TokenWeight objects with signed importance scores.
    Positive weight → pushes toward predicted class.
    Negative weight → pushes against predicted class.

    TODO (Student Task 7):
    Remove the `raise NotImplementedError` and implement this function.

    Required steps:
      1. Import `lime.lime_text.LimeTextExplainer`.
      2. Define `predict_proba(texts: list[str]) -> np.ndarray` closure:
           processed = [pipeline.process(t).cleaned_text for t in texts]
           ids = torch.tensor([vocab.encode(t, max_len=40) for t in processed],
                              dtype=torch.long).to(device)
           with torch.no_grad():
               result = model(ids)
               logits = result[0] if isinstance(result, tuple) else result
               probs  = torch.softmax(logits, dim=-1).cpu().numpy()
           return probs                   # shape (N, 4)

      3. Create explainer:
           explainer = LimeTextExplainer(class_names=list(IDX_TO_LABEL.values()))

      4. Run explanation on the *cleaned* text (so LIME perturbations match
         what the model actually receives):
           cleaned = pipeline.process(raw_text).cleaned_text
           predicted_class_idx = predict_proba([cleaned]).argmax()
           exp = explainer.explain_instance(
               cleaned, predict_proba,
               num_features=top_k,
               labels=[predicted_class_idx],
               num_samples=num_samples,
           )

      5. Extract feature importances:
           items = exp.as_list(label=predicted_class_idx)
           return [TokenWeight(token=tok, weight=w) for tok, w in items]

    Notes:
      - Install lime: `pip install lime`
      - LIME is model-agnostic and should work with all three model variants.
      - num_samples=300 is sufficient for short texts; increase if results are noisy.
    """
    raise NotImplementedError(
        "Implement explain_with_lime() – see the docstring for step-by-step instructions."
    )


# ---------------------------------------------------------------------------
# Main Predictor class
# ---------------------------------------------------------------------------

class Predictor:
    """
    Wraps a trained model, vocabulary, and preprocessing pipeline into a
    single predict() interface that returns Pydantic-validated output.

    Parameters
    ----------
    model          : trained nn.Module (any of the three variants)
    vocab          : fitted Vocabulary
    pipeline       : PreprocessingPipeline (use the same config as training)
    max_len        : token sequence length (must match training)
    device         : torch device string
    use_lime       : if True, LIME explanations are generated (slow but universal)
                     if False, attention weights are used when available
    """

    def __init__(
        self,
        model:    nn.Module,
        vocab:    Vocabulary,
        pipeline: PreprocessingPipeline,
        max_len:  int = 40,
        device:   str = "cpu",
        use_lime: bool = False,
        model_name: str = "lstm",
    ):
        self.model     = model.to(device).eval()
        self.vocab     = vocab
        self.pipeline  = pipeline
        self.max_len   = max_len
        self.device    = device
        self.use_lime  = use_lime
        self.model_name = model_name

    # ------------------------------------------------------------------

    @torch.no_grad()
    def predict(
        self,
        raw_text:   str,
        message_id: Optional[str] = None,
    ) -> ClassificationOutput:
        """Predict sentiment for a single raw message."""
        if message_id is None:
            message_id = f"MSG-{uuid.uuid4().hex[:8].upper()}"

        proc   = self.pipeline.process(raw_text)
        ids    = torch.tensor(
            [self.vocab.encode(proc.cleaned_text, max_len=self.max_len)],
            dtype=torch.long
        ).to(self.device)

        result = self.model(ids)
        logits = result[0] if isinstance(result, tuple) else result
        probs  = torch.softmax(logits, dim=-1).squeeze(0).cpu().numpy()

        predicted_idx   = int(probs.argmax())
        predicted_label = SentimentLabel(IDX_TO_LABEL[predicted_idx])
        confidence      = float(probs[predicted_idx])
        class_probs     = _probs_to_class_dict(probs)

        # ------ Explanation -------------------------------------------------
        tokens = proc.cleaned_text.split()[:self.max_len]
        tokens += ["<PAD>"] * (self.max_len - len(tokens))

        if self.use_lime:
            try:
                top_tokens = explain_with_lime(
                    raw_text, self.model, self.vocab, self.pipeline, self.device
                )
            except NotImplementedError:
                top_tokens = _fallback_token_weights(tokens, ids)
        else:
            from models import AttentionLSTMClassifier
            if isinstance(self.model, AttentionLSTMClassifier):
                top_tokens = explain_with_attention(self.model, ids, tokens)
            else:
                top_tokens = _fallback_token_weights(tokens, ids)

        flags = _preprocessing_flags(proc) + _low_confidence_flag(confidence)

        explanation = _build_explanation(predicted_label, top_tokens, proc, confidence)

        # ------ Pydantic output (raises ValidationError if something is wrong)
        return ClassificationOutput(
            message_id      = message_id,
            original_text   = raw_text,
            predicted_label = predicted_label,
            confidence      = round(confidence, 6),
            class_probabilities = {k: round(v, 6) for k, v in class_probs.items()},
            preprocessing_info  = PreprocessingInfo(
                original_text          = proc.original_text,
                cleaned_text           = proc.cleaned_text,
                detected_source        = SourceType(proc.detected_source.value),
                abbreviations_expanded = proc.abbreviations_expanded,
                ocr_corrections        = proc.ocr_corrections,
                email_header_removed   = proc.email_header_removed,
                word_count_before      = proc.word_count_before,
                word_count_after       = proc.word_count_after,
            ),
            reasoning = ClassificationReasoning(
                top_influential_tokens = top_tokens if top_tokens else [
                    TokenWeight(token="<no explanation>", weight=0.0)
                ],
                explanation      = explanation,
                confidence_flags = flags,
            ),
            model_name = self.model_name,
        )

    # ------------------------------------------------------------------

    def predict_batch(
        self,
        raw_texts:   list[str],
        message_ids: Optional[list[str]] = None,
    ) -> BatchClassificationOutput:
        """Predict sentiment for a list of raw messages."""
        if message_ids is None:
            message_ids = [f"MSG-{i+1:05d}" for i in range(len(raw_texts))]

        results = [
            self.predict(text, mid)
            for text, mid in zip(raw_texts, message_ids)
        ]

        label_counts = dict(Counter(r.predicted_label for r in results))
        avg_conf     = float(np.mean([r.confidence for r in results]))

        return BatchClassificationOutput(
            results            = results,
            total_processed    = len(results),
            label_distribution = label_counts,
            average_confidence = round(avg_conf, 6),
        )


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _fallback_token_weights(
    tokens:    list[str],
    input_ids: torch.Tensor,
) -> list[TokenWeight]:
    """
    Fallback when neither attention nor LIME is available.
    Returns uniform dummy weights so the schema can still be satisfied.
    Students are expected to implement a real explanation method.
    """
    meaningful = [t for t in tokens if t not in ("<PAD>", "<UNK>")][:6]
    if not meaningful:
        return [TokenWeight(token="<unknown>", weight=0.0)]
    return [TokenWeight(token=t, weight=1.0 / len(meaningful)) for t in meaningful]


def _build_explanation(
    label:      SentimentLabel,
    top_tokens: list[TokenWeight],
    proc,
    confidence: float,
) -> str:
    top_words = [tw.token for tw in top_tokens[:3]]
    word_str  = ", ".join(f'"{w}"' for w in top_words) if top_words else "no clear tokens"
    exp = (
        f"Classified as {label.value} (confidence {confidence:.0%}) "
        f"based on key terms {word_str}."
    )
    if proc.abbreviations_expanded:
        abbrevs = ", ".join(proc.abbreviations_expanded[:3])
        exp += f" Medical abbreviations were expanded ({abbrevs})."
    return exp


# ---------------------------------------------------------------------------
# CLI demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print(
        "Run main.py to use the full pipeline, or import Predictor in your own script.\n"
        "Example:\n"
        "  from predict import Predictor\n"
        "  predictor = Predictor(model, vocab, pipeline)\n"
        "  out = predictor.predict('pt c/o sob x2d rn not responding')\n"
        "  print(out.model_dump_json(indent=2))\n"
    )
