"""
Dataset Utilities
=================
Handles:
  - Loading the CSV produced by data/generate_dataset.py
  - Train / validation / test splitting (stratified)
  - Vocabulary construction from training data
  - Loading pre-trained GloVe embeddings and building an embedding matrix
  - A PyTorch Dataset class ready for DataLoader

TODO (Student Task 4):
    The GloVe loader currently only reports OOV token counts.
    Extend it to:
      a) Print the 20 most frequent OOV tokens (these are your expansion candidates).
      b) Compute the OOV rate *before* and *after* preprocessing and include
         both numbers in your written report.

Usage:
    from dataset import load_splits, build_vocab, load_glove, FeedbackDataset
"""

from __future__ import annotations

import os
import zipfile
from collections import Counter
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset

from preprocess import PreprocessingPipeline

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

LABEL_TO_IDX: dict[str, int] = {
    "positive": 0,
    "negative": 1,
    "neutral":  2,
    "urgent":   3,
}
IDX_TO_LABEL: dict[int, str] = {v: k for k, v in LABEL_TO_IDX.items()}

PAD_TOKEN = "<PAD>"   # index 0
UNK_TOKEN = "<UNK>"   # index 1

GLOVE_DIM_OPTIONS = (50, 100, 200, 300)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_csv(csv_path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    required = {"message_id", "text", "label"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing columns: {missing}")
    # Drop rows with null text or label
    df = df.dropna(subset=["text", "label"]).reset_index(drop=True)
    return df


def load_splits(
    csv_path: str | Path,
    test_size: float  = 0.15,
    val_size:  float  = 0.15,
    random_state: int = 42,
    pipeline: Optional[PreprocessingPipeline] = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Load CSV and return stratified (train, val, test) DataFrames.
    Applies the preprocessing pipeline if provided (recommended).
    """
    df = load_csv(csv_path)

    if pipeline is not None:
        results = pipeline.process_batch(df["text"].tolist())
        df["text_clean"] = [r.cleaned_text   for r in results]
        df["source_det"] = [r.detected_source.value for r in results]
    else:
        df["text_clean"] = df["text"]

    train_df, test_df = train_test_split(
        df, test_size=test_size, stratify=df["label"], random_state=random_state
    )
    train_df, val_df = train_test_split(
        train_df, test_size=val_size / (1 - test_size),
        stratify=train_df["label"], random_state=random_state
    )

    print(f"Split sizes: train={len(train_df)}, val={len(val_df)}, test={len(test_df)}")
    return train_df.reset_index(drop=True), val_df.reset_index(drop=True), test_df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Vocabulary
# ---------------------------------------------------------------------------

class Vocabulary:
    """Simple word-level vocabulary built from training data."""

    def __init__(self, min_freq: int = 2):
        self.min_freq = min_freq
        self.word2idx: dict[str, int] = {PAD_TOKEN: 0, UNK_TOKEN: 1}
        self.idx2word: dict[int, str] = {0: PAD_TOKEN, 1: UNK_TOKEN}
        self._freq: Counter = Counter()

    def build(self, texts: list[str]) -> None:
        """Build vocabulary from a list of pre-tokenised (whitespace-split) texts."""
        for text in texts:
            self._freq.update(text.lower().split())

        for word, freq in self._freq.items():
            if freq >= self.min_freq and word not in self.word2idx:
                idx = len(self.word2idx)
                self.word2idx[word] = idx
                self.idx2word[idx]  = word

        print(f"Vocabulary size: {len(self.word2idx):,} tokens "
              f"(min_freq={self.min_freq}, {len(self._freq):,} unique raw tokens)")

    def encode(self, text: str, max_len: int = 40) -> list[int]:
        tokens = text.lower().split()[:max_len]
        ids = [self.word2idx.get(t, self.word2idx[UNK_TOKEN]) for t in tokens]
        # Pad to max_len
        ids += [self.word2idx[PAD_TOKEN]] * (max_len - len(ids))
        return ids

    def __len__(self) -> int:
        return len(self.word2idx)


def build_vocab(train_texts: list[str], min_freq: int = 2) -> Vocabulary:
    vocab = Vocabulary(min_freq=min_freq)
    vocab.build(train_texts)
    return vocab


# ---------------------------------------------------------------------------
# GloVe embedding loader
# ---------------------------------------------------------------------------

def load_glove(
    glove_path: str | Path,
    vocab: Vocabulary,
    embedding_dim: int = 100,
) -> np.ndarray:
    """
    Load GloVe vectors and return an embedding matrix aligned to vocab indices.

    Download GloVe (glove.6B.zip) from https://nlp.stanford.edu/projects/glove/
    and place it (or the extracted .txt files) in the data/ directory.

    Parameters
    ----------
    glove_path    : path to a GloVe .txt file OR the containing .zip archive
    vocab         : Vocabulary built from training data
    embedding_dim : must be one of 50, 100, 200, 300

    Returns
    -------
    numpy array of shape (vocab_size, embedding_dim); unknown tokens get
    a random vector drawn from N(0, 0.01).
    """
    if embedding_dim not in GLOVE_DIM_OPTIONS:
        raise ValueError(f"embedding_dim must be one of {GLOVE_DIM_OPTIONS}")

    glove_path = Path(glove_path)

    # If a .zip was provided, try to read the matching .txt inside it
    if glove_path.suffix == ".zip":
        with zipfile.ZipFile(glove_path) as zf:
            txt_name = f"glove.6B.{embedding_dim}d.txt"
            lines = zf.read(txt_name).decode("utf-8").splitlines()
    else:
        with open(glove_path, encoding="utf-8") as f:
            lines = f.readlines()

    glove_vectors: dict[str, np.ndarray] = {}
    for line in lines:
        parts = line.rstrip().split(" ")
        word  = parts[0]
        vec   = np.array(parts[1:], dtype=np.float32)
        glove_vectors[word] = vec

    vocab_size = len(vocab)
    matrix = np.random.randn(vocab_size, embedding_dim).astype(np.float32) * 0.01
    matrix[vocab.word2idx[PAD_TOKEN]] = 0.0   # PAD → zero vector

    n_found = 0
    oov_tokens: list[str] = []
    for word, idx in vocab.word2idx.items():
        if word in glove_vectors:
            matrix[idx] = glove_vectors[word]
            n_found += 1
        else:
            oov_tokens.append(word)

    oov_rate = (vocab_size - n_found) / vocab_size * 100
    print(f"GloVe coverage: {n_found:,}/{vocab_size:,} tokens  (OOV rate: {oov_rate:.1f}%)")

    # TODO (Student Task 4): Print the top-20 most frequent OOV tokens here.
    # Hint: use vocab._freq to look up their frequencies.

    return matrix


# ---------------------------------------------------------------------------
# PyTorch Dataset
# ---------------------------------------------------------------------------

class FeedbackDataset(Dataset):
    """
    Converts a DataFrame of patient feedback into tensors for model training.

    Parameters
    ----------
    df        : DataFrame with at least 'text_clean' and 'label' columns
    vocab     : fitted Vocabulary
    max_len   : maximum token sequence length (shorter → padded, longer → truncated)
    text_col  : which column to encode (default: 'text_clean')
    """

    def __init__(
        self,
        df:       pd.DataFrame,
        vocab:    Vocabulary,
        max_len:  int = 40,
        text_col: str = "text_clean",
    ):
        self.data    = df.reset_index(drop=True)
        self.vocab   = vocab
        self.max_len = max_len
        self.text_col = text_col

    def __len__(self) -> int:
        return len(self.data)

    def __getitem__(self, idx: int) -> dict[str, torch.Tensor]:
        row  = self.data.iloc[idx]
        ids  = self.vocab.encode(str(row[self.text_col]), max_len=self.max_len)
        label = LABEL_TO_IDX[row["label"]]
        return {
            "input_ids": torch.tensor(ids, dtype=torch.long),
            "label":     torch.tensor(label, dtype=torch.long),
        }


# ---------------------------------------------------------------------------
# Class weight helper (for imbalanced training)
# ---------------------------------------------------------------------------

def compute_class_weights(train_df: pd.DataFrame) -> torch.Tensor:
    """
    Return inverse-frequency class weights as a tensor.
    Pass to nn.CrossEntropyLoss(weight=...) to handle class imbalance.
    """
    counts = train_df["label"].value_counts()
    total  = counts.sum()
    weights = []
    for label in sorted(LABEL_TO_IDX.keys(), key=lambda x: LABEL_TO_IDX[x]):
        w = total / (len(LABEL_TO_IDX) * counts.get(label, 1))
        weights.append(w)
    wt = torch.tensor(weights, dtype=torch.float32)
    print(f"Class weights: { {k: f'{wt[v]:.3f}' for k,v in LABEL_TO_IDX.items()} }")
    return wt


# ---------------------------------------------------------------------------
# Quick sanity check
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    DATA_CSV = Path(__file__).parent.parent / "data" / "patient_feedback.csv"
    if not DATA_CSV.exists():
        print("Dataset not found – run: python data/generate_dataset.py")
    else:
        pipe = PreprocessingPipeline()
        train_df, val_df, test_df = load_splits(DATA_CSV, pipeline=pipe)
        vocab = build_vocab(train_df["text_clean"].tolist())
        ds    = FeedbackDataset(train_df, vocab)
        sample = ds[0]
        print(f"\nSample input_ids shape : {sample['input_ids'].shape}")
        print(f"Sample label           : {sample['label'].item()} "
              f"({IDX_TO_LABEL[sample['label'].item()]})")
