"""
Model Definitions
=================
Three model variants to compare:

  Model A – LSTMClassifier         : frozen GloVe embeddings
  Model B – FineTunedLSTMClassifier: GloVe initialised, embeddings trainable
  Model C – AttentionLSTMClassifier: trainable embeddings + additive attention
                                     (attention weights enable token-level explanations)

All three share the same LSTM backbone so that ablation experiments are fair.

TODO (Student Task 5):
    Implement the forward() method in AttentionLSTMClassifier.
    The method signature and expected tensor shapes are documented inline.
    Run all three models and fill in the comparison table in your report.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Helper – load a pre-trained embedding matrix
# ---------------------------------------------------------------------------

def embedding_layer_from_matrix(
    matrix: np.ndarray,
    freeze: bool,
    padding_idx: int = 0,
) -> nn.Embedding:
    """Create an nn.Embedding pre-initialised with `matrix`."""
    vocab_size, embed_dim = matrix.shape
    emb = nn.Embedding(vocab_size, embed_dim, padding_idx=padding_idx)
    emb.weight = nn.Parameter(torch.tensor(matrix, dtype=torch.float32), requires_grad=not freeze)
    return emb


# ---------------------------------------------------------------------------
# Model A – Frozen GloVe
# ---------------------------------------------------------------------------

class LSTMClassifier(nn.Module):
    """
    Bidirectional LSTM with *frozen* pre-trained GloVe embeddings.

    Best suited for cases where the training data is small and the domain
    vocabulary is close to general English.  Fast to train because embedding
    gradients are not computed.

    Architecture:
        Embedding (frozen) → BiLSTM → mean pooling → Dropout → Linear → softmax
    """

    def __init__(
        self,
        embedding_matrix: np.ndarray,
        hidden_dim:        int  = 128,
        num_layers:        int  = 2,
        num_classes:       int  = 4,
        dropout:           float = 0.3,
        padding_idx:       int  = 0,
    ):
        super().__init__()
        embed_dim = embedding_matrix.shape[1]
        self.embedding = embedding_layer_from_matrix(embedding_matrix, freeze=True,
                                                     padding_idx=padding_idx)
        self.lstm = nn.LSTM(
            input_size   = embed_dim,
            hidden_size  = hidden_dim,
            num_layers   = num_layers,
            batch_first  = True,
            bidirectional= True,
            dropout      = dropout if num_layers > 1 else 0.0,
        )
        self.dropout    = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_dim * 2, num_classes)  # *2 for bidirectional

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        """
        Args:
            input_ids: (batch, seq_len)  – padded token indices

        Returns:
            logits: (batch, num_classes)
        """
        x = self.embedding(input_ids)              # (B, L, E)
        x = self.dropout(x)
        out, _ = self.lstm(x)                       # (B, L, 2*H)
        # Mean pooling over non-padding positions
        pooled = out.mean(dim=1)                    # (B, 2*H)
        pooled = self.dropout(pooled)
        return self.classifier(pooled)             # (B, C)


# ---------------------------------------------------------------------------
# Model B – Fine-tuned GloVe
# ---------------------------------------------------------------------------

class FineTunedLSTMClassifier(nn.Module):
    """
    Identical architecture to LSTMClassifier but the embeddings are
    *trainable* (initialised from GloVe).

    This allows the model to adapt representations for domain-specific tokens
    (medical abbreviations, OCR artefacts) that GloVe has never seen or has
    only seen in generic contexts.

    Trade-off: higher capacity → more prone to overfitting on small datasets.
    Use with early stopping and compare val-F1 against Model A.
    """

    def __init__(
        self,
        embedding_matrix: np.ndarray,
        hidden_dim:        int  = 128,
        num_layers:        int  = 2,
        num_classes:       int  = 4,
        dropout:           float = 0.3,
        padding_idx:       int  = 0,
    ):
        super().__init__()
        embed_dim = embedding_matrix.shape[1]
        self.embedding = embedding_layer_from_matrix(embedding_matrix, freeze=False,
                                                     padding_idx=padding_idx)
        self.lstm = nn.LSTM(
            input_size   = embed_dim,
            hidden_size  = hidden_dim,
            num_layers   = num_layers,
            batch_first  = True,
            bidirectional= True,
            dropout      = dropout if num_layers > 1 else 0.0,
        )
        self.dropout    = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_dim * 2, num_classes)

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        x       = self.embedding(input_ids)        # (B, L, E)
        x       = self.dropout(x)
        out, _  = self.lstm(x)                      # (B, L, 2*H)
        pooled  = out.mean(dim=1)                   # (B, 2*H)
        pooled  = self.dropout(pooled)
        return self.classifier(pooled)             # (B, C)


# ---------------------------------------------------------------------------
# Model C – Attention LSTM  (student implementation required)
# ---------------------------------------------------------------------------

class AdditiveAttention(nn.Module):
    """
    Bahdanau-style additive attention over LSTM hidden states.

    Produces a context vector as a weighted sum of all time steps, and
    returns the attention weights for explainability.

    Input : hidden states  (B, L, 2*H)
    Output: context vector (B, 2*H),  attention weights (B, L)
    """

    def __init__(self, hidden_dim: int):
        super().__init__()
        # Projects concatenation of hidden state + query → scalar score
        self.attention = nn.Linear(hidden_dim * 2, 1)

    def forward(
        self,
        hidden_states: torch.Tensor,      # (B, L, 2*H)
        mask:          torch.Tensor | None = None,  # (B, L) True where padding
    ) -> tuple[torch.Tensor, torch.Tensor]:
        scores = self.attention(hidden_states).squeeze(-1)   # (B, L)
        if mask is not None:
            scores = scores.masked_fill(mask, float("-inf"))
        weights = F.softmax(scores, dim=-1)                  # (B, L)
        context = (weights.unsqueeze(-1) * hidden_states).sum(dim=1)  # (B, 2*H)
        return context, weights


class AttentionLSTMClassifier(nn.Module):
    """
    BiLSTM + additive attention with *trainable* embeddings.

    The attention weights map directly back to input tokens and can be used
    as a simple (though imperfect) token-level explanation of the prediction.

    TODO (Student Task 5):
    Implement the forward() method using the following template.
    Expected tensor shapes are annotated in comments.

    Steps:
      1. Look up embeddings                         → (B, L, E)
      2. Apply dropout to embeddings
      3. Run BiLSTM                                 → out: (B, L, 2*H)
      4. Build a padding mask from input_ids        → (B, L) bool
      5. Call self.attn(out, mask)                  → context: (B, 2*H), weights: (B, L)
      6. Apply dropout to context
      7. Pass through self.classifier               → logits: (B, C)
      8. Return logits AND weights (see signature)
    """

    def __init__(
        self,
        embedding_matrix: np.ndarray,
        hidden_dim:        int  = 128,
        num_layers:        int  = 2,
        num_classes:       int  = 4,
        dropout:           float = 0.3,
        padding_idx:       int  = 0,
    ):
        super().__init__()
        embed_dim = embedding_matrix.shape[1]
        self.padding_idx = padding_idx
        self.embedding   = embedding_layer_from_matrix(embedding_matrix, freeze=False,
                                                       padding_idx=padding_idx)
        self.lstm = nn.LSTM(
            input_size   = embed_dim,
            hidden_size  = hidden_dim,
            num_layers   = num_layers,
            batch_first  = True,
            bidirectional= True,
            dropout       = dropout if num_layers > 1 else 0.0,
        )
        self.attn       = AdditiveAttention(hidden_dim)
        self.dropout    = nn.Dropout(dropout)
        self.classifier = nn.Linear(hidden_dim * 2, num_classes)

    def forward(
        self,
        input_ids: torch.Tensor,                # (B, L)
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Returns
        -------
        logits  : (B, num_classes)
        weights : (B, L)  – attention weights over input tokens (for explainability)
        """
        # ------------------------------------------------------------------ #
        # TODO: Implement this method.  Remove the raise below when done.     #
        # ------------------------------------------------------------------ #
        raise NotImplementedError(
            "Implement AttentionLSTMClassifier.forward() as described in the docstring."
        )


# ---------------------------------------------------------------------------
# Factory helper
# ---------------------------------------------------------------------------

MODEL_REGISTRY = {
    "lstm-glove":    LSTMClassifier,
    "lstm-finetuned": FineTunedLSTMClassifier,
    "lstm-attention": AttentionLSTMClassifier,
}


def build_model(
    name:             str,
    embedding_matrix: np.ndarray,
    **kwargs,
) -> nn.Module:
    cls = MODEL_REGISTRY.get(name)
    if cls is None:
        raise ValueError(f"Unknown model '{name}'. Choose from {list(MODEL_REGISTRY)}")
    return cls(embedding_matrix=embedding_matrix, **kwargs)


# ---------------------------------------------------------------------------
# Parameter count utility
# ---------------------------------------------------------------------------

def count_parameters(model: nn.Module) -> int:
    total     = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"  Total params    : {total:,}")
    print(f"  Trainable params: {trainable:,}")
    return trainable


# ---------------------------------------------------------------------------
# Quick shape test (no real data needed)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    VOCAB, DIM, B, L = 1000, 100, 8, 20
    fake_matrix = np.random.randn(VOCAB, DIM).astype(np.float32)
    ids = torch.randint(0, VOCAB, (B, L))

    for name, cls in MODEL_REGISTRY.items():
        print(f"\n--- {name} ---")
        m = cls(fake_matrix)
        count_parameters(m)
        if name == "lstm-attention":
            print("  (forward() not yet implemented — skip shape test)")
            continue
        out = m(ids)
        assert out.shape == (B, 4), f"Expected (B,4), got {out.shape}"
        print(f"  Output shape: {out.shape}  ✓")
