"""
Dataset Generator for Patient Feedback Classification Project
=============================================================
Generates ~5000 labeled patient feedback messages from three realistic
sources: scanned PDFs (with OCR noise), emails, and nursing notes
(with medical abbreviations).

The generated data is designed so that:
  - Pre-processing makes a measurable difference in model performance.
  - Medical abbreviations create OOV challenges for frozen GloVe.
  - Class imbalance reflects real-world hospital feedback distributions.
  - Ambiguous "urgent" vs "negative" cases test model sensitivity.

Run:
    python generate_dataset.py                  # saves patient_feedback.csv
    python generate_dataset.py --samples 500    # smaller set for quick tests
"""

import random
import csv
import re
import argparse
from pathlib import Path

random.seed(42)

# ---------------------------------------------------------------------------
# Medical Abbreviations (nursing note style)
# ---------------------------------------------------------------------------
ABBREV_MAP = {
    "patient":              ["pt", "px"],
    "diagnosis":            ["dx"],
    "treatment":            ["tx", "trt"],
    "history":              ["hx", "h/o"],
    "with":                 ["w/", "w/"],
    "without":              ["w/o"],
    "because":              ["b/c"],
    "follow up":            ["f/u", "fu"],
    "complains of":         ["c/o"],
    "status post":          ["s/p"],
    "appointment":          ["appt"],
    "medication":           ["med", "meds"],
    "blood pressure":       ["bp"],
    "shortness of breath":  ["sob", "s.o.b."],
    "emergency room":       ["er", "ed"],
    "discharge":            ["dc", "d/c"],
    "doctor":               ["dr", "md"],
    "nurse":                ["rn"],
    "pain":                 ["pn"],
    "negative":             ["neg"],
    "positive":             ["pos"],
    "temperature":          ["temp"],
    "twice daily":          ["bid"],
    "three times daily":    ["tid"],
    "as needed":            ["prn"],
    "nothing by mouth":     ["npo"],
    "intravenous":          ["iv"],
    "operating room":       ["or"],
}

# OCR character-level substitutions (lower → noisy alternatives)
OCR_SUBS = {
    'a': ['@', 'o'],
    'e': ['c', '3', 'é'],
    'i': ['1', 'l', '|'],
    'o': ['0', 'Q'],
    's': ['5', '$'],
    't': ['+', '†'],
    'l': ['1', '|', 'I'],
    'n': ['m', 'ri'],
    'g': ['9'],
    'b': ['6'],
}

DOCTOR_NAMES = ["Johnson", "Smith", "Williams", "Brown", "Davis", "Miller", "Wilson",
                "Moore", "Taylor", "Anderson", "Thomas", "Jackson", "White", "Harris"]

# ---------------------------------------------------------------------------
# Template sentences  (5–20 words each, before any transformation)
# ---------------------------------------------------------------------------
TEMPLATES = {
    "positive": [
        "The care I received was exceptional and the staff were very kind to me",
        "Dr {name} was thorough and explained everything clearly throughout my entire stay",
        "The nursing team was incredibly attentive and responded quickly to every request",
        "I felt well cared for by the entire team from admission to discharge",
        "The facility was clean well maintained and all the staff were professional",
        "My recovery was faster than expected thanks to the excellent personalised care",
        "The doctor listened to all my concerns and addressed each one promptly",
        "Very satisfied with the treatment plan and the follow up care provided",
        "Pain management was effective and the nurses checked on me regularly",
        "Best hospital experience I have had I would highly recommend this hospital",
        "Staff were friendly and helped me feel comfortable during the entire procedure",
        "Quick response time from the nurses and excellent bedside manner from the doctor",
        "The physiotherapy team was outstanding and helped me regain mobility much faster",
        "Excellent communication from every department I never felt confused or left out",
        "The night staff were especially caring and attentive during my difficult recovery",
    ],
    "negative": [
        "Waited over four hours in the emergency room without receiving any updates",
        "The nurse seemed dismissive when I reported my increasing pain levels",
        "My medication was administered late multiple times over the course of my stay",
        "The room was not adequately cleaned and the bed linens appeared soiled",
        "The doctor did not explain the diagnosis or treatment plan in any detail",
        "I had to repeat my full medical history to every single staff member",
        "The discharge instructions were confusing incomplete and contained contradictory information",
        "The call button was ignored for long periods leaving me in significant distress",
        "Staff appeared overworked and could not provide the level of attention I needed",
        "The billing statement contained multiple errors and disputes went unresolved for weeks",
        "My appointment was cancelled at the last minute without adequate prior notification",
        "The specialist referral was never processed despite me making multiple requests",
        "The food was consistently cold and the dietary restrictions I noted were ignored",
        "I was not informed about side effects of the newly prescribed medication",
        "Post discharge follow up was never arranged even though it was promised",
    ],
    "neutral": [
        "The waiting room was adequately maintained with standard seating and basic amenities",
        "Staff followed standard procedures during my routine annual physical examination",
        "The appointment was completed as scheduled and there were no major unexpected issues",
        "Received standard post discharge wound care instructions for my surgical incision",
        "The facility has typical equipment and the rooms meet standard hospital requirements",
        "Check in process took about twenty minutes which is consistent with previous visits",
        "The doctor reviewed my chart and ordered the routine set of blood tests",
        "Prescription was sent electronically to the pharmacy as expected after the consultation",
        "Follow up appointment has been scheduled for next month as part of standard care",
        "The procedure was carried out as described in the consent form I signed",
        "Staff explained the billing process and what would be covered by my insurance",
        "Lab results came back within the normal expected processing timeframe of two days",
        "The imaging department handled the referral and scheduled my MRI within one week",
        "Parking was available and the visitor policy was clearly explained at reception",
        "The triage nurse assessed me and assigned the appropriate priority level for my case",
    ],
    "urgent": [
        "Patient had severe allergic reaction to medication that was administered without informing me",
        "Patient was left completely alone for three hours after a major surgical procedure",
        "Wrong medication dosage was administered twice and this needs immediate formal review",
        "Critical lab values were not communicated to the attending physician for over six hours",
        "Patient fell from the bed because the side rail was not properly secured",
        "Symptoms of anaphylaxis were reported but the staff response time was dangerously slow",
        "Surgical wound showing clear signs of serious infection that were flagged and ignored",
        "Patient has a documented allergy but was still given the contraindicated medication",
        "Chest pain was reported for over two hours before any medical assessment was done",
        "Equipment malfunction during the procedure was not reported or documented by any staff",
        "Patient was discharged despite clearly deteriorating vital signs and family objections",
        "Wrong patient identity band was attached creating a serious medication safety risk",
    ],
}

# Nursing note stop-words to randomly drop (terse style)
TERSE_DROPS = {"the", "a", "an", "was", "were", "is", "are", "and", "or", "but",
               "to", "of", "in", "for", "on", "at", "by", "with", "that", "this"}

# Email subject-line prefixes
EMAIL_PREFIXES = [
    "Re: Patient Feedback - ",
    "Fwd: ",
    "Patient Comment: ",
    "Feedback Received: ",
    "CARE Feedback Portal - ",
    "Patient Experience Survey: ",
]

# Email sign-offs occasionally appended
EMAIL_SIGNOFFS = [
    "Thank you for your attention.",
    "Please respond at your earliest convenience.",
    "Regards,",
    "Best wishes,",
]


# ---------------------------------------------------------------------------
# Noise application helpers
# ---------------------------------------------------------------------------

def apply_ocr_noise(text: str, intensity: float = 0.10) -> str:
    """Simulate OCR scanning errors at character level."""
    chars = list(text)
    for i, ch in enumerate(chars):
        if ch.lower() in OCR_SUBS and random.random() < intensity:
            replacement = random.choice(OCR_SUBS[ch.lower()])
            chars[i] = replacement
    text = "".join(chars)

    # Random inserted space (split token)
    if random.random() < 0.25 and len(text) > 6:
        pos = random.randint(3, len(text) - 3)
        text = text[:pos] + " " + text[pos:]

    # Random duplicated letter
    if random.random() < 0.15 and len(text) > 4:
        pos = random.randint(1, len(text) - 2)
        text = text[:pos] + text[pos] + text[pos:]

    # Occasionally ALL CAPS (poor scan)
    if random.random() < 0.20:
        text = text.upper()

    return text


def apply_abbrevs(text: str, intensity: float = 0.65) -> str:
    """Replace full medical terms with their common abbreviations."""
    for full, options in ABBREV_MAP.items():
        pattern = re.compile(re.escape(full), re.IGNORECASE)
        if pattern.search(text) and random.random() < intensity:
            text = pattern.sub(random.choice(options), text, count=1)
    return text


def make_terse(text: str, drop_prob: float = 0.55) -> str:
    """Drop articles and connectives to mimic terse nursing note style."""
    words = text.split()
    kept = [w for w in words if w.lower() not in TERSE_DROPS or random.random() > drop_prob]
    result = " ".join(kept)
    # Randomly strip punctuation
    if random.random() < 0.5:
        result = result.replace(",", "").replace(".", "").replace(";", "")
    return result


def add_email_wrapper(text: str) -> str:
    prefix = random.choice(EMAIL_PREFIXES)
    result = prefix + text
    if random.random() < 0.35:
        result += " " + random.choice(EMAIL_SIGNOFFS)
    return result


# ---------------------------------------------------------------------------
# Sample generation
# ---------------------------------------------------------------------------

def generate_sample(template: str, source: str, label: str) -> dict:
    """Transform a template into a noisy sample for the given source type."""
    text = template.replace("{name}", random.choice(DOCTOR_NAMES))
    original = text  # keep clean copy for reference

    if source == "pdf":
        intensity = random.uniform(0.06, 0.22)
        text = apply_ocr_noise(text, intensity)

    elif source == "nursing_note":
        text = apply_abbrevs(text, intensity=random.uniform(0.45, 0.85))
        text = make_terse(text, drop_prob=random.uniform(0.40, 0.70))
        # Occasional all-lower
        if random.random() < 0.60:
            text = text.lower()

    elif source == "email":
        text = add_email_wrapper(text)
        # Occasional HTML-like artefacts (forwarded mail)
        if random.random() < 0.15:
            text = text + " <br>"
        if random.random() < 0.10:
            text = "&gt; " + text

    return {
        "text": text,
        "label": label,
        "source": source,
        "clean_reference": original,   # NOT for model training – only for analysis
    }


# ---------------------------------------------------------------------------
# Full dataset generation
# ---------------------------------------------------------------------------

# Class distribution (mirrors real hospital feedback imbalance)
CLASS_DISTRIBUTION = {
    "positive": 0.40,
    "neutral":  0.30,
    "negative": 0.22,
    "urgent":   0.08,
}

SOURCE_WEIGHTS = {
    "pdf":           0.30,
    "nursing_note":  0.45,
    "email":         0.25,
}


def generate_dataset(n_samples: int = 5000) -> list[dict]:
    samples = []
    sources = list(SOURCE_WEIGHTS.keys())
    source_probs = [SOURCE_WEIGHTS[s] for s in sources]

    for label, proportion in CLASS_DISTRIBUTION.items():
        n = round(n_samples * proportion)
        for _ in range(n):
            template = random.choice(TEMPLATES[label])
            source = random.choices(sources, weights=source_probs, k=1)[0]
            samples.append(generate_sample(template, source, label))

    random.shuffle(samples)

    # Assign sequential IDs
    for i, s in enumerate(samples):
        s["message_id"] = f"MSG-{i+1:05d}"

    return samples


def save_csv(samples: list[dict], path: Path) -> None:
    fieldnames = ["message_id", "text", "label", "source", "clean_reference"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(samples)
    print(f"Saved {len(samples)} samples -> {path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate synthetic patient feedback dataset")
    parser.add_argument("--samples", type=int, default=5000, help="Total number of samples")
    parser.add_argument("--out", type=str, default="patient_feedback.csv", help="Output CSV path")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    out_path = Path(__file__).parent / args.out
    data = generate_dataset(args.samples)
    save_csv(data, out_path)

    # Print class & source distribution summary
    from collections import Counter
    labels  = Counter(s["label"]  for s in data)
    sources = Counter(s["source"] for s in data)
    print("\nLabel distribution:")
    for lbl, cnt in sorted(labels.items()):
        print(f"  {lbl:<12} {cnt:>5}  ({cnt/len(data)*100:.1f}%)")
    print("\nSource distribution:")
    for src, cnt in sorted(sources.items()):
        print(f"  {src:<15} {cnt:>5}  ({cnt/len(data)*100:.1f}%)")
    print("\nSample rows (one per class × source):")
    seen = set()
    for s in data:
        key = (s["label"], s["source"])
        if key not in seen:
            seen.add(key)
            print(f'\n  [{s["label"].upper()} / {s["source"]}]')
            print(f'  raw  : {s["text"][:90]}')
            print(f'  clean: {s["clean_reference"][:90]}')
