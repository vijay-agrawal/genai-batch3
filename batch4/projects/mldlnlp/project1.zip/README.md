# Mini-Project 1: Patient Feedback Message Classification

## The Problem

A hospital wants to automatically classify short patient feedback messages
(5–20 words) into one of four sentiment categories:

| Label | Meaning | Approx. frequency |
|---|---|---|
| `positive` | Satisfied patient experience | 40% |
| `neutral` | Factual / routine feedback | 30% |
| `negative` | Dissatisfaction, complaints | 22% |
| `urgent` | Safety concern, requires immediate review | 8% |

### Why this is hard

Messages arrive from **three very different sources**, each with its own
noise profile:

| Source | Typical issues |
|---|---|
| **Scanned PDFs** | OCR artefacts (`1` → `i`, `0` → `o`, random spaces, ALL CAPS) |
| **Nursing notes** | Dense medical abbreviations (`pt c/o sob`, `dx`, `tx`), dropped articles, no punctuation |
| **Emails** | Subject-line headers (`Re: Patient Feedback –`), HTML artefacts, sign-off boilerplate |

The deployment environment has **strict latency and compute constraints**,
ruling out large transformer models.

---

## Your Task

Compare two LSTM-based approaches:

- **Approach A** – BiLSTM with *frozen* pre-trained GloVe embeddings
- **Approach B** – BiLSTM with GloVe-initialised *trainable* embeddings

You will implement the preprocessing, training, and explainability steps
and write a report analysing when each approach is better and why.

---

## Directory Structure

```
project1/
├── README.md               ← you are here
├── rubric.md               ← grading criteria
├── requirements.txt        ← Python dependencies
│
├── data/
│   ├── generate_dataset.py ← run this first to create the dataset
│   └── patient_feedback.csv← generated output (5 000 rows)
│
└── starter/
    ├── schemas.py          ← Pydantic output schema  (DO NOT MODIFY)
    ├── preprocess.py       ← preprocessing pipeline  (extend abbreviation dict)
    ├── dataset.py          ← vocab, GloVe loader, Dataset class
    ├── models.py           ← 3 model architectures   (implement forward() in Model C)
    ├── train.py            ← training loop           (implement train_one_epoch())
    ├── evaluate.py         ← metrics & comparison    (complete, read carefully)
    ├── predict.py          ← prediction + LIME       (implement explain_with_lime())
    └── main.py             ← orchestrates everything (complete, run end-to-end)
```

---

## Quick Start

### 1. Set up the environment

```bash
python -m venv .venv
# Linux/Mac:
source .venv/bin/activate
# Windows:
.venv\Scripts\activate

pip install -r requirements.txt
python -m nltk.downloader punkt stopwords
```

### 2. Generate the dataset

```bash
python data/generate_dataset.py
# Creates: data/patient_feedback.csv  (~5 000 rows)
# For quick testing: python data/generate_dataset.py --samples 500
```

Open the CSV and inspect it before writing any code.
Notice the three `source` types and how the same underlying message looks
completely different depending on its origin.

### 3. Download GloVe

Download `glove.6B.zip` from the Stanford NLP website and place it in the
`data/` directory (or any path you pass to `--glove`).

> **File size:** 822 MB zip.  If bandwidth is limited, use the 50-d variant
> (`glove.6B.50d.txt`) — it fits in ~170 MB.

### 4. Run the baseline (Models A & B)

```bash
python starter/main.py \
    --glove  data/glove.6B.100d.txt \
    --data   data/patient_feedback.csv \
    --dim    100 \
    --epochs 20 \
    --models lstm-glove,lstm-finetuned \
    --out    outputs/
```

This trains both models, saves checkpoints, evaluation plots, and JSON
predictions to `outputs/`.

---

## Student Tasks

The codebase has **7 explicit TODOs** for you to complete:

| Task | File | Description |
|---|---|---|
| **1** | `preprocess.py` | Add ≥10 medical abbreviations to `MEDICAL_ABBREVS` |
| **2** | `preprocess.py` | Extend `fix_ocr_noise()` for `@`, `\|`, and digit-in-word patterns |
| **3** | `preprocess.py` | Verify your additions reduce OOV rate; document before/after numbers |
| **4** | `dataset.py` | Print top-20 OOV tokens in `load_glove()`; use them to guide Tasks 1–3 |
| **5** | `models.py` | Implement `AttentionLSTMClassifier.forward()` |
| **6** | `train.py` | Implement `train_one_epoch()` |
| **7** | `predict.py` | Implement `explain_with_lime()` |

---

## Experiments to Run

After completing the tasks, run these ablation experiments and include
results in your report:

### Experiment 1: Preprocessing ablation

```python
# In main.py or a notebook, create four pipelines:
configs = [
    PreprocessingPipeline(fix_ocr=False, expand_abbrevs=False),   # baseline (no preprocessing)
    PreprocessingPipeline(fix_ocr=True,  expand_abbrevs=False),   # OCR only
    PreprocessingPipeline(fix_ocr=False, expand_abbrevs=True),    # abbrev only
    PreprocessingPipeline(fix_ocr=True,  expand_abbrevs=True),    # full pipeline  ← default
]
# Train Model A with each and compare macro-F1 and urgent-recall.
```

**Expected finding:** Abbreviation expansion should have the largest impact
on nursing-note inputs; OCR correction on PDF inputs.

### Experiment 2: Frozen vs fine-tuned embeddings

Train both Model A and Model B under the same conditions and compare:

- Macro-F1 and urgent recall on the test set
- OOV token handling (check the most frequent OOV tokens — do fine-tuned
  embeddings learn better representations for them?)
- Training curves (does Model B overfit faster?)
- Inference time (should be similar; embeddings don't affect inference speed)

**Key question:** With only ~3 500 training examples, does fine-tuning
help or hurt?  Under what conditions would you choose each approach?

### Experiment 3: Per-source performance

The `evaluate_model()` function already reports per-source macro-F1.
Analyse which source is hardest and why.  Does preprocessing help more for
one source type than another?

---

## Output Format

All predictions must be serialised as JSON that validates against
`ClassificationOutput` (see `starter/schemas.py`).

Example single prediction:

```json
{
  "message_id": "MSG-00042",
  "original_text": "pt c/o sob x2d rn not responding",
  "predicted_label": "urgent",
  "confidence": 0.874,
  "class_probabilities": {
    "positive": 0.031,
    "negative": 0.071,
    "neutral":  0.024,
    "urgent":   0.874
  },
  "preprocessing_info": {
    "original_text": "pt c/o sob x2d rn not responding",
    "cleaned_text": "patient complains of shortness of breath for 2 days nurse not responding",
    "detected_source": "nursing_note",
    "abbreviations_expanded": ["pt → patient", "c/o → complains of",
                               "sob → shortness of breath", "rn → nurse"],
    "ocr_corrections": [],
    "email_header_removed": false,
    "word_count_before": 7,
    "word_count_after": 13
  },
  "reasoning": {
    "top_influential_tokens": [
      {"token": "shortness of breath", "weight": 0.71},
      {"token": "not responding",      "weight": 0.58},
      {"token": "2 days",              "weight": 0.39}
    ],
    "explanation": "Classified as urgent (87%) based on key terms 'shortness of breath', 'not responding'. Medical abbreviations were expanded (pt → patient, c/o → complains of, sob → shortness of breath).",
    "confidence_flags": ["contains_abbreviations"]
  },
  "model_name": "lstm-finetuned",
  "model_version": "1.0.0"
}
```

---

## Explainability

### Attention weights (Model C)
After implementing `AttentionLSTMClassifier.forward()`, the model returns
attention weights alongside logits.  Visualise them as a heatmap over the
input tokens to see which words the model "attends to".

> **Caution:** Attention weights are a popular but imperfect explanation
> tool.  They show what the model focuses on, not necessarily what drives
> the output.  Compare with LIME to see if they agree.

### LIME
LIME treats the model as a black box and approximates its local decision
boundary by perturbing the input.  It works with any model.

After implementing `explain_with_lime()`, verify that the explanations are
sensible for both correct and incorrect predictions, especially for the
`urgent` class.

---

## Evaluation Metric Priority

Because misclassifying an `urgent` message as anything else has safety
consequences, evaluation is weighted as follows:

1. **Urgent-class recall** (primary — must be ≥ 0.80)
2. **Macro-F1** (balanced across all four classes)
3. **Weighted F1** (reflects class frequency)
4. Accuracy (reported but not the primary metric)

---

## Hints & Common Pitfalls

1. **Data leakage** — Build your vocabulary and fit any preprocessing
   statistics *only* on the training split.  `clean_reference` in the CSV
   is there for analysis only — never use it as a model input.

2. **OOV tokens** — Run `load_glove()` and note the OOV rate.  Then extend
   `MEDICAL_ABBREVS` and re-run to see how much it drops.  This is the core
   insight of Task 3.

3. **Imbalanced classes** — Naive accuracy will be ~70% even with a model
   that never predicts `urgent`.  Always report macro-F1 and urgent recall.

4. **Early stopping** — Fine-tuned embeddings (Model B) have more trainable
   parameters.  Without early stopping, val-F1 may peak at epoch 5 but
   training continues to overfit.

5. **Attention ≠ explanation** — Attention weights show correlation, not
   causation.  Do not equate high attention with "the model decided because
   of this word."  LIME gives a more rigorous (though slower) alternative.

---

## Report Structure (≤ 4 pages)

1. **Dataset analysis** – class distribution, noise characterisation, OOV
   analysis table (before/after preprocessing).

2. **Preprocessing pipeline** – ablation table; which step helped most and
   for which source type.

3. **Model comparison** – side-by-side table (macro-F1, urgent recall,
   parameter count, inference latency).  Answer: *which approach would you
   deploy, and why?*

4. **Explainability analysis** – 2 LIME examples (one per class you find
   most interesting); do attention and LIME agree?

5. **Conclusion** – one paragraph: given the latency constraint and small
   dataset, what is your recommendation?

---

## Grading

See [rubric.md](rubric.md) for the full grading breakdown (100 pts + 10 bonus).

Key milestones:

| Milestone | Points |
|---|---|
| Tasks 1–4 (preprocessing + OOV analysis) | 30 |
| Tasks 5–6 (model + training) | 20 |
| Task 7 + explainability report | 15 |
| Evaluation & comparison | 15 |
| Pydantic output | 5 |
| Report quality | 5 |
| Bonus experiments | up to +10 |
