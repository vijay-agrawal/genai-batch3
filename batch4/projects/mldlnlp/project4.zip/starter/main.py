"""
Main Entry Point — Project 4: Semantic Search & Retrieval
==========================================================
Runs all pipeline experiments end-to-end:

  Part A — Vocabulary mismatch analysis + sparse baselines
  Part B — Dense retrieval with SBERT
  Part C — Multi-stage pipeline (expansion + BM25 + re-rank)
  Part D — FAISS index benchmarks + scale projection

Run:
    python main.py --part A              # sparse baseline only
    python main.py --part B              # SBERT dense
    python main.py --part C              # full pipeline
    python main.py --part D              # FAISS benchmarks
    python main.py --part all            # everything
    python main.py --part all --k 10     # top-K evaluation cutoff
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))

from embeddings import DenseRetriever, EmbeddingEncoder, estimate_embedding_memory
from evaluate import (
    evaluate_retrieval,
    plot_index_benchmarks,
    plot_scale_projection,
    print_comparison_table,
)
from faiss_index import FAISSRetriever, ScaleAnalyser
from pipeline import MultiStagePipeline, run_ablation
from query_expansion import QueryExpander
from retrieval import BM25Retriever, TFIDFRetriever, analyse_vocabulary_mismatch
from schemas import IndexType, RetrievalMethod


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--part",     choices=["A", "B", "C", "D", "all"], default="all")
    p.add_argument("--data_dir", default="data")
    p.add_argument("--out",      default="outputs")
    p.add_argument("--k",        type=int, default=10, help="Evaluation cutoff")
    p.add_argument("--device",   default="cpu")
    p.add_argument("--model",    default="all-MiniLM-L6-v2", help="SBERT model name")
    p.add_argument("--cache_embeddings", action="store_true",
                   help="Cache SBERT embeddings to disk")
    return p.parse_args()


# ---------------------------------------------------------------------------
# Part A — Sparse baselines + vocabulary mismatch
# ---------------------------------------------------------------------------

def run_part_a(data_dir: Path, out_dir: Path, k: int) -> dict:
    print("\n" + "="*60)
    print("  PART A — Vocabulary Mismatch + Sparse Baselines")
    print("="*60)

    corpus_df = pd.read_csv(data_dir / "clinical_corpus.csv")
    query_df  = pd.read_csv(data_dir / "query_testset.csv")
    print(f"Corpus: {len(corpus_df)} docs | Queries: {len(query_df)}")

    # 1. Vocabulary mismatch analysis
    print("\n  1. Vocabulary mismatch analysis:")
    mismatch_df = analyse_vocabulary_mismatch(corpus_df, query_df)
    high_mismatch = mismatch_df[mismatch_df["lay_mismatch_pct"] == 100]
    print(f"  Queries with 100% lay-term mismatch: {len(high_mismatch)}/{len(query_df)}")
    print("  These queries will score ZERO with TF-IDF unless expansion is applied.")

    # 2. Query expansion detection demo
    print("\n  2. Query expansion preview:")
    expander = QueryExpander()
    demo_queries = [
        "heart attack treatment aspirin antiplatelet",
        "water pill swollen ankles",
        "brain bleed anticoagulation",
    ]
    for q in demo_queries:
        lay_terms = expander.detect_lay_terms(q)
        print(f"  '{q[:50]}'")
        print(f"    -> Lay terms detected: {lay_terms}")
        try:
            exp = expander.expand(q)
            print(f"    -> Expanded: {exp.expansion_query[:80]}")
        except NotImplementedError:
            print(f"    -> (expand() not yet implemented — Task 2)")

    # 3. TF-IDF baseline
    print("\n  3. TF-IDF baseline retrieval:")
    tfidf = TFIDFRetriever()
    tfidf.fit(corpus_df)

    responses_tfidf = [
        tfidf.search(row["query_id"], row["query_text"], top_k=k)
        for _, row in query_df.iterrows()
    ]
    metrics_tfidf = evaluate_retrieval(responses_tfidf, query_df, k=k, model_name="TF-IDF")

    # 4. BM25 baseline
    print("\n  4. BM25 baseline retrieval:")
    bm25 = BM25Retriever()
    bm25.fit(corpus_df)

    responses_bm25 = [
        bm25.search(row["query_id"], row["query_text"], top_k=k)
        for _, row in query_df.iterrows()
    ]
    metrics_bm25 = evaluate_retrieval(responses_bm25, query_df, k=k, model_name="BM25")

    # 5. BM25 + expansion (if Task 2 implemented)
    print("\n  5. BM25 + query expansion:")
    try:
        responses_expanded = []
        for _, row in query_df.iterrows():
            exp = expander.expand(row["query_text"])
            resp = bm25.search(row["query_id"], exp.expansion_query, top_k=k)
            responses_expanded.append(resp)
        metrics_expanded = evaluate_retrieval(
            responses_expanded, query_df, k=k, model_name="BM25+Expansion"
        )
    except NotImplementedError:
        metrics_expanded = None
        print("  (skipped — Task 2 not implemented)")

    metrics_list = [m for m in [metrics_tfidf, metrics_bm25, metrics_expanded] if m]
    print_comparison_table(metrics_list, k=k)

    # Save
    out_path = out_dir / "sparse_results.json"
    with open(out_path, "w") as f:
        json.dump(
            [{k2: v for k2, v in m.items() if k2 != "per_query"} for m in metrics_list],
            f, indent=2,
        )
    print(f"\n  Sparse results saved -> {out_path}")

    return {"tfidf": metrics_tfidf, "bm25": metrics_bm25}


# ---------------------------------------------------------------------------
# Part B — Dense retrieval with SBERT
# ---------------------------------------------------------------------------

def run_part_b(
    data_dir: Path,
    out_dir:  Path,
    k:        int,
    device:   str = "cpu",
    model:    str = "all-MiniLM-L6-v2",
    cache:    bool = False,
) -> dict:
    print("\n" + "="*60)
    print("  PART B — Dense Retrieval with SBERT")
    print("="*60)

    corpus_df = pd.read_csv(data_dir / "clinical_corpus.csv")
    query_df  = pd.read_csv(data_dir / "query_testset.csv")

    # Memory estimate
    print("\n  Memory requirements:")
    for n in [len(corpus_df), 1_000_000, 10_000_000]:
        estimate_embedding_memory(n)
    estimate_embedding_memory(10_000_000, compression="pq96")

    encoder = EmbeddingEncoder(model_name=model, device=device)
    dense   = DenseRetriever(encoder)

    cache_path = out_dir / "corpus_embeddings.npy" if cache else None

    try:
        dense.fit(corpus_df, cache_path=cache_path)
        print(f"\n  Embedding matrix: {dense.memory_mb:.1f} MB")

        responses_sbert = []
        for _, row in query_df.iterrows():
            resp = dense.search(row["query_id"], row["query_text"], top_k=k)
            responses_sbert.append(resp)

        metrics_sbert = evaluate_retrieval(
            responses_sbert, query_df, k=k, model_name="SBERT dense"
        )

        # Demonstrate semantic match
        print("\n  Sample: SBERT top-3 for 'heart attack treatment aspirin antiplatelet':")
        resp = dense.search("demo", "heart attack treatment aspirin antiplatelet", top_k=3)
        for r in resp.results:
            print(f"    Rank {r.rank} [{r.topic}] score={r.score:.3f}")
            print(f"      {r.title[:70]}")

        return metrics_sbert

    except NotImplementedError:
        print("  (SBERT encode() not implemented — Tasks 5 & 6)")
        print("  Expected: SBERT will find 'myocardial infarction' docs for 'heart attack' query")
        print("  because their embeddings are semantically similar.")
        return {}


# ---------------------------------------------------------------------------
# Part C — Multi-stage pipeline
# ---------------------------------------------------------------------------

def run_part_c(data_dir: Path, out_dir: Path, k: int, device: str) -> None:
    print("\n" + "="*60)
    print("  PART C — Multi-Stage Pipeline Ablation")
    print("="*60)

    corpus_df = pd.read_csv(data_dir / "clinical_corpus.csv")
    query_df  = pd.read_csv(data_dir / "query_testset.csv")

    ablation_df = run_ablation(corpus_df, query_df, top_k=k, verbose=True)

    # Save ablation table
    ablation_path = out_dir / "ablation_results.csv"
    ablation_df.to_csv(ablation_path, index=False)
    print(f"\n  Ablation results saved -> {ablation_path}")

    print("\n  Key question for report:")
    print("  Which stage gives the biggest MRR improvement?")
    print("  A->B (query expansion) OR B->C (dense embeddings) OR C->D (combined)?")

    # Clinical safety note
    print("\n" + "="*60)
    print("  CLINICAL SAFETY NOTE")
    print("="*60)
    print(textwrap.dedent("""
  Is this system acceptable at point-of-care?
  Generally NO, in isolation.

  Missing a single critical drug-interaction guideline or contraindication
  is UNACCEPTABLE in a clinical decision support setting.
  Recall@10 of 0.85 means 15% of critical documents are missed.

  Mitigating recommendations (do NOT implement — report only):
  1. HUMAN-IN-THE-LOOP: All results should be reviewed by a pharmacist or
     clinician before acting on them.
  2. SAFETY FILTER LAYER: A separate rule-based system that flags known
     high-risk drug pairs, regardless of retrieval rank.
  3. RECALL OVER PRECISION: Tune the threshold/top-K to maximise Recall
     even at the cost of Precision. Better to review 20 results than miss one.
  4. ALERT ON UNCERTAINTY: If max_score < threshold, show a "low confidence"
     warning and escalate to a human expert.
  5. DOMAIN-SPECIFIC FINE-TUNING: Fine-tune SBERT on a curated clinical QA
     dataset (e.g., MedQA, BioASQ) to improve clinical term alignment.
  6. ADVERSARIAL TESTING: Red-team the system with adversarial queries that
     are designed to elicit dangerous missed retrievals.
    """).strip())


# ---------------------------------------------------------------------------
# Part D — FAISS index benchmarks + scale projection
# ---------------------------------------------------------------------------

def run_part_d(data_dir: Path, out_dir: Path, device: str) -> None:
    print("\n" + "="*60)
    print("  PART D — FAISS Index Benchmarks + Scale Projection")
    print("="*60)

    corpus_df = pd.read_csv(data_dir / "clinical_corpus.csv")
    encoder   = EmbeddingEncoder(device=device)

    # Scale projection (no SBERT needed for projection)
    print("\n  Scale projection @ 10M documents:")
    analyser = ScaleAnalyser()
    try:
        projections = analyser.project()
        analyser.print_table(projections)
        plot_scale_projection(projections)

        # Save projections
        proj_path = out_dir / "scale_projections.json"
        with open(proj_path, "w") as f:
            json.dump([p.model_dump() for p in projections], f, indent=2)
        print(f"  Scale projections saved -> {proj_path}")

    except NotImplementedError:
        print("  (ScaleAnalyser.project() not implemented — Task 10)")
        print("  Showing expected output structure:")
        print("  IVF-PQ is the only index that fits 16 GB RAM AND meets 50 ms SLA.")

    # FAISS index benchmarks on 2K corpus (if SBERT available)
    print("\n  FAISS index comparison (requires SBERT + Tasks 7-9):")
    try:
        texts = corpus_df["full_text"].fillna("").tolist()
        embeddings = encoder.encode(texts, show_progress=True)

        benchmarks = []
        for idx_type in [IndexType.IVF_FLAT, IndexType.HNSW, IndexType.IVF_PQ]:
            print(f"\n  Building {idx_type.value} ...")
            retriever = FAISSRetriever(index_type=idx_type)
            retriever.fit(
                embeddings,
                corpus_df["doc_id"].tolist(),
                corpus_df["title"].tolist(),
                corpus_df["topic"].tolist(),
            )
            # 20 random queries for benchmarking
            q_vecs = embeddings[np.random.choice(len(embeddings), 20, replace=False)]
            bm = retriever.benchmark(q_vecs)
            benchmarks.append(bm)
            print(f"  {bm.index_type.value}: {bm.query_time_ms:.1f} ms/query, {bm.memory_mb:.1f} MB")

        print_comparison_table(
            [{"model": b.index_type.value, "mrr": 0, "precision": 0, "recall": 0,
              "ndcg": 0, "avg_latency_ms": b.query_time_ms} for b in benchmarks],
            k=10,
        )
        plot_index_benchmarks(benchmarks)

    except NotImplementedError as e:
        print(f"  Skipped: {e}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

import textwrap


def main():
    args    = parse_args()
    out_dir = Path(args.out)
    data_dir = Path(args.data_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Check data exists
    if not (data_dir / "clinical_corpus.csv").exists():
        sys.exit(
            "Dataset not found. Run:\n  python data/generate_dataset.py"
        )

    if args.part in ("A", "all"):
        run_part_a(data_dir, out_dir, args.k)

    if args.part in ("B", "all"):
        run_part_b(data_dir, out_dir, args.k, device=args.device, model=args.model,
                   cache=args.cache_embeddings)

    if args.part in ("C", "all"):
        run_part_c(data_dir, out_dir, args.k, device=args.device)

    if args.part in ("D", "all"):
        run_part_d(data_dir, out_dir, device=args.device)

    print(f"\nOutputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()
