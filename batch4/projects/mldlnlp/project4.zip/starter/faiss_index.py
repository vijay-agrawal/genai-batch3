"""
FAISS Index Builders — IVFFlat, HNSW, IVF-PQ
=============================================
Approximate Nearest Neighbour (ANN) search for large-scale retrieval.

At 10 million clinical notes, exact cosine search is infeasible:
  - Memory: 10M x 384 x 4 bytes = 14.4 GB (exceeds 16 GB RAM)
  - Latency: ~100-500 ms per query on CPU (exceeds 50 ms SLA)

FAISS trades a small amount of recall for massive speed and memory gains.

Index comparison:
+-----------+------------------+-------------------+-------------------+----------+
| Index     | Memory @10M docs | Query latency CPU | Recall@10 typical | Suitable |
+-----------+------------------+-------------------+-------------------+----------+
| Flat      | 14.4 GB          | ~200 ms           | 100% (exact)      | Dev only |
| IVFFlat   | ~15 GB           | ~20-40 ms         | ~95%              | Medium   |
| HNSW      | ~18 GB           | ~2-5 ms           | ~98%              | No (RAM) |
| IVF-PQ    | ~0.9 GB          | ~5-15 ms          | ~85-90%           | YES      |
+-----------+------------------+-------------------+-------------------+----------+

Recommendation: IVF-PQ is the only index type that fits in 16 GB RAM AND
meets the 50 ms CPU latency SLA for 10M documents.

Student Tasks:
  Task 7: Implement FAISSRetriever._build_ivfflat()
  Task 8: Implement FAISSRetriever._build_hnsw()
  Task 9: Implement FAISSRetriever._build_ivfpq()   <-- most important
  Task 10: ScaleAnalyser.project() — fill memory/latency table and Pydantic validation
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from schemas import (
    IndexBenchmark,
    IndexType,
    RetrievalMethod,
    RetrievalResponse,
    ScaleProjection,
    SearchResult,
)


# ---------------------------------------------------------------------------
# FAISS Retriever
# ---------------------------------------------------------------------------

class FAISSRetriever:
    """
    FAISS-backed approximate nearest-neighbour retrieval.

    Supports three index types, selected at construction time:
      - IndexType.IVF_FLAT  (inverted file with exact search within clusters)
      - IndexType.HNSW      (hierarchical navigable small world)
      - IndexType.IVF_PQ    (inverted file + product quantization — RECOMMENDED)

    Usage:
        retriever = FAISSRetriever(index_type=IndexType.IVF_PQ, n_clusters=256)
        retriever.fit(doc_embeddings, doc_ids, doc_titles, doc_topics)
        response  = retriever.search("Q-001", query_vec, top_k=10)
    """

    def __init__(
        self,
        index_type:   IndexType = IndexType.IVF_PQ,
        n_clusters:   int = 256,      # IVF: number of Voronoi cells (nlist)
        n_probe:      int = 32,       # IVF: cells to visit at query time
        m_pq:         int = 96,       # PQ: number of sub-quantizers (bytes/vec)
        bits_pq:      int = 8,        # PQ: bits per sub-quantizer (256 centroids)
        hnsw_m:       int = 32,       # HNSW: number of neighbours per node
        hnsw_ef:      int = 64,       # HNSW: ef_construction
        dim:          int = 384,      # embedding dimension
    ) -> None:
        self.index_type = index_type
        self.n_clusters = n_clusters
        self.n_probe    = n_probe
        self.m_pq       = m_pq
        self.bits_pq    = bits_pq
        self.hnsw_m     = hnsw_m
        self.hnsw_ef    = hnsw_ef
        self.dim        = dim

        self._index         = None      # faiss.Index
        self._doc_ids:    list[str] = []
        self._doc_titles: list[str] = []
        self._doc_topics: list[str] = []
        self._build_time_s: float   = 0.0
        self._n_docs:       int     = 0

    # ------------------------------------------------------------------
    # TODO (Task 7): Implement _build_ivfflat()
    # ------------------------------------------------------------------

    def _build_ivfflat(self, embeddings: np.ndarray) -> "faiss.Index":
        """
        Build an IVFFlat index.

        Algorithm:
          1. Create quantizer = faiss.IndexFlatL2(self.dim)
          2. index = faiss.IndexIVFFlat(quantizer, self.dim, self.n_clusters,
                                        faiss.METRIC_INNER_PRODUCT)
          3. index.train(embeddings)
          4. index.add(embeddings)
          5. index.nprobe = self.n_probe
          6. return index

        Note: embeddings must be float32 and L2-normalised for inner product
              to equal cosine similarity.

        Raises:
            NotImplementedError: until implemented.
        """
        raise NotImplementedError(
            "TODO Task 7: implement _build_ivfflat()\n"
            "  import faiss\n"
            "  quantizer = faiss.IndexFlatL2(self.dim)\n"
            "  index = faiss.IndexIVFFlat(quantizer, self.dim, self.n_clusters,\n"
            "                              faiss.METRIC_INNER_PRODUCT)\n"
            "  index.train(embeddings)\n"
            "  index.add(embeddings)\n"
            "  index.nprobe = self.n_probe\n"
            "  return index"
        )

    # ------------------------------------------------------------------
    # TODO (Task 8): Implement _build_hnsw()
    # ------------------------------------------------------------------

    def _build_hnsw(self, embeddings: np.ndarray) -> "faiss.Index":
        """
        Build an HNSW (Hierarchical Navigable Small World) index.

        HNSW stores extra graph connectivity data — memory usage is HIGHER
        than flat, making it unsuitable for the 10M / 16 GB constraint.
        Students should observe this in the scale projection table.

        Algorithm:
          1. index = faiss.IndexHNSWFlat(self.dim, self.hnsw_m,
                                          faiss.METRIC_INNER_PRODUCT)
          2. index.hnsw.efConstruction = self.hnsw_ef
          3. index.add(embeddings)        # HNSW does not need .train()
          4. return index

        Raises:
            NotImplementedError: until implemented.
        """
        raise NotImplementedError(
            "TODO Task 8: implement _build_hnsw()\n"
            "  import faiss\n"
            "  index = faiss.IndexHNSWFlat(self.dim, self.hnsw_m,\n"
            "                               faiss.METRIC_INNER_PRODUCT)\n"
            "  index.hnsw.efConstruction = self.hnsw_ef\n"
            "  index.add(embeddings)\n"
            "  return index"
        )

    # ------------------------------------------------------------------
    # TODO (Task 9): Implement _build_ivfpq()  <-- KEY TASK
    # ------------------------------------------------------------------

    def _build_ivfpq(self, embeddings: np.ndarray) -> "faiss.Index":
        """
        Build an IVF-PQ (Inverted File with Product Quantization) index.

        This is the RECOMMENDED index for the 10M-document deployment scenario.

        Product Quantization compresses each 384-dim float32 vector (1536 bytes)
        into m_pq bytes (default: 96 bytes), achieving 16x compression:
          - Memory: 10M x 96 bytes = ~0.9 GB  << 16 GB RAM limit  OK
          - Latency: ~5-15 ms on CPU           << 50 ms SLA        OK
          - Recall@10: ~85-90%                (acceptable for clinical search)

        Algorithm:
          1. Create quantizer = faiss.IndexFlatL2(self.dim)
          2. index = faiss.IndexIVFPQ(
                 quantizer, self.dim,
                 self.n_clusters,   # nlist (number of Voronoi cells)
                 self.m_pq,         # M (sub-quantizers = bytes per vector)
                 self.bits_pq,      # nbits per sub-quantizer (8 -> 256 centroids)
             )
          3. index.train(embeddings)   # must train before adding
          4. index.add(embeddings)
          5. index.nprobe = self.n_probe
          6. return index

        Key insight: m_pq determines bytes per vector.
          384 dims / 96 sub-quantizers = 4 dims per sub-vector  (typical: 4-8)
          m_pq must evenly divide self.dim.

        Raises:
            NotImplementedError: until implemented.
        """
        raise NotImplementedError(
            "TODO Task 9: implement _build_ivfpq()  <-- KEY TASK\n"
            "  import faiss\n"
            "  quantizer = faiss.IndexFlatL2(self.dim)\n"
            "  index = faiss.IndexIVFPQ(\n"
            "      quantizer, self.dim,\n"
            "      self.n_clusters,   # nlist\n"
            "      self.m_pq,         # M bytes per vector\n"
            "      self.bits_pq,      # 8 -> 256 centroids per sub-quantizer\n"
            "  )\n"
            "  index.train(embeddings)\n"
            "  index.add(embeddings)\n"
            "  index.nprobe = self.n_probe\n"
            "  return index\n"
            "\n"
            "  Memory formula: n_docs * self.m_pq bytes\n"
            "  Compression ratio vs flat: (dim * 4) / m_pq = 384*4/96 = 16x"
        )

    # ------------------------------------------------------------------
    # fit() — dispatches to the correct builder
    # ------------------------------------------------------------------

    def fit(
        self,
        embeddings:  np.ndarray,
        doc_ids:     list[str],
        doc_titles:  list[str],
        doc_topics:  list[str],
    ) -> None:
        """
        Build FAISS index from pre-computed L2-normalised embeddings.

        Args:
            embeddings: float32 array of shape (N, dim).
            doc_ids:    list of document IDs (length N).
            doc_titles: list of document titles.
            doc_topics: list of ground-truth topic labels.
        """
        import faiss  # noqa: F401 (ensure installed)

        assert embeddings.dtype == np.float32, "embeddings must be float32"
        assert embeddings.shape[1] == self.dim, \
            f"embeddings dim {embeddings.shape[1]} != expected {self.dim}"

        self._doc_ids    = doc_ids
        self._doc_titles = doc_titles
        self._doc_topics = doc_topics
        self._n_docs     = len(doc_ids)

        t0 = time.perf_counter()

        if self.index_type == IndexType.IVF_FLAT:
            self._index = self._build_ivfflat(embeddings)
        elif self.index_type == IndexType.HNSW:
            self._index = self._build_hnsw(embeddings)
        elif self.index_type == IndexType.IVF_PQ:
            self._index = self._build_ivfpq(embeddings)
        else:
            raise ValueError(f"Unknown index type: {self.index_type}")

        self._build_time_s = time.perf_counter() - t0
        print(f"{self.index_type.value} index built in {self._build_time_s:.2f}s "
              f"for {self._n_docs:,} docs")

    def search_vector(
        self,
        query_id:   str,
        query_text: str,
        query_vec:  np.ndarray,
        top_k:      int = 10,
    ) -> RetrievalResponse:
        """
        Search using a pre-computed query vector.

        Args:
            query_id:   identifier string.
            query_text: raw text (for response object).
            query_vec:  1D float32 array of shape (dim,).
            top_k:      number of results.

        Returns:
            RetrievalResponse.
        """
        if self._index is None:
            raise RuntimeError("Call fit() before search_vector()")

        q = query_vec.reshape(1, -1).astype(np.float32)
        t0 = time.perf_counter()
        distances, indices = self._index.search(q, top_k)
        elapsed = (time.perf_counter() - t0) * 1000

        results = []
        for rank, (dist, idx) in enumerate(zip(distances[0], indices[0]), start=1):
            if idx < 0:  # FAISS returns -1 for unfilled slots
                continue
            results.append(SearchResult(
                rank=rank,
                doc_id=self._doc_ids[idx],
                score=float(dist),
                topic=self._doc_topics[idx],
                title=self._doc_titles[idx],
                retrieval_method=RetrievalMethod.SBERT,
            ))

        return RetrievalResponse(
            query_id=query_id,
            original_query=query_text,
            results=results,
            retrieval_method=RetrievalMethod.SBERT,
            latency_ms=elapsed,
            n_results=len(results),
        )

    def benchmark(self, test_vectors: np.ndarray) -> IndexBenchmark:
        """
        Measure query latency and approximate memory usage.

        Args:
            test_vectors: float32 array of shape (N_queries, dim).

        Returns:
            IndexBenchmark (Pydantic validated).
        """
        if self._index is None:
            raise RuntimeError("Call fit() first")

        import faiss
        latencies = []
        for vec in test_vectors:
            t0 = time.perf_counter()
            self._index.search(vec.reshape(1, -1), 10)
            latencies.append((time.perf_counter() - t0) * 1000)

        # Approximate index size via serialization
        try:
            buf = faiss.serialize_index(self._index)
            mem_mb = len(buf) / (1024 ** 2)
        except Exception:
            mem_mb = self._n_docs * self.m_pq / (1024 ** 2) if hasattr(self, 'm_pq') else 0.0

        return IndexBenchmark(
            index_type=self.index_type,
            n_docs=self._n_docs,
            d_dim=self.dim,
            build_time_s=round(self._build_time_s, 3),
            query_time_ms=round(float(np.mean(latencies)), 3),
            memory_mb=round(mem_mb, 2),
        )


# ---------------------------------------------------------------------------
# Scale Analyser
# ---------------------------------------------------------------------------

class ScaleAnalyser:
    """
    Projects memory and latency to 10 million documents and validates against
    the hospital deployment constraints:
      - 16 GB RAM
      - < 50 ms per query on CPU

    Student Task 10: Implement project() to fill the projection table and
    produce Pydantic-validated ScaleProjection objects.
    """

    # Approximate bytes-per-vector for each index type at 384 dimensions
    # Students should verify / update these after running benchmarks.
    BYTES_PER_VECTOR: dict[IndexType, int] = {
        IndexType.FLAT:     384 * 4,    # 1536 bytes  (dense float32)
        IndexType.IVF_FLAT: 384 * 4,    # same as flat (+ small IVF overhead)
        IndexType.HNSW:     384 * 4 + 32 * 4 * 2,  # ~1792 bytes (graph links)
        IndexType.IVF_PQ:   96,         # 96 bytes (default m_pq=96)
    }

    # Approximate milliseconds per query at 10M docs on a 4-core CPU
    # These are empirically estimated; students should measure and update.
    MS_PER_QUERY_10M: dict[IndexType, float] = {
        IndexType.FLAT:     250.0,
        IndexType.IVF_FLAT: 30.0,
        IndexType.HNSW:     4.0,
        IndexType.IVF_PQ:   12.0,
    }

    def __init__(self, n_docs: int = 10_000_000) -> None:
        self.n_docs = n_docs

    # ------------------------------------------------------------------
    # TODO (Task 10): Implement project()
    # ------------------------------------------------------------------

    def project(self) -> list[ScaleProjection]:
        """
        For each index type, compute projected memory and latency at self.n_docs,
        then build a Pydantic-validated ScaleProjection.

        Algorithm for each index_type:
          bytes_total  = self.n_docs * self.BYTES_PER_VECTOR[index_type]
          memory_gb    = bytes_total / (1024**3)
          latency_ms   = self.MS_PER_QUERY_10M[index_type]
          fits_ram     = memory_gb <= 16.0
          meets_sla    = latency_ms <= 50.0
          recommended  = fits_ram AND meets_sla

        Returns:
            list[ScaleProjection] — one entry per IndexType, sorted by memory_gb.

        Raises:
            NotImplementedError: until implemented.
        """
        raise NotImplementedError(
            "TODO Task 10: implement ScaleAnalyser.project()\n"
            "  For each index_type in IndexType:\n"
            "    bytes_total = self.n_docs * self.BYTES_PER_VECTOR[index_type]\n"
            "    memory_gb   = bytes_total / (1024**3)\n"
            "    latency_ms  = self.MS_PER_QUERY_10M[index_type]\n"
            "    fits_ram    = memory_gb <= 16.0\n"
            "    meets_sla   = latency_ms <= 50.0\n"
            "    recommended = fits_ram and meets_sla\n"
            "    compression = BYTES_PER_VECTOR[FLAT] / BYTES_PER_VECTOR[index_type]\n"
            "  Return list[ScaleProjection] sorted by memory_gb ascending"
        )

    def print_table(self, projections: list[ScaleProjection]) -> None:
        """Pretty-print the scale projection table."""
        print(f"\n{'='*75}")
        print(f"  Scale Projection: {self.n_docs:,} documents")
        print(f"  Constraints: RAM <= 16 GB, Latency <= 50 ms on CPU")
        print(f"{'='*75}")
        print(f"  {'Index':<12} {'Memory':>10} {'Latency':>10} {'RAM OK':>8} {'SLA OK':>8} {'Compress':>10} {'Rec':>5}")
        print("  " + "-" * 65)
        for p in projections:
            compress = f"{p.compression_ratio:.0f}x" if p.compression_ratio else "1x"
            print(
                f"  {p.index_type.value:<12} "
                f"{p.projected_memory_gb:>8.1f}GB "
                f"{p.projected_latency_ms:>9.0f}ms "
                f"{'YES' if p.fits_in_16gb_ram else 'NO':>8} "
                f"{'YES' if p.meets_50ms_sla else 'NO':>8} "
                f"{compress:>10} "
                f"{'***' if p.recommended else '':>5}"
            )
        print()
        recommended = [p for p in projections if p.recommended]
        if recommended:
            print(f"  RECOMMENDATION: {recommended[0].index_type.value.upper()}")
            if recommended[0].recommendation_reason:
                print(f"  {recommended[0].recommendation_reason}")


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=== Scale Projection ===")
    analyser = ScaleAnalyser()
    try:
        projections = analyser.project()
        analyser.print_table(projections)
    except NotImplementedError:
        print("(project() not yet implemented — Task 10)")
        print("\nExpected output preview:")
        print("  Index        Memory   Latency   RAM OK  SLA OK  Compress   Rec")
        print("  flat         14.4GB    250ms       NO      NO        1x      ")
        print("  ivfflat      14.4GB     30ms       NO     YES        1x      ")
        print("  hnsw         17.5GB      4ms       NO     YES      0.9x      ")
        print("  ivfpq         0.9GB     12ms      YES     YES       16x    ***")
