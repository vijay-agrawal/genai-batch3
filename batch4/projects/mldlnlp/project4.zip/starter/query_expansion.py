"""
Query Expansion — Medical Ontology
===================================
Maps lay / colloquial medical vocabulary to formal clinical terminology.

The vocabulary mismatch problem:
  A healthcare rep searches: "heart attack treatment aspirin antiplatelet"
  The most relevant document says: "myocardial infarction antiplatelet therapy clopidogrel"

  TF-IDF / BM25 will score this document POORLY because:
    "heart attack" does not appear in the document
    "aspirin" appears but only in passing
  The similarity score is dominated by shared stop-words, not clinical concepts.

Query expansion is a lightweight pre-processing step that:
  1. Scans the query for known lay terms
  2. Adds their clinical synonyms to the query
  3. Downstream retrieval operates on the enriched query

This module provides:
  - MEDICAL_ONTOLOGY  : dict mapping informal terms -> list[clinical synonyms]
  - QueryExpander     : class wrapping expansion logic with Pydantic-validated output

Student Tasks:
  Task 1 (Task 1 in main):  Extend MEDICAL_ONTOLOGY with >= 15 new term mappings
  Task 2:                   Implement QueryExpander.expand()
  Task 3:                   Implement _score_expansion_quality() for ablation study
"""

from __future__ import annotations

import re
from typing import Optional

from schemas import QueryExpansion

# ---------------------------------------------------------------------------
# Medical Ontology  (UMLS / SNOMED-CT inspired — simplified for teaching)
# ---------------------------------------------------------------------------

MEDICAL_ONTOLOGY: dict[str, list[str]] = {
    # Cardiovascular
    "heart attack":         ["myocardial infarction", "STEMI", "NSTEMI",
                              "acute coronary syndrome"],
    "mini heart attack":    ["NSTEMI", "non-ST-elevation myocardial infarction",
                              "unstable angina"],
    "blocked artery":       ["coronary artery occlusion", "coronary stenosis",
                              "atherosclerotic plaque"],
    "clot busting":         ["thrombolysis", "fibrinolytic therapy", "alteplase",
                              "tenecteplase"],
    "chest pain":           ["angina", "angina pectoris", "precordial pain",
                              "substernal discomfort"],
    "widowmaker":           ["left anterior descending artery occlusion",
                              "LAD occlusion", "anterior STEMI"],
    "stent":                ["percutaneous coronary intervention", "PCI",
                              "coronary stent", "drug-eluting stent"],

    # Anticoagulation
    "blood thinner":        ["anticoagulant", "anticoagulation", "warfarin",
                              "heparin", "low molecular weight heparin",
                              "direct oral anticoagulant"],
    "blood clot":           ["thrombosis", "thrombus", "venous thromboembolism",
                              "deep vein thrombosis", "pulmonary embolism"],
    "blood clot leg":       ["deep vein thrombosis", "DVT", "venous thrombosis"],
    "clot lung":            ["pulmonary embolism", "pulmonary thromboembolism"],
    "new blood thinner":    ["direct oral anticoagulant", "DOAC", "NOAC",
                              "rivaroxaban", "apixaban", "dabigatran"],
    "rat poison pill":      ["warfarin", "vitamin K antagonist"],

    # Heart failure
    "water pill":           ["diuretic", "loop diuretic", "furosemide",
                              "bumetanide", "thiazide"],
    "fluid pill":           ["diuretic", "loop diuretic", "furosemide"],
    "weak heart":           ["heart failure", "reduced ejection fraction",
                              "left ventricular systolic dysfunction"],
    "breathless flat":      ["orthopnoea", "paroxysmal nocturnal dyspnoea"],
    "shock device":         ["implantable cardioverter-defibrillator", "ICD",
                              "cardiac resynchronisation therapy"],
    "drowning in fluid":    ["pulmonary oedema", "acute decompensated heart failure",
                              "congestive heart failure"],

    # Diabetes
    "high blood sugar":     ["hyperglycaemia", "type 2 diabetes mellitus",
                              "elevated plasma glucose"],
    "sugar diabetes":       ["type 2 diabetes mellitus", "diabetes mellitus",
                              "hyperglycaemia"],
    "low blood sugar":      ["hypoglycaemia", "hypoglycemic episode"],
    "hypo":                 ["hypoglycaemia", "hypoglycemic episode"],
    "slimming jab":         ["GLP-1 receptor agonist", "semaglutide", "liraglutide",
                              "weight reduction injection"],
    "diabetes injection":   ["GLP-1 receptor agonist", "insulin", "semaglutide",
                              "liraglutide"],
    "sugar tablet":         ["metformin", "oral hypoglycaemic agent",
                              "antidiabetic medication"],
    "sugar test three months": ["HbA1c", "glycated haemoglobin",
                                "three-month blood glucose average"],
    "sugar sensor":         ["continuous glucose monitor", "CGM", "flash glucose monitor"],
    "insulin pump":         ["continuous subcutaneous insulin infusion", "CSII"],

    # Hypertension
    "high blood pressure":  ["hypertension", "arterial hypertension",
                              "elevated blood pressure"],
    "blood pressure tablet": ["antihypertensive", "antihypertensive agent",
                               "ACE inhibitor", "ARB", "calcium channel blocker"],
    "white coat":           ["white-coat hypertension", "white-coat effect",
                              "office hypertension"],

    # Stroke
    "brain attack":         ["ischaemic stroke", "cerebrovascular accident",
                              "acute stroke"],
    "mini stroke":          ["transient ischaemic attack", "TIA"],
    "brain clot":           ["ischaemic stroke", "cerebral thrombosis",
                              "middle cerebral artery occlusion"],
    "brain bleed":          ["intracranial haemorrhage", "intracerebral haemorrhage",
                              "haemorrhagic stroke"],
    "stroke clot removal":  ["mechanical thrombectomy", "endovascular thrombectomy",
                              "intra-arterial thrombolysis"],
    "face drooping":        ["facial palsy", "facial droop", "FAST symptoms"],

    # Sepsis / infection
    "blood poisoning":      ["sepsis", "septicaemia", "bacteraemia"],
    "septic shock":         ["sepsis-induced hypotension", "septic shock",
                              "vasopressor-dependent sepsis"],
    "blood pressure crash": ["septic shock", "haemodynamic instability",
                              "vasodilatory shock"],
    "infection marker":     ["C-reactive protein", "CRP", "procalcitonin",
                              "white cell count"],
    "white cells":          ["white blood cell count", "leukocyte count",
                              "neutrophilia", "leucocytosis"],
    "lactic acid":          ["lactate", "serum lactate", "hyperlactataemia"],
    "drip antibiotics":     ["intravenous antibiotics", "IV antimicrobial therapy",
                              "parenteral antibiotics"],

    # Respiratory
    "puffer":               ["inhaler", "bronchodilator", "short-acting beta-agonist",
                              "salbutamol"],
    "reliever inhaler":     ["short-acting beta-agonist", "SABA", "salbutamol",
                              "rescue inhaler"],
    "home oxygen":          ["long-term oxygen therapy", "LTOT",
                              "supplemental oxygen"],
    "lung scarring":        ["pulmonary fibrosis", "interstitial lung disease",
                              "idiopathic pulmonary fibrosis"],
    "stiff lungs":          ["restrictive lung disease", "pulmonary fibrosis",
                              "decreased lung compliance"],
    "sleep apnea mask":     ["CPAP", "continuous positive airway pressure",
                              "non-invasive ventilation"],

    # Renal
    "kidney failure":       ["renal failure", "acute kidney injury",
                              "chronic kidney disease", "end-stage renal disease"],
    "kidney washout":       ["haemodialysis", "renal replacement therapy",
                              "peritoneal dialysis"],
    "kidney number":        ["serum creatinine", "estimated GFR",
                              "glomerular filtration rate"],
    "contrast dye kidney":  ["contrast-induced nephropathy",
                              "contrast-induced acute kidney injury"],
    "foamy urine":          ["proteinuria", "nephrotic syndrome",
                              "heavy proteinuria"],
    "protein urine":        ["proteinuria", "albuminuria", "nephrotic range proteinuria"],
    "kidney anaemia":       ["anaemia of chronic kidney disease",
                              "renal anaemia", "erythropoietin deficiency"],
    "tired kidney":         ["chronic kidney disease", "renal insufficiency"],

    # Drug interactions
    "blood thinner antibiotic": ["anticoagulant-antibiotic interaction",
                                  "warfarin potentiation", "INR increase"],
    "grapefruit medication":    ["cytochrome P450 3A4 inhibition",
                                  "CYP3A4 inhibitor", "grapefruit-drug interaction"],
    "cholesterol tablet muscle pain": ["statin myopathy", "statin-induced myalgia",
                                        "rhabdomyolysis"],
    "antidepressant interaction":     ["serotonin syndrome", "SSRI interaction",
                                       "monoamine oxidase inhibitor interaction"],
    "serotonin overload":             ["serotonin syndrome", "serotonin toxicity"],
    "painkiller blood thinner":       ["NSAID anticoagulant interaction",
                                       "aspirin warfarin interaction",
                                       "ibuprofen anticoagulant"],
    "herbal supplement interaction":  ["St John's Wort interaction",
                                       "CYP induction", "herb-drug interaction"],

    # TODO (Task 1 — Student): Add >= 15 more mappings from lay terms
    # you discover while analysing the query test set.
    # Example:
    # "sugar eye":   ["diabetic retinopathy", "macular oedema", "fundoscopy"],
    # "sugar foot":  ["diabetic foot ulcer", "diabetic neuropathy", "peripheral vascular disease"],
}


# ---------------------------------------------------------------------------
# QueryExpander
# ---------------------------------------------------------------------------

class QueryExpander:
    """
    Expands medical queries using MEDICAL_ONTOLOGY synonym lookup.

    Usage:
        expander = QueryExpander()
        result   = expander.expand("heart attack treatment aspirin")
        # result.expansion_query contains original + clinical synonyms
    """

    def __init__(
        self,
        ontology:      dict[str, list[str]] | None = None,
        max_synonyms:  int = 4,
        deduplicate:   bool = True,
    ) -> None:
        self.ontology     = ontology or MEDICAL_ONTOLOGY
        self.max_synonyms = max_synonyms
        self.deduplicate  = deduplicate

        # Pre-compile sorted patterns (longest-first to avoid partial matches)
        self._sorted_keys = sorted(self.ontology.keys(), key=len, reverse=True)

    # ------------------------------------------------------------------
    # TODO (Task 2):  Implement expand()
    # ------------------------------------------------------------------

    def expand(self, query: str) -> QueryExpansion:
        """
        Expand the query by appending clinical synonyms for recognised lay terms.

        Algorithm:
          1. Lowercase the query.
          2. Iterate over self._sorted_keys (longest first).
          3. If a key is found in the query, record an ontology hit and collect
             up to self.max_synonyms clinical synonyms.
          4. Deduplicate added terms (if self.deduplicate=True).
          5. Build expansion_query = original_query + " " + " ".join(expanded_terms)
          6. Return a QueryExpansion (Pydantic model).

        Args:
            query: raw user query string.

        Returns:
            QueryExpansion with original, expanded terms, and combined query.

        Raises:
            NotImplementedError: until implemented.
        """
        raise NotImplementedError(
            "TODO Task 2: implement QueryExpander.expand()\n"
            "Steps:\n"
            "  1. Scan query (lowercased) for keys in self._sorted_keys\n"
            "  2. For each match, record in ontology_hits dict\n"
            "  3. Collect synonyms (up to self.max_synonyms per match)\n"
            "  4. Deduplicate expanded_terms\n"
            "  5. expansion_query = original_query + ' ' + ' '.join(expanded_terms)\n"
            "  6. Return QueryExpansion(...)"
        )

    # ------------------------------------------------------------------
    # TODO (Task 3):  Implement _score_expansion_quality()
    # ------------------------------------------------------------------

    def score_expansion_quality(
        self,
        expansion: QueryExpansion,
        corpus_vocab: set[str],
    ) -> dict[str, float]:
        """
        Measure how many of the expanded terms actually appear in the corpus.

        This tells us whether expansion added useful terms or noise.

        Args:
            expansion:    A QueryExpansion result from expand().
            corpus_vocab: Set of unique tokens present in the document corpus.

        Returns:
            dict with:
              "coverage"       : fraction of expanded_terms in corpus_vocab
              "n_terms_in_corpus" : count
              "n_terms_not_found" : count

        Raises:
            NotImplementedError: until implemented.
        """
        raise NotImplementedError(
            "TODO Task 3: implement score_expansion_quality()\n"
            "  coverage = sum(t.lower() in corpus_vocab for t in expansion.expanded_terms)\n"
            "             / max(1, len(expansion.expanded_terms))"
        )

    # ------------------------------------------------------------------
    # Provided helper: check if a query contains any known lay terms
    # ------------------------------------------------------------------

    def detect_lay_terms(self, query: str) -> list[str]:
        """Return list of ontology keys found in the query (lay terms detected)."""
        q_lower = query.lower()
        found = []
        for key in self._sorted_keys:
            if re.search(r'\b' + re.escape(key) + r'\b', q_lower):
                found.append(key)
        return found

    def summary(self) -> None:
        """Print a summary of the ontology."""
        print(f"Medical ontology: {len(self.ontology)} lay-term entries")
        total_synonyms = sum(len(v) for v in self.ontology.values())
        print(f"Total synonyms  : {total_synonyms}")
        avg = total_synonyms / max(1, len(self.ontology))
        print(f"Avg synonyms/term: {avg:.1f}")


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    expander = QueryExpander()
    expander.summary()
    print()

    demo_queries = [
        "heart attack treatment aspirin antiplatelet",
        "water pill swollen ankles fluid retention",
        "brain bleed anticoagulation stop restart",
        "blood poisoning signs ICU drip antibiotics",
        "sugar diabetes HbA1c target elderly patient",
    ]

    for q in demo_queries:
        lay = expander.detect_lay_terms(q)
        print(f"Query : {q}")
        print(f"  Lay terms detected: {lay}")
        print(f"  (run expand() once Task 2 is implemented)")
        print()
