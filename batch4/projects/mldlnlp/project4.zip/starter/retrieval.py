"""
Sparse Retrieval Baselines — TF-IDF and BM25
=============================================
These are the "before" side of the vocabulary-mismatch comparison.

Both methods rely on LEXICAL overlap between query and documents.
They will score poorly on queries like:
  "heart attack treatment aspirin"
against documents containing only:
  "myocardial infarction antiplatelet therapy clopidogrel"

Student Tasks:
  Task 4a: Confirm the vocabulary mismatch is real — run the baseline and
           look at which relevant documents are missed (MRR < 0.2 expected).
  Task 4b: Run again with QueryExpander applied — observe MRR improvement.
"""

from __future__ import annotations

import time
from typing import Optional

import numpy as np
import pandas as pd
from rank_bm25 import BM25Okapi
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from schemas import RetrievalMethod, RetrievalResponse, SearchResult


# ---------------------------------------------------------------------------
# TF-IDF Retriever
# ---------------------------------------------------------------------------

class TFIDFRetriever:
    """
    Classic TF-IDF cosine similarity retrieval.

    Strengths  : fast, no GPU, interpretable
    Weaknesses : vocabulary mismatch (exact token overlap required)
    """

    def __init__(
        self,
        max_features:    int = 30_000,
        ngram_range:     tuple[int, int] = (1, 2),
        sublinear_tf:    bool = True,
    ) -> None:
        self.vectorizer = TfidfVectorizer(
            max_features=max_features,
            ngram_range=ngram_range,
            sublinear_tf=sublinear_tf,
            stop_words="english",
        )
        self._doc_matrix  = None
        self._doc_ids:    list[str]  = []
        self._doc_titles: list[str]  = []
        self._doc_topics: list[str]  = []
        self._fitted      = False

    def fit(self, docs: pd.DataFrame) -> None:
        """
        Build TF-IDF matrix.

        Args:
            docs: DataFrame with columns [doc_id, full_text, title, topic].
        """
        self._doc_ids    = docs["doc_id"].tolist()
        self._doc_titles = docs["title"].tolist()
        self._doc_topics = docs["topic"].tolist() if "topic" in docs.columns else [""] * len(docs)
        self._doc_matrix = self.vectorizer.fit_transform(docs["full_text"].fillna(""))
        self._fitted     = True
        print(f"TF-IDF index built: {self._doc_matrix.shape[0]} docs, "
              f"{self._doc_matrix.shape[1]} features")

    def search(
        self,
        query_id:   str,
        query:      str,
        top_k:      int = 10,
    ) -> RetrievalResponse:
        if not self._fitted:
            raise RuntimeError("Call fit() before search()")

        t0       = time.perf_counter()
        q_vec    = self.vectorizer.transform([query])
        scores   = cosine_similarity(q_vec, self._doc_matrix)[0]
        top_idx  = np.argsort(scores)[::-1][:top_k]
        elapsed  = (time.perf_counter() - t0) * 1000

        results = [
            SearchResult(
                rank=rank + 1,
                doc_id=self._doc_ids[i],
                score=float(scores[i]),
                topic=self._doc_topics[i],
                title=self._doc_titles[i],
                retrieval_method=RetrievalMethod.TFIDF,
            )
            for rank, i in enumerate(top_idx)
        ]

        return RetrievalResponse(
            query_id=query_id,
            original_query=query,
            results=results,
            retrieval_method=RetrievalMethod.TFIDF,
            latency_ms=elapsed,
            n_results=len(results),
        )

    @property
    def vocab_size(self) -> int:
        return len(self.vectorizer.vocabulary_) if self._fitted else 0


# ---------------------------------------------------------------------------
# BM25 Retriever
# ---------------------------------------------------------------------------

class BM25Retriever:
    """
    BM25 (Okapi BM25) — improved term-frequency-based retrieval.

    BM25 addresses TF saturation and document length normalisation,
    but still requires LEXICAL overlap — no semantic understanding.

    Strengths  : better than TF-IDF for long documents; standard baseline in IR
    Weaknesses : vocabulary mismatch equally severe as TF-IDF
    """

    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        self.k1   = k1
        self.b    = b
        self._bm25: Optional[BM25Okapi] = None
        self._doc_ids:    list[str] = []
        self._doc_titles: list[str] = []
        self._doc_topics: list[str] = []

    def fit(self, docs: pd.DataFrame) -> None:
        self._doc_ids    = docs["doc_id"].tolist()
        self._doc_titles = docs["title"].tolist()
        self._doc_topics = docs["topic"].tolist() if "topic" in docs.columns else [""] * len(docs)

        tokenised = [
            text.lower().split()
            for text in docs["full_text"].fillna("")
        ]
        self._bm25 = BM25Okapi(tokenised, k1=self.k1, b=self.b)
        print(f"BM25 index built: {len(docs)} docs")

    def search(
        self,
        query_id: str,
        query:    str,
        top_k:    int = 10,
    ) -> RetrievalResponse:
        if self._bm25 is None:
            raise RuntimeError("Call fit() before search()")

        t0      = time.perf_counter()
        tokens  = query.lower().split()
        scores  = self._bm25.get_scores(tokens)
        top_idx = np.argsort(scores)[::-1][:top_k]
        elapsed = (time.perf_counter() - t0) * 1000

        results = [
            SearchResult(
                rank=rank + 1,
                doc_id=self._doc_ids[i],
                score=float(scores[i]),
                topic=self._doc_topics[i],
                title=self._doc_titles[i],
                retrieval_method=RetrievalMethod.BM25,
            )
            for rank, i in enumerate(top_idx)
        ]

        return RetrievalResponse(
            query_id=query_id,
            original_query=query,
            results=results,
            retrieval_method=RetrievalMethod.BM25,
            latency_ms=elapsed,
            n_results=len(results),
        )


# ---------------------------------------------------------------------------
# Vocabulary overlap analysis (provided — use in Task 4a)
# ---------------------------------------------------------------------------

def analyse_vocabulary_mismatch(
    corpus_df: pd.DataFrame,
    queries_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    For each query, compute the fraction of query tokens present in the
    corpus vocabulary and in the relevant documents specifically.

    Returns a DataFrame with per-query mismatch statistics.
    """
    corpus_vocab: set[str] = set()
    for text in corpus_df["full_text"].fillna(""):
        for tok in text.lower().split():
            corpus_vocab.add(tok.strip(".,;:()[]"))

    rows = []
    for _, qrow in queries_df.iterrows():
        q_tokens    = qrow["query_text"].lower().split()
        q_tokens    = [t.strip(".,;:()[]") for t in q_tokens]
        n_overlap   = sum(1 for t in q_tokens if t in corpus_vocab)
        lay_terms   = [t.strip() for t in str(qrow.get("lay_terms", "")).split(";") if t.strip()]
        n_lay_in_corpus = sum(
            1 for term in lay_terms
            if any(w in corpus_vocab for w in term.lower().split())
        )
        rows.append({
            "query_id":         qrow["query_id"],
            "query_text":       qrow["query_text"],
            "n_query_tokens":   len(q_tokens),
            "n_overlap_corpus": n_overlap,
            "overlap_pct":      round(100 * n_overlap / max(1, len(q_tokens)), 1),
            "n_lay_terms":      len(lay_terms),
            "lay_terms_in_corpus": n_lay_in_corpus,
            "lay_mismatch_pct": round(100 * (1 - n_lay_in_corpus / max(1, len(lay_terms))), 1),
        })

    df = pd.DataFrame(rows)
    print(f"\nVocabulary mismatch analysis ({len(df)} queries):")
    print(f"  Avg query-corpus token overlap : {df['overlap_pct'].mean():.1f}%")
    print(f"  Queries where lay term absent  : "
          f"{(df['lay_mismatch_pct'] == 100).sum()} / {len(df)}")
    return df


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent))

    data_dir = Path(__file__).parent.parent / "data"
    corpus_path = data_dir / "clinical_corpus.csv"
    query_path  = data_dir / "query_testset.csv"

    if not corpus_path.exists():
        print("Run: python data/generate_dataset.py first")
        sys.exit(1)

    corpus_df = pd.read_csv(corpus_path)
    query_df  = pd.read_csv(query_path)

    print(f"Corpus: {len(corpus_df)} docs | Queries: {len(query_df)}")

    # Vocabulary mismatch analysis
    mismatch_df = analyse_vocabulary_mismatch(corpus_df, query_df)
    print(mismatch_df[["query_id", "query_text", "overlap_pct", "lay_mismatch_pct"]].head(10).to_string())

    # Quick retrieval demo
    tfidf = TFIDFRetriever()
    tfidf.fit(corpus_df)

    demo_query = "heart attack treatment aspirin antiplatelet"
    resp = tfidf.search("Q-000", demo_query, top_k=5)
    print(f"\nTF-IDF top-5 for: '{demo_query}'")
    for r in resp.results:
        print(f"  Rank {r.rank}: [{r.topic}] {r.title[:60]}  score={r.score:.4f}")

    print("\nNote: clinical synonyms (myocardial infarction, STEMI) likely NOT in top results.")
    print("This is the vocabulary mismatch problem.")
