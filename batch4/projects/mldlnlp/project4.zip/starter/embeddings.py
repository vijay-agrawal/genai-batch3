"""
Dense Retrieval — SBERT Embeddings + Cosine Similarity
=======================================================
Transforms texts to 384-dimensional dense vectors using sentence-transformers.
Similarity is measured by cosine distance in embedding space.

Unlike TF-IDF / BM25, SBERT embeddings capture SEMANTIC meaning:
  "heart attack" -> embedding close to "myocardial infarction"
  "blood thinner" -> embedding close to "anticoagulant"

This file contains:
  - EmbeddingEncoder : wraps sentence-transformers for batch encoding
  - DenseRetriever   : exact cosine search over encoded corpus
                       (no FAISS index — brute force for small corpora)

Student Tasks:
  Task 5: Implement EmbeddingEncoder.encode() using sentence-transformers
  Task 6: Implement DenseRetriever.search() using cosine similarity

For efficient approximate search at scale, see faiss_index.py.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from schemas import RetrievalMethod, RetrievalResponse, SearchResult


# ---------------------------------------------------------------------------
# Embedding Encoder
# ---------------------------------------------------------------------------

class EmbeddingEncoder:
    """
    Sentence-level encoder using sentence-transformers.

    Default model: 'all-MiniLM-L6-v2'  (384-dim, fast, strong baseline)
    Medical model: 'pritamdeka/S-PubMedBert-MS-MARCO'  (better for clinical text)

    Memory:
      2000 documents x 384 dims x 4 bytes (float32) = ~3 MB  (manageable)
      10M  documents x 384 dims x 4 bytes (float32) = ~14.4 GB  (exceeds 16 GB RAM!)
      -> For 10M docs, use IVF-PQ compression (see faiss_index.py)
    """

    EMBEDDING_DIM = 384

    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        batch_size: int = 64,
        device:     str = "cpu",
        cache_dir:  Optional[Path] = None,
    ) -> None:
        self.model_name = model_name
        self.batch_size = batch_size
        self.device     = device
        self.cache_dir  = cache_dir
        self._model     = None

    def _load_model(self) -> None:
        """Lazy-load the sentence transformer model."""
        if self._model is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
            print(f"Loading SBERT model: {self.model_name} ...")
            kwargs = {}
            if self.cache_dir:
                kwargs["cache_folder"] = str(self.cache_dir)
            self._model = SentenceTransformer(self.model_name, device=self.device, **kwargs)
            print(f"  Embedding dim: {self._model.get_sentence_embedding_dimension()}")
        except ImportError:
            raise ImportError("pip install sentence-transformers")

    # ------------------------------------------------------------------
    # TODO (Task 5): Implement encode()
    # ------------------------------------------------------------------

    def encode(
        self,
        texts:           list[str],
        show_progress:   bool = True,
        normalize:       bool = True,
    ) -> np.ndarray:
        """
        Encode a list of texts into L2-normalised dense vectors.

        Args:
            texts:         list of strings to encode.
            show_progress: show tqdm progress bar.
            normalize:     if True, L2-normalise each vector so that cosine
                           similarity == dot product.  Set True for retrieval.

        Returns:
            np.ndarray of shape (len(texts), embedding_dim), dtype float32.

        Raises:
            NotImplementedError: until implemented.

        Hint:
            self._load_model()
            embeddings = self._model.encode(
                texts,
                batch_size=self.batch_size,
                show_progress_bar=show_progress,
                normalize_embeddings=normalize,
                convert_to_numpy=True,
            )
        """
        raise NotImplementedError(
            "TODO Task 5: implement EmbeddingEncoder.encode()\n"
            "  1. Call self._load_model()\n"
            "  2. Call self._model.encode(..., normalize_embeddings=normalize)\n"
            "  3. Return numpy array of shape (len(texts), 384)"
        )

    def encode_single(self, text: str, normalize: bool = True) -> np.ndarray:
        """Convenience wrapper for a single text string."""
        return self.encode([text], show_progress=False, normalize=normalize)[0]

    @property
    def dim(self) -> int:
        return self.EMBEDDING_DIM


# ---------------------------------------------------------------------------
# Dense Retriever (brute-force exact cosine search)
# ---------------------------------------------------------------------------

class DenseRetriever:
    """
    Exact cosine similarity retrieval over a precomputed embedding matrix.

    For corpora up to ~50 000 documents this is fast enough on CPU.
    For larger corpora, use FAISSRetriever in faiss_index.py.
    """

    def __init__(self, encoder: EmbeddingEncoder) -> None:
        self.encoder      = encoder
        self._doc_matrix: Optional[np.ndarray] = None    # (N, D) float32
        self._doc_ids:    list[str]             = []
        self._doc_titles: list[str]             = []
        self._doc_topics: list[str]             = []
        self._fitted      = False

    def fit(self, docs: pd.DataFrame, cache_path: Optional[Path] = None) -> None:
        """
        Encode all documents and store the embedding matrix.

        Args:
            docs:        DataFrame with [doc_id, full_text, title, topic].
            cache_path:  if given, save/load embeddings from this .npy file.
        """
        self._doc_ids    = docs["doc_id"].tolist()
        self._doc_titles = docs["title"].tolist()
        self._doc_topics = docs["topic"].tolist() if "topic" in docs.columns else [""] * len(docs)

        if cache_path and cache_path.exists():
            print(f"Loading cached embeddings from {cache_path} ...")
            self._doc_matrix = np.load(str(cache_path))
        else:
            print(f"Encoding {len(docs)} documents with SBERT ...")
            texts = docs["full_text"].fillna("").tolist()
            self._doc_matrix = self.encoder.encode(texts, show_progress=True)
            if cache_path:
                np.save(str(cache_path), self._doc_matrix)
                print(f"Embeddings cached -> {cache_path}")

        print(f"Dense index ready: {self._doc_matrix.shape}")
        self._fitted = True

    # ------------------------------------------------------------------
    # TODO (Task 6): Implement search()
    # ------------------------------------------------------------------

    def search(
        self,
        query_id:  str,
        query:     str,
        top_k:     int = 10,
    ) -> RetrievalResponse:
        """
        Retrieve top-k documents by cosine similarity to the query embedding.

        Since embeddings are L2-normalised (normalize=True in encode()),
        cosine similarity == dot product:
            scores = self._doc_matrix @ query_vec   (shape: N,)

        Args:
            query_id:   identifier for this query (for the response object)
            query:      raw query text
            top_k:      number of results to return

        Returns:
            RetrievalResponse validated by Pydantic schema.

        Raises:
            NotImplementedError: until implemented.

        Algorithm:
          1. Check self._fitted.
          2. Encode query: q_vec = self.encoder.encode_single(query)  shape: (D,)
          3. Compute scores = self._doc_matrix @ q_vec                shape: (N,)
          4. top_idx = np.argsort(scores)[::-1][:top_k]
          5. Build list[SearchResult] with rank, doc_id, score, topic, title
          6. Wrap in RetrievalResponse and return.
        """
        raise NotImplementedError(
            "TODO Task 6: implement DenseRetriever.search()\n"
            "  q_vec = self.encoder.encode_single(query)\n"
            "  scores = self._doc_matrix @ q_vec\n"
            "  top_idx = np.argsort(scores)[::-1][:top_k]\n"
            "  Build SearchResult list and return RetrievalResponse"
        )

    @property
    def memory_mb(self) -> float:
        """Approximate memory used by the embedding matrix."""
        if self._doc_matrix is None:
            return 0.0
        return self._doc_matrix.nbytes / (1024 ** 2)


# ---------------------------------------------------------------------------
# Memory calculator (provided — useful for Task 10 scale analysis)
# ---------------------------------------------------------------------------

def estimate_embedding_memory(
    n_docs:       int,
    embedding_dim: int = 384,
    dtype:         str = "float32",
    compression:   Optional[str] = None,
) -> dict[str, float]:
    """
    Calculate memory required for embedding matrix at different scales.

    Args:
        n_docs:         Number of documents.
        embedding_dim:  Embedding dimensionality (default: 384 for MiniLM).
        dtype:          'float32' (4 bytes) or 'float16' (2 bytes).
        compression:    None | 'pq96'  (IVF-PQ with 96 bytes/vector)

    Returns:
        dict with 'bytes', 'mb', 'gb'

    Example:
        >>> estimate_embedding_memory(10_000_000)
        10M docs x 384 dims x 4 bytes = 14.4 GB  -> exceeds 16 GB RAM!
        >>> estimate_embedding_memory(10_000_000, compression='pq96')
        10M docs x 96 bytes = 0.9 GB  -> fits easily!
    """
    bytes_per_val = 4 if dtype == "float32" else 2

    if compression == "pq96":
        # IVF-PQ with M=96 sub-quantizers, 8 bits each: 96 bytes/vector
        total_bytes = n_docs * 96
        method      = "IVF-PQ (96 bytes/vec)"
    elif compression == "pq48":
        total_bytes = n_docs * 48
        method      = "IVF-PQ (48 bytes/vec)"
    else:
        total_bytes = n_docs * embedding_dim * bytes_per_val
        method      = f"Dense {dtype}"

    result = {
        "n_docs":      n_docs,
        "method":      method,
        "bytes":       total_bytes,
        "mb":          total_bytes / (1024 ** 2),
        "gb":          total_bytes / (1024 ** 3),
    }
    print(f"{method}: {n_docs:,} docs -> {result['gb']:.2f} GB")
    return result


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=== Memory scale analysis ===")
    for n in [2_000, 100_000, 1_000_000, 10_000_000]:
        estimate_embedding_memory(n)
    print()
    for n in [1_000_000, 10_000_000]:
        estimate_embedding_memory(n, compression="pq96")

    print("\n=== SBERT encoding demo (requires Task 5 implementation) ===")
    encoder = EmbeddingEncoder()
    queries = [
        "heart attack treatment aspirin",
        "myocardial infarction antiplatelet therapy",
        "blood poisoning ICU antibiotics",
    ]
    try:
        vecs = encoder.encode(queries, show_progress=False)
        # Cosine similarities between pairs
        for i in range(len(queries)):
            for j in range(i + 1, len(queries)):
                sim = float(np.dot(vecs[i], vecs[j]))
                print(f"  sim(q{i}, q{j}) = {sim:.3f}")
                print(f"    '{queries[i][:40]}'")
                print(f"    '{queries[j][:40]}'")
    except NotImplementedError:
        print("  (encode() not yet implemented — Task 5)")
