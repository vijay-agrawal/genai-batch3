"""
Multi-Stage Retrieval Pipeline
================================
Combines query expansion, sparse first-stage retrieval, and dense re-ranking
into a single callable pipeline.

Architecture:
  Stage 1: Query Expansion
    - Map lay terms -> clinical synonyms using MEDICAL_ONTOLOGY
    - Produces enriched query for Stage 2

  Stage 2: BM25 Candidate Retrieval  (fast, sparse)
    - Retrieve top-100 candidates using expanded query
    - Cheap: ~1-5 ms on CPU

  Stage 3: SBERT Re-ranking  (accurate, dense)
    - Re-score top-100 candidates with cosine similarity
    - Expensive: ~10-30 ms on CPU
    - Returns top-K final results

This pattern (cheap recall stage + expensive precision stage) is the standard
approach for production retrieval systems at any scale.

Why not just use SBERT directly on all 10M documents?
  - 10M x 384 x 4 bytes = 14.4 GB flat matrix (exceeds RAM)
  - With FAISS IVF-PQ: feasible, but add FAISS module for that path
  - Two-stage: keep BM25 extremely fast for first-pass filtering

Student Tasks:
  Task 11: Implement MultiStagePipeline.retrieve()
  Task 12: Ablation study — compare:
           Baseline (BM25 no expansion) vs
           BM25+Expansion vs
           Dense (SBERT no expansion) vs
           MultiStage (Expansion + BM25 + SBERT rerank)
"""

from __future__ import annotations

import time
from typing import Optional

import numpy as np
import pandas as pd

from embeddings import DenseRetriever, EmbeddingEncoder
from query_expansion import QueryExpander
from retrieval import BM25Retriever
from schemas import RetrievalMethod, RetrievalResponse, SearchResult


# ---------------------------------------------------------------------------
# Multi-Stage Pipeline
# ---------------------------------------------------------------------------

class MultiStagePipeline:
    """
    Three-stage retrieval: Expansion -> BM25 candidates -> SBERT re-rank.

    Args:
        expander:       QueryExpander instance (can be None to skip expansion).
        bm25:           Fitted BM25Retriever for first-stage candidate recall.
        encoder:        EmbeddingEncoder for dense re-ranking.
        candidate_k:    Number of candidates from BM25 (default: 100).
        final_k:        Number of final results after SBERT re-rank (default: 10).
    """

    def __init__(
        self,
        expander:    Optional[QueryExpander],
        bm25:        BM25Retriever,
        encoder:     EmbeddingEncoder,
        candidate_k: int = 100,
        final_k:     int = 10,
    ) -> None:
        self.expander    = expander
        self.bm25        = bm25
        self.encoder     = encoder
        self.candidate_k = candidate_k
        self.final_k     = final_k

        # Cache: doc_id -> (full_text, title, topic)
        self._doc_lookup: dict[str, dict] = {}

    def index_corpus(self, corpus_df: pd.DataFrame) -> None:
        """
        Build BM25 index and doc lookup table from corpus DataFrame.

        Args:
            corpus_df: DataFrame with [doc_id, full_text, title, topic].
        """
        self.bm25.fit(corpus_df)
        for _, row in corpus_df.iterrows():
            self._doc_lookup[row["doc_id"]] = {
                "full_text": str(row.get("full_text", "")),
                "title":     str(row.get("title", "")),
                "topic":     str(row.get("topic", "")),
            }
        print(f"Pipeline corpus indexed: {len(self._doc_lookup)} docs")

    # ------------------------------------------------------------------
    # TODO (Task 11): Implement retrieve()
    # ------------------------------------------------------------------

    def retrieve(
        self,
        query_id:  str,
        query:     str,
        top_k:     Optional[int] = None,
    ) -> RetrievalResponse:
        """
        Run the full multi-stage pipeline for a single query.

        Algorithm:
          Step 1 — Query Expansion (if self.expander is not None):
              expansion = self.expander.expand(query)
              search_query = expansion.expansion_query
          else:
              search_query = query
              expansion    = None

          Step 2 — BM25 candidate retrieval:
              candidates = self.bm25.search(query_id, search_query,
                                             top_k=self.candidate_k)
              candidate_doc_ids = [r.doc_id for r in candidates.results]

          Step 3 — SBERT re-ranking:
              a. Collect the full_text of each candidate doc from self._doc_lookup
              b. Encode candidate texts:
                     doc_vecs = self.encoder.encode(candidate_texts,
                                                    show_progress=False)
              c. Encode query (use original query for semantic search):
                     q_vec = self.encoder.encode_single(query)
              d. Compute cosine scores = doc_vecs @ q_vec
              e. Sort by score descending, keep top self.final_k

          Step 4 — Build and return RetrievalResponse with:
              query_id         = query_id
              original_query   = query
              expansion        = expansion (from step 1)
              results          = top-k SearchResult list (rank 1..k)
              retrieval_method = RetrievalMethod.MULTISTAGE
              latency_ms       = total elapsed time

        Args:
            query_id: identifier string.
            query:    raw user query (lay language).
            top_k:    override final number of results (default: self.final_k).

        Returns:
            RetrievalResponse validated by Pydantic.

        Raises:
            NotImplementedError: until implemented.
        """
        raise NotImplementedError(
            "TODO Task 11: implement MultiStagePipeline.retrieve()\n"
            "\n"
            "Steps:\n"
            "  1. Expand query with self.expander (if not None)\n"
            "  2. BM25 search using expanded query -> self.candidate_k results\n"
            "  3. Encode candidate docs with self.encoder\n"
            "  4. Encode original query with self.encoder.encode_single()\n"
            "  5. Re-score: scores = doc_vecs @ q_vec\n"
            "  6. Sort top_k candidates by score\n"
            "  7. Return RetrievalResponse with method=MULTISTAGE\n"
            "\n"
            "Note: use the ORIGINAL query (not expanded) for SBERT encoding.\n"
            "SBERT already understands semantics; expansion is only for BM25."
        )


# ---------------------------------------------------------------------------
# Ablation runner (provided — students call this after implementing Tasks)
# ---------------------------------------------------------------------------

def run_ablation(
    corpus_df:    pd.DataFrame,
    queries_df:   pd.DataFrame,
    top_k:        int = 10,
    verbose:      bool = True,
) -> pd.DataFrame:
    """
    Run four retrieval conditions on all test queries and compute MRR@K.

    Conditions:
      A. BM25 only (no expansion)       <- vocabulary mismatch baseline
      B. BM25 + query expansion         <- shows value of expansion
      C. SBERT dense (no expansion)     <- semantic retrieval
      D. MultiStage (exp + BM25 + SBERT) <- full pipeline

    For ground truth, a result is marked relevant if its topic matches
    any of the query's relevant_topics.

    Args:
        corpus_df:  clinical_corpus.csv as DataFrame.
        queries_df: query_testset.csv as DataFrame.
        top_k:      evaluation cutoff.

    Returns:
        DataFrame with MRR@K and Recall@K for each condition.
    """
    from evaluate import mrr_at_k, recall_at_k

    # ---- Setup ----
    bm25_plain  = BM25Retriever()
    bm25_plain.fit(corpus_df)

    bm25_exp    = BM25Retriever()
    bm25_exp.fit(corpus_df)
    expander    = QueryExpander()

    encoder     = EmbeddingEncoder()
    dense       = DenseRetriever(encoder)

    try:
        dense.fit(corpus_df)
        dense_available = True
    except NotImplementedError:
        dense_available = False
        if verbose:
            print("SBERT encode() not implemented (Task 5) — skipping dense conditions")

    pipeline    = MultiStagePipeline(expander, bm25_exp, encoder, candidate_k=100)
    pipeline.index_corpus(corpus_df)

    # ---- Evaluate ----
    results = {"condition": [], "mrr_at_k": [], "recall_at_k": []}

    def _evaluate_condition(responses, condition_name):
        mrr_scores, rec_scores = [], []
        for resp, (_, qrow) in zip(responses, queries_df.iterrows()):
            relevant_topics = set(qrow["relevant_topics"].split("; "))
            relevance = [
                1 if (r.topic in relevant_topics) else 0
                for r in resp.results
            ]
            mrr_scores.append(mrr_at_k(relevance, top_k))
            rec_scores.append(recall_at_k(relevance, top_k))
        results["condition"].append(condition_name)
        results["mrr_at_k"].append(round(float(np.mean(mrr_scores)), 4))
        results["recall_at_k"].append(round(float(np.mean(rec_scores)), 4))
        if verbose:
            print(f"  {condition_name:<35} MRR@{top_k}={results['mrr_at_k'][-1]:.4f}  "
                  f"Recall@{top_k}={results['recall_at_k'][-1]:.4f}")

    if verbose:
        print(f"\nAblation study (top_k={top_k}):")

    # Condition A — BM25 only
    responses_a = [
        bm25_plain.search(row["query_id"], row["query_text"], top_k=top_k)
        for _, row in queries_df.iterrows()
    ]
    _evaluate_condition(responses_a, "A. BM25 (no expansion)")

    # Condition B — BM25 + expansion
    try:
        responses_b = []
        for _, row in queries_df.iterrows():
            exp = expander.expand(row["query_text"])
            resp = bm25_exp.search(row["query_id"], exp.expansion_query, top_k=top_k)
            responses_b.append(resp)
        _evaluate_condition(responses_b, "B. BM25 + expansion")
    except NotImplementedError:
        if verbose:
            print("  B. BM25 + expansion   (skipped — Task 2 not implemented)")

    # Condition C — SBERT dense
    if dense_available:
        responses_c = [
            dense.search(row["query_id"], row["query_text"], top_k=top_k)
            for _, row in queries_df.iterrows()
        ]
        _evaluate_condition(responses_c, "C. SBERT dense")
    else:
        if verbose:
            print("  C. SBERT dense        (skipped — Task 5/6 not implemented)")

    # Condition D — MultiStage
    try:
        responses_d = [
            pipeline.retrieve(row["query_id"], row["query_text"])
            for _, row in queries_df.iterrows()
        ]
        _evaluate_condition(responses_d, "D. MultiStage (full pipeline)")
    except NotImplementedError:
        if verbose:
            print("  D. MultiStage         (skipped — Task 11 not implemented)")

    return pd.DataFrame(results)


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent))

    data_dir   = Path(__file__).parent.parent / "data"
    corpus_path = data_dir / "clinical_corpus.csv"
    query_path  = data_dir / "query_testset.csv"

    if not corpus_path.exists():
        print("Run: python data/generate_dataset.py first")
        sys.exit(1)

    corpus_df = pd.read_csv(corpus_path)
    query_df  = pd.read_csv(query_path)

    ablation_df = run_ablation(corpus_df, query_df, top_k=10)
    print("\nAblation summary:")
    print(ablation_df.to_string(index=False))
