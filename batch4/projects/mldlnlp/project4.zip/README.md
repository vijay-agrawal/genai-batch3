# Mini-Project 4: Semantic Search & Information Retrieval at Scale

## The Problem

A healthcare representative searches:

> *"heart attack treatment aspirin antiplatelet"*

The most relevant clinical guideline says:

> *"Dual antiplatelet therapy following myocardial infarction: management of STEMI with clopidogrel and ticagrelor"*

A TF-IDF or BM25 system scores this document **poorly** because none of the key lay terms — *heart attack*, *aspirin* — appear in the document's formal medical language.

This is the **vocabulary mismatch problem**: the user's language and the document's language describe the same concept but share few tokens.

**The same problem appears throughout healthcare:**

| User query (lay language) | Document terminology (clinical) |
|---|---|
| "heart attack" | myocardial infarction, STEMI, NSTEMI |
| "blood thinner" | anticoagulant, warfarin, heparin |
| "water pill" | diuretic, furosemide, loop diuretic |
| "sugar diabetes" | type 2 diabetes mellitus, hyperglycaemia |
| "brain bleed" | intracranial haemorrhage |
| "blood poisoning" | sepsis, bacteraemia |

---

## Three Complementary Solutions

### Solution 1: Query Expansion (lightweight, interpretable)
Map lay terms to clinical synonyms using a medical ontology before retrieval.
- Adds "myocardial infarction" to the query "heart attack"
- Works for known vocabulary mismatches
- Zero latency overhead, fully deterministic

### Solution 2: Dense Retrieval (semantic, general)
Encode both queries and documents as dense vectors using SBERT sentence embeddings.
- "heart attack" embedding is geometrically close to "myocardial infarction" in vector space
- Handles novel vocabulary mismatches not in the ontology
- Requires a pre-built embedding index

### Solution 3: Multi-Stage Pipeline (production-grade)
Combine both: expand the query, retrieve 100 BM25 candidates, re-rank with SBERT.
- Stage 1 (cheap): BM25 on expanded query — fast first-pass recall
- Stage 2 (accurate): SBERT re-ranking of 100 candidates — precise top-10

---

## Scale Constraint

You are building for a hospital with **10 million clinical notes** on a **CPU-only server with 16 GB RAM** and a **latency SLA of < 50 ms per query**.

| Index | Memory @10M docs | Query latency | Acceptable? |
|---|---|---|---|
| Dense flat | 14.4 GB | ~250 ms | NO (RAM + speed) |
| IVFFlat | ~14.4 GB | ~30 ms | NO (RAM) |
| HNSW | ~17.5 GB | ~4 ms | NO (RAM) |
| **IVF-PQ** | **~0.9 GB** | **~12 ms** | **YES** |

**IVF-PQ** (Inverted File + Product Quantization) compresses each 384-dim float32 vector (1536 bytes) to 96 bytes — a **16× compression** — while retaining ~85–90% recall.

---

## Directory Structure

```
project4/
├── README.md
├── rubric.md
├── requirements.txt
├── data/
│   ├── generate_dataset.py
│   ├── clinical_corpus.csv      (2000 clinical documents)
│   └── query_testset.csv        (100 queries + ground truth)
└── starter/
    ├── schemas.py               DO NOT MODIFY
    ├── query_expansion.py       Tasks 1, 2, 3
    ├── retrieval.py             Task 4 (baselines — mostly provided)
    ├── embeddings.py            Tasks 5, 6
    ├── faiss_index.py           Tasks 7, 8, 9, 10
    ├── pipeline.py              Task 11
    ├── evaluate.py              (provided)
    └── main.py                  orchestration
```

---

## Quick Start

```bash
pip install -r requirements.txt

# Generate datasets
python data/generate_dataset.py

# Run sparse baselines (no GPU needed)
python starter/main.py --part A

# Run all parts
python starter/main.py --part all

# Run with SBERT on GPU
python starter/main.py --part all --device cuda
```

---

## Student Tasks (11 TODOs)

| Task | File | What to implement |
|---|---|---|
| **1** | `query_expansion.py` | Extend `MEDICAL_ONTOLOGY` with ≥15 new lay-term mappings |
| **2** | `query_expansion.py` | `QueryExpander.expand()` — synonym injection |
| **3** | `query_expansion.py` | `score_expansion_quality()` — corpus coverage check |
| **4a** | `retrieval.py` | Run baseline + confirm vocabulary mismatch in output |
| **4b** | `retrieval.py` | Re-run with expansion, observe MRR improvement |
| **5** | `embeddings.py` | `EmbeddingEncoder.encode()` — SBERT batch encoding |
| **6** | `embeddings.py` | `DenseRetriever.search()` — cosine similarity search |
| **7** | `faiss_index.py` | `FAISSRetriever._build_ivfflat()` |
| **8** | `faiss_index.py` | `FAISSRetriever._build_hnsw()` |
| **9** | `faiss_index.py` | `FAISSRetriever._build_ivfpq()` — **key task** |
| **10** | `faiss_index.py` | `ScaleAnalyser.project()` — 10M doc projection table |
| **11** | `pipeline.py` | `MultiStagePipeline.retrieve()` — full 3-stage pipeline |

---

## Core Concepts

### Vocabulary Mismatch

```
Query tokens:     {heart, attack, treatment, aspirin, antiplatelet}
Document tokens:  {myocardial, infarction, antiplatelet, therapy, clopidogrel}

Overlap:          {antiplatelet}  <- only 1 shared token
TF-IDF score:     LOW  (document ranked #180 out of 2000)

After expansion:  {heart, attack, myocardial, infarction, STEMI, ...}
New overlap:      {myocardial, infarction, antiplatelet}
BM25+exp score:   HIGHER (document ranked #8)

SBERT embedding:  cos("heart attack", "myocardial infarction") = 0.82
SBERT score:      HIGH  (document ranked #2)
```

### Product Quantization (IVF-PQ)

```
Original vector:  384 dims x float32 = 1536 bytes

PQ compression:
  Split 384-dim vector into M=96 sub-vectors of 4 dims each.
  For each sub-vector, find nearest centroid from 256 options.
  Store centroid index (1 byte) instead of 4 floats.

Compressed:       96 x 1 byte = 96 bytes
Compression ratio: 1536 / 96 = 16x

At 10M documents:
  Dense:  10M x 1536 bytes = 14.4 GB  <- EXCEEDS 16 GB RAM
  IVF-PQ: 10M x  96 bytes  =  0.9 GB  <- FITS  in 16 GB RAM

Recall loss:  ~10-15% (acceptable for most clinical IR use cases)
```

### FAISS Index Types

```
Flat (brute force)
  Every query vector compared to every document.
  Exact: 100% recall, but O(N) per query.

IVFFlat
  Corpus partitioned into nlist=256 Voronoi cells.
  Query searches nprobe=32 closest cells only.
  ~95% recall, ~8x faster than flat.
  Memory: same as flat (~15 GB for 10M docs).

HNSW
  Graph-based: each node linked to M=32 neighbours.
  ~98% recall, very fast (~4 ms).
  Memory: float32 vectors + graph edges = ~18 GB for 10M docs.
  Exceeds 16 GB RAM.

IVF-PQ  (RECOMMENDED)
  IVF partitioning + product quantization.
  ~85-90% recall, ~12 ms, 0.9 GB for 10M docs.
  Only index type meeting BOTH constraints.
```

---

## Experiments to Run

### Experiment 1: Vocabulary Mismatch Quantification
Run `analyse_vocabulary_mismatch()`.
- What % of lay terms in queries have 0% overlap with clinical corpus?
- Expected: >60% of lay terms absent from corpus vocabulary.

### Experiment 2: Ablation Study
Run `run_ablation()` with conditions:
- A: BM25 only
- B: BM25 + query expansion
- C: SBERT dense
- D: Multi-stage pipeline

Expected ranking: D > C ≥ B > A  
Expected MRR improvement A->D: from ~0.15 to ~0.65+

### Experiment 3: FAISS Index Benchmarks
For a 2000-document corpus:
- Build IVFFlat, HNSW, IVF-PQ
- Measure build time, query latency, memory
- Compare to the 10M scale projections

### Experiment 4: Scale Projection
Complete `ScaleAnalyser.project()`.
- Which index fits 16 GB RAM at 10M docs?
- Which meets 50 ms SLA?
- Only IVF-PQ satisfies BOTH constraints.

---

## Output Format

### RetrievalResponse (Pydantic-validated JSON)

```json
{
  "query_id": "Q-000",
  "original_query": "heart attack treatment aspirin antiplatelet",
  "expansion": {
    "original_query": "heart attack treatment aspirin antiplatelet",
    "expanded_terms": ["myocardial infarction", "STEMI", "NSTEMI",
                       "acute coronary syndrome", "antiplatelet therapy"],
    "expansion_query": "heart attack treatment aspirin antiplatelet myocardial infarction STEMI ...",
    "n_terms_added": 5,
    "ontology_hits": {"heart attack": ["myocardial infarction", "STEMI", ...]}
  },
  "results": [
    {"rank": 1, "doc_id": "DOC-00042", "score": 0.847,
     "topic": "acute_coronary_syndrome",
     "title": "Dual antiplatelet therapy following STEMI",
     "retrieval_method": "multistage", "is_relevant": true},
    ...
  ],
  "retrieval_method": "multistage",
  "latency_ms": 18.4,
  "n_results": 10
}
```

### ScaleProjection (Pydantic-validated JSON)

```json
{
  "index_type": "ivfpq",
  "n_docs_projected": 10000000,
  "projected_memory_gb": 0.9,
  "projected_latency_ms": 12.0,
  "fits_in_16gb_ram": true,
  "meets_50ms_sla": true,
  "compression_ratio": 16.0,
  "recommended": true,
  "recommendation_reason": "Only index satisfying both 16 GB RAM and 50 ms SLA."
}
```

---

## Clinical Safety Note

> **Is this system acceptable at point-of-care?**

**Generally NO, in isolation.** Missing a single critical drug-interaction guideline is clinically unacceptable. A Recall@10 of 0.85 means 15% of critical documents are missed.

Mitigating recommendations *(suggest in report — do NOT implement)*:

1. **Human-in-the-loop**: Clinical pharmacist review before acting on results
2. **Safety filter layer**: Separate rule-based system for known high-risk drug pairs
3. **Tune for recall**: Maximise Recall@K at the cost of Precision — missing one guideline is worse than reviewing ten
4. **Alert on low confidence**: Show warning when max_score < threshold, escalate to expert
5. **Domain fine-tuning**: Fine-tune SBERT on clinical QA datasets (BioASQ, MedQA)
6. **Adversarial red-teaming**: Systematic testing for dangerous missed retrievals

---

## Report Structure (≤ 5 pages)

1. **Vocabulary mismatch analysis** — quantify the overlap gap; show the mismatch table.
2. **Query expansion** — which lay terms benefited most; ontology coverage analysis.
3. **Retrieval comparison** — ablation table: MRR@10 for all four conditions; explain gaps.
4. **FAISS index analysis** — latency / memory tradeoffs; justify IVF-PQ recommendation.
5. **Scale deployment** — 10M doc projection table; clinical safety discussion.

---

## Grading

See [rubric.md](rubric.md) — 100 points + up to 10 bonus.
