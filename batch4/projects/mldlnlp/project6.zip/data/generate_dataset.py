"""
Generate synthetic FAQ and test-query datasets for Project 6.

Run:
    python data/generate_dataset.py

Outputs:
    data/faqs.csv           — 60 FAQs across 6 categories
    data/test_queries.csv   — 120 test queries (easy / hard / out_of_scope)
"""

import csv
import random
import os

random.seed(42)

# ---------------------------------------------------------------------------
# 60 FAQs  — 10 per category
# ---------------------------------------------------------------------------

FAQS = [
    # ── appointments ────────────────────────────────────────────────────────
    ("FAQ-001", "appointments", "How do I book a new appointment?",
     "Call our scheduling line at 555-0100 (Mon–Fri, 8am–6pm) or log into "
     "the patient portal at portal.citygeneral.org and click 'New Appointment'."),

    ("FAQ-002", "appointments", "How do I cancel or reschedule an appointment?",
     "Cancellations and reschedules require at least 24 hours' notice. "
     "Call 555-0100 or use the portal. Late cancellations may incur a $25 fee."),

    ("FAQ-003", "appointments", "Do I need a referral to see a specialist?",
     "Most insurance plans require a referral from your primary-care physician "
     "before a specialist visit. Check with your insurer — some plans allow "
     "direct specialist access."),

    ("FAQ-004", "appointments", "How early should I arrive for my appointment?",
     "Please arrive 15 minutes early to complete any paperwork. "
     "For surgical procedures, please arrive 60 minutes early."),

    ("FAQ-005", "appointments", "Can I book a same-day appointment?",
     "Same-day slots are occasionally available for urgent but non-emergency "
     "concerns. Call 555-0100 as early as possible — slots are released at 8am."),

    ("FAQ-006", "appointments", "What happens if I miss my appointment?",
     "Missed appointments without 24-hour notice are subject to a $25 "
     "no-show fee. After three missed appointments your scheduling privileges "
     "may be reviewed."),

    ("FAQ-007", "appointments", "Can I request a specific doctor?",
     "Yes — when booking, state your preferred physician. We cannot guarantee "
     "availability, but we will do our best to accommodate your request."),

    ("FAQ-008", "appointments", "How do I prepare for a routine check-up?",
     "Bring your insurance card, a photo ID, and a list of current medications. "
     "Avoid eating or drinking (other than water) for two hours beforehand "
     "if blood tests are likely."),

    ("FAQ-009", "appointments", "Are telehealth appointments available?",
     "Yes. Video consultations are available for many follow-up and "
     "non-emergency visits. Book through the portal and select 'Virtual Visit'. "
     "You will need a device with a camera and microphone."),

    ("FAQ-010", "appointments", "Can a family member attend my appointment?",
     "One support person may accompany you. Please inform reception on arrival. "
     "Children under 16 must be accompanied by a guardian at all times."),

    # ── billing ─────────────────────────────────────────────────────────────
    ("FAQ-011", "billing", "How do I pay my hospital bill?",
     "Pay online at billing.citygeneral.org, by phone at 555-0200, "
     "by mail (cheque payable to City General Hospital), or in person at "
     "the cashier on Level 1."),

    ("FAQ-012", "billing", "What insurance plans do you accept?",
     "We accept most major plans including BlueCross, Aetna, UnitedHealth, "
     "Cigna, and Medicare/Medicaid. Call 555-0201 to verify your specific plan "
     "before your visit."),

    ("FAQ-013", "billing", "Can I set up a payment plan?",
     "Yes. Patients facing financial hardship can apply for an interest-free "
     "instalment plan. Contact our financial counsellors at 555-0202 "
     "or visit the Billing office on Level 1."),

    ("FAQ-014", "billing", "I received a bill I don't understand — who do I call?",
     "Call our billing helpline at 555-0200 (Mon–Fri, 8am–5pm) or email "
     "billing@citygeneral.org. Please have your account number ready."),

    ("FAQ-015", "billing", "What is the co-pay for an outpatient visit?",
     "Co-pays vary by insurance plan, typically $20–$50 for a GP visit "
     "and $40–$100 for a specialist. Contact your insurer for your exact amount."),

    ("FAQ-016", "billing", "Do you offer financial assistance for uninsured patients?",
     "Yes. Our financial assistance programme can reduce or waive charges "
     "based on household income. Ask at the admissions desk or call 555-0202."),

    ("FAQ-017", "billing", "Why did I receive two separate bills?",
     "You may receive separate bills for the facility fee and the physician fee. "
     "This is standard practice — the hospital and the doctor may bill independently."),

    ("FAQ-018", "billing", "How long do I have to pay my bill?",
     "Payment is due within 30 days of the invoice date. After 60 days "
     "a late fee may be applied. After 90 days the account may be sent "
     "to a collections agency."),

    ("FAQ-019", "billing", "Can I get an itemised bill?",
     "Yes. Request an itemised statement online, by calling 555-0200, "
     "or in writing. We are required by law to provide one within 30 days."),

    ("FAQ-020", "billing", "Will I be billed if my appointment is cancelled by the hospital?",
     "No. If we cancel or reschedule your appointment you will not be charged "
     "any cancellation or no-show fee."),

    # ── medications ─────────────────────────────────────────────────────────
    ("FAQ-021", "medications", "How do I request a prescription refill?",
     "Contact your prescribing physician via the patient portal, "
     "or call the pharmacy at 555-0300. Allow 3–5 business days for processing."),

    ("FAQ-022", "medications", "Can I get a 90-day supply of my medication?",
     "Yes, for maintenance medications (taken long-term). Your doctor must "
     "authorise a 90-day supply. Mail-order pharmacy options are also available."),

    ("FAQ-023", "medications", "What should I do if I miss a dose?",
     "Take it as soon as you remember unless it is almost time for the next dose. "
     "Never double-dose. If unsure, call our pharmacy helpline at 555-0301."),

    ("FAQ-024", "medications", "Can I bring my own medications from home during a hospital stay?",
     "Inform nursing staff of all medications you take. In most cases "
     "the hospital will dispense equivalents from our pharmacy. "
     "Bring original bottles for identification."),

    ("FAQ-025", "medications", "Are generic medications available?",
     "Yes. Generic equivalents are available for most branded drugs and are "
     "therapeutically identical. Ask your pharmacist about switching to save on cost."),

    ("FAQ-026", "medications", "How are medications affected by food or drink?",
     "Some drugs must be taken with food, others on an empty stomach. "
     "Your prescription label will specify. Ask the pharmacist if you are unsure."),

    ("FAQ-027", "medications", "What is a medication reconciliation?",
     "Medication reconciliation is the process of reviewing all drugs a patient "
     "takes (prescribed, OTC, supplements) to avoid harmful interactions. "
     "It is done at every admission, transfer, and discharge."),

    ("FAQ-028", "medications", "Can I get my prescription filled at any pharmacy?",
     "Yes. Ask your doctor for a written or electronic prescription. "
     "Our on-site pharmacy is on Level 0; we also transmit e-prescriptions "
     "to most external pharmacies."),

    ("FAQ-029", "medications", "Who should I contact about a drug allergy or reaction?",
     "Report any suspected drug reaction to nursing staff or your doctor "
     "immediately. In an emergency call 911. Update your allergy list in "
     "the patient portal after the event."),

    ("FAQ-030", "medications", "How do I safely dispose of unused medications?",
     "Use the medication drop-box in our Level 0 pharmacy lobby. "
     "Do not flush medications or put them in household rubbish — "
     "many can harm the environment."),

    # ── test_results ────────────────────────────────────────────────────────
    ("FAQ-031", "test_results", "How long does it take to get blood test results?",
     "Routine blood panels are available within 24–48 hours. "
     "Some specialised tests take 5–7 business days. "
     "Results appear in your patient portal when ready."),

    ("FAQ-032", "test_results", "Where can I view my test results?",
     "Log in to the patient portal at portal.citygeneral.org. "
     "Results are released as soon as your doctor has reviewed them."),

    ("FAQ-033", "test_results", "Can my doctor explain my test results to me?",
     "Yes. Book a follow-up appointment or use the portal messaging feature "
     "to ask your doctor to explain the findings."),

    ("FAQ-034", "test_results", "Why haven't I received my results yet?",
     "Some tests take longer due to specialised analysis. "
     "If your results are more than 7 days late, call 555-0400 "
     "or message your care team via the portal."),

    ("FAQ-035", "test_results", "Are my test results shared with anyone?",
     "Results are shared only with your care team and anyone you authorise "
     "in your privacy settings. We do not share results with employers "
     "or insurers without your written consent."),

    ("FAQ-036", "test_results", "How do I request copies of my test results?",
     "Download them from the patient portal, or submit a Medical Records "
     "request form (in-person or online). A small fee may apply for printed copies."),

    ("FAQ-037", "test_results", "What is a normal range and why is mine flagged?",
     "Normal ranges are statistical averages; a result slightly outside "
     "the range is not always clinically significant. Your doctor will "
     "interpret the result in the context of your full history."),

    ("FAQ-038", "test_results", "I received an abnormal result — what should I do?",
     "Don't panic. Many abnormal flags are mild. Contact your doctor "
     "within 48 hours to discuss next steps. If you experience symptoms, "
     "call 555-0100 for an urgent appointment."),

    ("FAQ-039", "test_results", "Can I request a repeat test?",
     "Yes. Ask your doctor if a repeat is clinically indicated. "
     "Self-requested repeats are generally not covered by insurance "
     "without a medical reason."),

    ("FAQ-040", "test_results", "How do I understand my radiology report?",
     "Radiology reports use technical language. Your referring physician "
     "will explain the findings. You can also ask for a plain-language "
     "summary during your follow-up appointment."),

    # ── visiting ────────────────────────────────────────────────────────────
    ("FAQ-041", "visiting", "What are the visiting hours?",
     "General wards: 10am–8pm daily. ICU and surgical wards: 11am–1pm "
     "and 5pm–7pm. A maximum of two visitors per patient at a time."),

    ("FAQ-042", "visiting", "Is there parking available at the hospital?",
     "Yes. Multi-storey car park on the east side of the building. "
     "First 30 minutes free; $3 per hour thereafter. Disabled bays "
     "are available on Level 1 near the main entrance."),

    ("FAQ-043", "visiting", "Can children visit patients?",
     "Children under 12 may visit general wards only, accompanied by an adult. "
     "Children are not permitted in ICU, oncology, or isolation wards."),

    ("FAQ-044", "visiting", "What items are not allowed in patient rooms?",
     "No flowers or plants in ICU/oncology (infection risk). No outside food "
     "for patients on special diets. No balloons in cardiac wards. "
     "Check with the nursing station when in doubt."),

    ("FAQ-045", "visiting", "Is there a cafeteria or restaurant in the hospital?",
     "Yes. The Garden Café on Level 1 is open 7am–8pm daily. "
     "Vending machines are available 24 hours on every floor."),

    ("FAQ-046", "visiting", "Is Wi-Fi available for visitors?",
     "Free Wi-Fi (CityGeneral_Guest) is available throughout the building. "
     "The password is displayed at the reception desk and nursing stations."),

    ("FAQ-047", "visiting", "Are there overnight accommodation options near the hospital?",
     "The Hope House patient-family lodge is a 5-minute walk away — "
     "call 555-0500 for availability. Several hotels are within 1 km; "
     "reception can provide a list."),

    ("FAQ-048", "visiting", "What accessibility features does the hospital have?",
     "Wheelchair ramps and lifts at all entrances. Hearing loop in the "
     "main reception. Accessible toilets on every floor. "
     "Contact 555-0100 in advance for additional needs."),

    ("FAQ-049", "visiting", "Can I bring a pet to visit a patient?",
     "Service animals are permitted at all times. "
     "Therapy pet visits are available by prior arrangement — "
     "call 555-0501 for the therapy animal schedule."),

    ("FAQ-050", "visiting", "Are masks required for visitors?",
     "Masks are required in ICU, oncology, and isolation wards. "
     "Recommended (but not mandatory) in general areas during respiratory "
     "illness season. Free masks are available at reception."),

    # ── emergency ────────────────────────────────────────────────────────────
    ("FAQ-051", "emergency", "When should I go to the Emergency Department?",
     "Go immediately for: chest pain, difficulty breathing, severe bleeding, "
     "signs of stroke (FAST: face drooping, arm weakness, speech difficulty, "
     "time to call 911), loss of consciousness, or severe allergic reaction."),

    ("FAQ-052", "emergency", "What is the average ED wait time?",
     "Wait times vary by severity. Critical cases are seen immediately. "
     "Minor cases average 2–3 hours. Check live estimates at "
     "citygeneral.org/ed-wait or call 555-0600."),

    ("FAQ-053", "emergency", "What should I bring to the Emergency Department?",
     "Bring your insurance card, photo ID, and a list of current medications "
     "and allergies. If you come by ambulance, hospital staff will record "
     "your information on arrival."),

    ("FAQ-054", "emergency", "Is there a separate paediatric emergency area?",
     "Yes. The Children's Emergency Unit is on Level 0, Wing B. "
     "It operates 24/7 with paediatric-specialist nurses and doctors."),

    ("FAQ-055", "emergency", "Can I call ahead to say I am coming to the ED?",
     "Yes — call 555-0600. This does not reserve a slot, but the triage "
     "team can prepare for your arrival, especially for complex conditions."),

    ("FAQ-056", "emergency", "What happens when I arrive at the Emergency Department?",
     "You will be assessed by a triage nurse who assigns a priority level "
     "(1=resuscitation through 5=non-urgent). You are then seen in priority order, "
     "not arrival order."),

    ("FAQ-057", "emergency", "Do I need a referral to use the Emergency Department?",
     "No. The ED is open to all patients without a referral, 24 hours a day, "
     "7 days a week, 365 days a year."),

    ("FAQ-058", "emergency", "What mental health crisis services do you offer?",
     "A mental health crisis team is available in the ED 24/7. "
     "You can also call the crisis line at 555-0700 or the national "
     "Suicide & Crisis Lifeline at 988."),

    ("FAQ-059", "emergency", "Is there a fast-track area for minor injuries?",
     "Yes. The Minor Injuries Unit (Level 0, Wing A) handles sprains, "
     "minor cuts, and simple fractures. Walk-in only, 8am–10pm. "
     "Average wait: 45 minutes."),

    ("FAQ-060", "emergency", "What should I do if I cannot afford emergency treatment?",
     "No one is refused emergency care due to inability to pay. "
     "A financial counsellor will contact you after treatment to discuss "
     "assistance options. This will not delay your care."),
]

# ---------------------------------------------------------------------------
# 120 test queries  (easy, hard, out_of_scope  — 40 each)
# ---------------------------------------------------------------------------

EASY_QUERIES = [
    # appointments
    ("Q-001", "appointments", "FAQ-001", "How do I make a new appointment at the hospital?"),
    ("Q-002", "appointments", "FAQ-002", "How can I cancel or change my appointment?"),
    ("Q-003", "appointments", "FAQ-003", "Do I need a referral to see a specialist?"),
    ("Q-004", "appointments", "FAQ-005", "Is it possible to get a same-day appointment?"),
    ("Q-005", "appointments", "FAQ-009", "Are there virtual or telehealth appointments?"),
    ("Q-006", "appointments", "FAQ-004", "How early should I arrive for my appointment?"),
    ("Q-007", "appointments", "FAQ-008", "What do I need to bring for a routine check-up?"),
    # billing
    ("Q-008", "billing", "FAQ-011", "How do I pay my hospital bill?"),
    ("Q-009", "billing", "FAQ-013", "Can I set up a payment plan for my bill?"),
    ("Q-010", "billing", "FAQ-012", "What insurance plans does the hospital accept?"),
    ("Q-011", "billing", "FAQ-019", "How do I request an itemised bill?"),
    ("Q-012", "billing", "FAQ-016", "Do you have financial assistance for uninsured patients?"),
    # medications
    ("Q-013", "medications", "FAQ-021", "How do I request a prescription refill?"),
    ("Q-014", "medications", "FAQ-025", "Are generic drugs available?"),
    ("Q-015", "medications", "FAQ-027", "What is a medication reconciliation?"),
    ("Q-016", "medications", "FAQ-029", "Who do I contact about a drug allergy or reaction?"),
    ("Q-017", "medications", "FAQ-030", "How can I dispose of unused medications safely?"),
    # test_results
    ("Q-018", "test_results", "FAQ-031", "How long does it take to get blood test results?"),
    ("Q-019", "test_results", "FAQ-032", "Where can I view my test results?"),
    ("Q-020", "test_results", "FAQ-038", "I got an abnormal test result — what should I do?"),
    ("Q-021", "test_results", "FAQ-036", "How do I get copies of my test results?"),
    ("Q-022", "test_results", "FAQ-035", "Are my test results shared with anyone?"),
    # visiting
    ("Q-023", "visiting", "FAQ-041", "What are the hospital visiting hours?"),
    ("Q-024", "visiting", "FAQ-042", "Is there parking at the hospital?"),
    ("Q-025", "visiting", "FAQ-043", "Can children visit patients in hospital?"),
    ("Q-026", "visiting", "FAQ-045", "Is there a cafeteria in the hospital?"),
    ("Q-027", "visiting", "FAQ-046", "Is Wi-Fi available for visitors?"),
    # emergency
    ("Q-028", "emergency", "FAQ-051", "When should I go to the Emergency Department?"),
    ("Q-029", "emergency", "FAQ-052", "What is the average wait time at the ED?"),
    ("Q-030", "emergency", "FAQ-057", "Do I need a referral for the Emergency Department?"),
    ("Q-031", "emergency", "FAQ-053", "What should I bring to the Emergency Department?"),
    ("Q-032", "emergency", "FAQ-056", "What happens when I arrive at the ED?"),
    ("Q-033", "emergency", "FAQ-058", "What mental health emergency services do you offer?"),
    ("Q-034", "emergency", "FAQ-059", "Is there a fast-track area for minor injuries?"),
    ("Q-035", "appointments", "FAQ-006", "What happens if I miss my appointment?"),
    ("Q-036", "billing", "FAQ-017", "Why did I get two bills for the same visit?"),
    ("Q-037", "test_results", "FAQ-037", "Why is my test result flagged as abnormal?"),
    ("Q-038", "visiting", "FAQ-048", "What accessibility features does the hospital have?"),
    ("Q-039", "medications", "FAQ-023", "What do I do if I miss a dose of my medication?"),
    ("Q-040", "visiting", "FAQ-049", "Can I bring a pet to visit a patient?"),
]

HARD_QUERIES = [
    # appointments — paraphrase / lay terms
    ("Q-041", "appointments", "FAQ-001",
     "I need to schedule a visit with a doctor for next week, how do I go about that?"),
    ("Q-042", "appointments", "FAQ-002",
     "I can't make it to my check-up tomorrow — can I move it to a different day?"),
    ("Q-043", "appointments", "FAQ-003",
     "My GP wants me to see a heart specialist — will my insurance cover that without a letter?"),
    ("Q-044", "appointments", "FAQ-005",
     "Are there any last-minute openings today? It's not an emergency but I'd like to be seen."),
    ("Q-045", "appointments", "FAQ-009",
     "Can I talk to a doctor over video call instead of coming in?"),
    # billing — lay/synonym
    ("Q-046", "billing", "FAQ-011",
     "I owe money from my hospital stay — where can I send a cheque?"),
    ("Q-047", "billing", "FAQ-013",
     "The amount due is too large to pay at once — is there a way to pay it off gradually?"),
    ("Q-048", "billing", "FAQ-015",
     "How much out-of-pocket will I have to pay for seeing my GP?"),
    ("Q-049", "billing", "FAQ-019",
     "I want a line-by-line breakdown of every charge from my procedure."),
    ("Q-050", "billing", "FAQ-016",
     "I don't have health coverage and can't afford the invoice — is there any help?"),
    # medications — indirect phrasing
    ("Q-051", "medications", "FAQ-021",
     "My tablets are running low and I need more — what's the quickest way to get a new supply?"),
    ("Q-052", "medications", "FAQ-023",
     "I forgot to take my morning pill — is it safe to take two at once now?"),
    ("Q-053", "medications", "FAQ-025",
     "My brand-name drug is expensive — is there a cheaper version that works the same?"),
    ("Q-054", "medications", "FAQ-029",
     "I broke out in hives after starting a new drug — what should I do?"),
    ("Q-055", "medications", "FAQ-030",
     "I have old tablets at home that expired — how do I get rid of them without causing harm?"),
    # test_results — indirect phrasing
    ("Q-056", "test_results", "FAQ-031",
     "My doctor took blood this morning — when will I know the numbers?"),
    ("Q-057", "test_results", "FAQ-032",
     "Where do I go online to check my lab results?"),
    ("Q-058", "test_results", "FAQ-038",
     "My results came back with a red flag next to one of the values — should I be worried?"),
    ("Q-059", "test_results", "FAQ-040",
     "I got my scan report but I can't understand the medical language — who explains it to me?"),
    ("Q-060", "test_results", "FAQ-035",
     "Will my employer be able to see my test results?"),
    # visiting — indirect
    ("Q-061", "visiting", "FAQ-041",
     "Until what time can people come to see a patient in a ward?"),
    ("Q-062", "visiting", "FAQ-042",
     "Is there somewhere to leave my car while I visit someone?"),
    ("Q-063", "visiting", "FAQ-044",
     "My mum loves flowers — can I bring a bunch to brighten up her room?"),
    ("Q-064", "visiting", "FAQ-050",
     "Do guests have to wear face coverings when they come in?"),
    ("Q-065", "visiting", "FAQ-047",
     "My relative is far from home — where can the family stay overnight nearby?"),
    # emergency — indirect
    ("Q-066", "emergency", "FAQ-051",
     "My husband is having chest pains and his left arm feels heavy — what do we do?"),
    ("Q-067", "emergency", "FAQ-052",
     "How long will we be waiting in A&E if it's not life-threatening?"),
    ("Q-068", "emergency", "FAQ-054",
     "My 5-year-old has a very high fever — is there a special emergency area for kids?"),
    ("Q-069", "emergency", "FAQ-060",
     "We have no insurance — will the hospital still treat us if we show up at A&E?"),
    ("Q-070", "emergency", "FAQ-058",
     "My teenager is in crisis and I'm really worried — what mental health support is there?"),
    # mixed hard
    ("Q-071", "appointments", "FAQ-007",
     "I only want to be seen by Dr. Patel — can I make sure she's the one I get?"),
    ("Q-072", "appointments", "FAQ-010",
     "Can my husband come into the room with me during my consultation?"),
    ("Q-073", "billing", "FAQ-018",
     "The invoice is overdue — what happens if I can't pay by the deadline?"),
    ("Q-074", "billing", "FAQ-020",
     "The hospital cancelled my operation at the last minute — will I still get a bill?"),
    ("Q-075", "medications", "FAQ-022",
     "Instead of collecting every month, can I get a three-month supply at once?"),
    ("Q-076", "medications", "FAQ-024",
     "I take blood pressure tablets at home — should I bring them when I'm admitted?"),
    ("Q-077", "test_results", "FAQ-033",
     "My results look confusing — can I book time to go through them with my doctor?"),
    ("Q-078", "test_results", "FAQ-039",
     "The result seems off to me — can I ask for the test to be redone?"),
    ("Q-079", "visiting", "FAQ-043",
     "My nephew is 8 years old — is he allowed to come with us?"),
    ("Q-080", "emergency", "FAQ-055",
     "I'm on my way to A&E — should I call ahead so they know I'm coming?"),
]

OUT_OF_SCOPE_QUERIES = [
    ("Q-081", None, None, "Can I adopt a pet from your hospital?"),
    ("Q-082", None, None, "What is the best restaurant near the hospital?"),
    ("Q-083", None, None, "How do I apply for a job as a nurse at this hospital?"),
    ("Q-084", None, None, "Do you offer cooking classes or nutrition workshops?"),
    ("Q-085", None, None, "Can I donate my organs after death?"),
    ("Q-086", None, None, "Is there a gym or fitness centre in the building?"),
    ("Q-087", None, None, "What is the hospital's policy on cryptocurrency payments?"),
    ("Q-088", None, None, "Can I buy a gift from your hospital gift shop online?"),
    ("Q-089", None, None, "How do I become a volunteer at the hospital?"),
    ("Q-090", None, None, "What is the hospital CEO's name?"),
    ("Q-091", None, None, "Can I rent a meeting room at the hospital for a corporate event?"),
    ("Q-092", None, None, "Does the hospital have a swimming pool?"),
    ("Q-093", None, None, "How do I get a medical certificate for my employer?"),
    ("Q-094", None, None, "What is the hospital's stance on alternative medicine?"),
    ("Q-095", None, None, "Can I use the hospital's laundry facilities?"),
    ("Q-096", None, None, "How do I access my school vaccination records?"),
    ("Q-097", None, None, "Does the hospital offer dental services?"),
    ("Q-098", None, None, "Can you recommend a good physiotherapist outside the hospital?"),
    ("Q-099", None, None, "What time does the last bus leave from the hospital stop?"),
    ("Q-100", None, None, "How do I report a safety hazard in the hospital building?"),
    ("Q-101", None, None, "Is there a library or reading room for patients?"),
    ("Q-102", None, None, "Can I arrange a blood donation here?"),
    ("Q-103", None, None, "Where can I find the hospital annual report?"),
    ("Q-104", None, None, "Does the hospital have a complaints ombudsman?"),
    ("Q-105", None, None, "Can I request a chaperone during my examination?"),
    ("Q-106", None, None, "Are there translation services available?"),
    ("Q-107", None, None, "Does the hospital have a chapel or prayer room?"),
    ("Q-108", None, None, "How long do medical records need to be kept by law?"),
    ("Q-109", None, None, "Can I see my child's medical records?"),
    ("Q-110", None, None, "What research trials is the hospital currently running?"),
    ("Q-111", None, None, "How do I get a second opinion from another hospital?"),
    ("Q-112", None, None, "Does the hospital have student placement programmes?"),
    ("Q-113", None, None, "Can I get a copy of my discharge summary?"),
    ("Q-114", None, None, "Where is the nearest blood bank?"),
    ("Q-115", None, None, "Can I request a specific nurse for my care?"),
    ("Q-116", None, None, "Do you have an oncology support group?"),
    ("Q-117", None, None, "Can I use my smartphone to record consultations?"),
    ("Q-118", None, None, "Is the hospital accredited by any regulatory body?"),
    ("Q-119", None, None, "How do I change my next of kin on my records?"),
    ("Q-120", None, None, "Does the hospital have a social worker I can speak to?"),
]

ALL_QUERIES = EASY_QUERIES + HARD_QUERIES + OUT_OF_SCOPE_QUERIES

# ---------------------------------------------------------------------------
# Write CSV files
# ---------------------------------------------------------------------------

def write_faqs(out_path: str) -> None:
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["faq_id", "category", "question", "answer"])
        for row in FAQS:
            writer.writerow(row)
    print(f"Wrote {len(FAQS)} FAQs -> {out_path}")


def write_queries(out_path: str) -> None:
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["query_id", "category", "ground_truth_faq_id",
                         "query_text", "difficulty"])
        for q in EASY_QUERIES:
            writer.writerow(list(q) + ["easy"])
        for q in HARD_QUERIES:
            writer.writerow(list(q) + ["hard"])
        for q in OUT_OF_SCOPE_QUERIES:
            writer.writerow(list(q) + ["out_of_scope"])
    print(f"Wrote {len(ALL_QUERIES)} test queries -> {out_path}")


if __name__ == "__main__":
    base = os.path.dirname(__file__)
    write_faqs(os.path.join(base, "faqs.csv"))
    write_queries(os.path.join(base, "test_queries.csv"))
    print("\nDone. Open both CSV files and read them before starting to code.")
    print("Notice how 'hard' queries use completely different words from the FAQ questions.")
