"""
Entry point for Project 6.

Usage:
    # Evaluate both matchers on the test set and print a comparison table
    python starter/main.py --mode eval

    # Run the interactive chatbot (semantic matcher, default threshold)
    python starter/main.py --mode chat

    # Evaluate with a specific confidence threshold
    python starter/main.py --mode eval --threshold 0.45

    # Use TF-IDF matcher for the interactive chatbot
    python starter/main.py --mode chat --matcher tfidf
"""

import argparse
import os
import sys

import pandas as pd

# Allow running from the project root or from starter/
sys.path.insert(0, os.path.dirname(__file__))

from evaluate import run_batch, summarise, print_comparison_table
from tfidf_matcher import TFIDFMatcher
from semantic_matcher import SemanticMatcher
from chatbot import ChatSession


DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
FAQS_PATH = os.path.join(DATA_DIR, "faqs.csv")
QUERIES_PATH = os.path.join(DATA_DIR, "test_queries.csv")


def load_data() -> tuple[pd.DataFrame, pd.DataFrame]:
    if not os.path.exists(FAQS_PATH):
        print("ERROR: data/faqs.csv not found.")
        print("       Run:  python data/generate_dataset.py")
        sys.exit(1)
    faqs = pd.read_csv(FAQS_PATH)
    queries = pd.read_csv(QUERIES_PATH)
    return faqs, queries


def build_matchers(faqs: pd.DataFrame):
    """Fit both matchers and return them."""
    print("Fitting TF-IDF matcher … ", end="", flush=True)
    tfidf = TFIDFMatcher()
    tfidf.fit(faqs)
    print("done")

    print("Loading sentence-transformer and encoding FAQs … ")
    semantic = SemanticMatcher()
    semantic.fit(faqs)
    print("done\n")

    return tfidf, semantic


def run_eval(threshold: float, matcher_choice: str | None) -> None:
    faqs, queries = load_data()
    tfidf, semantic = build_matchers(faqs)

    matchers = [
        (tfidf,    "tfidf"),
        (semantic, "semantic"),
    ]
    if matcher_choice:
        matchers = [(m, n) for m, n in matchers if n == matcher_choice]

    results = []
    for matcher, name in matchers:
        print(f"Evaluating {name} matcher (threshold={threshold}) …")
        responses, gt = run_batch(matcher, faqs, queries, threshold, name)
        result = summarise(name, responses, gt)
        results.append(result)

    print_comparison_table(results)

    # ── Experiment 1 hint ─────────────────────────────────────────────────
    print("Tip: find queries where TF-IDF fails but semantic succeeds:")
    print("     Look for hard queries where tfidf top_match is wrong but")
    print("     semantic top_match is correct.\n")


def run_chat(threshold: float, matcher_choice: str) -> None:
    faqs, _ = load_data()
    _, semantic = build_matchers(faqs) if matcher_choice == "semantic" else (None, None)

    if matcher_choice == "tfidf":
        print("Fitting TF-IDF matcher … ", end="", flush=True)
        m = TFIDFMatcher()
        m.fit(faqs)
        print("done\n")
        name = "tfidf"
    else:
        print("Loading sentence-transformer … ")
        m = SemanticMatcher()
        m.fit(faqs)
        print("done\n")
        name = "semantic"

    session = ChatSession(matcher=m, threshold=threshold, matcher_name=name)
    session.run_interactive()


def main() -> None:
    parser = argparse.ArgumentParser(description="Hospital FAQ Chatbot — Project 6")
    parser.add_argument("--mode", choices=["eval", "chat"], default="eval",
                        help="eval: batch evaluation; chat: interactive chatbot")
    parser.add_argument("--threshold", type=float, default=0.50,
                        help="Confidence threshold (default 0.50)")
    parser.add_argument("--matcher", choices=["tfidf", "semantic"], default=None,
                        help="Which matcher to use (default: both, for eval mode)")
    args = parser.parse_args()

    if args.mode == "eval":
        run_eval(threshold=args.threshold, matcher_choice=args.matcher)
    else:
        run_chat(threshold=args.threshold,
                 matcher_choice=args.matcher or "semantic")


if __name__ == "__main__":
    main()
