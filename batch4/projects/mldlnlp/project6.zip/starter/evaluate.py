"""
Evaluation utilities for Project 6.

Task 8 — implement accuracy_at_k() below.

The other functions are fully provided.
"""

from __future__ import annotations

import pandas as pd

from schemas import ChatbotResponse, EvaluationResult


# ── Task 8 ────────────────────────────────────────────────────────────────────

def accuracy_at_k(responses: list[ChatbotResponse],
                  ground_truth: dict[str, str | None],
                  k: int = 1) -> float:
    """
    Compute Top-K accuracy across a list of chatbot responses.

    A query is counted as CORRECT at rank k if:
      - The ground-truth FAQ ID appears among the top-k candidates
        in the response (check top_match + runner_up_matches), AND
      - The response is answered (answered=True).

    A query is counted as INCORRECT if:
      - answered=False  (chatbot refused — counts against accuracy), OR
      - The correct FAQ ID is not in the top-k candidates.

    Queries with ground_truth == None are OUT-OF-SCOPE and should be
    EXCLUDED from the accuracy calculation entirely.

    Args:
        responses:      List of ChatbotResponse objects from a batch run.
        ground_truth:   Dict mapping query_id → correct FAQ ID (or None for OOS).
        k:              How many top candidates to check.  Use k=1 for Top-1
                        accuracy, k=3 for Top-3 accuracy.

    Returns:
        Accuracy as a float between 0.0 and 1.0.
        Returns 0.0 if there are no in-scope queries.

    Example:
        ground_truth = {"Q-001": "FAQ-001", "Q-002": "FAQ-002", "Q-099": None}
        # Q-099 is out-of-scope and should not affect the score.

    Steps (Task 8):
        1. Filter out responses whose ground_truth is None (OOS queries).
        2. For each remaining response:
           a. Collect the top-k candidate FAQ IDs:
              - If answered=True and top_match is not None, start with [top_match.faq_id].
              - Extend with [m.faq_id for m in runner_up_matches] up to k total.
              - If answered=False, the candidates list is empty.
           b. Check if ground_truth[response.query_id] is in the candidates list.
        3. Return correct_count / total_in_scope_count.
    """
    # ── TODO 8 ───────────────────────────────────────────────────────────────
    raise NotImplementedError("TODO 8: implement accuracy_at_k()")
    # ─────────────────────────────────────────────────────────────────────────


# ── Provided helpers ──────────────────────────────────────────────────────────

def oos_rejection_rate(responses: list[ChatbotResponse],
                       ground_truth: dict[str, str | None]) -> float:
    """
    Fraction of out-of-scope queries that were correctly refused (answered=False).

    A high rejection rate means the confidence threshold is working well:
    the chatbot declines to answer when it doesn't know, rather than
    confidently returning a wrong FAQ.
    """
    oos = [r for r in responses if ground_truth.get(r.query_id) is None]
    if not oos:
        return 0.0
    refused = sum(1 for r in oos if not r.answered)
    return refused / len(oos)


def run_batch(matcher, faqs_df: pd.DataFrame,
              queries_df: pd.DataFrame,
              threshold: float,
              matcher_name: str) -> tuple[list[ChatbotResponse], dict[str, str | None]]:
    """
    Run a matcher over every query in queries_df and collect responses.

    Returns:
        responses:     One ChatbotResponse per query.
        ground_truth:  Dict mapping query_id → correct FAQ ID (None for OOS).
    """
    from chatbot import ChatSession

    session = ChatSession(matcher=matcher, threshold=threshold,
                          matcher_name=matcher_name)

    responses: list[ChatbotResponse] = []
    ground_truth: dict[str, str | None] = {}

    for _, row in queries_df.iterrows():
        qid = row["query_id"]
        gt = row["ground_truth_faq_id"] if pd.notna(row["ground_truth_faq_id"]) else None
        ground_truth[qid] = gt

        response = session.respond(query_id=qid, query_text=row["query_text"])
        responses.append(response)

    return responses, ground_truth


def summarise(matcher_name: str,
              responses: list[ChatbotResponse],
              ground_truth: dict[str, str | None]) -> EvaluationResult:
    """
    Compute all evaluation metrics and return an EvaluationResult.
    Provided — no changes needed.
    """
    n_answered = sum(1 for r in responses if r.answered)

    # Split into difficulty buckets using the ground_truth key
    # (OOS queries have None ground truth)
    in_scope = [r for r in responses if ground_truth.get(r.query_id) is not None]
    oos_resp = [r for r in responses if ground_truth.get(r.query_id) is None]

    # Rough split: first 40 are easy, next 40 are hard (matches generate_dataset.py order)
    easy_ids = {r.query_id for r in in_scope if r.query_id.startswith("Q-0") and
                int(r.query_id.split("-")[1]) <= 40}
    hard_ids = {r.query_id for r in in_scope if r.query_id not in easy_ids}

    easy_resp = [r for r in in_scope if r.query_id in easy_ids]
    hard_resp = [r for r in in_scope if r.query_id in hard_ids]

    return EvaluationResult(
        matcher=matcher_name,
        n_queries=len(responses),
        n_answered=n_answered,
        n_unanswered=len(responses) - n_answered,
        top1_accuracy=accuracy_at_k(in_scope, ground_truth, k=1),
        top3_accuracy=accuracy_at_k(in_scope, ground_truth, k=3),
        easy_top1=accuracy_at_k(easy_resp, ground_truth, k=1),
        hard_top1=accuracy_at_k(hard_resp, ground_truth, k=1),
        oos_rejection_rate=oos_rejection_rate(responses, ground_truth),
    )


def print_comparison_table(results: list[EvaluationResult]) -> None:
    """Print a side-by-side comparison table.  Provided."""
    header = f"{'Metric':<28}" + "".join(f"{r.matcher:>14}" for r in results)
    print("\n" + "=" * (28 + 14 * len(results)))
    print(header)
    print("-" * (28 + 14 * len(results)))

    rows = [
        ("Top-1 accuracy (all)",   [f"{r.top1_accuracy:.1%}" for r in results]),
        ("Top-3 accuracy (all)",   [f"{r.top3_accuracy:.1%}" for r in results]),
        ("Top-1 easy queries",     [f"{r.easy_top1:.1%}" for r in results]),
        ("Top-1 hard queries",     [f"{r.hard_top1:.1%}" for r in results]),
        ("OOS rejection rate",     [f"{r.oos_rejection_rate:.1%}" for r in results]),
        ("Answered / total",       [f"{r.n_answered}/{r.n_queries}" for r in results]),
    ]

    for label, values in rows:
        print(f"{label:<28}" + "".join(f"{v:>14}" for v in values))

    print("=" * (28 + 14 * len(results)) + "\n")
