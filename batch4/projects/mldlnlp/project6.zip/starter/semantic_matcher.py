"""
Semantic (sentence-embedding) matcher for Project 6.

Tasks 3–6 — implement the four methods marked TODO below.

How semantic matching works:
  1. Load a pre-trained sentence-transformer model.  This model converts
     any text into a 384-dimensional float vector (for MiniLM).

  2. At startup (fit), encode every FAQ question into a vector matrix.
     Shape: (n_faqs, 384).  Store this matrix — it does not change.

  3. At query time, encode the user's query into a single vector.
     Shape: (384,).

  4. Compute cosine similarity between the query vector and every
     FAQ vector.  The FAQ with the highest score is the best match.

Unlike TF-IDF, two sentences can be similar even if they share zero words,
because the model encodes *meaning*, not *tokens*:

    "Can I reschedule my check-up?"
    "How do I book or change an appointment?"
    → cosine similarity ≈ 0.82   (same intent, different words)

Model to use: "all-MiniLM-L6-v2"
  - 22 million parameters, ~80 MB download on first use.
  - 384-dimensional output vectors.
  - Fast CPU inference (~5 ms per sentence).
  - Good balance of quality and speed for FAQ-style texts.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from schemas import FAQMatch

# ── dependency note ──────────────────────────────────────────────────────────
# from sentence_transformers import SentenceTransformer
# Install: pip install sentence-transformers
# The model downloads automatically on first use (~80 MB).
# ─────────────────────────────────────────────────────────────────────────────

MODEL_NAME = "all-MiniLM-L6-v2"


class SemanticMatcher:
    """
    Matches a user query to the closest FAQ using sentence embeddings
    and cosine similarity.
    """

    def __init__(self, model_name: str = MODEL_NAME) -> None:
        """
        Load the sentence-transformer model.

        Args:
            model_name: HuggingFace model identifier.
                        Default: "all-MiniLM-L6-v2"

        Steps (Task 3):
            Import SentenceTransformer from sentence_transformers.
            Instantiate the model with model_name and store it in self._model.

        The model downloads automatically the first time — this may take a
        minute on a slow connection.  Subsequent runs use the cached copy.
        """
        # ── TODO 3 ───────────────────────────────────────────────────────────
        # from sentence_transformers import SentenceTransformer
        # self._model = SentenceTransformer(model_name)
        raise NotImplementedError("TODO 3: load the SentenceTransformer model")
        # ─────────────────────────────────────────────────────────────────────

        # Will hold the embedding matrix after fit().
        # Shape: (n_faqs, 384)
        self._faq_embeddings: np.ndarray | None = None

        # Will hold the original FAQ rows after fit().
        self._faqs: pd.DataFrame | None = None

    # ── fit ──────────────────────────────────────────────────────────────────

    def fit(self, faqs: pd.DataFrame) -> None:
        """
        Encode all FAQ questions and store the embedding matrix.

        Args:
            faqs: DataFrame with columns [faq_id, category, question, answer].

        Steps (Task 4):
            1. Store the DataFrame in self._faqs.
            2. Extract the list of FAQ question strings.
            3. Call self._model.encode() on the list of questions.
               Pass show_progress_bar=True so you can see it working.
               This returns a numpy array of shape (n_faqs, 384).
            4. Store the result in self._faq_embeddings.

        After fit():
            self._faq_embeddings.shape == (60, 384)   # for our 60 FAQs

        Hint:
            questions = faqs["question"].tolist()
            self._faq_embeddings = self._model.encode(questions, ...)
        """
        # ── TODO 4 ───────────────────────────────────────────────────────────
        raise NotImplementedError("TODO 4: implement SemanticMatcher.fit()")
        # ─────────────────────────────────────────────────────────────────────

    # ── find_best_match ───────────────────────────────────────────────────────

    def find_best_match(self, query: str) -> FAQMatch:
        """
        Return the single FAQ most similar to the query.

        Args:
            query: Raw user query string (no preprocessing needed here —
                   the model handles it internally).

        Returns:
            FAQMatch — the best-matching FAQ with its cosine similarity score.

        Steps (Task 5):
            1. Encode the query with self._model.encode().
               Pass convert_to_numpy=True to get a numpy array of shape (384,).
            2. Compute cosine similarity between the query vector and every row
               in self._faq_embeddings.

               Cosine similarity formula:
                   sim(u, v) = dot(u, v) / (norm(u) * norm(v))

               You can use sklearn:
                   from sklearn.metrics.pairwise import cosine_similarity
                   sims = cosine_similarity([query_vec], self._faq_embeddings)[0]

               Or compute manually with numpy:
                   query_norm = query_vec / np.linalg.norm(query_vec)
                   faq_norms  = self._faq_embeddings / np.linalg.norm(
                                    self._faq_embeddings, axis=1, keepdims=True)
                   sims = faq_norms @ query_norm  # shape (n_faqs,)

            3. Find the index of the highest score (np.argmax).
            4. Look up that row in self._faqs and return a FAQMatch.

        Raises:
            RuntimeError if called before fit().
        """
        if self._faq_embeddings is None:
            raise RuntimeError("Call fit() before find_best_match().")

        # ── TODO 5 ───────────────────────────────────────────────────────────
        raise NotImplementedError("TODO 5: implement SemanticMatcher.find_best_match()")
        # ─────────────────────────────────────────────────────────────────────

    # ── find_top_k ────────────────────────────────────────────────────────────

    def find_top_k(self, query: str, k: int = 3) -> list[FAQMatch]:
        """
        Return the top-K most similar FAQs, sorted by score descending.

        Args:
            query: Raw user query string.
            k:     Number of results to return.

        Returns:
            List of FAQMatch objects, length = min(k, n_faqs).

        Steps (Task 6):
            1. Encode the query (same as Task 5, step 1).
            2. Compute cosine similarity with all FAQ embeddings (same as Task 5, step 2).
            3. Use np.argsort(sims)[::-1][:k] to get the indices of the top-K scores
               in descending order.
            4. Build and return a list of FAQMatch objects for those indices.

        Raises:
            RuntimeError if called before fit().
        """
        if self._faq_embeddings is None:
            raise RuntimeError("Call fit() before find_top_k().")

        # ── TODO 6 ───────────────────────────────────────────────────────────
        raise NotImplementedError("TODO 6: implement SemanticMatcher.find_top_k()")
        # ─────────────────────────────────────────────────────────────────────
