"""
Chatbot session logic for Project 6.

Task 7 — implement ChatSession.respond().

This module wraps the SemanticMatcher (or TFIDFMatcher) in a simple
conversational session that:

  - Applies a CONFIDENCE THRESHOLD: if the best match score is below the
    threshold, the chatbot declines to answer rather than returning a
    potentially wrong FAQ.

  - Keeps a CONVERSATION HISTORY of the last N exchanges, so you can inspect
    what was discussed (useful for debugging and for future extensions like
    context-aware follow-up questions).

  - Returns a validated ChatbotResponse object for every query.

Confidence threshold intuition
───────────────────────────────
Imagine asking "Do you accept cryptocurrency?"  The semantic matcher will
still return SOMETHING — the FAQ with the highest score — but that score
might only be 0.18.  Without a threshold, you'd mislead the user with a
completely irrelevant answer.

A threshold of 0.50 means: "Only answer if you're at least 50% confident."

Choosing the threshold is covered in Experiment 2 (see README).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from schemas import ChatbotResponse, FAQMatch

# Default answer when the matcher's confidence is too low
DEFAULT_FALLBACK = (
    "I'm not sure I have the right information for that question. "
    "Please call our helpline at 555-0199 or speak to a member of staff."
)

# How many past exchanges to remember
HISTORY_LENGTH = 5


@runtime_checkable
class Matcher(Protocol):
    """
    Structural protocol — any object with find_best_match() and find_top_k()
    can be used as a matcher.  Both TFIDFMatcher and SemanticMatcher satisfy
    this protocol automatically.
    """

    def find_best_match(self, query: str) -> FAQMatch: ...
    def find_top_k(self, query: str, k: int = 3) -> list[FAQMatch]: ...


@dataclass
class Turn:
    """One conversational exchange (user query → chatbot response)."""
    query: str
    response: ChatbotResponse


class ChatSession:
    """
    Manages a single conversation session.

    Usage:
        session = ChatSession(matcher=semantic, threshold=0.50)
        response = session.respond(query_id="Q-001", query_text="Can I reschedule?")
        print(response.model_dump_json(indent=2))
    """

    def __init__(
        self,
        matcher: Matcher,
        threshold: float = 0.50,
        matcher_name: str = "semantic",
    ) -> None:
        """
        Args:
            matcher:      A fitted TFIDFMatcher or SemanticMatcher.
            threshold:    Minimum similarity score to consider a query answered.
                          Queries below this threshold get the fallback message.
            matcher_name: Label stored in ChatbotResponse.matcher_used.
        """
        self.matcher = matcher
        self.threshold = threshold
        self.matcher_name = matcher_name
        self.history: list[Turn] = []

    # ── respond ──────────────────────────────────────────────────────────────

    def respond(self, query_id: str, query_text: str) -> ChatbotResponse:
        """
        Process one user query and return a ChatbotResponse.

        Args:
            query_id:   Identifier string (e.g. "Q-00042").
            query_text: The user's raw question.

        Returns:
            A validated ChatbotResponse object.

        Steps (Task 7):
            1. Call self.matcher.find_top_k(query_text, k=3) to get the top 3
               candidate FAQs.  The first element is the best match.

            2. Check the confidence gate:
               - If top_matches[0].similarity_score >= self.threshold:
                   answered = True
                   top_match = top_matches[0]
                   runner_up_matches = top_matches[1:]  (the remaining 2)
                   fallback_message = None
               - Otherwise:
                   answered = False
                   top_match = None
                   runner_up_matches = []
                   fallback_message = DEFAULT_FALLBACK

            3. Build a ChatbotResponse with all the fields above plus:
               - query_id, query_text
               - matcher_used = self.matcher_name
               - confidence = top_matches[0].similarity_score
               - threshold_used = self.threshold

            4. Append a Turn(query=query_text, response=response) to
               self.history.  Keep at most HISTORY_LENGTH turns by slicing:
               self.history = self.history[-HISTORY_LENGTH:]

            5. Return the ChatbotResponse.
        """
        # ── TODO 7 ───────────────────────────────────────────────────────────
        raise NotImplementedError("TODO 7: implement ChatSession.respond()")
        # ─────────────────────────────────────────────────────────────────────

    # ── interactive loop ──────────────────────────────────────────────────────

    def run_interactive(self) -> None:
        """
        Simple command-line chat loop.
        Provided — no changes needed.
        Type 'quit' or 'exit' to stop.
        """
        print(f"\n{'='*60}")
        print("  Hospital FAQ Chatbot  (type 'quit' to exit)")
        print(f"  Matcher: {self.matcher_name}   Threshold: {self.threshold}")
        print(f"{'='*60}\n")

        query_counter = 1
        while True:
            try:
                user_input = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye!")
                break

            if not user_input:
                continue
            if user_input.lower() in {"quit", "exit", "bye"}:
                print("Chatbot: Goodbye! Have a healthy day.")
                break

            response = self.respond(
                query_id=f"SESSION-{query_counter:03d}",
                query_text=user_input,
            )
            query_counter += 1

            if response.answered:
                print(f"\nChatbot (confidence {response.confidence:.0%}):")
                print(f"  Q: {response.top_match.question}")
                print(f"  A: {response.top_match.answer}")
                if response.runner_up_matches:
                    print("\n  Related questions you might also mean:")
                    for i, m in enumerate(response.runner_up_matches, 1):
                        print(f"    {i}. {m.question}  [{m.similarity_score:.2f}]")
            else:
                print(f"\nChatbot: {response.fallback_message}")
            print()
