"""
Pydantic output schemas for Project 6.

DO NOT MODIFY THIS FILE.

All matcher results and chatbot responses must validate against these schemas.
"""

from __future__ import annotations
from typing import Optional
from pydantic import BaseModel, Field


class FAQMatch(BaseModel):
    """A single FAQ entry returned as a candidate match."""

    faq_id: str = Field(..., description="e.g. 'FAQ-001'")
    category: str = Field(..., description="e.g. 'appointments'")
    question: str = Field(..., description="The FAQ question text")
    answer: str = Field(..., description="The FAQ answer text")
    similarity_score: float = Field(
        ..., ge=0.0, le=1.0,
        description="Cosine similarity between query and FAQ (0–1)"
    )


class ChatbotResponse(BaseModel):
    """
    Full response object for a single chatbot query.

    Serialise every response to JSON that validates against this schema.
    """

    query_id: str = Field(..., description="e.g. 'Q-00042'")
    query_text: str = Field(..., description="The raw user query")
    matcher_used: str = Field(..., description="'tfidf' or 'semantic'")

    answered: bool = Field(
        ...,
        description="True if the best match exceeded the confidence threshold"
    )
    confidence: float = Field(
        ..., ge=0.0, le=1.0,
        description="Similarity score of the top match (0 if no match found)"
    )
    threshold_used: float = Field(
        ..., ge=0.0, le=1.0,
        description="The minimum score required to be considered answered"
    )

    top_match: Optional[FAQMatch] = Field(
        None,
        description="Best matching FAQ (None when answered=False)"
    )
    runner_up_matches: list[FAQMatch] = Field(
        default_factory=list,
        description="2nd and 3rd best matches, always included for transparency"
    )
    fallback_message: Optional[str] = Field(
        None,
        description="Message returned to the user when answered=False"
    )


class EvaluationResult(BaseModel):
    """Summary statistics for a batch evaluation run."""

    matcher: str
    n_queries: int
    n_answered: int
    n_unanswered: int

    top1_accuracy: float = Field(..., ge=0.0, le=1.0)
    top3_accuracy: float = Field(..., ge=0.0, le=1.0)

    # broken down by difficulty
    easy_top1: float = Field(..., ge=0.0, le=1.0)
    hard_top1: float = Field(..., ge=0.0, le=1.0)
    oos_rejection_rate: float = Field(
        ..., ge=0.0, le=1.0,
        description="Fraction of out-of-scope queries correctly refused"
    )
