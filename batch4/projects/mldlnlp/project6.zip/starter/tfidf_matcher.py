"""
TF-IDF baseline matcher for Project 6.

Task 2 — implement TFIDFMatcher.fit() and TFIDFMatcher.find_best_match().

How TF-IDF matching works:
  1. At startup (fit), encode every FAQ question as a TF-IDF vector.
     Each vector has one dimension per vocabulary word.  A word that appears
     often in this FAQ but rarely across all FAQs gets a high weight.

  2. At query time, encode the user's query with the SAME vocabulary
     (words not seen during fit get weight 0).

  3. Compute the cosine similarity between the query vector and every
     FAQ vector.  Return the FAQ with the highest score.

Cosine similarity:
    sim(u, v) = dot(u, v) / (norm(u) * norm(v))

  - Returns 0.0  if the query shares no words with the FAQ.
  - Returns 1.0  for identical vectors.
  - TfidfVectorizer(norm="l2") normalises vectors to unit length, so
    cosine similarity reduces to a simple dot product.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from preprocess import clean_text
from schemas import FAQMatch


class TFIDFMatcher:
    """
    Matches a user query to the closest FAQ using TF-IDF + cosine similarity.
    """

    def __init__(self) -> None:
        # TfidfVectorizer converts text into a TF-IDF matrix.
        # norm="l2" makes each row a unit-length vector.
        # max_features limits vocabulary size to prevent memory issues.
        self._vectorizer = TfidfVectorizer(norm="l2", max_features=5_000)

        # Will hold the TF-IDF matrix of all FAQ questions after fit().
        # Shape: (n_faqs, vocab_size)
        self._faq_matrix = None

        # Will hold the original FAQ rows (pandas DataFrame) after fit().
        self._faqs: pd.DataFrame | None = None

    # ── fit ──────────────────────────────────────────────────────────────────

    def fit(self, faqs: pd.DataFrame) -> None:
        """
        Build the TF-IDF index from the FAQ questions.

        Args:
            faqs: DataFrame with columns [faq_id, category, question, answer].

        Steps (Task 2a):
            1. Store the FAQ DataFrame in self._faqs.
            2. Clean each FAQ question with clean_text() (from preprocess.py).
            3. Fit self._vectorizer on the cleaned questions AND transform them
               into a matrix.  Use fit_transform().
               Store the result in self._faq_matrix.

        After fit(), self._faq_matrix has shape (n_faqs, vocab_size).
        """
        # ── TODO 2a ──────────────────────────────────────────────────────────
        raise NotImplementedError("TODO 2a: implement TFIDFMatcher.fit()")
        # ─────────────────────────────────────────────────────────────────────

    # ── find_best_match ───────────────────────────────────────────────────────

    def find_best_match(self, query: str) -> FAQMatch:
        """
        Return the single FAQ most similar to the query.

        Args:
            query: Raw user query string (will be cleaned inside this method).

        Returns:
            FAQMatch — the best-matching FAQ with its similarity score.

        Steps (Task 2b):
            1. Clean the query with clean_text().
            2. Transform it using self._vectorizer.transform() (NOT fit_transform —
               you must use the vocabulary built during fit()).
            3. Compute cosine similarity between the query vector and self._faq_matrix.
               sklearn.metrics.pairwise.cosine_similarity returns a (1, n_faqs) array.
            4. Find the index of the highest score (np.argmax).
            5. Look up that row in self._faqs and return a FAQMatch object.

        Raises:
            RuntimeError if called before fit().
        """
        if self._faq_matrix is None:
            raise RuntimeError("Call fit() before find_best_match().")

        # ── TODO 2b ──────────────────────────────────────────────────────────
        raise NotImplementedError("TODO 2b: implement TFIDFMatcher.find_best_match()")
        # ─────────────────────────────────────────────────────────────────────

    # ── find_top_k ────────────────────────────────────────────────────────────

    def find_top_k(self, query: str, k: int = 3) -> list[FAQMatch]:
        """
        Return the top-K most similar FAQs, sorted by score descending.

        Provided — no changes needed.
        Uses find_best_match() logic internally but returns k results.
        """
        if self._faq_matrix is None:
            raise RuntimeError("Call fit() before find_top_k().")

        cleaned = clean_text(query)
        query_vec = self._vectorizer.transform([cleaned])
        sims = cosine_similarity(query_vec, self._faq_matrix)[0]  # shape (n_faqs,)

        # argsort gives indices in ascending order; [::-1] reverses to descending
        top_indices = np.argsort(sims)[::-1][:k]

        results = []
        for idx in top_indices:
            row = self._faqs.iloc[idx]
            results.append(FAQMatch(
                faq_id=row["faq_id"],
                category=row["category"],
                question=row["question"],
                answer=row["answer"],
                similarity_score=float(sims[idx]),
            ))
        return results
