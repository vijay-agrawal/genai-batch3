"""
Text preprocessing for Project 6.

Task 1 — implement clean_text() below.

Why preprocessing helps TF-IDF:
  - Lowercasing ensures "Appointment" and "appointment" are the same token.
  - Punctuation removal avoids "appointment?" being a different token from "appointment".
  - Stopword removal drops words like "the", "a", "is" that carry no useful
    signal — they would otherwise dominate TF-IDF scores because they appear
    everywhere, making everything look similar.

Why preprocessing matters LESS for sentence embeddings:
  - The sentence-transformer model handles casing and punctuation internally.
  - Removing stopwords can sometimes hurt embeddings because the model uses
    context (including function words) to build meaning.
  - You will apply clean_text() only for the TF-IDF matcher; the semantic
    matcher uses the raw text.
"""

import re
import string

import nltk

# Download stopwords the first time (no-op if already downloaded)
try:
    from nltk.corpus import stopwords
    STOPWORDS = set(stopwords.words("english"))
except LookupError:
    nltk.download("stopwords", quiet=True)
    from nltk.corpus import stopwords
    STOPWORDS = set(stopwords.words("english"))


def clean_text(text: str, remove_stopwords: bool = True) -> str:
    """
    Clean a single string for use with the TF-IDF matcher.

    Steps to implement (Task 1):
        1. Convert the text to lowercase.
        2. Remove all punctuation characters (use str.translate or re.sub).
        3. If remove_stopwords is True, drop any tokens that appear in
           STOPWORDS (defined above).
        4. Return the cleaned string (tokens joined by spaces).

    Args:
        text:              Raw input string.
        remove_stopwords:  Whether to drop stopwords. Default True.

    Returns:
        Cleaned string, e.g. "appointment book reschedule" (no stopwords).

    Example:
        >>> clean_text("How do I book a new Appointment?")
        'book new appointment'
    """
    # ── TODO 1 ── implement the three cleaning steps described above ──────
    # Hint: string.punctuation contains all punctuation characters.
    # Hint: text.translate(str.maketrans("", "", string.punctuation))
    #       removes all punctuation in one call.
    raise NotImplementedError("TODO 1: implement clean_text()")
    # ─────────────────────────────────────────────────────────────────────


def clean_texts(texts: list[str], remove_stopwords: bool = True) -> list[str]:
    """
    Apply clean_text() to a list of strings.
    Provided — no changes needed.
    """
    return [clean_text(t, remove_stopwords=remove_stopwords) for t in texts]
