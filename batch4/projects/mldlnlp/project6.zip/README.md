# Mini-Project 6: Semantic FAQ Chatbot

## The Problem

A hospital's patient-services team has a document of 60 frequently-asked
questions (FAQs) — covering appointments, billing, medications, test results,
visiting hours, and emergencies.

Today they route incoming queries using keyword rules:
- *"Does the message contain the word 'appointment'?"*
- *"Does it contain 'bill' or 'invoice'?"*

This breaks constantly:

| Patient asks… | Keyword rule fires on… | Result |
|---|---|---|
| "Can I reschedule my check-up?" | `appointment` | **MISS** — "reschedule" and "check-up" aren't in the rule |
| "How much will I owe after my procedure?" | `bill` | **MISS** — "owe" and "procedure" aren't in the rule |
| "Is there parking for wheelchairs?" | `visit` | **MISS** — "parking" and "wheelchairs" aren't in the rule |

The root cause is **vocabulary mismatch**: the patient's words and the FAQ's
words describe the same concept but share few tokens.

**Your goal**: build a chatbot that matches patient questions to the right FAQ
using *meaning*, not just shared words.

---

## Three Stages

### Stage 1 — TF-IDF Baseline (keyword sophistication++)

TF-IDF counts tokens, weighted by how distinctive they are across the corpus.
It still fails when query and FAQ share no tokens, but it beats exact rules.

### Stage 2 — Sentence Embeddings (semantic matching)

A pre-trained sentence transformer encodes any text as a 384-dimension vector
where semantically similar sentences are geometrically close.

```
"Can I reschedule my check-up?"       → [0.12, -0.34, …, 0.07]   ← 384 floats
"How do I book or change an appointment?" → [0.14, -0.31, …, 0.09]   ← nearby!
```

Finding the best-matching FAQ becomes: encode the query → compute cosine
similarity against all FAQ embeddings → return the closest one.

### Stage 3 — Chatbot Session

Wrap Stage 2 in a conversational loop that:
- Keeps a short memory of recent exchanges
- Handles low-confidence queries gracefully ("I'm not sure — please call us")
- Logs every interaction for later review

---

## Directory Structure

```
project6/
├── README.md               ← you are here
├── rubric.md               ← grading criteria
├── requirements.txt
│
├── data/
│   ├── generate_dataset.py ← run this first
│   ├── faqs.csv            ← 60 FAQs across 6 categories
│   └── test_queries.csv    ← 120 test queries with ground-truth FAQ IDs
│
└── starter/
    ├── schemas.py          ← Pydantic output schemas  (DO NOT MODIFY)
    ├── preprocess.py       ← text cleaning            (Task 1)
    ├── tfidf_matcher.py    ← TF-IDF baseline          (Task 2)
    ├── semantic_matcher.py ← sentence embeddings      (Tasks 3–5)
    ├── chatbot.py          ← chatbot session           (Tasks 6–7)
    ├── evaluate.py         ← metrics                  (Task 8)
    └── main.py             ← run everything
```

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Generate the dataset

```bash
python data/generate_dataset.py
# Creates: data/faqs.csv  (60 rows)
#          data/test_queries.csv  (120 rows)
```

Open both files before writing any code.  Notice how the test queries use
completely different words from the FAQ questions — that is the challenge.

### 3. Run the evaluation (requires your implementations)

```bash
# Evaluate both matchers on the test set
python starter/main.py --mode eval

# Run the interactive chatbot
python starter/main.py --mode chat
```

---

## Student Tasks (8 TODOs)

| Task | File | What to implement |
|---|---|---|
| **1** | `preprocess.py` | `clean_text()` — lowercase, remove punctuation, remove stopwords |
| **2** | `tfidf_matcher.py` | `TFIDFMatcher.fit()` and `find_best_match()` |
| **3** | `semantic_matcher.py` | `SemanticMatcher.__init__()` — load the sentence-transformer model |
| **4** | `semantic_matcher.py` | `SemanticMatcher.fit()` — encode all FAQ questions into vectors |
| **5** | `semantic_matcher.py` | `SemanticMatcher.find_best_match()` — cosine similarity search |
| **6** | `semantic_matcher.py` | `SemanticMatcher.find_top_k()` — return top-K matches with scores |
| **7** | `chatbot.py` | `ChatSession.respond()` — full session logic with confidence gate |
| **8** | `evaluate.py` | `accuracy_at_k()` — compute Top-K accuracy from results list |

---

## Core Concepts

### What is TF-IDF?

**TF** (Term Frequency): how often a word appears in *this* document.
**IDF** (Inverse Document Frequency): how rare the word is across *all* documents.

A word like "the" has high TF everywhere but near-zero IDF — so it gets
down-weighted.  A word like "angioplasty" is rare → high IDF → high weight.

TF-IDF turns a text into a sparse vector (one dimension per vocabulary word).
Cosine similarity then measures the angle between two such vectors.

**Key limitation**: if the query uses "reschedule" and the FAQ uses "appointment",
their TF-IDF vectors share zero dimensions → similarity = 0.

### What is a Sentence Embedding?

A sentence transformer is a pre-trained neural network that converts any
sentence into a fixed-size dense vector (384 floats in our case).

The network was trained on millions of sentence pairs so that sentences with
similar *meaning* end up with similar vectors — regardless of word choice.

```
Sentence A: "How do I book an appointment?"
Sentence B: "Can I reschedule my check-up?"
Sentence C: "What is the capital of France?"

cos_sim(A, B) ≈ 0.82   ← same meaning, different words
cos_sim(A, C) ≈ 0.07   ← unrelated topics
```

You don't train this network — you load it once and use it to encode text.

### What is Cosine Similarity?

Given two vectors **u** and **v**:

```
cosine_similarity(u, v) = (u · v) / (||u|| × ||v||)
```

- Result is between –1 and +1 (for embeddings, always 0 to 1).
- 1.0 → identical meaning
- 0.5 → somewhat related
- 0.0 → unrelated

For FAQ matching: encode the query → compute cosine similarity with every
FAQ embedding → the FAQ with the highest score is the best match.

### What is a Confidence Threshold?

Not every query has a matching FAQ.  A patient might ask "Do you accept
cryptocurrency?" — there is no relevant FAQ.

Without a threshold, the chatbot always returns the "closest" FAQ, even if
it's completely unrelated (low similarity score).

A confidence threshold says: *"If the best-match score is below X, say 'I
don't know' instead of returning a wrong answer."*

Choosing the threshold is a trade-off:
- **Too low** → chatbot answers wrong questions (embarrassing)
- **Too high** → chatbot says "I don't know" too often (unhelpful)

---

## Experiments to Run

### Experiment 1: TF-IDF vs Semantic — Side-by-Side

Run both matchers on the full test set and compare Top-1 accuracy:

```python
# Expected pattern:
# TF-IDF:   good on "easy" queries (direct paraphrase), poor on "hard" queries
# Semantic: good on both easy AND hard queries (handles vocabulary mismatch)
```

Find 3 examples where TF-IDF fails but semantic succeeds.
Find 1 example (if any) where TF-IDF beats semantic — what's special about it?

### Experiment 2: Threshold Sweep

```python
for threshold in [0.3, 0.4, 0.5, 0.6, 0.7, 0.8]:
    # Measure:
    #   answered_rate = fraction of queries that get an answer (not "I don't know")
    #   accuracy_when_answered = Top-1 accuracy on those answered queries
    #   out_of_scope_rejection_rate = fraction of OOS queries correctly refused
```

Plot answered_rate and accuracy vs threshold.  What threshold gives the
best balance?

### Experiment 3: Category Breakdown

The test set has queries from 6 categories.  For each category, report Top-1
accuracy for both matchers.  Which category is hardest?  Why?

```
Categories: appointments, billing, medications, test_results, visiting, emergency
```

**Expected finding**: "emergency" queries likely score highest (medical urgency
vocabulary is distinct); "billing" queries are harder (many synonyms for money/payment).

### Experiment 4: Top-K vs Top-1

A chatbot can show the user the top-3 matching FAQs and let them pick.
Compare Top-1 accuracy vs Top-3 accuracy for the semantic matcher.

**Question**: Is the correct FAQ usually in the Top-3 even when it's not Top-1?
If yes, offering "Did you mean one of these?" as a fallback makes sense.

---

## Output Format

All matcher results are serialised as `ChatbotResponse` (see `schemas.py`):

```json
{
  "query_id": "Q-00042",
  "query_text": "Can I reschedule my check-up for next week?",
  "matcher_used": "semantic",
  "answered": true,
  "confidence": 0.83,
  "threshold_used": 0.50,
  "top_match": {
    "faq_id": "FAQ-003",
    "category": "appointments",
    "question": "How do I book or change an appointment?",
    "answer": "Call our scheduling line at 555-0100 or use the online portal. Changes require 24 hours notice.",
    "similarity_score": 0.83
  },
  "runner_up_matches": [
    {"faq_id": "FAQ-004", "question": "What is your cancellation policy?", "similarity_score": 0.61},
    {"faq_id": "FAQ-007", "question": "Do I need a referral for a specialist?", "similarity_score": 0.44}
  ],
  "fallback_message": null
}
```

When the best match is below threshold:

```json
{
  "query_id": "Q-00099",
  "query_text": "Do you accept cryptocurrency?",
  "matcher_used": "semantic",
  "answered": false,
  "confidence": 0.21,
  "threshold_used": 0.50,
  "top_match": null,
  "runner_up_matches": [],
  "fallback_message": "I'm not sure about that — please call our helpline at 555-0199 or speak to a staff member."
}
```

---

## Report Structure (≤ 3 pages)

1. **Dataset analysis** — FAQ category distribution; example of an "easy"
   query vs a "hard" query; what makes the hard queries hard?

2. **TF-IDF vs Semantic comparison** — accuracy table broken down by
   difficulty (easy / hard / out-of-scope).  Three examples where semantic
   wins.  One example where TF-IDF is competitive.

3. **Threshold analysis** — your threshold sweep plot; chosen threshold and
   justification.

4. **Conclusion** — one paragraph: would you deploy this chatbot in production?
   What would you add next (e.g., LLM-generated answers, escalation to human)?

---

## Grading

See [rubric.md](rubric.md) for the full breakdown (100 pts + 10 bonus).

| Milestone | Points |
|---|---|
| Task 1 — preprocessing | 10 |
| Task 2 — TF-IDF matcher | 15 |
| Tasks 3–5 — semantic matcher core | 25 |
| Task 6 — Top-K retrieval | 10 |
| Task 7 — chatbot session | 15 |
| Task 8 — evaluation metric | 10 |
| Report | 15 |
| Bonus: threshold sweep plot | +5 |
| Bonus: category breakdown table | +5 |
