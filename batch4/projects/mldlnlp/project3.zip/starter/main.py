"""
Main Entry Point
================
Runs all three parts end-to-end:

  Part A – NER + NegEx on clinical notes
  Part B – LDA / NMF topic modeling on historical articles
  Part C – New topic detection on emerging articles + BERTopic comparison

Run:
    python main.py --part A          # NER + NegEx only
    python main.py --part B          # Topic modeling only
    python main.py --part C          # New topic detection only
    python main.py --part all        # Everything
    python main.py --part all --k 7  # Override number of LDA topics
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))

from evaluate import (
    evaluate_ner,
    evaluate_new_topic_detection,
    print_comparison_table,
    topic_coherence_sweep,
    topic_diversity,
)
from ner import GazetteerNER, ner_evaluation
from schemas import DocumentNEROutput, NegationStatus
from topic_model import (
    LDATopicModel,
    NMFTopicModel,
    cluster_novel_articles,
    detect_new_topics,
    extract_keywords_tfidf,
    extract_keywords_yake,
    preprocess_for_topics,
)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--part",     choices=["A", "B", "C", "all"], default="all")
    p.add_argument("--data_dir", default="data")
    p.add_argument("--out",      default="outputs")
    p.add_argument("--k",        type=int, default=5, help="Number of LDA topics")
    p.add_argument("--threshold",type=float, default=0.35,
                   help="Max-probability threshold for new topic detection")
    return p.parse_args()


# ---------------------------------------------------------------------------
# Part A – NER + NegEx
# ---------------------------------------------------------------------------

def run_part_a(data_dir: Path, out_dir: Path) -> None:
    notes_path = data_dir / "clinical_notes.csv"
    if not notes_path.exists():
        sys.exit(f"Dataset not found: {notes_path}\nRun: python data/generate_dataset.py")

    print("\n" + "="*60)
    print("  PART A — NER + NegEx on Clinical Notes")
    print("="*60)

    notes_df = pd.read_csv(notes_path)
    print(f"Loaded {len(notes_df)} clinical notes")

    ner = GazetteerNER(negex_window=6)
    all_results: list[DocumentNEROutput] = []

    for _, row in notes_df.iterrows():
        text = str(row["text"])
        try:
            entities = ner.extract(text, apply_negex=True)
        except Exception:
            entities = ner.extract(text, apply_negex=False)

        n_neg = sum(1 for e in entities if e.negation == NegationStatus.NEGATED)
        n_aff = sum(1 for e in entities if e.negation == NegationStatus.AFFIRMED)

        doc_out = DocumentNEROutput(
            doc_id      = str(row["note_id"]),
            source_text = text,
            entities    = entities,
            n_entities  = len(entities),
            n_negated   = n_neg,
            n_affirmed  = n_aff,
            model_used  = "negex+gazetteer",
        )
        all_results.append(doc_out)

    # Summary
    total_entities = sum(r.n_entities for r in all_results)
    total_negated  = sum(r.n_negated  for r in all_results)
    print(f"\n  Total entities found   : {total_entities}")
    print(f"  Total negated          : {total_negated} "
          f"({100*total_negated/max(1,total_entities):.1f}%)")

    # Show a few interesting examples
    print("\n  Sample extractions:")
    for r in all_results[:5]:
        if r.entities:
            print(f"\n  [{r.doc_id}] {r.source_text[:70]}")
            for e in r.entities:
                trig = f" (trigger: '{e.negation_trigger}')" if e.negation_trigger else ""
                print(f"    {e.text:<28} [{e.negation.value}]{trig}")

    # Save JSON output
    out_path = out_dir / "ner_results.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump([r.model_dump() for r in all_results], f, indent=2, default=str)
    print(f"\n  NER results saved -> {out_path}")

    # Basic negation breakdown by note type
    if "note_type" in notes_df.columns:
        print("\n  Negation rate by note type:")
        for r, (_, row) in zip(all_results, notes_df.iterrows()):
            pass  # student exercise: aggregate and print


# ---------------------------------------------------------------------------
# Part B – Topic Modeling
# ---------------------------------------------------------------------------

def run_part_b(data_dir: Path, out_dir: Path, k: int) -> LDATopicModel:
    hist_path = data_dir / "historical_articles.csv"
    if not hist_path.exists():
        sys.exit(f"Dataset not found: {hist_path}")

    print("\n" + "="*60)
    print(f"  PART B — Topic Modeling on Historical Articles (K={k})")
    print("="*60)

    hist_df = pd.read_csv(hist_path)
    print(f"Loaded {len(hist_df)} historical articles across "
          f"{hist_df['topic'].nunique()} true topics")

    texts_raw  = hist_df["full_text"].tolist()
    texts_proc = preprocess_for_topics(texts_raw)

    # Coherence sweep (optional — uncomment to run)
    # print("\n  Coherence sweep (K=2..9):")
    # coherence_df = topic_coherence_sweep(texts_proc, k_range=range(2, 10))

    # LDA
    print(f"\n  Training LDA (K={k}) ...")
    lda = LDATopicModel(n_topics=k, passes=15)
    lda.fit(texts_proc)
    coh = lda.coherence_score(texts_proc)
    descriptors = lda.to_topic_descriptors()

    print("\n  Discovered topics (top 8 words):")
    for d in descriptors:
        words = [tw.word for tw in d.top_words[:8]]
        print(f"  Topic {d.topic_id}: {words}")

    div = topic_diversity(descriptors)

    # Keyword extraction sample
    print("\n  Sample keywords (TF-IDF) from 3 articles:")
    for idx in [0, len(texts_raw)//2, -1]:
        kws = extract_keywords_tfidf(texts_proc, idx)
        print(f"  [{hist_df.iloc[idx]['topic']}] {kws[:5]}")

    # NMF comparison
    print("\n  Training NMF for comparison ...")
    nmf = NMFTopicModel(n_topics=k)
    nmf.fit(texts_proc)
    print("  NMF topic top words:")
    for i in range(k):
        terms = nmf.get_topic_terms(i, top_n=6)
        print(f"  Topic {i}: {[w for w,_ in terms]}")

    # Save topic assignments
    assignments = lda.assign_topics(hist_df["article_id"].tolist(), texts_proc)
    assign_path = out_dir / "topic_assignments_historical.json"
    with open(assign_path, "w", encoding="utf-8") as f:
        json.dump([a.model_dump() for a in assignments], f, indent=2)
    print(f"\n  Topic assignments saved -> {assign_path}")

    return lda


# ---------------------------------------------------------------------------
# Part C – New Topic Detection
# ---------------------------------------------------------------------------

def run_part_c(
    data_dir: Path,
    out_dir:  Path,
    lda_model: LDATopicModel,
    threshold: float,
) -> None:
    new_path = data_dir / "new_articles.csv"
    if not new_path.exists():
        sys.exit(f"Dataset not found: {new_path}")

    print("\n" + "="*60)
    print("  PART C — New Topic Detection")
    print("="*60)

    new_df     = pd.read_csv(new_path)
    texts_raw  = new_df["full_text"].tolist()
    texts_proc = preprocess_for_topics(texts_raw)
    doc_ids    = new_df["article_id"].tolist()

    print(f"Loaded {len(new_df)} new articles from {new_df['topic'].nunique()} "
          f"truly-novel topics:")
    print(f"  {new_df['topic'].value_counts().to_dict()}")

    try:
        alerts = detect_new_topics(doc_ids, texts_raw, texts_proc, lda_model, threshold)
        novel_alerts = [a for a in alerts if a.is_novel]

        print(f"\n  Flagged as novel: {len(novel_alerts)}/{len(alerts)} articles "
              f"(threshold={threshold})")

        if novel_alerts:
            print("  Sample novel alerts:")
            for a in novel_alerts[:3]:
                print(f"\n  [{a.doc_id}]")
                print(f"    max_prob={a.max_probability:.3f}  novel_terms={a.representative_terms}")
                print(f"    {a.alert_reason}")

        # Cluster novel articles to surface candidate new topics
        if novel_alerts:
            novel_texts = [
                texts_raw[doc_ids.index(a.doc_id)]
                for a in novel_alerts if a.doc_id in doc_ids
            ]
            labels = cluster_novel_articles(novel_texts, n_clusters=3)
            print(f"\n  Novel articles clustered into {len(set(labels))} candidate topics")

        # Evaluate
        metrics = evaluate_new_topic_detection(alerts, new_df)

        # Save alerts
        alerts_path = out_dir / "new_topic_alerts.json"
        with open(alerts_path, "w", encoding="utf-8") as f:
            json.dump([a.model_dump() for a in alerts], f, indent=2)
        print(f"\n  Alerts saved -> {alerts_path}")

    except NotImplementedError:
        print("  (detect_new_topics() not yet implemented — Task 8)")
        print("  Showing raw topic distributions on new articles instead:")
        assignments = lda_model.assign_topics(doc_ids, texts_proc)
        for a in assignments[:6]:
            print(f"    [{a.doc_id}] max_prob={a.max_probability:.3f}  "
                  f"dominant_topic={a.dominant_topic_id}")
        print("  Notice: new articles have uniformly low max_probability (~0.2–0.35)")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    args     = parse_args()
    out_dir  = Path(args.out)
    data_dir = Path(args.data_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    lda_model = None

    if args.part in ("A", "all"):
        run_part_a(data_dir, out_dir)

    if args.part in ("B", "all"):
        lda_model = run_part_b(data_dir, out_dir, args.k)

    if args.part in ("C", "all"):
        if lda_model is None:
            # Build LDA if part B was skipped
            hist_df    = pd.read_csv(data_dir / "historical_articles.csv")
            texts_proc = preprocess_for_topics(hist_df["full_text"].tolist())
            lda_model  = LDATopicModel(n_topics=args.k, passes=15)
            lda_model.fit(texts_proc)
        run_part_c(data_dir, out_dir, lda_model, args.threshold)

    print(f"\nOutputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()
