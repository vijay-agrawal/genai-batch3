"""
Evaluation Utilities
====================
Three distinct evaluation tasks:

  Part A – NER + NegEx evaluation
    Entity-level precision, recall, F1.
    Critical sub-metric: NEGATION RECALL — how many truly negated entities
    did the system correctly classify as negated?
    A system with 0% negation recall is DANGEROUS in clinical IR.

  Part B – Topic model quality
    * Coherence (C_v) — are topic words semantically related?
    * Topic diversity  — do topics differ from each other?
    * Perplexity      — how well does the model explain held-out documents?

  Part C – New topic detection
    * Precision@novel — of flagged documents, what fraction were truly new topics?
    * Recall@novel    — of truly new documents, what fraction were flagged?
    * F1@novel        — harmonic mean
    (Uses the 'topic' column in new_articles.csv as ground-truth label)
"""

from __future__ import annotations

from typing import Optional

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


# ============================================================
# Part A – NER + NegEx evaluation
# ============================================================

def evaluate_ner(
    pred_df: pd.DataFrame,    # columns: doc_id, entity_text, entity_type, negation
    gold_df: pd.DataFrame,    # columns: doc_id, entity_text, negation  (gold annotations)
    model_name: str = "system",
) -> dict:
    """
    Compute entity-level and negation-level metrics.

    Matching criterion: same doc_id AND lower-cased entity_text.
    """
    # Build (doc_id, entity_text_lower) sets
    pred_set = set(
        zip(pred_df["doc_id"], pred_df["entity_text"].str.lower())
    )
    gold_set = set(
        zip(gold_df["doc_id"], gold_df["entity_text"].str.lower())
    )

    tp  = len(pred_set & gold_set)
    fp  = len(pred_set - gold_set)
    fn  = len(gold_set - pred_set)
    prec = tp / (tp + fp) if (tp + fp) else 0.0
    rec  = tp / (tp + fn) if (tp + fn) else 0.0
    f1   = 2*prec*rec/(prec+rec) if (prec+rec) else 0.0

    # Negation sub-metric: entities correctly marked as NEGATED
    pred_neg = set(zip(
        pred_df[pred_df["negation"] == "negated"]["doc_id"],
        pred_df[pred_df["negation"] == "negated"]["entity_text"].str.lower(),
    ))
    gold_neg = set(zip(
        gold_df[gold_df["negation"] == "negated"]["doc_id"],
        gold_df[gold_df["negation"] == "negated"]["entity_text"].str.lower(),
    ))

    neg_tp = len(pred_neg & gold_neg)
    neg_fp = len(pred_neg - gold_neg)
    neg_fn = len(gold_neg - pred_neg)
    neg_prec = neg_tp / (neg_tp + neg_fp) if (neg_tp + neg_fp) else 0.0
    neg_rec  = neg_tp / (neg_tp + neg_fn) if (neg_tp + neg_fn) else 0.0
    neg_f1   = 2*neg_prec*neg_rec/(neg_prec+neg_rec) if (neg_prec+neg_rec) else 0.0

    pseudo_correct = _evaluate_pseudo_negation(pred_df, gold_df)

    print(f"\n{'='*55}")
    print(f"  NER Evaluation: {model_name}")
    print(f"{'='*55}")
    print(f"  Entity F1        : {f1:.4f}  (P={prec:.4f}  R={rec:.4f})")
    print(f"  Negation F1      : {neg_f1:.4f}  (P={neg_prec:.4f}  R={neg_rec:.4f})")
    print(f"  Negation recall  : {neg_rec:.4f}  (missed: {neg_fn} negated entities)")
    print(f"  Pseudo-neg correct: {pseudo_correct['correct']}/{pseudo_correct['total']}")
    if neg_rec < 0.70:
        print("  *** WARNING: negation recall < 0.70 — clinically unsafe ***")

    return dict(
        model=model_name, precision=prec, recall=rec, f1=f1,
        neg_precision=neg_prec, neg_recall=neg_rec, neg_f1=neg_f1,
        neg_tp=neg_tp, neg_fp=neg_fp, neg_fn=neg_fn,
        pseudo_negation_accuracy=pseudo_correct,
    )


def _evaluate_pseudo_negation(
    pred_df: pd.DataFrame,
    gold_df: pd.DataFrame,
) -> dict:
    """
    Check that pseudo-negated entities (e.g., 'no change in hypertension')
    are NOT marked as negated (gold label = 'affirmed').
    """
    gold_pseudo = gold_df[gold_df.get("note_type", "") == "pseudo_negated"] \
        if "note_type" in gold_df.columns else pd.DataFrame()
    if gold_pseudo.empty:
        return {"correct": 0, "total": 0}
    total = len(gold_pseudo)
    correct = sum(
        1 for _, row in gold_pseudo.iterrows()
        if not (
            (pred_df["doc_id"] == row.get("doc_id", "")) &
            (pred_df["entity_text"].str.lower() == str(row.get("entity_text", "")).lower()) &
            (pred_df["negation"] == "negated")
        ).any()
    )
    return {"correct": correct, "total": total}


# ============================================================
# Part B – Topic model evaluation
# ============================================================

def topic_coherence_sweep(
    texts:        list[str],
    k_range:      range = range(2, 10),
    model_class=None,
) -> pd.DataFrame:
    """
    Train LDA for each K in k_range and record coherence.
    Plot the elbow curve to identify optimal K.

    TODO (Student Task 7):
    Run this function and include the plot in your report.
    Explain why you chose the K you did for Part B experiments.
    """
    from topic_model import LDATopicModel
    if model_class is None:
        model_class = LDATopicModel

    rows = []
    for k in k_range:
        print(f"  Fitting K={k} ...", end="", flush=True)
        m = model_class(n_topics=k, passes=10)
        m.fit(texts)
        coh = m.coherence_score(texts)
        rows.append({"K": k, "coherence_cv": round(coh, 4)})
        print(f" coherence={coh:.4f}")

    df = pd.DataFrame(rows)
    _plot_coherence(df)
    return df


def topic_diversity(topic_descriptors: list) -> float:
    """
    Compute topic diversity as the fraction of unique top-10 words across topics.
    Diversity ∈ [0, 1]; higher = topics are more distinct.
    Diversity < 0.6 suggests over-similar or redundant topics (K may be too high).
    """
    all_words = []
    for t in topic_descriptors:
        all_words.extend([tw.word for tw in t.top_words[:10]])
    if not all_words:
        return 0.0
    div = len(set(all_words)) / len(all_words)
    print(f"Topic diversity: {div:.4f}  ({len(set(all_words))} unique / {len(all_words)} total top-10 words)")
    return div


def _plot_coherence(df: pd.DataFrame) -> None:
    plt.figure(figsize=(7, 4))
    plt.plot(df["K"], df["coherence_cv"], marker="o", color="steelblue")
    plt.xlabel("Number of topics (K)")
    plt.ylabel("C_v coherence")
    plt.title("LDA Coherence vs K — pick the elbow")
    plt.tight_layout()
    plt.show()


# ============================================================
# Part C – New topic detection evaluation
# ============================================================

def evaluate_new_topic_detection(
    alerts:     list,         # list of NewTopicAlert
    new_df:     pd.DataFrame, # new_articles.csv with 'topic' column
) -> dict:
    """
    Evaluate new topic detection against ground-truth article topics.

    Ground truth: articles in new_articles.csv are ALL novel (topic not in
    historical corpus).  Historical articles are ALL known.
    """
    from schemas import NewTopicAlert

    # Build lookup
    id_to_true_novel = {
        row["article_id"]: True   # all new_articles are truly novel
        for _, row in new_df.iterrows()
    }

    y_true = []
    y_pred = []
    for alert in alerts:
        true_novel = id_to_true_novel.get(alert.doc_id, False)
        y_true.append(int(true_novel))
        y_pred.append(int(alert.is_novel))

    tp = sum(t == 1 and p == 1 for t, p in zip(y_true, y_pred))
    fp = sum(t == 0 and p == 1 for t, p in zip(y_true, y_pred))
    fn = sum(t == 1 and p == 0 for t, p in zip(y_true, y_pred))

    prec = tp / (tp + fp) if (tp + fp) else 0.0
    rec  = tp / (tp + fn) if (tp + fn) else 0.0
    f1   = 2*prec*rec/(prec+rec) if (prec+rec) else 0.0

    # Score distribution analysis
    scores = [a.max_probability for a in alerts]
    mean_score = np.mean(scores)

    print(f"\n{'='*55}")
    print(f"  New Topic Detection")
    print(f"{'='*55}")
    print(f"  Precision : {prec:.4f}")
    print(f"  Recall    : {rec:.4f}")
    print(f"  F1        : {f1:.4f}")
    print(f"  TP={tp}  FP={fp}  FN={fn}")
    print(f"  Mean max-topic-prob: {mean_score:.4f}  "
          f"(lower = more confidently novel)")

    # Per-true-topic breakdown
    true_topic_col = "topic" if "topic" in new_df.columns else None
    if true_topic_col:
        print("\n  Per-true-topic recall:")
        alert_map = {a.doc_id: a.is_novel for a in alerts}
        for topic, grp in new_df.groupby(true_topic_col):
            flagged = sum(alert_map.get(r["article_id"], False) for _, r in grp.iterrows())
            print(f"    {topic:<25} {flagged}/{len(grp)} flagged")

    return dict(precision=prec, recall=rec, f1=f1, tp=tp, fp=fp, fn=fn,
                mean_max_prob=mean_score)


# ============================================================
# Comparison table
# ============================================================

def print_comparison_table(
    ner_metrics:   list[dict],
    topic_metrics: list[dict],
) -> None:
    """Print side-by-side NER and topic quality comparisons."""

    if ner_metrics:
        print("\n  NER COMPARISON")
        print(f"  {'Model':<20} {'F1':>7} {'Neg-Rec':>9} {'Pseudo-OK':>10}")
        print("  " + "-"*50)
        for m in ner_metrics:
            ps = m.get("pseudo_negation_accuracy", {})
            ps_str = f"{ps.get('correct','-')}/{ps.get('total','-')}"
            print(f"  {m['model']:<20} {m['f1']:>7.4f} {m['neg_recall']:>9.4f} {ps_str:>10}")

    if topic_metrics:
        print("\n  TOPIC MODEL COMPARISON")
        print(f"  {'Model':<20} {'Coherence':>10} {'Diversity':>10}")
        print("  " + "-"*42)
        for m in topic_metrics:
            print(f"  {m.get('model','?'):<20} "
                  f"{m.get('coherence',float('nan')):>10.4f} "
                  f"{m.get('diversity',float('nan')):>10.4f}")
