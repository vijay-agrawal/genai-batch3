"""
Topic Modeling & New Topic Discovery
=====================================
Implements three complementary topic modeling approaches and a principled
new-topic detection pipeline.

  Model 1 – LDA (Latent Dirichlet Allocation)
    Classical generative model.  Each document = mixture of topics;
    each topic = distribution over words.
    Pros: interpretable, fast, well-studied, coherence metrics available.
    Cons: bag-of-words (no semantics), requires fixed K, sensitive to preprocessing.

  Model 2 – NMF (Non-negative Matrix Factorization)
    Matrix factorisation approach on TF-IDF matrix.
    Pros: often produces cleaner topics than LDA on short texts,
          faster to train, easier to initialise.
    Cons: not a generative model, no probabilistic coherence metric.

  Model 3 – BERTopic
    Transformer embeddings + UMAP + HDBSCAN + c-TF-IDF.
    Pros: semantically rich topics, handles short texts well,
          automatically detects outliers (noise/novel topics as cluster -1).
    Cons: requires GPU for speed, UMAP is stochastic, harder to reproduce.

NEW TOPIC DETECTION PIPELINE:
  Step 1: Train LDA(K=5) on historical articles.
  Step 2: For each new article, compute document-topic distribution.
  Step 3: Flag articles where max_probability < NOVELTY_THRESHOLD.
          These are "poorly explained" by historical topics.
  Step 4: Cluster the flagged articles with KMeans or BERTopic.
  Step 5: Each discovered cluster is a candidate new topic.
  Step 6: Retrain LDA(K=8) on combined corpus to confirm.

STUDENT TASKS:
  Task 7  – Tune LDA hyperparameters (K, alpha, eta) using coherence score
  Task 8  – Implement new_topic_detector() using the perplexity / max-prob signal
  Task 9  – Run BERTopic and compare topic quality with LDA
  Task 10 – Visualise topic space with pyLDAvis and/or t-SNE
"""

from __future__ import annotations

import re
import string
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.decomposition import NMF
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

from schemas import NewTopicAlert, TopicAssignment, TopicDescriptor, TopicSource, TopicWord

# ---------------------------------------------------------------------------
# Text preprocessing for topic models
# ---------------------------------------------------------------------------

try:
    import nltk
    nltk.data.find("corpora/stopwords")
    from nltk.corpus import stopwords as _sw
    STOPWORDS = set(_sw.words("english"))
except LookupError:
    import subprocess, sys
    subprocess.run([sys.executable, "-m", "nltk.downloader", "stopwords", "-q"])
    from nltk.corpus import stopwords as _sw
    STOPWORDS = set(_sw.words("english"))

# Domain-specific stop words that add no topic signal in medical literature
MEDICAL_STOPWORDS = {
    "patient", "patients", "study", "studies", "results", "methods",
    "conclusion", "objective", "background", "compared", "significant",
    "observed", "identified", "using", "used", "analysis", "data",
    "clinical", "treatment", "therapy", "associated", "based",
    "higher", "lower", "increased", "decreased", "versus", "among",
    "within", "between", "shown", "demonstrated",
}

ALL_STOPWORDS = STOPWORDS | MEDICAL_STOPWORDS


def preprocess_for_topics(texts: list[str], min_word_len: int = 3) -> list[str]:
    """
    Clean text for topic modeling:
      - Lowercase
      - Remove punctuation and numbers
      - Remove stopwords (English + medical)
      - Keep only words of min_word_len characters

    Returns processed strings (bag of words).
    """
    processed = []
    for text in texts:
        text = text.lower()
        text = re.sub(r"\d+", " ", text)
        text = text.translate(str.maketrans("", "", string.punctuation))
        tokens = [
            w for w in text.split()
            if len(w) >= min_word_len and w not in ALL_STOPWORDS
        ]
        processed.append(" ".join(tokens))
    return processed


# ---------------------------------------------------------------------------
# Model 1 – LDA
# ---------------------------------------------------------------------------

class LDATopicModel:
    """
    Latent Dirichlet Allocation using Gensim.

    HYPERPARAMETERS (students must tune — Task 7):
      n_topics (K): number of topics.  Start with K=5 for historical corpus,
                    try K=6,7,8 and pick the K that maximises C_v coherence.
                    Rule of thumb: too few K → broad, overlapping topics;
                    too many K → split topics that should be together.

      alpha: document-topic prior (Dirichlet).
             'auto' = let Gensim learn it; or try 0.01 (sparse) to 1.0 (dense).
             Sparse alpha → documents dominated by 1–2 topics (good for short articles).

      eta (beta): topic-word prior.
             'auto' or 0.01 (sparse).
             Sparse eta → topics dominated by fewer, sharper words.

      passes: number of training passes over the corpus.  Higher → better
              convergence but slower.  Start at 10; increase to 30 for final runs.
    """

    def __init__(
        self,
        n_topics: int   = 5,
        alpha:    float = 0.1,    # try 'auto', 0.01, 0.1, 1.0
        eta:      float = 0.01,   # try 'auto', 0.01, 0.1
        passes:   int   = 15,
        random_state: int = 42,
    ):
        self.n_topics     = n_topics
        self.alpha        = alpha
        self.eta          = eta
        self.passes       = passes
        self.random_state = random_state
        self._model       = None
        self._dictionary  = None
        self._corpus      = None

    def fit(self, texts: list[str]) -> "LDATopicModel":
        """
        Train LDA on a list of preprocessed text strings.
        MUST be called only on the training (historical) corpus.
        """
        from gensim import corpora
        from gensim.models import LdaMulticore

        tokenised        = [t.split() for t in texts]
        self._dictionary = corpora.Dictionary(tokenised)
        self._dictionary.filter_extremes(no_below=2, no_above=0.90)
        self._corpus     = [self._dictionary.doc2bow(t) for t in tokenised]

        self._model = LdaMulticore(
            corpus          = self._corpus,
            id2word         = self._dictionary,
            num_topics      = self.n_topics,
            alpha           = self.alpha,
            eta             = self.eta,
            passes          = self.passes,
            random_state    = self.random_state,
            workers         = 2,
        )
        print(
            f"[LDA] Trained K={self.n_topics} topics on {len(texts)} documents. "
            f"Vocab size: {len(self._dictionary)}"
        )
        return self

    def get_document_topics(
        self,
        texts: list[str],
        minimum_probability: float = 0.0,
    ) -> list[list[tuple[int, float]]]:
        """
        Return topic distributions for a list of new texts.
        Each element is [(topic_id, probability), ...] sorted by probability desc.
        """
        if self._model is None:
            raise RuntimeError("Call fit() first.")
        results = []
        for text in texts:
            bow    = self._dictionary.doc2bow(text.split())
            topics = self._model.get_document_topics(
                bow, minimum_probability=minimum_probability
            )
            topics = sorted(topics, key=lambda x: -x[1])
            results.append(topics)
        return results

    def get_topic_terms(self, topic_id: int, top_n: int = 10) -> list[tuple[str, float]]:
        """Return [(word, weight), ...] for the given topic."""
        if self._model is None:
            raise RuntimeError("Call fit() first.")
        return [
            (self._dictionary[int(wid)], float(prob))
            for wid, prob in self._model.get_topic_terms(topic_id, topn=top_n)
        ]

    def coherence_score(self, texts: list[str], metric: str = "c_v") -> float:
        """
        Compute topic coherence (C_v metric recommended).

        C_v ∈ [0, 1]:
          > 0.55 = reasonable  |  > 0.65 = good  |  > 0.75 = very good

        TODO (Student Task 7):
          Run coherence_score() for K in range(3, 10) and plot the results.
          The K with the highest C_v score is the best number of topics.
          Report this plot in your analysis.
        """
        from gensim.models import CoherenceModel
        tokenised = [t.split() for t in texts]
        cm = CoherenceModel(
            model      = self._model,
            texts      = tokenised,
            dictionary = self._dictionary,
            coherence  = metric,
        )
        score = cm.get_coherence()
        print(f"[LDA] Coherence ({metric}) = {score:.4f}")
        return score

    def to_topic_descriptors(self) -> list[TopicDescriptor]:
        """Convert trained model topics to Pydantic TopicDescriptor objects."""
        descriptors = []
        for i in range(self.n_topics):
            terms = self.get_topic_terms(i, top_n=10)
            descriptors.append(TopicDescriptor(
                topic_id    = i,
                top_words   = [TopicWord(word=w, weight=round(p, 4)) for w, p in terms],
                source      = TopicSource.HISTORICAL,
            ))
        return descriptors

    def assign_topics(
        self,
        doc_ids: list[str],
        texts:   list[str],
    ) -> list[TopicAssignment]:
        """Produce Pydantic TopicAssignment for each document."""
        distributions = self.get_document_topics(texts)
        assignments   = []
        for doc_id, dist in zip(doc_ids, distributions):
            if not dist:
                # Empty document / all OOV
                dist = [(0, 1.0)]
            dist_dict    = {int(t): round(float(p), 4) for t, p in dist}
            # Ensure all topics represented (some may be zero)
            for k in range(self.n_topics):
                dist_dict.setdefault(k, 0.0)
            # Normalise to sum=1.0
            total = sum(dist_dict.values())
            if total > 0:
                dist_dict = {k: round(v / total, 4) for k, v in dist_dict.items()}
            dom_topic = max(dist_dict, key=dist_dict.get)
            assignments.append(TopicAssignment(
                doc_id              = doc_id,
                dominant_topic_id   = dom_topic,
                topic_distribution  = dist_dict,
                max_probability     = dist_dict[dom_topic],
                model_used          = "lda",
            ))
        return assignments


# ---------------------------------------------------------------------------
# Model 2 – NMF  (sklearn)
# ---------------------------------------------------------------------------

class NMFTopicModel:
    """
    Non-negative Matrix Factorization on TF-IDF vectors.

    Preferred over LDA for:
      * Very short texts (tweets, titles, abstracts)
      * When you want sharper, less-overlapping topics
      * When training speed matters more than probabilistic output

    NOTE: NMF does not produce a true probability distribution.
    The document-component matrix H is normalised to [0,1] per row to simulate
    topic proportions, but this is an approximation.
    """

    def __init__(self, n_topics: int = 5, max_features: int = 5000, random_state: int = 42):
        self.n_topics     = n_topics
        self._vectoriser  = TfidfVectorizer(
            max_features = max_features, ngram_range=(1, 2),
            min_df=2, max_df=0.90,
        )
        self._nmf = NMF(
            n_components = n_topics, random_state=random_state, max_iter=400
        )
        self._feature_names: list[str] = []

    def fit(self, texts: list[str]) -> "NMFTopicModel":
        X = self._vectoriser.fit_transform(texts)
        self._nmf.fit(X)
        self._feature_names = self._vectoriser.get_feature_names_out().tolist()
        print(f"[NMF] Trained K={self.n_topics} topics on {len(texts)} documents.")
        return self

    def get_topic_terms(self, topic_id: int, top_n: int = 10) -> list[tuple[str, float]]:
        comp = self._nmf.components_[topic_id]
        top  = comp.argsort()[-top_n:][::-1]
        return [(self._feature_names[i], float(comp[i])) for i in top]

    def transform(self, texts: list[str]) -> np.ndarray:
        X = self._vectoriser.transform(texts)
        H = self._nmf.transform(X)
        # Normalise each row to sum=1 for pseudo-probability
        row_sums = H.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1
        return H / row_sums

    def assign_topics(
        self,
        doc_ids: list[str],
        texts:   list[str],
    ) -> list[TopicAssignment]:
        H = self.transform(texts)
        assignments = []
        for i, doc_id in enumerate(doc_ids):
            probs     = {k: round(float(H[i, k]), 4) for k in range(self.n_topics)}
            dom_topic = int(H[i].argmax())
            assignments.append(TopicAssignment(
                doc_id             = doc_id,
                dominant_topic_id  = dom_topic,
                topic_distribution = probs,
                max_probability    = probs[dom_topic],
                model_used         = "nmf",
            ))
        return assignments


# ---------------------------------------------------------------------------
# Model 3 – BERTopic stub
# ---------------------------------------------------------------------------

class BERTopicModel:
    """
    BERTopic: transformer embeddings + UMAP + HDBSCAN + c-TF-IDF.

    BERTopic's key advantage for this project:
      * Documents that don't cluster with any topic get label=-1 (noise).
      * This is a direct "new topic" signal — no threshold tuning needed.
      * After fitting, new articles get topic=-1 if they don't fit.

    TODO (Student Task 9):
    Implement fit() and assign_topics() using the BERTopic library.

    from bertopic import BERTopic
    from sentence_transformers import SentenceTransformer

    embedding_model = SentenceTransformer("all-MiniLM-L6-v2")
    topic_model = BERTopic(
        embedding_model    = embedding_model,
        nr_topics          = "auto",          # let BERTopic decide
        min_topic_size     = 5,
        calculate_probabilities = True,
    )
    topics, probs = topic_model.fit_transform(texts)

    # topics[i] == -1 → document i is an outlier (potential new topic)
    # Use topic_model.get_topic_info() to inspect discovered topics.

    COMPARISON WITH LDA:
    After implementing, create a table comparing:
      * Number of topics discovered
      * Coherence of top words per topic
      * How many new_articles get flagged as novel vs. LDA
      * Qualitative assessment: do the topic labels make clinical sense?
    """

    def __init__(self):
        self._model = None

    def fit(self, texts: list[str]) -> "BERTopicModel":
        raise NotImplementedError("Implement BERTopicModel.fit() — see docstring.")

    def assign_topics(
        self,
        doc_ids: list[str],
        texts:   list[str],
    ) -> tuple[list[TopicAssignment], list[int]]:
        """Returns (assignments, raw_topic_ids); raw_topic_id == -1 means novel."""
        raise NotImplementedError("Implement BERTopicModel.assign_topics() — see docstring.")


# ---------------------------------------------------------------------------
# New Topic Detection
# ---------------------------------------------------------------------------

NOVELTY_THRESHOLD = 0.35   # max topic probability below this → potential new topic


def detect_new_topics(
    new_doc_ids:   list[str],
    new_texts_raw: list[str],
    new_texts_proc: list[str],
    lda_model:     LDATopicModel,
    threshold:     float = NOVELTY_THRESHOLD,
) -> list[NewTopicAlert]:
    """
    Flag new articles that are NOT well-explained by the historical LDA model.

    Algorithm:
      1. Get document-topic distributions for new articles.
      2. For each article: max_prob = max(distribution values).
      3. If max_prob < threshold → emit NewTopicAlert with is_novel=True.
      4. Compute per-document top TF-IDF terms vs historical vocabulary
         to surface the "new" vocabulary driving the novelty signal.

    TODO (Student Task 8):
    The current implementation is a stub.  Implement it following the steps:

      assignments = lda_model.assign_topics(new_doc_ids, new_texts_proc)
      alerts = []

      for i, (doc_id, text_raw, assignment) in enumerate(
              zip(new_doc_ids, new_texts_raw, assignments)):
          max_prob = assignment.max_probability
          is_novel = max_prob < threshold

          # Get representative terms: words in this document that are
          # NOT in the top-N most common words of the historical corpus.
          # Hint: use a TfidfVectorizer fitted on historical texts,
          # transform the new article, take the top-K terms.
          rep_terms = _get_novel_terms(text_raw, lda_model)  # implement below

          alerts.append(NewTopicAlert(
              doc_id               = doc_id,
              title                = text_raw[:80],
              max_probability      = round(max_prob, 4),
              novelty_threshold    = threshold,
              is_novel             = is_novel,
              representative_terms = rep_terms,
              alert_reason         = (
                  f"Max historical topic probability {max_prob:.3f} "
                  f"{'<' if is_novel else '>='} threshold {threshold}."
              ),
          ))
      return alerts
    """
    raise NotImplementedError(
        "Implement detect_new_topics() — see the step-by-step guide in the docstring."
    )


def _get_novel_terms(
    text:       str,
    lda_model:  LDATopicModel,
    top_k:      int = 5,
) -> list[str]:
    """
    Return the top-K terms in `text` that are NOT in the historical
    LDA dictionary (i.e., OOV terms that signal new vocabulary).
    """
    if lda_model._dictionary is None:
        return []
    known_words = set(lda_model._dictionary.values())
    tokens = [
        w.lower() for w in text.split()
        if len(w) > 3 and w.lower() not in ALL_STOPWORDS
    ]
    novel = [w for w in tokens if w not in known_words]
    # Deduplicate while preserving order
    seen, unique = set(), []
    for w in novel:
        if w not in seen:
            seen.add(w)
            unique.append(w)
    return unique[:top_k]


def cluster_novel_articles(
    novel_texts: list[str],
    n_clusters:  int = 3,
) -> np.ndarray:
    """
    Cluster the novel (unfitted) articles into candidate new topic groups.

    Uses TF-IDF + KMeans as a simple baseline.
    Students can replace KMeans with BERTopic for semantically richer clusters.

    Returns cluster label array of shape (n_novel,).
    """
    if not novel_texts:
        return np.array([], dtype=int)
    from sklearn.cluster import KMeans
    vec     = TfidfVectorizer(max_features=200, ngram_range=(1,2)).fit_transform(novel_texts)
    labels  = KMeans(n_clusters=n_clusters, random_state=42, n_init=10).fit_predict(vec)
    counts  = np.bincount(labels)
    print(f"[cluster_novel_articles] Cluster sizes: {counts.tolist()}")
    return labels


# ---------------------------------------------------------------------------
# Keyword extraction helpers
# ---------------------------------------------------------------------------

def extract_keywords_tfidf(
    texts:   list[str],
    doc_idx: int,
    top_k:   int = 8,
) -> list[str]:
    """Extract top TF-IDF keywords for a single document within a corpus."""
    vec   = TfidfVectorizer(max_features=2000, stop_words=list(ALL_STOPWORDS),
                            ngram_range=(1,2))
    matrix = vec.fit_transform(texts)
    names  = vec.get_feature_names_out()
    scores = matrix[doc_idx].toarray().flatten()
    top    = scores.argsort()[-top_k:][::-1]
    return [names[i] for i in top if scores[i] > 0]


def extract_keywords_yake(text: str, top_k: int = 8) -> list[tuple[str, float]]:
    """Extract keywords using YAKE (language-agnostic, unsupervised)."""
    try:
        import yake
        extractor = yake.KeywordExtractor(
            lan="en", n=2, dedupLim=0.7, top=top_k, features=None
        )
        return extractor.extract_keywords(text)   # [(keyword, score), ...]
    except ImportError:
        print("[YAKE] not installed. Run: pip install yake")
        return []


# ---------------------------------------------------------------------------
# Quick demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from pathlib import Path
    DATA = Path(__file__).parent.parent / "data"

    hist_path = DATA / "historical_articles.csv"
    new_path  = DATA / "new_articles.csv"

    if not hist_path.exists():
        print("Run: python data/generate_dataset.py")
    else:
        import pandas as pd

        hist_df = pd.read_csv(hist_path)
        new_df  = pd.read_csv(new_path)

        hist_texts_raw  = hist_df["full_text"].tolist()
        hist_texts_proc = preprocess_for_topics(hist_texts_raw)

        print(f"Fitting LDA(K=5) on {len(hist_texts_proc)} historical articles ...")
        lda = LDATopicModel(n_topics=5, passes=10)
        lda.fit(hist_texts_proc)

        print("\nHistorical topics:")
        for i in range(5):
            terms = lda.get_topic_terms(i, top_n=6)
            print(f"  Topic {i}: {[w for w, _ in terms]}")

        print("\nNew topic detection (requires Task 8 implementation):")
        new_texts_raw  = new_df["full_text"].tolist()
        new_texts_proc = preprocess_for_topics(new_texts_raw)
        new_ids        = new_df["article_id"].tolist()
        try:
            alerts = detect_new_topics(new_ids, new_texts_raw, new_texts_proc, lda)
            novel  = [a for a in alerts if a.is_novel]
            print(f"  {len(novel)}/{len(alerts)} new articles flagged as novel")
        except NotImplementedError:
            print("  (implement detect_new_topics first — Task 8)")
