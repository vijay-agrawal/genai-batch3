"""
Named Entity Recognition Pipeline
====================================
Three NER approaches, increasing in sophistication:

  Approach A – Gazetteer (rule-based dictionary lookup)
    Fast, deterministic, zero training data, zero GPU.
    Works well for known controlled vocabulary (e.g. drug names, ICD terms).
    Fails on spelling variants, context-dependent entities, novel terms.

  Approach B – spaCy NER
    Pre-trained en_core_web_sm model with optional custom components.
    General-purpose; does not recognise clinical entities out of the box
    unless fine-tuned on clinical corpora.

  Approach C – ClinicalBERT  (advanced — requires GPU/large download)
    emilyalsentzer/Bio_ClinicalBERT fine-tuned on clinical NER datasets.
    State-of-the-art for clinical NER but requires:
      * ~400 MB model download
      * Clinical NER training data (i2b2/n2c2, NCBI disease, MedNLI)
    Provided as a stub; students who want to explore this approach should
    use the HuggingFace `pipeline("ner", model="...")` interface.

PROS / CONS TABLE
  ┌────────────────┬───────────────┬──────────────┬───────────────┬─────────────────┐
  │                │ Speed         │ Recall       │ Precision     │ Novel entities  │
  ├────────────────┼───────────────┼──────────────┼───────────────┼─────────────────┤
  │ Gazetteer      │ Very fast     │ LOW (dict-bound) │ HIGH      │ MISSED          │
  │ spaCy          │ Fast          │ Medium       │ Medium        │ Some            │
  │ ClinicalBERT   │ Slow (GPU)    │ HIGH         │ HIGH          │ Handles well    │
  └────────────────┴───────────────┴──────────────┴───────────────┴─────────────────┘

TODO (Student Task 5):
  Extend the CLINICAL_GAZETTEER with at least 20 additional clinical entities.
  Use the clinical_notes.csv to identify which entities are currently MISSED
  (false negatives) and add them.

TODO (Student Task 6):
  Fine-tune spaCy on the (small) annotated subset of clinical_notes.csv.
  Compare entity-level F1 before and after fine-tuning.
"""

from __future__ import annotations

from typing import Optional

from schemas import ClinicalEntity, EntityType, NegationStatus
from negex import NegExProcessor


# ---------------------------------------------------------------------------
# Clinical gazetteer
# ---------------------------------------------------------------------------

CLINICAL_GAZETTEER: dict[str, EntityType] = {
    # Symptoms
    "fever":                EntityType.SYMPTOM,
    "cough":                EntityType.SYMPTOM,
    "chest pain":           EntityType.SYMPTOM,
    "shortness of breath":  EntityType.SYMPTOM,
    "dyspnoea":             EntityType.SYMPTOM,
    "dyspnea":              EntityType.SYMPTOM,
    "fatigue":              EntityType.SYMPTOM,
    "nausea":               EntityType.SYMPTOM,
    "vomiting":             EntityType.SYMPTOM,
    "headache":             EntityType.SYMPTOM,
    "dizziness":            EntityType.SYMPTOM,
    "syncope":              EntityType.SYMPTOM,
    "palpitations":         EntityType.SYMPTOM,
    "abdominal pain":       EntityType.SYMPTOM,
    "haemoptysis":          EntityType.SYMPTOM,
    "hemoptysis":           EntityType.SYMPTOM,

    # Conditions
    "hypertension":           EntityType.CONDITION,
    "diabetes mellitus":      EntityType.CONDITION,
    "atrial fibrillation":    EntityType.CONDITION,
    "heart failure":          EntityType.CONDITION,
    "pneumonia":              EntityType.CONDITION,
    "COVID-19":               EntityType.CONDITION,
    "SARS-CoV-2":             EntityType.CONDITION,
    "sepsis":                 EntityType.CONDITION,
    "anaemia":                EntityType.CONDITION,
    "anemia":                 EntityType.CONDITION,
    "hypothyroidism":         EntityType.CONDITION,
    "chronic kidney disease": EntityType.CONDITION,
    "COPD":                   EntityType.CONDITION,
    "asthma":                 EntityType.CONDITION,
    "stroke":                 EntityType.CONDITION,
    "deep vein thrombosis":   EntityType.CONDITION,
    "pulmonary embolism":     EntityType.CONDITION,

    # Drugs
    "metformin":          EntityType.DRUG,
    "aspirin":            EntityType.DRUG,
    "warfarin":           EntityType.DRUG,
    "lisinopril":         EntityType.DRUG,
    "atorvastatin":       EntityType.DRUG,
    "metoprolol":         EntityType.DRUG,
    "insulin":            EntityType.DRUG,
    "vancomycin":         EntityType.DRUG,
    "amoxicillin":        EntityType.DRUG,
    "paracetamol":        EntityType.DRUG,
    "ibuprofen":          EntityType.DRUG,
    "omeprazole":         EntityType.DRUG,

    # Procedures
    "echocardiogram":     EntityType.PROCEDURE,
    "CT scan":            EntityType.PROCEDURE,
    "MRI":                EntityType.PROCEDURE,
    "biopsy":             EntityType.PROCEDURE,
    "bronchoscopy":       EntityType.PROCEDURE,
    "colonoscopy":        EntityType.PROCEDURE,
    "blood culture":      EntityType.PROCEDURE,

    # Findings
    "consolidation":          EntityType.FINDING,
    "pleural effusion":       EntityType.FINDING,
    "ST depression":          EntityType.FINDING,
    "elevated troponin":      EntityType.FINDING,
    "bilateral infiltrates":  EntityType.FINDING,
    "lymphadenopathy":        EntityType.FINDING,
    "cardiomegaly":           EntityType.FINDING,

    # TODO (Student Task 5): add more entries here.
    # Useful sources: UMLS, SNOMED-CT, RxNorm, ICD-10
    # Minimum: 20 additional entries covering drugs, findings, and rare conditions
    # observed in the clinical_notes.csv.
}


# ---------------------------------------------------------------------------
# Approach A – Gazetteer NER
# ---------------------------------------------------------------------------

class GazetteerNER:
    """
    Exact-match dictionary lookup with case-insensitive matching.
    Handles multi-word entries (longest match first).
    Integrates with NegExProcessor to detect negated entities.
    """

    def __init__(self, negex_window: int = 6):
        # Sort by length descending for greedy longest-match
        self._entries = sorted(
            CLINICAL_GAZETTEER.items(), key=lambda x: -len(x[0])
        )
        self._negex = NegExProcessor(window=negex_window)

    def extract(self, text: str, apply_negex: bool = True) -> list[ClinicalEntity]:
        """
        Find all gazetteer entities in text, then apply NegEx.

        Parameters
        ----------
        text        : raw clinical note text
        apply_negex : if True, classify each entity's negation status

        Returns
        -------
        list of ClinicalEntity objects
        """
        import re as _re
        found: list[tuple[str, int, int, EntityType]] = []
        used_spans: list[tuple[int, int]] = []

        for phrase, etype in self._entries:
            pattern = _re.compile(
                r'\b' + _re.escape(phrase) + r'\b', _re.IGNORECASE
            )
            for m in pattern.finditer(text):
                s, e = m.start(), m.end()
                # No overlap with already-matched spans
                if any(s < eu and e > su for su, eu in used_spans):
                    continue
                found.append((m.group(0), s, e, etype))
                used_spans.append((s, e))

        # Sort by start position
        found.sort(key=lambda x: x[1])

        if not found:
            return []

        # Apply NegEx
        if apply_negex:
            try:
                negex_inputs = [(f[0], f[1], f[2]) for f in found]
                negex_results = self._negex.process_entities(text, negex_inputs)
                return [
                    ClinicalEntity(
                        text             = r.entity_text,
                        entity_type      = found[i][3],
                        negation         = r.status,
                        negation_trigger = r.trigger,
                        start_char       = r.entity_start,
                        end_char         = r.entity_end,
                        negex_window     = r.window_text,
                    )
                    for i, r in enumerate(negex_results)
                ]
            except NotImplementedError:
                # NegEx not implemented yet: return all as AFFIRMED
                pass

        return [
            ClinicalEntity(
                text        = f[0],
                entity_type = f[3],
                negation    = NegationStatus.AFFIRMED,
                start_char  = f[1],
                end_char    = f[2],
            )
            for f in found
        ]


# ---------------------------------------------------------------------------
# Approach B – spaCy NER  (wrapper)
# ---------------------------------------------------------------------------

class SpacyNER:
    """
    spaCy NER wrapper.  Loads en_core_web_sm by default.
    For clinical NER, consider fine-tuning on clinical annotations.

    Entity type mapping: spaCy labels → our EntityType enum.
    Unknown labels map to EntityType.OTHER.
    """

    SPACY_TO_ENTITY = {
        "DISEASE": EntityType.CONDITION,
        "CHEMICAL": EntityType.DRUG,
        "PROCEDURE": EntityType.PROCEDURE,
        "ORG": EntityType.OTHER,
        "GPE": EntityType.OTHER,
        "PERSON": EntityType.OTHER,
    }

    def __init__(self, model_name: str = "en_core_web_sm", negex_window: int = 6):
        try:
            import spacy
            self._nlp   = spacy.load(model_name)
            self._negex = NegExProcessor(window=negex_window)
            self._ready = True
        except (ImportError, OSError) as e:
            print(f"[SpacyNER] Model not available ({e}). "
                  f"Install: python -m spacy download {model_name}")
            self._ready = False

    def extract(self, text: str, apply_negex: bool = True) -> list[ClinicalEntity]:
        if not self._ready:
            return []
        doc = self._nlp(text)
        found: list[tuple[str, int, int, EntityType]] = []
        for ent in doc.ents:
            etype = self.SPACY_TO_ENTITY.get(ent.label_, EntityType.OTHER)
            found.append((ent.text, ent.start_char, ent.end_char, etype))

        if not found:
            return []

        if apply_negex:
            try:
                negex_inputs  = [(f[0], f[1], f[2]) for f in found]
                negex_results = self._negex.process_entities(text, negex_inputs)
                return [
                    ClinicalEntity(
                        text             = r.entity_text,
                        entity_type      = found[i][3],
                        negation         = r.status,
                        negation_trigger = r.trigger,
                        start_char       = r.entity_start,
                        end_char         = r.entity_end,
                        negex_window     = r.window_text,
                    )
                    for i, r in enumerate(negex_results)
                ]
            except NotImplementedError:
                pass

        return [
            ClinicalEntity(
                text=f[0], entity_type=f[3], negation=NegationStatus.AFFIRMED,
                start_char=f[1], end_char=f[2]
            )
            for f in found
        ]


# ---------------------------------------------------------------------------
# Approach C – ClinicalBERT stub
# ---------------------------------------------------------------------------

class ClinicalBERTNER:
    """
    ClinicalBERT-based NER.

    Uses HuggingFace `pipeline("ner", ...)` with:
      "emilyalsentzer/Bio_ClinicalBERT"  (general clinical BERT)
      "allenai/scibert_scivocab_uncased" (scientific text)
      "dmis-lab/biobert-base-cased-v1.2" (biomedical text)

    For clinical NER specifically, fine-tune one of the above on:
      * i2b2/n2c2 2018 NLP Challenge (conditions, medications, procedures)
      * NCBI Disease Corpus
      * BC5CDR (chemicals and diseases)

    TODO (Student Task 6 — Advanced):
      Replace the stub below with a real HuggingFace pipeline call.

      from transformers import pipeline
      ner_pipeline = pipeline(
          "ner",
          model="emilyalsentzer/Bio_ClinicalBERT",
          aggregation_strategy="simple",   # merges sub-word tokens
      )
      results = ner_pipeline(text)
      # Each result: {'entity_group': 'B-Disease', 'word': 'fever',
      #               'start': 3, 'end': 8, 'score': 0.99}

    Comparison guidance:
      Run all three NER approaches on the same test set.
      Compute precision, recall, F1 using the gold annotations in
      clinical_notes.csv.  Report:
        a) Which model has the highest recall?  (catches the most entities)
        b) Which has the highest precision?     (fewest false positives)
        c) How does negation detection change the results?
           (hint: NegEx integration with ClinicalBERT should be modular)
    """

    def __init__(self, model_name: str = "emilyalsentzer/Bio_ClinicalBERT"):
        self.model_name = model_name
        self._pipeline  = None
        self._negex     = NegExProcessor()

    def load(self) -> "ClinicalBERTNER":
        try:
            from transformers import pipeline
            self._pipeline = pipeline(
                "ner",
                model                = self.model_name,
                aggregation_strategy = "simple",
            )
            print(f"[ClinicalBERTNER] Loaded {self.model_name}")
        except Exception as e:
            print(f"[ClinicalBERTNER] Could not load model: {e}")
        return self

    def extract(self, text: str, apply_negex: bool = True) -> list[ClinicalEntity]:
        if self._pipeline is None:
            raise RuntimeError("Call .load() first (downloads ~400 MB).")
        # TODO (Student Task 6): implement entity extraction + NegEx integration
        raise NotImplementedError("Implement ClinicalBERTNER.extract() — see docstring.")


# ---------------------------------------------------------------------------
# Utility: evaluate NER against gold annotations
# ---------------------------------------------------------------------------

def ner_evaluation(
    pred_entities: list[tuple[str, str]],   # [(entity_text, negation_status), ...]
    gold_entities: list[tuple[str, str]],
) -> dict:
    """
    Compute precision, recall, F1 at the entity-text level.
    Ignores character offsets — matches on lower-cased entity text.

    Also reports negation-specific metrics:
      * True Positive Negated  (correctly detected as negated)
      * False Negative Negated (missed negation — entity wrongly called affirmed)
    """
    pred_set = {(t.lower(), s) for t, s in pred_entities}
    gold_set = {(t.lower(), s) for t, s in gold_entities}

    tp = len(pred_set & gold_set)
    fp = len(pred_set - gold_set)
    fn = len(gold_set - pred_set)

    prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    rec  = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1   = 2 * prec * rec / (prec + rec) if (prec + rec) > 0 else 0.0

    # Negation-specific
    gold_neg = {t for t, s in gold_set if s == "negated"}
    pred_neg = {t for t, s in pred_set if s == "negated"}
    neg_tp   = len(gold_neg & pred_neg)
    neg_fn   = len(gold_neg - pred_neg)

    return dict(
        precision=prec, recall=rec, f1=f1,
        tp=tp, fp=fp, fn=fn,
        negation_recall=neg_tp / len(gold_neg) if gold_neg else float("nan"),
        negation_missed=neg_fn,
    )


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    ner = GazetteerNER()
    examples = [
        "No fever. Patient denies chest pain. Hypertension well controlled.",
        "History of diabetes mellitus. No current hypoglycaemia.",
        "No change in atrial fibrillation. Shortness of breath improving.",
    ]
    for text in examples:
        print(f"Text: {text}")
        try:
            entities = ner.extract(text, apply_negex=True)
            for e in entities:
                neg = f"[{e.negation.value}]"
                trig = f" (trigger: '{e.negation_trigger}')" if e.negation_trigger else ""
                print(f"  {e.text:<28} {neg:<15}{trig}")
        except NotImplementedError:
            entities = ner.extract(text, apply_negex=False)
            print("  (NegEx not yet implemented — showing AFFIRMED only)")
            for e in entities:
                print(f"  {e.text:<28} [AFFIRMED — no negex]")
        print()
