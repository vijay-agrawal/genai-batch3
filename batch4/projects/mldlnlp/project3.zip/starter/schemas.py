"""
Output Schemas (Pydantic v2)
============================
Three output types for the three tasks in this project:

  ClinicalEntity       – a single extracted entity with negation flag
  DocumentNEROutput    – full NER result for one document
  TopicAssignment      – LDA/BERTopic topic for one document
  NewTopicAlert        – fired when a document doesn't fit historical topics

Students: Do NOT modify this file.
"""

from __future__ import annotations

from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class EntityType(str, Enum):
    SYMPTOM    = "symptom"
    CONDITION  = "condition"
    DRUG       = "drug"
    PROCEDURE  = "procedure"
    FINDING    = "finding"
    ANATOMY    = "anatomy"
    OTHER      = "other"


class NegationStatus(str, Enum):
    AFFIRMED        = "affirmed"         # entity is present
    NEGATED         = "negated"          # "no fever" → fever NEGATED
    POSSIBLE        = "possible"         # "possible fever" → uncertain
    HISTORICAL      = "historical"       # "history of hypertension"
    HYPOTHETICAL    = "hypothetical"     # "if patient develops fever"
    FAMILY_HISTORY  = "family_history"   # "mother had diabetes"


class TopicSource(str, Enum):
    HISTORICAL = "historical"    # topic was in the original training corpus
    EMERGING   = "emerging"      # newly detected topic not seen during LDA training


# ---------------------------------------------------------------------------
# NER Schemas
# ---------------------------------------------------------------------------

class ClinicalEntity(BaseModel):
    """
    A single extracted clinical entity with full context.

    Example:
        ClinicalEntity(
            text="fever", entity_type=EntityType.SYMPTOM,
            negation=NegationStatus.NEGATED,
            negation_trigger="no",
            start_char=3, end_char=8,
            negex_window="No fever was recorded"
        )
    """
    text:             str
    entity_type:      EntityType
    negation:         NegationStatus = NegationStatus.AFFIRMED
    negation_trigger: Optional[str] = Field(
        default=None,
        description="The trigger word that caused negation, e.g. 'no', 'denies'"
    )
    start_char:       int  = Field(ge=0)
    end_char:         int  = Field(ge=0)
    negex_window:     Optional[str] = Field(
        default=None,
        description="The text window used by NegEx to determine negation"
    )
    confidence:       float = Field(default=1.0, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def end_after_start(self) -> "ClinicalEntity":
        if self.end_char <= self.start_char:
            raise ValueError(
                f"end_char ({self.end_char}) must be > start_char ({self.start_char})"
            )
        return self

    @model_validator(mode="after")
    def negation_trigger_required_when_negated(self) -> "ClinicalEntity":
        if (self.negation in (NegationStatus.NEGATED,)
                and self.negation_trigger is None):
            raise ValueError(
                "negation_trigger must be set when negation='negated'"
            )
        return self


class DocumentNEROutput(BaseModel):
    """Full NER result for a single document."""

    doc_id:          str
    source_text:     str
    entities:        List[ClinicalEntity]
    n_entities:      int = Field(ge=0)
    n_negated:       int = Field(ge=0)
    n_affirmed:      int = Field(ge=0)
    model_used:      str  = "rule_based"    # "rule_based" | "spacy" | "clinical_bert"
    processing_notes: Optional[str] = None

    @model_validator(mode="after")
    def counts_consistent(self) -> "DocumentNEROutput":
        actual_total   = len(self.entities)
        actual_negated = sum(
            1 for e in self.entities if e.negation == NegationStatus.NEGATED
        )
        actual_affirmed = sum(
            1 for e in self.entities if e.negation == NegationStatus.AFFIRMED
        )
        if self.n_entities != actual_total:
            raise ValueError(
                f"n_entities={self.n_entities} != len(entities)={actual_total}"
            )
        if self.n_negated != actual_negated:
            raise ValueError(
                f"n_negated={self.n_negated} != actual negated count={actual_negated}"
            )
        if self.n_affirmed != actual_affirmed:
            raise ValueError(
                f"n_affirmed={self.n_affirmed} != actual affirmed count={actual_affirmed}"
            )
        return self


# ---------------------------------------------------------------------------
# Topic Modeling Schemas
# ---------------------------------------------------------------------------

class TopicWord(BaseModel):
    word:   str
    weight: float = Field(ge=0.0, description="Contribution weight in the topic")


class TopicDescriptor(BaseModel):
    """
    Describes a discovered topic — its ID, top words, and coherence score.
    """
    topic_id:       int  = Field(ge=0)
    top_words:      List[TopicWord] = Field(min_length=3)
    label:          Optional[str]  = Field(
        default=None,
        description="Human-readable label assigned after inspection, e.g. 'oncology'"
    )
    coherence_score: Optional[float] = None
    source:         TopicSource = TopicSource.HISTORICAL


class TopicAssignment(BaseModel):
    """
    Topic assignment for a single document.
    """
    doc_id:              str
    dominant_topic_id:   int  = Field(ge=0)
    dominant_topic_label: Optional[str] = None
    topic_distribution:  Dict[int, float] = Field(
        description="Map of topic_id -> probability; should sum to 1.0"
    )
    max_probability:     float = Field(ge=0.0, le=1.0)
    model_used:          str   = "lda"   # "lda" | "nmf" | "bertopic"

    @field_validator("topic_distribution")
    @classmethod
    def probs_sum_to_one(cls, v: Dict[int, float]) -> Dict[int, float]:
        total = sum(v.values())
        if abs(total - 1.0) > 0.02:
            raise ValueError(
                f"topic_distribution must sum to ~1.0, got {total:.4f}"
            )
        return v

    @model_validator(mode="after")
    def dominant_topic_in_distribution(self) -> "TopicAssignment":
        if self.dominant_topic_id not in self.topic_distribution:
            raise ValueError(
                f"dominant_topic_id={self.dominant_topic_id} not in topic_distribution keys"
            )
        expected_max = max(self.topic_distribution.values())
        if abs(self.max_probability - expected_max) > 0.01:
            raise ValueError(
                f"max_probability={self.max_probability:.4f} does not match "
                f"maximum in topic_distribution ({expected_max:.4f})"
            )
        return self


# ---------------------------------------------------------------------------
# New Topic Alert
# ---------------------------------------------------------------------------

class NewTopicAlert(BaseModel):
    """
    Fired when a document cannot be adequately explained by the historical
    topic model — indicating an emerging / novel topic.

    Criteria (students must implement and justify their thresholds):
      * max_probability < novelty_threshold   (poor fit to existing topics)
      * assigned to an emerging cluster by BERTopic
    """
    doc_id:              str
    title:               Optional[str] = None
    max_probability:     float = Field(ge=0.0, le=1.0,
                             description="Best-matching historical topic probability")
    novelty_threshold:   float = Field(ge=0.0, le=1.0,
                             description="Threshold below which document is flagged")
    is_novel:            bool
    suggested_cluster:   Optional[int]  = Field(
        default=None,
        description="Cluster ID assigned by BERTopic or KMeans to the novel documents"
    )
    representative_terms: List[str] = Field(
        default_factory=list,
        description="Top TF-IDF terms from this document that differ from historical topics"
    )
    alert_reason:        str = Field(min_length=5)

    @model_validator(mode="after")
    def novel_flag_consistent(self) -> "NewTopicAlert":
        if self.is_novel and self.max_probability >= self.novelty_threshold:
            raise ValueError(
                f"is_novel=True but max_probability={self.max_probability:.4f} "
                f">= novelty_threshold={self.novelty_threshold:.4f}"
            )
        if not self.is_novel and self.max_probability < self.novelty_threshold:
            raise ValueError(
                f"is_novel=False but max_probability={self.max_probability:.4f} "
                f"< novelty_threshold={self.novelty_threshold:.4f}"
            )
        return self


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json

    # NER example with negated entity
    ner_out = DocumentNEROutput(
        doc_id      = "NOTE-0001",
        source_text = "No fever. Patient denies chest pain. Hypertension stable.",
        entities    = [
            ClinicalEntity(
                text="fever", entity_type=EntityType.SYMPTOM,
                negation=NegationStatus.NEGATED, negation_trigger="No",
                start_char=3, end_char=8,
                negex_window="No fever",
            ),
            ClinicalEntity(
                text="chest pain", entity_type=EntityType.SYMPTOM,
                negation=NegationStatus.NEGATED, negation_trigger="denies",
                start_char=28, end_char=38,
                negex_window="denies chest pain",
            ),
            ClinicalEntity(
                text="Hypertension", entity_type=EntityType.CONDITION,
                negation=NegationStatus.AFFIRMED,
                start_char=40, end_char=52,
            ),
        ],
        n_entities=3, n_negated=2, n_affirmed=1,
        model_used="negex+rule_based",
    )

    # Topic assignment example
    topic_out = TopicAssignment(
        doc_id="NEW-00001",
        dominant_topic_id=5,
        dominant_topic_label="long_covid (emerging)",
        topic_distribution={0: 0.05, 1: 0.05, 2: 0.05, 3: 0.05, 4: 0.05, 5: 0.75},
        max_probability=0.75,
        model_used="lda_retrained",
    )

    # New topic alert example
    alert = NewTopicAlert(
        doc_id="NEW-00003",
        title="Lipid nanoparticle optimisation for VEGF mRNA delivery",
        max_probability=0.18,
        novelty_threshold=0.35,
        is_novel=True,
        suggested_cluster=1,
        representative_terms=["lipid nanoparticle", "pseudouridine", "mRNA stability"],
        alert_reason=(
            "Maximum historical topic probability 0.18 below threshold 0.35; "
            "vocabulary overlap with historical corpus < 10%."
        ),
    )

    print(json.loads(ner_out.model_dump_json(indent=2)))
    print(json.loads(topic_out.model_dump_json(indent=2)))
    print(json.loads(alert.model_dump_json(indent=2)))
    print("\nSchema self-test passed.")
