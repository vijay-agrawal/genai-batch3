"""
NegEx Algorithm
===============
NegEx (Chapman et al., 2001) is a rule-based algorithm that detects negated
clinical concepts in free text.  It is one of the most widely used and
well-studied algorithms in clinical NLP.

ALGORITHM OVERVIEW:
  1. Find all clinical entities in the text (via NER or gazetteer).
  2. For each entity, extract a WINDOW of words around it.
  3. Check the PRE-window (before entity) for pre-negation triggers.
  4. Check the POST-window (after entity) for post-negation triggers.
  5. If a trigger is found AND no PSEUDO-NEGATION pattern matches, mark NEGATED.

THREE SCOPE RULES that make NegEx non-trivial:
  a) SCOPE: negation triggers only affect entities within a fixed window
            (default 6 tokens each side).  They do NOT propagate past a
            SCOPE_TERMINATOR (e.g. "but", "however", "except").

  b) PSEUDO-NEGATION: patterns like "no change in X" look negative but are NOT.
                      The entity X is still PRESENT.  These must be detected
                      BEFORE the standard negation check.

  c) SPECULATIVE / HYPOTHETICAL context: "if patient develops fever" → fever is
     HYPOTHETICAL, not negated, but also not affirmed.

WHY NEGEX MATTERS:
  Without negation detection, a search for "patients with diabetes" would also
  retrieve notes saying "no history of diabetes" and "diabetes ruled out".
  In clinical IR, NER extraction of disease phenotypes, and adverse event
  detection, this is a CRITICAL bug that degrades precision severely.

STUDENT TASKS:
  Task 1 – Implement apply_negex() using the provided trigger lists
  Task 2 – Handle pseudo-negation patterns
  Task 3 – Add scope terminators so negation doesn't bleed across clauses
  Task 4 – Add HISTORICAL and HYPOTHETICAL context detection

Usage:
    from negex import NegExProcessor
    proc = NegExProcessor()
    result = proc.process("No fever. Patient denies chest pain. Hypertension stable.")
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

from schemas import NegationStatus


# ---------------------------------------------------------------------------
# Trigger word lists
# ---------------------------------------------------------------------------

# Appear BEFORE the entity and negate it
PRE_NEGATION_TRIGGERS: list[str] = [
    "no", "not", "denies", "denied", "deny",
    "without", "absence of", "absent",
    "negative for", "neg for",
    "ruled out", "rule out",
    "no evidence of", "no signs of", "no sign of",
    "no history of",
    "free of", "never",
    "failed to reveal", "fails to reveal",
    "cannot identify", "cannot find",
    "no longer",
]

# Appear AFTER the entity and negate it
POST_NEGATION_TRIGGERS: list[str] = [
    "was ruled out", "were ruled out",
    "not identified", "not observed", "not detected", "not found",
    "is unlikely", "are unlikely",
    "has been excluded", "have been excluded",
    "not present", "not noted",
    "was negative", "were negative",
]

# Pseudo-negation: "no X" patterns where X is STILL PRESENT
# The match here is against the full phrase, NOT just the trigger.
# These must be detected FIRST to avoid false negatives.
PSEUDO_NEGATION_PHRASES: list[str] = [
    r"no change in",
    r"no improvement in",
    r"no improvement of",
    r"no worsening of",
    r"no worse than",
    r"not responding to treatment for",
    r"not improving",
    r"no response to",
    r"no significant change",
    r"no acute change",
    r"denies any change",
    r"without improvement",
    r"without worsening",
]

# Hypothetical context triggers
HYPOTHETICAL_TRIGGERS: list[str] = [
    "if patient develops", "if the patient develops",
    "if he develops", "if she develops",
    "should patient develop", "in the event of",
    "watch for", "monitor for",
    "prophylaxis against",
]

# Historical context triggers
HISTORICAL_TRIGGERS: list[str] = [
    "history of", "h/o", "hx of",
    "previous", "previously",
    "prior", "remote history of",
    "past medical history",
    "childhood history of",
]

# Scope terminators: negation cannot propagate past these
SCOPE_TERMINATORS: list[str] = [
    "but", "however", "although", "nevertheless",
    "except", "yet", "still", "despite",
    "on the other hand", ";", ":"
]

# Default window size (tokens) to look each side of the entity
DEFAULT_WINDOW = 6


# ---------------------------------------------------------------------------
# Internal data structure
# ---------------------------------------------------------------------------

@dataclass
class NegExResult:
    """Result of NegEx analysis for a single entity mention."""
    entity_text:       str
    entity_start:      int
    entity_end:        int
    status:            NegationStatus
    trigger:           Optional[str] = None
    window_text:       Optional[str] = None


# ---------------------------------------------------------------------------
# NegExProcessor
# ---------------------------------------------------------------------------

class NegExProcessor:
    """
    Applies the NegEx algorithm to detect negated clinical entities in a text.

    Typical usage:
        proc     = NegExProcessor(window=6)
        entities = [("fever", 3, 8), ("chest pain", 22, 32)]
        results  = proc.process_entities(text, entities)
        for r in results:
            print(r.entity_text, r.status, r.trigger)
    """

    def __init__(self, window: int = DEFAULT_WINDOW):
        self.window = window
        # Pre-compile patterns for efficiency
        self._pre_patterns  = self._compile_sorted(PRE_NEGATION_TRIGGERS)
        self._post_patterns = self._compile_sorted(POST_NEGATION_TRIGGERS)
        self._pseudo_patterns = [
            re.compile(p, re.IGNORECASE) for p in PSEUDO_NEGATION_PHRASES
        ]
        self._hypo_patterns = self._compile_sorted(HYPOTHETICAL_TRIGGERS)
        self._hist_patterns = self._compile_sorted(HISTORICAL_TRIGGERS)

    @staticmethod
    def _compile_sorted(phrases: list[str]) -> list[re.Pattern]:
        """Compile patterns sorted longest-first to avoid partial matches."""
        return [
            re.compile(re.escape(p), re.IGNORECASE)
            for p in sorted(phrases, key=len, reverse=True)
        ]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def process_entities(
        self,
        text:     str,
        entities: list[tuple[str, int, int]],   # [(entity_text, start, end), ...]
    ) -> list[NegExResult]:
        """
        Apply NegEx to every entity in the provided list.

        Parameters
        ----------
        text     : the full document text
        entities : list of (entity_text, start_char, end_char) tuples

        Returns
        -------
        list of NegExResult, one per entity
        """
        results = []
        for entity_text, start, end in entities:
            result = self._classify_entity(text, entity_text, start, end)
            results.append(result)
        return results

    # ------------------------------------------------------------------
    # Internal methods
    # ------------------------------------------------------------------

    def _get_window(self, text: str, start: int, end: int) -> tuple[str, str]:
        """
        Extract the pre-window (before entity) and post-window (after entity).
        Windows are truncated by sentence boundaries and scope terminators.
        """
        # Token-level window extraction
        tokens_before = text[:start].split()
        tokens_after  = text[end:].split()

        pre_tokens  = tokens_before[-self.window:]
        post_tokens = tokens_after[:self.window]

        # Truncate at scope terminators
        pre_tokens  = self._truncate_at_terminator(pre_tokens, reverse=True)
        post_tokens = self._truncate_at_terminator(post_tokens, reverse=False)

        return " ".join(pre_tokens), " ".join(post_tokens)

    @staticmethod
    def _truncate_at_terminator(tokens: list[str], reverse: bool) -> list[str]:
        """
        Truncate the token list when a scope terminator is encountered.
        In the pre-window (reverse=True), terminators are read right-to-left.
        """
        terminators = set(SCOPE_TERMINATORS)
        result = []
        if reverse:
            tokens = list(reversed(tokens))
        for tok in tokens:
            if tok.lower().rstrip(".,;:") in terminators:
                break
            result.append(tok)
        if reverse:
            result = list(reversed(result))
        return result

    def _is_pseudo_negation(self, text: str, entity_start: int) -> bool:
        """
        Return True if the text AROUND the entity matches a pseudo-negation
        pattern (entity is PRESENT despite the surface negation).

        TODO (Student Task 2):
        The current implementation only checks a fixed number of characters
        before the entity.  Improve it to:
          a) Scan a 60-character pre-context window for pseudo-negation phrases.
          b) Also check for post-entity pseudo patterns ("not improving from X").
          c) Return True only if the entity itself is mentioned WITHIN the
             pseudo-negation phrase span.
        """
        pre_context = text[max(0, entity_start - 60): entity_start + 20]
        for pat in self._pseudo_patterns:
            if pat.search(pre_context):
                return True
        return False

    def _check_triggers(
        self,
        patterns:   list[re.Pattern],
        window_text: str,
    ) -> Optional[str]:
        """Return the matched trigger string if any pattern matches, else None."""
        for pat in patterns:
            m = pat.search(window_text)
            if m:
                return m.group(0)
        return None

    def _classify_entity(
        self,
        text: str,
        entity_text: str,
        start: int,
        end: int,
    ) -> NegExResult:
        """
        Classify a single entity as AFFIRMED, NEGATED, HISTORICAL, or HYPOTHETICAL.

        TODO (Student Task 1):
        Complete this method by following the NegEx algorithm:

        Step 1: Check pseudo-negation FIRST (if True → return AFFIRMED).

        Step 2: Extract pre_window and post_window via self._get_window().

        Step 3: Check hypothetical triggers in pre_window.
                If found → return NegExResult(..., status=NegationStatus.HYPOTHETICAL,
                                                   trigger=matched_trigger)

        Step 4: Check historical triggers in pre_window.
                If found → return NegExResult(..., status=NegationStatus.HISTORICAL,
                                                   trigger=matched_trigger)

        Step 5: Check PRE-negation triggers in pre_window.
                If found → return NEGATED with the trigger.

        Step 6: Check POST-negation triggers in post_window.
                If found → return NEGATED with the trigger.

        Step 7: Default → return AFFIRMED (no negation found).

        The template below guides the structure:

            pre_window, post_window = self._get_window(text, start, end)
            window_text = pre_window + " [ENTITY] " + post_window

            if self._is_pseudo_negation(text, start):
                return NegExResult(entity_text, start, end,
                                   NegationStatus.AFFIRMED, window_text=window_text)

            trigger = self._check_triggers(self._hypo_patterns, pre_window)
            if trigger:
                return NegExResult(entity_text, start, end,
                                   NegationStatus.HYPOTHETICAL, trigger, window_text)

            trigger = self._check_triggers(self._hist_patterns, pre_window)
            if trigger:
                return NegExResult(entity_text, start, end,
                                   NegationStatus.HISTORICAL, trigger, window_text)

            trigger = self._check_triggers(self._pre_patterns, pre_window)
            if trigger:
                return NegExResult(entity_text, start, end,
                                   NegationStatus.NEGATED, trigger, window_text)

            trigger = self._check_triggers(self._post_patterns, post_window)
            if trigger:
                return NegExResult(entity_text, start, end,
                                   NegationStatus.NEGATED, trigger, window_text)

            return NegExResult(entity_text, start, end,
                               NegationStatus.AFFIRMED, window_text=window_text)
        """
        raise NotImplementedError(
            "Implement _classify_entity() — see the step-by-step guide in the docstring."
        )


# ---------------------------------------------------------------------------
# Convenience: sentence splitter
# ---------------------------------------------------------------------------

def split_sentences(text: str) -> list[str]:
    """
    Simple rule-based sentence splitter for clinical notes.
    Clinical text has unusual punctuation (abbreviations, dosages) so
    general-purpose splitters often fail.

    TODO (Student Task — preprocess.py):
    This is a baseline.  Compare with spacy's sentenciser and report
    precision on the clinical_notes.csv corpus.
    """
    # Split on ". " or ".\n" but NOT on common clinical abbreviations
    abbrevs = {"Dr.", "Mr.", "Mrs.", "Ms.", "e.g.", "i.e.", "vs.", "approx.",
               "b.i.d.", "t.i.d.", "q.i.d.", "q.d.", "p.r.n."}
    # Simple heuristic: split on period + space + uppercase letter
    pattern = re.compile(r'(?<!\b(?:' +
                         '|'.join(re.escape(a[:-1]) for a in abbrevs) +
                         r'))\.\s+(?=[A-Z])')
    sentences = pattern.split(text)
    return [s.strip() for s in sentences if s.strip()]


# ---------------------------------------------------------------------------
# Quick demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    proc = NegExProcessor()

    test_cases = [
        ("No fever. Patient denies chest pain. Hypertension stable.",
         [("fever", 3, 8), ("chest pain", 28, 38), ("Hypertension", 40, 52)]),

        ("No change in hypertension. Chest pain ruled out.",
         [("hypertension", 13, 25), ("Chest pain", 27, 37)]),

        ("History of diabetes mellitus. No current symptoms.",
         [("diabetes mellitus", 11, 28), ("symptoms", 41, 49)]),

        ("Watch for signs of pneumonia. No fever at this time.",
         [("pneumonia", 18, 27), ("fever", 33, 38)]),
    ]

    print("NegEx Demo (requires Task 1 implementation):\n")
    for text, entities in test_cases:
        print(f"Text: {text}")
        try:
            results = proc.process_entities(text, entities)
            for r in results:
                tag = f"[{r.status.value.upper()}]"
                trig = f"  trigger='{r.trigger}'" if r.trigger else ""
                print(f"  {r.entity_text:<25} {tag:<15}{trig}")
        except NotImplementedError:
            print("  (implement _classify_entity first)")
        print()
