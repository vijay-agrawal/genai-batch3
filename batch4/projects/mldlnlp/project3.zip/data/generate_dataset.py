"""
Dataset Generator – Information Extraction & Theme Discovery
=============================================================
Generates THREE complementary datasets:

DATASET A – Clinical Notes (200 notes)
  clinical_notes.csv
  Short discharge summaries / progress notes with AFFIRMED and NEGATED clinical
  entities.  Designed to make NegEx essential:
    • "No fever" → fever: NEGATED
    • "Denies chest pain" → chest pain: NEGATED
    • "No change in hypertension" → hypertension: AFFIRMED  (pseudo-negation!)
    • "Negative for COVID" → COVID: NEGATED

DATASET B – Historical Research Articles (500 articles)
  historical_articles.csv
  Covers 5 established medical domains with clean topic separation:
    1. Oncology          (cancer, immunotherapy, biomarkers)
    2. Cardiology        (hypertension, statins, arrhythmia)
    3. Diabetes/Metabolic (insulin, HbA1c, GLP-1)
    4. Infectious Disease (antibiotics, sepsis, vaccination)
    5. Neurology         (Alzheimer, stroke, neuroprotection)

DATASET C – Emerging / New Articles (150 articles)
  new_articles.csv
  Contains 3 ENTIRELY NEW topics NOT covered in Dataset B:
    6. Long COVID / PASC  (post-acute sequelae, brain fog, dysautonomia)
    7. mRNA Therapeutics   (lipid nanoparticles, nucleoside modification)
    8. AI-Assisted Diagnosis (foundation models, diagnostic algorithms)

  KEY PEDAGOGICAL POINT:
  An LDA model trained on Dataset B (K=5 topics) will have HIGH perplexity on
  Dataset C new articles and no topic distribution peak above ~0.35.
  Retraining on the combined corpus with K=8 cleanly surfaces the 3 new topics.
  BERTopic labels the new articles as outliers then forms new clusters.

Run:
    python generate_dataset.py           # full datasets
    python generate_dataset.py --quick   # 50/100/30 rows for quick testing
"""

from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path

random.seed(42)

# ============================================================
# DATASET A – Clinical Notes
# ============================================================

# Clinical entities used in the notes
CLINICAL_ENTITIES = {
    "symptoms":   ["fever", "cough", "chest pain", "shortness of breath", "fatigue",
                   "nausea", "headache", "dizziness", "abdominal pain", "palpitations"],
    "conditions": ["hypertension", "diabetes mellitus", "atrial fibrillation",
                   "heart failure", "pneumonia", "COVID-19", "sepsis", "anemia",
                   "hypothyroidism", "chronic kidney disease"],
    "findings":   ["consolidation", "pleural effusion", "ST depression",
                   "elevated troponin", "bilateral infiltrates", "lymphadenopathy"],
}

# PRE-negation triggers  (appear BEFORE the entity)
PRE_NEG_TRIGGERS = [
    "no", "not", "denies", "without", "absence of", "negative for",
    "ruled out", "free of", "never developed", "no evidence of",
    "no signs of", "failed to reveal",
]

# POST-negation triggers (appear AFTER the entity)
POST_NEG_TRIGGERS = [
    "was ruled out", "not identified", "not observed", "not detected",
    "is unlikely", "has been excluded",
]

# PSEUDO-negation patterns — look like negation but entity is PRESENT
# NegEx must NOT flag these as negated
PSEUDO_NEG_PATTERNS = [
    "no change in {entity}",       # entity still present
    "no improvement in {entity}",  # entity still present
    "no worsening of {entity}",    # entity still present
    "no worse than {entity}",      # complex — entity present
    "not responding to treatment for {entity}",
]

# Clinical note templates  (each generates one note row)
NOTE_TEMPLATES = {
    "affirmed": [
        "Patient presents with {e1} and {e2}. History of {c1} noted.",
        "{c1} confirmed on examination. {e1} reported since yesterday.",
        "Admitted for {e1}. Workup reveals {f1}. Background of {c1}.",
        "Patient with known {c1}, presenting with new onset {e1}.",
        "Assessment: {c1} with associated {e1} and {e2}.",
        "On review, {e1} and {f1} consistent with {c1}.",
        "Patient complains of {e1}. Physical exam positive for {f1}.",
        "Chief complaint: {e1}. Secondary concerns: {e2}. PMH: {c1}.",
    ],
    "negated_pre": [
        "No {e1}. {c1} stable on current medications.",
        "Patient denies {e1} and {e2}. {c1} well controlled.",
        "Absence of {e1}. No evidence of {c1}.",
        "{c1} ruled out. No {e1} or {e2} at this time.",
        "Negative for {e1}. Without {e2}. {c1} not identified.",
        "No signs of {e1}. Free of {e2}. No {f1} on imaging.",
        "Failed to reveal {e1}. Not {e2}. {c1} excluded.",
    ],
    "negated_post": [
        "{e1} was ruled out after extensive workup. {c1} stable.",
        "{e1} and {e2} not identified. {c1} not observed at this visit.",
        "{c1} has been excluded based on recent investigations.",
        "{e1} not detected. {f1} is unlikely in this clinical context.",
    ],
    "pseudo_negated": [
        "No change in {c1}. {e1} persists despite treatment.",
        "{c1} shows no improvement on current regimen. {e1} ongoing.",
        "No worsening of {c1}. Continue current management.",
        "Not responding to treatment for {c1}. Consider escalation.",
        "No change in {e1} following intervention. {c1} unchanged.",
    ],
    "mixed": [
        "Patient with {c1} and {e1}. Denies {e2} or {f1}.",
        "History of {c1}. No {e1} currently. {e2} reported.",
        "No {e1}. {c1} active. {e2} well managed.",
        "Presents with {e1} and {e2}. No evidence of {c1}.",
        "Known {c1}. No {e1} on this admission. {e2} improving.",
        "Absence of {f1}. {c1} confirmed. {e1} mild and self-limiting.",
    ],
}


def _pick(lst):
    return random.choice(lst)


def _fill_template(template: str) -> dict:
    """Fill a note template and return structured row with gold labels."""
    syms = CLINICAL_ENTITIES["symptoms"]
    conds = CLINICAL_ENTITIES["conditions"]
    finds = CLINICAL_ENTITIES["findings"]

    e1 = _pick(syms)
    e2 = _pick([s for s in syms if s != e1])
    c1 = _pick(conds)
    f1 = _pick(finds)

    text = (template
            .replace("{e1}", e1).replace("{e2}", e2)
            .replace("{c1}", c1).replace("{f1}", f1))
    return {"text": text, "e1": e1, "e2": e2, "c1": c1, "f1": f1}


def generate_clinical_notes(n: int = 200) -> list[dict]:
    rows = []
    note_id = 1

    counts = {
        "affirmed":       max(1, int(n * 0.25)),
        "negated_pre":    max(1, int(n * 0.25)),
        "negated_post":   max(1, int(n * 0.10)),
        "pseudo_negated": max(1, int(n * 0.15)),
        "mixed":          max(1, int(n * 0.25)),
    }

    for note_type, count in counts.items():
        for _ in range(count):
            template = _pick(NOTE_TEMPLATES[note_type])
            filled   = _fill_template(template)
            rows.append({
                "note_id":    f"NOTE-{note_id:04d}",
                "text":       filled["text"],
                "note_type":  note_type,
                # Gold labels for evaluation
                "entities":   "; ".join([filled["e1"], filled["e2"],
                                         filled["c1"], filled["f1"]]),
                # Which entities are NEGATED (gold annotation)
                "negated_entities": (
                    "; ".join([filled["e1"], filled["e2"], filled["c1"]])
                    if "negated" in note_type and "pseudo" not in note_type
                    else ""
                ),
            })
            note_id += 1

    random.shuffle(rows)
    return rows


# ============================================================
# DATASETS B & C – Research Articles
# ============================================================

# ---- HISTORICAL TOPICS (vocabulary deliberately disjoint) ----

TOPIC_VOCAB = {
    "oncology": {
        "title_patterns": [
            "PD-L1 expression as a biomarker for {drug} response in {cancer} patients",
            "Efficacy of {drug} in metastatic {cancer}: a phase III randomised trial",
            "Tumour mutational burden predicts {drug} outcomes in {cancer}",
            "Genomic profiling of {cancer}: implications for targeted therapy",
            "Immunotherapy resistance mechanisms in {cancer}: a systematic review",
        ],
        "vocab": [
            "tumor", "malignancy", "biopsy", "chemotherapy", "immunotherapy",
            "biomarker", "PD-L1", "VEGF", "metastasis", "remission", "cytotoxic",
            "angiogenesis", "genomic", "oncogene", "apoptosis", "checkpoint inhibitor",
            "clinical trial", "progression-free survival", "overall survival",
            "carboplatin", "paclitaxel", "pembrolizumab", "bevacizumab", "FOLFOX",
            "radiation therapy", "tumour microenvironment", "T-cell infiltration",
            "EGFR mutation", "KRAS", "ALK rearrangement", "HER2", "BRCA",
        ],
        "fillers": {
            "drug": ["pembrolizumab", "bevacizumab", "carboplatin", "nivolumab"],
            "cancer": ["non-small cell lung cancer", "colorectal cancer",
                       "triple-negative breast cancer", "melanoma", "glioblastoma"],
        },
    },
    "cardiology": {
        "title_patterns": [
            "Statin therapy and cardiovascular outcomes in patients with {condition}",
            "Impact of {drug} on left ventricular function in {condition}",
            "Risk stratification for {condition} using {marker}",
            "Catheter ablation versus antiarrhythmic drugs in {condition}: meta-analysis",
            "Optimal blood pressure targets in patients with {condition}",
        ],
        "vocab": [
            "hypertension", "coronary", "myocardial infarction", "atherosclerosis",
            "statin", "cholesterol", "arrhythmia", "echocardiogram", "troponin",
            "ejection fraction", "pericardium", "revascularisation", "stenosis",
            "metoprolol", "lisinopril", "aspirin", "warfarin", "clopidogrel",
            "atorvastatin", "heart failure", "systolic", "diastolic", "QRS",
            "atrial fibrillation", "ventricular tachycardia", "LVEF", "BNP",
            "percutaneous coronary intervention", "STEMI", "NSTEMI",
        ],
        "fillers": {
            "drug": ["atorvastatin", "bisoprolol", "lisinopril", "apixaban"],
            "condition": ["heart failure", "atrial fibrillation",
                          "hypertension", "stable coronary artery disease"],
            "marker": ["troponin I", "NT-proBNP", "CRP", "high-sensitivity troponin"],
        },
    },
    "diabetes": {
        "title_patterns": [
            "GLP-1 receptor agonists and glycaemic control in type 2 {condition}",
            "SGLT2 inhibitors reduce {outcome} in patients with {condition}",
            "HbA1c reduction with {drug} versus metformin: a head-to-head comparison",
            "Insulin resistance mechanisms in {condition}: a metabolic perspective",
            "Continuous glucose monitoring and outcomes in {condition}",
        ],
        "vocab": [
            "insulin", "glucose", "HbA1c", "glycaemic", "pancreas", "islet",
            "adipose", "obesity", "metabolic syndrome", "OGTT", "GLP-1", "SGLT2",
            "sitagliptin", "insulin glargine", "liraglutide", "empagliflozin",
            "type 2 diabetes", "insulin resistance", "hyperglycaemia", "beta cell",
            "postprandial", "fasting glucose", "diabetic nephropathy", "neuropathy",
            "metformin", "DPP-4 inhibitor", "basal insulin", "C-peptide",
        ],
        "fillers": {
            "drug": ["semaglutide", "empagliflozin", "dulaglutide", "insulin degludec"],
            "condition": ["type 2 diabetes mellitus", "prediabetes",
                          "diabetes with renal impairment"],
            "outcome": ["cardiovascular events", "hospitalisation", "renal progression"],
        },
    },
    "infectious_disease": {
        "title_patterns": [
            "Antimicrobial resistance patterns in {pathogen}: a global surveillance study",
            "Efficacy of {drug} versus standard of care in {infection}",
            "Vaccination strategies for {pathogen} in immunocompromised patients",
            "Risk factors for nosocomial {infection} in ICU patients",
            "Molecular epidemiology of {pathogen} outbreak: whole-genome sequencing",
        ],
        "vocab": [
            "pathogen", "antibiotic", "resistance", "viral", "immune", "vaccination",
            "prophylaxis", "sepsis", "nosocomial", "bacteraemia", "MRSA",
            "Staphylococcus aureus", "Escherichia coli", "Clostridium difficile",
            "influenza", "broad-spectrum", "beta-lactam", "carbapenem",
            "vancomycin", "multidrug-resistant", "infection control", "PCR",
            "serotype", "virulence factor", "biofilm", "plasmid", "horizontal gene transfer",
        ],
        "fillers": {
            "drug": ["meropenem", "vancomycin", "ceftriaxone", "azithromycin"],
            "pathogen": ["MRSA", "Klebsiella pneumoniae", "C. difficile", "influenza A"],
            "infection": ["pneumonia", "bloodstream infection", "urinary tract infection",
                          "surgical site infection"],
        },
    },
    "neurology": {
        "title_patterns": [
            "Amyloid-beta clearance by {drug} in early Alzheimer disease",
            "Neuroprotective effects of {drug} following ischaemic {condition}",
            "Tau accumulation and cognitive decline: longitudinal biomarker study",
            "Dopamine replacement therapy in {condition}: efficacy and adverse effects",
            "Cerebrospinal fluid biomarkers in early detection of {condition}",
        ],
        "vocab": [
            "neuron", "synapse", "tau", "amyloid", "dementia", "stroke",
            "ischaemic", "neuroprotection", "dopamine", "cerebrospinal fluid",
            "memantine", "lecanemab", "alteplase", "carbidopa", "levodopa",
            "Alzheimer disease", "Parkinson disease", "multiple sclerosis",
            "neuroinflammation", "blood-brain barrier", "BDNF", "cholinergic",
            "MRI", "PET scan", "MMSE", "cognitive reserve", "hippocampal",
        ],
        "fillers": {
            "drug": ["lecanemab", "aducanumab", "alteplase", "rasagiline"],
            "condition": ["stroke", "Parkinson disease", "Alzheimer disease",
                          "traumatic brain injury"],
        },
    },
}

# ---- NEW/EMERGING TOPICS (vocabulary NOT in historical corpus) ----

NEW_TOPIC_VOCAB = {
    "long_covid": {
        "title_patterns": [
            "Post-acute sequelae of SARS-CoV-2: mechanisms of {symptom} persistence",
            "Dysautonomia and {symptom} in long COVID: a prospective cohort study",
            "Mast cell activation and neurological symptoms in post-COVID syndrome",
            "Spike protein persistence and immune dysregulation in PASC",
            "Microbiome dysbiosis as a driver of {symptom} in long COVID",
        ],
        "vocab": [
            "post-acute sequelae", "PASC", "brain fog", "dysautonomia",
            "mast cell activation", "ACE2 receptor", "spike protein persistence",
            "microbiome dysbiosis", "autonomic dysfunction", "orthostatic intolerance",
            "postural tachycardia syndrome", "POTS", "cognitive impairment",
            "long COVID", "mitochondrial dysfunction", "viral reservoir",
            "cytokine dysregulation", "reactivation", "Epstein-Barr reactivation",
            "fibromyalgia-like", "fatigue syndrome", "chronic fatigue",
        ],
        "fillers": {
            "symptom": ["fatigue", "cognitive impairment", "breathlessness",
                        "orthostatic intolerance"],
        },
    },
    "mrna_therapeutics": {
        "title_patterns": [
            "Lipid nanoparticle optimisation for {target} mRNA delivery",
            "Pseudouridine modification enhances mRNA stability for {disease} therapy",
            "In vitro transcription of {target} mRNA: purity and immunogenicity",
            "mRNA-based protein replacement therapy in {disease}: preclinical results",
            "5-prime cap analogues improve translation efficiency of therapeutic mRNA",
        ],
        "vocab": [
            "lipid nanoparticle", "LNP", "mRNA stability", "5-prime cap",
            "pseudouridine", "nucleoside modification", "in vitro transcription",
            "therapeutic mRNA", "ionisable lipid", "PEGylation", "endosomal escape",
            "BNT162b2", "mRNA-1273", "open reading frame", "polyadenylation",
            "codon optimisation", "self-amplifying mRNA", "saRNA",
            "protein replacement therapy", "mRNA half-life", "toll-like receptor",
            "innate immune evasion", "transient expression",
        ],
        "fillers": {
            "target": ["spike protein", "VEGF", "erythropoietin", "factor VIII"],
            "disease": ["TTR amyloidosis", "Huntington disease",
                        "cystic fibrosis", "propionic acidaemia"],
        },
    },
    "ai_diagnosis": {
        "title_patterns": [
            "Foundation model for {modality} interpretation: zero-shot diagnostic accuracy",
            "Contrastive learning in medical imaging: {modality} pre-training",
            "Large language model-assisted {task}: a prospective clinical evaluation",
            "Multimodal AI integrating {modality} and clinical text for {task}",
            "Federated learning for privacy-preserving {task} across hospital networks",
        ],
        "vocab": [
            "foundation model", "vision transformer", "ViT", "multimodal",
            "zero-shot", "contrastive learning", "CLIP", "diagnostic algorithm",
            "medical imaging", "radiology AI", "FDA clearance", "clinical decision support",
            "transfer learning", "self-supervised", "DINO", "MedSAM",
            "GPT-4", "Med-PaLM", "BioViL-T", "CheXpert", "MIMIC",
            "AUC", "calibration", "explainability", "saliency map",
            "federated learning", "differential privacy", "benchmark",
        ],
        "fillers": {
            "modality": ["chest X-ray", "fundus photography", "ECG", "CT scan"],
            "task": ["triage", "diagnosis", "prognosis", "treatment planning"],
        },
    },
}


def _build_article(topic_key: str, topic_data: dict, article_id: str) -> dict:
    """Build one article from topic vocabulary."""
    title_tpl = random.choice(topic_data["title_patterns"])
    fillers   = topic_data.get("fillers", {})

    # Fill title template
    title = title_tpl
    for key, options in fillers.items():
        if f"{{{key}}}" in title:
            title = title.replace(f"{{{key}}}", random.choice(options))

    # Build abstract from randomly sampled vocabulary
    vocab    = topic_data["vocab"]
    n_words  = random.randint(6, 10)
    keywords = random.sample(vocab, min(n_words, len(vocab)))

    # Simple sentence templates for the abstract
    sentences = [
        f"This study investigates {keywords[0]} and {keywords[1]} in the context of recent findings.",
        f"Methods: {keywords[2]} was assessed using validated clinical protocols.",
        f"Results demonstrate significant associations between {keywords[3]} and {keywords[4]}.",
    ]
    if len(keywords) > 5:
        sentences.append(
            f"Furthermore, {keywords[5]} was identified as a key modulator. "
            f"Implications for {keywords[6] if len(keywords) > 6 else 'clinical practice'} are discussed."
        )
    abstract = " ".join(sentences)

    return {
        "article_id":  article_id,
        "_topic":      topic_key,   # internal only — stripped before saving training set
        "title":       title,
        "abstract":    abstract,
        "full_text":   title + ". " + abstract,  # model input
        "keywords":    "; ".join(keywords[:5]),
    }


def generate_articles(
    topic_dict:  dict,
    n_per_topic: int,
    id_prefix:   str,
) -> list[dict]:
    rows     = []
    counter  = 1
    topics   = list(topic_dict.keys())
    per      = max(1, n_per_topic)

    for topic_key in topics:
        for _ in range(per):
            aid = f"{id_prefix}-{counter:05d}"
            rows.append(_build_article(topic_key, topic_dict[topic_key], aid))
            counter += 1

    random.shuffle(rows)
    return rows


def save_csv(rows: list[dict], path: Path, columns: list[str] | None = None) -> None:
    """Save rows to CSV, optionally restricting to a subset of columns."""
    if not rows:
        return
    fieldnames = columns if columns else list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    print(f"  Saved {len(rows)} rows -> {path}")


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true",
                        help="Small dataset for quick testing")
    args = parser.parse_args()

    out = Path(__file__).parent

    if args.quick:
        n_notes, n_hist_per, n_new_per = 50, 20, 10
    else:
        n_notes, n_hist_per, n_new_per = 200, 100, 50

    print("Generating Dataset A: clinical notes ...")
    notes = generate_clinical_notes(n_notes)
    save_csv(notes, out / "clinical_notes.csv")
    type_counts = {}
    for n in notes:
        type_counts[n["note_type"]] = type_counts.get(n["note_type"], 0) + 1
    for t, c in type_counts.items():
        print(f"    {t:<20} {c}")

    print("\nGenerating Dataset B: historical articles ...")
    hist = generate_articles(TOPIC_VOCAB, n_hist_per, "HIST")

    # Training file: NO topic label — LDA must discover topics unsupervised
    HIST_COLS = ["article_id", "title", "abstract", "full_text", "keywords"]
    save_csv(hist, out / "historical_articles.csv", columns=HIST_COLS)

    # Post-hoc labeling reference: 3 known examples per topic for human interpretation
    # Use these AFTER LDA training to match numbered topics to subject labels.
    label_examples = []
    for topic_key in TOPIC_VOCAB:
        topic_rows = [a for a in hist if a["_topic"] == topic_key]
        for row in topic_rows[:3]:
            label_examples.append({
                "article_id": row["article_id"],
                "topic_label": topic_key,
                "title": row["title"],
                "keywords": row["keywords"],
            })
    save_csv(label_examples, out / "topic_label_examples.csv")

    hist_topics = {}
    for a in hist:
        hist_topics[a["_topic"]] = hist_topics.get(a["_topic"], 0) + 1
    for t, c in hist_topics.items():
        print(f"    {t:<25} {c}")

    print("\nGenerating Dataset C: NEW emerging articles ...")
    new_arts = generate_articles(NEW_TOPIC_VOCAB, n_new_per, "NEW")

    # Rename _topic → true_new_topic for evaluation; still not used during detection
    NEW_COLS = ["article_id", "true_new_topic", "title", "abstract", "full_text", "keywords"]
    new_arts_renamed = [
        {**{k: v for k, v in a.items() if k != "_topic"}, "true_new_topic": a["_topic"]}
        for a in new_arts
    ]
    save_csv(new_arts_renamed, out / "new_articles.csv", columns=NEW_COLS)

    new_topics = {}
    for a in new_arts:
        new_topics[a["_topic"]] = new_topics.get(a["_topic"], 0) + 1
    for t, c in new_topics.items():
        print(f"    {t:<25} {c}")

    # Print an example to show the vocabulary gap
    print("\nSample from historical corpus (cardiology):")
    ex = next(a for a in hist if a["_topic"] == "cardiology")
    print(f"  Title: {ex['title']}")
    print(f"  Keys : {ex['keywords']}")

    print("\nSample from NEW corpus (long_covid):")
    ex2 = next(a for a in new_arts if a["_topic"] == "long_covid")
    print(f"  Title: {ex2['title']}")
    print(f"  Keys : {ex2['keywords']}")

    print("\nVocabulary overlap check:")
    hist_words = set(w for a in hist for w in a["keywords"].split("; "))
    new_words  = set(w for a in new_arts for w in a["keywords"].split("; "))
    overlap    = hist_words & new_words
    print(f"  Historical vocab size : {len(hist_words)}")
    print(f"  New article vocab size: {len(new_words)}")
    print(f"  Overlap               : {len(overlap)} words  ({overlap})")
    print("  (Low overlap confirms new articles require new topics in LDA)")
