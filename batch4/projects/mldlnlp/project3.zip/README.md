# Mini-Project 3: Information Extraction & Theme Discovery


## The Problem

Two complementary clinical NLP challenges:

**Part A — Clinical Entity Extraction with Negation**
> *"A search for 'patients with pneumonia' must NOT return notes saying
> 'no pneumonia', 'pneumonia ruled out', or 'if patient develops pneumonia'."*

Without negation-aware NER, clinical information retrieval, disease phenotyping,
and adverse event detection are fatally flawed.

**Part B + C — Topic Discovery in Research Literature**
> *"Given 500 historical medical articles, identify the core research themes.
> Then, when 150 new articles arrive covering topics we have never seen before,
> automatically detect and characterise the new themes."*

This is the real problem faced by systematic review pipelines, evidence
surveillance systems, and research trend analytics tools.

---

## Three Datasets

| Dataset | File | Size | Purpose |
|---|---|---|---|
| Clinical Notes | `clinical_notes.csv` | 200 notes | NER + NegEx evaluation |
| Historical Articles | `historical_articles.csv` | 500 articles | LDA training corpus |
| New / Emerging Articles | `new_articles.csv` | 150 articles | New topic detection |

### The NegEx challenge (Dataset A)

Notes are labelled by type:

| Note type | Example | Ground truth |
|---|---|---|
| `affirmed` | "Patient presents with fever" | fever: AFFIRMED |
| `negated_pre` | "No fever. Denies chest pain." | fever: NEGATED, chest pain: NEGATED |
| `negated_post` | "Fever was ruled out." | fever: NEGATED |
| **`pseudo_negated`** | **"No change in hypertension."** | **hypertension: AFFIRMED** |
| `mixed` | "History of HTN. No fever." | HTN: HISTORICAL, fever: NEGATED |

The **pseudo-negated** type is the trap: `"no change in X"` looks negative but
X is still **present**. Standard NegEx must handle this with a special pre-check.

### The vocabulary gap (Datasets B vs C)

```
Historical corpus (5 known topics):
  oncology, cardiology, diabetes, infectious_disease, neurology

New articles corpus (3 new topics — NOT in historical corpus):
  long_covid    → brain fog, PASC, dysautonomia, spike protein persistence
  mrna_therapeutics → lipid nanoparticle, pseudouridine, in vitro transcription
  ai_diagnosis  → foundation model, vision transformer, zero-shot, CLIP
```

The vocabulary overlap between datasets B and C is **< 5 words**.
An LDA model trained on B assigns new articles max-topic-probabilities of 0.15–0.30
(poorly explained). This is the signal your new-topic detector should exploit.

---

## Directory Structure

```
project3/
├── README.md               ← you are here
├── rubric.md
├── requirements.txt
├── data/
│   ├── generate_dataset.py
│   ├── clinical_notes.csv
│   ├── historical_articles.csv
│   └── new_articles.csv
└── starter/
    ├── schemas.py          ← Pydantic output schemas  (DO NOT MODIFY)
    ├── negex.py            ← NegEx algorithm           (Tasks 1, 2, 3)
    ├── ner.py              ← NER pipeline              (Tasks 5, 6)
    ├── topic_model.py      ← LDA, NMF, BERTopic        (Tasks 7, 8, 9)
    ├── evaluate.py         ← All evaluation utilities  (Task 10)
    └── main.py             ← End-to-end orchestration
```

---

## Quick Start

```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
python -m nltk.downloader stopwords

# Generate datasets
python data/generate_dataset.py

# Run everything (requires Task implementations)
python starter/main.py --part all --k 5
```

---

## Student Tasks (10 TODOs)

| Task | File | What to implement |
|---|---|---|
| **1** | `negex.py` | `_classify_entity()` — core NegEx algorithm |
| **2** | `negex.py` | `_is_pseudo_negation()` — pseudo-negation pre-check |
| **3** | `negex.py` | Scope terminators — stop negation at "but", ";", "however" |
| **4** | `negex.py` | Hypothetical + historical context detection |
| **5** | `ner.py` | Extend `CLINICAL_GAZETTEER` with ≥20 new entries |
| **6** | `ner.py` | `ClinicalBERTNER.extract()` — HuggingFace pipeline |
| **7** | `topic_model.py` | Coherence sweep + optimal K selection |
| **8** | `topic_model.py` | `detect_new_topics()` — max-probability novelty signal |
| **9** | `topic_model.py` | `BERTopicModel.fit()` + `assign_topics()` |
| **10**| `evaluate.py` | Topic coherence sweep + comparison table |

---

## Core Concepts

### NegEx algorithm (Chapman et al., 2001)

```
Input : "No fever. Patient denies chest pain. No change in hypertension."
Entities: fever (3-8), chest pain (28-38), hypertension (52-64)

Step 1: Pseudo-negation check FIRST
  "No change in hypertension" → PSEUDO → hypertension = AFFIRMED  ✓

Step 2: Pre-window of fever (window=6)
  Pre-window: "No"
  PRE_TRIGGERS match "No" → fever = NEGATED (trigger: "No")  ✓

Step 3: Pre-window of chest pain
  Pre-window: "Patient denies"
  PRE_TRIGGERS match "denies" → chest pain = NEGATED (trigger: "denies")  ✓

Step 4: Scope terminators
  "No fever, but patient has cough"
  "but" terminates scope → cough = AFFIRMED  ✓ (scope doesn't bleed)
```

### Why pseudo-negation is a hard problem

| Phrase | Naive prediction | Correct prediction |
|---|---|---|
| "No fever" | fever: NEGATED | fever: NEGATED ✓ |
| "No change in fever" | fever: NEGATED | fever: **AFFIRMED** ✗ |
| "No improvement in fever" | fever: NEGATED | fever: **AFFIRMED** ✗ |
| "No worsening of fever" | fever: NEGATED | fever: **AFFIRMED** ✗ |
| "No evidence of fever" | fever: NEGATED | fever: NEGATED ✓ |

The pseudo-negation list must be checked BEFORE the standard pre-trigger check.

### LDA topic modelling

LDA assumes:
- A document is a **mixture of topics** (e.g., 80% cardiology, 20% infectious disease)
- Each topic is a **distribution over words** (cardiology topic: high probability for "statin", "hypertension", "myocardial")

Training (on historical corpus only):
1. Initialise each word to a random topic
2. Iteratively reassign: given the topic of all other words, what topic should this word be?
3. Repeat until stable (passes)

**Key parameters:**
- `K` (n_topics): the number of topics — too few → broad overlapping; too many → split topics
- `alpha`: document-topic Dirichlet prior — low = documents dominated by few topics
- `eta`: topic-word Dirichlet prior — low = topics dominated by few sharp words

### New topic detection: the max-probability signal

```python
# Historical LDA (K=5) assigns a new article this distribution:
# Topic 0 (oncology)    : 0.18
# Topic 1 (cardiology)  : 0.22
# Topic 2 (diabetes)    : 0.15
# Topic 3 (infect. dis.): 0.19
# Topic 4 (neurology)   : 0.26
#                          ↑
#                          max = 0.26  <  threshold 0.35
#                          → NOVEL TOPIC ALERT  ✓

# For a truly historical article (cardiology):
# Topic 1 (cardiology)  : 0.71   ← clearly fits
# max = 0.71  >=  threshold 0.35
# → NO ALERT  ✓
```

### BERTopic vs LDA

| | LDA | BERTopic |
|---|---|---|
| Representation | Bag-of-words (TF) | Sentence embeddings (semantic) |
| Topic "new" signal | Low max-probability | Cluster label = -1 (outlier) |
| Requires GPU | No | Recommended |
| Topic words | Top-probability words | c-TF-IDF class words |
| Short text quality | Poor | Good |
| Reproducibility | Good (random_state) | Moderate (UMAP stochastic) |
| Clinical domain | General | Richer with domain sentence-transformers |

---

## Experiments to Run

### Experiment 1: NegEx ablation

```
Test set: clinical_notes.csv  (note_type column = ground truth)

Condition A: run ner.extract(text, apply_negex=False)
Condition B: run ner.extract(text, apply_negex=True)
Condition C: run ner.extract with pseudo-negation DISABLED

Measure: negation recall, precision, F1
Expected: Condition B >> Condition A;
          Condition B >= Condition C on pseudo-negated notes
```

### Experiment 2: LDA K selection

Run `topic_coherence_sweep(texts_proc, range(2, 10))`.
Expected: coherence peaks around K=5 (the true number of historical topics).
What happens to topics when K=8 on historical corpus? (over-splitting)
What happens when K=8 on historical + new corpus? (new topics emerge!)

### Experiment 3: New topic detection threshold sweep

```python
for threshold in [0.20, 0.25, 0.30, 0.35, 0.40, 0.50]:
    alerts = detect_new_topics(new_ids, new_raw, new_proc, lda, threshold)
    evaluate_new_topic_detection(alerts, new_df)
```
Plot precision and recall vs threshold. What is the F1-maximising threshold?

### Experiment 4: ClinicalBERT vs Gazetteer

If ClinicalBERT is available (large download), compare:
- Entity F1 on clinical_notes.csv
- Negation recall with and without NegEx integration
- Which entities does ClinicalBERT find that the gazetteer misses?

---

## Output Format

### NER output (Pydantic-validated JSON)

```json
{
  "doc_id": "NOTE-0042",
  "source_text": "No fever. Denies chest pain. No change in hypertension.",
  "entities": [
    {
      "text": "fever",
      "entity_type": "symptom",
      "negation": "negated",
      "negation_trigger": "No",
      "start_char": 3,
      "end_char": 8,
      "negex_window": "No [ENTITY]"
    },
    {
      "text": "chest pain",
      "entity_type": "symptom",
      "negation": "negated",
      "negation_trigger": "denies",
      "start_char": 17,
      "end_char": 27,
      "negex_window": "Patient denies [ENTITY]"
    },
    {
      "text": "hypertension",
      "entity_type": "condition",
      "negation": "affirmed",
      "negation_trigger": null,
      "negex_window": "No change in [ENTITY]"
    }
  ],
  "n_entities": 3,
  "n_negated": 2,
  "n_affirmed": 1,
  "model_used": "negex+gazetteer"
}
```

### New topic alert (Pydantic-validated JSON)

```json
{
  "doc_id": "NEW-00012",
  "title": "Lipid nanoparticle optimisation for VEGF mRNA delivery.",
  "max_probability": 0.19,
  "novelty_threshold": 0.35,
  "is_novel": true,
  "suggested_cluster": 1,
  "representative_terms": ["lipid nanoparticle", "pseudouridine", "codon optimisation"],
  "alert_reason": "Max historical topic probability 0.19 < threshold 0.35."
}
```

---

## Report Structure (≤ 5 pages)

1. **NegEx analysis** — negation recall before/after NegEx; pseudo-negation examples; scope terminator demonstration.

2. **NER comparison** — Gazetteer vs spaCy vs ClinicalBERT table; analysis of which entity types each approach handles better.

3. **LDA coherence** — elbow plot; chosen K and justification; top words per topic mapped to true topic labels.

4. **New topic detection** — threshold sweep plot; precision/recall table; cluster characterisation (what words define each new cluster?).

5. **BERTopic vs LDA** — qualitative + quantitative comparison; which approach would you deploy in a real clinical NLP pipeline and why?

---

## Grading

See [rubric.md](rubric.md) — 100 points + up to 10 bonus.
