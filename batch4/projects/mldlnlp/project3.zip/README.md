# Mini-Project 3: Information Extraction & Theme Discovery

Two complementary clinical NLP challenges — covered in two separate use cases below.

---

# Use Case A — Clinical Entity Extraction with Negation

> *"A search for 'patients with pneumonia' must NOT return notes saying
> 'no pneumonia', 'pneumonia ruled out', or 'if patient develops pneumonia'."*

Without negation-aware NER, clinical information retrieval, disease phenotyping,
and adverse event detection are fatally flawed.

## Dataset A — Clinical Notes

**File:** `data/clinical_notes.csv`  
**Size:** 200 notes  
**Role:** **Golden / Test set** (do NOT use for training)

> **Important:** This file contains human-labelled ground-truth annotations.
> The `note_type` column and the `entities` column tell you the *correct answer*.
> You will run your NER + negation pipeline on the raw `text` column and compare
> your predictions against these labels to measure accuracy.
> **Do not train any model on this file.**

Notes are labelled by negation type:

| `note_type` | Example text | What the label means |
|---|---|---|
| `affirmed` | "Patient presents with fever" | fever: **AFFIRMED** — entity is present |
| `negated_pre` | "No fever. Denies chest pain." | fever: **NEGATED**, chest pain: **NEGATED** |
| `negated_post` | "Fever was ruled out." | fever: **NEGATED** |
| **`pseudo_negated`** | **"No change in hypertension."** | hypertension: **AFFIRMED** — looks negative but is NOT |
| `mixed` | "History of HTN. No fever." | HTN: **HISTORICAL**, fever: **NEGATED** |

The **pseudo-negated** type is the key trap: `"no change in X"` looks negative
but X is still **present**. Standard NegEx must handle this with a special pre-check.

---

## Part A — NER: Recommended Approach — Clinical NLP Model

**Do not use a plain rule-based gazetteer as your primary NER system.**
Clinical text contains spelling variants, abbreviations, and novel terms that
simple dictionary lookup will silently miss. Use a pre-trained **clinical NLP model**
as your primary recogniser.

### Recommended: scispaCy + BC5CDR model

[scispaCy](https://allenai.github.io/scispacy/) provides spaCy-compatible models
trained on biomedical and clinical corpora.

```bash
pip install scispacy
pip install https://s3-us-west-2.amazonaws.com/ai2-s2-scispacy/releases/v0.5.4/en_ner_bc5cdr_md-0.5.4.tar.gz
```

```python
import spacy
nlp = spacy.load("en_ner_bc5cdr_md")   # recognises CHEMICAL and DISEASE entities

doc = nlp("Patient has fever and was prescribed metformin.")
for ent in doc.ents:
    print(ent.text, ent.label_)
# fever        DISEASE
# metformin    CHEMICAL
```

Other useful scispaCy models:

| Model | Entities recognised | Size |
|---|---|---|
| `en_ner_bc5cdr_md` | Disease, Chemical | ~50 MB |
| `en_ner_craft_md` | Cell, Gene, Protein, Chemical, Disease | ~50 MB |
| `en_core_sci_lg` | General biomedical entities | ~150 MB |

### Alternative (advanced): ClinicalBERT / BioBERT

For state-of-the-art accuracy, use a HuggingFace transformer pipeline:

```python
from transformers import pipeline

ner_pipeline = pipeline(
    "ner",
    model="emilyalsentzer/Bio_ClinicalBERT",
    aggregation_strategy="simple",   # merges sub-word tokens
)
results = ner_pipeline("Patient has fever and was prescribed metformin.")
# Each result: {'entity_group': 'B-Disease', 'word': 'fever', 'score': 0.99, ...}
```

> **Note:** ClinicalBERT downloads ~400 MB and benefits from a GPU.
> scispaCy is the recommended starting point.

---

### What is a Gazetteer — and why keep it as a baseline?

A **gazetteer** is a curated lookup dictionary that maps known phrases to
entity types. It performs *exact-match* (or case-insensitive) string search.

**How it does domain-specific NER:**
1. A human expert (or ontology, e.g., SNOMED-CT, RxNorm, UMLS) compiles a list
   of known clinical terms: `"hypertension" → CONDITION`, `"metformin" → DRUG`, etc.
2. At inference time, the gazetteer scans the text for any of those phrases
   (longest match first, to prefer "chest pain" over "pain").
3. Any match triggers an entity span — no model weights, no training data.

**When a gazetteer is useful:**
- Zero training data required — works day one.
- Perfect precision on in-vocabulary terms (no false positives for known entries).
- Deterministic and auditable — you can always explain why an entity was found.
- Great for controlled vocabularies: ICD codes, drug brand names, lab test names.

**When a gazetteer fails:**
- Spelling variants: "dyspnoea" vs "dyspnea", "haemoptysis" vs "hemoptysis".
- Abbreviations not in the dictionary: "SOB" (shortness of breath), "HTN" (hypertension).
- Novel terms (new drugs, newly coined syndromes) never added to the dictionary.
- Context-dependent meaning: "MI" = myocardial infarction or Michigan?

**Use the gazetteer as a fast baseline** to compare against the clinical model.
This comparison is itself a learning objective of the project.

---

## Part A — Negation Detection: Two Approaches

### Option 1 — Manual NegEx (implement in `negex.py`)

The NegEx algorithm (Chapman et al., 2001) scans a fixed-size window around
each entity for trigger words:

```
Input : "No fever. Patient denies chest pain. No change in hypertension."
Entities: fever, chest pain, hypertension

Step 1: Pseudo-negation check FIRST
  "No change in hypertension" → PSEUDO → hypertension = AFFIRMED  ✓

Step 2: Pre-window of fever (window=6 tokens)
  Pre-window: "No"
  PRE_TRIGGERS match "No" → fever = NEGATED (trigger: "No")  ✓

Step 3: Pre-window of chest pain
  Pre-window: "Patient denies"
  PRE_TRIGGERS match "denies" → chest pain = NEGATED (trigger: "denies")  ✓

Step 4: Scope terminators
  "No fever, but patient has cough"
  "but" terminates scope → cough = AFFIRMED  ✓ (scope doesn't bleed)
```

You will implement this algorithm yourself in `starter/negex.py` (Tasks 1–4).

---

### Option 2 — negspaCy (ready-to-use library)

[negspaCy](https://github.com/NLP4PA/negspacy) is a spaCy pipeline component that
implements NegEx automatically. You add it as a pipe to any spaCy model and it
annotates each entity with a `._.negex` boolean attribute.

```bash
pip install negspacy
```

```python
import spacy
from negspacy.negation import Negex

# Load any spaCy or scispaCy model
nlp = spacy.load("en_ner_bc5cdr_md")

# Add the negation component — must come AFTER the NER component
nlp.add_pipe("negex")

doc = nlp("Patient has no fever and denies chest pain.")
for ent in doc.ents:
    print(ent.text, "→ negated:", ent._.negex)
# fever       → negated: True
# chest pain  → negated: True
```

**Customising negspaCy for clinical text:**

negspaCy ships with a default trigger list but you can extend it:

```python
nlp.add_pipe(
    "negex",
    config={
        "neg_termset": "en_clinical",   # use clinical-domain trigger list
        "chunk_prefix": ["no", "denies", "without", "absent"],
    }
)
```

**negspaCy vs manual NegEx — when to use which:**

| | Manual NegEx (Task 1–4) | negspaCy |
|---|---|---|
| Learning value | High — you see every step | Low — black box |
| Clinical coverage | What you implement | Pre-built, tested on clinical corpora |
| Pseudo-negation | You must handle explicitly | Handled by default trigger list |
| Scope terminators | You must implement | Built-in |
| Integration effort | Moderate | One `add_pipe` line |
| Production use | Not recommended | Suitable |

**Recommendation:** Implement Tasks 1–4 manually to understand the algorithm, then
validate your implementation against negspaCy on the same test notes.

---

### Why pseudo-negation is a hard problem

| Phrase | Naive prediction | Correct prediction |
|---|---|---|
| "No fever" | fever: NEGATED | fever: NEGATED ✓ |
| "No change in fever" | fever: NEGATED | fever: **AFFIRMED** ✗ |
| "No improvement in fever" | fever: NEGATED | fever: **AFFIRMED** ✗ |
| "No worsening of fever" | fever: NEGATED | fever: **AFFIRMED** ✗ |
| "No evidence of fever" | fever: NEGATED | fever: NEGATED ✓ |

The pseudo-negation list must be checked BEFORE the standard pre-trigger check.

---

## Part A — Student Tasks

| Task | File | What to implement |
|---|---|---|
| **1** | `negex.py` | `_classify_entity()` — core NegEx algorithm |
| **2** | `negex.py` | `_is_pseudo_negation()` — pseudo-negation pre-check |
| **3** | `negex.py` | Scope terminators — stop negation at "but", ";", "however" |
| **4** | `negex.py` | Hypothetical + historical context detection |
| **5** | `ner.py` | Load scispaCy (`en_ner_bc5cdr_md`) and extract entities |
| **6** | `ner.py` | Integrate negation (negspaCy or your NegEx) with scispaCy |

---

## Part A — Experiments

### Experiment 1: NegEx ablation

```
Test set: data/clinical_notes.csv  (note_type column = ground truth labels)

Condition A: run ner.extract(text, apply_negex=False)  — no negation detection
Condition B: run ner.extract(text, apply_negex=True)   — with NegEx
Condition C: run ner.extract with pseudo-negation DISABLED

Measure: negation recall, precision, F1
Expected: Condition B >> Condition A;
          Condition B >= Condition C on pseudo-negated notes
```

### Experiment 2: NER system comparison

```
Test set: data/clinical_notes.csv

System A: Gazetteer (baseline — rule-based dictionary lookup)
System B: scispaCy en_ner_bc5cdr_md
System C: ClinicalBERT (if available)

Measure: entity-level precision, recall, F1
Expected: System B and C >> System A on novel / abbreviated entities
```

---

## Part A — NER Output Format (Pydantic-validated JSON)

```json
{
  "doc_id": "NOTE-0042",
  "source_text": "No fever. Denies chest pain. No change in hypertension.",
  "entities": [
    {
      "text": "fever",
      "entity_type": "symptom",
      "negation": "negated",
      "negation_trigger": "No",
      "start_char": 3,
      "end_char": 8,
      "negex_window": "No [ENTITY]"
    },
    {
      "text": "chest pain",
      "entity_type": "symptom",
      "negation": "negated",
      "negation_trigger": "denies",
      "start_char": 17,
      "end_char": 27,
      "negex_window": "Patient denies [ENTITY]"
    },
    {
      "text": "hypertension",
      "entity_type": "condition",
      "negation": "affirmed",
      "negation_trigger": null,
      "negex_window": "No change in [ENTITY]"
    }
  ],
  "n_entities": 3,
  "n_negated": 2,
  "n_affirmed": 1,
  "model_used": "scispacy+negspacy"
}
```

---
---

# Use Case B — Topic Discovery in Research Literature

> *"Given 500 historical medical articles, identify the core research themes.
> Then, when 150 new articles arrive covering topics we have never seen before,
> automatically detect and characterise the new themes."*

This is the real problem faced by systematic review pipelines, evidence
surveillance systems, and research trend analytics tools.

---

## Datasets B, B½ and C — Research Articles

### Dataset B — Historical Articles (LDA training corpus)

**File:** `data/historical_articles.csv`  
**Size:** 500 articles  
**Columns:** `article_id`, `title`, `abstract`, `full_text`, `keywords`  
**Role:** Feed the raw text to LDA — **no topic labels are present in this file**

> **LDA is fully unsupervised.** You build a bag-of-words matrix from the raw
> `full_text` column and pass it to LDA. The model discovers latent topics purely
> from word co-occurrence patterns — it is never told what the topics are or how
> many there should be. The expected optimal `K` is **5**, but your coherence
> sweep (Task 7) must find this empirically.

---

### Dataset B½ — Topic Label Examples (post-hoc interpretation only)

**File:** `data/topic_label_examples.csv`  
**Size:** 15 articles (3 per subject area)  
**Columns:** `article_id`, `topic_label`, `title`, `keywords`  
**Role:** Help you assign human-readable names to the numbered topics LDA produces

> **Do NOT use this file during LDA training.** Open it only after training,
> to help understand what each discovered topic represents.
> See the "How to label LDA topics" section below for the workflow.

---

### Dataset C — New / Emerging Articles (Test set)

**File:** `data/new_articles.csv`  
**Size:** 150 articles  
**Role:** **Test / evaluation set** — do NOT train on this file

> **Important:** These 150 articles intentionally cover topics that were **not
> present** in the historical corpus. The vocabulary overlap with Dataset B is
> **< 5 words**. Your LDA model (trained unsupervised on Dataset B) will produce
> low max-topic-probabilities for these articles — that "poor fit" signal is
> exactly what your new-topic detector should exploit.
>
> The file contains a `true_new_topic` column with ground-truth labels. This is
> also **not a training signal** — LDA never sees it. Use it **only after
> detection** to evaluate whether the topics your system flagged match the real
> new areas.

### What new topics are being detected?

The 150 new articles come from **3 entirely new research areas** that emerged
after the historical corpus was compiled:

---

#### New Topic 1 — `long_covid`

This cluster represents the wave of research following the COVID-19 pandemic into
**Post-Acute Sequelae of SARS-CoV-2 infection (PASC)**, a syndrome where patients
continue to experience symptoms months after the acute infection has resolved.

Key distinguishing terms you should see in this cluster's top words:
- **brain fog** — cognitive impairment and difficulty concentrating
- **PASC** — the clinical abbreviation for post-acute sequelae
- **dysautonomia** — dysfunction of the autonomic nervous system (heart rate,
  blood pressure dysregulation) prominent in long COVID patients
- **spike protein persistence** — evidence that viral spike protein fragments
  persist in tissues long after infection, a proposed mechanism for ongoing
  inflammation
- **fatigue**, **post-exertional malaise** — hallmark symptoms distinguishing
  long COVID from simple recovery

Why this is a *new* topic: the historical cardiology, infectious disease, and
neurology topics all share partial vocabulary with long COVID, but none fully
explains it. An LDA model trained on the historical corpus assigns long COVID
articles low max-probability (< 0.30) to every known topic — a clear novel signal.

---

#### New Topic 2 — `mrna_therapeutics`

This cluster captures the surge in research following the successful deployment
of mRNA COVID-19 vaccines, extending into broader mRNA-based drug development.

Key distinguishing terms:
- **lipid nanoparticle (LNP)** — the delivery vehicle that encapsulates mRNA
  and enables it to enter cells without being degraded
- **pseudouridine** — a chemically modified nucleotide (replacing uridine) that
  prevents the immune system from attacking the synthetic mRNA, critical for
  tolerability
- **in vitro transcription (IVT)** — the manufacturing process for producing
  synthetic mRNA at scale
- **codon optimisation** — rewriting the mRNA sequence to maximise protein
  production in human cells while preserving the encoded protein structure
- **VEGF**, **CAR-T** — application domains (cancer therapy, gene therapy)
  now being targeted with mRNA approaches

Why this is a *new* topic: the historical drug/chemical vocabulary (metformin,
warfarin, vancomycin) bears no lexical resemblance to lipid nanoparticle or
pseudouridine. LDA assigns these articles diffuse distributions across all 5
known topics with no clear dominant topic.

---

#### New Topic 3 — `ai_diagnosis`

This cluster captures the application of modern deep learning and foundation
models to medical image interpretation and clinical decision support.

Key distinguishing terms:
- **foundation model** — large pre-trained models (e.g., GPT-4V, Med-PaLM)
  adapted to medical tasks with minimal fine-tuning
- **vision transformer (ViT)** — the transformer architecture applied to
  medical images (X-ray, MRI, pathology slides) replacing CNN-based approaches
- **zero-shot** — the ability of foundation models to perform diagnostic tasks
  on disease categories they were never explicitly trained on
- **CLIP** — Contrastive Language-Image Pre-training; a model that learns joint
  representations of medical images and text, enabling text-guided image search
- **radiology report generation**, **pathology classification**, **fundus image** —
  specific clinical application domains driving this research

Why this is a *new* topic: historical neurology and oncology articles discuss
imaging (CT, MRI) but at a clinical/procedural level. The new AI articles discuss
model architectures, training strategies, and benchmark datasets — a vocabulary
that did not exist in the historical corpus.

---

### The vocabulary gap — why this is hard

```
Historical corpus vocabulary (sample):
  statin, myocardial, insulin, HbA1c, sepsis, bacteraemia, seizure, cortex

New articles vocabulary (sample):
  lipid nanoparticle, pseudouridine, PASC, dysautonomia,
  vision transformer, zero-shot, foundation model, CLIP
```

Overlap: **< 5 words**. A trained LDA(K=5) assigns new articles
max-topic-probabilities of **0.15–0.30** (none of the 5 known topics fits well).
This is the signal your detector exploits.

---

## Part B — Student Tasks

| Task | File | What to implement |
|---|---|---|
| **7** | `topic_model.py` | Coherence sweep + optimal K selection |
| **8** | `topic_model.py` | `detect_new_topics()` — max-probability novelty signal |
| **9** | `topic_model.py` | `BERTopicModel.fit()` + `assign_topics()` |
| **10**| `evaluate.py` | Topic coherence sweep + comparison table |

---

## Part B — LDA: Core Concepts

### LDA does not label its own topics — you must do it

When LDA finishes training it produces **numbered topics**: Topic 0, Topic 1, …, Topic K-1.
Each topic is a ranked list of the words most strongly associated with it.
LDA has no idea what "cardiology" or "oncology" means — it only knows word frequencies.

**Example output after training LDA(K=5) on the historical corpus:**

```
Topic 0 top words: statin, myocardial, hypertension, troponin, arrhythmia, LVEF, ejection
Topic 1 top words: insulin, HbA1c, glycaemic, GLP-1, SGLT2, metformin, beta cell
Topic 2 top words: tumor, chemotherapy, PD-L1, metastasis, pembrolizumab, VEGF, apoptosis
Topic 3 top words: pathogen, antibiotic, sepsis, bacteraemia, MRSA, carbapenem, virulence
Topic 4 top words: tau, amyloid, dopamine, Alzheimer, stroke, neuroprotection, cerebrospinal
```

A human looks at these lists and assigns labels:

```
Topic 0  →  cardiology         (statin, myocardial, troponin)
Topic 1  →  diabetes           (insulin, HbA1c, GLP-1)
Topic 2  →  oncology           (tumor, chemotherapy, PD-L1)
Topic 3  →  infectious_disease (pathogen, antibiotic, sepsis)
Topic 4  →  neurology          (tau, amyloid, Alzheimer)
```

**Step-by-step labeling workflow:**

1. Train LDA and extract top-10 words per topic:
   ```python
   for topic_id, word_dist in lda_model.show_topics(num_words=10):
       print(f"Topic {topic_id}: {word_dist}")
   ```

2. Open `data/topic_label_examples.csv`. For each `topic_label` (e.g., `cardiology`),
   look at the `keywords` column to see the vocabulary you expect in that topic.

3. Compare LDA's top words against the example keywords. The topic whose top words
   best overlap with a label's keywords gets assigned that label.

4. Record your mapping (e.g., `{0: "cardiology", 1: "diabetes", ...}`).
   This mapping is only for your report — it is not fed back into LDA.

> **No perfect mapping is guaranteed.** LDA may split a topic, merge two, or
> produce one broad "mixed" topic. Part of the exercise is to reason about why
> this happens (see Experiment 3 on K selection).

---

LDA assumes:
- A document is a **mixture of topics** (e.g., 80% cardiology, 20% infectious disease)
- Each topic is a **distribution over words** (cardiology topic: high probability for
  "statin", "hypertension", "myocardial")

Training (on **historical corpus only**):
1. Initialise each word to a random topic
2. Iteratively reassign: given the topic of all other words, what topic should this word be?
3. Repeat until stable

**Key parameters:**
- `K` (n_topics): the number of topics — too few → broad overlapping; too many → split topics
- `alpha`: document-topic Dirichlet prior — low = documents dominated by few topics
- `eta`: topic-word Dirichlet prior — low = topics dominated by few sharp words

### New topic detection: the max-probability signal

```python
# Historical LDA (K=5) assigns a new article (long_covid) this distribution:
# Topic 0 (oncology)         : 0.18
# Topic 1 (cardiology)       : 0.22
# Topic 2 (diabetes)         : 0.15
# Topic 3 (infect. disease)  : 0.19
# Topic 4 (neurology)        : 0.26
#                               ↑
#                               max = 0.26  <  threshold 0.35
#                               → NOVEL TOPIC ALERT  ✓
#
# This article is about PASC / brain fog / dysautonomia.
# None of the 5 known topics can claim it — it belongs to a new topic.

# For a truly historical article (cardiology):
# Topic 1 (cardiology)  : 0.71   ← clearly fits
# max = 0.71  >=  threshold 0.35
# → NO ALERT  ✓
```

### BERTopic vs LDA

| | LDA | BERTopic |
|---|---|---|
| Representation | Bag-of-words (TF) | Sentence embeddings (semantic) |
| Topic "new" signal | Low max-probability | Cluster label = -1 (outlier) |
| Requires GPU | No | Recommended |
| Topic words | Top-probability words | c-TF-IDF class words |
| Short text quality | Poor | Good |
| Reproducibility | Good (random_state) | Moderate (UMAP stochastic) |
| Clinical domain | General | Richer with domain sentence-transformers |

---

## Part B — Experiments

### Experiment 3: LDA K selection

Run `topic_coherence_sweep(texts_proc, range(2, 10))` on **historical corpus only**.
Expected: coherence peaks around K=5 (the true number of historical topics).

Questions to answer:
- What happens to topics when K=8 on historical corpus alone? (over-splitting)
- What happens when K=8 on **combined** historical + new corpus? (new topics emerge!)
- Can you label the 3 extra topics when K=8 on the combined corpus using the
  top words (brain fog, lipid nanoparticle, vision transformer)?

### Experiment 4: New topic detection threshold sweep

```python
for threshold in [0.20, 0.25, 0.30, 0.35, 0.40, 0.50]:
    alerts = detect_new_topics(new_ids, new_raw, new_proc, lda, threshold)
    evaluate_new_topic_detection(alerts, new_df)   # uses true_new_topic column
```

Plot precision and recall vs threshold. What is the F1-maximising threshold?
At the best threshold, which of the 3 new topics is easiest to detect and why?

### Experiment 5: BERTopic on new articles

Run BERTopic on the 150 new articles. Does it recover 3 distinct clusters?
Do the cluster keywords match `long_covid`, `mrna_therapeutics`, `ai_diagnosis`?
Compare cluster quality against the LDA K=8 approach.

---

## Part B — New Topic Alert Output (Pydantic-validated JSON)

```json
{
  "doc_id": "NEW-00012",
  "title": "Lipid nanoparticle optimisation for VEGF mRNA delivery.",
  "max_probability": 0.19,
  "novelty_threshold": 0.35,
  "is_novel": true,
  "suggested_cluster": 1,
  "representative_terms": ["lipid nanoparticle", "pseudouridine", "codon optimisation"],
  "alert_reason": "Max historical topic probability 0.19 < threshold 0.35. Likely new topic: mrna_therapeutics."
}
```

---
---

# Project Setup

## Directory Structure

```
project3/
├── README.md               ← you are here
├── rubric.md
├── requirements.txt
├── data/
│   ├── generate_dataset.py
│   ├── clinical_notes.csv          ← Use Case A: TEST / golden set (labelled)
│   ├── historical_articles.csv     ← Use Case B: LDA TRAINING corpus (no topic labels)
│   ├── topic_label_examples.csv    ← Use Case B: 3 labelled examples per topic, for post-hoc interpretation only
│   └── new_articles.csv            ← Use Case B: TEST / evaluation set (true_new_topic for eval only)
└── starter/
    ├── schemas.py          ← Pydantic output schemas  (DO NOT MODIFY)
    ├── negex.py            ← NegEx algorithm           (Tasks 1–4)
    ├── ner.py              ← NER pipeline              (Tasks 5, 6)
    ├── topic_model.py      ← LDA, NMF, BERTopic        (Tasks 7, 8, 9)
    ├── evaluate.py         ← All evaluation utilities  (Task 10)
    └── main.py             ← End-to-end orchestration
```

## Quick Start

```bash
# Install core dependencies
pip install -r requirements.txt

# Install scispaCy clinical NER model (Use Case A)
pip install scispacy negspacy
pip install https://s3-us-west-2.amazonaws.com/ai2-s2-scispacy/releases/v0.5.4/en_ner_bc5cdr_md-0.5.4.tar.gz

# Install NLTK stopwords (Use Case B)
python -m nltk.downloader stopwords

# Generate datasets
python data/generate_dataset.py

# Run everything (requires Task implementations)
python starter/main.py --part all --k 5
```

---

## Report Structure (≤ 5 pages)

1. **Use Case A — NER comparison** — Gazetteer (baseline) vs scispaCy vs ClinicalBERT.
   Which entities does the clinical model find that the gazetteer misses?

2. **Use Case A — NegEx analysis** — negation recall before/after negation detection;
   pseudo-negation examples; scope terminator demonstration.
   Compare your manual NegEx implementation against negspaCy.

3. **Use Case B — LDA coherence** — elbow plot; chosen K and justification;
   top words per topic mapped to true topic labels.

4. **Use Case B — New topic detection** — threshold sweep plot; precision/recall table;
   cluster characterisation: which words define each new cluster, and do they
   match the expected `long_covid`, `mrna_therapeutics`, `ai_diagnosis` topics?

5. **Use Case B — BERTopic vs LDA** — qualitative + quantitative comparison;
   which approach would you deploy in a real clinical NLP pipeline and why?

---

## Grading

See [rubric.md](rubric.md) — 100 points + up to 10 bonus.
