# Grading Rubric – Information Extraction & Theme Discovery

**Total: 100 points**

---

## 1. Dataset & Problem Understanding (5 pts)

| Criterion | Marks | Evidence Required |
|---|---|---|
| Vocabulary overlap analysis between historical and new corpus | 3 | Number from generate_dataset.py "overlap check"; explain why low overlap matters |
| Demonstrate the pseudo-negation trap with 2+ examples | 2 | Examples where naive "no X" → NEGATED fails |

---

## 2. NegEx Implementation (25 pts)

### 2a. Core algorithm — Task 1 (12 pts)

| Criterion | Marks |
|---|---|
| Pre-negation triggers detected correctly | 4 |
| Post-negation triggers detected correctly | 3 |
| Scope window implemented (not unlimited lookahead) | 3 |
| Historical context (h/o, history of) detected separately | 2 |

### 2b. Pseudo-negation — Task 2 (7 pts)

| Criterion | Marks |
|---|---|
| Pseudo-negation phrases checked BEFORE standard negation | 3 |
| All PSEUDO_NEG_PATTERNS from negex.py handled | 2 |
| Post-entity pseudo patterns handled | 2 |

### 2c. Scope terminators — Task 3 (6 pts)

| Criterion | Marks |
|---|---|
| Negation does NOT propagate past "but", "however", ";" | 4 |
| Example demonstrated: "No fever, but patient has cough" → cough=AFFIRMED | 2 |

**Safety deduction:** If negation recall < 0.70 on the test set → −5 pts (clinically unsafe system).

---

## 3. Named Entity Recognition (15 pts)

### 3a. Gazetteer extension — Task 5 (5 pts)

| Criterion | Marks |
|---|---|
| ≥20 new entries added to CLINICAL_GAZETTEER | 3 |
| Additions justified by false-negative analysis of clinical_notes.csv | 2 |

### 3b. NER evaluation table (5 pts)

| Criterion | Marks |
|---|---|
| All three models compared (Gazetteer, spaCy, ClinicalBERT if attempted) | 3 |
| Per-model: entity F1, negation recall, pseudo-negation accuracy | 2 |

### 3c. ClinicalBERT stub implementation — Task 6 (5 pts)

| Criterion | Marks |
|---|---|
| HuggingFace pipeline correctly called | 3 |
| NegEx integrated with ClinicalBERT output | 2 |

*(3 pts awarded for well-documented attempt even if model download fails)*

---

## 4. Topic Modeling — LDA (20 pts)

### 4a. Coherence sweep — Task 7 (8 pts)

| Criterion | Marks |
|---|---|
| C_v coherence computed for K=2 through K=10 | 4 |
| Elbow plot included in report | 2 |
| Chosen K justified with coherence value ≥ 0.50 | 2 |

### 4b. Hyperparameter analysis (7 pts)

| Criterion | Marks |
|---|---|
| Alpha and eta varied (at least 3 combinations each) | 4 |
| Effect on topic coherence and topic diversity documented | 3 |

### 4c. LDA vs NMF comparison (5 pts)

| Criterion | Marks |
|---|---|
| Both models trained on same corpus | 2 |
| Coherence and diversity compared; qualitative analysis of top words | 3 |

---

## 5. New Topic Detection (20 pts)

### 5a. Perplexity / max-probability detector — Task 8 (12 pts)

| Criterion | Marks |
|---|---|
| detect_new_topics() implemented correctly | 5 |
| Novelty threshold selection justified (not arbitrary 0.5) | 3 |
| Novel articles clustered into candidate topics using cluster_novel_articles() | 4 |

**Expected result:** ≥ 80% of new_articles flagged as novel; ≤ 10% of historical articles falsely flagged.

### 5b. BERTopic comparison — Task 9 (8 pts)

| Criterion | Marks |
|---|---|
| BERTopic fit on historical + new articles combined | 4 |
| Topic -1 (outlier) rate on new vs historical articles compared | 2 |
| Qualitative comparison: are BERTopic topics more meaningful than LDA? | 2 |

---

## 6. Pydantic Output Schema (5 pts)

| Criterion | Marks |
|---|---|
| All outputs pass schema validation (no ValidationError) | 3 |
| NewTopicAlert.novel_flag_consistent validator fires correctly | 2 |

---

## 7. Report Quality (10 pts)

| Criterion | Marks |
|---|---|
| Answers the core clinical IR question: why does NegEx matter? | 3 |
| Topic analysis: do the discovered historical topics match the 5 true categories? | 3 |
| New topic analysis: which method (LDA vs BERTopic) discovered the 3 new topics more cleanly? | 2 |
| Figures labelled; ≤ 5 pages | 2 |

---

## Bonus (up to +10 pts)

| Task | Bonus |
|---|---|
| pyLDAvis interactive visualisation of LDA topics | +3 |
| t-SNE / UMAP plot of document embeddings coloured by topic | +3 |
| Dynamic topic modelling: show how topics evolve when new articles are added | +4 |

---

## Grading Scale

| Band | Score | Description |
|---|---|---|
| Distinction | 85–100 | All tasks; negation recall ≥ 0.85; new topics reliably detected |
| Merit | 70–84 | Tasks 1–3, 7–8; negation recall ≥ 0.70 |
| Pass | 55–69 | Tasks 1–2 attempted; basic LDA working |
| Fail | < 55 | NegEx not implemented; or pseudo-negation not handled |

---

## Submission Checklist

- [ ] `data/clinical_notes.csv`, `historical_articles.csv`, `new_articles.csv` present
- [ ] `starter/negex.py` — `_classify_entity()` implemented (Task 1)
- [ ] `starter/negex.py` — `_is_pseudo_negation()` extended (Task 2)
- [ ] `starter/ner.py` — `CLINICAL_GAZETTEER` extended (Task 5)
- [ ] `starter/topic_model.py` — `detect_new_topics()` implemented (Task 8)
- [ ] `starter/topic_model.py` — `BERTopicModel` implemented (Task 9)
- [ ] `outputs/ner_results.json` validates against Pydantic schema
- [ ] `outputs/new_topic_alerts.json` validates against Pydantic schema
- [ ] Report PDF (≤ 5 pages)
