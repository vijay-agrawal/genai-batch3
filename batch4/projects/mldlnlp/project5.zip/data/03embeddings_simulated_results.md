# Simulated Dense Embedding Search Results

**Query:** `"heart attack"`  
**Retrieval method:** Dense bi-encoder retrieval (SBERT `all-MiniLM-L6-v2` cosine similarity)  
**Number of results returned:** 5 (top-5 from corpus of 20)

---

## What Dense Retrieval Does

A bi-encoder model encodes the query and every document into fixed-size vectors in a shared
semantic space. The score between query and document is the **cosine similarity** of their
vectors. Documents are ranked by descending similarity.

Dense retrieval is **much better at synonyms** than BM25 — "heart attack" and "myocardial
infarction" land close together in embedding space. However, it has no hard logical reasoning
and cannot distinguish *degrees* of relevance within a semantic neighbourhood. In particular:

- It cannot tell whether the topic of a document is the **same condition** or merely a
  *semantically adjacent* condition (e.g., cardiac arrest vs. myocardial infarction).
- It cannot detect **negation** or **context** (a document about avoiding a condition looks
  like a document about treating it).
- It over-retrieves documents in the **same broad topic cluster** (cardiovascular emergencies)
  even when the specific condition is different.

---

## Results (Ranked 1 → 5)

---

### Rank 1 — D11: Cardiac Arrest & CPR Protocol
**Cosine similarity (simulated):** 0.81  
**Relevant to treatment query?** ❌ NO — different condition  
**Why embeddings ranked it first:** "Cardiac arrest" and "heart attack" both describe
life-threatening cardiac events and share a dense vocabulary: "defibrillation", "chest
compressions", "resuscitation", "cardiac", "emergency", "ACLS". The embedding model conflates
these because the two conditions co-occur in training data and clinical texts.

> **The clinical difference:** A heart attack (MI) is a *plumbing problem* — a blocked
> artery causing myocardial necrosis; the patient may be conscious and talking. Cardiac arrest
> is an *electrical problem* — no effective cardiac output; the patient is pulseless and
> unconscious. Treatment protocols are entirely different.

**What you actually get:** CPR compression rates, defibrillation joules, and adrenaline dosing
for cardiac arrest — none of which are relevant to managing an acute MI.

---

### Rank 2 — D13: Acute Heart Failure Management
**Cosine similarity (simulated):** 0.76  
**Relevant to treatment query?** ❌ NO — different condition  
**Why embeddings ranked it second:** "Heart failure" contains "heart"; the document discusses
"cardiogenic shock", "LVEF", "cardiac output" and "acute" decompensation — all terms that
co-embed with MI content. Dense retrieval cannot distinguish between:
- **Acute MI**: plaque rupture → blocked artery → myocardial necrosis (emergency reperfusion needed)
- **Acute Heart Failure**: failing pump (often chronic) → fluid accumulation (diuresis, not PCI)

> *"IV furosemide 40–80 mg if volume overloaded... IV nitrates for preload/afterload reduction..."*
> — diuretics and vasodilators are the treatment here, not antiplatelet therapy or PCI.

**What you actually get:** Diuretic dosing and afterload reduction for heart failure —
completely wrong treatment if applied to an acute MI patient.

---

### Rank 3 — D01: STEMI Treatment Protocol ✓
**Cosine similarity (simulated):** 0.73  
**Relevant to treatment query?** ✅ YES  
**Why embeddings retrieved it:** Dense retrieval correctly maps "heart attack" close to "STEMI"
and "myocardial infarction". Despite using no lay terminology, the document's semantic content
is unmistakably about the same clinical entity.

> *"Administer dual antiplatelet therapy... activate catheterisation laboratory for primary PCI...
> door-to-device goal < 90 minutes..."*
> — the right document, but ranked 3rd, not 1st.

**The problem:** Correct result, wrong rank. A clinical decision-support system that shows
only the top-1 or top-2 results would still fail this query.

---

### Rank 4 — D12: Stroke Emergency Management Protocol
**Cosine similarity (simulated):** 0.71  
**Relevant to treatment query?** ❌ NO — different condition  
**Why embeddings ranked it fourth:** Both stroke and MI are "acute vascular emergencies"
treated with "thrombolytic / reperfusion" therapy. The embedding model assigns high similarity
because the *treatment paradigm* is structurally the same: blocked vessel → thrombolysis or
mechanical removal. It cannot disambiguate brain vessel vs. coronary artery.

> *"Intravenous alteplase (IV-tPA)... mechanical thrombectomy... reperfusion..."*
> — these are stroke reperfusion methods, not coronary reperfusion.

**The clinical danger:** Stroke thrombolysis dosing (alteplase 0.9 mg/kg, max 90 mg) differs
from cardiac thrombolysis (tenecteplase weight-based bolus). Cross-applying these protocols
could be fatal.

---

### Rank 5 — D02: NSTEMI Management Guidelines ✓
**Cosine similarity (simulated):** 0.68  
**Relevant to treatment query?** ✅ YES  
**Why embeddings retrieved it:** "NSTEMI" and "ACS" embed close to "heart attack". The model
correctly identifies this document as being about myocardial infarction management.

> *"NSTEMI is an acute coronary syndrome characterised by elevated high-sensitivity troponin..."*
> — again, a correct document, but ranked 5th.

---

## What Dense Retrieval Missed

Three of the five truly relevant documents were not returned at all:

| Doc | Title | Why Embeddings Missed It |
|-----|-------|--------------------------|
| D03 | ACS Antiplatelet & Anticoagulation | Pharmacy-heavy language ("DAPT", "fondaparinux", "aPTT") shifts the embedding away from the query cluster |
| D04 | Emergency PCI Procedure Note | Procedure-note format with very specific anatomical terms ("LAD occlusion", "radial access") — embedding anchors to "procedure" cluster |
| D05 | Thrombolytic Therapy for STEMI | Research-article style + fibrinolytic terminology ("tenecteplase", "plasminogen", "TIMI") — semantic cluster drifts away from "heart attack" |

**Precision@5: 2/5 = 40 %**  
**Recall@5: 2/5 = 40 %**

---

## Comparison: BM25 vs. Dense Retrieval

| Metric | BM25 | Dense (SBERT) |
|--------|------|---------------|
| Precision@5 | **0 %** | **40 %** |
| Recall@5 | **0 %** | **40 %** |
| Relevant docs in top-2 | 0 | 0 |
| Relevant docs in top-3 | 0 | 1 (rank 3) |
| Relevant docs returned | 0 | 2 (ranks 3 & 5) |
| Missed relevant docs | D01, D02, D03, D04, D05 | D03, D04, D05 |
| Harmful irrelevant docs | legal/admin noise | clinically confusable conditions |

Dense retrieval is **clearly better** than BM25 for this query (40 % vs 0 % precision),
but still returns 3 clinically confusable, potentially dangerous results in the top-5.

---

## Summary: Dense Retrieval's Fundamental Limitations Here

```
BM25 problem:  vocabulary mismatch
               ("heart attack" ≠ "STEMI" as tokens)

Dense problem: semantic over-smoothing
               ("heart attack" ≈ "cardiac arrest" ≈ "heart failure" as vectors)
```

Dense retrieval collapses the distinctions that matter most clinically.
The embedding space has learned that all acute cardiac emergencies are "similar",
which is true at the topic level but catastrophically wrong at the treatment level.

**Both methods fail. This is exactly why reranking exists.**

---

## Questions to Consider Before Reranking

1. In Rank 1 (cardiac arrest), the document even says *"Cardiac arrest must be distinguished
   from myocardial infarction"* — yet the embedder ranked it first. What does this tell you
   about what sentence-level models understand vs. ignore?
2. Why does a cross-encoder reranker handle the BM25 vocabulary problem better than a
   bi-encoder? What is fundamentally different about how they score documents?
3. Can you think of a retrieval scenario where dense retrieval's "semantic smoothing" is
   actually the right behaviour?
4. If you could only use one method from {BM25, dense, cross-encoder, LLM-rerank}, which
   would you choose for a clinical decision-support system — and why?
