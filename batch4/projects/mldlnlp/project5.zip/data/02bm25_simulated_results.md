# Simulated BM25 Search Results

**Query:** `"heart attack"`  
**Retrieval method:** BM25 (Best Match 25 — keyword frequency + inverse document frequency)  
**Number of results returned:** 5 (top-5 from corpus of 20)

---

## What BM25 Does

BM25 scores each document by counting how many query terms appear in it, weighted by:
- **Term Frequency (TF)**: how often "heart" and "attack" appear in the document.
- **Inverse Document Frequency (IDF)**: how rare those words are across the corpus.
- **Document length normalisation**: penalises very long documents for inflated counts.

BM25 has **no understanding of meaning** — it treats "heart attack" as two tokens and
rewards documents that contain those tokens often. It cannot recognise synonyms like
"myocardial infarction", "STEMI", "NSTEMI", or "ACS".

---

## Results (Ranked 1 → 5)

---

### Rank 1 — D10: Heart Attack Awareness Brochure
**BM25 score (simulated):** 18.4  
**Relevant to treatment query?** ❌ NO — lay education document  
**Why BM25 ranked it first:** "heart attack" appears **21 times** in this document.
The brochure is written for the general public and repeats the phrase in every sentence.
BM25's TF component saturates on this high count, placing it at rank 1.

> *"A heart attack happens when blood flow to part of the heart is blocked. A heart attack is a
> medical emergency. Every minute matters during a heart attack..."*
> — 21 occurrences of "heart attack" in 300 words

**What you actually get:** A lay-language list of symptoms and first-aid advice.
No pharmacological protocols, no treatment doses, no clinical decision-making guidance.

---

### Rank 2 — D06: Patient Consent Form Template
**BM25 score (simulated):** 16.7  
**Relevant to treatment query?** ❌ NO — legal boilerplate  
**Why BM25 ranked it second:** "heart attack" appears **9 times** in standard legal risk-disclosure
language. The document is about consent for *any* procedure; MI treatment is not discussed.

> *"...I acknowledge that the medical team will take every precaution to minimise the risk of a
> heart attack... I consent to all necessary emergency interventions including CPR, defibrillation..."*
> — 9 occurrences of "heart attack", all in risk-disclosure context

**What you actually get:** Legal disclaimers informing the patient that a heart attack *might
happen* as a complication — the opposite of a treatment protocol.

---

### Rank 3 — D07: Hospital Navigation / Wayfinding Guide
**BM25 score (simulated):** 14.1  
**Relevant to treatment query?** ❌ NO — signage and directory text  
**Why BM25 ranked it third:** The wayfinding guide uses "heart attack" **8 times** in department
names ("Heart Attack Care Unit", "Heart Attack Survivor Support Group", etc.). These are
proper nouns/titles, not clinical content, but BM25 cannot distinguish them.

> *"Heart Attack Emergency → Emergency Department... Heart Attack Care Unit (HACU): Level 3...
> Heart Attack Survivor Support Group: Tuesdays 18:00..."*
> — 8 occurrences, all in signage/directory context

**What you actually get:** A hospital map. Clinically worthless for treatment guidance.

---

### Rank 4 — D09: NSAID Medication Side-Effects Reference
**BM25 score (simulated):** 11.9  
**Relevant to treatment query?** ❌ NO — drug safety warning, not MI treatment  
**Why BM25 ranked it fourth:** "heart attack" appears **7 times** in the context of NSAID risks.
The document warns *against* using NSAIDs in post-MI patients — the opposite of what a
clinician needs when treating an acute MI.

> *"Do NOT prescribe NSAIDs to patients within 6 months of a heart attack. Patients with prior
> heart attack taking NSAIDs have a 45–55 % increased risk of recurrent heart attack..."*
> — 7 occurrences, all in contraindication/risk context

**What you actually get:** A list of drugs to *avoid* in MI patients, not drugs to *give*.

---

### Rank 5 — D08: Nurse Training Completion Record
**BM25 score (simulated):** 9.3  
**Relevant to treatment query?** ❌ NO — HR administrative record  
**Why BM25 ranked it fifth:** "heart attack" appears **6 times** purely as training module titles
(e.g., "Heart Attack Recognition and Early Response"). This is an HR record, not a clinical
document.

> *"Heart Attack Recognition and Early Response | Heart Attack Triage Protocols |
> Heart Attack Patient Communication Skills..."*
> — 6 occurrences, all as training module names

**What you actually get:** A nurse's CPD log confirming they attended training sessions.
No clinical content whatsoever.

---

## What BM25 Missed Entirely

The five **truly relevant** documents were **not returned** because they consistently use
clinical/research terminology rather than the lay phrase "heart attack":

| Doc | Title | Why BM25 Missed It | "heart attack" count |
|-----|-------|--------------------|----------------------|
| D01 | STEMI Treatment Protocol | Uses "STEMI", "myocardial infarction", "PCI" | 0 |
| D02 | NSTEMI Management Guidelines | Uses "NSTEMI", "ACS", "troponin" | 0 |
| D03 | ACS Antiplatelet & Anticoagulation | Uses "ACS", "DAPT", "antiplatelet" | 0 |
| D04 | Emergency PCI Procedure Note | Uses "acute MI", "LAD occlusion", "catheterisation" | 0 |
| D05 | Thrombolytic Therapy for STEMI | Uses "fibrinolytic", "tenecteplase", "reperfusion" | 0 |

**Precision@5: 0/5 = 0 %**  
**Recall@5: 0/5 = 0 %**

---

## Summary: BM25's Fundamental Limitation Here

```
BM25 ranking signal: term frequency of "heart attack"
                         ↓
Corpus writes MI content using: "STEMI", "NSTEMI", "ACS",
                                "myocardial infarction", "PCI",
                                "fibrinolytic", "troponin"
                         ↓
Result: relevant documents score 0.0 — never retrieved.
        Irrelevant documents with high "heart attack" TF flood the top-5.
```

This is the **vocabulary mismatch problem**: BM25 excels when the query vocabulary
matches the document vocabulary exactly, but clinical language has rich synonymy
(one concept, many terms) that BM25 cannot bridge.

---

## Questions to Consider Before Reranking

1. If a clinician types "heart attack" into a hospital search system, should they receive
   a wayfinding guide as the top result?
2. What is the cost of Precision@5 = 0 % in a clinical decision-support context?
3. What would happen if we expanded the query to `"myocardial infarction OR STEMI OR ACS"`?
   Would that fix BM25, or is that placing an unfair burden on the user?
4. Can you think of a case where BM25's exact-match behaviour is a *feature*, not a bug?
