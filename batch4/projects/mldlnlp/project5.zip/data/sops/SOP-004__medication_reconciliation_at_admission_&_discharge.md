---
sop_id: SOP-004
title: Medication Reconciliation at Admission & Discharge
version: 1.4
effective_date: 2025-03-01
last_reviewed: 2025-08-10
tags: [medication, reconciliation]
---

# Medication Reconciliation at Admission & Discharge

## [SECTION: PURPOSE]
Ensure accurate and complete medication lists at transitions of care.

## [SECTION: SCOPE]
All inpatient and ED admissions; all discharges.

## [SECTION: PROCEDURE]
1. Obtain **Best Possible Medication History (BPMH)** using ≥2 sources.
2. Reconcile discrepancies with prescriber; document intentional changes.
3. At discharge, provide updated med list and patient counseling.

## [SECTION: DOCUMENTATION]
BPMH source list, reconciled meds, intentional changes, counseling provided.

## [SECTION: REFERENCES]
- Pharmacy Policy RX-MEDREC-03 (rev. 2025-07)