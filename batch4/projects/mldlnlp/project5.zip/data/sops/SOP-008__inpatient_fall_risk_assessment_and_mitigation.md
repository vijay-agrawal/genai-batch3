---
sop_id: SOP-008
title: Inpatient Fall Risk Assessment and Mitigation
version: 1.1
effective_date: 2025-03-20
last_reviewed: 2025-08-01
tags: [falls, risk]
---

# Inpatient Fall Risk Assessment and Mitigation

## [SECTION: PROCEDURE]
- Assess on admission and daily using a validated scale (e.g., Morse).
- High-risk measures: bed alarms, non-slip socks, frequent rounding.

## [SECTION: DOCUMENTATION]
Risk score, interventions chosen, reassessment times.

## [SECTION: REFERENCES]
- Nursing Policy NUR-FALLS-02 (rev. 2025-07)