---
sop_id: SOP-001
title: MRI With Gadolinium Contrast — Patient Preparation
version: 1.3
effective_date: 2025-06-01
last_reviewed: 2025-08-15
tags: [MRI, contrast, gadolinium, renal]
---

# MRI With Gadolinium Contrast — Patient Preparation

## [SECTION: PURPOSE]
Establish a standardized method to safely prepare patients for MRI with gadolinium-based contrast agents (GBCA).

## [SECTION: SCOPE]
Applies to all outpatient MRI exams performed in Radiology Suite A & B.

## [SECTION: CONTRAINDICATIONS]
- **Severe CKD** (eGFR < 30 mL/min/1.73 m²) → *avoid GBCA unless radiologist approval*.
- **Known GBCA allergy** → premedication protocol required (see SOP-007).
- **Pregnancy** → risk/benefit discussion and radiologist approval required.

## [SECTION: REQUIRED_SUPPLIES]
- 18–22G IV cannula, normal saline flush, GBCA vial, consent form.

## [SECTION: PROCEDURE]
1. Verify identity with two identifiers and confirm exam order.
2. Review **eGFR** within 30 days (or 48h if risk factors). If eGFR < 30 → consult radiologist.
3. Screen for GBCA allergy; if positive → follow **Premedication for Contrast Allergy (SOP-007)**.
4. Confirm pregnancy status for individuals of child-bearing potential.
5. Obtain consent; place IV line; administer GBCA per weight (0.1 mmol/kg typical).
6. Post-injection observation for 15 minutes for immediate reactions.

## [SECTION: DOCUMENTATION]
Record dose (mmol/kg), GBCA name/lot, consent, eGFR value/date, and any adverse events in the RIS.

## [SECTION: SAFETY_AND_INFECTION_CONTROL]
Hand hygiene per **SOP-003**; use appropriate PPE; dispose sharps per policy.

## [SECTION: REFERENCES]
- Internal Radiology Policy RAD-IMG-12 (rev. 2025-06)
- ACR Manual on Contrast Media (public reference)