---
sop_id: SOP-003
title: Hand Hygiene and PPE
version: 1.0
effective_date: 2025-01-02
last_reviewed: 2025-07-05
tags: [hand-hygiene, PPE]
---

# Hand Hygiene and PPE

## [SECTION: PURPOSE]
Standardize hand hygiene and PPE selection to prevent transmission.

## [SECTION: SCOPE]
All clinical staff and patient-contact workflows.

## [SECTION: PROCEDURE]
- Perform hand hygiene **before and after** patient contact and after glove removal.
- Alcohol-based rub preferred; soap/water if visibly soiled.
- PPE selection:
  - Contact: gown + gloves
  - Droplet: mask + eye protection
  - Airborne: N95/respirator + negative-pressure room if available

## [SECTION: DOCUMENTATION]
Unit audits monthly; non-compliance triggers remedial training.

## [SECTION: REFERENCES]
- Infection Control IC-HH-05 (rev. 2025-06)