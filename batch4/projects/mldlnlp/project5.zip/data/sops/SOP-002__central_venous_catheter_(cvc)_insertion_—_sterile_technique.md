---
sop_id: SOP-002
title: Central Venous Catheter (CVC) Insertion — Sterile Technique
version: 2.1
effective_date: 2025-05-10
last_reviewed: 2025-08-20
tags: [CVC, central-line, sterile]
---

# Central Venous Catheter (CVC) Insertion — Sterile Technique

## [SECTION: PURPOSE]
Reduce catheter-related bloodstream infections (CRBSI) during CVC placement.

## [SECTION: SCOPE]
Adult ICU and step-down units; internal jugular and subclavian approaches.

## [SECTION: CONTRAINDICATIONS]
- Uncorrected coagulopathy (INR > 2.0 or platelets < 50k) without risk–benefit review.
- Overlying cellulitis at insertion site.

## [SECTION: REQUIRED_SUPPLIES]
- Full sterile barrier kit, **chlorhexidine 2% in 70% isopropyl**, ultrasound with sterile cover.

## [SECTION: PROCEDURE]
1. Time-out and checklist completion.
2. Full barrier precautions: cap, mask, sterile gown, sterile gloves, large drape.
3. Skin prep with chlorhexidine; allow to dry.
4. Ultrasound-guided venipuncture; Seldinger technique.
5. Confirm placement (ultrasound or CXR). Secure line; sterile dressing.

## [SECTION: DOCUMENTATION]
Site, attempts, guidance modality, complications, and confirmation method.

## [SECTION: SAFETY_AND_INFECTION_CONTROL]
Bundle adherence tracked; dressing changes q7d or sooner if soiled.

## [SECTION: REFERENCES]
- Internal ICU Policy ICU-CLABSI-01 (rev. 2025-05)