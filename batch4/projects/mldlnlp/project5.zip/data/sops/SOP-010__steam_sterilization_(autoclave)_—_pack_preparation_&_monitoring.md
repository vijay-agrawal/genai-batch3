---
sop_id: SOP-010
title: Steam Sterilization (Autoclave) — Pack Preparation & Monitoring
version: 2.2
effective_date: 2025-04-05
last_reviewed: 2025-08-22
tags: [sterilization, autoclave]
---

# Steam Sterilization (Autoclave) — Pack Preparation & Monitoring

## [SECTION: PROCEDURE]
- Wrap instruments per IFU; include chemical indicator inside packs.
- Cycle: 132°C for 4 min (example), dry time per load.
- Use **biological indicators** at least weekly; quarantine until pass.

## [SECTION: DOCUMENTATION]
Load ID, cycle parameters, indicator results, release authorization.

## [SECTION: REFERENCES]
- SPD Policy SPD-STER-06 (rev. 2025-08)