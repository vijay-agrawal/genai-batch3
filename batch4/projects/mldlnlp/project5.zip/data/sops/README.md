# Synthetic SOP Pack (Project 4 — MCP Clinic SOP Copilot)

**Count:** 10 SOPs  
**Format:** Markdown with YAML front-matter. Standard sections are labeled as `[SECTION: ...]` for easier programmatic parsing.

## Standard Sections
- `[SECTION: PURPOSE]`
- `[SECTION: SCOPE]`
- `[SECTION: CONTRAINDICATIONS]` (if applicable)
- `[SECTION: REQUIRED_SUPPLIES]` (if applicable)
- `[SECTION: PROCEDURE]`
- `[SECTION: DOCUMENTATION]`
- `[SECTION: SAFETY_AND_INFECTION_CONTROL]` (if applicable)
- `[SECTION: REFERENCES]`

## Index Files
- `sops_index.csv`: tabular index with keywords
- `sops_index.json`: JSON index

## Suggested MCP Tools
- `sop.search(query)` → returns matches across titles/keywords/sections
- `sop.read(section_id)` → returns full section text
- `cite.validate(text, citations)` → simple validator for citation anchors

All content is synthetic and intended for demos, training, and evaluation only.