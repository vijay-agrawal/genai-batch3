---
sop_id: SOP-006
title: Preoperative Fasting (NPO) Guidelines
version: 1.0
effective_date: 2025-04-12
last_reviewed: 2025-08-12
tags: [preop, NPO]
---

# Preoperative Fasting (NPO) Guidelines

## [SECTION: PURPOSE]
Reduce aspiration risk prior to anesthesia.

## [SECTION: PROCEDURE]
- Clear liquids: up to 2 hours before anesthesia.
- Breast milk: up to 4 hours; infant formula: up to 6 hours.
- Light meal: up to 6 hours; fatty meal: 8 hours.

## [SECTION: REFERENCES]
- Anesthesia Policy ANES-NPO-01 (rev. 2025-05)