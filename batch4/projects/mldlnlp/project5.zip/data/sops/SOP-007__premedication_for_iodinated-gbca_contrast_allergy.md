---
sop_id: SOP-007
title: Premedication for Iodinated/GBCA Contrast Allergy
version: 2.0
effective_date: 2025-05-02
last_reviewed: 2025-08-18
tags: [premed, contrast]
---

# Premedication for Iodinated/GBCA Contrast Allergy

## [SECTION: PURPOSE]
Reduce risk of immediate hypersensitivity reactions to contrast media.

## [SECTION: PROCEDURE]
- Standard regimen (example): Prednisone 50 mg PO at 13h, 7h, 1h pre-contrast + Diphenhydramine 50 mg PO/IV 1h pre-contrast.
- For urgent studies (<6h), use accelerated protocol per radiologist.

## [SECTION: REFERENCES]
- Radiology Policy RAD-ALLERGY-04 (rev. 2025-07)