---
sop_id: SOP-009
title: PPE Selection and Donning/Doffing Sequence
version: 1.0
effective_date: 2025-02-01
last_reviewed: 2025-08-05
tags: [PPE, sequence]
---

# PPE Selection and Donning/Doffing Sequence

## [SECTION: PROCEDURE]
- Donning: gown → mask/respirator → goggles/face shield → gloves.
- Doffing: gloves → goggles/face shield → gown → mask (perform hand hygiene between steps).

## [SECTION: SAFETY_AND_INFECTION_CONTROL]
Dispose PPE per unit policy; perform hand hygiene.

## [SECTION: REFERENCES]
- Infection Control IC-PPE-01 (rev. 2025-07)