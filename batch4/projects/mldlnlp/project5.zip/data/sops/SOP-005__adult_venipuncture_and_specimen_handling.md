---
sop_id: SOP-005
title: Adult Venipuncture and Specimen Handling
version: 1.2
effective_date: 2025-02-15
last_reviewed: 2025-08-08
tags: [phlebotomy, specimen]
---

# Adult Venipuncture and Specimen Handling

## [SECTION: PURPOSE]
Standardize safe venipuncture and accurate specimen labeling.

## [SECTION: PROCEDURE]
- Verify identity with two identifiers.
- Recommended order of draw per CLSI.
- Label **at bedside** immediately after collection.
- Transport per temperature/stability requirements.

## [SECTION: DOCUMENTATION]
Collector ID, time, site, any deviations or hemolysis.

## [SECTION: REFERENCES]
- Lab Policy LAB-VENI-02 (rev. 2025-06)