# Heart Attack — Synthetic Retrieval Corpus

**Fixed query:** `"heart attack"`

This corpus contains **20 synthetic documents** drawn from three source types —
clinical notes, hospital treatment guidelines, and medical research excerpts.
They are engineered so that the five truly relevant documents (`D01–D05`) use
**clinical/research terminology** ("STEMI", "myocardial infarction", "ACS",
"NSTEMI", "fibrinolytic") rather than the lay phrase "heart attack", while the
remaining 15 documents are designed to exploit specific weaknesses in BM25 and
dense-embedding retrieval.

---

## Ground-Truth Relevance Labels

| Doc ID | Title (abbreviated) | Relevant? | Why |
|--------|---------------------|-----------|-----|
| D01 | STEMI Treatment Protocol | **YES** | Core MI treatment guideline |
| D02 | NSTEMI Management Guidelines | **YES** | Core MI variant guideline |
| D03 | ACS Antiplatelet & Anticoagulation | **YES** | Drug therapy for MI |
| D04 | Emergency PCI Procedure Note | **YES** | Reperfusion procedure for MI |
| D05 | Thrombolytic Therapy for STEMI | **YES** | Alternative reperfusion strategy |
| D06 | Patient Consent Form Template | NO | Legal boilerplate; keyword trap for BM25 |
| D07 | Hospital Navigation / Wayfinding | NO | Signage text; keyword trap for BM25 |
| D08 | Nurse Training Completion Record | NO | Admin record; keyword trap for BM25 |
| D09 | NSAID Medication Side-Effects Reference | NO | Drug safety note; keyword trap for BM25 |
| D10 | Heart Attack Awareness Brochure | NO | Lay education; keyword trap for BM25 |
| D11 | Cardiac Arrest & CPR Protocol | NO | Different condition; embedding trap |
| D12 | Stroke Emergency Management Protocol | NO | Different condition; embedding trap |
| D13 | Acute Heart Failure Management | NO | Different condition; embedding trap |
| D14 | Atrial Fibrillation Rate Control | NO | Different condition; embedding trap |
| D15 | Cardiovascular Risk Assessment | NO | Preventive; embedding trap |
| D16 | Post-MI Cardiac Rehabilitation | PARTIAL | Post-acute phase only |
| D17 | Chest Pain Differential Diagnosis | PARTIAL | Broad; MI is one of many |
| D18 | ECG Interpretation: ST-Segment Changes | PARTIAL | Diagnostic only, not treatment |
| D19 | Troponin Assay Reference Guide | PARTIAL | Lab test only |
| D20 | ICU Monitoring After Cardiac Events | PARTIAL | Broad post-event care |

---

## Documents

---

### D01 — STEMI Treatment Protocol
*Source type: Hospital treatment guideline*

> **Guideline: Management of ST-Elevation Myocardial Infarction (STEMI)**
> Version 4.2 | Cardiology Department | Effective 2024-09-01
>
> **1. Diagnosis**
> STEMI is defined as chest pain or equivalent ischaemic symptoms lasting ≥ 20 minutes with
> ST elevation ≥ 1 mm in ≥ 2 contiguous limb leads or ≥ 2 mm in ≥ 2 contiguous precordial
> leads, or new left bundle branch block (LBBB).
>
> **2. Immediate Interventions (Door-to-Device Goal: < 90 minutes)**
> - Administer dual antiplatelet therapy (aspirin 300 mg + ticagrelor 180 mg loading dose).
> - Initiate anticoagulation: unfractionated heparin (UFH) 60 U/kg IV bolus (max 4 000 U).
> - Activate catheterisation laboratory for primary percutaneous coronary intervention (PCI).
> - Continuous 12-lead ECG monitoring; establish large-bore IV access × 2.
>
> **3. Primary PCI**
> Primary PCI is the preferred reperfusion strategy for STEMI when a skilled laboratory is
> available within 120 minutes of first medical contact. Culprit-vessel-only intervention is
> recommended in haemodynamically stable patients.
>
> **4. Adjunctive Pharmacotherapy**
> - Beta-blocker within 24 h if no cardiogenic shock/bradycardia.
> - High-intensity statin (atorvastatin 80 mg) initiated in hospital.
> - ACE inhibitor or ARB for LVEF < 40 % or anterior MI.
>
> **5. Monitoring**
> Serial troponin (high-sensitivity cTnI) at 0, 1, and 3 hours; repeat ECG post-PCI;
> echocardiogram before discharge to assess LVEF.

---

### D02 — NSTEMI Management Guidelines
*Source type: Hospital treatment guideline*

> **Guideline: Management of Non-ST-Elevation Myocardial Infarction (NSTEMI)**
> Cardiology & Emergency Medicine Consensus | Revision 3.0 | 2025-01-15
>
> **Definition**
> NSTEMI is an acute coronary syndrome (ACS) characterised by elevated high-sensitivity
> troponin without ST-segment elevation. It is distinguished from unstable angina by
> the presence of myocardial necrosis biomarkers.
>
> **Risk Stratification**
> Use the GRACE 2.0 score. High-risk features (GRACE > 140, haemodynamic instability,
> recurrent ischaemia) mandate invasive strategy within 24 hours.
>
> **Antiplatelet Loading**
> - Aspirin 300 mg oral stat + 75 mg daily maintenance.
> - P2Y12 inhibitor: ticagrelor 180 mg loading (preferred); clopidogrel 600 mg if ticagrelor
>   contraindicated.
>
> **Anticoagulation**
> Fondaparinux 2.5 mg SC daily (preferred if no urgent PCI) or enoxaparin 1 mg/kg SC every 12 h.
>
> **Invasive Strategy**
> Coronary angiography ± PCI within 24 h for high-risk; within 72 h for intermediate-risk.
> Conservative (medical) management for low-risk patients (GRACE ≤ 108).
>
> **Discharge Medications**
> DAPT (dual antiplatelet therapy) for 12 months, high-intensity statin, ACE inhibitor/ARB,
> beta-blocker, proton pump inhibitor.

---

### D03 — ACS Antiplatelet & Anticoagulation Protocol
*Source type: Hospital treatment guideline*

> **Protocol: Antiplatelet and Anticoagulation Therapy in Acute Coronary Syndromes**
> Pharmacy & Cardiology Joint Protocol | Version 2.1
>
> **Scope**
> Applies to all adult inpatients admitted with a diagnosis of acute coronary syndrome (ACS),
> including STEMI, NSTEMI, and unstable angina (UA).
>
> **Antiplatelet Therapy — Loading Doses**
>
> | Agent | Loading Dose | Maintenance | Notes |
> |-------|-------------|-------------|-------|
> | Aspirin | 300 mg PO | 75–100 mg daily | Indefinite; do not omit |
> | Ticagrelor | 180 mg PO | 90 mg BD | Preferred P2Y12 for ACS |
> | Clopidogrel | 600 mg PO | 75 mg daily | Use if ticagrelor contraindicated |
> | Prasugrel | 60 mg PO | 10 mg daily | Only after angiography; avoid if prior stroke/TIA |
>
> **Anticoagulation Options**
> - Unfractionated heparin (UFH): 60 U/kg bolus IV + 12 U/kg/h infusion (target aPTT 50–70 s).
> - Enoxaparin: 1 mg/kg SC every 12 h (adjust for eGFR < 30).
> - Fondaparinux: 2.5 mg SC daily (avoid if eGFR < 20 or in patients going for primary PCI).
>
> **GP IIb/IIIa Inhibitors**
> Reserved for bail-out situations during PCI (large thrombus burden, no-reflow).
> Not routinely recommended as upstream therapy.
>
> **Duration of DAPT Post-ACS**
> Standard: 12 months. Consider 6 months in high bleeding-risk patients (ARC-HBR criteria).
> Extend beyond 12 months only if low bleeding risk and high ischaemic risk (DAPT score ≥ 2).

---

### D04 — Emergency PCI Procedure Note
*Source type: Clinical note*

> **PROCEDURE NOTE — Cardiac Catheterisation Laboratory**
> Patient: [REDACTED] | Attending: Dr. S. Mehta | Date: 2025-03-14 02:37
>
> **Indication**
> 58-year-old male presenting with 90-minute history of crushing anterior chest pain, diaphoresis,
> and dyspnoea. 12-lead ECG on arrival showed 4 mm ST elevation in V1–V4. High-sensitivity
> troponin I drawn; patient taken directly to catheterisation laboratory per STEMI protocol.
> Diagnosis: Acute anterior MI secondary to total occlusion of the proximal LAD.
>
> **Procedure**
> Right radial access obtained. Coronary angiography demonstrated 100 % occlusion of the
> proximal left anterior descending (LAD) artery with TIMI-0 flow. The right coronary artery (RCA)
> and left circumflex (LCx) showed non-obstructive disease (< 40 % stenosis).
>
> Primary PCI performed: wire crossed lesion; thrombus aspiration performed; 3.5 × 24 mm
> drug-eluting stent (DES) deployed at 14 atm. Final TIMI-3 flow achieved. Door-to-balloon
> time: 62 minutes.
>
> **Post-Procedure Orders**
> Dual antiplatelet therapy continued (aspirin + ticagrelor); IV heparin discontinued post-sheath
> removal; high-intensity statin initiated; cardiac monitoring in CCU overnight.
>
> **Complications:** None.

---

### D05 — Thrombolytic Therapy for STEMI
*Source type: Medical research excerpt*

> **Clinical Practice Review: Fibrinolytic Therapy in ST-Elevation Myocardial Infarction**
> *Journal of Emergency Cardiovascular Care*, 2024; 18(3): 112–121
>
> **Abstract**
> When primary PCI cannot be delivered within 120 minutes of first medical contact, fibrinolytic
> (thrombolytic) therapy remains a guideline-endorsed reperfusion strategy for patients with STEMI.
> Tissue plasminogen activator (tPA) variants — alteplase, tenecteplase, and reteplase — act by
> converting plasminogen to plasmin, dissolving the coronary thrombus responsible for acute MI.
>
> **Patient Selection**
> Absolute contraindications include: prior intracranial haemorrhage, known intracranial neoplasm,
> ischaemic stroke within 3 months, active internal bleeding, suspected aortic dissection, and
> significant closed-head trauma within 3 months.
>
> **Dosing (Tenecteplase — weight-based)**
>
> | Body Weight | TNKase Dose |
> |-------------|-------------|
> | < 60 kg | 30 mg IV bolus |
> | 60–69 kg | 35 mg IV bolus |
> | 70–79 kg | 40 mg IV bolus |
> | ≥ 80 kg | 50 mg IV bolus (max) |
>
> **Post-Fibrinolysis Care**
> Pharmacoinvasive strategy: coronary angiography at 3–24 hours post-fibrinolysis regardless of
> clinical success. Failed reperfusion (< 50 % ST resolution at 60–90 min) mandates immediate
> rescue PCI. Adjunctive anticoagulation with enoxaparin is preferred over UFH post-lytics.

---

### D06 — Patient Consent Form Template
*Source type: Administrative / legal document*  
**BM25 trap: high "heart attack" term frequency in legal boilerplate**

> **GENERAL INFORMED CONSENT FOR CARDIAC PROCEDURES**
> Patient Name: _____________________ Date: ____________
>
> I, the undersigned patient (or authorised representative), understand that the proposed procedure
> carries risks including but not limited to: heart attack, stroke, bleeding, infection, and death.
>
> I have been informed that a heart attack may occur as a complication of general anaesthesia,
> cardiac catheterisation, or any major surgical procedure. The risk of a procedural heart attack
> varies based on my individual health status.
>
> I understand that if I experience symptoms of a heart attack during or after this procedure —
> such as chest pain, jaw pain, left arm pain, shortness of breath, or sweating — I should
> immediately notify the nursing staff.
>
> I acknowledge that the medical team will take every precaution to minimise the risk of a
> heart attack or other adverse cardiac event. However, I accept that no medical procedure is
> entirely without risk, and that a heart attack, though rare, remains a documented complication.
>
> I further acknowledge that a prior history of heart attack increases my surgical risk, and that
> I have disclosed any previous heart attack or cardiac event to my care team.
>
> In the event of a heart attack during this procedure, I consent to all necessary emergency
> interventions including CPR, defibrillation, intubation, and emergency cardiac surgery.
>
> Signed: _________________________ Date: _____________

---

### D07 — Hospital Navigation / Wayfinding Guide
*Source type: Administrative document*  
**BM25 trap: "heart attack" appears in signage context, not clinical context**

> **GENERAL HOSPITAL — PATIENT & VISITOR WAYFINDING GUIDE (2025 Edition)**
>
> **EMERGENCY SERVICES**
> Heart Attack Emergency → Emergency Department, Ground Floor, East Wing (follow RED signs)
> Stroke Emergency → Emergency Department, Ground Floor, East Wing (follow RED signs)
>
> All "Heart Attack?" signs throughout the hospital campus point to the Emergency Department.
> Do not drive yourself if you think you are having a heart attack — call 000 immediately.
>
> **CARDIAC SERVICES DIRECTORY**
> - Heart Attack Care Unit (HACU): Level 3, North Tower
> - Heart Attack Survivor Support Group: Tuesdays 18:00, Chapel Suite B
> - Heart Attack Education Resource Centre: Level 2, adjacent to Cardiology Outpatients
> - Post-Heart Attack Rehabilitation Gym: Level 4, Physiotherapy Department
>
> **NOTICE TO VISITORS**
> Our Heart Attack Response Team (HART) is available 24/7. If you see a visitor or patient
> collapse and suspect a heart attack, activate the emergency call button on any red wall panel.
>
> **CAFÉ & AMENITIES**
> The Heart-Healthy Café on Level 1 serves low-sodium, heart-smart meals designed for patients
> recovering from heart attack and other cardiac conditions. Heart attack prevention resources
> are available at the café information stand.

---

### D08 — Nurse Training Completion Record
*Source type: Administrative / HR document*  
**BM25 trap: "heart attack" repeated as training module names, not clinical content**

> **CONTINUING PROFESSIONAL DEVELOPMENT — TRAINING RECORD**
> Staff Member: J. Williams, RN | Ward: Cardiology | Year: 2025
>
> | Module | Date Completed | Score | Status |
> |--------|---------------|-------|--------|
> | Heart Attack Recognition and Early Response | 2025-02-10 | 92 % | PASSED |
> | Heart Attack Triage Protocols — Emergency Settings | 2025-02-10 | 88 % | PASSED |
> | Heart Attack Patient Communication Skills | 2025-03-01 | 95 % | PASSED |
> | Heart Attack Survivor: Psychological Support | 2025-03-15 | 90 % | PASSED |
> | Differentiating Heart Attack from Other Chest Pain | 2025-04-02 | 87 % | PASSED |
> | Heart Attack First Aid — Community Response | 2025-04-02 | 91 % | PASSED |
>
> **Supervisor Comments:**
> J. Williams has demonstrated excellent completion of all heart attack-related training modules
> this year. Their understanding of heart attack recognition has improved significantly since the
> last appraisal. Recommended for Heart Attack Response Champion designation.
>
> *This record certifies that the staff member has met all mandatory heart attack training
> requirements for 2025 as per hospital policy CPD-007.*

---

### D09 — NSAID Medication Side-Effects Reference
*Source type: Pharmacy reference document*  
**BM25 trap: "heart attack" appears many times in drug safety context, not treatment**

> **PHARMACY QUICK REFERENCE: Cardiovascular Risks of Non-Steroidal Anti-Inflammatory Drugs (NSAIDs)**
> Compiled by Clinical Pharmacy | Updated January 2025
>
> **Black Box Warning**
> Non-selective NSAIDs and COX-2 selective inhibitors increase the risk of serious cardiovascular
> events including heart attack and stroke, which can be fatal. This risk may increase with
> duration of use. Patients with known cardiovascular disease or risk factors for cardiovascular
> disease may be at greater risk of heart attack.
>
> **Key Points for Prescribers**
> - Do NOT prescribe NSAIDs to patients within 6 months of a heart attack.
> - Patients with prior heart attack taking NSAIDs have a 45–55 % increased risk of recurrent
>   heart attack compared to non-users.
> - COX-2 inhibitors (e.g., celecoxib) carry a similar heart attack risk to non-selective NSAIDs.
> - Naproxen may have a slightly more favourable heart attack risk profile than other NSAIDs
>   but should still be used with caution in post-heart attack patients.
> - Diclofenac carries the highest heart attack risk among commonly used NSAIDs.
>
> **Contraindications**
> Absolute contraindication: active peptic ulcer, severe renal impairment, heart failure,
> and recent heart attack (< 6 months). Relative contraindication: prior heart attack > 6 months.
>
> **Patient Counselling Point**
> Advise patients with heart attack history to avoid all over-the-counter NSAIDs and to
> inform their pharmacist of their heart attack history before purchasing any pain relief.

---

### D10 — Heart Attack Awareness Brochure
*Source type: Patient education document*  
**BM25 trap: lay-language document with maximum "heart attack" density**

> **KNOW THE SIGNS: Heart Attack Awareness**
> *A Public Health Resource from the Cardiology Foundation*
>
> **What Is a Heart Attack?**
> A heart attack happens when blood flow to part of the heart is blocked. A heart attack is a
> medical emergency. Every minute matters during a heart attack.
>
> **Heart Attack Warning Signs**
> - Chest pain or pressure (most common heart attack symptom)
> - Pain spreading to arm, neck, or jaw (classic heart attack sign)
> - Shortness of breath (common in heart attack, especially in women)
> - Nausea or cold sweats (heart attack symptoms often dismissed)
> - Sudden fatigue (a silent heart attack may present this way)
>
> **What to Do During a Heart Attack**
> 1. Call emergency services immediately — do not drive to hospital during a heart attack.
> 2. Chew one regular aspirin if you are not allergic — this can help during a heart attack.
> 3. Unlock your door so paramedics can enter if you are alone during a heart attack.
> 4. Stay calm and sit or lie down while waiting during a heart attack.
>
> **Heart Attack Risk Factors**
> Smoking doubles your heart attack risk. High blood pressure is a major heart attack risk factor.
> Diabetes significantly increases heart attack risk. Obesity and physical inactivity raise
> heart attack risk. Family history of heart attack is a strong predictor.
>
> **After a Heart Attack**
> Recovery after a heart attack takes time. Heart attack survivors should enrol in cardiac
> rehabilitation. Heart attack patients must take medications as prescribed.

---

### D11 — Cardiac Arrest & CPR Protocol
*Source type: Hospital treatment guideline*  
**Dense embedding trap: cardiac emergency vocabulary overlaps strongly with MI**

> **Protocol: In-Hospital Cardiac Arrest — Resuscitation Response**
> Resuscitation Committee | Version 5.1 | 2024-11-01
>
> **Definition**
> Cardiac arrest is defined as the sudden cessation of effective cardiac mechanical activity,
> resulting in the absence of a detectable pulse, unresponsiveness, and apnoea. Cardiac arrest
> must be distinguished from myocardial infarction (which may or may not cause cardiac arrest)
> and from other causes of haemodynamic collapse.
>
> **Calling the Code**
> Activate Code Blue via overhead intercom. Resuscitation team responds within 3 minutes.
>
> **Basic Life Support (BLS) — Initiate Immediately**
> - Confirm unresponsiveness; open airway; check for absence of normal breathing.
> - Begin chest compressions at 100–120/min, depth 5–6 cm, full recoil between compressions.
> - 30:2 compression-to-ventilation ratio until advanced airway placed.
>
> **Advanced Cardiac Life Support (ACLS)**
> - Attach defibrillator; analyse rhythm: shockable (VF/pVT) vs non-shockable (PEA/asystole).
> - Shockable: deliver 200 J biphasic shock; resume CPR immediately; adrenaline 1 mg IV every
>   3–5 min; amiodarone 300 mg IV after third shock.
> - Non-shockable: adrenaline 1 mg IV every 3–5 min; identify reversible causes (4H & 4T).
>
> **Post-Resuscitation Care**
> Targeted temperature management (TTM) at 36 °C for 24 h in comatose survivors.
> Urgent coronary angiography if STEMI present on post-ROSC ECG.

---

### D12 — Stroke Emergency Management Protocol
*Source type: Hospital treatment guideline*  
**Dense embedding trap: "acute vascular emergency" semantic cluster matches MI**

> **Protocol: Acute Ischaemic Stroke — Emergency Management**
> Neurology & Emergency Medicine | Guideline NST-04 | 2024-07-15
>
> **Recognition — Act FAST**
> Face drooping, Arm weakness, Speech difficulty, Time to call emergency services.
> Stroke is an acute neurovascular emergency requiring immediate assessment and intervention.
>
> **Triage & Imaging**
> Non-contrast CT head within 25 minutes of arrival to exclude haemorrhagic stroke.
> CT angiography (head and neck) to identify large vessel occlusion (LVO).
>
> **Reperfusion Strategies**
> - Intravenous alteplase (IV-tPA): 0.9 mg/kg (max 90 mg) if within 4.5 h of symptom onset
>   and no contraindications (e.g., prior haemorrhagic stroke, uncontrolled hypertension).
> - Mechanical thrombectomy: indicated for LVO in anterior circulation up to 24 h from onset
>   if perfusion mismatch demonstrated on advanced imaging.
>
> **Blood Pressure Management**
> Hold antihypertensives unless SBP > 220 mmHg (non-thrombolysis) or > 180 mmHg (post-tPA).
>
> **Antiplatelet Therapy**
> Aspirin 300 mg within 24–48 h post-tPA (delayed to reduce haemorrhagic transformation risk).
> Dual antiplatelet (aspirin + clopidogrel) for 21 days in minor stroke/high-risk TIA.

---

### D13 — Acute Heart Failure Management
*Source type: Hospital treatment guideline*  
**Dense embedding trap: "cardiac" + "acute" + "decompensated" overlaps with MI semantic space**

> **Guideline: Acute Decompensated Heart Failure (ADHF) — Inpatient Management**
> Heart Failure Service | Version 3.3 | 2025-02-01
>
> **Presentation**
> ADHF presents with dyspnoea, orthopnoea, peripheral oedema, and elevated filling pressures.
> Precipitants include dietary indiscretion, medication non-adherence, arrhythmia, infection,
> and — importantly — acute myocardial ischaemia. Exclude ACS as a precipitant in all ADHF
> presentations (troponin, ECG).
>
> **Initial Stabilisation**
> - Sit patient upright; supplemental oxygen if SpO₂ < 94 %.
> - IV furosemide 40–80 mg if volume overloaded (titrate to urine output > 0.5 mL/kg/h).
> - IV nitrates for preload/afterload reduction if SBP > 110 mmHg.
> - Consider non-invasive ventilation (CPAP/BiPAP) for respiratory distress.
>
> **Cardiogenic Shock**
> MAP < 65 mmHg despite fluids: initiate noradrenaline; consider dobutamine for inotropic support.
> Intra-aortic balloon pump (IABP) or VA-ECMO for refractory cardiogenic shock.
>
> **Aetiology Work-up**
> Echocardiogram within 24 h; BNP/NT-proBNP; renal function panel; thyroid function.
> Assess LVEF and diastolic parameters to guide chronic HF therapy.

---

### D14 — Atrial Fibrillation Rate Control
*Source type: Hospital treatment guideline*  
**Dense embedding trap: "arrhythmia" + "anticoagulation" overlaps with cardiac treatment cluster**

> **Protocol: Atrial Fibrillation — Rate Control and Anticoagulation Strategy**
> Cardiology | Protocol AF-02 | Version 2.0
>
> **Ventricular Rate Control**
> Target resting heart rate < 110 bpm (lenient) or < 80 bpm (strict, if symptomatic).
> - First-line: beta-blocker (metoprolol 25–50 mg BD or bisoprolol 2.5–5 mg OD) or
>   non-dihydropyridine calcium channel blocker (diltiazem, verapamil — avoid in HFrEF).
> - IV diltiazem or metoprolol for acute rate control in haemodynamically stable AF.
> - Digoxin for rate control in sedentary patients or as add-on therapy.
>
> **Anticoagulation**
> Calculate CHA₂DS₂-VASc score. Start oral anticoagulation (OAC) if score ≥ 2 (male) or ≥ 3
> (female). Preferred agents: apixaban 5 mg BD or rivaroxaban 20 mg OD.
> Warfarin only if mechanical heart valve or moderate-severe mitral stenosis.
>
> **Rhythm Control**
> Consider electrical cardioversion (DC cardioversion) for AF < 48 h or after 3 weeks of
> therapeutic anticoagulation. Flecainide or propafenone for pharmacological cardioversion
> (structurally normal heart only). Amiodarone for structural heart disease.
>
> **Catheter Ablation**
> Pulmonary vein isolation (PVI) — consider for symptomatic AF failing or intolerant of
> antiarrhythmic drugs.

---

### D15 — Cardiovascular Risk Assessment Tool
*Source type: Clinical guideline*  
**Dense embedding trap: "cardiovascular" + "risk" + "event prevention" matches MI prevention space**

> **Guideline: Primary Prevention Cardiovascular Risk Assessment**
> Preventive Cardiology Service | Version 1.5 | 2024-08-01
>
> **Purpose**
> Estimate a patient's 10-year risk of a major adverse cardiovascular event (MACE) — defined as
> fatal or non-fatal myocardial infarction, fatal or non-fatal stroke, or cardiovascular death —
> to guide preventive therapy decisions.
>
> **Risk Calculators**
> - **Pooled Cohort Equations (PCE)**: validated in the US population for patients aged 40–79 y.
> - **SCORE2 / SCORE2-OP**: European Society of Cardiology tool; region-specific risk charts.
> - **Framingham Risk Score**: older tool, less preferred but still widely used.
>
> **Risk Categories and Interventions**
>
> | 10-year MACE Risk | Category | Action |
> |-------------------|----------|--------|
> | < 5 % | Low | Lifestyle advice; re-assess in 5 years |
> | 5–10 % | Moderate | Statin therapy discussion; lifestyle modification |
> | 10–20 % | High | Statin therapy; blood pressure optimisation |
> | > 20 % | Very High | Statin + aspirin; refer to preventive cardiology |
>
> **Statin Initiation**
> LDL-C target for high/very-high risk: < 1.8 mmol/L (< 70 mg/dL). High-intensity statin
> (atorvastatin 40–80 mg or rosuvastatin 20–40 mg) preferred.

---

### D16 — Post-MI Cardiac Rehabilitation
*Source type: Clinical guideline*  
**Partial relevance: post-acute MI care, not acute treatment**

> **Programme: Cardiac Rehabilitation Post-Myocardial Infarction**
> Physiotherapy & Cardiology | CR Programme Guide | 2024-03-01
>
> **Eligibility**
> All patients discharged following acute MI (STEMI or NSTEMI), PCI, or CABG are eligible
> and should be referred prior to discharge.
>
> **Programme Components (12 Weeks)**
> 1. **Exercise training**: progressive aerobic exercise (walking, cycling) 3 × per week.
>    Target: 60–80 % peak VO₂ on symptom-limited exercise test.
> 2. **Education**: risk factor modification, medication adherence, return-to-work planning.
> 3. **Psychological support**: depression and anxiety screening (PHQ-9, GAD-7);
>    CBT-based intervention if required.
>
> **Secondary Prevention Medications (Discharge Bundle)**
> Aspirin, P2Y12 inhibitor (DAPT for 12 months), beta-blocker, statin, ACE inhibitor/ARB.
> All medications should be reconciled before discharge per SOP-004.
>
> **Outcome Metrics**
> 6-minute walk test, LVEF re-assessment at 3 months, quality-of-life score (EQ-5D).
> Enrolment in CR reduces all-cause mortality post-MI by approximately 26 %.

---

### D17 — Chest Pain Differential Diagnosis
*Source type: Emergency medicine reference*  
**Partial relevance: MI is one diagnosis among many**

> **Emergency Medicine Reference: Differential Diagnosis of Acute Chest Pain**
> ED Education Series | Dr. P. Nguyen | 2025-01-10
>
> Acute chest pain is one of the most common emergency presentations and requires systematic
> evaluation to rule out life-threatening causes.
>
> **Must-Not-Miss Diagnoses (The "Deadly Six")**
> 1. Acute myocardial infarction (STEMI / NSTEMI)
> 2. Aortic dissection
> 3. Pulmonary embolism (PE)
> 4. Tension pneumothorax
> 5. Oesophageal rupture (Boerhaave syndrome)
> 6. Cardiac tamponade
>
> **Initial Investigations**
> 12-lead ECG (within 10 min), high-sensitivity troponin (0 h and 1–2 h), chest X-ray,
> D-dimer (if PE suspected), BMP, FBC.
>
> **Key Discriminating Features**
> - Tearing pain radiating to the back: aortic dissection until proven otherwise.
> - Pleuritic pain + risk factors: PE.
> - Worsened by lying flat, relieved by leaning forward: pericarditis.
> - Reproducible on palpation: musculoskeletal (but never exclude MI on this basis alone).
> - Typical: ST elevation on ECG = STEMI until proven otherwise.

---

### D18 — ECG Interpretation: ST-Segment Changes
*Source type: Medical education reference*  
**Partial relevance: diagnostic tool for MI but not treatment**

> **Clinical Reference: ECG Interpretation — ST-Segment and T-Wave Changes**
> Department of Cardiology | Educational Series | Part 4 of 8
>
> **ST-Segment Elevation**
> Normal: < 1 mm in limb leads; < 2 mm in precordial leads (up to 3 mm V1–V3 in males < 40 y).
> Pathological ST elevation suggests:
> - Acute STEMI: convex ("tombstone") ST elevation; correlates with vessel territory.
>   - Inferior MI (II, III, aVF): RCA or dominant LCx.
>   - Anterior MI (V1–V4): LAD.
>   - Lateral MI (I, aVL, V5–V6): LCx.
> - Benign early repolarisation (BER): concave ST elevation; most common in young men.
> - Pericarditis: diffuse saddle-shaped ST elevation with PR depression.
> - Left ventricular aneurysm: persistent ST elevation weeks after MI.
>
> **Posterior STEMI**
> No direct leads — look for ST depression in V1–V3 (reciprocal change); tall broad R waves in
> V1–V2. Obtain posterior leads (V7–V9): ST elevation ≥ 0.5 mm confirms posterior MI.
>
> **T-Wave Changes**
> Hyperacute T waves: very early STEMI sign (within first 30 minutes).
> T-wave inversion: ischaemia, NSTEMI ("Wellens patterns" in V2–V3 = critical LAD stenosis),
> or non-ischaemic causes (PE, cardiomyopathy).

---

### D19 — Troponin Assay Reference Guide
*Source type: Pathology/laboratory reference*  
**Partial relevance: diagnostic biomarker for MI but not treatment guidance**

> **Laboratory Reference: High-Sensitivity Cardiac Troponin (hs-cTn) Interpretation**
> Biochemistry Department | Clinician Quick Reference | Revision 2.2
>
> **hs-cTnI — Reference Ranges (Siemens ADVIA Centaur)**
> - 99th-percentile upper reference limit (URL): 53 ng/L (male); 20 ng/L (female)
> - Values above URL = elevated; does not alone diagnose MI.
>
> **ESC 0h/1h Algorithm (Rapid Rule-Out/Rule-In)**
>
> | Result | Interpretation |
> |--------|----------------|
> | 0h hs-cTnI < 5 ng/L | Rule-out (< 1 % MI probability) |
> | 0h hs-cTnI ≥ 52 ng/L AND 1h rise ≥ 6 ng/L | Rule-in (> 90 % MI probability) |
> | Intermediate | Observe to 2–3 h; repeat troponin |
>
> **Causes of Elevated Troponin Other Than ACS**
> Myocarditis, pulmonary embolism, sepsis, renal failure, tachyarrhythmia, ablation,
> cardiac contusion, rhabdomyolysis, chemotherapy cardiotoxicity, Takotsubo syndrome.
>
> **Important Pitfalls**
> - Type 2 MI (troponin rise from supply-demand mismatch, e.g., tachycardia): differentiate
>   from Type 1 MI (plaque rupture) — management differs.
> - Chronic troponin elevation (stable, non-rising): suggests non-ACS aetiology.

---

### D20 — ICU Monitoring After Cardiac Events
*Source type: Clinical guideline*  
**Partial relevance: post-event ICU care, not specific to acute MI treatment**

> **Protocol: Coronary Care Unit (CCU) Monitoring — Post-Cardiac Event**
> Intensive Care & Cardiology | CCU-03 | Version 1.8
>
> **Admission Criteria**
> CCU admission indicated for: post-primary PCI, post-thrombolysis, haemodynamically unstable
> NSTEMI, post-cardiac arrest with ROSC, cardiogenic shock, malignant arrhythmias.
>
> **Standard Monitoring Frequency**
> - Continuous telemetry: all patients for minimum 24 h post-event.
> - 12-lead ECG: on admission, 6 h post-intervention, and with new symptoms.
> - Vital signs: hourly for first 6 h; 2-hourly once stable.
> - Urine output: catheterise if haemodynamically compromised; target > 0.5 mL/kg/h.
>
> **Key Parameters to Monitor**
> - Repeat troponin at 6 h and 24 h post-PCI (periprocedural MI detection).
> - Serum electrolytes (K⁺ > 4.0 mmol/L reduces arrhythmia risk).
> - Blood glucose (maintain 6–10 mmol/L; hyperglycaemia worsens myocardial recovery).
>
> **Early Mobilisation**
> Begin passive physiotherapy at 12 h if haemodynamically stable. Sit out of bed at 24 h.
> Ambulate at 48 h if no ongoing ischaemia, no cardiogenic shock, LVEF > 30 %.
>
> **Nursing Handover Checklist**
> Troponin trend ✓ | Rhythm assessment ✓ | Antiplatelet compliance ✓ | Access site assessment ✓
