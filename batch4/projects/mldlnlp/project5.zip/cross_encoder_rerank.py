"""
cross_encoder_rerank.py — Project 5: Reranking
Applies a cross-encoder to rerank candidates returned by baseline retrieval.

A cross-encoder jointly encodes (query, document) → relevance score, giving
much richer matching than cosine similarity but at higher inference cost.
This is the standard first-stage / second-stage pipeline pattern in IR.

Pipeline:
    1. First-stage retrieval  : BM25 or Dense (from baseline_results.json)
    2. Second-stage reranking : cross-encoder scores each (query, candidate) pair

Run:
    python cross_encoder_rerank.py
Dependencies:
    pip install sentence-transformers
Output:
    reranked_cross_encoder.json
"""

import json, os, re
from pathlib import Path


# ── helpers ───────────────────────────────────────────────────────────────────

def load_corpus_map(sops_dir: str) -> dict:
    """Return {sop_id: full_text} mapping."""
    index_path = os.path.join(sops_dir, "sops_index.json")
    index = json.load(open(index_path, encoding="utf-8"))
    corpus_map = {}
    for entry in index:
        md_path = os.path.join(sops_dir, entry["filename"])
        text = Path(md_path).read_text(encoding="utf-8")
        text = re.sub(r"^---.*?---\s*", "", text, flags=re.DOTALL)
        corpus_map[entry["sop_id"]] = entry["title"] + ". " + text
    return corpus_map


# ── cross-encoder reranker ────────────────────────────────────────────────────

def cross_encoder_rerank(
    queries:          list[dict],
    first_stage_hits: dict,          # {qid: [{sop_id, score, rank}, ...]}
    corpus_map:       dict,
    model_name:       str = "cross-encoder/ms-marco-MiniLM-L-6-v2",
    top_k:            int = 5,
) -> dict:
    """
    For each query, score every (query, doc) pair with the cross-encoder and
    return a new ranked list.

    cross-encoder/ms-marco-MiniLM-L-6-v2 is a lightweight MS-MARCO model
    suitable for passage ranking.  For clinical text, consider:
      - cross-encoder/ms-marco-MiniLM-L-12-v2   (larger)
      - Specialised biomedical cross-encoders from HuggingFace
    """
    from sentence_transformers import CrossEncoder

    print(f"Loading cross-encoder: {model_name}")
    model = CrossEncoder(model_name)

    results = {}
    for q in queries:
        qid   = q["qid"]
        query = q["query"]
        candidates = first_stage_hits.get(qid, [])

        pairs = [(query, corpus_map[c["sop_id"]]) for c in candidates]
        if not pairs:
            results[qid] = []
            continue

        ce_scores = model.predict(pairs)        # numpy array of floats

        reranked = sorted(
            zip(candidates, ce_scores),
            key=lambda x: x[1],
            reverse=True,
        )
        results[qid] = [
            {
                "sop_id":         cand["sop_id"],
                "first_stage_rank": cand["rank"],
                "ce_score":       float(score),
                "rank":           r + 1,
            }
            for r, (cand, score) in enumerate(reranked[:top_k])
        ]
    return results


# ── main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    base_dir  = os.path.dirname(__file__)
    sops_dir  = os.path.join(base_dir, "sops")

    queries_path  = os.path.join(base_dir, "queries.json")
    baseline_path = os.path.join(base_dir, "baseline_results.json")

    if not os.path.exists(queries_path):
        raise FileNotFoundError("Run generate_queries.py first.")
    if not os.path.exists(baseline_path):
        raise FileNotFoundError("Run baseline_retrieval.py first.")

    queries      = json.load(open(queries_path,  encoding="utf-8"))
    baseline     = json.load(open(baseline_path, encoding="utf-8"))
    corpus_map   = load_corpus_map(sops_dir)

    # Rerank on top of dense first-stage (typically better recall than BM25)
    print("\n── Cross-encoder reranking (first-stage = dense) ──")
    ce_on_dense = cross_encoder_rerank(
        queries,
        first_stage_hits=baseline["dense"],
        corpus_map=corpus_map,
        top_k=5,
    )

    print("\n── Cross-encoder reranking (first-stage = BM25) ──")
    ce_on_bm25 = cross_encoder_rerank(
        queries,
        first_stage_hits=baseline["bm25"],
        corpus_map=corpus_map,
        top_k=5,
    )

    output = {
        "ce_on_dense": ce_on_dense,
        "ce_on_bm25":  ce_on_bm25,
    }
    out_path = os.path.join(base_dir, "reranked_cross_encoder.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)
    print(f"\nSaved → {out_path}")

    # spot-check — focus on negation queries where baseline may struggle
    print("\n── Spot-check: negation queries ──")
    negation_qids = [q["qid"] for q in queries if q["query_type"] == "negation"]
    for qid in negation_qids:
        q = next(x for x in queries if x["qid"] == qid)
        dense_top = [r["sop_id"] for r in baseline["dense"][qid][:3]]
        ce_top    = [r["sop_id"] for r in ce_on_dense[qid][:3]]
        print(f"\n[{qid}] {q['query']!r}")
        print(f"  Dense (no rerank): {dense_top}")
        print(f"  CE reranked      : {ce_top}")
        print(f"  Ground truth     : {q['relevant_sop_ids']}")
