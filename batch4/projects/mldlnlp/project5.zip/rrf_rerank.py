"""
rrf_rerank.py — Project 5: Reranking
Reciprocal Rank Fusion (RRF) with variants:
  • Standard RRF         — fuse BM25 + dense ranked lists
  • Smoothed RRF         — softer penalty for low-rank documents
  • k-adjusted RRF       — tune the k hyperparameter
  • Negation-aware RRF   — boost / suppress candidates based on negation cues

Background
──────────
Classic RRF (Cormack et al., 2009):
    score(d, q) = Σ_r  1 / (k + rank_r(d))
where r iterates over retrieval systems and k=60 is the original default.

The formula is rank-only (ignores raw scores), making it robust to score
scale differences between BM25 and dense systems.

Run:
    python rrf_rerank.py
Dependencies: none (pure Python)
Output: reranked_rrf.json
"""

import json, math, os, re


# ─── RRF core ─────────────────────────────────────────────────────────────────

def rrf_fuse(
    ranked_lists: list[list[str]],   # each inner list = [sop_id, ...] ranked best-first
    k: float = 60.0,
) -> list[tuple[str, float]]:
    """
    Standard RRF: fuse N ranked lists.
    Returns [(sop_id, rrf_score), ...] sorted by descending score.
    """
    scores: dict[str, float] = {}
    for ranked in ranked_lists:
        for rank, sop_id in enumerate(ranked, start=1):
            scores[sop_id] = scores.get(sop_id, 0.0) + 1.0 / (k + rank)
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


def rrf_smoothed(
    ranked_lists: list[list[str]],
    k: float = 60.0,
    smoothing: float = 0.5,   # add a small constant to break ties at low rank
) -> list[tuple[str, float]]:
    """
    Smoothed RRF: adds a small constant to each rank score to soften the
    penalty for documents ranked just outside the top-K.

        score contribution = 1 / (k + rank) + smoothing / (k + rank)^2
    """
    scores: dict[str, float] = {}
    for ranked in ranked_lists:
        for rank, sop_id in enumerate(ranked, start=1):
            base = 1.0 / (k + rank)
            smooth = smoothing / (k + rank) ** 2
            scores[sop_id] = scores.get(sop_id, 0.0) + base + smooth
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)


def rrf_k_sweep(
    ranked_lists: list[list[str]],
    k_values: list[float] = [10, 30, 60, 100, 200],
) -> dict[float, list[tuple[str, float]]]:
    """Return RRF-fused rankings for each k value (for ablation / tuning)."""
    return {k: rrf_fuse(ranked_lists, k=k) for k in k_values}


# ─── Negation-aware RRF ───────────────────────────────────────────────────────

NEGATION_PATTERNS = re.compile(
    r"\b(no|not|without|absence of|never|neither|nor|hasn't|doesn't|isn't|"
    r"aren't|wasn't|weren't|cannot|can't|won't|wouldn't|shouldn't|"
    r"negative for|denies|denying|ruled out|ruled-out|free of|lacks)\b",
    re.IGNORECASE,
)

# Tokens that, if negated, should suppress the corresponding SOP
CLINICAL_NEGATION_MAP = {
    # negated term → suppress these SOPs
    "allergy":        ["SOP-007"],
    "contrast allergy": ["SOP-007"],
    "renal":          [],               # no suppression — SOP-001 still relevant
    "hepatic":        [],               # query about hepatic injury → still med-rec
    "coagulopathy":   [],               # CVC SOP still relevant
    "fasting":        ["SOP-006"],      # "no fasting required" → suppress NPO SOP slightly
}

# Tokens that, if negated, should *boost* the non-negation SOP
NEGATION_BOOST_MAP: dict[str, list[str]] = {
    "hepatic injury":   ["SOP-004"],    # patient without hepatic injury → med-rec
    "contrast allergy": ["SOP-001"],    # no allergy → primary MRI SOP more relevant
}


def negation_aware_rrf(
    query: str,
    ranked_lists: list[list[str]],
    k: float = 60.0,
    suppress_penalty: float = 0.5,   # multiply score of suppressed SOPs
    boost_factor:     float = 1.3,   # multiply score of boosted SOPs
) -> list[tuple[str, float]]:
    """
    1. Run standard RRF.
    2. Detect negation cues in the query.
    3. Apply suppression to SOPs mentioned in the negated phrase context.
    4. Apply boost to SOPs that become more relevant given the negation.

    This is a heuristic; production systems would use span-level NLP
    (e.g., NegEx, medspacy) for proper negation detection.
    """
    base_scores = dict(rrf_fuse(ranked_lists, k=k))

    has_negation = bool(NEGATION_PATTERNS.search(query))
    if not has_negation:
        return sorted(base_scores.items(), key=lambda x: x[1], reverse=True)

    query_lower = query.lower()

    # Suppress
    for term, sop_ids in CLINICAL_NEGATION_MAP.items():
        if term in query_lower:
            for sid in sop_ids:
                if sid in base_scores:
                    base_scores[sid] *= suppress_penalty

    # Boost
    for term, sop_ids in NEGATION_BOOST_MAP.items():
        if term in query_lower:
            for sid in sop_ids:
                if sid in base_scores:
                    base_scores[sid] *= boost_factor

    return sorted(base_scores.items(), key=lambda x: x[1], reverse=True)


# ─── helpers ──────────────────────────────────────────────────────────────────

def hits_to_ranked_list(hits: list[dict]) -> list[str]:
    """Convert [{sop_id, rank, ...}] → [sop_id, ...] sorted by rank."""
    return [h["sop_id"] for h in sorted(hits, key=lambda x: x["rank"])]


# ─── main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    base_dir      = os.path.dirname(__file__)
    queries_path  = os.path.join(base_dir, "queries.json")
    baseline_path = os.path.join(base_dir, "baseline_results.json")

    if not os.path.exists(queries_path):
        raise FileNotFoundError("Run generate_queries.py first.")
    if not os.path.exists(baseline_path):
        raise FileNotFoundError("Run baseline_retrieval.py first.")

    queries  = json.load(open(queries_path,  encoding="utf-8"))
    baseline = json.load(open(baseline_path, encoding="utf-8"))

    results: dict[str, dict] = {}

    for q in queries:
        qid   = q["qid"]
        query = q["query"]

        bm25_list  = hits_to_ranked_list(baseline["bm25"].get(qid, []))
        dense_list = hits_to_ranked_list(baseline["dense"].get(qid, []))
        both_lists = [bm25_list, dense_list]

        # Standard RRF
        std = rrf_fuse(both_lists, k=60)

        # Smoothed RRF
        smo = rrf_smoothed(both_lists, k=60, smoothing=0.5)

        # k sweep (just store top-1 per k for comparison)
        sweep = {
            str(k): [sid for sid, _ in fused[:5]]
            for k, fused in rrf_k_sweep(both_lists).items()
        }

        # Negation-aware RRF
        neg_aware = negation_aware_rrf(
            query, both_lists, k=60, suppress_penalty=0.5, boost_factor=1.3
        )

        def fmt(fused, top=5):
            return [
                {"sop_id": sid, "rrf_score": round(score, 6), "rank": r + 1}
                for r, (sid, score) in enumerate(fused[:top])
            ]

        results[qid] = {
            "query":           query,
            "query_type":      q["query_type"],
            "relevant":        q["relevant_sop_ids"],
            "standard_rrf":    fmt(std),
            "smoothed_rrf":    fmt(smo),
            "negation_aware":  fmt(neg_aware),
            "k_sweep_top5":    sweep,
        }

    out_path = os.path.join(base_dir, "reranked_rrf.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print(f"Saved → {out_path}")

    # ── Print analysis for negation queries ──────────────────────────────────
    print("\n── Negation query analysis ──")
    for qid, res in results.items():
        if res["query_type"] != "negation":
            continue
        std_top3 = [r["sop_id"] for r in res["standard_rrf"][:3]]
        neg_top3 = [r["sop_id"] for r in res["negation_aware"][:3]]
        changed  = std_top3 != neg_top3
        print(f"\n[{qid}] {res['query']!r}")
        print(f"  Standard RRF top-3     : {std_top3}")
        print(f"  Negation-aware top-3   : {neg_top3}")
        print(f"  Ground truth           : {res['relevant']}")
        print(f"  Ranking changed        : {changed}")

    # ── k sensitivity ─────────────────────────────────────────────────────────
    print("\n── k sensitivity for Q001 ──")
    q1 = results.get("Q001", {})
    for k_val, top5 in (q1.get("k_sweep_top5") or {}).items():
        print(f"  k={k_val:>3s}: {top5}")
