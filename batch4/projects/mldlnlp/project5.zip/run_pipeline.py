"""
run_pipeline.py — Project 5: Reranking
Orchestrates the full reranking pipeline end-to-end:

    Step 1: generate_queries   — create evaluation query set
    Step 2: baseline_retrieval — BM25 + dense first-stage retrieval
    Step 3: cross_encoder      — cross-encoder reranking
    Step 4: rrf                — RRF fusion variants
    Step 5: evaluate           — compute and print all metrics

Run:
    python run_pipeline.py [--skip-ce]   # skip cross-encoder (slow on CPU)
Dependencies:
    pip install rank-bm25 sentence-transformers
"""

import argparse, importlib, sys, os

def run_module(module_name: str):
    """Import and run a sibling module (equivalent to subprocess but in-process)."""
    print(f"\n{'='*60}")
    print(f"  STEP: {module_name}")
    print(f"{'='*60}")
    # Add the current directory to sys.path so sibling imports work
    here = os.path.dirname(__file__)
    if here not in sys.path:
        sys.path.insert(0, here)
    spec   = importlib.util.spec_from_file_location(module_name, os.path.join(here, f"{module_name}.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Project 5 — Reranking pipeline")
    parser.add_argument("--skip-ce", action="store_true",
                        help="Skip cross-encoder step (faster, no GPU required)")
    args = parser.parse_args()

    run_module("generate_queries")
    run_module("baseline_retrieval")
    if not args.skip_ce:
        run_module("cross_encoder_rerank")
    run_module("rrf_rerank")
    run_module("evaluate")

    print("\n\nPipeline complete.")
