"""
evaluate.py — Project 5: Reranking
Computes information-retrieval metrics for each retrieval / reranking system:

  Recall@K     — fraction of relevant docs retrieved in top-K
  Precision@K  — fraction of top-K results that are relevant
  MRR          — Mean Reciprocal Rank (first relevant result)
  NDCG@K       — Normalised Discounted Cumulative Gain

Systems evaluated:
  bm25                  baseline BM25
  dense                 baseline dense (SBERT cosine)
  ce_on_dense           cross-encoder reranked on top of dense
  ce_on_bm25            cross-encoder reranked on top of BM25
  rrf_standard          Reciprocal Rank Fusion (k=60)
  rrf_smoothed          Smoothed RRF
  rrf_negation_aware    Negation-aware RRF

Run:
    python evaluate.py
Dependencies: none (pure Python + json)
"""

import json, math, os
from collections import defaultdict


# ─── metric functions ─────────────────────────────────────────────────────────

def recall_at_k(retrieved: list[str], relevant: list[str], k: int) -> float:
    if not relevant:
        return 0.0
    hits = sum(1 for sop in retrieved[:k] if sop in relevant)
    return hits / len(relevant)


def precision_at_k(retrieved: list[str], relevant: list[str], k: int) -> float:
    if k == 0:
        return 0.0
    hits = sum(1 for sop in retrieved[:k] if sop in relevant)
    return hits / k


def reciprocal_rank(retrieved: list[str], relevant: list[str]) -> float:
    for rank, sop in enumerate(retrieved, start=1):
        if sop in relevant:
            return 1.0 / rank
    return 0.0


def ndcg_at_k(retrieved: list[str], relevant: list[str], k: int) -> float:
    """Binary relevance DCG: gain=1 if relevant, 0 otherwise."""
    def dcg(items):
        return sum(
            (1.0 if items[i] in relevant else 0.0) / math.log2(i + 2)
            for i in range(min(len(items), k))
        )

    actual  = dcg(retrieved)
    ideal   = dcg(relevant[:k])   # best possible ordering
    return actual / ideal if ideal > 0 else 0.0


# ─── helpers ──────────────────────────────────────────────────────────────────

def extract_ranked_list(hits: list[dict]) -> list[str]:
    """[{sop_id, rank, ...}] → [sop_id, ...] by rank."""
    return [h["sop_id"] for h in sorted(hits, key=lambda x: x["rank"])]


def mean(vals: list[float]) -> float:
    return sum(vals) / len(vals) if vals else 0.0


# ─── evaluation loop ──────────────────────────────────────────────────────────

def evaluate_system(
    system_name: str,
    system_hits: dict,           # {qid: [{sop_id, rank, ...}]}
    queries:     list[dict],
    k_values:    list[int] = [1, 3, 5],
) -> dict:
    per_query  = {}
    aggregated = defaultdict(list)

    for q in queries:
        qid     = q["qid"]
        relevant = set(q["relevant_sop_ids"])
        hits     = system_hits.get(qid, [])
        ranked   = extract_ranked_list(hits)

        row = {"qid": qid, "query_type": q["query_type"], "relevant": list(relevant)}
        for k in k_values:
            row[f"R@{k}"]    = round(recall_at_k(ranked, relevant, k), 4)
            row[f"P@{k}"]    = round(precision_at_k(ranked, relevant, k), 4)
            row[f"NDCG@{k}"] = round(ndcg_at_k(ranked, relevant, k), 4)
        row["RR"] = round(reciprocal_rank(ranked, relevant), 4)
        per_query[qid] = row

        for metric, val in row.items():
            if metric not in ("qid", "query_type", "relevant"):
                aggregated[metric].append(val)

    summary = {
        "system":   system_name,
        "n_queries": len(queries),
    }
    for metric, vals in aggregated.items():
        summary[f"mean_{metric}"] = round(mean(vals), 4)
    summary["MRR"] = summary.pop("mean_RR")

    return {"summary": summary, "per_query": per_query}


# ─── build system map ─────────────────────────────────────────────────────────

def load_systems(base_dir: str) -> dict:
    """Load all result files and return a unified {system_name: {qid: hits}} dict."""
    systems = {}

    baseline_path = os.path.join(base_dir, "baseline_results.json")
    if os.path.exists(baseline_path):
        bl = json.load(open(baseline_path, encoding="utf-8"))
        systems["bm25"]  = bl["bm25"]
        systems["dense"] = bl["dense"]

    ce_path = os.path.join(base_dir, "reranked_cross_encoder.json")
    if os.path.exists(ce_path):
        ce = json.load(open(ce_path, encoding="utf-8"))
        systems["ce_on_dense"] = ce["ce_on_dense"]
        systems["ce_on_bm25"]  = ce["ce_on_bm25"]

    rrf_path = os.path.join(base_dir, "reranked_rrf.json")
    if os.path.exists(rrf_path):
        rrf = json.load(open(rrf_path, encoding="utf-8"))
        # RRF results are stored as {qid: {standard_rrf: [...], ...}}
        def rrf_to_hits(key):
            out = {}
            for qid, res in rrf.items():
                out[qid] = res.get(key, [])
            return out
        systems["rrf_standard"]       = rrf_to_hits("standard_rrf")
        systems["rrf_smoothed"]       = rrf_to_hits("smoothed_rrf")
        systems["rrf_negation_aware"] = rrf_to_hits("negation_aware")

    return systems


# ─── main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    base_dir     = os.path.dirname(__file__)
    queries_path = os.path.join(base_dir, "queries.json")

    if not os.path.exists(queries_path):
        raise FileNotFoundError("Run generate_queries.py first.")

    queries = json.load(open(queries_path, encoding="utf-8"))
    systems = load_systems(base_dir)

    if not systems:
        raise RuntimeError("No result files found. Run baseline_retrieval.py, "
                           "cross_encoder_rerank.py, and rrf_rerank.py first.")

    K = [1, 3, 5]
    all_evals = {}
    summaries = []

    for name, hits in systems.items():
        eval_result = evaluate_system(name, hits, queries, k_values=K)
        all_evals[name] = eval_result
        summaries.append(eval_result["summary"])

    # Save full evaluation
    out_path = os.path.join(base_dir, "evaluation_results.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(all_evals, f, indent=2)
    print(f"Full evaluation saved → {out_path}\n")

    # ── Summary table ─────────────────────────────────────────────────────────
    metric_cols = ["MRR", "mean_R@1", "mean_R@3", "mean_R@5",
                   "mean_P@1", "mean_P@3", "mean_NDCG@3", "mean_NDCG@5"]
    header = f"{'System':<28}" + "".join(f"{m:>14}" for m in metric_cols)
    print(header)
    print("-" * len(header))
    for s in summaries:
        row = f"{s['system']:<28}" + "".join(
            f"{s.get(m, 0.0):>14.4f}" for m in metric_cols
        )
        print(row)

    # ── Recall loss analysis ───────────────────────────────────────────────────
    print("\n── Recall@5 loss vs. best system ──")
    if "dense" in all_evals and "ce_on_dense" in all_evals:
        for q in queries:
            qid = q["qid"]
            baseline_r = all_evals["dense"]["per_query"][qid]["R@5"]
            ce_r       = all_evals["ce_on_dense"]["per_query"].get(qid, {}).get("R@5", 0)
            loss       = baseline_r - ce_r
            if loss > 0:
                print(f"  [{qid}] {q['query'][:55]!r}  "
                      f"dense={baseline_r:.2f}  CE={ce_r:.2f}  loss={loss:.2f}")

    # ── Negation query breakdown ───────────────────────────────────────────────
    negation_qids = [q["qid"] for q in queries if q["query_type"] == "negation"]
    if negation_qids and len(systems) >= 2:
        print("\n── Negation queries — MRR per system ──")
        neg_header = f"{'QID':<8}" + "".join(f"{n[:16]:>18}" for n in systems)
        print(neg_header)
        for qid in negation_qids:
            row = f"{qid:<8}"
            for name in systems:
                mrr_val = all_evals[name]["per_query"].get(qid, {}).get("RR", 0.0)
                row += f"{mrr_val:>18.4f}"
            print(row)
