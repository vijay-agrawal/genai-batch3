"""
generate_queries.py — Project 5: Reranking
Generates a labelled evaluation set of queries against the SOP corpus.
Each query has a list of relevant SOP IDs (ground truth).
Includes affirmative queries, negation queries, and multi-hop queries.

Run:
    python generate_queries.py
Output:
    queries.json   — list of {qid, query, relevant_sop_ids, query_type}
"""

import json, os

QUERIES = [
    # ── affirmative ──────────────────────────────────────────────────────────
    {
        "qid": "Q001",
        "query": "How do I prepare a patient for MRI with contrast?",
        "relevant_sop_ids": ["SOP-001", "SOP-007"],
        "query_type": "affirmative",
    },
    {
        "qid": "Q002",
        "query": "What is the sterile technique for central line insertion?",
        "relevant_sop_ids": ["SOP-002"],
        "query_type": "affirmative",
    },
    {
        "qid": "Q003",
        "query": "What are the hand hygiene steps before patient contact?",
        "relevant_sop_ids": ["SOP-003", "SOP-009"],
        "query_type": "affirmative",
    },
    {
        "qid": "Q004",
        "query": "How to reconcile medications at patient discharge?",
        "relevant_sop_ids": ["SOP-004"],
        "query_type": "affirmative",
    },
    {
        "qid": "Q005",
        "query": "Order of draw for blood specimen collection",
        "relevant_sop_ids": ["SOP-005"],
        "query_type": "affirmative",
    },
    {
        "qid": "Q006",
        "query": "NPO fasting duration before anesthesia",
        "relevant_sop_ids": ["SOP-006"],
        "query_type": "affirmative",
    },
    {
        "qid": "Q007",
        "query": "Contrast allergy premedication regimen",
        "relevant_sop_ids": ["SOP-007", "SOP-001"],
        "query_type": "affirmative",
    },
    {
        "qid": "Q008",
        "query": "Fall risk assessment tool for inpatients",
        "relevant_sop_ids": ["SOP-008"],
        "query_type": "affirmative",
    },
    {
        "qid": "Q009",
        "query": "Autoclave biological indicator monitoring frequency",
        "relevant_sop_ids": ["SOP-010"],
        "query_type": "affirmative",
    },
    {
        "qid": "Q010",
        "query": "PPE donning sequence for airborne precautions",
        "relevant_sop_ids": ["SOP-009", "SOP-003"],
        "query_type": "affirmative",
    },
    # ── negation (tricky for bag-of-words and cosine similarity) ────────────
    {
        "qid": "Q011",
        "query": "patient has no contrast allergy — is premedication still needed?",
        "relevant_sop_ids": ["SOP-001", "SOP-007"],
        "query_type": "negation",
        "negation_note": "No-allergy context should still retrieve contrast-related SOPs, not allergy-premedication as primary",
    },
    {
        "qid": "Q012",
        "query": "patient with no renal impairment receiving gadolinium",
        "relevant_sop_ids": ["SOP-001"],
        "query_type": "negation",
        "negation_note": "Negates the CKD contraindication; SOP-001 is still the right SOP",
    },
    {
        "qid": "Q013",
        "query": "CVC placement when coagulopathy is NOT present",
        "relevant_sop_ids": ["SOP-002"],
        "query_type": "negation",
        "negation_note": "Negates the coagulopathy contraindication but CVC SOP is still relevant",
    },
    {
        "qid": "Q014",
        "query": "patient has no hepatic injury — can we proceed with standard medication reconciliation?",
        "relevant_sop_ids": ["SOP-004"],
        "query_type": "negation",
        "negation_note": "Hepatic injury is absent; medication-reconciliation SOP is still needed",
    },
    {
        "qid": "Q015",
        "query": "fasting not required for which procedure?",
        "relevant_sop_ids": ["SOP-006"],
        "query_type": "negation",
        "negation_note": "Negation of NPO; answer still lives in the NPO SOP",
    },
    # ── multi-keyword / multi-hop ────────────────────────────────────────────
    {
        "qid": "Q016",
        "query": "infection control during venipuncture and specimen handling",
        "relevant_sop_ids": ["SOP-005", "SOP-003"],
        "query_type": "multi_hop",
    },
    {
        "qid": "Q017",
        "query": "sterile barrier technique and chlorhexidine skin prep",
        "relevant_sop_ids": ["SOP-002"],
        "query_type": "multi_hop",
    },
    {
        "qid": "Q018",
        "query": "Morse scale and bed alarms for patient safety",
        "relevant_sop_ids": ["SOP-008"],
        "query_type": "multi_hop",
    },
    {
        "qid": "Q019",
        "query": "doffing gloves then mask hand hygiene sequence",
        "relevant_sop_ids": ["SOP-009", "SOP-003"],
        "query_type": "multi_hop",
    },
    {
        "qid": "Q020",
        "query": "sterilization pack preparation and cycle parameters",
        "relevant_sop_ids": ["SOP-010"],
        "query_type": "multi_hop",
    },
]

out_path = os.path.join(os.path.dirname(__file__), "queries.json")
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(QUERIES, f, indent=2)

print(f"Saved {len(QUERIES)} queries → {out_path}")
counts = {}
for q in QUERIES:
    counts[q["query_type"]] = counts.get(q["query_type"], 0) + 1
for qtype, n in counts.items():
    print(f"  {qtype}: {n}")
