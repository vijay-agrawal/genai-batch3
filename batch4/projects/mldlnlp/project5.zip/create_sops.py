# Re-run the file creation (state was reset by the environment). 
import os, csv, json, datetime
from textwrap import dedent

sops_dir = "sops"
os.makedirs(sops_dir, exist_ok=True)

sops = [
    ("SOP-001","MRI With Gadolinium Contrast — Patient Preparation","1.3","2025-06-01","2025-08-15",
     ["MRI","contrast","gadolinium","renal function","pregnancy","screening"],
     dedent("""
     ---
     sop_id: SOP-001
     title: MRI With Gadolinium Contrast — Patient Preparation
     version: 1.3
     effective_date: 2025-06-01
     last_reviewed: 2025-08-15
     tags: [MRI, contrast, gadolinium, renal]
     ---

     # MRI With Gadolinium Contrast — Patient Preparation

     ## [SECTION: PURPOSE]
     Establish a standardized method to safely prepare patients for MRI with gadolinium-based contrast agents (GBCA).

     ## [SECTION: SCOPE]
     Applies to all outpatient MRI exams performed in Radiology Suite A & B.

     ## [SECTION: CONTRAINDICATIONS]
     - **Severe CKD** (eGFR < 30 mL/min/1.73 m²) → *avoid GBCA unless radiologist approval*.
     - **Known GBCA allergy** → premedication protocol required (see SOP-007).
     - **Pregnancy** → risk/benefit discussion and radiologist approval required.

     ## [SECTION: REQUIRED_SUPPLIES]
     - 18–22G IV cannula, normal saline flush, GBCA vial, consent form.

     ## [SECTION: PROCEDURE]
     1. Verify identity with two identifiers and confirm exam order.
     2. Review **eGFR** within 30 days (or 48h if risk factors). If eGFR < 30 → consult radiologist.
     3. Screen for GBCA allergy; if positive → follow **Premedication for Contrast Allergy (SOP-007)**.
     4. Confirm pregnancy status for individuals of child-bearing potential.
     5. Obtain consent; place IV line; administer GBCA per weight (0.1 mmol/kg typical).
     6. Post-injection observation for 15 minutes for immediate reactions.

     ## [SECTION: DOCUMENTATION]
     Record dose (mmol/kg), GBCA name/lot, consent, eGFR value/date, and any adverse events in the RIS.

     ## [SECTION: SAFETY_AND_INFECTION_CONTROL]
     Hand hygiene per **SOP-003**; use appropriate PPE; dispose sharps per policy.

     ## [SECTION: REFERENCES]
     - Internal Radiology Policy RAD-IMG-12 (rev. 2025-06)
     - ACR Manual on Contrast Media (public reference)
     """).strip()
    ),
    ("SOP-002","Central Venous Catheter (CVC) Insertion — Sterile Technique","2.1","2025-05-10","2025-08-20",
     ["CVC","central line","sterile","ultrasound","chlorhexidine"],
     dedent("""
     ---
     sop_id: SOP-002
     title: Central Venous Catheter (CVC) Insertion — Sterile Technique
     version: 2.1
     effective_date: 2025-05-10
     last_reviewed: 2025-08-20
     tags: [CVC, central-line, sterile]
     ---

     # Central Venous Catheter (CVC) Insertion — Sterile Technique

     ## [SECTION: PURPOSE]
     Reduce catheter-related bloodstream infections (CRBSI) during CVC placement.

     ## [SECTION: SCOPE]
     Adult ICU and step-down units; internal jugular and subclavian approaches.

     ## [SECTION: CONTRAINDICATIONS]
     - Uncorrected coagulopathy (INR > 2.0 or platelets < 50k) without risk–benefit review.
     - Overlying cellulitis at insertion site.

     ## [SECTION: REQUIRED_SUPPLIES]
     - Full sterile barrier kit, **chlorhexidine 2% in 70% isopropyl**, ultrasound with sterile cover.

     ## [SECTION: PROCEDURE]
     1. Time-out and checklist completion.
     2. Full barrier precautions: cap, mask, sterile gown, sterile gloves, large drape.
     3. Skin prep with chlorhexidine; allow to dry.
     4. Ultrasound-guided venipuncture; Seldinger technique.
     5. Confirm placement (ultrasound or CXR). Secure line; sterile dressing.

     ## [SECTION: DOCUMENTATION]
     Site, attempts, guidance modality, complications, and confirmation method.

     ## [SECTION: SAFETY_AND_INFECTION_CONTROL]
     Bundle adherence tracked; dressing changes q7d or sooner if soiled.

     ## [SECTION: REFERENCES]
     - Internal ICU Policy ICU-CLABSI-01 (rev. 2025-05)
     """).strip()
    ),
    ("SOP-003","Hand Hygiene and PPE","1.0","2025-01-02","2025-07-05",
     ["hand hygiene","PPE","infection control"],
     dedent("""
     ---
     sop_id: SOP-003
     title: Hand Hygiene and PPE
     version: 1.0
     effective_date: 2025-01-02
     last_reviewed: 2025-07-05
     tags: [hand-hygiene, PPE]
     ---

     # Hand Hygiene and PPE

     ## [SECTION: PURPOSE]
     Standardize hand hygiene and PPE selection to prevent transmission.

     ## [SECTION: SCOPE]
     All clinical staff and patient-contact workflows.

     ## [SECTION: PROCEDURE]
     - Perform hand hygiene **before and after** patient contact and after glove removal.
     - Alcohol-based rub preferred; soap/water if visibly soiled.
     - PPE selection:
       - Contact: gown + gloves
       - Droplet: mask + eye protection
       - Airborne: N95/respirator + negative-pressure room if available

     ## [SECTION: DOCUMENTATION]
     Unit audits monthly; non-compliance triggers remedial training.

     ## [SECTION: REFERENCES]
     - Infection Control IC-HH-05 (rev. 2025-06)
     """).strip()
    ),
    ("SOP-004","Medication Reconciliation at Admission & Discharge","1.4","2025-03-01","2025-08-10",
     ["med rec","admission","discharge","pharmacy"],
     dedent("""
     ---
     sop_id: SOP-004
     title: Medication Reconciliation at Admission & Discharge
     version: 1.4
     effective_date: 2025-03-01
     last_reviewed: 2025-08-10
     tags: [medication, reconciliation]
     ---

     # Medication Reconciliation at Admission & Discharge

     ## [SECTION: PURPOSE]
     Ensure accurate and complete medication lists at transitions of care.

     ## [SECTION: SCOPE]
     All inpatient and ED admissions; all discharges.

     ## [SECTION: PROCEDURE]
     1. Obtain **Best Possible Medication History (BPMH)** using ≥2 sources.
     2. Reconcile discrepancies with prescriber; document intentional changes.
     3. At discharge, provide updated med list and patient counseling.

     ## [SECTION: DOCUMENTATION]
     BPMH source list, reconciled meds, intentional changes, counseling provided.

     ## [SECTION: REFERENCES]
     - Pharmacy Policy RX-MEDREC-03 (rev. 2025-07)
     """).strip()
    ),
    ("SOP-005","Adult Venipuncture and Specimen Handling","1.2","2025-02-15","2025-08-08",
     ["phlebotomy","specimen","labels","order of draw"],
     dedent("""
     ---
     sop_id: SOP-005
     title: Adult Venipuncture and Specimen Handling
     version: 1.2
     effective_date: 2025-02-15
     last_reviewed: 2025-08-08
     tags: [phlebotomy, specimen]
     ---

     # Adult Venipuncture and Specimen Handling

     ## [SECTION: PURPOSE]
     Standardize safe venipuncture and accurate specimen labeling.

     ## [SECTION: PROCEDURE]
     - Verify identity with two identifiers.
     - Recommended order of draw per CLSI.
     - Label **at bedside** immediately after collection.
     - Transport per temperature/stability requirements.

     ## [SECTION: DOCUMENTATION]
     Collector ID, time, site, any deviations or hemolysis.

     ## [SECTION: REFERENCES]
     - Lab Policy LAB-VENI-02 (rev. 2025-06)
     """).strip()
    ),
    ("SOP-006","Preoperative Fasting (NPO) Guidelines","1.0","2025-04-12","2025-08-12",
     ["preop fasting","NPO","anesthesia"],
     dedent("""
     ---
     sop_id: SOP-006
     title: Preoperative Fasting (NPO) Guidelines
     version: 1.0
     effective_date: 2025-04-12
     last_reviewed: 2025-08-12
     tags: [preop, NPO]
     ---

     # Preoperative Fasting (NPO) Guidelines

     ## [SECTION: PURPOSE]
     Reduce aspiration risk prior to anesthesia.

     ## [SECTION: PROCEDURE]
     - Clear liquids: up to 2 hours before anesthesia.
     - Breast milk: up to 4 hours; infant formula: up to 6 hours.
     - Light meal: up to 6 hours; fatty meal: 8 hours.

     ## [SECTION: REFERENCES]
     - Anesthesia Policy ANES-NPO-01 (rev. 2025-05)
     """).strip()
    ),
    ("SOP-007","Premedication for Iodinated/GBCA Contrast Allergy","2.0","2025-05-02","2025-08-18",
     ["premedication","contrast allergy","steroids","antihistamines"],
     dedent("""
     ---
     sop_id: SOP-007
     title: Premedication for Iodinated/GBCA Contrast Allergy
     version: 2.0
     effective_date: 2025-05-02
     last_reviewed: 2025-08-18
     tags: [premed, contrast]
     ---

     # Premedication for Iodinated/GBCA Contrast Allergy

     ## [SECTION: PURPOSE]
     Reduce risk of immediate hypersensitivity reactions to contrast media.

     ## [SECTION: PROCEDURE]
     - Standard regimen (example): Prednisone 50 mg PO at 13h, 7h, 1h pre-contrast + Diphenhydramine 50 mg PO/IV 1h pre-contrast.
     - For urgent studies (<6h), use accelerated protocol per radiologist.

     ## [SECTION: REFERENCES]
     - Radiology Policy RAD-ALLERGY-04 (rev. 2025-07)
     """).strip()
    ),
    ("SOP-008","Inpatient Fall Risk Assessment and Mitigation","1.1","2025-03-20","2025-08-01",
     ["fall risk","assessment","mitigation","morse"],
     dedent("""
     ---
     sop_id: SOP-008
     title: Inpatient Fall Risk Assessment and Mitigation
     version: 1.1
     effective_date: 2025-03-20
     last_reviewed: 2025-08-01
     tags: [falls, risk]
     ---

     # Inpatient Fall Risk Assessment and Mitigation

     ## [SECTION: PROCEDURE]
     - Assess on admission and daily using a validated scale (e.g., Morse).
     - High-risk measures: bed alarms, non-slip socks, frequent rounding.

     ## [SECTION: DOCUMENTATION]
     Risk score, interventions chosen, reassessment times.

     ## [SECTION: REFERENCES]
     - Nursing Policy NUR-FALLS-02 (rev. 2025-07)
     """).strip()
    ),
    ("SOP-009","PPE Selection and Donning/Doffing Sequence","1.0","2025-02-01","2025-08-05",
     ["PPE","donning","doffing","sequence"],
     dedent("""
     ---
     sop_id: SOP-009
     title: PPE Selection and Donning/Doffing Sequence
     version: 1.0
     effective_date: 2025-02-01
     last_reviewed: 2025-08-05
     tags: [PPE, sequence]
     ---

     # PPE Selection and Donning/Doffing Sequence

     ## [SECTION: PROCEDURE]
     - Donning: gown → mask/respirator → goggles/face shield → gloves.
     - Doffing: gloves → goggles/face shield → gown → mask (perform hand hygiene between steps).

     ## [SECTION: SAFETY_AND_INFECTION_CONTROL]
     Dispose PPE per unit policy; perform hand hygiene.

     ## [SECTION: REFERENCES]
     - Infection Control IC-PPE-01 (rev. 2025-07)
     """).strip()
    ),
    ("SOP-010","Steam Sterilization (Autoclave) — Pack Preparation & Monitoring","2.2","2025-04-05","2025-08-22",
     ["autoclave","sterilization","biological indicator"],
     dedent("""
     ---
     sop_id: SOP-010
     title: Steam Sterilization (Autoclave) — Pack Preparation & Monitoring
     version: 2.2
     effective_date: 2025-04-05
     last_reviewed: 2025-08-22
     tags: [sterilization, autoclave]
     ---

     # Steam Sterilization (Autoclave) — Pack Preparation & Monitoring

     ## [SECTION: PROCEDURE]
     - Wrap instruments per IFU; include chemical indicator inside packs.
     - Cycle: 132°C for 4 min (example), dry time per load.
     - Use **biological indicators** at least weekly; quarantine until pass.

     ## [SECTION: DOCUMENTATION]
     Load ID, cycle parameters, indicator results, release authorization.

     ## [SECTION: REFERENCES]
     - SPD Policy SPD-STER-06 (rev. 2025-08)
     """).strip()
    )
]

# Write markdown files and indices
index_rows = []
for sop_id, title, version, eff, last, keywords, content in sops:
    fname = f"{sop_id}__{title.lower().replace(' ', '_').replace('/', '-')}.md"
    path = os.path.join(sops_dir, fname)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    index_rows.append({
        "sop_id": sop_id,
        "title": title,
        "version": version,
        "effective_date": eff,
        "last_reviewed": last,
        "filename": fname,
        "keywords": ";".join(keywords)
    })

# CSV index
csv_path = os.path.join(sops_dir, "sops_index.csv")
import csv
with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(index_rows[0].keys()))
    writer.writeheader()
    writer.writerows(index_rows)

# JSON index
json_path = os.path.join(sops_dir, "sops_index.json")
import json
with open(json_path, "w", encoding="utf-8") as f:
    json.dump(index_rows, f, indent=2)

# README
readme = os.path.join(sops_dir, "README.md")
with open(readme, "w", encoding="utf-8") as f:
    f.write(dedent(f"""
    # Synthetic SOP Pack (Project 4 — MCP Clinic SOP Copilot)

    **Count:** {len(index_rows)} SOPs  
    **Format:** Markdown with YAML front-matter. Standard sections are labeled as `[SECTION: ...]` for easier programmatic parsing.

    ## Standard Sections
    - `[SECTION: PURPOSE]`
    - `[SECTION: SCOPE]`
    - `[SECTION: CONTRAINDICATIONS]` (if applicable)
    - `[SECTION: REQUIRED_SUPPLIES]` (if applicable)
    - `[SECTION: PROCEDURE]`
    - `[SECTION: DOCUMENTATION]`
    - `[SECTION: SAFETY_AND_INFECTION_CONTROL]` (if applicable)
    - `[SECTION: REFERENCES]`

    ## Index Files
    - `sops_index.csv`: tabular index with keywords
    - `sops_index.json`: JSON index

    ## Suggested MCP Tools
    - `sop.search(query)` → returns matches across titles/keywords/sections
    - `sop.read(section_id)` → returns full section text
    - `cite.validate(text, citations)` → simple validator for citation anchors

    All content is synthetic and intended for demos, training, and evaluation only.
    """).strip())

