"""
baseline_retrieval.py — Project 5: Reranking
Two baseline retrieval systems (no reranking):
  1. BM25          — keyword matching via rank_bm25
  2. Dense (SBERT) — cosine similarity on sentence embeddings

Both return top-K ranked SOP IDs for each query.
Results are saved to baseline_results.json for evaluation.

Run:
    python baseline_retrieval.py
Dependencies:
    pip install rank-bm25 sentence-transformers
"""

import json, os, re
from pathlib import Path

# ── helpers ──────────────────────────────────────────────────────────────────

def load_corpus(sops_dir: str) -> list[dict]:
    """Load all SOP markdown files; return list of {sop_id, title, text}."""
    index_path = os.path.join(sops_dir, "sops_index.json")
    with open(index_path, encoding="utf-8") as f:
        index = json.load(f)
    corpus = []
    for entry in index:
        md_path = os.path.join(sops_dir, entry["filename"])
        text = Path(md_path).read_text(encoding="utf-8")
        # strip YAML front-matter for cleaner text
        text = re.sub(r"^---.*?---\s*", "", text, flags=re.DOTALL)
        corpus.append({
            "sop_id": entry["sop_id"],
            "title":  entry["title"],
            "text":   text,
            "keywords": entry.get("keywords", ""),
        })
    return corpus


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


# ── BM25 retrieval ────────────────────────────────────────────────────────────

def bm25_retrieve(corpus: list[dict], queries: list[dict], top_k: int = 5) -> dict:
    from rank_bm25 import BM25Okapi
    tokenized_corpus = [tokenize(d["text"] + " " + d["keywords"]) for d in corpus]
    bm25 = BM25Okapi(tokenized_corpus)

    results = {}
    for q in queries:
        tokens = tokenize(q["query"])
        scores = bm25.get_scores(tokens)
        ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]
        results[q["qid"]] = [
            {"sop_id": corpus[i]["sop_id"], "score": float(scores[i]), "rank": r + 1}
            for r, i in enumerate(ranked)
        ]
    return results


# ── Dense (SBERT) retrieval ───────────────────────────────────────────────────

def dense_retrieve(corpus: list[dict], queries: list[dict], top_k: int = 5) -> dict:
    from sentence_transformers import SentenceTransformer
    import numpy as np

    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

    doc_texts = [d["title"] + ". " + d["text"][:512] for d in corpus]
    doc_embs  = model.encode(doc_texts, convert_to_numpy=True, show_progress_bar=True)
    # L2-normalize for cosine via dot-product
    doc_embs  = doc_embs / (np.linalg.norm(doc_embs, axis=1, keepdims=True) + 1e-9)

    query_texts = [q["query"] for q in queries]
    q_embs = model.encode(query_texts, convert_to_numpy=True, show_progress_bar=True)
    q_embs = q_embs / (np.linalg.norm(q_embs, axis=1, keepdims=True) + 1e-9)

    results = {}
    for q, qe in zip(queries, q_embs):
        scores = (doc_embs @ qe).tolist()
        ranked = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]
        results[q["qid"]] = [
            {"sop_id": corpus[i]["sop_id"], "score": float(scores[i]), "rank": r + 1}
            for r, i in enumerate(ranked)
        ]
    return results


# ── main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    base_dir  = os.path.dirname(__file__)
    sops_dir  = os.path.join(base_dir, "sops")
    queries_path = os.path.join(base_dir, "queries.json")

    if not os.path.exists(queries_path):
        raise FileNotFoundError("Run generate_queries.py first.")

    corpus  = load_corpus(sops_dir)
    queries = json.load(open(queries_path, encoding="utf-8"))

    print(f"Corpus: {len(corpus)} SOPs | Queries: {len(queries)}")

    print("\n── BM25 retrieval ──")
    bm25_res = bm25_retrieve(corpus, queries, top_k=5)

    print("\n── Dense (SBERT) retrieval ──")
    dense_res = dense_retrieve(corpus, queries, top_k=5)

    output = {
        "bm25":  bm25_res,
        "dense": dense_res,
    }
    out_path = os.path.join(base_dir, "baseline_results.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)
    print(f"\nSaved → {out_path}")

    # quick spot-check
    for qid in ["Q001", "Q011", "Q014"]:
        q = next(x for x in queries if x["qid"] == qid)
        print(f"\n[{qid}] {q['query']!r}  (type={q['query_type']})")
        print(f"  BM25 top-3  : {[r['sop_id'] for r in bm25_res[qid][:3]]}")
        print(f"  Dense top-3 : {[r['sop_id'] for r in dense_res[qid][:3]]}")
        print(f"  Relevant    : {q['relevant_sop_ids']}")
