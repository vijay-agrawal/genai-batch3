Text embeddings matter MORE for:
1. Autoimmune Dysregulation
The lab signal is deliberately weak: WBC is only mildly elevated (1.4–1.9×), and CRP is paradoxically normal — that's the whole point of this archetype. The numerical features barely deviate from healthy ranges. But the notes contain highly specific clinical vocabulary:

"Joint stiffness in mornings ... ANA ordered"

"Rash noted on arms ... autoimmune w/u initiated"

"Inflammatory markers borderline. Refer rheumatology."

Terms like joint stiffness, ANA, rheumatology, autoimmune are essentially not present in any healthy-patient note. A TF-IDF or sentence embedding will pick these up cleanly even when the structured features look near-normal.

2. Rare Cardiac Syndrome
The notes contain very distinctive event-based descriptions:

"Syncope x2 this month. BP and HR dissociation observed."

"Unexplained tachycardia. BNP normal. ECG shows subtle ST changes."

Words like syncope, palpitations, Holter, dissociation are strong textual signals. The lab signal (troponin 3–8×, HR 15–30% elevated) has some numerical strength but is not extreme — text reinforces it.

Labs are sufficient for:
3. Mitochondrial Disorder
This has the strongest numerical signal in the whole dataset: lactate is 1.8–2.8× elevated, glucose 15–30% below normal, SpO2 2–4 points lower, HGB mildly low — all simultaneously. A PCA reconstruction error or Isolation Forest will flag this from structured data alone. Notes mention "exercise intolerance" and "lactate-pyruvate ratio" but they're redundant given the numeric strength.

4. Hematologic Anomaly
The most extreme lab shift: HGB is 22–40% below normal AND WBC is 50–120% above normal simultaneously, with CRP staying normal (ruling out infection). This joint distribution is so far from the healthy covariance structure that every detector should catch it without any text. Notes ("night sweats", "flow cytometry ordered") add narrative but add no detection value.

Summary table
Disease	Lab signal	Note signal	Text adds value?
Autoimmune Dysregulation	Weak (subtle WBC↑, CRP paradox)	Strong (ANA, rheumatology, joint stiffness)	Yes, substantially
Rare Cardiac Syndrome	Moderate (troponin, HR-BP dissociation)	Strong (syncope, palpitations, Holter)	Yes, reinforces
Mitochondrial Disorder	Strong (lactate, glucose, SpO2 all off)	Moderate (exercise intolerance)	Marginal
Hematologic Anomaly	Very strong (HGB+WBC joint shift)	Moderate (night sweats, pallor)	Minimal
This is why the ablation experiment (with/without TF-IDF) is interesting — you should observe that removing text embeddings hurts AUROC for autoimmune dysregulation specifically, while having almost no effect on the hematologic archetype. Subtype-level AUROC breakdown (via subtype_breakdown() in evaluate.py) will show this directly.

