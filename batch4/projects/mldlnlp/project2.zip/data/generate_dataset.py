"""
Dataset Generator – Clinical Anomaly Detection
===============================================
Generates two complementary datasets that together require both static
and sequential anomaly detection techniques:

PART A – Rare Disease Detection (static / tabular + text)
  rare_disease_patients.csv   (~5 000 patients)
  Each row: demographics, lab values, vital signs, a clinical note, label.

  Healthy patients: features drawn from calibrated Gaussian distributions.
  Rare disease patients: same distribution BUT with subtle *multivariate*
  anomalies — individual features may sit inside normal ranges, yet their
  *correlation structure* is abnormal. This is the key learning outcome:
  simple thresholding will miss many cases; PCA / density models are needed.

PART B – ICU Monitoring (time-series)
  icu_vitals.csv   (~1 200 stays × 24 hourly readings = 28 800 rows)
  Columns: patient_id, hour, hr, sbp, dbp, spo2, rr, temp, label, pattern_type

  Normal stays: stable vitals with circadian micro-variation.
  Deteriorating stays: three realistic deterioration archetypes (sepsis,
  cardiogenic shock, respiratory failure) injected at varying onset times.

Both datasets are intentionally designed so that:
  * Preprocessing (feature scaling, note embedding) measurably affects performance.
  * The value of training *only on healthy data* is clear (test-time contamination
    experiments are possible).
  * Classical methods (OC-SVM, Isolation Forest, DBSCAN) and the LSTM autoencoder
    have distinct strengths and weaknesses visible in the evaluation metrics.

Run:
    python generate_dataset.py             # full datasets
    python generate_dataset.py --quick     # 500 patients + 200 ICU stays (for testing)
"""

from __future__ import annotations

import argparse
import random
from pathlib import Path

import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)
random.seed(42)

# ============================================================
# PART A: Static rare-disease dataset
# ============================================================

# --- Normal ranges (mean, std) for healthy adults ---
HEALTHY_PARAMS = {
    "age":        (52,  14),
    "hr":         (72,   8),    # beats/min
    "sbp":        (120, 10),    # systolic BP mmHg
    "dbp":        (80,   8),    # diastolic BP mmHg
    "spo2":       (98,   1),    # % (clipped 88–100)
    "rr":         (16,   2),    # breaths/min
    "temp":       (98.6, 0.4),  # Fahrenheit
    "wbc":        (7.5,  1.5),  # K/uL
    "hgb":        (14.0, 1.5),  # g/dL
    "glucose":    (90,  15),    # mg/dL
    "lactate":    (1.2,  0.3),  # mmol/L
    "crp":        (3.0,  1.5),  # mg/L
    "troponin":   (0.02, 0.01), # ng/mL
}

# --- Clinical note templates by category ---
HEALTHY_NOTES = [
    "Pt presents for routine annual check. VS stable. Labs WNL. No acute complaints.",
    "Follow-up visit. BP and HR within normal limits. Denies chest pain or dyspnea.",
    "Routine health maintenance. CBC and metabolic panel unremarkable. ROS negative.",
    "Pre-op clearance visit. No significant findings. Cleared for elective procedure.",
    "Patient seen for annual physical. All vitals normal. Lipid panel reviewed.",
    "Preventive care visit. Vaccinations updated. No concerns raised by patient.",
    "Asymptomatic. All labs within expected range for age and sex. F/u in 12 months.",
    "Wellness visit. BMI within healthy range. Discussed diet and exercise.",
    "Post-discharge follow-up. Recovery progressing normally. Wound well-healed.",
    "Stable chronic disease management. Meds adjusted. No acute issues noted.",
]

# Rare disease archetypes: each modifies specific feature correlations
DISEASE_ARCHETYPES = {
    "autoimmune_dysregulation": {
        "description": "Elevated WBC with paradoxically normal CRP; abnormal lymphocyte pattern.",
        "note_snippets": [
            "Recurrent low-grade fever. WBC mildly elevated. Fatigue reported.",
            "Joint stiffness in mornings. Inflammatory markers borderline. Refer rheumatology.",
            "Unexplained fatigue x3 months. CRP normal but WBC trending up. ANA ordered.",
            "Rash noted on arms. CBC shows mild leukocytosis. Autoimmune w/u initiated.",
        ],
        "modifiers": lambda f: {
            **f,
            "wbc":     f["wbc"]  * RNG.uniform(1.4, 1.9),    # elevated WBC
            "crp":     f["crp"]  * RNG.uniform(0.8, 1.2),    # paradoxically NORMAL CRP
            "hr":      f["hr"]   * RNG.uniform(1.05, 1.15),  # mildly elevated HR
            "lactate": f["lactate"] * RNG.uniform(1.1, 1.4), # slightly elevated
        },
    },
    "mitochondrial_disorder": {
        "description": "Elevated lactate, abnormal glucose metabolism, mildly low SpO2.",
        "note_snippets": [
            "Exercise intolerance and muscle weakness. Lactate elevated post-exertion.",
            "Recurrent hypoglycaemia episodes. Lactate borderline high. Genetics referral.",
            "Fatigue and cognitive fog. SpO2 drops with minimal exertion. Metabolic w/u.",
            "Abnormal lactate-to-pyruvate ratio. Glucose regulation impaired. MRI ordered.",
        ],
        "modifiers": lambda f: {
            **f,
            "lactate": f["lactate"] * RNG.uniform(1.8, 2.8),  # elevated lactate
            "glucose": f["glucose"] * RNG.uniform(0.70, 0.85),# low glucose
            "spo2":    f["spo2"]   - RNG.uniform(2.0, 4.0),   # slightly lower SpO2
            "hgb":     f["hgb"]   * RNG.uniform(0.80, 0.92),  # mild anaemia
        },
    },
    "rare_cardiac_syndrome": {
        "description": "Abnormal HR–BP correlation; episodic troponin release.",
        "note_snippets": [
            "Palpitations on exertion. Echo unremarkable. Holter monitor ordered.",
            "Atypical chest pain episodes. Troponin borderline. Cardiology referral.",
            "Syncope x2 this month. BP and HR dissociation observed. Cardiac MRI.",
            "Unexplained tachycardia. BNP normal. ECG shows subtle ST changes.",
        ],
        "modifiers": lambda f: {
            **f,
            "hr":       f["hr"]      * RNG.uniform(1.15, 1.30),  # elevated HR
            "sbp":      f["sbp"]     * RNG.uniform(0.92, 0.98),  # slightly low SBP (dissociation)
            "troponin": f["troponin"] * RNG.uniform(3.0, 8.0),   # elevated troponin
            "dbp":      f["dbp"]     * RNG.uniform(0.88, 0.96),
        },
    },
    "hematologic_anomaly": {
        "description": "Abnormal WBC/HGB joint distribution; inconsistent with infection.",
        "note_snippets": [
            "Incidental finding of low HGB with elevated WBC. No infection source found.",
            "Fatigue and pallor. CBC: anaemia with leukocytosis. Haematology referral.",
            "Unexplained anaemia. Reticulocyte count low. WBC elevated. BM biopsy ordered.",
            "Night sweats and weight loss. WBC high, HGB dropping. Flow cytometry ordered.",
        ],
        "modifiers": lambda f: {
            **f,
            "hgb":  f["hgb"]  * RNG.uniform(0.60, 0.78),   # significantly low HGB
            "wbc":  f["wbc"]  * RNG.uniform(1.5, 2.2),      # elevated WBC
            "crp":  f["crp"]  * RNG.uniform(0.9, 1.3),      # normal CRP (not infective)
            "hr":   f["hr"]   * RNG.uniform(1.05, 1.20),    # compensatory tachycardia
        },
    },
}


def _sample_healthy() -> dict:
    f = {k: float(RNG.normal(mu, sigma)) for k, (mu, sigma) in HEALTHY_PARAMS.items()}
    f["spo2"]    = float(np.clip(f["spo2"], 88, 100))
    f["age"]     = float(np.clip(f["age"], 18, 95))
    f["rr"]      = float(max(8, f["rr"]))
    f["wbc"]     = float(max(1.0, f["wbc"]))
    f["hgb"]     = float(max(5.0, f["hgb"]))
    f["glucose"] = float(max(40, f["glucose"]))
    f["lactate"] = float(max(0.3, f["lactate"]))
    f["troponin"]= float(max(0.001, f["troponin"]))
    return f


def generate_static_dataset(n_total: int = 5000, anomaly_fraction: float = 0.09) -> pd.DataFrame:
    """
    Returns a DataFrame of patient records (static snapshot).

    CLASS BALANCE: ~91% healthy, ~9% rare disease.
    Individual feature values for diseased patients intentionally overlap with
    healthy ranges — multivariate detection is required.
    """
    archetypes = list(DISEASE_ARCHETYPES.keys())
    n_anomaly  = int(n_total * anomaly_fraction)
    n_healthy  = n_total - n_anomaly

    rows = []

    # Healthy patients
    for i in range(n_healthy):
        f = _sample_healthy()
        rows.append({
            "patient_id":  f"P-{i+1:05d}",
            "label":       0,
            "disease_type": "healthy",
            "clinical_note": random.choice(HEALTHY_NOTES),
            **f,
        })

    # Rare disease patients
    for j in range(n_anomaly):
        archetype_name = archetypes[j % len(archetypes)]
        arch = DISEASE_ARCHETYPES[archetype_name]
        f = _sample_healthy()
        f = arch["modifiers"](f)
        # Clip physiologically
        f["spo2"]    = float(np.clip(f["spo2"], 70, 100))
        f["lactate"] = float(max(0.3, f["lactate"]))
        f["troponin"]= float(max(0.001, f["troponin"]))
        rows.append({
            "patient_id":  f"P-{n_healthy+j+1:05d}",
            "label":       1,
            "disease_type": archetype_name,
            "clinical_note": random.choice(arch["note_snippets"]),
            **f,
        })

    df = pd.DataFrame(rows)
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    return df


# ============================================================
# PART B: ICU time-series dataset
# ============================================================

# Circadian variation amplitudes (healthy)
CIRCADIAN = {
    "hr":   (4, 0.26),    # amplitude, phase shift (radians)
    "sbp":  (6, 0.26),
    "spo2": (0.4, 0),
    "rr":   (1.5, 0),
    "temp": (0.5, -0.52),  # temp lowest ~4am
}

FEATURE_NAMES_ICU = ["hr", "sbp", "dbp", "spo2", "rr", "temp"]


def _healthy_icu_sequence(n_hours: int = 24) -> np.ndarray:
    """Generate a realistic stable ICU vital signs sequence."""
    hours = np.arange(n_hours)
    seq = np.zeros((n_hours, 6))

    base_hr   = float(RNG.normal(78, 8))
    base_sbp  = float(RNG.normal(122, 10))
    base_dbp  = float(RNG.normal(78,  8))
    base_spo2 = float(RNG.normal(97.5, 0.8))
    base_rr   = float(RNG.normal(17, 2))
    base_temp = float(RNG.normal(98.8, 0.3))

    for t, h in enumerate(hours):
        phase = 2 * np.pi * h / 24
        seq[t, 0] = base_hr   + 4   * np.sin(phase + 0.26) + RNG.normal(0, 2)
        seq[t, 1] = base_sbp  + 6   * np.sin(phase + 0.26) + RNG.normal(0, 3)
        seq[t, 2] = base_dbp  + 4   * np.sin(phase + 0.26) + RNG.normal(0, 2)
        seq[t, 3] = base_spo2 + 0.4 * np.sin(phase)        + RNG.normal(0, 0.3)
        seq[t, 4] = base_rr   + 1.5 * np.sin(phase)        + RNG.normal(0, 0.5)
        seq[t, 5] = base_temp + 0.5 * np.sin(phase - 0.52) + RNG.normal(0, 0.15)

    # Physiological clipping
    seq[:, 0] = np.clip(seq[:, 0], 40, 160)   # HR
    seq[:, 1] = np.clip(seq[:, 1], 70, 200)   # SBP
    seq[:, 2] = np.clip(seq[:, 2], 40, 130)   # DBP
    seq[:, 3] = np.clip(seq[:, 3], 85, 100)   # SpO2
    seq[:, 4] = np.clip(seq[:, 4],  8, 40)    # RR
    seq[:, 5] = np.clip(seq[:, 5], 96, 104)   # Temp
    return seq


def _deteriorating_sequence(pattern: str, onset_hour: int = 8, n_hours: int = 24) -> np.ndarray:
    """
    Inject a clinical deterioration pattern into an otherwise normal sequence.

    Patterns:
      sepsis            : HR up, Temp spike, SBP drops late, SpO2 drifts down
      cardiogenic_shock : SBP collapses, HR compensates, SpO2 drops
      respiratory_failure: RR spikes, SpO2 plummets, HR rises reactively
    """
    seq = _healthy_icu_sequence(n_hours)
    for t in range(n_hours):
        if t < onset_hour:
            continue
        progress = (t - onset_hour) / max(n_hours - onset_hour - 1, 1)   # 0 → 1

        if pattern == "sepsis":
            seq[t, 0] += progress * RNG.uniform(20, 35)      # HR up
            seq[t, 5] += progress * RNG.uniform(1.5, 3.0)    # Temp spike
            seq[t, 1] -= progress * RNG.uniform(15, 30)      # SBP drops
            seq[t, 3] -= progress * RNG.uniform(3, 6)        # SpO2 drifts
            seq[t, 4] += progress * RNG.uniform(5, 10)       # RR up

        elif pattern == "cardiogenic_shock":
            seq[t, 1] -= progress * RNG.uniform(30, 50)      # SBP collapses
            seq[t, 2] -= progress * RNG.uniform(20, 35)      # DBP collapses
            seq[t, 0] += progress * RNG.uniform(15, 30)      # HR compensates
            seq[t, 3] -= progress * RNG.uniform(4, 9)        # SpO2 drops
            seq[t, 4] += progress * RNG.uniform(6, 12)       # RR up

        elif pattern == "respiratory_failure":
            seq[t, 4] += progress * RNG.uniform(10, 20)      # RR spikes
            seq[t, 3] -= progress * RNG.uniform(6, 12)       # SpO2 plummets
            seq[t, 0] += progress * RNG.uniform(10, 20)      # HR reactively up

    # Re-clip after injection
    seq[:, 0] = np.clip(seq[:, 0], 30, 200)
    seq[:, 1] = np.clip(seq[:, 1], 40, 220)
    seq[:, 2] = np.clip(seq[:, 2], 20, 140)
    seq[:, 3] = np.clip(seq[:, 3], 60, 100)
    seq[:, 4] = np.clip(seq[:, 4],  6, 60)
    seq[:, 5] = np.clip(seq[:, 5], 96, 106)
    return seq


ICU_NOTES_NORMAL = [
    "Patient resting comfortably. VS stable throughout shift. No acute concerns.",
    "Tolerating diet well. Ambulated with PT. Vitals within expected range.",
    "Overnight uneventful. BP and HR stable. Pain managed with scheduled analgesia.",
    "Alert and oriented x3. Respiratory status unchanged. Labs pending.",
    "Stable post-op day 2. Incision site clean. Vitals monitoring continued.",
]

ICU_NOTES_DETERIORATING = {
    "sepsis": [
        "New fever noted. HR trending up. Blood cultures drawn. Antibiotics started.",
        "Temp 39.8, HR 118. Hypotension developing. Fluids bolused. Sepsis protocol activated.",
        "Vasopressors initiated. CVP monitoring. Lactate elevated. ICU team at bedside.",
    ],
    "cardiogenic_shock": [
        "BP dropping despite fluids. Cardiology consulted. Echo ordered.",
        "Cardiogenic shock suspected. Dobutamine started. Invasive monitoring placed.",
        "MAP <65 on vasopressors. Pulmonary oedema on CXR. Cath lab notified.",
    ],
    "respiratory_failure": [
        "SpO2 dropping. O2 requirements increasing. ABG drawn. NIV initiated.",
        "Work of breathing increased. RR 34. HFNC trialled. Intensivist called.",
        "Intubation planned. Pre-oxygenation in progress. Anaesthesia at bedside.",
    ],
}


def generate_icu_dataset(
    n_normal: int = 900,
    n_anomaly: int = 300,
    n_hours: int = 24,
) -> pd.DataFrame:
    """Returns a long-format DataFrame (one row per patient-hour)."""
    deterioration_patterns = ["sepsis", "cardiogenic_shock", "respiratory_failure"]
    rows = []

    # Normal ICU stays
    for i in range(n_normal):
        pid   = f"ICU-{i+1:05d}"
        seq   = _healthy_icu_sequence(n_hours)
        note  = random.choice(ICU_NOTES_NORMAL)
        for t in range(n_hours):
            rows.append({
                "patient_id":  pid,
                "hour":        t,
                "hr":          round(seq[t, 0], 1),
                "sbp":         round(seq[t, 1], 1),
                "dbp":         round(seq[t, 2], 1),
                "spo2":        round(seq[t, 3], 2),
                "rr":          round(seq[t, 4], 1),
                "temp":        round(seq[t, 5], 2),
                "label":       0,
                "pattern_type":"normal",
                "shift_note":  note if t % 8 == 0 else "",   # note every 8 hours
            })

    # Deteriorating ICU stays
    for j in range(n_anomaly):
        pid     = f"ICU-{n_normal+j+1:05d}"
        pattern = deterioration_patterns[j % len(deterioration_patterns)]
        onset   = int(RNG.integers(6, 16))   # onset between hour 6 and 15
        seq     = _deteriorating_sequence(pattern, onset_hour=onset, n_hours=n_hours)
        for t in range(n_hours):
            note = ""
            if t % 8 == 0:
                shift = t // 8
                if t >= onset and shift > 0:
                    note = random.choice(ICU_NOTES_DETERIORATING[pattern])
                else:
                    note = random.choice(ICU_NOTES_NORMAL)
            rows.append({
                "patient_id":  pid,
                "hour":        t,
                "hr":          round(seq[t, 0], 1),
                "sbp":         round(seq[t, 1], 1),
                "dbp":         round(seq[t, 2], 1),
                "spo2":        round(seq[t, 3], 2),
                "rr":          round(seq[t, 4], 1),
                "temp":        round(seq[t, 5], 2),
                "label":       1,
                "pattern_type": pattern,
                "shift_note":  note,
            })

    df = pd.DataFrame(rows)
    # Shuffle at patient level
    pids    = df["patient_id"].unique().tolist()
    random.shuffle(pids)
    order   = {pid: i for i, pid in enumerate(pids)}
    df      = df.sort_values(by=["patient_id", "hour"],
                             key=lambda s: s.map(order) if s.name == "patient_id" else s)
    return df.reset_index(drop=True)


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true",
                        help="Generate smaller dataset for quick testing")
    parser.add_argument("--out", default=".", help="Output directory")
    args = parser.parse_args()

    out = Path(__file__).parent if args.out == "." else Path(args.out)

    if args.quick:
        n_static, n_icu_normal, n_icu_anom = 500, 150, 50
    else:
        n_static, n_icu_normal, n_icu_anom = 5000, 900, 300

    print("Generating Part A: rare disease static dataset ...")
    static_df = generate_static_dataset(n_total=n_static)
    static_path = out / "rare_disease_patients.csv"
    static_df.to_csv(static_path, index=False)
    healthy = (static_df["label"] == 0).sum()
    anomaly = (static_df["label"] == 1).sum()
    print(f"  Saved {len(static_df)} rows -> {static_path}")
    print(f"  Healthy: {healthy} ({100*healthy/len(static_df):.1f}%)  "
          f"Anomaly: {anomaly} ({100*anomaly/len(static_df):.1f}%)")
    if not args.quick:
        print("  Disease breakdown:")
        for dt, cnt in static_df[static_df["label"]==1]["disease_type"].value_counts().items():
            print(f"    {dt:<30} {cnt}")

    print("\nGenerating Part B: ICU time-series dataset ...")
    icu_df = generate_icu_dataset(n_normal=n_icu_normal, n_anomaly=n_icu_anom)
    icu_path = out / "icu_vitals.csv"
    icu_df.to_csv(icu_path, index=False)
    n_stays = icu_df["patient_id"].nunique()
    n_anom  = icu_df[icu_df["label"]==1]["patient_id"].nunique()
    print(f"  Saved {len(icu_df)} rows ({n_stays} stays) -> {icu_path}")
    print(f"  Normal: {n_stays-n_anom}  Deteriorating: {n_anom}  "
          f"({100*n_anom/n_stays:.1f}%)")

    # Print sample rows to illustrate what preprocessing must handle
    print("\nSample – rare disease (multivariate anomaly, individual features look plausible):")
    sample = static_df[static_df["label"] == 1].head(2)[
        ["disease_type", "wbc", "crp", "hgb", "lactate", "spo2", "troponin", "clinical_note"]
    ]
    print(sample.to_string(index=False))

    print("\nSample – ICU deterioration onset (first anomalous hour shown):")
    det = icu_df[icu_df["label"] == 1].groupby("patient_id").first().head(2)[
        ["hr", "sbp", "spo2", "rr", "temp", "pattern_type"]
    ]
    print(det.to_string())
