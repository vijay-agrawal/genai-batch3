"""
Prediction & Explainability
============================
Wraps trained detectors into a single Predictor interface that:
  1. Preprocesses raw input (static or sequential)
  2. Computes anomaly scores
  3. Applies the calibrated threshold to produce a verdict
  4. Builds feature-level explanations
  5. Extracts clinical safety flags (hard threshold — independent of model)
  6. Returns Pydantic-validated AnomalyDetectionOutput

Explainability strategies by model:
  PCA              : per-feature squared residual in PCA space
  Isolation Forest : SHAP TreeExplainer (fast, exact for ensemble)
  One-Class SVM    : permutation importance (approximate; slow)
  LSTM Autoencoder : per-feature temporal reconstruction error

TODO (Student Task 9):
  Implement explain_isolation_forest() using SHAP.
  Guide is provided inline.
"""

from __future__ import annotations

import uuid
from typing import Optional

import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import MinMaxScaler

from models import (
    DBSCANDetector,
    IsolationForestDetector,
    LSTMAutoencoder,
    OneClassSVMDetector,
    PCADetector,
)
from preprocess import (
    ICU_FEATURES,
    SequencePreprocessor,
    StaticPreprocessor,
    extract_clinical_flags_icu,
    extract_clinical_flags_static,
)
from schemas import (
    AnomalyDetectionOutput,
    AnomalyVerdict,
    BatchAnomalyOutput,
    DataModality,
    DetectionMethod,
    FeatureContribution,
)


# ---------------------------------------------------------------------------
# Score normaliser (shared helper)
# ---------------------------------------------------------------------------

def _build_score_normaliser(raw_train_scores: np.ndarray) -> MinMaxScaler:
    scaler = MinMaxScaler()
    scaler.fit(raw_train_scores.reshape(-1, 1))
    return scaler


def _normalise(raw: np.ndarray, scaler: MinMaxScaler) -> np.ndarray:
    return np.clip(scaler.transform(raw.reshape(-1, 1)).flatten(), 0.0, 1.0)


# ============================================================
# Part A – Static Predictor
# ============================================================

class StaticPredictor:
    """
    Predict anomaly for a static patient record using a classical detector.

    Supports: PCADetector, IsolationForestDetector, OneClassSVMDetector, DBSCAN.
    """

    METHOD_MAP = {
        PCADetector:             DetectionMethod.PCA,
        IsolationForestDetector: DetectionMethod.ISOFOREST,
        OneClassSVMDetector:     DetectionMethod.OCSVM,
        DBSCANDetector:          DetectionMethod.DBSCAN,
    }

    def __init__(
        self,
        detector:    object,          # one of the static detector classes
        preprocessor: StaticPreprocessor,
        threshold:    float,
        feature_names: list[str],
    ):
        self.detector     = detector
        self.preprocessor = preprocessor
        self.threshold    = threshold
        self.feature_names = feature_names
        self.method       = self.METHOD_MAP.get(type(detector), DetectionMethod.PCA)

    def predict_row(self, row: pd.Series, patient_id: Optional[str] = None) -> AnomalyDetectionOutput:
        df  = pd.DataFrame([row])
        X   = self.preprocessor.transform(df)
        score = self._score(X)[0]

        verdict = AnomalyVerdict.ANOMALY if score >= self.threshold else AnomalyVerdict.NORMAL
        contributions = self._explain(X[0], row)
        flags = extract_clinical_flags_static(row)

        top3 = [f.feature for f in contributions[:3]]
        reasoning = (
            f"Classified as {verdict.value} (score={score:.3f}, threshold={self.threshold:.3f}). "
            f"Top deviating features: {', '.join(top3)}."
        )

        return AnomalyDetectionOutput(
            patient_id            = patient_id or f"P-{uuid.uuid4().hex[:8].upper()}",
            data_modality         = DataModality.MIXED,
            verdict               = verdict,
            anomaly_score         = round(float(score), 6),
            detection_method      = self.method,
            threshold_used        = self.threshold,
            feature_contributions = contributions if contributions else [
                FeatureContribution(feature="unknown", value=0.0,
                                    contribution=0.0, direction="pattern")
            ],
            clinical_flags = flags,
            reasoning      = reasoning,
        )

    def predict_dataframe(self, df: pd.DataFrame) -> BatchAnomalyOutput:
        results = []
        for _, row in df.iterrows():
            pid = str(row.get("patient_id", uuid.uuid4().hex[:8]))
            results.append(self.predict_row(row, pid))

        n_anom = sum(r.verdict == AnomalyVerdict.ANOMALY for r in results)
        avg_s  = float(np.mean([r.anomaly_score for r in results]))
        rate   = n_anom / len(results)

        return BatchAnomalyOutput(
            results            = results,
            total_evaluated    = len(results),
            n_anomalies        = n_anom,
            anomaly_rate       = round(rate, 6),
            mean_anomaly_score = round(avg_s, 6),
            detection_method   = self.method,
            threshold_used     = self.threshold,
        )

    # ------------------------------------------------------------------

    def _score(self, X: np.ndarray) -> np.ndarray:
        if isinstance(self.detector, DBSCANDetector):
            return self.detector.fit_predict_anomaly_score(X)
        return self.detector.anomaly_score(X)

    def _explain(self, x: np.ndarray, raw_row: pd.Series) -> list[FeatureContribution]:
        if isinstance(self.detector, PCADetector):
            return _explain_pca(self.detector, x, raw_row, self.feature_names)
        elif isinstance(self.detector, IsolationForestDetector):
            return explain_isolation_forest(self.detector, x, raw_row, self.feature_names)
        else:
            return _fallback_contributions(x, raw_row, self.feature_names)


# ============================================================
# Part B – LSTM AE Predictor
# ============================================================

class LSTMAEPredictor:
    """
    Predict anomaly for an ICU stay using the LSTM Autoencoder.
    """

    def __init__(
        self,
        model:          LSTMAutoencoder,
        preprocessor:   SequencePreprocessor,
        score_normaliser: MinMaxScaler,    # fitted on normal train reconstruction errors
        threshold:        float,
        device:           str = "cpu",
    ):
        self.model            = model.to(device).eval()
        self.preprocessor     = preprocessor
        self.score_normaliser = score_normaliser
        self.threshold        = threshold
        self.device           = device

    def predict_stay(
        self,
        stay_df:    pd.DataFrame,   # long-format rows for ONE patient
        patient_id: Optional[str] = None,
    ) -> AnomalyDetectionOutput:
        """Predict for a single ICU stay (multiple hourly rows)."""
        pid = patient_id or str(stay_df["patient_id"].iloc[0])

        X, _ = self.preprocessor.transform(stay_df)             # (1, T, F)
        t     = torch.tensor(X, dtype=torch.float32).to(self.device)

        raw_err   = self.model.reconstruction_error(t, per_feature=False)  # (1,)
        per_feat  = self.model.reconstruction_error(t, per_feature=True)   # (1, F)

        norm_score = float(np.clip(
            self.score_normaliser.transform(raw_err.reshape(-1, 1)).flatten()[0], 0, 1
        ))
        verdict    = AnomalyVerdict.ANOMALY if norm_score >= self.threshold else AnomalyVerdict.NORMAL

        # Per-feature contributions
        feat_errs = per_feat[0]     # (F,)
        contributions = [
            FeatureContribution(
                feature      = ICU_FEATURES[i],
                value        = float(stay_df[ICU_FEATURES[i]].mean()),
                contribution = float(feat_errs[i]),
                direction    = _direction(stay_df, ICU_FEATURES[i]),
            )
            for i in range(len(ICU_FEATURES))
        ]
        contributions.sort(key=lambda c: c.contribution, reverse=True)

        flags     = extract_clinical_flags_icu(stay_df)
        top3      = [c.feature for c in contributions[:3]]
        reasoning = (
            f"LSTM AE reconstruction error = {raw_err[0]:.4f} (normalised={norm_score:.3f}). "
            f"Highest errors in: {', '.join(top3)}. "
            f"Verdict: {verdict.value} (threshold={self.threshold:.3f})."
        )

        return AnomalyDetectionOutput(
            patient_id           = pid,
            data_modality        = DataModality.TIME_SERIES,
            verdict              = verdict,
            anomaly_score        = round(norm_score, 6),
            detection_method     = DetectionMethod.LSTM_AE,
            threshold_used       = self.threshold,
            reconstruction_error = round(float(raw_err[0]), 6),
            feature_contributions= contributions[:6],
            clinical_flags       = flags,
            reasoning            = reasoning,
        )

    def predict_cohort(
        self,
        icu_df: pd.DataFrame,
    ) -> BatchAnomalyOutput:
        """Predict for all patients in a long-format ICU DataFrame."""
        results = []
        for pid in icu_df["patient_id"].unique():
            stay = icu_df[icu_df["patient_id"] == pid]
            results.append(self.predict_stay(stay, pid))

        n_anom = sum(r.verdict == AnomalyVerdict.ANOMALY for r in results)
        avg_s  = float(np.mean([r.anomaly_score for r in results]))
        rate   = n_anom / len(results)

        return BatchAnomalyOutput(
            results            = results,
            total_evaluated    = len(results),
            n_anomalies        = n_anom,
            anomaly_rate       = round(rate, 6),
            mean_anomaly_score = round(avg_s, 6),
            detection_method   = DetectionMethod.LSTM_AE,
            threshold_used     = self.threshold,
        )


# ============================================================
# Explainability helpers
# ============================================================

def _explain_pca(
    detector:      PCADetector,
    x:             np.ndarray,   # (D,) scaled feature vector
    raw_row:       pd.Series,
    feature_names: list[str],
) -> list[FeatureContribution]:
    """Use per-feature squared residual as contribution."""
    contribs = detector.feature_contributions(x)   # (D,)
    result   = []
    for i, name in enumerate(feature_names[:len(contribs)]):
        raw_val  = float(raw_row.get(name, 0.0))
        direction = "high" if raw_val > 0 else "low"
        result.append(FeatureContribution(
            feature      = name,
            value        = raw_val,
            contribution = float(contribs[i]),
            direction    = direction,
        ))
    result.sort(key=lambda c: c.contribution, reverse=True)
    return result[:8]


def explain_isolation_forest(
    detector:      IsolationForestDetector,
    x:             np.ndarray,    # (D,) scaled feature vector
    raw_row:       pd.Series,
    feature_names: list[str],
    top_k:         int = 6,
) -> list[FeatureContribution]:
    """
    Use SHAP TreeExplainer to compute per-feature attribution for the
    Isolation Forest anomaly score.

    TODO (Student Task 9):
    Remove the fallback and implement using SHAP.

    Steps:
      import shap
      explainer  = shap.TreeExplainer(detector.model)
      shap_vals  = explainer.shap_values(x.reshape(1, -1))   # (1, D)
      importances = np.abs(shap_vals[0])                      # (D,) unsigned

      contributions = [
          FeatureContribution(
              feature      = feature_names[i],
              value        = float(raw_row.get(feature_names[i], 0.0)),
              contribution = float(importances[i]),
              direction    = "high" if shap_vals[0][i] > 0 else "low",
          )
          for i in range(min(len(feature_names), len(importances)))
      ]
      contributions.sort(key=lambda c: c.contribution, reverse=True)
      return contributions[:top_k]

    Note: shap_vals > 0 means the feature pushed the score UP (toward anomaly).
    """
    return _fallback_contributions(x, raw_row, feature_names, top_k)


def _fallback_contributions(
    x:             np.ndarray,
    raw_row:       pd.Series,
    feature_names: list[str],
    top_k:         int = 6,
) -> list[FeatureContribution]:
    """Placeholder: uniform contributions (replace with real explanations)."""
    n = min(len(feature_names), len(x), top_k)
    return [
        FeatureContribution(
            feature      = feature_names[i],
            value        = float(raw_row.get(feature_names[i], 0.0)),
            contribution = float(abs(x[i])),
            direction    = "high" if x[i] > 0 else "low",
        )
        for i in range(n)
    ]


def _direction(stay_df: pd.DataFrame, feature: str) -> str:
    """Infer whether a vital sign was trending high or low during the stay."""
    if feature not in stay_df.columns:
        return "pattern"
    vals = stay_df[feature].dropna().values
    if len(vals) < 2:
        return "pattern"
    return "high" if vals[-1] > vals[0] else "low"
