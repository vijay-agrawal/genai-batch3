"""
Main Entry Point
================
Orchestrates both parts of the project end-to-end:

  Part A (static): PCA / OC-SVM / Isolation Forest / DBSCAN
    on rare_disease_patients.csv

  Part B (sequential): LSTM Autoencoder
    on icu_vitals.csv

Run:
    # Part A only (all classical detectors)
    python main.py --part A

    # Part B only (LSTM AE — requires GPU for reasonable speed)
    python main.py --part B --epochs 50

    # Both parts
    python main.py --part both --epochs 50 --out outputs/
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset

sys.path.insert(0, str(Path(__file__).parent))

from evaluate import compare_detectors, evaluate_detector, plot_threshold_sweep, subtype_breakdown
from models import IsolationForestDetector, LSTMAutoencoder, PCADetector, OneClassSVMDetector
from predict import LSTMAEPredictor, StaticPredictor, _build_score_normaliser
from preprocess import ICU_FEATURES, SequencePreprocessor, StaticPreprocessor
from train import TrainerLSTMAE, calibrate_threshold, make_normal_dataloader, plot_training_curves


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(description="Clinical Anomaly Detector")
    p.add_argument("--part",    choices=["A", "B", "both"], default="both")
    p.add_argument("--data_dir",default="data")
    p.add_argument("--epochs",  type=int, default=50)
    p.add_argument("--batch",   type=int, default=32)
    p.add_argument("--device",  default=None)
    p.add_argument("--out",     default="outputs")
    return p.parse_args()


# ---------------------------------------------------------------------------
# Part A – Static rare-disease detection
# ---------------------------------------------------------------------------

def run_part_a(data_dir: Path, out_dir: Path) -> list[dict]:
    csv_path = data_dir / "rare_disease_patients.csv"
    if not csv_path.exists():
        sys.exit(f"Dataset not found: {csv_path}\nRun: python data/generate_dataset.py")

    print("\n" + "="*60)
    print("  PART A — RARE DISEASE DETECTION (STATIC)")
    print("="*60)

    df = pd.read_csv(csv_path)
    print(f"Loaded {len(df)} patients  (anomaly rate: {df['label'].mean()*100:.1f}%)")

    # Stratified split — but fit preprocessor ONLY on healthy training patients
    train_df, test_df = train_test_split(
        df, test_size=0.20, stratify=df["label"], random_state=42
    )
    train_healthy = train_df[train_df["label"] == 0]
    print(f"Train (healthy only): {len(train_healthy)}  |  Test (all): {len(test_df)}")

    # Preprocessing
    prep = StaticPreprocessor(tfidf_max_features=80)
    X_train_h = prep.fit(train_healthy).transform(train_healthy)
    X_test    = prep.transform(test_df)
    y_test    = test_df["label"].values

    all_metrics = []

    # PCA
    pca_det  = PCADetector(n_components=10).fit(X_train_h)
    pca_thr  = calibrate_threshold(pca_det.anomaly_score(X_train_h), target_fpr=0.05)
    pca_sc   = pca_det.anomaly_score(X_test)
    m = evaluate_detector(y_test, pca_sc, pca_thr, "PCA", save_dir=str(out_dir))
    subtype_breakdown(test_df, pca_sc, pca_thr, "PCA")
    all_metrics.append(m)
    plot_threshold_sweep(y_test, pca_sc, "PCA",
                         save_path=str(out_dir / "threshold_sweep_pca.png"))

    # Isolation Forest
    if_det  = IsolationForestDetector(contamination=0.09).fit(X_train_h)
    if_thr  = calibrate_threshold(if_det.anomaly_score(X_train_h), target_fpr=0.05)
    if_sc   = if_det.anomaly_score(X_test)
    m = evaluate_detector(y_test, if_sc, if_thr, "Isolation Forest", save_dir=str(out_dir))
    subtype_breakdown(test_df, if_sc, if_thr, "Isolation Forest")
    all_metrics.append(m)

    # OC-SVM (on PCA-reduced space for speed)
    print("\n[OC-SVM] Reducing to 20 PCA components first ...")
    from sklearn.decomposition import PCA as skPCA
    pca_pre = skPCA(n_components=20, random_state=42).fit(X_train_h)
    X_train_pca = pca_pre.transform(X_train_h)
    X_test_pca  = pca_pre.transform(X_test)

    svm_det = OneClassSVMDetector(nu=0.07).fit(X_train_pca)
    svm_thr = calibrate_threshold(svm_det.anomaly_score(X_train_pca), target_fpr=0.05)
    svm_sc  = svm_det.anomaly_score(X_test_pca)
    m = evaluate_detector(y_test, svm_sc, svm_thr, "OC-SVM", save_dir=str(out_dir))
    all_metrics.append(m)

    compare_detectors(all_metrics,
                      save_path=str(out_dir / "partA_comparison.png"))

    # JSON predictions using best model by AUROC
    best = max(all_metrics, key=lambda x: x["auroc"])
    print(f"\nBest detector by AUROC: {best['detector']} ({best['auroc']:.4f})")

    # Build predictor for best static model and save predictions
    det_map = {"PCA": pca_det, "Isolation Forest": if_det, "OC-SVM": svm_det}
    thr_map = {"PCA": pca_thr, "Isolation Forest": if_thr, "OC-SVM": svm_thr}
    best_det = det_map[best["detector"]]
    best_thr = thr_map[best["detector"]]

    predictor = StaticPredictor(
        detector      = best_det,
        preprocessor  = prep,
        threshold     = best_thr,
        feature_names = prep.feature_names,
    )
    batch_out = predictor.predict_dataframe(test_df)
    pred_path = out_dir / "predictions_partA.json"
    pred_path.write_text(batch_out.model_dump_json(indent=2), encoding="utf-8")
    print(f"Predictions saved -> {pred_path}")
    print(f"Anomaly rate in predictions: {batch_out.anomaly_rate:.1%}")

    return all_metrics


# ---------------------------------------------------------------------------
# Part B – ICU LSTM Autoencoder
# ---------------------------------------------------------------------------

def run_part_b(data_dir: Path, out_dir: Path, epochs: int, batch: int, device: str) -> dict:
    csv_path = data_dir / "icu_vitals.csv"
    if not csv_path.exists():
        sys.exit(f"Dataset not found: {csv_path}\nRun: python data/generate_dataset.py")

    print("\n" + "="*60)
    print("  PART B — ICU MONITORING (LSTM AUTOENCODER)")
    print("="*60)

    icu_df = pd.read_csv(csv_path)
    print(f"Loaded {icu_df['patient_id'].nunique()} ICU stays  "
          f"(anomaly rate: {icu_df.groupby('patient_id')['label'].first().mean()*100:.1f}%)")

    # Split at PATIENT level (never split a stay across train/test)
    all_pids     = icu_df["patient_id"].unique()
    pid_labels   = icu_df.groupby("patient_id")["label"].first()
    train_pids, test_pids = train_test_split(
        all_pids, test_size=0.20, stratify=pid_labels[all_pids], random_state=42
    )
    train_df = icu_df[icu_df["patient_id"].isin(train_pids)]
    test_df  = icu_df[icu_df["patient_id"].isin(test_pids)]

    # Fit preprocessor on NORMAL training stays ONLY
    normal_train = train_df[train_df["label"] == 0]
    seq_prep     = SequencePreprocessor().fit(normal_train)

    # Training data: only normal sequences
    X_train_n, _ = seq_prep.transform(normal_train)
    X_test,  y_test = seq_prep.transform(test_df)

    print(f"Training sequences (normal only): {len(X_train_n)}")
    print(f"Test sequences (all):             {len(X_test)}  "
          f"(anomaly rate: {y_test.mean():.1%})")

    # Validation split from normal training data
    n_val   = max(1, int(len(X_train_n) * 0.15))
    X_val_n = X_train_n[:n_val]
    X_tr_n  = X_train_n[n_val:]

    train_loader = make_normal_dataloader(X_tr_n,  batch_size=batch, shuffle=True)
    val_loader   = make_normal_dataloader(X_val_n, batch_size=batch, shuffle=False)

    # Build and train LSTM AE
    model = LSTMAutoencoder(
        n_features = seq_prep.n_features,
        hidden_dim = 64,
        seq_len    = 24,
        dropout    = 0.2,
    )
    trainer = TrainerLSTMAE(
        model       = model,
        train_loader= train_loader,
        val_loader  = val_loader,
        lr          = 1e-3,
        device      = device,
        checkpoint_dir = out_dir / "checkpoints",
    )
    history = trainer.fit(epochs=epochs, early_stop_patience=8)
    plot_training_curves(history, save_path=str(out_dir / "lstm_ae_training.png"))

    # Calibrate threshold using normal train reconstruction errors
    X_tn_t = torch.tensor(X_tr_n, dtype=torch.float32).to(device)
    raw_train_err = model.reconstruction_error(X_tn_t)
    score_norm    = _build_score_normaliser(raw_train_err)
    threshold     = calibrate_threshold(
        np.clip(score_norm.transform(raw_train_err.reshape(-1, 1)).flatten(), 0, 1),
        target_fpr=0.05
    )

    # Evaluate on test set
    X_test_t = torch.tensor(X_test, dtype=torch.float32).to(device)
    raw_test  = model.reconstruction_error(X_test_t)
    test_scores = np.clip(
        score_norm.transform(raw_test.reshape(-1, 1)).flatten(), 0, 1
    )
    metrics_ae = evaluate_detector(
        y_test, test_scores, threshold, "LSTM Autoencoder", save_dir=str(out_dir)
    )
    plot_threshold_sweep(y_test, test_scores, "LSTM Autoencoder",
                         save_path=str(out_dir / "threshold_sweep_lstm.png"))

    # Per-pattern breakdown
    test_pid_labels = icu_df[icu_df["patient_id"].isin(test_pids)].groupby(
        "patient_id"
    )[["label", "pattern_type"]].first().reset_index()
    test_pid_labels["score"] = test_scores
    print("\nPer-pattern breakdown:")
    for pat, grp in test_pid_labels.groupby("pattern_type"):
        print(f"  {pat:<22} n={len(grp):3d}  mean_score={grp['score'].mean():.3f}")

    # Generate JSON predictions
    predictor = LSTMAEPredictor(
        model           = model,
        preprocessor    = seq_prep,
        score_normaliser= score_norm,
        threshold       = threshold,
        device          = device,
    )
    batch_out = predictor.predict_cohort(test_df)
    pred_path = out_dir / "predictions_partB.json"
    pred_path.write_text(batch_out.model_dump_json(indent=2), encoding="utf-8")
    print(f"\nPredictions saved -> {pred_path}")
    print(f"Anomaly rate: {batch_out.anomaly_rate:.1%}")

    return metrics_ae


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    args     = parse_args()
    out_dir  = Path(args.out)
    data_dir = Path(args.data_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    summary = {}

    if args.part in ("A", "both"):
        metrics_a = run_part_a(data_dir, out_dir)
        summary["part_A"] = metrics_a

    if args.part in ("B", "both"):
        try:
            metrics_b = run_part_b(data_dir, out_dir, args.epochs, args.batch, device)
            summary["part_B"] = metrics_b
        except NotImplementedError as e:
            print(f"\n[Part B] Skipped — not yet implemented: {e}")

    print(f"\nAll outputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()
