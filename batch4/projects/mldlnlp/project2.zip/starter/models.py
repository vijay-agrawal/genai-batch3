"""
Anomaly Detection Models
========================
Five complementary approaches, each with distinct strengths and trade-offs:

  PART A – Static / tabular (rare disease)
  ─────────────────────────────────────────
  Model 1 – PCADetector
    Trains PCA on healthy patients → uses reconstruction error as anomaly score.
    Interpretable (loadings), fast, linear only.

  Model 2 – OneClassSVMDetector
    Learns a tight hypersphere around normal data (kernel-based).
    Good theoretical grounding, tuning-sensitive, O(n²) memory.

  Model 3 – IsolationForestDetector
    Ensemble of random trees that isolate anomalies faster.
    Scalable, handles high-dim data, not easily interpretable.

  Model 4 – DBSCANDetector
    Density-based: points with no dense neighbourhood = anomalies.
    No training phase; sensitive to eps/min_samples; breaks in high dims.

  PART B – Sequential (ICU monitoring)
  ─────────────────────────────────────
  Model 5 – LSTMAutoencoder
    Stacked seq-to-seq BiLSTM that reconstructs normal vital-sign sequences.
    Reconstruction error = anomaly score. Captures temporal patterns that
    classical models cannot.

PROS / CONS CHEATSHEET (students: verify empirically!)
  ┌───────────────────┬──────────────┬──────────────┬───────────────┬─────────────┐
  │                   │ Interpretable│ Scalable     │ Non-linear    │ Temporal    │
  ├───────────────────┼──────────────┼──────────────┼───────────────┼─────────────┤
  │ PCA               │ ✓ (loadings) │ ✓✓           │ ✗             │ ✗           │
  │ One-Class SVM     │ ✗            │ ✗ (O(n²))    │ ✓ (kernel)    │ ✗           │
  │ Isolation Forest  │ partial SHAP │ ✓✓           │ ✓             │ ✗           │
  │ DBSCAN            │ partial      │ ✗ (high dim) │ ✓             │ ✗           │
  │ LSTM Autoencoder  │ recon. error │ ✓ (GPU)      │ ✓✓            │ ✓✓          │
  └───────────────────┴──────────────┴──────────────┴───────────────┴─────────────┘

TODOs:
  Task 3 – Implement PCADetector.anomaly_score()
  Task 4 – Implement LSTMAutoencoder.forward()
  Task 5 – Implement LSTMAutoencoder.reconstruction_error()
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import torch
import torch.nn as nn
from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import MinMaxScaler
from sklearn.svm import OneClassSVM


# ============================================================
# PART A – Static anomaly detectors
# ============================================================

class PCADetector:
    """
    PCA-based anomaly detection.

    Training: fit PCA on healthy patients, keep top-k components.
    Scoring : project a sample into PCA space, reconstruct it,
              compute squared reconstruction error (residual).

    The intuition: healthy patients live on a low-dimensional subspace
    (captured by the principal components).  Anomalous patients have
    features that do not lie on this subspace → high residual.

    This approach is:
      + Highly interpretable (eigenvector loadings show which features matter)
      + Fast to train and score
      + Works well when anomalies differ *linearly* from the healthy distribution
      - Misses non-linear anomaly patterns (e.g., abnormal correlations that are
        individually in-range but jointly abnormal)

    Why PCA can detect the multivariate anomalies in our dataset:
      Even when individual feature values are within range, if their correlation
      structure deviates from the healthy covariance matrix, the projection onto
      the healthy subspace leaves a large residual.
    """

    def __init__(self, n_components: int = 8):
        self.n_components = n_components
        self.pca:       Optional[PCA]         = None
        self.normaliser: Optional[MinMaxScaler] = None
        self._fitted = False

    def fit(self, X: np.ndarray) -> "PCADetector":
        """Fit PCA on healthy training features."""
        self.pca = PCA(n_components=self.n_components, random_state=42)
        self.pca.fit(X)
        # Fit a score normaliser on training residuals so output is in [0, 1]
        train_scores = self._raw_score(X)
        self.normaliser = MinMaxScaler()
        self.normaliser.fit(train_scores.reshape(-1, 1))
        self._fitted = True
        explained = self.pca.explained_variance_ratio_.cumsum()[-1]
        print(
            f"[PCADetector] {self.n_components} components explain "
            f"{explained*100:.1f}% of healthy variance."
        )
        return self

    def anomaly_score(self, X: np.ndarray) -> np.ndarray:
        """
        Return normalised anomaly scores in [0, 1].
        Higher score → more anomalous.

        TODO (Student Task 3):
        Remove the `raise` and implement this method.

        Steps:
          1. Project X into PCA space:       Z = X @ self.pca.components_.T
             (or use self.pca.transform(X))
          2. Reconstruct:                    X_hat = Z @ self.pca.components_
             (or use self.pca.inverse_transform(Z))
          3. Per-sample squared residual:    errors = ((X - X_hat) ** 2).mean(axis=1)
          4. Normalise to [0, 1] using self.normaliser.transform().
             Clip at 1.0 for test samples with errors above the training max.

        Expected shape: (N,) float array.
        """
        raise NotImplementedError(
            "Implement PCADetector.anomaly_score() – see docstring for step-by-step guide."
        )

    def _raw_score(self, X: np.ndarray) -> np.ndarray:
        """Unnormalised reconstruction error (MSE per sample)."""
        X_hat = self.pca.inverse_transform(self.pca.transform(X))
        return ((X - X_hat) ** 2).mean(axis=1)

    def feature_contributions(self, x: np.ndarray) -> np.ndarray:
        """
        Per-feature squared residual for a single sample x (shape: n_features).
        Used to populate FeatureContribution in the output schema.
        """
        if not self._fitted:
            raise RuntimeError("Call fit() first.")
        x_hat = self.pca.inverse_transform(self.pca.transform(x.reshape(1, -1)))
        return ((x - x_hat.flatten()) ** 2)

    def predict(self, X: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        """Returns 1 (anomaly) or 0 (normal) for each sample."""
        return (self.anomaly_score(X) >= threshold).astype(int)


# ---------------------------------------------------------------------------

class OneClassSVMDetector:
    """
    One-Class SVM anomaly detector.

    Learns a tight kernel-based boundary around the healthy distribution.
    Points outside the boundary are anomalies.

    Strengths:
      + Theoretically well-founded (structural risk minimisation)
      + Captures non-linear boundaries via the RBF kernel
      + nu parameter directly controls the expected anomaly fraction

    Weaknesses:
      - O(n²) memory and O(n³) training: impractical for > ~10 000 samples
      - Very sensitive to nu and gamma: requires careful hyperparameter search
      - Decision function is not a probability; threshold is arbitrary
      - Does not scale to high-dimensional inputs without prior PCA

    Recommended usage: apply after PCA reduction (50–80% variance retained).
    """

    def __init__(self, nu: float = 0.05, kernel: str = "rbf", gamma: str = "scale"):
        """
        Parameters
        ----------
        nu : upper bound on the fraction of training errors and support vectors.
             Set to your expected anomaly contamination rate.
             Typical range: 0.01 – 0.20.
        """
        self.model = OneClassSVM(nu=nu, kernel=kernel, gamma=gamma)
        self.normaliser = MinMaxScaler()

    def fit(self, X: np.ndarray) -> "OneClassSVMDetector":
        self.model.fit(X)
        # decision_function: negative = anomaly, positive = normal
        scores = -self.model.decision_function(X)          # flip: higher = more anomalous
        self.normaliser.fit(scores.reshape(-1, 1))
        print(f"[OneClassSVMDetector] fitted on {X.shape[0]} samples.")
        return self

    def anomaly_score(self, X: np.ndarray) -> np.ndarray:
        raw = -self.model.decision_function(X)
        return np.clip(self.normaliser.transform(raw.reshape(-1, 1)).flatten(), 0, 1)

    def predict(self, X: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        return (self.anomaly_score(X) >= threshold).astype(int)


# ---------------------------------------------------------------------------

class IsolationForestDetector:
    """
    Isolation Forest anomaly detector.

    Key idea: anomalies are *rare* and *different* — they are isolated by
    random splits much faster than normal points.  Anomaly score is inversely
    proportional to the average tree path length.

    Strengths:
      + O(n log n) training — scales to large datasets
      + Handles high-dimensional data well
      + No distance metric needed; robust to different feature scales
      + contamination parameter has an intuitive meaning

    Weaknesses:
      - Feature importances require SHAP (not built-in)
      - Masking effect: multiple anomalies can hide each other
      - Not ideal for anomalies that form dense clusters (DBSCAN handles better)

    Comparison with OC-SVM:
      Isolation Forest is almost always preferred for large n (> 5 000).
      OC-SVM is preferred when the healthy boundary is known to be smooth and
      the dataset is small enough for exact kernel computation.
    """

    def __init__(self, contamination: float = 0.09, n_estimators: int = 200):
        """
        contamination : expected fraction of anomalies in training data.
                        Use your known class-imbalance ratio.
        """
        self.model = IsolationForest(
            contamination = contamination,
            n_estimators  = n_estimators,
            random_state  = 42,
            n_jobs        = -1,
        )
        self.normaliser = MinMaxScaler()

    def fit(self, X: np.ndarray) -> "IsolationForestDetector":
        self.model.fit(X)
        scores = -self.model.score_samples(X)   # higher = more anomalous
        self.normaliser.fit(scores.reshape(-1, 1))
        print(f"[IsolationForestDetector] fitted on {X.shape[0]} samples.")
        return self

    def anomaly_score(self, X: np.ndarray) -> np.ndarray:
        raw = -self.model.score_samples(X)
        return np.clip(self.normaliser.transform(raw.reshape(-1, 1)).flatten(), 0, 1)

    def predict(self, X: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        return (self.anomaly_score(X) >= threshold).astype(int)


# ---------------------------------------------------------------------------

class DBSCANDetector:
    """
    DBSCAN-based anomaly detection (no training phase).

    Points that cannot be assigned to any dense cluster (label = -1) are
    treated as anomalies.

    Strengths:
      + Finds arbitrarily shaped clusters
      + No training phase: works purely on test-time density
      + No fixed assumption about the number of anomalies

    Weaknesses:
      - eps and min_samples require manual tuning (often domain-specific)
      - CRITICAL: breaks down in high dimensions (distance concentration)
        → MUST apply PCA first (see dimensionality_reduction_first warning)
      - Treats ALL outliers the same — does not rank anomalies by severity
      - Not suitable for streaming / online detection

    Practical note:
      DBSCAN is most useful as a SECOND PASS — first remove obvious anomalies
      with Isolation Forest, then use DBSCAN on the PCA-reduced residuals to
      identify structured anomaly clusters (e.g., "all sepsis cases form one cluster").

    TODO (Student Task 6a — bonus):
      Run DBSCAN on the PCA-2D projection and plot the clusters.
      Do rare disease subtypes form distinct clusters in the anomaly set?
    """

    def __init__(self, eps: float = 0.5, min_samples: int = 10):
        """
        eps        : neighbourhood radius (in scaled feature space).
                     Start with the elbow of a k-distance plot.
        min_samples: minimum cluster size. Rule of thumb: 2 × n_features.
        """
        from sklearn.cluster import DBSCAN
        self.model = DBSCAN(eps=eps, min_samples=min_samples, n_jobs=-1)
        self._labels: Optional[np.ndarray] = None

    def fit_predict_anomaly_score(self, X: np.ndarray) -> np.ndarray:
        """
        Run DBSCAN on X and return binary anomaly labels (1 = anomaly).
        Note: DBSCAN has no separate fit/predict — it runs on the provided X.

        Returns an anomaly_score of 1.0 for noise points, 0.0 for cluster members.
        (DBSCAN does not produce continuous scores — this is a known limitation.)
        """
        self._labels = self.model.fit_predict(X)
        return (self._labels == -1).astype(float)

    @staticmethod
    def plot_k_distance(X: np.ndarray, k: int = 5) -> None:
        """
        Plot the k-distance graph to help choose eps.
        The 'elbow' of the curve is a good starting point for eps.
        """
        from sklearn.neighbors import NearestNeighbors
        import matplotlib.pyplot as plt

        nbrs = NearestNeighbors(n_neighbors=k).fit(X)
        distances, _ = nbrs.kneighbors(X)
        distances = np.sort(distances[:, k - 1])

        plt.figure(figsize=(8, 4))
        plt.plot(distances)
        plt.xlabel("Points sorted by distance")
        plt.ylabel(f"{k}-NN distance")
        plt.title("K-distance graph — choose eps at the elbow")
        plt.tight_layout()
        plt.show()


# ============================================================
# PART B – LSTM Autoencoder
# ============================================================

class LSTMAutoencoder(nn.Module):
    """
    Deep stacked seq-to-seq LSTM autoencoder for ICU vital sign monitoring.

    Architecture:
    ─────────────
      Input:  (batch, seq_len, n_features)

      Encoder (compresses the sequence to a fixed bottleneck vector):
        BiLSTM layer 1: hidden_dim       → (B, T, 2*H)
        BiLSTM layer 2: hidden_dim // 2  → (B, T, H)   [stacked, narrows]
        Take the final time-step hidden state as the bottleneck: (B, H)

      Decoder (reconstructs the full sequence from the bottleneck):
        Repeat bottleneck T times: (B, T, H)
        LSTM layer 1:  hidden_dim // 2   → (B, T, H)
        LSTM layer 2:  hidden_dim        → (B, T, 2*H)
        Linear projection:               → (B, T, n_features)

    Training:
      - Optimise MSE( input_sequence, reconstruction ) on NORMAL sequences ONLY.
      - At inference: compute per-sequence mean MSE → anomaly score.
      - Normal sequences are well-reconstructed (low MSE).
      - Abnormal sequences cannot be reconstructed accurately (high MSE).

    Why does this outperform classical methods on ICU data?
      The encoder captures the *temporal dependencies* in vital signs —
      e.g., that a rising HR is normal during a fever taper but abnormal if
      BP is simultaneously dropping.  Classical methods see each timestep
      independently and miss these cross-time correlations.

    TODO (Student Task 4):
      Implement the forward() method.
      Expected shapes are annotated in the docstring below.

    TODO (Student Task 5):
      Implement reconstruction_error() — it will be the core anomaly score.
    """

    def __init__(
        self,
        n_features:  int,
        hidden_dim:  int   = 64,
        seq_len:     int   = 24,
        dropout:     float = 0.2,
    ):
        super().__init__()
        self.seq_len    = seq_len
        self.hidden_dim = hidden_dim

        # Encoder (bidirectional stacked LSTM)
        self.encoder_lstm1 = nn.LSTM(
            n_features,    hidden_dim,     num_layers=1,
            batch_first=True, bidirectional=True, dropout=0.0
        )
        self.encoder_lstm2 = nn.LSTM(
            hidden_dim * 2, hidden_dim // 2, num_layers=1,
            batch_first=True, bidirectional=True, dropout=0.0
        )
        # Bottleneck projection: from 2*(H/2)=H → H
        self.bottleneck = nn.Linear(hidden_dim, hidden_dim)

        # Decoder (unidirectional — reconstructing forward in time)
        self.decoder_lstm1 = nn.LSTM(
            hidden_dim, hidden_dim,     num_layers=1, batch_first=True
        )
        self.decoder_lstm2 = nn.LSTM(
            hidden_dim, hidden_dim * 2, num_layers=1, batch_first=True
        )
        self.output_proj = nn.Linear(hidden_dim * 2, n_features)
        self.dropout     = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Full autoencoder forward pass.

        Args:
            x : (B, T, F) — normalised vital sign sequences

        Returns:
            x_hat : (B, T, F) — reconstructed sequences

        TODO (Student Task 4):
        Remove the raise and implement as described below.

        Template:

          # --- ENCODER ---
          # Pass x through encoder_lstm1 → out1: (B, T, 2*H)
          # Apply dropout to out1
          # Pass out1 through encoder_lstm2 → out2: (B, T, H)
          #   where H = hidden_dim // 2 × 2 (bidirectional)
          # Take the LAST TIME STEP of out2 as the bottleneck context vector:
          #   ctx = out2[:, -1, :]         shape: (B, H)
          # Project: ctx = self.bottleneck(ctx) + optional activation
          #   ctx shape: (B, H)

          # --- DECODER ---
          # Repeat ctx across time: dec_input = ctx.unsqueeze(1).repeat(1, T, 1)
          #   shape: (B, T, H)
          # Apply dropout to dec_input
          # Pass through decoder_lstm1 → dec1: (B, T, H)
          # Pass through decoder_lstm2 → dec2: (B, T, 2*H)
          # Project to features: x_hat = self.output_proj(dec2)
          #   shape: (B, T, F)

          return x_hat
        """
        raise NotImplementedError(
            "Implement LSTMAutoencoder.forward() — see the docstring above."
        )

    @torch.no_grad()
    def reconstruction_error(
        self,
        x: torch.Tensor,          # (B, T, F)
        per_feature: bool = False,
    ) -> np.ndarray:
        """
        Compute the per-sample reconstruction error (MSE).

        Returns
        -------
        If per_feature=False : (B,) array of mean MSE per sequence
        If per_feature=True  : (B, F) array of per-feature mean MSE
                               (used to populate FeatureContribution in output)

        TODO (Student Task 5):
        Remove the raise and implement.

        Steps:
          self.eval()
          x_hat = self.forward(x)                      # (B, T, F)
          err   = (x - x_hat) ** 2                     # (B, T, F)
          if per_feature:
              return err.mean(dim=1).cpu().numpy()     # (B, F)
          else:
              return err.mean(dim=(1, 2)).cpu().numpy()# (B,)

        The returned values are RAW MSE (not normalised).
        Normalisation to [0, 1] is done in predict.py using the
        training distribution of reconstruction errors (analogous to
        how PCADetector uses a MinMaxScaler on its residuals).
        """
        raise NotImplementedError(
            "Implement LSTMAutoencoder.reconstruction_error() — see docstring."
        )


# ============================================================
# Factory
# ============================================================

STATIC_MODELS = {
    "pca":            PCADetector,
    "ocsvm":          OneClassSVMDetector,
    "isolation_forest": IsolationForestDetector,
    "dbscan":         DBSCANDetector,
}

SEQUENTIAL_MODELS = {
    "lstm_autoencoder": LSTMAutoencoder,
}


# ============================================================
# Shape / smoke test
# ============================================================

if __name__ == "__main__":
    print("Static model smoke test (PCA, IF, OC-SVM):")
    np.random.seed(0)
    X_train = np.random.randn(200, 20).astype(np.float32)
    X_test  = np.random.randn(50,  20).astype(np.float32)
    X_test[0] += 5   # inject obvious anomaly

    for name, cls in [("pca", PCADetector), ("isolation_forest", IsolationForestDetector),
                      ("ocsvm", OneClassSVMDetector)]:
        m = cls()
        m.fit(X_train)
        try:
            scores = m.anomaly_score(X_test)
            print(f"  {name:<20} score shape: {scores.shape}  "
                  f"injected anomaly score: {scores[0]:.3f}")
        except NotImplementedError:
            print(f"  {name:<20} (forward not yet implemented)")

    print("\nLSTM AE shape test:")
    B, T, F = 4, 24, 6
    model = LSTMAutoencoder(n_features=F, hidden_dim=32, seq_len=T)
    x = torch.randn(B, T, F)
    try:
        out = model(x)
        assert out.shape == (B, T, F), f"Expected {(B,T,F)}, got {out.shape}"
        print(f"  Output shape: {out.shape}  OK")
    except NotImplementedError:
        print("  forward() not yet implemented — implement Task 4.")
