"""
Feature Engineering & Preprocessing
=====================================
Handles both modalities used in this project:

  Part A – Static patient records (structured vitals/labs + clinical notes)
    Steps: outlier clipping, robust scaling, log-transform right-skewed labs,
           TF-IDF embedding of clinical notes, feature fusion.

  Part B – ICU time-series (sequential vitals, 24h × 6 features)
    Steps: per-patient z-score normalisation, sliding-window creation,
           padding/truncation, optional per-feature delta (rate-of-change).

KEY DESIGN QUESTION:
  Should you scale using statistics from ALL patients or only HEALTHY patients?
  Answer: use ONLY the training (healthy) split — any leakage of anomaly
  statistics into the scaler will make anomalies look less anomalous.

TODOs are marked with TODO (Task N) and describe the expected implementation.

Usage:
    from preprocess import StaticPreprocessor, SequencePreprocessor
"""

from __future__ import annotations

import re
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import RobustScaler


# ---------------------------------------------------------------------------
# Part A – Static Preprocessor
# ---------------------------------------------------------------------------

# Features present in rare_disease_patients.csv
STRUCTURED_FEATURES = [
    "age", "hr", "sbp", "dbp", "spo2", "rr", "temp",
    "wbc", "hgb", "glucose", "lactate", "crp", "troponin",
]

# These are right-skewed: log-transform reduces the effect of extreme values
# and makes PCA / distance metrics better behaved.
LOG_TRANSFORM_FEATURES = ["wbc", "lactate", "crp", "troponin"]

# Physiological hard limits – values outside these are instrument artefacts
CLIP_LIMITS = {
    "hr":       (20,  250),
    "sbp":      (50,  280),
    "dbp":      (20,  180),
    "spo2":     (60,  100),
    "rr":       (4,    80),
    "temp":     (94,  110),
    "wbc":      (0.1,  80),
    "hgb":      (2,    25),
    "glucose":  (20,  700),
    "lactate":  (0.1,  20),
    "crp":      (0.1, 300),
    "troponin": (0.001, 10),
    "age":      (0,   120),
}


class StaticPreprocessor:
    """
    Fit on healthy training patients, transform any split.

    Pipeline:
      1. Clip physiological outliers
      2. Log-transform right-skewed lab values
      3. RobustScaler (median + IQR — robust to extreme anomalies)
      4. TF-IDF on clinical notes  (n_components=50 by default)
      5. Concatenate scaled structured + TF-IDF vectors

    TODO (Student Task 1a):
      After fitting, examine self.scaler.center_ and self.scaler.scale_.
      Add 3–4 interaction features (e.g. shock_index = hr/sbp,
      lactate_glucose_ratio = lactate/glucose) that are known clinical markers.
      Compare AUROC with and without these features and report findings.

    TODO (Student Task 1b):
      Replace TF-IDF with sentence-transformer embeddings (384-d).
      Does richer text representation improve anomaly detection?
      Hint: use SentenceTransformer('all-MiniLM-L6-v2').encode(notes).
    """

    def __init__(self, tfidf_max_features: int = 100):
        self.tfidf_max_features = tfidf_max_features
        self.scaler: Optional[RobustScaler]      = None
        self.tfidf:  Optional[TfidfVectorizer]   = None
        self._fitted = False

    def fit(self, df: pd.DataFrame) -> "StaticPreprocessor":
        """
        Fit scaler and TF-IDF on the provided DataFrame.
        MUST be called only with healthy (normal) training patients.
        """
        X_struct = self._engineer_and_clip(df)
        self.scaler = RobustScaler()
        self.scaler.fit(X_struct)

        notes = df["clinical_note"].fillna("").tolist()
        self.tfidf = TfidfVectorizer(
            max_features = self.tfidf_max_features,
            ngram_range  = (1, 2),
            min_df       = 2,
            sublinear_tf = True,
        )
        self.tfidf.fit(notes)
        self._fitted = True
        print(
            f"[StaticPreprocessor] fitted on {len(df)} samples. "
            f"Structured dim: {X_struct.shape[1]}, "
            f"TF-IDF vocab: {len(self.tfidf.vocabulary_)}"
        )
        return self

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        """
        Returns fused feature matrix of shape (N, n_structured + n_tfidf).
        """
        if not self._fitted:
            raise RuntimeError("Call fit() first.")
        X_struct = self._engineer_and_clip(df)
        X_scaled = self.scaler.transform(X_struct)
        notes    = df["clinical_note"].fillna("").tolist()
        X_text   = self.tfidf.transform(notes).toarray()
        return np.hstack([X_scaled, X_text])

    def fit_transform(self, df: pd.DataFrame) -> np.ndarray:
        return self.fit(df).transform(df)

    # ------------------------------------------------------------------

    def _engineer_and_clip(self, df: pd.DataFrame) -> np.ndarray:
        """Clip, log-transform, add interaction features, return np.ndarray."""
        d = df.copy()

        # 1. Clip to physiological limits
        for feat, (lo, hi) in CLIP_LIMITS.items():
            if feat in d.columns:
                d[feat] = d[feat].clip(lo, hi)

        # 2. Log-transform skewed features
        for feat in LOG_TRANSFORM_FEATURES:
            if feat in d.columns:
                d[feat] = np.log1p(d[feat])

        # 3. Base features
        cols = [f for f in STRUCTURED_FEATURES if f in d.columns]
        X    = d[cols].values.astype(np.float32)

        # 4. TODO (Student Task 1a): Add interaction features here.
        #    Example (do NOT leave commented out — implement and test):
        #
        #    shock_index = hr / sbp  (> 1.0 suggests haemodynamic compromise)
        #    lactate_glucose_ratio   (elevated in mitochondrial disorders)
        #    pulse_pressure = sbp - dbp  (widened in sepsis / aortic regurgitation)
        #    MAP = (sbp + 2*dbp) / 3    (mean arterial pressure, used in ICU protocols)
        #
        #    Append these as extra columns to X and return.

        return X

    @property
    def feature_names(self) -> list[str]:
        """Names matching the columns of the transformed matrix (for explanation)."""
        base = [f for f in STRUCTURED_FEATURES if f in CLIP_LIMITS]
        # TODO: extend with interaction feature names you add in Task 1a
        tfidf_names = [f"tfidf_{t}" for t in (
            self.tfidf.get_feature_names_out() if self._fitted else []
        )]
        return base + tfidf_names


# ---------------------------------------------------------------------------
# Part B – Sequence Preprocessor
# ---------------------------------------------------------------------------

ICU_FEATURES = ["hr", "sbp", "dbp", "spo2", "rr", "temp"]
SEQ_LEN      = 24   # hours


class SequencePreprocessor:
    """
    Transforms the long-format ICU DataFrame into 3-D tensors for the LSTM AE.

    Normalisation strategy:
      Population-level: fit mean/std only on NORMAL training stays, then apply
      to all stays.  This is correct for anomaly detection — we want normal
      vitals to have ~zero residual; anomalies will have large residuals.

    Shapes:
      fit()/transform() return (N, SEQ_LEN, n_features) numpy arrays.

    TODO (Student Task 2):
      Add a delta (rate-of-change) channel for each feature:
          delta[t] = x[t] - x[t-1]    (0 for t=0)
      This doubles the feature dimension but makes the LSTM AE sensitive to
      sudden *changes* as well as absolute values — crucial for detecting
      sudden deterioration onset.
      Compare AUROC with and without delta features.
    """

    def __init__(self):
        self._mean: Optional[np.ndarray] = None
        self._std:  Optional[np.ndarray] = None
        self._fitted = False

    def fit(self, normal_df: pd.DataFrame) -> "SequencePreprocessor":
        """
        Compute population mean/std from NORMAL ICU stays only.

        Parameters
        ----------
        normal_df: long-format DataFrame filtered to label==0 stays.
        """
        vals = normal_df[ICU_FEATURES].values.astype(np.float32)
        self._mean = vals.mean(axis=0)
        self._std  = vals.std(axis=0) + 1e-6
        self._fitted = True
        print(
            f"[SequencePreprocessor] fitted on {normal_df['patient_id'].nunique()} "
            f"normal stays."
        )
        return self

    def transform(self, df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        """
        Convert long-format DataFrame to (X, y) arrays.

        Returns
        -------
        X : (N, SEQ_LEN, n_features)  – normalised sequences
        y : (N,)  – 0 = normal, 1 = anomaly (from label column)
        """
        if not self._fitted:
            raise RuntimeError("Call fit() first.")

        patient_ids = df["patient_id"].unique()
        X_list, y_list = [], []

        for pid in patient_ids:
            stay = df[df["patient_id"] == pid].sort_values("hour")
            # Take first SEQ_LEN hours; pad with mean if shorter
            vals = stay[ICU_FEATURES].values.astype(np.float32)
            if len(vals) < SEQ_LEN:
                pad  = np.tile(self._mean, (SEQ_LEN - len(vals), 1))
                vals = np.vstack([vals, pad])
            vals = vals[:SEQ_LEN]

            # Normalise
            vals = (vals - self._mean) / self._std

            # TODO (Student Task 2): Compute and concatenate delta features here.

            X_list.append(vals)
            y_list.append(int(stay["label"].iloc[0]))

        return np.stack(X_list, axis=0), np.array(y_list)

    def fit_transform(
        self, normal_df: pd.DataFrame, all_df: pd.DataFrame
    ) -> tuple[np.ndarray, np.ndarray]:
        """Fit on normal_df then transform all_df."""
        return self.fit(normal_df).transform(all_df)

    @property
    def n_features(self) -> int:
        return len(ICU_FEATURES)   # TODO: update if delta features added


# ---------------------------------------------------------------------------
# Clinical flag extraction (hard-threshold safety warnings)
# ---------------------------------------------------------------------------

def extract_clinical_flags_static(row: pd.Series) -> list[str]:
    """
    Return a list of critical-threshold violations for a static patient record.
    These are surfaced in the output regardless of the model's anomaly verdict.
    """
    flags = []
    checks = [
        ("spo2",     row.get("spo2",    100), lambda v: v < 90,   "SpO2 < 90%"),
        ("sbp",      row.get("sbp",     120), lambda v: v < 90,   "Hypotension (SBP < 90)"),
        ("hr",       row.get("hr",       70), lambda v: v > 130,  "HR > 130"),
        ("rr",       row.get("rr",       16), lambda v: v > 30,   "RR > 30"),
        ("lactate",  row.get("lactate",  1.2), lambda v: v > 2.0, "Lactate > 2.0 mmol/L"),
        ("temp",     row.get("temp",    98.6), lambda v: v > 101.5,"Fever > 101.5 F"),
        ("troponin", row.get("troponin", 0.02), lambda v: v > 0.04,"Troponin elevation"),
    ]
    for feat, val, condition, label in checks:
        if pd.notna(val) and condition(val):
            flags.append(f"{label} (value: {val:.2f})")
    return flags


def extract_clinical_flags_icu(sequence_df: pd.DataFrame) -> list[str]:
    """
    Return critical-threshold violations found at any hour during an ICU stay.
    sequence_df: subset of icu_vitals.csv for one patient, multiple hours.
    """
    flags = []
    for col, threshold, direction, label in [
        ("spo2", 90,  "below", "SpO2 < 90%"),
        ("sbp",  90,  "below", "SBP < 90"),
        ("hr",   130, "above", "HR > 130"),
        ("rr",   30,  "above", "RR > 30"),
        ("temp", 101.5, "above", "Fever > 101.5 F"),
    ]:
        if col not in sequence_df.columns:
            continue
        if direction == "below":
            bad = sequence_df[sequence_df[col] < threshold]
        else:
            bad = sequence_df[sequence_df[col] > threshold]
        if not bad.empty:
            hour = bad["hour"].min()
            val  = bad[col].iloc[0]
            flags.append(f"{label} at hour {hour} (value: {val:.1f})")
    return flags


# ---------------------------------------------------------------------------
# Quick demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from pathlib import Path
    DATA = Path(__file__).parent.parent / "data"

    static_path = DATA / "rare_disease_patients.csv"
    icu_path    = DATA / "icu_vitals.csv"

    if not static_path.exists():
        print("Run: python data/generate_dataset.py")
    else:
        df   = pd.read_csv(static_path)
        prep = StaticPreprocessor(tfidf_max_features=50)
        normal = df[df["label"] == 0].head(200)
        X = prep.fit(normal).transform(df.head(10))
        print(f"Static feature matrix shape: {X.shape}")

    if not icu_path.exists():
        print("ICU dataset not found.")
    else:
        icu = pd.read_csv(icu_path)
        normal_icu = icu[icu["label"] == 0]
        seq_prep = SequencePreprocessor()
        X_seq, y_seq = seq_prep.fit_transform(normal_icu, icu)
        print(f"ICU sequence tensor shape:  {X_seq.shape}  labels: {y_seq.shape}")
