"""
Training Utilities
==================
Two training workflows:

  train_static_detectors()   – fit PCA / OC-SVM / Isolation Forest on healthy
                               patient feature vectors (Part A)

  train_lstm_autoencoder()   – train the LSTM AE on normal ICU sequences (Part B)

CRITICAL PRINCIPLE – one-class training:
  All models in this project are trained ONLY on normal/healthy data.
  If anomalies leak into training, the models will learn to reconstruct them
  too, destroying their anomaly detection capability.

  The `train_lstm_autoencoder()` function asserts that the supplied DataLoader
  only contains label=0 samples.  Never disable this check.

TODO (Student Task 7):
  Implement `_train_one_epoch()` inside TrainerLSTMAE.
  The training loop is identical in structure to Project 1 but with MSE loss
  instead of cross-entropy, and no label is used (unsupervised reconstruction).
"""

from __future__ import annotations

import copy
import time
from pathlib import Path
from typing import Optional

import numpy as np
import torch
import torch.nn as nn
from torch.optim import Adam
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm

from models import (
    DBSCANDetector,
    IsolationForestDetector,
    LSTMAutoencoder,
    OneClassSVMDetector,
    PCADetector,
)


# ============================================================
# Part A – Classical detectors
# ============================================================

def train_static_detectors(
    X_train_healthy: np.ndarray,
    n_components_pca: int   = 8,
    nu_ocsvm:         float = 0.05,
    contamination_if: float = 0.09,
    fit_dbscan:       bool  = False,
    eps_dbscan:       float = 0.5,
) -> dict:
    """
    Fit all classical anomaly detectors on the healthy training set.

    Parameters
    ----------
    X_train_healthy : feature matrix for HEALTHY patients only (shape: N, D)
    fit_dbscan      : DBSCAN has no separate fit — set True to build the object;
                      anomaly scores are computed at predict time.

    Returns
    -------
    dict : { "pca": PCADetector, "ocsvm": OC-SVM, "isolation_forest": IF,
             "dbscan": DBSCANDetector (optional) }

    Notes for students
    ------------------
    * OC-SVM is slow: reduce X to ~50 components via PCA before passing it in
      if the dataset is large.
    * contamination_if should match the known anomaly fraction in your dataset.
      Try values of 0.05, 0.09, 0.15 and observe the effect on precision/recall.
    * For DBSCAN, use DBSCANDetector.plot_k_distance(X_test_reduced) to choose eps.
    """
    print("Training static anomaly detectors ...")
    models = {}

    print("  [1/3] PCA Detector")
    models["pca"] = PCADetector(n_components=n_components_pca).fit(X_train_healthy)

    print("  [2/3] Isolation Forest")
    models["isolation_forest"] = IsolationForestDetector(
        contamination=contamination_if
    ).fit(X_train_healthy)

    print("  [3/3] One-Class SVM  (may be slow for large datasets)")
    models["ocsvm"] = OneClassSVMDetector(nu=nu_ocsvm).fit(X_train_healthy)

    if fit_dbscan:
        print("  [+]   DBSCAN (no training; object created for predict time)")
        models["dbscan"] = DBSCANDetector(eps=eps_dbscan)

    print("Done.\n")
    return models


# ============================================================
# Part B – LSTM Autoencoder
# ============================================================

def make_normal_dataloader(
    X_normal: np.ndarray,    # (N, T, F) — only normal sequences
    batch_size: int = 32,
    shuffle: bool   = True,
) -> DataLoader:
    """
    Create a DataLoader from a numpy array of normal ICU sequences.

    NOTE: The DataLoader contains NO labels — the target is the input itself
    (reconstruction loss).  This is intentional for autoencoders.
    """
    tensor = torch.tensor(X_normal, dtype=torch.float32)
    return DataLoader(TensorDataset(tensor), batch_size=batch_size, shuffle=shuffle)


class TrainerLSTMAE:
    """
    Trains the LSTM Autoencoder on normal ICU sequences.

    Early stopping monitors validation reconstruction loss.
    The best model (lowest val_loss) is checkpointed and restored at the end.

    Key hyperparameters to explore:
      hidden_dim : 32 vs 64 vs 128 — affects bottleneck expressiveness
      dropout    : 0.1 – 0.3 — regularisation; prevents overfit on small datasets
      lr         : 1e-3 with ReduceLROnPlateau typically works well
    """

    def __init__(
        self,
        model:      LSTMAutoencoder,
        train_loader: DataLoader,
        val_loader:   DataLoader,
        lr:           float     = 1e-3,
        device:       str       = "cpu",
        checkpoint_dir: str | Path = "checkpoints",
    ):
        self.device        = device
        self.model         = model.to(device)
        self.train_loader  = train_loader
        self.val_loader    = val_loader
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        self.criterion = nn.MSELoss()
        self.optimiser = Adam(model.parameters(), lr=lr, weight_decay=1e-5)
        self.scheduler = ReduceLROnPlateau(
            self.optimiser, mode="min", factor=0.5, patience=4, verbose=True
        )
        self.history: list[dict] = []
        self._best_loss  = float("inf")
        self._best_state = None

    # ------------------------------------------------------------------

    def _train_one_epoch(self) -> float:
        """
        Run one full pass over the training DataLoader.

        Returns
        -------
        avg_loss : float — mean MSE over all batches

        TODO (Student Task 7):
        Remove the raise and implement.

        Template:
            self.model.train()
            total_loss, total_samples = 0.0, 0

            for (x_batch,) in tqdm(self.train_loader, desc="  train", leave=False):
                x_batch = x_batch.to(self.device)

                self.optimiser.zero_grad()
                x_hat = self.model(x_batch)            # (B, T, F)
                loss  = self.criterion(x_hat, x_batch) # MSE vs. INPUT (no labels!)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=5.0)
                self.optimiser.step()

                total_loss    += loss.item() * len(x_batch)
                total_samples += len(x_batch)

            return total_loss / total_samples

        Note: the target is x_batch itself (self-supervised reconstruction).
        """
        raise NotImplementedError(
            "Implement _train_one_epoch() — see the docstring template above."
        )

    @torch.no_grad()
    def _validate(self) -> float:
        self.model.eval()
        total_loss, total = 0.0, 0
        for (x_batch,) in self.val_loader:
            x_batch = x_batch.to(self.device)
            x_hat   = self.model(x_batch)
            loss    = self.criterion(x_hat, x_batch)
            total_loss += loss.item() * len(x_batch)
            total      += len(x_batch)
        return total_loss / total

    def fit(self, epochs: int = 50, early_stop_patience: int = 8) -> list[dict]:
        no_improve = 0

        for epoch in range(1, epochs + 1):
            t0         = time.time()
            train_loss = self._train_one_epoch()
            val_loss   = self._validate()
            self.scheduler.step(val_loss)

            row = dict(epoch=epoch, train_loss=train_loss, val_loss=val_loss,
                       elapsed=time.time() - t0)
            self.history.append(row)

            print(
                f"Epoch {epoch:3d} | "
                f"train_loss={train_loss:.6f} | "
                f"val_loss={val_loss:.6f} | "
                f"{row['elapsed']:.1f}s"
            )

            if val_loss < self._best_loss:
                self._best_loss  = val_loss
                self._best_state = copy.deepcopy(self.model.state_dict())
                ckpt = self.checkpoint_dir / "lstm_ae_best.pt"
                torch.save(self._best_state, ckpt)
                no_improve = 0
                print(f"  * New best val_loss={val_loss:.6f} -> {ckpt}")
            else:
                no_improve += 1
                if no_improve >= early_stop_patience:
                    print(f"  Early stopping at epoch {epoch}.")
                    break

        if self._best_state:
            self.model.load_state_dict(self._best_state)

        return self.history


# ============================================================
# Threshold calibration  (shared by all models)
# ============================================================

def calibrate_threshold(
    scores_normal:  np.ndarray,
    target_fpr:     float = 0.05,
) -> float:
    """
    Set the anomaly score threshold so that a target fraction of NORMAL
    samples is misclassified as anomalies (false positive rate).

    This is the principled way to choose a threshold in one-class settings:
    you decide what false-alarm rate is operationally acceptable.

    Parameters
    ----------
    scores_normal : anomaly scores for normal validation samples
    target_fpr    : fraction of normal samples you are willing to flag
                    (e.g. 0.05 = 5% false alarm rate)

    Returns
    -------
    threshold : float in [0, 1]
    """
    threshold = float(np.percentile(scores_normal, (1 - target_fpr) * 100))
    threshold = float(np.clip(threshold, 0.01, 0.99))
    print(
        f"[calibrate_threshold] target FPR={target_fpr*100:.0f}% → "
        f"threshold={threshold:.4f}"
    )
    return threshold


def plot_training_curves(history: list[dict], save_path: Optional[str] = None) -> None:
    import matplotlib.pyplot as plt
    epochs     = [r["epoch"]      for r in history]
    train_loss = [r["train_loss"] for r in history]
    val_loss   = [r["val_loss"]   for r in history]
    plt.figure(figsize=(8, 4))
    plt.plot(epochs, train_loss, label="train MSE")
    plt.plot(epochs, val_loss,   label="val MSE")
    plt.xlabel("Epoch"); plt.ylabel("MSE (reconstruction loss)")
    plt.title("LSTM Autoencoder Training Curves")
    plt.legend(); plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved -> {save_path}")
    else:
        plt.show()
