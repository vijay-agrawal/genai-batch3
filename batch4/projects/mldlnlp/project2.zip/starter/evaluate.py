"""
Evaluation Utilities
====================
Anomaly detection uses different metrics from multi-class classification:

  AUROC          – area under the ROC curve (threshold-independent; primary metric)
  AUPRC          – area under the precision-recall curve (better for imbalanced data)
  F1 @ threshold – F1 score at the operational threshold
  Recall@FPR5    – true positive rate when false positive rate = 5%
  FNR            – false negative rate (how many anomalies we MISSED — safety-critical)

KEY INSIGHT:
  Accuracy is a misleading metric when anomalies are ~9% of the dataset.
  A model that predicts "normal" for every patient achieves 91% accuracy but
  zero clinical utility.  AUROC and Recall are what matter.

Usage:
    from evaluate import evaluate_detector, compare_detectors
"""

from __future__ import annotations

from typing import Optional

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import (
    auc,
    average_precision_score,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)


# ---------------------------------------------------------------------------
# Single detector evaluation
# ---------------------------------------------------------------------------

def evaluate_detector(
    y_true:        np.ndarray,   # 0 = normal, 1 = anomaly
    scores:        np.ndarray,   # continuous anomaly scores in [0, 1]
    threshold:     float,
    detector_name: str           = "detector",
    save_dir:      Optional[str] = None,
) -> dict:
    """
    Comprehensive evaluation of one anomaly detector.

    Returns a dict with all key metrics plus visualisations.
    """
    y_pred = (scores >= threshold).astype(int)

    auroc  = roc_auc_score(y_true, scores)
    auprc  = average_precision_score(y_true, scores)
    f1     = f1_score(y_true, y_pred, zero_division=0)
    prec   = precision_score(y_true, y_pred, zero_division=0)
    rec    = recall_score(y_true, y_pred, zero_division=0)
    fnr    = 1 - rec   # fraction of anomalies MISSED

    # Recall at 5% FPR
    fpr_arr, tpr_arr, thresh_arr = roc_curve(y_true, scores)
    idx_fpr5 = np.searchsorted(fpr_arr, 0.05)
    rec_at_fpr5 = float(tpr_arr[idx_fpr5]) if idx_fpr5 < len(tpr_arr) else float("nan")

    cm = confusion_matrix(y_true, y_pred)

    print(f"\n{'='*55}")
    print(f"  {detector_name.upper()}")
    print(f"{'='*55}")
    print(f"  AUROC             : {auroc:.4f}   (1.0 = perfect)")
    print(f"  AUPRC             : {auprc:.4f}")
    print(f"  F1 @ threshold    : {f1:.4f}   (threshold={threshold:.3f})")
    print(f"  Precision         : {prec:.4f}")
    print(f"  Recall            : {rec:.4f}")
    print(f"  FNR (missed!)     : {fnr:.4f}", end="")
    if fnr > 0.20:
        print("  *** HIGH: >20% of anomalies missed ***")
    else:
        print()
    print(f"  Recall @ FPR=5%   : {rec_at_fpr5:.4f}")
    print(f"  Confusion matrix  :\n  {cm}")

    # Plots
    fig, axes = plt.subplots(1, 3, figsize=(16, 4))
    _plot_roc(axes[0], fpr_arr, tpr_arr, auroc, detector_name)
    _plot_prc(axes[1], y_true, scores, auprc, detector_name)
    _plot_score_hist(axes[2], y_true, scores, threshold, detector_name)
    plt.tight_layout()

    if save_dir:
        from pathlib import Path
        Path(save_dir).mkdir(parents=True, exist_ok=True)
        p = Path(save_dir) / f"eval_{detector_name.replace(' ', '_')}.png"
        plt.savefig(p, dpi=150)
        plt.close()
        print(f"  Plots saved -> {p}")
    else:
        plt.show()

    return dict(
        detector     = detector_name,
        auroc        = auroc,
        auprc        = auprc,
        f1           = f1,
        precision    = prec,
        recall       = rec,
        fnr          = fnr,
        recall_fpr5  = rec_at_fpr5,
        threshold    = threshold,
    )


# ---------------------------------------------------------------------------
# Comparison table
# ---------------------------------------------------------------------------

def compare_detectors(
    metrics_list: list[dict],
    save_path: Optional[str] = None,
) -> None:
    """
    Print a side-by-side comparison table for multiple detectors
    and optionally save as PNG.

    Expected insight (confirm or refute with your results):
      * AUROC ranking:  LSTM AE > IF >= PCA > OC-SVM > DBSCAN (high-dim)
      * PCA is competitive because the dataset has linear multivariate structure
      * DBSCAN degrades without prior dimensionality reduction
      * LSTM AE dominates on the ICU (temporal) task; classical methods are weaker
    """
    df = pd.DataFrame(metrics_list).set_index("detector")
    cols = ["auroc", "auprc", "f1", "recall", "precision", "fnr", "recall_fpr5"]
    df   = df[[c for c in cols if c in df.columns]]

    print("\n" + "="*75)
    print("  DETECTOR COMPARISON")
    print("="*75)
    print(df.round(4).to_string())
    print("="*75)

    if save_path:
        fig, ax = plt.subplots(figsize=(10, 4))
        df_plot = df[["auroc", "auprc", "recall"]].T
        df_plot.plot(kind="bar", ax=ax, rot=0)
        ax.set_ylim(0, 1.05)
        ax.set_title("AUROC / AUPRC / Recall comparison")
        ax.legend(loc="lower right")
        plt.tight_layout()
        plt.savefig(save_path, dpi=150)
        plt.close()
        print(f"Comparison chart saved -> {save_path}")


# ---------------------------------------------------------------------------
# Score distribution analysis  (helps choose / justify threshold)
# ---------------------------------------------------------------------------

def plot_threshold_sweep(
    y_true:   np.ndarray,
    scores:   np.ndarray,
    name:     str           = "detector",
    save_path: Optional[str] = None,
) -> None:
    """
    Plot Precision, Recall, and F1 as a function of threshold.
    Helps students understand the precision-recall trade-off and justify
    their threshold choice (e.g., maximise F1 vs. maximise Recall at FPR).

    TODO (Student Task 8):
    Run this for each detector and answer in your report:
      a) What threshold maximises F1?
      b) What threshold achieves Recall >= 0.90 (clinically acceptable)?
      c) Is there a large gap between (a) and (b)?  What does this imply
         about the difficulty of the detection problem?
    """
    thresholds = np.linspace(0.01, 0.99, 200)
    precisions, recalls, f1s = [], [], []

    for t in thresholds:
        y_pred = (scores >= t).astype(int)
        precisions.append(precision_score(y_true, y_pred, zero_division=0))
        recalls.append(recall_score(y_true, y_pred, zero_division=0))
        f1s.append(f1_score(y_true, y_pred, zero_division=0))

    best_f1_idx = np.argmax(f1s)
    best_t = thresholds[best_f1_idx]

    plt.figure(figsize=(9, 4))
    plt.plot(thresholds, precisions, label="Precision")
    plt.plot(thresholds, recalls,    label="Recall")
    plt.plot(thresholds, f1s,        label="F1")
    plt.axvline(best_t, color="red", linestyle="--", label=f"Best F1 threshold={best_t:.2f}")
    plt.xlabel("Threshold"); plt.ylabel("Score")
    plt.title(f"Threshold sweep — {name}")
    plt.legend(); plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150)
        plt.close()
        print(f"Threshold sweep saved -> {save_path}")
    else:
        plt.show()

    print(f"[{name}] Best F1={f1s[best_f1_idx]:.4f} at threshold={best_t:.3f}")


# ---------------------------------------------------------------------------
# Per-disease-subtype breakdown (Part A)
# ---------------------------------------------------------------------------

def subtype_breakdown(
    test_df:    pd.DataFrame,
    scores:     np.ndarray,
    threshold:  float,
    detector:   str = "detector",
) -> pd.DataFrame:
    """
    Break down AUROC and recall by disease subtype.

    test_df must contain 'label' and 'disease_type' columns.
    Returns a DataFrame with one row per subtype.
    """
    df = test_df.copy()
    df["score"] = scores
    df["pred"]  = (scores >= threshold).astype(int)

    rows = []
    for subtype, group in df.groupby("disease_type"):
        if group["label"].nunique() < 2:
            continue
        try:
            auroc = roc_auc_score(group["label"], group["score"])
        except Exception:
            auroc = float("nan")
        rec = recall_score(group["label"], group["pred"], zero_division=0)
        rows.append(dict(disease_type=subtype, auroc=auroc, recall=rec,
                         n=len(group), n_anomaly=group["label"].sum()))

    result = pd.DataFrame(rows).set_index("disease_type")
    print(f"\n  [{detector}] Per-subtype breakdown:")
    print(result.round(4).to_string())
    return result


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _plot_roc(ax, fpr, tpr, auroc, name):
    ax.plot(fpr, tpr, label=f"AUROC={auroc:.3f}")
    ax.plot([0, 1], [0, 1], "k--", linewidth=0.8)
    ax.set_xlabel("FPR"); ax.set_ylabel("TPR")
    ax.set_title(f"ROC — {name}"); ax.legend()


def _plot_prc(ax, y_true, scores, auprc, name):
    prec, rec, _ = precision_recall_curve(y_true, scores)
    ax.plot(rec, prec, label=f"AUPRC={auprc:.3f}")
    ax.set_xlabel("Recall"); ax.set_ylabel("Precision")
    ax.set_title(f"PR Curve — {name}"); ax.legend()


def _plot_score_hist(ax, y_true, scores, threshold, name):
    ax.hist(scores[y_true == 0], bins=40, alpha=0.6, label="Normal",  color="steelblue")
    ax.hist(scores[y_true == 1], bins=40, alpha=0.6, label="Anomaly", color="tomato")
    ax.axvline(threshold, color="black", linestyle="--", label=f"thresh={threshold:.2f}")
    ax.set_xlabel("Anomaly score"); ax.set_ylabel("Count")
    ax.set_title(f"Score Distribution — {name}"); ax.legend()
