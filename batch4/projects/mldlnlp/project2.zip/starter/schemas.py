"""
Output Schemas (Pydantic v2)
============================
Every anomaly detection result — whether from Part A (rare disease, static)
or Part B (ICU monitoring, time-series) — must conform to these schemas.

Design goals:
  * A single ClassificationOutput works for both problem settings.
  * The reasoning block captures *which features* drove the anomaly score
    (vital for clinical use — a model that says "anomalous" without evidence
    is not actionable).
  * ClinicalFlags surface safety-relevant context (e.g. low SpO2, elevated
    lactate) that clinicians need regardless of the model's final verdict.

Students: Do NOT modify this file.
"""

from __future__ import annotations

from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class AnomalyVerdict(str, Enum):
    NORMAL  = "normal"
    ANOMALY = "anomaly"


class DetectionMethod(str, Enum):
    PCA          = "pca_reconstruction"
    OCSVM        = "one_class_svm"
    ISOFOREST    = "isolation_forest"
    DBSCAN       = "dbscan"
    LSTM_AE      = "lstm_autoencoder"
    ENSEMBLE     = "ensemble"


class DataModality(str, Enum):
    STATIC     = "static"          # Part A: single snapshot
    TIME_SERIES= "time_series"     # Part B: sequential
    MIXED      = "mixed"           # structured + text embeddings fused


# ---------------------------------------------------------------------------
# Feature contribution (what drove the anomaly score)
# ---------------------------------------------------------------------------

class FeatureContribution(BaseModel):
    """
    One feature's contribution to the anomaly score.

    For PCA:        contribution = squared projection onto top residual component
    For LSTM AE:    contribution = per-feature mean squared reconstruction error
    For IF/OC-SVM:  contribution = SHAP value (sign indicates direction)
    """
    feature:      str
    value:        float = Field(description="Raw (unscaled) feature value")
    contribution: float = Field(description="Contribution magnitude (>=0); larger = more anomalous")
    direction:    str   = Field(
        description="'high' | 'low' | 'pattern' — what kind of deviation was detected"
    )


# ---------------------------------------------------------------------------
# Clinical flags (safety-critical surface features)
# ---------------------------------------------------------------------------

CRITICAL_THRESHOLDS = {
    "spo2":    ("< 90%",  "Hypoxia"),
    "sbp":     ("< 90",   "Hypotension"),
    "hr":      ("> 130",  "Severe tachycardia"),
    "rr":      ("> 30",   "Tachypnoea"),
    "lactate": ("> 2.0",  "Hyperlactataemia"),
    "temp":    ("> 101.5","Fever"),
    "troponin":("> 0.04", "Troponin elevation"),
}


# ---------------------------------------------------------------------------
# Core output model
# ---------------------------------------------------------------------------

class AnomalyDetectionOutput(BaseModel):
    """
    Full structured output for a single patient / ICU stay assessment.

    Example (ICU stay flagged by LSTM autoencoder):
        output = AnomalyDetectionOutput(
            patient_id       = "ICU-00042",
            data_modality    = DataModality.TIME_SERIES,
            verdict          = AnomalyVerdict.ANOMALY,
            anomaly_score    = 0.83,
            detection_method = DetectionMethod.LSTM_AE,
            threshold_used   = 0.50,
            feature_contributions = [...],
            clinical_flags   = ["SpO2 < 90% at hour 18", "HR > 130 at hour 20"],
            reasoning        = "Reconstruction error peaked at hours 16-20 ...",
        )
        print(output.model_dump_json(indent=2))
    """

    patient_id:           str
    data_modality:        DataModality
    verdict:              AnomalyVerdict
    anomaly_score:        float = Field(ge=0.0, le=1.0,
                              description="Normalised score: 0 = very normal, 1 = very anomalous")
    detection_method:     DetectionMethod
    threshold_used:       float = Field(ge=0.0, le=1.0,
                              description="Threshold applied to anomaly_score to produce verdict")
    feature_contributions: List[FeatureContribution] = Field(
        min_length=1,
        description="Top features driving the anomaly score, ranked by contribution magnitude"
    )
    clinical_flags:       List[str] = Field(
        default_factory=list,
        description="Hard-threshold safety flags independent of the model verdict"
    )
    reasoning:            str = Field(
        min_length=10,
        description="One or two sentences summarising why this verdict was reached"
    )
    reconstruction_error: Optional[float] = Field(
        default=None,
        description="Raw MSE (LSTM AE only); included for threshold calibration analysis"
    )
    model_version:        str = "1.0.0"

    @field_validator("threshold_used")
    @classmethod
    def threshold_is_plausible(cls, v: float) -> float:
        if v <= 0 or v >= 1:
            raise ValueError(
                f"threshold_used={v} looks misconfigured; expect a value derived from "
                "the training anomaly score distribution, typically in (0.05, 0.95)."
            )
        return v

    @model_validator(mode="after")
    def verdict_consistent_with_score(self) -> "AnomalyDetectionOutput":
        expected = AnomalyVerdict.ANOMALY if self.anomaly_score >= self.threshold_used \
                   else AnomalyVerdict.NORMAL
        if self.verdict != expected:
            raise ValueError(
                f"verdict='{self.verdict}' is inconsistent with "
                f"anomaly_score={self.anomaly_score:.4f} and "
                f"threshold={self.threshold_used:.4f}. "
                f"Expected verdict='{expected}'."
            )
        return self

    @model_validator(mode="after")
    def lstm_ae_has_reconstruction_error(self) -> "AnomalyDetectionOutput":
        if (self.detection_method == DetectionMethod.LSTM_AE
                and self.reconstruction_error is None):
            raise ValueError(
                "reconstruction_error must be set when detection_method='lstm_autoencoder'."
            )
        return self


# ---------------------------------------------------------------------------
# Batch output
# ---------------------------------------------------------------------------

class BatchAnomalyOutput(BaseModel):
    """Aggregated results over a cohort of patients or ICU stays."""

    results:            List[AnomalyDetectionOutput]
    total_evaluated:    int = Field(ge=1)
    n_anomalies:        int = Field(ge=0)
    anomaly_rate:       float = Field(ge=0.0, le=1.0)
    mean_anomaly_score: float = Field(ge=0.0, le=1.0)
    detection_method:   DetectionMethod
    threshold_used:     float
    processing_notes:   Optional[str] = None

    @model_validator(mode="after")
    def counts_consistent(self) -> "BatchAnomalyOutput":
        actual_anomalies = sum(
            1 for r in self.results if r.verdict == AnomalyVerdict.ANOMALY
        )
        if self.n_anomalies != actual_anomalies:
            raise ValueError(
                f"n_anomalies={self.n_anomalies} != actual count "
                f"in results ({actual_anomalies})"
            )
        expected_rate = actual_anomalies / len(self.results)
        if abs(self.anomaly_rate - expected_rate) > 1e-3:
            raise ValueError(
                f"anomaly_rate={self.anomaly_rate:.4f} != "
                f"n_anomalies/total ({expected_rate:.4f})"
            )
        return self

    @model_validator(mode="after")
    def total_matches_results(self) -> "BatchAnomalyOutput":
        if self.total_evaluated != len(self.results):
            raise ValueError(
                f"total_evaluated ({self.total_evaluated}) != len(results) ({len(self.results)})"
            )
        return self


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json

    dummy = AnomalyDetectionOutput(
        patient_id            = "ICU-00042",
        data_modality         = DataModality.TIME_SERIES,
        verdict               = AnomalyVerdict.ANOMALY,
        anomaly_score         = 0.83,
        detection_method      = DetectionMethod.LSTM_AE,
        threshold_used        = 0.60,
        reconstruction_error  = 0.047,
        feature_contributions = [
            FeatureContribution(feature="spo2", value=88.2, contribution=0.62, direction="low"),
            FeatureContribution(feature="hr",   value=138,  contribution=0.44, direction="high"),
            FeatureContribution(feature="rr",   value=34,   contribution=0.38, direction="high"),
        ],
        clinical_flags = ["SpO2 < 90% at hour 18", "HR > 130 at hour 20", "RR > 30 at hour 22"],
        reasoning      = (
            "LSTM autoencoder reconstruction error peaked at hours 16-22, "
            "driven by SpO2 collapse and compensatory tachycardia/tachypnoea — "
            "pattern consistent with respiratory failure."
        ),
    )
    print(json.loads(dummy.model_dump_json(indent=2)))
    print("\nSchema self-test passed.")
