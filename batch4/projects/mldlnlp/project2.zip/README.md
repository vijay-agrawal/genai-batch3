# Mini-Project 2: Clinical Anomaly Detection

## The Problem

Clinical anomaly detection is a **one-class learning** problem:

> *"I don't know what a rare disease looks like — but I have thousands of
> healthy patient records. Train on those, and flag anything that doesn't fit."*

This is fundamentally different from standard classification because:
- You cannot train on anomalies (they are rare, diverse, and often unknown)
- Any model that learns from anomalies will overfit to known failure modes
- The cost of a **false negative** (missed sick patient) is severe

---

## Two Sub-Problems

### Part A — Rare Disease Detection (static patient profiles)

A hospital has 5 000 patient records (structured labs/vitals + clinical notes).
~9% have a rare condition. The records come from multiple disease archetypes:

| Disease Archetype | Key Pattern |
|---|---|
| Autoimmune Dysregulation | WBC↑ + CRP *normal* (paradox) |
| Mitochondrial Disorder | Lactate↑ + Glucose↓ + SpO2 slightly low |
| Rare Cardiac Syndrome | HR–BP dissociation + Troponin elevation |
| Hematologic Anomaly | HGB↓ + WBC↑ + CRP *normal* |

**The trap:** every individual feature can sit inside the normal range.
The anomaly is in the *multivariate correlation structure*, not in any single value.
This is exactly what PCA, OC-SVM, and Isolation Forest are designed to catch.

### Part B — ICU Monitoring (sequential vitals)

An ICU records 6 vital signs hourly for 24 hours per patient stay.
~25% of stays involve a deterioration event (sepsis, cardiogenic shock,
respiratory failure) that begins at a random hour between hour 6 and 15.

The LSTM Autoencoder learns the **temporal grammar** of normal ICU vitals —
the circadian rhythms, expected co-variation between HR and BP, etc.
When a stay deviates from this learned grammar, the reconstruction error spikes.

---

## Directory Structure

```
project2/
├── README.md               ← you are here
├── rubric.md               ← grading criteria
├── requirements.txt
│
├── data/
│   ├── generate_dataset.py ← generates both datasets
│   ├── rare_disease_patients.csv
│   └── icu_vitals.csv
│
└── starter/
    ├── schemas.py          ← Pydantic output schema  (DO NOT MODIFY)
    ├── preprocess.py       ← feature engineering     (Tasks 1, 2)
    ├── models.py           ← 5 model architectures   (Tasks 3, 4, 5)
    ├── train.py            ← training utilities      (Task 7)
    ├── evaluate.py         ← anomaly detection metrics (Task 8)
    ├── predict.py          ← prediction + SHAP       (Task 9)
    └── main.py             ← end-to-end orchestration
```

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Generate datasets

```bash
# Full datasets (~5 000 patients + ~1 200 ICU stays)
python data/generate_dataset.py

# Quick version for initial testing
python data/generate_dataset.py --quick
```

### 3. Run Part A (classical detectors — no GPU needed)

```bash
python starter/main.py --part A
```

### 4. Run Part B (LSTM AE — GPU recommended)

```bash
python starter/main.py --part B --epochs 50
```

---

## Approaches at a Glance

```
PART A — Static Patient Records
                                            
  [Feature Vector]
       │
       ├─── PCA ────────────────────────► reconstruction error → anomaly score
       │         (linear, interpretable)
       │
       ├─── Isolation Forest ───────────► isolation depth      → anomaly score
       │         (scalable, non-linear)
       │
       ├─── One-Class SVM ────��────────► signed distance       → anomaly score
       │         (kernel, small data)
       │
       └─── DBSCAN ────────────��───────► cluster membership    → 0/1 label
                 (density, no training) [best after PCA reduction]


PART B — ICU Time-Series
                                            
  [Hour × Feature Sequence]
       │                             
       │   ┌─────────────────────────────────────────┐
       │   │  BiLSTM Encoder (stacked, 2 layers)      │
       │   │  (B, T, F) ──► (B, T, 2H) ──► (B, H)    │
       │   │                        ↑ bottleneck       │
       │   │  LSTM Decoder (2 layers)                  │
       │   │  (B, H) ──► (B, T, H) ──► (B, T, F)      │
       │   └────────���───────────────────────────��────┘
       │
       └─── MSE(input, reconstruction) → anomaly score
```

---

## Student Tasks (9 TODOs)

| Task | File | What to implement |
|---|---|---|
| **1a** | `preprocess.py` | Add interaction features (shock index, MAP, pulse pressure) |
| **1b** | `preprocess.py` | Explore sentence-transformer embeddings vs TF-IDF |
| **2**  | `preprocess.py` | Add delta (rate-of-change) feature channel for ICU sequences |
| **3**  | `models.py`     | `PCADetector.anomaly_score()` — PCA reconstruction error |
| **4**  | `models.py`     | `LSTMAutoencoder.forward()` — encoder + decoder |
| **5**  | `models.py`     | `LSTMAutoencoder.reconstruction_error()` — per-sample MSE |
| **6a** | `models.py`     | (bonus) DBSCAN cluster visualisation on PCA-2D |
| **7**  | `train.py`      | `_train_one_epoch()` — MSE reconstruction training loop |
| **8**  | `evaluate.py`   | Run threshold sweep; answer questions (a)(b)(c) in code comment |
| **9**  | `predict.py`    | `explain_isolation_forest()` — SHAP TreeExplainer |

---

## Experiments to Run

### Experiment 1: Preprocessing ablation (Part A)

```python
# Train all detectors with and without:
#   a) interaction features (Task 1a)
#   b) TF-IDF note embeddings
#   c) log-transform of skewed lab values
# Report AUROC change for each.
```

**Question:** Does clinical note embedding contribute beyond structured features?
When would text matter more (hint: think about which disease archetypes are
better described in notes vs. labs)?

### Experiment 2: Method comparison (Part A)

Train all four classical detectors on the same healthy training split.
Compare:
- AUROC and AUPRC
- Compute time (fit + predict)
- Behaviour on each disease subtype
- Failure modes: which method misses which subtype?

**Expected insight:**
- PCA catches linear correlation deviations (autoimmune paradox)
- Isolation Forest catches outliers in any direction
- OC-SVM is competitive but slow; requires PCA pre-reduction
- DBSCAN fails without prior dimensionality reduction (high-dim curse)

### Experiment 3: Delta features (Part B)

```python
seq_prep_no_delta = SequencePreprocessor()   # Task 2 not implemented
seq_prep_delta    = SequencePreprocessor()   # Task 2 implemented
# Train two LSTM AEs and compare AUROC
```

**Expected insight:** Delta features capture the *rate of deterioration*.
Sepsis onset is characterised by HR *increasing*, not just HR being high.
Without delta features, the model may miss early-onset deterioration.

### Experiment 4: Training contamination experiment

> **This is the core conceptual experiment of the project.**

```python
# Scenario A (correct): train on healthy only
# Scenario B (wrong):   train on all patients (including 9% anomalies)
# Compare AUROC for both scenarios.
```

**Expected result:** Scenario B produces lower AUROC because the autoencoder
learns to reconstruct anomalies too, reducing the reconstruction error gap.
This is the empirical demonstration of why one-class learning matters.

---

## Key Concepts to Understand

### Why reconstruction error detects anomalies

A model trained only on normal data learns a *manifold* (a compressed
representation) of normality. New inputs are:
- **Normal** → close to the manifold → low reconstruction error
- **Anomalous** → far from the manifold → high reconstruction error

This fails when:
1. The anomaly looks superficially similar to normal data (subtle anomalies)
2. The model capacity is too high (memorises everything → low error for anomalies too)
3. Too little training data → the model hasn't learned the full normal manifold

### Why PCA finds multivariate anomalies

PCA finds the directions of maximum variance in the healthy data.
An anomalous patient with values in unusual *combinations* (e.g. WBC high but
CRP low — opposite to what infection does) projects poorly onto the healthy
principal components, producing a large residual.

Key insight: PCA is not just dimensionality reduction — it is a *covariance
anomaly detector*.

### Isolation Forest vs One-Class SVM — when to use which

| Factor | Use Isolation Forest | Use One-Class SVM |
|---|---|---|
| Dataset size | > 5 000 | < 2 000 |
| Dimensionality | Any (high-d OK) | After PCA reduction |
| Anomaly fraction | Any | < 10% |
| Need for explainability | SHAP available | Difficult |
| Training speed | Fast | Slow (O(n²) memory) |

### Why DBSCAN struggles in high dimensions

The curse of dimensionality: in high-dimensional spaces, all pairwise distances
converge to the same value. The `eps` neighbourhood radius becomes meaningless
because no points are "dense" relative to any other. DBSCAN works well after
PCA reduction to 2–10 dimensions.

---

## Output Format

Every prediction validates against `AnomalyDetectionOutput` (see `schemas.py`).

Example (ICU stay with LSTM AE):

```json
{
  "patient_id": "ICU-00312",
  "data_modality": "time_series",
  "verdict": "anomaly",
  "anomaly_score": 0.847,
  "detection_method": "lstm_autoencoder",
  "threshold_used": 0.612,
  "reconstruction_error": 0.0523,
  "feature_contributions": [
    {"feature": "spo2", "value": 88.4, "contribution": 0.031, "direction": "low"},
    {"feature": "hr",   "value": 142,  "contribution": 0.024, "direction": "high"},
    {"feature": "rr",   "value": 36,   "contribution": 0.019, "direction": "high"}
  ],
  "clinical_flags": [
    "SpO2 < 90% at hour 18 (value: 88.4)",
    "HR > 130 at hour 20 (value: 142.0)",
    "RR > 30 at hour 22 (value: 36.0)"
  ],
  "reasoning": "LSTM AE reconstruction error = 0.0523 (normalised=0.847). Highest errors in: spo2, hr, rr. Verdict: anomaly (threshold=0.612).",
  "model_version": "1.0.0"
}
```

---

## Evaluation Metric Priority

Because missing a deteriorating ICU patient or a rare disease is a patient
safety issue:

1. **Recall @ FPR=5%** (primary — how many sick patients do we catch while
   maintaining a 5% false alarm rate on healthy patients?)
2. **AUROC** (overall discriminative power, threshold-independent)
3. **AUPRC** (more informative than AUROC for imbalanced datasets)
4. F1 @ operational threshold
5. Accuracy (reported but always last)

---

## Report Structure (≤ 5 pages)

1. **Dataset analysis** — feature distributions, overlap analysis, time-series visualisation.

2. **Preprocessing** — ablation table (with/without interaction features, delta channels, notes).

3. **Part A: Method comparison** — AUROC table; per-subtype breakdown;
   which detector catches which archetype and why.

4. **Part B: LSTM AE analysis** — training curves, reconstruction error histograms,
   per-feature error heatmap for one deterioration case.

5. **Explainability** — 2 SHAP examples (Part A) + 1 LSTM temporal heatmap (Part B).

6. **Key learning** — one paragraph answering: *"Would you deploy a single model
   for both tasks, or different models? Justify with your empirical results."*

---

## Grading

See [rubric.md](rubric.md) for full breakdown (100 pts + 10 bonus).
