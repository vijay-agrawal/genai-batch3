"""
MCPDischarge — Three MCP Servers
===================================
FastMCP-compatible server implementations for EHR, Pharmacy, and Billing.
Each server exposes typed tools with RBAC enforcement at the tool level.

Architecture:
  EHR Server     (port 8001) — patient records, discharge notes, medications
  Pharmacy Server(port 8002) — drug inventory, stock checks, alternatives
  Billing Server (port 8003) — charge codes, invoice generation, insurance

RBAC is enforced per-tool: every tool call validates the caller's role
against the RBAC policy matrix before returning data.

PHI Boundary:
  - EHR discharge_note field is BLOCKED from billing_agent role
  - ICD-10 codes + LOS + ward flow freely to billing (non-PHI operational data)
  - Drug names with clinical context BLOCKED from billing_agent

Run servers:
  python mcp_servers.py --server ehr      (port 8001)
  python mcp_servers.py --server pharmacy (port 8002)
  python mcp_servers.py --server billing  (port 8003)
  python mcp_servers.py --all             (all three)
"""

import json
import logging
import hashlib
import re
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Any

logger = logging.getLogger("MCPServers")
DATA_DIR = Path(__file__).parent.parent.parent / "data"

# ─────────────────────────────────────────────────────────
# LOAD DATA
# ─────────────────────────────────────────────────────────

def _load(fname): return json.load(open(DATA_DIR / fname))

EHR_DB        = {p["patient_id"]: p for p in _load("ehr_patients.json")}
PHARMACY_DB   = {d["drug_id"]: d for d in _load("pharmacy_inventory.json")}
BILLING_RATES = {r["charge_code"]: r for r in _load("billing_rate_cards.json")}
INSURANCE     = {c["insurer_id"]: c for c in _load("insurance_contracts.json")}
PAT_INSURANCE = _load("patient_insurance_map.json")
ICD10_BILL    = _load("icd10_billing_codes.json")
RBAC          = _load("rbac_policies.json")

# Build pharmacy aliases index
PHARMACY_ALIAS = {}
for drug in _load("pharmacy_inventory.json"):
    for alias in drug.get("semantic_aliases", []):
        PHARMACY_ALIAS[alias.lower()] = drug["drug_id"]
    PHARMACY_ALIAS[drug["generic_name"].lower()] = drug["drug_id"]
    for brand in drug.get("brand_names", []):
        PHARMACY_ALIAS[brand.lower()] = drug["drug_id"]

# Telemetry log
_TELEMETRY: list[dict] = []

def _log_telemetry(server: str, tool: str, caller_role: str, patient_id: str,
                   allowed: bool, phi_leak: bool = False, payload_summary: str = ""):
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "server": server, "tool": tool, "caller_role": caller_role,
        "patient_id": patient_id, "allowed": allowed,
        "phi_leak_detected": phi_leak, "payload_summary": payload_summary,
    }
    _TELEMETRY.append(entry)
    icon = "✓" if allowed else "✗"
    phi_warn = " [PHI-LEAK-BLOCKED]" if phi_leak else ""
    logger.info(f"  [{server}] {icon} {tool} | role={caller_role}{phi_warn}")
    return entry


# ─────────────────────────────────────────────────────────
# RBAC GUARD
# ─────────────────────────────────────────────────────────

class RBACError(PermissionError):
    """Raised when a caller role is not authorised for a tool."""
    pass

def rbac_check(server: str, tool: str, caller_role: str, patient_id: str = ""):
    """Validate that caller_role has permission to call tool on server."""
    role_perms = RBAC.get(caller_role, {})
    server_perms = role_perms.get(server, [])
    allowed = tool in server_perms
    _log_telemetry(server, tool, caller_role, patient_id, allowed)
    if not allowed:
        raise RBACError(
            f"[RBAC BLOCKED] Role '{caller_role}' is NOT authorised to call "
            f"'{tool}' on the {server} server. "
            f"Authorised tools for this role: {server_perms}"
        )


# ─────────────────────────────────────────────────────────
# PHI BOUNDARY ENFORCEMENT
# ─────────────────────────────────────────────────────────

PHI_FIELDS = {"name", "dob", "mrn", "discharge_note", "attending_physician"}

def strip_phi_for_billing(patient: dict) -> dict:
    """Remove clinical PHI fields — return only billing-safe operational data."""
    safe_fields = {"patient_id", "ward", "admission_date", "discharge_date",
                   "los_days", "diagnosis_icd10", "diagnosis_labels"}
    stripped = {k: v for k, v in patient.items() if k in safe_fields}
    # Detect any PHI field that might have leaked
    for field in PHI_FIELDS:
        if field in stripped:
            _log_telemetry("ehr", "phi_check", "billing_agent", patient.get("patient_id",""),
                           False, phi_leak=True, payload_summary=f"PHI field '{field}' blocked")
    return stripped


# ─────────────────────────────────────────────────────────
# EHR MCP SERVER
# ─────────────────────────────────────────────────────────

class EHRServer:
    """
    MCP Server — Electronic Health Records
    Exposes: discharge notes, medications, diagnosis codes, demographics.
    PHI guardrail: discharge_note blocked from billing_agent.
    """
    SERVER_NAME = "ehr"

    def get_patient_discharge_summary(self, patient_id: str, caller_role: str) -> dict:
        """Full discharge summary including clinical notes — clinical roles only."""
        rbac_check(self.SERVER_NAME, "read_discharge_note", caller_role, patient_id)
        patient = EHR_DB.get(patient_id)
        if not patient:
            raise KeyError(f"Patient {patient_id} not found in EHR")
        return {
            "patient_id": patient_id,
            "discharge_note": patient["discharge_note"],
            "discharge_medications": patient["discharge_medications"],
            "special_instructions": patient["special_instructions"],
            "diagnosis_icd10": patient["diagnosis_icd10"],
            "attending_physician": patient["attending_physician"],
        }

    def get_discharge_medications(self, patient_id: str, caller_role: str) -> dict:
        """Medication list — available to pharmacy and clinical roles."""
        rbac_check(self.SERVER_NAME, "read_medications", caller_role, patient_id)
        patient = EHR_DB.get(patient_id)
        if not patient:
            raise KeyError(f"Patient {patient_id} not found")
        return {
            "patient_id": patient_id,
            "discharge_medications": patient["discharge_medications"],
            "special_instructions": patient["special_instructions"],
        }

    def get_diagnosis_codes(self, patient_id: str, caller_role: str) -> dict:
        """ICD-10 codes only — available to all roles including billing."""
        rbac_check(self.SERVER_NAME, "read_diagnosis_codes", caller_role, patient_id)
        patient = EHR_DB.get(patient_id)
        if not patient:
            raise KeyError(f"Patient {patient_id} not found")
        return {
            "patient_id": patient_id,
            "diagnosis_icd10": patient["diagnosis_icd10"],
            "diagnosis_labels": patient["diagnosis_labels"],
        }

    def get_admission_info(self, patient_id: str, caller_role: str) -> dict:
        """Admission dates, LOS, ward — billing-safe operational data."""
        rbac_check(self.SERVER_NAME, "read_admission_dates", caller_role, patient_id)
        patient = EHR_DB.get(patient_id)
        if not patient:
            raise KeyError(f"Patient {patient_id} not found")
        # This is safe for billing — no clinical content
        return {
            "patient_id": patient_id,
            "ward": patient["ward"],
            "admission_date": patient["admission_date"],
            "discharge_date": patient["discharge_date"],
            "los_days": patient["los_days"],
        }

    def get_billing_safe_summary(self, patient_id: str, caller_role: str) -> dict:
        """
        Billing-safe patient summary — PHI stripped.
        Returns ICD-10 + LOS + ward ONLY.
        BLOCKED fields: name, DOB, MRN, discharge_note, medications.
        """
        rbac_check(self.SERVER_NAME, "read_diagnosis_codes", caller_role, patient_id)
        rbac_check(self.SERVER_NAME, "read_admission_dates", caller_role, patient_id)
        patient = EHR_DB.get(patient_id)
        if not patient:
            raise KeyError(f"Patient {patient_id} not found")
        safe = strip_phi_for_billing(patient)
        safe["phi_stripped"] = True
        safe["blocked_fields"] = sorted(PHI_FIELDS & set(patient.keys()))
        return safe


# ─────────────────────────────────────────────────────────
# PHARMACY MCP SERVER
# ─────────────────────────────────────────────────────────

def _find_drug_by_name(drug_name: str) -> Optional[dict]:
    """Fuzzy semantic lookup by drug name, brand, or alias."""
    name_lower = drug_name.lower().strip()
    # Direct alias match
    if name_lower in PHARMACY_ALIAS:
        drug_id = PHARMACY_ALIAS[name_lower]
        return PHARMACY_DB.get(drug_id)
    # Partial match
    for alias, drug_id in PHARMACY_ALIAS.items():
        if name_lower in alias or alias in name_lower:
            return PHARMACY_DB.get(drug_id)
    # Word overlap
    name_words = set(name_lower.split())
    best_score = 0
    best_drug = None
    for alias, drug_id in PHARMACY_ALIAS.items():
        alias_words = set(alias.split())
        score = len(name_words & alias_words)
        if score > best_score:
            best_score = score
            best_drug = PHARMACY_DB.get(drug_id)
    return best_drug if best_score > 0 else None


class PharmacyServer:
    """
    MCP Server — Pharmacy Inventory
    Exposes: stock checks, alternatives, pricing, dispense requests.
    """
    SERVER_NAME = "pharmacy"

    def check_stock(self, drug_name: str, dose: str, caller_role: str,
                    patient_id: str = "") -> dict:
        """
        Check if a drug is in stock. Performs semantic name matching
        (EHR brand names → pharmacy generic names).
        """
        rbac_check(self.SERVER_NAME, "check_stock", caller_role, patient_id)
        drug = _find_drug_by_name(drug_name)

        if not drug:
            return {
                "found": False,
                "drug_name_queried": drug_name,
                "message": f"Drug '{drug_name}' not found in pharmacy formulary.",
                "semantic_match": False,
            }

        # Dose mismatch detection
        dose_conflict = False
        conflict_detail = ""
        if dose and drug.get("formulary_standard_dose"):
            queried_dose = dose.strip().lower()
            formulary_dose = drug["formulary_standard_dose"].lower()
            if queried_dose not in formulary_dose and formulary_dose.split()[0] != queried_dose:
                dose_conflict = True
                conflict_detail = (
                    f"DOSE CONFLICT: EHR prescribes {dose}; "
                    f"formulary standard is {drug['formulary_standard_dose']}. "
                    f"Clinical review required before dispensing."
                )

        return {
            "found": True,
            "drug_id": drug["drug_id"],
            "generic_name": drug["generic_name"],
            "brand_names": drug["brand_names"],
            "queried_name": drug_name,
            "semantic_match": drug_name.lower() not in [drug["generic_name"].lower()],
            "name_matched_via_alias": True,
            "in_stock": drug["in_stock"],
            "stock_units": drug["stock_units"],
            "restock_eta_days": drug.get("restock_eta_days"),
            "dose_conflict": dose_conflict,
            "dose_conflict_detail": conflict_detail if dose_conflict else None,
            "controlled_substance": drug.get("controlled_substance", False),
            "specialty_drug": drug.get("specialty_drug", False),
            "formulary_standard_dose": drug.get("formulary_standard_dose"),
            "requires_refrigeration": drug.get("requires_refrigeration", False),
        }

    def get_alternative(self, drug_name: str, caller_role: str,
                         patient_id: str = "") -> dict:
        """Get formulary alternative when drug is out of stock."""
        rbac_check(self.SERVER_NAME, "get_alternatives", caller_role, patient_id)
        drug = _find_drug_by_name(drug_name)
        if not drug:
            return {"found": False, "alternative": None}

        alt_id = drug.get("alternative_drug_id")
        alt_name = drug.get("alternative_name")
        if alt_id and alt_id in PHARMACY_DB:
            alt = PHARMACY_DB[alt_id]
            return {
                "original_drug": drug["generic_name"],
                "alternative_drug_id": alt_id,
                "alternative_name": alt["generic_name"],
                "alternative_brand": alt["brand_names"][0] if alt["brand_names"] else None,
                "alternative_in_stock": alt["in_stock"],
                "alternative_price_inr": alt["price_per_unit_inr"],
                "clinical_equivalence": alt_name,
                "requires_prescriber_approval": True,
            }
        return {
            "original_drug": drug["generic_name"] if drug else drug_name,
            "alternative_available": False,
            "message": alt_name or "No alternative available in formulary. Source from specialty pharmacy.",
        }

    def get_drug_price(self, drug_name: str, days_supply: int,
                        caller_role: str, patient_id: str = "") -> dict:
        """Drug pricing — available to discharge coordinator and billing."""
        rbac_check(self.SERVER_NAME, "get_drug_price", caller_role, patient_id)
        drug = _find_drug_by_name(drug_name)
        if not drug:
            return {"found": False, "drug_name": drug_name}
        units = days_supply  # 1 tablet/dose per day simplified
        total = round(drug["price_per_unit_inr"] * units, 2)
        return {
            "generic_name": drug["generic_name"],
            "price_per_unit_inr": drug["price_per_unit_inr"],
            "days_supply": days_supply,
            "estimated_total_inr": total,
            "specialty_drug": drug.get("specialty_drug", False),
        }

    def submit_dispense_request(self, patient_id: str, drug_name: str,
                                 dose: str, frequency: str, days_supply: int,
                                 caller_role: str) -> dict:
        """Submit a dispense order — returns request ID."""
        rbac_check(self.SERVER_NAME, "submit_dispense_request", caller_role, patient_id)
        drug = _find_drug_by_name(drug_name)
        if not drug:
            return {"success": False, "error": f"Drug '{drug_name}' not in formulary"}
        if not drug["in_stock"]:
            return {
                "success": False,
                "error": f"{drug['generic_name']} is OUT OF STOCK.",
                "restock_eta_days": drug.get("restock_eta_days"),
                "alternative_available": bool(drug.get("alternative_drug_id")),
            }
        request_id = f"RX-{patient_id}-{drug['drug_id']}-{datetime.now().strftime('%Y%m%d%H%M')}"
        return {
            "success": True,
            "request_id": request_id,
            "patient_id": patient_id,
            "drug_dispensed": drug["generic_name"],
            "dose": dose,
            "frequency": frequency,
            "days_supply": days_supply,
            "dispense_timestamp": datetime.now(timezone.utc).isoformat(),
        }


# ─────────────────────────────────────────────────────────
# BILLING MCP SERVER
# ─────────────────────────────────────────────────────────

class BillingServer:
    """
    MCP Server — Hospital Billing
    Exposes: charge codes, invoice generation, insurance contract lookup.
    RBAC: billing_agent role CANNOT call EHR tools that return clinical text.
    """
    SERVER_NAME = "billing"

    def get_charge_codes(self, ward: str, caller_role: str) -> list[dict]:
        """Return applicable charge codes for a given ward."""
        rbac_check(self.SERVER_NAME, "read_charge_codes", caller_role)
        ward_map = {
            "Cardiology": "WRD-CARD", "Nephrology": "WRD-NEPH",
            "Rheumatology": "WRD-RHEU", "Oncology": "WRD-ONCO",
            "Neurology": "WRD-NEUR",
        }
        ward_code = ward_map.get(ward, "WRD-CARD")
        ward_rate = BILLING_RATES.get(ward_code, {})
        return [ward_rate, BILLING_RATES["INV-LAB"], BILLING_RATES["PRO-CONS"]]

    def get_insurance_contract(self, insurer_id: str, caller_role: str) -> dict:
        """Return insurance contract details."""
        rbac_check(self.SERVER_NAME, "read_insurance_contract", caller_role)
        contract = INSURANCE.get(insurer_id)
        if not contract:
            return {"error": f"Insurer '{insurer_id}' not found"}
        return contract

    def generate_invoice(self, patient_id: str, caller_role: str,
                          billing_safe_ehr: dict,
                          drug_costs: list[dict],
                          additional_charges: list[str] = None) -> dict:
        """
        Generate a discharge invoice.
        billing_safe_ehr must come from EHR.get_billing_safe_summary()
        — i.e., PHI must already be stripped.
        Drug costs are price-only, no clinical context.
        """
        rbac_check(self.SERVER_NAME, "generate_invoice", caller_role)

        # Verify PHI is stripped
        for phi_field in PHI_FIELDS:
            if phi_field in billing_safe_ehr:
                _log_telemetry("billing", "phi_leak_check", caller_role, patient_id,
                               False, phi_leak=True,
                               payload_summary=f"PHI field '{phi_field}' detected in billing payload — BLOCKED")
                raise PermissionError(
                    f"[PHI BOUNDARY VIOLATION] Field '{phi_field}' must not appear in billing payload. "
                    f"Use EHR.get_billing_safe_summary() to strip PHI before passing to billing."
                )

        ward = billing_safe_ehr.get("ward", "Unknown")
        los = billing_safe_ehr.get("los_days", 1)
        icd10_codes = billing_safe_ehr.get("diagnosis_icd10", [])

        # Ward charges
        ward_map = {"Cardiology": "WRD-CARD", "Nephrology": "WRD-NEPH",
                    "Rheumatology": "WRD-RHEU", "Oncology": "WRD-ONCO", "Neurology": "WRD-NEUR"}
        ward_code = ward_map.get(ward, "WRD-CARD")
        ward_rate = BILLING_RATES.get(ward_code, {}).get("rate_inr", 4000)
        ward_total = ward_rate * los

        # Lab charges
        lab_total = BILLING_RATES["INV-LAB"]["rate_inr"] * los

        # Drug costs (pass-through from pharmacy, no clinical context)
        drug_total = sum(d.get("estimated_total_inr", 0) for d in drug_costs)
        drug_specialty_fees = sum(
            BILLING_RATES["DRG-SPEC"]["rate_inr"]
            for d in drug_costs if d.get("specialty_drug")
        )

        subtotal = ward_total + lab_total + drug_total + drug_specialty_fees

        # Insurance
        insurance_info = PAT_INSURANCE.get(patient_id, {})
        insurer_id = insurance_info.get("insurer_id", "INS-BLUE")
        contract = INSURANCE.get(insurer_id, {})
        deductible = contract.get("deductible_inr", 5000)
        copay = contract.get("copay_inr", 500)
        max_covered = contract.get("max_covered_per_admission_inr", 300000)
        covered_amount = min(subtotal - deductible, max_covered)
        patient_liability = max(subtotal - covered_amount, deductible + copay)

        invoice = {
            "invoice_id": f"INV-{patient_id}-{datetime.now().strftime('%Y%m%d')}",
            "patient_id": patient_id,
            "insurer": contract.get("insurer_name", "Unknown"),
            "policy_number": insurance_info.get("policy_number", ""),
            "icd10_codes": icd10_codes,
            "los_days": los,
            "ward": ward,
            "line_items": [
                {"description": f"Ward charges ({ward}, {los} days)", "amount_inr": ward_total},
                {"description": "Laboratory services", "amount_inr": lab_total},
                {"description": "Drug dispensing", "amount_inr": drug_total},
                {"description": "Specialty drug handling fees", "amount_inr": drug_specialty_fees},
            ],
            "subtotal_inr": round(subtotal, 2),
            "deductible_inr": deductible,
            "insurance_covered_inr": round(covered_amount, 2),
            "patient_liability_inr": round(patient_liability, 2),
            "copay_inr": copay,
            "phi_verified_stripped": True,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }
        _log_telemetry("billing", "generate_invoice", caller_role, patient_id, True,
                       payload_summary=f"Invoice {invoice['invoice_id']} — ₹{subtotal:.0f}")
        return invoice


# ─────────────────────────────────────────────────────────
# FASTMCP WRAPPERS (optional — use when fastmcp is installed)
# ─────────────────────────────────────────────────────────

def try_fastmcp_servers():
    """
    Attempt to create FastMCP server instances.
    Falls back gracefully if fastmcp is not installed.
    """
    try:
        from fastmcp import FastMCP

        ehr_mcp = FastMCP("EHR-Server")
        pharmacy_mcp = FastMCP("Pharmacy-Server")
        billing_mcp = FastMCP("Billing-Server")

        _ehr = EHRServer()
        _ph  = PharmacyServer()
        _bl  = BillingServer()

        # ── EHR tools ──────────────────────────────────────
        @ehr_mcp.tool()
        def get_discharge_medications(patient_id: str, caller_role: str) -> dict:
            """Get discharge medication list from EHR."""
            return _ehr.get_discharge_medications(patient_id, caller_role)

        @ehr_mcp.tool()
        def get_diagnosis_codes(patient_id: str, caller_role: str) -> dict:
            """Get ICD-10 diagnosis codes — available to all roles."""
            return _ehr.get_diagnosis_codes(patient_id, caller_role)

        @ehr_mcp.tool()
        def get_billing_safe_summary(patient_id: str, caller_role: str) -> dict:
            """Get billing-safe patient summary (PHI stripped)."""
            return _ehr.get_billing_safe_summary(patient_id, caller_role)

        @ehr_mcp.tool()
        def get_patient_discharge_summary(patient_id: str, caller_role: str) -> dict:
            """Full discharge summary — clinical roles only."""
            return _ehr.get_patient_discharge_summary(patient_id, caller_role)

        # ── Pharmacy tools ─────────────────────────────────
        @pharmacy_mcp.tool()
        def check_stock(drug_name: str, dose: str, caller_role: str, patient_id: str = "") -> dict:
            """Check pharmacy stock for a drug."""
            return _ph.check_stock(drug_name, dose, caller_role, patient_id)

        @pharmacy_mcp.tool()
        def get_alternative(drug_name: str, caller_role: str, patient_id: str = "") -> dict:
            """Get formulary alternative for out-of-stock drug."""
            return _ph.get_alternative(drug_name, caller_role, patient_id)

        @pharmacy_mcp.tool()
        def get_drug_price(drug_name: str, days_supply: int, caller_role: str, patient_id: str = "") -> dict:
            """Get drug pricing."""
            return _ph.get_drug_price(drug_name, days_supply, caller_role, patient_id)

        @pharmacy_mcp.tool()
        def submit_dispense_request(patient_id: str, drug_name: str, dose: str,
                                     frequency: str, days_supply: int, caller_role: str) -> dict:
            """Submit a pharmacy dispense request."""
            return _ph.submit_dispense_request(patient_id, drug_name, dose, frequency, days_supply, caller_role)

        # ── Billing tools ──────────────────────────────────
        @billing_mcp.tool()
        def get_charge_codes(ward: str, caller_role: str) -> list:
            """Get applicable charge codes for a ward."""
            return _bl.get_charge_codes(ward, caller_role)

        @billing_mcp.tool()
        def get_insurance_contract(insurer_id: str, caller_role: str) -> dict:
            """Get insurance contract details."""
            return _bl.get_insurance_contract(insurer_id, caller_role)

        @billing_mcp.tool()
        def generate_invoice(patient_id: str, caller_role: str,
                              billing_safe_ehr: dict, drug_costs: list,
                              additional_charges: list = None) -> dict:
            """Generate discharge invoice (PHI must be pre-stripped)."""
            return _bl.generate_invoice(patient_id, caller_role, billing_safe_ehr, drug_costs, additional_charges)

        return ehr_mcp, pharmacy_mcp, billing_mcp, True

    except ImportError:
        logger.info("fastmcp not installed — using direct Python class interface (equivalent functionality)")
        return EHRServer(), PharmacyServer(), BillingServer(), False


def get_telemetry_log() -> list[dict]:
    return _TELEMETRY.copy()


def print_telemetry_summary():
    print("\n  MCP Telemetry Log:")
    for e in _TELEMETRY:
        icon = "✓" if e["allowed"] else "✗"
        phi = " ⚠PHI-BLOCKED" if e["phi_leak_detected"] else ""
        print(f"    [{e['timestamp'][11:19]}] {icon} [{e['server'].upper():8s}] "
              f"{e['tool']:35s} role={e['caller_role']}{phi}")


# ─────────────────────────────────────────────────────────
# CLI RUNNER (for running as actual HTTP servers)
# ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    import asyncio

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    arg = sys.argv[1] if len(sys.argv) > 1 else "--all"
    ehr_mcp, pharmacy_mcp, billing_mcp, is_fastmcp = try_fastmcp_servers()

    if is_fastmcp:
        if arg == "--server" and len(sys.argv) > 2:
            server_name = sys.argv[2]
            servers = {"ehr": (ehr_mcp, 8001), "pharmacy": (pharmacy_mcp, 8002), "billing": (billing_mcp, 8003)}
            if server_name in servers:
                srv, port = servers[server_name]
                print(f"Starting {server_name} MCP server on port {port}...")
                srv.run(transport="sse", host="0.0.0.0", port=port)
        else:
            print("Starting all 3 MCP servers...")
            import threading
            for srv, name, port in [(ehr_mcp, "EHR", 8001), (pharmacy_mcp, "Pharmacy", 8002), (billing_mcp, "Billing", 8003)]:
                t = threading.Thread(target=srv.run, kwargs={"transport": "sse", "host": "0.0.0.0", "port": port})
                t.daemon = True
                t.start()
                print(f"  ✓ {name} MCP server: http://localhost:{port}")
            print("\nAll servers running. Press Ctrl+C to stop.")
            try:
                import time; time.sleep(9999)
            except KeyboardInterrupt:
                print("Stopping servers.")
    else:
        print("FastMCP not installed. Server classes are available for direct use.")
        print("Install: pip install fastmcp")
        print("Direct usage: see discharge_agent.py")
