"""
MCPDischarge — Discharge Coordination Agent
=============================================
An autonomous agent that queries all three MCP servers
(EHR, Pharmacy, Billing) to fully automate patient discharge.

The agent uses MCP clients to:
  1. Pull discharge medications from EHR
  2. Check every drug against pharmacy inventory (handles name mismatches)
  3. Detect stock-outs, dose conflicts, controlled substances
  4. Get billing-safe summary from EHR (PHI stripped)
  5. Collect drug pricing from Pharmacy
  6. Generate discharge invoice via Billing

Traditional workflow: 4–6 manual handoffs across departments.
MCP workflow: single orchestration call, all cross-department queries automated.
"""

import json
import time
import logging
import hashlib
from typing import Optional
from pathlib import Path
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("DischargeAgent")

SRC_DIR  = Path(__file__).parent.parent
DATA_DIR = Path(__file__).parent.parent.parent / "data"

import sys
sys.path.insert(0, str(SRC_DIR / "servers"))
from mcp_servers import EHRServer, PharmacyServer, BillingServer, RBACError, get_telemetry_log

# MCP client instances (direct Python — equivalent to calling MCP over HTTP)
EHR_CLIENT      = EHRServer()
PHARMACY_CLIENT = PharmacyServer()
BILLING_CLIENT  = BillingServer()


# ─────────────────────────────────────────────────────────
# DATA INTEGRITY CHECKER
# ─────────────────────────────────────────────────────────

def semantic_drug_match_score(ehr_name: str, pharmacy_name: str) -> float:
    """
    Calculate semantic match score between EHR drug name and pharmacy name.
    Score 1.0 = identical, 0.0 = no match.
    Used to detect NAME_MISMATCH patterns.
    """
    ehr_lower = ehr_name.lower().strip()
    pharm_lower = pharmacy_name.lower().strip()
    if ehr_lower == pharm_lower:
        return 1.0
    if ehr_lower in pharm_lower or pharm_lower in ehr_lower:
        return 0.92
    # Word overlap
    ehr_words = set(ehr_lower.split())
    pharm_words = set(pharm_lower.split())
    overlap = len(ehr_words & pharm_words)
    if overlap > 0:
        return round(overlap / max(len(ehr_words), len(pharm_words)), 2)
    return 0.0


MATCH_THRESHOLD = 0.85  # below this → CONFLICT_ALERT


# ─────────────────────────────────────────────────────────
# DISCHARGE COORDINATION AGENT
# ─────────────────────────────────────────────────────────

class DischargeCoordinationAgent:
    """
    Orchestrates the full patient discharge workflow across 3 MCP servers.

    Roles used:
      discharge_coordinator — full access to EHR medications + billing summary
      billing_agent         — billing invoice only, no clinical notes
      pharmacy_agent        — pharmacy queries, no billing access
    """

    def __init__(self):
        self.role = "discharge_coordinator"
        self.tool_calls = []     # For metrics: track every MCP call
        self.start_time = None

    def _mcp_call(self, server: str, tool: str, **kwargs) -> dict:
        """
        Wrapper for every MCP tool call — logs timing and result for metrics.
        In production this would be an HTTP call to the MCP server endpoint.
        """
        t0 = time.time()
        try:
            result = self._dispatch(server, tool, **kwargs)
            latency = round((time.time() - t0) * 1000, 1)
            self.tool_calls.append({
                "server": server, "tool": tool, "success": True,
                "latency_ms": latency,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            logger.debug(f"  [MCP] {server}.{tool} → OK ({latency:.0f}ms)")
            return result
        except (RBACError, PermissionError) as e:
            latency = round((time.time() - t0) * 1000, 1)
            self.tool_calls.append({
                "server": server, "tool": tool, "success": False,
                "error": "RBAC_BLOCKED", "latency_ms": latency,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            logger.warning(f"  [MCP] {server}.{tool} → RBAC BLOCKED")
            raise
        except Exception as e:
            latency = round((time.time() - t0) * 1000, 1)
            self.tool_calls.append({
                "server": server, "tool": tool, "success": False,
                "error": str(e), "latency_ms": latency,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            raise

    def _dispatch(self, server: str, tool: str, **kwargs):
        if server == "ehr":
            return getattr(EHR_CLIENT, tool)(**kwargs)
        elif server == "pharmacy":
            return getattr(PHARMACY_CLIENT, tool)(**kwargs)
        elif server == "billing":
            return getattr(BILLING_CLIENT, tool)(**kwargs)
        raise ValueError(f"Unknown server: {server}")

    # ─────────────────────────────────────────────────────
    # STEP 1: GET MEDICATIONS FROM EHR
    # ─────────────────────────────────────────────────────

    def fetch_discharge_medications(self, patient_id: str) -> dict:
        """MCP call to EHR server — get medication list."""
        logger.info(f"  [Step 1] EHR.get_discharge_medications({patient_id})")
        return self._mcp_call("ehr", "get_discharge_medications",
                              patient_id=patient_id, caller_role=self.role)

    # ─────────────────────────────────────────────────────
    # STEP 2: CHECK ALL DRUGS AGAINST PHARMACY
    # ─────────────────────────────────────────────────────

    def check_all_medications(self, patient_id: str,
                               medications: list[dict]) -> list[dict]:
        """
        For each medication in EHR, call Pharmacy MCP server.
        Handles:
          - Brand name → generic name semantic matching
          - Out-of-stock detection + alternative lookup
          - Dose conflict alerts (DATA_DRIFT pattern)
          - Controlled substance flagging
        """
        results = []
        for med in medications:
            drug_name = med["drug_name"]
            dose = med["dose"]
            days_supply = med.get("days_supply", 30)

            logger.info(f"  [Step 2] Pharmacy.check_stock({drug_name} {dose})")

            # Stock check
            stock = self._mcp_call("pharmacy", "check_stock",
                                   drug_name=drug_name, dose=dose,
                                   caller_role=self.role, patient_id=patient_id)

            # Semantic match score
            if stock.get("found") and stock.get("generic_name"):
                match_score = semantic_drug_match_score(drug_name, stock["generic_name"])
            else:
                match_score = 0.0

            # Out-of-stock → get alternative
            alternative = None
            if stock.get("found") and not stock.get("in_stock"):
                logger.info(f"  [Step 2] Pharmacy.get_alternative({drug_name}) — OUT OF STOCK")
                alternative = self._mcp_call("pharmacy", "get_alternative",
                                             drug_name=drug_name, caller_role=self.role,
                                             patient_id=patient_id)

            # Pricing
            price = None
            if stock.get("found"):
                price = self._mcp_call("pharmacy", "get_drug_price",
                                       drug_name=drug_name, days_supply=days_supply,
                                       caller_role=self.role, patient_id=patient_id)

            results.append({
                "ehr_drug_name": drug_name,
                "ehr_dose": dose,
                "ehr_frequency": med.get("frequency"),
                "days_supply": days_supply,
                "pharmacy_result": stock,
                "match_score": match_score,
                "name_conflict": match_score < MATCH_THRESHOLD and stock.get("found"),
                "out_of_stock": stock.get("found") and not stock.get("in_stock"),
                "dose_conflict": stock.get("dose_conflict", False),
                "controlled_substance": stock.get("controlled_substance", False),
                "alternative": alternative,
                "pricing": price,
                "dispense_ready": (
                    stock.get("found") and
                    stock.get("in_stock") and
                    not stock.get("dose_conflict") and
                    not stock.get("controlled_substance")
                ),
            })
        return results

    # ─────────────────────────────────────────────────────
    # STEP 3: SUBMIT DISPENSE REQUESTS
    # ─────────────────────────────────────────────────────

    def submit_dispense_orders(self, patient_id: str,
                                pharmacy_results: list[dict]) -> list[dict]:
        """Submit dispense requests for all ready drugs."""
        dispense_results = []
        for pr in pharmacy_results:
            if pr["dispense_ready"]:
                logger.info(f"  [Step 3] Pharmacy.submit_dispense_request({pr['ehr_drug_name']})")
                result = self._mcp_call("pharmacy", "submit_dispense_request",
                                        patient_id=patient_id,
                                        drug_name=pr["ehr_drug_name"],
                                        dose=pr["ehr_dose"],
                                        frequency=pr["ehr_frequency"],
                                        days_supply=pr["days_supply"],
                                        caller_role=self.role)
                dispense_results.append({**result, "drug": pr["ehr_drug_name"]})
        return dispense_results

    # ─────────────────────────────────────────────────────
    # STEP 4: GET BILLING-SAFE EHR SUMMARY
    # ─────────────────────────────────────────────────────

    def fetch_billing_safe_summary(self, patient_id: str) -> dict:
        """
        Pull EHR summary with PHI stripped.
        This is the ONLY data that flows to the Billing server.
        Clinical notes, patient name, DOB, MRN are BLOCKED.
        """
        logger.info(f"  [Step 4] EHR.get_billing_safe_summary({patient_id}) — PHI stripped")
        return self._mcp_call("ehr", "get_billing_safe_summary",
                              patient_id=patient_id, caller_role=self.role)

    # ─────────────────────────────────────────────────────
    # STEP 5: GENERATE INVOICE
    # ─────────────────────────────────────────────────────

    def generate_discharge_invoice(self, patient_id: str,
                                    billing_safe_ehr: dict,
                                    pharmacy_results: list[dict]) -> dict:
        """
        Call Billing MCP server to generate invoice.
        Passes only: billing_safe EHR data + drug prices (no clinical context).
        """
        logger.info(f"  [Step 5] Billing.generate_invoice({patient_id})")
        # Extract drug costs only (no drug name clinical context for billing)
        drug_costs = [
            {
                "drug_name": pr["ehr_drug_name"],
                "estimated_total_inr": pr["pricing"]["estimated_total_inr"] if pr.get("pricing") else 0,
                "specialty_drug": pr["pharmacy_result"].get("specialty_drug", False),
            }
            for pr in pharmacy_results if pr.get("pricing")
        ]

        # Look up insurance for this patient
        from mcp_servers import PAT_INSURANCE
        insurance_info = PAT_INSURANCE.get(patient_id, {})
        insurer_id = insurance_info.get("insurer_id", "INS-BLUE")
        contract = self._mcp_call("billing", "get_insurance_contract",
                                   insurer_id=insurer_id, caller_role=self.role)

        invoice = self._mcp_call("billing", "generate_invoice",
                                  patient_id=patient_id, caller_role=self.role,
                                  billing_safe_ehr=billing_safe_ehr,
                                  drug_costs=drug_costs)
        return invoice

    # ─────────────────────────────────────────────────────
    # FULL ORCHESTRATION
    # ─────────────────────────────────────────────────────

    def orchestrate_discharge(self, patient_id: str) -> dict:
        """
        Run the complete discharge workflow across all 3 MCP servers.
        Returns a comprehensive discharge package.
        """
        self.start_time = time.time()
        self.tool_calls = []
        alerts = []
        conflicts = []

        logger.info(f"\n{'='*60}")
        logger.info(f"[Discharge Agent] Starting discharge: {patient_id}")

        # Step 1: Medications from EHR
        ehr_meds = self.fetch_discharge_medications(patient_id)
        medications = ehr_meds.get("discharge_medications", [])

        # Step 2: Pharmacy checks for all medications
        pharmacy_results = self.check_all_medications(patient_id, medications)

        # Collect alerts
        for pr in pharmacy_results:
            drug = pr["ehr_drug_name"]
            if pr["out_of_stock"]:
                alerts.append({
                    "type": "OUT_OF_STOCK",
                    "severity": "HIGH",
                    "drug": drug,
                    "message": f"{drug} is OUT OF STOCK. "
                               + (f"Alternative: {pr['alternative']['alternative_name']}"
                                  if pr.get("alternative") and pr["alternative"].get("alternative_name") else "No alternative available."),
                    "restock_eta": pr["pharmacy_result"].get("restock_eta_days"),
                })
            if pr["dose_conflict"]:
                conflicts.append({
                    "type": "DOSE_CONFLICT",
                    "severity": "HIGH",
                    "drug": drug,
                    "detail": pr["pharmacy_result"].get("dose_conflict_detail"),
                })
            if pr["name_conflict"]:
                alerts.append({
                    "type": "NAME_MISMATCH",
                    "severity": "MEDIUM",
                    "drug": drug,
                    "match_score": pr["match_score"],
                    "message": f"EHR name '{drug}' matched to pharmacy as "
                               f"'{pr['pharmacy_result'].get('generic_name')}' "
                               f"(score: {pr['match_score']:.0%}) — verify equivalence",
                })
            if pr["controlled_substance"]:
                alerts.append({
                    "type": "CONTROLLED_SUBSTANCE",
                    "severity": "MEDIUM",
                    "drug": drug,
                    "message": f"{drug} is a Schedule H controlled substance — special handling required",
                })

        # Step 3: Submit dispense orders for ready drugs
        dispense_orders = self.submit_dispense_orders(patient_id, pharmacy_results)

        # Step 4: Billing-safe EHR summary (PHI stripped)
        billing_safe = self.fetch_billing_safe_summary(patient_id)

        # Step 5: Generate invoice
        invoice = self.generate_discharge_invoice(patient_id, billing_safe, pharmacy_results)

        total_latency = round((time.time() - self.start_time) * 1000, 1)
        tool_call_count = len(self.tool_calls)
        success_count = sum(1 for t in self.tool_calls if t["success"])

        return {
            "patient_id": patient_id,
            "orchestration_complete": True,
            "total_latency_ms": total_latency,
            "mcp_tool_calls_total": tool_call_count,
            "mcp_tool_calls_success": success_count,
            "tool_call_success_rate": round(success_count / tool_call_count, 3) if tool_call_count else 0,
            "medications_count": len(medications),
            "dispense_orders_placed": len(dispense_orders),
            "alerts": alerts,
            "data_integrity_conflicts": conflicts,
            "dispense_orders": dispense_orders,
            "pharmacy_check_results": pharmacy_results,
            "billing_safe_ehr": billing_safe,
            "invoice": invoice,
            "tool_call_trace": self.tool_calls,
            "phi_boundary_enforced": True,
            "phi_blocked_fields": billing_safe.get("blocked_fields", []),
        }


# ─────────────────────────────────────────────────────────
# SCOPE VIOLATION TESTER
# ─────────────────────────────────────────────────────────

def test_scope_violation(patient_id: str = "PAT-006") -> dict:
    """
    Demonstrate that billing_agent CANNOT access clinical notes.
    Returns the RBAC error for observability/demo purposes.
    """
    results = {}
    # This should SUCCEED (billing-safe)
    try:
        safe = EHR_CLIENT.get_billing_safe_summary(patient_id, "billing_agent")
        results["billing_safe_summary"] = {"success": True, "fields": list(safe.keys())}
    except RBACError as e:
        results["billing_safe_summary"] = {"success": False, "error": str(e)}

    # This should FAIL — billing_agent cannot read clinical notes
    try:
        notes = EHR_CLIENT.get_patient_discharge_summary(patient_id, "billing_agent")
        results["clinical_notes"] = {"success": True, "ALERT": "PHI BOUNDARY VIOLATION — this should not succeed!"}
    except RBACError as e:
        results["clinical_notes"] = {"success": False, "rbac_blocked": True,
                                      "message": "RBAC correctly blocked billing_agent from reading clinical notes"}

    # This should FAIL — pharmacy cannot touch billing
    try:
        _ = BILLING_CLIENT.get_charge_codes("Cardiology", "pharmacy_agent")
        results["pharmacy_billing_access"] = {"success": True, "ALERT": "SCOPE VIOLATION — pharmacy should not access billing!"}
    except RBACError as e:
        results["pharmacy_billing_access"] = {"success": False, "rbac_blocked": True,
                                               "message": "RBAC correctly blocked pharmacy_agent from billing server"}

    return results


# ─────────────────────────────────────────────────────────
# METRICS COLLECTOR
# ─────────────────────────────────────────────────────────

class WorkflowMetrics:
    """Compare traditional manual workflow vs MCP-automated workflow."""

    TRADITIONAL_MANUAL_STEPS = {
        "nurse_reviews_discharge_note": 1,
        "transcribes_medications_to_form": 1,
        "calls_pharmacy_for_each_drug": 4,  # avg 4 drugs
        "waits_for_pharmacy_callback": 1,
        "manually_checks_stock": 4,
        "calls_billing_department": 1,
        "re-enters_data_into_billing_system": 1,
        "billing_calls_EHR_for_codes": 1,
        "pharmacy_confirms_dispense": 1,
        "total_manual_handoffs": 15,
        "avg_time_minutes": 45,
        "error_rate_pct": 18,  # studies show 15-20% medication errors in manual discharge
    }

    @staticmethod
    def compute(result: dict) -> dict:
        tool_calls = result["mcp_tool_calls_total"]
        latency_s = result["total_latency_ms"] / 1000
        return {
            "mcp_tool_calls": tool_calls,
            "mcp_latency_seconds": latency_s,
            "manual_handoffs_replaced": WorkflowMetrics.TRADITIONAL_MANUAL_STEPS["total_manual_handoffs"],
            "manual_steps_eliminated": WorkflowMetrics.TRADITIONAL_MANUAL_STEPS["total_manual_handoffs"] - tool_calls,
            "time_saved_minutes": WorkflowMetrics.TRADITIONAL_MANUAL_STEPS["avg_time_minutes"] - latency_s / 60,
            "tool_call_success_rate": result["tool_call_success_rate"],
            "data_integrity_conflicts_detected": len(result["data_integrity_conflicts"]),
            "stock_alerts": sum(1 for a in result["alerts"] if a["type"] == "OUT_OF_STOCK"),
            "phi_boundary_enforced": result["phi_boundary_enforced"],
        }


# ─────────────────────────────────────────────────────────
# QUICK TEST
# ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    patient_id = sys.argv[1] if len(sys.argv) > 1 else "PAT-001"

    agent = DischargeCoordinationAgent()
    result = agent.orchestrate_discharge(patient_id)

    print(f"\nDischarge Result — {patient_id}")
    print(f"  MCP calls: {result['mcp_tool_calls_total']} ({result['tool_call_success_rate']:.0%} success)")
    print(f"  Latency: {result['total_latency_ms']:.0f}ms")
    print(f"  Alerts: {len(result['alerts'])}")
    print(f"  Conflicts: {len(result['data_integrity_conflicts'])}")
    print(f"  Dispense orders placed: {result['dispense_orders_placed']}")
    print(f"  Invoice: ₹{result['invoice']['subtotal_inr']:,.0f}")
    print(f"  PHI blocked fields: {result['phi_blocked_fields']}")

    if result["alerts"]:
        print("\n  Alerts:")
        for a in result["alerts"]:
            print(f"    [{a['severity']}] {a['type']}: {a['message'][:80]}")
