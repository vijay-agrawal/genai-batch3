"""
MCPDischarge — Interactive Demo
================================
4 discharge scenarios showing MCP cross-department automation.
2 limitation scenarios showing architectural boundaries.

Usage:
  python demo.py                  # All 4 scenarios + 2 limitations
  python demo.py --scenario 1     # Single scenario (1-4)
  python demo.py --limitations    # Limitations only
"""

import sys, json, time, argparse, logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src" / "servers"))
sys.path.insert(0, str(Path(__file__).parent.parent / "src" / "agents"))
logging.disable(logging.WARNING)

from discharge_agent import DischargeCoordinationAgent, test_scope_violation, WorkflowMetrics
from mcp_servers import get_telemetry_log

class C:
    RED="\033[91m"; GREEN="\033[92m"; YELLOW="\033[93m"; CYAN="\033[96m"
    MAGENTA="\033[95m"; BOLD="\033[1m"; DIM="\033[2m"; RESET="\033[0m"; ORANGE="\033[33m"

def hdr(t): print(f"\n{C.BOLD}{C.CYAN}{'═'*65}\n  {t}{C.RESET}")
def sec(t): print(f"\n  {C.YELLOW}▶ {t}{C.RESET}")
def ok(t):  print(f"  {C.GREEN}✓{C.RESET} {t}")
def err(t): print(f"  {C.RED}✗{C.RESET} {t}")
def warn(t):print(f"  {C.YELLOW}⚠{C.RESET}  {t}")
def dim(t): print(f"  {C.DIM}{t}{C.RESET}")


SCENARIOS = [
    {
        "num": 1,
        "patient_id": "PAT-001",
        "title": "HFrEF Discharge — Stock-Out + Brand/Generic Name Mismatch",
        "patient": "Arjun Mehta, 67M, Cardiology",
        "challenge": "NAME_MISMATCH + OUT_OF_STOCK",
        "teaching": (
            "EHR prescribes 'Dapagliflozin' (matches Pharmacy generic — OK). "
            "EHR prescribes 'Furosemide 40mg OD' — OUT OF STOCK in Pharmacy. "
            "MCP agent automatically detects stock-out and surfaces Torsemide 10mg as equivalent. "
            "PHI boundary: billing receives ICD-10 codes + LOS only — name/DOB/MRN blocked."
        ),
        "traditional_failure": "Nurse phones pharmacy. Pharmacy calls back 2 hours later. Discharge delayed.",
    },
    {
        "num": 2,
        "patient_id": "PAT-003",
        "title": "RA Discharge — Biologic Out-of-Stock + Biosimilar Substitution",
        "patient": "Meera Krishnan, 48F, Rheumatology",
        "challenge": "OUT_OF_STOCK + NAME_MISMATCH",
        "teaching": (
            "EHR prescribes 'Humira 40mg SC q2w' (brand name). "
            "Pharmacy has no Humira — but MCP agent matches 'Humira' → 'Adalimumab' → "
            "finds biosimilar Exemptia (40mg, in stock, 30% cheaper). "
            "Prescriber approval flag raised automatically. "
            "Traditional: pharmacist would need to call rheumatologist, re-prescribe, re-document."
        ),
        "traditional_failure": "Humira stock-out discovered at discharge counter. Patient waits while pharmacist hunts for alternative.",
    },
    {
        "num": 3,
        "patient_id": "PAT-006",
        "title": "MS Discharge — RBAC Scope Violation Blocked (Modafinil + Billing)",
        "patient": "Sunita Rao, 38F, Neurology",
        "challenge": "SCOPE_VIOLATION",
        "teaching": (
            "Modafinil is a Schedule H controlled substance. "
            "Billing agent role is NOT authorised to read controlled substance prescription details. "
            "MCP RBAC blocks billing_agent from calling EHR.get_discharge_medications(). "
            "Billing only receives: ward charges, ICD-10 code (G35), LOS=2 — no drug details. "
            "Traditional: same billing clerk who processes the invoice can see the full prescription — "
            "creates unnecessary access to sensitive medication information."
        ),
        "traditional_failure": "Billing department sees full medication list including controlled substances — data minimisation principle violated.",
    },
    {
        "num": 4,
        "patient_id": "PAT-002",
        "title": "AKI Discharge — Dose Conflict Alert (Semaglutide Starter vs Maintenance)",
        "patient": "Fatima Sheikh, 68F, Nephrology",
        "challenge": "DATA_DRIFT",
        "teaching": (
            "EHR prescribes Semaglutide 0.5mg SC weekly (maintenance dose). "
            "Pharmacy formulary standard: start at 0.25mg weekly × 4 weeks, then escalate. "
            "MCP Pharmacy server detects DOSE CONFLICT: prescribes 0.5mg vs standard 0.25mg starter. "
            "Alert raised: clinical review required before dispensing. "
            "Traditional: pharmacist may dispense prescribed dose without formulary cross-check, "
            "or the escalation protocol may be unknown to the discharging ward."
        ),
        "traditional_failure": "Maintenance dose dispensed without starter escalation — patient experiences more side effects.",
    },
]

LIMITATIONS = [
    {
        "title": "Real-Time EHR Update Lag — MCP Reads Stale Discharge Note",
        "scenario": (
            "A senior consultant updates the discharge medications 30 minutes before discharge "
            "— removes one drug and adds a new one. The MCP agent ran its discharge orchestration "
            "20 minutes earlier and cached the medication list. The Pharmacy dispense order was "
            "already submitted for the old medication list."
        ),
        "limitation": (
            "MCP servers serve point-in-time data. If the EHR record is updated AFTER the agent "
            "runs its orchestration, the downstream pharmacy and billing actions are based on "
            "stale data. The agent has no push-notification mechanism from the EHR — it relies "
            "on polling or event triggers that are not built into this architecture."
        ),
        "mitigations": [
            "EHR change event webhook: trigger agent re-run on any discharge note update",
            "Idempotent dispense requests: pharmacy can receive updated orders and reconcile",
            "Discharge 'lock' workflow: agent runs only after physician clicks 'finalise discharge'",
            "LangGraph interrupt(): pause agent at pharmacy step and wait for 'discharge_finalised' event",
        ],
    },
    {
        "title": "Semantic Mismatch Below Confidence Threshold — Drug Not Found",
        "scenario": (
            "A physician writes 'Vildagliptin 50mg' in the discharge note using an abbreviated "
            "trade name common in India. The Pharmacy MCP server's semantic alias table does not "
            "include this particular spelling variant. The agent returns drug_found=False. "
            "The dispense order is not placed. Patient leaves without the medication."
        ),
        "limitation": (
            "The pharmacy semantic alias lookup is only as complete as the alias table. "
            "Drug names vary by region (US brand vs Indian brand vs INN), abbreviation conventions, "
            "and spell variants. A drug not in the alias table returns 'not found' — "
            "a false negative that is clinically dangerous. The agent has no fallback to human "
            "pharmacist escalation in this version."
        ),
        "mitigations": [
            "Continuous alias table enrichment: mine EHR prescription logs for drug name variants",
            "LLM-powered fuzzy match: use embedding similarity for drug names not in alias table",
            "Not-found escalation: any drug_found=False automatically creates a human pharmacist task",
            "WHO INN normalisation: standardise all drug names to WHO International Nonproprietary Names at ingestion",
        ],
    },
]


def run_scenario(s: dict, agent: DischargeCoordinationAgent):
    hdr(f"SCENARIO {s['num']}: {s['title']}")
    print(f"  Patient   : {s['patient']}")
    print(f"  Challenge : {C.YELLOW}[{s['challenge']}]{C.RESET}")
    print()

    sec("Traditional Manual Workflow Problem")
    dim(s["traditional_failure"])

    sec("MCP Agent Running (cross-department queries)...")
    t0 = time.time()
    steps = [
        "EHR.get_discharge_medications()",
        "Pharmacy.check_stock() × N drugs",
        "Pharmacy.get_alternative() [if out of stock]",
        "Pharmacy.get_drug_price() × N drugs",
        "Pharmacy.submit_dispense_request() [if in stock]",
        "EHR.get_billing_safe_summary()  [PHI stripped]",
        "Billing.get_insurance_contract()",
        "Billing.generate_invoice()",
    ]
    for step in steps:
        time.sleep(0.04)
        print(f"  {C.DIM}  [{step:55s}]{C.RESET}")

    result = agent.orchestrate_discharge(s["patient_id"])
    elapsed = round((time.time() - t0) * 1000, 0)

    sec("Results")
    print(f"  MCP calls    : {result['mcp_tool_calls_total']} ({result['tool_call_success_rate']:.0%} success)")
    print(f"  Total latency: {elapsed:.0f}ms  (vs ~45 minutes manually)")
    print(f"  PHI blocked  : {result['phi_blocked_fields']}")
    print(f"  Invoice      : ₹{result['invoice']['subtotal_inr']:,.0f}  (patient liability: ₹{result['invoice']['patient_liability_inr']:,.0f})")

    if result["alerts"]:
        print()
        sec("Alerts Raised by MCP Agent")
        for a in result["alerts"]:
            icon = f"{C.RED}🔴{C.RESET}" if a["severity"]=="HIGH" else f"{C.YELLOW}🟡{C.RESET}"
            print(f"  {icon} [{a['type']}] {a['message'][:120]}")

    if result["data_integrity_conflicts"]:
        sec("Data Integrity Conflicts")
        for c in result["data_integrity_conflicts"]:
            err(f"[{c['type']}] {c['detail'][:120]}")

    # RBAC demonstration for scenario 3
    if s["num"] == 3:
        sec("RBAC Scope Violation Test (billing_agent tries to read clinical notes)")
        rbac_results = test_scope_violation(s["patient_id"])
        for test_name, outcome in rbac_results.items():
            if outcome.get("rbac_blocked"):
                ok(f"RBAC correctly BLOCKED: billing_agent → {test_name}")
            elif outcome.get("success"):
                print(f"  ✓ ALLOWED: {test_name} (safe fields: {list(outcome.get('fields',[]))[:5]})")
            else:
                warn(f"{test_name}: {outcome}")

    print()
    print(f"  {C.BOLD}Teaching Point:{C.RESET}")
    for line in s["teaching"].split(". "):
        if line.strip(): dim(line.strip() + ".")


def run_limitations():
    hdr("HONEST LIMITATION DISCLOSURES")
    for i, lim in enumerate(LIMITATIONS, 1):
        print(f"\n{'─'*65}")
        print(f"  {C.BOLD}{C.YELLOW}LIMITATION {i}: {lim['title']}{C.RESET}\n")
        print(f"  {C.BOLD}Scenario:{C.RESET}")
        for sent in lim["scenario"].split(". "):
            if sent.strip(): dim(sent.strip() + ".")
        print(f"\n  {C.RED}{C.BOLD}Why it fails:{C.RESET}")
        for sent in lim["limitation"].split(". "):
            if sent.strip(): print(f"    {C.RED}·{C.RESET} {sent.strip()}.")
        print(f"\n  {C.GREEN}Mitigations:{C.RESET}")
        for m in lim["mitigations"]:
            ok(m)
    print(f"\n{'═'*65}")
    dim("MCP standardises cross-department tool calls and enforces RBAC.")
    dim("It does NOT solve data freshness or semantic alias completeness — those require operational controls.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", type=int, choices=[1,2,3,4])
    parser.add_argument("--limitations", action="store_true")
    args = parser.parse_args()

    print(f"\n{C.BOLD}{C.CYAN}")
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║   MCPDischarge — Cross-Department MCP Interoperability       ║")
    print("║   EHR × Pharmacy × Billing  |  RBAC × PHI Boundary          ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print(C.RESET)

    if args.limitations:
        run_limitations(); return

    agent = DischargeCoordinationAgent()

    if args.scenario:
        s = next(x for x in SCENARIOS if x["num"] == args.scenario)
        run_scenario(s, agent)
    else:
        for s in SCENARIOS:
            print(f"\n{'█'*65}")
            run_scenario(s, agent)
            time.sleep(0.1)
        print(f"\n{'█'*65}")
        run_limitations()
        print(f"\n\n{'═'*65}")
        print(f"  {C.BOLD}DEMO SUMMARY{C.RESET}")
        ok("Scenario 1: Stock-out + name mismatch detected automatically (Furosemide → Torsemide)")
        ok("Scenario 2: Biosimilar substitution surfaced (Humira → Exemptia, 30% cheaper)")
        ok("Scenario 3: RBAC blocked billing from reading controlled substance details")
        ok("Scenario 4: Dose conflict alert for Semaglutide (0.5mg vs formulary 0.25mg starter)")
        print()
        warn("Limitation 1: EHR update after agent run → stale dispense orders")
        warn("Limitation 2: Drug alias gaps → drug_found=False for regional brand names")
        print()

if __name__ == "__main__":
    main()
