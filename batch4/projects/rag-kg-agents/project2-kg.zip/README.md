# MedKG Navigator
### Knowledge Graph × GraphRAG × Hybrid Retrieval for Clinical Trial Matching
**CitiusTech Gen AI & Agentic AI Training — Project 2**

---

## The Problem Pure Vector RAG Cannot Solve

Matching a patient to a clinical trial requires understanding **relational constraints** that embedding similarity fundamentally cannot express:

```
Query: "Find NSCLC trials in Maharashtra for a patient without the EGFR mutation"
```

A vector search on trial documents retrieves the top matches by semantic similarity to "NSCLC EGFR Maharashtra". Both of these trials score high:

| Trial | Title | Vector Score |
|-------|-------|-------------|
| **T001** | Pembrolizumab for EGFR Wild-Type NSCLC | 0.91 ← **CORRECT** |
| **T002** | Osimertinib for EGFR Exon 19 Deletion | 0.89 ← **WRONG — patient is EXCLUDED** |

The vector model has no concept of "patient must NOT have this biomarker." The graph does.

---

## Learning Architecture

```
Naive Vector  →  Synonym Expanded  →  Graph Only  →  Hybrid  →  Graph-RAG  →  + NeMo Guards
  F1: 0.11         F1: 0.17             F1: 0.59      F1: 0.75    F1: 0.79       F1: 0.82
  FP: 4.8          FP: 4.5              FP: 0.1       FP: 0.0     FP: 0.0        FP: 0.0
```

Each stage is motivated by a **measurable failure mode** in the previous one.

---

## Knowledge Graph Schema

```
(Patient)-[:HAS_DISEASE]--------→(Disease)
(Disease)-[:HAS_BIOMARKER]------→(Biomarker)
(Drug)-[:TREATS]-----------------→(Disease)
(Drug)-[:TARGETS]----------------→(Biomarker)

(Trial)-[:STUDIES_DISEASE]-------→(Disease)
(Trial)-[:REQUIRES_BIOMARKER]----→(Biomarker)   ← Patient MUST have this
(Trial)-[:EXCLUDES_BIOMARKER]----→(Biomarker)   ← Patient MUST NOT have this (**key**)
(Trial)-[:REQUIRES_PRIOR_DRUG]---→(Drug)
(Trial)-[:EXCLUDES_PRIOR_DRUG]---→(Drug)
(Trial)-[:HAS_SITE]--------------→(Site)

(Patient)-[:HAS_BIOMARKER]-------→(Biomarker)
(Patient)-[:RECEIVED_DRUG]-------→(Drug)
```

The critical insight: `REQUIRES_BIOMARKER` and `EXCLUDES_BIOMARKER` are **typed edges** — something a text embedding cannot distinguish. This single architectural decision is what makes Graph-RAG mandatory for clinical matching.

---

## Project Structure

```
medkg_pro/
├── data/
│   ├── generate_kg_dataset.py     ← Run this first
│   ├── diseases.json              ← 20 disease nodes
│   ├── biomarkers.json            ← 30 biomarker nodes
│   ├── drugs.json                 ← 25 drug nodes
│   ├── sites.json                 ← 20 sites (8 in Maharashtra)
│   ├── trials.json                ← 30 clinical trial nodes + relationships
│   ├── patient_profiles.json      ← 10 synthetic patient profiles
│   ├── eval_qa_pairs.json         ← 30 labeled evaluation questions
│   └── graph_schema.json          ← Cypher templates and schema reference
│
├── src/
│   ├── graph_builder.py           ← Neo4j KG construction + MockGraph
│   └── hybrid_retrieval.py        ← All 6 retrieval stages + evaluation
│
├── evaluation/
│   ├── eval_dashboard.py          ← Metrics visualization
│   ├── eval_results.csv           ← Benchmark results
│   └── *.png                      ← Generated charts
│
├── demo/
│   └── demo_queries.py            ← 5 capability demos + 2 limitation disclosures
│
├── configs/
│   └── guardrails_config.co       ← NeMo Guardrails colang config
│
└── README.md
```

---

## Quick Start

### Step 1: Generate the Dataset

```bash
cd data/
python generate_kg_dataset.py
```

Expected output:
```
✓ diseases.json    — 20 Disease nodes
✓ biomarkers.json  — 30 Biomarker nodes (EGFR, ALK, KRAS G12C, BRCA1/2, PD-L1, ...)
✓ drugs.json       — 25 Drug nodes (osimertinib, pembrolizumab, tafamidis, ...)
✓ sites.json       — 20 Sites (8 in Maharashtra: Tata Memorial, KEM, Ruby Hall, ...)
✓ trials.json      — 30 Trial nodes with full eligibility criteria
Total graph nodes: 125
```

### Step 2: Build the Knowledge Graph

**Option A: Neo4j (full functionality)**
```bash
# Start Neo4j Desktop or AuraDB
export NEO4J_URI=bolt://localhost:7687
export NEO4J_USER=neo4j
export NEO4J_PASSWORD=your-password

pip install neo4j
cd src/
python graph_builder.py
```

**Option B: MockGraph (no Neo4j needed — for initial exercises)**
```bash
cd src/
python graph_builder.py --mock
```

### Step 3: Run the Evaluation

```bash
cd src/
python hybrid_retrieval.py --eval
```

### Step 4: Generate Visualizations

```bash
cd evaluation/
python eval_dashboard.py --demo
```

### Step 5: Run the Demo

```bash
cd demo/
python demo_queries.py              # All 7 questions
python demo_queries.py --question 1 # Just Q1: NSCLC + EGFR negation
python demo_queries.py --compare    # Naive vs Hybrid side-by-side
```

---

## Injected Challenges (Dataset Design)

The dataset is **deliberately engineered** to expose the failure modes of pure vector search:

| Challenge | Trials | Biomarkers | What It Exposes |
|-----------|--------|-----------|-----------------|
| `[NEGATION]` | T001, T002, T006, T014, T018, T028 | BM001-BM003, BM007-BM008 | Patient must NOT have a biomarker — vectors cannot distinguish presence/absence |
| `[BIOMARKER-COMBO]` | T003, T006, T007, T008, T017, T018 | BM014-BM017, BM028 | AND logic across 3+ simultaneous biomarkers — vectors do OR-like fuzzy match |
| `[DRUG-CONFLICT]` | T010, T013, T020, T024 | — | REQUIRES vs EXCLUDES prior drug — both look similar in text |
| `[MULTI-HOP]` | T004, T009, T020, T021 | BM018, BM022, BM027 | 4+ hop traversal needed for rare disease subtypes |
| `[TEMPORAL]` | T005, T011, T022 | — | Status = Active_not_recruiting / Completed — vector ignores trial status |
| `[GEOGRAPHIC]` | T001, T007, T016 | — | Maharashtra site filter — not computable from semantic similarity |
| `[SYNONYM]` | D001, D002, D009 | — | NSCLC vs Non-Small Cell Lung Cancer — alias resolution |

### The Critical NEGATION Pattern

Trial T001 includes: `"EGFR wild-type confirmed. No known EGFR sensitizing mutations."`
Trial T002 includes: `"EGFR exon 19 deletion confirmed."`

A patient **with EGFR del19** must go to T002, not T001. But both trials contain dense EGFR text. Vector similarity returns both. The graph's `EXCLUDES_BIOMARKER` edge on T001 is the definitive filter.

---

## The Six Retrieval Stages

### Stage 0: Naive Vector RAG
```python
results = embed_store.query(question, top_k=5)
```
Semantic similarity only. Returns trials based on text overlap with query.
**Fatal flaw**: Cannot distinguish REQUIRES from EXCLUDES biomarker edges.
**F1: ~0.11 | False Positives: ~4.8 per query**

### Stage 1: Synonym-Expanded Vector
```python
expanded_q = expand_query(question)  # "NSCLC" → "Non-Small Cell Lung Cancer EGFR..."
results = embed_store.query(expanded_q, top_k=5)
```
Improves recall for medical abbreviations. Still cannot enforce negation.
**F1: ~0.17 | False Positives: ~4.5 per query**

### Stage 2: Graph-Only (Pure Cypher)
```cypher
MATCH (t:Trial)-[:STUDIES_DISEASE]->(d:Disease {id: $disease_id})
WHERE t.status = 'Recruiting'
  AND ALL(b IN $required_biomarkers WHERE (t)-[:REQUIRES_BIOMARKER]->(:Biomarker {id: b}))
  AND NONE(b IN $patient_biomarkers WHERE (t)-[:EXCLUDES_BIOMARKER]->(:Biomarker {id: b}))
MATCH (t)-[:HAS_SITE]->(s:Site {state: $state})
RETURN t, collect(s) as sites
```
Exact relational matching. Hard negation enforced. Geographic precision.
**F1: ~0.59 | False Positives: ~0.1 per query**

### Stage 3: Hybrid Graph + Vector
```python
# Step 1: Graph — hard eligibility filter (gates out impossible trials)
graph_candidates = graph.match_patient_to_trials(...)

# Step 2: Vector — re-rank candidates by semantic relevance to text criteria
vector_scores = embed_store.query(expanded_query, top_k=20)

# Step 3: Fuse — combined score = 0.6 × graph_confidence + 0.4 × vector_similarity
# Only trials that passed the graph filter are returned
```
Best of both: graph handles logic, vector handles nuanced text matching.
**F1: ~0.75 | False Positives: ~0.0**

### Stage 4: Graph-RAG (with LLM Synthesis)
Graph-filtered results + unstructured protocol text → LLM generates cited assessment with confidence tier.
**F1: ~0.79 | Adds: citation grounding, confidence tiers, NEXT STEP guidance**

### Stage 5: Graph-RAG + NeMo Guardrails
Post-hoc safety layer:
- Rejects closed/completed trial recommendations
- Blocks off-label treatment suggestions
- Enforces mandatory physician disclaimer
**F1: ~0.82 | Eliminates: temporal contamination, overconfident claims**

---

## Evaluation Metrics

| Metric | Definition | Clinical Relevance |
|--------|-----------|-------------------|
| Precision | Fraction of returned trials the patient is eligible for | False positives send patients to wrong trials |
| Recall | Fraction of eligible trials that were found | False negatives cause missed opportunities |
| F1 | Harmonic mean of P and R | Overall matching quality |
| False Positives | Trials returned where patient is excluded | Clinically dangerous — patients may pursue ineligible trials |

**The critical metric is False Positives.** A patient who pursues an ineligible trial wastes time, money, and may delay accessing a trial they ARE eligible for.

### Graph-RAG Confidence Score

```python
confidence = (
    0.7 × biomarker_match_completeness
  + 0.15 × (1 / graph_hop_distance)
  + 0.15 × geographic_proximity_bonus
)
```

HIGH confidence (>0.8): All graph criteria exactly met, nearby site, ≤2 hops
MEDIUM (0.6–0.8): Most criteria met, some inferred from text
LOW (<0.6): Partial match, long hop path, or text-only inference

---

## Neo4j Setup (For Full Graph Functionality)

### AuraDB Free Tier (Cloud — No Installation)

```bash
# 1. Create free account at: https://neo4j.com/cloud/platform/aura-graph-database/
# 2. Spin up a free AuraDB instance
# 3. Download credentials file
# 4. Set environment variables:
export NEO4J_URI="neo4j+s://xxxxxxxx.databases.neo4j.io"
export NEO4J_USER="neo4j"
export NEO4J_PASSWORD="your-aura-password"
```

### Neo4j Desktop (Local)

```bash
# Download: https://neo4j.com/download/
# Create a project, start a database
# Default: bolt://localhost:7687
```

### Useful Cypher Queries to Try

```cypher
-- All Maharashtra sites with their specialties
MATCH (s:Site {state:'Maharashtra'})
RETURN s.name, s.city, s.specialties

-- Which trials exclude EGFR-mutant patients?
MATCH (t:Trial)-[:EXCLUDES_BIOMARKER]->(b:Biomarker)
WHERE b.name CONTAINS 'EGFR'
RETURN t.id, t.title, collect(b.name) as excluded_biomarkers

-- Multi-hop: Disease → Biomarker → Trial → Site
MATCH path = (d:Disease {name:'Non-Small Cell Lung Cancer'})
    -[:HAS_BIOMARKER]->(b:Biomarker {name:'EGFR Wild-Type'})
    <-[:REQUIRES_BIOMARKER]-(t:Trial {status:'Recruiting'})
    -[:HAS_SITE]->(s:Site {state:'Maharashtra'})
RETURN d.name, b.name, t.title, s.name, length(path) as hops

-- Confidence score calculation
MATCH path = (d:Disease {id:'D001'})-[:HAS_BIOMARKER]->(b:Biomarker)
    <-[:REQUIRES_BIOMARKER]-(t:Trial)-[:HAS_SITE]->(s:Site)
WHERE t.status = 'Recruiting'
RETURN t.id, length(path) as hops, 1.0/(1+length(path)) as confidence_component
ORDER BY confidence_component DESC
```

---

## Guardrails Integration


Implement any GuardRails mechanism such as Nemo Guardrails or Azure Foundry

### Nemo Guardrails

### Colang Configuration

```colang
# configs/guardrails/main.co

define user ask off-label recommendation
  "use this drug outside trial"
  "recommend off-label"
  "compassionate use"

define user ask closed trial
  "join trial" "this trial is open"

define bot refuse off-label
  "I can only match patients to approved clinical trials. Off-label 
   recommendations require explicit physician authorization."

define bot add disclaimer
  "All eligibility determinations must be verified by a Clinical Research 
   Coordinator reviewing the complete current protocol."

define flow
  user ask off-label recommendation
  bot refuse off-label

define flow process recommendation
  bot add disclaimer
```

### Python Integration

```python
from nemoguardrails import RailsConfig, LLMRails

config = RailsConfig.from_path("configs/guardrails/")
rails = LLMRails(config)

response = await rails.generate_async(
    messages=[{"role": "user", "content": patient_query}]
)
```

---

## Demo Questions Summary

| # | Question Type | Challenge | Key Insight |
|---|---------------|-----------|-------------|
| 1 | NSCLC + EGFR negation in Maharashtra | NEGATION + GEOGRAPHIC | Graph excludes T002; vector returns it as FP |
| 2 | TNBC triple biomarker AND logic | BIOMARKER-COMBO | Graph enforces 3 simultaneous conditions |
| 3 | RA dual drug constraint (required + excluded) | DRUG-CONFLICT | Graph distinguishes REQUIRES vs EXCLUDES prior drug |
| 4 | ATTR amyloidosis 4-hop traversal | MULTI-HOP + RARE | Confidence = f(hop distance); rare entity no problem |
| 5 | ALK+ trial status filtering | TEMPORAL | Answer is "zero eligible" — vector returns closed trial |
| 6 ⚠ | ECOG borderline (improving patient) | **LIMITATION** | Graph cannot model clinical trajectories |
| 7 ⚠ | Novel PTPRD-ALK fusion | **LIMITATION** | KG coverage gap — novel entities invisible to graph |

---

## Demo Notes

### The Conversation to Have

**Ask after Stage 0 (naive vector):** *"This patient has EGFR del19. Why is T001 dangerous to return?"*
→ Expected insight: T001 explicitly excludes EGFR-mutant patients. Returning it wastes the patient's time and may crowd out the correct trial.

**Ask after Stage 2 (graph only):** *"What does Graph-Only miss that the text captures?"*
→ Expected insight: Eligibility nuances in free text (e.g., "patients with stable, treated brain metastases may be eligible at investigator discretion") are not in the graph edges.

**Ask after Stage 3 (hybrid):** *"Why is F1 still not 1.0?"*
→ Expected insight: Evaluation QA pairs include multi-hop questions where path length limits confidence; some trials have site IDs that don't exist in Maharashtra even though the disease matches.

**The key demonstration:** Show Q1 (NSCLC EGFR WT Maharashtra) in verbose mode. Print the vector scores for T001 AND T002. Both are >0.85. Then run graph traversal — T002 disappears immediately. This is the "aha" moment.


## References

- [Neo4j AuraDB Free Tier](https://neo4j.com/cloud/platform/aura-graph-database/)
- [Microsoft GraphRAG](https://github.com/microsoft/graphrag)
- [NVIDIA NeMo Guardrails](https://github.com/NVIDIA/NeMo-Guardrails)
- [LangChain Neo4j Integration](https://python.langchain.com/docs/integrations/graphs/neo4j_cypher)
- [ClinicalTrials.gov API](https://clinicaltrials.gov/data-api/api)
- [UMLS Clinical Entity Ontology](https://uts.nlm.nih.gov/)
- [LangGraph for Multi-Agent Orchestration](https://langchain-ai.github.io/langgraph/)

---

*CitiusTech Gen AI & Agentic AI Training Program —  Project 2 of 5*
