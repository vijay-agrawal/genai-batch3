"""
MedKG Navigator — Interactive Demo Script
==========================================
5 questions that showcase the system's capabilities,
2 questions that honestly expose its limitations.

Run:
  python demo_queries.py              # All 7 questions, text output
  python demo_queries.py --question 1 # Single question
  python demo_queries.py --compare    # Show naive vs hybrid side-by-side
"""

import sys
import json
import time
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from graph_builder import MockGraph
from hybrid_retrieval import ProgressivePipeline, expand_query

DATA_DIR = Path(__file__).parent.parent / "data"

# ─────────────────────────────────────────────────────────
# COLOUR CODES
# ─────────────────────────────────────────────────────────

class C:
    RED    = "\033[91m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    BLUE   = "\033[94m"
    CYAN   = "\033[96m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    RESET  = "\033[0m"

def header(text): print(f"\n{C.BOLD}{C.CYAN}{'='*65}{C.RESET}")
def section(text): print(f"\n{C.BOLD}{C.YELLOW}{text}{C.RESET}")
def success(text): print(f"  {C.GREEN}✓{C.RESET} {text}")
def warning(text): print(f"  {C.YELLOW}⚠{C.RESET}  {text}")
def error(text):   print(f"  {C.RED}✗{C.RESET} {text}")
def info(text):    print(f"  {C.DIM}{text}{C.RESET}")


# ─────────────────────────────────────────────────────────
# DEMO QUESTIONS
# ─────────────────────────────────────────────────────────

DEMO_QUESTIONS = [

    # ════════════════════════════════════════════════════
    # Q1: FLAGSHIP — NEGATION + GEOGRAPHIC
    # Shows the core graph advantage: biomarker negation
    # ════════════════════════════════════════════════════
    {
        "num": 1,
        "title": "NSCLC + EGFR Negation + Maharashtra Filter",
        "insight": "Why Graph > Vector: negation of biomarker presence",
        "question": (
            "Find all currently RECRUITING clinical trials in Maharashtra for a "
            "58-year-old male with Non-Small Cell Lung Cancer (NSCLC) who is "
            "EGFR wild-type (does NOT have the EGFR mutation). He is treatment-naive."
        ),
        "patient_id": "P001",
        "challenge_type": "NEGATION + GEOGRAPHIC",
        "ground_truth_trials": ["T001", "T018", "T028"],
        "ground_truth_excluded": ["T002", "T005"],
        "key_teaching_point": (
            "Trial T002 (EGFR del19 trial) must be EXCLUDED even though it discusses NSCLC+EGFR at length. "
            "Trial T005 (ALK trial) must be EXCLUDED because it is 'Active_not_recruiting'. "
            "Naive vector search returns T002 because 'NSCLC EGFR' text is semantically similar. "
            "The graph EXCLUDES_BIOMARKER edge is the only way to enforce this correctly."
        ),
    },

    # ════════════════════════════════════════════════════
    # Q2: COMPOUND BIOMARKER LOGIC (AND across 3 markers)
    # ════════════════════════════════════════════════════
    {
        "num": 2,
        "title": "TNBC Triple Biomarker AND Logic",
        "insight": "Why Graph > Vector: AND logic across multiple biomarkers",
        "question": (
            "Which clinical trials accept a 42-year-old female with newly diagnosed "
            "Triple Negative Breast Cancer (TNBC) who is HER2-negative, ER-negative, PR-negative, "
            "AND has a germline BRCA1 mutation? She is treatment-naive in Chennai, Tamil Nadu."
        ),
        "patient_id": "P004",
        "challenge_type": "BIOMARKER-COMBO",
        "ground_truth_trials": ["T006"],
        "ground_truth_excluded": ["T012"],
        "key_teaching_point": (
            "T006 requires all THREE simultaneously: HER2- AND ER/PR- AND BRCA1/2 mutation. "
            "T012 requires BRCA but excludes prior PARP inhibitors. "
            "Naive vector search performs fuzzy OR-like matching — any TNBC or BRCA mention scores high. "
            "Graph traversal checks ALL REQUIRES_BIOMARKER edges must be satisfied simultaneously."
        ),
    },

    # ════════════════════════════════════════════════════
    # Q3: DRUG CONFLICT (dual constraint — required AND excluded)
    # ════════════════════════════════════════════════════
    {
        "num": 3,
        "title": "RA Drug History Dual Constraint",
        "insight": "Why Graph > Vector: exact prior drug history with dual direction constraints",
        "question": (
            "A 52-year-old female in Pune has Rheumatoid Arthritis. She previously received "
            "Adalimumab (TNF inhibitor) for 18 months but had inadequate response. "
            "She has NEVER received a JAK inhibitor. CRP is 18 mg/L, DAS28 is 4.2. "
            "Which clinical trials in Maharashtra are she eligible for?"
        ),
        "patient_id": "P005",
        "challenge_type": "DRUG-CONFLICT + GEOGRAPHIC",
        "ground_truth_trials": ["T010"],
        "ground_truth_excluded": ["T024"],
        "key_teaching_point": (
            "T010 (Upadacitinib) REQUIRES prior adalimumab AND EXCLUDES prior JAK inhibitor — this patient qualifies. "
            "T024 (Abatacept) EXCLUDES prior adalimumab — this patient is ineligible. "
            "Vector search cannot determine this — it sees 'rheumatoid arthritis adalimumab' in BOTH trials "
            "and cannot distinguish REQUIRES_PRIOR_DRUG from EXCLUDES_PRIOR_DRUG edge types."
        ),
    },

    # ════════════════════════════════════════════════════
    # Q4: MULTI-HOP GRAPH TRAVERSAL (4 hops with confidence score)
    # ════════════════════════════════════════════════════
    {
        "num": 4,
        "title": "Hereditary ATTR Amyloidosis — Multi-Hop Rare Disease",
        "insight": "Graph enables multi-hop reasoning: Disease → Subtype → Biomarker → Trial → Site",
        "question": (
            "A 72-year-old male in New Delhi has hereditary ATTR cardiac amyloidosis. "
            "His TTR variant is confirmed (Val30Met). Technetium PYP scan shows Grade 3 uptake. "
            "NYHA Class II. He has never received tafamidis or any TTR-lowering therapy. "
            "Find eligible trials and report the graph traversal path and confidence score."
        ),
        "patient_id": "P009",
        "challenge_type": "MULTI-HOP + RARE-DISEASE",
        "ground_truth_trials": ["T009", "T027"],
        "ground_truth_excluded": [],
        "key_teaching_point": (
            "4-hop path: Patient→Disease(D010)→Biomarker(BM018/BM022)→Trial(T009)→Site(S006). "
            "Confidence = 1/(1+4) = 0.20 base, boosted by biomarker match completeness. "
            "Naive vector fails because ATTR amyloidosis is a rare entity underrepresented in training data. "
            "Graph doesn't rely on semantic similarity — it follows typed edges regardless of entity frequency."
        ),
    },

    # ════════════════════════════════════════════════════
    # Q5: TEMPORAL (closed trial contamination prevention)
    # ════════════════════════════════════════════════════
    {
        "num": 5,
        "title": "ALK+ NSCLC — Status Filtering (Temporal Challenge)",
        "insight": "Graph enforces trial status; vector returns closed trials as if open",
        "question": (
            "A 45-year-old female in Mumbai has ALK-positive NSCLC (adenocarcinoma), Stage IV, "
            "treatment-naive. Are there any currently RECRUITING ALK-positive NSCLC trials "
            "with sites in Maharashtra?"
        ),
        "patient_id": "P010",
        "challenge_type": "TEMPORAL + GEOGRAPHIC",
        "ground_truth_trials": [],  # Answer is: NO eligible trial
        "ground_truth_excluded": ["T005"],
        "key_teaching_point": (
            "T005 (Alectinib trial) has status 'Active_not_recruiting' — not accepting new patients. "
            "Naive vector returns T005 because it matches 'ALK NSCLC Maharashtra' perfectly. "
            "This is CLINICALLY DANGEROUS: a patient and family may be falsely hopeful about a trial "
            "that is no longer enrolling. Graph traversal filters WHERE t.status='Recruiting' exactly."
        ),
        "expected_answer": "NO eligible trial found in Maharashtra for ALK+ NSCLC currently recruiting.",
    },

    # ════════════════════════════════════════════════════
    # Q6: LIMITATION — Unstructured Eligibility Nuance
    # System cannot handle implicit clinical judgment
    # ════════════════════════════════════════════════════
    {
        "num": 6,
        "title": "⚠ LIMITATION: Implicit Clinical Judgment",
        "insight": "System limitation: eligibility requires clinical judgment not encodable in graph edges",
        "question": (
            "A 67-year-old male with metastatic NSCLC and EGFR wild-type has 'borderline' ECOG PS 2 "
            "due to recent pneumonia, but his oncologist expects recovery to ECOG 1 within 3 weeks. "
            "Trial T001 requires ECOG 0-1. Is he eligible?"
        ),
        "patient_id": None,
        "challenge_type": "LIMITATION — TEMPORAL CLINICAL JUDGMENT",
        "ground_truth_trials": ["T001"],  # The 'correct' answer requires physician judgment
        "ground_truth_excluded": [],
        "key_teaching_point": (
            "The graph stores ECOG ≤1 as a hard constraint. The patient currently has ECOG 2. "
            "The system will say INELIGIBLE. But clinically, there is nuance: the physician expects "
            "improvement. Neither the graph NOR the LLM can make this judgment reliably — "
            "it requires real-time clinical assessment. "
            "This is why the system always outputs: 'Verify with CRC and current protocol version.'"
        ),
        "is_limitation": True,
        "limitation_explanation": (
            "Graph-RAG encodes static eligibility criteria. It cannot model:\n"
            "  1. Temporal clinical trajectories (patient improving/worsening)\n"
            "  2. Investigator discretion clauses ('per PI judgment')\n"
            "  3. Protocol amendments not yet reflected in the graph\n"
            "  4. Relative contraindications requiring multidisciplinary assessment\n"
            "Human CRC review is ALWAYS required."
        ),
    },

    # ════════════════════════════════════════════════════
    # Q7: LIMITATION — Graph Coverage Gaps (rare mutations not in KB)
    # ════════════════════════════════════════════════════
    {
        "num": 7,
        "title": "⚠ LIMITATION: Out-of-Graph Entity (Novel Mutation)",
        "insight": "System limitation: entities not in the KG are invisible to graph traversal",
        "question": (
            "A 54-year-old NSCLC patient has a PTPRD-ALK fusion (ultra-rare, not yet included "
            "in most trial registries as a distinct biomarker). Will the system correctly "
            "identify trials for this patient?"
        ),
        "patient_id": None,
        "challenge_type": "LIMITATION — KG COVERAGE GAP",
        "ground_truth_trials": ["T005"],  # ALK trial, but rare fusion type
        "ground_truth_excluded": [],
        "key_teaching_point": (
            "The knowledge graph contains Biomarker node BM004 (ALK Rearrangement). "
            "PTPRD-ALK is a specific variant of ALK fusion not explicitly mapped in the graph. "
            "Graph traversal will MISS this connection. "
            "A physician who recognizes PTPRD-ALK as an ALK rearrangement variant would match T005, "
            "but the system requires explicit graph edges. "
            "This is why continuous KG maintenance, molecular tumor board integration, and "
            "expert curation pipelines are required in production deployment."
        ),
        "is_limitation": True,
        "limitation_explanation": (
            "Graph completeness is the ceiling on Graph-RAG quality:\n"
            "  1. Novel biomarkers require KG updates (takes time)\n"
            "  2. Biomarker synonyms/variants need explicit alias nodes\n"
            "  3. Trial protocol amendments may not be reflected immediately\n"
            "  4. Oncology is moving faster than any static KG can self-update\n"
            "Hybrid approach: LLM handles novel entities with LOW confidence flag; "
            "graph provides authoritative match for known entities."
        ),
    },
]


# ─────────────────────────────────────────────────────────
# DEMO RUNNER
# ─────────────────────────────────────────────────────────

def run_question(q: dict, graph: MockGraph, pipeline: ProgressivePipeline, show_compare: bool = False):
    is_limitation = q.get("is_limitation", False)
    
    print(f"\n{'━'*65}")
    if is_limitation:
        print(f"  {C.BOLD}{C.RED}QUESTION {q['num']}: {q['title']}{C.RESET}")
        print(f"  {C.YELLOW}Challenge: {q['challenge_type']}{C.RESET}")
    else:
        print(f"  {C.BOLD}{C.CYAN}QUESTION {q['num']}: {q['title']}{C.RESET}")
        print(f"  {C.YELLOW}Challenge: {q['challenge_type']}{C.RESET}")
    print(f"  {C.DIM}Insight: {q['insight']}{C.RESET}")
    
    print(f"\n  {C.BOLD}Query:{C.RESET}")
    print(f"  {q['question']}")
    
    if is_limitation:
        print(f"\n  {C.RED}⚠  LIMITATION DEMONSTRATION{C.RESET}")
        print(f"\n  {q['limitation_explanation']}")
        print(f"\n  Teaching point:")
        print(f"  {C.DIM}{q['key_teaching_point']}{C.RESET}")
        return
    
    # Run retrieval
    pid = q.get("patient_id")
    gt_trials = q.get("ground_truth_trials", [])
    gt_excluded = q.get("ground_truth_excluded", [])
    
    if pid:
        patient = graph.patients[pid] if hasattr(graph, 'patients') else None
        if not patient:
            with open(DATA_DIR / "patient_profiles.json") as f:
                patients = {p["id"]: p for p in json.load(f)}
            patient = patients.get(pid)
        
        section("Stage 0: Naive Vector RAG")
        start = time.time()
        qa_mock = {"question": q["question"], "ground_truth_trials": gt_trials, "patient_id": pid}
        v_result = pipeline.run_stage0_naive_vector(qa_mock)
        print(f"  Returned trials: {v_result.retrieved_trial_ids}")
        
        for tid in v_result.retrieved_trial_ids:
            if tid in gt_trials:
                success(f"{tid} — correctly found")
            elif tid in gt_excluded:
                error(f"{tid} — FALSE POSITIVE! Patient is excluded from this trial!")
            else:
                warning(f"{tid} — not in ground truth set")
        print(f"  Precision: {v_result.precision:.2f} | Recall: {v_result.recall:.2f} | F1: {v_result.f1:.2f}")
        print(f"  False Positives: {C.RED}{v_result.false_positive_count}{C.RESET}")
        
        section("Stage 3: Hybrid Graph-RAG")
        start = time.time()
        g_result = pipeline.run_stage3_hybrid(qa_mock)
        print(f"  Returned trials: {g_result.retrieved_trial_ids}")
        
        for tid in g_result.retrieved_trial_ids:
            if tid in gt_trials:
                success(f"{tid} — correctly found")
            elif tid in gt_excluded:
                error(f"{tid} — FALSE POSITIVE! (should not happen with graph)")
            else:
                warning(f"{tid} — not in ground truth set")
        
        # Also show what was correctly excluded
        if gt_excluded:
            print(f"\n  Correctly excluded:")
            for tid in gt_excluded:
                if tid not in g_result.retrieved_trial_ids:
                    success(f"{tid} — correctly EXCLUDED (graph negation working)")
        
        if q.get("expected_answer"):
            print(f"\n  {C.YELLOW}Expected answer: {q['expected_answer']}{C.RESET}")
        
        print(f"\n  Precision: {g_result.precision:.2f} | Recall: {g_result.recall:.2f} | F1: {g_result.f1:.2f}")
        print(f"  False Positives: {C.GREEN}{g_result.false_positive_count}{C.RESET}")
        
        print(f"\n  {C.BOLD}Key Teaching Point:{C.RESET}")
        print(f"  {C.DIM}{q['key_teaching_point']}{C.RESET}")
        
        # Graph metadata for matched trials
        if g_result.retrieved_trial_ids:
            section("Graph Context (matched trials):")
            context = graph.get_trial_context(g_result.retrieved_trial_ids[:2])
            for line in context.split('\n')[:15]:
                print(f"  {line}")


def run_all_demo(show_compare=False):
    print(f"\n{C.BOLD}{C.CYAN}")
    print("╔═══════════════════════════════════════════════════════════════╗")
    print("║          MedKG Navigator — Clinical Trial Matching Demo       ║")
    print("║    Knowledge Graph × GraphRAG × Hybrid Retrieval             ║")
    print("╚═══════════════════════════════════════════════════════════════╝")
    print(C.RESET)
    
    print(f"Loading knowledge graph ({C.DIM}in-memory MockGraph{C.RESET})...")
    graph = MockGraph(DATA_DIR)
    pipeline = ProgressivePipeline(DATA_DIR)
    print(f"  ✓ {len(graph.trials)} trials | {len(graph.biomarkers)} biomarkers | {len(graph.sites)} sites")
    print(f"  ✓ {sum(1 for s in graph.sites if s.get('state')=='Maharashtra')} Maharashtra sites")
    
    print(f"\n{C.BOLD}Running 5 capability demonstrations + 2 limitation disclosures...{C.RESET}")
    
    for q in DEMO_QUESTIONS:
        run_question(q, graph, pipeline, show_compare)
        if q["num"] in [5, 7]:
            print(f"\n{'━'*65}")
        time.sleep(0.1)
    
    print(f"\n\n{C.BOLD}{'═'*65}")
    print("SYSTEM SUMMARY")
    print(f"{'═'*65}{C.RESET}")
    print(f"  Demonstrated {C.GREEN}5{C.RESET} capabilities | Disclosed {C.YELLOW}2{C.RESET} honest limitations")
    print()
    print("  Core advantage of Graph-RAG over pure vector search:")
    print(f"    {C.GREEN}✓{C.RESET} Biomarker NEGATION (EGFR wild-type vs EGFR-mutant trials)")
    print(f"    {C.GREEN}✓{C.RESET} Drug history (REQUIRES vs EXCLUDES prior therapy)")
    print(f"    {C.GREEN}✓{C.RESET} Trial status enforcement (Recruiting only)")
    print(f"    {C.GREEN}✓{C.RESET} Geographic precision (Maharashtra site filter)")
    print(f"    {C.GREEN}✓{C.RESET} Compound AND logic (3+ biomarkers simultaneously)")
    print()
    print("  Honest limitations (require human CRC oversight):")
    print(f"    {C.YELLOW}⚠{C.RESET}  Clinical trajectory judgments (ECOG improving, borderline cases)")
    print(f"    {C.YELLOW}⚠{C.RESET}  Novel biomarker variants not yet in the KG")
    print()
    print(f"  {C.DIM}Always verify eligibility with a clinical research coordinator{C.RESET}")
    print()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--question", type=int, help="Run single question (1-7)")
    parser.add_argument("--compare", action="store_true", help="Show naive vs hybrid side-by-side")
    args = parser.parse_args()
    
    if args.question:
        q = next((x for x in DEMO_QUESTIONS if x["num"] == args.question), None)
        if q:
            graph = MockGraph(DATA_DIR)
            pipeline = ProgressivePipeline(DATA_DIR)
            run_question(q, graph, pipeline, args.compare)
        else:
            print(f"Question {args.question} not found. Valid: 1-7")
    else:
        run_all_demo(args.compare)
