"""
MedKG Navigator — Graph Construction
======================================
Builds the clinical trial knowledge graph in Neo4j.

Schema:
  (Patient)-[:HAS_DISEASE]->(Disease)
  (Disease)-[:HAS_BIOMARKER]->(Biomarker)
  (Drug)-[:TREATS]->(Disease)
  (Drug)-[:TARGETS]->(Biomarker)
  (Trial)-[:STUDIES_DISEASE]->(Disease)
  (Trial)-[:REQUIRES_BIOMARKER]->(Biomarker)   ← INCLUSION criterion
  (Trial)-[:EXCLUDES_BIOMARKER]->(Biomarker)   ← EXCLUSION criterion (critical!)
  (Trial)-[:REQUIRES_PRIOR_DRUG]->(Drug)
  (Trial)-[:EXCLUDES_PRIOR_DRUG]->(Drug)
  (Trial)-[:HAS_SITE]->(Site)
  (Patient)-[:HAS_BIOMARKER]->(Biomarker)
  (Patient)-[:RECEIVED_DRUG]->(Drug)

Requirements:
  pip install neo4j
  Neo4j Desktop or AuraDB free instance
  
Environment variables:
  NEO4J_URI      = bolt://localhost:7687  (or AuraDB URI)
  NEO4J_USER     = neo4j
  NEO4J_PASSWORD = your-password
"""

import os
import json
import logging
from pathlib import Path
from typing import Optional

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

DATA_DIR = Path(__file__).parent.parent / "data"

# ─────────────────────────────────────────────────────────
# NEO4J CONNECTION
# ─────────────────────────────────────────────────────────

try:
    from neo4j import GraphDatabase, basic_auth
    NEO4J_AVAILABLE = True
except ImportError:
    NEO4J_AVAILABLE = False
    print("⚠  neo4j driver not installed: pip install neo4j")

NEO4J_URI  = os.getenv("NEO4J_URI", "bolt://localhost:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASS = os.getenv("NEO4J_PASSWORD", "password")


class KGBuilder:
    """Builds and queries the clinical trial knowledge graph."""
    
    def __init__(self, uri=NEO4J_URI, user=NEO4J_USER, password=NEO4J_PASS):
        if not NEO4J_AVAILABLE:
            raise ImportError("Install: pip install neo4j")
        self.driver = GraphDatabase.driver(uri, auth=basic_auth(user, password))
        logger.info(f"Connected to Neo4j: {uri}")
    
    def close(self):
        self.driver.close()
    
    def _run(self, cypher: str, params: dict = None):
        with self.driver.session() as session:
            return list(session.run(cypher, params or {}))
    
    # ─── SCHEMA SETUP ─────────────────────────────────────
    
    def setup_constraints(self):
        """Create uniqueness constraints and indexes."""
        constraints = [
            "CREATE CONSTRAINT disease_id IF NOT EXISTS FOR (d:Disease) REQUIRE d.id IS UNIQUE",
            "CREATE CONSTRAINT biomarker_id IF NOT EXISTS FOR (b:Biomarker) REQUIRE b.id IS UNIQUE",
            "CREATE CONSTRAINT drug_id IF NOT EXISTS FOR (d:Drug) REQUIRE d.id IS UNIQUE",
            "CREATE CONSTRAINT trial_id IF NOT EXISTS FOR (t:Trial) REQUIRE t.id IS UNIQUE",
            "CREATE CONSTRAINT site_id IF NOT EXISTS FOR (s:Site) REQUIRE s.id IS UNIQUE",
            "CREATE CONSTRAINT patient_id IF NOT EXISTS FOR (p:Patient) REQUIRE p.id IS UNIQUE",
            "CREATE INDEX disease_name IF NOT EXISTS FOR (d:Disease) ON (d.name)",
            "CREATE INDEX trial_status IF NOT EXISTS FOR (t:Trial) ON (t.status)",
            "CREATE INDEX site_state IF NOT EXISTS FOR (s:Site) ON (s.state)",
            "CREATE INDEX biomarker_name IF NOT EXISTS FOR (b:Biomarker) ON (b.name)",
        ]
        for c in constraints:
            try:
                self._run(c)
            except Exception as e:
                logger.debug(f"Constraint/index note: {e}")
        logger.info("✓ Schema constraints and indexes created.")
    
    def clear_graph(self):
        """Drop all nodes and relationships. USE WITH CARE."""
        self._run("MATCH (n) DETACH DELETE n")
        logger.info("Graph cleared.")
    
    # ─── NODE CREATION ─────────────────────────────────────
    
    def load_diseases(self, diseases: list[dict]):
        q = """
        UNWIND $rows AS row
        MERGE (d:Disease {id: row.id})
        SET d.name = row.name,
            d.aliases = row.aliases,
            d.icd10 = row.icd10,
            d.category = row.category,
            d.prevalence = row.prevalence,
            d.challenge_tags = row.challenge_tags
        """
        self._run(q, {"rows": diseases})
        logger.info(f"✓ Loaded {len(diseases)} Disease nodes.")
    
    def load_biomarkers(self, biomarkers: list[dict]):
        q = """
        UNWIND $rows AS row
        MERGE (b:Biomarker {id: row.id})
        SET b.name = row.name,
            b.aliases = row.aliases,
            b.type = row.type,
            b.assay = row.assay,
            b.challenge_tags = row.challenge_tags
        WITH b, row
        UNWIND row.disease_ids AS did
        MATCH (d:Disease {id: did})
        MERGE (b)-[:IS_BIOMARKER_FOR]->(d)
        """
        self._run(q, {"rows": biomarkers})
        logger.info(f"✓ Loaded {len(biomarkers)} Biomarker nodes + IS_BIOMARKER_FOR edges.")
    
    def load_drugs(self, drugs: list[dict]):
        # Create drug nodes
        q = """
        UNWIND $rows AS row
        MERGE (d:Drug {id: row.id})
        SET d.name = row.name,
            d.brand = row.brand,
            d.class = row.class,
            d.targets = row.targets,
            d.approval_year = row.approval_year
        WITH d, row
        UNWIND row.approved_indications AS did
        MATCH (dis:Disease {id: did})
        MERGE (d)-[:TREATS]->(dis)
        """
        self._run(q, {"rows": drugs})
        logger.info(f"✓ Loaded {len(drugs)} Drug nodes + TREATS edges.")
    
    def load_sites(self, sites: list[dict]):
        q = """
        UNWIND $rows AS row
        MERGE (s:Site {id: row.id})
        SET s.name = row.name,
            s.city = row.city,
            s.state = row.state,
            s.country = row.country,
            s.tier = row.tier,
            s.specialties = row.specialties,
            s.lat = row.lat,
            s.lon = row.lon
        """
        self._run(q, {"rows": sites})
        logger.info(f"✓ Loaded {len(sites)} Site nodes.")
    
    def load_trials(self, trials: list[dict]):
        """Load trials and ALL relationships (inclusion, exclusion, sites, disease)."""
        
        # Step 1: Create trial nodes
        q_nodes = """
        UNWIND $rows AS row
        MERGE (t:Trial {id: row.id})
        SET t.nct_id = row.nct_id,
            t.title = row.title,
            t.phase = row.phase,
            t.status = row.status,
            t.primary_endpoint = row.primary_endpoint,
            t.target_enrollment = row.target_enrollment,
            t.sponsor = row.sponsor,
            t.start_date = row.start_date,
            t.prior_treatment_lines_max = row.prior_treatment_lines_max,
            t.inclusion_criteria_text = row.inclusion_criteria_text,
            t.exclusion_criteria_text = row.exclusion_criteria_text,
            t.challenge_tags = row.challenge_tags
        """
        self._run(q_nodes, {"rows": trials})
        
        # Step 2: STUDIES_DISEASE edges
        q_disease = """
        UNWIND $rows AS row
        MATCH (t:Trial {id: row.id})
        UNWIND row.disease_ids AS did
        MATCH (d:Disease {id: did})
        MERGE (t)-[:STUDIES_DISEASE]->(d)
        """
        self._run(q_disease, {"rows": trials})
        
        # Step 3: REQUIRES_BIOMARKER edges (INCLUSION - critical for NEGATION challenge)
        q_req_bm = """
        UNWIND $rows AS row
        MATCH (t:Trial {id: row.id})
        UNWIND row.required_biomarkers AS bid
        MATCH (b:Biomarker {id: bid})
        MERGE (t)-[:REQUIRES_BIOMARKER]->(b)
        """
        self._run(q_req_bm, {"rows": trials})
        
        # Step 4: EXCLUDES_BIOMARKER edges (EXCLUSION - KEY for negation queries)
        q_exc_bm = """
        UNWIND $rows AS row
        MATCH (t:Trial {id: row.id})
        UNWIND row.excluded_biomarkers AS bid
        MATCH (b:Biomarker {id: bid})
        MERGE (t)-[:EXCLUDES_BIOMARKER]->(b)
        """
        self._run(q_exc_bm, {"rows": trials})
        
        # Step 5: REQUIRES_PRIOR_DRUG edges
        q_req_drug = """
        UNWIND $rows AS row
        MATCH (t:Trial {id: row.id})
        UNWIND row.required_drugs_prior AS did
        MATCH (d:Drug {id: did})
        MERGE (t)-[:REQUIRES_PRIOR_DRUG]->(d)
        """
        self._run(q_req_drug, {"rows": trials})
        
        # Step 6: EXCLUDES_PRIOR_DRUG edges
        q_exc_drug = """
        UNWIND $rows AS row
        MATCH (t:Trial {id: row.id})
        UNWIND row.excluded_drugs_prior AS did
        MATCH (d:Drug {id: did})
        MERGE (t)-[:EXCLUDES_PRIOR_DRUG]->(d)
        """
        self._run(q_exc_drug, {"rows": trials})
        
        # Step 7: HAS_SITE edges
        q_sites = """
        UNWIND $rows AS row
        MATCH (t:Trial {id: row.id})
        UNWIND row.site_ids AS sid
        MATCH (s:Site {id: sid})
        MERGE (t)-[:HAS_SITE]->(s)
        """
        self._run(q_sites, {"rows": trials})
        
        logger.info(f"✓ Loaded {len(trials)} Trial nodes + all relationship types.")
    
    def load_patients(self, patients: list[dict]):
        """Load patient profiles and connect to disease, biomarker, drug nodes."""
        
        q_nodes = """
        UNWIND $rows AS row
        MERGE (p:Patient {id: row.id})
        SET p.age = row.age,
            p.sex = row.sex,
            p.city = row.city,
            p.state = row.state,
            p.country = row.country,
            p.ecog = row.ecog,
            p.prior_treatment_lines = row.prior_treatment_lines
        WITH p, row
        MATCH (d:Disease {id: row.diagnosis.disease_id})
        MERGE (p)-[:HAS_DISEASE]->(d)
        """
        self._run(q_nodes, {"rows": patients})
        
        q_bm_pos = """
        UNWIND $rows AS row
        MATCH (p:Patient {id: row.id})
        UNWIND row.biomarkers_positive AS bid
        MATCH (b:Biomarker {id: bid})
        MERGE (p)-[:HAS_BIOMARKER]->(b)
        """
        self._run(q_bm_pos, {"rows": patients})
        
        q_drugs = """
        UNWIND $rows AS row
        MATCH (p:Patient {id: row.id})
        UNWIND row.prior_drugs AS did
        MATCH (d:Drug {id: did})
        MERGE (p)-[:RECEIVED_DRUG]->(d)
        """
        self._run(q_drugs, {"rows": patients})
        
        logger.info(f"✓ Loaded {len(patients)} Patient nodes.")
    
    # ─── GRAPH STATISTICS ─────────────────────────────────
    
    def graph_stats(self) -> dict:
        stats = {}
        for label in ["Disease", "Biomarker", "Drug", "Trial", "Site", "Patient"]:
            result = self._run(f"MATCH (n:{label}) RETURN count(n) as cnt")
            stats[label] = result[0]["cnt"]
        
        rel_result = self._run("MATCH ()-[r]->() RETURN type(r), count(r) as cnt ORDER BY cnt DESC")
        stats["relationships"] = {row["type(r)"]: row["cnt"] for row in rel_result}
        return stats
    
    def print_stats(self):
        stats = self.graph_stats()
        print("\n" + "="*50)
        print("KNOWLEDGE GRAPH STATISTICS")
        print("="*50)
        for label in ["Disease", "Biomarker", "Drug", "Trial", "Site", "Patient"]:
            print(f"  {label:15s}: {stats.get(label, 0):4d} nodes")
        print("\n  Relationship counts:")
        for rel, cnt in stats.get("relationships", {}).items():
            print(f"    {rel:35s}: {cnt:4d}")
        total_nodes = sum(stats.get(l, 0) for l in ["Disease", "Biomarker", "Drug", "Trial", "Site", "Patient"])
        total_rels = sum(stats.get("relationships", {}).values())
        print(f"\n  Total nodes        : {total_nodes}")
        print(f"  Total relationships: {total_rels}")


def build_graph(clear=False):
    """Main function to build the complete knowledge graph."""
    builder = KGBuilder()
    
    if clear:
        confirm = input("Clear existing graph? (yes/no): ")
        if confirm.lower() == "yes":
            builder.clear_graph()
    
    print("\n📐 Setting up schema constraints...")
    builder.setup_constraints()
    
    print("📂 Loading datasets...")
    with open(DATA_DIR / "diseases.json") as f:
        diseases = json.load(f)
    with open(DATA_DIR / "biomarkers.json") as f:
        biomarkers = json.load(f)
    with open(DATA_DIR / "drugs.json") as f:
        drugs = json.load(f)
    with open(DATA_DIR / "sites.json") as f:
        sites = json.load(f)
    with open(DATA_DIR / "trials.json") as f:
        trials = json.load(f)
    with open(DATA_DIR / "patient_profiles.json") as f:
        patients = json.load(f)
    
    print("\n🔨 Building knowledge graph...")
    builder.load_diseases(diseases)
    builder.load_biomarkers(biomarkers)
    builder.load_drugs(drugs)
    builder.load_sites(sites)
    builder.load_trials(trials)
    builder.load_patients(patients)
    
    print("\n📊 Graph statistics:")
    builder.print_stats()
    
    print("\n✅ Knowledge graph built successfully!")
    print("   Access at: http://localhost:7474 (Neo4j Browser)")
    print("   Try: MATCH (t:Trial)-[:HAS_SITE]->(s:Site {state:'Maharashtra'}) RETURN t, s")
    
    builder.close()
    return builder


# ─────────────────────────────────────────────────────────
# MOCK GRAPH (for use WITHOUT Neo4j — in-memory for training)
# ─────────────────────────────────────────────────────────

class MockGraph:
    """
    In-memory graph implementation for training without Neo4j.
    Implements the same interface as KGBuilder for portability.
    
    TRAINER NOTE: Use this during initial exercises so participants
    can build retrieval logic without Neo4j setup overhead.
    Switch to KGBuilder when covering Cypher and graph analytics.
    """
    
    def __init__(self, data_dir=DATA_DIR):
        self.diseases  = json.load(open(data_dir / "diseases.json"))
        self.biomarkers = json.load(open(data_dir / "biomarkers.json"))
        self.drugs     = json.load(open(data_dir / "drugs.json"))
        self.sites     = json.load(open(data_dir / "sites.json"))
        self.trials    = json.load(open(data_dir / "trials.json"))
        self.patients  = json.load(open(data_dir / "patient_profiles.json"))
        
        # Build lookup indexes
        self.bm_idx    = {b["id"]: b for b in self.biomarkers}
        self.drug_idx  = {d["id"]: d for d in self.drugs}
        self.site_idx  = {s["id"]: s for s in self.sites}
        self.trial_idx = {t["id"]: t for t in self.trials}
        self.dis_idx   = {d["id"]: d for d in self.diseases}
        logger.info(f"MockGraph loaded: {len(self.trials)} trials, {len(self.sites)} sites")
    
    def match_patient_to_trials(
        self,
        disease_id: str,
        biomarkers_positive: list[str],
        biomarkers_negative: list[str],
        prior_drug_ids: list[str],
        prior_lines: int = 0,
        state_filter: Optional[str] = None,
        country_filter: Optional[str] = None,
        recruiting_only: bool = True,
    ) -> list[dict]:
        """
        Core matching logic using in-memory graph traversal.
        
        Returns list of eligible trials with confidence scores.
        This replicates what Cypher does in Neo4j.
        """
        results = []
        
        for trial in self.trials:
            # ── GATE 1: Recruitment status ────────────────
            if recruiting_only and trial.get("status", "") != "Recruiting":
                continue
            
            # ── GATE 2: Disease match ─────────────────────
            if disease_id not in trial.get("disease_ids", []):
                continue
            
            # ── GATE 3: Prior treatment lines ─────────────
            if prior_lines > trial.get("prior_treatment_lines_max", 99):
                continue
            
            # ── GATE 4: Required biomarkers (INCLUSION) ───
            required_bms = trial.get("required_biomarkers", [])
            if not all(bm in biomarkers_positive for bm in required_bms):
                continue
            
            # ── GATE 5: Excluded biomarkers (NEGATION) ────
            # *** THIS IS THE KEY CHALLENGE ***
            # Pure vector search CANNOT distinguish required vs excluded!
            excluded_bms = trial.get("excluded_biomarkers", [])
            if any(bm in biomarkers_positive for bm in excluded_bms):
                continue  # Patient has a biomarker this trial excludes
            
            # ── GATE 6: Required prior drugs ──────────────
            req_drugs = trial.get("required_drugs_prior", [])
            if not all(d in prior_drug_ids for d in req_drugs):
                continue
            
            # ── GATE 7: Excluded prior drugs ──────────────
            exc_drugs = trial.get("excluded_drugs_prior", [])
            if any(d in prior_drug_ids for d in exc_drugs):
                continue
            
            # ── GATE 8: Geographic filter ─────────────────
            trial_sites = [self.site_idx[sid] for sid in trial.get("site_ids", [])
                          if sid in self.site_idx]
            if state_filter:
                trial_sites = [s for s in trial_sites if s.get("state") == state_filter]
                if not trial_sites:
                    continue
            if country_filter:
                trial_sites = [s for s in trial_sites if s.get("country") == country_filter]
                if not trial_sites:
                    continue
            
            # ── CONFIDENCE SCORE ──────────────────────────
            # Based on: biomarker match completeness, hop distance, geographic proximity
            bm_match_rate = len(required_bms) / max(1, len(required_bms) + len(excluded_bms))
            geo_bonus = 0.15 if state_filter and trial_sites else 0.0
            hop_distance = 2 + len(required_bms)  # Disease→Biomarker→Trial path
            confidence = round(
                (0.7 * bm_match_rate + 0.15 * (1.0 / hop_distance) + geo_bonus) * 0.95,
                3
            )
            
            results.append({
                "trial_id":   trial["id"],
                "nct_id":     trial.get("nct_id"),
                "title":      trial["title"],
                "phase":      trial.get("phase"),
                "status":     trial.get("status"),
                "matching_sites": [s["name"] + f", {s['city']}" for s in trial_sites[:3]],
                "required_biomarkers_met": required_bms,
                "excluded_biomarkers_avoided": excluded_bms,
                "hop_distance": hop_distance,
                "confidence_score": confidence,
            })
        
        return sorted(results, key=lambda x: x["confidence_score"], reverse=True)
    
    def get_trial_context(self, trial_ids: list[str]) -> str:
        """Retrieve trial details for LLM context."""
        parts = []
        for tid in trial_ids:
            if tid not in self.trial_idx:
                continue
            t = self.trial_idx[tid]
            req_bms = [self.bm_idx[b]["name"] for b in t.get("required_biomarkers", []) if b in self.bm_idx]
            exc_bms = [self.bm_idx[b]["name"] for b in t.get("excluded_biomarkers", []) if b in self.bm_idx]
            sites = [self.site_idx[s]["name"] + f", {self.site_idx[s]['city']}"
                    for s in t.get("site_ids", []) if s in self.site_idx]
            
            parts.append(
                f"[{t['id']}] {t['title']}\n"
                f"  NCT: {t.get('nct_id')} | Phase: {t.get('phase')} | Status: {t.get('status')}\n"
                f"  Required biomarkers: {req_bms}\n"
                f"  Excluded biomarkers: {exc_bms}\n"
                f"  Sites: {sites[:4]}\n"
                f"  Inclusion: {t.get('inclusion_criteria_text','')[:200]}...\n"
                f"  Exclusion: {t.get('exclusion_criteria_text','')[:200]}..."
            )
        return "\n\n---\n".join(parts)


if __name__ == "__main__":
    import sys
    if "--mock" in sys.argv:
        print("Testing MockGraph (no Neo4j required)...")
        g = MockGraph()
        
        # Test: P001 — EGFR WT NSCLC in Maharashtra
        matches = g.match_patient_to_trials(
            disease_id="D001",
            biomarkers_positive=["BM003"],
            biomarkers_negative=["BM001", "BM002"],
            prior_drug_ids=[],
            prior_lines=0,
            state_filter="Maharashtra"
        )
        print(f"\nP001 (EGFR-WT NSCLC, Maharashtra): {len(matches)} eligible trials")
        for m in matches:
            print(f"  ✓ {m['trial_id']}: {m['title'][:50]} | Confidence: {m['confidence_score']}")
    else:
        build_graph()
