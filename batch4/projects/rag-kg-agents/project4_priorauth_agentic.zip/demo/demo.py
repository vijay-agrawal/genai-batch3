"""
PriorAuth — Multi-Agent Demo
==============================
Demonstrates 4 distinct prior authorization scenarios and 2 limitation cases.

Usage:
  python demo.py                  # All 4 scenarios + 2 limitations
  python demo.py --scenario 1     # Single scenario (1-4)
  python demo.py --limitations    # Limitations only
"""

import sys
import json
import time
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from agents import (
    PriorAuthOrchestrator, mask_phi,
    CONFIDENCE_THRESHOLD, CPT_CONFIDENCE_THRESHOLD
)

DATA_DIR = Path(__file__).parent.parent / "data"

class C:
    RED="\033[91m"; GREEN="\033[92m"; YELLOW="\033[93m"; CYAN="\033[96m"
    MAGENTA="\033[95m"; BLUE="\033[94m"; BOLD="\033[1m"; DIM="\033[2m"; RESET="\033[0m"
    ORANGE="\033[33m"

def hdr(t): print(f"\n{C.BOLD}{C.CYAN}{'═'*65}\n  {t}{C.RESET}")
def sec(t): print(f"\n  {C.YELLOW}▶ {t}{C.RESET}")
def ok(t):  print(f"  {C.GREEN}✓{C.RESET} {t}")
def err(t): print(f"  {C.RED}✗{C.RESET} {t}")
def warn(t):print(f"  {C.YELLOW}⚠{C.RESET}  {t}")
def dim(t): print(f"  {C.DIM}{t}{C.RESET}")
def info(t):print(f"  {C.CYAN}ℹ{C.RESET}  {t}")

with open(DATA_DIR / "patient_notes.json") as f:
    ALL_CASES = {c["case_id"]: c for c in json.load(f)}


# ─────────────────────────────────────────────────────────
# DEMO SCENARIO RUNNER
# ─────────────────────────────────────────────────────────

def run_scenario(case_id: str, orch: PriorAuthOrchestrator, show_trace: bool = True):
    case = ALL_CASES[case_id]
    tags = " ".join(f"[{t}]" for t in case["challenge_tags"])

    hdr(f"SCENARIO: {case['scenario_name']}")
    print(f"  Case ID  : {case_id}  |  {tags}")
    print(f"  Expected : {C.BOLD}{case['expected_outcome']}{C.RESET}")
    print()

    # Show excerpt of raw note
    note_preview = case["raw_note"].strip()[:400].replace("\n", "\n    ")
    print(f"  {C.DIM}Doctor's Note (excerpt):{C.RESET}")
    print(f"    {note_preview}...")
    print()

    # PHI preview
    if case.get("phi_present"):
        phi_fields = case.get("phi_fields", [])
        print(f"  {C.RED}PHI in note:{C.RESET} {', '.join(phi_fields)}")
        masked, types = mask_phi(case["raw_note"])
        print(f"  {C.GREEN}After masking:{C.RESET} {', '.join(types)} redacted before LLM call")
        if case.get("phi_contains_ssn"):
            warn("SSN detected — highest-risk PHI category — MASKED")

    sec("Running 5-Agent Pipeline...")
    print()

    # Simulate node-by-node output
    nodes = [
        ("Agent1_Extractor",      "PHI masked → entities extracted"),
        ("Agent2_ICDCoder",       "KG lookup → ICD-10 code assigned"),
        ("Agent2_5_CPTPredictor", "KG lookup → CPT procedure code assigned"),
        ("Agent3_PolicyRAG",      "Policy docs retrieved → compliance checked"),
        ("Agent4_FormFiller",     "HITL routing + PA JSON + schema validated"),
    ]
    for node, desc in nodes:
        time.sleep(0.06)
        print(f"  {C.DIM}  [{node:28s}] {desc}{C.RESET}")

    result = orch.process(case["raw_note"], case_id)
    form = result["pa_form"]
    hitl = result["hitl_routing"]
    decision = form["workflow_status"]["decision"]

    print()
    sec("Result")

    # Decision with colour
    decision_color = {
        "APPROVED": C.GREEN, "DENIED": C.RED, "PEND": C.YELLOW,
        "SUSPENDED": C.MAGENTA, "QUERY": C.CYAN
    }.get(decision, C.RESET)
    decision_icon = {
        "APPROVED": "✅", "DENIED": "❌", "PEND": "⏳",
        "SUSPENDED": "⛔", "QUERY": "❓"
    }.get(decision, "·")

    print(f"  {decision_icon}  Decision     : {decision_color}{C.BOLD}{decision}{C.RESET}")
    print(f"     Reason      : {form['workflow_status']['reason'][:120]}")
    print()

    # ICD-10 coding
    print(f"  {C.BOLD}ICD-10 Coding (Agent 2):{C.RESET}")
    print(f"     Code        : {form['coding']['icd10_code']} — {form['coding']['icd10_description'][:55]}")
    conf = form["coding"]["confidence_score"]
    conf_str = f"{conf:.0%}"
    if conf < CONFIDENCE_THRESHOLD:
        print(f"     Confidence  : {C.RED}{conf_str} ← BELOW {CONFIDENCE_THRESHOLD:.0%} THRESHOLD → SUSPEND{C.RESET}")
    else:
        print(f"     Confidence  : {C.GREEN}{conf_str}{C.RESET}")

    # CPT coding
    cpt = form.get("cpt_coding", {})
    cpt_code = cpt.get("primary_cpt_code", "UNKNOWN")
    cpt_conf = cpt.get("cpt_confidence", 0.0)
    sec_cpt  = cpt.get("secondary_cpt_code")
    route    = cpt.get("drug_route_inferred", "unknown")
    print()
    print(f"  {C.BOLD}CPT Coding (Agent 2.5):{C.RESET}")
    print(f"     Route       : {route}")
    if cpt.get("cpt_suspended"):
        print(f"     CPT Code    : {C.MAGENTA}⛔ {cpt_code} ← CPT SUSPENDED{C.RESET}")
        print(f"     CPT Conf    : {C.RED}{cpt_conf:.0%} < {CPT_CONFIDENCE_THRESHOLD:.0%} threshold → CPT coder queue{C.RESET}")
        warn(cpt.get("cpt_suspend_reason", "CPT confidence gate triggered"))
    else:
        cpt_color = C.CYAN if cpt_conf >= CPT_CONFIDENCE_THRESHOLD else C.YELLOW
        print(f"     CPT Code    : {cpt_color}{cpt_code}{C.RESET} — {cpt.get('cpt_description','')[:55]}")
        if sec_cpt:
            print(f"     Secondary   : {sec_cpt} (additional infusion hours)")
        print(f"     CPT Conf    : {C.GREEN}{cpt_conf:.0%}{C.RESET}")
        if cpt.get("cpt_ambiguous"):
            warn(f"CPT ambiguous: {cpt.get('cpt_ambiguous_codes')} — flagged for clarification")

    # Policy / docs
    print()
    if form["policy_check"].get("missing_documentation"):
        warn(f"Missing docs: {form['policy_check']['missing_documentation']}")
    if form["policy_check"].get("policy_conflicts"):
        err(f"Policy conflicts: {form['policy_check']['policy_conflicts']}")

    # HITL routing block
    print()
    print(f"  {C.BOLD}HITL Routing (Agent 4 — HITLRouter):{C.RESET}")
    if hitl["requires_hitl"]:
        pcolor = {"HIGH": C.RED, "MEDIUM": C.YELLOW, "LOW": C.CYAN}.get(hitl["hitl_priority"], C.RESET)
        print(f"     {C.RED}⚑{C.RESET} Requires HITL : {C.BOLD}YES{C.RESET}")
        print(f"       Priority    : {pcolor}{hitl['hitl_priority']}{C.RESET} (SLA: {hitl['hitl_sla_hours']}h)")
        print(f"       Queue       : {hitl['hitl_queue']}")
        print(f"       Triggers    : {hitl['hitl_triggers']}")
        for desc in hitl.get("trigger_descriptions", []):
            dim(f"         · {desc}")
    else:
        print(f"     {C.GREEN}✓{C.RESET} HITL not required — case fully automated")

    print()
    print(f"  PHI Masked   : {'✓' if form['patient']['phi_masked'] else '✗ NOT masked'}")
    print(f"  Schema OK    : {'✓' if result['schema_valid'] else '✗ SCHEMA ERROR'}")
    print(f"  Latency      : {result['end_to_end_latency_ms']:.0f}ms (5-agent A2A)")

    if show_trace:
        sec("A2A Handoff Trace")
        result["bus"].print_trace()

    # Compare with monolithic
    print()
    print(f"  {C.BOLD}Why A2A > Monolithic for this case:{C.RESET}")
    challenge_explanations = {
        "AMBIGUOUS_CODE": "Agent 2 detects dual ICD-10 candidates and flags QUERY — monolithic picks one arbitrarily",
        "LOW_CONFIDENCE": (f"Agent 2 confidence gate ({CONFIDENCE_THRESHOLD:.0%}) + Agent 2.5 CPT gate ({CPT_CONFIDENCE_THRESHOLD:.0%}) "
                           "catch rare/misspelled conditions — monolithic approves confidently at same low score"),
        "PHI_LEAK": "Agent 1 runs PHI masker BEFORE LLM call — monolithic sends raw SSN/DOB/MRN to LLM context",
        "POLICY_CONFLICT": "Agent 3 retrieves and reads full policy text — catches exclusion clauses monolithic ignores",
        "MULTI_AGENT_HANDOFF": "Clean typed schema flows Agent1→2→2.5→3→4 — full trace for audit; monolithic is a black box",
        "FORM_SCHEMA_FAIL": "Agent 4 validates JSON against strict schema — monolithic output is unvalidated free text",
    }
    for tag in case["challenge_tags"]:
        if tag in challenge_explanations:
            dim(challenge_explanations[tag])
    dim("Agent 4 HITLRouter evaluates 8 triggers — monolithic has ZERO human oversight layer")


# ─────────────────────────────────────────────────────────
# FOUR DEMO SCENARIOS
# ─────────────────────────────────────────────────────────

SCENARIO_CASES = [
    ("CASE_001", "NSCLC + Osimertinib — Full 5-agent approval flow with CPT 99214"),
    ("CASE_003", "ATTR Amyloidosis — Dual ICD-10+CPT suspension, HIGH priority HITL"),
    ("CASE_006", "NSCLC + PHI leak — SSN masked, IV CPT 96413, policy conflict → DENIED"),
    ("CASE_008", "RRMS + Ocrelizumab — IV infusion CPT 96365, high-cost HITL routing"),
]


# ─────────────────────────────────────────────────────────
# LIMITATION SCENARIOS
# ─────────────────────────────────────────────────────────

LIMITATIONS = [
    {
        "title": "Contradictory Information Across Note Sections",
        "scenario": (
            "A doctor's note contains LVEF '35%' in one paragraph and '55%' in the attachments section "
            "(typo in the attachment reference). "
            "Agent 1 extracts LVEF=35%, triggering HFrEF policy (APPROVED). "
            "The actual echo shows LVEF=55% — the patient has HFpEF, where the drug is NOT indicated."
        ),
        "limitation": (
            "Agent 1 performs single-pass NLP extraction. It cannot reconcile contradictory values "
            "across different sections of the same document. It extracts the first or most prominent value. "
            "Without access to the actual attached echo report (PDF), the discrepancy is invisible."
        ),
        "mitigations": [
            "Multi-modal document parsing: extract from attached PDF echo reports, not just note text",
            "Contradiction detection: flag when same entity appears with different values",
            "Verification callback: Agent 4 could flag conflicting values for HITL review",
            "EHR integration: pull structured echo data directly from HL7 FHIR rather than parsing notes",
        ],
    },
    {
        "title": "Policy Document Staleness — KG Not Updated After Insurer Amendment",
        "scenario": (
            "BlueStar Health updated their SGLT2i policy in Q1 2025 to remove the step therapy requirement "
            "for the HFrEF indication (eGFR ≥20 now sufficient, no metformin step needed). "
            "The policy_documents.json still contains the old step therapy rule. "
            "Agent 3 INCORRECTLY marks a valid HFrEF claim as PEND/DENIED due to stale policy text."
        ),
        "limitation": (
            "The Agentic RAG layer is only as current as the policy documents in the vector store. "
            "Insurers update PA criteria quarterly or in response to new drug approvals. "
            "A stale knowledge base produces systematically wrong decisions — and does so confidently "
            "(high RAG retrieval score on an outdated document)."
        ),
        "mitigations": [
            "Automated policy ingestion pipeline: pull from insurer portals (EDI 278 feeds) on refresh schedule",
            "Document versioning: tag each policy chunk with effective_date; reject chunks older than 90 days",
            "Policy changelog alert: notify clinical team when new policy version detected",
            "Human-in-the-loop for edge cases: borderline denials always routed to human reviewer",
        ],
    },
    {
        "title": "CPT Code Ambiguity for Multi-Indication Drugs",
        "scenario": (
            "Dapagliflozin (Farxiga) is approved for three separate indications: HFrEF (I50.20), "
            "T2DM with CKD (E11.65), and CKD standalone (N18.3). "
            "The PA request is for HFrEF but the patient ALSO has T2DM. "
            "Agent 2.5 returns CPT 99214 with high confidence, but cannot determine whether "
            "the billing should reflect HFrEF management or T2DM management — "
            "the CPT code is the same but the downstream formulary tier and cost-sharing differ."
        ),
        "limitation": (
            "Agent 2.5 predicts the procedure code but cannot disambiguate the PRIMARY indication "
            "for billing purposes when multiple valid indications coexist. "
            "The claims system may apply the wrong cost-sharing tier or reject the claim "
            "if the submitted ICD-10 primary code doesn't match the expected formulary pathway."
        ),
        "mitigations": [
            "Multi-indication ranking: Agent 2 should rank ICD-10 codes by clinical primacy, not just confidence",
            "Agent 2.5 CPT disambiguation: separate E/M code selection from primary indication routing",
            "HITL trigger: when patient has overlapping indications, always route to clinical reviewer",
            "Formulary integration: look up indication-specific cost-sharing before issuing final CPT code",
        ],
    },
]


def run_limitations():
    hdr("HONEST LIMITATION DISCLOSURES")
    print(f"  {C.DIM}Architectural boundaries of the multi-agent PA system.{C.RESET}")
    for i, lim in enumerate(LIMITATIONS, 1):
        print(f"\n{'─'*65}")
        print(f"  {C.BOLD}{C.YELLOW}LIMITATION {i}: {lim['title']}{C.RESET}\n")
        print(f"  {C.BOLD}Scenario:{C.RESET}")
        for sent in lim["scenario"].split(". "):
            if sent.strip(): dim(sent.strip() + ".")
        print(f"\n  {C.RED}{C.BOLD}Why it fails:{C.RESET}")
        for sent in lim["limitation"].split(". "):
            if sent.strip(): print(f"    {C.RED}·{C.RESET} {sent.strip()}.")
        print(f"\n  {C.GREEN}Mitigations:{C.RESET}")
        for m in lim["mitigations"]:
            ok(m)
    print(f"\n{'═'*65}")
    print(f"  {C.BOLD}Bottom line:{C.RESET}")
    dim("Multi-agent A2A reduces prior auth errors vs monolithic LLM.")
    dim("CPT prediction adds procedure-level accuracy and surfaces billing risks early.")
    dim("HITL routing ensures no high-risk case escapes human oversight.")
    dim("Policy staleness and document contradictions require operational controls outside the ML layer.")


# ─────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", type=int, choices=[1,2,3,4])
    parser.add_argument("--limitations", action="store_true")
    args = parser.parse_args()

    print(f"\n{C.BOLD}{C.CYAN}")
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║   PriorAuth — Autonomous Multi-Agent Prior Authorization     ║")
    print("║   A2A × ICD-10 KG × CPT KG × Policy RAG × HITL Router       ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print(C.RESET)
    print(f"  Agents: {C.DIM}Extractor → ICD-10 Coder → CPT Predictor → Policy RAG → Form Filler{C.RESET}")
    print(f"  HITL triggers: {C.DIM}ICD-10 confidence, CPT confidence, ambiguity, cost, policy, docs{C.RESET}")
    print()

    if args.limitations:
        run_limitations(); return

    orch = PriorAuthOrchestrator()

    if args.scenario:
        case_id, title = SCENARIO_CASES[args.scenario - 1]
        print(f"  {C.BOLD}Running Scenario {args.scenario}: {title}{C.RESET}")
        run_scenario(case_id, orch)
    else:
        print(f"  {C.BOLD}Running all 4 PA scenarios + 3 limitations{C.RESET}\n")
        for i, (case_id, title) in enumerate(SCENARIO_CASES, 1):
            print(f"\n{'█'*65}")
            print(f"  {C.BOLD}SCENARIO {i} of 4: {title}{C.RESET}")
            run_scenario(case_id, orch, show_trace=(i == 1))
            time.sleep(0.1)

        print(f"\n\n{'█'*65}")
        run_limitations()

        print(f"\n\n{'═'*65}")
        print(f"  {C.BOLD}DEMO SUMMARY{C.RESET}")
        ok("Scenario 1 (NSCLC): Osimertinib APPROVED — CPT 99214, HITL for $18.5k/month cost")
        ok("Scenario 2 (ATTR): Dual ICD-10+CPT suspension → HIGH priority HITL, 2-hour SLA")
        ok("Scenario 3 (NSCLC+PHI): SSN masked, CPT 96413 (IV infusion), EGFR conflict → DENIED")
        ok("Scenario 4 (RRMS): Ocrelizumab APPROVED — CPT 96365+96366, HITL for $20k/month")
        print()
        warn("Limitation 1: Contradictory values within same note unresolvable by current extraction")
        warn("Limitation 2: Stale policy documents produce confident but wrong decisions")
        warn("Limitation 3: CPT code ambiguity for multi-indication drugs — formulary routing risk")
        print()
        print(f"  {C.DIM}CPT Confidence Threshold: {CPT_CONFIDENCE_THRESHOLD:.0%}  |  ICD-10 Confidence Threshold: {CONFIDENCE_THRESHOLD:.0%}{C.RESET}")
        print(f"  {C.DIM}HITL triggers: 8 types across 3 queues (medical coder / compliance / clinical manager){C.RESET}")
        print()

if __name__ == "__main__":
    main()
