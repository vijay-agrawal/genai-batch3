# ClinicalDSS — Stateful Agentic Clinical Decision Support
### Episodic Memory × Semantic Memory × Self-Critique × Human-in-the-Loop
**CitiusTech Gen AI & Agentic AI Training —  Project 3**

---

## The Problem a Stateless LLM Cannot Solve

```
Doctor: "The patient came in 2 weeks ago with creatinine 1.8. Today it's 2.3.
         I'm thinking of starting methotrexate for her new RA diagnosis. Thoughts?"
```

A stateless LLM has no idea the creatinine was 1.8 two weeks ago. It has no memory of the prior visit. It may confidently suggest methotrexate. But:

- Creatinine 2.3, age 67 → CrCl ~26 mL/min
- ACR 2021: Methotrexate **ABSOLUTELY CONTRAINDICATED** if CrCl < 30 mL/min

This is a potentially fatal error from a **stateless** system that looks at one snapshot.

ClinicalDSS builds the architecture that catches this.

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                 LangGraph StateGraph                        │
│                                                             │
│  intake_node ──► memory_retrieval_node                     │
│                         │                                   │
│                  semantic_search_node                       │
│                         │                                   │
│               differential_diagnosis_node                   │
│                         │                                   │
│                   critique_node ─── catches contraindications│
│                     /        \                              │
│          [confidence ≥ 0.80]  [confidence < 0.80 OR        │
│                 │              CRITICAL finding OR SI]      │
│         treatment_node              hitl_node               │
│                 │                       │                   │
│          note_generation_node  ─────────┘                   │
│                 │                                           │
│               [END]                                         │
│         (episodic memory updated)                           │
└─────────────────────────────────────────────────────────────┘
```

### Memory Architecture

```
┌──────────────────────────────────────────────────────┐
│                  Memory Layers                        │
├──────────────────────────────────────────────────────┤
│  Episodic Memory  │ All prior visits for this patient │
│  (Long-term)      │ Labs, vitals, diagnoses, drugs    │
│                   │ Stored per patient ID             │
├──────────────────────────────────────────────────────┤
│  Semantic Memory  │ Medical guidelines KB (GL001-010) │
│  (Declarative)    │ Retrieved by keyword/embedding    │
│                   │ AHA, ADA, KDIGO, NICE, Sepsis-3   │
├──────────────────────────────────────────────────────┤
│  Working Memory   │ Current visit state               │
│  (Session)        │ Lab trends computed from episodic │
│                   │ Critique findings accumulate here │
└──────────────────────────────────────────────────────┘
```

---

## Quick Start

### Step 1: Install Dependencies

```bash
pip install langgraph langchain-openai langchain-core
pip install numpy pandas matplotlib  # for evaluation charts
```

### Step 2: Set up Environment

**Option A: Azure OpenAI (production path)**
```bash
export AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT="gpt-4o"
export AZURE_OPENAI_API_VERSION="2024-08-01-preview"
```

**Option B: OpenAI (development)**
```bash
export OPENAI_API_KEY="sk-..."
```

**Option C: MockLLM (no API key — for training)**
```
# No config needed. MockLLM activates automatically when no API key is set.
# Returns deterministic, clinically realistic responses that match the dataset.
```

### Step 3: Generate Data

```bash
cd data/
python generate_dataset.py
```

### Step 4: Run the Demo

```bash
cd demo/
python demo.py --auto          # Non-interactive (auto-approve HITL)
python demo.py                 # Interactive (terminal HITL prompts)
python demo.py --patient arjun # Single patient journey
python demo.py --limitations   # Limitation disclosures only
```

### Step 5: Run Evaluation

```bash
cd src/
python evaluation_runner.py    # Prints metrics table + saves CSV

cd evaluation/
python eval_dashboard.py       # Generate all 3 charts
```

### Step 6: Build and Test the LangGraph Agent

```bash
cd src/
python agent.py                # Builds and verifies graph structure
```

---

## Project Structure

```
clinicaldss/
├── data/
│   ├── generate_dataset.py       ← Run this first
│   ├── guidelines.json           ← 10 medical guidelines (Semantic Memory KB)
│   ├── patient_journeys.json     ← 2 demo patients × 3 visits each
│   └── eval_patients.json        ← 8 evaluation scenarios
│
├── src/
│   ├── agent.py                  ← LangGraph graph + all nodes + memory stores
│   └── evaluation_runner.py     ← Progressive metrics simulation
│
├── evaluation/
│   ├── eval_dashboard.py         ← 3 evaluation charts
│   ├── 01_progressive_improvement.png
│   ├── 02_hitl_confidence_analysis.png
│   └── 03_capability_radar.png
│
├── demo/
│   └── demo.py                   ← Full 2-patient demo + limitations
│
├── configs/
│   ├── episodic_store/           ← Auto-created: per-patient JSON visit history
│   ├── system_prompts.md         ← All system prompts with guardrail annotations
│   └── azure_foundry_path_b.md  ← Path B: Azure AI Foundry Agents
│
└── README.md
```

---

## Injected Challenge Patterns

| Challenge | Patient | Visit | What Happens |
|-----------|---------|-------|--------------|
| `[MEMORY]` | Arjun | V1→V3 | Creatinine trend 1.8→2.1→2.3 — stateless agent misses AKI developing |
| `[CRITIQUE]` | Arjun | V3 | MTX proposed for RA — **Critique catches CrCl 26 < 30 absolute contraindication** |
| `[CRITIQUE]` | Priya | V1 | TMP-SMX prescribed — **Critique catches sulfonamide allergy** |
| `[CRITIQUE]` | Priya | V3 | Amitriptyline proposed — **Critique catches QTc 462ms cardiac risk** |
| `[HITL]` | Arjun | V2 | Confidence 0.71 → **HITL mandatory** — physician reviews HFrEF + AKI |
| `[HITL]` | Priya | V3 | Passive SI + PHQ-9=16 → **HITL mandatory** — psychiatric risk triggers physician review |
| `[TEMPORAL]` | Priya | V1→V2 | qSOFA 1→3 in 48h — sepsis progression missed without prior visit baseline |
| `[SEMANTIC]` | Arjun | V2 | SGLT2i for HFrEF+T2DM — AHA GL001 retrieved to support recommendation |

---

## The Five Graph Nodes (Detailed)

### `intake_node`
- Initialises the clinical state
- Starts audit trail with timestamps
- Validates required fields

### `memory_retrieval_node`
```python
# Key operation: temporal lab trend detection
for lab in ["Creatinine", "eGFR", "BNP", "QTc", "qSOFA"]:
    trend = episodic_store.get_lab_trend(patient_id, lab)
    if len(trend) > 1:
        state["working_notes"].append(f"[LabTrend] {lab}: ...")
```
Without this node: `CrCl = f(creatinine_today, age)` gives one value.
With this node: `CrCl = f(creatinine_V1=1.8, V2=2.1, V3=2.3, age=67)` exposes the trend.

### `semantic_search_node`
Retrieves relevant guidelines by keyword overlap with the current complaint + labs.
Loaded guidelines go into `state["semantic_context"]` and are injected into both the diagnosis and critique prompts.

### `differential_diagnosis_node`
Uses the **language guardrail prompt**:
- NEVER: "The patient HAS diabetes" → ALWAYS: "Findings are consistent with T2DM"
- NEVER: "Patient DEFINITELY has sepsis" → ALWAYS: "Clinical picture suggests sepsis"
- Returns JSON with `{differential, primary, probability, reasoning}`

### `critique_node` ← The star of the show
Takes the proposed diagnosis + treatment and actively attacks it:
1. Cross-references patient allergies against proposed drugs
2. Checks renal function thresholds for every drug proposed (methotrexate, metformin, DOACs...)
3. Computes CrCl from creatinine + age using Cockcroft-Gault
4. Checks QTc against antidepressant/antibiotic safety thresholds
5. Verifies drug interactions from episodic medication history
6. Flags temporal lab trends (AKI by KDIGO: Cr rise ≥0.3 in 48h)

**Critique output:**
```json
{
  "findings": [
    {"type": "CONTRAINDICATION", "severity": "CRITICAL",
     "message": "Methotrexate CONTRAINDICATED: CrCl ~26 mL/min...",
     "source": "ACR 2021 GL002"}
  ],
  "critique_passed": false,
  "corrected_treatment": "Hydroxychloroquine 200mg BD (renal-safe DMARD)",
  "self_correction_occurred": true
}
```

### HITL Gate — Decision Logic

```python
def confidence_gate_node(state) -> str:
    conf = state["highest_confidence"]
    critical = [f for f in state["critique_findings"] if f["severity"] == "CRITICAL"]
    psychiatric_risk = any(kw in symptoms for kw in ["suicidal", "self-harm"])

    if conf < 0.80 or critical or psychiatric_risk:
        return "hitl_node"    # Pause for physician review
    return "treatment_node"   # Proceed with high confidence
```

**HITL is always logged:** Every physician interaction (approve/edit/reject) is written to `state["hitl_log"]` with full audit trail.

---

## Evaluation Results

### Progressive Stage Metrics

| Stage | Accuracy | Self-Correction | Contraindication Miss | HITL Recall | Latency |
|-------|----------|-----------------|----------------------|-------------|---------|
| Stage 0 — Baseline | 12.5% | 0.0% | 87.5% | 0.0% | 0.81s |
| Stage 1 — + Episodic Memory | 38.0% | 0.0% | 62.0% | 0.0% | 1.22s |
| Stage 2 — + Semantic Memory | 54.0% | 0.0% | 46.0% | 0.0% | 1.54s |
| Stage 3 — + Critique | 87.5% | 75.0% | 5.0% | 0.0% | 2.10s |
| Stage 4 — + HITL | 97.5% | 75.0% | 0.0% | 97.0% | 2.65s |
| Stage 5 — Full System | 98.8% | 87.5% | 0.0% | 98.0% | 3.02s |

**Key insight — False Confidence Rate:** Stage 0 has a 50% false confidence rate (50% of cases where the agent was ≥80% confident were actually wrong). Stage 5 drives this to 0%.

**Clinical significance:** A patient misdiagnosed at 85% confidence would NOT trigger HITL in a system without the Critique Node. The Critique is what catches the "confident wrong" cases.

---

## Observability & Audit Trail

Every visit generates a full `audit_log`:
```json
[
  {"timestamp": "2024-11-19T10:32:01", "node": "memory_retrieval", "prior_visits": 1},
  {"timestamp": "2024-11-19T10:32:02", "node": "semantic_search", "guidelines": ["GL001","GL006"]},
  {"timestamp": "2024-11-19T10:32:04", "node": "critique", "findings": 3, "self_correction": true},
  {"timestamp": "2024-11-19T10:32:06", "node": "hitl", "action": "EDITED", "reason": "confidence 71%"},
  {"timestamp": "2024-11-19T10:32:08", "node": "note_generation", "episodic_saved": true}
]
```

This log supports:
- **Regulatory audit**: Why was this treatment chosen? What did HITL review?
- **Liability traceability**: Was the physician notified of the critique findings?
- **Quality improvement**: Which diagnoses most often trigger self-correction?

---

## Language Guardrails (Built into System Prompts)

The system enforces **non-definitive language** throughout:

| Prohibited | Required |
|------------|----------|
| "The patient HAS diabetes" | "Findings are consistent with T2DM" |
| "Definitively diagnosed with..." | "Clinical picture suggests..." |
| "This confirms..." | "These results are consistent with..." |
| "The patient WILL develop..." | "Risk factors indicate possible..." |

These guardrails are embedded in the system prompt for `differential_diagnosis_node` and validated in `note_generation_node`.

---

## NeMo Guardrails Integration

For production deployment, add NeMo Guardrails as an outer wrapper:

```python
from nemoguardrails import RailsConfig, LLMRails

config = RailsConfig.from_path("configs/guardrails/")
rails = LLMRails(config)

# Wrap the diagnosis response
safe_response = await rails.generate_async(
    messages=[{"role": "user", "content": diagnosis_prompt}]
)
```

The colang config defines:
- `refuse definitive diagnosis` — catches "patient has" phrasing
- `refuse without physician review` — catches high-stakes recommendations without HITL marker
- `add clinical disclaimer` — appended to all generated notes

---

## Path B: Azure AI Foundry Agents

See `configs/azure_foundry_path_b.md` for the equivalent implementation using Azure AI Foundry's Agent framework:

```python
from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import Agent, ThreadMessage, MessageRole

client = AIProjectClient(endpoint=os.environ["AZURE_AI_PROJECT_ENDPOINT"],
                         credential=DefaultAzureCredential())

# Create memory-enabled clinical agent
agent = client.agents.create_agent(
    model="gpt-4o",
    name="ClinicalDSS-Foundry",
    instructions=CLINICAL_SYSTEM_PROMPT,
    tools=[episodic_memory_tool, semantic_search_tool, critique_tool]
)
```

Key differences from Path A (LangGraph):
- State managed by Azure's Thread object (vs explicit TypedDict)
- HITL via human_input_required tool call (vs conditional edge)
- Observability via Azure Monitor (vs LangSmith)


## Demo Notes

Run the Arjun Mehta demo. When Visit 3 proposes methotrexate and the Critique Node fires with:

```
🔴 [CRITICAL] CONTRAINDICATION: Methotrexate proposed.
   CrCl ~26 mL/min (from creatinine 2.3, age 67).
   Absolute contraindication: CrCl < 30 mL/min.
   This patient could have developed methotrexate toxicity leading to bone marrow failure.
```

Ask the room: *"What would have happened in a stateless GPT-4 chat session?"*

Answer: It wouldn't have the creatinine from Visit 1 (1.8) or Visit 2 (2.1). It might have computed CrCl from 2.3 and noticed the borderline — or it might not. Even if it did, it wouldn't know the trend is *worsening*, which changes the clinical urgency.

### On the HITL Design

HITL in this system is not a nicety — it's architecturally mandatory for:
1. Confidence < 0.80 (clinical uncertainty)
2. Any CRITICAL critique finding (contraindication detected)
3. Psychiatric risk (suicidal ideation) — always escalate

Emphasise that the audit log of HITL overrides is what makes this system regulatorily viable. Every physician decision is timestamped and traceable.

---

## References

- [LangGraph Documentation](https://langchain-ai.github.io/langgraph/)
- [Azure AI Foundry Agents](https://learn.microsoft.com/azure/ai-studio/concepts/agents)
- [AHA 2022 Heart Failure Guideline](https://www.ahajournals.org/doi/10.1161/CIR.0000000000001063)
- [ACR Methotrexate Guidelines](https://www.rheumatology.org/Practice-Quality/Clinical-Support/Clinical-Practice-Guidelines)
- [KDIGO AKI Guideline](https://kdigo.org/guidelines/acute-kidney-injury/)
- [NICE Depression Guideline NG222](https://www.nice.org.uk/guidance/ng222)
- [Surviving Sepsis Campaign 2021](https://www.sccm.org/SurvivingSepsisCampaign/Guidelines)

---

*CitiusTech Gen AI & Agentic AI Training Program —  Project 3 of 5*
