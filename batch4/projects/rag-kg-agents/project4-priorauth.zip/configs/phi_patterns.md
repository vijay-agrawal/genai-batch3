# PHI/PII Masking Reference
============================

## Patterns Applied (in order)
1. SSN: `\b\d{3}-\d{2}-\d{4}\b` → [SSN-REDACTED]
2. DOB: `(DOB|Date of Birth):\s*\d{1,2}/\d{1,2}/\d{2,4}` → [DOB-REDACTED]
3. Phone (India): `(\+91)?\d{10}` → [PHONE-REDACTED]
4. Phone (US): `\d{3}[-.\s]\d{3}[-.\s]\d{4}` → [PHONE-REDACTED]
5. Patient name: `(Patient\s*:)\s*([A-Z][a-z]+ [A-Z][a-z]+)` → `\1[NAME-REDACTED]`
6. MRN: `(MRN\s*:)\s*([A-Z]{2}-\d{5,10})` → `\1[MRN-REDACTED]`
7. Member ID: `(Member\s*ID\s*:)\s*(BS-\d{7})` → `\1[MEMBER-ID-REDACTED]`
8. Email: standard RFC email regex → [EMAIL-REDACTED]

## HIPAA Safeguards Covered
- Direct identifiers: name, DOB, phone, SSN, MRN, member ID, email
- All 18 HIPAA Safe Harbor identifiers handled except geographic (state-level retained)

## What is NOT Masked (by design)
- Clinical information (diagnosis, drug name, lab values)
- Age (retained as age_band: "61-75")
- Physician name and NPI (required for PA form)
- Insurer name (required for routing)
