# Azure AI Foundry Setup Guide
===============================

## Prerequisites
```bash
pip install azure-ai-projects azure-identity openai
```

## Environment
```bash
export AZURE_AI_PROJECT_ENDPOINT="https://your-project.api.azureml.ms"
export AZURE_SUBSCRIPTION_ID="..."
export AZURE_RESOURCE_GROUP="..."
export AZURE_AI_PROJECT_NAME="priorauth-project"
```

## Create Multi-Agent System
```python
from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import Agent, FunctionTool, ToolSet
from azure.identity import DefaultAzureCredential

client = AIProjectClient(
    endpoint=os.environ["AZURE_AI_PROJECT_ENDPOINT"],
    credential=DefaultAzureCredential()
)

# Tool definitions
phi_masker_tool = FunctionTool(
    name="mask_phi", description="Mask PHI/PII before LLM processing",
    parameters={"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}
)

kg_lookup_tool = FunctionTool(
    name="kg_lookup", description="Look up ICD-10 code from knowledge graph",
    parameters={"type":"object","properties":{"condition":{"type":"string"}},"required":["condition"]}
)

policy_search_tool = FunctionTool(
    name="policy_search", description="Search insurer policy documents",
    parameters={"type":"object","properties":{"drug":{"type":"string"},"icd10":{"type":"string"}}}
)

# Create agents
agents = {
    "extractor": client.agents.create_agent(
        model="gpt-4o", name="PA_Extractor",
        instructions=EXTRACTION_PROMPT, toolset=ToolSet([phi_masker_tool])
    ),
    "icd_coder": client.agents.create_agent(
        model="gpt-4o", name="PA_ICDCoder",
        instructions=ICD_PROMPT, toolset=ToolSet([kg_lookup_tool])
    ),
    "policy_rag": client.agents.create_agent(
        model="gpt-4o", name="PA_PolicyRAG",
        instructions=POLICY_PROMPT, toolset=ToolSet([policy_search_tool])
    ),
    "form_filler": client.agents.create_agent(
        model="gpt-4o", name="PA_FormFiller",
        instructions=FORM_PROMPT, toolset=ToolSet([])
    ),
}
```

## A2A via Thread Handoff
```python
# Each agent reads the Thread context (prior agent's output) and appends its result
thread = client.agents.create_thread()

for agent_name, agent in agents.items():
    run = client.agents.create_and_process_run(
        thread_id=thread.id,
        agent_id=agent.id
    )
    # Next agent automatically sees previous agent's output in thread context
```

## Observability
```python
# Azure Monitor / Application Insights tracing
from azure.monitor.opentelemetry import configure_azure_monitor
configure_azure_monitor(connection_string=os.environ["APPLICATIONINSIGHTS_CONNECTION_STRING"])
```
