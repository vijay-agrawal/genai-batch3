# PriorAuth — Autonomous Multi-Agent Prior Authorization
### A2A × Agentic KG × Agentic RAG × Azure AI Foundry
**CitiusTech Gen AI & Agentic AI Training — one Project 4**

---

## The Problem a Single LLM Cannot Reliably Solve

A monolithic LLM asked to process a prior authorization request:

```
"Patient: Deepa Iyer, DOB: 22/09/1969, SSN: 987-65-4321
 Diagnosis: NSCLC with EGFR del19 + PD-L1 55%
 Drug: Pembrolizumab 200mg q3w. Please approve."
```

will likely:
1. **Approve** — without checking BlueStar policy explicitly excludes pembrolizumab when EGFR mutation is present
2. **Send the SSN to the LLM context window** — HIPAA violation
3. **Return a free-text paragraph** — not a structured JSON payload the claims system can ingest
4. **Assign the wrong ICD-10 code** — NSCLC has 4 valid codes; wrong code means wrong policy branch

The multi-agent system catches all four failures through specialisation and gating.

---

## Agent Architecture

```
                        ┌────────────────────────────────────────────────┐
                        │           A2A Message Bus (Observable)          │
                        │   All inter-agent messages logged + timestamped │
                        └────────────────────────────────────────────────┘
                                        │
Raw doctor note ──► [PHI GUARDRAIL] ──► │
                    mask before LLM     │
                                        ▼
                         ┌─────────────────────────┐
                         │   Agent 1 — Extractor    │
                         │  Reads masked note        │
                         │  Extracts: condition,     │
                         │  drug, NPI, docs, facts   │
                         └────────────┬────────────┘
                                      │ entities payload
                                      ▼
                         ┌─────────────────────────┐
                         │  Agent 2 — ICD Coder     │
                         │  KG lookup: condition     │
                         │  → ICD-10 code            │
                         │  Confidence gate: <0.90   │
                         │  → SUSPEND (early exit)   │
                         └────────────┬────────────┘
                                      │ coded payload
                                      ▼
                         ┌─────────────────────────┐
                         │  Agent 3 — Policy RAG    │
                         │  Retrieves policy docs    │
                         │  Checks: step therapy,    │
                         │  exclusions, missing docs │
                         │  → APPROVED/DENIED/PEND  │
                         └────────────┬────────────┘
                                      │ policy check
                                      ▼
                         ┌─────────────────────────┐
                         │  Agent 4 — Form Filler   │
                         │  Generates PA JSON        │
                         │  Schema validation        │
                         │  → Final PA payload       │
                         └─────────────────────────┘
```

---

## Quick Start

### Step 1: Install Dependencies

```bash
pip install jsonschema langchain-openai langchain-core numpy pandas matplotlib
```

### Step 2: Configure LLM (choose one)

**Azure OpenAI (production):**
```bash
export AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT="gpt-4o"
export AZURE_OPENAI_API_VERSION="2024-08-01-preview"
```

**OpenAI (development):**
```bash
export OPENAI_API_KEY="sk-..."
```

**MockLLM (no API key — for training):**
No config needed — activated automatically. Returns scripted responses that replicate all 10 injected failure modes.

### Step 3: Generate Data

```bash
cd data/
python generate_dataset.py
```

### Step 4: Run a Single Case

```bash
cd src/
python agents.py 1    # Case 1: NSCLC + Osimertinib → APPROVED
python agents.py 3    # Case 3: ATTR → SUSPENDED (confidence gate)
python agents.py 6    # Case 6: NSCLC + PHI leak + policy conflict
```

### Step 5: Run the Full Demo

```bash
cd demo/
python demo.py                    # All 4 scenarios + 2 limitations
python demo.py --scenario 1       # Single scenario
python demo.py --limitations      # Limitations only
```

### Step 6: Evaluation + Charts

```bash
cd evaluation/
python eval_dashboard.py
```

---

## Project Structure

```
priorauth/
├── data/
│   ├── generate_dataset.py          ← Run this first
│   ├── icd10_knowledge_graph.json   ← 16 ICD-10 nodes with aliases
│   ├── drugs.json                   ← 15 drugs with tiers + PA requirements
│   ├── policy_documents.json        ← 8 insurer policy docs (Agent 3 RAG corpus)
│   ├── patient_notes.json           ← 10 PA cases with injected challenges
│   └── pa_form_schema.json          ← JSON Schema for output validation
│
├── src/
│   └── agents.py                    ← All 4 agents + orchestrator + PHI masker + A2A bus
│
├── evaluation/
│   ├── eval_dashboard.py            ← Metrics + 3 charts
│   ├── 01_multiagent_vs_monolithic.png
│   ├── 02_decision_breakdown_latency.png
│   └── 03_agent_waterfall.png
│
├── demo/
│   └── demo.py                      ← 4 scenarios + 2 limitations
│
├── configs/
│   ├── azure_foundry_setup.md       ← Azure AI Foundry deployment guide
│   ├── autogen_alternative.md       ← AutoGen multi-agent alternative
│   └── phi_patterns.md              ← PHI masking patterns reference
│
└── README.md
```

---

## Injected Challenge Patterns

| Challenge | Cases | What It Exposes |
|-----------|-------|-----------------|
| `[AMBIGUOUS_CODE]` | CASE_002 | AFib maps to I48.91 vs I48.11 — Agent 2 flags for clarification |
| `[LOW_CONFIDENCE]` | CASE_003, CASE_009 | ATTR amyloidosis (0.78) + misspelled diagnosis (0.42) → SUSPEND |
| `[PHI_LEAK]` | CASE_006 | SSN in note — must be masked before LLM call (HIPAA) |
| `[POLICY_CONFLICT]` | CASE_004, CASE_006, CASE_007 | Step therapy violation, EGFR exclusion, concurrent ACEi |
| `[MULTI_AGENT_HANDOFF]` | CASE_001, CASE_005, CASE_008 | Full A2A trace — verify inter-agent payload integrity |
| `[FORM_SCHEMA_FAIL]` | CASE_009, CASE_010 | Missing required field triggers schema validation error |

---

## The Four Agents (Detailed)

### Agent 1 — Extractor

**Responsibility:** Read the doctor's note, mask all PHI, extract structured entities.

**PHI Guardrail (runs BEFORE any LLM call):**
```python
masked_note, redacted_types = mask_phi(raw_note)
# Patterns: SSN, DOB, phone, patient name, MRN, member ID, email
# 8 regex patterns applied sequentially
```

**Output payload:**
```json
{
  "condition": "Non-Small Cell Lung Cancer",
  "drug_requested": "Osimertinib",
  "physician_npi": "NPI-SHARMA-001",
  "supporting_docs": ["pathology_report", "NGS_report"],
  "phi_masked": true,
  "phi_types_masked": ["NAME", "MRN", "MEMBER-ID"]
}
```

### Agent 2 — ICD-10 Coder (Agentic KG)

**Responsibility:** Map the extracted condition to an ICD-10 code using the knowledge graph.

**Knowledge Graph lookup:**
```python
# Alias matching (exact → partial → word overlap)
# Confidence = match_score × base_confidence_for_node
candidates = kg_lookup("ATTR Cardiac Amyloidosis")
# → [{"code": "E85.4", "_match_score": 0.74}, ...]
```

**Confidence gate:**
```python
CONFIDENCE_THRESHOLD = 0.90
if confidence < CONFIDENCE_THRESHOLD:
    # SUSPEND — do not proceed to policy check
    # Early exit: Agent 3 and 4 propagate SUSPENDED
```

This is the key differentiator: a monolithic LLM would assign E85.4 at 0.78 confidence and proceed to approve — potentially paying out a claim for a miscoded rare disease.

**Ambiguity detection:**
When two candidates have scores within 8% of each other (e.g., I48.91 vs I48.11 for AFib), the agent flags `is_ambiguous=True` → Agent 4 outputs `QUERY`.

### Agent 3 — Policy RAG (Agentic RAG)

**Responsibility:** Retrieve and check the insurer's policy against the coded claim.

**Retrieval strategy:**
```python
# Relevance score = 0.6 × (ICD-10 code in approved list) + 0.4 × (drug name match)
pol_results = policy_search(drug_name, icd10_code)
```

**Checks performed (rule-based overrides on LLM output):**
1. Is this drug+ICD-10 combination in the approved indications list?
2. Is step therapy documented (e.g., metformin trial before SGLT2i for diabetes)?
3. Are all required documents present in the submission?
4. Are there active policy exclusion clauses (concurrent ACEi + Entresto)?

**Output decision:** `APPROVED | DENIED | PEND | QUERY | SUSPENDED`

### Agent 4 — Form Filler + Schema Validator

**Responsibility:** Aggregate all agent outputs into a valid PA JSON payload.

**JSON Schema enforcement:**
```python
jsonschema.validate(pa_form, PA_SCHEMA)
# Required fields: request_id, timestamp, patient, clinical, coding,
#                  policy_check, workflow_status, agent_trace
# Pattern: request_id matches "^PA-[0-9]{8}-[A-Z0-9]{6}$"
```

If schema validation fails, the result is flagged before transmission to the claims system — preventing downstream parse errors.

---

## A2A Message Bus

Every inter-agent handoff is logged:

```
[10:32:15] Agent1_Extractor → Agent2_ICDCoder   |   85ms | keys=[condition, drug, phi_masked, ...]
[10:32:15] Agent2_ICDCoder  → Agent3_PolicyRAG  |   95ms | keys=[icd10_code, confidence, ...]
[10:32:15] Agent3_PolicyRAG → Agent4_FormFiller |  180ms | keys=[policy_id, decision, ...]
[10:32:16] Agent4_FormFiller → OUTPUT           |   60ms | keys=[request_id, workflow_status, ...]
```

This trace is embedded in the final PA payload under `agent_trace[]`. Benefits:
- **Audit trail**: which agent made which decision, when
- **Debugging**: where in the pipeline a failure occurred
- **Latency analysis**: which agent is the bottleneck

---

## Evaluation Results

| Metric | Monolithic LLM | Multi-Agent A2A |
|--------|----------------|-----------------|
| Decision Accuracy | 70% | 100% |
| PHI Masking Rate | 0% | 100% |
| Schema Validity | 80% | 100% |
| Avg E2E Latency | ~2,200ms | ~395ms |
| Confidence Gate Triggers | 0/10 | 2/10 |

**Critical finding:** The monolithic LLM approves all 10 cases. Three of those ten should be denied. In healthcare insurance this means:
- Wrongful reimbursement for pembrolizumab in an EGFR-mutant patient (clinical harm + $15,000/month)
- Wrongful reimbursement for upadacitinib without TNF inhibitor step ($5,400/month)
- Wrongful approval for Entresto with concurrent ACEi (patient safety risk)

---

## Azure AI Foundry Deployment

See `configs/azure_foundry_setup.md` for full deployment guide. Summary:

```python
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential

client = AIProjectClient(
    endpoint=os.environ["AZURE_AI_PROJECT_ENDPOINT"],
    credential=DefaultAzureCredential()
)

# Create each agent as an Azure Foundry Agent with dedicated tools
extractor_agent = client.agents.create_agent(
    model="gpt-4o",
    name="PA_Extractor",
    instructions=EXTRACTION_SYSTEM_PROMPT,
    toolset=ToolSet([phi_masker_tool, entity_extractor_tool])
)

icd_coder_agent = client.agents.create_agent(
    model="gpt-4o",
    name="PA_ICDCoder",
    instructions=ICD_CODING_SYSTEM_PROMPT,
    toolset=ToolSet([kg_lookup_tool, confidence_gate_tool])
)
# etc.

# A2A orchestration via shared Thread
thread = client.agents.create_thread()
# Each agent reads the thread context from the previous agent's message
```

---

## AutoGen Alternative

See `configs/autogen_alternative.md`. The AutoGen GroupChat pattern:

```python
import autogen

extractor   = autogen.AssistantAgent("Extractor",   llm_config=llm_config, system_message=EXTRACTION_PROMPT)
icd_coder   = autogen.AssistantAgent("ICDCoder",    llm_config=llm_config, system_message=ICD_PROMPT)
policy_rag  = autogen.AssistantAgent("PolicyRAG",   llm_config=llm_config, system_message=POLICY_PROMPT)
form_filler = autogen.AssistantAgent("FormFiller",  llm_config=llm_config, system_message=FORM_PROMPT)
orchestrator = autogen.UserProxyAgent("Orchestrator", human_input_mode="NEVER")

group_chat = autogen.GroupChat(
    agents=[orchestrator, extractor, icd_coder, policy_rag, form_filler],
    speaker_selection_method="round_robin",
    max_round=4
)
```

---

## PA Case Summary

| Case | Condition | Drug | Outcome |
|------|-----------|------|---------|
| CASE_001 | NSCLC + EGFR del19 | Osimertinib | ✅ APPROVED |
| CASE_002 | Atrial Fibrillation (ambiguous) | Apixaban | ❓ QUERY |
| CASE_003 | ATTR Amyloidosis (rare) | Tafamidis | ⛔ SUSPENDED |
| CASE_004 | RA (no prior TNF inhibitor) | Upadacitinib | ❌ DENIED |
| CASE_005 | HFrEF + T2DM-CKD | Dapagliflozin | ✅ APPROVED |
| CASE_006 | NSCLC + EGFR + high PD-L1 | Pembrolizumab | ❌ DENIED |
| CASE_007 | HFrEF + concurrent ACEi | Sacubitril-val | ❌ DENIED |
| CASE_008 | RRMS | Ocrelizumab | ✅ APPROVED |
| CASE_009 | Misspelled "fibromylagia" | Duloxetine | ⛔ SUSPENDED |
| CASE_010 | T2DM (missing HbA1c) | Semaglutide | ⏳ PEND |


*CitiusTech Gen AI & Agentic AI Training Program — one Project 4 of 5*
