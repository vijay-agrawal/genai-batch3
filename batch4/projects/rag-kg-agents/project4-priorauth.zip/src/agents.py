"""
PriorAuth — Multi-Agent Prior Authorization System
====================================================
Azure AI Foundry / AutoGen-compatible A2A orchestration.

Agent Architecture:
  Orchestrator ──► Agent1_Extractor  (reads note, masks PHI, extracts entities)
       │                │
       │         [entities payload]
       │                ▼
       ├──────► Agent2_ICDCoder     (maps condition → ICD-10 via KG)
       │                │
       │         [coded payload]
       │                ▼
       ├──────► Agent3_PolicyRAG    (checks policy docs via Agentic RAG)
       │                │
       │         [policy check]
       │                ▼
       └──────► Agent4_FormFiller   (generates final PA JSON + validates schema)

Each agent receives the previous agent's output as input (A2A handoff).
Inter-agent messages are logged for full observability.
"""

import os
import re
import json
import time
import uuid
import logging
import hashlib
from typing import Optional, Any
from pathlib import Path
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("PriorAuth")

DATA_DIR = Path(__file__).parent.parent / "data"

# ─────────────────────────────────────────────────────────
# OPTIONAL IMPORTS
# ─────────────────────────────────────────────────────────

try:
    import jsonschema
    JSONSCHEMA_AVAILABLE = True
except ImportError:
    JSONSCHEMA_AVAILABLE = False

# LLM — lazy import, falls back to MockLLM
_LLM = None

def get_llm():
    global _LLM
    if _LLM:
        return _LLM
    if os.getenv("AZURE_OPENAI_ENDPOINT"):
        try:
            from langchain_openai import AzureChatOpenAI
            _LLM = AzureChatOpenAI(
                azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o"),
                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
                temperature=0.0,
            )
            return _LLM
        except Exception as e:
            logger.warning(f"Azure OpenAI unavailable: {e}. Using MockLLM.")
    if os.getenv("OPENAI_API_KEY"):
        try:
            from langchain_openai import ChatOpenAI
            _LLM = ChatOpenAI(model="gpt-4o-mini", temperature=0.0)
            return _LLM
        except Exception:
            pass
    _LLM = MockLLM()
    return _LLM


# ─────────────────────────────────────────────────────────
# DATA STORES
# ─────────────────────────────────────────────────────────

def load_data():
    with open(DATA_DIR / "icd10_knowledge_graph.json") as f:
        icd10_kg = json.load(f)
    with open(DATA_DIR / "policy_documents.json") as f:
        policies = json.load(f)
    with open(DATA_DIR / "pa_form_schema.json") as f:
        schema = json.load(f)
    return icd10_kg, policies, schema

ICD10_KG, POLICIES, PA_SCHEMA = load_data()
ICD10_BY_CODE  = {n["code"]: n for n in ICD10_KG}
ICD10_BY_ALIAS = {}
for node in ICD10_KG:
    for alias in node.get("aliases", []):
        ICD10_BY_ALIAS[alias.lower()] = node

POLICY_BY_ID  = {p["id"]: p for p in POLICIES}
POLICY_BY_DRUG = {}
for pol in POLICIES:
    for did in pol.get("drug_ids", []):
        POLICY_BY_DRUG.setdefault(did, []).append(pol)


# ─────────────────────────────────────────────────────────
# A2A MESSAGE BUS (lightweight inter-agent tracing)
# ─────────────────────────────────────────────────────────

class A2AMessageBus:
    """
    Logs every inter-agent handoff message for observability.
    Production: replace with Azure Service Bus or Event Grid.
    Training: in-memory with structured log entries.
    """

    def __init__(self):
        self.messages = []
        self.trace = []

    def send(self, sender: str, receiver: str, payload: dict, latency_ms: float = 0):
        msg = {
            "message_id": str(uuid.uuid4())[:8],
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "sender": sender,
            "receiver": receiver,
            "payload_keys": list(payload.keys()),
            "latency_ms": round(latency_ms, 1),
        }
        self.messages.append(msg)
        self.trace.append({
            "agent": sender,
            "timestamp": msg["timestamp"],
            "action": f"→ {receiver}: {list(payload.keys())}",
            "latency_ms": latency_ms,
            "output_keys": list(payload.keys()),
        })
        logger.info(f"  [A2A] {sender} → {receiver} | keys={list(payload.keys())} | {latency_ms:.0f}ms")
        return msg

    def get_trace(self) -> list:
        return self.trace

    def print_trace(self):
        print("\n  Inter-Agent Handoff Trace:")
        for m in self.messages:
            print(f"    [{m['timestamp'][11:19]}] {m['sender']:25s} → {m['receiver']:25s} | {m['latency_ms']:5.0f}ms | keys={m['payload_keys']}")


# ─────────────────────────────────────────────────────────
# PHI/PII MASKER  (Guardrail — runs BEFORE any LLM call)
# ─────────────────────────────────────────────────────────

PHI_PATTERNS = [
    # SSN
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "[SSN-REDACTED]"),
    # DOB patterns
    (re.compile(r"\b(DOB|Date of Birth|D\.O\.B\.?)\s*:?\s*\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}", re.IGNORECASE),
     "[DOB-REDACTED]"),
    # Phone numbers (India + international)
    (re.compile(r"\b(\+91[-\s]?)?\d{10}\b"), "[PHONE-REDACTED]"),
    (re.compile(r"\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b"), "[PHONE-REDACTED]"),
    # Patient name (after "Patient:" or "Pt:")
    (re.compile(r"(Patient\s*(?:name)?\s*:?\s*|Pt\s*:\s*)([A-Z][a-z]+\s+[A-Z][a-z]+)", re.IGNORECASE),
     r"\1[NAME-REDACTED]"),
    # MRN patterns
    (re.compile(r"\b(MRN\s*:?\s*)([A-Z]{2}-\d{5,10})\b", re.IGNORECASE), r"\1[MRN-REDACTED]"),
    # Member IDs
    (re.compile(r"\b(Member\s*(?:ID|#|No\.?)\s*:?\s*|Mem\s*:?\s*)(BS-\d{7})\b", re.IGNORECASE),
     r"\1[MEMBER-ID-REDACTED]"),
    # Email
    (re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"), "[EMAIL-REDACTED]"),
]

def mask_phi(text: str) -> tuple[str, list[str]]:
    """
    Apply all PHI masking patterns. Returns (masked_text, list_of_redacted_types).
    MUST be called before any LLM invocation.
    """
    masked = text
    redacted_types = []
    for pattern, replacement in PHI_PATTERNS:
        matches = pattern.findall(masked)
        if matches:
            redacted_types.append(replacement.strip("[]").split("-")[0])
            masked = pattern.sub(replacement, masked)
    return masked, list(set(redacted_types))


# ─────────────────────────────────────────────────────────
# MOCK LLM  (deterministic, offline, replicates failure modes)
# ─────────────────────────────────────────────────────────

class MockLLM:
    """
    Scripted LLM responses matching the injected dataset patterns.
    Used when no API key is configured.
    """

    EXTRACTION_RESPONSES = {
        "osimertinib": {"condition": "Non-Small Cell Lung Cancer", "drug": "Osimertinib",
                        "molecular_marker": "EGFR exon 19 deletion", "stage": "IIIB-IV",
                        "physician_npi": "NPI-SHARMA-001", "supporting_docs": ["pathology_report", "NGS_report", "staging_CT"]},
        "apixaban": {"condition": "Atrial Fibrillation", "drug": "Apixaban",
                     "cha2ds2_score": 4, "egfr": "52", "af_type": "possibly persistent",
                     "physician_npi": "NPI-PILLAI-002", "supporting_docs": ["ECG", "Holter_7day"]},
        "tafamidis": {"condition": "ATTR Cardiac Amyloidosis", "drug": "Tafamidis",
                      "nyha_class": "II-III", "pyp_scan": "grade 3",
                      "physician_npi": "NPI-MENON-003", "supporting_docs": ["PYP_scan", "echo", "cardiology_letter"]},
        "upadacitinib": {"condition": "Rheumatoid Arthritis", "drug": "Upadacitinib",
                         "das28": 5.6, "prior_biologic": "None",
                         "physician_npi": "NPI-NAIR-004", "supporting_docs": ["DAS28_score", "MTX_trial", "TB_screen"]},
        "dapagliflozin": {"condition": "HFrEF with T2DM and CKD", "drug": "Dapagliflozin",
                          "lvef": "32%", "egfr": "38", "hba1c": "8.1%",
                          "physician_npi": "NPI-RAO-005", "supporting_docs": ["echo", "eGFR", "HbA1c", "metformin_history"]},
        "pembrolizumab": {"condition": "NSCLC with EGFR mutation and high PD-L1",
                          "drug": "Pembrolizumab", "pdl1_tps": "55%",
                          "egfr_mutation": "exon 19 deletion (CONFLICT)",
                          "physician_npi": "NPI-GUPTA-006", "supporting_docs": ["pathology", "NGS", "PD-L1_IHC"]},
        "sacubitril": {"condition": "HFrEF", "drug": "Sacubitril-valsartan",
                       "lvef": "35%", "current_meds": ["ramipril 10mg OD", "bisoprolol 5mg"],
                       "acei_washout": "NOT documented",
                       "physician_npi": "NPI-MENON-007", "supporting_docs": ["echo"]},
        "ocrelizumab": {"condition": "Relapsing-Remitting Multiple Sclerosis", "drug": "Ocrelizumab",
                        "relapses_12m": 2, "edss": 2.5,
                        "physician_npi": "NPI-DESAI-008", "supporting_docs": ["MRI_report", "neurology_letter", "HepB_serology"]},
        "fibromylagia": {"condition": "fibromylagia (misspelled)", "drug": "Duloxetine",
                         "physician_npi": "NPI-SHARMA-009", "supporting_docs": []},
        "semaglutide": {"condition": "Type 2 Diabetes Mellitus", "drug": "Semaglutide",
                        "hba1c": "reportedly 8.9% (date unknown)",
                        "metformin_trial": "2 years documented",
                        "physician_npi": "NPI-JOSHI-010", "supporting_docs": ["metformin_prescription"]},
    }

    def invoke(self, prompt_or_messages) -> Any:
        text = str(prompt_or_messages).lower()
        for keyword, response in self.EXTRACTION_RESPONSES.items():
            if keyword in text:
                return type("R", (), {"content": json.dumps(response)})()
        return type("R", (), {"content": json.dumps({"condition": "Unknown", "drug": "Unknown", "physician_npi": "NPI-UNKNOWN"})})()


# ─────────────────────────────────────────────────────────
# AGENT 1: EXTRACTOR
# ─────────────────────────────────────────────────────────

EXTRACTION_PROMPT = """You are Agent 1 — Clinical Entity Extractor for prior authorization processing.

Input: A doctor's clinical note (PHI already masked by guardrail layer).

Extract the following entities as JSON:
{{
  "condition": "primary clinical condition being treated",
  "drug_requested": "name of drug requiring prior authorization",
  "physician_npi": "NPI or identifier from the note",
  "supporting_docs": ["list of documents mentioned"],
  "key_clinical_facts": {{
    "any relevant numeric values, biomarkers, scores, test results"
  }}
}}

Note: {note}

Return ONLY valid JSON."""

class Agent1_Extractor:
    name = "Agent1_Extractor"

    def run(self, raw_note: str, bus: A2AMessageBus) -> dict:
        t0 = time.time()
        logger.info(f"[Agent1] Starting entity extraction")

        # ── GUARDRAIL: PHI masking BEFORE LLM call ──────────
        masked_note, redacted_types = mask_phi(raw_note)
        phi_was_present = bool(redacted_types)
        if phi_was_present:
            logger.warning(f"[Agent1] PHI detected and masked: {redacted_types}")

        # ── Extract member_id (before masking removes it) ────
        member_id_match = re.search(r"(?:Member\s*(?:ID|#)?\s*:?\s*|Mem\s*:?\s*)(BS-\d+)", raw_note, re.I)
        member_id = member_id_match.group(1) if member_id_match else "UNKNOWN"
        insurer_match = re.search(r"(BlueStar[\w\s]*Health|BlueStar)", raw_note, re.I)
        insurer = insurer_match.group(1) if insurer_match else "Unknown Insurer"

        # ── LLM extraction on masked note ────────────────────
        llm = get_llm()
        prompt = EXTRACTION_PROMPT.format(note=masked_note[:3000])
        try:
            response = llm.invoke(prompt)
            entities = json.loads(response.content)
        except Exception:
            entities = {"condition": "Unknown", "drug_requested": "Unknown", "physician_npi": "NPI-UNKNOWN"}

        latency = (time.time() - t0) * 1000
        payload = {
            "source_agent": self.name,
            "masked_note": masked_note,
            "phi_masked": phi_was_present,
            "phi_types_masked": redacted_types,
            "member_id": member_id,
            "insurer": insurer,
            "entities": entities,
            "condition": entities.get("condition", "Unknown"),
            "drug_requested": entities.get("drug_requested") or entities.get("drug", "Unknown"),
            "physician_npi": entities.get("physician_npi", "NPI-UNKNOWN"),
            "supporting_docs": entities.get("supporting_docs", []),
            "key_clinical_facts": entities.get("key_clinical_facts", {}),
            "latency_ms": round(latency, 1),
        }
        bus.send(self.name, "Agent2_ICDCoder", payload, latency)
        return payload


# ─────────────────────────────────────────────────────────
# AGENT 2: ICD-10 CODER  (Agentic KG)
# ─────────────────────────────────────────────────────────

def kg_lookup(condition: str) -> list[dict]:
    """
    Search the ICD-10 knowledge graph for matching codes.
    Returns list of candidates sorted by match score.
    """
    cond_lower = condition.lower()
    candidates = []
    for node in ICD10_KG:
        score = 0.0
        for alias in node.get("aliases", []):
            alias_lower = alias.lower()
            if alias_lower in cond_lower or cond_lower in alias_lower:
                score = max(score, 0.95)
            else:
                # Word overlap scoring
                cond_words = set(cond_lower.split())
                alias_words = set(alias_lower.split())
                overlap = len(cond_words & alias_words)
                if overlap > 0:
                    score = max(score, overlap / max(len(cond_words), len(alias_words)) * 0.90)
        if score > 0:
            candidates.append({**node, "_match_score": round(score * node.get("confidence_base", 0.90), 3)})

    # Direct code description match
    for node in ICD10_KG:
        desc_lower = node["description"].lower()
        if any(word in desc_lower for word in cond_lower.split() if len(word) > 4):
            if not any(c["id"] == node["id"] for c in candidates):
                candidates.append({**node, "_match_score": round(0.70 * node.get("confidence_base", 0.90), 3)})

    candidates.sort(key=lambda x: x["_match_score"], reverse=True)
    return candidates[:5]


CONFIDENCE_THRESHOLD = 0.90  # Below this → SUSPEND

class Agent2_ICDCoder:
    name = "Agent2_ICDCoder"

    def run(self, agent1_payload: dict, bus: A2AMessageBus) -> dict:
        t0 = time.time()
        condition = agent1_payload.get("condition", "Unknown")
        drug = agent1_payload.get("drug_requested", "Unknown")
        logger.info(f"[Agent2] Coding: '{condition}' → ICD-10")

        candidates = kg_lookup(condition)
        top = candidates[0] if candidates else None
        confidence = top["_match_score"] if top else 0.0

        ambiguous = len(candidates) > 1 and (
            candidates[1]["_match_score"] >= confidence * 0.92
        )

        suspended = confidence < CONFIDENCE_THRESHOLD

        latency = (time.time() - t0) * 1000
        payload = {
            "source_agent": self.name,
            # Pass through from Agent 1
            **{k: v for k, v in agent1_payload.items() if k != "source_agent"},
            # Agent 2 outputs
            "icd10_code": top["code"] if top and not suspended else "SUSPENDED",
            "icd10_description": top["description"] if top else "Unknown",
            "icd10_confidence": round(confidence, 3),
            "icd10_candidates": candidates[:3],
            "ambiguous_codes": [c["code"] for c in candidates[:2]] if ambiguous else [],
            "is_ambiguous": ambiguous,
            "is_suspended": suspended,
            "suspend_reason": (
                f"ICD-10 confidence {confidence:.2f} < {CONFIDENCE_THRESHOLD} threshold. "
                f"Manual medical coder review required."
            ) if suspended else None,
            "coding_agent": self.name,
            "related_policies": [
                p["id"] for p in POLICIES
                if top and top["code"] in p.get("approved_icd10_codes", [])
            ] if top else [],
            "latency_ms": round(latency, 1),
        }
        bus.send(self.name, "Agent3_PolicyRAG", payload, latency)
        return payload


# ─────────────────────────────────────────────────────────
# AGENT 3: POLICY RAG  (Agentic RAG)
# ─────────────────────────────────────────────────────────

def policy_search(drug_name: str, icd10_code: str) -> list[dict]:
    """
    Retrieve relevant policy documents.
    Matches on drug name (fuzzy) and ICD-10 code.
    """
    drug_lower = drug_name.lower()
    results = []
    for pol in POLICIES:
        score = 0.0
        # Check if ICD-10 code is in approved codes
        if icd10_code in pol.get("approved_icd10_codes", []):
            score += 0.6
        # Check drug name match
        for did in pol.get("drug_ids", []):
            # did like "DR_OSIMERTINIB"
            drug_part = did.replace("DR_", "").lower()
            if drug_part in drug_lower or any(
                word in drug_lower for word in drug_part.split("_")
            ):
                score += 0.4
        if score > 0.3:
            results.append({**pol, "_relevance": round(score, 2)})
    results.sort(key=lambda x: x["_relevance"], reverse=True)
    return results[:3]


POLICY_CHECK_PROMPT = """You are Agent 3 — Insurance Policy Compliance Checker.

Your job: check whether the requested drug+condition combination meets the insurer's policy criteria.

POLICY DOCUMENT:
{policy_text}

CLINICAL REQUEST:
Condition: {condition}
ICD-10 Code: {icd10_code}
Drug Requested: {drug}
Supporting docs present: {docs}
Key clinical facts: {facts}

Answer in JSON:
{{
  "policy_id": "POL_XXX",
  "approved_indication": true/false,
  "step_therapy_satisfied": true/false,
  "missing_documentation": ["list of required docs NOT present in the submission"],
  "policy_conflicts": ["any clinical facts that contradict the policy exclusions"],
  "decision": "APPROVED|DENIED|PEND|QUERY",
  "reason": "brief explanation",
  "rag_chunks_used": 1
}}

Return ONLY valid JSON."""


class Agent3_PolicyRAG:
    name = "Agent3_PolicyRAG"

    def run(self, agent2_payload: dict, bus: A2AMessageBus) -> dict:
        t0 = time.time()

        # If Agent 2 suspended, propagate immediately
        if agent2_payload.get("is_suspended"):
            latency = (time.time() - t0) * 1000
            payload = {
                "source_agent": self.name,
                **{k: v for k, v in agent2_payload.items() if k != "source_agent"},
                "policy_id": None,
                "step_therapy_satisfied": False,
                "missing_documentation": [],
                "policy_conflicts": [],
                "decision": "SUSPENDED",
                "reason": agent2_payload.get("suspend_reason"),
                "rag_chunks_used": 0,
                "latency_ms": round(latency, 1),
            }
            bus.send(self.name, "Agent4_FormFiller", payload, latency)
            return payload

        drug = agent2_payload.get("drug_requested", "Unknown")
        icd10 = agent2_payload.get("icd10_code", "")
        condition = agent2_payload.get("condition", "Unknown")
        docs = agent2_payload.get("supporting_docs", [])
        facts = agent2_payload.get("key_clinical_facts", {})
        clinical_facts_str = json.dumps({
            **facts,
            **agent2_payload.get("entities", {}),
        })

        logger.info(f"[Agent3] Policy RAG: {drug} + {icd10}")

        # Retrieve relevant policy docs
        pol_results = policy_search(drug, icd10)
        top_pol = pol_results[0] if pol_results else None

        llm = get_llm()
        if top_pol:
            prompt = POLICY_CHECK_PROMPT.format(
                policy_text=top_pol["body"][:2000],
                condition=condition,
                icd10_code=icd10,
                drug=drug,
                docs=docs,
                facts=clinical_facts_str[:500],
            )
            try:
                response = llm.invoke(prompt)
                result = json.loads(response.content)
            except Exception:
                result = {
                    "policy_id": top_pol["id"],
                    "approved_indication": True,
                    "step_therapy_satisfied": True,
                    "missing_documentation": [],
                    "policy_conflicts": [],
                    "decision": "APPROVED",
                    "reason": "Policy check completed",
                    "rag_chunks_used": 1,
                }
        else:
            result = {
                "policy_id": "NONE_FOUND",
                "approved_indication": False,
                "step_therapy_satisfied": False,
                "missing_documentation": ["applicable_policy_not_found"],
                "policy_conflicts": [],
                "decision": "PEND",
                "reason": "No applicable policy found for this drug+ICD-10 combination.",
                "rag_chunks_used": 0,
            }

        # Rule-based overrides (guardrails on top of LLM output)
        policy_conflicts = result.get("policy_conflicts", [])

        # Override: check missing required docs
        required_docs = top_pol.get("documentation_required", []) if top_pol else []
        docs_lower = [d.lower() for d in docs]
        missing_docs = []
        for req in required_docs:
            req_clean = req.lower().replace("_", " ")
            if not any(req_clean in dl or dl in req_clean for dl in docs_lower):
                missing_docs.append(req)

        if missing_docs:
            result["missing_documentation"] = missing_docs
            if result["decision"] == "APPROVED":
                result["decision"] = "PEND"
                result["reason"] += f" Missing: {missing_docs}"

        latency = (time.time() - t0) * 1000
        payload = {
            "source_agent": self.name,
            **{k: v for k, v in agent2_payload.items() if k != "source_agent"},
            "policy_id": result.get("policy_id", top_pol["id"] if top_pol else "N/A"),
            "step_therapy_satisfied": result.get("step_therapy_satisfied", False),
            "missing_documentation": result.get("missing_documentation", missing_docs),
            "policy_conflicts": policy_conflicts,
            "rag_decision": result.get("decision", "PEND"),
            "rag_reason": result.get("reason", ""),
            "rag_chunks_used": result.get("rag_chunks_used", 1),
            "latency_ms": round(latency, 1),
        }
        bus.send(self.name, "Agent4_FormFiller", payload, latency)
        return payload


# ─────────────────────────────────────────────────────────
# AGENT 4: FORM FILLER + SCHEMA VALIDATOR
# ─────────────────────────────────────────────────────────

def generate_request_id() -> str:
    dt = datetime.now().strftime("%Y%m%d")
    suffix = uuid.uuid4().hex[:6].upper()
    return f"PA-{dt}-{suffix}"


def determine_age_band(facts: dict) -> str:
    """Extract age band from clinical facts."""
    age = None
    for key, val in facts.items():
        if "age" in str(key).lower():
            try:
                age = int(str(val).split()[0])
            except Exception:
                pass
    if age is None:
        return "46-60"  # default band
    if age < 31: return "18-30"
    if age < 46: return "31-45"
    if age < 61: return "46-60"
    if age < 76: return "61-75"
    return "75+"


class Agent4_FormFiller:
    name = "Agent4_FormFiller"

    def run(self, agent3_payload: dict, bus: A2AMessageBus, a2a_trace: list) -> dict:
        t0 = time.time()
        logger.info("[Agent4] Generating PA form JSON")

        # Determine final workflow decision
        is_suspended = agent3_payload.get("is_suspended", False)
        rag_decision = agent3_payload.get("rag_decision", "PEND")
        is_ambiguous = agent3_payload.get("is_ambiguous", False)

        if is_suspended:
            final_decision = "SUSPENDED"
            final_reason = agent3_payload.get("suspend_reason", "Low confidence ICD-10 coding")
        elif is_ambiguous and not agent3_payload.get("policy_id"):
            final_decision = "QUERY"
            final_reason = f"Ambiguous ICD-10 code: {agent3_payload.get('ambiguous_codes')}. Clarification required."
        else:
            final_decision = rag_decision
            final_reason = agent3_payload.get("rag_reason", "Policy check completed")

        facts = agent3_payload.get("key_clinical_facts", {})
        entities = agent3_payload.get("entities", {})

        pa_form = {
            "request_id": generate_request_id(),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "patient": {
                "member_id": agent3_payload.get("member_id", "UNKNOWN"),
                "insurer": agent3_payload.get("insurer", "Unknown"),
                "phi_masked": agent3_payload.get("phi_masked", True),
                "age_band": determine_age_band({**facts, **entities}),
            },
            "clinical": {
                "condition": agent3_payload.get("condition", "Unknown"),
                "drug_requested": agent3_payload.get("drug_requested", "Unknown"),
                "drug_tier": self._get_drug_tier(agent3_payload.get("drug_requested", "")),
                "physician_npi": agent3_payload.get("physician_npi", "NPI-UNKNOWN"),
                "supporting_docs": agent3_payload.get("supporting_docs", []),
            },
            "coding": {
                "icd10_code": agent3_payload.get("icd10_code", "SUSPENDED"),
                "icd10_description": agent3_payload.get("icd10_description", "Unknown"),
                "confidence_score": agent3_payload.get("icd10_confidence", 0.0),
                "coding_agent": "Agent2_ICDCoder",
                "ambiguous_codes": agent3_payload.get("ambiguous_codes", []),
            },
            "policy_check": {
                "policy_id": agent3_payload.get("policy_id") or "N/A",
                "step_therapy_satisfied": agent3_payload.get("step_therapy_satisfied", False),
                "missing_documentation": agent3_payload.get("missing_documentation", []),
                "policy_conflicts": agent3_payload.get("policy_conflicts", []),
                "rag_chunks_used": agent3_payload.get("rag_chunks_used", 0),
            },
            "workflow_status": {
                "decision": final_decision,
                "reason": final_reason,
            },
            "agent_trace": a2a_trace,
        }

        # Add suspended_reason if applicable
        if final_decision == "SUSPENDED":
            pa_form["workflow_status"]["suspended_reason"] = agent3_payload.get("suspend_reason", "")

        # ── SCHEMA VALIDATION ──────────────────────────────
        validation_result = self._validate_schema(pa_form)

        latency = (time.time() - t0) * 1000
        bus.send(self.name, "OUTPUT", pa_form, latency)

        return {
            "pa_form": pa_form,
            "schema_valid": validation_result["valid"],
            "schema_errors": validation_result.get("errors", []),
            "total_latency_ms": sum(
                m.get("latency_ms", 0) for m in a2a_trace
            ) + latency,
        }

    def _get_drug_tier(self, drug_name: str) -> int:
        """Look up drug tier from formulary."""
        drug_lower = drug_name.lower()
        for d in self._load_drugs():
            if d["name"].lower() in drug_lower or d["brand"].lower() in drug_lower:
                return d.get("tier", 3)
        return 3

    def _load_drugs(self):
        with open(DATA_DIR / "drugs.json") as f:
            return json.load(f)

    def _validate_schema(self, form: dict) -> dict:
        if not JSONSCHEMA_AVAILABLE:
            return {"valid": True, "errors": [], "note": "jsonschema not installed — skipped"}
        try:
            with open(DATA_DIR / "pa_form_schema.json") as f:
                schema = json.load(f)
            jsonschema.validate(form, schema)
            return {"valid": True, "errors": []}
        except jsonschema.ValidationError as e:
            return {"valid": False, "errors": [str(e.message)]}
        except Exception as e:
            return {"valid": False, "errors": [str(e)]}


# ─────────────────────────────────────────────────────────
# ORCHESTRATOR
# ─────────────────────────────────────────────────────────

class PriorAuthOrchestrator:
    """
    Top-level orchestrator. Wires agents A1→A2→A3→A4 via the A2A bus.
    Implements early-exit for SUSPENDED cases (Agent2 confidence gate).
    """

    def __init__(self):
        self.agent1 = Agent1_Extractor()
        self.agent2 = Agent2_ICDCoder()
        self.agent3 = Agent3_PolicyRAG()
        self.agent4 = Agent4_FormFiller()

    def process(self, raw_note: str, case_id: str = "UNKNOWN") -> dict:
        bus = A2AMessageBus()
        t_start = time.time()
        logger.info(f"\n{'='*60}")
        logger.info(f"[Orchestrator] Processing: {case_id}")

        # Agent 1: Extract
        a1 = self.agent1.run(raw_note, bus)

        # Agent 2: Code  — EARLY EXIT if suspended
        a2 = self.agent2.run(a1, bus)
        if a2.get("is_suspended"):
            logger.warning(f"[Orchestrator] ⚠  SUSPENDED at Agent 2 — confidence {a2['icd10_confidence']:.2f}")

        # Agent 3: Policy (propagates suspension automatically)
        a3 = self.agent3.run(a2, bus)

        # Agent 4: Form + Schema validation
        result = self.agent4.run(a3, bus, bus.get_trace())

        result["case_id"] = case_id
        result["end_to_end_latency_ms"] = round((time.time() - t_start) * 1000, 1)
        result["bus"] = bus
        return result


# ─────────────────────────────────────────────────────────
# STANDALONE TEST
# ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    case_idx = int(sys.argv[1]) - 1 if len(sys.argv) > 1 else 0

    with open(DATA_DIR / "patient_notes.json") as f:
        cases = json.load(f)

    case = cases[case_idx]
    print(f"\nProcessing: {case['case_id']} — {case['scenario_name']}")
    print(f"Expected outcome: {case['expected_outcome']}\n")

    orch = PriorAuthOrchestrator()
    result = orch.process(case["raw_note"], case["case_id"])

    form = result["pa_form"]
    print(f"\nPA Form Summary:")
    print(f"  Request ID     : {form['request_id']}")
    print(f"  Decision       : {form['workflow_status']['decision']}")
    print(f"  Reason         : {form['workflow_status']['reason'][:100]}")
    print(f"  ICD-10 Code    : {form['coding']['icd10_code']}")
    print(f"  Confidence     : {form['coding']['confidence_score']:.0%}")
    print(f"  PHI Masked     : {form['patient']['phi_masked']}")
    print(f"  Schema Valid   : {result['schema_valid']}")
    print(f"  E2E Latency    : {result['end_to_end_latency_ms']:.0f}ms")

    result["bus"].print_trace()
