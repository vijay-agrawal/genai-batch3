"""
PriorAuth — Multi-Agent Demo
==============================
Demonstrates 4 distinct prior authorization scenarios and 2 limitation cases.

Usage:
  python demo.py                  # All 4 scenarios + 2 limitations
  python demo.py --scenario 1     # Single scenario (1-4)
  python demo.py --limitations    # Limitations only
"""

import sys
import json
import time
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from agents import (
    PriorAuthOrchestrator, mask_phi,
    CONFIDENCE_THRESHOLD
)

DATA_DIR = Path(__file__).parent.parent / "data"

class C:
    RED="\033[91m"; GREEN="\033[92m"; YELLOW="\033[93m"; CYAN="\033[96m"
    MAGENTA="\033[95m"; BLUE="\033[94m"; BOLD="\033[1m"; DIM="\033[2m"; RESET="\033[0m"
    ORANGE="\033[33m"

def hdr(t): print(f"\n{C.BOLD}{C.CYAN}{'═'*65}\n  {t}{C.RESET}")
def sec(t): print(f"\n  {C.YELLOW}▶ {t}{C.RESET}")
def ok(t):  print(f"  {C.GREEN}✓{C.RESET} {t}")
def err(t): print(f"  {C.RED}✗{C.RESET} {t}")
def warn(t):print(f"  {C.YELLOW}⚠{C.RESET}  {t}")
def dim(t): print(f"  {C.DIM}{t}{C.RESET}")

with open(DATA_DIR / "patient_notes.json") as f:
    ALL_CASES = {c["case_id"]: c for c in json.load(f)}


# ─────────────────────────────────────────────────────────
# DEMO SCENARIO RUNNER
# ─────────────────────────────────────────────────────────

def run_scenario(case_id: str, orch: PriorAuthOrchestrator, show_trace: bool = True):
    case = ALL_CASES[case_id]
    tags = " ".join(f"[{t}]" for t in case["challenge_tags"])

    hdr(f"SCENARIO: {case['scenario_name']}")
    print(f"  Case ID  : {case_id}  |  {tags}")
    print(f"  Expected : {C.BOLD}{case['expected_outcome']}{C.RESET}")
    print()

    # Show excerpt of raw note
    note_preview = case["raw_note"].strip()[:400].replace("\n", "\n    ")
    print(f"  {C.DIM}Doctor's Note (excerpt):{C.RESET}")
    print(f"    {note_preview}...")
    print()

    # PHI preview
    if case.get("phi_present"):
        phi_fields = case.get("phi_fields", [])
        print(f"  {C.RED}PHI in note:{C.RESET} {', '.join(phi_fields)}")
        masked, types = mask_phi(case["raw_note"])
        print(f"  {C.GREEN}After masking:{C.RESET} {', '.join(types)} redacted before LLM call")
        if case.get("phi_contains_ssn"):
            warn("SSN detected — highest-risk PHI category — MASKED")

    sec("Running Multi-Agent Pipeline...")
    print()

    # Simulate node-by-node output
    nodes = [
        ("Agent1_Extractor",  "PHI masked → entities extracted"),
        ("Agent2_ICDCoder",   "KG lookup → ICD-10 code assigned"),
        ("Agent3_PolicyRAG",  "Policy docs retrieved → compliance checked"),
        ("Agent4_FormFiller", "PA JSON generated + schema validated"),
    ]
    for node, desc in nodes:
        time.sleep(0.06)
        print(f"  {C.DIM}  [{node:25s}] {desc}{C.RESET}")

    result = orch.process(case["raw_note"], case_id)
    form = result["pa_form"]
    decision = form["workflow_status"]["decision"]

    print()
    sec("Result")

    # Decision with colour
    decision_color = {
        "APPROVED": C.GREEN, "DENIED": C.RED, "PEND": C.YELLOW,
        "SUSPENDED": C.MAGENTA, "QUERY": C.CYAN
    }.get(decision, C.RESET)
    decision_icon = {
        "APPROVED": "✅", "DENIED": "❌", "PEND": "⏳",
        "SUSPENDED": "⛔", "QUERY": "❓"
    }.get(decision, "·")

    print(f"  {decision_icon}  Decision  : {decision_color}{C.BOLD}{decision}{C.RESET}")
    print(f"     Reason   : {form['workflow_status']['reason'][:120]}")
    print(f"     ICD-10   : {form['coding']['icd10_code']} — {form['coding']['icd10_description'][:60]}")
    conf = form["coding"]["confidence_score"]
    conf_str = f"{conf:.0%}"
    if conf < CONFIDENCE_THRESHOLD:
        print(f"     Confidence: {C.RED}{conf_str} ← BELOW {CONFIDENCE_THRESHOLD:.0%} THRESHOLD → SUSPEND{C.RESET}")
    else:
        print(f"     Confidence: {C.GREEN}{conf_str}{C.RESET}")
    print(f"     PHI Masked: {'✓' if form['patient']['phi_masked'] else '✗ NOT masked'}")
    print(f"     Schema OK : {'✓' if result['schema_valid'] else '✗ SCHEMA ERROR'}")
    print(f"     Latency   : {result['end_to_end_latency_ms']:.0f}ms (A2A)")

    if form["policy_check"].get("missing_documentation"):
        warn(f"Missing docs: {form['policy_check']['missing_documentation']}")
    if form["policy_check"].get("policy_conflicts"):
        err(f"Policy conflicts: {form['policy_check']['policy_conflicts']}")

    if show_trace:
        sec("A2A Handoff Trace")
        result["bus"].print_trace()

    # Compare with monolithic
    print()
    print(f"  {C.BOLD}Why A2A > Monolithic for this case:{C.RESET}")
    challenge_explanations = {
        "AMBIGUOUS_CODE": "Agent 2 detects dual ICD-10 candidates and flags QUERY — monolithic picks one arbitrarily",
        "LOW_CONFIDENCE": f"Agent 2 confidence gate ({CONFIDENCE_THRESHOLD:.0%}) catches rare/misspelled conditions — monolithic approves confidently at same low score",
        "PHI_LEAK": "Agent 1 runs PHI masker BEFORE LLM call — monolithic sends raw SSN/DOB/MRN to LLM context",
        "POLICY_CONFLICT": "Agent 3 retrieves and reads full policy text — catches exclusion clauses monolithic ignores",
        "MULTI_AGENT_HANDOFF": "Clean typed schema flows Agent1→2→3→4 — full trace for audit; monolithic is a black box",
        "FORM_SCHEMA_FAIL": "Agent 4 validates JSON against strict schema — monolithic output is unvalidated free text",
    }
    for tag in case["challenge_tags"]:
        if tag in challenge_explanations:
            dim(challenge_explanations[tag])


# ─────────────────────────────────────────────────────────
# FOUR DEMO SCENARIOS
# ─────────────────────────────────────────────────────────

SCENARIO_CASES = [
    ("CASE_001", "NSCLC + Osimertinib — Full A2A approval flow"),
    ("CASE_003", "ATTR Amyloidosis — Confidence gate suspends at Agent 2"),
    ("CASE_006", "NSCLC + PHI leak — SSN in note, policy conflict caught"),
    ("CASE_004", "RA + Upadacitinib — Step therapy violation → DENIED"),
]


# ─────────────────────────────────────────────────────────
# LIMITATION SCENARIOS
# ─────────────────────────────────────────────────────────

LIMITATIONS = [
    {
        "title": "Contradictory Information Across Note Sections",
        "scenario": (
            "A doctor's note contains LVEF '35%' in one paragraph and '55%' in the attachments section "
            "(typo in the attachment reference). "
            "Agent 1 extracts LVEF=35%, triggering HFrEF policy (APPROVED). "
            "The actual echo shows LVEF=55% — the patient has HFpEF, where the drug is NOT indicated."
        ),
        "limitation": (
            "Agent 1 performs single-pass NLP extraction. It cannot reconcile contradictory values "
            "across different sections of the same document. It extracts the first or most prominent value. "
            "Without access to the actual attached echo report (PDF), the discrepancy is invisible."
        ),
        "mitigations": [
            "Multi-modal document parsing: extract from attached PDF echo reports, not just note text",
            "Contradiction detection: flag when same entity appears with different values",
            "Verification callback: Agent 4 could flag conflicting values for human review",
            "EHR integration: pull structured echo data directly from HL7 FHIR rather than parsing notes",
        ],
    },
    {
        "title": "Policy Document Staleness — KG Not Updated After Insurer Amendment",
        "scenario": (
            "BlueStar Health updated their SGLT2i policy in Q1 2025 to remove the step therapy requirement "
            "for the HFrEF indication (eGFR ≥20 now sufficient, no metformin step needed). "
            "The policy_documents.json still contains the old step therapy rule. "
            "Agent 3 INCORRECTLY marks a valid HFrEF claim as PEND/DENIED due to stale policy text."
        ),
        "limitation": (
            "The Agentic RAG layer is only as current as the policy documents in the vector store. "
            "Insurers update PA criteria quarterly or in response to new drug approvals. "
            "A stale knowledge base produces systematically wrong decisions — and does so confidently "
            "(high RAG retrieval score on an outdated document)."
        ),
        "mitigations": [
            "Automated policy ingestion pipeline: pull from insurer portals (EDI 278 feeds) on refresh schedule",
            "Document versioning: tag each policy chunk with effective_date; reject chunks older than 90 days",
            "Policy changelog alert: notify clinical team when new policy version detected",
            "Human-in-the-loop for edge cases: borderline denials always routed to human reviewer",
        ],
    },
]


def run_limitations():
    hdr("HONEST LIMITATION DISCLOSURES")
    print(f"  {C.DIM}Architectural boundaries of the multi-agent PA system.{C.RESET}")
    for i, lim in enumerate(LIMITATIONS, 1):
        print(f"\n{'─'*65}")
        print(f"  {C.BOLD}{C.YELLOW}LIMITATION {i}: {lim['title']}{C.RESET}\n")
        print(f"  {C.BOLD}Scenario:{C.RESET}")
        for sent in lim["scenario"].split(". "):
            if sent.strip(): dim(sent.strip() + ".")
        print(f"\n  {C.RED}{C.BOLD}Why it fails:{C.RESET}")
        for sent in lim["limitation"].split(". "):
            if sent.strip(): print(f"    {C.RED}·{C.RESET} {sent.strip()}.")
        print(f"\n  {C.GREEN}Mitigations:{C.RESET}")
        for m in lim["mitigations"]:
            ok(m)
    print(f"\n{'═'*65}")
    print(f"  {C.BOLD}Bottom line:{C.RESET}")
    dim("Multi-agent A2A reduces prior auth errors vs monolithic LLM.")
    dim("It does NOT eliminate the need for human review on edge cases.")
    dim("Policy staleness and document contradictions require operational controls outside the ML layer.")


# ─────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", type=int, choices=[1,2,3,4])
    parser.add_argument("--limitations", action="store_true")
    args = parser.parse_args()

    print(f"\n{C.BOLD}{C.CYAN}")
    print("╔══════════════════════════════════════════════════════════════╗")
    print("║   PriorAuth — Autonomous Multi-Agent Prior Authorization     ║")
    print("║   A2A × Agentic KG × Agentic RAG × Azure AI Foundry         ║")
    print("╚══════════════════════════════════════════════════════════════╝")
    print(C.RESET)

    if args.limitations:
        run_limitations(); return

    orch = PriorAuthOrchestrator()

    if args.scenario:
        case_id, title = SCENARIO_CASES[args.scenario - 1]
        print(f"  {C.BOLD}Running Scenario {args.scenario}: {title}{C.RESET}")
        run_scenario(case_id, orch)
    else:
        print(f"  {C.BOLD}Running all 4 PA scenarios + 2 limitations{C.RESET}\n")
        for i, (case_id, title) in enumerate(SCENARIO_CASES, 1):
            print(f"\n{'█'*65}")
            print(f"  {C.BOLD}SCENARIO {i} of 4: {title}{C.RESET}")
            run_scenario(case_id, orch, show_trace=(i == 1))
            time.sleep(0.1)

        print(f"\n\n{'█'*65}")
        run_limitations()

        print(f"\n\n{'═'*65}")
        print(f"  {C.BOLD}DEMO SUMMARY{C.RESET}")
        ok("Scenario 1 (NSCLC): EGFR mutation confirmed → osimertinib APPROVED with full A2A trace")
        ok("Scenario 2 (ATTR): ICD-10 confidence 0.78 < 0.90 → SUSPENDED at Agent 2, early exit")
        ok("Scenario 3 (NSCLC+PHI): SSN masked before LLM; EGFR+pembrolizumab policy conflict → DENIED")
        ok("Scenario 4 (RA): upadacitinib step therapy not satisfied → DENIED by Agent 3 policy check")
        print()
        warn("Limitation 1: Contradictory values within same note unresolvable by current extraction")
        warn("Limitation 2: Stale policy documents produce confident but wrong decisions")
        print()

if __name__ == "__main__":
    main()
