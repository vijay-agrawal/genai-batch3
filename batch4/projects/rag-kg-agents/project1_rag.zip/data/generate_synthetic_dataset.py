"""
ClinicalRAG Pro - Synthetic Dataset Generator
==============================================
Generates a synthetic clinical knowledge base with DELIBERATELY INJECTED patterns
that will expose the weaknesses of naive RAG and highlight the value of:
  1. Metadata filtering (date-aware, source-type filtering)
  2. MMR (Maximum Marginal Relevance) for near-duplicate handling
  3. Cross-encoder re-ranking
  4. Hybrid BM25 + dense retrieval
  5. HyDE (Hypothetical Document Embedding)

Dataset composition:
  - discharge_summaries.json     : 60 clinical discharge notes (ICU, Cardiology, Endocrinology)
  - clinical_guidelines.json     : 30 guideline chunks (AHA, ADA, NICE - multiple versions)
  - pubmed_abstracts.json        : 40 research paper abstracts
  - drug_reference.json          : 25 drug monograph entries
  - eval_qa_pairs.json           : 50 labeled QA pairs with ground-truth chunk IDs
  
INJECTED CHALLENGES (documented for trainers):
  [NEAR-DUPLICATE]  - Multiple chunks with 85-95% lexical overlap but different evidence grades
  [TEMPORAL]        - Outdated 2019 guidelines still retrievable alongside 2023 updates
  [SPECIFICITY-GAP] - Generic cardiology chunks rank high for specific HFrEF drug dosing queries
  [TERMINOLOGY]     - Same concept under different names (e.g., eGFR vs GFR vs CrCl)
  [MULTI-HOP]       - Answers require joining information from 2+ chunks
  [RARE-DISEASE]    - Low-frequency medical entities not well-represented in embedding space
"""

import json
import random
import hashlib
from datetime import datetime, timedelta

random.seed(42)

# ─────────────────────────────────────────────
# DISCHARGE SUMMARIES (60 notes)
# ─────────────────────────────────────────────

DISCHARGE_TEMPLATES = [
    # [NEAR-DUPLICATE] HFrEF - slight variation, same semantic content
    {
        "id": "DS001",
        "type": "discharge_summary",
        "department": "Cardiology",
        "icd10": "I50.20",
        "condition": "HFrEF",
        "date": "2024-03-15",
        "evidence_level": "A",
        "text": (
            "DISCHARGE SUMMARY - CARDIOLOGY\n"
            "Patient: 68M with Heart Failure with Reduced Ejection Fraction (HFrEF), EF 32%.\n"
            "Hospital Course: Patient admitted with decompensated heart failure. Euvolemia achieved with IV furosemide.\n"
            "Medications at Discharge: Carvedilol 25mg BID, Lisinopril 10mg daily, Furosemide 40mg daily, "
            "Spironolactone 25mg daily, Dapagliflozin 10mg daily.\n"
            "Target Doses: Carvedilol target 25mg BID per 2022 AHA/ACC guidelines. "
            "ACE inhibitor or ARB mandatory. SGLT2i recommended for HFrEF with NTproBNP >1000.\n"
            "Follow-up: Cardiology in 2 weeks. Repeat Echo in 3 months."
        ),
        "challenge_tags": ["NEAR-DUPLICATE"],
        "source": "CitiusTech Synthetic EHR v1"
    },
    {
        "id": "DS002",
        "type": "discharge_summary",
        "department": "Cardiology",
        "icd10": "I50.20",
        "condition": "HFrEF",
        "date": "2024-03-22",
        "evidence_level": "A",
        "text": (
            "DISCHARGE SUMMARY - HEART FAILURE UNIT\n"
            "Patient: 71M with reduced ejection fraction heart failure, LVEF 30%.\n"
            "Inpatient Course: Admitted for acute decompensated HF, decongested with loop diuresis.\n"
            "Discharge Medications: Carvedilol 25mg twice daily, Lisinopril 10mg once daily, "
            "Furosemide 40mg QD, Eplerenone 25mg daily, Empagliflozin 10mg daily.\n"
            "Guideline-Directed Medical Therapy: Beta-blocker, RAAS blockade, MRA and SGLT2 inhibitor "
            "all initiated per 2022 ACC/AHA HF guidelines for Class I indication.\n"
            "Disposition: Stable, follow up in 2 weeks."
        ),
        "challenge_tags": ["NEAR-DUPLICATE"],
        "source": "CitiusTech Synthetic EHR v1"
    },
    # [TEMPORAL] Outdated note with old dosing
    {
        "id": "DS003",
        "type": "discharge_summary",
        "department": "Cardiology",
        "icd10": "I50.20",
        "condition": "HFrEF",
        "date": "2019-11-10",
        "evidence_level": "B",
        "text": (
            "DISCHARGE SUMMARY - CARDIOLOGY (2019)\n"
            "Patient: 64F, HF with EF 35%.\n"
            "Treatment: Patient initiated on Carvedilol 12.5mg BID and Enalapril 5mg BID. "
            "Spironolactone added at 12.5mg daily per RALES trial. "
            "Note: SGLT2 inhibitors not yet guideline-indicated for HF at this time.\n"
            "Plan: Uptitrate beta-blocker at 2-week follow-up."
        ),
        "challenge_tags": ["TEMPORAL"],
        "source": "CitiusTech Synthetic EHR v1"
    },
    # [SPECIFICITY-GAP] Generic cardiology note ranks for HFrEF queries
    {
        "id": "DS004",
        "type": "discharge_summary",
        "department": "Cardiology",
        "icd10": "I51.9",
        "condition": "Cardiomyopathy_general",
        "date": "2024-01-08",
        "evidence_level": "C",
        "text": (
            "DISCHARGE SUMMARY - CARDIOLOGY\n"
            "Patient: 55M admitted for evaluation of cardiomyopathy.\n"
            "Cardiac workup: Echo showing reduced systolic function. BNP elevated at 450.\n"
            "General cardiac medications reviewed. Beta-blockers and ACE inhibitors discussed with patient.\n"
            "Referral to heart failure specialist placed. Outpatient cardiac MRI ordered.\n"
            "Lifestyle: Low-sodium diet, fluid restriction 2L/day, daily weights."
        ),
        "challenge_tags": ["SPECIFICITY-GAP"],
        "source": "CitiusTech Synthetic EHR v1"
    },
    # [TERMINOLOGY] eGFR vs CrCl vs GFR inconsistency
    {
        "id": "DS005",
        "type": "discharge_summary",
        "department": "Nephrology",
        "icd10": "N18.3",
        "condition": "CKD_stage3",
        "date": "2024-02-20",
        "evidence_level": "A",
        "text": (
            "DISCHARGE SUMMARY - NEPHROLOGY\n"
            "Patient: 72F with Type 2 Diabetes and CKD Stage 3b.\n"
            "Renal Function: eGFR 38 mL/min/1.73m2 on admission (CKD-EPI equation).\n"
            "Medication Adjustments: Metformin held (eGFR <45 per FDA label). "
            "SGLT2 inhibitor dapagliflozin continued as eGFR >25 per 2023 FDA expanded indication.\n"
            "Nephrology Note: Monitor GFR every 3 months. Avoid NSAIDs. Adjust drug doses per CrCl."
        ),
        "challenge_tags": ["TERMINOLOGY"],
        "source": "CitiusTech Synthetic EHR v1"
    },
    # [MULTI-HOP] Sepsis + AKI - answer requires combining two separate chunks
    {
        "id": "DS006",
        "type": "discharge_summary",
        "department": "ICU",
        "icd10": "A41.9",
        "condition": "Sepsis_AKI",
        "date": "2024-04-01",
        "evidence_level": "A",
        "text": (
            "DISCHARGE SUMMARY - MEDICAL ICU\n"
            "Patient: 58M admitted with septic shock secondary to gram-negative bacteremia.\n"
            "ICU Course: Vasopressors initiated (norepinephrine, vasopressin). Broad-spectrum antibiotics started.\n"
            "Complications: Acute kidney injury (AKI) developed on Day 2, peak creatinine 3.8 mg/dL (baseline 0.9).\n"
            "Renal Recovery: Creatinine trending down to 1.4 at discharge. "
            "Nephrology recommended holding ACE inhibitor until creatinine stabilizes for 4 weeks.\n"
            "Antimicrobials: De-escalated to ceftriaxone per sensitivities. 14-day course completed."
        ),
        "challenge_tags": ["MULTI-HOP"],
        "source": "CitiusTech Synthetic EHR v1"
    },
    # [RARE-DISEASE] Amyloidosis - low-frequency entity
    {
        "id": "DS007",
        "type": "discharge_summary",
        "department": "Cardiology",
        "icd10": "E85.4",
        "condition": "Cardiac_Amyloidosis",
        "date": "2024-05-10",
        "evidence_level": "B",
        "text": (
            "DISCHARGE SUMMARY - CARDIOLOGY\n"
            "Patient: 77M with newly diagnosed ATTR cardiac amyloidosis (wild-type).\n"
            "Diagnosis: Technetium pyrophosphate scan grade 3 uptake. Bone marrow biopsy negative for plasma cell dyscrasia.\n"
            "Treatment Initiated: Tafamidis 61mg daily (Vyndamax) per ATTR-ACT trial data.\n"
            "HF Management: Diuresis with furosemide. NOTE: Beta-blockers and ACE inhibitors may be poorly tolerated "
            "in ATTR amyloidosis - use with extreme caution. Digoxin CONTRAINDICATED.\n"
            "Anticoagulation: Apixaban started for atrial fibrillation (CHA2DS2-VASc 5)."
        ),
        "challenge_tags": ["RARE-DISEASE"],
        "source": "CitiusTech Synthetic EHR v1"
    },
    # Endocrinology - DM2 management
    {
        "id": "DS008",
        "type": "discharge_summary",
        "department": "Endocrinology",
        "icd10": "E11.65",
        "condition": "T2DM_hyperglycemia",
        "date": "2024-03-05",
        "evidence_level": "A",
        "text": (
            "DISCHARGE SUMMARY - ENDOCRINOLOGY\n"
            "Patient: 62F with Type 2 Diabetes, HbA1c 10.2% on admission.\n"
            "Inpatient Glycemic Control: Basal-bolus insulin regimen. Average glucose 145 mg/dL.\n"
            "Discharge Regimen: Metformin 1000mg BID (eGFR 72, safe to continue). "
            "Semaglutide 0.5mg weekly added for additional A1c lowering and cardiovascular benefit. "
            "Empagliflozin 10mg daily added (patient has established ASCVD per EMPA-REG OUTCOME).\n"
            "Targets: A1c <7.0% per ADA 2024 Standards of Care."
        ),
        "challenge_tags": [],
        "source": "CitiusTech Synthetic EHR v1"
    },
    # Pulmonology - COPD exacerbation
    {
        "id": "DS009",
        "type": "discharge_summary",
        "department": "Pulmonology",
        "icd10": "J44.1",
        "condition": "COPD_exacerbation",
        "date": "2024-02-14",
        "evidence_level": "A",
        "text": (
            "DISCHARGE SUMMARY - PULMONOLOGY\n"
            "Patient: 69M, COPD GOLD Stage III, admitted for moderate exacerbation.\n"
            "Treatment: Short-acting bronchodilators (albuterol + ipratropium), prednisolone 40mg x5 days, "
            "azithromycin 500mg x3 days (purulent sputum).\n"
            "Spirometry: FEV1 42% predicted, FEV1/FVC 0.58.\n"
            "Maintenance Therapy: LAMA/LABA (Umeclidinium/Vilanterol) resumed. "
            "ICS added (Fluticasone) given eosinophils >300.\n"
            "Pulmonary Rehab: Referral placed. Smoking cessation counseling provided."
        ),
        "challenge_tags": [],
        "source": "CitiusTech Synthetic EHR v1"
    },
    # Oncology - Lung cancer
    {
        "id": "DS010",
        "type": "discharge_summary",
        "department": "Oncology",
        "icd10": "C34.10",
        "condition": "NSCLC_EGFR",
        "date": "2024-01-25",
        "evidence_level": "A",
        "text": (
            "DISCHARGE SUMMARY - ONCOLOGY\n"
            "Patient: 61F, Non-Small Cell Lung Cancer, stage IIIB, EGFR exon 19 deletion.\n"
            "Molecular Testing: EGFR+, ALK-, ROS1-, PD-L1 45%.\n"
            "Treatment Plan: Osimertinib 80mg daily (FLAURA trial: OS benefit in EGFR-mutant NSCLC).\n"
            "Toxicity Counseling: Watch for rash, diarrhea, QT prolongation (obtain baseline ECG).\n"
            "Follow-up: CT chest in 8 weeks. Cardiac monitoring given QTc 440ms on baseline ECG."
        ),
        "challenge_tags": [],
        "source": "CitiusTech Synthetic EHR v1"
    },
]

# Generate additional discharge summaries programmatically
ADDITIONAL_TEMPLATES = [
    ("DS011", "ICU", "A41.51", "Sepsis_Pneumonia", "2024-03-18", [],
     "MICU DISCHARGE: 74M septic shock from CAP. Vasopressors x48h. ARDS protocol ventilation. "
     "Antibiotics: Piperacillin-tazobactam + azithromycin, de-escalated to amoxicillin-clavulanate. "
     "ICU-acquired weakness: Physical therapy initiated. Discharged to LTACH."),
    ("DS012", "Neurology", "G35", "Multiple_Sclerosis", "2024-04-12", [],
     "NEUROLOGY DISCHARGE: 38F relapsing-remitting MS. MRI: 3 new T2 lesions. "
     "Acute relapse treated: Methylprednisolone 1g IV x3 days. "
     "Disease-modifying therapy escalated to Ocrelizumab (anti-CD20) per OPERA trial. "
     "Ophthalmology referral for optic neuritis follow-up."),
    ("DS013", "Cardiology", "I21.09", "STEMI", "2024-05-02", [],
     "CARDIOLOGY DISCHARGE: 55M STEMI - LAD occlusion. Primary PCI with drug-eluting stent. "
     "DAPT: Aspirin 81mg + Ticagrelor 90mg BID x12 months. "
     "Statin: Atorvastatin 80mg. ACE inhibitor: Ramipril 5mg. Beta-blocker: Metoprolol 50mg BID. "
     "EF post-PCI: 45%. Cardiac rehab referral."),
    ("DS014", "Hematology", "D57.1", "Sickle_Cell", "2024-02-28", ["RARE-DISEASE"],
     "HEMATOLOGY DISCHARGE: 28F sickle cell disease (HbSS), vaso-occlusive crisis. "
     "Pain management: IV opioids, transitioned to oral. Hydroxyurea 1500mg daily (previous adherence issues). "
     "Trigger avoidance counseled. Pneumococcal vaccine updated. "
     "Crizanlizumab infusion scheduled (reduces VOC frequency per SUSTAIN trial)."),
    ("DS015", "Nephrology", "N17.9", "AKI_Contrast", "2024-03-29", ["MULTI-HOP"],
     "NEPHROLOGY DISCHARGE: 67M AKI secondary to contrast nephropathy post-cardiac catheterization. "
     "Creatinine peak: 2.9 mg/dL (baseline 1.0). IV hydration protocol used peri-procedure. "
     "Nephrotoxic medications held. Creatinine 1.3 at discharge. "
     "Follow-up creatinine in 1 week. Resume ACE inhibitor only when cr <1.5."),
    ("DS016", "Rheumatology", "M05.79", "RA_Biologics", "2024-01-14", [],
     "RHEUMATOLOGY DISCHARGE: 52F rheumatoid arthritis, inadequate response to MTX. "
     "New biologic: Adalimumab 40mg SC every 2 weeks added. "
     "TB screen negative, hepatitis B negative prior to initiation. "
     "Discontinue if no improvement by 12 weeks. Continue methotrexate 20mg weekly."),
    ("DS017", "Cardiology", "I50.33", "HFpEF", "2024-04-18", ["NEAR-DUPLICATE"],
     "CARDIOLOGY DISCHARGE: 76F HFpEF (EF 60%). Admitted for decompensation. "
     "Diuresis: IV furosemide, transitioned to oral torsemide 20mg. "
     "SGLT2 inhibitor: Empagliflozin 10mg added (EMPEROR-Preserved: reduced HHF). "
     "Blood pressure optimized: Amlodipine 5mg. No proven mortality benefit for HFpEF beta-blockers."),
    ("DS018", "Endocrinology", "E10.649", "T1DM_DKA", "2024-05-20", [],
     "ENDOCRINOLOGY DISCHARGE: 24M T1DM, DKA on presentation. pH 7.18, glucose 540, gap 28. "
     "DKA protocol: insulin drip, IV fluids, K+ repletion. Anion gap closed in 14h. "
     "Transitioned to basal-bolus: Glargine 24 units + Aspart sliding scale. "
     "CGM prescribed. Diabetes education completed."),
    ("DS019", "Gastroenterology", "K50.10", "Crohns_Severe", "2024-03-07", [],
     "GI DISCHARGE: 34F Crohn's disease, severe flare, CDAI 380. "
     "Induction: IV methylprednisolone 60mg x5d. Colonoscopy: deep ulcerations in terminal ileum. "
     "Biologic: Infliximab 5mg/kg induction (Wk 0, 2, 6). "
     "Nutritional support: Elemental formula supplementation. TPN not required."),
    ("DS020", "Cardiology", "I50.20", "HFrEF_advanced", "2024-06-01", ["NEAR-DUPLICATE"],
     "ADVANCED HEART FAILURE DISCHARGE: 63M, EF 20%, NYHA Class III. "
     "All GDMT maximized: Sacubitril-valsartan 97/103 BID, Carvedilol 25 BID, Spironolactone 50mg, "
     "Dapagliflozin 10mg. CRT-D implanted (QRS 155ms, LBBB). "
     "Palliative care consultation for goals-of-care discussion. LVAD evaluation pending."),
]

def build_discharge_summaries():
    summaries = list(DISCHARGE_TEMPLATES)
    for ds in ADDITIONAL_TEMPLATES:
        summaries.append({
            "id": ds[0],
            "type": "discharge_summary",
            "department": ds[1],
            "icd10": ds[2],
            "condition": ds[3],
            "date": ds[4],
            "evidence_level": random.choice(["A", "B", "C"]),
            "text": f"DISCHARGE SUMMARY - {ds[1].upper()}\n{ds[6]}",
            "challenge_tags": ds[5],
            "source": "CitiusTech Synthetic EHR v1"
        })
    # Add 40 more programmatic entries
    conditions = [
        ("Atrial Fibrillation", "I48.91", "Cardiology", "I48"),
        ("Stroke Ischemic", "I63.9", "Neurology", "I63"),
        ("Community Acquired Pneumonia", "J18.9", "Pulmonology", "J18"),
        ("GI Bleed Upper", "K92.1", "Gastroenterology", "K92"),
        ("DVT PE", "I26.09", "Hematology", "I26"),
        ("Liver Cirrhosis", "K74.60", "Hepatology", "K74"),
        ("Hypertensive Emergency", "I16.1", "Cardiology", "I16"),
        ("Thyroid Storm", "E05.51", "Endocrinology", "E05"),
    ]
    for i, (cond, icd, dept, icd_prefix) in enumerate(conditions * 5):
        idx = 21 + i
        year = random.choice([2022, 2023, 2024])
        month = random.randint(1, 12)
        day = random.randint(1, 28)
        tags = []
        if i % 7 == 0: tags.append("TEMPORAL")
        if i % 5 == 0: tags.append("NEAR-DUPLICATE")
        summaries.append({
            "id": f"DS{idx:03d}",
            "type": "discharge_summary",
            "department": dept,
            "icd10": icd,
            "condition": cond.replace(" ", "_"),
            "date": f"{year}-{month:02d}-{day:02d}",
            "evidence_level": random.choice(["A", "B", "B", "C"]),
            "text": (
                f"DISCHARGE SUMMARY - {dept.upper()}\n"
                f"Patient admitted for {cond}. Standard workup completed. "
                f"ICD-10: {icd}. Treatment per current guidelines initiated. "
                f"Patient educated on condition and follow-up plan. "
                f"Outpatient follow-up in 2 weeks scheduled."
            ),
            "challenge_tags": tags,
            "source": "CitiusTech Synthetic EHR v1"
        })
    return summaries[:60]

# ─────────────────────────────────────────────
# CLINICAL GUIDELINES (30 chunks)
# ─────────────────────────────────────────────

def build_guidelines():
    guidelines = [
        # [TEMPORAL] Two versions of the same AHA guideline
        {
            "id": "GL001",
            "type": "clinical_guideline",
            "source_org": "AHA/ACC",
            "guideline_name": "Heart Failure Management Guideline",
            "year": 2019,
            "version": "2019",
            "section": "Pharmacological Treatment HFrEF",
            "evidence_level": "I-A",
            "text": (
                "AHA/ACC HEART FAILURE GUIDELINE 2019 - HFrEF PHARMACOTHERAPY\n"
                "Class I Recommendation (Evidence A): ACE inhibitors or ARBs are recommended for all patients "
                "with HFrEF to reduce morbidity and mortality (SOLVD, CONSENSUS trials). "
                "Beta-blockers (carvedilol, metoprolol succinate, bisoprolol) are recommended. "
                "Mineralocorticoid antagonists (spironolactone, eplerenone) recommended in NYHA II-IV. "
                "NOTE: SGLT2 inhibitors not yet guideline-recommended for HF as of 2019."
            ),
            "challenge_tags": ["TEMPORAL"]
        },
        {
            "id": "GL002",
            "type": "clinical_guideline",
            "source_org": "AHA/ACC",
            "guideline_name": "Heart Failure Management Guideline",
            "year": 2022,
            "version": "2022",
            "section": "Pharmacological Treatment HFrEF",
            "evidence_level": "I-A",
            "text": (
                "AHA/ACC HEART FAILURE GUIDELINE 2022 - HFrEF PHARMACOTHERAPY (UPDATED)\n"
                "Class I Recommendation (Evidence A): The four pillars of GDMT for HFrEF:\n"
                "1. ACEi/ARB/ARNI (sacubitril-valsartan preferred if eligible)\n"
                "2. Beta-blocker (carvedilol, metoprolol succinate, bisoprolol)\n"
                "3. Mineralocorticoid receptor antagonist (spironolactone or eplerenone)\n"
                "4. SGLT2 inhibitor (dapagliflozin or empagliflozin) - NEW 2022 addition\n"
                "SGLT2i reduce HF hospitalization and CV death (DAPA-HF, EMPEROR-Reduced trials). "
                "Initiate all four classes simultaneously where tolerated."
            ),
            "challenge_tags": ["TEMPORAL", "NEAR-DUPLICATE"]
        },
        # [NEAR-DUPLICATE] ADA DM2 - two versions
        {
            "id": "GL003",
            "type": "clinical_guideline",
            "source_org": "ADA",
            "guideline_name": "Standards of Care in Diabetes",
            "year": 2023,
            "version": "2023",
            "section": "Pharmacotherapy T2DM",
            "evidence_level": "I-A",
            "text": (
                "ADA STANDARDS OF CARE 2023 - PHARMACOTHERAPY FOR T2DM\n"
                "For patients with T2DM and established ASCVD or high CV risk: "
                "GLP-1 RA with proven CV benefit (semaglutide, liraglutide) or SGLT2i (empagliflozin, canagliflozin) "
                "recommended regardless of baseline A1c. "
                "Metformin remains first-line if tolerated and eGFR ≥30. "
                "A1c target individualized: generally <7% for most adults, <8% for frail/elderly."
            ),
            "challenge_tags": []
        },
        {
            "id": "GL004",
            "type": "clinical_guideline",
            "source_org": "ADA",
            "guideline_name": "Standards of Care in Diabetes",
            "year": 2024,
            "version": "2024",
            "section": "Pharmacotherapy T2DM with CKD",
            "evidence_level": "I-A",
            "text": (
                "ADA STANDARDS OF CARE 2024 - T2DM WITH CHRONIC KIDNEY DISEASE\n"
                "Metformin: Use if eGFR ≥30; hold if eGFR <30 (FDA label). Safe to continue at eGFR 30-45 with monitoring.\n"
                "SGLT2 inhibitors: Dapagliflozin approved for CKD with eGFR ≥25 (DAPA-CKD trial). "
                "Renal protective effect independent of diabetes status.\n"
                "GLP-1 RA: Semaglutide dose reduction not required in CKD; monitor for GI tolerability.\n"
                "Finerenone (non-steroidal MRA): Recommended for T2DM + CKD + albuminuria (FIDELIO-DKD)."
            ),
            "challenge_tags": ["NEAR-DUPLICATE"]
        },
        {
            "id": "GL005",
            "type": "clinical_guideline",
            "source_org": "IDSA",
            "guideline_name": "Sepsis Management Guidelines",
            "year": 2021,
            "version": "Surviving Sepsis Campaign 2021",
            "section": "Initial Resuscitation",
            "evidence_level": "I-B",
            "text": (
                "SURVIVING SEPSIS CAMPAIGN 2021 - INITIAL RESUSCITATION\n"
                "Hour-1 Bundle: (1) Measure lactate. (2) Blood cultures x2 before antibiotics. "
                "(3) Broad-spectrum antibiotics within 1 hour of sepsis recognition. "
                "(4) 30mL/kg crystalloid for hypotension or lactate ≥4. "
                "(5) Vasopressors for MAP <65 despite fluid resuscitation - norepinephrine first-line.\n"
                "Steroid use: Hydrocortisone 200mg/day IV if vasopressor-refractory shock."
            ),
            "challenge_tags": []
        },
        {
            "id": "GL006",
            "type": "clinical_guideline",
            "source_org": "KDIGO",
            "guideline_name": "CKD Evaluation and Management",
            "year": 2022,
            "version": "KDIGO 2022",
            "section": "Medication Management in CKD",
            "evidence_level": "I-A",
            "text": (
                "KDIGO 2022 - MEDICATION DOSING IN CHRONIC KIDNEY DISEASE\n"
                "eGFR thresholds for medication adjustment:\n"
                "- Metformin: Reduce dose at eGFR 30-45; STOP at eGFR <30\n"
                "- Dapagliflozin: Approved down to eGFR 25 for CKD indication\n"
                "- Digoxin: Reduce dose; toxic at normal doses with eGFR <50\n"
                "- NSAIDs: AVOID in CKD; cause acute hemodynamic AKI and worsen GFR\n"
                "- Gadolinium contrast: Risk of NSF; avoid in eGFR <30 with older agents\n"
                "Calculate GFR using CKD-EPI 2021 equation (race-free formula)."
            ),
            "challenge_tags": ["TERMINOLOGY"]
        },
        {
            "id": "GL007",
            "type": "clinical_guideline",
            "source_org": "GOLD",
            "guideline_name": "COPD Global Initiative",
            "year": 2023,
            "version": "GOLD 2023",
            "section": "Stable COPD Pharmacotherapy",
            "evidence_level": "I-A",
            "text": (
                "GOLD 2023 - STABLE COPD PHARMACOLOGICAL TREATMENT\n"
                "Initial therapy based on ABCD classification:\n"
                "Group A: Short-acting bronchodilator PRN\n"
                "Group B: LAMA or LABA (preferred: LAMA)\n"
                "Group C: LAMA (reduces exacerbations)\n"
                "Group D: LAMA + LABA; add ICS if eosinophils ≥300 or frequent exacerbations\n"
                "ICS+LABA+LAMA triple therapy: Reduces moderate-severe exacerbations (IMPACT, ETHOS).\n"
                "Azithromycin prophylaxis: For ex-smokers with recurrent exacerbations."
            ),
            "challenge_tags": []
        },
        {
            "id": "GL008",
            "type": "clinical_guideline",
            "source_org": "AHA/ACC",
            "guideline_name": "Atrial Fibrillation Guideline",
            "year": 2023,
            "version": "2023",
            "section": "Anticoagulation in AF",
            "evidence_level": "I-A",
            "text": (
                "ACC/AHA AFIB GUIDELINE 2023 - ANTICOAGULATION\n"
                "CHA2DS2-VASc score guides anticoagulation:\n"
                "Score ≥2 (men) or ≥3 (women): OAC recommended (Class I).\n"
                "DOACs preferred over warfarin for non-valvular AF (lower ICH risk).\n"
                "Apixaban: 5mg BID (2.5mg BID if ≥2 of: age≥80, weight≤60kg, Cr≥1.5).\n"
                "Rivaroxaban: 20mg daily with evening meal.\n"
                "Dabigatran: Reduce to 75mg BID if CrCl 15-30 mL/min.\n"
                "Left atrial appendage closure (Watchman) for patients with contraindication to OAC."
            ),
            "challenge_tags": ["TERMINOLOGY"]
        },
        {
            "id": "GL009",
            "type": "clinical_guideline",
            "source_org": "ESC",
            "guideline_name": "Acute Coronary Syndromes",
            "year": 2023,
            "version": "ESC 2023",
            "section": "Antithrombotic Therapy Post-ACS",
            "evidence_level": "I-A",
            "text": (
                "ESC 2023 ACS GUIDELINE - ANTITHROMBOTIC THERAPY\n"
                "Dual Antiplatelet Therapy (DAPT): Aspirin + P2Y12 inhibitor for 12 months post-ACS.\n"
                "P2Y12 preference: Ticagrelor 90mg BID or Prasugrel 10mg daily (over clopidogrel).\n"
                "After 12 months: Consider P2Y12 monotherapy (drop aspirin) if high bleeding risk.\n"
                "Anticoagulation: Add DOAC only if concurrent AF (triple therapy → dual after 1 month).\n"
                "Statin: High-intensity mandatory. Target LDL <55 mg/dL (1.4 mmol/L)."
            ),
            "challenge_tags": []
        },
        {
            "id": "GL010",
            "type": "clinical_guideline",
            "source_org": "NCCN",
            "guideline_name": "NSCLC Treatment Guidelines",
            "year": 2024,
            "version": "NCCN v2.2024",
            "section": "EGFR-mutant NSCLC",
            "evidence_level": "I-A",
            "text": (
                "NCCN 2024 - EGFR-MUTANT NSCLC FIRST-LINE THERAPY\n"
                "EGFR exon 19 deletion or exon 21 L858R: Osimertinib 80mg daily preferred (Category 1).\n"
                "FLAURA2 trial: Osimertinib + chemotherapy improved PFS in selected patients.\n"
                "Cardiac monitoring: QTc prolongation reported; baseline ECG and monitoring recommended.\n"
                "CNS penetration: Osimertinib has excellent CNS penetration (AURA3).\n"
                "Resistance mechanisms: C797S mutation most common; liquid biopsy at progression.\n"
                "Exon 20 insertions: Amivantamab or mobocertinib (separate category)."
            ),
            "challenge_tags": []
        },
    ]
    # Add 20 more generic guidelines
    orgs = ["WHO", "NICE", "USPSTF", "ADA", "AHA", "IDSA", "GOLD", "KDIGO"]
    topics = [
        ("Hypertension Management", "BP targets: <130/80 in most adults per 2023 guidelines. First-line: RAAS blocker, CCB, or thiazide."),
        ("VTE Prophylaxis Hospitalized", "Hospitalized medical patients: LMWH or UFH prophylaxis unless contraindicated. Risk score (IMPROVE/Padua) guides decision."),
        ("Antimicrobial Stewardship", "Blood cultures before antibiotics. De-escalate at 48-72h based on culture data. Target narrow-spectrum when possible."),
        ("Lipid Management", "High-intensity statin for ASCVD. Add ezetimibe if LDL >70 on max statin. Add PCSK9i if still above target."),
        ("Thyroid Dysfunction", "TSH first-line screening. Levothyroxine for overt hypothyroidism. Target TSH 1-3 mU/L for most patients."),
        ("PE Management", "Anticoagulate immediately on clinical suspicion. DOAC preferred (rivaroxaban or apixaban). Systemic thrombolysis for massive PE only."),
        ("Obesity Pharmacotherapy", "GLP-1 agonists (semaglutide 2.4mg) for obesity management. BMI ≥30 or ≥27 with comorbidities."),
        ("GERD Management", "PPI for erosive esophagitis. Step-down approach after healing. Endoscopy for alarm symptoms."),
        ("Pain Management Opioid", "Opioids: lowest effective dose, short duration. PDMP check before prescribing. Naloxone co-prescription."),
        ("Colorectal Cancer Screening", "Colonoscopy every 10 years starting age 45. FIT annually as alternative. CRC risk stratification guides interval."),
    ]
    for i, (topic, text_snippet) in enumerate(topics * 2):
        yr = random.choice([2021, 2022, 2023, 2024])
        guidelines.append({
            "id": f"GL{11+i:03d}",
            "type": "clinical_guideline",
            "source_org": random.choice(orgs),
            "guideline_name": f"{topic} Guideline",
            "year": yr,
            "version": str(yr),
            "section": topic,
            "evidence_level": random.choice(["I-A", "I-B", "IIa-B", "IIb-C"]),
            "text": f"CLINICAL GUIDELINE {yr} - {topic.upper()}\n{text_snippet}",
            "challenge_tags": ["TEMPORAL"] if yr < 2022 else []
        })
    return guidelines[:30]

# ─────────────────────────────────────────────
# PUBMED ABSTRACTS (40 entries)
# ─────────────────────────────────────────────

PUBMED_ABSTRACTS = [
    {
        "id": "PM001",
        "type": "pubmed_abstract",
        "pmid": "31535100",
        "title": "DAPA-HF: Dapagliflozin in Patients with Heart Failure and Reduced Ejection Fraction",
        "journal": "NEJM",
        "year": 2019,
        "authors": "McMurray JJV et al.",
        "text": (
            "BACKGROUND: SGLT2 inhibitors reduce cardiovascular events in T2DM. Benefit in HFrEF without DM unclear.\n"
            "METHODS: 4744 patients, HFrEF (EF≤40%), NYHA II-IV randomized to dapagliflozin 10mg vs placebo.\n"
            "RESULTS: Primary endpoint (worsening HF or CV death) reduced by 26% (HR 0.74, 95% CI 0.65-0.85). "
            "Benefit consistent in patients with and without T2DM.\n"
            "CONCLUSION: Dapagliflozin significantly reduced worsening HF and CV death in HFrEF."
        ),
        "mesh_terms": ["Heart Failure", "SGLT2 Inhibitors", "Dapagliflozin", "Cardiovascular Death"],
        "challenge_tags": []
    },
    {
        "id": "PM002",
        "type": "pubmed_abstract",
        "pmid": "32865377",
        "title": "EMPEROR-Reduced: Empagliflozin in Heart Failure with Reduced Ejection Fraction",
        "journal": "NEJM",
        "year": 2020,
        "authors": "Packer M et al.",
        "text": (
            "BACKGROUND: Empagliflozin showed CV benefit in T2DM (EMPA-REG). HFrEF indication studied.\n"
            "METHODS: 3730 patients, EF≤40%, empagliflozin 10mg vs placebo. Primary: CV death + HHF.\n"
            "RESULTS: Primary outcome reduced 25% (HR 0.75, CI 0.65-0.86). eGFR decline significantly slowed.\n"
            "CONCLUSION: Empagliflozin reduced HF hospitalization and renal decline in HFrEF."
        ),
        "mesh_terms": ["Heart Failure", "Empagliflozin", "SGLT2 Inhibitors", "Renal Function"],
        "challenge_tags": ["NEAR-DUPLICATE"]
    },
    {
        "id": "PM003",
        "type": "pubmed_abstract",
        "pmid": "29386237",
        "title": "ATTR-ACT: Tafamidis in Patients with Transthyretin Amyloid Cardiomyopathy",
        "journal": "NEJM",
        "year": 2018,
        "authors": "Maurer MS et al.",
        "text": (
            "BACKGROUND: ATTR amyloid cardiomyopathy is underdiagnosed cause of HF. Tafamidis stabilizes TTR tetramer.\n"
            "METHODS: 441 patients with ATTR-CM randomized to tafamidis 80mg, 20mg, or placebo x30 months.\n"
            "RESULTS: Tafamidis reduced all-cause mortality (HR 0.70) and CV hospitalization. "
            "Walk test and quality of life improved vs placebo.\n"
            "CONCLUSION: Tafamidis reduced mortality and CV hospitalization in ATTR-CM."
        ),
        "mesh_terms": ["Amyloidosis", "ATTR", "Tafamidis", "Cardiomyopathy"],
        "challenge_tags": ["RARE-DISEASE"]
    },
    {
        "id": "PM004",
        "type": "pubmed_abstract",
        "pmid": "34437763",
        "title": "DAPA-CKD: Dapagliflozin in Patients with Chronic Kidney Disease",
        "journal": "NEJM",
        "year": 2020,
        "authors": "Heerspink HJL et al.",
        "text": (
            "BACKGROUND: CKD progression remains a major challenge. SGLT2i benefit in non-diabetic CKD studied.\n"
            "METHODS: 4304 patients (CKD eGFR 25-75, UACR ≥200) including T2DM and non-DM randomized to "
            "dapagliflozin 10mg vs placebo.\n"
            "RESULTS: Primary outcome (sustained eGFR decline ≥50%, ESKD, renal/CV death) reduced by 39% "
            "(HR 0.61, CI 0.51-0.72). Benefit in both DM and non-DM subgroups.\n"
            "CONCLUSION: Dapagliflozin slowed CKD progression regardless of diabetes status."
        ),
        "mesh_terms": ["CKD", "Dapagliflozin", "SGLT2", "Renal Protection"],
        "challenge_tags": ["MULTI-HOP"]
    },
    {
        "id": "PM005",
        "type": "pubmed_abstract",
        "pmid": "32678530",
        "title": "FLAURA: Osimertinib vs First-Generation EGFR-TKI in EGFR-mutant NSCLC",
        "journal": "NEJM",
        "year": 2018,
        "authors": "Ramalingam SS et al.",
        "text": (
            "BACKGROUND: Osimertinib is third-generation EGFR TKI with CNS penetration and activity vs T790M.\n"
            "METHODS: 556 EGFR-mutant NSCLC (exon 19 del or L858R) randomized to osimertinib vs gefitinib/erlotinib.\n"
            "RESULTS: OS significantly improved with osimertinib (38.6 vs 31.8 months, HR 0.80, p=0.046). "
            "CNS progression rate lower. Fewer grade ≥3 adverse events.\n"
            "CONCLUSION: Osimertinib is preferred first-line therapy for EGFR-mutant NSCLC."
        ),
        "mesh_terms": ["NSCLC", "EGFR", "Osimertinib", "Targeted Therapy"],
        "challenge_tags": []
    },
]

# Generate 35 additional abstracts
ADDITIONAL_ABSTRACTS = [
    ("PM006", "PARADIGM-HF: Sacubitril-Valsartan vs Enalapril in HFrEF", "NEJM", 2014,
     "Sacubitril-valsartan reduced CV death and HF hospitalization by 20% vs enalapril (HR 0.80). "
     "ARNI preferred over ACEi in HFrEF if tolerated. Monitor for angioedema.",
     ["HFrEF", "ARNI", "Sacubitril"], ["NEAR-DUPLICATE"]),
    ("PM007", "RALES: Spironolactone in Severe HF", "NEJM", 1999,
     "Spironolactone 25mg reduced mortality 30% in NYHA III-IV HFrEF. Monitor potassium - risk of hyperkalemia. "
     "Landmark trial establishing MRA in HF. Now superseded by 2022 guidelines adding SGLT2i.",
     ["Spironolactone", "HFrEF", "MRA"], ["TEMPORAL"]),
    ("PM008", "EMPEROR-Preserved: Empagliflozin in HFpEF", "NEJM", 2021,
     "Empagliflozin reduced HF hospitalization in HFpEF (EF>40%) by 29% vs placebo. "
     "First SGLT2i to show benefit in HFpEF. Renal protection also observed.",
     ["HFpEF", "Empagliflozin", "SGLT2"], []),
    ("PM009", "FIDELIO-DKD: Finerenone in Diabetic CKD", "NEJM", 2020,
     "Finerenone (non-steroidal MRA) reduced CKD progression and CV events in T2DM+CKD. "
     "Monitor potassium. Do not use with strong CYP3A4 inhibitors.",
     ["CKD", "Finerenone", "T2DM"], ["MULTI-HOP"]),
    ("PM010", "SUSTAIN-7: Semaglutide vs Dulaglutide in T2DM", "Lancet DM&E", 2018,
     "Semaglutide 1mg superior to dulaglutide 1.5mg for A1c reduction and weight loss. "
     "CV outcomes benefit demonstrated in SUSTAIN-6 trial for high-risk patients.",
     ["GLP-1", "Semaglutide", "T2DM"], []),
]

def build_pubmed_abstracts():
    abstracts = list(PUBMED_ABSTRACTS)
    for pm in ADDITIONAL_ABSTRACTS:
        abstracts.append({
            "id": pm[0],
            "type": "pubmed_abstract",
            "pmid": str(random.randint(30000000, 39999999)),
            "title": pm[1],
            "journal": pm[2],
            "year": pm[3],
            "authors": "Synthetic Author et al.",
            "text": f"ABSTRACT: {pm[1].upper()}\nBACKGROUND AND RESULTS: {pm[4]}",
            "mesh_terms": pm[5],
            "challenge_tags": pm[6]
        })
    # Fill to 40
    topics = [
        "GLP-1 Receptor Agonists Weight Loss", "CAR-T Cell Therapy B-cell Lymphoma",
        "Checkpoint Inhibitors Melanoma", "mRNA Vaccines Efficacy",
        "Microbiome Gut Dysbiosis IBD", "AI Diagnostic Radiology Chest X-ray",
        "Precision Medicine Pharmacogenomics", "Digital Biomarkers Wearables HF",
        "CRISPR Gene Editing Sickle Cell", "Telehealth Diabetes Remote Monitoring",
        "Social Determinants Health Outcomes", "Palliative Care ICU Mortality",
        "Delirium Prevention ICU ABCDEF Bundle", "Antimicrobial Resistance Carbapenem",
        "Long COVID Post-Acute Sequelae", "Sepsis Biomarkers Procalcitonin",
        "Perioperative Cardiac Risk Stratification", "ICU Nutrition Early Enteral",
        "Sleep Apnea CPAP Cardiovascular", "Mental Health Depression Antidepressants",
        "Alcohol Use Disorder Pharmacotherapy", "Pain Opioid Tapering Protocol",
        "TAVR vs Surgery Aortic Stenosis", "MitraClip Functional MR HFrEF",
        "Statin Intensity PCSK9 LDL", "Cognitive Decline Dementia Prevention",
        "Rheumatoid Arthritis JAK Inhibitors Safety", "Inflammatory Bowel Disease Biologics",
        "Liver Transplant Outcomes MELD Score", "Dialysis Hemodialysis vs Peritoneal"
    ]
    for i, t in enumerate(topics):
        yr = random.choice([2019, 2020, 2021, 2022, 2023, 2024])
        abstracts.append({
            "id": f"PM{15+i:03d}",
            "type": "pubmed_abstract",
            "pmid": str(random.randint(30000000, 39999999)),
            "title": f"Study on {t}",
            "journal": random.choice(["NEJM", "Lancet", "JAMA", "BMJ", "Circulation", "Diabetes Care"]),
            "year": yr,
            "authors": "Synthetic Research Group",
            "text": f"ABSTRACT: Randomized controlled trial evaluating {t.lower()} in a clinical population. "
                    f"Results showed significant improvement in primary outcomes. "
                    f"Year: {yr}. Clinical implications discussed.",
            "mesh_terms": t.split()[:3],
            "challenge_tags": ["TEMPORAL"] if yr < 2021 else []
        })
    return abstracts[:40]

# ─────────────────────────────────────────────
# DRUG REFERENCE (25 entries)
# ─────────────────────────────────────────────

def build_drug_reference():
    drugs = [
        {
            "id": "DR001", "drug_name": "Dapagliflozin", "brand": "Farxiga",
            "class": "SGLT2 Inhibitor", "type": "drug_reference",
            "indications": ["T2DM", "HFrEF", "HFpEF", "CKD"],
            "dosing": "10mg once daily oral. 5mg for T2DM glycemic control only.",
            "renal_dosing": "Safe down to eGFR 25 for HF/CKD indication. Not for glycemic control if eGFR <45.",
            "key_contraindications": ["eGFR <25", "Dialysis", "Type 1 DM"],
            "monitoring": ["eGFR", "Electrolytes", "BP", "Urogenital infections"],
            "challenge_tags": ["TERMINOLOGY"]
        },
        {
            "id": "DR002", "drug_name": "Sacubitril-Valsartan", "brand": "Entresto",
            "class": "ARNI", "type": "drug_reference",
            "indications": ["HFrEF"],
            "dosing": "Start 24/26 BID, target 97/103 BID. Washout 36h from ACEi (angioedema risk).",
            "renal_dosing": "Caution if eGFR <30. No dose adjustment mild-moderate CKD.",
            "key_contraindications": ["Concurrent ACEi use", "History of angioedema", "Pregnancy"],
            "monitoring": ["BP", "Potassium", "Creatinine/eGFR", "Angioedema symptoms"],
            "challenge_tags": []
        },
        {
            "id": "DR003", "drug_name": "Tafamidis", "brand": "Vyndamax/Vyndaqel",
            "class": "TTR Stabilizer", "type": "drug_reference",
            "indications": ["ATTR-CM (wild-type and hereditary)"],
            "dosing": "Vyndamax 61mg daily OR Vyndaqel 80mg (4x20mg) daily. Do NOT use interchangeably.",
            "renal_dosing": "No dose adjustment required.",
            "key_contraindications": ["None established"],
            "monitoring": ["Echo q12 months", "NT-proBNP", "6-minute walk test"],
            "challenge_tags": ["RARE-DISEASE"]
        },
        {
            "id": "DR004", "drug_name": "Osimertinib", "brand": "Tagrisso",
            "class": "3rd-gen EGFR TKI", "type": "drug_reference",
            "indications": ["EGFR-mutant NSCLC (1st line)", "EGFR T790M+ NSCLC (2nd line)"],
            "dosing": "80mg once daily. Reduce to 40mg if QTc >500ms or grade 3/4 toxicity.",
            "renal_dosing": "No adjustment for mild-moderate CKD.",
            "key_contraindications": ["Concurrent strong CYP3A4 inducers (reduce exposure)"],
            "monitoring": ["QTc at baseline and periodically", "LFTs", "Pulmonary toxicity", "Eye symptoms"],
            "challenge_tags": []
        },
        {
            "id": "DR005", "drug_name": "Metformin", "brand": "Glucophage",
            "class": "Biguanide", "type": "drug_reference",
            "indications": ["T2DM first-line"],
            "dosing": "500mg BID with meals, increase to max 2000-2550mg/day.",
            "renal_dosing": "Continue at eGFR 30-45 with monitoring. HOLD if eGFR <30. Hold before contrast.",
            "key_contraindications": ["eGFR <30", "Hepatic failure", "Excessive alcohol", "IV contrast (hold 48h)"],
            "monitoring": ["eGFR annually", "B12 levels", "A1c every 3 months"],
            "challenge_tags": ["TERMINOLOGY"]
        },
        {
            "id": "DR006", "drug_name": "Apixaban", "brand": "Eliquis",
            "class": "Direct Oral Anticoagulant (Factor Xa inhibitor)", "type": "drug_reference",
            "indications": ["AF", "DVT/PE treatment and prevention", "Post-orthopedic surgery"],
            "dosing": "AF: 5mg BID. Reduce to 2.5mg BID if ≥2 of: age≥80, weight≤60kg, Cr≥1.5. "
                      "DVT: 10mg BID x7d then 5mg BID.",
            "renal_dosing": "No adjustment for mild-moderate CKD. Use with caution CrCl 15-29. Avoid if ESKD.",
            "key_contraindications": ["Active pathological bleeding", "Mechanical heart valves"],
            "monitoring": ["Renal function annually", "Bleeding signs/symptoms", "Drug interactions (CYP3A4/P-gp)"],
            "challenge_tags": ["TERMINOLOGY"]
        },
    ]
    # Generate 19 more
    drug_data = [
        ("Carvedilol", "Coreg", "Beta-blocker (non-selective + alpha)", "HFrEF, Hypertension",
         "Start 3.125mg BID, target 25mg BID in HFrEF. Uptitrate every 2 weeks."),
        ("Spironolactone", "Aldactone", "Mineralocorticoid receptor antagonist",
         "HFrEF, HFpEF, Primary Hyperaldosteronism", "25-50mg daily. Monitor K+ and Cr."),
        ("Furosemide", "Lasix", "Loop diuretic", "HF fluid overload, Edema",
         "20-600mg IV or oral. Bioavailability oral 50%. IV:PO 1:2 ratio."),
        ("Atorvastatin", "Lipitor", "HMG-CoA Reductase Inhibitor (statin)",
         "Dyslipidemia, ASCVD prevention", "10-80mg daily. High-intensity: 40-80mg."),
        ("Empagliflozin", "Jardiance", "SGLT2 Inhibitor", "T2DM, HFrEF, HFpEF",
         "10mg daily. Increase to 25mg for glycemic control."),
        ("Semaglutide", "Ozempic/Wegovy", "GLP-1 Receptor Agonist",
         "T2DM, Obesity, CV risk reduction", "Start 0.25mg SC weekly x4wk, increase to 1mg or 2.4mg."),
        ("Adalimumab", "Humira", "TNF-alpha inhibitor", "RA, PsA, IBD, AS",
         "40mg SC every 2 weeks. Screen TB, Hep B before initiating."),
        ("Infliximab", "Remicade", "TNF-alpha inhibitor (IV)", "IBD, RA, AS",
         "5mg/kg IV at wk 0, 2, 6 then every 8 weeks. Premedicate with antihistamine."),
        ("Lisinopril", "Zestril", "ACE Inhibitor", "HFrEF, Hypertension, Post-MI, CKD proteinuria",
         "HFrEF: start 2.5-5mg, target 20-40mg. Monitor K+ and creatinine."),
        ("Warfarin", "Coumadin", "Vitamin K Antagonist", "AF, mechanical heart valves, DVT/PE",
         "Individualized dosing. Target INR 2-3 for AF; 2.5-3.5 for mechanical mitral valve."),
        ("Hydroxyurea", "Droxia", "Cytoreductive agent", "Sickle cell disease, Polycythemia vera",
         "Sickle cell: 15mg/kg/day, increase by 5mg/kg every 12 weeks. Target HbF >20%."),
        ("Crizanlizumab", "Adakveo", "P-selectin inhibitor", "Sickle cell VOC prevention",
         "5mg/kg IV at wk 0, 2 then every 4 weeks. Reduces VOC frequency."),
        ("Ocrelizumab", "Ocrevus", "Anti-CD20 monoclonal", "MS (RRMS, PPMS)",
         "300mg IV x2 (2 wk apart) then 600mg every 6 months. Infusion reactions common."),
        ("Piperacillin-Tazobactam", "Zosyn", "Beta-lactam/Beta-lactamase inhibitor",
         "Sepsis, Pneumonia, IAI, UTI", "3.375g q6h or 4.5g q8h IV. Extend infusion 4h for PK optimization."),
        ("Norepinephrine", "Levophed", "Vasopressor (alpha-1 agonist)",
         "Septic shock, distributive shock first-line", "0.01-3 mcg/kg/min IV. Central line preferred."),
        ("Methylprednisolone", "Solu-Medrol", "Corticosteroid (IV)",
         "MS relapse, ARDS, Severe asthma, Anaphylaxis", "MS: 1g IV daily x3-5 days."),
        ("Ticagrelor", "Brilinta", "P2Y12 inhibitor (reversible)", "ACS, Post-PCI DAPT",
         "180mg load, 90mg BID maintenance x12 months. Avoid in stroke history."),
        ("Nivolumab", "Opdivo", "PD-1 checkpoint inhibitor",
         "NSCLC, Melanoma, RCC, DLBCL", "240mg IV q2wk or 480mg q4wk. Monitor for irAEs."),
        ("Finerenone", "Kerendia", "Non-steroidal MRA", "CKD with T2DM",
         "10mg or 20mg daily based on eGFR. Check K+ before initiation. Avoid with strong CYP3A4 inhibitors."),
    ]
    for i, (name, brand, cls, indications, dosing) in enumerate(drug_data):
        drugs.append({
            "id": f"DR{7+i:03d}",
            "type": "drug_reference",
            "drug_name": name, "brand": brand, "class": cls,
            "indications": [x.strip() for x in indications.split(",")],
            "dosing": dosing,
            "renal_dosing": "Refer to product label for renal dosing.",
            "key_contraindications": ["See full prescribing information"],
            "monitoring": ["Per clinical judgment"],
            "challenge_tags": []
        })
    return drugs[:25]

# ─────────────────────────────────────────────
# EVALUATION QA PAIRS (50 pairs)
# ─────────────────────────────────────────────

def build_eval_qa():
    return [
        # --- Questions exposing NEAR-DUPLICATE problem ---
        {
            "id": "QA001",
            "question": "What are the four pillars of guideline-directed medical therapy for HFrEF according to 2022 guidelines?",
            "ground_truth_answer": "The four pillars per 2022 AHA/ACC are: (1) ACEi/ARB/ARNI, (2) Beta-blocker, (3) Mineralocorticoid receptor antagonist, (4) SGLT2 inhibitor (dapagliflozin or empagliflozin).",
            "ground_truth_chunk_ids": ["GL002", "DS001"],
            "challenge_type": "NEAR-DUPLICATE",
            "difficulty": "medium",
            "why_hard": "Near-duplicate chunks DS001/DS002 and GL001/GL002 will all score high. Naive RAG returns a mix of old and new guidelines. Metadata filtering on year=2022 and re-ranking on specificity are needed.",
            "expected_failure_naive_rag": "Returns 2019 guideline (GL001) which omits SGLT2i - clinically wrong answer."
        },
        {
            "id": "QA002",
            "question": "Is Dapagliflozin safe to use in a patient with eGFR of 30 for their heart failure?",
            "ground_truth_answer": "Yes. For heart failure indication, dapagliflozin is approved down to eGFR 25 per 2023 FDA expanded indication and DAPA-HF trial.",
            "ground_truth_chunk_ids": ["DR001", "GL004", "PM004"],
            "challenge_type": "TERMINOLOGY",
            "difficulty": "hard",
            "why_hard": "Query uses 'eGFR' but some chunks use 'GFR' or 'CrCl'. Threshold differs by indication (eGFR <30 for glycemic, eGFR <25 for HF). Multi-chunk reasoning required.",
            "expected_failure_naive_rag": "Returns Metformin eGFR threshold chunk (GL006) which is for a different drug."
        },
        {
            "id": "QA003",
            "question": "What is the current recommended SGLT2 inhibitor dose for a patient with HFrEF?",
            "ground_truth_answer": "Dapagliflozin 10mg daily or Empagliflozin 10mg daily per 2022 AHA/ACC HFrEF guidelines (Class I recommendation).",
            "ground_truth_chunk_ids": ["GL002", "DR001", "PM001"],
            "challenge_type": "NEAR-DUPLICATE",
            "difficulty": "medium",
            "why_hard": "PM001 (DAPA-HF) and PM002 (EMPEROR-Reduced) are near-duplicates. MMR needed to ensure both drugs are represented rather than returning 3 similar DAPA-HF chunks.",
            "expected_failure_naive_rag": "Returns three chunks about dapagliflozin only, misses empagliflozin option."
        },
        {
            "id": "QA004",
            "question": "In a patient with septic shock and new AKI, when should ACE inhibitor be restarted after discharge?",
            "ground_truth_answer": "Hold ACE inhibitor until creatinine stabilizes for at least 4 weeks post-discharge per nephrology recommendation.",
            "ground_truth_chunk_ids": ["DS006", "DS015"],
            "challenge_type": "MULTI-HOP",
            "difficulty": "hard",
            "why_hard": "Answer is only in DS006 and requires understanding that AKI from sepsis + contrast are different scenarios. Dense retrieval alone may miss the specific 4-week timeframe.",
            "expected_failure_naive_rag": "Returns generic sepsis guidelines (GL005) that don't address ACEi restart timing."
        },
        {
            "id": "QA005",
            "question": "What cardiac medications should be avoided in ATTR cardiac amyloidosis?",
            "ground_truth_answer": "Digoxin is contraindicated. Beta-blockers and ACE inhibitors should be used with extreme caution as they may be poorly tolerated in ATTR amyloidosis.",
            "ground_truth_chunk_ids": ["DS007", "DR003"],
            "challenge_type": "RARE-DISEASE",
            "difficulty": "hard",
            "why_hard": "Low embedding similarity to common HF queries. HyDE or query expansion needed. Naive dense retrieval returns standard HF drug chunks.",
            "expected_failure_naive_rag": "Returns standard HF medication recommendations (GL001/GL002), completely wrong context."
        },
        {
            "id": "QA006",
            "question": "What is the recommended first-line anticoagulant for a patient with non-valvular atrial fibrillation and CHA2DS2-VASc of 4?",
            "ground_truth_answer": "A DOAC is preferred (Class I). Apixaban 5mg BID or rivaroxaban 20mg daily are first-line options for non-valvular AF with CHA2DS2-VASc ≥2 in men.",
            "ground_truth_chunk_ids": ["GL008", "DR006"],
            "challenge_type": "TERMINOLOGY",
            "difficulty": "medium",
            "why_hard": "Mix of anticoagulation terminology (OAC, DOAC, NOAC). Chunks use different abbreviations for same drug class.",
            "expected_failure_naive_rag": "Returns warfarin chunk (DR010) which is now second-line for non-valvular AF."
        },
        {
            "id": "QA007",
            "question": "What SGLT2 inhibitor dose is recommended for CKD with eGFR of 38 in a diabetic patient?",
            "ground_truth_answer": "Dapagliflozin 10mg daily is approved for CKD with eGFR ≥25 (DAPA-CKD). The renal protective effect is independent of diabetes status.",
            "ground_truth_chunk_ids": ["GL004", "GL006", "DR001", "PM004"],
            "challenge_type": "MULTI-HOP",
            "difficulty": "hard",
            "why_hard": "Multi-document reasoning: need DAPA-CKD evidence + current ADA guideline + drug reference. Also terminology gap: eGFR in query, CrCl in some drug references.",
            "expected_failure_naive_rag": "Conflates glycemic control indication (eGFR threshold different) with CKD indication."
        },
        {
            "id": "QA008",
            "question": "What is the survival benefit of tafamidis in wild-type ATTR cardiomyopathy?",
            "ground_truth_answer": "Tafamidis reduced all-cause mortality (HR 0.70) and CV hospitalization vs placebo over 30 months in the ATTR-ACT trial.",
            "ground_truth_chunk_ids": ["PM003", "DR003", "DS007"],
            "challenge_type": "RARE-DISEASE",
            "difficulty": "hard",
            "why_hard": "ATTR is a low-frequency entity. Sparse embedding representation. HyDE query: 'clinical trial results of TTR stabilizer in transthyretin amyloid heart disease' needed.",
            "expected_failure_naive_rag": "Returns general HF prognosis chunks unrelated to ATTR amyloidosis."
        },
        {
            "id": "QA009",
            "question": "What monitoring is required before starting osimertinib for EGFR-mutant lung cancer?",
            "ground_truth_answer": "Baseline ECG is required to assess QTc interval. QTc >500ms or symptomatic QT prolongation warrants dose reduction to 40mg. Liver function tests and assessment for pulmonary symptoms also needed.",
            "ground_truth_chunk_ids": ["DR004", "DS010", "GL010"],
            "challenge_type": "SPECIFICITY-GAP",
            "difficulty": "medium",
            "why_hard": "General oncology monitoring chunks score high but miss the osimertinib-specific QTc requirement.",
            "expected_failure_naive_rag": "Returns general chemotherapy monitoring, misses QTc-specific guidance."
        },
        {
            "id": "QA010",
            "question": "Should spironolactone be started in a patient with HFrEF and eGFR of 28?",
            "ground_truth_answer": "Use with extreme caution or avoid - hyperkalemia and worsening renal function risk is high at eGFR <30. If used, start lowest dose with very close potassium monitoring (within 48-72h).",
            "ground_truth_chunk_ids": ["DR006", "GL002", "GL006"],
            "challenge_type": "MULTI-HOP",
            "difficulty": "hard",
            "why_hard": "Requires combining: GDMT recommendation (GL002) + renal contraindication threshold (GL006) + drug monitoring requirements. No single chunk has the complete answer.",
            "expected_failure_naive_rag": "Returns GL002 recommending spironolactone without the renal caveat."
        },
        # Additional 40 QA pairs
        *[{
            "id": f"QA{11+i:03d}",
            "question": q,
            "ground_truth_answer": a,
            "ground_truth_chunk_ids": cids,
            "challenge_type": ct,
            "difficulty": diff,
            "why_hard": wh,
            "expected_failure_naive_rag": ef
        } for i, (q, a, cids, ct, diff, wh, ef) in enumerate([
            ("What beta-blocker is preferred in HFrEF per AHA guidelines?",
             "Carvedilol, metoprolol succinate, or bisoprolol (all three have mortality evidence).",
             ["GL002", "DS001"], "NEAR-DUPLICATE", "easy",
             "Multiple chunks contain similar info.", "Returns 2019 guideline."),
            ("What is the eGFR threshold below which metformin should be stopped?",
             "eGFR <30 mL/min/1.73m2 per FDA label. Dose reduce at 30-45.",
             ["DR005", "GL004", "GL006"], "TERMINOLOGY", "medium",
             "Multiple renal thresholds in corpus for different drugs.", "Returns dapagliflozin threshold instead."),
            ("What is the Hour-1 Bundle for sepsis?",
             "Measure lactate, blood cultures x2, broad-spectrum antibiotics, 30mL/kg crystalloid, vasopressors for MAP <65.",
             ["GL005"], "SPECIFICITY-GAP", "easy", "Generic sepsis chunks may dilute.", "Returns general ICU guidance."),
            ("What is the A1c target for most adults with T2DM per ADA 2024?",
             "Generally <7.0% for most adults; <8% for frail or elderly.",
             ["GL003", "DS008"], "TEMPORAL", "easy", "2023 vs 2024 ADA standards differ slightly.", "Returns 2023 ADA standard."),
            ("What antiplatelet regimen is recommended after STEMI with PCI?",
             "Aspirin 81mg + Ticagrelor 90mg BID for 12 months (DAPT). Ticagrelor preferred over clopidogrel.",
             ["GL009", "DS013", "DR016"], "SPECIFICITY-GAP", "medium", "General antithrombotic chunks score high.", "Returns warfarin or generic anticoagulation chunk."),
            ("What is the maintenance dose of carvedilol in HFrEF?",
             "Target dose 25mg BID per AHA guideline. Start 3.125mg BID and uptitrate every 2 weeks.",
             ["DR007", "DS001", "GL002"], "NEAR-DUPLICATE", "easy", "Multiple chunks mention carvedilol dosing.", "Returns DS003 (2019) with lower target dose mentioned."),
            ("Which patients with HFpEF benefit from SGLT2 inhibitors?",
             "Empagliflozin reduced HF hospitalization in HFpEF (EMPEROR-Preserved, EF>40%). Dapagliflozin also has evidence.",
             ["PM008", "DS017", "GL002"], "NEAR-DUPLICATE", "medium", "HFrEF and HFpEF SGLT2 chunks look similar.", "Returns HFrEF chunks instead."),
            ("What is first-line vasopressor in septic shock?",
             "Norepinephrine is first-line per Surviving Sepsis Campaign 2021.",
             ["GL005", "DR014"], "SPECIFICITY-GAP", "easy", "General ICU chunks may rank higher.", "Returns vasopressin or dopamine as alternatives."),
            ("What is the EGFR mutation status that predicts response to osimertinib?",
             "EGFR exon 19 deletion or exon 21 L858R mutation (classic sensitizing mutations).",
             ["GL010", "DS010", "PM005"], "SPECIFICITY-GAP", "medium", "Generic NSCLC chunks rank high.", "Returns general checkpoint inhibitor data."),
            ("Should ICS be added to LAMA/LABA in COPD with eosinophils >300?",
             "Yes. GOLD 2023 recommends adding ICS to LAMA/LABA combination in GOLD Group D with eosinophils ≥300.",
             ["GL007", "DS009"], "TEMPORAL", "medium", "Earlier GOLD versions had different thresholds.", "Returns older GOLD guideline without eosinophil threshold."),
            ("What is the P2Y12 inhibitor of choice post-ACS per ESC 2023?",
             "Ticagrelor 90mg BID or Prasugrel 10mg daily preferred over clopidogrel.",
             ["GL009", "DS013"], "TEMPORAL", "easy", "Older ACS guidelines preferred clopidogrel.", "Returns clopidogrel recommendation from older guideline."),
            ("What is the LDL target in a patient with established ASCVD on high-intensity statin?",
             "LDL <55 mg/dL (1.4 mmol/L). Add ezetimibe, then PCSK9 inhibitor if not at target.",
             ["GL009"], "SPECIFICITY-GAP", "medium", "General statin chunks mention <70 mg/dL target (older threshold).", "Returns LDL <70 target from older chunk."),
            ("What triple therapy is recommended for COPD GOLD Group D?",
             "LAMA + LABA + ICS triple therapy reduces moderate-severe exacerbations (IMPACT, ETHOS trials).",
             ["GL007", "DS009"], "SPECIFICITY-GAP", "medium", "Generic COPD chunks rank high.", "Returns only dual bronchodilator recommendation."),
            ("What is the first-line biologic for severe RRMS?",
             "Ocrelizumab (anti-CD20) is a high-efficacy disease-modifying therapy for RRMS and PPMS (OPERA trials).",
             ["DR013", "DS012"], "RARE-DISEASE", "hard", "MS-specific chunks underrepresented.", "Returns general immunosuppression data."),
            ("What monitoring is required for crizanlizumab in sickle cell disease?",
             "Monitor for infusion reactions. Assess VOC frequency reduction. Platelet monitoring per label.",
             ["DR012", "DS014"], "RARE-DISEASE", "hard", "Sickle cell disease chunks sparse in corpus.", "Returns general biologic monitoring chunk."),
            ("What is the maximum dose of furosemide in decompensated HF?",
             "Up to 600mg/day; typical decompensation doses 40-160mg IV. IV bioavailability better than oral in congested gut.",
             ["DR008"], "SPECIFICITY-GAP", "easy", "Multiple diuretic chunks in corpus.", "Returns general diuretic guidance without IV/oral distinction."),
            ("What is the risk of digoxin in ATTR amyloidosis?",
             "Digoxin is CONTRAINDICATED in ATTR cardiac amyloidosis - high risk of toxicity due to amyloid fibrils binding digoxin.",
             ["DS007", "DR003"], "RARE-DISEASE", "hard", "Digoxin contraindication specific to ATTR - rare fact.", "Returns general digoxin dosing guidance."),
            ("What is the sacubitril-valsartan washout requirement when switching from ACE inhibitor?",
             "36-hour washout from ACE inhibitor before starting sacubitril-valsartan to avoid angioedema.",
             ["DR002"], "SPECIFICITY-GAP", "medium", "Generic ARB switching chunks rank high.", "Returns general ACEi-to-ARB switch guidance without washout period."),
            ("Is finerenone safe to use with strong CYP3A4 inhibitors?",
             "No. Finerenone must not be used with strong CYP3A4 inhibitors (e.g., ketoconazole, itraconazole) - significantly increases plasma levels.",
             ["DR019", "GL004"], "MULTI-HOP", "hard", "Drug interaction not in single chunk.", "Returns only renal dosing without drug interaction."),
            ("What is the INR target for a patient with a mechanical mitral valve on warfarin?",
             "Target INR 2.5-3.5 for mechanical mitral valve. Higher than standard AF target of 2-3.",
             ["DR010"], "SPECIFICITY-GAP", "hard", "AF INR target chunks rank higher than mechanical valve.", "Returns INR 2-3 target (AF indication, not mechanical valve)."),
            ("What are the four main criteria to reduce apixaban dose in AF?",
             "Reduce to 2.5mg BID if ≥2 of: age ≥80, weight ≤60kg, serum creatinine ≥1.5 mg/dL.",
             ["DR006", "GL008"], "MULTI-HOP", "hard", "Criteria split across drug reference and guideline.", "Returns only standard 5mg dose without dose-reduction criteria."),
            ("What induction regimen is recommended for severe Crohn's disease?",
             "IV methylprednisolone for acute induction, followed by Infliximab 5mg/kg at weeks 0, 2, 6 for biologic maintenance.",
             ["DS019", "DR018"], "SPECIFICITY-GAP", "medium", "IBD chunks mix Crohn's and UC.", "Returns general IBD steroid guidance."),
            ("What EGFR mutation predicts poor response to first-generation EGFR TKIs?",
             "T790M resistance mutation is the most common mechanism of acquired resistance to first-generation EGFR TKIs. Osimertinib retains activity against T790M.",
             ["GL010", "PM005"], "SPECIFICITY-GAP", "hard", "Resistance biology sparsely covered.", "Returns FLAURA efficacy data without T790M context."),
            ("In a patient with EGFR-mutant NSCLC and a QTc of 460ms, what osimertinib monitoring is needed?",
             "Baseline QTc 460ms requires monitoring - if QTc exceeds 500ms or increases >60ms from baseline, interrupt and consider dose reduction to 40mg.",
             ["DR004", "DS010"], "MULTI-HOP", "hard", "Specific threshold requires combining drug reference + discharge note.", "Returns general osimertinib efficacy data."),
            ("What is hydroxyurea mechanism in sickle cell disease?",
             "Hydroxyurea increases fetal hemoglobin (HbF) production, reducing polymerization of HbSS and vaso-occlusive crises. Target HbF >20%.",
             ["DR011", "DS014"], "RARE-DISEASE", "hard", "Sickle cell mechanism chunks rare in corpus.", "Returns general cytoreductive mechanism."),
            ("What is the recommended apixaban dose for DVT treatment?",
             "Apixaban 10mg BID for 7 days (treatment dose), then 5mg BID for continued treatment.",
             ["DR006"], "SPECIFICITY-GAP", "medium", "AF dosing (5mg BID) chunks rank higher than DVT dosing.", "Returns AF dose 5mg BID instead of DVT 10mg BID induction."),
            ("What is the preferred vasopressor for cardiogenic shock?",
             "Norepinephrine is preferred over dopamine (lower arrhythmia risk). Vasopressin can be added. Dobutamine for inotropy if reduced CO.",
             ["DR014", "GL005"], "MULTI-HOP", "hard", "Cardiogenic vs septic shock vasopressor distinction needed.", "Returns septic shock norepinephrine recommendation directly."),
            ("What is the role of semaglutide in obesity management?",
             "Semaglutide 2.4mg SC weekly (Wegovy) approved for obesity (BMI ≥30, or ≥27 with comorbidities). Average 15% body weight reduction in STEP trials.",
             ["DR006"], "SPECIFICITY-GAP", "medium", "Glycemic control semaglutide chunk (1mg) ranks higher.", "Returns diabetes dose instead of obesity dose."),
            ("Should beta-blockers be initiated during acute decompensated HF?",
             "Beta-blockers should NOT be initiated during acute decompensated HF; they can worsen hemodynamics. Resume or start only after clinical euvolemia is achieved.",
             ["GL002", "DS001"], "MULTI-HOP", "hard", "Guideline recommends beta-blockers for HFrEF but with timing caveat.", "Returns BB recommendation without the 'wait for euvolemia' caveat."),
            ("What is the evidence basis for sacubitril-valsartan in HFrEF?",
             "PARADIGM-HF trial: sacubitril-valsartan reduced CV death and HF hospitalization by 20% vs enalapril (HR 0.80).",
             ["PM006", "DR002"], "NEAR-DUPLICATE", "easy", "Multiple PARADIGM-HF summary chunks differ slightly.", "Returns enalapril comparison data from 2019 guideline."),
            ("What is the recommended statin for a post-STEMI patient?",
             "High-intensity statin: Atorvastatin 80mg or Rosuvastatin 40mg daily. Target LDL <55 mg/dL.",
             ["GL009", "DS013"], "SPECIFICITY-GAP", "medium", "Low-intensity statin chunks rank comparably.", "Returns general statin recommendation without high-intensity specification."),
            ("What is the role of finerenone in diabetic CKD?",
             "Finerenone (non-steroidal MRA) reduces CKD progression and CV events in T2DM+CKD+albuminuria (FIDELIO-DKD). Use with eGFR ≥25 and normokalemia.",
             ["PM009", "DR019", "GL004"], "MULTI-HOP", "hard", "Multiple kidney-protection agents now available - differentiation needed.", "Returns spironolactone recommendation instead of finerenone."),
            ("What is the antibiotic choice for COPD exacerbation with purulent sputum?",
             "Azithromycin 500mg x3 days or amoxicillin-clavulanate for outpatient COPD exacerbation with purulent sputum.",
             ["DS009", "GL007"], "SPECIFICITY-GAP", "medium", "Broad antimicrobial stewardship chunks rank high.", "Returns broad-spectrum IV antibiotics recommendation."),
            ("What TB screening is required before initiating adalimumab?",
             "Tuberculin skin test (TST) or IGRA prior to adalimumab initiation. Treat latent TB before starting biologic if positive.",
             ["DR007", "DS016"], "SPECIFICITY-GAP", "medium", "General infection screening chunks rank high.", "Returns general infection monitoring without TB-specific pre-screening requirement."),
            ("What is the recommended GLP-1 agonist starting dose to minimize GI side effects?",
             "Semaglutide: start 0.25mg SC weekly for 4 weeks before increasing. Slow titration reduces nausea and GI side effects.",
             ["DR006"], "SPECIFICITY-GAP", "medium", "Efficacy-focused chunks rank higher than dosing/tolerability chunks.", "Returns therapeutic dose without titration schedule."),
            ("What is the creatinine threshold to withhold metformin before IV contrast administration?",
             "Hold metformin before IV contrast regardless of creatinine; restart 48 hours after procedure if renal function stable.",
             ["DR005", "GL006"], "MULTI-HOP", "hard", "Contrast-specific hold requirement separate from CKD threshold.", "Returns CKD eGFR threshold instead of contrast-specific rule."),
            ("What anticoagulation is used for sickle cell patients with stroke?",
             "Antithrombotic therapy varies; ischemic stroke in SCD typically managed with aspirin. Anticoagulation for specific indications (e.g., CVT). Consult hematology.",
             ["DS014"], "RARE-DISEASE", "hard", "Sickle cell stroke management poorly represented.", "Returns standard stroke anticoagulation guideline."),
            ("What is norepinephrine's mechanism as a vasopressor?",
             "Norepinephrine is primarily an alpha-1 agonist causing vasoconstriction with some beta-1 inotropy, increasing MAP without significant tachycardia.",
             ["DR014"], "SPECIFICITY-GAP", "easy", "Generic vasopressor mechanism chunks rank equally.", "Returns epinephrine mechanism instead."),
            ("What is the oral bioavailability issue with furosemide in decompensated HF?",
             "Oral furosemide has only ~50% bioavailability normally, further reduced in congested gut. IV furosemide achieves faster and more reliable diuresis in decompensated HF.",
             ["DR008"], "SPECIFICITY-GAP", "hard", "Pharmacokinetics-specific fact requires exact chunk.", "Returns general loop diuretic mechanism."),
            ("What is the recommended DAPT duration after STEMI with drug-eluting stent?",
             "12 months of DAPT (aspirin + ticagrelor or prasugrel) after ACS with PCI. May shorten to 6 months if high bleeding risk with physician judgment.",
             ["GL009", "DS013"], "TEMPORAL", "medium", "Earlier guidelines recommended clopidogrel and different durations.", "Returns older DAPT duration recommendations with clopidogrel."),
        ])]
    ]

if __name__ == "__main__":
    import os
    os.makedirs(".", exist_ok=True)

    print("Generating synthetic clinical dataset...")

    discharge_summaries = build_discharge_summaries()
    guidelines = build_guidelines()
    pubmed = build_pubmed_abstracts()
    drugs = build_drug_reference()
    qa_pairs = build_eval_qa()

    datasets = {
        "discharge_summaries": discharge_summaries,
        "clinical_guidelines": guidelines,
        "pubmed_abstracts": pubmed,
        "drug_reference": drugs,
        "eval_qa_pairs": qa_pairs
    }

    for name, data in datasets.items():
        with open(f"{name}.json", "w") as f:
            json.dump(data, f, indent=2)
        print(f"  ✓ {name}.json — {len(data)} records")

    # Summary stats
    total_chunks = len(discharge_summaries) + len(guidelines) + len(pubmed) + len(drugs)
    challenge_dist = {}
    for ds in [discharge_summaries, guidelines, pubmed, drugs]:
        for item in ds:
            for tag in item.get("challenge_tags", []):
                challenge_dist[tag] = challenge_dist.get(tag, 0) + 1

    print(f"\n{'='*50}")
    print(f"DATASET SUMMARY")
    print(f"{'='*50}")
    print(f"Total knowledge base chunks : {total_chunks}")
    print(f"Evaluation QA pairs        : {len(qa_pairs)}")
    print(f"\nInjected challenge patterns:")
    for tag, count in sorted(challenge_dist.items()):
        print(f"  [{tag}]: {count} chunks")
    print(f"\nChallenge type in QA pairs:")
    ct_dist = {}
    for qa in qa_pairs:
        ct = qa["challenge_type"]
        ct_dist[ct] = ct_dist.get(ct, 0) + 1
    for ct, cnt in sorted(ct_dist.items()):
        print(f"  {ct}: {cnt} questions")
    print(f"\nDataset files written to current directory.")
