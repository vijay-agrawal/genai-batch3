# ClinicalRAG Pro
### Advanced RAG for Clinical Decision Support
**CitiusTech Gen AI & Agentic AI Training — Project 1**

---

## Overview

ClinicalRAG Pro - Architect a production grade RAG system for clinical decision support

Participants see naive RAG produce a clinically dangerous answer (citing a 2019 guideline that omits SGLT2 inhibitors for HFrEF), then fix it with metadata filtering and verify the improvement with hard numbers.

```
Naive RAG  →  Metadata Filter  →  MMR  →  Re-ranking  →  Hybrid  →  HyDE  →  Agentic RAG
  0.33 MRR        0.57 MRR         0.58     0.77          0.88      0.92        Adaptive
```

---

## Learning Objectives

By completing this project, participants will be able to:

1. **Diagnose** retrieval failures by category: temporal contamination, near-duplicate flooding, specificity gaps, terminology mismatches, rare entity cold-start, and multi-hop reasoning gaps
2. **Implement** all six retrieval strategies from scratch: naive dense, metadata-filtered, MMR, cross-encoder re-ranking, hybrid BM25+dense with RRF, and HyDE
3. **Measure** retrieval quality using MRR, Precision@K, Recall@K, and faithfulness — and show progressive improvement as each technique is added
4. **Design** guardrails for clinical AI: confidence tiering, citation grounding, hallucination detection
5. **Instrument** a RAG pipeline for production observability with LangSmith and Azure Monitor
6. **Architect** an Agentic RAG system using Azure AI Foundry with query decomposition, dynamic strategy selection, reflection, and human-in-the-loop confidence gating

---


## Quick Start


### Generate synthetic dataset

```bash
cd data/
python generate_synthetic_dataset.py
```

Expected output:
```
✓ discharge_summaries.json — 60 records
✓ clinical_guidelines.json — 30 records
✓ pubmed_abstracts.json    — 40 records
✓ drug_reference.json      — 25 records
✓ eval_qa_pairs.json       — 50 records
Total knowledge base chunks: 155
```


### Step 5: Run the full pipeline

```bash
cd src/

# Run all stages on 20 questions (cost-controlled)
python rag_pipeline.py --stage all --max-questions 20

# Run a specific query at a specific stage
python rag_pipeline.py --query "What SGLT2 inhibitor dose is safe in HFrEF with eGFR 30?" --stage 5
```

---

### Step 4: Run the evaluation dashboard (no API needed)

```bash
cd evaluation/
python evaluation_dashboard.py --demo
```

This generates three charts and the comparison table using pre-modeled performance data so participants can see the target output structure before running the actual pipeline.


## Dataset Design: Injected Retrieval Challenges

The synthetic dataset is **deliberately engineered** to expose the failure modes that motivate each advanced technique. This is the core of the learning design.

### Challenge Types

| Tag | What It Simulates | Which Technique Fixes It |
|-----|-------------------|--------------------------|
| `[TEMPORAL]` | 2019 AHA guideline (no SGLT2i) and 2022 guideline coexist in KB | Metadata filtering by year ≥ 2022 |
| `[NEAR-DUPLICATE]` | 5 chunks about DAPA-HF trial with 85-90% lexical overlap | MMR (λ=0.5 for diversity) |
| `[SPECIFICITY-GAP]` | Generic cardiology chunks rank high for HFrEF-specific dose query | Cross-encoder re-ranking |
| `[TERMINOLOGY]` | eGFR vs CrCl vs GFR used inconsistently across chunks | Hybrid BM25+Dense (BM25 catches exact tokens) |
| `[MULTI-HOP]` | Answer requires combining sepsis guideline + nephrology note | Hybrid retrieval + query decomposition |
| `[RARE-DISEASE]` | ATTR amyloidosis / Sickle cell: low embedding coverage | HyDE (hypothesis closes the embedding gap) |

### Sample Failure Walk-Through

**Query**: *"What cardiac medications should be avoided in ATTR cardiac amyloidosis?"*

- **Naive RAG returns**: Standard HFrEF GDMT chunks (GL001/GL002) — completely wrong context
- **Root cause**: ATTR amyloidosis has sparse embedding representation; the query embeds close to general HF treatment space
- **Fix**: HyDE generates a hypothesis mentioning "tafamidis", "TTR stabilizer", "ATTR-ACT trial" — this hypothesis embeds close to the correct chunks (DS007, DR003)
- **After HyDE**: MRR jumps from 0.00 → 0.89 for RARE-DISEASE queries

---

## The Six Retrieval Stages

### Stage 0: Naive RAG (Baseline)
```python
docs = vectorstore.similarity_search(query, k=5)
```
Dense cosine similarity. No filtering, no diversity, no re-ranking.
**Baseline MRR: ~0.33**

### Stage 1: Metadata Filtering
```python
docs = vectorstore.similarity_search(
    query, k=5,
    filter={"$and": [{"year": {"$gte": 2022}}, {"doc_type": {"$in": ["clinical_guideline"]}}]}
)
```
Filter by year, document type, department, evidence level. Prevents returning the 2019 guideline that omits SGLT2 inhibitors.
**Key impact: TEMPORAL queries +30% MRR**

### Stage 2: MMR (Maximum Marginal Relevance)
```python
docs = vectorstore.max_marginal_relevance_search(query, k=5, fetch_k=20, lambda_mult=0.6)
```
MMR score = λ × sim(d, q) − (1−λ) × max_sim(d, selected)  
Prevents all 5 results being near-duplicate DAPA-HF chunks when the question needs both DAPA-HF and EMPEROR-Reduced.
**Key impact: NEAR-DUPLICATE queries +28% MRR**

### Stage 3: Cross-Encoder Re-ranking
```python
from sentence_transformers import CrossEncoder
ce = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
candidates = vectorstore.similarity_search(query, k=20)
scores = ce.predict([(query, d.page_content) for d in candidates])
ranked = sorted(zip(scores, candidates), reverse=True)[:5]
```
Bi-encoder retrieves candidates (fast), cross-encoder re-scores each (query, doc) pair simultaneously (accurate). 100% local — no API needed.
**Key impact: SPECIFICITY-GAP queries +22% MRR**

### Stage 4: Hybrid BM25 + Dense (RRF)
```python
dense_results = vectorstore.similarity_search(query, k=20)
bm25_results  = bm25_retriever.get_relevant_documents(query)
fused = reciprocal_rank_fusion([dense_results, bm25_results])  # RRF k=60
```
BM25 captures exact token matches (drug names, ICD codes, numerical thresholds). Dense handles semantic similarity. RRF combines both rank lists without requiring score calibration.
**Key impact: TERMINOLOGY queries +25% MRR (eGFR/CrCl/GFR resolved)**

### Stage 5: HyDE (Hypothetical Document Embedding)
```python
hypothesis = llm.invoke(f"Write a clinical document excerpt answering: {query}")
docs = vectorstore.similarity_search(hypothesis, k=5)
```
For rare diseases, the query embedding is far from relevant documents. A generated hypothesis that contains the rare terminology bridges the embedding gap.
**Key impact: RARE-DISEASE queries +28% MRR**

---

## Evaluation Framework

### Metrics Computed

| Metric | Formula | Interpretation |
|--------|---------|----------------|
| MRR@10 | 1/rank of first relevant doc | Is the most relevant doc near the top? |
| Precision@5 | relevant_in_top5 / 5 | How many of top 5 are actually useful? |
| Recall@5 | relevant_found / total_relevant | Did we find all the needed documents? |
| Faithfulness | NLI-based overlap score | Does the answer stay within retrieved context? |
| Latency | End-to-end seconds | What is the production cost of each technique? |

### Target Performance Table

| Stage | MRR | Δ vs Baseline | P@5 | Latency |
|-------|-----|---------------|-----|---------|
| 0 Naive RAG | 0.33 | — | 0.30 | 1.2s |
| 1 Metadata Filtered | 0.57 | +0.24 | 0.52 | 1.4s |
| 2 MMR | 0.58 | +0.25 | 0.53 | 1.6s |
| 3 Cross-Encoder Rerank | 0.77 | +0.44 | 0.68 | 3.4s |
| 4 Hybrid BM25+Dense | 0.88 | +0.55 | 0.80 | 2.1s |
| 5 HyDE | 0.92 | +0.59 | 0.83 | 4.6s |

### Running RAGAS (Advanced — Requires OpenAI API)

```python
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_recall, context_precision

result = evaluate(
    dataset=your_hf_dataset,
    metrics=[faithfulness, answer_relevancy, context_recall, context_precision]
)
print(result.to_pandas())
```

---

## Task 6: Agentic RAG with Azure AI Foundry

This is the advanced  extension. The static pipeline becomes an autonomous agent that:

1. **QueryAnalyzer**: Decomposes complex questions into sub-questions, detects intent and complexity
2. **StrategyRouter**: Selects the optimal retrieval strategy for each sub-question (rare entity → HyDE; temporal → metadata filter; etc.)
3. **RetrieverAgent**: Executes multi-strategy retrieval in parallel
4. **AnswerSynthesizer**: Generates grounded, cited answer with confidence score
5. **CritiqueAgent**: Reflects on the answer — checks faithfulness, flags hallucinations, assigns confidence tier
6. **ConfidenceGate**: Routes: HIGH → return | NEEDS_REVIEW → iterate | ESCALATE → human physician

### Azure AI Foundry Services Integrated

| Service | Usage |
|---------|-------|
| Azure OpenAI Deployment | GPT-4o via Foundry model catalog |
| Prompt Management | Versioned system prompts, A/B testing |
| Content Safety API | Input/output screening for medical harmful content |
| Azure AI Tracing | Full OpenTelemetry spans for every agent step |
| Azure Monitor | Business KPI dashboard (escalation rate, latency SLA) |

### Setup for Azure Foundry (Task 6)

```bash
# 1. Create Azure AI Foundry project in Azure Portal
# 2. Deploy GPT-4o model in Foundry model catalog
# 3. Get connection string from Foundry project settings

export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
export AZURE_OPENAI_API_KEY="your-azure-openai-key"
export AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4o"
export AZURE_AI_PROJECT_CONN_STRING="eastus.api.azureml.ms;sub-id;rg;project-name"
export AZURE_CONTENT_SAFETY_KEY="your-content-safety-key"
export AZURE_CONTENT_SAFETY_ENDPOINT="https://your-cs.cognitiveservices.azure.com/"
export APPLICATIONINSIGHTS_CONN_STR="InstrumentationKey=..."

# Run agentic demo
cd src/
python agentic_rag_azure.py
```

---

## Observability Setup

### LangSmith (Recommended)

```bash
export LANGCHAIN_TRACING_V2=true
export LANGCHAIN_API_KEY=ls_xxxxxxxxxxxx
export LANGCHAIN_PROJECT=clinicalrag-pro
```

Every retrieval call and LLM generation is automatically traced. Build dashboards for:
- Retrieval latency P95 by stage
- Chunk hit rate (% of retrievals that include ground-truth chunk)
- Re-ranker score distribution
- Hallucination flag rate over time

### Azure Monitor (for Azure Foundry)

```python
from azure.monitor.opentelemetry import configure_azure_monitor
configure_azure_monitor(connection_string=os.getenv("APPLICATIONINSIGHTS_CONN_STR"))
```

Custom metrics to track:
- `rag.retrieval.mrr` — per-query MRR
- `rag.confidence_tier` — HIGH/NEEDS_REVIEW/ESCALATE distribution
- `rag.agent.iterations` — how often the critique loop fires
- `rag.latency_p95` — SLA monitoring

---

## Guardrails Implemented

| Guardrail | Implementation | Clinical Rationale |
|-----------|---------------|-------------------|
| Confidence Tiering | HIGH/NEEDS_REVIEW/ESCALATE based on faithfulness score | Prevents acting on low-confidence clinical answers |
| Citation Grounding | Every factual claim requires [DocID] citation | Enables source verification |
| Temporal Flagging | Flag if citing pre-2022 guidelines | Clinical guidelines update; old guidance can be harmful |
| Hallucination Detection | NLI-based faithfulness check (CritiqueAgent) | Clinical hallucinations cause patient harm |
| Content Safety | Azure AI Content Safety API | Screens for harmful medical content |
| Retrieval Verification | Check retrieved doc IDs against ground truth | Maintains evaluation accountability |

---


### Showcase/Demo

1. **Stage 0→1 (TEMPORAL)**: Show the 2019 HF guideline answer (missing SGLT2i) vs 2022 answer. Ask: *"What would happen if a clinician acted on the 2019 answer?"*

2. **Stage 0→2 (NEAR-DUPLICATE)**: Show the top 5 results for "SGLT2i for HFrEF" — all 5 are about DAPA-HF, none about EMPEROR-Reduced. Ask: *"How would you answer which SGLT2i to choose if you only saw dapagliflozin evidence?"*

3. **Stage 2→3 (SPECIFICITY-GAP)**: Show rank before/after cross-encoder for "osimertinib QTc monitoring". The generic monitoring chunk drops from rank 1 to rank 4; the osimertinib-specific chunk rises from rank 3 to rank 1.

4. **Stage 3→4 (TERMINOLOGY)**: Show BM25 finding "CrCl" chunks when query says "eGFR". Dense retrieval completely misses them. The hybrid retrieval fuses both.

5. **Stage 4→5 (RARE-DISEASE)**: Show the HyDE hypothesis for ATTR amyloidosis — it contains "tafamidis", "TTR", "ATTR-ACT". Ask: *"Why does the RAG system retrieve the right docs when given this hypothesis but not the original query?"*


## References

- [RAGAs Evaluation Framework](https://docs.ragas.io/)
- [LangChain MMR Documentation](https://python.langchain.com/docs/modules/data_connection/retrievers/mmr)
- [Reciprocal Rank Fusion Paper](https://plg.uwaterloo.ca/~gvcormac/cormacksigir09-rrf.pdf)
- [HyDE Paper (Gao et al. 2022)](https://arxiv.org/abs/2212.10496)
- [Azure AI Foundry Documentation](https://learn.microsoft.com/en-us/azure/ai-foundry/)
- [LangSmith Platform](https://smith.langchain.com/)
- [Serper API](https://serper.dev) — Google Search API for real-time guideline retrieval
- [PubMed E-Utilities](https://www.ncbi.nlm.nih.gov/books/NBK25497/) — Free clinical abstract API
- [UMLS Terminology Services](https://uts.nlm.nih.gov/) — Free with registration

---

*CitiusTech Gen AI & Agentic AI Training Program —  Project 1 of 5*
