"""
ClinicalRAG Pro — Task 6: Agentic RAG with Azure AI Foundry
=============================================================
Transforms the static RAG pipeline into an autonomous agent that:
  1. Decomposes complex multi-hop clinical questions
  2. Selects the right retrieval strategy per sub-question
  3. Critiques its own answers and iterates
  4. Uses Azure AI Foundry for: model deployment, safety evaluation,
     prompt management, and observability tracing

Architecture:
  User Query
      │
  [QueryAnalyzer Agent] ──→ intent, decomposed sub-questions, metadata hints
      │
  [StrategyRouter Agent] ──→ chooses: naive/metadata/mmr/rerank/hybrid/hyde
      │                                per sub-question
  [Retriever Tool x N]  ──→ parallel retrieval for each sub-question
      │
  [AnswerSynthesizer Agent] ──→ merges evidence, generates grounded answer
      │
  [CritiqueAgent] ──→ scores faithfulness, identifies hallucinations
      │
  [ConfidenceGate] ──→ HIGH / NEEDS_REVIEW / ESCALATE
      │
  Final Answer + Audit Trail

Azure AI Foundry Services Used:
  - Azure AI Foundry model deployment (GPT-4o via Azure OpenAI)
  - Prompt Management (versioned prompts)
  - Content Safety API (medical guardrails)
  - Azure AI Tracing (Application Insights)
  - Prompt Flow for orchestration visualization

Requirements:
  pip install azure-ai-projects azure-ai-inference azure-monitor-opentelemetry
              opentelemetry-sdk langchain-azure-ai

Environment variables:
  AZURE_OPENAI_ENDPOINT        = https://<your-resource>.openai.azure.com/
  AZURE_OPENAI_API_KEY         = <your-key>
  AZURE_OPENAI_DEPLOYMENT_NAME = gpt-4o (or your deployment name)
  AZURE_AI_PROJECT_CONN_STRING = <found in Azure AI Foundry project settings>
  AZURE_CONTENT_SAFETY_KEY     = <from Azure AI Services>
  AZURE_CONTENT_SAFETY_ENDPOINT= https://<your-resource>.cognitiveservices.azure.com/
  APPLICATIONINSIGHTS_CONN_STR = <from Azure Monitor>
"""

import os
import json
import logging
from typing import Literal, Optional
from dataclasses import dataclass, field
from enum import Enum

# Azure AI Foundry / Azure OpenAI
try:
    from azure.ai.projects import AIProjectClient
    from azure.ai.projects.models import ConnectionType
    from azure.identity import DefaultAzureCredential
    AZURE_AI_PROJECTS_AVAILABLE = True
except ImportError:
    AZURE_AI_PROJECTS_AVAILABLE = False
    print("⚠  azure-ai-projects not installed. Using mock Azure client.")

# Azure Content Safety
try:
    from azure.ai.contentsafety import ContentSafetyClient
    from azure.ai.contentsafety.models import AnalyzeTextOptions, TextCategory
    from azure.core.credentials import AzureKeyCredential
    CONTENT_SAFETY_AVAILABLE = True
except ImportError:
    CONTENT_SAFETY_AVAILABLE = False

# OpenTelemetry for tracing
try:
    from azure.monitor.opentelemetry import configure_azure_monitor
    from opentelemetry import trace
    TRACING_AVAILABLE = True
except ImportError:
    TRACING_AVAILABLE = False
    print("⚠  azure-monitor-opentelemetry not installed. Tracing disabled.")

from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from pydantic import BaseModel, Field

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────
# AZURE CONFIGURATION
# ─────────────────────────────────────────────────────────

AZURE_ENDPOINT   = os.getenv("AZURE_OPENAI_ENDPOINT", "https://your-resource.openai.azure.com/")
AZURE_KEY        = os.getenv("AZURE_OPENAI_API_KEY", "YOUR_AZURE_OPENAI_KEY")
AZURE_DEPLOY     = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
AZURE_EMBED_DEPLOY = os.getenv("AZURE_EMBED_DEPLOYMENT_NAME", "text-embedding-3-small")
AZURE_CONN_STR   = os.getenv("AZURE_AI_PROJECT_CONN_STRING", "")
CS_KEY           = os.getenv("AZURE_CONTENT_SAFETY_KEY", "")
CS_ENDPOINT      = os.getenv("AZURE_CONTENT_SAFETY_ENDPOINT", "")
APP_INSIGHTS_STR = os.getenv("APPLICATIONINSIGHTS_CONN_STR", "")


def get_azure_llm(temperature=0) -> AzureChatOpenAI:
    """Initialize Azure OpenAI LLM via Foundry deployment."""
    return AzureChatOpenAI(
        azure_endpoint=AZURE_ENDPOINT,
        api_key=AZURE_KEY,
        azure_deployment=AZURE_DEPLOY,
        api_version="2024-08-01-preview",
        temperature=temperature,
    )


def get_azure_embeddings() -> AzureOpenAIEmbeddings:
    """Initialize Azure OpenAI embeddings via Foundry deployment."""
    return AzureOpenAIEmbeddings(
        azure_endpoint=AZURE_ENDPOINT,
        api_key=AZURE_KEY,
        azure_deployment=AZURE_EMBED_DEPLOY,
        api_version="2024-08-01-preview",
    )


def setup_tracing():
    """Configure Azure Monitor OpenTelemetry tracing."""
    if not TRACING_AVAILABLE or not APP_INSIGHTS_STR:
        logger.warning("Tracing not configured. Set APPLICATIONINSIGHTS_CONN_STR.")
        return None
    configure_azure_monitor(connection_string=APP_INSIGHTS_STR)
    tracer = trace.get_tracer("clinicalrag_pro.agentic")
    logger.info("✅ Azure Monitor tracing configured.")
    return tracer


# ─────────────────────────────────────────────────────────
# AZURE AI FOUNDRY — PROMPT MANAGEMENT
# ─────────────────────────────────────────────────────────

class FoundryPromptManager:
    """
    Manages versioned prompts via Azure AI Foundry.
    
    In production: prompts are stored, versioned, and A/B testable in Foundry.
    Here we provide the prompts inline with documentation on how to migrate.
    
    TRAINER NOTE: Walk participants through:
    1. Creating a Prompt Flow in Azure AI Foundry Studio
    2. Storing system prompts as versioned assets
    3. Evaluating prompt variants using Foundry's built-in evaluators
    4. Monitoring prompt drift via Azure Monitor
    """
    
    # Versioned system prompts — in production, load from Azure AI Foundry
    PROMPTS = {
        "query_analyzer_v1": """You are a clinical query analysis expert.
Analyze the user's clinical question and return a JSON with:
{
  "intent": "drug_dosing|guideline_lookup|drug_interaction|diagnosis_support|prognosis",
  "complexity": "single_hop|multi_hop|comparative",
  "entities": ["list of medical entities: drugs, conditions, ICD codes"],
  "temporal_sensitivity": true/false,
  "rare_entity": true/false,
  "sub_questions": ["list of sub-questions to answer (1-3)"],
  "metadata_hints": {
    "preferred_doc_types": ["clinical_guideline", "drug_reference", "pubmed_abstract"],
    "filter_year_min": 2022,
    "department": ""
  }
}""",
        "strategy_router_v1": """Given the query analysis, select the optimal retrieval strategy.
Return JSON: {"strategy": "naive|metadata|mmr|rerank|hybrid|hyde", "reason": "..."}

Rules:
- TEMPORAL question → always use "metadata" (filter_year_min)
- NEAR-DUPLICATE risk → use "mmr"  
- RARE entity (amyloidosis, ATTR, rare conditions) → use "hyde"
- Multi-hop or terminology issues → use "hybrid"
- Straightforward guideline lookup → use "rerank"
- Default → "rerank" """,
        
        "answer_synthesizer_v2": """You are ClinicalRAG Pro, an evidence-based clinical decision support assistant.
RULES:
1. Answer ONLY from context below. Never invent clinical facts.
2. Cite every claim with [DocID] notation.
3. If evidence is insufficient: state "INSUFFICIENT EVIDENCE IN CONTEXT."
4. Note evidence levels: Class I-A (strongest) to III (expert opinion).
5. Flag outdated information (pre-2022 guidelines).
6. End every answer with: CONFIDENCE: [HIGH|MEDIUM|LOW] and reason.

Context:
{context}""",

        "critique_v1": """You are a clinical QA critic. Evaluate this answer strictly.
Return JSON:
{
  "faithfulness_score": 0.0-1.0,  # How well answer is grounded in context
  "hallucination_flags": ["list any claims not supported by context"],
  "citation_coverage": 0.0-1.0,   # Fraction of claims with citations
  "temporal_flag": true/false,     # Is outdated info cited without caveat?
  "confidence_tier": "HIGH|NEEDS_REVIEW|ESCALATE",
  "revision_needed": true/false,
  "revision_instruction": "..."
}

Original Question: {question}
Retrieved Context: {context}
Generated Answer: {answer}"""
    }
    
    @classmethod
    def get(cls, name: str) -> str:
        return cls.PROMPTS.get(name, "Prompt not found.")
    
    @classmethod
    def migrate_to_foundry(cls):
        """
        TRAINER EXERCISE: Implement this to push prompts to Azure AI Foundry.
        
        from azure.ai.projects import AIProjectClient
        client = AIProjectClient.from_connection_string(AZURE_CONN_STR, DefaultAzureCredential())
        
        for name, content in cls.PROMPTS.items():
            # Store prompt as a versioned asset in Foundry
            client.prompts.create_or_update(name=name, content=content)
            print(f"Uploaded prompt: {name}")
        """
        raise NotImplementedError("Implement using Azure AI Projects SDK")


# ─────────────────────────────────────────────────────────
# AZURE CONTENT SAFETY GUARDRAIL
# ─────────────────────────────────────────────────────────

class ContentSafetyGuardrail:
    """
    Azure AI Content Safety integration.
    Screens both inputs and outputs for harmful medical content.
    
    For clinical RAG, we focus on:
    - Violence (self-harm, suicide methods in medical context)
    - Hate content
    - Medical misinformation patterns (custom blocklist)
    
    TRAINER NOTE: Foundry Safety Evaluations (groundedness, relevance,
    coherence) can be run as batch evaluators — discuss async eval pipeline.
    """
    
    CLINICAL_BLOCKLIST = [
        "lethal dose of", "how to overdose on", "suicide method",
        "harm yourself with", "fatal amount of"
    ]
    
    def __init__(self):
        self.client = None
        if CONTENT_SAFETY_AVAILABLE and CS_KEY and CS_ENDPOINT:
            self.client = ContentSafetyClient(
                CS_ENDPOINT, AzureKeyCredential(CS_KEY)
            )
    
    def check_input(self, text: str) -> dict:
        """Check query for harmful content before processing."""
        # Pattern-based blocklist (fast, no API cost)
        text_lower = text.lower()
        for pattern in self.CLINICAL_BLOCKLIST:
            if pattern in text_lower:
                return {
                    "safe": False,
                    "reason": f"Blocked pattern: '{pattern}'",
                    "action": "BLOCK"
                }
        
        # Azure Content Safety API check
        if self.client:
            try:
                response = self.client.analyze_text(
                    AnalyzeTextOptions(
                        text=text,
                        categories=[
                            TextCategory.HATE,
                            TextCategory.SELF_HARM,
                            TextCategory.VIOLENCE
                        ]
                    )
                )
                for result in response.categories_analysis:
                    if result.severity >= 4:  # 0-6 scale; 4+ = action required
                        return {
                            "safe": False,
                            "reason": f"{result.category} severity {result.severity}",
                            "action": "BLOCK"
                        }
            except Exception as e:
                logger.warning(f"Content Safety API error: {e}. Proceeding with caution.")
        
        return {"safe": True, "reason": "Passed", "action": "ALLOW"}
    
    def check_output(self, answer: str) -> dict:
        """Check generated answer before returning to user."""
        return self.check_input(answer)  # Same checks apply


# ─────────────────────────────────────────────────────────
# AGENTIC RAG — AGENT NODES
# ─────────────────────────────────────────────────────────

@dataclass
class AgentState:
    """Shared state across all agent nodes."""
    original_query:    str = ""
    intent:            str = ""
    complexity:        str = ""
    entities:          list = field(default_factory=list)
    sub_questions:     list = field(default_factory=list)
    metadata_hints:    dict = field(default_factory=dict)
    selected_strategy: str = ""
    retrieved_docs:    list = field(default_factory=list)
    context:           str = ""
    draft_answer:      str = ""
    critique:          dict = field(default_factory=dict)
    final_answer:      str = ""
    confidence_tier:   str = ""
    audit_trail:       list = field(default_factory=list)
    iteration:         int = 0
    max_iterations:    int = 2


class QueryAnalyzerAgent:
    """Decomposes complex queries into structured analysis."""
    
    def __init__(self, llm):
        self.llm = llm
        self.parser = JsonOutputParser()
    
    def run(self, state: AgentState, tracer=None) -> AgentState:
        span_ctx = tracer.start_as_current_span("QueryAnalyzer") if tracer else None
        try:
            prompt = ChatPromptTemplate.from_messages([
                ("system", FoundryPromptManager.get("query_analyzer_v1")),
                ("human", "Clinical Question: {question}")
            ])
            chain = prompt | self.llm | self.parser
            result = chain.invoke({"question": state.original_query})
            
            state.intent          = result.get("intent", "unknown")
            state.complexity      = result.get("complexity", "single_hop")
            state.entities        = result.get("entities", [])
            state.sub_questions   = result.get("sub_questions", [state.original_query])
            state.metadata_hints  = result.get("metadata_hints", {})
            
            state.audit_trail.append({
                "agent": "QueryAnalyzer",
                "intent": state.intent,
                "complexity": state.complexity,
                "sub_questions": state.sub_questions
            })
            logger.info(f"[QueryAnalyzer] Intent: {state.intent} | Complexity: {state.complexity}")
        except Exception as e:
            logger.error(f"[QueryAnalyzer] Failed: {e}. Using query as-is.")
            state.sub_questions = [state.original_query]
        finally:
            if span_ctx:
                span_ctx.__exit__(None, None, None)
        return state


class StrategyRouterAgent:
    """Selects optimal retrieval strategy based on query analysis."""
    
    def __init__(self, llm):
        self.llm = llm
        self.parser = JsonOutputParser()
    
    def run(self, state: AgentState, tracer=None) -> AgentState:
        analysis_summary = json.dumps({
            "intent":     state.intent,
            "complexity": state.complexity,
            "entities":   state.entities,
            "temporal_sensitivity": state.metadata_hints.get("filter_year_min") is not None,
            "rare_entity": any(e.lower() in ["attr", "amyloid", "tafamidis", "crizanlizumab"]
                               for e in state.entities)
        })
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", FoundryPromptManager.get("strategy_router_v1")),
            ("human", "Query Analysis: {analysis}\nOriginal Query: {query}")
        ])
        chain = prompt | self.llm | self.parser
        try:
            result = chain.invoke({
                "analysis": analysis_summary,
                "query": state.original_query
            })
            state.selected_strategy = result.get("strategy", "rerank")
        except Exception:
            state.selected_strategy = "rerank"  # Safe default
        
        state.audit_trail.append({
            "agent": "StrategyRouter",
            "selected_strategy": state.selected_strategy
        })
        logger.info(f"[StrategyRouter] Selected: {state.selected_strategy}")
        return state


class RetrieverAgent:
    """
    Executes retrieval using the strategy selected by StrategyRouter.
    Supports all 6 retrieval modes from the static pipeline.
    """
    
    def __init__(self, vectorstore, bm25_retriever, llm):
        self.vs   = vectorstore
        self.bm25 = bm25_retriever
        self.llm  = llm
    
    def run(self, state: AgentState, tracer=None) -> AgentState:
        # Import retrieval functions from static pipeline
        from rag_pipeline import (
            retrieve_naive, retrieve_with_metadata_filter,
            retrieve_with_mmr, retrieve_with_reranking,
            retrieve_hybrid, retrieve_with_hyde,
            TOP_K, FINAL_K
        )
        
        strategy = state.selected_strategy
        hints    = state.metadata_hints
        all_docs = []
        
        for sub_q in state.sub_questions:
            try:
                if strategy == "naive":
                    docs = retrieve_naive(self.vs, sub_q)
                elif strategy == "metadata":
                    docs = retrieve_with_metadata_filter(
                        self.vs, sub_q,
                        filter_year_min=hints.get("filter_year_min", 2022),
                        filter_doc_types=hints.get("preferred_doc_types"),
                    )
                elif strategy == "mmr":
                    docs = retrieve_with_mmr(self.vs, sub_q)
                elif strategy == "rerank":
                    docs = retrieve_with_reranking(self.vs, sub_q)
                elif strategy == "hybrid":
                    docs = retrieve_hybrid(self.vs, self.bm25, sub_q)
                elif strategy == "hyde":
                    docs = retrieve_with_hyde(self.vs, sub_q, self.llm)
                else:
                    docs = retrieve_with_reranking(self.vs, sub_q)
                
                all_docs.extend(docs)
            except Exception as e:
                logger.error(f"[Retriever] Error on '{sub_q}': {e}")
        
        # Deduplicate by doc_id
        seen = set()
        unique_docs = []
        for doc in all_docs:
            doc_id = doc.metadata.get("doc_id", doc.page_content[:30])
            if doc_id not in seen:
                seen.add(doc_id)
                unique_docs.append(doc)
        
        state.retrieved_docs = unique_docs[:FINAL_K * 2]  # Generous pool for synthesizer
        state.context = "\n\n---\n\n".join(
            f"[{d.metadata.get('doc_id','?')}] ({d.metadata.get('doc_type','?')}, "
            f"{d.metadata.get('year','')})\n{d.page_content}"
            for d in state.retrieved_docs
        )
        
        state.audit_trail.append({
            "agent": "Retriever",
            "strategy": strategy,
            "num_docs": len(state.retrieved_docs),
            "doc_ids": [d.metadata.get("doc_id") for d in state.retrieved_docs]
        })
        logger.info(f"[Retriever] Retrieved {len(state.retrieved_docs)} docs via {strategy}.")
        return state


class AnswerSynthesizerAgent:
    """Generates grounded, cited clinical answer."""
    
    def __init__(self, llm):
        self.llm = llm
    
    def run(self, state: AgentState, tracer=None) -> AgentState:
        prompt = ChatPromptTemplate.from_messages([
            ("system", FoundryPromptManager.get("answer_synthesizer_v2")),
            ("human", "Clinical Question: {question}\n\nProvide evidence-based answer with [DocID] citations.")
        ])
        chain = prompt | self.llm
        
        try:
            response = chain.invoke({
                "context":  state.context,
                "question": state.original_query
            })
            state.draft_answer = response.content
        except Exception as e:
            logger.error(f"[Synthesizer] Error: {e}")
            state.draft_answer = "ERROR: Could not generate answer. Please retry."
        
        state.audit_trail.append({"agent": "AnswerSynthesizer", "answer_length": len(state.draft_answer)})
        return state


class CritiqueAgent:
    """
    Reflection agent that critiques the draft answer for:
    - Faithfulness to retrieved context (hallucination detection)
    - Citation coverage
    - Temporal accuracy (old guideline citations)
    - Assigns confidence tier
    
    TRAINER NOTE: This is the "Reflection" agentic design pattern.
    The critique agent creates a feedback loop, triggering re-retrieval
    or re-generation when quality thresholds are not met.
    """
    
    def __init__(self, llm):
        self.llm = llm
        self.parser = JsonOutputParser()
    
    def run(self, state: AgentState, tracer=None) -> AgentState:
        prompt = ChatPromptTemplate.from_messages([
            ("system", FoundryPromptManager.get("critique_v1")),
            ("human", "Evaluate the following answer. Return only valid JSON.")
        ])
        chain = prompt | self.llm | self.parser
        
        try:
            critique = chain.invoke({
                "question": state.original_query,
                "context":  state.context[:3000],  # Truncate for token efficiency
                "answer":   state.draft_answer
            })
            state.critique        = critique
            state.confidence_tier = critique.get("confidence_tier", "NEEDS_REVIEW")
        except Exception as e:
            logger.error(f"[Critique] Error: {e}")
            state.critique        = {"faithfulness_score": 0.5, "revision_needed": False}
            state.confidence_tier = "NEEDS_REVIEW"
        
        state.audit_trail.append({
            "agent": "CritiqueAgent",
            "faithfulness": state.critique.get("faithfulness_score"),
            "confidence_tier": state.confidence_tier,
            "revision_needed": state.critique.get("revision_needed", False),
            "hallucination_flags": state.critique.get("hallucination_flags", [])
        })
        logger.info(f"[CritiqueAgent] Faithfulness: {state.critique.get('faithfulness_score','?')} | Tier: {state.confidence_tier}")
        return state


class ConfidenceGate:
    """
    Routes the response based on confidence tier.
    HIGH → return directly
    NEEDS_REVIEW → iterate if budget allows, else flag
    ESCALATE → always require human physician review
    
    TRAINER NOTE: This is the "Confidence Gating" reliability pattern.
    In production, ESCALATE tier would trigger an alert to the on-call
    clinical decision support team.
    """
    
    @staticmethod
    def route(state: AgentState) -> str:
        """Returns: 'done' | 'retry' | 'escalate'"""
        tier = state.confidence_tier
        
        if tier == "HIGH":
            return "done"
        elif tier == "ESCALATE":
            return "escalate"
        elif state.iteration >= state.max_iterations:
            logger.warning("[ConfidenceGate] Max iterations reached. Returning with NEEDS_REVIEW flag.")
            return "done"
        else:
            return "retry"


# ─────────────────────────────────────────────────────────
# AGENTIC ORCHESTRATOR (LangGraph-compatible)
# ─────────────────────────────────────────────────────────

class AgenticRAGOrchestrator:
    """
    Orchestrates the full agentic RAG pipeline.
    
    This implementation uses a direct state machine pattern.
    EXTENSION: Replace with LangGraph StateGraph for full agentic
    control (conditional edges, human interrupt, parallel nodes).
    See: notebooks/langgraph_extension.ipynb
    
    FOUNDRY INTEGRATION POINTS:
    ┌──────────────────────────────────────────────────────┐
    │  Azure AI Foundry                                     │
    │  ┌─────────────────┐  ┌──────────────────────────┐  │
    │  │  Model Deploy.  │  │  Content Safety API       │  │
    │  │  GPT-4o         │  │  Input/Output screening   │  │
    │  └─────────────────┘  └──────────────────────────┘  │
    │  ┌─────────────────┐  ┌──────────────────────────┐  │
    │  │  Prompt Mgmt    │  │  Azure Monitor Tracing    │  │
    │  │  Versioned      │  │  Full span instrumentation│  │
    │  └─────────────────┘  └──────────────────────────┘  │
    └──────────────────────────────────────────────────────┘
    """
    
    def __init__(self, vectorstore, bm25_retriever):
        self.llm           = get_azure_llm(temperature=0)
        self.safety        = ContentSafetyGuardrail()
        self.tracer        = setup_tracing()
        
        self.query_analyzer = QueryAnalyzerAgent(self.llm)
        self.strategy_router = StrategyRouterAgent(self.llm)
        self.retriever      = RetrieverAgent(vectorstore, bm25_retriever, self.llm)
        self.synthesizer    = AnswerSynthesizerAgent(self.llm)
        self.critiquer      = CritiqueAgent(self.llm)
    
    def run(self, query: str, max_iterations=2) -> dict:
        """Execute the full agentic pipeline and return structured result."""
        
        print(f"\n{'='*60}")
        print(f"🤖 ClinicalRAG Pro — Agentic Mode")
        print(f"{'='*60}")
        print(f"Query: {query}\n")
        
        # ── GUARDRAIL: Input Safety Check ─────────────────
        safety_check = self.safety.check_input(query)
        if not safety_check["safe"]:
            return {
                "answer": f"⛔ Query blocked by safety guardrail: {safety_check['reason']}",
                "confidence_tier": "BLOCKED",
                "audit_trail": [{"agent": "ContentSafety", **safety_check}]
            }
        
        # ── AGENT STATE INITIALIZATION ─────────────────────
        state = AgentState(
            original_query=query,
            max_iterations=max_iterations
        )
        
        # ── AGENT LOOP ─────────────────────────────────────
        while state.iteration <= max_iterations:
            print(f"\n[Iteration {state.iteration + 1}]")
            
            if state.iteration == 0:
                # First pass: full analysis + strategy selection
                print("  ▶ QueryAnalyzer...")
                state = self.query_analyzer.run(state, self.tracer)
                print(f"    Intent: {state.intent} | Sub-questions: {len(state.sub_questions)}")
                
                print("  ▶ StrategyRouter...")
                state = self.strategy_router.run(state, self.tracer)
                print(f"    Strategy: {state.selected_strategy}")
                
                print("  ▶ Retriever...")
                state = self.retriever.run(state, self.tracer)
                print(f"    Retrieved: {len(state.retrieved_docs)} documents")
            else:
                # Subsequent passes: re-retrieve with a different strategy
                state.selected_strategy = "hybrid"  # Fallback to most robust strategy
                state.sub_questions = [query]        # Simplify to original query
                print("  ▶ Retriever (retry with hybrid)...")
                state = self.retriever.run(state, self.tracer)
            
            print("  ▶ AnswerSynthesizer...")
            state = self.synthesizer.run(state, self.tracer)
            
            print("  ▶ CritiqueAgent...")
            state = self.critiquer.run(state, self.tracer)
            print(f"    Faithfulness: {state.critique.get('faithfulness_score', '?')} | Tier: {state.confidence_tier}")
            
            route = ConfidenceGate.route(state)
            
            if route == "done":
                print(f"  ✅ ConfidenceGate: DONE (Tier: {state.confidence_tier})")
                break
            elif route == "escalate":
                print("  🚨 ConfidenceGate: ESCALATE — Human physician review required")
                state.draft_answer += (
                    "\n\n⚠️  ESCALATION FLAG: This answer requires review by a clinical "
                    "specialist before acting on it. Confidence tier: ESCALATE. "
                    f"Hallucination flags: {state.critique.get('hallucination_flags', [])}"
                )
                break
            else:
                print(f"  🔄 ConfidenceGate: RETRY (iteration {state.iteration + 1})")
                state.iteration += 1
        
        # ── GUARDRAIL: Output Safety Check ────────────────
        output_check = self.safety.check_output(state.draft_answer)
        if not output_check["safe"]:
            state.draft_answer = f"⛔ Generated answer blocked by safety filter: {output_check['reason']}"
        
        state.final_answer = state.draft_answer
        
        # ── RESULT ─────────────────────────────────────────
        print(f"\n{'='*60}")
        print(f"📝 FINAL ANSWER [{state.confidence_tier}]:")
        print(f"{'='*60}")
        print(state.final_answer)
        print(f"\n📚 Sources: {[d.metadata.get('doc_id') for d in state.retrieved_docs]}")
        
        return {
            "query":           query,
            "answer":          state.final_answer,
            "confidence_tier": state.confidence_tier,
            "retrieved_doc_ids": [d.metadata.get("doc_id") for d in state.retrieved_docs],
            "strategy_used":   state.selected_strategy,
            "iterations":      state.iteration + 1,
            "faithfulness":    state.critique.get("faithfulness_score", 0.0),
            "hallucination_flags": state.critique.get("hallucination_flags", []),
            "audit_trail":     state.audit_trail,
        }


# ─────────────────────────────────────────────────────────
# AZURE AI FOUNDRY — EVALUATION PIPELINE
# ─────────────────────────────────────────────────────────

def run_foundry_evaluation(results: list[dict], project_conn_str: str = ""):
    """
    TRAINER TASK: Implement batch evaluation using Azure AI Foundry's
    built-in evaluators (groundedness, relevance, coherence, fluency).
    
    This is the PRODUCTION evaluation approach for enterprise deployment.
    
    How to implement:
    ─────────────────
    from azure.ai.projects import AIProjectClient
    from azure.ai.projects.models import (
        GroundednessEvaluator, RelevanceEvaluator, CoherenceEvaluator
    )
    from azure.identity import DefaultAzureCredential
    
    client = AIProjectClient.from_connection_string(
        project_conn_str or AZURE_CONN_STR,
        DefaultAzureCredential()
    )
    
    eval_data = [
        {
            "query": r["query"],
            "response": r["answer"],
            "context": r.get("context", ""),
            "ground_truth": r.get("ground_truth_answer", "")
        }
        for r in results
    ]
    
    # Run Foundry's built-in evaluators
    eval_run = client.evaluations.create(
        data=eval_data,
        evaluators={
            "groundedness": GroundednessEvaluator(client.inference.get_azure_openai_client()),
            "relevance":    RelevanceEvaluator(client.inference.get_azure_openai_client()),
            "coherence":    CoherenceEvaluator(client.inference.get_azure_openai_client()),
        }
    )
    eval_run.wait()
    print(eval_run.get_results())
    
    Azure AI Foundry Dashboard:
    - Navigate to: AI Foundry Studio → Evaluation → Your eval run
    - Review per-metric heatmaps
    - Compare baseline vs. advanced RAG side-by-side
    - Export to Azure Monitor for ongoing observability
    """
    print("\n⚙️  Azure AI Foundry Evaluation")
    print("   TRAINER: Implement run_foundry_evaluation() using the")
    print("   Azure AI Projects SDK and the pattern above.")
    print(f"   {len(results)} results ready for evaluation.")


# ─────────────────────────────────────────────────────────
# ENTRYPOINT
# ─────────────────────────────────────────────────────────

def demo(query: str = None):
    """
    Demo runner - builds orchestrator and runs a single query.
    In a real environment, vectorstore and bm25 are prebuilt.
    """
    import sys
    sys.path.insert(0, str(__file__).replace("agentic_rag_azure.py", ""))
    
    from rag_pipeline import load_knowledge_base, chunk_documents, build_vectorstore
    from langchain_community.retrievers import BM25Retriever
    
    query = query or (
        "What is the current evidence-based treatment for a 70-year-old patient with HFrEF "
        "and CKD stage 3b (eGFR 35), and which SGLT2 inhibitor dose is appropriate?"
    )
    
    docs = load_knowledge_base()
    chunks = chunk_documents(docs)
    
    # Use Azure embeddings for production
    vectorstore = build_vectorstore(chunks, embed_model="azure")
    bm25 = BM25Retriever.from_documents(chunks)
    bm25.k = 10
    
    orchestrator = AgenticRAGOrchestrator(vectorstore, bm25)
    result = orchestrator.run(query)
    
    print("\n\n📊 AUDIT TRAIL:")
    for entry in result["audit_trail"]:
        print(f"  [{entry['agent']}] {json.dumps({k: v for k, v in entry.items() if k != 'agent'}, default=str)}")
    
    return result


if __name__ == "__main__":
    demo()
