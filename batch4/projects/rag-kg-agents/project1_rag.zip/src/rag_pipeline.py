"""
ClinicalRAG Pro - Main Pipeline
================================
Progressive RAG implementation showing baseline → advanced techniques.

Strategies implemented:
  Stage 0: Naive RAG (baseline)
  Stage 1: + Metadata Filtering
  Stage 2: + MMR (Maximum Marginal Relevance)
  Stage 3: + Cross-encoder Re-ranking
  Stage 4: + Hybrid BM25+Dense Retrieval
  Stage 5: + HyDE (Hypothetical Document Embedding)
  Stage 6: Agentic RAG (see agentic_rag_azure.py)

Usage:
  python rag_pipeline.py --stage all          # Run all stages sequentially
  python rag_pipeline.py --stage 0            # Naive RAG only
  python rag_pipeline.py --stage 3            # Up to re-ranking
  python rag_pipeline.py --query "your query" --stage 5

Requirements:
  pip install openai langchain langchain-openai langchain-community
              chromadb rank_bm25 sentence-transformers ragas pandas tqdm
"""

import os
import json
import math
import time
import argparse
import logging
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from tqdm import tqdm

# LangChain
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_community.retrievers import BM25Retriever

# Cross-encoder re-ranking
try:
    from sentence_transformers import CrossEncoder
    CROSSENCODER_AVAILABLE = True
except ImportError:
    CROSSENCODER_AVAILABLE = False
    print("⚠  sentence-transformers not installed. Stage 3 (re-ranking) will be skipped.")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────

DATA_DIR = Path(__file__).parent.parent / "data"
RESULTS_DIR = Path(__file__).parent.parent / "evaluation"
RESULTS_DIR.mkdir(exist_ok=True)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "YOUR_OPENAI_API_KEY_HERE")
# Free alternatives: use Ollama with local models, or HuggingFace Inference API
# See configs/free_api_alternatives.md for details

EMBED_MODEL = "text-embedding-3-small"      # ~$0.02 per 1M tokens
LLM_MODEL   = "gpt-4o-mini"                # Cost-efficient for training
CROSS_ENCODER = "cross-encoder/ms-marco-MiniLM-L-6-v2"  # Free, no API needed
TOP_K = 10          # Candidates retrieved before re-ranking
FINAL_K = 5         # Final chunks passed to LLM
MMR_LAMBDA = 0.6    # MMR diversity-relevance tradeoff (0=max diversity, 1=max relevance)

# ─────────────────────────────────────────────────────────
# DATA LOADING & DOCUMENT PREPARATION
# ─────────────────────────────────────────────────────────

def load_knowledge_base() -> list[Document]:
    """
    Load all synthetic clinical documents and convert to LangChain Documents.
    Metadata is preserved for filtering.
    """
    all_docs = []
    sources = [
        ("discharge_summaries.json", "discharge_summary"),
        ("clinical_guidelines.json", "clinical_guideline"),
        ("pubmed_abstracts.json",    "pubmed_abstract"),
        ("drug_reference.json",      "drug_reference"),
    ]
    for fname, doc_type in sources:
        fpath = DATA_DIR / fname
        if not fpath.exists():
            logger.warning(f"Dataset file not found: {fpath}. Run generate_synthetic_dataset.py first.")
            continue
        with open(fpath) as f:
            items = json.load(f)
        for item in items:
            # Build rich metadata - critical for Stage 1 (metadata filtering)
            metadata = {
                "doc_id":       item["id"],
                "doc_type":     item.get("type", doc_type),
                "year":         int(item.get("year", item.get("date", "2020")[:4])),
                "department":   item.get("department", ""),
                "icd10":        item.get("icd10", ""),
                "condition":    item.get("condition", ""),
                "evidence_lvl": item.get("evidence_level", ""),
                "source_org":   item.get("source_org", ""),
                "challenge_tags": ",".join(item.get("challenge_tags", [])),
                # Drug-specific metadata
                "drug_class":   item.get("class", ""),
                "drug_name":    item.get("drug_name", ""),
                # Research metadata
                "journal":      item.get("journal", ""),
                "pmid":         item.get("pmid", ""),
            }
            # Build text: prepend metadata summary for better BM25/dense retrieval
            text_parts = []
            if item.get("drug_name"):
                text_parts.append(f"Drug: {item['drug_name']} ({item.get('brand','')}) | Class: {item.get('class','')}")
            if item.get("guideline_name"):
                text_parts.append(f"Guideline: {item['guideline_name']} {item.get('year','')} | Org: {item.get('source_org','')}")
            if item.get("title"):
                text_parts.append(f"Study: {item['title']} ({item.get('journal','')}, {item.get('year','')})")
            text_parts.append(item.get("text", ""))
            full_text = "\n".join(text_parts)
            all_docs.append(Document(page_content=full_text, metadata=metadata))
    logger.info(f"Loaded {len(all_docs)} documents from knowledge base.")
    return all_docs


def chunk_documents(docs: list[Document], chunk_size=600, chunk_overlap=100) -> list[Document]:
    """
    Chunk documents using recursive character splitting.
    Metadata is propagated to each chunk.
    
    TRAINER NOTE: This is a key design decision point.
    Participants should experiment with:
      - chunk_size: 300 (fine-grained) vs 800 (coarse)
      - Semantic chunking using sentence-transformers
      - Late chunking (chunk at query time)
      - Hierarchical chunking for structured clinical notes
    """
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " "],
    )
    chunks = splitter.split_documents(docs)
    # Preserve and augment chunk metadata
    for i, chunk in enumerate(chunks):
        chunk.metadata["chunk_id"] = f"{chunk.metadata.get('doc_id','UNK')}_c{i:03d}"
        chunk.metadata["chunk_index"] = i
    logger.info(f"Created {len(chunks)} chunks from {len(docs)} documents.")
    return chunks

# ─────────────────────────────────────────────────────────
# VECTOR STORE
# ─────────────────────────────────────────────────────────

def build_vectorstore(chunks: list[Document], persist_dir="./chroma_db") -> Chroma:
    """Build or load Chroma vector store."""
    embeddings = OpenAIEmbeddings(model=EMBED_MODEL, api_key=OPENAI_API_KEY)
    if Path(persist_dir).exists():
        logger.info("Loading existing vector store...")
        return Chroma(persist_directory=persist_dir, embedding_function=embeddings)
    logger.info("Building vector store (embedding documents)...")
    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=persist_dir
    )
    logger.info("Vector store built and persisted.")
    return vectorstore

# ─────────────────────────────────────────────────────────
# STAGE 0: NAIVE RAG (BASELINE)
# ─────────────────────────────────────────────────────────

def retrieve_naive(vectorstore: Chroma, query: str, k=FINAL_K) -> list[Document]:
    """
    Stage 0: Naive dense retrieval. No filtering, no re-ranking.
    This is the BASELINE that participants compare against.
    """
    return vectorstore.similarity_search(query, k=k)

# ─────────────────────────────────────────────────────────
# STAGE 1: METADATA FILTERING
# ─────────────────────────────────────────────────────────

def retrieve_with_metadata_filter(
    vectorstore: Chroma,
    query: str,
    k=FINAL_K,
    filter_year_min: Optional[int] = None,
    filter_doc_types: Optional[list[str]] = None,
    filter_department: Optional[str] = None,
) -> list[Document]:
    """
    Stage 1: Metadata-filtered retrieval.
    
    TRAINER NOTE: This stage exposes the TEMPORAL challenge.
    Filtering to year >= 2022 prevents retrieval of the 2019 HF guideline
    that omits SGLT2 inhibitors - a clinically critical distinction.
    
    Supported filters (Chroma where clause):
      year, doc_type, department, evidence_lvl, icd10
    """
    where_clause = {}
    conditions = []
    if filter_year_min:
        conditions.append({"year": {"$gte": filter_year_min}})
    if filter_doc_types:
        conditions.append({"doc_type": {"$in": filter_doc_types}})
    if filter_department:
        conditions.append({"department": {"$eq": filter_department}})
    
    if len(conditions) > 1:
        where_clause = {"$and": conditions}
    elif len(conditions) == 1:
        where_clause = conditions[0]
    
    return vectorstore.similarity_search(
        query, k=k,
        filter=where_clause if where_clause else None
    )

# ─────────────────────────────────────────────────────────
# STAGE 2: MMR (Maximum Marginal Relevance)
# ─────────────────────────────────────────────────────────

def retrieve_with_mmr(
    vectorstore: Chroma,
    query: str,
    k=FINAL_K,
    fetch_k=TOP_K,
    lambda_mult=MMR_LAMBDA
) -> list[Document]:
    """
    Stage 2: MMR retrieval.
    
    MMR selects documents that balance:
      - Relevance to the query (lambda_mult controls weight)
      - Diversity from already-selected documents (1-lambda_mult controls weight)
    
    TRAINER NOTE: This stage exposes the NEAR-DUPLICATE challenge.
    Without MMR, all top-5 results may be variations of the same chunk
    (e.g., 5 DAPA-HF related chunks when a query needs DAPA-HF + EMPEROR-Reduced).
    
    lambda_mult=1.0 → pure similarity (same as naive)
    lambda_mult=0.0 → pure diversity (ignores relevance)
    lambda_mult=0.5 → balanced (good default for clinical diversity)
    """
    return vectorstore.max_marginal_relevance_search(
        query,
        k=k,
        fetch_k=fetch_k,
        lambda_mult=lambda_mult
    )

# ─────────────────────────────────────────────────────────
# STAGE 3: CROSS-ENCODER RE-RANKING
# ─────────────────────────────────────────────────────────

_cross_encoder_model = None

def get_cross_encoder():
    global _cross_encoder_model
    if _cross_encoder_model is None and CROSSENCODER_AVAILABLE:
        logger.info(f"Loading cross-encoder: {CROSS_ENCODER}")
        _cross_encoder_model = CrossEncoder(CROSS_ENCODER)
    return _cross_encoder_model


def retrieve_with_reranking(
    vectorstore: Chroma,
    query: str,
    k=FINAL_K,
    fetch_k=TOP_K,
) -> list[Document]:
    """
    Stage 3: Two-stage retrieval with cross-encoder re-ranking.
    
    Step 1: Dense retrieval of fetch_k candidates (cheap, fast)
    Step 2: Cross-encoder scores each (query, chunk) pair
    Step 3: Return top-k by cross-encoder score
    
    TRAINER NOTE: Cross-encoders are dramatically more accurate than
    bi-encoder (dense) similarity because they see BOTH query and
    document simultaneously. They are too slow for full corpus scoring
    but perfect for re-ranking a small candidate set.
    
    CROSSENCODER_AVAILABLE is False if sentence-transformers not installed.
    """
    candidates = vectorstore.similarity_search(query, k=fetch_k)
    if not CROSSENCODER_AVAILABLE or len(candidates) == 0:
        logger.warning("Cross-encoder not available, returning dense retrieval results.")
        return candidates[:k]
    
    ce = get_cross_encoder()
    pairs = [(query, doc.page_content) for doc in candidates]
    scores = ce.predict(pairs)
    
    ranked = sorted(zip(scores, candidates), key=lambda x: x[0], reverse=True)
    # Attach scores to metadata for evaluation visibility
    results = []
    for score, doc in ranked[:k]:
        doc.metadata["reranker_score"] = float(score)
        results.append(doc)
    return results

# ─────────────────────────────────────────────────────────
# STAGE 4: HYBRID RETRIEVAL (BM25 + Dense with RRF)
# ─────────────────────────────────────────────────────────

def reciprocal_rank_fusion(
    result_lists: list[list[Document]],
    k_rrf=60
) -> list[Document]:
    """
    Reciprocal Rank Fusion (RRF): combines multiple ranked lists.
    
    RRF score = sum(1 / (k_rrf + rank_i)) for each retriever i
    
    TRAINER NOTE: RRF is parameter-free and robust.
    k_rrf=60 is standard. Lower values increase influence of top ranks.
    """
    scores: dict[str, float] = {}
    doc_map: dict[str, Document] = {}
    
    for result_list in result_lists:
        for rank, doc in enumerate(result_list):
            doc_id = doc.metadata.get("chunk_id", doc.page_content[:50])
            if doc_id not in scores:
                scores[doc_id] = 0.0
                doc_map[doc_id] = doc
            scores[doc_id] += 1.0 / (k_rrf + rank + 1)
    
    sorted_ids = sorted(scores, key=lambda x: scores[x], reverse=True)
    results = []
    for doc_id in sorted_ids:
        doc = doc_map[doc_id]
        doc.metadata["rrf_score"] = scores[doc_id]
        results.append(doc)
    return results


def retrieve_hybrid(
    vectorstore: Chroma,
    bm25_retriever: BM25Retriever,
    query: str,
    k=FINAL_K,
    fetch_k=TOP_K,
) -> list[Document]:
    """
    Stage 4: Hybrid BM25 + Dense retrieval with Reciprocal Rank Fusion.
    
    BM25 excels at: exact keyword matches, drug names, ICD codes, dosing values
    Dense excels at: semantic similarity, paraphrases, medical synonyms
    
    TRAINER NOTE: This stage exposes the TERMINOLOGY challenge.
    Query "what is the GFR threshold for metformin" will BM25-match chunks
    containing "CrCl" (creatinine clearance) while dense handles "kidney function".
    """
    dense_results = vectorstore.similarity_search(query, k=fetch_k)
    bm25_results  = bm25_retriever.get_relevant_documents(query)[:fetch_k]
    
    fused = reciprocal_rank_fusion([dense_results, bm25_results])
    return fused[:k]

# ─────────────────────────────────────────────────────────
# STAGE 5: HyDE (Hypothetical Document Embedding)
# ─────────────────────────────────────────────────────────

def retrieve_with_hyde(
    vectorstore: Chroma,
    query: str,
    llm: ChatOpenAI,
    k=FINAL_K,
    fetch_k=TOP_K,
) -> list[Document]:
    """
    Stage 5: Hypothetical Document Embedding (HyDE).
    
    Instead of embedding the query directly, we ask the LLM to generate
    a HYPOTHETICAL answer, then embed that answer for retrieval.
    The hypothesis is usually closer in embedding space to actual documents
    than the short query itself.
    
    TRAINER NOTE: Critical for RARE-DISEASE queries.
    Query: "ATTR cardiac amyloidosis treatment" has low embedding coverage.
    Hypothesis: "Tafamidis 61mg daily was shown in ATTR-ACT to reduce mortality..."
    This hypothesis embedding retrieves the correct chunks.
    
    Failure mode: LLM hallucinations in hypothesis can mislead retrieval.
    Always fall back to dense retrieval as backup.
    """
    hyde_prompt = ChatPromptTemplate.from_template(
        """You are a clinical knowledge expert. Write a detailed 3-4 sentence 
clinical document excerpt that would answer this question:

Question: {question}

Write only the excerpt, no preamble. Use precise medical terminology, 
drug names, dosing, and guideline references as if from a real clinical document."""
    )
    
    try:
        chain = hyde_prompt | llm
        hypothesis = chain.invoke({"question": query}).content
        logger.info(f"HyDE hypothesis: {hypothesis[:150]}...")
        
        # Retrieve using the hypothesis embedding
        hypothesis_results = vectorstore.similarity_search(hypothesis, k=fetch_k)
        # Also retrieve using original query (safety net)
        original_results   = vectorstore.similarity_search(query, k=fetch_k // 2)
        
        # Fuse both
        fused = reciprocal_rank_fusion([hypothesis_results, original_results])
        
        # Mark which results came from HyDE
        for doc in fused[:k]:
            doc.metadata["retrieval_method"] = "HyDE"
        
        return fused[:k]
    
    except Exception as e:
        logger.warning(f"HyDE failed: {e}. Falling back to dense retrieval.")
        return vectorstore.similarity_search(query, k=k)

# ─────────────────────────────────────────────────────────
# RAG GENERATION WITH CITATION GROUNDING
# ─────────────────────────────────────────────────────────

CLINICAL_SYSTEM_PROMPT = """You are ClinicalRAG Pro, an evidence-based clinical decision support assistant.

CRITICAL RULES:
1. Answer ONLY from the provided context. Never fabricate clinical information.
2. Cite your sources using [DocID] notation after every factual claim.
3. If the answer cannot be found in the context, explicitly state: "INSUFFICIENT EVIDENCE IN CONTEXT."
4. Distinguish between different evidence levels (I-A = highest, III = expert opinion).
5. Flag temporal concerns: note if citing a guideline older than 2022.
6. Do NOT provide definitive clinical recommendations - indicate "consult specialist" for complex cases.

Context provided below:
{context}"""

def generate_answer(
    query: str,
    retrieved_docs: list[Document],
    llm: ChatOpenAI,
    stage_name: str = "Unknown"
) -> dict:
    """Generate answer from retrieved docs with citation grounding."""
    
    # Build context with source IDs for citation
    context_parts = []
    for i, doc in enumerate(retrieved_docs):
        doc_id = doc.metadata.get("doc_id", f"DOC{i}")
        year   = doc.metadata.get("year", "")
        evl    = doc.metadata.get("evidence_lvl", "")
        dtype  = doc.metadata.get("doc_type", "")
        header = f"[{doc_id}] ({dtype}, {year}, Evidence:{evl})"
        context_parts.append(f"{header}\n{doc.page_content}")
    
    context = "\n\n---\n\n".join(context_parts)
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", CLINICAL_SYSTEM_PROMPT),
        ("human", "Clinical Question: {question}\n\nProvide an evidence-based answer with citations.")
    ])
    
    chain = prompt | llm
    response = chain.invoke({"context": context, "question": query})
    
    return {
        "query":        query,
        "stage":        stage_name,
        "answer":       response.content,
        "retrieved_ids": [d.metadata.get("doc_id", "") for d in retrieved_docs],
        "num_retrieved": len(retrieved_docs),
        "reranker_scores": [d.metadata.get("reranker_score", None) for d in retrieved_docs],
    }

# ─────────────────────────────────────────────────────────
# EVALUATION ENGINE
# ─────────────────────────────────────────────────────────

def compute_mrr(retrieved_ids: list[str], ground_truth_ids: list[str]) -> float:
    """Mean Reciprocal Rank - position of first relevant doc."""
    for rank, doc_id in enumerate(retrieved_ids, 1):
        # Match on doc_id prefix (chunk_id includes suffix)
        if any(doc_id.startswith(gt) or gt.startswith(doc_id) for gt in ground_truth_ids):
            return 1.0 / rank
    return 0.0


def compute_precision_at_k(retrieved_ids: list[str], ground_truth_ids: list[str], k: int) -> float:
    """Precision@K - fraction of top-k results that are relevant."""
    hits = sum(
        1 for r in retrieved_ids[:k]
        if any(r.startswith(gt) or gt.startswith(r) for gt in ground_truth_ids)
    )
    return hits / k if k > 0 else 0.0


def compute_recall_at_k(retrieved_ids: list[str], ground_truth_ids: list[str], k: int) -> float:
    """Recall@K - fraction of relevant docs found in top-k."""
    if not ground_truth_ids:
        return 0.0
    hits = sum(
        1 for gt in ground_truth_ids
        if any(gt.startswith(r) or r.startswith(gt) for r in retrieved_ids[:k])
    )
    return hits / len(ground_truth_ids)


def simple_faithfulness_score(answer: str, retrieved_docs: list[Document]) -> float:
    """
    Lightweight faithfulness proxy: checks if key terms from retrieved docs
    appear in the answer. Not a substitute for RAGAS but useful without API cost.
    """
    context = " ".join(d.page_content for d in retrieved_docs).lower()
    answer_lower = answer.lower()
    
    # Extract key clinical terms from context
    clinical_tokens = set()
    for word in context.split():
        if len(word) > 5 and word.isalpha():
            clinical_tokens.add(word)
    
    if not clinical_tokens:
        return 0.0
    
    overlap = sum(1 for t in clinical_tokens if t in answer_lower)
    return min(1.0, overlap / max(1, len(clinical_tokens) * 0.1))


def evaluate_stage(
    stage_name: str,
    qa_pairs: list[dict],
    retrieve_fn,           # callable(query) -> list[Document]
    llm: ChatOpenAI,
    max_questions: int = 20,  # Limit for cost control in training
) -> pd.DataFrame:
    """
    Evaluate a retrieval stage on the QA benchmark.
    Returns a DataFrame with per-question metrics.
    """
    records = []
    for qa in tqdm(qa_pairs[:max_questions], desc=f"Evaluating Stage: {stage_name}"):
        start = time.time()
        try:
            docs = retrieve_fn(qa["question"])
            result = generate_answer(qa["question"], docs, llm, stage_name)
        except Exception as e:
            logger.error(f"Error on QA {qa['id']}: {e}")
            records.append({
                "qa_id": qa["id"], "stage": stage_name,
                "challenge_type": qa.get("challenge_type", ""),
                "difficulty": qa.get("difficulty", ""),
                "mrr": 0.0, "p@5": 0.0, "recall@5": 0.0,
                "faithfulness": 0.0, "latency_s": 0.0,
                "error": str(e)
            })
            continue
        
        latency = time.time() - start
        retrieved_ids = [d.metadata.get("doc_id", "") for d in docs]
        gt_ids = qa.get("ground_truth_chunk_ids", [])
        
        records.append({
            "qa_id":          qa["id"],
            "stage":          stage_name,
            "challenge_type": qa.get("challenge_type", ""),
            "difficulty":     qa.get("difficulty", ""),
            "question":       qa["question"][:80],
            "mrr":            compute_mrr(retrieved_ids, gt_ids),
            "p@5":            compute_precision_at_k(retrieved_ids, gt_ids, 5),
            "recall@5":       compute_recall_at_k(retrieved_ids, gt_ids, 5),
            "faithfulness":   simple_faithfulness_score(result["answer"], docs),
            "latency_s":      round(latency, 2),
            "retrieved_ids":  "|".join(retrieved_ids),
            "answer_snippet": result["answer"][:200],
        })
    
    return pd.DataFrame(records)


def print_comparison_table(all_results: pd.DataFrame):
    """Print a comparative metrics table across all stages."""
    summary = all_results.groupby("stage").agg(
        MRR=("mrr", "mean"),
        Precision_at_5=("p@5", "mean"),
        Recall_at_5=("recall@5", "mean"),
        Faithfulness=("faithfulness", "mean"),
        Avg_Latency_s=("latency_s", "mean"),
    ).round(3)
    
    print("\n" + "="*70)
    print("PROGRESSIVE EVALUATION RESULTS — ClinicalRAG Pro")
    print("="*70)
    print(summary.to_string())
    print("\nBreakdown by Challenge Type (MRR):")
    ct_summary = all_results.groupby(["stage", "challenge_type"])["mrr"].mean().unstack().round(3)
    print(ct_summary.to_string())


# ─────────────────────────────────────────────────────────
# MAIN PIPELINE
# ─────────────────────────────────────────────────────────

def main(args):
    # Initialize LLM
    llm = ChatOpenAI(
        model=LLM_MODEL,
        api_key=OPENAI_API_KEY,
        temperature=0,
    )
    
    # Load and chunk documents
    print("\n📂 Loading knowledge base...")
    docs = load_knowledge_base()
    chunks = chunk_documents(docs)
    
    # Build vector store
    print("🔢 Building/loading vector store...")
    vectorstore = build_vectorstore(chunks)
    
    # Build BM25 index for hybrid retrieval
    print("📊 Building BM25 index...")
    bm25 = BM25Retriever.from_documents(chunks)
    bm25.k = TOP_K
    
    # Load QA pairs
    qa_path = DATA_DIR / "eval_qa_pairs.json"
    with open(qa_path) as f:
        qa_pairs = json.load(f)
    print(f"📋 Loaded {len(qa_pairs)} evaluation QA pairs.\n")
    
    # Interactive query mode
    if args.query:
        print(f"\n🔍 Query: {args.query}")
        print(f"   Stage: {args.stage}\n")
        
        stage = int(args.stage) if args.stage != "all" else 5
        
        if stage == 0:
            docs = retrieve_naive(vectorstore, args.query)
        elif stage == 1:
            docs = retrieve_with_metadata_filter(
                vectorstore, args.query, filter_year_min=2022,
                filter_doc_types=["clinical_guideline", "pubmed_abstract"]
            )
        elif stage == 2:
            docs = retrieve_with_mmr(vectorstore, args.query)
        elif stage == 3:
            docs = retrieve_with_reranking(vectorstore, args.query)
        elif stage == 4:
            docs = retrieve_hybrid(vectorstore, bm25, args.query)
        else:
            docs = retrieve_with_hyde(vectorstore, args.query, llm)
        
        result = generate_answer(args.query, docs, llm, f"Stage {stage}")
        print(f"\n📝 ANSWER:\n{result['answer']}")
        print(f"\n📚 Retrieved: {result['retrieved_ids']}")
        return
    
    # Full evaluation
    if args.stage == "all":
        stages_to_run = [0, 1, 2, 3, 4, 5]
    else:
        stages_to_run = [int(args.stage)]
    
    stage_configs = {
        0: ("Naive RAG",             lambda q: retrieve_naive(vectorstore, q)),
        1: ("Metadata Filtered",     lambda q: retrieve_with_metadata_filter(
                                        vectorstore, q, filter_year_min=2022)),
        2: ("MMR",                   lambda q: retrieve_with_mmr(vectorstore, q)),
        3: ("Cross-Encoder Rerank",  lambda q: retrieve_with_reranking(vectorstore, q)),
        4: ("Hybrid BM25+Dense",     lambda q: retrieve_hybrid(vectorstore, bm25, q)),
        5: ("HyDE",                  lambda q: retrieve_with_hyde(vectorstore, q, llm)),
    }
    
    all_results = []
    for stage_id in stages_to_run:
        if stage_id not in stage_configs:
            continue
        name, fn = stage_configs[stage_id]
        print(f"\n▶ Running Stage {stage_id}: {name}")
        df = evaluate_stage(name, qa_pairs, fn, llm, max_questions=args.max_questions)
        all_results.append(df)
    
    if all_results:
        combined = pd.concat(all_results, ignore_index=True)
        out_path = RESULTS_DIR / "evaluation_results.csv"
        combined.to_csv(out_path, index=False)
        print(f"\n✅ Results saved to: {out_path}")
        print_comparison_table(combined)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ClinicalRAG Pro Pipeline")
    parser.add_argument("--stage", default="all", help="Stage to run: 0-5 or 'all'")
    parser.add_argument("--query", default="", help="Single query to test")
    parser.add_argument("--max-questions", type=int, default=20,
                        help="Max QA pairs to evaluate (cost control)")
    args = parser.parse_args()
    main(args)
