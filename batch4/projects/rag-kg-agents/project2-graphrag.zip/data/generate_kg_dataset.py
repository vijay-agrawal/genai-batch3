"""
MedKG Navigator — Synthetic Dataset Generator
===============================================
Generates a realistic clinical trial knowledge graph dataset with
DELIBERATELY INJECTED patterns that expose the limitations of pure
vector RAG and validate the value of hybrid Graph+Embedding retrieval.

Knowledge Graph Entities:
  Disease → Symptom, Biomarker, Drug, Trial, Site

INJECTED CHALLENGES (mapped to retrieval strategies):
  [MULTI-HOP]       Multi-hop relation queries fail with pure vector search
  [NEGATION]        "Patient must NOT have EGFR mutation" — vectors ignore negation
  [SYNONYM]         "NSCLC" vs "Non-Small Cell Lung Cancer" — graph resolves aliases
  [GEOGRAPHIC]      Site filtering impossible with embeddings alone
  [BIOMARKER-COMBO] AND/OR logic on biomarkers — graph traversal required
  [TEMPORAL]        Phase transitions change eligibility — graph tracks current phase
  [DRUG-CONFLICT]   Prior drug exclusions cross-referenced from trial protocol
"""

import json
import random
from pathlib import Path

random.seed(42)

OUT = Path(__file__).parent

# ─────────────────────────────────────────────────────────────────────────────
# DISEASES (25 nodes)
# ─────────────────────────────────────────────────────────────────────────────

DISEASES = [
    # Oncology
    {"id": "D001", "name": "Non-Small Cell Lung Cancer", "aliases": ["NSCLC", "non-small-cell lung carcinoma"],
     "icd10": "C34.10", "category": "oncology", "prevalence": "high",
     "challenge_tags": ["SYNONYM"]},
    {"id": "D002", "name": "Small Cell Lung Cancer", "aliases": ["SCLC", "oat cell carcinoma"],
     "icd10": "C34.10", "category": "oncology", "prevalence": "medium",
     "challenge_tags": ["SYNONYM"]},
    {"id": "D003", "name": "HER2-Positive Breast Cancer", "aliases": ["HER2+ BC", "HER2-amplified breast cancer"],
     "icd10": "C50.919", "category": "oncology", "prevalence": "high",
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "D004", "name": "Triple Negative Breast Cancer", "aliases": ["TNBC"],
     "icd10": "C50.919", "category": "oncology", "prevalence": "medium",
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "D005", "name": "Metastatic Colorectal Cancer", "aliases": ["mCRC", "advanced colorectal cancer"],
     "icd10": "C18.9", "category": "oncology", "prevalence": "high",
     "challenge_tags": ["MULTI-HOP"]},
    {"id": "D006", "name": "Chronic Myeloid Leukemia", "aliases": ["CML", "BCR-ABL leukemia"],
     "icd10": "C91.10", "category": "oncology", "prevalence": "low",
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "D007", "name": "Diffuse Large B-Cell Lymphoma", "aliases": ["DLBCL"],
     "icd10": "C83.30", "category": "oncology", "prevalence": "medium",
     "challenge_tags": ["MULTI-HOP"]},
    {"id": "D008", "name": "Pancreatic Ductal Adenocarcinoma", "aliases": ["PDAC", "pancreatic cancer"],
     "icd10": "C25.0", "category": "oncology", "prevalence": "medium",
     "challenge_tags": []},
    {"id": "D009", "name": "Hepatocellular Carcinoma", "aliases": ["HCC", "liver cancer", "hepatoma"],
     "icd10": "C22.0", "category": "oncology", "prevalence": "medium",
     "challenge_tags": ["SYNONYM"]},
    # Rare/Complex
    {"id": "D010", "name": "ATTR Cardiac Amyloidosis", "aliases": ["ATTR-CM", "transthyretin amyloidosis"],
     "icd10": "E85.4", "category": "rare_disease", "prevalence": "low",
     "challenge_tags": ["MULTI-HOP"]},
    # Metabolic/Cardiology
    {"id": "D011", "name": "Type 2 Diabetes with CKD", "aliases": ["T2DM-CKD", "diabetic nephropathy"],
     "icd10": "E11.65", "category": "metabolic", "prevalence": "high",
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "D012", "name": "Heart Failure with Reduced EF", "aliases": ["HFrEF"],
     "icd10": "I50.20", "category": "cardiology", "prevalence": "high",
     "challenge_tags": []},
    {"id": "D013", "name": "Pulmonary Arterial Hypertension", "aliases": ["PAH"],
     "icd10": "I27.0", "category": "cardiology", "prevalence": "low",
     "challenge_tags": ["MULTI-HOP"]},
    {"id": "D014", "name": "Relapsing-Remitting Multiple Sclerosis", "aliases": ["RRMS", "relapsing MS"],
     "icd10": "G35", "category": "neurology", "prevalence": "medium",
     "challenge_tags": []},
    {"id": "D015", "name": "Rheumatoid Arthritis Refractory", "aliases": ["RA refractory", "biologic-naive RA"],
     "icd10": "M05.79", "category": "rheumatology", "prevalence": "high",
     "challenge_tags": ["DRUG-CONFLICT"]},
    # Infectious / Rare
    {"id": "D016", "name": "HIV with CD4 <200", "aliases": ["AIDS", "advanced HIV disease"],
     "icd10": "B20", "category": "infectious", "prevalence": "medium",
     "challenge_tags": ["DRUG-CONFLICT"]},
    {"id": "D017", "name": "Alpha-1 Antitrypsin Deficiency", "aliases": ["AATD", "A1AT deficiency"],
     "icd10": "E88.01", "category": "rare_disease", "prevalence": "low",
     "challenge_tags": ["MULTI-HOP"]},
    {"id": "D018", "name": "Idiopathic Pulmonary Fibrosis", "aliases": ["IPF"],
     "icd10": "J84.112", "category": "pulmonary", "prevalence": "low",
     "challenge_tags": []},
    {"id": "D019", "name": "Sickle Cell Disease Vaso-Occlusive", "aliases": ["SCD VOC", "HbSS"],
     "icd10": "D57.1", "category": "hematology", "prevalence": "medium",
     "challenge_tags": ["NEGATION"]},
    {"id": "D020", "name": "Psoriatic Arthritis with Enthesitis", "aliases": ["PsA"],
     "icd10": "L40.54", "category": "rheumatology", "prevalence": "medium",
     "challenge_tags": ["BIOMARKER-COMBO"]},
]

# ─────────────────────────────────────────────────────────────────────────────
# BIOMARKERS (30 nodes)
# ─────────────────────────────────────────────────────────────────────────────

BIOMARKERS = [
    # Oncology biomarkers — KEY for NEGATION and BIOMARKER-COMBO challenges
    {"id": "BM001", "name": "EGFR Exon 19 Deletion", "aliases": ["EGFR del19", "EGFR sensitizing mutation"],
     "type": "genetic", "assay": "NGS", "disease_ids": ["D001"],
     "challenge_tags": ["NEGATION"],
     "note": "CRITICAL: Many trials EXCLUDE patients WITH this mutation (target for different drug class)"},
    {"id": "BM002", "name": "EGFR Exon 21 L858R Mutation", "aliases": ["EGFR L858R"],
     "type": "genetic", "assay": "NGS", "disease_ids": ["D001"],
     "challenge_tags": ["NEGATION"]},
    {"id": "BM003", "name": "EGFR Wild-Type", "aliases": ["EGFR WT", "EGFR negative"],
     "type": "genetic", "assay": "NGS", "disease_ids": ["D001"],
     "challenge_tags": ["NEGATION"],
     "note": "Required for immunotherapy trials — inverse of BM001/BM002"},
    {"id": "BM004", "name": "ALK Rearrangement", "aliases": ["ALK fusion", "ALK positive"],
     "type": "genetic", "assay": "FISH or IHC", "disease_ids": ["D001"],
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "BM005", "name": "PD-L1 TPS ≥50%", "aliases": ["PD-L1 high", "PD-L1 ≥50"],
     "type": "expression", "assay": "IHC 22C3", "disease_ids": ["D001", "D003", "D005"],
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "BM006", "name": "KRAS G12C Mutation", "aliases": ["KRAS G12C", "KRAS mutant"],
     "type": "genetic", "assay": "NGS", "disease_ids": ["D001", "D005"],
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "BM007", "name": "HER2 Amplification (IHC 3+)", "aliases": ["HER2+", "HER2 overexpression"],
     "type": "protein", "assay": "IHC/FISH", "disease_ids": ["D003"],
     "challenge_tags": ["NEGATION"]},
    {"id": "BM008", "name": "HER2 Negative (IHC 0-1+)", "aliases": ["HER2-", "HER2 negative"],
     "type": "protein", "assay": "IHC", "disease_ids": ["D004"],
     "challenge_tags": ["NEGATION"]},
    {"id": "BM009", "name": "ER/PR Negative", "aliases": ["hormone receptor negative", "HR-"],
     "type": "protein", "assay": "IHC", "disease_ids": ["D004"],
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "BM010", "name": "BCR-ABL1 Fusion", "aliases": ["BCR-ABL", "Philadelphia chromosome"],
     "type": "genetic", "assay": "PCR/FISH", "disease_ids": ["D006"],
     "challenge_tags": []},
    {"id": "BM011", "name": "BRCA1/2 Germline Mutation", "aliases": ["BRCA1", "BRCA2", "BRCA mutant"],
     "type": "genetic", "assay": "Germline sequencing", "disease_ids": ["D003", "D004", "D008"],
     "challenge_tags": ["MULTI-HOP"]},
    {"id": "BM012", "name": "MSI-High / dMMR", "aliases": ["microsatellite instability high", "mismatch repair deficient"],
     "type": "molecular", "assay": "PCR or IHC", "disease_ids": ["D005", "D008"],
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "BM013", "name": "BRAF V600E Mutation", "aliases": ["BRAF V600", "BRAF mutant"],
     "type": "genetic", "assay": "NGS", "disease_ids": ["D005"],
     "challenge_tags": []},
    # Metabolic biomarkers
    {"id": "BM014", "name": "eGFR 25-45 mL/min/1.73m2", "aliases": ["CKD stage 3b", "moderate CKD"],
     "type": "lab", "assay": "CKD-EPI serum creatinine", "disease_ids": ["D011"],
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "BM015", "name": "HbA1c ≥8.0%", "aliases": ["poorly controlled diabetes", "A1c ≥8"],
     "type": "lab", "assay": "HPLC", "disease_ids": ["D011"],
     "challenge_tags": []},
    {"id": "BM016", "name": "NT-proBNP >1000 pg/mL", "aliases": ["elevated BNP", "high NTproBNP"],
     "type": "lab", "assay": "Immunoassay", "disease_ids": ["D012"],
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "BM017", "name": "LVEF ≤40%", "aliases": ["reduced EF", "EF ≤40%"],
     "type": "imaging", "assay": "Echocardiography", "disease_ids": ["D012"],
     "challenge_tags": []},
    {"id": "BM018", "name": "Technetium PYP Scan Grade 2-3", "aliases": ["PYP positive", "bone tracer uptake"],
     "type": "imaging", "assay": "Nuclear medicine scan", "disease_ids": ["D010"],
     "challenge_tags": ["MULTI-HOP"]},
    # Infectious
    {"id": "BM019", "name": "CD4 Count <200 cells/μL", "aliases": ["CD4 <200", "low CD4"],
     "type": "lab", "assay": "Flow cytometry", "disease_ids": ["D016"],
     "challenge_tags": ["DRUG-CONFLICT"]},
    {"id": "BM020", "name": "HIV RNA >50 copies/mL", "aliases": ["detectable viral load", "viremia"],
     "type": "lab", "assay": "PCR", "disease_ids": ["D016"],
     "challenge_tags": []},
    {"id": "BM021", "name": "FEV1 <50% Predicted", "aliases": ["severe airflow obstruction"],
     "type": "lab", "assay": "Spirometry", "disease_ids": ["D017", "D018"],
     "challenge_tags": []},
    {"id": "BM022", "name": "TTR Variant Confirmed", "aliases": ["TTR mutation", "ATTR hereditary"],
     "type": "genetic", "assay": "Sequencing", "disease_ids": ["D010"],
     "challenge_tags": []},
    {"id": "BM023", "name": "CRP >10 mg/L", "aliases": ["elevated CRP", "systemic inflammation"],
     "type": "lab", "assay": "hs-CRP immunoassay", "disease_ids": ["D015", "D020"],
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "BM024", "name": "DAS28 Score ≥3.2", "aliases": ["moderate-severe RA activity", "active RA"],
     "type": "clinical", "assay": "DAS28-ESR or CRP", "disease_ids": ["D015"],
     "challenge_tags": []},
    {"id": "BM025", "name": "HbF <30%", "aliases": ["low fetal hemoglobin"],
     "type": "lab", "assay": "HPLC", "disease_ids": ["D019"],
     "challenge_tags": []},
    {"id": "BM026", "name": "ROS1 Rearrangement", "aliases": ["ROS1 fusion", "ROS1 positive"],
     "type": "genetic", "assay": "FISH/NGS", "disease_ids": ["D001"],
     "challenge_tags": []},
    {"id": "BM027", "name": "MET Exon 14 Skipping", "aliases": ["METex14", "MET mutation"],
     "type": "genetic", "assay": "RNA sequencing", "disease_ids": ["D001"],
     "challenge_tags": ["MULTI-HOP"]},
    {"id": "BM028", "name": "TMB ≥10 mut/Mb", "aliases": ["high tumor mutational burden", "TMB-high"],
     "type": "molecular", "assay": "Whole exome sequencing", "disease_ids": ["D001", "D003"],
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "BM029", "name": "UACR >300 mg/g", "aliases": ["macroalbuminuria", "nephrotic proteinuria"],
     "type": "lab", "assay": "Urine albumin-creatinine ratio", "disease_ids": ["D011"],
     "challenge_tags": []},
    {"id": "BM030", "name": "NTRK Fusion", "aliases": ["TRK fusion", "NTRK1/2/3 rearrangement"],
     "type": "genetic", "assay": "RNA NGS", "disease_ids": ["D001", "D005"],
     "challenge_tags": ["MULTI-HOP"]},
]

# ─────────────────────────────────────────────────────────────────────────────
# DRUGS (25 nodes)
# ─────────────────────────────────────────────────────────────────────────────

DRUGS = [
    {"id": "DR001", "name": "Osimertinib", "brand": "Tagrisso", "class": "EGFR TKI 3rd gen",
     "targets": ["EGFR del19", "EGFR L858R", "EGFR T790M"],
     "approved_indications": ["D001"], "approval_year": 2015,
     "challenge_tags": ["NEGATION"],
     "note": "Patients ON osimertinib are excluded from wild-type EGFR immunotherapy trials"},
    {"id": "DR002", "name": "Pembrolizumab", "brand": "Keytruda", "class": "PD-1 inhibitor",
     "targets": ["PD-1"], "approved_indications": ["D001", "D003", "D005"],
     "approval_year": 2014, "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "DR003", "name": "Sotorasib", "brand": "Lumakras", "class": "KRAS G12C inhibitor",
     "targets": ["KRAS G12C"], "approved_indications": ["D001", "D005"],
     "approval_year": 2021, "challenge_tags": []},
    {"id": "DR004", "name": "Trastuzumab", "brand": "Herceptin", "class": "HER2 monoclonal",
     "targets": ["HER2"], "approved_indications": ["D003"],
     "approval_year": 1998, "challenge_tags": ["DRUG-CONFLICT"]},
    {"id": "DR005", "name": "Sacituzumab Govitecan", "brand": "Trodelvy", "class": "ADC",
     "targets": ["TROP-2"], "approved_indications": ["D004"],
     "approval_year": 2021, "challenge_tags": []},
    {"id": "DR006", "name": "Imatinib", "brand": "Gleevec", "class": "BCR-ABL TKI",
     "targets": ["BCR-ABL", "KIT", "PDGFR"], "approved_indications": ["D006"],
     "approval_year": 2001, "challenge_tags": ["DRUG-CONFLICT"]},
    {"id": "DR007", "name": "Olaparib", "brand": "Lynparza", "class": "PARP inhibitor",
     "targets": ["PARP"], "approved_indications": ["D003", "D004", "D008"],
     "approval_year": 2014, "challenge_tags": ["MULTI-HOP"]},
    {"id": "DR008", "name": "Dapagliflozin", "brand": "Farxiga", "class": "SGLT2 inhibitor",
     "targets": ["SGLT2"], "approved_indications": ["D011", "D012"],
     "approval_year": 2012, "challenge_tags": []},
    {"id": "DR009", "name": "Finerenone", "brand": "Kerendia", "class": "Non-steroidal MRA",
     "targets": ["Mineralocorticoid receptor"], "approved_indications": ["D011"],
     "approval_year": 2021, "challenge_tags": []},
    {"id": "DR010", "name": "Tafamidis", "brand": "Vyndamax", "class": "TTR stabilizer",
     "targets": ["TTR tetramer"], "approved_indications": ["D010"],
     "approval_year": 2019, "challenge_tags": ["MULTI-HOP"]},
    {"id": "DR011", "name": "Ocrelizumab", "brand": "Ocrevus", "class": "Anti-CD20",
     "targets": ["CD20"], "approved_indications": ["D014"],
     "approval_year": 2017, "challenge_tags": []},
    {"id": "DR012", "name": "Adalimumab", "brand": "Humira", "class": "TNF-alpha inhibitor",
     "targets": ["TNF-alpha"], "approved_indications": ["D015", "D020"],
     "approval_year": 2002, "challenge_tags": ["DRUG-CONFLICT"]},
    {"id": "DR013", "name": "Crizanlizumab", "brand": "Adakveo", "class": "P-selectin inhibitor",
     "targets": ["P-selectin"], "approved_indications": ["D019"],
     "approval_year": 2019, "challenge_tags": []},
    {"id": "DR014", "name": "Entrectinib", "brand": "Rozlytrek", "class": "TRK/ROS1/ALK inhibitor",
     "targets": ["NTRK", "ROS1", "ALK"], "approved_indications": ["D001", "D005"],
     "approval_year": 2019, "challenge_tags": ["MULTI-HOP"]},
    {"id": "DR015", "name": "Capmatinib", "brand": "Tabrecta", "class": "MET inhibitor",
     "targets": ["MET"], "approved_indications": ["D001"],
     "approval_year": 2020, "challenge_tags": []},
    {"id": "DR016", "name": "Tucatinib", "brand": "Tukysa", "class": "HER2 TKI",
     "targets": ["HER2"], "approved_indications": ["D003"],
     "approval_year": 2020, "challenge_tags": []},
    {"id": "DR017", "name": "Nivolumab", "brand": "Opdivo", "class": "PD-1 inhibitor",
     "targets": ["PD-1"], "approved_indications": ["D001", "D005", "D007"],
     "approval_year": 2014, "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "DR018", "name": "Inavolisib", "brand": "Itovebi", "class": "PI3K inhibitor",
     "targets": ["PI3Ka"], "approved_indications": ["D003"],
     "approval_year": 2024, "challenge_tags": []},
    {"id": "DR019", "name": "Tarlatamab", "brand": "Imdelltra", "class": "BiTE antibody",
     "targets": ["DLL3", "CD3"], "approved_indications": ["D002"],
     "approval_year": 2024, "challenge_tags": ["TEMPORAL"]},
    {"id": "DR020", "name": "Amivantamab", "brand": "Rybrevant", "class": "EGFR-MET bispecific",
     "targets": ["EGFR exon 20", "MET"], "approved_indications": ["D001"],
     "approval_year": 2021, "challenge_tags": ["MULTI-HOP"]},
    {"id": "DR021", "name": "Semaglutide", "brand": "Ozempic/Wegovy", "class": "GLP-1 RA",
     "targets": ["GLP-1R"], "approved_indications": ["D011"],
     "approval_year": 2017, "challenge_tags": []},
    {"id": "DR022", "name": "Ofatumumab", "brand": "Kesimpta", "class": "Anti-CD20",
     "targets": ["CD20"], "approved_indications": ["D014"],
     "approval_year": 2020, "challenge_tags": []},
    {"id": "DR023", "name": "Guselkumab", "brand": "Tremfya", "class": "IL-23 inhibitor",
     "targets": ["IL-23p19"], "approved_indications": ["D020"],
     "approval_year": 2017, "challenge_tags": []},
    {"id": "DR024", "name": "Upadacitinib", "brand": "Rinvoq", "class": "JAK1 inhibitor",
     "targets": ["JAK1"], "approved_indications": ["D015", "D020"],
     "approval_year": 2019, "challenge_tags": ["DRUG-CONFLICT"]},
    {"id": "DR025", "name": "Voxelotor", "brand": "Oxbryta", "class": "Hemoglobin modifier",
     "targets": ["HbS polymerization"], "approved_indications": ["D019"],
     "approval_year": 2019, "challenge_tags": []},
]

# ─────────────────────────────────────────────────────────────────────────────
# TRIAL SITES (20 nodes across India + Global)
# ─────────────────────────────────────────────────────────────────────────────

SITES = [
    # Maharashtra (key for geographic challenge)
    {"id": "S001", "name": "Tata Memorial Hospital", "city": "Mumbai", "state": "Maharashtra",
     "country": "India", "tier": "tier1", "specialties": ["oncology"],
     "lat": 19.0050, "lon": 72.8342, "challenge_tags": ["GEOGRAPHIC"]},
    {"id": "S002", "name": "KEM Hospital", "city": "Mumbai", "state": "Maharashtra",
     "country": "India", "tier": "tier1", "specialties": ["cardiology", "nephrology", "oncology"],
     "lat": 18.9912, "lon": 72.8370, "challenge_tags": ["GEOGRAPHIC"]},
    {"id": "S003", "name": "Jehangir Hospital", "city": "Pune", "state": "Maharashtra",
     "country": "India", "tier": "tier2", "specialties": ["rheumatology", "cardiology"],
     "lat": 18.5246, "lon": 73.8656, "challenge_tags": ["GEOGRAPHIC"]},
    {"id": "S004", "name": "Ruby Hall Clinic", "city": "Pune", "state": "Maharashtra",
     "country": "India", "tier": "tier2", "specialties": ["oncology", "neurology"],
     "lat": 18.5314, "lon": 73.8937, "challenge_tags": ["GEOGRAPHIC"]},
    {"id": "S005", "name": "Government Medical College Aurangabad", "city": "Aurangabad",
     "state": "Maharashtra", "country": "India", "tier": "tier3",
     "specialties": ["oncology", "hematology"], "lat": 19.8762, "lon": 75.3433,
     "challenge_tags": ["GEOGRAPHIC"]},
    # Other India
    {"id": "S006", "name": "AIIMS Delhi", "city": "New Delhi", "state": "Delhi",
     "country": "India", "tier": "tier1", "specialties": ["oncology", "neurology", "cardiology", "hematology"],
     "lat": 28.5672, "lon": 77.2100, "challenge_tags": []},
    {"id": "S007", "name": "PGIMER Chandigarh", "city": "Chandigarh", "state": "Punjab",
     "country": "India", "tier": "tier1", "specialties": ["hematology", "oncology"],
     "lat": 30.7651, "lon": 76.7792, "challenge_tags": []},
    {"id": "S008", "name": "Christian Medical College Vellore", "city": "Vellore",
     "state": "Tamil Nadu", "country": "India", "tier": "tier1",
     "specialties": ["hematology", "oncology", "nephrology"],
     "lat": 12.9342, "lon": 79.1560, "challenge_tags": []},
    {"id": "S009", "name": "Apollo Hospitals Hyderabad", "city": "Hyderabad",
     "state": "Telangana", "country": "India", "tier": "tier2",
     "specialties": ["cardiology", "oncology", "rheumatology"],
     "lat": 17.4065, "lon": 78.4772, "challenge_tags": []},
    {"id": "S010", "name": "Rajiv Gandhi Cancer Institute Delhi", "city": "New Delhi",
     "state": "Delhi", "country": "India", "tier": "tier2",
     "specialties": ["oncology"], "lat": 28.7122, "lon": 77.1545, "challenge_tags": []},
    # International
    {"id": "S011", "name": "MD Anderson Cancer Center", "city": "Houston", "state": "Texas",
     "country": "USA", "tier": "tier1", "specialties": ["oncology"],
     "lat": 29.7080, "lon": -95.3975, "challenge_tags": []},
    {"id": "S012", "name": "Memorial Sloan Kettering", "city": "New York", "state": "New York",
     "country": "USA", "tier": "tier1", "specialties": ["oncology", "hematology"],
     "lat": 40.7641, "lon": -73.9567, "challenge_tags": []},
    {"id": "S013", "name": "Royal Marsden Hospital", "city": "London", "state": "England",
     "country": "UK", "tier": "tier1", "specialties": ["oncology"],
     "lat": 51.4956, "lon": -0.1721, "challenge_tags": []},
    {"id": "S014", "name": "Institut Gustave Roussy", "city": "Villejuif", "state": "Île-de-France",
     "country": "France", "tier": "tier1", "specialties": ["oncology"],
     "lat": 48.7998, "lon": 2.3473, "challenge_tags": []},
    {"id": "S015", "name": "Singapore General Hospital", "city": "Singapore", "state": "Singapore",
     "country": "Singapore", "tier": "tier1", "specialties": ["oncology", "hematology"],
     "lat": 1.2792, "lon": 103.8356, "challenge_tags": []},
    {"id": "S016", "name": "Fortis Hospital Bangalore", "city": "Bangalore",
     "state": "Karnataka", "country": "India", "tier": "tier2",
     "specialties": ["cardiology", "rheumatology"], "lat": 12.9716, "lon": 77.5946, "challenge_tags": []},
    {"id": "S017", "name": "Medanta Medicity Gurugram", "city": "Gurugram",
     "state": "Haryana", "country": "India", "tier": "tier2",
     "specialties": ["cardiology", "oncology", "nephrology"],
     "lat": 28.4489, "lon": 77.0721, "challenge_tags": []},
    {"id": "S018", "name": "Wockhardt Hospital Mumbai", "city": "Mumbai",
     "state": "Maharashtra", "country": "India", "tier": "tier2",
     "specialties": ["cardiology", "neurology"], "lat": 19.1136, "lon": 72.8697,
     "challenge_tags": ["GEOGRAPHIC"]},
    {"id": "S019", "name": "Deenanath Mangeshkar Hospital Pune", "city": "Pune",
     "state": "Maharashtra", "country": "India", "tier": "tier2",
     "specialties": ["oncology", "hematology"],
     "lat": 18.5196, "lon": 73.8400, "challenge_tags": ["GEOGRAPHIC"]},
    {"id": "S020", "name": "Asian Cancer Institute Mumbai", "city": "Mumbai",
     "state": "Maharashtra", "country": "India", "tier": "tier2",
     "specialties": ["oncology"], "lat": 19.0278, "lon": 72.8316,
     "challenge_tags": ["GEOGRAPHIC"]},
]

# ─────────────────────────────────────────────────────────────────────────────
# CLINICAL TRIALS (30 nodes) — KEY dataset with rich eligibility criteria
# ─────────────────────────────────────────────────────────────────────────────

TRIALS = [
    # ── NSCLC Trials (multiple — key for NEGATION + BIOMARKER-COMBO challenges)
    {
        "id": "T001",
        "nct_id": "NCT-SYN-0001",
        "title": "MOMENTUM-1: Pembrolizumab + Chemotherapy for EGFR Wild-Type NSCLC",
        "phase": "Phase 3",
        "status": "Recruiting",
        "disease_ids": ["D001"],
        "sponsor": "SynthBio Inc.",
        "start_date": "2023-06-01",
        "primary_endpoint": "Overall Survival",
        "target_enrollment": 450,
        "site_ids": ["S001", "S006", "S011", "S012"],
        "required_biomarkers": ["BM003"],  # EGFR Wild-Type REQUIRED
        "excluded_biomarkers": ["BM001", "BM002", "BM004", "BM026"],  # EGFR mutations, ALK, ROS1 excluded
        "required_drugs_prior": [],
        "excluded_drugs_prior": ["DR001"],  # No prior osimertinib
        "prior_treatment_lines_max": 0,  # Treatment-naive
        "inclusion_criteria_text": (
            "Adults ≥18 years with histologically confirmed NSCLC (squamous or non-squamous). "
            "ECOG PS 0-1. EGFR wild-type confirmed by NGS. "
            "No known EGFR sensitizing mutations (exon 19 del, exon 21 L858R), ALK rearrangement, "
            "ROS1 rearrangement. No prior systemic chemotherapy for metastatic disease. "
            "Measurable disease per RECIST 1.1. Adequate organ function."
        ),
        "exclusion_criteria_text": (
            "Prior treatment with anti-PD-1 or anti-PD-L1 antibodies. "
            "Active autoimmune disease requiring systemic treatment. "
            "Prior EGFR-targeted therapy. "
            "Known brain metastases unless stable and not requiring steroids for >2 weeks. "
            "Active hepatitis B or C infection."
        ),
        "challenge_tags": ["NEGATION", "BIOMARKER-COMBO"],
        "why_hard": "Patient WITH EGFR mutation must be EXCLUDED — vectors cannot distinguish presence/absence of a biomarker"
    },
    {
        "id": "T002",
        "nct_id": "NCT-SYN-0002",
        "title": "LASER-2: Osimertinib + Bevacizumab for EGFR-Mutant NSCLC",
        "phase": "Phase 2",
        "status": "Recruiting",
        "disease_ids": ["D001"],
        "sponsor": "AstraZeneca Synthetic",
        "start_date": "2023-09-15",
        "primary_endpoint": "PFS",
        "target_enrollment": 120,
        "site_ids": ["S001", "S004", "S006", "S013"],
        "required_biomarkers": ["BM001"],  # EGFR del19 REQUIRED
        "excluded_biomarkers": ["BM003", "BM004"],  # EGFR WT, ALK excluded
        "required_drugs_prior": [],
        "excluded_drugs_prior": [],
        "prior_treatment_lines_max": 1,
        "inclusion_criteria_text": (
            "Locally advanced or metastatic NSCLC. EGFR exon 19 deletion confirmed. "
            "No prior systemic therapy for metastatic setting or 1 prior platinum doublet. "
            "ECOG PS 0-2. Adequate hepatic and renal function (creatinine <1.5x ULN). "
            "No significant cardiac history."
        ),
        "exclusion_criteria_text": (
            "EGFR wild-type or ALK-positive tumors. "
            "Prior treatment with 3rd generation EGFR TKI. "
            "Uncontrolled hypertension >150/90. "
            "Bleeding diathesis or anticoagulation therapy. "
            "Pregnancy or lactation."
        ),
        "challenge_tags": ["NEGATION"],
        "why_hard": "Requires EGFR del19 PRESENT — opposite requirement from T001 for same disease"
    },
    {
        "id": "T003",
        "nct_id": "NCT-SYN-0003",
        "title": "CATALYST: Sotorasib + Panitumumab for KRAS G12C NSCLC",
        "phase": "Phase 2",
        "status": "Recruiting",
        "disease_ids": ["D001"],
        "sponsor": "Amgen Synthetic",
        "start_date": "2024-01-10",
        "primary_endpoint": "ORR",
        "target_enrollment": 80,
        "site_ids": ["S001", "S020", "S011"],
        "required_biomarkers": ["BM006"],
        "excluded_biomarkers": ["BM001", "BM002"],
        "required_drugs_prior": [],
        "excluded_drugs_prior": [],
        "prior_treatment_lines_max": 2,
        "inclusion_criteria_text": (
            "Metastatic NSCLC with KRAS G12C mutation confirmed by validated NGS assay. "
            "1-2 prior lines of systemic therapy including platinum doublet. "
            "ECOG PS 0-1. KRAS G12C wild-type patients ineligible."
        ),
        "exclusion_criteria_text": (
            "Prior KRAS-targeted therapy. Co-occurring EGFR sensitizing mutations. "
            "Active CNS metastases. GI malabsorption condition."
        ),
        "challenge_tags": ["BIOMARKER-COMBO", "MULTI-HOP"],
        "why_hard": "KRAS G12C required AND co-occurring EGFR excluded — dual biomarker logic"
    },
    {
        "id": "T004",
        "nct_id": "NCT-SYN-0004",
        "title": "METropolis-3: Capmatinib Monotherapy for METex14 NSCLC",
        "phase": "Phase 3",
        "status": "Recruiting",
        "disease_ids": ["D001"],
        "sponsor": "Novartis Synthetic",
        "start_date": "2023-11-01",
        "primary_endpoint": "PFS",
        "target_enrollment": 300,
        "site_ids": ["S001", "S002", "S006", "S012", "S015"],
        "required_biomarkers": ["BM027"],  # METex14 required
        "excluded_biomarkers": ["BM001", "BM002", "BM004"],
        "required_drugs_prior": [],
        "excluded_drugs_prior": [],
        "prior_treatment_lines_max": 0,
        "inclusion_criteria_text": (
            "Treatment-naive advanced NSCLC with MET exon 14 skipping mutation confirmed by RNA sequencing. "
            "ECOG PS 0-2. No concurrent EGFR or ALK alterations. "
            "Adequate organ function. No active CNS disease."
        ),
        "exclusion_criteria_text": (
            "Prior MET-targeted therapy. Concurrent EGFR or ALK mutations. "
            "Spinal cord compression requiring urgent intervention."
        ),
        "challenge_tags": ["MULTI-HOP"],
        "why_hard": "Requires RNA-based METex14 assay — multi-hop: disease → biomarker_type → assay requirement"
    },
    {
        "id": "T005",
        "nct_id": "NCT-SYN-0005",
        "title": "ALCYONE-2: Alectinib for ALK-Positive NSCLC Brain Mets",
        "phase": "Phase 2",
        "status": "Active_not_recruiting",
        "disease_ids": ["D001"],
        "sponsor": "Roche Synthetic",
        "start_date": "2022-04-01",
        "primary_endpoint": "Intracranial ORR",
        "target_enrollment": 100,
        "site_ids": ["S006", "S012", "S013"],
        "required_biomarkers": ["BM004"],  # ALK required
        "excluded_biomarkers": ["BM001", "BM002"],
        "required_drugs_prior": [],
        "excluded_drugs_prior": [],
        "prior_treatment_lines_max": 1,
        "inclusion_criteria_text": (
            "ALK-positive NSCLC with active or previously treated brain metastases. "
            "Confirmed ALK rearrangement by FISH or IHC. ECOG 0-2. "
            "Prior crizotinib allowed; prior alectinib not allowed."
        ),
        "exclusion_criteria_text": (
            "Prior alectinib or lorlatinib treatment. "
            "EGFR-mutant tumors. Active leptomeningeal disease."
        ),
        "challenge_tags": ["TEMPORAL"],
        "why_hard": "Status Active_not_recruiting — patient arrives too late; graph tracks current enrollment phase"
    },
    # ── Breast Cancer Trials
    {
        "id": "T006",
        "nct_id": "NCT-SYN-0006",
        "title": "AURORA-3: Olaparib + Pembrolizumab for BRCA-Mutant TNBC",
        "phase": "Phase 2",
        "status": "Recruiting",
        "disease_ids": ["D004"],
        "sponsor": "AZ/MSD Synthetic",
        "start_date": "2024-02-15",
        "primary_endpoint": "pCR at surgery",
        "target_enrollment": 200,
        "site_ids": ["S001", "S006", "S008", "S012"],
        "required_biomarkers": ["BM007", "BM008", "BM009", "BM011"],  # HER2- AND ER/PR- AND BRCA1/2
        "excluded_biomarkers": ["BM007"],  # No HER2 amplification
        "required_drugs_prior": [],
        "excluded_drugs_prior": ["DR004", "DR016"],  # No prior HER2-targeted therapy
        "prior_treatment_lines_max": 0,
        "inclusion_criteria_text": (
            "Newly diagnosed, locally advanced TNBC (ER-, PR-, HER2-). "
            "Germline BRCA1 or BRCA2 pathogenic variant confirmed. "
            "Stage II-III. No prior systemic chemotherapy. "
            "ECOG PS 0-1. Adequate bone marrow reserve."
        ),
        "exclusion_criteria_text": (
            "HER2-positive by IHC or FISH. Prior PARP inhibitor therapy. "
            "Prior immune checkpoint inhibitor. "
            "Known active CNS metastases. MDS or AML history."
        ),
        "challenge_tags": ["BIOMARKER-COMBO", "NEGATION"],
        "why_hard": "Requires 3 simultaneous biomarker conditions AND excludes HER2+ — compound logic"
    },
    # ── CKD + Diabetes Trials (BIOMARKER-COMBO for eGFR range)
    {
        "id": "T007",
        "nct_id": "NCT-SYN-0007",
        "title": "RENOVA-1: Finerenone + Dapagliflozin Combination for T2DM-CKD",
        "phase": "Phase 3",
        "status": "Recruiting",
        "disease_ids": ["D011"],
        "sponsor": "Bayer Synthetic",
        "start_date": "2023-08-01",
        "primary_endpoint": "Composite renal endpoint",
        "target_enrollment": 2400,
        "site_ids": ["S002", "S006", "S008", "S009", "S017"],
        "required_biomarkers": ["BM014", "BM015", "BM029"],  # eGFR 25-45 AND HbA1c ≥8 AND UACR >300
        "excluded_biomarkers": [],
        "required_drugs_prior": [],
        "excluded_drugs_prior": [],
        "prior_treatment_lines_max": 99,
        "inclusion_criteria_text": (
            "Adults ≥18 with Type 2 Diabetes and CKD. "
            "eGFR 25-45 mL/min/1.73m² at screening (CKD-EPI 2021). "
            "HbA1c ≥8.0% despite standard care. "
            "UACR >300 mg/g (macroalbuminuria). "
            "Stable background therapy for ≥3 months."
        ),
        "exclusion_criteria_text": (
            "eGFR <25 or >45 mL/min/1.73m². "
            "Type 1 Diabetes. Dialysis-dependent. Transplant recipient. "
            "Potassium >5.5 mEq/L. "
            "Current finerenone or eplerenone use. Active urinary tract infection."
        ),
        "challenge_tags": ["BIOMARKER-COMBO", "GEOGRAPHIC"],
        "why_hard": "Patient must satisfy eGFR 25-45 range check — vector search cannot evaluate numeric ranges"
    },
    # ── HFrEF Trial
    {
        "id": "T008",
        "nct_id": "NCT-SYN-0008",
        "title": "CARDIAC-SGLT2: Empagliflozin + Sacubitril-Valsartan Combo HFrEF",
        "phase": "Phase 3",
        "status": "Recruiting",
        "disease_ids": ["D012"],
        "sponsor": "BI/Novartis Synthetic",
        "start_date": "2024-03-01",
        "primary_endpoint": "HF hospitalization or CV death",
        "target_enrollment": 3000,
        "site_ids": ["S002", "S003", "S006", "S017"],
        "required_biomarkers": ["BM016", "BM017"],  # NT-proBNP >1000 AND LVEF ≤40%
        "excluded_biomarkers": [],
        "required_drugs_prior": [],
        "excluded_drugs_prior": [],
        "prior_treatment_lines_max": 99,
        "inclusion_criteria_text": (
            "Symptomatic chronic HFrEF (NYHA class II-III). LVEF ≤40% on Echo. "
            "NT-proBNP >1000 pg/mL (or BNP >300). "
            "eGFR ≥20 mL/min/1.73m². "
            "On stable GDMT for ≥3 months including beta-blocker and RAAS blocker."
        ),
        "exclusion_criteria_text": (
            "LVEF >40% (HFpEF). Acute decompensation within 4 weeks. "
            "SBP <95 mmHg. eGFR <20. "
            "History of angioedema with ACEi/ARB. "
            "Type 1 diabetes."
        ),
        "challenge_tags": ["BIOMARKER-COMBO"],
        "why_hard": "Two numeric biomarker conditions must both be satisfied — requires graph traversal"
    },
    # ── ATTR Amyloidosis Trial
    {
        "id": "T009",
        "nct_id": "NCT-SYN-0009",
        "title": "ATLAS-2: Acoramidis for Hereditary ATTR Amyloidosis",
        "phase": "Phase 3",
        "status": "Recruiting",
        "disease_ids": ["D010"],
        "sponsor": "BridgeBio Synthetic",
        "start_date": "2023-12-01",
        "primary_endpoint": "6-minute walk test",
        "target_enrollment": 400,
        "site_ids": ["S002", "S006", "S012"],
        "required_biomarkers": ["BM018", "BM022"],  # PYP positive AND TTR variant
        "excluded_biomarkers": [],
        "required_drugs_prior": [],
        "excluded_drugs_prior": ["DR010"],  # No prior tafamidis
        "prior_treatment_lines_max": 0,
        "inclusion_criteria_text": (
            "Hereditary ATTR amyloidosis with confirmed pathogenic TTR variant. "
            "Technetium pyrophosphate scan grade 2 or 3. "
            "NYHA class I-III. No prior TTR stabilizer therapy. "
            "eGFR ≥20 mL/min/1.73m²."
        ),
        "exclusion_criteria_text": (
            "Wild-type ATTR (senile amyloidosis — different protocol). "
            "Prior tafamidis, diflunisal, or TTR-lowering therapy. "
            "Organ transplant recipient. Life expectancy <12 months."
        ),
        "challenge_tags": ["MULTI-HOP", "DRUG-CONFLICT"],
        "why_hard": "Hereditary ATTR requires TTR variant confirmed — multi-hop: disease→subtype→genetic confirmation"
    },
    # ── Rheumatoid Arthritis Trial
    {
        "id": "T010",
        "nct_id": "NCT-SYN-0010",
        "title": "RESOLVE-JAK: Upadacitinib for TNF-Inadequate RA",
        "phase": "Phase 3",
        "status": "Recruiting",
        "disease_ids": ["D015"],
        "sponsor": "AbbVie Synthetic",
        "start_date": "2023-07-01",
        "primary_endpoint": "ACR50 at Week 12",
        "target_enrollment": 600,
        "site_ids": ["S003", "S009", "S016"],
        "required_biomarkers": ["BM023", "BM024"],  # CRP >10 AND DAS28 ≥3.2
        "excluded_biomarkers": [],
        "required_drugs_prior": ["DR012"],  # Must have had prior adalimumab (inadequate response)
        "excluded_drugs_prior": ["DR024"],  # No prior JAK inhibitor
        "prior_treatment_lines_max": 99,
        "inclusion_criteria_text": (
            "Adults ≥18 with rheumatoid arthritis. DAS28-CRP ≥3.2 (moderate-severe). "
            "Inadequate response or intolerance to ≥1 prior TNF inhibitor (adalimumab, etanercept, etc.). "
            "CRP >10 mg/L. No prior JAK inhibitor therapy. "
            "Background MTX allowed. "
            "Negative TB screen."
        ),
        "exclusion_criteria_text": (
            "Prior JAK inhibitor use (tofacitinib, baricitinib, upadacitinib). "
            "Active serious infection. Active TB. "
            "Current malignancy except basal cell skin cancer. "
            "Absolute lymphocyte count <500/mm³. "
            "Pregnancy."
        ),
        "challenge_tags": ["DRUG-CONFLICT", "MULTI-HOP"],
        "why_hard": "Patient must have had PRIOR adalimumab AND must NOT have had JAK inhibitor — dual drug history logic"
    },
    # ── SCLC Trial (TEMPORAL challenge — new drug)
    {
        "id": "T011",
        "nct_id": "NCT-SYN-0011",
        "title": "DLL3-STAR: Tarlatamab Maintenance for ES-SCLC",
        "phase": "Phase 3",
        "status": "Recruiting",
        "disease_ids": ["D002"],
        "sponsor": "Amgen Synthetic",
        "start_date": "2024-05-01",
        "primary_endpoint": "PFS",
        "target_enrollment": 380,
        "site_ids": ["S001", "S006", "S011"],
        "required_biomarkers": [],
        "excluded_biomarkers": [],
        "required_drugs_prior": [],
        "excluded_drugs_prior": [],
        "prior_treatment_lines_max": 1,
        "inclusion_criteria_text": (
            "Extensive-stage SCLC. Completed 4-6 cycles platinum-etoposide ± atezolizumab. "
            "No disease progression on first-line therapy. ECOG PS 0-2. "
            "Adequate organ function."
        ),
        "exclusion_criteria_text": (
            "Mixed small cell/non-small cell histology. "
            "Active CNS metastases requiring steroids. Prior tarlatamab."
        ),
        "challenge_tags": ["TEMPORAL"],
        "why_hard": "Drug approved 2024 — may not be in older training data; graph tracks approval dates"
    },
    # ── More trials for geographic and other challenges
    {
        "id": "T012",
        "nct_id": "NCT-SYN-0012",
        "title": "BRCA-BRIDGE: Olaparib for Platinum-Sensitive HER2- Breast Cancer",
        "phase": "Phase 2",
        "status": "Recruiting",
        "disease_ids": ["D003"],
        "sponsor": "AZ Synthetic",
        "start_date": "2024-01-20",
        "primary_endpoint": "ORR",
        "target_enrollment": 150,
        "site_ids": ["S001", "S019", "S008"],
        "required_biomarkers": ["BM011"],
        "excluded_biomarkers": [],
        "required_drugs_prior": [],
        "excluded_drugs_prior": ["DR007"],
        "prior_treatment_lines_max": 2,
        "inclusion_criteria_text": (
            "HER2-negative advanced or metastatic breast cancer. "
            "Germline BRCA1 or BRCA2 mutation. "
            "Prior platinum chemotherapy with response. "
            "No prior PARP inhibitor."
        ),
        "exclusion_criteria_text": (
            "Prior olaparib, niraparib, or other PARP inhibitors. "
            "MDS or AML. Active CNS metastases."
        ),
        "challenge_tags": ["DRUG-CONFLICT", "GEOGRAPHIC"]
    },
    {
        "id": "T013",
        "nct_id": "NCT-SYN-0013",
        "title": "SHIELD-MS: Ofatumumab vs Ocrelizumab in High-Activity RRMS",
        "phase": "Phase 3",
        "status": "Recruiting",
        "disease_ids": ["D014"],
        "sponsor": "Novartis Synthetic",
        "start_date": "2023-10-01",
        "primary_endpoint": "ARR at 2 years",
        "target_enrollment": 700,
        "site_ids": ["S004", "S006", "S013"],
        "required_biomarkers": [],
        "excluded_biomarkers": [],
        "required_drugs_prior": [],
        "excluded_drugs_prior": ["DR011", "DR022"],
        "prior_treatment_lines_max": 99,
        "inclusion_criteria_text": (
            "Confirmed RRMS with ≥2 relapses in last 2 years or 1 relapse + MRI activity. "
            "No prior anti-CD20 therapy. EDSS 0-5.5. Age 18-55."
        ),
        "exclusion_criteria_text": (
            "Prior natalizumab within 6 months. Prior alemtuzumab. "
            "Active hepatitis B. Immunocompromised state."
        ),
        "challenge_tags": ["DRUG-CONFLICT"]
    },
    {
        "id": "T014",
        "nct_id": "NCT-SYN-0014",
        "title": "SICKLE-SHIELD: Voxelotor + Hydroxyurea for SCD Adults",
        "phase": "Phase 3",
        "status": "Recruiting",
        "disease_ids": ["D019"],
        "sponsor": "Pfizer Synthetic",
        "start_date": "2023-05-15",
        "primary_endpoint": "VOC rate at 12 months",
        "target_enrollment": 300,
        "site_ids": ["S005", "S006", "S007", "S008"],
        "required_biomarkers": ["BM025"],  # HbF <30%
        "excluded_biomarkers": [],
        "required_drugs_prior": [],
        "excluded_drugs_prior": [],
        "prior_treatment_lines_max": 99,
        "inclusion_criteria_text": (
            "Adults ≥18 with homozygous SCD (HbSS) or HbSβ0-thalassemia. "
            "Fetal hemoglobin (HbF) <30%. "
            "≥2 VOC episodes in prior 12 months. "
            "Hydroxyurea-stable for ≥6 months."
        ),
        "exclusion_criteria_text": (
            "Patients on chronic transfusion program. "
            "Prior HSCT. "
            "HbSC disease (different subtype). "
            "ALT >3x ULN."
        ),
        "challenge_tags": ["NEGATION"]
    },
    {
        "id": "T015",
        "nct_id": "NCT-SYN-0015",
        "title": "PSORIASIS-JOINT: Guselkumab for PsA with Axial Involvement",
        "phase": "Phase 3",
        "status": "Recruiting",
        "disease_ids": ["D020"],
        "sponsor": "J&J Synthetic",
        "start_date": "2024-02-01",
        "primary_endpoint": "ACR20 at week 24",
        "target_enrollment": 500,
        "site_ids": ["S009", "S016", "S017"],
        "required_biomarkers": ["BM023"],
        "excluded_biomarkers": [],
        "required_drugs_prior": [],
        "excluded_drugs_prior": ["DR024"],  # No prior JAK inhibitor
        "prior_treatment_lines_max": 99,
        "inclusion_criteria_text": (
            "Active PsA with ≥3 tender and ≥3 swollen joints. "
            "Radiographic evidence of axial involvement. "
            "Inadequate response to ≥1 NSAID. CRP >10 mg/L or elevated ESR. "
            "TNF-naive or ≤1 prior TNF inhibitor."
        ),
        "exclusion_criteria_text": (
            "Prior IL-23 inhibitor or JAK inhibitor. "
            "Active psoriatic lesions requiring phototherapy. "
            "TB positive screen without completed prophylaxis."
        ),
        "challenge_tags": ["DRUG-CONFLICT"]
    },
]

# Add 15 more trials (abbreviated)
ADDITIONAL_TRIALS = [
    {"id": "T016", "nct_id": "NCT-SYN-0016",
     "title": "NTRK-GLOBAL: Larotrectinib for TRK Fusion Cancers India",
     "phase": "Phase 2", "status": "Recruiting", "disease_ids": ["D001", "D005"],
     "site_ids": ["S001", "S019", "S020"],
     "required_biomarkers": ["BM030"], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "Any solid tumor with NTRK1/2/3 fusion confirmed by RNA NGS. ECOG 0-2.",
     "challenge_tags": ["MULTI-HOP", "GEOGRAPHIC"]},
    {"id": "T017", "nct_id": "NCT-SYN-0017",
     "title": "TMB-IMMUNO: Nivolumab for TMB-High Solid Tumors",
     "phase": "Phase 2", "status": "Recruiting", "disease_ids": ["D001", "D003"],
     "site_ids": ["S001", "S006", "S011"],
     "required_biomarkers": ["BM028"], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": ["DR002", "DR017"],
     "inclusion_criteria_text": "Solid tumor TMB ≥10 mut/Mb by whole exome sequencing. No prior PD-1/PD-L1.",
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "T018", "nct_id": "NCT-SYN-0018",
     "title": "LUNG-IMMUNO-2L: Pembrolizumab for PD-L1 ≥50% NSCLC Second-Line",
     "phase": "Phase 2", "status": "Recruiting", "disease_ids": ["D001"],
     "site_ids": ["S001", "S002", "S018"],
     "required_biomarkers": ["BM003", "BM005"], "excluded_biomarkers": ["BM001", "BM002"],
     "required_drugs_prior": [], "excluded_drugs_prior": ["DR002"],
     "inclusion_criteria_text": "EGFR WT NSCLC. PD-L1 TPS ≥50% by IHC 22C3. 1 prior platinum doublet.",
     "challenge_tags": ["BIOMARKER-COMBO", "NEGATION"]},
    {"id": "T019", "nct_id": "NCT-SYN-0019",
     "title": "RENAL-PROTECT: Semaglutide for Cardiorenal Protection in T2DM",
     "phase": "Phase 3", "status": "Recruiting", "disease_ids": ["D011"],
     "site_ids": ["S002", "S009", "S017"],
     "required_biomarkers": ["BM014"], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "T2DM with eGFR 30-60. BMI ≥27. HbA1c 7-11%.",
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "T020", "nct_id": "NCT-SYN-0020",
     "title": "CML-3G: Asciminib for BCR-ABL CML Resistant to 2G TKI",
     "phase": "Phase 3", "status": "Recruiting", "disease_ids": ["D006"],
     "site_ids": ["S006", "S007", "S012"],
     "required_biomarkers": ["BM010"], "excluded_biomarkers": [],
     "required_drugs_prior": ["DR006"], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "CML in chronic phase. BCR-ABL confirmed. Failure of ≥2 prior TKIs including imatinib.",
     "challenge_tags": ["DRUG-CONFLICT", "MULTI-HOP"]},
    {"id": "T021", "nct_id": "NCT-SYN-0021",
     "title": "DLBCL-BEACON: CAR-T Salvage for R/R DLBCL",
     "phase": "Phase 2", "status": "Recruiting", "disease_ids": ["D007"],
     "site_ids": ["S006", "S012"],
     "required_biomarkers": [], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "R/R DLBCL after ≥2 prior chemoimmunotherapy lines including anti-CD20. ECOG 0-2.",
     "challenge_tags": ["MULTI-HOP"]},
    {"id": "T022", "nct_id": "NCT-SYN-0022",
     "title": "CRC-VEGF: Bevacizumab + FOLFOX for mCRC KRAS WT",
     "phase": "Phase 3", "status": "Completed",
     "disease_ids": ["D005"],
     "site_ids": ["S001", "S006"],
     "required_biomarkers": ["BM012"], "excluded_biomarkers": ["BM006", "BM013"],
     "required_drugs_prior": [], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "mCRC with MSI-High. KRAS and BRAF wild-type preferred.",
     "challenge_tags": ["TEMPORAL"],
     "why_hard": "Status Completed — not accepting patients; vector search may still return this trial"},
    {"id": "T023", "nct_id": "NCT-SYN-0023",
     "title": "IPF-ANTIFIBROTIC: Nintedanib + Sildenafil Combination",
     "phase": "Phase 2", "status": "Recruiting", "disease_ids": ["D018"],
     "site_ids": ["S006", "S009"],
     "required_biomarkers": ["BM021"], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "IPF with FEV1 <50% predicted. Stable nintedanib ≥3 months. DLCO <40%.",
     "challenge_tags": []},
    {"id": "T024", "nct_id": "NCT-SYN-0024",
     "title": "RA-BIOLOGIC-NAIVE: Abatacept First-Line for Seropositive RA",
     "phase": "Phase 3", "status": "Recruiting", "disease_ids": ["D015"],
     "site_ids": ["S003", "S016"],
     "required_biomarkers": ["BM024"], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": ["DR012", "DR024"],
     "inclusion_criteria_text": "Biologic-naive RA. Anti-CCP positive or RF positive. DAS28 ≥3.2.",
     "challenge_tags": ["DRUG-CONFLICT"]},
    {"id": "T025", "nct_id": "NCT-SYN-0025",
     "title": "HCC-COMBO: Atezolizumab + Bevacizumab for Advanced HCC",
     "phase": "Phase 3", "status": "Recruiting", "disease_ids": ["D009"],
     "site_ids": ["S001", "S002", "S015"],
     "required_biomarkers": [], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "Advanced HCC. Child-Pugh A. ECOG 0-1. No prior systemic therapy.",
     "challenge_tags": []},
    {"id": "T026", "nct_id": "NCT-SYN-0026",
     "title": "PDAC-PARP: Olaparib Maintenance for BRCA+ Pancreatic Cancer",
     "phase": "Phase 2", "status": "Recruiting", "disease_ids": ["D008"],
     "site_ids": ["S006", "S012"],
     "required_biomarkers": ["BM011"], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": ["DR007"],
     "inclusion_criteria_text": "BRCA1/2 germline mutation. PDAC responding to ≥4 cycles platinum doublet.",
     "challenge_tags": ["MULTI-HOP"]},
    {"id": "T027", "nct_id": "NCT-SYN-0027",
     "title": "AMYLOID-RNA: Patisiran for Hereditary ATTR with Polyneuropathy",
     "phase": "Phase 3", "status": "Recruiting", "disease_ids": ["D010"],
     "site_ids": ["S006", "S015"],
     "required_biomarkers": ["BM022"], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "hATTR polyneuropathy (PND score I-IIIA). TTR variant confirmed.",
     "challenge_tags": ["MULTI-HOP"]},
    {"id": "T028", "nct_id": "NCT-SYN-0028",
     "title": "LUNG-PD1-COMBO: Nivolumab + Ipilimumab for NSCLC PD-L1 <50%",
     "phase": "Phase 3", "status": "Recruiting", "disease_ids": ["D001"],
     "site_ids": ["S001", "S020", "S011"],
     "required_biomarkers": ["BM003"], "excluded_biomarkers": ["BM001", "BM002", "BM005"],
     "required_drugs_prior": [], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "EGFR WT, ALK-neg NSCLC. PD-L1 TPS 1-49% (not ≥50%). Treatment-naive.",
     "challenge_tags": ["NEGATION", "BIOMARKER-COMBO"]},
    {"id": "T029", "nct_id": "NCT-SYN-0029",
     "title": "COLON-MSI: Dostarlimab for Stage II MSI-H Colon Cancer",
     "phase": "Phase 3", "status": "Recruiting", "disease_ids": ["D005"],
     "site_ids": ["S001", "S005", "S019"],
     "required_biomarkers": ["BM012"], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "Stage II colon cancer with MSI-H/dMMR confirmed. Post-resection surveillance.",
     "challenge_tags": ["BIOMARKER-COMBO"]},
    {"id": "T030", "nct_id": "NCT-SYN-0030",
     "title": "HIV-CURE: Long-Acting Lenacapavir for Treatment-Naive HIV",
     "phase": "Phase 3", "status": "Recruiting", "disease_ids": ["D016"],
     "site_ids": ["S006", "S008"],
     "required_biomarkers": ["BM020"], "excluded_biomarkers": [],
     "required_drugs_prior": [], "excluded_drugs_prior": [],
     "inclusion_criteria_text": "Treatment-naive HIV. Viral load >500 copies/mL. CD4 any level.",
     "challenge_tags": []},
]

# ─────────────────────────────────────────────────────────────────────────────
# PATIENT PROFILES (20 synthetic profiles for evaluation)
# ─────────────────────────────────────────────────────────────────────────────

PATIENT_PROFILES = [
    # The FLAGSHIP example: NSCLC, EGFR wild-type, Maharashtra — should match T001/T018/T028
    {
        "id": "P001",
        "age": 58, "sex": "Male",
        "city": "Pune", "state": "Maharashtra", "country": "India",
        "ecog": 1,
        "diagnosis": {"disease_id": "D001", "stage": "IV", "histology": "adenocarcinoma"},
        "biomarkers_positive": ["BM003"],  # EGFR wild-type
        "biomarkers_negative": ["BM001", "BM002", "BM004", "BM026"],
        "prior_drugs": [],
        "prior_treatment_lines": 0,
        "comorbidities": [],
        "challenge_tags": ["NEGATION", "GEOGRAPHIC"],
        "ground_truth_eligible_trials": ["T001", "T018", "T028"],
        "ground_truth_ineligible_trials": ["T002", "T003", "T005"],
        "question": "Find NSCLC trials for a treatment-naive patient in Maharashtra who does NOT have the EGFR mutation"
    },
    # EGFR del19 positive - should match T002 only
    {
        "id": "P002",
        "age": 64, "sex": "Female",
        "city": "Mumbai", "state": "Maharashtra", "country": "India",
        "ecog": 0,
        "diagnosis": {"disease_id": "D001", "stage": "IIIB", "histology": "adenocarcinoma"},
        "biomarkers_positive": ["BM001"],  # EGFR del19 positive
        "biomarkers_negative": ["BM003", "BM004"],
        "prior_drugs": [],
        "prior_treatment_lines": 0,
        "comorbidities": [],
        "challenge_tags": ["NEGATION", "GEOGRAPHIC"],
        "ground_truth_eligible_trials": ["T002"],
        "ground_truth_ineligible_trials": ["T001", "T018", "T028"],
        "question": "Mumbai patient with EGFR exon 19 deletion NSCLC — which trials qualify?"
    },
    # T2DM + CKD with specific eGFR and biomarker range
    {
        "id": "P003",
        "age": 67, "sex": "Female",
        "city": "Nagpur", "state": "Maharashtra", "country": "India",
        "ecog": 1,
        "diagnosis": {"disease_id": "D011", "stage": "N/A", "histology": "N/A"},
        "biomarkers_positive": ["BM014", "BM015", "BM029"],  # eGFR 25-45, HbA1c ≥8, UACR >300
        "biomarkers_negative": [],
        "prior_drugs": [],
        "prior_treatment_lines": 0,
        "comorbidities": ["CKD Stage 3b"],
        "challenge_tags": ["BIOMARKER-COMBO", "GEOGRAPHIC"],
        "ground_truth_eligible_trials": ["T007"],
        "ground_truth_ineligible_trials": ["T019"],
        "question": "Maharashtra patient with T2DM, eGFR 38, HbA1c 9.2%, UACR 450mg/g — which trial fits?"
    },
    # TNBC with BRCA mutation — compound biomarker logic
    {
        "id": "P004",
        "age": 42, "sex": "Female",
        "city": "Chennai", "state": "Tamil Nadu", "country": "India",
        "ecog": 0,
        "diagnosis": {"disease_id": "D004", "stage": "III", "histology": "TNBC"},
        "biomarkers_positive": ["BM008", "BM009", "BM011"],
        "biomarkers_negative": ["BM007"],
        "prior_drugs": [],
        "prior_treatment_lines": 0,
        "comorbidities": [],
        "challenge_tags": ["BIOMARKER-COMBO"],
        "ground_truth_eligible_trials": ["T006"],
        "ground_truth_ineligible_trials": ["T012"],
        "question": "TNBC patient with BRCA1 mutation, HER2-negative, treatment-naive — eligible trials?"
    },
    # RA with prior adalimumab, no JAK inhibitor
    {
        "id": "P005",
        "age": 52, "sex": "Female",
        "city": "Pune", "state": "Maharashtra", "country": "India",
        "ecog": 1,
        "diagnosis": {"disease_id": "D015", "stage": "N/A", "histology": "N/A"},
        "biomarkers_positive": ["BM023", "BM024"],
        "biomarkers_negative": [],
        "prior_drugs": ["DR012"],  # Prior adalimumab
        "prior_treatment_lines": 1,
        "comorbidities": [],
        "challenge_tags": ["DRUG-CONFLICT", "GEOGRAPHIC"],
        "ground_truth_eligible_trials": ["T010"],
        "ground_truth_ineligible_trials": ["T024"],
        "question": "Pune RA patient, prior adalimumab inadequate response, no prior JAK inhibitor — options?"
    },
    # SCD — multi-hop for subtype + biomarker
    {
        "id": "P006",
        "age": 28, "sex": "Male",
        "city": "Aurangabad", "state": "Maharashtra", "country": "India",
        "ecog": 1,
        "diagnosis": {"disease_id": "D019", "stage": "N/A", "histology": "HbSS"},
        "biomarkers_positive": ["BM025"],
        "biomarkers_negative": [],
        "prior_drugs": [],
        "prior_treatment_lines": 0,
        "comorbidities": [],
        "challenge_tags": ["NEGATION", "GEOGRAPHIC"],
        "ground_truth_eligible_trials": ["T014"],
        "ground_truth_ineligible_trials": [],
        "question": "HbSS sickle cell patient in Aurangabad, Maharashtra, HbF <20%, ≥3 VOC/year"
    },
    # KRAS G12C NSCLC — must distinguish from EGFR-targeted trials
    {
        "id": "P007",
        "age": 61, "sex": "Male",
        "city": "Hyderabad", "state": "Telangana", "country": "India",
        "ecog": 1,
        "diagnosis": {"disease_id": "D001", "stage": "IV", "histology": "adenocarcinoma"},
        "biomarkers_positive": ["BM006"],
        "biomarkers_negative": ["BM001", "BM002"],
        "prior_drugs": [],
        "prior_treatment_lines": 1,
        "comorbidities": [],
        "challenge_tags": ["BIOMARKER-COMBO"],
        "ground_truth_eligible_trials": ["T003"],
        "ground_truth_ineligible_trials": ["T001", "T002"],
        "question": "KRAS G12C NSCLC after 1 prior platinum, no EGFR mutation — which targeted trial?"
    },
    # HFrEF — numeric biomarker combo
    {
        "id": "P008",
        "age": 71, "sex": "Male",
        "city": "Mumbai", "state": "Maharashtra", "country": "India",
        "ecog": 2,
        "diagnosis": {"disease_id": "D012", "stage": "N/A", "histology": "N/A"},
        "biomarkers_positive": ["BM016", "BM017"],  # NT-proBNP >1000, LVEF ≤40%
        "biomarkers_negative": [],
        "prior_drugs": [],
        "prior_treatment_lines": 0,
        "comorbidities": ["CKD Stage 2"],
        "challenge_tags": ["BIOMARKER-COMBO", "GEOGRAPHIC"],
        "ground_truth_eligible_trials": ["T008"],
        "ground_truth_ineligible_trials": [],
        "question": "Mumbai HFrEF patient, LVEF 32%, NT-proBNP 2400, eGFR 55 — trial options?"
    },
    # Hereditary ATTR — multi-hop rare disease
    {
        "id": "P009",
        "age": 72, "sex": "Male",
        "city": "Delhi", "state": "Delhi", "country": "India",
        "ecog": 1,
        "diagnosis": {"disease_id": "D010", "stage": "N/A", "histology": "N/A"},
        "biomarkers_positive": ["BM018", "BM022"],
        "biomarkers_negative": [],
        "prior_drugs": [],
        "prior_treatment_lines": 0,
        "comorbidities": [],
        "challenge_tags": ["MULTI-HOP"],
        "ground_truth_eligible_trials": ["T009", "T027"],
        "ground_truth_ineligible_trials": [],
        "question": "Hereditary ATTR, TTR variant Val30Met, PYP grade 3 — trials in India?"
    },
    # ALK+ NSCLC — temporal challenge (T005 not recruiting)
    {
        "id": "P010",
        "age": 45, "sex": "Female",
        "city": "Mumbai", "state": "Maharashtra", "country": "India",
        "ecog": 0,
        "diagnosis": {"disease_id": "D001", "stage": "IV", "histology": "adenocarcinoma"},
        "biomarkers_positive": ["BM004"],
        "biomarkers_negative": ["BM001", "BM002"],
        "prior_drugs": [],
        "prior_treatment_lines": 0,
        "comorbidities": [],
        "challenge_tags": ["TEMPORAL", "GEOGRAPHIC"],
        "ground_truth_eligible_trials": [],
        "ground_truth_ineligible_trials": ["T005"],
        "question": "ALK+ NSCLC patient in Mumbai — any CURRENTLY recruiting ALK trials in Maharashtra?"
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# EVAL QA PAIRS (golden dataset — 30 questions)
# ─────────────────────────────────────────────────────────────────────────────

EVAL_QA = [
    {
        "id": "EQ001",
        "patient_id": "P001",
        "question": "Find all currently recruiting NSCLC clinical trials in Maharashtra for a 58-year-old male with EGFR wild-type (no EGFR mutation), treatment-naive, ECOG 1.",
        "ground_truth_trials": ["T001", "T018", "T028"],
        "ground_truth_excluded": ["T002", "T005"],
        "challenge_type": "NEGATION+GEOGRAPHIC",
        "hops_required": 3,
        "why_hard": "Must filter: (1) EGFR WT required, (2) EGFR mutations excluded, (3) Maharashtra site, (4) Recruiting status. Vector search conflates EGFR-mutant and EGFR-WT trials.",
        "expected_naive_rag_failure": "Returns T002 (EGFR del19 trial) because NSCLC+EGFR text is semantically similar",
        "graph_query_hint": "MATCH (t:Trial)-[:EXCLUDES_BIOMARKER]->(b:Biomarker) WHERE b.name='EGFR Exon 19 Deletion' AND t.status='Recruiting' WITH t MATCH (t)-[:HAS_SITE]->(s:Site) WHERE s.state='Maharashtra' RETURN t"
    },
    {
        "id": "EQ002",
        "patient_id": "P002",
        "question": "Which trials accept NSCLC patients with confirmed EGFR exon 19 deletion in Mumbai?",
        "ground_truth_trials": ["T002"],
        "ground_truth_excluded": ["T001", "T018", "T028"],
        "challenge_type": "NEGATION+GEOGRAPHIC",
        "hops_required": 2,
        "why_hard": "T001 explicitly EXCLUDES EGFR del19 patients. Pure semantic similarity will match both T001 and T002.",
        "expected_naive_rag_failure": "Returns T001 because it discusses NSCLC + EGFR extensively",
        "graph_query_hint": "MATCH (t:Trial)-[:REQUIRES_BIOMARKER]->(b:Biomarker {name:'EGFR Exon 19 Deletion'}) MATCH (t)-[:HAS_SITE]->(s:Site {state:'Maharashtra'}) RETURN t"
    },
    {
        "id": "EQ003",
        "patient_id": "P003",
        "question": "Which T2DM clinical trial is appropriate for a patient in Nagpur, Maharashtra with eGFR 38, HbA1c 9.2%, and UACR 450 mg/g?",
        "ground_truth_trials": ["T007"],
        "ground_truth_excluded": ["T019"],
        "challenge_type": "BIOMARKER-COMBO+GEOGRAPHIC",
        "hops_required": 4,
        "why_hard": "eGFR 38 is in range 25-45 (satisfies T007) but NOT in range 30-60 (T019 requires 30-60). Pure semantic search cannot evaluate numeric ranges.",
        "expected_naive_rag_failure": "Returns T019 (wrong eGFR range) because both trials discuss CKD+T2DM semantically",
        "graph_query_hint": "MATCH (t:Trial)-[:REQUIRES_BIOMARKER]->(b:Biomarker) WHERE b.id IN ['BM014','BM015','BM029'] MATCH (t)-[:HAS_SITE]->(s:Site {state:'Maharashtra'}) RETURN t"
    },
    {
        "id": "EQ004",
        "patient_id": "P005",
        "question": "Eligible RA trials for a Pune patient who previously received adalimumab but has never had a JAK inhibitor?",
        "ground_truth_trials": ["T010"],
        "ground_truth_excluded": ["T024"],
        "challenge_type": "DRUG-CONFLICT+GEOGRAPHIC",
        "hops_required": 3,
        "why_hard": "T010 REQUIRES prior adalimumab AND EXCLUDES prior JAK inhibitor. T024 EXCLUDES prior adalimumab. Dual drug-history constraints.",
        "expected_naive_rag_failure": "Returns T024 (biologic-naive trial) which EXCLUDES this patient",
        "graph_query_hint": "MATCH (t:Trial)-[:REQUIRES_PRIOR_DRUG]->(d1:Drug {name:'Adalimumab'}) WHERE NOT (t)-[:EXCLUDES_PRIOR_DRUG]->(:Drug {class:'JAK1 inhibitor'}) RETURN t"
    },
    {
        "id": "EQ005",
        "patient_id": "P010",
        "question": "Is there any CURRENTLY RECRUITING ALK-positive NSCLC trial with sites in Maharashtra?",
        "ground_truth_trials": [],
        "ground_truth_excluded": ["T005"],
        "challenge_type": "TEMPORAL+GEOGRAPHIC",
        "hops_required": 2,
        "why_hard": "T005 (ALK trial) has status Active_not_recruiting. No ALK trial has a Maharashtra site. Answer should be 'NO eligible trial found'. Naive RAG returns T005 ignoring status.",
        "expected_naive_rag_failure": "Returns T005 without checking that it is NOT recruiting",
        "graph_query_hint": "MATCH (t:Trial)-[:REQUIRES_BIOMARKER]->(b {name:'ALK Rearrangement'}) WHERE t.status='Recruiting' MATCH (t)-[:HAS_SITE]->(s) WHERE s.state='Maharashtra' RETURN t"
    },
    {
        "id": "EQ006",
        "question": "How many Maharashtra sites are conducting oncology trials for KRAS G12C lung cancer?",
        "patient_id": None,
        "ground_truth_trials": ["T003"],
        "ground_truth_excluded": [],
        "challenge_type": "GEOGRAPHIC+BIOMARKER-COMBO",
        "hops_required": 3,
        "why_hard": "Requires: disease→KRAS G12C biomarker→trials with that biomarker→sites in Maharashtra. Pure vector search has no geographic filter.",
        "graph_query_hint": "MATCH (d:Disease {name:'Non-Small Cell Lung Cancer'})<-[:STUDIES_DISEASE]-(t:Trial)-[:REQUIRES_BIOMARKER]->(b {name:'KRAS G12C Mutation'})-[:HAS_SITE]->(s {state:'Maharashtra'}) RETURN t, s"
    },
    {
        "id": "EQ007",
        "question": "Which trials require a specific prior drug history as an inclusion criterion?",
        "patient_id": None,
        "ground_truth_trials": ["T010", "T020"],
        "ground_truth_excluded": [],
        "challenge_type": "DRUG-CONFLICT",
        "hops_required": 2,
        "why_hard": "Requires traversing REQUIRES_PRIOR_DRUG edges — a graph-specific relationship not expressible in semantic search.",
        "graph_query_hint": "MATCH (t:Trial)-[:REQUIRES_PRIOR_DRUG]->(d:Drug) RETURN t.id, t.title, d.name"
    },
    {
        "id": "EQ008",
        "question": "Find trials for TNBC patient that require ALL THREE of: HER2-negative, ER/PR-negative, AND BRCA mutation.",
        "patient_id": "P004",
        "ground_truth_trials": ["T006"],
        "ground_truth_excluded": ["T012"],
        "challenge_type": "BIOMARKER-COMBO",
        "hops_required": 3,
        "why_hard": "AND logic across 3 biomarkers simultaneously. Vector search performs OR-like fuzzy matching by design.",
        "graph_query_hint": "MATCH (t:Trial)-[:REQUIRES_BIOMARKER]->(b1 {name:'HER2 Negative'}) MATCH (t)-[:REQUIRES_BIOMARKER]->(b2 {name:'ER/PR Negative'}) MATCH (t)-[:REQUIRES_BIOMARKER]->(b3 {name:'BRCA1/2 Germline Mutation'}) RETURN t"
    },
    {
        "id": "EQ009",
        "question": "What is the traversal path (graph distance) from HFrEF disease to trial T008 via biomarkers?",
        "patient_id": "P008",
        "ground_truth_trials": ["T008"],
        "ground_truth_excluded": [],
        "challenge_type": "MULTI-HOP",
        "hops_required": 4,
        "why_hard": "Tests multi-hop path: Patient→Disease→Biomarker→Trial→Site. Confidence inversely proportional to path length.",
        "graph_query_hint": "MATCH path = (d:Disease {name:'Heart Failure with Reduced EF'})-[:HAS_BIOMARKER]->(b:Biomarker)<-[:REQUIRES_BIOMARKER]-(t:Trial {id:'T008'})-[:HAS_SITE]->(s:Site) RETURN path, length(path)"
    },
    {
        "id": "EQ010",
        "question": "Find trials where the patient's prior drug IMATINIB is listed as a REQUIREMENT (not just relevant).",
        "patient_id": None,
        "ground_truth_trials": ["T020"],
        "ground_truth_excluded": [],
        "challenge_type": "DRUG-CONFLICT",
        "hops_required": 2,
        "why_hard": "Distinction between 'drug is relevant context' (vector) and 'drug is required prior therapy' (graph edge type)",
        "graph_query_hint": "MATCH (t:Trial)-[r:REQUIRES_PRIOR_DRUG]->(d:Drug {name:'Imatinib'}) RETURN t"
    },
    # Additional QA pairs
    *[{
        "id": f"EQ{11+i:03d}",
        "question": q,
        "patient_id": pid,
        "ground_truth_trials": gt,
        "ground_truth_excluded": ge,
        "challenge_type": ct,
        "hops_required": hr,
        "why_hard": wh
    } for i, (q, pid, gt, ge, ct, hr, wh) in enumerate([
        ("Which trials explicitly exclude patients with prior osimertinib treatment?", None, ["T001"], ["T002"], "DRUG-CONFLICT", 2, "EXCLUDES_PRIOR_DRUG edge on DR001"),
        ("List all Maharashtra sites conducting HFrEF or cardiology trials.", None, ["T008"], [], "GEOGRAPHIC", 2, "Site specialty filter combined with disease node"),
        ("What biomarkers does trial T001 require vs exclude?", None, ["T001"], [], "BIOMARKER-COMBO", 1, "Direct edge traversal on single trial node"),
        ("Find trials for hereditary ATTR amyloidosis requiring TTR variant confirmation.", "P009", ["T009", "T027"], [], "MULTI-HOP", 3, "Disease subtype distinction — hereditary vs wild-type ATTR"),
        ("Which completed trials should NOT appear in current patient matching?", None, ["T022"], [], "TEMPORAL", 1, "Status=Completed must filter out — semantic search ignores status"),
        ("Count trials that exclude prior anti-PD-1 therapy.", None, ["T006", "T017"], [], "DRUG-CONFLICT", 2, "EXCLUDES_PRIOR_DRUG where drug.class contains PD-1"),
        ("Find NSCLC trials that require PD-L1 ≥50% AND EGFR wild-type simultaneously.", None, ["T018"], [], "BIOMARKER-COMBO", 3, "Requires both BM003 and BM005 via REQUIRES_BIOMARKER"),
        ("What is the minimum number of graph hops to match P007 to trial T003?", "P007", ["T003"], [], "MULTI-HOP", 4, "Patient→Disease→Biomarker→Trial→Site path length"),
        ("Are there any Maharashtra trials for sickle cell disease?", "P006", ["T014"], [], "GEOGRAPHIC+NEGATION", 3, "Site filter + HbF <30% required biomarker"),
        ("Which trial has the strictest compound biomarker requirement (most simultaneous required biomarkers)?", None, ["T006"], [], "BIOMARKER-COMBO", 2, "T006 requires 4 simultaneous biomarkers"),
        ("Find trials for PsA that exclude JAK inhibitors.", None, ["T015"], [], "DRUG-CONFLICT", 2, "EXCLUDES_PRIOR_DRUG where class=JAK1 inhibitor"),
        ("Which disease nodes are connected to more than 5 different trial nodes?", None, ["D001"], [], "MULTI-HOP", 2, "Degree query on Disease nodes — pure graph analytics"),
        ("Find patients from Maharashtra eligible for more than one oncology trial.", None, ["P001", "P002", "P008"], [], "GEOGRAPHIC+MULTI-HOP", 4, "Multi-trial eligibility from Maharashtra sites"),
        ("Which drug approved after 2023 is being tested in SCLC?", None, ["T011"], [], "TEMPORAL", 2, "Tarlatamab approved 2024 + SCLC disease link"),
        ("Can a patient on current osimertinib therapy enter trial T001?", None, [], ["T001"], "DRUG-CONFLICT", 2, "T001 excludes prior osimertinib — drug conflict resolution"),
        ("Find trials requiring NTRK fusion confirmation with Maharashtra sites.", None, ["T016"], [], "MULTI-HOP+GEOGRAPHIC", 3, "NTRK biomarker → T016 → Maharashtra sites"),
        ("What is the confidence score for P001 matching T001 via 3-hop graph traversal?", "P001", ["T001"], [], "MULTI-HOP", 3, "Confidence = f(hop_distance, biomarker_match_count)"),
        ("Which trials study diseases that share the biomarker PD-L1 TPS ≥50%?", None, ["T001", "T006", "T018"], [], "BIOMARKER-COMBO", 2, "Shared biomarker node connecting multiple disease/trial nodes"),
        ("Find all trials a patient with BOTH KRAS G12C AND EGFR del19 mutation would be ineligible for.", None, ["T001", "T002", "T003", "T018", "T028"], [], "BIOMARKER-COMBO", 3, "Mutually exclusive — co-occurrence rare but tests AND exclusion logic"),
        ("List drug nodes that appear as BOTH required prior therapy in one trial and excluded prior therapy in another.", None, ["DR012"], [], "DRUG-CONFLICT", 3, "DR012 (adalimumab): required in T010, excluded in T024 — graph dual-role"),
    ])]
]

# ─────────────────────────────────────────────────────────────────────────────
# GRAPH SCHEMA DEFINITION (for LLM context injection)
# ─────────────────────────────────────────────────────────────────────────────

GRAPH_SCHEMA = {
    "nodes": {
        "Disease": {
            "properties": ["id", "name", "aliases", "icd10", "category", "prevalence"],
            "example": "Disease {id:'D001', name:'Non-Small Cell Lung Cancer', icd10:'C34.10'}"
        },
        "Biomarker": {
            "properties": ["id", "name", "aliases", "type", "assay"],
            "example": "Biomarker {id:'BM001', name:'EGFR Exon 19 Deletion', type:'genetic'}"
        },
        "Drug": {
            "properties": ["id", "name", "brand", "class", "targets", "approval_year"],
            "example": "Drug {id:'DR001', name:'Osimertinib', class:'EGFR TKI 3rd gen'}"
        },
        "Trial": {
            "properties": ["id", "nct_id", "title", "phase", "status", "primary_endpoint",
                           "prior_treatment_lines_max"],
            "example": "Trial {id:'T001', status:'Recruiting', phase:'Phase 3'}"
        },
        "Site": {
            "properties": ["id", "name", "city", "state", "country", "tier", "specialties"],
            "example": "Site {id:'S001', name:'Tata Memorial Hospital', state:'Maharashtra'}"
        }
    },
    "relationships": {
        "REQUIRES_BIOMARKER": "Trial → Biomarker (inclusion criterion — patient MUST have this)",
        "EXCLUDES_BIOMARKER": "Trial → Biomarker (exclusion criterion — patient MUST NOT have this)",
        "REQUIRES_PRIOR_DRUG": "Trial → Drug (patient must have received this previously)",
        "EXCLUDES_PRIOR_DRUG": "Trial → Drug (patient must NOT have received this previously)",
        "HAS_SITE": "Trial → Site (trial is conducted at this site)",
        "STUDIES_DISEASE": "Trial → Disease (trial is for this disease)",
        "IS_BIOMARKER_FOR": "Biomarker → Disease (this biomarker is associated with disease)",
        "TREATS": "Drug → Disease (drug is approved for this disease)",
        "TARGETS": "Drug → Biomarker (drug targets this molecular marker)"
    },
    "cypher_templates": {
        "match_patient": """
MATCH (t:Trial)-[:STUDIES_DISEASE]->(d:Disease {id: $disease_id})
WHERE t.status = 'Recruiting'
  AND t.prior_treatment_lines_max >= $prior_lines
WITH t
// Check required biomarkers
WHERE ALL(b_id IN $required_biomarker_ids WHERE 
    (t)-[:REQUIRES_BIOMARKER]->(:Biomarker {id: b_id}))
// Check excluded biomarkers
WHERE NONE(b_id IN $patient_biomarker_ids WHERE 
    (t)-[:EXCLUDES_BIOMARKER]->(:Biomarker {id: b_id}))
// Optional: filter by site geography
OPTIONAL MATCH (t)-[:HAS_SITE]->(s:Site)
WHERE s.state = $state
RETURN t, collect(s) as sites
""",
        "find_by_biomarker": """
MATCH (b:Biomarker {name: $biomarker_name})<-[:REQUIRES_BIOMARKER]-(t:Trial)
WHERE t.status = 'Recruiting'
MATCH (t)-[:HAS_SITE]->(s:Site {state: $state})
RETURN t.id, t.title, t.phase, collect(s.name) as sites
""",
        "graph_distance": """
MATCH path = (p:Patient {id: $patient_id})-[:HAS_DISEASE]->(d:Disease)
    -[:BIOMARKER_FOR]->(b:Biomarker)<-[:REQUIRES_BIOMARKER]-(t:Trial)
    -[:HAS_SITE]->(s:Site)
WHERE t.id = $trial_id
RETURN path, length(path) as hops, 
       1.0 / (1 + length(path)) as confidence_score
"""
    }
}

# ─────────────────────────────────────────────────────────────────────────────
# WRITE ALL FILES
# ─────────────────────────────────────────────────────────────────────────────

def write_all():
    datasets = {
        "diseases.json": DISEASES,
        "biomarkers.json": BIOMARKERS,
        "drugs.json": DRUGS,
        "sites.json": SITES,
        "trials.json": TRIALS + [
            {**t, "phase": "Phase 2", "status": "Recruiting",
             "primary_endpoint": "ORR", "target_enrollment": 200,
             "sponsor": "Synthetic Sponsor", "start_date": "2024-01-01",
             "prior_treatment_lines_max": 2,
             "exclusion_criteria_text": "Active autoimmune disease. Prior targeted therapy.",
             "required_drugs_prior": t.get("required_drugs_prior", []),
             "excluded_drugs_prior": t.get("excluded_drugs_prior", [])}
            for t in ADDITIONAL_TRIALS
        ],
        "patient_profiles.json": PATIENT_PROFILES,
        "eval_qa_pairs.json": EVAL_QA,
        "graph_schema.json": GRAPH_SCHEMA,
    }

    for fname, data in datasets.items():
        with open(OUT / fname, "w") as f:
            json.dump(data, f, indent=2)
        print(f"  ✓ {fname} — {len(data) if isinstance(data, list) else 'schema'}")

    # Summary
    total_trials = len(TRIALS) + len(ADDITIONAL_TRIALS)
    total_entities = len(DISEASES) + len(BIOMARKERS) + len(DRUGS) + len(SITES) + total_trials
    print(f"\n{'='*55}")
    print("KNOWLEDGE GRAPH DATASET SUMMARY")
    print(f"{'='*55}")
    print(f"Disease nodes      : {len(DISEASES)}")
    print(f"Biomarker nodes    : {len(BIOMARKERS)}")
    print(f"Drug nodes         : {len(DRUGS)}")
    print(f"Site nodes         : {len(SITES)} ({sum(1 for s in SITES if s['state']=='Maharashtra')} in Maharashtra)")
    print(f"Trial nodes        : {total_trials}")
    print(f"Total graph nodes  : {total_entities}")
    print(f"Patient profiles   : {len(PATIENT_PROFILES)}")
    print(f"Eval QA pairs      : {len(EVAL_QA)}")
    print(f"\nChallenge distribution in trials:")
    from collections import Counter
    all_tags = []
    for t in TRIALS + ADDITIONAL_TRIALS:
        all_tags.extend(t.get("challenge_tags", []))
    for tag, count in Counter(all_tags).most_common():
        print(f"  [{tag}]: {count} trials")


if __name__ == "__main__":
    write_all()
