# MedKG Navigator
### Knowledge Graph × GraphRAG × Hybrid Retrieval for Clinical Trial Matching
**CitiusTech Gen AI & Agentic AI Training — Project 2**

---

## The Problem Pure Vector RAG Cannot Solve

Matching a patient to a clinical trial requires understanding **relational constraints** that embedding similarity fundamentally cannot express:

```
Patient: 58-year-old NSCLC, EGFR Exon 19 Deletion confirmed, Maharashtra
Query:   "Find NSCLC trials in Maharashtra for this patient"
```

A vector search on trial documents retrieves the top matches by semantic similarity to "NSCLC EGFR Maharashtra". Both trials contain dense EGFR text, so both score high:

| Trial | Title | Vector Score | Vector returns it? | Graph verdict |
|-------|-------|-------------|-------------------|---------------|
| **T002** | Osimertinib for EGFR-Mutant NSCLC | 0.92 | ✅ Yes | ✅ ELIGIBLE |
| **T001** | Pembrolizumab for EGFR Wild-Type NSCLC | 0.89 | ✅ Yes ← **this is the problem** | ❌ EXCLUDED |

The vector model **recommends T001 with confidence (0.89)**. It has no idea that T001 is wrong for this patient — because the embedding of *"EGFR wild-type, no sensitizing mutations"* and *"EGFR exon 19 deletion"* land close together in vector space. Both phrases are "EGFR NSCLC context." The difference between wild-type and mutant is a tiny gap in embedding space; it is not a tiny gap clinically.

The graph knows T001 has `EXCLUDES_BIOMARKER → EGFR del19`. The patient has EGFR del19. Gate fails. T001 is dropped regardless of its 0.89 vector score.

A patient who acts on the vector result and contacts the T001 site will be turned away — after raising their hopes and delaying access to T002, which is the correct trial.

---

## What Goes in the Knowledge Graph vs the Vector DB

This is the central architectural question. The wrong answer — "put everything in vectors" — is exactly the failure mode this project is designed to expose.

### Decision Table

| Data Type | Knowledge Graph | Vector DB | Reason |
|-----------|:--------------:|:---------:|--------|
| Trial eligibility: required biomarkers | ✅ `REQUIRES_BIOMARKER` edge | ❌ | Edge type encodes meaning; prose cannot |
| Trial eligibility: excluded biomarkers | ✅ `EXCLUDES_BIOMARKER` edge | ❌ | **Critical** — negation is lost in text |
| Required/excluded prior drugs | ✅ `REQUIRES_PRIOR_DRUG` / `EXCLUDES_PRIOR_DRUG` | ❌ | Edge type distinguishes REQUIRES from EXCLUDES |
| Trial status (Recruiting / Completed) | ✅ `Trial.status` property | ❌ | Boolean fact; must not be fuzzily matched |
| Geographic filter (site state/city) | ✅ `HAS_SITE` → `Site.state` | ❌ | Exact match required; embedding similarity fails |
| Prior treatment lines limit | ✅ `Trial.prior_treatment_lines_max` | ❌ | Numeric comparison; not semantic |
| Cross-reference pointers | ✅ `Trial.chunk_ids` property | ❌ | KG carries the pointer TO vector DB |
| Protocol inclusion prose (nuanced narrative) | ❌ | ✅ `protocol_narrative` chunk | Nuance, investigator-discretion clauses |
| Protocol exclusion prose (clinical context) | ❌ | ✅ `protocol_narrative` chunk | Edge cases not encodable as graph edges |
| Scientific rationale / study hypothesis | ❌ | ✅ `trial_rationale` chunk | Why the trial exists; needed for LLM context |
| Drug mechanism of action | ❌ | ✅ `drug_mechanism` chunk | Class description, resistance patterns |
| Biomarker clinical significance | ❌ | ✅ `biomarker_clinical` chunk | What the test means, alternative assays |
| Disease overview / synonyms context | ❌ | ✅ `disease_overview` chunk | Pathophysiology, treatment landscape |
| Disease/Biomarker/Drug ontology links | ✅ graph edges | ❌ | Multi-hop traversal; not semantic |
| Patient facts (current biomarkers, drugs) | ✅ `HAS_BIOMARKER`, `RECEIVED_DRUG` | ❌ | Boolean facts to match against KG edges |

### Why Biomarker Negation MUST Live in the KG

```
Trial T001 text: "Patients must be EGFR wild-type. EGFR mutations are excluded."
Trial T002 text: "Patients must have EGFR exon 19 deletion confirmed."

Query: "EGFR NSCLC trial"
Vector score T001: 0.91  ← "EGFR" appears densely in both directions
Vector score T002: 0.89  ← "EGFR" appears densely, equally similar

KG traversal for EGFR-mutant patient:
  T001: EXCLUDES_BIOMARKER → BM001 (EGFR del19) → patient has BM001 → GATE FAILS ✗
  T002: REQUIRES_BIOMARKER → BM001 (EGFR del19) → patient has BM001 → GATE PASSES ✓
```

The edge **type** (`REQUIRES_` vs `EXCLUDES_`) carries the semantics. An embedding model collapses both into a high-similarity vector because "EGFR mutation" is textually prominent in both documents.

### Why KG Alone Cannot Solve the Problem

The graph enforces hard eligibility gates, but clinical matching requires **understanding prose** that cannot be reduced to typed edges. Consider this graph-only failure:

```
Patient: 58-year-old NSCLC, EGFR Exon 19 Deletion, stable brain metastases (treated, 6 weeks prior)
Query:   "Find eligible NSCLC trials for this patient"
```

The graph correctly gates on biomarker edges. But Trial T002's protocol text reads:

> *"Patients with previously treated, radiologically stable brain metastases may be eligible at investigator discretion, provided the last treatment was ≥4 weeks prior to enrollment."*

The graph has no node or edge for "investigator discretion" or "4-week washout for brain metastases." This clause lives exclusively in the protocol prose. A graph-only retriever either **hard-excludes all patients with brain metastases** (too strict, misses eligible patients) or **hard-includes all of them** (too permissive, sends ineligible patients). Neither is correct.

| Information Need | Graph-Only Result | What Vector DB Adds |
|-----------------|------------------|---------------------|
| Brain metastases eligibility nuance | ❌ Returns "no match" — no edge for this condition | ✅ `T002_protocol` chunk surfaces the investigator-discretion clause |
| Why osimertinib over gefitinib? | ❌ Only knows: Drug→targets→EGFR | ✅ `DR002_mechanism` chunk explains T790M resistance, 3rd-gen selectivity |
| What does EGFR del19 mean clinically? | ❌ Only knows: Biomarker node exists | ✅ `BM001_clinical` chunk explains sensitivity to EGFR-TKIs, diagnostic assays |
| NSCLC vs Non-Small Cell Lung Cancer | ❌ Only matches exact disease name stored in KG | ✅ `D001_overview` chunk contains both forms; semantic search handles aliases |
| LLM-explainable rationale for recommendation | ❌ Returns trial IDs and Cypher matches only | ✅ Protocol prose + rationale chunks give LLM grounded text to cite |

**The investigator-discretion failure in numbers:**

```
Patient: NSCLC, EGFR del19, stable brain mets (treated 6 weeks ago)
Trial T002: graph edges = REQUIRES_BIOMARKER → EGFR del19  [PASSES ✓]
            no edge for brain_metastasis_policy

Graph-Only decision: ELIGIBLE (brain mets policy not modeled → silent gap)
Graph-RAG decision:  "T002 may be eligible — brain metastasis clause requires
                      investigator review; washout period of ≥4 weeks is met.
                      Confidence: MEDIUM. Recommend CRC verification."
                      [Source: T002_protocol chunk, sentence 4]
```

The graph gets the biomarker gate right. The vector layer is what surfaces the washout caveat, enables the LLM to express uncertainty, and prevents a dangerously confident "ELIGIBLE" from going to the patient without qualification.

**Three categories where the KG is structurally blind:**

1. **Nuanced eligibility prose** — investigator-discretion clauses, washout windows, performance status ranges expressed as narrative, co-morbidity caveats. These involve conditional logic in free text that cannot be pre-enumerated as typed edges.

2. **Contextual background** — drug mechanism of action, resistance pathways, biomarker test alternatives, disease pathophysiology. The KG knows *that* osimertinib targets EGFR; the vector chunk knows *why* it is preferred for T790M-positive patients after 1st-gen TKI failure.

3. **Soft semantic matching** — medical synonyms, abbreviation variants, institution-specific terminology. `"Non-Small Cell Lung Cancer"`, `"NSCLC"`, `"non-small-cell lung carcinoma"` are the same entity clinically. The KG stores one canonical label; the vector store resolves all surface forms via embedding proximity.

### KG → Vector DB Cross-Reference Pattern

```
                    KNOWLEDGE GRAPH                    VECTOR DB
                    ───────────────                    ─────────
 Patient ──→ HAS_BIOMARKER ──→ Biomarker
                                   │
              graph traversal       │  (boolean gates)
              filters trials ───────┤
                                   ↓
              Trial node T001   chunk_ids: ["T001_protocol",
                │                          "T001_rationale",
                │  .chunk_ids property      "DR002_mechanism",
                │  (KG→VectorDB pointer)    "BM003_clinical"]
                │                               │
                └───────────────────────────────┤
                                                ↓
                                    VectorChunkStore.get_by_ids()
                                         targeted fetch
                                              │
                                    T001_protocol (prose)
                                    T001_rationale (why)
                                    DR002_mechanism (drug MOA)
                                    BM003_clinical (biomarker context)
                                              │
                                              ↓
                                    LLM synthesis (graph facts + prose)
```

### Cross-Linking Tips

**1. Chunk ID convention** — derive chunk_ids from entity IDs so the mapping is self-documenting:
```python
Trial T001  → chunk_ids: ["T001_protocol", "T001_rationale"]
Drug  DR002 → chunk_ids: ["DR002_mechanism"]
BM    BM003 → chunk_ids: ["BM003_clinical"]
Disease D001→ chunk_ids: ["D001_overview"]
```

**2. Store chunk_ids as a Neo4j property** — so Cypher can return them with the trial:
```cypher
MATCH (t:Trial {id: 'T001'})
RETURN t.chunk_ids  -- ["T001_protocol", "T001_rationale", ...]
```

**3. Targeted fetch beats blind semantic search** — after graph traversal gives you approved trial IDs, fetch their chunks directly by ID. This prevents semantically similar but graph-excluded trials (T002, T005) from re-entering through the vector path.

**4. Open semantic search as a supplement** — after targeted fetch, also run semantic search restricted to the graph-approved trial set:
```python
chunks = chunk_store.query(
    query_text,
    restrict_to_trial_ids=graph_approved_ids,  # graph-gated
    chunk_types=["protocol_narrative", "trial_rationale"],
)
```

**5. Chunk type routing in the LLM prompt** — label each chunk by type so the LLM can weight them appropriately:
- `protocol_narrative` → hard eligibility evidence (high weight)
- `drug_mechanism` → background context (medium weight)
- `disease_overview` → terminology context (low weight)

**6. Keep structured facts out of vector DB chunks** — the chunk text should NOT repeat the `required_biomarkers` list as plain text. That list lives in the KG. The chunk should contain only the prose that adds value beyond what graph edges already express.

---

## Learning Architecture

```
Naive Vector  →  Synonym Expanded  →  Graph Only  →  Hybrid  →  Graph-RAG  →  + NeMo Guards
  F1: 0.11         F1: 0.17             F1: 0.59      F1: 0.75    F1: 0.79       F1: 0.82
  FP: 4.8          FP: 4.5              FP: 0.1       FP: 0.0     FP: 0.0        FP: 0.0
```

Each stage is motivated by a **measurable failure mode** in the previous one.

---

## Knowledge Graph Schema

```
(Patient)-[:HAS_DISEASE]--------→(Disease)
(Disease)-[:HAS_BIOMARKER]------→(Biomarker)
(Drug)-[:TREATS]-----------------→(Disease)
(Drug)-[:TARGETS]----------------→(Biomarker)

(Trial)-[:STUDIES_DISEASE]-------→(Disease)
(Trial)-[:REQUIRES_BIOMARKER]----→(Biomarker)   ← Patient MUST have this
(Trial)-[:EXCLUDES_BIOMARKER]----→(Biomarker)   ← Patient MUST NOT have this (**key**)
(Trial)-[:REQUIRES_PRIOR_DRUG]---→(Drug)
(Trial)-[:EXCLUDES_PRIOR_DRUG]---→(Drug)
(Trial)-[:HAS_SITE]--------------→(Site)

(Patient)-[:HAS_BIOMARKER]-------→(Biomarker)
(Patient)-[:RECEIVED_DRUG]-------→(Drug)
```

The critical insight: `REQUIRES_BIOMARKER` and `EXCLUDES_BIOMARKER` are **typed edges** — something a text embedding cannot distinguish. This single architectural decision is what makes Graph-RAG mandatory for clinical matching.

---

## Project Structure

```
kgproject/
├── data/
│   ├── generate_kg_dataset.py     ← Run this first — generates KG entities
│   ├── diseases.json              ← 20 Disease nodes  [KG]
│   ├── biomarkers.json            ← 30 Biomarker nodes [KG]
│   ├── drugs.json                 ← 25 Drug nodes      [KG]
│   ├── sites.json                 ← 20 Site nodes      [KG]
│   ├── trials.json                ← 30 Trial nodes + typed eligibility edges [KG]
│   ├── patient_profiles.json      ← 10 Patient nodes   [KG]
│   ├── protocol_chunks.json       ← Narrative text chunks [VECTOR DB] ← NEW
│   │     • protocol_narrative     — eligibility prose with clinical nuance
│   │     • trial_rationale        — scientific hypothesis
│   │     • drug_mechanism         — MOA and class context
│   │     • biomarker_clinical     — test significance
│   │     • disease_overview       — pathophysiology + synonyms
│   ├── eval_qa_pairs.json         ← 30 labeled evaluation questions
│   └── graph_schema.json          ← Cypher templates and schema reference
│
├── src/
│   ├── graph_builder.py           ← Neo4j KG construction + MockGraph
│   └── hybrid_retrieval.py        ← All 6 retrieval stages + evaluation
│         • EmbeddingStore          — naive trial-blob store (Stages 0-1)
│         • VectorChunkStore        — typed narrative chunk store (Stages 3+)
│         • TRIAL_CHUNK_INDEX       — KG→VectorDB cross-reference map
│         • get_chunk_ids_for_trial — follow chunk_id pointers from KG nodes
│
├── evaluation/
│   ├── eval_dashboard.py          ← Metrics visualization
│   ├── eval_results.csv           ← Benchmark results
│   └── *.png                      ← Generated charts
│
├── demo/
│   └── demo_queries.py            ← 5 capability demos
│                                     + 1 architecture demo (Q8: KG→VectorDB trace)
│                                     + 2 limitation disclosures
│
├── configs/
│   └── guardrails_config.co       ← NeMo Guardrails colang config
│
└── README.md
```

---

## Quick Start

### Step 1: Generate the Dataset

```bash
cd data/
python generate_kg_dataset.py
```

Expected output:
```
✓ diseases.json    — 20 Disease nodes                           [KG]
✓ biomarkers.json  — 30 Biomarker nodes (EGFR, ALK, KRAS, ...) [KG]
✓ drugs.json       — 25 Drug nodes (osimertinib, tafamidis, ...)[KG]
✓ sites.json       — 20 Sites (8 in Maharashtra)                [KG]
✓ trials.json      — 30 Trial nodes + typed eligibility edges   [KG]
Total KG nodes: 125

✓ protocol_chunks.json — Narrative text chunks                  [VECTOR DB]
  protocol_narrative  : 12 chunks (trial eligibility prose)
  trial_rationale     :  2 chunks (scientific hypothesis)
  drug_mechanism      :  5 chunks (drug MOA and class context)
  biomarker_clinical  :  7 chunks (clinical significance)
  disease_overview    :  4 chunks (pathophysiology + synonyms)
  architecture_note   :  1 chunk  (design pattern reference)
Total chunks: 31
```

### Vector DB Chunk Schema

```json
{
  "chunk_id": "T001_protocol",
  "entity_type": "Trial",
  "entity_id": "T001",
  "chunk_type": "protocol_narrative",
  "text": "MOMENTUM-1: full inclusion/exclusion prose with clinical nuance...",
  "kg_node_ids": ["T001"],
  "metadata": {
    "trial_id": "T001",
    "chunk_category": "eligibility_prose",
    "tags": ["NSCLC", "EGFR-WT", "pembrolizumab"]
  }
}
```

**`chunk_id` convention:**
- `{trial_id}_protocol`  — protocol narrative (e.g., `T001_protocol`)
- `{trial_id}_rationale` — scientific rationale
- `{drug_id}_mechanism`  — drug MOA (e.g., `DR002_mechanism`)
- `{bm_id}_clinical`     — biomarker context (e.g., `BM003_clinical`)
- `{disease_id}_overview`— disease overview (e.g., `D001_overview`)

These IDs are stored as `chunk_ids` on KG Trial nodes, providing the cross-reference link.

### Step 2: Build the Knowledge Graph

**Option A: Neo4j (full functionality)**
```bash
# Start Neo4j Desktop or AuraDB
export NEO4J_URI=bolt://localhost:7687
export NEO4J_USER=neo4j
export NEO4J_PASSWORD=your-password

pip install neo4j
cd src/
python graph_builder.py
```

**Option B: MockGraph (no Neo4j needed — for initial exercises)**
```bash
cd src/
python graph_builder.py --mock
```

### Step 3: Run the Evaluation

```bash
cd src/
python hybrid_retrieval.py --eval
```

### Step 4: Generate Visualizations

```bash
cd evaluation/
python eval_dashboard.py --demo
```

### Step 5: Run the Demo

```bash
cd demo/
python demo_queries.py              # All 8 questions
python demo_queries.py --question 1 # Q1: NSCLC + EGFR negation
python demo_queries.py --question 8 # Q8: KG→VectorDB cross-reference trace
python demo_queries.py --compare    # Naive vs Hybrid side-by-side
```

**Q8 is the architecture walkthrough** — it traces the full KG→VectorDB cross-reference chain for Patient P001 and explicitly shows which chunk_ids the graph-approved trials carry, which chunks are fetched from the vector store, and why graph-excluded trials produce no chunks.

---

## Injected Challenges (Dataset Design)

The dataset is **deliberately engineered** to expose the failure modes of pure vector search:

| Challenge | Trials | Biomarkers | What It Exposes |
|-----------|--------|-----------|-----------------|
| `[NEGATION]` | T001, T002, T006, T014, T018, T028 | BM001-BM003, BM007-BM008 | Patient must NOT have a biomarker — vectors cannot distinguish presence/absence |
| `[BIOMARKER-COMBO]` | T003, T006, T007, T008, T017, T018 | BM014-BM017, BM028 | AND logic across 3+ simultaneous biomarkers — vectors do OR-like fuzzy match |
| `[DRUG-CONFLICT]` | T010, T013, T020, T024 | — | REQUIRES vs EXCLUDES prior drug — both look similar in text |
| `[MULTI-HOP]` | T004, T009, T020, T021 | BM018, BM022, BM027 | 4+ hop traversal needed for rare disease subtypes |
| `[TEMPORAL]` | T005, T011, T022 | — | Status = Active_not_recruiting / Completed — vector ignores trial status |
| `[GEOGRAPHIC]` | T001, T007, T016 | — | Maharashtra site filter — not computable from semantic similarity |
| `[SYNONYM]` | D001, D002, D009 | — | NSCLC vs Non-Small Cell Lung Cancer — alias resolution |

### The Critical NEGATION Pattern

Trial T001 includes: `"EGFR wild-type confirmed. No known EGFR sensitizing mutations."`
Trial T002 includes: `"EGFR exon 19 deletion confirmed."`

A patient **with EGFR del19** must go to T002, not T001. But both trials contain dense EGFR text. Vector similarity returns both. The graph's `EXCLUDES_BIOMARKER` edge on T001 is the definitive filter.

---

## The Six Retrieval Stages

### Stage 0: Naive Vector RAG
```python
results = embed_store.query(question, top_k=5)
```
Semantic similarity only. Returns trials based on text overlap with query.
**Fatal flaw**: Cannot distinguish REQUIRES from EXCLUDES biomarker edges.
**F1: ~0.11 | False Positives: ~4.8 per query**

### Stage 1: Synonym-Expanded Vector
```python
expanded_q = expand_query(question)  # "NSCLC" → "Non-Small Cell Lung Cancer EGFR..."
results = embed_store.query(expanded_q, top_k=5)
```
Improves recall for medical abbreviations. Still cannot enforce negation.
**F1: ~0.17 | False Positives: ~4.5 per query**

### Stage 2: Graph-Only (Pure Cypher)
```cypher
MATCH (t:Trial)-[:STUDIES_DISEASE]->(d:Disease {id: $disease_id})
WHERE t.status = 'Recruiting'
  AND ALL(b IN $required_biomarkers WHERE (t)-[:REQUIRES_BIOMARKER]->(:Biomarker {id: b}))
  AND NONE(b IN $patient_biomarkers WHERE (t)-[:EXCLUDES_BIOMARKER]->(:Biomarker {id: b}))
MATCH (t)-[:HAS_SITE]->(s:Site {state: $state})
RETURN t, collect(s) as sites
```
Exact relational matching. Hard negation enforced. Geographic precision.
**F1: ~0.59 | False Positives: ~0.1 per query**

### Stage 3: Hybrid Graph + Vector
```python
# Step 1: Graph — hard eligibility filter (gates out impossible trials)
graph_candidates = graph.match_patient_to_trials(...)

# Step 2: Vector — re-rank candidates by semantic relevance to text criteria
vector_scores = embed_store.query(expanded_query, top_k=20)

# Step 3: Fuse — combined score = 0.6 × graph_confidence + 0.4 × vector_similarity
# Only trials that passed the graph filter are returned
```
Best of both: graph handles logic, vector handles nuanced text matching.
**F1: ~0.75 | False Positives: ~0.0**

### Stage 4: Graph-RAG (with LLM Synthesis)
Graph-filtered results + unstructured protocol text → LLM generates cited assessment with confidence tier.
**F1: ~0.79 | Adds: citation grounding, confidence tiers, NEXT STEP guidance**

### Stage 5: Graph-RAG + NeMo Guardrails
Post-hoc safety layer:
- Rejects closed/completed trial recommendations
- Blocks off-label treatment suggestions
- Enforces mandatory physician disclaimer
**F1: ~0.82 | Eliminates: temporal contamination, overconfident claims**

---

## Evaluation Metrics

| Metric | Definition | Clinical Relevance |
|--------|-----------|-------------------|
| Precision | Fraction of returned trials the patient is eligible for | False positives send patients to wrong trials |
| Recall | Fraction of eligible trials that were found | False negatives cause missed opportunities |
| F1 | Harmonic mean of P and R | Overall matching quality |
| False Positives | Trials returned where patient is excluded | Clinically dangerous — patients may pursue ineligible trials |

**The critical metric is False Positives.** A patient who pursues an ineligible trial wastes time, money, and may delay accessing a trial they ARE eligible for.

### Graph-RAG Confidence Score

```python
confidence = (
    0.7 × biomarker_match_completeness
  + 0.15 × (1 / graph_hop_distance)
  + 0.15 × geographic_proximity_bonus
)
```

HIGH confidence (>0.8): All graph criteria exactly met, nearby site, ≤2 hops
MEDIUM (0.6–0.8): Most criteria met, some inferred from text
LOW (<0.6): Partial match, long hop path, or text-only inference

---

## Neo4j Setup (For Full Graph Functionality)

### AuraDB Free Tier (Cloud — No Installation)

```bash
# 1. Create free account at: https://neo4j.com/cloud/platform/aura-graph-database/
# 2. Spin up a free AuraDB instance
# 3. Download credentials file
# 4. Set environment variables:
export NEO4J_URI="neo4j+s://xxxxxxxx.databases.neo4j.io"
export NEO4J_USER="neo4j"
export NEO4J_PASSWORD="your-aura-password"
```

### Neo4j Desktop (Local)

```bash
# Download: https://neo4j.com/download/
# Create a project, start a database
# Default: bolt://localhost:7687
```

### Useful Cypher Queries to Try

```cypher
-- All Maharashtra sites with their specialties
MATCH (s:Site {state:'Maharashtra'})
RETURN s.name, s.city, s.specialties

-- Which trials exclude EGFR-mutant patients?
MATCH (t:Trial)-[:EXCLUDES_BIOMARKER]->(b:Biomarker)
WHERE b.name CONTAINS 'EGFR'
RETURN t.id, t.title, collect(b.name) as excluded_biomarkers

-- Multi-hop: Disease → Biomarker → Trial → Site
MATCH path = (d:Disease {name:'Non-Small Cell Lung Cancer'})
    -[:HAS_BIOMARKER]->(b:Biomarker {name:'EGFR Wild-Type'})
    <-[:REQUIRES_BIOMARKER]-(t:Trial {status:'Recruiting'})
    -[:HAS_SITE]->(s:Site {state:'Maharashtra'})
RETURN d.name, b.name, t.title, s.name, length(path) as hops

-- Confidence score calculation
MATCH path = (d:Disease {id:'D001'})-[:HAS_BIOMARKER]->(b:Biomarker)
    <-[:REQUIRES_BIOMARKER]-(t:Trial)-[:HAS_SITE]->(s:Site)
WHERE t.status = 'Recruiting'
RETURN t.id, length(path) as hops, 1.0/(1+length(path)) as confidence_component
ORDER BY confidence_component DESC
```

---

## Guardrails Integration


Implement any GuardRails mechanism such as Nemo Guardrails or Azure Foundry

### Nemo Guardrails

### Colang Configuration

```colang
# configs/guardrails/main.co

define user ask off-label recommendation
  "use this drug outside trial"
  "recommend off-label"
  "compassionate use"

define user ask closed trial
  "join trial" "this trial is open"

define bot refuse off-label
  "I can only match patients to approved clinical trials. Off-label 
   recommendations require explicit physician authorization."

define bot add disclaimer
  "All eligibility determinations must be verified by a Clinical Research 
   Coordinator reviewing the complete current protocol."

define flow
  user ask off-label recommendation
  bot refuse off-label

define flow process recommendation
  bot add disclaimer
```

### Python Integration

```python
from nemoguardrails import RailsConfig, LLMRails

config = RailsConfig.from_path("configs/guardrails/")
rails = LLMRails(config)

response = await rails.generate_async(
    messages=[{"role": "user", "content": patient_query}]
)
```

---

## Demo Questions Summary

| # | Question Type | Challenge | Key Insight |
|---|---------------|-----------|-------------|
| 1 | NSCLC + EGFR negation in Maharashtra | NEGATION + GEOGRAPHIC | Graph excludes T002; vector returns it as FP |
| 2 | TNBC triple biomarker AND logic | BIOMARKER-COMBO | Graph enforces 3 simultaneous conditions |
| 3 | RA dual drug constraint (required + excluded) | DRUG-CONFLICT | Graph distinguishes REQUIRES vs EXCLUDES prior drug |
| 4 | ATTR amyloidosis 4-hop traversal | MULTI-HOP + RARE | Confidence = f(hop distance); rare entity no problem |
| 5 | ALK+ trial status filtering | TEMPORAL | Answer is "zero eligible" — vector returns closed trial |
| 6 ⚠ | ECOG borderline (improving patient) | **LIMITATION** | Graph cannot model clinical trajectories |
| 7 ⚠ | Novel PTPRD-ALK fusion | **LIMITATION** | KG coverage gap — novel entities invisible to graph |
| 8 🔗 | KG→VectorDB cross-reference trace (P001) | **ARCHITECTURE** | Shows chunk_id pointers, targeted fetch, score fusion |

**Q8 explicitly teaches:** KG Trial node → `chunk_ids` property → `VectorChunkStore.get_by_ids()` → protocol prose → LLM. Graph-excluded trials (T002, T005) produce zero chunks — they cannot re-enter via the vector path.

---

## Demo Notes

### The Conversation to Have

**Ask after Stage 0 (naive vector):** *"This patient has EGFR del19. Why is T001 dangerous to return?"*
→ Expected insight: T001 explicitly excludes EGFR-mutant patients. Returning it wastes the patient's time and may crowd out the correct trial.

**Ask after Stage 2 (graph only):** *"What does Graph-Only miss that the text captures?"*
→ Expected insight: Eligibility nuances in free text (e.g., "patients with stable, treated brain metastases may be eligible at investigator discretion") are not in the graph edges.

**Ask after Stage 3 (hybrid):** *"Why is F1 still not 1.0?"*
→ Expected insight: Evaluation QA pairs include multi-hop questions where path length limits confidence; some trials have site IDs that don't exist in Maharashtra even though the disease matches.

**The key demonstration:** Show Q1 (NSCLC EGFR WT Maharashtra) in verbose mode. Print the vector scores for T001 AND T002. Both are >0.85. Then run graph traversal — T002 disappears immediately. This is the "aha" moment.


## References

- [Neo4j AuraDB Free Tier](https://neo4j.com/cloud/platform/aura-graph-database/)
- [Microsoft GraphRAG](https://github.com/microsoft/graphrag)
- [NVIDIA NeMo Guardrails](https://github.com/NVIDIA/NeMo-Guardrails)
- [LangChain Neo4j Integration](https://python.langchain.com/docs/integrations/graphs/neo4j_cypher)
- [ClinicalTrials.gov API](https://clinicaltrials.gov/data-api/api)
- [UMLS Clinical Entity Ontology](https://uts.nlm.nih.gov/)
- [LangGraph for Multi-Agent Orchestration](https://langchain-ai.github.io/langgraph/)

---

*CitiusTech Gen AI & Agentic AI Training Program —  Project 2 of 5*
