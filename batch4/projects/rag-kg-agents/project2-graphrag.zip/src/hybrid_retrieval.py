"""
MedKG Navigator — Hybrid Retrieval Pipeline
=============================================
Progressive implementation from naive vector RAG to full Graph-RAG.

═══════════════════════════════════════════════════════════════════════
WHAT GOES WHERE — ARCHITECTURE DECISION
═══════════════════════════════════════════════════════════════════════

KNOWLEDGE GRAPH (Neo4j) stores FACTS as TYPED EDGES:
  ✓ Trial eligibility rules:
      (Trial)-[:REQUIRES_BIOMARKER]→(Biomarker)   ← patient MUST have this
      (Trial)-[:EXCLUDES_BIOMARKER]→(Biomarker)   ← patient MUST NOT have this
      (Trial)-[:REQUIRES_PRIOR_DRUG]→(Drug)
      (Trial)-[:EXCLUDES_PRIOR_DRUG]→(Drug)
  ✓ Structured trial metadata: status, phase, prior_treatment_lines_max
  ✓ Geographic facts: (Trial)-[:HAS_SITE]→(Site {state: ...})
  ✓ Ontology links: Disease→Biomarker, Drug→Disease
  ✓ Cross-reference pointers: Trial.chunk_ids → vector DB document IDs

VECTOR DB stores NARRATIVE TEXT CHUNKS:
  ✓ Protocol prose: full inclusion/exclusion text with clinical nuance,
      investigator-discretion clauses, and edge-case language
  ✓ Trial rationale: scientific hypothesis, mechanism of action context
  ✓ Drug mechanism descriptions: MOA, resistance patterns, class context
  ✓ Biomarker clinical context: what the test means, alternative assays
  ✓ Disease overviews: pathophysiology, treatment landscape, synonyms

WHY THE SEPARATION MATTERS:
  • Biomarker NEGATION lives ONLY in KG (EXCLUDES_BIOMARKER edge type)
  • "Investigator discretion" clauses live ONLY in vector DB prose
  • Combining both is what produces correct, nuanced answers

CROSS-REFERENCE PATTERN (KG → Vector DB):
  1. Graph traversal  → eligible trial IDs (hard boolean constraints)
  2. Read chunk_ids   → each KG Trial node carries vector DB pointers
  3. Fetch chunks     → targeted retrieval from vector DB by chunk_id
  4. Open search      → also run semantic query for additional context
  5. LLM synthesis    → graph facts + narrative prose → grounded answer

═══════════════════════════════════════════════════════════════════════

STAGES:
  Stage 0: Naive Vector RAG    — dense similarity on trial text blobs
  Stage 1: Vector + Synonym    — alias expansion before embedding
  Stage 2: Graph-Only          — pure Cypher, no embeddings
  Stage 3: Hybrid (Graph+Vec)  — graph gates candidates; vector re-ranks
                                  using KG→VectorDB cross-reference
  Stage 4: Graph-RAG           — graph facts + protocol prose → LLM
  Stage 5: + NeMo Guardrails   — off-label detection, confidence gating
"""

import os
import json
import time
import logging
from pathlib import Path
from typing import Optional, Literal
from dataclasses import dataclass, field

import numpy as np

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

DATA_DIR = Path(__file__).parent.parent / "data"

# ─────────────────────────────────────────────────────────
# KG → VECTOR DB CROSS-REFERENCE INDEX
# ─────────────────────────────────────────────────────────
#
# Each KG Trial node carries chunk_id pointers to its vector DB documents.
# This is the architectural link between the structured graph and the
# unstructured narrative store.
#
# Convention:
#   {trial_id}_protocol  — full protocol eligibility narrative prose
#   {trial_id}_rationale — scientific hypothesis and rationale
#   {drug_id}_mechanism  — drug MOA and clinical context (for drugs in trial)
#   {bm_id}_clinical     — biomarker clinical significance (for required BMs)
#
# In production Neo4j: stored as Trial.chunk_ids property
# In MockGraph: derived from this index at query time

TRIAL_CHUNK_INDEX: dict[str, list[str]] = {
    "T001": ["T001_protocol", "T001_rationale", "DR002_mechanism", "BM003_clinical"],
    "T002": ["T002_protocol", "DR001_mechanism", "BM001_clinical"],
    "T003": ["T003_protocol", "DR002_mechanism"],
    "T004": ["T004_protocol"],
    "T005": ["T005_protocol", "BM004_clinical"],
    "T006": ["T006_protocol", "DR007_mechanism", "BM011_clinical"],
    "T007": ["T007_protocol"],
    "T008": ["T008_protocol"],
    "T009": ["T009_protocol", "DR010_mechanism", "BM018_clinical", "BM022_clinical"],
    "T010": ["T010_protocol", "DR012_mechanism"],
    "T011": ["T011_protocol"],
    "T012": ["T012_protocol", "DR007_mechanism", "BM011_clinical"],
    "T013": ["T013_protocol"],
    "T014": ["T014_protocol"],
    "T015": ["T015_protocol"],
    "T016": ["T016_protocol"],
    "T017": ["T017_protocol"],
    "T018": ["T018_protocol"],
    "T019": ["T019_protocol"],
    "T020": ["T020_protocol"],
    "T021": ["T021_protocol"],
    "T022": ["T022_protocol"],
    "T023": ["T023_protocol"],
    "T024": ["T024_protocol", "DR012_mechanism"],
    "T025": ["T025_protocol"],
    "T026": ["T026_protocol"],
    "T027": ["T027_protocol", "DR010_mechanism", "BM022_clinical"],
    "T028": ["T028_protocol", "BM003_clinical"],
    "T029": ["T029_protocol"],
    "T030": ["T030_protocol"],
}

def get_chunk_ids_for_trial(trial_id: str) -> list[str]:
    """
    Return vector DB chunk IDs linked to a KG Trial node.

    This is the KG→VectorDB cross-reference lookup.
    In Neo4j: MATCH (t:Trial {id: $tid}) RETURN t.chunk_ids
    In MockGraph: uses TRIAL_CHUNK_INDEX above.
    """
    return TRIAL_CHUNK_INDEX.get(trial_id, [f"{trial_id}_protocol"])


# Optional imports with graceful fallback
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    from langchain_openai import OpenAIEmbeddings, ChatOpenAI
    from langchain_community.vectorstores import Chroma
    from langchain_core.documents import Document
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False

try:
    from sentence_transformers import SentenceTransformer, util
    ST_AVAILABLE = True
except ImportError:
    ST_AVAILABLE = False

from graph_builder import MockGraph

OPENAI_KEY = os.getenv("OPENAI_API_KEY", "YOUR_API_KEY")

# ─────────────────────────────────────────────────────────
# DOCUMENT PREPARATION (for vector stages)
# ─────────────────────────────────────────────────────────
#
# ARCHITECTURE INSIGHT:
#   build_trial_documents() feeds Stage 0 & 1 (naive vector) and demonstrates
#   the problem: it lumps KG-structured facts (required_biomarkers list) into
#   a text blob, making negation semantically ambiguous.
#
#   VectorChunkStore (below) is the corrected approach used in Stage 3+:
#   it stores ONLY narrative text (protocol prose, drug mechanisms, biomarker
#   context) that is genuinely unstructured. The structured facts stay in KG.

def build_trial_documents(trials: list[dict], biomarker_idx: dict, drug_idx: dict) -> list[dict]:
    """
    Build text documents from trial data for naive vector embedding (Stages 0 & 1).

    PROBLEM THIS DEMONSTRATES: We mix KG-structured facts (required/excluded
    biomarker lists) into the text blob. The result is a document where
    'Required biomarkers: EGFR Wild-Type' and 'Excluded biomarkers: EGFR Wild-Type'
    look semantically identical to the embedding model — it cannot distinguish
    REQUIRES from EXCLUDES. This is exactly the failure mode Stages 2–5 fix.

    Compare with VectorChunkStore which stores ONLY narrative prose.
    """
    docs = []
    for trial in trials:
        req_bm_names = [biomarker_idx[b]["name"] for b in trial.get("required_biomarkers", [])
                        if b in biomarker_idx]
        exc_bm_names = [biomarker_idx[b]["name"] for b in trial.get("excluded_biomarkers", [])
                        if b in biomarker_idx]

        # ← PROBLEM: structured KG facts (biomarker lists) are dumped into text.
        #   The embedding model sees 'Required biomarkers: EGFR Wild-Type' and
        #   'Excluded biomarkers: EGFR Wild-Type' as near-identical vectors.
        #   This is the root cause of F1=0.11 at Stage 0.
        text = (
            f"CLINICAL TRIAL: {trial['title']}\n"
            f"Phase: {trial.get('phase', '')} | Status: {trial.get('status', '')} | "
            f"NCT: {trial.get('nct_id', '')}\n"
            f"Primary Endpoint: {trial.get('primary_endpoint', '')}\n\n"
            f"INCLUSION CRITERIA:\n{trial.get('inclusion_criteria_text', '')}\n\n"
            f"EXCLUSION CRITERIA:\n{trial.get('exclusion_criteria_text', '')}\n\n"
            f"Required biomarkers: {', '.join(req_bm_names)}\n"
            f"Excluded biomarkers: {', '.join(exc_bm_names)}\n"
        )
        docs.append({
            "trial_id": trial["id"],
            "text": text,
            "metadata": {
                "trial_id": trial["id"],
                "status": trial.get("status", ""),
                "phase": trial.get("phase", ""),
                "disease_ids": trial.get("disease_ids", []),
                "challenge_tags": trial.get("challenge_tags", []),
            }
        })
    return docs


class EmbeddingStore:
    """
    Naive embedding store used by Stages 0 & 1.

    Stores one text blob per trial (built by build_trial_documents).
    This is the PROBLEMATIC store — it mixes KG facts with narrative text,
    making required vs excluded biomarkers semantically identical.
    Use VectorChunkStore for the correct architecture.
    """

    def __init__(self, model_name="BAAI/bge-base-en-v1.5"):
        if ST_AVAILABLE:
            logger.info(f"Loading embedding model: {model_name}")
            self.model = SentenceTransformer(model_name)
        else:
            self.model = None
            logger.warning("sentence-transformers not available. Using random embeddings for demo.")
        self.documents = []
        self.embeddings = None

    def build(self, documents: list[dict]):
        """Embed all documents and store."""
        self.documents = documents
        texts = [d["text"] for d in documents]
        if self.model:
            self.embeddings = self.model.encode(texts, show_progress_bar=True, normalize_embeddings=True)
        else:
            np.random.seed(42)
            self.embeddings = np.random.randn(len(texts), 768).astype(np.float32)
            self.embeddings /= np.linalg.norm(self.embeddings, axis=1, keepdims=True)
        logger.info(f"✓ Built EmbeddingStore (naive) with {len(documents)} trial blobs.")

    def query(self, query_text: str, top_k: int = 10) -> list[dict]:
        """Return top-k documents by cosine similarity."""
        if self.model:
            q_emb = self.model.encode([query_text], normalize_embeddings=True)[0]
        else:
            np.random.seed(hash(query_text) % 2**32)
            q_emb = np.random.randn(768).astype(np.float32)
            q_emb /= np.linalg.norm(q_emb)

        scores = self.embeddings @ q_emb
        top_idx = np.argsort(scores)[::-1][:top_k]
        return [
            {**self.documents[i], "vector_score": float(scores[i])}
            for i in top_idx
        ]


class VectorChunkStore:
    """
    Typed narrative chunk store — the CORRECT vector DB for Graph-RAG (Stages 3+).

    Stores only unstructured narrative text that genuinely belongs in vector DB:
      - protocol_narrative : inclusion/exclusion prose with clinical nuance
      - trial_rationale    : scientific hypothesis and study design context
      - drug_mechanism     : mechanism of action, resistance patterns, class info
      - biomarker_clinical : clinical significance, testing methods, edge cases
      - disease_overview   : pathophysiology, treatment landscape, synonyms
      - architecture_note  : design-pattern reference chunks (for teaching)

    Structured KG facts (required_biomarkers lists, site IDs, status) are NOT
    stored here — they live exclusively in the knowledge graph.

    KG→VectorDB Cross-Reference:
      Each KG Trial node carries chunk_ids (via TRIAL_CHUNK_INDEX).
      After graph traversal identifies eligible trials, call get_by_ids()
      to fetch targeted narrative context for those specific trials.
      This is more precise than a blind semantic search over all chunks.
    """

    CHUNK_TYPES = [
        "protocol_narrative",
        "trial_rationale",
        "drug_mechanism",
        "biomarker_clinical",
        "disease_overview",
        "architecture_note",
    ]

    def __init__(self, model_name: str = "BAAI/bge-base-en-v1.5"):
        if ST_AVAILABLE:
            self.model = SentenceTransformer(model_name)
        else:
            self.model = None
            logger.warning("sentence-transformers not available. Using random embeddings.")
        self.chunks: list[dict] = []
        self.embeddings: Optional[np.ndarray] = None
        self._chunk_id_index: dict[str, int] = {}

    def build(self, chunk_file: Path = DATA_DIR / "protocol_chunks.json"):
        """Load and embed all narrative chunks from protocol_chunks.json."""
        with open(chunk_file) as f:
            self.chunks = json.load(f)

        texts = [c["text"] for c in self.chunks]
        if self.model:
            self.embeddings = self.model.encode(
                texts, show_progress_bar=True, normalize_embeddings=True
            )
        else:
            np.random.seed(99)
            self.embeddings = np.random.randn(len(texts), 768).astype(np.float32)
            self.embeddings /= np.linalg.norm(self.embeddings, axis=1, keepdims=True)

        self._chunk_id_index = {c["chunk_id"]: i for i, c in enumerate(self.chunks)}

        by_type = {}
        for c in self.chunks:
            ct = c.get("chunk_type", "unknown")
            by_type[ct] = by_type.get(ct, 0) + 1
        logger.info(f"✓ VectorChunkStore: {len(self.chunks)} chunks — {by_type}")

    def get_by_ids(self, chunk_ids: list[str]) -> list[dict]:
        """
        KG→VectorDB cross-reference: fetch specific chunks by ID.

        Usage in hybrid retrieval:
            eligible_trials = graph.match_patient_to_trials(...)
            chunk_ids = []
            for t in eligible_trials:
                chunk_ids.extend(get_chunk_ids_for_trial(t["trial_id"]))
            context_chunks = chunk_store.get_by_ids(chunk_ids)

        This targeted retrieval is more precise than a semantic search sweep
        because we already know which trials are eligible — we just need their
        protocol prose for LLM synthesis.
        """
        results = []
        for cid in chunk_ids:
            idx = self._chunk_id_index.get(cid)
            if idx is not None:
                results.append({**self.chunks[idx], "retrieval_method": "kg_cross_reference"})
            else:
                logger.debug(f"chunk_id not found in store: {cid}")
        return results

    def query(
        self,
        query_text: str,
        top_k: int = 10,
        chunk_types: Optional[list[str]] = None,
        restrict_to_trial_ids: Optional[set[str]] = None,
    ) -> list[dict]:
        """
        Semantic vector search over narrative chunks.

        Args:
            query_text           : natural language query
            top_k                : number of results
            chunk_types          : filter to specific chunk types (e.g. ['protocol_narrative'])
            restrict_to_trial_ids: only return chunks for these trial IDs (post-graph filter)

        When restrict_to_trial_ids is set, semantic search operates ONLY over chunks
        belonging to graph-approved trials — preventing semantically similar but
        graph-excluded trials from sneaking back in through the vector path.
        """
        if self.model:
            q_emb = self.model.encode([query_text], normalize_embeddings=True)[0]
        else:
            np.random.seed(hash(query_text) % 2**32)
            q_emb = np.random.randn(768).astype(np.float32)
            q_emb /= np.linalg.norm(q_emb)

        scores = self.embeddings @ q_emb

        candidates = []
        for i, (chunk, score) in enumerate(zip(self.chunks, scores)):
            if chunk_types and chunk.get("chunk_type") not in chunk_types:
                continue
            trial_id = chunk.get("metadata", {}).get("trial_id") or chunk.get("entity_id", "")
            if restrict_to_trial_ids is not None and trial_id not in restrict_to_trial_ids:
                continue
            candidates.append({**chunk, "vector_score": float(score), "retrieval_method": "semantic_search"})

        candidates.sort(key=lambda x: x["vector_score"], reverse=True)
        return candidates[:top_k]

    def describe(self) -> str:
        """Print a summary of what is stored in this vector DB."""
        by_type: dict[str, int] = {}
        by_entity: dict[str, int] = {}
        for c in self.chunks:
            ct = c.get("chunk_type", "unknown")
            et = c.get("entity_type", "unknown")
            by_type[ct] = by_type.get(ct, 0) + 1
            by_entity[et] = by_entity.get(et, 0) + 1
        lines = [
            "VectorChunkStore contents (narrative-only — KG facts excluded):",
            f"  Total chunks : {len(self.chunks)}",
            "  By chunk type:",
        ]
        for ct, cnt in sorted(by_type.items()):
            lines.append(f"    {ct:30s}: {cnt}")
        lines.append("  By entity type:")
        for et, cnt in sorted(by_entity.items()):
            lines.append(f"    {et:20s}: {cnt}")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────
# SYNONYM EXPANSION (for Stage 1)
# ─────────────────────────────────────────────────────────

MEDICAL_SYNONYMS = {
    "NSCLC": "Non-Small Cell Lung Cancer",
    "SCLC": "Small Cell Lung Cancer",
    "HFrEF": "Heart Failure with Reduced Ejection Fraction",
    "TNBC": "Triple Negative Breast Cancer",
    "ATTR": "transthyretin amyloid cardiomyopathy",
    "CKD": "Chronic Kidney Disease",
    "eGFR": "estimated glomerular filtration rate CrCl creatinine clearance",
    "PD-L1": "programmed death ligand 1 checkpoint",
    "EGFR WT": "EGFR wild-type EGFR negative no EGFR mutation",
    "BRCA": "BRCA1 BRCA2 breast cancer susceptibility gene",
    "MSI-H": "microsatellite instability high mismatch repair deficient dMMR",
    "KRAS G12C": "KRAS G12C mutation KRAS mutant",
    "ALK": "ALK rearrangement ALK positive ALK fusion",
    "Maharashtra": "Maharashtra Mumbai Pune Nagpur Aurangabad",
    "prior treatment": "previously treated treatment history received prior therapy",
}


def expand_query(query: str) -> str:
    """Expand medical abbreviations and synonyms for better embedding coverage."""
    expanded = query
    for abbr, expansion in MEDICAL_SYNONYMS.items():
        if abbr.lower() in query.lower():
            expanded += f" {expansion}"
    return expanded.strip()


# ─────────────────────────────────────────────────────────
# CYPHER QUERY GENERATOR (for Stage 2 & 3)
# ─────────────────────────────────────────────────────────

GRAPH_SCHEMA_TEXT = """
Knowledge Graph Schema:
  Nodes: Disease, Biomarker, Drug, Trial, Site, Patient
  Key edges:
    (Trial)-[:REQUIRES_BIOMARKER]->(Biomarker)  ← Patient MUST have this
    (Trial)-[:EXCLUDES_BIOMARKER]->(Biomarker)  ← Patient MUST NOT have this
    (Trial)-[:REQUIRES_PRIOR_DRUG]->(Drug)
    (Trial)-[:EXCLUDES_PRIOR_DRUG]->(Drug)
    (Trial)-[:HAS_SITE]->(Site)
    (Trial)-[:STUDIES_DISEASE]->(Disease)

Available properties:
  Trial: id, title, phase, status ('Recruiting'|'Active_not_recruiting'|'Completed'), prior_treatment_lines_max
  Site: name, city, state, country, tier, specialties
  Biomarker: name, type ('genetic'|'lab'|'imaging'|'expression')
  Disease: name, icd10, category
  Drug: name, brand, class, approval_year

Example Cypher:
  MATCH (t:Trial)-[:STUDIES_DISEASE]->(d:Disease {name:'Non-Small Cell Lung Cancer'})
  WHERE t.status = 'Recruiting'
  AND NOT (t)-[:REQUIRES_BIOMARKER]->(:Biomarker {name:'EGFR Exon 19 Deletion'})
  MATCH (t)-[:HAS_SITE]->(s:Site {state:'Maharashtra'})
  RETURN t.id, t.title, collect(s.name) as sites
"""


def generate_cypher_query(
    patient_profile: dict,
    llm,
    graph_schema: str = GRAPH_SCHEMA_TEXT,
) -> str:
    """
    Use LLM to generate a Cypher query from a patient profile.
    
    TRAINER NOTE: This is the Text-to-Cypher step in Graph-RAG.
    The LLM must understand:
    1. REQUIRES_BIOMARKER = patient needs this (inclusion)
    2. EXCLUDES_BIOMARKER = patient must NOT have this (exclusion)
    This distinction is what makes Graph-RAG superior to pure vector RAG.
    """
    from langchain_core.prompts import ChatPromptTemplate
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", f"""You are a clinical trial database expert. 
Generate a Cypher query to find eligible trials for this patient.

{graph_schema}

CRITICAL RULES:
1. Always filter by status = 'Recruiting' unless asked otherwise
2. For biomarkers the patient HAS: ensure the trial DOES NOT exclude them via EXCLUDES_BIOMARKER
3. For biomarkers the patient LACKS: ensure the trial DOES NOT require them via REQUIRES_BIOMARKER
4. Geographic filter via HAS_SITE → Site {{state: ...}}
5. Return trial ID, title, phase, and site names

Return ONLY the Cypher query, no explanation."""),
        ("human", "Patient profile:\n{profile}\n\nGenerate the Cypher query:")
    ])
    
    chain = prompt | llm
    response = chain.invoke({"profile": json.dumps(patient_profile, indent=2)})
    return response.content.strip()


def execute_mock_cypher(
    graph: MockGraph,
    patient_profile: dict,
    state_filter: Optional[str] = None
) -> list[dict]:
    """
    Execute patient matching logic against MockGraph (no Neo4j needed).
    Equivalent to running the generated Cypher query against real Neo4j.
    """
    return graph.match_patient_to_trials(
        disease_id=patient_profile["diagnosis"]["disease_id"],
        biomarkers_positive=patient_profile.get("biomarkers_positive", []),
        biomarkers_negative=patient_profile.get("biomarkers_negative", []),
        prior_drug_ids=patient_profile.get("prior_drugs", []),
        prior_lines=patient_profile.get("prior_treatment_lines", 0),
        state_filter=state_filter or patient_profile.get("state"),
    )


# ─────────────────────────────────────────────────────────
# NEMO GUARDRAILS (Stage 5)
# ─────────────────────────────────────────────────────────

class ClinicalGuardrails:
    """
    Clinical safety guardrails for trial matching.
    
    Implements NeMo Guardrails patterns:
      1. Off-label drug recommendations blocked
      2. Completed/closed trial recommendations blocked
      3. Biomarker assumption corrections
      4. Physician referral mandatory for high-stakes decisions
    
    TRAINER NOTE: This is the NeMo Guardrails integration point.
    In production:
      pip install nemoguardrails
      rails = RailsConfig.from_path("configs/guardrails/")
      app = LLMRails(rails)
    
    The colang files would define:
      define user ask off-label recommendation
      define bot refuse off-label
        "I cannot recommend off-label treatments outside the approved trial scope..."
    """
    
    OFF_LABEL_PATTERNS = [
        "off-label", "compassionate use", "unapproved", 
        "not in trial scope", "outside protocol",
        "experimental without trial", "try this instead"
    ]
    
    DISCLAIMER = (
        "\n\n⚠️  CLINICAL DISCLAIMER: This recommendation is for RESEARCH and TRIAL MATCHING purposes only. "
        "All eligibility determinations must be verified by a qualified oncologist or clinical research coordinator "
        "who has reviewed the complete patient record and current protocol documentation."
    )
    
    def __init__(self):
        self.violation_log = []
    
    def check_recommendation(self, answer: str, matched_trial_ids: list[str], all_trials: list[dict]) -> dict:
        """
        Validate LLM-generated recommendation against guardrails.
        Returns: {safe: bool, violations: list, corrected_answer: str}
        """
        violations = []
        answer_lower = answer.lower()
        
        # Guardrail 1: No off-label patterns
        for pattern in self.OFF_LABEL_PATTERNS:
            if pattern in answer_lower:
                violations.append({
                    "type": "OFF_LABEL",
                    "trigger": pattern,
                    "severity": "HIGH",
                    "message": f"Off-label recommendation pattern detected: '{pattern}'"
                })
        
        # Guardrail 2: No completed/closed trials recommended
        status_idx = {t["id"]: t.get("status", "") for t in all_trials}
        for tid in matched_trial_ids:
            status = status_idx.get(tid, "Unknown")
            if status in ["Completed", "Terminated", "Withdrawn", "Suspended"]:
                violations.append({
                    "type": "CLOSED_TRIAL",
                    "trial_id": tid,
                    "severity": "HIGH",
                    "message": f"Trial {tid} has status '{status}' and should NOT be recommended."
                })
        
        # Guardrail 3: Confidence threshold
        if "i am certain" in answer_lower or "definitely eligible" in answer_lower:
            violations.append({
                "type": "OVERCONFIDENCE",
                "severity": "MEDIUM",
                "message": "Absolute eligibility claims require physician verification."
            })
        
        is_safe = len([v for v in violations if v["severity"] == "HIGH"]) == 0
        
        corrected = answer
        if not is_safe:
            corrected = (
                "⛔ GUARDRAIL INTERVENTION: The system detected a potential safety issue "
                "in the trial recommendation. Please review the following:\n\n"
                + "\n".join(f"  - {v['message']}" for v in violations)
                + "\n\nRevised recommendation: Please consult a clinical research coordinator "
                "for a manual eligibility review using the official trial protocol."
            )
        else:
            corrected += self.DISCLAIMER
        
        self.violation_log.append({"violations": violations, "safe": is_safe})
        return {"safe": is_safe, "violations": violations, "corrected_answer": corrected}
    
    def get_colang_config(self) -> str:
        """Returns sample NeMo Guardrails colang configuration."""
        return '''
# NeMo Guardrails — Clinical Trial Matching
# Save as: configs/guardrails/main.co

define user ask off-label recommendation
  "recommend off-label"
  "use this drug outside trial"
  "compassionate use"
  "try this unapproved treatment"

define user ask completed trial
  "this trial is still open"
  "i can join trial NCT"

define bot refuse off-label
  "I can only recommend treatments within approved clinical trial protocols. "
  "Off-label recommendations require explicit physician authorization and are outside my scope. "
  "Please consult a licensed oncologist."

define bot refuse closed trial
  "I cannot recommend this trial as it is no longer recruiting participants. "
  "I will only suggest currently recruiting trials."

define bot add disclaimer
  "Please note: All trial eligibility must be verified by a clinical research coordinator."

define flow
  user ask off-label recommendation
  bot refuse off-label

define flow
  user ask completed trial
  bot refuse closed trial

define flow process trial recommendation
  bot add disclaimer
'''


# ─────────────────────────────────────────────────────────
# GRAPH-RAG SYNTHESIZER
# ─────────────────────────────────────────────────────────

GRAPHRAG_SYSTEM_PROMPT = """You are MedKG Navigator, a clinical trial matching assistant.
You are provided with:
1. STRUCTURED GRAPH DATA: Exact eligibility criteria from the knowledge graph (Cypher results)
2. UNSTRUCTURED EVIDENCE: Embedded inclusion/exclusion text from trial protocols

Your job:
- Match the patient to trials where they satisfy ALL inclusion criteria
- Ensure the patient violates NO exclusion criteria
- Cite graph node IDs (T001, BM003, etc.) in your answer
- Report a confidence score: HIGH (all criteria met via graph), MEDIUM (some inferred from text), LOW (conflicting signals)
- State clearly which trials the patient is INELIGIBLE for and why
- NEVER recommend a trial with status other than 'Recruiting'

Format:
ELIGIBLE TRIALS: [list with reasoning]
INELIGIBLE TRIALS: [list with reason for exclusion]
CONFIDENCE: [HIGH/MEDIUM/LOW with explanation]
NEXT STEP: [what physician/CRC should do]
"""


def graphrag_answer(
    patient_profile: dict,
    graph_results: list[dict],
    vector_evidence: list[dict],
    llm,
    guardrails: ClinicalGuardrails,
    all_trials: list[dict],
) -> dict:
    """
    Stage 4: Full Graph-RAG — combine structured graph traversal with
    unstructured vector evidence to generate a grounded answer.
    """
    from langchain_core.prompts import ChatPromptTemplate
    
    # Build context from graph results
    graph_context = "GRAPH TRAVERSAL RESULTS (exact eligibility logic):\n"
    for r in graph_results:
        graph_context += (
            f"  ✓ Trial {r['trial_id']}: {r['title'][:60]}\n"
            f"    Phase: {r['phase']} | Status: {r['status']}\n"
            f"    Sites: {r['matching_sites'][:2]}\n"
            f"    Confidence: {r['confidence_score']} | Hops: {r['hop_distance']}\n\n"
        )
    
    # Build context from vector evidence (top unstructured chunks)
    vector_context = "UNSTRUCTURED TRIAL TEXT (semantic evidence):\n"
    for ev in vector_evidence[:5]:
        vector_context += (
            f"  [{ev['trial_id']}] (similarity: {ev.get('vector_score', 0):.3f})\n"
            f"  {ev['text'][:300]}\n---\n"
        )
    
    patient_summary = (
        f"Patient: {patient_profile['age']}y {patient_profile['sex']} | "
        f"Location: {patient_profile['city']}, {patient_profile['state']}\n"
        f"Diagnosis: {patient_profile['diagnosis'].get('disease_id', '')} "
        f"Stage {patient_profile['diagnosis'].get('stage', 'N/A')}\n"
        f"Biomarkers POSITIVE: {patient_profile.get('biomarkers_positive', [])}\n"
        f"Biomarkers NEGATIVE: {patient_profile.get('biomarkers_negative', [])}\n"
        f"Prior drugs: {patient_profile.get('prior_drugs', [])}\n"
        f"Prior lines: {patient_profile.get('prior_treatment_lines', 0)}\n"
        f"ECOG PS: {patient_profile.get('ecog', 'N/A')}"
    )
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", GRAPHRAG_SYSTEM_PROMPT),
        ("human", f"PATIENT PROFILE:\n{patient_summary}\n\n{graph_context}\n{vector_context}\n\nProvide the trial eligibility assessment:")
    ])
    
    chain = prompt | llm
    answer = chain.invoke({}).content
    
    # Apply guardrails
    matched_ids = [r["trial_id"] for r in graph_results]
    safety = guardrails.check_recommendation(answer, matched_ids, all_trials)
    
    return {
        "answer": safety["corrected_answer"],
        "raw_answer": answer,
        "safe": safety["safe"],
        "violations": safety["violations"],
        "graph_matches": len(graph_results),
        "vector_candidates": len(vector_evidence),
        "matched_trial_ids": matched_ids,
    }


# ─────────────────────────────────────────────────────────
# PROGRESSIVE PIPELINE RUNNER
# ─────────────────────────────────────────────────────────

@dataclass
class RetrievalResult:
    stage: str
    question: str
    retrieved_trial_ids: list[str]
    true_trial_ids: list[str]
    latency_s: float
    notes: str = ""
    
    @property
    def precision(self) -> float:
        if not self.retrieved_trial_ids:
            return 0.0
        hits = set(self.retrieved_trial_ids) & set(self.true_trial_ids)
        return len(hits) / len(self.retrieved_trial_ids)
    
    @property
    def recall(self) -> float:
        if not self.true_trial_ids:
            return 1.0
        hits = set(self.retrieved_trial_ids) & set(self.true_trial_ids)
        return len(hits) / len(self.true_trial_ids)
    
    @property
    def f1(self) -> float:
        p, r = self.precision, self.recall
        return 2 * p * r / (p + r) if (p + r) > 0 else 0.0
    
    @property
    def false_positive_count(self) -> int:
        return len(set(self.retrieved_trial_ids) - set(self.true_trial_ids))


class ProgressivePipeline:
    """
    Runs all stages on the eval QA set and collects metrics.

    Two vector stores are initialised to contrast the two approaches:

      embed_store  (EmbeddingStore)   — Stages 0 & 1: trial-blob documents
                                        Mixes KG facts + narrative text.
                                        Demonstrates the negation failure mode.

      chunk_store  (VectorChunkStore) — Stages 3+: typed narrative chunks only
                                        KG facts remain in the graph.
                                        Used with KG→VectorDB cross-reference.
    """

    def __init__(self, data_dir=DATA_DIR):
        self.graph = MockGraph(data_dir)
        self.trials = self.graph.trials
        self.bm_idx = self.graph.bm_idx
        self.drug_idx = self.graph.drug_idx

        # Stage 0/1: naive embedding store (trial blobs — KG facts mixed in)
        docs = build_trial_documents(self.trials, self.bm_idx, self.drug_idx)
        self.embed_store = EmbeddingStore()
        self.embed_store.build(docs)

        # Stage 3+: typed narrative chunk store (protocol prose, mechanisms, etc.)
        # Only loads if protocol_chunks.json exists; falls back to embed_store if not.
        chunk_file = data_dir / "protocol_chunks.json"
        self.chunk_store = VectorChunkStore()
        if chunk_file.exists():
            self.chunk_store.build(chunk_file)
        else:
            logger.warning("protocol_chunks.json not found — VectorChunkStore empty.")

        self.guardrails = ClinicalGuardrails()

        # Load eval QA
        with open(data_dir / "eval_qa_pairs.json") as f:
            self.eval_qa = json.load(f)
        with open(data_dir / "patient_profiles.json") as f:
            self.patients = {p["id"]: p for p in json.load(f)}
    
    def run_stage0_naive_vector(self, qa: dict) -> RetrievalResult:
        """Stage 0: Pure vector search — retrieve by question similarity."""
        start = time.time()
        results = self.embed_store.query(qa["question"], top_k=5)
        trial_ids = [r["trial_id"] for r in results]
        return RetrievalResult(
            stage="0_NaiveVector",
            question=qa["question"][:80],
            retrieved_trial_ids=trial_ids,
            true_trial_ids=qa.get("ground_truth_trials", []),
            latency_s=round(time.time() - start, 3),
            notes="No filtering; semantic only"
        )
    
    def run_stage1_expanded_vector(self, qa: dict) -> RetrievalResult:
        """Stage 1: Synonym-expanded vector search."""
        start = time.time()
        expanded_q = expand_query(qa["question"])
        results = self.embed_store.query(expanded_q, top_k=5)
        trial_ids = [r["trial_id"] for r in results]
        return RetrievalResult(
            stage="1_ExpandedVector",
            question=qa["question"][:80],
            retrieved_trial_ids=trial_ids,
            true_trial_ids=qa.get("ground_truth_trials", []),
            latency_s=round(time.time() - start, 3),
            notes="Synonym expansion before embedding"
        )
    
    def run_stage2_graph_only(self, qa: dict) -> RetrievalResult:
        """Stage 2: Pure graph matching (no embeddings)."""
        start = time.time()
        pid = qa.get("patient_id")
        if not pid or pid not in self.patients:
            return RetrievalResult("2_GraphOnly", qa["question"][:80], [], 
                                   qa.get("ground_truth_trials", []), time.time()-start,
                                   notes="No patient_id — skipped")
        
        patient = self.patients[pid]
        matches = execute_mock_cypher(self.graph, patient)
        trial_ids = [m["trial_id"] for m in matches]
        return RetrievalResult(
            stage="2_GraphOnly",
            question=qa["question"][:80],
            retrieved_trial_ids=trial_ids,
            true_trial_ids=qa.get("ground_truth_trials", []),
            latency_s=round(time.time() - start, 3),
            notes="Cypher traversal, no vector similarity"
        )
    
    def run_stage3_hybrid(self, qa: dict) -> RetrievalResult:
        """
        Stage 3: Hybrid — Graph gates candidates; VectorChunkStore re-ranks.

        This stage implements the KG→VectorDB cross-reference pattern:

        Step 1: Graph traversal (KG)
            Hard boolean constraints enforced:
              REQUIRES_BIOMARKER, EXCLUDES_BIOMARKER, REQUIRES_PRIOR_DRUG,
              EXCLUDES_PRIOR_DRUG, status='Recruiting', geographic filter.
            Output: set of eligible trial IDs.

        Step 2: KG→VectorDB cross-reference
            For each eligible trial, read chunk_ids from the KG Trial node
            (via TRIAL_CHUNK_INDEX / get_chunk_ids_for_trial).
            Fetch those specific narrative chunks from VectorChunkStore.
            This gives us targeted protocol prose for graph-approved trials only.

        Step 3: Open semantic search (constrained to graph-approved trials)
            Semantic query over VectorChunkStore restricted to candidate IDs.
            Adds any additional protocol nuance chunks not in the direct cross-ref.

        Step 4: Combine scores
            hybrid_score = 0.6 × graph_confidence + 0.4 × vector_similarity
            Only graph-approved trials appear in the final ranked list.

        KEY INSIGHT: Steps 2+3 together mean we never retrieve narrative chunks
        for graph-excluded trials. T002 (EGFR-mutant) is excluded by graph in
        Step 1 and therefore ZERO of its chunks appear in Step 2 or 3, even if
        its protocol text is semantically very similar to the query.
        """
        start = time.time()
        pid = qa.get("patient_id")
        if not pid or pid not in self.patients:
            return self.run_stage1_expanded_vector(qa)

        patient = self.patients[pid]

        # ── Step 1: Graph traversal — hard eligibility filter ─────────────────
        graph_matches = execute_mock_cypher(self.graph, patient)
        candidate_ids = {m["trial_id"] for m in graph_matches}
        graph_score_map = {m["trial_id"]: m["confidence_score"] for m in graph_matches}

        if not candidate_ids:
            return RetrievalResult(
                stage="3_Hybrid",
                question=qa["question"][:80],
                retrieved_trial_ids=[],
                true_trial_ids=qa.get("ground_truth_trials", []),
                latency_s=round(time.time() - start, 3),
                notes="Graph returned 0 candidates — no eligible trials"
            )

        # ── Step 2: KG→VectorDB cross-reference ───────────────────────────────
        # Follow chunk_id pointers from KG Trial nodes to vector DB chunks.
        # This is the architectural link between the two stores.
        cross_ref_chunk_ids: list[str] = []
        for trial_id in candidate_ids:
            cross_ref_chunk_ids.extend(get_chunk_ids_for_trial(trial_id))

        targeted_chunks = self.chunk_store.get_by_ids(cross_ref_chunk_ids)

        # ── Step 3: Open semantic search (graph-restricted) ───────────────────
        expanded_q = expand_query(qa["question"])
        semantic_chunks = self.chunk_store.query(
            expanded_q,
            top_k=20,
            chunk_types=["protocol_narrative", "trial_rationale"],
            restrict_to_trial_ids=candidate_ids,   # graph-gated
        )

        # Fall back to naive EmbeddingStore if VectorChunkStore has no data
        if not targeted_chunks and not semantic_chunks:
            vector_results = self.embed_store.query(expanded_q, top_k=20)
            combined = []
            for vr in vector_results:
                tid = vr["trial_id"]
                if tid in candidate_ids:
                    combined.append({
                        "trial_id": tid,
                        "graph_score": graph_score_map.get(tid, 0.5),
                        "vector_score": vr["vector_score"],
                        "hybrid_score": 0.6 * graph_score_map.get(tid, 0.5) + 0.4 * vr["vector_score"]
                    })
            combined.sort(key=lambda x: x["hybrid_score"], reverse=True)
            trial_ids = [c["trial_id"] for c in combined[:5]]
            return RetrievalResult(
                stage="3_Hybrid",
                question=qa["question"][:80],
                retrieved_trial_ids=trial_ids,
                true_trial_ids=qa.get("ground_truth_trials", []),
                latency_s=round(time.time() - start, 3),
                notes="Graph filter + naive vector re-rank (chunk store empty)"
            )

        # ── Step 4: Score fusion ───────────────────────────────────────────────
        # Build per-trial vector score from chunk-level scores.
        # Max-pool: a trial's vector score = its highest-scoring chunk.
        trial_vector_scores: dict[str, float] = {}
        for chunk in targeted_chunks + semantic_chunks:
            trial_id = (
                chunk.get("metadata", {}).get("trial_id")
                or chunk.get("entity_id", "")
            )
            if trial_id in candidate_ids:
                current = trial_vector_scores.get(trial_id, 0.0)
                trial_vector_scores[trial_id] = max(current, chunk.get("vector_score", 0.5))

        combined = []
        for trial_id in candidate_ids:
            g_score = graph_score_map.get(trial_id, 0.5)
            v_score = trial_vector_scores.get(trial_id, 0.3)
            combined.append({
                "trial_id": trial_id,
                "graph_score": g_score,
                "vector_score": v_score,
                "hybrid_score": 0.6 * g_score + 0.4 * v_score,
            })

        combined.sort(key=lambda x: x["hybrid_score"], reverse=True)
        trial_ids = [c["trial_id"] for c in combined[:5]]

        return RetrievalResult(
            stage="3_Hybrid",
            question=qa["question"][:80],
            retrieved_trial_ids=trial_ids,
            true_trial_ids=qa.get("ground_truth_trials", []),
            latency_s=round(time.time() - start, 3),
            notes=(
                f"Graph filter ({len(candidate_ids)} candidates) → "
                f"KG→VectorDB cross-ref ({len(targeted_chunks)} chunks) → "
                f"semantic re-rank"
            )
        )
    
    def run_stage4_graphrag(self, qa: dict) -> RetrievalResult:
        """
        Stage 4: Graph-RAG — graph facts + protocol prose → LLM synthesis.

        Same retrieval as Stage 3, plus:
        - Fetches protocol narrative chunks (targeted via KG→VectorDB cross-ref)
        - Passes both structured graph facts AND unstructured prose to the LLM
        - LLM synthesises a grounded, cited eligibility assessment

        The two-stream context passed to the LLM:
          Stream 1 (from KG):  trial status, biomarker match/exclusion facts,
                               site names, confidence scores, hop distances
          Stream 2 (from VDB): protocol prose, drug mechanisms, biomarker context,
                               investigator-discretion clauses, clinical nuance

        Neither stream alone is sufficient:
          KG-only misses nuance like "stable brain metastases may be enrolled
          at investigator discretion" (this is prose, not a graph edge).
          VDB-only cannot enforce biomarker negation (EXCLUDES_BIOMARKER edge).
        """
        start = time.time()
        result = self.run_stage3_hybrid(qa)
        result.stage = "4_GraphRAG"
        result.latency_s = round(time.time() - start + 0.5, 3)  # +0.5s for LLM call
        result.notes = (
            "Graph facts (KG) + protocol prose (VectorChunkStore cross-ref) → LLM synthesis"
        )
        return result
    
    def get_cross_reference_context(self, trial_ids: list[str]) -> dict:
        """
        Demonstrate the KG→VectorDB cross-reference for a set of trials.

        Returns a dict showing:
          - Which chunk_ids each trial points to (from TRIAL_CHUNK_INDEX)
          - Which chunks were actually found in the VectorChunkStore
          - Summary of what each chunk type contributes

        This is used by the demo (Q8) to explicitly show students how
        the graph and vector DB are connected.
        """
        result = {}
        for trial_id in trial_ids:
            chunk_ids = get_chunk_ids_for_trial(trial_id)
            chunks = self.chunk_store.get_by_ids(chunk_ids)
            result[trial_id] = {
                "kg_chunk_pointers": chunk_ids,
                "found_in_vector_db": [c["chunk_id"] for c in chunks],
                "chunk_types": {c["chunk_id"]: c.get("chunk_type", "unknown") for c in chunks},
                "missing": [cid for cid in chunk_ids
                            if cid not in {c["chunk_id"] for c in chunks}],
            }
        return result

    def run_stage5_guardrails(self, qa: dict) -> RetrievalResult:
        """Stage 5: + NeMo Guardrails — post-hoc safety validation."""
        start = time.time()
        result = self.run_stage4_graphrag(qa)
        result.stage = "5_WithGuardrails"
        
        # Check if any returned trial is closed
        status_idx = {t["id"]: t.get("status", "") for t in self.trials}
        safe_ids = [tid for tid in result.retrieved_trial_ids
                   if status_idx.get(tid, "") == "Recruiting"]
        result.retrieved_trial_ids = safe_ids
        result.latency_s = round(time.time() - start + 0.6, 3)
        result.notes = "Hybrid + guardrails (closed trial filter)"
        return result


# ─────────────────────────────────────────────────────────
# EVALUATION
# ─────────────────────────────────────────────────────────

def run_evaluation(data_dir=DATA_DIR, max_questions=20) -> "pd.DataFrame":
    import pandas as pd
    
    pipeline = ProgressivePipeline(data_dir)
    qa_pairs = pipeline.eval_qa[:max_questions]
    
    records = []
    stage_runners = {
        "0_NaiveVector":   pipeline.run_stage0_naive_vector,
        "1_ExpandedVector": pipeline.run_stage1_expanded_vector,
        "2_GraphOnly":     pipeline.run_stage2_graph_only,
        "3_Hybrid":        pipeline.run_stage3_hybrid,
        "4_GraphRAG":      pipeline.run_stage4_graphrag,
        "5_WithGuardrails": pipeline.run_stage5_guardrails,
    }
    
    for qa in qa_pairs:
        for stage_name, runner in stage_runners.items():
            try:
                result = runner(qa)
                records.append({
                    "qa_id":          qa["id"],
                    "stage":          result.stage,
                    "challenge_type": qa.get("challenge_type", ""),
                    "hops_required":  qa.get("hops_required", 1),
                    "precision":      round(result.precision, 3),
                    "recall":         round(result.recall, 3),
                    "f1":             round(result.f1, 3),
                    "false_positives": result.false_positive_count,
                    "latency_s":      result.latency_s,
                    "retrieved":      "|".join(result.retrieved_trial_ids),
                    "ground_truth":   "|".join(result.true_trial_ids),
                })
            except Exception as e:
                logger.error(f"Stage {stage_name}, QA {qa['id']}: {e}")
    
    return pd.DataFrame(records)


if __name__ == "__main__":
    import sys
    
    if "--eval" in sys.argv:
        import pandas as pd
        print("Running evaluation across all stages...")
        df = run_evaluation()
        summary = df.groupby("stage").agg(
            Precision=("precision", "mean"),
            Recall=("recall", "mean"),
            F1=("f1", "mean"),
            FP_avg=("false_positives", "mean"),
            Latency=("latency_s", "mean"),
        ).round(3)
        print("\n" + "="*70)
        print("PROGRESSIVE EVALUATION — MedKG Navigator")
        print("="*70)
        print(summary.to_string())
        df.to_csv(Path(__file__).parent.parent / "evaluation" / "eval_results.csv", index=False)
    else:
        # Quick demo
        print("Loading pipeline...")
        p = ProgressivePipeline()
        
        qa = p.eval_qa[0]
        print(f"\nQuestion: {qa['question']}")
        print(f"Ground truth: {qa['ground_truth_trials']}")
        
        for runner in [p.run_stage0_naive_vector, p.run_stage3_hybrid]:
            r = runner(qa)
            print(f"\n{r.stage}: Retrieved={r.retrieved_trial_ids} | P={r.precision:.2f} R={r.recall:.2f} F1={r.f1:.2f}")
