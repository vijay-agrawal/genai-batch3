import os
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI

load_dotenv(Path(__file__).parent.parent / ".env")

prompt = 'who is the best bollywood star?'

# Demonstration of using AzureChatOpenAI
try:

    azure_chat_model = AzureChatOpenAI(
        # Use 'azure_endpoint' for the base URL
        azure_endpoint="https://genaitraining-azureopenai.openai.azure.com/",
        azure_deployment="gpt-4o-mini",    
        api_key="",
        api_version="2024-08-01-preview", # Or your preferred version
    )
    chat_response = azure_chat_model.invoke(
        [
            {"role": "system", "content": "You are a helpful assistant for general knowledge."},
            {"role": "user", "content": "What is the capital of France?"}
        ]
    )

    print("\nAzureChatOpenAI Response:")
    # Access .content directly from the response object
    print(chat_response.content.strip())

except Exception as e:
    print("Error using AzureChatOpenAI:", e)
