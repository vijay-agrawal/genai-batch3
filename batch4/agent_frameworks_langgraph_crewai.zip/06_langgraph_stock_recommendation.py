"""
Stock Recommendation Agent using LangGraph and Azure OpenAI.

Builds on the CrewAI version (05_crewai_stock_recommendation.py) to show the LangGraph
value proposition: explicit, inspectable control flow with conditional branching and cycles.

═══════════════════════════════════════════════════════════════════════════
KEY LANGGRAPH CONSTRUCTS DEMONSTRATED IN THIS FILE
═══════════════════════════════════════════════════════════════════════════

1. STATE  (TypedDict)
   ─────────────────
   A single typed dictionary (StockState) is the shared memory that flows
   through every node in the graph.  Every node receives the full state and
   returns only the keys it wants to update — LangGraph merges the changes.
   Compare with CrewAI where inter-agent data is passed implicitly via task
   context; here the data contract is explicit and type-checked.

2. NODES  (plain Python functions)
   ────────────────────────────────
   Each processing step is a regular function that accepts state and returns
   a dict of state updates.  Nodes have no hidden wiring — what they read and
   write is visible in the function signature and return value.
   Nodes in this demo:
     • search_node          – fetches live market data via Serper API
     • quality_check_node   – decides whether the search result is usable
     • sentiment_node       – classifies market sentiment (bullish/bearish/neutral)
     • bullish_node         – deep-dive analysis for a positive outlook
     • bearish_node         – deep-dive analysis for a negative/risk outlook
     • neutral_node         – balanced analysis when sentiment is mixed
     • summarize_node       – condenses findings into bullet points
     • recommend_node       – produces the final investment recommendation

3. CONDITIONAL EDGES  ← KEY LANGGRAPH VALUE PROPOSITION
   ──────────────────────────────────────────────────────
   add_conditional_edges(source, routing_fn, mapping) wires a node to
   different downstream nodes depending on runtime state.  The routing
   function inspects the state and returns a string key; the mapping
   translates that key to the actual target node.

   Two conditional edges appear in this graph:

   a) route_after_quality_check  — after fetching data, decides:
        • "retry"    → loop back to search_node (up to MAX_RETRIES times)
        • "continue" → proceed to sentiment analysis
      This demonstrates a CYCLE, which is impossible in CrewAI's linear
      sequential process but trivial in LangGraph.

   b) route_after_sentiment — after classifying sentiment, decides:
        • "bullish"  → bullish_node  (bull-case deep dive)
        • "bearish"  → bearish_node  (bear-case / risk deep dive)
        • "neutral"  → neutral_node  (balanced view)
      This demonstrates BRANCHING — different paths for different data,
      with each branch doing specialised work before rejoining at summarize.

4. COMPILE  (graph.compile())
   ───────────────────────────
   compile() validates the graph (no dangling edges, no unreachable nodes)
   and returns a Runnable.  The compiled graph can be invoked, streamed,
   or have a checkpointer attached for persistence / human-in-the-loop.

5. GRAPH VISUALISATION  (get_graph().draw_mermaid())
   ──────────────────────────────────────────────────
   LangGraph can print a Mermaid diagram of the compiled graph so you can
   see the exact topology — edges, branches, and cycles — before running it.

VALUE PROPOSITION vs CREWAI (05_crewai_stock_recommendation.py)
────────────────────────────────────────────────────────────────
• CrewAI: agents run in a fixed sequential order decided at design time.
  Adding a retry loop or a sentiment-based branch requires hacking around
  the framework.

• LangGraph: the control flow IS the graph.  Retries, branches, merges,
  and human-in-the-loop pauses are first-class primitives, making complex
  workflows easy to build, test, and visualise.
═══════════════════════════════════════════════════════════════════════════
"""

import os
import json
import requests
from pathlib import Path
from typing import TypedDict, Literal

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END


# ──────────────────────────────────────────────────────────────────────────────
# Environment setup (same pattern as azure_openai_basicapp.py)
# ──────────────────────────────────────────────────────────────────────────────

def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env in any parent directory.")
    exit(1)


PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

MAX_RETRIES = 2  # maximum search retries if data quality is poor


def validate_environment_variables():
    required = ["AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY",
                 "AZURE_OPENAI_MODEL_NAME", "SERPER_API_KEY"]
    missing = [v for v in required if not os.getenv(v)]
    if missing:
        print("ERROR: Missing required environment variables:")
        for v in missing:
            print(f"  - {v}")
        exit(1)
    print("✓ All required environment variables loaded.")


def build_llm() -> ChatOpenAI:
    """
    Build a LangChain ChatOpenAI client pointed at the Azure AI Foundry endpoint.
    The Foundry endpoint is OpenAI-compatible, so we use ChatOpenAI with a custom
    base_url rather than AzureChatOpenAI (which expects *.openai.azure.com).
    """
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    if endpoint.endswith("/responses"):
        endpoint = endpoint[: -len("/responses")]
    return ChatOpenAI(
        model=os.getenv("AZURE_OPENAI_MODEL_NAME"),
        base_url=endpoint,
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        temperature=0,
    )


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 1 — STATE
# A TypedDict is the single shared memory for the entire graph.
# Every node reads from it and returns a partial dict of updates.
# ──────────────────────────────────────────────────────────────────────────────

class StockState(TypedDict):
    entity_name: str                                          # input: company / ticker
    search_results: str                                       # raw text from Serper search
    data_sufficient: bool                                     # quality gate flag
    retry_count: int                                          # tracks search retry attempts
    sentiment: Literal["bullish", "bearish", "neutral", "unknown"]  # classified outlook
    analysis: str                                             # output of the sentiment branch
    summary: str                                              # condensed bullet points
    recommendation: str                                       # final buy/hold/avoid verdict


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 2 — NODES
# Each node is a plain function: (StockState) -> dict[str, Any]
# The returned dict contains only the keys this node wants to update.
# ──────────────────────────────────────────────────────────────────────────────

def search_node(state: StockState) -> dict:
    """Fetch live market news using the Serper API."""
    print(f"\n[search_node] Searching for: {state['entity_name']} "
          f"(attempt {state['retry_count'] + 1})")

    query = f"{state['entity_name']} stock market analysis India NSE BSE 2024"
    payload = json.dumps({"q": query, "num": 5})
    headers = {
        "X-API-KEY": os.getenv("SERPER_API_KEY"),
        "Content-Type": "application/json",
    }
    try:
        resp = requests.post("https://google.serper.dev/search",
                             headers=headers, data=payload, timeout=10)
        resp.raise_for_status()
        results = resp.json()

        snippets = []
        for item in results.get("organic", []):
            title = item.get("title", "")
            snippet = item.get("snippet", "")
            if title or snippet:
                snippets.append(f"• {title}: {snippet}")

        search_text = "\n".join(snippets) if snippets else ""
    except Exception as e:
        print(f"  [search_node] Search error: {e}")
        search_text = ""

    return {
        "search_results": search_text,
        "retry_count": state["retry_count"] + 1,
    }


def quality_check_node(state: StockState, llm: ChatOpenAI) -> dict:
    """
    Assess whether the search results contain enough financial information
    to proceed with analysis.  Sets data_sufficient = True/False.
    """
    print("[quality_check_node] Assessing data quality...")

    if not state["search_results"] or len(state["search_results"]) < 100:
        print("  → Insufficient data (too short or empty)")
        return {"data_sufficient": False}

    messages = [
        SystemMessage(content="You are a data quality analyst for financial research."),
        HumanMessage(content=(
            f"Does the following search result contain enough financial information "
            f"(news, prices, earnings, analyst opinions) about '{state['entity_name']}' "
            f"to perform a stock analysis?\n\n"
            f"{state['search_results']}\n\n"
            f"Reply with only YES or NO."
        )),
    ]
    response = llm.invoke(messages).content.strip().upper()
    sufficient = response.startswith("YES")
    print(f"  → Data sufficient: {sufficient}")
    return {"data_sufficient": sufficient}


def sentiment_node(state: StockState, llm: ChatOpenAI) -> dict:
    """
    Classify overall market sentiment from search results.
    Returns 'bullish', 'bearish', or 'neutral'.
    This output drives the CONDITIONAL EDGE that follows.
    """
    print("[sentiment_node] Classifying market sentiment...")

    messages = [
        SystemMessage(content="You are a financial sentiment analyst."),
        HumanMessage(content=(
            f"Based on the following market information about '{state['entity_name']}', "
            f"classify the overall investment sentiment as exactly one of: "
            f"BULLISH, BEARISH, or NEUTRAL.\n\n"
            f"{state['search_results']}\n\n"
            f"Reply with only the single word: BULLISH, BEARISH, or NEUTRAL."
        )),
    ]
    raw = llm.invoke(messages).content.strip().upper()
    if "BULLISH" in raw:
        sentiment = "bullish"
    elif "BEARISH" in raw:
        sentiment = "bearish"
    else:
        sentiment = "neutral"

    print(f"  → Sentiment: {sentiment}")
    return {"sentiment": sentiment}


def bullish_node(state: StockState, llm: ChatOpenAI) -> dict:
    """
    Specialised analysis node reached only when sentiment is BULLISH.
    Focuses on growth catalysts, upside targets, and momentum signals.
    """
    print("[bullish_node] Running bull-case analysis...")

    messages = [
        SystemMessage(content="You are a bullish equity research analyst focused on Indian markets."),
        HumanMessage(content=(
            f"The market sentiment for '{state['entity_name']}' is BULLISH.\n\n"
            f"Using this data:\n{state['search_results']}\n\n"
            f"Provide a concise bull-case analysis covering:\n"
            f"1. Key growth catalysts\n"
            f"2. Positive financial signals\n"
            f"3. Upside potential and target range\n"
            f"4. Risks that could invalidate the bull thesis"
        )),
    ]
    analysis = llm.invoke(messages).content.strip()
    return {"analysis": f"[BULL CASE]\n{analysis}"}


def bearish_node(state: StockState, llm: ChatOpenAI) -> dict:
    """
    Specialised analysis node reached only when sentiment is BEARISH.
    Focuses on downside risks, red flags, and capital preservation.
    """
    print("[bearish_node] Running bear-case analysis...")

    messages = [
        SystemMessage(content="You are a cautious risk analyst focused on Indian markets."),
        HumanMessage(content=(
            f"The market sentiment for '{state['entity_name']}' is BEARISH.\n\n"
            f"Using this data:\n{state['search_results']}\n\n"
            f"Provide a concise bear-case analysis covering:\n"
            f"1. Key downside risks and red flags\n"
            f"2. Weak or deteriorating financial signals\n"
            f"3. Downside target or potential loss range\n"
            f"4. Conditions that would reverse the bearish outlook"
        )),
    ]
    analysis = llm.invoke(messages).content.strip()
    return {"analysis": f"[BEAR CASE]\n{analysis}"}


def neutral_node(state: StockState, llm: ChatOpenAI) -> dict:
    """
    Specialised analysis node reached only when sentiment is NEUTRAL.
    Provides a balanced view and identifies what would tip the scales.
    """
    print("[neutral_node] Running balanced analysis...")

    messages = [
        SystemMessage(content="You are a balanced equity analyst focused on Indian markets."),
        HumanMessage(content=(
            f"The market sentiment for '{state['entity_name']}' is NEUTRAL.\n\n"
            f"Using this data:\n{state['search_results']}\n\n"
            f"Provide a balanced analysis covering:\n"
            f"1. Key strengths of the company\n"
            f"2. Key weaknesses or concerns\n"
            f"3. Catalysts that would make it a BUY\n"
            f"4. Triggers that would make it a SELL"
        )),
    ]
    analysis = llm.invoke(messages).content.strip()
    return {"analysis": f"[NEUTRAL / BALANCED]\n{analysis}"}


def summarize_node(state: StockState, llm: ChatOpenAI) -> dict:
    """Condense the branch analysis into clear bullet points."""
    print("[summarize_node] Summarizing findings...")

    messages = [
        SystemMessage(content="You are a financial summarizer. Write concise bullet points."),
        HumanMessage(content=(
            f"Summarize the following analysis of '{state['entity_name']}' "
            f"into 5-7 clear bullet points that a retail investor can act on:\n\n"
            f"{state['analysis']}"
        )),
    ]
    summary = llm.invoke(messages).content.strip()
    return {"summary": summary}


def recommend_node(state: StockState, llm: ChatOpenAI) -> dict:
    """Produce the final BUY / HOLD / AVOID verdict with reasoning."""
    print("[recommend_node] Generating final recommendation...")

    messages = [
        SystemMessage(content="You are a senior stock advisor at the National Stock Exchange of India."),
        HumanMessage(content=(
            f"Based on the following summary for '{state['entity_name']}', "
            f"give a final investment recommendation:\n\n"
            f"{state['summary']}\n\n"
            f"Structure your answer as:\n"
            f"VERDICT: BUY / HOLD / AVOID\n"
            f"Short-term outlook (1-3 months):\n"
            f"Long-term outlook (1-3 years):\n"
            f"Key risks:\n"
            f"Suggested action:"
        )),
    ]
    recommendation = llm.invoke(messages).content.strip()
    return {"recommendation": recommendation}


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 3 — CONDITIONAL EDGES (routing functions)
# These functions inspect the state and return a string key that LangGraph
# maps to the next node.  This is the heart of LangGraph's value proposition.
# ──────────────────────────────────────────────────────────────────────────────

def route_after_quality_check(state: StockState) -> Literal["retry", "continue"]:
    """
    CONDITIONAL EDGE #1 — after quality_check_node:

    Demonstrates a CYCLE: if data is poor and retries remain, loop back
    to search_node.  CrewAI's sequential process cannot do this natively.
    """
    if not state["data_sufficient"] and state["retry_count"] < MAX_RETRIES:
        print(f"  [router] Data insufficient — retrying (attempt {state['retry_count']})")
        return "retry"
    return "continue"


def route_after_sentiment(state: StockState) -> Literal["bullish", "bearish", "neutral"]:
    """
    CONDITIONAL EDGE #2 — after sentiment_node:

    Demonstrates BRANCHING: each sentiment value routes to a completely
    different specialised analysis node before rejoining at summarize_node.
    """
    print(f"  [router] Routing to {state['sentiment']}_node")
    return state["sentiment"]


# ──────────────────────────────────────────────────────────────────────────────
# CONSTRUCT 4 — GRAPH ASSEMBLY
# Wire nodes and edges together, then COMPILE to validate topology.
# ──────────────────────────────────────────────────────────────────────────────

def build_graph(llm: ChatOpenAI) -> "CompiledGraph":
    """
    Assemble the StateGraph, add nodes, wire edges (including conditional ones),
    and compile.  The returned compiled graph is the executable workflow.

    Graph topology:

        [START]
           │
           ▼
      search_node ◄─────────────────────────────────────┐
           │                                             │ (retry)
           ▼                                             │
    quality_check_node ──── route_after_quality_check ──┘
           │ (continue)
           ▼
      sentiment_node ──── route_after_sentiment ──► bullish_node ──┐
                                                ──► bearish_node ──┤
                                                ──► neutral_node ──┤
                                                                    │
                                                                    ▼
                                                             summarize_node
                                                                    │
                                                                    ▼
                                                             recommend_node
                                                                    │
                                                                    ▼
                                                                  [END]
    """
    # Bind the LLM into each node that needs it using lambdas so the node
    # signature still matches (state) -> dict as LangGraph expects.
    graph = StateGraph(StockState)

    graph.add_node("search_node",        lambda s: search_node(s))
    graph.add_node("quality_check_node", lambda s: quality_check_node(s, llm))
    graph.add_node("sentiment_node",     lambda s: sentiment_node(s, llm))
    graph.add_node("bullish_node",       lambda s: bullish_node(s, llm))
    graph.add_node("bearish_node",       lambda s: bearish_node(s, llm))
    graph.add_node("neutral_node",       lambda s: neutral_node(s, llm))
    graph.add_node("summarize_node",     lambda s: summarize_node(s, llm))
    graph.add_node("recommend_node",     lambda s: recommend_node(s, llm))

    # Entry point
    graph.set_entry_point("search_node")

    # Linear edge: search → quality check
    graph.add_edge("search_node", "quality_check_node")

    # CONDITIONAL EDGE #1 — cycle / retry loop
    graph.add_conditional_edges(
        "quality_check_node",
        route_after_quality_check,
        {
            "retry":    "search_node",      # loop back
            "continue": "sentiment_node",   # proceed
        },
    )

    # Linear edge: sentiment → sentiment classification
    # (no additional edge needed; sentiment_node is the next node after the
    #  "continue" branch above)

    # CONDITIONAL EDGE #2 — sentiment-based branching
    graph.add_conditional_edges(
        "sentiment_node",
        route_after_sentiment,
        {
            "bullish": "bullish_node",
            "bearish": "bearish_node",
            "neutral": "neutral_node",
        },
    )

    # All three branches converge at summarize_node
    graph.add_edge("bullish_node", "summarize_node")
    graph.add_edge("bearish_node", "summarize_node")
    graph.add_edge("neutral_node", "summarize_node")

    # Linear tail: summarize → recommend → END
    graph.add_edge("summarize_node", "recommend_node")
    graph.add_edge("recommend_node", END)

    # CONSTRUCT 4 — compile validates the graph and returns a Runnable
    return graph.compile()


# ──────────────────────────────────────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    validate_environment_variables()

    print("\n## Welcome to the LangGraph Stock Recommender")
    print("-----------------------------------------------")
    entity_name = input("Enter company or stock name (e.g. Tata Power): ").strip()
    if not entity_name:
        print("ERROR: No entity name provided.")
        exit(1)

    llm = build_llm()
    app = build_graph(llm)

    # CONSTRUCT 5 — visualise the compiled graph topology
    print("\n── Graph topology (Mermaid) ──")
    print(app.get_graph().draw_mermaid())
    print("─────────────────────────────\n")

    # Initial state — only required keys need values; others get defaults via TypedDict
    initial_state: StockState = {
        "entity_name":    entity_name,
        "search_results": "",
        "data_sufficient": False,
        "retry_count":    0,
        "sentiment":      "unknown",
        "analysis":       "",
        "summary":        "",
        "recommendation": "",
    }

    # invoke() runs the graph to completion and returns the final state
    final_state = app.invoke(initial_state)

    print("\n\n##########################################")
    print("##   Here is your Stock Recommendation   ##")
    print("##########################################\n")
    print(f"Sentiment detected: {final_state['sentiment'].upper()}\n")
    print(final_state["recommendation"])
