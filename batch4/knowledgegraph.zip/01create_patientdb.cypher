// =====================================================
// Neo4j demo dataset (clean + readable + best-practice order)
// - 1) Wipe data (optional)
// - 2) Create constraints + indexes (schema first so data writes are validated and lookup is fast)
// - 3) Create nodes (use CREATE since schema enforces uniqueness)
// - 4) Create relationships (use MATCH + CREATE clean, avoids accidental re-merge patterns).
// =====================================================


// -----------------------------------------------------
// 0) OPTIONAL: wipe the database (data only, keeps schema)
// -----------------------------------------------------
MATCH (n) DETACH DELETE n;


// -----------------------------------------------------
// 1) CONSTRAINTS (uniqueness / identity)  [create BEFORE data]
// -----------------------------------------------------
CREATE CONSTRAINT patient_id IF NOT EXISTS
FOR (p:Patient) REQUIRE p.patient_id IS UNIQUE;

CREATE CONSTRAINT encounter_id IF NOT EXISTS
FOR (e:Encounter) REQUIRE e.enc_id IS UNIQUE;

CREATE CONSTRAINT diagnosis_icd10 IF NOT EXISTS
FOR (d:Diagnosis) REQUIRE d.icd10 IS UNIQUE;

CREATE CONSTRAINT medication_rxnorm IF NOT EXISTS
FOR (m:Medication) REQUIRE m.rxnorm IS UNIQUE;

CREATE CONSTRAINT provider_npi IF NOT EXISTS
FOR (pr:Provider) REQUIRE pr.npi IS UNIQUE;

CREATE CONSTRAINT facility_id IF NOT EXISTS
FOR (f:Facility) REQUIRE f.facility_id IS UNIQUE;

CREATE CONSTRAINT note_id IF NOT EXISTS
FOR (n:ClinicalNote) REQUIRE n.note_id IS UNIQUE;


// -----------------------------------------------------
// 2) INDEXES (search / filtering)  [create BEFORE workloads]
// -----------------------------------------------------
CREATE INDEX diagnosis_name IF NOT EXISTS
FOR (d:Diagnosis) ON (d.name);

CREATE INDEX medication_name IF NOT EXISTS
FOR (m:Medication) ON (m.name);

CREATE INDEX encounter_date IF NOT EXISTS
FOR (e:Encounter) ON (e.date);


// -----------------------------------------------------
// 3) NODES (use CREATE; uniqueness constraints prevent duplicates)
// -----------------------------------------------------

// 3.1 Patients
CREATE (:Patient {patient_id:'P_001', name:'Asha Mehta', dob:date('1988-02-14'), sex:'F'});
CREATE (:Patient {patient_id:'P_002', name:'Ravi Kumar', dob:date('1975-11-01'), sex:'M'});
CREATE (:Patient {patient_id:'P_003', name:'Neha Singh', dob:date('1992-07-19'), sex:'F'});

// 3.2 Encounters
CREATE (:Encounter {enc_id:'ENC_101', date:date('2025-12-01'), reason:'Follow-up BP',        bp_systolic:150, bp_diastolic:95});
CREATE (:Encounter {enc_id:'ENC_102', date:date('2025-12-03'), reason:'Hypertension review', bp_systolic:145, bp_diastolic:92});
CREATE (:Encounter {enc_id:'ENC_103', date:date('2025-12-05'), reason:'Diabetes follow-up',  hba1c:8.2});

// 3.3 Diagnoses
CREATE (:Diagnosis {icd10:'I10', name:'Essential (primary) hypertension'});
CREATE (:Diagnosis {icd10:'E11', name:'Type 2 diabetes mellitus'});

// 3.4 Medications
CREATE (:Medication {rxnorm:'314076', name:'Amlodipine'});
CREATE (:Medication {rxnorm:'860975', name:'Metformin'});

// 3.5 Clinical notes
CREATE (:ClinicalNote {note_id:'N_901', text:'BP is high. Continue amlodipine.'});
CREATE (:ClinicalNote {note_id:'N_902', text:'Diabetes follow-up: metformin continued. No hypertension symptoms.'});


// -----------------------------------------------------
// 4) RELATIONSHIPS (MATCH endpoints, then CREATE relationships)
// -----------------------------------------------------

// 4.1 Patient -> Encounter
MATCH (p:Patient {patient_id:'P_001'}), (e:Encounter {enc_id:'ENC_101'})
CREATE (p)-[:HAD_ENCOUNTER]->(e);

MATCH (p:Patient {patient_id:'P_002'}), (e:Encounter {enc_id:'ENC_102'})
CREATE (p)-[:HAD_ENCOUNTER]->(e);

MATCH (p:Patient {patient_id:'P_003'}), (e:Encounter {enc_id:'ENC_103'})
CREATE (p)-[:HAD_ENCOUNTER]->(e);


// 4.2 Encounter -> Diagnosis
MATCH (e:Encounter {enc_id:'ENC_101'}), (d:Diagnosis {icd10:'I10'})
CREATE (e)-[:HAS_DIAGNOSIS]->(d);

MATCH (e:Encounter {enc_id:'ENC_102'}), (d:Diagnosis {icd10:'I10'})
CREATE (e)-[:HAS_DIAGNOSIS]->(d);

MATCH (e:Encounter {enc_id:'ENC_103'}), (d:Diagnosis {icd10:'E11'})
CREATE (e)-[:HAS_DIAGNOSIS]->(d);


// 4.3 Encounter -> Medication (with relationship properties)
MATCH (e:Encounter {enc_id:'ENC_101'}), (m:Medication {rxnorm:'314076'})
CREATE (e)-[:PRESCRIBED {dose:'5mg', frequency:'OD'}]->(m);

MATCH (e:Encounter {enc_id:'ENC_102'}), (m:Medication {rxnorm:'314076'})
CREATE (e)-[:PRESCRIBED {dose:'5mg', frequency:'OD'}]->(m);

MATCH (e:Encounter {enc_id:'ENC_103'}), (m:Medication {rxnorm:'860975'})
CREATE (e)-[:PRESCRIBED {dose:'500mg', frequency:'BD'}]->(m);


// 4.4 Note -> Encounter
MATCH (n:ClinicalNote {note_id:'N_901'}), (e:Encounter {enc_id:'ENC_102'})
CREATE (n)-[:ABOUT_ENCOUNTER]->(e);

MATCH (n:ClinicalNote {note_id:'N_902'}), (e:Encounter {enc_id:'ENC_103'})
CREATE (n)-[:ABOUT_ENCOUNTER]->(e);


// 4.5 Note -> (Diagnosis | Medication) mentions with score/method
MATCH (n:ClinicalNote {note_id:'N_901'}), (m:Medication {rxnorm:'314076'})
CREATE (n)-[:MENTIONS {mention:'amlodipine', method:'synonym_exact', score:1.0}]->(m);

MATCH (n:ClinicalNote {note_id:'N_901'}), (d:Diagnosis {icd10:'I10'})
CREATE (n)-[:MENTIONS {mention:'bp is high', method:'fuzzy', score:0.91}]->(d);

MATCH (n:ClinicalNote {note_id:'N_902'}), (m:Medication {rxnorm:'860975'})
CREATE (n)-[:MENTIONS {mention:'metformin', method:'synonym_exact', score:1.0}]->(m);
