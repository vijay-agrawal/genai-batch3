"""
nl2cypher_and_answer.py  (v2: auto-retry + richer parameter extraction)

Adds:
- Auto-retry once if Neo4j execution fails (LLM fixes Cypher using Neo4j error)
- Richer parameter extraction:
  * patient_id (P_###)
  * ICD-10 codes (e.g., I10, E11, E11.9)
  * rxnorm (digits)
  * medication / diagnosis name hints
  * date ranges (between/after/before; YYYY-MM-DD; "last N days")
  * thresholds for bp_systolic, bp_diastolic, hba1c (>, >=, <, <=, "above", "below", "over", "under")
  * BP 140/90 style detection

Prereqs:
  pip install openai neo4j python-dotenv python-dateutil

Env vars required:
  AZURE_OPENAI_ENDPOINT
  AZURE_OPENAI_API_KEY
  AZURE_OPENAI_API_VERSION
  AZURE_OPENAI_MODEL_NAME

  NEO4J_URI
  NEO4J_USER
  NEO4J_PASSWORD

Notes:
- Generated Cypher is enforced read-only and must return a SINGLE map aliased as `result`.
- Auto-retry sends Neo4j error back to LLM for self-correction once.
"""

import os
import re
import json
import datetime as dt
from typing import Optional, Tuple, Dict, Any, List

from dotenv import load_dotenv
from openai import AzureOpenAI
from neo4j import GraphDatabase
from dateutil import parser as dateparser

load_dotenv()


# =====================================================
# 1) Schema (as provided)
# =====================================================
GRAPH_SCHEMA = {
  "HAS_DIAGNOSIS": {"count": 3, "type": "relationship", "properties": {}},
  "ClinicalNote": {
    "count": 2,
    "relationships": {
      "MENTIONS": {
        "count": 0,
        "properties": {
          "score": {"existence": False, "type": "FLOAT", "array": False, "indexed": False},
          "method": {"existence": False, "type": "STRING", "array": False, "indexed": False},
          "mention": {"existence": False, "type": "STRING", "array": False, "indexed": False}
        },
        "direction": "out",
        "labels": ["Diagnosis", "Medication"]
      },
      "ABOUT_ENCOUNTER": {"count": 0, "properties": {}, "direction": "out", "labels": ["Encounter"]}
    },
    "type": "node",
    "properties": {
      "note_id": {"existence": False, "type": "STRING", "indexed": True, "unique": True},
      "text": {"existence": False, "type": "STRING", "indexed": False, "unique": False}
    },
    "labels": []
  },
  "Medication": {
    "count": 2,
    "relationships": {
      "PRESCRIBED": {
        "count": 3,
        "properties": {
          "dose": {"existence": False, "type": "STRING", "array": False, "indexed": False},
          "frequency": {"existence": False, "type": "STRING", "array": False, "indexed": False}
        },
        "direction": "in",
        "labels": ["Encounter"]
      },
      "MENTIONS": {
        "count": 3,
        "properties": {
          "score": {"existence": False, "type": "FLOAT", "array": False, "indexed": False},
          "method": {"existence": False, "type": "STRING", "array": False, "indexed": False},
          "mention": {"existence": False, "type": "STRING", "array": False, "indexed": False}
        },
        "direction": "in",
        "labels": ["ClinicalNote"]
      }
    },
    "type": "node",
    "properties": {
      "name": {"existence": False, "type": "STRING", "indexed": True, "unique": False},
      "rxnorm": {"existence": False, "type": "STRING", "indexed": True, "unique": True}
    },
    "labels": []
  },
  "PRESCRIBED": {
    "count": 3,
    "type": "relationship",
    "properties": {
      "dose": {"existence": False, "type": "STRING", "array": False, "indexed": False},
      "frequency": {"existence": False, "type": "STRING", "array": False, "indexed": False}
    }
  },
  "Patient": {
    "count": 3,
    "relationships": {
      "HAD_ENCOUNTER": {"count": 0, "properties": {}, "direction": "out", "labels": ["Encounter"]}
    },
    "type": "node",
    "properties": {
      "name": {"existence": False, "type": "STRING", "indexed": False, "unique": False},
      "patient_id": {"existence": False, "type": "STRING", "indexed": True, "unique": True},
      "dob": {"existence": False, "type": "DATE", "indexed": False, "unique": False},
      "sex": {"existence": False, "type": "STRING", "indexed": False, "unique": False}
    },
    "labels": []
  },
  "Encounter": {
    "count": 3,
    "relationships": {
      "HAS_DIAGNOSIS": {"count": 0, "properties": {}, "direction": "out", "labels": ["Diagnosis"]},
      "PRESCRIBED": {
        "count": 0,
        "properties": {
          "dose": {"existence": False, "type": "STRING", "array": False, "indexed": False},
          "frequency": {"existence": False, "type": "STRING", "array": False, "indexed": False}
        },
        "direction": "out",
        "labels": ["Medication"]
      },
      "HAD_ENCOUNTER": {"count": 3, "properties": {}, "direction": "in", "labels": ["Patient"]},
      "ABOUT_ENCOUNTER": {"count": 2, "properties": {}, "direction": "in", "labels": ["ClinicalNote"]}
    },
    "type": "node",
    "properties": {
      "date": {"existence": False, "type": "DATE", "indexed": True, "unique": False},
      "reason": {"existence": False, "type": "STRING", "indexed": False, "unique": False},
      "bp_diastolic": {"existence": False, "type": "INTEGER", "indexed": False, "unique": False},
      "enc_id": {"existence": False, "type": "STRING", "indexed": True, "unique": True},
      "hba1c": {"existence": False, "type": "FLOAT", "indexed": False, "unique": False},
      "bp_systolic": {"existence": False, "type": "INTEGER", "indexed": False, "unique": False}
    },
    "labels": []
  },
  "HAD_ENCOUNTER": {"count": 3, "type": "relationship", "properties": {}},
  "Diagnosis": {
    "count": 2,
    "relationships": {
      "HAS_DIAGNOSIS": {"count": 3, "properties": {}, "direction": "in", "labels": ["Encounter"]},
      "MENTIONS": {
        "count": 3,
        "properties": {
          "score": {"existence": False, "type": "FLOAT", "array": False, "indexed": False},
          "method": {"existence": False, "type": "STRING", "array": False, "indexed": False},
          "mention": {"existence": False, "type": "STRING", "array": False, "indexed": False}
        },
        "direction": "in",
        "labels": ["ClinicalNote"]
      }
    },
    "type": "node",
    "properties": {
      "name": {"existence": False, "type": "STRING", "indexed": True, "unique": False},
      "icd10": {"existence": False, "type": "STRING", "indexed": True, "unique": True}
    },
    "labels": []
  },
  "ABOUT_ENCOUNTER": {"count": 2, "type": "relationship", "properties": {}},
  "MENTIONS": {
    "count": 3,
    "type": "relationship",
    "properties": {
      "score": {"existence": False, "type": "FLOAT", "array": False, "indexed": False},
      "method": {"existence": False, "type": "STRING", "array": False, "indexed": False},
      "mention": {"existence": False, "type": "STRING", "array": False, "indexed": False}
    }
  }
}


# =====================================================
# 2) Prompts
# =====================================================
SYSTEM_PROMPT_CYPHER = """
You are a Neo4j Cypher expert.
Translate the user's natural-language question into a SINGLE Cypher query.

ABSOLUTE RULES:
1) Output MUST be ONLY Cypher text.
   - DO NOT use markdown.
   - DO NOT include triple backticks.
   - DO NOT include a language tag like ```cypher.
2) READ-ONLY ONLY:
   Allowed clauses: MATCH, OPTIONAL MATCH, WHERE, WITH, RETURN, ORDER BY, LIMIT, SKIP, DISTINCT
   Disallowed: CREATE, MERGE, DELETE, DETACH, SET, REMOVE, DROP, CALL, LOAD CSV, APOC, PERIODIC COMMIT
3) Final RETURN must NOT return raw nodes/relationships.
   - Final RETURN must return exactly ONE JSON-like map aliased as `result`.
   - Use property projections (maps) only.

OUTPUT SHAPE (default for patient-centric / "everything relevant"):
- Use a TWO-STAGE aggregation:
  Stage 1 (per encounter): collect diagnoses, medications (with relationship props), notes
  Stage 2 (per patient): collect encounter objects (sorted by date desc)

Use this template when applicable (adapt WHERE filters as needed):
MATCH (p:Patient {patient_id:$patient_id})-[:HAD_ENCOUNTER]->(e:Encounter)
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
OPTIONAL MATCH (e)-[pr:PRESCRIBED]->(m:Medication)
OPTIONAL MATCH (n:ClinicalNote)-[:ABOUT_ENCOUNTER]->(e)
WITH p, e,
     collect(DISTINCT {icd10:d.icd10, name:d.name}) AS dx,
     collect(DISTINCT {rxnorm:m.rxnorm, name:m.name, dose:pr.dose, frequency:pr.frequency}) AS meds,
     collect(DISTINCT {note_id:n.note_id, text:substring(n.text,0,180)}) AS notes
ORDER BY e.date DESC
WITH p, collect({
  enc_id:e.enc_id, date:e.date, reason:e.reason,
  bp_systolic:e.bp_systolic, bp_diastolic:e.bp_diastolic, hba1c:e.hba1c,
  diagnoses:dx, medications:meds, notes:notes
})[0..25] AS encounters
RETURN {
  patient: {patient_id:p.patient_id, name:p.name, dob:p.dob, sex:p.sex},
  encounters: encounters
} AS result

PARAMETERS:
- Use the PROVIDED parameter names exactly as given in AVAILABLE_PARAMS.
- Encounter.date is DATE; for ranges use:
  e.date >= date($start_date) AND e.date <= date($end_date)

Use ONLY labels/relationships/properties from the schema. Do not invent any.
"""

SYSTEM_PROMPT_CYPHER_FIX = """
You are a Neo4j Cypher debugger.
You will be given the question, schema, attempted Cypher, available parameters, and a Neo4j error.

Your job: output a corrected SINGLE Cypher query that:
- Is READ-ONLY (MATCH/OPTIONAL MATCH/WHERE/WITH/RETURN/ORDER BY/LIMIT/SKIP/DISTINCT only)
- Outputs ONLY Cypher text (no markdown, no backticks)
- Returns exactly ONE JSON-like map aliased as `result`
- Uses a two-stage aggregation for nested lists (no nested collect() inside a collected map)
- Uses relationship variable [pr:PRESCRIBED] when dose/frequency are required
- Uses only schema items and provided parameter names

Output ONLY the corrected Cypher.
"""

SYSTEM_PROMPT_ANSWER = """
You are a clinical-style assistant that formats results from a Neo4j query.
You will be given the user's question, the executed Cypher, and Neo4j results (JSON-like).

Rules:
- Use ONLY the provided results. Do not invent facts.
- If data is missing, say so.
- Provide a concise, actionable summary with sections:
  Patient summary
  Recent encounters (most recent first)
  Diagnoses
  Medications (dose/frequency if present)
  Notes highlights
  Quick prep checklist (3-6 items derived from data)

Output plain text. No markdown code fences.
"""


def build_user_prompt_for_cypher(question: str, params: Dict[str, Any]) -> str:
    schema_json = json.dumps(GRAPH_SCHEMA, indent=2)
    params_json = json.dumps(params, indent=2, default=str)
    return f"""Convert this question to Cypher.

IMPORTANT:
- Final RETURN must be a single JSON-like map aliased as `result`, with projected properties (no raw nodes).
- Use the provided parameter names exactly as listed in AVAILABLE_PARAMS.

QUESTION:
{question}

AVAILABLE_PARAMS (names + values):
{params_json}

SCHEMA (JSON):
{schema_json}
"""


def build_user_prompt_for_fix(
    question: str,
    cypher: str,
    params: Dict[str, Any],
    neo4j_error: str
) -> str:
    schema_json = json.dumps(GRAPH_SCHEMA, indent=2)
    params_json = json.dumps(params, indent=2, default=str)
    return f"""QUESTION:
{question}

ATTEMPTED CYPHER:
{cypher}

AVAILABLE_PARAMS (names + values):
{params_json}

NEO4J ERROR:
{neo4j_error}

SCHEMA (JSON):
{schema_json}
"""


def build_user_prompt_for_answer(question: str, cypher: str, results_json: str) -> str:
    return f"""QUESTION:
{question}

CYPHER EXECUTED:
{cypher}

NEO4J RESULTS (JSON):
{results_json}
"""


# =====================================================
# 3) Helpers: strip code fences + validate
# =====================================================
DISALLOWED = re.compile(
    r"\b(CREATE|MERGE|DELETE|DETACH|SET|REMOVE|DROP|CALL|LOAD\s+CSV|APOC|PERIODIC)\b",
    re.IGNORECASE,
)

CODE_FENCE_RE = re.compile(r"^\s*```(?:cypher|sql|text)?\s*|\s*```\s*$", re.IGNORECASE | re.MULTILINE)

def strip_code_fences(text: str) -> str:
    # removes opening/closing ``` and optional language tags
    return re.sub(CODE_FENCE_RE, "", text).strip()

def validate_readonly(cypher: str) -> None:
    if "```" in cypher:
        raise ValueError("Cypher contains markdown code fences.")
    if DISALLOWED.search(cypher):
        raise ValueError("Generated Cypher contains disallowed write/admin clauses.")


# =====================================================
# 4) Azure OpenAI helpers
# =====================================================
def get_azure_client_and_model() -> Tuple[AzureOpenAI, str]:
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    )
    model_name = os.getenv("AZURE_OPENAI_MODEL_NAME")
    if not model_name:
        raise ValueError("Missing env var: AZURE_OPENAI_MODEL_NAME")
    return client, model_name


def llm_chat(client: AzureOpenAI, model_name: str, system: str, user: str, temperature: float = 0.0) -> str:
    response = client.chat.completions.create(
        model=model_name,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=temperature,
    )
    return response.choices[0].message.content.strip()


# =====================================================
# 5) Neo4j helpers
# =====================================================
def get_neo4j_driver():
    NEO4J_URI = os.getenv("NEO4J_URI")
    NEO4J_USER = os.getenv("NEO4J_USER")
    NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")

    if not all([NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD]):
        raise ValueError("❌ Missing one or more Neo4j env variables")

    driver = GraphDatabase.driver(
        NEO4J_URI,
        auth=(NEO4J_USER, NEO4J_PASSWORD)
    )
    return driver


def neo4j_connection_test(driver) -> None:
    with driver.session() as session:
        record = session.run("RETURN 1 AS ok").single()
        print("✅ Neo4j connection successful:", record["ok"])


def run_cypher(driver, cypher: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
    with driver.session() as session:
        result = session.run(cypher, params)
        return [r.data() for r in result]


# =====================================================
# 6) Rich parameter extraction
# =====================================================
PATIENT_ID_RE = re.compile(r"\bP_\d{3}\b", re.IGNORECASE)
ICD10_RE = re.compile(r"\b[A-TV-Z][0-9]{2}(?:\.[0-9A-Z]{1,4})?\b", re.IGNORECASE)  # common ICD-10 pattern
RXNORM_RE = re.compile(r"\brxnorm\s*[:=]?\s*(\d{3,})\b", re.IGNORECASE)
DATE_ISO_RE = re.compile(r"\b(20\d{2}-\d{2}-\d{2})\b")
LAST_N_DAYS_RE = re.compile(r"\blast\s+(\d{1,3})\s+days\b", re.IGNORECASE)
BETWEEN_DATES_RE = re.compile(r"\bbetween\s+(20\d{2}-\d{2}-\d{2})\s+and\s+(20\d{2}-\d{2}-\d{2})\b", re.IGNORECASE)
AFTER_DATE_RE = re.compile(r"\b(after|since)\s+(20\d{2}-\d{2}-\d{2})\b", re.IGNORECASE)
BEFORE_DATE_RE = re.compile(r"\b(before|until)\s+(20\d{2}-\d{2}-\d{2})\b", re.IGNORECASE)

# Threshold patterns: e.g., "bp_systolic > 140", "systolic above 140", "hba1c >= 7.5"
THRESH_RE = re.compile(
    r"\b(?P<field>bp_systolic|bp_diastolic|hba1c|systolic|diastolic|bp)\b"
    r"\s*(?P<op>>=|<=|>|<|=|above|below|over|under)\s*"
    r"(?P<val>\d+(?:\.\d+)?)\b",
    re.IGNORECASE
)

# BP ratio style "140/90"
BP_RATIO_RE = re.compile(r"\b(\d{2,3})\s*/\s*(\d{2,3})\b")

# Simple “name hint” captures
MED_NAME_HINT_RE = re.compile(r"\b(medication|drug|med|on|taking|prescribed)\s+([A-Za-z][A-Za-z0-9_-]{2,})\b", re.IGNORECASE)
DX_NAME_HINT_RE  = re.compile(r"\b(diagnosis|diagnosed|condition)\s+([A-Za-z][A-Za-z0-9_-]{2,})\b", re.IGNORECASE)

def _to_iso_date(d: dt.date) -> str:
    return d.isoformat()

def extract_params(question: str) -> Dict[str, Any]:
    """
    Heuristic parameter extractor. It does NOT guarantee correctness, but provides useful
    bindings for common filters. The LLM is instructed to use these param names if relevant.
    """
    q = question.strip()
    params: Dict[str, Any] = {}

    # patient_id
    m = PATIENT_ID_RE.search(q)
    if m:
        params["patient_id"] = m.group(0).upper()

    # ICD10 codes
    icds = list({x.upper() for x in ICD10_RE.findall(q)})
    if icds:
        # If multiple, provide list; LLM can use IN $icd10_list
        params["icd10_list"] = icds
        if len(icds) == 1:
            params["icd10"] = icds[0]

    # rxnorm explicit
    m = RXNORM_RE.search(q)
    if m:
        params["rxnorm"] = m.group(1)

    # medication / diagnosis name hints (very light)
    m = MED_NAME_HINT_RE.search(q)
    if m:
        params["medication_name"] = m.group(2)
    m = DX_NAME_HINT_RE.search(q)
    if m:
        params["diagnosis_name"] = m.group(2)

    # Date ranges
    # between ISO dates
    m = BETWEEN_DATES_RE.search(q)
    if m:
        params["start_date"] = m.group(1)
        params["end_date"] = m.group(2)

    # after / before
    m = AFTER_DATE_RE.search(q)
    if m and "start_date" not in params:
        params["start_date"] = m.group(2)
    m = BEFORE_DATE_RE.search(q)
    if m and "end_date" not in params:
        params["end_date"] = m.group(2)

    # last N days (relative -> concrete)
    m = LAST_N_DAYS_RE.search(q)
    if m:
        n = int(m.group(1))
        today = dt.date.today()
        start = today - dt.timedelta(days=n)
        params["start_date"] = _to_iso_date(start)
        params["end_date"] = _to_iso_date(today)

    # Fallback: if question contains exactly two ISO dates, assume range if not already set
    if "start_date" not in params and "end_date" not in params:
        iso_dates = DATE_ISO_RE.findall(q)
        if len(iso_dates) >= 2:
            params["start_date"] = iso_dates[0]
            params["end_date"] = iso_dates[1]

    # Thresholds for BP / HbA1c
    # Also detect 140/90 as systolic/diastolic
    m = BP_RATIO_RE.search(q)
    if m:
        params["min_bp_systolic"] = int(m.group(1))
        params["min_bp_diastolic"] = int(m.group(2))

    for match in THRESH_RE.finditer(q):
        field_raw = match.group("field").lower()
        op = match.group("op").lower()
        val_str = match.group("val")
        val = float(val_str) if "." in val_str or field_raw == "hba1c" else int(float(val_str))

        # normalize field name
        if field_raw == "systolic":
            field = "bp_systolic"
        elif field_raw == "diastolic":
            field = "bp_diastolic"
        elif field_raw == "bp":
            # ambiguous; if "bp > 140" treat as systolic
            field = "bp_systolic"
        else:
            field = field_raw

        # normalize op words
        if op in ("above", "over"):
            op = ">"
        elif op in ("below", "under"):
            op = "<"

        # store as min_/max_ params (most common)
        if op in (">", ">="):
            params[f"min_{field}"] = val
        elif op in ("<", "<="):
            params[f"max_{field}"] = val
        elif op == "=":
            params[f"eq_{field}"] = val

    # Generic free-text term (for searching names/reasons/notes) if user asks "mention/contains"
    if re.search(r"\b(contains|mention|mentions|like|search|find)\b", q, re.IGNORECASE):
        # naive: take quoted string if present, else last token chunk after keyword
        quoted = re.findall(r"['\"]([^'\"]{2,})['\"]", q)
        if quoted:
            params["term"] = quoted[0]
        else:
            # fallback: don't overfit; let the LLM decide
            params["term"] = q

    return params

# =====================================================
# 7) Prompt builders
# =====================================================
def build_user_prompt_for_cypher(question: str, params: Dict[str, Any]) -> str:
    return f"""QUESTION:
{question}

AVAILABLE_PARAMS (names + values):
{json.dumps(params, indent=2, default=str)}

SCHEMA (JSON):
{json.dumps(GRAPH_SCHEMA, indent=2)}
"""

def build_user_prompt_for_fix(question: str, cypher: str, params: Dict[str, Any], neo4j_error: str) -> str:
    return f"""QUESTION:
{question}

ATTEMPTED CYPHER:
{cypher}

AVAILABLE_PARAMS (names + values):
{json.dumps(params, indent=2, default=str)}

NEO4J ERROR:
{neo4j_error}

SCHEMA (JSON):
{json.dumps(GRAPH_SCHEMA, indent=2)}
"""

def build_user_prompt_for_answer(question: str, cypher: str, results_json: str) -> str:
    return f"""QUESTION:
{question}

CYPHER EXECUTED:
{cypher}

NEO4J RESULTS (JSON):
{results_json}
"""


# =====================================================
# 8) Auto-retry execution with LLM fix (improved)
# =====================================================
def execute_with_retry(
    client: AzureOpenAI,
    model_name: str,
    driver,
    question: str,
    cypher: str,
    params: Dict[str, Any],
    max_attempts: int = 2
) -> Tuple[str, List[Dict[str, Any]]]:

    cur_cypher = cypher
    last_err: Optional[str] = None

    for attempt in range(1, max_attempts + 1):
        try:
            rows = run_cypher(driver, cur_cypher, params)
            return cur_cypher, rows
        except Exception as e:
            last_err = str(e)
            if attempt >= max_attempts:
                raise

            fix_prompt = build_user_prompt_for_fix(question, cur_cypher, params, last_err)
            fixed = llm_chat(client, model_name, SYSTEM_PROMPT_CYPHER_FIX, fix_prompt, temperature=0.0)
            fixed = strip_code_fences(fixed)
            validate_readonly(fixed)
            cur_cypher = fixed

    raise RuntimeError(f"Neo4j execution failed after retries: {last_err}")


# =====================================================
# 9) Main
# =====================================================
def main() -> None:
    print("Neo4j NL → Cypher → Neo4j (+auto-retry) → Answer (Azure OpenAI)")

    question = input("\nAsk a question: ").strip()
    if not question:
        print("No question provided.")
        return

    # Extract parameters first so the LLM can use consistent param names
    params = extract_params(question)

    # Azure OpenAI client
    client, model_name = get_azure_client_and_model()

    # Neo4j driver
    driver = get_neo4j_driver()
    try:
        neo4j_connection_test(driver)

        # 1) Generate Cypher (now includes AVAILABLE_PARAMS)
        cypher_prompt = build_user_prompt_for_cypher(question, params)
        cypher = llm_chat(client, model_name, SYSTEM_PROMPT_CYPHER, cypher_prompt, temperature=0.0)
        validate_readonly(cypher)

        print("\n--- Generated Cypher (attempt 1) ---")
        print(cypher)

        # Helpful warning if Cypher uses params not detected
        # (still okay; user may not have provided enough info)
        missing = []
        for p in re.findall(r"\$(\w+)", cypher):
            if p not in params:
                missing.append(p)
        if missing:
            print("\n⚠️ Note: Cypher references parameters not detected in the question:", sorted(set(missing)))
            print("   Either include those values in the question, or extend extract_params().")

        # 2) Execute with auto-retry
        final_cypher, rows = execute_with_retry(
            client=client,
            model_name=model_name,
            driver=driver,
            question=question,
            cypher=cypher,
            params=params,
            max_attempts=2,  # 1 retry
        )

        if final_cypher != cypher:
            print("\n--- Fixed Cypher (after Neo4j error) ---")
            print(final_cypher)

        # 3) Grounding payload to LLM
        results_json = json.dumps(rows, indent=2, default=str)

        # 4) Ask LLM for final formatted answer
        answer_prompt = build_user_prompt_for_answer(question, final_cypher, results_json)
        final_answer = llm_chat(client, model_name, SYSTEM_PROMPT_ANSWER, answer_prompt, temperature=0.2)

        print("\n==============================")
        print("FINAL ANSWER")
        print("==============================")
        print(final_answer)

    except Exception as e:
        print(f"\nERROR: {e}")
    finally:
        driver.close()


if __name__ == "__main__":
    main()
