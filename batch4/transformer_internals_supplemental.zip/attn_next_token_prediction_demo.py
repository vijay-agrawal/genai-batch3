"""
Attention Mechanism and Next Token Prediction — Interactive Math Walkthrough
===================================================
Streamlit demo for GenAI Training
Step-by-step: Tokens → Embeddings → Q/K/V → Scores → Softmax → Output → [FFN/MLP] → Unembedding (W_U) → softmax → Next Token
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import streamlit as st
import pandas as pd

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Attention Mechanism — Math Walkthrough",
    page_icon="🔍",
    layout="wide",
)

# ── Helpers ───────────────────────────────────────────────────────────────────
def softmax(x, axis=-1):
    x = x - x.max(axis=axis, keepdims=True)
    e = np.exp(x)
    return e / e.sum(axis=axis, keepdims=True)


TOKEN_COLORS = [
    "#4e79a7", "#f28e2b", "#e15759", "#76b7b2",
    "#59a14f", "#edc948", "#b07aa1", "#ff9da7",
    "#9c755f", "#bab0ac",
]


def token_pills(tokens):
    """Render tokens as colored HTML pills."""
    pills = []
    for i, tok in enumerate(tokens):
        color = TOKEN_COLORS[i % len(TOKEN_COLORS)]
        pills.append(
            f'<span style="background:{color};color:white;padding:4px 10px;'
            f'border-radius:14px;margin:3px;display:inline-block;font-weight:600;'
            f'font-size:15px">{tok}</span>'
        )
    return " ".join(pills)


def styled_matrix_df(matrix, row_labels, col_labels):
    """Return a styled pandas DataFrame for display."""
    df = pd.DataFrame(matrix.round(3), index=row_labels, columns=col_labels)
    return df


def plot_heatmap(matrix, row_labels, col_labels, title, cmap="Blues",
                 figsize=None, vmin=None, vmax=None, row_colors=None):
    T, D = matrix.shape
    if figsize is None:
        figsize = (max(4, D * 0.7 + 1), max(3, T * 0.55 + 1))
    fig, ax = plt.subplots(figsize=figsize)
    sns.heatmap(
        matrix, annot=True, fmt=".2f", cmap=cmap,
        xticklabels=col_labels, yticklabels=row_labels,
        ax=ax, linewidths=0.6, linecolor="#cccccc",
        vmin=vmin, vmax=vmax,
        annot_kws={"size": 9},
        cbar_kws={"shrink": 0.8},
    )
    ax.set_title(title, fontsize=12, pad=8, fontweight="bold")
    ax.tick_params(axis="x", labelsize=9, rotation=30)
    ax.tick_params(axis="y", labelsize=9, rotation=0)

    # Color row labels to match token colors
    if row_colors:
        for tick, color in zip(ax.get_yticklabels(), row_colors):
            tick.set_color(color)
            tick.set_fontweight("bold")

    plt.tight_layout()
    return fig


def plot_attention_heatmap_large(attn, tokens):
    """Big centrepiece heatmap with per-cell intensity and token coloring."""
    N = len(tokens)
    fig, ax = plt.subplots(figsize=(max(5, N * 0.9 + 1.5), max(4, N * 0.9 + 1.5)))
    colors_tok = [TOKEN_COLORS[i % len(TOKEN_COLORS)] for i in range(N)]

    im = ax.imshow(attn, cmap="YlOrRd", vmin=0, vmax=1, aspect="auto")

    for i in range(N):
        for j in range(N):
            val = attn[i, j]
            text_color = "white" if val > 0.55 else "black"
            ax.text(j, i, f"{val:.2f}", ha="center", va="center",
                    fontsize=11, fontweight="bold", color=text_color)

    ax.set_xticks(range(N))
    ax.set_yticks(range(N))
    ax.set_xticklabels(tokens, fontsize=11)
    ax.set_yticklabels(tokens, fontsize=11)

    for idx, (xtick, ytick) in enumerate(zip(ax.get_xticklabels(), ax.get_yticklabels())):
        xtick.set_color(colors_tok[idx % len(colors_tok)])
        xtick.set_fontweight("bold")
        ytick.set_color(colors_tok[idx])
        ytick.set_fontweight("bold")

    ax.set_xlabel("Key token  (attends TO →)", fontsize=11, labelpad=8)
    ax.set_ylabel("← Query token  (FROM)", fontsize=11, labelpad=8)
    ax.set_title("Attention Weight Matrix  —  softmax(QKᵀ / √d)",
                 fontsize=13, fontweight="bold", pad=10)
    plt.colorbar(im, ax=ax, fraction=0.04, pad=0.02, label="Attention weight")
    plt.tight_layout()
    return fig


def qkv_arrow_diagram(tokens, embed_dim):
    """Simple diagram: X → Wq/Wk/Wv → Q/K/V."""
    fig, ax = plt.subplots(figsize=(8, 2.4))
    ax.axis("off")
    N = len(tokens)

    boxes = {
        "X":  (0.10, 0.5, f"X\n({N}×{embed_dim})\nEmbeddings",    "#4e79a7"),
        "Wq": (0.33, 0.82, f"W_Q\n({embed_dim}×{embed_dim})",       "#59a14f"),
        "Wk": (0.33, 0.50, f"W_K\n({embed_dim}×{embed_dim})",       "#f28e2b"),
        "Wv": (0.33, 0.18, f"W_V\n({embed_dim}×{embed_dim})",       "#e15759"),
        "Q":  (0.65, 0.82, f"Q\n({N}×{embed_dim})\nQueries",        "#59a14f"),
        "K":  (0.65, 0.50, f"K\n({N}×{embed_dim})\nKeys",           "#f28e2b"),
        "V":  (0.65, 0.18, f"V\n({N}×{embed_dim})\nValues",         "#e15759"),
    }

    for _, (x, y, label, color) in boxes.items():
        ax.add_patch(mpatches.FancyBboxPatch(
            (x - 0.08, y - 0.16), 0.16, 0.32,
            boxstyle="round,pad=0.02", facecolor=color,
            edgecolor="white", linewidth=1.5, alpha=0.88,
        ))
        ax.text(x, y, label, ha="center", va="center",
                fontsize=8, color="white", fontweight="bold")

    # Arrows X → W
    for (wx, wy, _, _) in [boxes["Wq"], boxes["Wk"], boxes["Wv"]]:
        ax.annotate("", xy=(wx - 0.08, wy), xytext=(boxes["X"][0] + 0.08, boxes["X"][1]),
                    arrowprops=dict(arrowstyle="->", color="#aaaaaa", lw=1.5))
    # Arrows W → output
    for src, tgt in [("Wq", "Q"), ("Wk", "K"), ("Wv", "V")]:
        sx, sy = boxes[src][0] + 0.08, boxes[src][1]
        tx, ty = boxes[tgt][0] - 0.08, boxes[tgt][1]
        ax.annotate("", xy=(tx, ty), xytext=(sx, sy),
                    arrowprops=dict(arrowstyle="->", color="#aaaaaa", lw=1.5))
        mx, my = (sx + tx) / 2, (sy + ty) / 2
        ax.text(mx, my + 0.04, "×", ha="center", va="center", fontsize=13, color="#555")

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_title("Projection: X × W_Q / W_K / W_V  →  Q, K, V",
                 fontsize=11, fontweight="bold")
    plt.tight_layout()
    return fig


def score_formula_diagram(tokens, scores, embed_dim):
    """Visualise the score computation Q·Kᵀ / √d."""
    N = len(tokens)
    fig, axes = plt.subplots(1, 3, figsize=(max(10, N * 1.2 + 4), max(3.5, N * 0.7 + 1.5)))

    # Raw scores
    sns.heatmap(scores, annot=True, fmt=".2f", cmap="RdBu_r",
                xticklabels=tokens, yticklabels=tokens,
                ax=axes[0], linewidths=0.5, annot_kws={"size": 8},
                center=0, cbar_kws={"shrink": 0.8})
    axes[0].set_title(f"Raw scores  Q·Kᵀ / √{embed_dim}", fontsize=10, fontweight="bold")
    axes[0].tick_params(axis="x", rotation=35, labelsize=8)
    axes[0].tick_params(axis="y", rotation=0, labelsize=8)

    # Score distribution per query token
    axes[1].set_title("Score distribution per query token", fontsize=10, fontweight="bold")
    for i, tok in enumerate(tokens):
        axes[1].plot(tokens, scores[i], marker="o",
                     label=tok, color=TOKEN_COLORS[i % len(TOKEN_COLORS)], linewidth=2)
    axes[1].axhline(0, color="#cccccc", linewidth=0.8, linestyle="--")
    axes[1].legend(fontsize=7, loc="upper right")
    axes[1].set_xlabel("Key token", fontsize=9)
    axes[1].set_ylabel("Score", fontsize=9)
    axes[1].tick_params(axis="x", rotation=30, labelsize=8)

    # Softmax output
    attn = softmax(scores)
    sns.heatmap(attn, annot=True, fmt=".2f", cmap="YlOrRd",
                xticklabels=tokens, yticklabels=tokens,
                ax=axes[2], linewidths=0.5, annot_kws={"size": 8},
                vmin=0, vmax=1, cbar_kws={"shrink": 0.8})
    axes[2].set_title("After softmax  (each row sums to 1)", fontsize=10, fontweight="bold")
    axes[2].tick_params(axis="x", rotation=35, labelsize=8)
    axes[2].tick_params(axis="y", rotation=0, labelsize=8)

    for ax in [axes[0], axes[2]]:
        for tick_lbl in ax.get_yticklabels():
            idx = tokens.index(tick_lbl.get_text()) if tick_lbl.get_text() in tokens else -1
            if idx >= 0:
                tick_lbl.set_color(TOKEN_COLORS[idx % len(TOKEN_COLORS)])
                tick_lbl.set_fontweight("bold")

    plt.tight_layout()
    return fig


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.image(
        "https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/"
        "Hewlett_Packard_Enterprise_logo.svg/320px-Hewlett_Packard_Enterprise_logo.svg.png",
        width=180,
    )
    st.markdown("## ⚙️ Controls")

    sentence = st.text_area(
        "Input sentence",
        value="Server shutdown occurred because power supply overheated",
        height=90,
    )

    embed_dim = st.select_slider(
        "Embedding dimension (d)",
        options=[4, 6, 8],
        value=4,
        help="Dimensionality of each token's embedding vector.",
    )

    seed = st.number_input("Random seed", min_value=0, max_value=9999,
                           value=42, step=1,
                           help="Change to see different weight initialisations.")

    show_weight_matrices = st.checkbox("Show W_Q / W_K / W_V matrices", value=False)
    show_qkv_matrices    = st.checkbox("Show Q / K / V matrices", value=True)
    show_embeddings      = st.checkbox("Show embedding matrix X", value=False)

    st.markdown("---")
    st.markdown(
        "**Gen AI Lab** — Transformer Internals  \n"
        "Formula: `Attention(Q,K,V) = softmax(QKᵀ/√d)·V`"
    )

# ── Compute ───────────────────────────────────────────────────────────────────
tokens = sentence.strip().split()
MAX_TOKENS = 10
if len(tokens) > MAX_TOKENS:
    st.warning(f"Showing first {MAX_TOKENS} tokens for readability.")
    tokens = tokens[:MAX_TOKENS]

N = len(tokens)
D = embed_dim

rng = np.random.default_rng(seed)

# ⚠️  RANDOM — expected to be learned from data in a real model
# X: token embedding matrix.  In production transformers this is a trained look-up
# table (nn.Embedding) where each row is learned via backpropagation over the
# training corpus.  Here we sample from N(0,1) purely to make the demo runnable
# without loading a real checkpoint.
X   = rng.standard_normal((N, D))

# ⚠️  RANDOM — expected to be learned from data in a real model
# Wq, Wk, Wv: the three projection weight matrices — the *core learnable parameters*
# of every attention head.  During training, gradient descent adjusts these so that
# the resulting Q·Kᵀ dot products capture semantically meaningful relationships
# (e.g. "overheated" attends strongly to "power" and "supply").
# Initialised here with scaled Gaussian noise (σ=0.5) to mimic Xavier-style init.
Wq  = rng.standard_normal((D, D)) * 0.5
Wk  = rng.standard_normal((D, D)) * 0.5
Wv  = rng.standard_normal((D, D)) * 0.5

Q      = X @ Wq
K      = X @ Wk
V      = X @ Wv
scale  = np.sqrt(D)

# ★  KEY OPERATION — the dot product Q·Kᵀ is the heart of the attention mechanism
#
# scores[i, j] = dot(Q[i], K[j]) / √d
#
# Why dot product?
#   A dot product measures *similarity* between two vectors: high value → the
#   query vector for token i is well-aligned with the key vector for token j,
#   meaning "token i should pay attention to token j."
#
# Why divide by √d?
#   As d grows, dot products grow in magnitude (variance scales with d).
#   Dividing by √d keeps variance ≈ 1 so softmax doesn't saturate and
#   gradients remain healthy during training.
#
# This single N×N matrix of dot products drives ALL subsequent routing of
# information between tokens — it is literally what "attention" means.
scores = Q @ K.T / scale

attn   = softmax(scores)
output = attn @ V

tok_colors = [TOKEN_COLORS[i % len(TOKEN_COLORS)] for i in range(N)]
dim_labels = [f"d{i}" for i in range(D)]

# ── Main UI ───────────────────────────────────────────────────────────────────
st.markdown(
    "<h1 style='text-align:center;margin-bottom:0'>🔍 Attention Mechanism</h1>"
    "<h3 style='text-align:center;color:#888;margin-top:4px'>Interactive Math Walkthrough</h3>",
    unsafe_allow_html=True,
)

# Core formula banner
st.markdown(
    """
    <div style="background:linear-gradient(90deg,#1a1a2e,#16213e);
                border-radius:12px;padding:18px 28px;margin:18px 0;text-align:center">
        <span style="color:#e0e0e0;font-size:13px;letter-spacing:1px">CORE FORMULA</span><br>
        <span style="color:#ffd700;font-size:24px;font-family:monospace;font-weight:700">
            Attention(Q, K, V) &nbsp;=&nbsp; softmax( QK<sup>T</sup> / √d ) · V
        </span>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown("---")

# ── STEP 1: Tokenisation ─────────────────────────────────────────────────────
st.markdown("## Step 1 — Tokenisation")

col1, col2 = st.columns([3, 1])
with col1:
    st.markdown(token_pills(tokens), unsafe_allow_html=True)
    st.caption(f"N = **{N}** tokens  ·  embedding dimension d = **{D}**")
with col2:
    st.info(
        "**iLO Analogy**  \n"
        "Each word = one sensor reading ID.  \n"
        "The model reads *all* tokens in parallel — no sequential loop."
    )

# ── STEP 2: Embeddings ───────────────────────────────────────────────────────
st.markdown("## Step 2 — Token Embeddings  `X`")

with st.expander("What are embeddings?", expanded=True):
    st.markdown(
        "Each token is mapped to a **dense numerical vector** of dimension `d`.  \n"
        "Real transformers learn these vectors during training (look-up table).  \n"
        "Here we use **random vectors** to keep the demo self-contained.  \n\n"
        "Shape of `X`: **(N × d)** — one row per token, one column per embedding dimension."
    )

if show_embeddings:
    fig = plot_heatmap(X, tokens, dim_labels,
                       f"X  —  Token Embeddings  ({N} × {D})",
                       cmap="coolwarm", row_colors=tok_colors)
    st.pyplot(fig, use_container_width=False)
else:
    st.dataframe(
        styled_matrix_df(X, tokens, dim_labels).style.background_gradient(cmap="coolwarm", axis=None),
        use_container_width=False,
    )

# ── STEP 3: Weight matrices ───────────────────────────────────────────────────
st.markdown("## Step 3 — Learned Weight Matrices  `W_Q`, `W_K`, `W_V`")

col_a, col_b = st.columns([3, 1])
with col_b:
    st.info(
        "**The magic is here.**  \n"
        "These matrices are **learned during training** via backprop.  \n"
        "They teach each token *how to ask questions* (Q), *what to advertise* (K), "
        "and *what to share* (V)."
    )
with col_a:
    st.markdown("""
| Matrix | Shape | Role | iLO analogy |
|--------|-------|------|-------------|
| **W_Q** | d × d | Transforms each token into a **Query** — *"what am I looking for?"* | "Find me CPU temperature" |
| **W_K** | d × d | Transforms each token into a **Key** — *"what do I offer?"* | Sensor label: "CPU_TEMP" |
| **W_V** | d × d | Transforms each token into a **Value** — *"what data do I carry?"* | Actual sensor reading: 87 °C |
""")

with st.expander("Are W_Q / W_K / W_V fixed or do they change per token?  How are they learned?", expanded=True):
    st.markdown(
        """
**One set of weights per attention head — shared across ALL tokens.**

```python
Q = X @ W_Q   # X is (N × d),  W_Q is (d × d)
              # W_Q is applied to every token row — same matrix, N times
```

If your sentence has 7 tokens, `W_Q` is applied 7 times in parallel, but it is the
**same matrix** each time.  Think of it as a fixed lens every token looks through:
the lens is fixed, but each token brings different light (its embedding vector),
so each gets a unique `Q` vector out.

---

**Lifecycle of these weights:**

| Phase | What happens to W_Q, W_K, W_V |
|---|---|
| Initialisation | Set to small random values (Xavier / Kaiming init) |
| Training | Updated by backpropagation — millions of gradient steps adjust them so that `Q·Kᵀ` scores capture meaningful relationships |
| Inference | **Frozen** — loaded from checkpoint, never modified again |
| Per token | Not changed — only the *input* `x[i]` differs, producing a unique `Q[i]` |

---

**Why one shared matrix and not one per token?**

`W_Q` doesn't encode *what* a specific token is asking — it encodes *how to ask*.
The question content comes from the token's embedding; the weight matrix teaches the
model a universal *style* of reasoning that works for any token.

This is why a model trained on server logs generalises: the same `W_Q` handles
`"Server overheated"` and `"Fan speed nominal"` without needing separate weights
for each possible input.

---

**Scope hierarchy:**

```
Model
 └─ Layer 1 … Layer N          (each layer has its own W_Q, W_K, W_V)
     └─ Head 1 … Head H        (each head has its own W_Q, W_K, W_V)
         └─ Token 1 … Token T  (all share the same W_Q, W_K, W_V for that head)
```
        """
    )

if show_weight_matrices:
    c1, c2, c3 = st.columns(3)
    with c1:
        st.pyplot(plot_heatmap(Wq, dim_labels, dim_labels, "W_Q", cmap="Greens"), use_container_width=True)
    with c2:
        st.pyplot(plot_heatmap(Wk, dim_labels, dim_labels, "W_K", cmap="Oranges"), use_container_width=True)
    with c3:
        st.pyplot(plot_heatmap(Wv, dim_labels, dim_labels, "W_V", cmap="Reds"), use_container_width=True)

# ── STEP 4: Q, K, V projection ────────────────────────────────────────────────
st.markdown("## Step 4 — Compute Q, K, V  via Matrix Multiply")

st.markdown(
    r"""
```
Q = X · W_Q       (shape: N × d)
K = X · W_K       (shape: N × d)
V = X · W_V       (shape: N × d)
```
Each token now has three roles simultaneously — it asks a question (Q),
broadcasts a label (K), and carries a payload (V).
"""
)

st.pyplot(qkv_arrow_diagram(tokens, D), use_container_width=False)

if show_qkv_matrices:
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("**Q — Queries**")
        st.dataframe(
            styled_matrix_df(Q, tokens, dim_labels).style.background_gradient(cmap="Greens", axis=None),
            use_container_width=True,
        )
    with c2:
        st.markdown("**K — Keys**")
        st.dataframe(
            styled_matrix_df(K, tokens, dim_labels).style.background_gradient(cmap="Oranges", axis=None),
            use_container_width=True,
        )
    with c3:
        st.markdown("**V — Values**")
        st.dataframe(
            styled_matrix_df(V, tokens, dim_labels).style.background_gradient(cmap="Reds", axis=None),
            use_container_width=True,
        )

# ── STEP 5: Attention scores ──────────────────────────────────────────────────
st.markdown("## Step 5 — Attention Scores  `Q · Kᵀ / √d`")

col_a, col_b = st.columns([3, 1])
with col_b:
    st.info(
        f"**Why divide by √d = {scale:.2f}?**  \n"
        "With large `d`, dot products grow large → softmax saturates → "
        "gradients vanish.  \n"
        "Dividing by √d keeps the variance ≈ 1."
    )
with col_a:
    st.markdown(
        r"""
```
scores[i, j] = Q[i] · K[j]  /  √d
```
- `scores[i, j]` = how much **token i** (query) wants to attend to **token j** (key)
- High score → the tokens are *relevant* to each other
- This is just a **dot product** — the same GEMM that GPUs are built for
"""
    )

st.pyplot(score_formula_diagram(tokens, scores, D), use_container_width=False)

with st.expander("Deep dive — why Kᵀ (transpose)?  How does this score capture context?", expanded=True):
    st.markdown(
        f"""
**Why do we transpose K?**

`Q` and `K` are both shaped `(N × d)` — one row per token, one column per dimension.
To get a score between *every pair* of tokens we need a `(N × N)` matrix.
The only way to get that from two `(N × d)` matrices is to multiply one by the
transpose of the other:

```
Q         is  (N × d)   — N query vectors, each of length d
Kᵀ        is  (d × N)   — transpose flips K so its token vectors become columns
Q @ Kᵀ    is  (N × N)   — cell [i, j] = dot product of query i with key j
```

Without the transpose the shapes don't multiply: `(N×d) @ (N×d)` is illegal.
The transpose is purely a shape trick to compute all N² pairwise dot products
in one GPU-friendly matrix multiply (GEMM).

---

**What does the dot product actually measure?**

A dot product between two vectors `a` and `b` is:

```
dot(a, b) = a[0]·b[0] + a[1]·b[1] + … + a[d-1]·b[d-1]
```

It is large when the two vectors point in the **same direction** in d-dimensional
space, and near zero when they are perpendicular (unrelated).

In the attention context:
- `Q[i]` = "what token i is looking for" (shaped by W_Q during training)
- `K[j]` = "what token j offers" (shaped by W_K during training)
- `dot(Q[i], K[j])` = how well token j's offer matches token i's question

Training adjusts W_Q and W_K so that semantically related tokens end up with
similar Q/K directions — making the dot product a learned similarity measure,
not just a geometric one.

---

**The four pieces that make context capture work:**

| Piece | What it does | Why it matters |
|---|---|---|
| `W_Q` (learned) | Projects each token into "question space" | Tokens learn *how to ask* based on their meaning |
| `W_K` (learned) | Projects each token into "answer-label space" | Tokens learn *what to advertise* about themselves |
| `Q[i] · K[j]` (dot product) | Measures alignment between question and label | High score = strong relevance between token i and token j |
| `/ √d` (scaling) | Prevents dot products growing too large | Keeps softmax from saturating; maintains gradient flow |

Remove any one of these and context capture breaks:
- No W_Q/W_K → raw embeddings compared, no learned notion of relevance
- No dot product → no pairwise comparison, tokens stay isolated
- No √d scaling → softmax collapses to one-hot, attention becomes brittle

---

**A concrete example with this sentence:**

For the sentence *"Server shutdown occurred because power supply overheated"*,
a trained model's W_Q and W_K would cause:

- `"overheated"` (query) to have a high score against `"power"` and `"supply"` (keys)
  — because during training, cause-effect pairs repeatedly appeared together
- `"shutdown"` (query) to score highly against `"occurred"` — temporal relationship
- `"because"` (query) to score highly against both the cause and effect tokens

In this demo W_Q and W_K are random, so the scores `(currently ranging
{scores.min():.2f} to {scores.max():.2f})` are noise — but the **mechanism** is identical
to what a production model like Llama-3 runs on every forward pass.

---

**Computation cost note:**

The `Q @ Kᵀ` step produces a `N × N` matrix.  Cost scales as **O(N²)** in both
compute and memory.  For a 128k-token context window this is 128,000² = 16 billion
cells — the primary reason large context windows require so much GPU HBM memory,
and why CXL memory pooling is relevant for HPE inference servers.
        """
    )

# ── STEP 6: Softmax ───────────────────────────────────────────────────────────
st.markdown("## Step 6 — Softmax → Attention Weights")

col_a, col_b = st.columns([3, 1])
with col_b:
    st.info(
        "**Row sums**  \n"
        + "  \n".join(
            [f"`{tok}`: **{attn[i].sum():.4f}**" for i, tok in enumerate(tokens)]
        )
    )
with col_a:
    st.markdown(
        r"""
```
attn[i] = softmax(scores[i])   →  all values in [0, 1], row sums to 1
```
Softmax turns *raw scores* into a **probability distribution over tokens**.
Token `i` uses this distribution to decide *how much to listen* to each other token.
"""
    )

# ── STEP 7: Big attention heatmap ─────────────────────────────────────────────
st.markdown("## Step 7 — The Attention Matrix  _(centrepiece)_")

st.markdown(
    "> **Read this matrix:** row = query token, column = key token.  \n"
    "> A bright cell `[i, j]` means token **i** strongly attends to token **j**.  \n"
    "> Each row sums to **1.0**."
)

fig_big = plot_attention_heatmap_large(attn, tokens)
st.pyplot(fig_big, use_container_width=False)

# Highlight the top attending pair
flat_idx = np.unravel_index(np.argmax(attn), attn.shape)
st.success(
    f"**Strongest attention:** `{tokens[flat_idx[0]]}` → `{tokens[flat_idx[1]]}`  "
    f"(weight = {attn[flat_idx]:.3f})"
)

# Per-token top-3 attention
st.markdown("#### Each token's top-3 attended tokens")
rows = []
for i, tok in enumerate(tokens):
    top3_idx = np.argsort(attn[i])[::-1][:3]
    rows.append({
        "Query token": tok,
        "1st": f"{tokens[top3_idx[0]]}  ({attn[i, top3_idx[0]]:.3f})",
        "2nd": f"{tokens[top3_idx[1]]}  ({attn[i, top3_idx[1]]:.3f})",
        "3rd": f"{tokens[top3_idx[2]]}  ({attn[i, top3_idx[2]]:.3f})" if N >= 3 else "—",
    })
st.dataframe(pd.DataFrame(rows).set_index("Query token"), use_container_width=False)

# ── STEP 8: Output ────────────────────────────────────────────────────────────
st.markdown("## Step 8 — Output  =  Attention × V")

col_a, col_b = st.columns([3, 1])
with col_a:
    st.markdown(
        r"""
```
output = attn_weights  @  V        (shape: N × d)
```
Each output row is a **weighted blend of all Value vectors**, weighted by attention.
The token's representation is now *context-aware* — it has absorbed information
from the other tokens it attended to.
"""
    )
with col_b:
    st.info(
        "**Before attention:** each token knew only itself.  \n"
        "**After attention:** `overheated` is enriched with context from "
        "`power`, `supply`, `shutdown`, etc."
    )

fig_out = plot_heatmap(
    output, tokens, dim_labels,
    f"Output  =  Attention × V  ({N} × {D})  — context-aware representations",
    cmap="PuBuGn", row_colors=tok_colors,
)
st.pyplot(fig_out, use_container_width=False)

with st.expander("Deep dive — what is V, how is it computed, and what does it actually do?", expanded=True):
    st.markdown(
        f"""
**What is V (Value)?**

V is the **payload** — the actual information each token contributes to the output.
While Q and K play a matchmaking role (deciding *who attends to whom*), V carries
*what gets transferred* once a match is made.

```
V = X @ W_V        # shape: (N × d)
```

Every token produces a Value vector by projecting its embedding through `W_V`.
The attention weights (from Step 7) then decide how much of each token's V gets
mixed into every output position.

---

**Is W_V trained or only used at inference?**

| Phase | What happens to W_V |
|---|---|
| Initialisation | Small random values (same as W_Q, W_K) |
| Training | Updated by backpropagation — gradients flow from the loss all the way back through `attn @ V` into W_V |
| Inference | **Frozen** — loaded from checkpoint, never updated |
| Per token | Not changed — each token's V vector differs only because its input embedding `X[i]` differs |

So the answer is the same as W_Q and W_K: **W_V is learned during training, frozen
at inference**.  The V vectors themselves are recomputed fresh each forward pass
from the (fixed) W_V and the (variable) input tokens.

---

**How exactly is V computed — step by step?**

```
1. Start with X[i]         — the embedding of token i,  shape (d,)
2. V[i] = X[i] @ W_V      — linear projection, shape (d,)
3. output[i] = Σ_j  attn[i,j] * V[j]    — weighted sum over ALL token Values
```

Step 3 is the key: `output[i]` is not just token i's own V — it is a **blend of
every token's V**, where the blend weights come from the attention matrix row i.

Example with the current sentence:
- If `attn["overheated", "power"] = {attn[tokens.index("overheated"), tokens.index("power")] if "overheated" in tokens and "power" in tokens else "high"}`
  then `output["overheated"]` picks up a large fraction of `V["power"]`
- The output vector for "overheated" now geometrically sits *between* its own V
  and the V vectors of the tokens it attended to most

---

**Why have a separate W_V at all — why not just use the embeddings directly?**

Without W_V you would mix raw embeddings, which encode identity ("what word am I?").
W_V lets the model learn a separate projection that encodes *what information is
useful to share in this context*.  A single token can advertise different content
depending on what the model learns to extract.

Think of it this way:
- `W_K` = a token's *public label* ("I am a power-related concept")
- `W_V` = a token's *actual data payload* ("here is the specific power information
  that is useful for downstream reasoning")

Training can make these very different — a token might have a K that matches many
queries but a V that only transfers a narrow, task-relevant piece of information.

---

**Impact on the output — what changes when V is "good" (trained) vs random?**

| W_V state | What output[i] contains |
|---|---|
| **Random (this demo)** | Meaningless blend — noise weighted by noise |
| **Trained** | Semantically enriched representation — "overheated" now carries geometric signal from "power", "supply", "shutdown" |
| **Perfectly trained** | output[i] is the ideal context-fused representation for predicting the next token or answering a query |

In this demo `W_V = rng.standard_normal((D, D)) * 0.5` so all V vectors are random.
The heatmap above shows plausible-looking numbers, but they carry no meaning.
In a real model, the V projection is what makes the attention output genuinely useful
as input to the next transformer layer or the final unembedding step.
        """
    )

# ── STEP 9: Summary ───────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("## Step 9 — Full Picture")

st.markdown(
    """
    <div style="background:#f8f9fa;border-left:5px solid #4e79a7;
                border-radius:6px;padding:18px 22px;margin:10px 0">
    <table style="width:100%;border-collapse:collapse">
      <tr style="background:#4e79a7;color:white">
        <th style="padding:8px">Step</th><th style="padding:8px">Operation</th>
        <th style="padding:8px">Shape</th><th style="padding:8px">What it gives you</th>
      </tr>
      <tr><td>1</td><td>Tokenise</td><td>N tokens</td><td>Words → discrete IDs</td></tr>
      <tr style="background:#eef2f7"><td>2</td><td>Embed → X</td><td>N × d</td><td>Each token as a real vector</td></tr>
      <tr><td>3</td><td>Q = X·W_Q</td><td>N × d</td><td>What each token is <em>looking for</em></td></tr>
      <tr style="background:#eef2f7"><td>4</td><td>K = X·W_K</td><td>N × d</td><td>What each token <em>offers</em></td></tr>
      <tr><td>5</td><td>V = X·W_V</td><td>N × d</td><td>The information each token <em>carries</em></td></tr>
      <tr style="background:#eef2f7"><td>6</td><td>scores = QKᵀ/√d</td><td>N × N</td><td>Raw relevance between every pair</td></tr>
      <tr><td>7</td><td>attn = softmax(scores)</td><td>N × N</td><td>Normalised attention distribution</td></tr>
      <tr style="background:#eef2f7"><td>8</td><td>out = attn · V</td><td>N × d</td><td>Context-enriched token representations</td></tr>
    </table>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    **Key insight for  engineers:**
    Every step is a **matrix multiply (GEMM)**.
    GPUs are purpose-built for GEMM → this is why transformers scale so well on  GPU nodes.
    Larger context window = larger N × N attention matrix = more HBM bandwidth required (CXL matters here).
    """,
)

st.caption(
    " GenAI Training"
    "Transformer Internals: Attention Mechanism  |  "
    "Adjust sentence & controls in the sidebar ←"
)

# ── STEP 10: Missing piece — FFN, then Unembedding ────────────────────────────
st.markdown("---")
st.markdown("## Step 10 — The Missing Piece: FFN  +  Unembedding")

st.warning(
    "**⚠️  What a real transformer does between Step 8 and here (skipped in this demo)**\n\n"
    "After the attention output, every transformer block runs a **Feed-Forward Network (FFN / MLP)**:\n\n"
    "```\n"
    "h = GELU( output @ W1 + b1 ) @ W2 + b2     # W1: d→4d,  W2: 4d→d\n"
    "x = LayerNorm( output + h )                 # residual + normalise\n"
    "```\n\n"
    "The FFN is where the model stores **factual knowledge** (the W1/W2 matrices act as a "
    "key-value memory).  It runs independently on each token — no cross-token mixing — "
    "and accounts for ~2/3 of a model's total parameters.  "
    "We skip it here because its output has the same shape `(N × d)` as `output`, "
    "so the unembedding step below looks identical either way."
)

st.markdown(
    r"""
### Unembedding — projecting back to vocabulary space

After `N` transformer blocks (each = Attention + FFN), we take the **last token's**
final hidden vector and multiply by the unembedding matrix `W_U`:

```
logits = output[-1]  @  W_U        # shape: (vocab_size,)
probs  = softmax(logits)           # probability over every word in the vocabulary
```

- `output[-1]` is the last token's context-aware representation — it has "seen" all
  preceding tokens via attention and (in a full model) processed them via FFN.
- `W_U` (shape `d × vocab_size`) maps from model-space back into vocabulary space.
  It is a **learned** matrix — often weight-tied with the input embedding table.
- The highest-probability token is the model's next-word prediction.

---

**⚠️ Are these logits real?  No — they are random noise in this demo.**

Every matrix in the pipeline (`X`, `W_Q`, `W_K`, `W_V`, `W_U`) is sampled from
`np.random.standard_normal(seed)`.  The word that appears top-ranked is a pure
accident of the random seed — change the seed slider and the ranking reshuffles completely.
In a trained model, `W_U` has been adjusted over trillions of tokens so that the dot
product genuinely reflects which word belongs next.

---

**How does dot product → token lookup actually work?**

Each column of `W_U` is a learned *direction* in the model's `d`-dimensional space
that "points toward" one specific vocabulary word.  The dot product

```
logits[j] = dot( output[-1],  W_U[:, j] )
```

measures how strongly the last token's hidden vector aligns with the direction for
word `j`.  High alignment → high logit → that word is a likely next token.

Step by step:

```
1. output[-1]         shape (d,)          — context-enriched vector for last token
2. @ W_U              shape (d, vocab)    — one column per vocabulary word
   = logits           shape (vocab,)      — one score per word

3. probs = softmax(logits)                — convert scores to a probability distribution
                                            (all values 0–1, sum = 1.0)

4. predicted = argmax(probs)             — pick the index with highest probability
5. token = VOCAB[predicted]              — look up that index in the vocabulary list
                                            ← this is the "token lookup"
```

`argmax` is the simplest decoding strategy (greedy).  In practice, models use
**top-k** or **nucleus (top-p) sampling** to pick from the highest-probability
candidates rather than always taking the single best — this produces more natural,
varied text instead of repetitive greedy output.
"""
)

with st.expander(
    "Why do we need W_U at all?  Don't attention-adjusted vectors already encode contextual meaning?",
    expanded=True,
):
    st.markdown(
        f"""
**Short answer: Yes, the vectors do encode contextual meaning — but they live in the
wrong space to directly pick a token.  W_U is the bridge.**

---

**Your intuition is correct — attention DOES adjust the vectors**

Consider your example:

| Sentence | "Server" after attention |
|---|---|
| *"Server was shutdown"* | output["Server"] pulls in V["shutdown"], V["power"], V["fault"] → the vector shifts toward hardware/failure concepts |
| *"Server did not treat us well"* | output["Server"] pulls in V["treat"], V["well"], V["us"] → the vector shifts toward social/service concepts |

These two "Server" output vectors genuinely end up in different geometric regions of
the d-dimensional model space.  The attention mechanism has done exactly what it
should — produced context-aware representations.

So why can't we just look up the nearest token to that adjusted vector?

---

**The problem: two different spaces, two different dimensionalities**

```
Model hidden space:   d dimensions        (e.g. d = 4096 for Llama-7B)
Vocabulary space:     vocab_size entries   (e.g. 32,000 tokens for Llama)
```

These are not the same space.  The hidden vector `output[-1]` is a point in
ℝ^d (4096 dimensions).  The vocabulary is a discrete list of 32,000 integer IDs.
There is no direct geometric "nearest token" operation — you cannot compute a
distance between a 4096-dimensional float vector and a token ID like `"shutdown"`.

To bridge this, you need a way to *score* every vocabulary word against the
hidden vector.  That is exactly what W_U does:

```
W_U shape:  (d × vocab_size)     one column per vocabulary word, each of length d
logits[j] = dot( output[-1],  W_U[:, j] )
           = "how much does the hidden vector point toward word j's direction?"
```

Each column of W_U is a learned d-dimensional direction that represents one word
**in the model's own space**.  The dot product is the nearest-neighbour lookup —
just expressed as a matrix multiply instead of an explicit distance search.

---

**But isn't that what the input embedding table W_E already does?**

Yes — and this is why W_U is often **weight-tied** with W_E (they share the same
matrix, transposed).  The input embedding table W_E maps token IDs → d-dimensional
vectors.  W_U maps d-dimensional vectors → token scores.  They are inverses of each
other, and tying their weights enforces geometric consistency:

```
W_E[j]       = the vector for word j in model space   (shape: d)
W_U[:, j]    = the direction that "detects" word j     (shape: d)

If weight-tied: W_U[:, j] == W_E[j]
→ logits[j] = dot(output[-1], W_E[j])
            = "how similar is the hidden state to word j's embedding?"
```

This is the most elegant interpretation: **the model predicts the next token by
finding which input embedding is geometrically closest to the final hidden state**,
measured by dot product similarity.

---

**So why doesn't the hidden state just equal an embedding vector directly?**

Three reasons:

1. **The residual stream accumulates information from many layers.**
   After N transformer blocks, LayerNorms, FFN expansions, and residual additions,
   the hidden vector has drifted from the original embedding geometry.  W_U
   re-anchors it back to vocabulary space.

2. **The model's internal geometry ≠ the input embedding geometry.**
   Attention heads and FFN layers transform the hidden state in ways that are
   useful for computation but not necessarily aligned with the original embedding
   table.  W_U is trained to compensate for this drift.

3. **Dimensions may differ.**
   Some architectures use different embedding dim vs hidden dim.  W_U handles the
   projection even when they don't match.

---

**Geometric summary**

```
Input:   token IDs  ──W_E──►  d-dim embedding space  (model reasons here)
                                      │
                              N × (Attention + FFN)   (context fusion, factual lookup)
                                      │
                              final hidden state       (still in d-dim space)
                                      │
Output:              ──W_U──►  vocab_size logit space  (one score per word)
                                      │
                              softmax + argmax/sample  (pick the next token)
```

The hidden state for "Server" in a power-failure context genuinely points toward
the "fault / shutdown / overheated" region of ℝ^d — your geometric intuition is
right.  W_U then measures how strongly that region aligns with each word's column,
converting continuous geometry into a discrete probability over the vocabulary.
        """
    )

# ── Toy vocabulary (domain-relevant; keeps demo self-contained) ───────────────
VOCAB = [
    "shutdown", "overheated", "temperature", "power", "critical",
    "warning", "normal", "fault", "reboot", "sensor",
    "CPU", "memory", "fan", "alert", "firmware",
    "threshold", "exceeded", "stable", "detected", "failure",
]
VOCAB_SIZE = len(VOCAB)

# ⚠️  W_U is RANDOM here — in a trained model this matrix is learned from data
# and its columns encode "how much does this hidden-state direction vote for word X"
W_U = rng.standard_normal((D, VOCAB_SIZE)) * 0.5

# Take only the last token's hidden vector for next-token prediction
last_hidden = output[-1]                   # shape: (D,)
logits      = last_hidden @ W_U            # shape: (VOCAB_SIZE,)
next_probs  = softmax(logits)              # shape: (VOCAB_SIZE,)

TOP_K = min(8, VOCAB_SIZE)
top_idx   = np.argsort(next_probs)[::-1][:TOP_K]
top_words = [VOCAB[i] for i in top_idx]
top_p     = next_probs[top_idx]

# ── Layout: logits bar + probability bar side by side ─────────────────────────
col_left, col_right = st.columns(2)

with col_left:
    st.markdown(f"#### Raw logits  (`output[-1] @ W_U`)  — last token: `{tokens[-1]}`")
    fig_logits, ax_l = plt.subplots(figsize=(5, 3.5))
    colors_logits = ["#e15759" if v >= 0 else "#4e79a7" for v in logits[top_idx]]
    ax_l.barh(top_words[::-1], logits[top_idx][::-1], color=colors_logits[::-1], edgecolor="white")
    ax_l.axvline(0, color="#999", linewidth=0.8, linestyle="--")
    ax_l.set_xlabel("Logit value", fontsize=9)
    ax_l.set_title("Top-8 raw logits\n(before softmax)", fontsize=10, fontweight="bold")
    ax_l.tick_params(labelsize=9)
    plt.tight_layout()
    st.pyplot(fig_logits, use_container_width=True)

with col_right:
    st.markdown("#### After softmax — next-token probability distribution")
    fig_probs, ax_p = plt.subplots(figsize=(5, 3.5))
    bar_colors = [TOKEN_COLORS[i % len(TOKEN_COLORS)] for i in range(TOP_K)]
    bars = ax_p.barh(top_words[::-1], top_p[::-1], color=bar_colors[::-1], edgecolor="white")
    for bar, p in zip(bars, top_p[::-1]):
        ax_p.text(bar.get_width() + 0.002, bar.get_y() + bar.get_height() / 2,
                  f"{p:.3f}", va="center", fontsize=8)
    ax_p.set_xlim(0, top_p.max() * 1.25)
    ax_p.set_xlabel("Probability", fontsize=9)
    ax_p.set_title("Top-8 next-token probabilities\n(softmax output)", fontsize=10, fontweight="bold")
    ax_p.tick_params(labelsize=9)
    plt.tight_layout()
    st.pyplot(fig_probs, use_container_width=True)

# ── Prediction callout ────────────────────────────────────────────────────────
predicted_token = VOCAB[top_idx[0]]
st.info(
    f"**Predicted next token:** `{predicted_token}`  (p = {top_p[0]:.3f})\n\n"
    f"*Remember: W_U is random in this demo — these probabilities are meaningless.  "
    f"In a trained model (e.g. Llama-3), W_U is learned so that after seeing "
    f'"{" ".join(tokens)}", the highest-probability token would be contextually correct.*'
)

# ── STEP 11: Full pipeline summary including FFN + Unembedding ────────────────
st.markdown("---")
st.markdown("## Step 11 — Complete Transformer Pipeline")

st.markdown(
    """
    <div style="background:linear-gradient(90deg,#1a1a2e,#16213e);
                border-radius:12px;padding:18px 28px;margin:12px 0">
        <p style="color:#aaa;font-size:12px;letter-spacing:1px;margin:0 0 10px 0">
            FULL SINGLE-LAYER BLOCK (repeated N times)
        </p>
        <p style="color:#ffd700;font-size:15px;font-family:monospace;margin:4px 0">
            x &nbsp;→&nbsp; LayerNorm &nbsp;→&nbsp; <b>Multi-Head Attention</b>
            &nbsp;→&nbsp; (+residual)
        </p>
        <p style="color:#ffd700;font-size:15px;font-family:monospace;margin:4px 0">
            &nbsp;&nbsp;→&nbsp; LayerNorm &nbsp;→&nbsp;
            <span style="color:#ff9da7"><b>FFN / MLP</b> ← skipped in this demo</span>
            &nbsp;→&nbsp; (+residual)
        </p>
        <p style="color:#ffd700;font-size:15px;font-family:monospace;margin:4px 0">
            &nbsp;&nbsp;→&nbsp; [repeat N layers, e.g. 32× for Llama-7B]
        </p>
        <p style="color:#ffd700;font-size:15px;font-family:monospace;margin:4px 0">
            &nbsp;&nbsp;→&nbsp; LayerNorm &nbsp;→&nbsp;
            <b>Unembedding (W_U)</b> &nbsp;→&nbsp; softmax &nbsp;→&nbsp;
            <span style="color:#76b7b2">next token ✓</span>
        </p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div style="background:#f8f9fa;border-left:5px solid #59a14f;
                border-radius:6px;padding:18px 22px;margin:10px 0">
    <table style="width:100%;border-collapse:collapse">
      <tr style="background:#59a14f;color:white">
        <th style="padding:8px">Component</th>
        <th style="padding:8px">Operation</th>
        <th style="padding:8px">Shape change</th>
        <th style="padding:8px">Learned weights</th>
      </tr>
      <tr><td>Embedding</td><td>token_id → vector</td><td>N → N × d</td><td>W_E  (vocab × d)</td></tr>
      <tr style="background:#eef2f7"><td>Attention (this demo)</td><td>Q·Kᵀ/√d → softmax → ×V</td><td>N×d → N×d</td><td>W_Q, W_K, W_V</td></tr>
      <tr><td style="color:#e15759;font-weight:600">FFN / MLP ⚠️ skipped</td><td>GELU(x·W1)·W2</td><td>N×d → N×4d → N×d</td><td>W1, W2, b1, b2</td></tr>
      <tr style="background:#eef2f7"><td>Unembedding (this demo)</td><td>last_hidden @ W_U</td><td>d → vocab_size</td><td>W_U  (d × vocab)</td></tr>
      <tr><td>Sampling</td><td>softmax → argmax / top-k</td><td>vocab_size → 1 token</td><td>—</td></tr>
    </table>
    </div>
    """,
    unsafe_allow_html=True,
)

# ── BEYOND DECODER-ONLY: Cross-Attention & Encoder-Decoder Models ─────────────
st.markdown("---")
st.markdown("## Beyond This Demo — Cross-Attention & Encoder-Decoder Architecture")

with st.expander(
    "When does control pass to the decoder?  Does the encoder do unembedding?  "
    "How does cross-attention differ from self-attention?",
    expanded=True,
):
    st.markdown(
        """
This demo shows a **decoder-only** model (GPT / Llama style) — one stack of
self-attention layers that reads and generates in a single pass.  Models like
**T5, BART, and the original "Attention Is All You Need"** use a different
architecture: a separate **encoder** and **decoder** connected by **cross-attention**.

---

### The short answers

| Question | Answer |
|---|---|
| Does the encoder do unembedding? | **No** — the encoder only produces context vectors, never predicts tokens |
| When does control pass to the decoder? | After the encoder's **full N-block stack** completes — not mid-block |
| Is the encoder output handed off once? | **No** — it is injected into **every single decoder block** via cross-attention |

---

### Full encoder-decoder flow

```
ENCODER  (e.g. T5, BART, original Transformer)
──────────────────────────────────────────────────────────────────
Input tokens → Embeddings
  └─► [ Self-Attention  →  FFN ] × N blocks     ← runs to completion
                ↓
  Encoder output: shape (N_src × d)             ← K and V extracted here
                ↓  fed into EVERY decoder layer
                ↓
DECODER
──────────────────────────────────────────────────────────────────
Target tokens → Embeddings
  └─► [ Masked Self-Attention                   ← decoder attends only to its own past tokens
              ↓
         Cross-Attention                         ← Q from decoder, K+V from encoder output ←┐
              ↓                                                                              │
         FFN ] × N blocks                        ← encoder output reused in every block ────┘
              ↓
  Unembedding (W_U) → softmax → next token       ← only here, decoder side only
```

---

### What is cross-attention, and how does it differ from self-attention?

In **self-attention** (what this demo shows), Q, K, and V all come from the
**same sequence** — every token attends to every other token in its own input:

```
Q = X @ W_Q     # X is the current sequence
K = X @ W_K     # same X
V = X @ W_V     # same X
```

In **cross-attention**, the query comes from the **decoder's own hidden state**,
but the keys and values come from the **encoder's output**:

```
Q = decoder_hidden  @ W_Q     # "what is the decoder looking for?"
K = encoder_output  @ W_K     # "what did the encoder see in the source?"
V = encoder_output  @ W_V     # "what information does the encoder carry?"
```

The decoder is essentially asking: *"given where I am in my generation, which
parts of the encoder's source representation should I pay attention to?"*

---

### Why is the encoder output injected into EVERY decoder layer — not just once?

Each decoder layer gets to ask **different questions** of the encoder output.
Early decoder layers may query for syntactic structure; later layers query for
semantic content.  The encoder's K and V matrices act as a **persistent memory**
the decoder consults at every depth:

```
Decoder layer 1  →  cross-attention with encoder K, V  →  picks up source syntax
Decoder layer 2  →  cross-attention with encoder K, V  →  picks up source semantics
...
Decoder layer N  →  cross-attention with encoder K, V  →  refines final meaning
```

---

### HPE / ILO analogy

Think of the encoder as a **telemetry parser** that reads all ILO sensor events
and compresses them into a context vector.  The decoder is a **response generator**
that, at each generation step, queries that compressed sensor context to decide
what to write next in the fault report — just like cross-attention queries the
encoder output at every layer.

---

### Decoder-only vs encoder-decoder — when to use which?

| | Decoder-only (GPT, Llama) | Encoder-Decoder (T5, BART) | Encoder-only (BERT, RoBERTa) |
|---|---|---|---|
| Architecture | Single stack, self-attention only | Two stacks + cross-attention | Single encoder stack, bidirectional self-attention |
| Best for | Open-ended generation, chat, agents | Translation, summarisation, structured output | Classification, embeddings, retrieval, NER |
| Parameters | Fewer (one stack) | More (two stacks + cross-attn weights) | Fewer (one stack, no unembedding head) |
| Modern trend | Dominant for LLMs at scale | Still preferred for seq2seq tasks | Dominant for embedding / search workloads |
| HPE use case | ILO log analysis, firmware agents | ILO alert → human-readable report translation | ILO log semantic search, anomaly classification |
"""
    )

# ═══════════════════════════════════════════════════════════════════════════════
# WHAT HAPPENS NEXT — steps this demo does NOT show
# ═══════════════════════════════════════════════════════════════════════════════
#
# After the attention output (shape N × d) is produced, a full transformer layer
# passes it through two more sub-steps before the result moves to the next layer:
#
# ── 1.  MULTI-LAYER PERCEPTRON  (Feed-Forward Network, FFN) ──────────────────
#
#   output_ffn = GELU( output @ W1 + b1 ) @ W2 + b2
#
#   • Applied *independently* to each token's vector (no cross-token mixing here).
#   • W1 expands the dimension from d → 4d (or higher), W2 projects back to d.
#     This "expand-then-contract" structure lets the network store factual
#     knowledge: research shows individual neurons in W1/W2 can encode specific
#     facts (e.g. "Paris is the capital of France").
#   • Both W1 and W2 are ⚠️ LEARNED weight matrices — the largest share of a
#     transformer's parameters live here (typically ~2/3 of total parameters).
#   • After the FFN, a residual connection (+ LayerNorm) is added, then the
#     result is fed into the next transformer block.
#
#    note: the FFN GEMMs (d → 4d → d) dominate compute at inference time
#   on large models, which is why  GPU nodes with high HBM bandwidth and
#   tensor-core throughput matter more than raw clock speed.
#
# ── 2.  UNEMBEDDING  (final layer only — converts vectors back to token probs) ─
#
#   logits = final_hidden_state @ W_U      (shape: N × vocab_size)
#   probs  = softmax(logits[-1])           (we only care about the LAST token
#                                           when doing next-token prediction)
#
#   • W_U  is the *unembedding matrix* (shape: d × vocab_size).
#     It is the inverse of the token embedding table — it projects from
#     model-dimension space back into vocabulary space.
#   • ⚠️ LEARNED — often tied (shared weights) with the input embedding matrix
#     to reduce parameter count (a technique called "weight tying").
#   • The output is a probability distribution over the entire vocabulary
#     (~32 000 tokens for Llama, ~50 000 for GPT-2).  The next token is
#     sampled from this distribution (greedy, top-k, or nucleus sampling).
#
#   ILO analogy: think of unembedding as translating the model's internal
#   "compressed sensor state" back into a human-readable log message or
#   a specific command token your firmware agent can act on.
#
# ── 3.  RESIDUAL CONNECTIONS  ("skip connections") ──────────────────────────
#
#   x_out = x_in + sublayer(x_in)        ← the "+" is the residual
#
#   • Instead of replacing x_in with the sublayer's output, we ADD the output
#     back to the original input.  The sublayer only needs to learn the
#     *delta* (residual) — a much easier optimisation target.
#
#   • PRIMARY purpose — training stability in deep networks:
#     Gradients can flow directly back through the "+" shortcut path all the
#     way to early layers without passing through every weight matrix.
#     This solves the vanishing-gradient problem that killed deep RNNs.
#     A 96-layer GPT-3 would be untrainable without residual connections.
#
#   • Does it reduce overfitting?  Indirectly, yes — but that is NOT its
#     main job.  The mechanism is:
#       - Training converges faster and to better minima, so you need fewer
#         epochs and less aggressive regularisation.
#       - Deep networks without residuals tend to memorise rather than
#         generalise because gradient signal degrades; residuals keep all
#         layers learning meaningful features.
#     But dedicated anti-overfitting tools (Dropout, weight decay, data
#     augmentation) are separate and are still needed alongside residuals.
#
#   Firmware analogy: think of residuals like a hardware interrupt fallback —
#   if the new logic (sublayer) has nothing important to add, the signal passes
#   through unchanged.  The system is robust to any single layer doing "nothing."
#
# ── 4.  LAYER NORMALISATION  (LayerNorm) ─────────────────────────────────────
#
#   LayerNorm(x) = γ · (x − μ) / (σ + ε)  + β
#
#   where μ, σ are the mean and std computed across the d dimensions of a
#   SINGLE token's vector (not across the batch), γ and β are ⚠️ LEARNED
#   per-dimension scale and shift parameters.
#
#   • PRIMARY purpose — training stability, NOT overfitting prevention:
#     It keeps activations in a well-conditioned range so that weight updates
#     are predictable and learning rates can be set aggressively.
#     Without it, activations explode or vanish as they pass through 96+ layers.
#
#   • Why "Layer" norm and not "Batch" norm?
#     BatchNorm normalises across the batch dimension — fine for fixed-size
#     image grids, but sequences vary in length and batch size 1 (at inference)
#     makes batch statistics meaningless.  LayerNorm normalises within each
#     token vector independently, so it works at any batch size, including 1.
#     This matters enormously for autoregressive inference on an HPE server
#     handling single-request firmware queries.
#
#   • Does it reduce overfitting?  Only as a side-effect:
#     Normalised activations act as mild implicit regularisation (similar to
#     how BatchNorm does), but the effect is small.  Dropout (randomly zeroing
#     activations during training) is the transformer's main anti-overfitting
#     mechanism and is applied separately.
#
#   • Pre-LN vs Post-LN placement:
#     Original "Attention Is All You Need" paper used Post-LN:
#       x → sublayer → (+residual) → LayerNorm
#     Modern models (GPT-2 onward, Llama) use Pre-LN:
#       x → LayerNorm → sublayer → (+residual)
#     Pre-LN is more stable at the start of training (no "warm-up" LR tricks
#     needed) and is now the default in production transformer implementations.
#
# ── Full single-layer transformer block (summary) ────────────────────────────
#
#   x  →  LayerNorm  →  Multi-Head Attention  →  (+residual)   ← Pre-LN style
#      →  LayerNorm  →  FFN (MLP)             →  (+residual)
#      →  [repeat N times, e.g. 32 layers for Llama-7B]
#      →  LayerNorm  →  Unembedding  →  softmax  →  next token
#
#   Quick summary of what each component actually solves:
#   ┌─────────────────────┬──────────────────────────────┬─────────────────────┐
#   │ Component           │ Primary purpose              │ Overfitting impact  │
#   ├─────────────────────┼──────────────────────────────┼─────────────────────┤
#   │ Residual connection │ Vanishing gradient fix       │ Indirect / small    │
#   │ LayerNorm           │ Activation scale stability   │ Indirect / small    │
#   │ Dropout             │ Regularisation               │ Direct / large      │
#   │ Weight decay        │ Regularisation               │ Direct / large      │
#   └─────────────────────┴──────────────────────────────┴─────────────────────┘
#
# ═══════════════════════════════════════════════════════════════════════════════
