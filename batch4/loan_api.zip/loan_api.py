"""
Loan Approval Prediction API
=============================
Loads the trained RandomForest model (best_loan_approval_model.pkl)
and exposes a /predict endpoint.

Prerequisites:
    pip install fastapi uvicorn scikit-learn pandas

Run (from the mldemo directory):
    uvicorn loan_api:app --reload

Or from the parent directory:
    uvicorn mldemo.loan_api:app --reload

Interactive docs (Swagger UI):
    http://127.0.0.1:8000/docs
    Use the /predict endpoint there to test requests directly in the browser.

Example valid request body for POST /predict:
    {
        "age": 35,
        "dependents": 1,
        "credit_score": 720,
        "loan_term": 36,
        "proposed_emi": 15000,
        "existing_emi": 5000,
        "debt_to_income_ratio": 0.3,
        "monthly_income_log": 11.5,
        "loan_amount_log": 13.1,
        "co_applicant_income_log": 10.8,
        "education_encoded": 1,
        "credit_category_encoded": 2,
        "gender": "Male",
        "occupation": "Salaried - MNC",
        "property_area": "Urban",
        "loan_purpose": "Home Loan",
        "co_applicant": "No",
        "city": "Mumbai"
    }
"""

import pickle
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Literal

# ---------------------------------------------------------------------------
# Load model at startup (fail fast if pkl is missing)
# ---------------------------------------------------------------------------
import os

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "best_loan_approval_model.pkl")

try:
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
except FileNotFoundError:
    raise RuntimeError(
        f"Model file not found at '{MODEL_PATH}'. "
        "Run ml_loanapproval_prediction.py first to train and save the model."
    )

# ---------------------------------------------------------------------------
# Request schema  — accepts human-readable categorical values
# ---------------------------------------------------------------------------
class LoanApplication(BaseModel):
    age: float
    dependents: int
    credit_score: float
    loan_term: float                  # in months
    proposed_emi: float
    existing_emi: float
    debt_to_income_ratio: float
    monthly_income_log: float         # log(monthly_income)
    loan_amount_log: float            # log(loan_amount)
    co_applicant_income_log: float    # log(co_applicant_income + 1)
    education_encoded: int            # numeric encoding from training data
    credit_category_encoded: int      # numeric encoding from training data

    gender: Literal["Female", "Male"]
    occupation: Literal[
        "Salaried - Government",
        "Salaried - MNC",
        "Salaried - Private",
        "Self-Employed - Business",
        "Self-Employed - Professional",
    ]
    property_area: Literal["Rural", "Semi-Urban", "Urban"]
    loan_purpose: Literal[
        "Business Loan",
        "Education Loan",
        "Home Loan",
        "Personal Loan",
        "Vehicle Loan",
    ]
    co_applicant: Literal["No", "Yes"]
    city: Literal[
        "Ahmedabad", "Bangalore", "Chennai", "Delhi", "Hyderabad",
        "Jaipur", "Kolkata", "Lucknow", "Mumbai", "Pune",
    ]


def build_feature_vector(app: LoanApplication) -> pd.DataFrame:
    """Convert the request into the one-hot encoded DataFrame the model expects."""
    data: dict = {
        "age": app.age,
        "dependents": app.dependents,
        "credit_score": app.credit_score,
        "loan_term": app.loan_term,
        "proposed_emi": app.proposed_emi,
        "existing_emi": app.existing_emi,
        "debt_to_income_ratio": app.debt_to_income_ratio,
        "monthly_income_log": app.monthly_income_log,
        "loan_amount_log": app.loan_amount_log,
        "co_applicant_income_log": app.co_applicant_income_log,
        "education_encoded": app.education_encoded,
        "credit_category_encoded": app.credit_category_encoded,
    }

    for val in ["Female", "Male"]:
        data[f"gender_{val}"] = int(app.gender == val)

    for val in [
        "Salaried - Government", "Salaried - MNC", "Salaried - Private",
        "Self-Employed - Business", "Self-Employed - Professional",
    ]:
        data[f"occupation_{val}"] = int(app.occupation == val)

    for val in ["Rural", "Semi-Urban", "Urban"]:
        data[f"property_area_{val}"] = int(app.property_area == val)

    for val in ["Business Loan", "Education Loan", "Home Loan", "Personal Loan", "Vehicle Loan"]:
        data[f"loan_purpose_{val}"] = int(app.loan_purpose == val)

    for val in ["No", "Yes"]:
        data[f"co_applicant_{val}"] = int(app.co_applicant == val)

    for val in ["Ahmedabad", "Bangalore", "Chennai", "Delhi", "Hyderabad",
                "Jaipur", "Kolkata", "Lucknow", "Mumbai", "Pune"]:
        data[f"city_{val}"] = int(app.city == val)

    return pd.DataFrame([data])


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------
app = FastAPI(
    title="Loan Approval Prediction API",
    description="Predicts whether a loan will be approved using a tuned Random Forest model.",
    version="2.0.0",
)


@app.get("/")
def root():
    return {"message": "Loan Approval API is running. POST to /predict to get a prediction."}


@app.get("/health")
def health():
    return {"status": "ok", "model": type(model).__name__}


@app.post("/predict")
def predict(application: LoanApplication):
    """
    Returns:
        - prediction: 1 (Approved) or 0 (Rejected)
        - result: human-readable label
        - probability_approved: confidence score (0-1)
    """
    input_data = build_feature_vector(application)

    try:
        prediction = int(model.predict(input_data)[0])
        probability = float(model.predict_proba(input_data)[0][1])
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Prediction error: {str(e)}")

    return {
        "prediction": prediction,
        "result": "Approved" if prediction == 1 else "Rejected",
        "probability_approved": round(probability, 4),
    }
