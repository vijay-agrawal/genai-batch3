"""
pydantic.py
───────────────────────────────────────────────────────────────────────────────
Healthcare demos of Pydantic — from basic models to LLM-powered structured
output using Amazon Bedrock (Nova Micro).

WHAT THIS FILE COVERS
─────────────────────
1. Basic Pydantic model — Patient schema with auto type coercion
2. Validation Error     — Bad data caught before it reaches business logic
3. Optional fields      — Sensible defaults for missing data
4. Nested models        — Patient with embedded Vitals and Address
5. Custom validators    — Domain-specific rules (age range, BP format, BMI)
6. Serialization        — model → JSON and JSON → model round-trip
7. LLM + Pydantic (Extraction)  — LLM reads a clinical note and pulls out
                        facts that already exist in the text (reading task)
8. LLM + Pydantic (Generation)  — LLM reads a case description and reasons
                        about severity, treatment plan, red flags (thinking task)

KEY DIFFERENCE BETWEEN DEMO 7 AND DEMO 8
─────────────────────────────────────────
Demo 7 is EXTRACTION: the LLM acts like a reader — all the answers (name, age,
medications, etc.) are already present in the clinical note; it just needs to
find and format them.

Demo 8 is GENERATION / REASONING: the LLM acts like a clinician — it must
JUDGE the case (is it mild/moderate/severe?), PLAN treatment, IDENTIFY red
flags, and DECIDE whether a referral is needed. None of these answers exist
verbatim in the input text; the LLM has to reason them out.

Both use the identical Pydantic-as-contract pattern (LLM → JSON → Pydantic
validation → typed object). The difference is purely in what you ask the LLM
to do with the input.

RUN
───
pip install pydantic boto3 python-dotenv
python pydantic.py

Prereqs: .env file in project root with AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY
"""

# ── Standard + third-party imports ───────────────────────────────────────────
import json
import re
import os
from typing import Optional
from dotenv import load_dotenv

# Pydantic v2 imports
# BaseModel  → base class every schema inherits from
# Field      → attach metadata (description, default, constraints) to a field
# validator  → decorator for custom field-level validation logic
# ValidationError → raised when incoming data fails schema rules
from pydantic import BaseModel, Field, field_validator, ValidationError

# ── Load AWS credentials from .env ───────────────────────────────────────────
load_dotenv()

def strip_markdown_json(text: str) -> str:
    """
    LLMs often wrap JSON in markdown fences like:
        ```json
        { ... }
        ```
    Pydantic's model_validate_json expects raw JSON with no surrounding text.
    This helper strips those fences so validation works correctly.
    """
    # Remove ```json ... ``` or ``` ... ``` wrappers
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()

# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 1 — Basic Pydantic Model (Patient)
#
# Key concept: define a class that inherits BaseModel.
# Each class attribute becomes a validated, typed field.
# Pydantic will COERCE compatible types (e.g. "45" → 45 for an int field).
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 1 — Basic Patient Model (type coercion)")
print("═" * 60)
print("Story: A hospital receives patient data from an external API.")
print("The API returns 'age' as a string '45' instead of an integer.")
print("Pydantic quietly fixes this — no manual casting needed.\n")

class Patient(BaseModel):
    # str field — must be a string (or coercible to one)
    patient_id: str

    # int field — "45" as a string will be silently coerced to 45
    age: int

    # str field
    diagnosis: str


# Simulate data arriving from an API / LLM where age came back as a string
raw_data = {
    "patient_id": "P1001",
    "age": "45",          # <-- string, will be coerced to int automatically
    "diagnosis": "Hypertension"
}

patient = Patient(**raw_data)
print(f"✔ Patient admitted successfully:")
print(f"  Patient ID  : {patient.patient_id}")
print(f"  Age         : {patient.age}  ← was the string '45', coerced to int {type(patient.age).__name__}")
print(f"  Diagnosis   : {patient.diagnosis}")
print(f"\n  Full model repr: {patient}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 2 — Validation Error
#
# Key concept: if incoming data is INCOMPATIBLE (not coercible), Pydantic
# raises a ValidationError with a clear, structured error message.
# This is critical in production — bad data is caught BEFORE it reaches your
# business logic or database.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 2 — Validation Error (bad data caught at the gate)")
print("═" * 60)
print("Story: The same API now sends a garbled record — age is the word")
print("'sixty two' instead of a number. Pydantic refuses to accept it")
print("and tells us exactly which field failed and why.\n")

bad_data = {
    "patient_id": "P1002",
    "age": "sixty two",   # <-- cannot be converted to int → ValidationError
    "diagnosis": "Diabetes"
}

try:
    bad_patient = Patient(**bad_data)
except ValidationError as e:
    # e.errors() returns a structured list of all validation failures
    print("✘ Admission rejected — validation failed (expected):")
    for err in e.errors():
        # loc  → which field failed
        # msg  → human-readable reason
        print(f"  Field : {err['loc']}")
        print(f"  Error : {err['msg']}")
    print("\n  ↳ The bad record never reached the database. Crisis averted.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 3 — Optional Fields & Default Values
#
# Key concept: wrap a type with Optional[X] to allow None, and use
# Field(default=...) to provide fallback values.
# This is useful when LLM output or API payloads may omit certain keys.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 3 — Optional Fields & Defaults")
print("═" * 60)
print("Story: A walk-in patient arrives at the ER with very little info on")
print("file — no medication list, no assigned physician, not yet triaged.")
print("The model accepts partial data and fills in sensible defaults.\n")

class PatientFull(BaseModel):
    patient_id: str
    age: int
    diagnosis: str

    # Optional fields — these will default to None / given value if absent
    medication: Optional[list[str]] = None          # no meds listed yet
    attending_physician: Optional[str] = None       # might not be assigned
    is_critical: bool = False                       # default: not critical
    ward: str = Field(default="General", description="Hospital ward name")

# Minimal payload — only required fields supplied
minimal = PatientFull(patient_id="P1003", age=30, diagnosis="Flu")
print(f"✔ Walk-in patient registered with minimal info:")
print(f"  Patient ID        : {minimal.patient_id}")
print(f"  Diagnosis         : {minimal.diagnosis}")
print(f"  Medication        : {minimal.medication}  ← defaulted to None (unknown)")
print(f"  Attending         : {minimal.attending_physician}  ← not yet assigned")
print(f"  Critical?         : {minimal.is_critical}  ← assumed stable")
print(f"  Ward              : {minimal.ward}  ← placed in General by default")

# Full payload — later the record is completed
full = PatientFull(
    patient_id="P1004",
    age=55,
    diagnosis="Cardiac Arrest",
    medication=["Aspirin", "Clopidogrel"],
    attending_physician="Dr. Smith",
    is_critical=True,
    ward="ICU"
)
print(f"\n✔ Another patient — fully documented after assessment:")
print(f"  Patient ID        : {full.patient_id}")
print(f"  Diagnosis         : {full.diagnosis}")
print(f"  Medication        : {full.medication}")
print(f"  Attending         : {full.attending_physician}")
print(f"  Critical?         : {full.is_critical}  ← flagged critical, moved to ICU")
print(f"  Ward              : {full.ward}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 4 — Nested Models
#
# Key concept: embed one Pydantic model inside another to represent
# hierarchical / relational data (e.g. a patient HAS vitals, HAS address).
# Pydantic validates the nested model recursively.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 4 — Nested Models (Vitals + Address inside Patient)")
print("═" * 60)
print("Story: A home-care coordinator needs the full patient record —")
print("vitals measured at admission AND the home address for follow-up.")
print("Each sub-record is its own Pydantic model, validated independently.\n")

class Vitals(BaseModel):
    """Represents a patient's measured vital signs."""
    blood_pressure: str          # e.g. "120/80"
    heart_rate: int              # beats per minute
    temperature_celsius: float   # body temperature
    oxygen_saturation: float     # SpO2 %

class Address(BaseModel):
    """Physical address — used for home-care coordination."""
    street: str
    city: str
    state: str
    zip_code: str

class HospitalPatient(BaseModel):
    patient_id: str
    name: str
    age: int
    diagnosis: str
    vitals: Vitals               # ← nested Pydantic model
    address: Address             # ← another nested model
    medication: list[str] = []

# Pydantic handles nested dict → nested model conversion automatically
hospital_data = {
    "patient_id": "P2001",
    "name": "Alice Johnson",
    "age": 67,
    "diagnosis": "Congestive Heart Failure",
    "vitals": {                  # dict is auto-converted to Vitals model
        "blood_pressure": "145/95",
        "heart_rate": 92,
        "temperature_celsius": 37.4,
        "oxygen_saturation": 94.2
    },
    "address": {                 # dict is auto-converted to Address model
        "street": "42 Maple Ave",
        "city": "Boston",
        "state": "MA",
        "zip_code": "02101"
    },
    "medication": ["Furosemide", "Lisinopril", "Carvedilol"]
}

hp = HospitalPatient(**hospital_data)
print(f"✔ Full patient record built with nested sub-models:")
print(f"  Patient    : {hp.name}, age {hp.age}")
print(f"  Diagnosis  : {hp.diagnosis}")
print(f"  Vitals     → BP: {hp.vitals.blood_pressure}, HR: {hp.vitals.heart_rate} bpm, "
      f"Temp: {hp.vitals.temperature_celsius}°C, SpO2: {hp.vitals.oxygen_saturation}%")
print(f"  Address    → {hp.address.street}, {hp.address.city}, {hp.address.state} {hp.address.zip_code}")
print(f"  Medications: {hp.medication}")
print(f"\n  ↳ hp.vitals and hp.address are full Pydantic objects, not plain dicts.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 5 — Custom Field Validators
#
# Key concept: @field_validator lets you add domain-specific rules that go
# beyond type checking.  Example: age must be 0-120, blood pressure must
# match the "systolic/diastolic" pattern.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 5 — Custom Field Validators")
print("═" * 60)
print("Story: Intake forms sometimes contain typos or impossible values —")
print("an age of 150, a BMI of 5, or a blood pressure written as '120-80'.")
print("Custom validators catch these before they corrupt the records.\n")

class ValidatedPatient(BaseModel):
    patient_id: str
    age: int
    blood_pressure: str   # expected format: "120/80"
    bmi: float

    # Validator for 'age' — must be a plausible human age
    @field_validator("age")
    @classmethod
    def check_age(cls, v):
        if not (0 <= v <= 120):
            raise ValueError(f"Age {v} is outside plausible range 0-120")
        return v

    # Validator for 'blood_pressure' — must match pattern NNN/NN or NN/NN
    @field_validator("blood_pressure")
    @classmethod
    def check_bp_format(cls, v):
        pattern = r"^\d{2,3}/\d{2,3}$"
        if not re.match(pattern, v):
            raise ValueError(
                f"blood_pressure '{v}' must be in 'systolic/diastolic' format e.g. '120/80'"
            )
        return v

    # Validator for 'bmi' — clinically implausible values are rejected
    @field_validator("bmi")
    @classmethod
    def check_bmi(cls, v):
        if not (10.0 <= v <= 80.0):
            raise ValueError(f"BMI {v} is outside plausible range 10-80")
        return v

# Valid patient
try:
    vp = ValidatedPatient(
        patient_id="P3001",
        age=45,
        blood_pressure="120/80",
        bmi=27.5
    )
    print(f"✔ Clean intake form — patient accepted:")
    print(f"  {vp}")
except ValidationError as e:
    print(f"Unexpected error: {e}")

# Invalid patient — age 150, bad BP format, impossible BMI
print("\n✘ Corrupted intake form (age=150, bp='120-80', bmi=5) — rejected:")
try:
    bad_vp = ValidatedPatient(
        patient_id="P3002",
        age=150,             # fails age validator
        blood_pressure="120-80",  # fails bp format validator
        bmi=5.0              # fails bmi validator
    )
except ValidationError as e:
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
    print("\n  ↳ All three domain-specific rules fired. Record blocked.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 6 — Serialization: model → JSON and JSON → model
#
# Key concept: Pydantic models have built-in methods for serialization.
#   model.model_dump()       → Python dict
#   model.model_dump_json()  → JSON string
#   Model.model_validate()   → parse dict/JSON into model (Pydantic v2)
#
# This is essential for storing records in a database, sending over HTTP,
# or logging structured events.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 6 — Serialization (model ↔ JSON)")
print("═" * 60)
print("Story: Alice's record (from Demo 4) needs to be saved to the database")
print("and later retrieved. Pydantic converts the model to JSON for storage")
print("and rebuilds an identical typed object when reading it back.\n")

# Reuse HospitalPatient from Demo 4
as_dict = hp.model_dump()
print("① model_dump() — Python dict (ready for a database insert):")
print(json.dumps(as_dict, indent=2))

# model → JSON string
as_json = hp.model_dump_json(indent=2)
print("\n② model_dump_json() — JSON string (ready to send over HTTP, first 200 chars):")
print(as_json[:200] + "…")

# JSON string → model (round-trip)
restored = HospitalPatient.model_validate_json(as_json)
print(f"\n③ model_validate_json() — restored from JSON back to a typed object:")
print(f"  Name: {restored.name}, BP: {restored.vitals.blood_pressure}")
print(f"  ↳ Round-trip complete — same data, fully validated Pydantic object.")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 7 — LLM Integration: Extract Structured Data from a Clinical Note
#
# Key concept: the LLM acts as a READER / EXTRACTOR.
# The clinical note already contains all the facts (name, age, diagnosis,
# medications, follow-up interval). The LLM's job is simply to find them
# and format them as JSON matching the Pydantic schema.
#
# This is an EXTRACTION task — not reasoning or judgment.
# Every value in the output schema can be directly traced back to a sentence
# in the input text.
#
# Flow:
#   Clinical note (free text)
#       → Bedrock LLM (prompted to return JSON)
#           → JSON string
#               → Pydantic model (validate + use safely)
#
# This is the CORE pattern used in LangChain, LlamaIndex, and OpenAI
# structured-output features — Pydantic acts as the contract.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 7 — LLM as Extractor: Clinical Note → Structured Patient Data")
print("(LLM reads facts that already exist in the text — no reasoning needed)")
print("═" * 60)
print("Story: A doctor's handwritten note arrives as plain text. We need")
print("the data in structured form to load into the EHR system. The LLM")
print("reads the note and pulls out facts — name, meds, follow-up — as JSON.\n")

# ── Pydantic schema for the LLM to populate ──────────────────────────────────
class ClinicalExtraction(BaseModel):
    """Schema we expect the LLM to fill from a clinical note."""
    patient_name: str
    age: int
    diagnosis: str
    symptoms: list[str]
    medications: list[str]
    follow_up_days: Optional[int] = None   # LLM might not always extract this

# ── Sample clinical note (unstructured text) ─────────────────────────────────
clinical_note = """
PATIENT: John Doe, 58-year-old male.
CHIEF COMPLAINT: Chest pain, shortness of breath, fatigue for 3 days.
ASSESSMENT: Stable angina likely secondary to coronary artery disease.
PLAN: Initiate Aspirin 81mg daily, Atorvastatin 40mg nightly, and
      Metoprolol 25mg twice daily. Follow up in 2 weeks.
"""

# ── System prompt that instructs the LLM to return structured JSON ────────────
# We embed the Pydantic schema's field names directly in the prompt so the LLM
# knows exactly what keys to produce.
system_prompt = """You are a clinical data extraction assistant.
Extract patient information from the provided clinical note and return ONLY
valid JSON (no markdown, no explanation) with these exact keys:
{
  "patient_name": "<string>",
  "age": <integer>,
  "diagnosis": "<string>",
  "symptoms": ["<string>", ...],
  "medications": ["<string>", ...],
  "follow_up_days": <integer or null>
}
"""

# ── Connect to Amazon Bedrock ─────────────────────────────────────────────────
AWS_ACCESS_KEY_ID     = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION            = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID              = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")

import boto3

bedrock = boto3.client(
    "bedrock-runtime",
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
)

# ── Call the LLM ──────────────────────────────────────────────────────────────
print(f"Calling Bedrock model: {MODEL_ID}")
print(f"Input note:\n{clinical_note.strip()}\n")

response = bedrock.converse(
    modelId=MODEL_ID,
    system=[{"text": system_prompt}],
    messages=[{"role": "user", "content": [{"text": clinical_note}]}],
    inferenceConfig={"maxTokens": 512, "temperature": 0.0},  # 0 temp for determinism
)

raw_llm_output = response["output"]["message"]["content"][0]["text"]
print(f"Raw LLM output:\n{raw_llm_output}\n")

# ── Parse and validate with Pydantic ─────────────────────────────────────────
# model_validate_json converts the JSON string into a ClinicalExtraction object
# and validates every field according to our schema.
try:
    extracted = ClinicalExtraction.model_validate_json(strip_markdown_json(raw_llm_output))
    print("✔ Pydantic-validated extraction (facts pulled from text):")
    print(f"  Patient      : {extracted.patient_name}, age {extracted.age}")
    print(f"  Diagnosis    : {extracted.diagnosis}")
    print(f"  Symptoms     : {extracted.symptoms}")
    print(f"  Medications  : {extracted.medications}")
    print(f"  Follow-up    : {extracted.follow_up_days} days")
    print(f"\n  ↳ All values came verbatim from the note — LLM just extracted them.")
except ValidationError as e:
    print("LLM output failed Pydantic validation:")
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
except json.JSONDecodeError as e:
    print(f"LLM did not return valid JSON: {e}")
    print(f"Raw output was: {raw_llm_output}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 8 — LLM as Diagnostic Reasoner (Schema-Driven Output)
#
# Key concept: the LLM acts as a CLINICIAN / REASONER.
# Unlike Demo 7 (extraction), here the LLM must JUDGE and DECIDE:
#   • severity   — mild / moderate / severe  (not stated in the input)
#   • treatment_plan — ordered steps the LLM recommends (not just copied)
#   • red_flags  — warning signs to monitor (requires clinical knowledge)
#   • referral_needed — true/false decision (requires judgment)
#
# This is a GENERATION / REASONING task. None of the output fields exist
# verbatim in the input — the LLM applies domain knowledge to produce them.
#
# The Pydantic pattern is identical to Demo 7; only the LLM's role changes.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 8 — LLM as Reasoner: Case Description → Clinical Summary")
print("(LLM judges severity, plans treatment, flags risks — not just extraction)")
print("═" * 60)
print("Story: A triage nurse enters a brief case description. Instead of")
print("pulling out facts, the LLM must reason: how severe is this? What")
print("treatment steps are needed? Should this patient be referred? The")
print("answers don't exist in the text — the LLM has to think them through.\n")

class ClinicalSummary(BaseModel):
    """Structured summary that a downstream EHR system would consume."""
    patient_name: str
    diagnosis: str
    severity: str               # "mild" | "moderate" | "severe"  ← LLM must judge this
    treatment_plan: list[str]   # ordered list of actions          ← LLM must plan this
    red_flags: list[str]        # warning signs to watch           ← LLM must identify these
    referral_needed: bool       # true/false                       ← LLM must decide this

schema_prompt = """You are a clinical documentation assistant.
Given a patient case, return ONLY valid JSON (no markdown) matching:
{
  "patient_name": "<string>",
  "diagnosis": "<string>",
  "severity": "<mild|moderate|severe>",
  "treatment_plan": ["<step1>", "<step2>", ...],
  "red_flags": ["<flag1>", ...],
  "referral_needed": <true|false>
}
"""

case_description = """
Patient Maria Torres, 72F, presents with progressive confusion, fever 38.9°C,
dysuria, and urinary frequency for 48 hours.  History of recurrent UTIs.
Labs show WBC 14,000, UA positive for nitrites and leukocyte esterase.
"""

print(f"Case:\n{case_description.strip()}\n")

resp2 = bedrock.converse(
    modelId=MODEL_ID,
    system=[{"text": schema_prompt}],
    messages=[{"role": "user", "content": [{"text": case_description}]}],
    inferenceConfig={"maxTokens": 512, "temperature": 0.0},
)

raw2 = resp2["output"]["message"]["content"][0]["text"]
print(f"Raw LLM output:\n{raw2}\n")

try:
    summary = ClinicalSummary.model_validate_json(strip_markdown_json(raw2))
    print("✔ Validated Clinical Summary (LLM reasoned, not just extracted):")
    print(f"  Patient         : {summary.patient_name}")
    print(f"  Diagnosis       : {summary.diagnosis}")
    print(f"  Severity        : {summary.severity}  ← LLM judged this from symptoms + labs")
    print(f"  Treatment Plan  :  ← LLM planned these steps")
    for step in summary.treatment_plan:
        print(f"    • {step}")
    print(f"  Red Flags       :  ← LLM identified these from clinical knowledge")
    for flag in summary.red_flags:
        print(f"    ⚠ {flag}")
    print(f"  Referral Needed : {summary.referral_needed}  ← LLM made this decision")
    print(f"\n  ↳ None of these values were stated in the input — LLM reasoned them out.")
except ValidationError as e:
    print("Validation error on clinical summary:")
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
except json.JSONDecodeError as e:
    print(f"JSON parse error: {e}\nRaw: {raw2}")


print("\n" + "═" * 60)
print("All demos complete.")
print("═" * 60)
