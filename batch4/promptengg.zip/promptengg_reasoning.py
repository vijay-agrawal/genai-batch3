"""
promptengg_reasoning.py
───────────────────────────────────────────────────────────────────────────────
Prompt Engineering demos — Reasoning & Summarization using Azure Foundry.

WHAT THIS FILE COVERS
─────────────────────
1.  Reasoning Types    — deductive, inductive, abductive, analogical
2.  Summarization      — extractive vs abstractive

Run: python promptengg_reasoning.py
Prereqs: .env with AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_MODEL_NAME
"""

import os
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv


def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env in any parent directory.")
    exit(1)

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# ── Azure Foundry client ──────────────────────────────────────────────────────
_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
if _endpoint.endswith("/responses"):
    _endpoint = _endpoint[: -len("/responses")]

client = OpenAI(
    base_url=_endpoint,
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)
MODEL = os.getenv("AZURE_OPENAI_MODEL_NAME")

# ── ANSI colours for readable console output ─────────────────────────────────
CYAN   = "\033[1;36m"
GREEN  = "\033[1;32m"
YELLOW = "\033[1;33m"
RED    = "\033[1;31m"
MAGENTA= "\033[1;35m"
WHITE  = "\033[1;97m"   # bright bold white — used for scenario descriptions
RESET  = "\033[0m"


# ── Helper — call Azure Foundry with configurable params ─────────────────────
def ask(
    user_prompt: str,
    system_prompt: str = "You are a helpful medical assistant.",
    temperature: float = 0.7,
    max_tokens: int = 512,
) -> str:
    """
    Thin wrapper around the Azure Foundry chat completions API.
    temperature : 0.0 = deterministic/factual,  1.0 = creative/varied
    max_tokens  : hard cap on output length
    """
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_prompt},
        ],
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return response.choices[0].message.content.strip()


def section(title: str):
    print(f"\n{'═'*66}")
    print(f"  {title}")
    print(f"{'═'*66}")

def label(tag: str, text: str, colour: str = CYAN):
    print(f"{colour}[{tag}]{RESET}")
    print(text.strip())
    print()

def pause():
    input(f"{CYAN}  ── Press Enter to continue ──{RESET}\n")

def scenario(text: str):
    """Print the demo description in prominent bright-white so it stands out."""
    print(f"{WHITE}")
    for line in text.strip().splitlines():
        print(f"  {line}")
    print(f"{RESET}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 1 — REASONING TYPES
#
# LLMs can be steered toward four distinct reasoning patterns by how you frame
# the prompt.  Understanding which type fits your task leads to more accurate,
# trustworthy outputs.
#
#  Deductive   — from general rules → certain conclusion     ("must be true")
#  Inductive   — from specific cases → probable general rule ("likely true")
#  Abductive   — from observation   → best explanation       ("probably caused by")
#  Analogical  — map known situation → new similar situation ("works like")
# ═══════════════════════════════════════════════════════════════════════════════
section("DEMO 1 — Reasoning Types  (Deductive / Inductive / Abductive / Analogical)")
scenario("""
LLMs can be steered toward four distinct reasoning patterns by how you frame
the prompt.  Choosing the right type leads to more accurate, trustworthy output.

  Deductive   — from general rules → certain conclusion     ("must be true")
  Inductive   — from specific cases → probable general rule ("likely true")
  Abductive   — from observation   → best explanation       ("probably caused by")
  Analogical  — map known situation → new similar situation ("works like")
""")

# ── Deductive reasoning ───────────────────────────────────────────────────────
# General rule + specific fact → certain conclusion.
# Best for: eligibility checks, rule-based triage, policy enforcement.
deductive_prompt = """
Use deductive reasoning to answer the following.

Rule 1: All patients with eGFR < 30 mL/min are contraindicated for Metformin.
Rule 2: All patients with uncontrolled hypertension (BP > 180/120) must be
        referred to a cardiologist before starting any new medication.

Fact: Patient John, 62M, eGFR = 24 mL/min, BP = 165/95, newly diagnosed Type 2 Diabetes.

What conclusions can you draw with certainty about John's treatment plan?
Walk through each rule explicitly.
"""
label("Deductive — prompt", deductive_prompt, YELLOW)
deductive_resp = ask(deductive_prompt, temperature=0.0, max_tokens=300)
label("Deductive — response (certain conclusions from rules)", deductive_resp, GREEN)
pause()

# ── Inductive reasoning ───────────────────────────────────────────────────────
# Specific observations → probable general pattern.
# Best for: spotting trends in patient populations, hypothesis generation.
inductive_prompt = """
Use inductive reasoning. You are given observations from a hospital ward over
one week. Identify the most likely general pattern or hypothesis.

Observations:
- Patient A (68F): admitted Monday with confusion and low sodium (Na 121). Recovered with fluid restriction.
- Patient B (71M): admitted Tuesday with drowsiness, Na 118. On Thiazide diuretic. Recovered with fluid restriction.
- Patient C (65F): admitted Thursday with seizure, Na 115. Also on Thiazide. Recovered with fluid restriction.
- Patient D (74M): admitted Friday with fatigue and nausea, Na 120. On Thiazide. Recovered with fluid restriction.

What general pattern or hypothesis do these cases suggest?
State your confidence level and what additional data would strengthen the hypothesis.
"""
label("Inductive — prompt", inductive_prompt, YELLOW)
inductive_resp = ask(inductive_prompt, temperature=0.0, max_tokens=300)
label("Inductive — response (probable pattern from cases)", inductive_resp, CYAN)
pause()

# ── Abductive reasoning ───────────────────────────────────────────────────────
# Incomplete observations → the single best / most likely explanation.
# Best for: differential diagnosis, root-cause analysis, anomaly investigation.
abductive_prompt = """
Use abductive reasoning (inference to the best explanation).

A 45-year-old male presents to A&E with:
  • Sudden sharp chest pain that worsens when lying flat and improves leaning forward
  • Low-grade fever (37.8°C) for 3 days
  • Recent upper respiratory tract infection 2 weeks ago
  • ECG shows diffuse ST elevation in multiple leads with PR depression
  • Troponin: mildly elevated but stable on repeat

Among all possible explanations, what is the single most likely diagnosis?
Explain why this explanation fits the evidence better than the alternatives.
"""
label("Abductive — prompt", abductive_prompt, YELLOW)
abductive_resp = ask(abductive_prompt, temperature=0.0, max_tokens=300)
label("Abductive — response (best explanation from incomplete data)", abductive_resp, MAGENTA)
pause()

# ── Analogical reasoning ──────────────────────────────────────────────────────
# Map structure/lessons from a known domain onto an unfamiliar one.
# Best for: explaining new concepts to patients, cross-domain problem solving.
analogical_prompt = """
Use analogical reasoning to explain the following to a patient with no medical background.

Concept to explain: How the immune system's T-cell memory works after vaccination.

Use an analogy from everyday life (not biology) that makes the mechanism
intuitive. Clearly label (a) what maps to what, and (b) where the analogy breaks down.
"""
label("Analogical — prompt", analogical_prompt, YELLOW)
analogical_resp = ask(analogical_prompt, temperature=0.5, max_tokens=300)
label("Analogical — response (familiar concept mapped to new domain)", analogical_resp, CYAN)
pause()

print(f"{YELLOW}KEY LESSON:{RESET}")
print("  Deductive  → apply known rules to reach certain conclusions  (compliance, eligibility)")
print("  Inductive  → generalise from cases to form hypotheses        (trend analysis, research)")
print("  Abductive  → find the best explanation for observations      (diagnosis, root cause)")
print("  Analogical → transfer insight across domains                 (patient education, design)")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 2 — SUMMARIZATION STYLES  (Extractive vs Abstractive)
#
#  Extractive  — selects and returns verbatim sentences/phrases from the source.
#                Faithful to original wording; no new text introduced.
#                Best for: legal/compliance docs, evidence quotation, audit trails.
#
#  Abstractive — paraphrases and synthesises; may use words not in the source.
#                More fluent and concise; slight risk of meaning drift.
#                Best for: patient-facing summaries, executive briefings, reports.
# ═══════════════════════════════════════════════════════════════════════════════
pause()
section("DEMO 2 — Summarization Styles  (Extractive vs Abstractive)")
scenario("""
Extractive  — copies verbatim sentences/phrases directly from the source.
              Fully faithful; no new words introduced.
              Best for: audits, legal/compliance docs, evidence quotation.

Abstractive — paraphrases and synthesises; may use words not in the source.
              More fluent and concise; slight risk of meaning drift.
              Best for: patient-facing summaries, GP letters, executive briefings.
""")

clinical_note = """
CLINICAL NOTE — Date: 10 Apr 2026
Patient: Sarah Chen, 58F, MRN 4821093
Admitted: 08 Apr 2026   |   Ward: Cardiology 4B

History of presenting complaint:
Mrs Chen presented with a 3-day history of progressively worsening dyspnoea on
exertion and two-pillow orthopnoea. She reported bilateral ankle swelling for one
week and a 4 kg weight gain over 10 days. She denied chest pain or palpitations.
Background history of ischaemic cardiomyopathy (EF 35%, diagnosed 2021),
hypertension, and Type 2 Diabetes. Current medications: Furosemide 40 mg OD,
Bisoprolol 5 mg OD, Ramipril 5 mg OD, Empagliflozin 10 mg OD, Aspirin 75 mg OD.

Examination:
BP 158/94 mmHg, HR 88 bpm (sinus rhythm), RR 20/min, SpO2 94% on air.
JVP elevated at 4 cm above sternal angle. Bilateral basal crepitations on
auscultation. Pitting oedema to the knees bilaterally.

Investigations:
BNP: 1840 pg/mL (elevated). CXR: cardiomegaly, bilateral pleural effusions,
upper lobe diversion. Echo: EF 30%, moderate mitral regurgitation (new finding).
Renal function: Creatinine 112 μmol/L (stable), eGFR 52.

Assessment: Acute decompensated heart failure. New moderate mitral regurgitation
likely contributing to decompensation.

Plan:
1. IV Furosemide 80 mg BD — target 1.5 L negative fluid balance per day.
2. Uptitrate Ramipril to 10 mg once renal function stable.
3. Cardiology MDT referral for assessment of mitral valve intervention.
4. Strict fluid restriction 1.5 L/day. Daily weights. Strict fluid balance charting.
5. Diabetes team review re: Empagliflozin continuation during diuresis.
6. Repeat echo in 6 weeks post-optimisation.
"""

# ── Extractive summarization ──────────────────────────────────────────────────
extractive_prompt = f"""
Perform EXTRACTIVE summarization of the clinical note below.

Rules:
- Copy sentences or short phrases VERBATIM from the note — do not paraphrase or add any new words.
- Select only the most clinically important sentences.
- Limit to 5 bullet points maximum.
- Each bullet must be a direct quote (exact wording) from the text.

Clinical Note:
{clinical_note}
"""

label("Extractive summarization — prompt instruction", extractive_prompt, YELLOW)
extractive_resp = ask(extractive_prompt, temperature=0.0, max_tokens=300)
label("Extractive — verbatim sentences lifted from source", extractive_resp, CYAN)
pause()

# ── Abstractive summarization ─────────────────────────────────────────────────
abstractive_prompt = f"""
Write an ABSTRACTIVE summary of the clinical note below for a GP who was not
present during the admission.

Requirements:
- Synthesise and paraphrase — do NOT copy verbatim sentences.
- Use plain clinical language; avoid raw numbers where a brief interpretation is clearer.
- Cover: reason for admission, key findings, working diagnosis, and the discharge/ongoing plan.
- Maximum 100 words.

Clinical Note:
{clinical_note}
"""

label("Abstractive summarization — prompt instruction", abstractive_prompt, YELLOW)
abstractive_resp = ask(abstractive_prompt, temperature=0.3, max_tokens=200)
label("Abstractive — synthesised, paraphrased summary", abstractive_resp, GREEN)
pause()

print(f"{YELLOW}KEY LESSON:{RESET}")
print("  Extractive  → zero paraphrase, fully traceable to source — use for audits, legal, evidence")
print("  Abstractive → fluent synthesis, may introduce slight drift — use for comms, briefings, UX")
print("  In healthcare, prefer extractive when traceability matters; abstractive for readability.")
print("  For highest safety: extractive first, then abstractive over the extracted quotes.")


print(f"\n{'═'*66}")
print("  All demos complete.")
print(f"{'═'*66}\n")
