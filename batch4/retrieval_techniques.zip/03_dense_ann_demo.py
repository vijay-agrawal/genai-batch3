"""
=============================================================================
INFORMATION RETRIEVAL DEMO 3 — Dense Bi-Encoder + ANN (Approximate Nearest Neighbor)
=============================================================================

PART A: DENSE BI-ENCODER
─────────────────────────────────────────────────────────────────────────────
A bi-encoder uses a neural language model (e.g., BERT, sentence-transformers)
to independently encode queries and documents into dense floating-point vectors
in a shared semantic embedding space.

  ARCHITECTURE
  ────────────
                Query                       Document
                  │                            │
          ┌───────▼────────┐          ┌────────▼───────┐
          │  Transformer   │          │  Transformer   │
          │  Encoder       │          │  Encoder       │
          │  (shared       │          │  (same weights)│
          │   weights)     │          └────────┬───────┘
          └───────┬────────┘                   │
                  │                            │
              q_vector                    d_vector
           (768-dim float)             (768-dim float)
                  │                            │
                  └──── cosine_similarity ──────┘
                              score

  KEY INSIGHT: The encoder is trained with contrastive learning to place
  semantically similar text CLOSE together, regardless of exact word overlap.

  "myocardial infarction" and "heart attack" → vectors ~0.85 cosine similarity
  "diabetes treatment" and "pancreatic management" → vectors ~0.72 cosine sim
  "heart attack" and "renal protocol" → vectors ~0.12 cosine similarity

  WHY "BI"-ENCODER?
  Two separate encoding passes (one for query, one for doc) that can be
  computed INDEPENDENTLY and OFFLINE. This is the key to scalability:
  encode all documents once, store vectors, then at query time only encode
  the query and do vector search.

─────────────────────────────────────────────────────────────────────────────
PART B: APPROXIMATE NEAREST NEIGHBOR (ANN) SEARCH
─────────────────────────────────────────────────────────────────────────────
Given millions of pre-computed document vectors, how do you find the top-k
most similar to the query vector without comparing to every single document?

  EXACT NN: O(n × d) comparisons — 1M docs × 768-dim = 768M multiplications
  ANN:      O(log n) or O(1) amortized — sub-linear in corpus size

  MAIN ANN ALGORITHMS
  ───────────────────
  FAISS (Facebook AI Similarity Search) — used in this demo
    • IVFFlat: Inverted File Index.
      Training: clusters the vector space into nlist=100 Voronoi cells (k-means).
      Query: only search nprobe=10 nearest cells instead of all cells.
      Tradeoff: higher nprobe = higher recall, slower search.

    • HNSW (Hierarchical Navigable Small World): graph-based index.
      Builds a multi-layer proximity graph. Traverses from top layer down.
      Excellent recall (~99%) at very fast query speed.
      Used by: Pinecone, Weaviate, pgvector (PostgreSQL), Qdrant.

    • IVF-PQ (Product Quantization): compresses vectors from 768×float32
      to ~96 bytes by quantizing sub-vectors. 8× memory reduction.
      Tradeoff: slight recall loss (~2-3%) for 8× memory savings.

  RECALL@k vs LATENCY TRADEOFF
  ─────────────────────────────
  Recall@10 = fraction of true top-10 docs that ANN actually returns.
  ANN is "approximate" — it may miss a few true neighbors for speed.
  In healthcare: aim for Recall@10 ≥ 0.95 in production systems.

─────────────────────────────────────────────────────────────────────────────
BI-ENCODER vs CROSS-ENCODER (why we use bi-encoder for RETRIEVAL)
─────────────────────────────────────────────────────────────────────────────

  ┌─────────────────────┬──────────────────────────┬────────────────────────┐
  │ Feature             │ Bi-Encoder               │ Cross-Encoder          │
  ├─────────────────────┼──────────────────────────┼────────────────────────┤
  │ How it scores       │ separate Q/D vectors,    │ joint Q+D input,       │
  │                     │ then cosine similarity   │ full cross-attention   │
  │ Pre-indexable       │ YES — offline doc vectors│ NO — query needed      │
  │ Speed (1M docs)     │ ~1ms with ANN index      │ ~1000s (serial)        │
  │ Quality             │ Good (semantic)          │ Excellent (best known) │
  │ Use case            │ RETRIEVAL (first-stage)  │ RERANKING (second)     │
  │ Healthcare example  │ Find 100 candidates from │ Re-rank those 100 docs │
  │                     │ 10M clinical notes       │ in precise order       │
  └─────────────────────┴──────────────────────────┴────────────────────────┘

─────────────────────────────────────────────────────────────────────────────
HEALTHCARE-SPECIFIC EMBEDDING MODELS
─────────────────────────────────────────────────────────────────────────────

  Model                  │ Training Data            │ Use Case
  ───────────────────────┼──────────────────────────┼──────────────────────
  all-MiniLM-L6-v2       │ General web text         │ Baseline, fast (80MB)
  all-mpnet-base-v2      │ General web text         │ Stronger baseline
  BioLORD-2023           │ Medical ontologies/UMLS  │ Clinical term matching
  BiomedBERT             │ PubMed + PMC             │ Biomedical literature
  Clinical-BERT          │ MIMIC-III clinical notes │ EHR retrieval
  MedCPT                 │ PubMed Q&A pairs         │ Medical question answering
  PubMedBERT             │ PubMed abstracts only    │ Research literature

  This demo uses all-MiniLM-L6-v2 (general purpose, lightweight, no clinical
  GPU requirement) to show the mechanics. In production, swap for BioLORD
  or Clinical-BERT for significantly better medical synonym handling.

─────────────────────────────────────────────────────────────────────────────
TRADEOFFS IN HEALTHCARE IR
─────────────────────────────────────────────────────────────────────────────

  STRENGTHS vs SPARSE (TF-IDF / BM25)
  • Handles medical synonyms: "MI" = "STEMI" = "heart attack" = "cardiac event"
  • Handles abbreviation expansion: "HTN" → "hypertension"
  • Cross-lingual: Spanish patient notes → English query (for multilingual models)
  • Handles paraphrase: "reduce blood sugar" = "glycemic control"
  • Better for longer, natural-language queries (patient-facing chatbots)

  WEAKNESSES
  • Exact value mismatch: "eGFR < 30" may not precisely match documents with
    "eGFR of 28" — sparse methods excel here
  • Drug name confusion: "metformin" and "methotrexate" may embed similarly
    due to co-occurrence patterns in training data
  • Hallucination risk: model may "interpolate" between concepts incorrectly
  • Training domain gap: general models trained on web text may embed
    clinical jargon poorly without domain-specific fine-tuning
  • Computational cost: 768-dim float32 vectors; 10M docs = ~29GB of vectors
  • Black-box: harder to audit/explain ranking decisions to clinicians

  DEPLOYMENT CONSIDERATIONS
  • Index must be rebuilt when documents change (though incremental updates exist)
  • Model updates require re-encoding the entire corpus
  • HIPAA/GDPR: embeddings generated from patient notes may need to stay
    on-premise — use locally-hosted models (HuggingFace Transformers)

─────────────────────────────────────────────────────────────────────────────
THIS DEMO
─────────────────────────────────────────────────────────────────────────────
  1. Encode 30 clinical docs with sentence-transformers
  2. Build FAISS IVF and Flat indices and compare
  3. Search with 5 queries — compare dense vs BM25 vs TF-IDF
  4. Visualize the embedding space with UMAP (colored by medical specialty)
  5. Show recall@k: how often ANN returns same results as exact search

  Run:  python 03_dense_ann_demo.py
  Deps: pip install sentence-transformers faiss-cpu umap-learn matplotlib
        (for CPU-only: faiss-cpu works fine for demos up to ~1M docs)
=============================================================================
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    raise SystemExit("Missing dep: pip install sentence-transformers")

try:
    import faiss
except ImportError:
    raise SystemExit("Missing dep: pip install faiss-cpu")

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity as sklearn_cosine
    from rank_bm25 import BM25Okapi
    HAVE_SPARSE = True
except ImportError:
    HAVE_SPARSE = False
    print("[WARN] scikit-learn or rank-bm25 not installed — skipping comparison table")

# ─────────────────────────────────────────────────────────────────────────────
# SYNTHETIC CORPUS — 30 clinical document snippets with specialty labels
# ─────────────────────────────────────────────────────────────────────────────
DOCUMENTS = [
    # Diabetes / Endocrinology
    {"id": "D001", "specialty": "Endocrinology", "title": "Metformin Therapy in Type 2 Diabetes",
     "text": "Metformin is the first-line pharmacological treatment for type 2 diabetes mellitus. "
             "It reduces hepatic glucose production and improves insulin sensitivity. "
             "Patients on metformin typically achieve HbA1c reduction of 1-2%. "
             "Common side effects include gastrointestinal upset; lactic acidosis is rare but serious. "
             "Renal function eGFR must be monitored before initiation of metformin therapy."},
    {"id": "D002", "specialty": "Endocrinology", "title": "Semaglutide GLP-1 Agonist Therapy",
     "text": "Semaglutide, a GLP-1 receptor agonist, is approved for type 2 diabetes and obesity management. "
             "Weekly subcutaneous injection reduces HbA1c by up to 1.8% and promotes significant weight loss. "
             "Cardiovascular outcome trials demonstrate meaningful reduction in major adverse cardiac events. "
             "It is contraindicated in patients with personal or family history of medullary thyroid carcinoma."},
    {"id": "D003", "specialty": "Endocrinology", "title": "Insulin Therapy Initiation",
     "text": "When oral hypoglycemic agents fail to achieve glycemic targets, insulin therapy is initiated. "
             "Basal insulin such as glargine or detemir is preferred for type 2 diabetes management. "
             "Starting dose is 10 units daily or 0.1-0.2 units per kilogram per day, titrated to fasting glucose. "
             "Hypoglycemia is the primary safety risk; patients need education on self-monitoring blood glucose."},
    {"id": "D004", "specialty": "Endocrinology", "title": "Diabetic Ketoacidosis DKA Protocol",
     "text": "DKA is a life-threatening hyperglycemic emergency characterized by ketosis and metabolic acidosis. "
             "Intravenous fluid resuscitation with isotonic saline is the critical first intervention. "
             "Insulin infusion should begin after potassium correction if serum potassium is below 3.5. "
             "Patients require hourly monitoring of blood glucose, electrolytes, and anion gap during treatment."},
    {"id": "D005", "specialty": "Endocrinology", "title": "Continuous Glucose Monitoring Technology",
     "text": "CGM systems measure interstitial fluid glucose every five minutes providing real-time glucose trends. "
             "Time-in-range between 70-180 mg per dL is the primary metric correlating with HbA1c outcomes. "
             "Automated low-glucose alerts dramatically reduce hypoglycemic episodes compared to fingerstick monitoring. "
             "Integration with insulin pumps creates a closed-loop artificial pancreas for automated insulin delivery."},
    # Cardiology
    {"id": "C001", "specialty": "Cardiology", "title": "STEMI Myocardial Infarction Protocol",
     "text": "ST-elevation myocardial infarction requires emergency percutaneous coronary intervention within 90 minutes. "
             "Dual antiplatelet therapy with aspirin and a P2Y12 inhibitor such as ticagrelor is initiated immediately. "
             "Anticoagulation with heparin is administered during the cardiac catheterization procedure. "
             "After the procedure, patients are started on statin therapy, beta-blocker, and ACE inhibitor before discharge."},
    {"id": "C002", "specialty": "Cardiology", "title": "Heart Failure Reduced Ejection Fraction",
     "text": "Heart failure with reduced ejection fraction below 40% requires guideline-directed medical therapy. "
             "The four pillars are ACE inhibitor or ARB, beta-blocker, mineralocorticoid receptor antagonist, and SGLT2 inhibitor. "
             "Dapagliflozin significantly reduces cardiovascular mortality and hospitalizations in heart failure patients. "
             "Implantable cardioverter-defibrillator is indicated for patients with ejection fraction below 35 percent."},
    {"id": "C003", "specialty": "Cardiology", "title": "Atrial Fibrillation Stroke Prevention",
     "text": "Atrial fibrillation increases ischemic stroke risk five-fold due to left atrial thrombus formation. "
             "CHA2DS2-VASc score is used to guide anticoagulation therapy decisions in atrial fibrillation patients. "
             "Direct oral anticoagulants including apixaban and rivaroxaban are preferred over warfarin therapy. "
             "Rate control targeting resting heart rate below 80 beats per minute reduces symptoms and improves outcomes."},
    {"id": "C004", "specialty": "Cardiology", "title": "Hypertension Treatment CKD Patients",
     "text": "Blood pressure target in chronic kidney disease is below 130/80 millimeters of mercury. "
             "ACE inhibitors and angiotensin receptor blockers are first-line therapy in CKD with proteinuria. "
             "These agents provide renal protection by reducing glomerular filtration pressure and albuminuria. "
             "NSAIDs must be avoided in CKD as they worsen renal function and raise blood pressure."},
    {"id": "C005", "specialty": "Cardiology", "title": "Cardiac Troponin Biomarkers Acute Care",
     "text": "High-sensitivity troponin assays detect myocardial injury earlier than conventional troponin tests. "
             "Serial measurements at zero and three hours enable rapid rule-out of acute coronary syndrome. "
             "Elevated BNP or NT-proBNP levels confirm the diagnosis of acute decompensated heart failure. "
             "D-dimer measurement is used to exclude pulmonary embolism in patients with low pretest probability."},
    # Oncology
    {"id": "O001", "specialty": "Oncology", "title": "Lung Cancer Targeted Molecular Therapy",
     "text": "Non-small cell lung cancer patients require EGFR mutation testing before first-line therapy selection. "
             "Osimertinib, a third-generation EGFR tyrosine kinase inhibitor, is standard first-line for EGFR-mutant disease. "
             "ALK rearrangement-positive patients receive alectinib due to superior CNS penetration and outcomes. "
             "Pembrolizumab immunotherapy is used for high PD-L1 expressing NSCLC without actionable mutations."},
    {"id": "O002", "specialty": "Oncology", "title": "Hormone Receptor Positive Breast Cancer",
     "text": "HR-positive HER2-negative breast cancer is treated with CDK4/6 inhibitors combined with endocrine therapy. "
             "Aromatase inhibitors such as letrozole are preferred endocrine therapy in postmenopausal women. "
             "Tamoxifen remains the standard endocrine treatment for premenopausal breast cancer patients. "
             "PIK3CA mutations identify patients who benefit from alpelisib combined with fulvestrant."},
    {"id": "O003", "specialty": "Oncology", "title": "Colorectal Cancer Screening Prevention",
     "text": "Colorectal cancer screening is recommended for average-risk adults starting at age 45. "
             "Colonoscopy every ten years remains the gold standard for colorectal cancer screening. "
             "Fecal immunochemical testing annually and multitarget stool DNA testing are non-invasive alternatives. "
             "Lynch syndrome patients require earlier and more frequent colonoscopic surveillance due to hereditary risk."},
    {"id": "O004", "specialty": "Oncology", "title": "Febrile Neutropenia Chemotherapy Complication",
     "text": "Febrile neutropenia is a life-threatening oncologic emergency requiring immediate antibiotic treatment. "
             "Absolute neutrophil count below 500 with fever above 38.3 degrees Celsius defines febrile neutropenia. "
             "Empiric broad-spectrum antibiotics such as piperacillin-tazobactam are started within one hour. "
             "Granulocyte colony stimulating factor prophylaxis reduces febrile neutropenia risk in high-risk chemotherapy regimens."},
    {"id": "O005", "specialty": "Oncology", "title": "CAR-T Immunotherapy Lymphoma",
     "text": "Chimeric antigen receptor T-cell therapy represents a breakthrough in treating relapsed B-cell lymphomas. "
             "CD19-directed CAR-T cells such as axicabtagene ciloleucel achieve complete remission in 40-50% of cases. "
             "Cytokine release syndrome is the most common serious toxicity, managed with tocilizumab in severe cases. "
             "Neurotoxicity and immune effector cell-associated neurotoxicity syndrome require dexamethasone treatment."},
    # Infectious Disease
    {"id": "I001", "specialty": "Infectious Disease", "title": "Sepsis Bundle Treatment Protocol",
     "text": "Sepsis is life-threatening organ dysfunction caused by dysregulated host response to infection. "
             "The sepsis hour-1 bundle includes blood cultures, broad-spectrum antibiotics, and intravenous fluid resuscitation. "
             "Norepinephrine is the first-line vasopressor for maintaining mean arterial pressure in septic shock. "
             "Procalcitonin-guided antibiotic de-escalation safely reduces duration of antibiotic therapy in sepsis."},
    {"id": "I002", "specialty": "Infectious Disease", "title": "Antiviral Therapy COVID-19 Treatment",
     "text": "Nirmatrelvir-ritonavir oral antiviral therapy reduces hospitalization and death in high-risk COVID-19 patients. "
             "Treatment must be initiated within five days of symptom onset for maximum clinical benefit. "
             "Significant drug interactions with ritonavir component require careful medication reconciliation review. "
             "Remdesivir intravenous therapy benefits hospitalized COVID-19 patients requiring supplemental oxygen therapy."},
    {"id": "I003", "specialty": "Infectious Disease", "title": "Antibiotic Stewardship Program Hospital",
     "text": "Antibiotic stewardship programs reduce antimicrobial resistance, Clostridioides difficile infections, and costs. "
             "Prospective audit with feedback from infectious disease specialists improves antibiotic prescribing appropriateness. "
             "Intravenous to oral antibiotic conversion reduces catheter complications and hospital length of stay. "
             "De-escalation to narrowest effective antibiotic guided by culture and sensitivity results within 48-72 hours."},
    # Neurology
    {"id": "N001", "specialty": "Neurology", "title": "Acute Ischemic Stroke Thrombolysis",
     "text": "Intravenous alteplase thrombolysis is effective for acute ischemic stroke within 4.5 hours of symptom onset. "
             "Blood pressure must be controlled below 185/110 before tPA administration to reduce hemorrhage risk. "
             "Large vessel occlusion stroke benefits from mechanical thrombectomy up to 24 hours if brain tissue is salvageable. "
             "Aspirin and clopidogrel dual antiplatelet therapy is given for 21 days after minor stroke or TIA."},
    {"id": "N002", "specialty": "Neurology", "title": "Epilepsy Seizure Medication Management",
     "text": "Antiseizure medication selection depends on seizure type, epilepsy syndrome, and patient characteristics. "
             "Levetiracetam and lamotrigine are first-line treatments for focal epilepsy with favorable tolerability profiles. "
             "Valproate is highly effective for generalized epilepsy but teratogenic and avoided in women of childbearing age. "
             "Status epilepticus is a neurological emergency treated with benzodiazepines followed by IV levetiracetam."},
    # Nephrology
    {"id": "K001", "specialty": "Nephrology", "title": "Acute Kidney Injury Diagnosis Management",
     "text": "Acute kidney injury is diagnosed by a rise in serum creatinine of 0.3 mg per dL or more within 48 hours. "
             "Prerenal causes including volume depletion and sepsis account for the majority of hospital-acquired AKI. "
             "Nephrotoxic medications including NSAIDs, contrast agents, and aminoglycosides must be avoided in at-risk patients. "
             "Novel urinary biomarkers NGAL and KIM-1 detect acute tubular injury before creatinine elevation occurs."},
    # Pulmonology
    {"id": "P001", "specialty": "Pulmonology", "title": "COPD Acute Exacerbation Treatment",
     "text": "Acute COPD exacerbations are triggered by respiratory infections, air pollution, or temperature changes. "
             "Short-acting bronchodilators with albuterol and ipratropium provide rapid symptomatic relief in exacerbations. "
             "A short course of systemic corticosteroids reduces treatment failure and hastens clinical recovery. "
             "Non-invasive positive pressure ventilation reduces intubation risk in patients with respiratory acidosis."},
    # Pharmacology
    {"id": "PH001", "specialty": "Pharmacology", "title": "Warfarin Drug Interactions Antibiotics",
     "text": "Antibiotic therapy frequently potentiates warfarin anticoagulation by suppressing intestinal vitamin K synthesis. "
             "Azole antifungals and metronidazole inhibit CYP2C9 causing dramatic INR elevation in warfarin patients. "
             "Rifampin strongly induces hepatic cytochrome P450 enzymes requiring warfarin dose escalation. "
             "INR monitoring within three to five days of any antibiotic initiation or discontinuation is essential."},
    {"id": "PH002", "specialty": "Pharmacology", "title": "Opioid Analgesic Prescribing Safety",
     "text": "Opioid prescribing should follow the WHO analgesic ladder starting with non-opioid analgesics first. "
             "Morphine equivalent doses exceeding 90 mg per day substantially increase overdose risk and mortality. "
             "Naloxone rescue medication should be co-prescribed for patients on high-dose opioid therapy. "
             "Urine drug screening and prescription drug monitoring programs are required before initiating opioid therapy."},
    # Hematology
    {"id": "H001", "specialty": "Hematology", "title": "Venous Thromboembolism Anticoagulation",
     "text": "Deep vein thrombosis and pulmonary embolism require at least three months of anticoagulation therapy. "
             "Direct oral anticoagulants such as rivaroxaban and apixaban are preferred over warfarin for VTE treatment. "
             "Cancer-associated venous thrombosis is treated with low molecular weight heparin or rivaroxaban. "
             "Massive pulmonary embolism with hemodynamic instability requires systemic thrombolytic therapy with alteplase."},
    # Gastroenterology
    {"id": "G001", "specialty": "Gastroenterology", "title": "Helicobacter Pylori Eradication",
     "text": "Helicobacter pylori infection causes peptic ulcer disease and increases gastric cancer risk. "
             "First-line eradication uses clarithromycin triple therapy with a proton pump inhibitor and amoxicillin. "
             "Treatment success should be confirmed with urea breath test or stool antigen test after four weeks. "
             "Successful eradication reduces peptic ulcer recurrence from 80% to less than 5% within one year."},
    # Radiology
    {"id": "R001", "specialty": "Radiology", "title": "CT Pulmonary Angiography Pulmonary Embolism",
     "text": "CT pulmonary angiography is the imaging gold standard for diagnosing acute pulmonary embolism. "
             "Pre-test probability assessment with Wells score guides appropriate use of CTPA versus D-dimer testing. "
             "Metformin should be held 48 hours after contrast administration in patients with reduced kidney function. "
             "Ventilation-perfusion scintigraphy is the preferred alternative in pregnancy to minimize radiation exposure."},
    # Pediatrics
    {"id": "PED001", "specialty": "Pediatrics", "title": "Childhood Asthma Stepwise Therapy",
     "text": "Pediatric asthma management follows a stepwise approach escalating therapy based on symptom control. "
             "Inhaled corticosteroids are the cornerstone of persistent asthma treatment in children of all ages. "
             "Adding a long-acting beta-agonist improves symptom control in children with inadequately controlled asthma. "
             "Biologic agents targeting IL-4, IL-5, or IgE are reserved for severe therapy-resistant pediatric asthma."},
    # Mental Health
    {"id": "MH001", "specialty": "Psychiatry", "title": "Antidepressant Medication Selection",
     "text": "Selective serotonin reuptake inhibitors are the preferred initial pharmacotherapy for major depressive disorder. "
             "Sertraline and escitalopram are recommended first-line antidepressants due to favorable efficacy and tolerability. "
             "An adequate antidepressant trial requires six to eight weeks at therapeutic dose before declaring treatment failure. "
             "Augmentation with lithium or atypical antipsychotics is considered after two adequate SSRI treatment failures."},
    # Surgery
    {"id": "S001", "specialty": "Surgery", "title": "Perioperative Anticoagulation Management",
     "text": "Perioperative anticoagulation management balances thrombosis risk against surgical bleeding risk. "
             "Patients with high-risk mechanical heart valves or recent stroke require bridging anticoagulation therapy. "
             "Warfarin is typically held five days before elective surgery with low molecular weight heparin bridging. "
             "Direct oral anticoagulants are simply held 24-48 hours preoperatively without any bridging requirement."},
]

QUERIES = [
    {"id": "Q1", "text": "blood sugar control medication diabetes",
     "note": "Lay language — dense model should handle 'blood sugar' → glycemic context"},
    {"id": "Q2", "text": "heart attack emergency treatment",
     "note": "Lay synonym: 'heart attack' should match STEMI/MI docs semantically"},
    {"id": "Q3", "text": "antibiotic selection infection neutropenic patient",
     "note": "Multi-concept clinical query"},
    {"id": "Q4", "text": "clot in the lung blood thinner",
     "note": "Pure lay language: 'clot in the lung' = PE; 'blood thinner' = anticoagulant"},
    {"id": "Q5", "text": "cancer immunotherapy cellular treatment",
     "note": "CAR-T and checkpoint inhibitors should both surface"},
]

SPECIALTIES = list(dict.fromkeys(d["specialty"] for d in DOCUMENTS))
SPECIALTY_COLORS = {
    s: plt.cm.tab20(i / len(SPECIALTIES)) for i, s in enumerate(SPECIALTIES)
}


# ─────────────────────────────────────────────────────────────────────────────
# ENCODE DOCUMENTS
# ─────────────────────────────────────────────────────────────────────────────
def encode_corpus(docs, model_name="all-MiniLM-L6-v2"):
    print(f"\n[Loading sentence-transformer model: {model_name}]")
    model = SentenceTransformer(model_name)
    texts = [d["text"] for d in docs]
    print(f"[Encoding {len(texts)} clinical documents ...]")
    embeddings = model.encode(texts, show_progress_bar=True, normalize_embeddings=True)
    return model, embeddings.astype(np.float32)


# ─────────────────────────────────────────────────────────────────────────────
# BUILD FAISS INDICES
# ─────────────────────────────────────────────────────────────────────────────
def build_faiss_indices(embeddings):
    dim = embeddings.shape[1]
    n = embeddings.shape[0]

    # Flat L2 (exact brute-force — ground truth)
    flat_index = faiss.IndexFlatIP(dim)  # Inner Product = cosine for normalized vecs
    flat_index.add(embeddings)

    # IVF (Inverted File Index) — ANN approximation
    # For small corpus: nlist=4; for millions use nlist=sqrt(n) or 4096
    nlist = max(4, int(np.sqrt(n)))
    ivf_index = faiss.IndexIVFFlat(faiss.IndexFlatIP(dim), dim, nlist, faiss.METRIC_INNER_PRODUCT)
    ivf_index.train(embeddings)
    ivf_index.add(embeddings)
    ivf_index.nprobe = max(2, nlist // 2)  # search nprobe cells

    print(f"\nFAISS Flat index: {flat_index.ntotal} vectors, dim={dim}")
    print(f"FAISS IVF  index: {ivf_index.ntotal} vectors, nlist={nlist}, nprobe={ivf_index.nprobe}")

    return flat_index, ivf_index


# ─────────────────────────────────────────────────────────────────────────────
# DENSE SEARCH
# ─────────────────────────────────────────────────────────────────────────────
def dense_search(query_text, model, index, docs, top_k=5):
    q_emb = model.encode([query_text], normalize_embeddings=True).astype(np.float32)
    scores, indices = index.search(q_emb, top_k)
    hits = []
    for rank, (idx, score) in enumerate(zip(indices[0], scores[0])):
        if idx >= 0:
            hits.append({
                "rank": rank + 1,
                "doc_id": docs[idx]["id"],
                "title": docs[idx]["title"],
                "specialty": docs[idx]["specialty"],
                "score": float(score),
                "snippet": docs[idx]["text"][:100] + "...",
            })
    return hits


# ─────────────────────────────────────────────────────────────────────────────
# BM25 SEARCH (for comparison)
# ─────────────────────────────────────────────────────────────────────────────
def bm25_search(docs, query_text, top_k=5):
    if not HAVE_SPARSE:
        return []
    tokenized = [d["text"].lower().split() for d in docs]
    bm25 = BM25Okapi(tokenized)
    scores = bm25.get_scores(query_text.lower().split())
    top_indices = np.argsort(scores)[::-1][:top_k]
    return [{"rank": r + 1, "doc_id": docs[i]["id"], "title": docs[i]["title"],
             "score": scores[i]} for r, i in enumerate(top_indices)]


# ─────────────────────────────────────────────────────────────────────────────
# RECALL@k: ANN vs Exact
# ─────────────────────────────────────────────────────────────────────────────
def compute_ann_recall(model, flat_index, ivf_index, docs, k=10):
    texts = [d["text"] for d in docs]
    embeddings = model.encode(texts, normalize_embeddings=True).astype(np.float32)
    total_recall = 0
    for q_emb in embeddings:
        q = q_emb.reshape(1, -1)
        _, exact_ids = flat_index.search(q, k)
        _, ann_ids = ivf_index.search(q, k)
        overlap = len(set(exact_ids[0]) & set(ann_ids[0]))
        total_recall += overlap / k
    avg_recall = total_recall / len(embeddings)
    return avg_recall


# ─────────────────────────────────────────────────────────────────────────────
# VISUALIZATION 1: Embedding space (UMAP or PCA fallback)
# ─────────────────────────────────────────────────────────────────────────────
def plot_embedding_space(embeddings, docs, query_embeddings=None, query_texts=None):
    try:
        import umap
        reducer = umap.UMAP(n_components=2, random_state=42, n_neighbors=8, min_dist=0.2)
        method = "UMAP"
    except ImportError:
        from sklearn.decomposition import PCA
        reducer = PCA(n_components=2, random_state=42)
        method = "PCA"
        print("[WARN] umap-learn not installed — using PCA for 2D projection")

    all_vecs = embeddings
    if query_embeddings is not None:
        all_vecs = np.vstack([embeddings, query_embeddings])

    projected = reducer.fit_transform(all_vecs)
    doc_proj = projected[:len(embeddings)]
    q_proj = projected[len(embeddings):] if query_embeddings is not None else None

    fig, ax = plt.subplots(figsize=(12, 8))

    for i, doc in enumerate(docs):
        color = SPECIALTY_COLORS[doc["specialty"]]
        ax.scatter(doc_proj[i, 0], doc_proj[i, 1], color=color, s=80, zorder=3, alpha=0.85)
        ax.annotate(
            doc["id"],
            (doc_proj[i, 0], doc_proj[i, 1]),
            fontsize=6,
            alpha=0.7,
            ha="center",
            va="bottom",
        )

    if q_proj is not None and query_texts is not None:
        for i, (qp, qt) in enumerate(zip(q_proj, query_texts)):
            ax.scatter(qp[0], qp[1], marker="*", s=250, color="black", zorder=5)
            ax.annotate(
                f"Q{i+1}",
                (qp[0], qp[1]),
                fontsize=9,
                fontweight="bold",
                ha="center",
                va="bottom",
                color="black",
            )

    legend_patches = [
        mpatches.Patch(color=SPECIALTY_COLORS[s], label=s) for s in SPECIALTIES
    ]
    if query_embeddings is not None:
        legend_patches.append(
            mpatches.Patch(color="black", label="Queries (★)")
        )
    ax.legend(handles=legend_patches, loc="upper right", fontsize=8, title="Specialty")
    ax.set_title(
        f"Clinical Document Embedding Space ({method} 2D projection)\n"
        "Semantically similar documents cluster together across specialties",
        fontsize=12,
    )
    ax.set_xlabel(f"{method} Dimension 1")
    ax.set_ylabel(f"{method} Dimension 2")
    plt.tight_layout()
    plt.savefig("dense_embedding_space.png", dpi=150)
    print("  [saved] dense_embedding_space.png")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# VISUALIZATION 2: Pairwise specialty similarity heatmap
# ─────────────────────────────────────────────────────────────────────────────
def plot_specialty_similarity(embeddings, docs):
    import seaborn as sns

    specialty_vecs = {}
    for emb, doc in zip(embeddings, docs):
        specialty_vecs.setdefault(doc["specialty"], []).append(emb)
    specialty_centroids = {s: np.mean(vecs, axis=0) for s, vecs in specialty_vecs.items()}
    specialties = list(specialty_centroids.keys())
    mat = np.array([specialty_centroids[s] for s in specialties])
    sim_matrix = mat @ mat.T  # cosine sim (normalized vectors)

    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(
        sim_matrix,
        xticklabels=specialties,
        yticklabels=specialties,
        cmap="RdYlGn",
        vmin=0.0,
        vmax=1.0,
        annot=True,
        fmt=".2f",
        ax=ax,
        linewidths=0.5,
    )
    ax.set_title(
        "Inter-Specialty Semantic Similarity (Centroid Cosine Similarity)\n"
        "High values = specialties share language; useful for cross-specialty retrieval",
        fontsize=11,
    )
    plt.xticks(rotation=45, ha="right", fontsize=9)
    plt.yticks(rotation=0, fontsize=9)
    plt.tight_layout()
    plt.savefig("dense_specialty_similarity.png", dpi=150)
    print("  [saved] dense_specialty_similarity.png")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# PRINT COMPARISON TABLE
# ─────────────────────────────────────────────────────────────────────────────
def print_comparison(queries, model, flat_index, docs):
    sep = "─" * 82
    for q in queries:
        dense_hits = dense_search(q["text"], model, flat_index, docs, top_k=5)
        bm25_hits = bm25_search(docs, q["text"], top_k=5)

        print(f"\n{sep}")
        print(f"QUERY [{q['id']}]: {q['text']}")
        print(f"NOTE : {q['note']}")
        print(f"{'DENSE (Bi-Encoder)':^40}  {'BM25 (Sparse)':^38}")
        print(f"{'─'*40}  {'─'*38}")

        max_rows = max(len(dense_hits), len(bm25_hits))
        for i in range(min(3, max_rows)):
            dh = dense_hits[i] if i < len(dense_hits) else {}
            bh = bm25_hits[i] if i < len(bm25_hits) else {}
            d_str = (f"#{dh['rank']} [{dh['doc_id']}] {dh['title'][:22]:<22} {dh['score']:.3f}"
                     if dh else " " * 40)
            b_str = (f"#{bh['rank']} [{bh['doc_id']}] {bh['title'][:22]:<22} {bh['score']:.3f}"
                     if bh else " " * 40)
            same = "  " if (dh.get("doc_id") == bh.get("doc_id")) else "!!"
            print(f"  {d_str}  {same}  {b_str}")
    print()


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
def main():
    print("=" * 82)
    print("DEMO 3 — Dense Bi-Encoder + ANN Search for Healthcare IR")
    print(f"Corpus: {len(DOCUMENTS)} clinical document snippets")
    print("=" * 82)

    # 1. Encode
    model, embeddings = encode_corpus(DOCUMENTS)
    print(f"\nEmbedding shape: {embeddings.shape}  ({embeddings.shape[0]} docs × {embeddings.shape[1]} dims)")

    # 2. Build FAISS indices
    flat_index, ivf_index = build_faiss_indices(embeddings)

    # 3. Print retrieval comparison
    print("\n── Dense Bi-Encoder vs BM25 Comparison (!! = different top-3) ──")
    print_comparison(QUERIES, model, flat_index, DOCUMENTS)

    # 4. ANN recall
    print("[Computing ANN Recall@10 (IVF vs Exact) ...]")
    recall = compute_ann_recall(model, flat_index, ivf_index, DOCUMENTS, k=10)
    print(f"\nANN Recall@10: {recall:.3f}  ({recall*100:.1f}% of exact top-10 results returned)")

    # 5. Visualizations
    print("\n── Building visualizations ──")
    query_texts = [q["text"] for q in QUERIES]
    query_embeddings = model.encode(query_texts, normalize_embeddings=True).astype(np.float32)
    plot_embedding_space(embeddings, DOCUMENTS, query_embeddings, query_texts)
    plot_specialty_similarity(embeddings, DOCUMENTS)

    # 6. Summary
    print("\nKEY TAKEAWAYS")
    print("─" * 82)
    print("1. 'Heart attack' query retrieves STEMI/MI documents correctly (semantic bridging).")
    print("2. 'Blood thinner' → VTE/anticoagulation docs without exact term matching.")
    print("3. ANN (FAISS IVF) achieves high recall vs exact search with sub-linear time.")
    print("4. Embedding space clusters by specialty — enables cross-specialty discovery.")
    print("5. Domain-specific models (BioLORD, ClinicalBERT) significantly improve medical synonym handling.")
    print("6. Dense retrieval is weakest on exact values (drug doses, lab thresholds) — hybrid BM25+dense is best.")
    print("\n── THREE-SYSTEM RECOMMENDATION FOR PRODUCTION HEALTHCARE IR ──")
    print("  Stage 1 Retrieval : BM25 (exact terms) + Dense ANN (semantic) → fused candidate set")
    print("  Stage 2 Reranking : Cross-encoder (full attention, runs on shortlist of ~100 docs)")
    print("  This hybrid pipeline covers the weaknesses of each individual approach.")


if __name__ == "__main__":
    main()
