"""
=============================================================================
INFORMATION RETRIEVAL DEMO 2 — BM25 (Best Match 25)
=============================================================================

MECHANICS
─────────────────────────────────────────────────────────────────────────────
BM25 is a probabilistic ranking function that refines TF-IDF with two key
improvements: term frequency saturation and document length normalization.

  BM25(t, d, q) = IDF(t) × [ TF(t,d) × (k1 + 1) ]
                             ───────────────────────────────────
                             [ TF(t,d) + k1 × (1 - b + b × |d|/avgdl) ]

  PARAMETERS
  ──────────
  k1  (default 1.5)  — TF saturation point.
      At k1=1.5, adding more occurrences of a term beyond ~3-4 gives
      diminishing returns. At k1→∞, BM25 degrades to raw TF × IDF.
      At k1=0, only presence/absence matters (binary TF).

  b   (default 0.75) — document length normalization.
      b=1.0 = full normalization (long docs penalized heavily).
      b=0.0 = no normalization (same as TF-IDF with raw TF).
      b=0.75 = partial normalization — the standard healthcare sweet spot:
      a 5,000-word discharge summary and a 200-word lab report should
      not be penalized equally harshly.

  |d|      = length of document d in tokens
  avgdl    = average document length in the corpus
  IDF(t)   = log( (N - n(t) + 0.5) / (n(t) + 0.5) + 1 )
             (Robertson-Walker IDF variant, always positive)

  KEY DIFFERENCE vs TF-IDF
  ─────────────────────────
  TF-IDF:  score grows LINEARLY with term frequency (10 hits = 10× 1 hit).
  BM25:    score grows but SATURATES (10 hits ≈ 2× 1 hit when k1=1.5).

  Why saturation matters in EHRs:
  A discharge summary mentioning "hypertension" 20 times (chronic condition)
  should not dramatically outrank a diagnosis note that mentions it twice
  in a more targeted, relevant sentence.

─────────────────────────────────────────────────────────────────────────────
BM25 VARIANTS
─────────────────────────────────────────────────────────────────────────────

  BM25       — original Robertson et al. (1994); what most systems mean
  BM25+      — adds a floor (delta=1) so that a term present once always
               scores > 0 (prevents "term appears but gets zero score" bug)
  BM25L      — alternative normalization for very long documents
  BM25 Okapi — same as BM25, the Okapi IR system name for it

  This demo uses rank_bm25 library implementing standard BM25.

─────────────────────────────────────────────────────────────────────────────
BM25 vs TF-IDF — HEAD-TO-HEAD
─────────────────────────────────────────────────────────────────────────────

  Feature                  │  TF-IDF                  │  BM25
  ─────────────────────────┼──────────────────────────┼─────────────────────
  TF handling              │  Linear (raw or sublinear)│  Saturating (sigmoid)
  Doc length normalization │  L2 norm of vector        │  Explicit b parameter
  Tunable parameters       │  None                     │  k1 and b
  Output                   │  Dense cosine similarity  │  Scalar score (no cap)
  Matrix representation    │  Explicit vectors stored  │  Computed on-the-fly
  TREC benchmark results   │  Lower                    │  Consistently better
  Standard in Elasticsearch│  Legacy                   │  Default since v7.0
  Interpretability         │  Moderate                 │  High (same as TF-IDF)

─────────────────────────────────────────────────────────────────────────────
TRADEOFFS IN HEALTHCARE IR
─────────────────────────────────────────────────────────────────────────────

  STRENGTHS OVER TF-IDF
  • Handles noisy repetitive clinical text better:
    - Problem lists that repeat diagnoses across multiple sections
    - Templates that repeat "Patient denies..." 10× per note
    - Medication lists where "metformin" appears in header + body + footer
  • Length normalization respects the difference between a 50-word lab
    result and a 5,000-word operative note.
  • Tunable k1/b — can be optimized on a development set for your specific
    EHR system (e.g., radiology reports have different length distributions
    than progress notes).

  SHARED WEAKNESSES (vs dense models)
  • Still bag-of-words — "heart attack" ≠ "myocardial infarction"
  • No contextual understanding: negation, uncertainty not handled
    ("no signs of pneumonia" still matches "pneumonia" queries
  • Brittle on abbreviations and medical shorthand

  HEALTHCARE DEPLOYMENT CONTEXT
  • Default ranking function in Elasticsearch (clinical data platforms,
    Epic SearchMed, ClinicalKey, PubMed baseline ranking)
  • MIMIC-III / real-world EHR search benchmarks: BM25 consistently
    outperforms TF-IDF by 5-15% nDCG, making it the sparse IR gold standard
  • Combined with query expansion (UMLS synonyms) can close much of the
    vocabulary gap before bringing in heavier dense models

─────────────────────────────────────────────────────────────────────────────
THIS DEMO
─────────────────────────────────────────────────────────────────────────────
  Same 30-document clinical corpus as Demo 1.
  Compare BM25 vs TF-IDF on the same queries — highlighting where BM25 wins.
  Visualize TF saturation curve (how BM25 and TF-IDF weight term repetition).
  Run a parameter sensitivity analysis: how k1 and b affect ranking.

  Run:  python 02_bm25_demo.py
  Deps: pip install rank-bm25 scikit-learn matplotlib
=============================================================================
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

try:
    from rank_bm25 import BM25Okapi
except ImportError:
    raise SystemExit(
        "Missing dependency: run  pip install rank-bm25  then retry."
    )

# ─────────────────────────────────────────────────────────────────────────────
# SYNTHETIC CORPUS (same 30 documents as Demo 1)
# ─────────────────────────────────────────────────────────────────────────────
DOCUMENTS = [
    {"id": "D001", "title": "Metformin Therapy in Type 2 Diabetes",
     "text": "Metformin is the first-line pharmacological treatment for type 2 diabetes mellitus. "
             "It reduces hepatic glucose production and improves insulin sensitivity. "
             "Patients on metformin typically achieve HbA1c reduction of 1-2%. "
             "Common side effects include GI upset; lactic acidosis is rare but serious. "
             "Renal function eGFR must be monitored before initiation of metformin therapy."},
    {"id": "D002", "title": "Semaglutide for Glycemic Control",
     "text": "Semaglutide a GLP-1 receptor agonist is approved for type 2 diabetes and obesity. "
             "Weekly subcutaneous injection reduces HbA1c by up to 1.8% and body weight by 6-8 kg. "
             "Cardiovascular outcome trials show significant reduction in MACE events. "
             "Contraindicated in personal or family history of medullary thyroid carcinoma."},
    {"id": "D003", "title": "Insulin Initiation for Uncontrolled Diabetes",
     "text": "When oral agents fail to achieve glycemic targets insulin therapy is initiated. "
             "Basal insulin glargine or detemir is preferred for type 2 diabetes. "
             "Starting dose 10 units per day or 0.1-0.2 units per kg per day titrated to fasting glucose. "
             "Hypoglycemia is the primary risk; patients require education on self-monitoring."},
    {"id": "D004", "title": "Diabetic Ketoacidosis Management Protocol",
     "text": "DKA is a life-threatening complication of diabetes characterized by hyperglycemia ketosis "
             "and metabolic acidosis. IV fluid resuscitation with normal saline is first-line. "
             "Insulin infusion should begin after potassium replacement if K+ less than 3.5 mEq per L. "
             "Bicarbonate therapy is reserved for severe acidosis pH less than 6.9. "
             "Monitor glucose electrolytes and anion gap every 1-2 hours in DKA."},
    {"id": "D005", "title": "Continuous Glucose Monitoring in Diabetes",
     "text": "CGM devices measure interstitial glucose every 5 minutes and display trends. "
             "Time-in-range 70-180 mg per dL is the primary CGM metric correlated with HbA1c. "
             "Real-time alerts for hypoglycemia improve patient safety vs fingerstick alone. "
             "Sensor accuracy MARD less than 10% is critical for insulin dosing decisions in diabetes."},
    {"id": "C001", "title": "Acute Myocardial Infarction STEMI Protocol",
     "text": "STEMI management requires primary PCI within 90 minutes of first medical contact. "
             "Dual antiplatelet therapy aspirin 325 mg plus ticagrelor 180 mg loading dose. "
             "Anticoagulation with unfractionated heparin during PCI procedure. "
             "Post-PCI statin therapy beta-blocker ACE inhibitor initiated before discharge. "
             "Ejection fraction measured by echocardiogram guides further management after STEMI."},
    {"id": "C002", "title": "Heart Failure with Reduced Ejection Fraction",
     "text": "HFrEF EF less than 40% guideline-directed therapy includes four pillars: "
             "ACE inhibitor ARB ARNI beta-blocker MRA spironolactone and SGLT2 inhibitor. "
             "Dapagliflozin reduces hospitalization and cardiovascular death in HFrEF. "
             "Loop diuretics furosemide manage volume overload but do not improve survival. "
             "ICD implantation indicated if EF remains less than 35% after 3 months GDMT."},
    {"id": "C003", "title": "Atrial Fibrillation Anticoagulation Guidelines",
     "text": "AF increases stroke risk 5-fold. CHA2DS2-VASc score guides anticoagulation decisions. "
             "DOACs apixaban rivaroxaban dabigatran preferred over warfarin in non-valvular AF. "
             "Apixaban 5 mg BID superior stroke reduction with less bleeding than warfarin. "
             "Rate control target resting HR less than 80 bpm using beta-blocker or calcium channel blocker. "
             "Rhythm control with cardioversion or ablation for symptomatic atrial fibrillation."},
    {"id": "C004", "title": "Hypertension Management in Chronic Kidney Disease",
     "text": "Target BP in CKD is less than 130/80 mmHg per ACC/AHA guidelines. "
             "ACE inhibitors or ARBs are first-line in CKD with proteinuria due to renoprotective effect. "
             "Avoid NSAIDs; monitor potassium and creatinine after initiating RAAS blockade in CKD. "
             "Thiazide diuretics effective if eGFR greater than 30; loop diuretics preferred if eGFR less than 30. "
             "Resistant hypertension add spironolactone or refer to nephrology."},
    {"id": "C005", "title": "Cardiac Biomarkers in Chest Pain Evaluation",
     "text": "High-sensitivity troponin I or T is the gold standard for myocardial injury detection. "
             "Serial troponin at 0h and 3h rules out NSTEMI. "
             "BNP greater than 100 pg per mL or NT-proBNP greater than 300 pg per mL supports heart failure. "
             "D-dimer used to exclude pulmonary embolism in low-to-intermediate pretest probability. "
             "CK-MB less sensitive than troponin still used for reinfarction detection."},
    {"id": "O001", "title": "Non-Small Cell Lung Cancer Targeted Therapy",
     "text": "EGFR mutation testing is mandatory before first-line therapy in NSCLC. "
             "Osimertinib 3rd-gen EGFR TKI is first-line for EGFR exon 19/21 mutations. "
             "ALK rearrangement alectinib preferred over crizotinib better CNS penetration. "
             "PD-L1 expression guides immunotherapy pembrolizumab use in wild-type NSCLC. "
             "KRAS G12C inhibitor sotorasib approved for previously treated KRAS-mutant NSCLC."},
    {"id": "O002", "title": "Breast Cancer Hormone Receptor Positive Treatment",
     "text": "HR+/HER2- breast cancer CDK4/6 inhibitors palbociclib ribociclib plus endocrine therapy. "
             "Aromatase inhibitors letrozole anastrozole preferred in postmenopausal breast cancer patients. "
             "Tamoxifen for premenopausal women 10 years therapy reduces recurrence risk. "
             "PIK3CA mutation add alpelisib PI3K inhibitor after endocrine therapy progression. "
             "Bone-modifying agents reduce skeletal events in metastatic breast cancer disease."},
    {"id": "O003", "title": "Colorectal Cancer Screening Protocols",
     "text": "Average-risk adults colonoscopy every 10 years starting at age 45 ACS guideline. "
             "Stool-based tests FIT annually or Cologuard every 3 years as alternatives for colorectal cancer. "
             "High-risk Lynch syndrome FAP colonoscopy starting at 20-25 years old. "
             "CEA is a tumor marker used for monitoring CRC recurrence not screening. "
             "Positive non-invasive test requires follow-up colonoscopy within 3-6 months."},
    {"id": "O004", "title": "Chemotherapy-Induced Neutropenia Management",
     "text": "Febrile neutropenia ANC less than 500 fever greater than 38.3C requires broad-spectrum antibiotics. "
             "Empiric therapy piperacillin-tazobactam or cefepime add vancomycin for MRSA risk. "
             "G-CSF filgrastim primary prophylaxis for regimens with greater than 20% FN risk. "
             "MASCC score less than 21 identifies high-risk patients requiring hospitalization with neutropenia. "
             "Blood cultures x2 and chest X-ray before antibiotics if possible but do not delay treatment."},
    {"id": "O005", "title": "CAR-T Cell Therapy for Hematologic Malignancies",
     "text": "Chimeric antigen receptor T-cell therapy targets CD19 for B-cell lymphomas and leukemias. "
             "Axicabtagene ciloleucel and tisagenlecleucel approved for relapsed refractory DLBCL. "
             "Cytokine release syndrome CRS graded 1-4 tocilizumab IL-6 receptor blockade for grade 2+. "
             "Immune effector cell-associated neurotoxicity ICANS requires dexamethasone treatment. "
             "T-cell manufacturing takes 3-4 weeks bridging therapy may be needed."},
    {"id": "I001", "title": "Sepsis and Septic Shock Management",
     "text": "Sepsis-3 definition life-threatening organ dysfunction from infection SOFA score >= 2. "
             "Septic shock sepsis plus vasopressor requirement and lactate greater than 2 mmol per L. "
             "Hour-1 bundle blood cultures broad-spectrum antibiotics 30 mL per kg IV crystalloid. "
             "Norepinephrine first-line vasopressor add vasopressin if MAP less than 65 despite NE. "
             "Procalcitonin-guided antibiotic de-escalation reduces duration without harm in sepsis."},
    {"id": "I002", "title": "COVID-19 Antiviral Treatment Options",
     "text": "Nirmatrelvir-ritonavir Paxlovid reduces hospitalization by 89% in high-risk patients. "
             "Must be initiated within 5 days of symptom onset 5-day oral course for COVID-19. "
             "Drug interactions with ritonavir are extensive check all concurrent medications. "
             "Remdesivir IV approved for hospitalized patients requiring supplemental oxygen for COVID-19. "
             "Dexamethasone 6 mg per day for patients requiring oxygen harmful if no oxygen needed."},
    {"id": "I003", "title": "Antibiotic Stewardship in Hospital Settings",
     "text": "Antibiotic stewardship programs ASP reduce C. difficile resistance and hospital costs. "
             "Prospective audit and feedback ID physician reviews all broad-spectrum antibiotic orders. "
             "Formulary restriction carbapenems require pre-authorization in stewardship program. "
             "IV-to-oral switch amoxicillin ciprofloxacin azithromycin achieve similar serum levels. "
             "Culture results should trigger de-escalation to narrowest effective antibiotic within 48-72h."},
    {"id": "N001", "title": "Ischemic Stroke Thrombolysis Protocol",
     "text": "IV alteplase tPA within 4.5 hours of stroke symptom onset in eligible patients. "
             "Contraindications recent surgery active bleeding BP greater than 185/110 uncontrolled. "
             "Mechanical thrombectomy for large vessel occlusion up to 24 hours if penumbra viable. "
             "NIHSS score documents deficit severity target BP less than 180/105 post-tPA for stroke. "
             "Dual antiplatelet therapy aspirin plus clopidogrel for minor stroke TIA for 21 days."},
    {"id": "N002", "title": "Epilepsy and Antiseizure Medication Management",
     "text": "First unprovoked seizure treat if EEG abnormal brain lesion or nocturnal onset. "
             "Focal epilepsy lamotrigine or levetiracetam first-line lacosamide alternative antiseizure. "
             "Generalized epilepsy valproate most effective but teratogenic avoid in women of childbearing age. "
             "Status epilepticus lorazepam 0.1 mg per kg IV then levetiracetam 60 mg per kg IV. "
             "Therapeutic drug monitoring required for phenytoin valproate carbamazepine antiseizure."},
    {"id": "K001", "title": "Acute Kidney Injury Risk Stratification",
     "text": "AKI defined by KDIGO creatinine rise >= 0.3 mg per dL in 48h or >= 1.5× baseline in 7 days. "
             "Three stages Stage 1 1.5-1.9× baseline Stage 2 2-2.9× Stage 3 >= 3× or dialysis for AKI. "
             "Most common causes in hospital prerenal volume depletion sepsis nephrotoxins contrast NSAIDs. "
             "Urinary biomarkers NGAL and KIM-1 detect AKI before creatinine rise occurs. "
             "Renal replacement therapy indicated for refractory acidosis hyperkalemia or volume overload."},
    {"id": "P001", "title": "COPD Exacerbation Management",
     "text": "AECOPD triggered by infection pollution or cold air exacerbating COPD symptoms. "
             "SABA albuterol plus SAMA ipratropium nebulization every 4-6 hours for COPD exacerbation. "
             "Systemic corticosteroids prednisone 40 mg x 5 days reduce treatment failure in COPD. "
             "Antibiotics if 2 of 3 Anthonisen criteria increased dyspnea sputum volume sputum purulence. "
             "Non-invasive ventilation CPAP BiPAP for pH less than 7.35 and PaCO2 greater than 45 mmHg."},
    {"id": "PH001", "title": "Drug-Drug Interaction Warfarin and Antibiotics",
     "text": "Many antibiotics potentiate warfarin by killing gut flora that produce vitamin K. "
             "Fluconazole and metronidazole inhibit CYP2C9 dramatically increasing INR in warfarin patients. "
             "Rifampin induces CYP2C9/3A4 reducing warfarin effect dose increase needed. "
             "Check INR within 3-5 days of starting or stopping any antibiotic in warfarin patients. "
             "Azithromycin amoxicillin moderate interaction still requires INR monitoring with warfarin."},
    {"id": "PH002", "title": "Opioid Prescribing and Pain Management",
     "text": "WHO analgesic ladder non-opioid first then weak opioid tramadol then strong opioid morphine. "
             "Morphine equivalent dose MED greater than 90 mg per day associated with increased overdose risk. "
             "Always co-prescribe naloxone rescue inhaler for patients on greater than 50 MED or with risk factors. "
             "Urine drug screening and prescription monitoring programs PDMP before prescribing opioids. "
             "Abuse-deterrent formulations extended-release oxycodone with naltrexone for chronic pain."},
    {"id": "H001", "title": "Venous Thromboembolism Treatment",
     "text": "DVT and PE anticoagulate for minimum 3 months DOACs first-line over LMWH warfarin. "
             "Rivaroxaban 15 mg BID x 21 days then 20 mg daily for venous thromboembolism treatment. "
             "Cancer-associated thrombosis LMWH or rivaroxaban preferred over warfarin for VTE. "
             "Massive PE with hemodynamic instability systemic thrombolysis alteplase 100 mg IV x 2h. "
             "IVC filter only if anticoagulation is absolutely contraindicated for thromboembolism."},
    {"id": "G001", "title": "H pylori Eradication Therapy",
     "text": "First-line clarithromycin triple therapy PPI plus clarithromycin plus amoxicillin x 14 days. "
             "Clarithromycin resistance greater than 15% in region use bismuth quadruple therapy. "
             "Confirm eradication with urea breath test or stool antigen >= 4 weeks post-treatment for H pylori. "
             "H pylori eradication reduces peptic ulcer recurrence from 80% to less than 5% at 1 year. "
             "Test-and-treat strategy recommended for uninvestigated dyspepsia in low-risk patients."},
    {"id": "R001", "title": "CT Pulmonary Angiography for PE Diagnosis",
     "text": "CTPA is the gold standard imaging for pulmonary embolism with sensitivity greater than 95%. "
             "Wells score stratifies pretest probability D-dimer less than 500 ng per mL rules out PE. "
             "Contrast nephropathy risk hold metformin 48h post-contrast if eGFR less than 60. "
             "V/Q scan preferred in pregnancy or severe renal impairment to minimize radiation contrast exposure. "
             "Incidental pulmonary nodules on CTPA require Fleischner Society follow-up guidelines."},
    {"id": "PED001", "title": "Pediatric Asthma Stepwise Management",
     "text": "Step 1 SABA PRN for intermittent asthma. Step 2 low-dose ICS daily for persistent asthma. "
             "Step 3 low-dose ICS plus LABA or medium-dose ICS for moderate persistent asthma control. "
             "Step 4 medium-dose ICS plus LABA for severe persistent asthma management. "
             "Biologic therapy dupilumab mepolizumab for severe uncontrolled asthma >= step 5. "
             "Spacer device required for MDI use in children under 5 avoid nebulizer if MDI available."},
    {"id": "MH001", "title": "Depression Pharmacotherapy Selection",
     "text": "SSRIs sertraline escitalopram first-line for major depressive disorder treatment. "
             "Response expected at 4-8 weeks full trial requires 6-8 weeks at therapeutic dose for depression. "
             "Switch or augment add bupropion or lithium after two failed SSRI trials for depression. "
             "SNRIs venlafaxine duloxetine preferred for comorbid pain or anxiety with depression. "
             "MAOIs reserved for refractory depression strict tyramine diet and drug interaction vigilance."},
    {"id": "S001", "title": "Perioperative Anticoagulation Bridging",
     "text": "Bridging anticoagulation replace warfarin with LMWH UFH around surgery perioperatively. "
             "High-risk AF CHADS2 >= 5 recent stroke bridging anticoagulation recommended for surgery. "
             "Low-risk CHADS2 <= 2 no recent stroke bridging not needed may increase bleeding perioperatively. "
             "Stop warfarin 5 days pre-op start LMWH 3 days pre-op stop LMWH 24h pre-op before surgery. "
             "DOAC patients no bridging needed simply hold drug 24-48h or 48-72h for high bleed procedures."},
]

# ─────────────────────────────────────────────────────────────────────────────
# DEMO QUERIES — same as Demo 1 for direct comparison
# ─────────────────────────────────────────────────────────────────────────────
QUERIES = [
    {"id": "Q1", "text": "HbA1c reduction with metformin in type 2 diabetes",
     "note": "Exact term match — both should excel"},
    {"id": "Q2", "text": "heart attack treatment aspirin antiplatelet",
     "note": "Synonym challenge: 'heart attack' vs 'STEMI'/'myocardial infarction'"},
    {"id": "Q3", "text": "antibiotic selection febrile neutropenia cancer patient",
     "note": "Multi-concept: oncology + infectious disease"},
    {"id": "Q4", "text": "stroke thrombolysis tPA eligibility window",
     "note": "Clinical procedure with exact terminology"},
    {"id": "Q5", "text": "blood clot prevention anticoagulation",
     "note": "Generic language vs specialized medical terms"},
    {"id": "Q6", "text": "diabetes diabetes diabetes diabetes insulin",
     "note": "REPETITION TEST: shows BM25 saturation vs TF-IDF linear growth"},
]


# ─────────────────────────────────────────────────────────────────────────────
# BM25 SEARCH
# ─────────────────────────────────────────────────────────────────────────────
def tokenize(text: str) -> list[str]:
    """Simple whitespace + lowercase tokenizer (mirrors BM25Okapi default)."""
    return text.lower().split()


def bm25_search(docs, queries, top_k=5, k1=1.5, b=0.75):
    tokenized_corpus = [tokenize(d["text"]) for d in docs]
    bm25 = BM25Okapi(tokenized_corpus, k1=k1, b=b)

    results = []
    for q in queries:
        tokenized_query = tokenize(q["text"])
        scores = bm25.get_scores(tokenized_query)
        ranked_indices = np.argsort(scores)[::-1][:top_k]
        hits = [
            {
                "rank": rank + 1,
                "doc_id": docs[idx]["id"],
                "title": docs[idx]["title"],
                "score": scores[idx],
                "snippet": docs[idx]["text"][:100] + "...",
            }
            for rank, idx in enumerate(ranked_indices)
        ]
        results.append({"query": q, "hits": hits})
    return results


# ─────────────────────────────────────────────────────────────────────────────
# TF-IDF SEARCH (for comparison)
# ─────────────────────────────────────────────────────────────────────────────
def tfidf_search(docs, queries, top_k=5):
    corpus = [d["text"] for d in docs]
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, stop_words="english")
    matrix = vectorizer.fit_transform(corpus)
    results = []
    for q in queries:
        q_vec = vectorizer.transform([q["text"]])
        scores = cosine_similarity(q_vec, matrix).flatten()
        ranked_indices = np.argsort(scores)[::-1][:top_k]
        hits = [
            {"rank": rank + 1, "doc_id": docs[idx]["id"],
             "title": docs[idx]["title"], "score": scores[idx]}
            for rank, idx in enumerate(ranked_indices)
        ]
        results.append({"query": q, "hits": hits})
    return results


# ─────────────────────────────────────────────────────────────────────────────
# VISUALIZATION 1: TF saturation curve
# ─────────────────────────────────────────────────────────────────────────────
def plot_tf_saturation():
    tf_values = np.linspace(0, 15, 300)

    # BM25 TF component (numerator only, ignoring length normalization):
    k1 = 1.5
    bm25_tf = (tf_values * (k1 + 1)) / (tf_values + k1)

    # TF-IDF with raw TF
    tfidf_raw = tf_values

    # TF-IDF with sublinear TF (sklearn default)
    sublinear = np.where(tf_values > 0, 1 + np.log(tf_values + 1e-9), 0)

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(tf_values, bm25_tf, label=f"BM25 TF component (k1={k1})", linewidth=2.5, color="steelblue")
    ax.plot(tf_values, sublinear, label="Sublinear TF (sklearn TF-IDF)", linewidth=2.5, color="darkorange", linestyle="--")
    ax.plot(tf_values, tfidf_raw / tfidf_raw.max() * bm25_tf.max(),
            label="Raw TF (scaled for comparison)", linewidth=2, color="gray", linestyle=":")

    ax.axvline(x=3, color="red", linestyle=":", alpha=0.5, linewidth=1.5)
    ax.text(3.2, 0.3, "Typical EHR\nterm repetition", fontsize=9, color="red")

    ax.set_xlabel("Term frequency in document", fontsize=12)
    ax.set_ylabel("Score contribution", fontsize=12)
    ax.set_title("TF Saturation: BM25 vs TF-IDF\n"
                 "BM25 rapidly saturates — prevents over-rewarding noisy repetition in clinical notes",
                 fontsize=12)
    ax.legend(fontsize=10)
    ax.set_xlim(0, 15)
    ax.set_ylim(0, None)
    plt.tight_layout()
    plt.savefig("bm25_tf_saturation.png", dpi=150)
    print("  [saved] bm25_tf_saturation.png")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# VISUALIZATION 2: k1 parameter sensitivity
# ─────────────────────────────────────────────────────────────────────────────
def plot_k1_sensitivity(docs):
    query = "diabetes insulin HbA1c glucose management"
    tokenized_corpus = [tokenize(d["text"]) for d in docs]
    tokenized_query = tokenize(query)

    k1_values = [0.5, 1.0, 1.5, 2.0, 3.0]
    colors = plt.cm.viridis(np.linspace(0.1, 0.9, len(k1_values)))

    top3_titles = None
    all_scores = {}
    for k1 in k1_values:
        bm25 = BM25Okapi(tokenized_corpus, k1=k1, b=0.75)
        scores = bm25.get_scores(tokenized_query)
        all_scores[k1] = scores
        if top3_titles is None:
            top3_idx = np.argsort(scores)[::-1][:8]
            top3_titles = [docs[i]["title"][:25] for i in top3_idx]
            top3_indices = top3_idx

    fig, ax = plt.subplots(figsize=(12, 5))
    x = np.arange(len(top3_indices))
    width = 0.15
    for i, (k1, color) in enumerate(zip(k1_values, colors)):
        vals = [all_scores[k1][idx] for idx in top3_indices]
        ax.bar(x + i * width, vals, width, label=f"k1={k1}", color=color, alpha=0.85)

    ax.set_xticks(x + width * 2)
    ax.set_xticklabels(top3_titles, rotation=30, ha="right", fontsize=9)
    ax.set_ylabel("BM25 Score")
    ax.set_title(f'k1 Sensitivity Analysis\nQuery: "{query}"', fontsize=12)
    ax.legend(title="k1 value", fontsize=9)
    plt.tight_layout()
    plt.savefig("bm25_k1_sensitivity.png", dpi=150)
    print("  [saved] bm25_k1_sensitivity.png")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# PRINT COMPARISON RESULTS
# ─────────────────────────────────────────────────────────────────────────────
def print_comparison(bm25_results, tfidf_results):
    sep = "─" * 80
    for b_res, t_res in zip(bm25_results, tfidf_results):
        q = b_res["query"]
        print(f"\n{sep}")
        print(f"QUERY [{q['id']}]: {q['text']}")
        print(f"NOTE : {q['note']}")
        print(f"{'BM25':^38}  {'TF-IDF':^38}")
        print(f"{'─'*38}  {'─'*38}")
        for b_hit, t_hit in zip(b_res["hits"][:3], t_res["hits"][:3]):
            b_str = f"#{b_hit['rank']} [{b_hit['doc_id']}] {b_hit['title'][:25]:<25} {b_hit['score']:.3f}"
            t_str = f"#{t_hit['rank']} [{t_hit['doc_id']}] {t_hit['title'][:25]:<25} {t_hit['score']:.3f}"
            same = "  " if b_hit["doc_id"] == t_hit["doc_id"] else "!!"
            print(f"  {b_str}  {same}  {t_str}")
    print()


def main():
    print("=" * 80)
    print("DEMO 2 — BM25 Information Retrieval in Healthcare")
    print(f"Corpus: {len(DOCUMENTS)} clinical document snippets")
    print("=" * 80)

    bm25_results = bm25_search(DOCUMENTS, QUERIES, top_k=5)
    tfidf_results = tfidf_search(DOCUMENTS, QUERIES, top_k=5)

    print("\n── BM25 vs TF-IDF Top-3 Comparison (!! = different results) ──")
    print_comparison(bm25_results, tfidf_results)

    print("\n── Generating visualizations ──")
    plot_tf_saturation()
    plot_k1_sensitivity(DOCUMENTS)

    print("\nKEY TAKEAWAYS")
    print("─" * 80)
    print("1. Q6 (repeated 'diabetes'): BM25 ranks shorter, focused docs higher.")
    print("   TF-IDF over-rewards the doc that repeats 'diabetes' most — BM25 saturates.")
    print("2. BM25 is the DEFAULT in Elasticsearch (used by Epic, Cerner, most EHR platforms).")
    print("3. k1 tuning: lower k1 = faster saturation (good for short, template-heavy notes).")
    print("4. b parameter: lower b = less length penalization (good for long discharge summaries).")
    print("5. Both fail on synonyms ('heart attack' vs 'MI') — that's where Demo 3 wins.")


if __name__ == "__main__":
    main()
