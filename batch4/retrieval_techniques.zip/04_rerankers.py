"""
=============================================================================
CLINICAL TRIAL SEARCH — Reranking Techniques Demo
=============================================================================

WHAT THIS DEMO COVERS
----------------------
  Using the same 20-document clinical-trial corpus from the TF-IDF / nDCG
  demo, this file demonstrates a two-stage retrieval pipeline and compares
  four ranking approaches:

    Stage 1 (first-pass retrieval)
      A) TF-IDF — sparse keyword-based baseline (same as the other demo)

    Stage 2 (rerankers applied to the top-k TF-IDF candidates)
      B) Bi-encoder reranker  — dense sentence embeddings, fast, approximate
      C) Cross-encoder reranker — full query×document attention, slower, best
      D) Reciprocal Rank Fusion (RRF) — ensemble of TF-IDF + bi-encoder lists

  At each stage we compute nDCG@10 so you can see how much (or how little)
  each technique improves over the baseline.

─────────────────────────────────────────────────────────────────────────────
WHY TWO STAGES?
─────────────────────────────────────────────────────────────────────────────
  Modern IR systems almost always use a two-stage (retrieve → rerank) pipeline:

    1. RETRIEVAL  — cheap, runs over the full corpus (millions of docs).
       Goal: recall — return a candidate set that CONTAINS the relevant docs.
       Typical models: TF-IDF, BM25, dense bi-encoder ANN search.

    2. RERANKING  — expensive, runs only over the small candidate set (~100 docs).
       Goal: precision — put the BEST doc at rank 1, second best at rank 2, …
       Typical models: cross-encoder, learning-to-rank, LLM-based rerankers.

  The intuition: a cross-encoder reads "query + document" as one joint input,
  allowing full token-level attention between query and document tokens.
  This is far more powerful than comparing independent query/doc vectors, but
  also ~100× slower — hence we only apply it to the shortlist, not the corpus.

─────────────────────────────────────────────────────────────────────────────
BI-ENCODER vs CROSS-ENCODER
─────────────────────────────────────────────────────────────────────────────

  ┌──────────────────┬────────────────────────────────────────────────────┐
  │                  │               BI-ENCODER                          │
  │                  ├────────────────────────────────────────────────────┤
  │  Architecture    │ query → encoder → q_vec  (independently)          │
  │                  │  doc  → encoder → d_vec                           │
  │  Scoring         │ cosine_similarity(q_vec, d_vec)                   │
  │  Interaction     │ NONE — vectors are compared AFTER encoding        │
  │  Speed           │ Fast — doc vectors pre-computed once offline      │
  │  Quality         │ Good for retrieval; misses subtle relevance       │
  │  Example model   │ sentence-transformers/all-MiniLM-L6-v2            │
  ├──────────────────┼────────────────────────────────────────────────────┤
  │                  │               CROSS-ENCODER                       │
  │                  ├────────────────────────────────────────────────────┤
  │  Architecture    │ [CLS] query [SEP] document [SEP] → encoder → score│
  │  Scoring         │ single scalar from the final [CLS] token          │
  │  Interaction     │ FULL — every query token attends to every doc     │
  │                  │ token through all transformer layers              │
  │  Speed           │ Slow — must run inference for each (q, doc) pair  │
  │  Quality         │ Best — captures nuanced relevance signals        │
  │  Example model   │ cross-encoder/ms-marco-MiniLM-L-6-v2             │
  └──────────────────┴────────────────────────────────────────────────────┘

─────────────────────────────────────────────────────────────────────────────
RECIPROCAL RANK FUSION (RRF)
─────────────────────────────────────────────────────────────────────────────
  RRF is a simple, parameter-light method to COMBINE multiple ranked lists
  without needing to know each system's score scale.

  For document d, given ranked lists L1, L2, ..., Lm:

            m       1
    RRF(d) = Σ  ─────────────
            i=1  k + rank_i(d)

  where rank_i(d) is d's position in list Li (1-based), and k is a smoothing
  constant (typically 60) that reduces the impact of very high-ranked docs.

  Key properties:
    • Score-agnostic — only RANKS matter, not raw scores
    • Robust — a doc consistently in the top-10 of multiple lists beats
      a doc that tops one list but appears poorly in others
    • Trivial to implement and surprisingly effective in practice

─────────────────────────────────────────────────────────────────────────────
REQUIRED PACKAGES
─────────────────────────────────────────────────────────────────────────────
  pip install sentence-transformers scikit-learn numpy

  The demo uses two pre-trained HuggingFace models (downloaded automatically
  on first run, ~90 MB total):
    • sentence-transformers/all-MiniLM-L6-v2   (bi-encoder)
    • cross-encoder/ms-marco-MiniLM-L-6-v2     (cross-encoder)

=============================================================================
"""

import sys
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

sys.stdout.reconfigure(encoding="utf-8")

# ─────────────────────────────────────────────────────────────────────────────
# CORPUS — identical to clinical_trial_search_ndcg.py
# 20 clinical-trial abstracts; each has a relevance grade (0–3) for the
# query "Type 2 diabetes insulin therapy randomised controlled trial"
# ─────────────────────────────────────────────────────────────────────────────

CORPUS = [
    {
        "doc_id": "CT-001",
        "title": "Insulin Glargine vs. NPH in Type 2 Diabetes — RCT",
        "text": (
            "A randomised controlled trial comparing insulin glargine with NPH insulin "
            "in 480 patients with type 2 diabetes mellitus. Primary endpoint was HbA1c "
            "reduction at 24 weeks. Insulin glargine achieved superior glycaemic control "
            "with fewer nocturnal hypoglycaemia events. Secondary endpoints included "
            "fasting plasma glucose and patient-reported quality of life. Basal insulin "
            "therapy was well tolerated across all subgroups."
        ),
        "grade": 3,
    },
    {
        "doc_id": "CT-002",
        "title": "Metformin as First-Line Therapy in Newly Diagnosed Type 2 Diabetes",
        "text": (
            "Prospective cohort study evaluating metformin monotherapy in 620 adults with "
            "newly diagnosed type 2 diabetes. Patients were followed for 12 months. "
            "Metformin reduced HbA1c by 1.5% on average. Gastrointestinal side effects "
            "were the most common reason for discontinuation. No insulin therapy was used. "
            "Lifestyle modification counselling was provided to all participants."
        ),
        "grade": 2,
    },
    {
        "doc_id": "CT-003",
        "title": "Empagliflozin Cardiovascular Outcomes in Type 2 Diabetes",
        "text": (
            "The EMPA-REG OUTCOME trial randomised 7,020 patients with type 2 diabetes and "
            "high cardiovascular risk to empagliflozin or placebo. The primary composite "
            "outcome was death from cardiovascular causes, non-fatal myocardial infarction, "
            "or non-fatal stroke. Empagliflozin significantly reduced cardiovascular "
            "mortality. Secondary outcomes included hospitalisation for heart failure and "
            "renal function markers. Insulin use was permitted as background therapy."
        ),
        "grade": 2,
    },
    {
        "doc_id": "CT-004",
        "title": "Intensive Insulin Therapy in Critically Ill Patients (ICU Trial)",
        "text": (
            "Randomised trial of intensive insulin therapy targeting blood glucose 4.4–6.1 "
            "mmol/L versus conventional treatment in 1,548 ICU patients. Intensive insulin "
            "therapy reduced in-hospital mortality by 34%. Severe hypoglycaemia was more "
            "frequent in the intensive group. This landmark trial established tight glycaemic "
            "control protocols in critical care settings worldwide."
        ),
        "grade": 2,
    },
    {
        "doc_id": "CT-005",
        "title": "Liraglutide Once-Daily vs. Placebo in Type 2 Diabetes (LEAD-3)",
        "text": (
            "LEAD-3 was a 52-week randomised double-blind trial comparing liraglutide "
            "monotherapy with glimepiride in patients with early type 2 diabetes. Liraglutide "
            "produced greater HbA1c reductions and significant weight loss. Nausea was the "
            "most common adverse event. No insulin was used. This GLP-1 receptor agonist "
            "trial informed first-line treatment guidelines."
        ),
        "grade": 2,
    },
    {
        "doc_id": "CT-006",
        "title": "Hybrid Closed-Loop Insulin Delivery in Type 1 Diabetes",
        "text": (
            "Six-month randomised crossover trial of a hybrid closed-loop insulin delivery "
            "system versus sensor-augmented pump therapy in 86 adults with type 1 diabetes. "
            "Time-in-range (3.9–10 mmol/L) improved by 11 percentage points with the "
            "closed-loop system. Insulin dosing was automated via algorithm. No type 2 "
            "diabetes patients were enrolled."
        ),
        "grade": 1,
    },
    {
        "doc_id": "CT-007",
        "title": "Bariatric Surgery vs. Medical Therapy for Obese Type 2 Diabetes",
        "text": (
            "Randomised trial of Roux-en-Y gastric bypass versus intensive medical therapy "
            "in 150 obese patients with type 2 diabetes. Surgical remission rate at 3 years "
            "was 38% versus 5% in the medical arm. HbA1c, fasting glucose, and insulin "
            "resistance markers all improved post-surgery. Some patients were on basal "
            "insulin at baseline and were able to discontinue after surgery."
        ),
        "grade": 2,
    },
    {
        "doc_id": "CT-008",
        "title": "ACE Inhibitor Therapy for Hypertension — HOPE Trial",
        "text": (
            "The HOPE trial enrolled 9,297 patients aged ≥55 years with cardiovascular "
            "disease or diabetes at high risk. Ramipril (an ACE inhibitor) significantly "
            "reduced the risk of MI, stroke, and cardiovascular death. A subgroup analysis "
            "in patients with diabetes showed consistent benefit. No insulin therapy was "
            "studied as a primary or secondary intervention."
        ),
        "grade": 1,
    },
    {
        "doc_id": "CT-009",
        "title": "SGLT2 Inhibitor Dapagliflozin in Heart Failure (DAPA-HF)",
        "text": (
            "DAPA-HF randomised 4,744 patients with heart failure and reduced ejection "
            "fraction to dapagliflozin or placebo. Approximately 45% had type 2 diabetes. "
            "The primary composite outcome of worsening heart failure or cardiovascular "
            "death was significantly reduced. Dapagliflozin's mechanism is insulin-independent. "
            "Renal outcomes were a secondary endpoint."
        ),
        "grade": 1,
    },
    {
        "doc_id": "CT-010",
        "title": "Prevention of Type 2 Diabetes by Lifestyle Intervention — DPP Trial",
        "text": (
            "The Diabetes Prevention Program (DPP) randomised 3,234 participants with "
            "impaired glucose tolerance to intensive lifestyle change, metformin, or placebo. "
            "Lifestyle intervention reduced diabetes incidence by 58%. Metformin reduced it "
            "by 31%. No insulin was used. This prevention trial is a cornerstone of public "
            "health guidelines for prediabetes management."
        ),
        "grade": 1,
    },
    {
        "doc_id": "CT-011",
        "title": "Atorvastatin for LDL Reduction in Hypercholesterolaemia (ASCOT-LLA)",
        "text": (
            "ASCOT-LLA tested atorvastatin 10mg versus placebo in 10,305 hypertensive patients "
            "with total cholesterol ≤6.5 mmol/L. The trial was stopped early due to a 36% "
            "relative risk reduction in primary coronary events. No glucose-lowering "
            "intervention was studied. Diabetes was an exclusion criterion in some strata."
        ),
        "grade": 0,
    },
    {
        "doc_id": "CT-012",
        "title": "Pembrolizumab plus Chemotherapy for Non-Small-Cell Lung Cancer",
        "text": (
            "KEYNOTE-189 randomised 616 patients with metastatic non-squamous NSCLC to "
            "pembrolizumab plus platinum-based chemotherapy or placebo plus chemotherapy. "
            "Combination immunotherapy significantly improved overall survival and "
            "progression-free survival. PD-L1 expression was a pre-specified biomarker. "
            "No metabolic or endocrine conditions were studied."
        ),
        "grade": 0,
    },
    {
        "doc_id": "CT-013",
        "title": "Transcatheter Aortic Valve Implantation for Severe Aortic Stenosis",
        "text": (
            "PARTNER 3 compared TAVI with surgical aortic valve replacement in 1,000 low-risk "
            "patients with severe aortic stenosis. TAVI met non-inferiority and superiority "
            "for the composite of death, stroke, or rehospitalisation at one year. Diabetes "
            "was present in 30% of participants but was not an endpoint. No insulin trials."
        ),
        "grade": 0,
    },
    {
        "doc_id": "CT-014",
        "title": "Rivaroxaban for Stroke Prevention in Atrial Fibrillation — ROCKET-AF",
        "text": (
            "ROCKET-AF randomised 14,264 patients with non-valvular atrial fibrillation to "
            "rivaroxaban or warfarin. Rivaroxaban was non-inferior for stroke prevention. "
            "Renal function and drug interactions were key safety concerns. No diabetes-specific "
            "intervention was evaluated. Anticoagulation focus only."
        ),
        "grade": 0,
    },
    {
        "doc_id": "CT-015",
        "title": "Cognitive Behavioural Therapy for Major Depressive Disorder",
        "text": (
            "Randomised trial comparing CBT with antidepressant pharmacotherapy in 240 adults "
            "with moderate-to-severe major depressive disorder. Response rates at 16 weeks "
            "were equivalent between arms. Remission was slightly higher in the pharmacotherapy "
            "arm. No metabolic or endocrine outcomes were assessed."
        ),
        "grade": 0,
    },
    {
        "doc_id": "CT-016",
        "title": "Basal-Bolus Insulin Regimen in Hospitalised Patients with Type 2 Diabetes",
        "text": (
            "Open-label randomised trial comparing basal-bolus insulin (glargine + glulisine) "
            "with sliding-scale insulin in 211 general medicine patients with type 2 diabetes. "
            "Basal-bolus therapy achieved significantly better mean daily glucose and reduced "
            "treatment failure. Hypoglycaemia rates were similar. This trial directly informed "
            "inpatient hyperglycaemia management guidelines for type 2 diabetic patients."
        ),
        "grade": 3,
    },
    {
        "doc_id": "CT-017",
        "title": "Semaglutide Weekly Injection in Type 2 Diabetes — SUSTAIN-6",
        "text": (
            "SUSTAIN-6 randomised 3,297 patients with type 2 diabetes to once-weekly "
            "semaglutide or placebo. Primary outcome was a composite cardiovascular endpoint. "
            "Semaglutide reduced non-fatal stroke significantly. HbA1c and body weight "
            "declined markedly. Insulin use was allowed as background therapy in ~57% of "
            "patients, making this a real-world T2DM population study."
        ),
        "grade": 2,
    },
    {
        "doc_id": "CT-018",
        "title": "Alogliptin DPP-4 Inhibitor for Glycaemic Control in Type 2 Diabetes",
        "text": (
            "52-week randomised placebo-controlled study of alogliptin (a DPP-4 inhibitor) "
            "added to existing therapy in 1,768 patients with inadequately controlled type 2 "
            "diabetes. HbA1c fell by 0.59% versus placebo. No increased hypoglycaemia risk. "
            "Insulin combination sub-study showed additive effect. Renal safety was confirmed."
        ),
        "grade": 2,
    },
    {
        "doc_id": "CT-019",
        "title": "Bone Marrow Transplantation for Acute Myeloid Leukaemia — Phase III",
        "text": (
            "Multicentre phase III trial comparing allogeneic bone marrow transplantation "
            "with consolidation chemotherapy in 508 AML patients in first complete remission. "
            "Transplantation improved disease-free survival at five years. Graft-versus-host "
            "disease was the principal toxicity. No endocrine endpoints were measured."
        ),
        "grade": 0,
    },
    {
        "doc_id": "CT-020",
        "title": "Pioglitazone for Non-Alcoholic Steatohepatitis (NASH) in Type 2 Diabetes",
        "text": (
            "Randomised trial of pioglitazone (a thiazolidinedione) versus vitamin E and "
            "placebo in 247 patients with NASH and type 2 diabetes. Pioglitazone improved "
            "liver histology scores significantly. Insulin sensitivity (HOMA-IR) improved. "
            "Weight gain was common. No exogenous insulin was used in this hepatology trial."
        ),
        "grade": 1,
    },
]

QUERY = "Type 2 diabetes insulin therapy randomised controlled trial"

# Pre-compute a lookup: doc_id → index and index → grade for convenience
DOC_ID_TO_IDX = {doc["doc_id"]: i for i, doc in enumerate(CORPUS)}
GRADES = [doc["grade"] for doc in CORPUS]


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def dcg_at_k(relevance_grades: list[float], k: int) -> float:
    grades = np.array(relevance_grades[:k], dtype=float)
    discounts = np.log2(np.arange(2, len(grades) + 2))
    return float(np.sum(grades / discounts))


def ndcg_at_k(relevance_grades: list[float], k: int) -> float:
    ideal = sorted(relevance_grades, reverse=True)
    idcg = dcg_at_k(ideal, k)
    return 0.0 if idcg == 0 else dcg_at_k(relevance_grades, k) / idcg


def grades_from_ranking(ranked_indices: list[int]) -> list[int]:
    """Return the relevance grade list in the order of the given doc indices."""
    return [GRADES[i] for i in ranked_indices]


def print_ranking_table(label: str, ranked_docs: list[dict], ndcg: float) -> None:
    """Pretty-print a ranked list with grades and nDCG score."""
    grade_labels = {3: "HIGHLY REL", 2: "RELEVANT  ", 1: "MARGINAL  ", 0: "NOT REL   "}
    grade_bars   = {3: "███", 2: "██ ", 1: "█  ", 0: "   "}

    print(f"\n  {'Rank':<5} {'Doc ID':<8} {'Grade':<6} {'Bar':<5} Title")
    print(f"  {'────':<5} {'──────':<8} {'─────':<6} {'───':<5} {'─' * 42}")
    for rank, doc in enumerate(ranked_docs, start=1):
        g = doc["grade"]
        bar = grade_bars[g]
        title = doc["title"][:42]
        print(f"  {rank:<5} {doc['doc_id']:<8} {g:<6} {bar:<5} {title}")
    print(f"\n  nDCG@10 = {ndcg:.4f}  ({label})")


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 1 — TF-IDF RETRIEVAL (first-pass, full corpus)
# ─────────────────────────────────────────────────────────────────────────────

print("=" * 72)
print("CLINICAL TRIAL SEARCH — Reranking Techniques Demo")
print("=" * 72)
print(f'\nQuery: "{QUERY}"\n')

documents_text = [f"{doc['title']} {doc['text']}" for doc in CORPUS]

vectorizer = TfidfVectorizer(sublinear_tf=True, stop_words="english", ngram_range=(1, 2))
tfidf_matrix = vectorizer.fit_transform(documents_text)
query_vec = vectorizer.transform([QUERY])

# Cosine similarity of query against every document; shape → (1, 20)
tfidf_scores = cosine_similarity(query_vec, tfidf_matrix).flatten()

# Rank all 20 documents by TF-IDF score (descending)
tfidf_ranked_indices = np.argsort(tfidf_scores)[::-1].tolist()

# We pass the TOP-15 candidates forward to the rerankers.
# In production you might use top-50 or top-100; 15 is enough for 20 docs.
CANDIDATE_K = 15
candidates_indices = tfidf_ranked_indices[:CANDIDATE_K]
candidates = [CORPUS[i] for i in candidates_indices]
candidates_text = [documents_text[i] for i in candidates_indices]

tfidf_grades = grades_from_ranking(tfidf_ranked_indices[:10])
tfidf_ndcg   = ndcg_at_k(tfidf_grades, 10)

print("─" * 72)
print("APPROACH A — TF-IDF (first-pass retrieval, no reranking)")
print("─" * 72)
print_ranking_table("TF-IDF baseline", [CORPUS[i] for i in tfidf_ranked_indices[:10]], tfidf_ndcg)


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 2A — BI-ENCODER RERANKER
#
# How it works:
#   1. Encode the query once with the bi-encoder → q_vec  (384-dim vector)
#   2. Encode each candidate document independently → d_vec_i
#   3. Score = cosine_similarity(q_vec, d_vec_i) for each candidate
#   4. Re-sort candidates by this semantic similarity score
#
# Why it can beat TF-IDF:
#   TF-IDF requires EXACT keyword overlap.  If a document says "glycaemic
#   control RCT" instead of "randomised controlled trial", TF-IDF misses it.
#   The bi-encoder maps both phrases to nearby points in embedding space,
#   so it captures SEMANTIC equivalence — synonyms, paraphrases, abbreviations.
#
# Trade-off:
#   The query and document are still encoded INDEPENDENTLY.  There is no
#   token-level interaction between them.  The 384-dim vector must compress
#   the entire document meaning before "meeting" the query vector.
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "─" * 72)
print("APPROACH B — Bi-Encoder Reranker (sentence-transformers)")
print("─" * 72)
print("  Loading bi-encoder model: all-MiniLM-L6-v2 ...")

try:
    from sentence_transformers import SentenceTransformer

    bi_encoder = SentenceTransformer("all-MiniLM-L6-v2")

    # Encode query (shape: [384,]) and all candidate documents (shape: [15, 384])
    query_embedding = bi_encoder.encode(QUERY, convert_to_numpy=True)
    doc_embeddings  = bi_encoder.encode(candidates_text, convert_to_numpy=True,
                                        show_progress_bar=False)

    # Cosine similarity: dot product of L2-normalised vectors
    query_norm = query_embedding / (np.linalg.norm(query_embedding) + 1e-10)
    doc_norms  = doc_embeddings  / (np.linalg.norm(doc_embeddings, axis=1, keepdims=True) + 1e-10)
    bi_scores  = doc_norms @ query_norm           # shape: [15,]

    # Sort candidates by bi-encoder score (descending)
    bi_order         = np.argsort(bi_scores)[::-1].tolist()
    bi_ranked_docs   = [candidates[i] for i in bi_order]
    bi_ranked_grades = [doc["grade"] for doc in bi_ranked_docs[:10]]
    bi_ndcg          = ndcg_at_k(bi_ranked_grades, 10)

    print_ranking_table("Bi-Encoder reranker", bi_ranked_docs[:10], bi_ndcg)

    # Store the bi-encoder ranked candidate indices (original corpus positions)
    # for use in RRF later
    bi_candidate_corpus_indices = [candidates_indices[i] for i in bi_order]

except ImportError:
    print("  ✗ sentence-transformers not installed.")
    print("    pip install sentence-transformers")
    bi_ndcg = None
    bi_candidate_corpus_indices = candidates_indices[:]


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 2B — CROSS-ENCODER RERANKER
#
# How it works:
#   1. For each candidate document, concatenate:
#        [CLS] <query tokens> [SEP] <document tokens> [SEP]
#   2. Run this JOINT sequence through the transformer encoder.
#   3. The [CLS] token aggregates full query–document attention across ALL layers.
#   4. A linear head on top of [CLS] produces a single relevance scalar.
#
# Why cross-encoder > bi-encoder:
#   Every query token can directly attend to every document token at every
#   layer.  The model can learn patterns like:
#     • "type 2" in query ↔ "type 2 diabetes" in doc   → high relevance
#     • "insulin therapy" in query ↔ "metformin" in doc → lower relevance
#   A bi-encoder cannot do this — the 384-dim summary vector must capture
#   all relevant signals without seeing the query at encoding time.
#
# Why not use cross-encoder for all 20 docs from the start?
#   Each inference call is ~5–20 ms on CPU.  Over a 1-million-doc corpus
#   that would take hours.  Applied to 15 candidates it takes milliseconds.
#
# Model: cross-encoder/ms-marco-MiniLM-L-6-v2
#   Trained on the MS MARCO passage ranking dataset (~500k query–passage pairs
#   with human relevance labels).  Generalises well to biomedical text.
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "─" * 72)
print("APPROACH C — Cross-Encoder Reranker (sentence-transformers)")
print("─" * 72)
print("  Loading cross-encoder model: ms-marco-MiniLM-L-6-v2 ...")

try:
    from sentence_transformers import CrossEncoder

    cross_encoder = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")

    # Build (query, document) pairs — the cross-encoder reads both together
    query_doc_pairs = [(QUERY, text) for text in candidates_text]

    # predict() returns a relevance score per pair (higher = more relevant)
    ce_scores = cross_encoder.predict(query_doc_pairs, show_progress_bar=False)

    # Sort candidates by cross-encoder score (descending)
    ce_order         = np.argsort(ce_scores)[::-1].tolist()
    ce_ranked_docs   = [candidates[i] for i in ce_order]
    ce_ranked_grades = [doc["grade"] for doc in ce_ranked_docs[:10]]
    ce_ndcg          = ndcg_at_k(ce_ranked_grades, 10)

    print_ranking_table("Cross-Encoder reranker", ce_ranked_docs[:10], ce_ndcg)

    # Annotate candidates with their cross-encoder scores for inspection
    ce_scores_by_docid = {candidates[i]["doc_id"]: float(ce_scores[i])
                          for i in range(len(candidates))}

    print("\n  Cross-encoder raw scores (higher = more relevant to cross-encoder):")
    print(f"  {'Doc ID':<8}  {'CE Score':>9}  {'Grade':<6}  Title")
    print(f"  {'──────':<8}  {'────────':>9}  {'─────':<6}  {'─' * 42}")
    for i in ce_order:
        doc = candidates[i]
        print(f"  {doc['doc_id']:<8}  {ce_scores[i]:>9.3f}  {doc['grade']:<6}  {doc['title'][:42]}")

    ce_candidate_corpus_indices = [candidates_indices[i] for i in ce_order]

except ImportError:
    print("  ✗ sentence-transformers not installed.")
    print("    pip install sentence-transformers")
    ce_ndcg = None
    ce_candidate_corpus_indices = candidates_indices[:]


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 2C — RECIPROCAL RANK FUSION (RRF)
#
# RRF combines the TF-IDF and bi-encoder ranked lists without needing to
# know each system's score scale.  This is useful when the two lists use
# incomparable score ranges (TF-IDF cosine 0–1 vs. bi-encoder cosine 0–1
# — they happen to share a range here, but in general they do not).
#
# Algorithm:
#   For each document d:
#     rrf_score(d) = 1/(k + rank_tfidf(d)) + 1/(k + rank_biencoder(d))
#   where k=60 (the standard constant that dampens the effect of very small
#   ranks and prevents a single top-ranked doc from dominating).
#
#   Documents not in one of the lists get a rank of +infinity (score 0).
#
# We fuse the FULL TF-IDF ranking of all 20 docs with the bi-encoder ranking
# of the top-15 candidates.  The 5 docs not in the candidate set receive
# only the TF-IDF contribution.
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "─" * 72)
print("APPROACH D — Reciprocal Rank Fusion  (TF-IDF  ⊕  Bi-Encoder)")
print("─" * 72)

RRF_K = 60
n_docs = len(CORPUS)

# Build rank lookups: doc_index → 1-based rank position in each list
tfidf_rank_of = {idx: rank + 1 for rank, idx in enumerate(tfidf_ranked_indices)}
bi_rank_of    = {idx: rank + 1 for rank, idx in enumerate(bi_candidate_corpus_indices)}

rrf_scores = []
for idx in range(n_docs):
    score  = 1.0 / (RRF_K + tfidf_rank_of.get(idx, n_docs + 1))
    score += 1.0 / (RRF_K + bi_rank_of.get(idx, n_docs + 1))
    rrf_scores.append((idx, score))

rrf_ranked_indices = [idx for idx, _ in sorted(rrf_scores, key=lambda x: -x[1])]
rrf_grades         = grades_from_ranking(rrf_ranked_indices[:10])
rrf_ndcg           = ndcg_at_k(rrf_grades, 10)

print_ranking_table("RRF (TF-IDF + Bi-Encoder)", [CORPUS[i] for i in rrf_ranked_indices[:10]], rrf_ndcg)


# ─────────────────────────────────────────────────────────────────────────────
# COMPARISON TABLE — all four approaches
# ─────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 72)
print("SUMMARY — nDCG@10 across all approaches")
print("=" * 72)

# Ideal nDCG (reference ceiling)
ideal_ndcg = ndcg_at_k(sorted(GRADES, reverse=True)[:10], 10)

approaches = [
    ("A  TF-IDF (no reranking)", tfidf_ndcg),
    ("B  Bi-Encoder reranker",   bi_ndcg),
    ("C  Cross-Encoder reranker", ce_ndcg),
    ("D  RRF (TF-IDF + Bi-Enc)", rrf_ndcg),
    ("── Ideal (IDCG ceiling) ──", ideal_ndcg),
]

bar_width = 40
print(f"\n  {'Approach':<32}  {'nDCG@10':>7}  {'Bar'}")
print(f"  {'────────':<32}  {'───────':>7}  {'─' * bar_width}")
for name, score in approaches:
    if score is None:
        bar = "(not available)"
        print(f"  {name:<32}  {'  N/A':>7}  {bar}")
    else:
        filled = int(score * bar_width)
        bar = "█" * filled + "░" * (bar_width - filled)
        print(f"  {name:<32}  {score:>7.4f}  {bar}")

print()
print("  Interpretation:")
print("  • nDCG = 1.0 means the system perfectly ranked all relevant docs first")
print("  • Cross-encoder typically achieves the highest nDCG because it reads")
print("    query + document jointly, enabling fine-grained relevance reasoning")
print("  • Bi-encoder beats TF-IDF on paraphrase/synonym queries but can fall")
print("    short on highly specific keyword requirements")
print("  • RRF is score-agnostic and often robust — it hedges against any single")
print("    retriever's blind spots by combining their ranked lists")
print()

# ─────────────────────────────────────────────────────────────────────────────
# DEEPER DIVE — position-by-position grade comparison across approaches
# ─────────────────────────────────────────────────────────────────────────────

print("=" * 72)
print("RANK-BY-RANK GRADE COMPARISON  (top-10 positions)")
print("=" * 72)

# Collect top-10 indices for each approach
top10 = {
    "TF-IDF":        tfidf_ranked_indices[:10],
    "Bi-Enc":        [candidates_indices[i] for i in bi_order[:10]] if bi_ndcg is not None else tfidf_ranked_indices[:10],
    "Cross-Enc":     [candidates_indices[i] for i in ce_order[:10]] if ce_ndcg is not None else tfidf_ranked_indices[:10],
    "RRF":           rrf_ranked_indices[:10],
}

header = f"  {'Rank':<5}" + "".join(f"  {k:<12}" for k in top10)
print(f"\n{header}")
print(f"  {'────':<5}" + "".join(f"  {'──────────':<12}" for _ in top10))

grade_symbols = {3: "3 ███", 2: "2 ██ ", 1: "1 █  ", 0: "0    "}

for rank in range(10):
    row = f"  {rank+1:<5}"
    for indices in top10.values():
        idx = indices[rank]
        g = GRADES[idx]
        row += f"  {CORPUS[idx]['doc_id']} g={g:<5}"
    print(row)

print()
print("  Grade legend: 3=Highly Relevant  2=Relevant  1=Marginal  0=Not Relevant")
print()
