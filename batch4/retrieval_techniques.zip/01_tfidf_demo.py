"""
=============================================================================
INFORMATION RETRIEVAL DEMO 1 — TF-IDF (Term Frequency–Inverse Document Frequency)
=============================================================================

MECHANICS
─────────────────────────────────────────────────────────────────────────────
TF-IDF scores each term in a document by combining two signals:

  TF  (Term Frequency)
      How often a term appears in THIS document, normalized by document length.
      A term appearing 5× in a 100-word doc gets TF = 5/100 = 0.05.
      Intuition: if "metformin" appears many times, the doc is probably about it.

  IDF (Inverse Document Frequency)
      log( N / df(t) )   where N = corpus size, df(t) = # docs containing term t
      Penalizes terms that appear in MANY documents (e.g., "the", "patient").
      Rewards rare, specific terms (e.g., "semaglutide", "HbA1c").
      Intuition: "patient" in every doc → low IDF; "semaglutide" in 2 docs → high IDF.

  TF-IDF(t, d) = TF(t, d) × IDF(t)

RETRIEVAL
  1. Build a VOCABULARY of all unique terms in the corpus.
  2. Represent each document as a sparse vector (one dimension per vocab term).
  3. At query time, vectorize the query the same way.
  4. Score documents by cosine similarity between query vector and doc vector.

SKLEARN VARIANT
  sklearn's TfidfVectorizer uses sublinear TF (1 + log(tf)) and L2-normalizes
  the final vectors, which prevents long documents from dominating.

─────────────────────────────────────────────────────────────────────────────
TRADEOFFS IN HEALTHCARE IR
─────────────────────────────────────────────────────────────────────────────

  STRENGTHS
  • Exact term matching — critical for drug names, ICD codes, lab values.
    "metformin 500mg" WILL be found; a dense model might return "oral hypoglycemic"
    instead, missing the exact formulation.
  • Transparent & auditable — clinicians can see WHY a document ranked highly.
    Required in many regulatory/compliance contexts (FDA, HIPAA).
  • No GPU required — runs on a laptop; fast to index thousands of clinical notes.
  • Zero training data needed — works out of the box on any medical corpus.

  WEAKNESSES
  • Vocabulary mismatch — query "heart attack" ≠ document "myocardial infarction".
    TF-IDF sees these as completely different terms; dense models capture synonymy.
  • No semantic understanding — "drug did NOT cause liver damage" scores the same
    for "liver damage" as "drug caused liver damage".
  • Brittle with acronyms — "MI" could mean Myocardial Infarction or Michigan.
  • Long documents penalized unless normalized carefully.

  TYPICAL HEALTHCARE USE CASES
  • EHR keyword search (doctor searching their own notes)
  • Drug/procedure code lookup (ICD-10, CPT codes are exact strings)
  • First-pass retrieval in a two-stage pipeline (cheap + fast)
  • Regulatory document retrieval where exact terminology is mandated

─────────────────────────────────────────────────────────────────────────────
THIS DEMO
─────────────────────────────────────────────────────────────────────────────
  Synthetic corpus: 30 clinical document snippets (discharge summaries,
  lab reports, drug monographs) covering diabetes, cardiology, oncology.
  We run 5 queries and show top-5 results with TF-IDF scores.
  We also visualize the TF-IDF weight matrix as a heatmap.

  Run:  python 01_tfidf_demo.py
  Deps: pip install scikit-learn matplotlib seaborn
=============================================================================
"""

import math
import textwrap

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ─────────────────────────────────────────────────────────────────────────────
# SYNTHETIC CORPUS — 30 clinical document snippets
# ─────────────────────────────────────────────────────────────────────────────
DOCUMENTS = [
    # Diabetes / endocrinology
    {
        "id": "D001",
        "title": "Metformin Therapy in Type 2 Diabetes",
        "text": (
            "Metformin is the first-line pharmacological treatment for type 2 diabetes mellitus. "
            "It reduces hepatic glucose production and improves insulin sensitivity. "
            "Patients on metformin typically achieve HbA1c reduction of 1-2%. "
            "Common side effects include GI upset; lactic acidosis is rare but serious. "
            "Renal function (eGFR) must be monitored before initiation."
        ),
    },
    {
        "id": "D002",
        "title": "Semaglutide for Glycemic Control",
        "text": (
            "Semaglutide, a GLP-1 receptor agonist, is approved for type 2 diabetes and obesity. "
            "Weekly subcutaneous injection reduces HbA1c by up to 1.8% and body weight by 6-8 kg. "
            "Cardiovascular outcome trials show significant reduction in MACE events. "
            "Contraindicated in personal or family history of medullary thyroid carcinoma."
        ),
    },
    {
        "id": "D003",
        "title": "Insulin Initiation for Uncontrolled Diabetes",
        "text": (
            "When oral agents fail to achieve glycemic targets, insulin therapy is initiated. "
            "Basal insulin (glargine or detemir) is preferred for type 2 diabetes. "
            "Starting dose: 10 units/day or 0.1-0.2 units/kg/day, titrated to fasting glucose. "
            "Hypoglycemia is the primary risk; patients require education on self-monitoring."
        ),
    },
    {
        "id": "D004",
        "title": "Diabetic Ketoacidosis Management Protocol",
        "text": (
            "DKA is a life-threatening complication of diabetes characterized by hyperglycemia, "
            "ketosis, and metabolic acidosis. IV fluid resuscitation with normal saline is first-line. "
            "Insulin infusion should begin after potassium replacement if K+ < 3.5 mEq/L. "
            "Bicarbonate therapy is reserved for severe acidosis (pH < 6.9). "
            "Monitor glucose, electrolytes, and anion gap every 1-2 hours."
        ),
    },
    {
        "id": "D005",
        "title": "Continuous Glucose Monitoring in Diabetes",
        "text": (
            "CGM devices measure interstitial glucose every 5 minutes and display trends. "
            "Time-in-range (70-180 mg/dL) is the primary CGM metric correlated with HbA1c. "
            "Real-time alerts for hypoglycemia improve patient safety vs fingerstick alone. "
            "Sensor accuracy (MARD < 10%) is critical for insulin dosing decisions."
        ),
    },
    # Cardiology
    {
        "id": "C001",
        "title": "Acute Myocardial Infarction — STEMI Protocol",
        "text": (
            "STEMI management requires primary PCI within 90 minutes of first medical contact. "
            "Dual antiplatelet therapy: aspirin 325 mg plus ticagrelor 180 mg loading dose. "
            "Anticoagulation with unfractionated heparin during PCI. "
            "Post-PCI: statin therapy, beta-blocker, ACE inhibitor initiated before discharge. "
            "Ejection fraction measured by echocardiogram guides further management."
        ),
    },
    {
        "id": "C002",
        "title": "Heart Failure with Reduced Ejection Fraction",
        "text": (
            "HFrEF (EF < 40%) guideline-directed therapy includes four pillars: "
            "ACE inhibitor/ARB/ARNI, beta-blocker, MRA (spironolactone), and SGLT2 inhibitor. "
            "Dapagliflozin reduces hospitalization and cardiovascular death in HFrEF. "
            "Loop diuretics (furosemide) manage volume overload but do not improve survival. "
            "ICD implantation indicated if EF remains < 35% after 3 months of GDMT."
        ),
    },
    {
        "id": "C003",
        "title": "Atrial Fibrillation Anticoagulation Guidelines",
        "text": (
            "AF increases stroke risk 5-fold. CHA2DS2-VASc score guides anticoagulation decisions. "
            "DOACs (apixaban, rivaroxaban, dabigatran) preferred over warfarin in non-valvular AF. "
            "Apixaban 5 mg BID: superior stroke reduction with less bleeding than warfarin. "
            "Rate control target: resting HR < 80 bpm using beta-blocker or calcium channel blocker. "
            "Rhythm control with cardioversion or ablation for symptomatic AF."
        ),
    },
    {
        "id": "C004",
        "title": "Hypertension Management in Chronic Kidney Disease",
        "text": (
            "Target BP in CKD is < 130/80 mmHg per ACC/AHA guidelines. "
            "ACE inhibitors or ARBs are first-line in CKD with proteinuria due to renoprotective effect. "
            "Avoid NSAIDs; monitor potassium and creatinine after initiating RAAS blockade. "
            "Thiazide diuretics effective if eGFR > 30; loop diuretics preferred if eGFR < 30. "
            "Resistant hypertension: add spironolactone or refer to nephrology."
        ),
    },
    {
        "id": "C005",
        "title": "Cardiac Biomarkers in Chest Pain Evaluation",
        "text": (
            "High-sensitivity troponin I or T is the gold standard for myocardial injury detection. "
            "Serial troponin at 0h and 3h (or 0h/1h with high-sensitivity assay) rules out NSTEMI. "
            "BNP > 100 pg/mL or NT-proBNP > 300 pg/mL supports heart failure diagnosis. "
            "D-dimer used to exclude pulmonary embolism in low-to-intermediate pretest probability. "
            "CK-MB less sensitive than troponin; still used for reinfarction detection."
        ),
    },
    # Oncology
    {
        "id": "O001",
        "title": "Non-Small Cell Lung Cancer — Targeted Therapy",
        "text": (
            "EGFR mutation testing is mandatory before first-line therapy in NSCLC. "
            "Osimertinib (3rd-gen EGFR TKI) is first-line for EGFR exon 19/21 mutations. "
            "ALK rearrangement: alectinib preferred over crizotinib (better CNS penetration). "
            "PD-L1 expression guides immunotherapy (pembrolizumab) use in wild-type NSCLC. "
            "KRAS G12C inhibitor sotorasib approved for previously treated KRAS-mutant NSCLC."
        ),
    },
    {
        "id": "O002",
        "title": "Breast Cancer Hormone Receptor Positive Treatment",
        "text": (
            "HR+/HER2- breast cancer: CDK4/6 inhibitors (palbociclib, ribociclib) plus endocrine therapy. "
            "Aromatase inhibitors (letrozole, anastrozole) preferred in postmenopausal patients. "
            "Tamoxifen for premenopausal women; 10 years of therapy reduces recurrence risk. "
            "PIK3CA mutation: add alpelisib (PI3K inhibitor) after endocrine therapy progression. "
            "Bone-modifying agents reduce skeletal events in metastatic disease."
        ),
    },
    {
        "id": "O003",
        "title": "Colorectal Cancer Screening Protocols",
        "text": (
            "Average-risk adults: colonoscopy every 10 years starting at age 45 (ACS guideline). "
            "Stool-based tests: FIT annually or Cologuard every 3 years as alternatives. "
            "High-risk (Lynch syndrome, FAP): colonoscopy starting at 20-25 years old. "
            "CEA is a tumor marker used for monitoring CRC recurrence, not screening. "
            "Positive non-invasive test requires follow-up colonoscopy within 3-6 months."
        ),
    },
    {
        "id": "O004",
        "title": "Chemotherapy-Induced Neutropenia Management",
        "text": (
            "Febrile neutropenia (ANC < 500, fever > 38.3°C) requires immediate broad-spectrum antibiotics. "
            "Empiric therapy: piperacillin-tazobactam or cefepime; add vancomycin for MRSA risk. "
            "G-CSF (filgrastim) primary prophylaxis for regimens with > 20% FN risk. "
            "MASCC score < 21 identifies high-risk patients requiring hospitalization. "
            "Blood cultures x2 and chest X-ray before antibiotics if possible but do not delay treatment."
        ),
    },
    {
        "id": "O005",
        "title": "CAR-T Cell Therapy for Hematologic Malignancies",
        "text": (
            "Chimeric antigen receptor T-cell therapy targets CD19 for B-cell lymphomas and leukemias. "
            "Axicabtagene ciloleucel and tisagenlecleucel approved for relapsed/refractory DLBCL. "
            "Cytokine release syndrome (CRS) graded 1-4; tocilizumab (IL-6 receptor blockade) for grade 2+. "
            "Immune effector cell-associated neurotoxicity (ICANS) requires dexamethasone. "
            "T-cell manufacturing takes 3-4 weeks; bridging therapy may be needed."
        ),
    },
    # Infectious Disease
    {
        "id": "I001",
        "title": "Sepsis and Septic Shock Management",
        "text": (
            "Sepsis-3 definition: life-threatening organ dysfunction from infection. SOFA score >= 2. "
            "Septic shock: sepsis plus vasopressor requirement and lactate > 2 mmol/L. "
            "Hour-1 bundle: blood cultures, broad-spectrum antibiotics, 30 mL/kg IV crystalloid. "
            "Norepinephrine first-line vasopressor; add vasopressin if MAP < 65 despite NE. "
            "Procalcitonin-guided antibiotic de-escalation reduces duration without harm."
        ),
    },
    {
        "id": "I002",
        "title": "COVID-19 Antiviral Treatment Options",
        "text": (
            "Nirmatrelvir-ritonavir (Paxlovid) reduces hospitalization by 89% in high-risk patients. "
            "Must be initiated within 5 days of symptom onset; 5-day oral course. "
            "Drug interactions with ritonavir are extensive; check all concurrent medications. "
            "Remdesivir IV: approved for hospitalized patients requiring supplemental oxygen. "
            "Dexamethasone 6 mg/day for patients requiring oxygen; harmful if no oxygen needed."
        ),
    },
    {
        "id": "I003",
        "title": "Antibiotic Stewardship in Hospital Settings",
        "text": (
            "Antibiotic stewardship programs (ASP) reduce C. difficile, resistance, and costs. "
            "Prospective audit and feedback: ID physician reviews all broad-spectrum antibiotic orders. "
            "Formulary restriction: carbapenems require pre-authorization. "
            "IV-to-oral switch: amoxicillin, ciprofloxacin, azithromycin achieve similar serum levels. "
            "Culture results should trigger de-escalation to narrowest effective agent within 48-72h."
        ),
    },
    # Neurology
    {
        "id": "N001",
        "title": "Ischemic Stroke Thrombolysis Protocol",
        "text": (
            "IV alteplase (tPA) within 4.5 hours of stroke symptom onset in eligible patients. "
            "Contraindications: recent surgery, active bleeding, BP > 185/110 uncontrolled. "
            "Mechanical thrombectomy for large vessel occlusion up to 24 hours if penumbra viable. "
            "NIHSS score documents deficit severity; target BP < 180/105 post-tPA. "
            "Dual antiplatelet therapy (aspirin + clopidogrel) for minor stroke/TIA for 21 days."
        ),
    },
    {
        "id": "N002",
        "title": "Epilepsy and Antiseizure Medication Management",
        "text": (
            "First unprovoked seizure: treat if EEG abnormal, brain lesion, or nocturnal onset. "
            "Focal epilepsy: lamotrigine or levetiracetam first-line; lacosamide alternative. "
            "Generalized epilepsy: valproate most effective but teratogenic; avoid in women of childbearing age. "
            "Status epilepticus: lorazepam 0.1 mg/kg IV, then levetiracetam 60 mg/kg IV. "
            "Therapeutic drug monitoring required for phenytoin, valproate, carbamazepine."
        ),
    },
    # Nephrology
    {
        "id": "K001",
        "title": "Acute Kidney Injury Risk Stratification",
        "text": (
            "AKI defined by KDIGO: creatinine rise >= 0.3 mg/dL in 48h or >= 1.5× baseline in 7 days. "
            "Three stages: Stage 1 (1.5-1.9× baseline), Stage 2 (2-2.9×), Stage 3 (>= 3× or dialysis). "
            "Most common causes in hospital: prerenal (volume depletion, sepsis), nephrotoxins (contrast, NSAIDs). "
            "Urinary biomarkers NGAL and KIM-1 detect AKI before creatinine rise. "
            "Renal replacement therapy indicated for refractory acidosis, hyperkalemia, or volume overload."
        ),
    },
    # Pulmonology
    {
        "id": "P001",
        "title": "COPD Exacerbation Management",
        "text": (
            "AECOPD triggered by infection, pollution, or cold air. "
            "SABA (albuterol) plus SAMA (ipratropium) nebulization every 4-6 hours. "
            "Systemic corticosteroids (prednisone 40 mg x 5 days) reduce treatment failure. "
            "Antibiotics if 2 of 3 Anthonisen criteria: increased dyspnea, sputum volume, sputum purulence. "
            "Non-invasive ventilation (CPAP/BiPAP) for pH < 7.35 and PaCO2 > 45 mmHg."
        ),
    },
    # Pharmacology
    {
        "id": "PH001",
        "title": "Drug-Drug Interaction: Warfarin and Antibiotics",
        "text": (
            "Many antibiotics potentiate warfarin by killing gut flora that produce vitamin K. "
            "Fluconazole and metronidazole inhibit CYP2C9, dramatically increasing INR. "
            "Rifampin induces CYP2C9/3A4, reducing warfarin effect — dose increase needed. "
            "Check INR within 3-5 days of starting or stopping any antibiotic in warfarin patients. "
            "Azithromycin, amoxicillin: moderate interaction; still requires INR monitoring."
        ),
    },
    {
        "id": "PH002",
        "title": "Opioid Prescribing and Pain Management",
        "text": (
            "WHO analgesic ladder: non-opioid first, then weak opioid (tramadol), then strong opioid. "
            "Morphine equivalent dose (MED) > 90 mg/day associated with increased overdose risk. "
            "Always co-prescribe naloxone rescue inhaler for patients on > 50 MED or with risk factors. "
            "Urine drug screening and prescription monitoring programs (PDMP) before prescribing. "
            "Abuse-deterrent formulations (extended-release oxycodone with naltrexone) for chronic pain."
        ),
    },
    # Hematology
    {
        "id": "H001",
        "title": "Venous Thromboembolism Treatment",
        "text": (
            "DVT and PE: anticoagulate for minimum 3 months. DOACs first-line over LMWH/warfarin. "
            "Rivaroxaban 15 mg BID x 21 days, then 20 mg daily. Apixaban 10 mg BID x 7 days, then 5 mg BID. "
            "Cancer-associated thrombosis: LMWH or rivaroxaban preferred over warfarin. "
            "Massive PE with hemodynamic instability: systemic thrombolysis (alteplase 100 mg IV x 2h). "
            "IVC filter only if anticoagulation is absolutely contraindicated."
        ),
    },
    # Gastroenterology
    {
        "id": "G001",
        "title": "H. pylori Eradication Therapy",
        "text": (
            "First-line: clarithromycin triple therapy (PPI + clarithromycin + amoxicillin x 14 days). "
            "Clarithromycin resistance > 15% in region: use bismuth quadruple or concomitant therapy. "
            "Confirm eradication with urea breath test or stool antigen >= 4 weeks post-treatment. "
            "H. pylori eradication reduces peptic ulcer recurrence from 80% to < 5% at 1 year. "
            "Test-and-treat strategy recommended for uninvestigated dyspepsia in low-risk patients."
        ),
    },
    # Radiology / Diagnostics
    {
        "id": "R001",
        "title": "CT Pulmonary Angiography for PE Diagnosis",
        "text": (
            "CTPA is the gold standard imaging for pulmonary embolism with sensitivity > 95%. "
            "Wells score stratifies pretest probability; D-dimer < 500 ng/mL rules out PE in low-risk. "
            "Contrast nephropathy risk: hold metformin 48h post-contrast if eGFR < 60. "
            "V/Q scan preferred in pregnancy or severe renal impairment to minimize radiation/contrast. "
            "Incidental pulmonary nodules on CTPA require Fleischner Society follow-up guidelines."
        ),
    },
    # Pediatrics
    {
        "id": "PED001",
        "title": "Pediatric Asthma Stepwise Management",
        "text": (
            "Step 1: SABA PRN for intermittent asthma. Step 2: low-dose ICS daily. "
            "Step 3: low-dose ICS + LABA or medium-dose ICS. Step 4: medium-dose ICS + LABA. "
            "Biologic therapy (dupilumab, mepolizumab) for severe uncontrolled asthma >= step 5. "
            "Assess asthma control at every visit; spirometry with bronchodilator reversibility. "
            "Spacer device required for MDI use in children under 5; avoid nebulizer if MDI available."
        ),
    },
    # Mental Health
    {
        "id": "MH001",
        "title": "Depression Pharmacotherapy Selection",
        "text": (
            "SSRIs (sertraline, escitalopram) first-line for major depressive disorder. "
            "Response expected at 4-8 weeks; full trial requires 6-8 weeks at therapeutic dose. "
            "Switch or augment (add bupropion or lithium) after two failed SSRI trials. "
            "SNRIs (venlafaxine, duloxetine) preferred for comorbid pain or anxiety. "
            "MAOIs: reserved for refractory depression; strict tyramine diet and drug interaction vigilance."
        ),
    },
    # Surgery
    {
        "id": "S001",
        "title": "Perioperative Anticoagulation Bridging",
        "text": (
            "Bridging anticoagulation: replace warfarin with LMWH/UFH around surgery. "
            "High-risk AF (CHADS2 >= 5, recent stroke): bridging recommended. "
            "Low-risk (CHADS2 <= 2, no recent stroke): bridging not needed — may increase bleeding. "
            "Stop warfarin 5 days pre-op; start LMWH 3 days pre-op; stop LMWH 24h pre-op. "
            "DOAC patients: no bridging needed — simply hold drug 24-48h (or 48-72h for high bleed procedures)."
        ),
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# DEMO QUERIES
# ─────────────────────────────────────────────────────────────────────────────
QUERIES = [
    {
        "id": "Q1",
        "text": "HbA1c reduction with metformin in type 2 diabetes",
        "note": "Exact term match — TF-IDF should excel here",
    },
    {
        "id": "Q2",
        "text": "heart attack treatment aspirin antiplatelet",
        "note": "Partial synonym: 'heart attack' vs 'myocardial infarction' / 'STEMI'",
    },
    {
        "id": "Q3",
        "text": "antibiotic selection febrile neutropenia cancer patient",
        "note": "Multi-concept: oncology + infectious disease",
    },
    {
        "id": "Q4",
        "text": "stroke thrombolysis tPA eligibility window",
        "note": "Clinical procedure lookup — specific terminology",
    },
    {
        "id": "Q5",
        "text": "blood clot prevention anticoagulation",
        "note": "Generic lay language — may miss 'thromboembolism', 'VTE' jargon",
    },
]


def build_and_search(docs, queries, top_k=5):
    """Build TF-IDF index and retrieve top-k docs per query."""
    corpus = [d["text"] for d in docs]
    doc_meta = {i: d for i, d in enumerate(docs)}

    # Build TF-IDF matrix (docs × vocab)
    vectorizer = TfidfVectorizer(
        ngram_range=(1, 2),      # unigrams + bigrams capture "blood pressure", "HbA1c"
        sublinear_tf=True,       # use 1+log(tf) to dampen high-freq terms
        min_df=1,                # include all terms (small corpus)
        max_df=0.95,             # drop terms in > 95% of docs (near-stopwords)
        stop_words="english",
    )
    tfidf_matrix = vectorizer.fit_transform(corpus)  # shape: (n_docs, n_vocab)

    results = []
    for q in queries:
        q_vec = vectorizer.transform([q["text"]])
        scores = cosine_similarity(q_vec, tfidf_matrix).flatten()
        ranked_indices = np.argsort(scores)[::-1][:top_k]
        hits = [
            {
                "rank": rank + 1,
                "doc_id": doc_meta[idx]["id"],
                "title": doc_meta[idx]["title"],
                "score": scores[idx],
                "snippet": doc_meta[idx]["text"][:100] + "...",
            }
            for rank, idx in enumerate(ranked_indices)
        ]
        results.append({"query": q, "hits": hits})

    return vectorizer, tfidf_matrix, results


def visualize_tfidf_heatmap(vectorizer, tfidf_matrix, docs, top_n_terms=20):
    """Plot heatmap of TF-IDF weights for a subset of docs and top terms."""
    feature_names = vectorizer.get_feature_names_out()

    # Pick docs with highest average TF-IDF (most informative)
    subset_doc_indices = np.argsort(tfidf_matrix.mean(axis=1).A.flatten())[-12:]
    subset_matrix = tfidf_matrix[subset_doc_indices].toarray()

    # Find top-N terms by total weight across subset
    term_totals = subset_matrix.sum(axis=0)
    top_term_indices = np.argsort(term_totals)[-top_n_terms:]
    subset_matrix = subset_matrix[:, top_term_indices]
    top_terms = feature_names[top_term_indices]
    subset_doc_titles = [docs[i]["title"][:30] for i in subset_doc_indices]

    fig, ax = plt.subplots(figsize=(14, 7))
    sns.heatmap(
        subset_matrix,
        xticklabels=top_terms,
        yticklabels=subset_doc_titles,
        cmap="YlOrRd",
        ax=ax,
        annot=False,
        linewidths=0.3,
    )
    ax.set_title(
        "TF-IDF Weight Heatmap\n"
        "(12 most informative clinical docs × top 20 discriminating terms)",
        fontsize=13,
        pad=12,
    )
    ax.set_xlabel("Terms (unigrams + bigrams)", fontsize=11)
    ax.set_ylabel("Clinical Documents", fontsize=11)
    plt.xticks(rotation=45, ha="right", fontsize=9)
    plt.yticks(fontsize=9)
    plt.tight_layout()
    plt.savefig("tfidf_heatmap.png", dpi=150)
    print("  [saved] tfidf_heatmap.png")
    plt.show()


def print_results(results):
    sep = "─" * 72
    for r in results:
        q = r["query"]
        print(f"\n{sep}")
        print(f"QUERY [{q['id']}]: {q['text']}")
        print(f"NOTE : {q['note']}")
        print(sep)
        for hit in r["hits"]:
            print(f"  #{hit['rank']:1d}  [{hit['doc_id']}]  score={hit['score']:.4f}")
            print(f"       {hit['title']}")
            print(f"       {hit['snippet']}")
        print()


def show_idf_analysis(vectorizer):
    """Show which terms have highest/lowest IDF — clinical insight."""
    feature_names = vectorizer.get_feature_names_out()
    idf_values = vectorizer.idf_
    sorted_idx = np.argsort(idf_values)

    print("\n" + "=" * 72)
    print("IDF ANALYSIS — What does TF-IDF consider rare vs. common?")
    print("=" * 72)
    print("\nLowest IDF (most common terms — low discriminative power):")
    for idx in sorted_idx[:10]:
        print(f"  IDF={idf_values[idx]:.3f}  '{feature_names[idx]}'")
    print("\nHighest IDF (rarest terms — most discriminative for retrieval):")
    for idx in sorted_idx[-10:]:
        print(f"  IDF={idf_values[idx]:.3f}  '{feature_names[idx]}'")


def main():
    print("=" * 72)
    print("DEMO 1 — TF-IDF Information Retrieval in Healthcare")
    print(f"Corpus: {len(DOCUMENTS)} clinical document snippets")
    print(f"Queries: {len(QUERIES)}")
    print("=" * 72)

    vectorizer, tfidf_matrix, results = build_and_search(DOCUMENTS, QUERIES, top_k=5)

    print(f"\nVocabulary size: {len(vectorizer.vocabulary_):,} terms")
    print(f"TF-IDF matrix shape: {tfidf_matrix.shape}  (docs × vocab_terms)")
    print(f"Matrix sparsity: {100 * (1 - tfidf_matrix.nnz / (tfidf_matrix.shape[0] * tfidf_matrix.shape[1])):.1f}%")

    print_results(results)
    show_idf_analysis(vectorizer)

    print("\n[Building TF-IDF heatmap visualization ...]")
    visualize_tfidf_heatmap(vectorizer, tfidf_matrix, DOCUMENTS)

    print("\nKEY TAKEAWAYS")
    print("─" * 72)
    print("1. Exact medical terms (HbA1c, metformin) match perfectly.")
    print("2. Lay synonym 'heart attack' ranks STEMI doc lower → vocabulary gap.")
    print("3. IDF naturally upweights rare clinical terms over generic words.")
    print("4. Bigrams (e.g. 'type 2', 'blood pressure') improve precision.")
    print("5. No GPU or training data required — deploy anywhere in minutes.")


if __name__ == "__main__":
    main()
