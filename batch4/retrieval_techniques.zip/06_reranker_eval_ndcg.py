"""
=============================================================================
CLINICAL TRIAL SEARCH SYSTEM — TF-IDF Retrieval + nDCG Evaluation
=============================================================================

WHAT THIS DEMO COVERS
----------------------
  1. A synthetic corpus of 20 clinical trial abstracts spanning several
     therapeutic areas (diabetes, oncology, cardiology, neurology, etc.)

  2. A TF-IDF (Term Frequency–Inverse Document Frequency) search engine
     that ranks all documents against a user query and returns the top-10.

  3. Full nDCG evaluation — the gold-standard metric for ranked retrieval —
     that measures whether the MOST RELEVANT documents appear at the TOP.

─────────────────────────────────────────────────────────────────────────────
BACKGROUND: WHY RANKING QUALITY MATTERS
─────────────────────────────────────────────────────────────────────────────
In information retrieval (IR) a search engine doesn't just find relevant
documents — it must ORDER them. Returning 10 relevant documents is useless
if the best one appears last. Clinicians, researchers, and patients stop
reading after the first few results, so position matters enormously.

─────────────────────────────────────────────────────────────────────────────
TF-IDF (the retrieval model)
─────────────────────────────────────────────────────────────────────────────
  TF-IDF scores how "characteristic" a term is for a document relative to
  the entire corpus:

    TF(t, d)  = count of term t in document d
                ─────────────────────────────  (normalised by doc length)
                total terms in document d

    IDF(t)    = log( N / df(t) )
                where N  = total number of documents
                      df = number of documents containing term t

    TF-IDF(t, d) = TF(t,d) × IDF(t)

  Each document becomes a sparse vector of TF-IDF weights.
  A query is also converted to a TF-IDF vector.
  Documents are ranked by COSINE SIMILARITY between query and doc vectors.

─────────────────────────────────────────────────────────────────────────────
RELEVANCE GRADES (ground truth, assigned by a human expert / oracle)
─────────────────────────────────────────────────────────────────────────────
  For evaluation we need a "ground truth" relevance judgment for every
  (query, document) pair. In real life these come from annotators; here
  they are synthetically assigned:

    Grade 3  → Highly relevant   — directly addresses the query condition,
                                   intervention, and population
    Grade 2  → Relevant          — related condition or intervention
    Grade 1  → Marginally relevant — tangentially related
    Grade 0  → Not relevant      — different therapeutic area entirely

─────────────────────────────────────────────────────────────────────────────
DCG — Discounted Cumulative Gain
─────────────────────────────────────────────────────────────────────────────
  DCG rewards finding highly relevant documents AND placing them early.
  The "discount" penalises relevance that appears at lower ranks.

  Formula (position i starts at 1):

              k    rel_i
    DCG@k  = Σ  ─────────
             i=1  log₂(i+1)

  • rel_i  = relevance grade of the document at rank position i
  • The denominator log₂(i+1) grows with rank, so position-1 contributes
    full relevance, position-2 discounts by log₂(3) ≈ 1.58, etc.
  • Summing k=10 terms gives DCG@10.

  Example (grades at ranks 1..5): [3, 2, 3, 0, 1]
    DCG = 3/log₂(2) + 2/log₂(3) + 3/log₂(4) + 0/log₂(5) + 1/log₂(6)
        = 3/1      + 2/1.585  + 3/2      + 0       + 1/2.585
        = 3.0      + 1.262    + 1.5      + 0        + 0.387
        = 6.149

─────────────────────────────────────────────────────────────────────────────
IDCG — Ideal DCG (the best possible DCG)
─────────────────────────────────────────────────────────────────────────────
  IDCG@k is computed by sorting ALL available relevance grades in descending
  order (highest grade first) and then computing DCG on that ideal list.
  This is the maximum achievable DCG for the given set of judgments.

─────────────────────────────────────────────────────────────────────────────
nDCG — Normalized DCG (the final metric)
─────────────────────────────────────────────────────────────────────────────
  nDCG normalises DCG by IDCG so the score is always in [0, 1]:

              DCG@k
    nDCG@k = ───────
              IDCG@k

  • nDCG = 1.0  → perfect ranking (best documents are all at the top)
  • nDCG = 0.0  → worst possible ranking (no relevant doc retrieved)
  • Values in 0.6–0.8 are considered good for real search engines

  nDCG is corpus-independent and comparable across different queries and
  systems — that is why it is the standard metric for TREC, MS MARCO,
  BioASQ, and other IR benchmarks.

─────────────────────────────────────────────────────────────────────────────
WHAT THE DEMO SHOWS
─────────────────────────────────────────────────────────────────────────────
  Query: "Type 2 diabetes insulin therapy randomised controlled trial"

  We compute nDCG@10 for THREE rankings:

    A) TF-IDF ranking   — what the search engine actually returns
    B) Ideal ranking    — IDCG: every relevant doc at the top in grade order
    C) Worst ranking    — relevant docs deliberately placed at the bottom

  Comparing the three rankings makes it viscerally clear that nDCG is NOT
  just about retrieving relevant documents — it rewards the system that puts
  the BEST documents FIRST.

=============================================================================
"""

import sys
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Reconfigure stdout to UTF-8 so Unicode box-drawing and block chars render
# correctly on Windows terminals (avoids cp1252 codec errors).
sys.stdout.reconfigure(encoding="utf-8")

# ─────────────────────────────────────────────────────────────────────────────
# SYNTHETIC CORPUS — 20 Clinical Trial Abstracts
#
# Each document is a condensed abstract typical of ClinicalTrials.gov or
# PubMed. The corpus deliberately mixes several therapeutic areas so the
# retrieval task is non-trivial.
#
# Structure per document:
#   "doc_id" : short identifier used in output tables
#   "title"  : concise trial title
#   "text"   : abstract text used for indexing and retrieval
#   "grade"  : oracle relevance grade for the diabetes-insulin query (0–3)
# ─────────────────────────────────────────────────────────────────────────────

CORPUS = [
    {
        "doc_id": "CT-001",
        "title": "Insulin Glargine vs. NPH in Type 2 Diabetes — RCT",
        "text": (
            "A randomised controlled trial comparing insulin glargine with NPH insulin "
            "in 480 patients with type 2 diabetes mellitus. Primary endpoint was HbA1c "
            "reduction at 24 weeks. Insulin glargine achieved superior glycaemic control "
            "with fewer nocturnal hypoglycaemia events. Secondary endpoints included "
            "fasting plasma glucose and patient-reported quality of life. Basal insulin "
            "therapy was well tolerated across all subgroups."
        ),
        "grade": 3,   # HIGHLY RELEVANT — exact match: T2DM, insulin, RCT
    },
    {
        "doc_id": "CT-002",
        "title": "Metformin as First-Line Therapy in Newly Diagnosed Type 2 Diabetes",
        "text": (
            "Prospective cohort study evaluating metformin monotherapy in 620 adults with "
            "newly diagnosed type 2 diabetes. Patients were followed for 12 months. "
            "Metformin reduced HbA1c by 1.5% on average. Gastrointestinal side effects "
            "were the most common reason for discontinuation. No insulin therapy was used. "
            "Lifestyle modification counselling was provided to all participants."
        ),
        "grade": 2,   # RELEVANT — T2DM focus, but no insulin
    },
    {
        "doc_id": "CT-003",
        "title": "Empagliflozin Cardiovascular Outcomes in Type 2 Diabetes",
        "text": (
            "The EMPA-REG OUTCOME trial randomised 7,020 patients with type 2 diabetes and "
            "high cardiovascular risk to empagliflozin or placebo. The primary composite "
            "outcome was death from cardiovascular causes, non-fatal myocardial infarction, "
            "or non-fatal stroke. Empagliflozin significantly reduced cardiovascular "
            "mortality. Secondary outcomes included hospitalisation for heart failure and "
            "renal function markers. Insulin use was permitted as background therapy."
        ),
        "grade": 2,   # RELEVANT — T2DM RCT, insulin mentioned as background
    },
    {
        "doc_id": "CT-004",
        "title": "Intensive Insulin Therapy in Critically Ill Patients (ICU Trial)",
        "text": (
            "Randomised trial of intensive insulin therapy targeting blood glucose 4.4–6.1 "
            "mmol/L versus conventional treatment in 1,548 ICU patients. Intensive insulin "
            "therapy reduced in-hospital mortality by 34%. Severe hypoglycaemia was more "
            "frequent in the intensive group. This landmark trial established tight glycaemic "
            "control protocols in critical care settings worldwide."
        ),
        "grade": 2,   # RELEVANT — insulin RCT but in ICU, not specifically T2DM
    },
    {
        "doc_id": "CT-005",
        "title": "Liraglutide Once-Daily vs. Placebo in Type 2 Diabetes (LEAD-3)",
        "text": (
            "LEAD-3 was a 52-week randomised double-blind trial comparing liraglutide "
            "monotherapy with glimepiride in patients with early type 2 diabetes. Liraglutide "
            "produced greater HbA1c reductions and significant weight loss. Nausea was the "
            "most common adverse event. No insulin was used. This GLP-1 receptor agonist "
            "trial informed first-line treatment guidelines."
        ),
        "grade": 2,   # RELEVANT — T2DM RCT; GLP-1, not insulin
    },
    {
        "doc_id": "CT-006",
        "title": "Hybrid Closed-Loop Insulin Delivery in Type 1 Diabetes",
        "text": (
            "Six-month randomised crossover trial of a hybrid closed-loop insulin delivery "
            "system versus sensor-augmented pump therapy in 86 adults with type 1 diabetes. "
            "Time-in-range (3.9–10 mmol/L) improved by 11 percentage points with the "
            "closed-loop system. Insulin dosing was automated via algorithm. No type 2 "
            "diabetes patients were enrolled."
        ),
        "grade": 1,   # MARGINALLY RELEVANT — insulin + RCT, but Type 1 only
    },
    {
        "doc_id": "CT-007",
        "title": "Bariatric Surgery vs. Medical Therapy for Obese Type 2 Diabetes",
        "text": (
            "Randomised trial of Roux-en-Y gastric bypass versus intensive medical therapy "
            "in 150 obese patients with type 2 diabetes. Surgical remission rate at 3 years "
            "was 38% versus 5% in the medical arm. HbA1c, fasting glucose, and insulin "
            "resistance markers all improved post-surgery. Some patients were on basal "
            "insulin at baseline and were able to discontinue after surgery."
        ),
        "grade": 2,   # RELEVANT — T2DM, insulin mentioned; surgery is primary intervention
    },
    {
        "doc_id": "CT-008",
        "title": "ACE Inhibitor Therapy for Hypertension — HOPE Trial",
        "text": (
            "The HOPE trial enrolled 9,297 patients aged ≥55 years with cardiovascular "
            "disease or diabetes at high risk. Ramipril (an ACE inhibitor) significantly "
            "reduced the risk of MI, stroke, and cardiovascular death. A subgroup analysis "
            "in patients with diabetes showed consistent benefit. No insulin therapy was "
            "studied as a primary or secondary intervention."
        ),
        "grade": 1,   # MARGINALLY RELEVANT — diabetes subgroup, no insulin
    },
    {
        "doc_id": "CT-009",
        "title": "SGLT2 Inhibitor Dapagliflozin in Heart Failure (DAPA-HF)",
        "text": (
            "DAPA-HF randomised 4,744 patients with heart failure and reduced ejection "
            "fraction to dapagliflozin or placebo. Approximately 45% had type 2 diabetes. "
            "The primary composite outcome of worsening heart failure or cardiovascular "
            "death was significantly reduced. Dapagliflozin's mechanism is insulin-independent. "
            "Renal outcomes were a secondary endpoint."
        ),
        "grade": 1,   # MARGINALLY RELEVANT — partial T2DM population, no insulin
    },
    {
        "doc_id": "CT-010",
        "title": "Prevention of Type 2 Diabetes by Lifestyle Intervention — DPP Trial",
        "text": (
            "The Diabetes Prevention Program (DPP) randomised 3,234 participants with "
            "impaired glucose tolerance to intensive lifestyle change, metformin, or placebo. "
            "Lifestyle intervention reduced diabetes incidence by 58%. Metformin reduced it "
            "by 31%. No insulin was used. This prevention trial is a cornerstone of public "
            "health guidelines for prediabetes management."
        ),
        "grade": 1,   # MARGINALLY RELEVANT — diabetes prevention, no insulin, no T2DM treatment
    },
    {
        "doc_id": "CT-011",
        "title": "Atorvastatin for LDL Reduction in Hypercholesterolaemia (ASCOT-LLA)",
        "text": (
            "ASCOT-LLA tested atorvastatin 10mg versus placebo in 10,305 hypertensive patients "
            "with total cholesterol ≤6.5 mmol/L. The trial was stopped early due to a 36% "
            "relative risk reduction in primary coronary events. No glucose-lowering "
            "intervention was studied. Diabetes was an exclusion criterion in some strata."
        ),
        "grade": 0,   # NOT RELEVANT — statin/lipid trial; no diabetes, no insulin
    },
    {
        "doc_id": "CT-012",
        "title": "Pembrolizumab plus Chemotherapy for Non-Small-Cell Lung Cancer",
        "text": (
            "KEYNOTE-189 randomised 616 patients with metastatic non-squamous NSCLC to "
            "pembrolizumab plus platinum-based chemotherapy or placebo plus chemotherapy. "
            "Combination immunotherapy significantly improved overall survival and "
            "progression-free survival. PD-L1 expression was a pre-specified biomarker. "
            "No metabolic or endocrine conditions were studied."
        ),
        "grade": 0,   # NOT RELEVANT — oncology immunotherapy
    },
    {
        "doc_id": "CT-013",
        "title": "Transcatheter Aortic Valve Implantation for Severe Aortic Stenosis",
        "text": (
            "PARTNER 3 compared TAVI with surgical aortic valve replacement in 1,000 low-risk "
            "patients with severe aortic stenosis. TAVI met non-inferiority and superiority "
            "for the composite of death, stroke, or rehospitalisation at one year. Diabetes "
            "was present in 30% of participants but was not an endpoint. No insulin trials."
        ),
        "grade": 0,   # NOT RELEVANT — cardiac structural intervention
    },
    {
        "doc_id": "CT-014",
        "title": "Rivaroxaban for Stroke Prevention in Atrial Fibrillation — ROCKET-AF",
        "text": (
            "ROCKET-AF randomised 14,264 patients with non-valvular atrial fibrillation to "
            "rivaroxaban or warfarin. Rivaroxaban was non-inferior for stroke prevention. "
            "Renal function and drug interactions were key safety concerns. No diabetes-specific "
            "intervention was evaluated. Anticoagulation focus only."
        ),
        "grade": 0,   # NOT RELEVANT — anticoagulation trial
    },
    {
        "doc_id": "CT-015",
        "title": "Cognitive Behavioural Therapy for Major Depressive Disorder",
        "text": (
            "Randomised trial comparing CBT with antidepressant pharmacotherapy in 240 adults "
            "with moderate-to-severe major depressive disorder. Response rates at 16 weeks "
            "were equivalent between arms. Remission was slightly higher in the pharmacotherapy "
            "arm. No metabolic or endocrine outcomes were assessed."
        ),
        "grade": 0,   # NOT RELEVANT — psychiatry trial
    },
    {
        "doc_id": "CT-016",
        "title": "Basal-Bolus Insulin Regimen in Hospitalised Patients with Type 2 Diabetes",
        "text": (
            "Open-label randomised trial comparing basal-bolus insulin (glargine + glulisine) "
            "with sliding-scale insulin in 211 general medicine patients with type 2 diabetes. "
            "Basal-bolus therapy achieved significantly better mean daily glucose and reduced "
            "treatment failure. Hypoglycaemia rates were similar. This trial directly informed "
            "inpatient hyperglycaemia management guidelines for type 2 diabetic patients."
        ),
        "grade": 3,   # HIGHLY RELEVANT — T2DM + insulin + RCT — textbook match
    },
    {
        "doc_id": "CT-017",
        "title": "Semaglutide Weekly Injection in Type 2 Diabetes — SUSTAIN-6",
        "text": (
            "SUSTAIN-6 randomised 3,297 patients with type 2 diabetes to once-weekly "
            "semaglutide or placebo. Primary outcome was a composite cardiovascular endpoint. "
            "Semaglutide reduced non-fatal stroke significantly. HbA1c and body weight "
            "declined markedly. Insulin use was allowed as background therapy in ~57% of "
            "patients, making this a real-world T2DM population study."
        ),
        "grade": 2,   # RELEVANT — T2DM RCT; GLP-1 primary, insulin background
    },
    {
        "doc_id": "CT-018",
        "title": "Alogliptin DPP-4 Inhibitor for Glycaemic Control in Type 2 Diabetes",
        "text": (
            "52-week randomised placebo-controlled study of alogliptin (a DPP-4 inhibitor) "
            "added to existing therapy in 1,768 patients with inadequately controlled type 2 "
            "diabetes. HbA1c fell by 0.59% versus placebo. No increased hypoglycaemia risk. "
            "Insulin combination sub-study showed additive effect. Renal safety was confirmed."
        ),
        "grade": 2,   # RELEVANT — T2DM + insulin sub-study, but DPP4 is primary
    },
    {
        "doc_id": "CT-019",
        "title": "Bone Marrow Transplantation for Acute Myeloid Leukaemia — Phase III",
        "text": (
            "Multicentre phase III trial comparing allogeneic bone marrow transplantation "
            "with consolidation chemotherapy in 508 AML patients in first complete remission. "
            "Transplantation improved disease-free survival at five years. Graft-versus-host "
            "disease was the principal toxicity. No endocrine endpoints were measured."
        ),
        "grade": 0,   # NOT RELEVANT — haematological oncology
    },
    {
        "doc_id": "CT-020",
        "title": "Pioglitazone for Non-Alcoholic Steatohepatitis (NASH) in Type 2 Diabetes",
        "text": (
            "Randomised trial of pioglitazone (a thiazolidinedione) versus vitamin E and "
            "placebo in 247 patients with NASH and type 2 diabetes. Pioglitazone improved "
            "liver histology scores significantly. Insulin sensitivity (HOMA-IR) improved. "
            "Weight gain was common. No exogenous insulin was used in this hepatology trial."
        ),
        "grade": 1,   # MARGINALLY RELEVANT — T2DM + insulin sensitivity, no insulin therapy
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# SEARCH QUERY
#
# This is the query a clinician or researcher might type into a trial database.
# The retrieval engine will rank all 20 documents against this query.
# ─────────────────────────────────────────────────────────────────────────────
QUERY = "Type 2 diabetes insulin therapy randomised controlled trial"

# ─────────────────────────────────────────────────────────────────────────────
# HELPER — nDCG COMPUTATION
# ─────────────────────────────────────────────────────────────────────────────

def dcg_at_k(relevance_grades: list[float], k: int) -> float:
    """
    Compute Discounted Cumulative Gain at rank cut-off k.

    Parameters
    ----------
    relevance_grades : list of relevance grades in retrieval ORDER
                       (index 0 = rank 1, index 1 = rank 2, ...)
    k                : rank cut-off (e.g. 10 for DCG@10)

    Returns
    -------
    DCG@k as a float
    """
    grades = np.array(relevance_grades[:k], dtype=float)
    # Positions are 1-based; log₂(i+1) for i in 1..k
    discounts = np.log2(np.arange(2, len(grades) + 2))  # log2(2), log2(3), ...
    return float(np.sum(grades / discounts))


def ndcg_at_k(relevance_grades: list[float], k: int) -> float:
    """
    Compute Normalised Discounted Cumulative Gain at cut-off k.

    nDCG@k = DCG@k / IDCG@k
    IDCG@k is the DCG of the ideal (descending) ordering of all grades.

    Returns a float in [0, 1].
    """
    ideal_grades = sorted(relevance_grades, reverse=True)
    idcg = dcg_at_k(ideal_grades, k)
    if idcg == 0:
        return 0.0
    return dcg_at_k(relevance_grades, k) / idcg


# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 — BUILD TF-IDF INDEX AND RETRIEVE TOP-10
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 72)
print("CLINICAL TRIAL SEARCH SYSTEM — TF-IDF Retrieval + nDCG Evaluation")
print("=" * 72)

# Concatenate title + text for richer indexing (title terms often matter most)
documents_text = [f"{doc['title']} {doc['text']}" for doc in CORPUS]

# TfidfVectorizer:
#   - sublinear_tf=True  → uses 1 + log(TF) instead of raw TF (compresses
#                          the dominance of very frequent terms)
#   - stop_words='english' → removes "the", "in", "of", etc. which carry no
#                            semantic signal and inflate cosine similarity
#   - ngram_range=(1,2)  → includes both unigrams and bigrams, capturing
#                          "type 2", "insulin therapy", "controlled trial"
#
# At this point `vectorizer` is a STATELESS CONFIGURATION OBJECT — it holds
# only the tokenisation rules above. It does NOT yet contain any vocabulary,
# term counts, or IDF weights; no text has been processed.
# This is analogous to a recipe with no ingredients mixed yet.
vectorizer = TfidfVectorizer(sublinear_tf=True,
                             stop_words="english",
                             ngram_range=(1, 2))

# fit_transform LEARNS from the corpus and APPLIES what it learned in one step:
#   • fit   → scans all documents, builds the vocabulary (every unique unigram /
#             bigram after stop-word removal), then computes IDF for each term.
#             After this, `vectorizer` is STATEFUL: it stores the vocabulary
#             mapping (term → column index) and the IDF weight per term.
#   • transform → converts each document into a sparse TF-IDF weight vector
#             using the vocabulary and IDF values just learned.
# Shape of result: [n_documents × n_unique_terms]  (sparse matrix)
#
# KEY DIFFERENCE from the vectorizer object above:
#   vectorizer  = the RULES (how to tokenise, which stop-words to drop, etc.)
#                 + after fit: the LEARNED STATE (vocabulary + IDF weights)
#   tfidf_matrix = the NUMBERS — a numeric matrix where every row is a document
#                  and every column is a term weight ready for maths (cosine sim)
#
# ── IS EACH WORD CONVERTED TO A VECTOR? NO — EACH DOCUMENT IS. ───────────────
#
#   Common misconception: "each word becomes a vector of vocab_size dimensions."
#   That is word embeddings (Word2Vec, GloVe).  TF-IDF works differently:
#
#   • The ENTIRE DOCUMENT (all its words combined) becomes ONE vector.
#   • That vector has vocab_size dimensions — one slot per vocabulary term.
#   • Each slot holds the TF-IDF weight of that term in this document (0.0
#     if the term does not appear, hence "sparse").
#
# ── CONCRETE MINI-EXAMPLE ────────────────────────────────────────────────────
#
#   Suppose our tiny corpus has only 3 documents and after tokenisation the
#   vocabulary (unigrams only, no stop-words) is:
#
#     Index:   0          1           2         3          4          5
#     Term: "cancer"  "diabetes"  "insulin"  "surgery"  "therapy"  "trial"
#
#   Documents:
#     Doc A: "insulin therapy randomised trial"
#     Doc B: "diabetes randomised trial"
#     Doc C: "cancer surgery"
#
#   The TF-IDF matrix (one ROW per document, one COLUMN per vocabulary term):
#
#              cancer  diabetes  insulin  surgery  therapy  trial
#     Doc A  [  0.00,   0.00,    0.58,    0.00,    0.58,   0.43 ]
#     Doc B  [  0.00,   0.71,    0.00,    0.00,    0.00,   0.71 ]
#     Doc C  [  0.71,   0.00,    0.00,    0.71,    0.00,   0.00 ]
#             ^─────────────────────────────────────────────────^
#             vocab_size = 6 columns  (thousands in real corpus)
#
#   Reading Doc A's row:
#     • "insulin" → 0.58  (appears once; moderately rare across corpus)
#     • "therapy" → 0.58  (appears once; moderately rare)
#     • "trial"   → 0.43  (appears in Doc A and Doc B → lower IDF → lower weight)
#     • "cancer"  → 0.00  (never appears in Doc A → zero → sparse)
#     • "diabetes"→ 0.00  (never appears in Doc A → zero → sparse)
#
#   Key observations:
#     1. Every document produces exactly ONE vector regardless of its length.
#     2. Most entries are 0.0 (sparse) — only terms present in the document
#        get a non-zero weight, which is why scipy stores it as a sparse matrix.
#     3. A term appearing in MANY documents gets a LOW IDF (less discriminating)
#        e.g. "trial" is in both Doc A and Doc B → IDF is smaller than "cancer".
#     4. A term appearing in VERY FEW documents gets a HIGH IDF (more specific).
#
#   In our real corpus: 20 documents, ngram_range=(1,2), so vocab_size is
#   typically in the low thousands.  tfidf_matrix.shape → (20, ~thousands).
# ─────────────────────────────────────────────────────────────────────────────
tfidf_matrix = vectorizer.fit_transform(documents_text)

# Transform the query into the SAME TF-IDF vector space.
# The query is treated as if it were one more document: its terms are looked up
# in the vocabulary the vectorizer already learned (fit), and their TF-IDF
# weights are computed using those stored IDF values.
# IMPORTANT: only terms seen during fit are used; unseen query terms are
# silently ignored (no KeyError — they simply contribute nothing).
# Result shape: [1 × vocab_size]  (same number of columns as tfidf_matrix)
#
# ── CONTINUING THE MINI-EXAMPLE: QUERY AS A VECTOR ───────────────────────────
#
#   Query: "insulin therapy trial"
#
#   Using the same vocabulary as before:
#     Index:   0          1           2         3          4          5
#     Term: "cancer"  "diabetes"  "insulin"  "surgery"  "therapy"  "trial"
#
#   Query vector (TF-IDF weights for each vocab term in the query):
#
#              cancer  diabetes  insulin  surgery  therapy  trial
#     Query  [  0.00,   0.00,    0.58,    0.00,    0.58,   0.43 ]
#
#   Notice: this query vector lives in the SAME 6-dimensional space as the
#   document rows.  We can now measure the "angle" between the query vector
#   and each document vector — that angle is what cosine similarity captures.
# ─────────────────────────────────────────────────────────────────────────────
query_vector = vectorizer.transform([QUERY])

# Cosine similarity between the query vector and every document vector.
# Result shape: [1 × n_documents]; we flatten to 1-D
#
# ── HOW COSINE SIMILARITY WORKS ──────────────────────────────────────────────
#
#   Two vectors A and B of the same length:
#
#              A · B          sum(A_i × B_i)
#   cos(θ) = ───────── = ─────────────────────────
#             |A| × |B|   sqrt(sum(A_i²)) × sqrt(sum(B_i²))
#
#   • The NUMERATOR (dot product) is large when the same dimensions are
#     simultaneously large in both vectors — i.e. the same terms have high
#     TF-IDF weight in both the query and the document.
#   • The DENOMINATOR normalises for vector length, so a longer document
#     does not automatically score higher just because it has more non-zero
#     entries.  Only SHARED, RARE terms lift the score.
#   • Result is always in [0, 1] for TF-IDF vectors (all weights ≥ 0).
#     1.0 = identical direction (perfect overlap), 0.0 = no shared terms.
#
# ── WORKED EXAMPLE WITH OUR THREE DOCUMENTS ──────────────────────────────────
#
#   Recall the vectors (indices: cancer=0, diabetes=1, insulin=2,
#                                surgery=3, therapy=4, trial=5):
#
#     Query  Q = [ 0.00, 0.00, 0.58, 0.00, 0.58, 0.43 ]
#     Doc A  A = [ 0.00, 0.00, 0.58, 0.00, 0.58, 0.43 ]   ← insulin therapy trial
#     Doc B  B = [ 0.00, 0.71, 0.00, 0.00, 0.00, 0.71 ]   ← diabetes trial
#     Doc C  C = [ 0.71, 0.00, 0.00, 0.71, 0.00, 0.00 ]   ← cancer surgery
#
#   cosine_similarity(Q, Doc A):
#     numerator   = 0×0 + 0×0 + 0.58×0.58 + 0×0 + 0.58×0.58 + 0.43×0.43
#                 = 0.3364 + 0.3364 + 0.1849  =  0.8577
#     |Q|         = sqrt(0.58²+0.58²+0.43²)  =  sqrt(0.8577) ≈ 0.9261
#     |A|         = sqrt(0.58²+0.58²+0.43²)  ≈  0.9261   (same vector here)
#     cos(Q,A)    = 0.8577 / (0.9261 × 0.9261) ≈ 1.00  ← perfect match
#
#   cosine_similarity(Q, Doc B):
#     numerator   = 0×0 + 0×0.71 + 0.58×0 + 0×0 + 0.58×0 + 0.43×0.71
#                 = 0 + 0 + 0 + 0 + 0 + 0.305  =  0.305
#     |Q| ≈ 0.9261,  |B| = sqrt(0.71²+0.71²) ≈ 1.004
#     cos(Q,B) = 0.305 / (0.9261 × 1.004) ≈ 0.33  ← partial match ("trial" shared)
#
#   cosine_similarity(Q, Doc C):
#     numerator   = 0×0.71 + 0×0 + 0.58×0 + 0×0.71 + 0.58×0 + 0.43×0
#                 = 0  ← no shared vocabulary terms at all
#     cos(Q,C) = 0.00  ← no match
#
#   RANKING by cosine score:
#     Rank 1 → Doc A  (score 1.00) — "insulin therapy trial"      ✓ best match
#     Rank 2 → Doc B  (score 0.33) — "diabetes trial"             ✓ partial
#     Rank 3 → Doc C  (score 0.00) — "cancer surgery"             ✗ irrelevant
#
#   This is exactly how TF-IDF retrieval ranks documents — shared rare terms
#   drive scores up; unrelated documents fall to the bottom automatically.
#
#   In our real 20-document corpus the same logic applies across thousands of
#   vocabulary dimensions. cosine_similarity(query_vector, tfidf_matrix)
#   computes this dot-product-then-normalise operation for ALL 20 documents
#   in one vectorised matrix multiplication — fast and exact.
# ─────────────────────────────────────────────────────────────────────────────
cosine_scores = cosine_similarity(query_vector, tfidf_matrix).flatten()

# Argsort in descending order → indices of documents sorted by relevance score
ranked_indices = np.argsort(cosine_scores)[::-1]

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 — DISPLAY TOP-10 SEARCH RESULTS
# ─────────────────────────────────────────────────────────────────────────────
K = 10  # result list size

print(f"\nQUERY: \"{QUERY}\"\n")
print(f"{'Rank':<5} {'Doc ID':<8} {'Score':>7}  {'Grade':>5}  {'Title'}")
print("-" * 72)

retrieved_grades = []  # relevance grades in retrieval order (for nDCG)

for rank, idx in enumerate(ranked_indices[:K], start=1):
    doc   = CORPUS[idx]
    score = cosine_scores[idx]
    grade = doc["grade"]
    retrieved_grades.append(grade)

    # Visual indicator: [***] conveys relevance grade at a glance
    stars = "[" + "*" * grade + "-" * (3 - grade) + "]"

    print(f"  {rank:<3} {doc['doc_id']:<8} {score:>7.4f}  {stars}  {doc['title']}")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 — COMPUTE nDCG FOR THE TF-IDF RANKING
# ─────────────────────────────────────────────────────────────────────────────
# All grades in the corpus (needed to compute the ideal ordering)
all_grades = [doc["grade"] for doc in CORPUS]

# DCG@10 for what the search engine actually returned
dcg_retrieved  = dcg_at_k(retrieved_grades, K)

# IDCG@10 — ideal: sort ALL corpus grades descending and compute DCG
ideal_grades   = sorted(all_grades, reverse=True)[:K]
idcg           = dcg_at_k(ideal_grades, K)

# nDCG@10
ndcg_retrieved = ndcg_at_k(retrieved_grades, K)

print("\n" + "=" * 72)
print("nDCG EVALUATION — TF-IDF Ranking vs. Ideal vs. Worst")
print("=" * 72)

print(f"""
  All 20 corpus documents have the following relevance grade distribution
  for the query  "{QUERY}":

    Grade 3 (Highly Relevant)   : {all_grades.count(3)} documents
    Grade 2 (Relevant)          : {all_grades.count(2)} documents
    Grade 1 (Marginally Relev.) : {all_grades.count(1)} documents
    Grade 0 (Not Relevant)      : {all_grades.count(0)} documents
""")

# ── A) TF-IDF ranking ────────────────────────────────────────────────────────
print("─" * 72)
print("A) TF-IDF RANKING (what the search engine returned)")
print("─" * 72)
print(f"   Grades at ranks 1–{K}: {retrieved_grades}")
print(f"   DCG@{K}              : {dcg_retrieved:.4f}")
print(f"   IDCG@{K}             : {idcg:.4f}")
print(f"   nDCG@{K}             : {ndcg_retrieved:.4f}  ← the score we care about")

# ── B) Ideal ranking (IDCG) ──────────────────────────────────────────────────
ideal_ranking_grades = sorted(all_grades, reverse=True)[:K]
dcg_ideal  = dcg_at_k(ideal_ranking_grades, K)
ndcg_ideal = ndcg_at_k(ideal_ranking_grades, K)  # will always be 1.0

print()
print("─" * 72)
print("B) IDEAL RANKING (best possible — highest grade docs first)")
print("─" * 72)
print(f"   Grades at ranks 1–{K}: {ideal_ranking_grades}")
print(f"   DCG@{K}              : {dcg_ideal:.4f}")
print(f"   nDCG@{K}             : {ndcg_ideal:.4f}  ← always 1.0 by definition")

# ── C) Worst plausible ranking (relevant docs pushed to the bottom) ───────────
# Sort so that grade-0 docs come first, then ascending grades — reverse of ideal
worst_ranking_grades = sorted(retrieved_grades)   # ascending = worst first
dcg_worst  = dcg_at_k(worst_ranking_grades, K)
ndcg_worst = ndcg_at_k(worst_ranking_grades, K)

print()
print("─" * 72)
print("C) WORST RANKING (relevant docs deliberately pushed to the BOTTOM)")
print("─" * 72)
print(f"   Grades at ranks 1–{K}: {worst_ranking_grades}")
print(f"   DCG@{K}              : {dcg_worst:.4f}")
print(f"   nDCG@{K}             : {ndcg_worst:.4f}  ← low because best docs appear last")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 — RANK-BY-RANK DCG CONTRIBUTION BREAKDOWN
#
# This section unpacks HOW each position contributes to DCG so learners can
# see the discounting in action.  A grade-3 document at rank 1 contributes
# much more than the same grade at rank 10.
# ─────────────────────────────────────────────────────────────────────────────
print()
print("=" * 72)
print("RANK-BY-RANK DCG CONTRIBUTION — TF-IDF Ranking")
print("(Shows how the position discount diminishes value of later results)")
print("=" * 72)
print(f"\n  {'Rank':<5} {'Grade':<7} {'Discount log₂(rank+1)':<24} {'Contribution grade/log₂'}")
print("  " + "-" * 60)

cumulative_dcg = 0.0
for i, grade in enumerate(retrieved_grades, start=1):
    discount    = np.log2(i + 1)
    contribution = grade / discount
    cumulative_dcg += contribution
    bar = "█" * int(contribution * 8)
    print(f"  {i:<5} {grade:<7} {discount:<24.4f} {contribution:.4f}  {bar}")

print(f"\n  Cumulative DCG@{K} = {cumulative_dcg:.4f}")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 5 — SENSITIVITY: HOW MUCH DOES POSITION MATTER?
#
# Move a grade-3 document from rank 1 to rank 10 and observe the nDCG drop.
# This dramatically illustrates why ordering is not cosmetic.
# ─────────────────────────────────────────────────────────────────────────────
print()
print("=" * 72)
print("SENSITIVITY ANALYSIS — Cost of Burying a Highly Relevant Document")
print("=" * 72)
print("""
  Suppose the BEST document (grade 3) appears at various rank positions.
  All other positions filled with irrelevant documents (grade 0).
  nDCG@10 is computed for each case.
""")
print(f"  {'Position of grade-3 doc':<28} {'DCG@10':>8}  {'nDCG@10':>9}  {'Loss vs. rank-1':>16}")
print("  " + "-" * 66)

# IDCG for this scenario: one grade-3 doc, rest are grade-0 → only one
# contributes, so IDCG = 3 / log2(2) = 3.0
scenario_idcg = 3.0 / np.log2(2)

for pos in range(1, K + 1):
    scenario_grades = [0] * K
    scenario_grades[pos - 1] = 3
    dcg  = dcg_at_k(scenario_grades, K)
    ndcg = dcg / scenario_idcg  # manual normalisation for this scenario
    loss = (1.0 - ndcg) * 100
    bar  = "█" * int(ndcg * 30)
    print(f"  Rank {pos:<24} {dcg:>8.4f}  {ndcg:>9.4f}  {loss:>14.1f}%  {bar}")

print("""
  Takeaway: A grade-3 document at rank 10 contributes only 18% of the value
  it would have at rank 1. Moving the best result DOWN by 9 positions loses
  82% of its potential contribution — this is the "discount" in DCG.
""")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 6 — FINAL SUMMARY
# ─────────────────────────────────────────────────────────────────────────────
print("=" * 72)
print("SUMMARY")
print("=" * 72)
print(f"""
  Query  : "{QUERY}"

  ┌─────────────────────────────┬──────────┬──────────┬──────────────────┐
  │ Ranking strategy            │  DCG@10  │ nDCG@10  │ Interpretation   │
  ├─────────────────────────────┼──────────┼──────────┼──────────────────┤
  │ A) TF-IDF retrieval         │ {dcg_retrieved:>8.4f} │ {ndcg_retrieved:>8.4f} │ System score     │
  │ B) Ideal (IDCG)             │ {dcg_ideal:>8.4f} │ {ndcg_ideal:>8.4f} │ Perfect = 1.0    │
  │ C) Worst (relevant at base) │ {dcg_worst:>8.4f} │ {ndcg_worst:>8.4f} │ Relevant, but    │
  │                             │          │          │ buried at bottom │
  └─────────────────────────────┴──────────┴──────────┴──────────────────┘

  KEY TAKEAWAYS
  ─────────────
  1. nDCG is POSITION-SENSITIVE — retrieving relevant documents is not
     enough; they must appear at the TOP of the list.

  2. The denominator log₂(rank+1) creates an exponentially decaying
     discount — early ranks matter disproportionately more.

  3. nDCG = 1.0 (ideal) means every relevant document appeared above
     every irrelevant document, in descending grade order.

  4. In clinical IR, nDCG is critical: a physician scanning the first
     page of results should find the highest-quality evidence first.

  5. TF-IDF is a strong lexical baseline. For better semantic matching
     (paraphrases, synonyms) use dense embeddings (sentence-transformers)
     and compare nDCG improvements — that is the natural next step.
""")
