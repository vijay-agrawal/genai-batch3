"""
=============================================================================
INFORMATION RETRIEVAL — Evaluation Metrics Deep Dive
=============================================================================

WHY EVALUATION MATTERS
─────────────────────────────────────────────────────────────────────────────
Building a retrieval system is only half the job. You need to measure whether
it works — and *how much* better or worse one system is than another.

In healthcare IR the stakes are especially high:
  • A clinician searching for "insulin dosing in renal failure" who gets
    irrelevant results at rank 1 may miss a critical dose-adjustment guideline.
  • A researcher using PubMed who only gets 40% of relevant trials in the
    top-20 results may draw biased conclusions in a systematic review.

Different clinical applications prioritise different things:
  Application                         What matters most
  ─────────────────────────────────── ──────────────────────────
  Point-of-care clinical search       Precision — top result must be correct
  Systematic review / meta-analysis   Recall — must find ALL relevant papers
  Drug interaction lookup             MRR — first correct answer is enough
  EHR patient similarity              nDCG — graded relevance, rank order
  Rare disease literature search      R-Precision — corpus is small & known

─────────────────────────────────────────────────────────────────────────────
HOW EVALUATION METRICS ACTUALLY WORK — NO TEXT INVOLVED
─────────────────────────────────────────────────────────────────────────────
Evaluation metrics do NOT read document text. They do NOT do keyword matching,
token overlap, or semantic comparison. They perform pure set membership checks
on document IDs.

The only question a metric ever asks is:

    Is this document ID in the golden set or not?

  ranked_list = ["D01", "C03", "D02", "N01", "O04", ...]
  golden_set  = {"D01", "D02", "D04"}

  rank 1: "D01" → in golden? YES  ✓
  rank 2: "C03" → in golden? NO   ✗
  rank 3: "D02" → in golden? YES  ✓

  P@3 = 2/3 = 0.667   ← that is the entire computation

No tokens. No words. No embeddings. Just: doc_id in golden_set.

This means evaluation metrics are completely decoupled from how retrieval works:
  • A TF-IDF system produces a ranked list  →  metric scores it
  • A dense bi-encoder produces a ranked list  →  same metric scores it
  • A human expert writes a ranked list  →  same metric scores it
The metric cannot tell and does not care which system produced the list.

THIS IS WHY THE GOLDEN DATASET IS EVERYTHING
─────────────────────────────────────────────
The entire evaluation pipeline is only as good as the relevance judgments.
If a physician marked D02 as relevant but forgot D05 (which is equally
relevant), every metric will silently penalise any system that correctly
retrieves D05 — the metric has no way to know the judgment was incomplete.

This is why TREC uses pooling: no annotator can review all 1M documents, so
NIST merges the top-100 results from all submitted systems, sends that pool
to human assessors, and treats everything outside the pool as non-relevant.
This known bias is called pooling bias — systems that retrieve relevant
documents outside the pool are unfairly penalised.

In this demo, relevance judgments are hardcoded synthetically:
  "binary_relevant": {"D01", "D02", "D04"},
  "graded_relevance": {"D01": 3, "D02": 2, "D03": 1, ...}

In production healthcare systems, clinical informaticists or physicians must
label hundreds of (query, document) pairs — the expensive human bottleneck
in any real IR evaluation pipeline.

─────────────────────────────────────────────────────────────────────────────
METRICS COVERED IN THIS DEMO
─────────────────────────────────────────────────────────────────────────────

  1.  Precision@k          — of the top-k returned, what fraction is relevant?
  2.  Recall@k             — of ALL relevant docs, what fraction was found in top-k?
  3.  F1@k                 — harmonic mean of Precision@k and Recall@k
  4.  Average Precision     — area under the Precision-Recall curve for one query
  5.  MAP                  — Mean Average Precision across multiple queries
  6.  MRR                  — Mean Reciprocal Rank (first correct answer)
  7.  nDCG@k               — Normalized Discounted Cumulative Gain (graded relevance)
  8.  R-Precision           — Precision at rank R (R = number of relevant docs)

─────────────────────────────────────────────────────────────────────────────
METRIC 1 — Precision@k
─────────────────────────────────────────────────────────────────────────────
  P@k = (# relevant docs in top-k) / k

  The simplest metric. Answers: "If a clinician reads only the first k
  results, how many of them will be useful?"

  Example: top-5 results are [✓, ✗, ✓, ✓, ✗]  →  P@5 = 3/5 = 0.60

  LIMITATION: Does not penalise for relevant documents that were NOT retrieved
  (a system returning 1 relevant result in k=1 scores P@1=1.0 regardless of
  whether it missed 99 other relevant documents).

─────────────────────────────────────────────────────────────────────────────
METRIC 2 — Recall@k
─────────────────────────────────────────────────────────────────────────────
  R@k = (# relevant docs in top-k) / (total # relevant docs in corpus)

  Answers: "Of everything relevant in the corpus, how much did we surface?"
  Critical for systematic reviews where missing evidence is dangerous.

  Example: top-5 returns 3 relevant docs, corpus has 8 relevant total
           →  Recall@5 = 3/8 = 0.375

  LIMITATION: Ignores rank order within the top-k. Finding 3 at ranks 1,2,3
  scores the same as finding 3 at ranks 3,4,5.

─────────────────────────────────────────────────────────────────────────────
METRIC 3 — F1@k
─────────────────────────────────────────────────────────────────────────────
  F1@k = 2 × P@k × R@k / (P@k + R@k)

  The harmonic mean punishes extreme imbalance. A system with P@10=0.9 and
  R@10=0.1 scores F1=0.18 — far lower than the 0.5 arithmetic mean would give.
  Forces the system to be reasonably good at both.

─────────────────────────────────────────────────────────────────────────────
METRIC 4 — Average Precision (AP)
─────────────────────────────────────────────────────────────────────────────
  AP is the area under the Precision-Recall curve, computed as:

  AP = (1 / R) × Σ P@k × rel(k)        for k = 1..n

  where R    = total relevant docs
        rel(k) = 1 if doc at rank k is relevant, else 0
        P@k  = precision at rank k (only counted when rel(k) = 1)

  Rewards finding relevant docs EARLY. A system that finds all 5 relevant
  docs at ranks 1-5 scores AP=1.0. One that finds them at ranks 6-10 scores
  much lower even though both have Recall=1.0.

  Example: relevant docs at ranks 1, 3, 5 out of 5 relevant total
    AP = (1/5) × [P@1×1 + P@3×1 + P@5×1]
       = (1/5) × [1/1  + 2/3  + 3/5]
       = (1/5) × [1.0  + 0.667 + 0.6]
       = (1/5) × 2.267 = 0.453

─────────────────────────────────────────────────────────────────────────────
METRIC 5 — MAP (Mean Average Precision)
─────────────────────────────────────────────────────────────────────────────
  MAP = (1/Q) × Σ AP(q)    for each query q in the evaluation set

  The standard single-number summary for a retrieval system evaluated over
  multiple queries. A system with MAP=0.6 is better on average than one with MAP=0.4 across the query set.
  Weakness: treats all relevant documents as binary (relevant/not-relevant).
  Does not capture degrees of relevance. nDCG is preferred when graded
  relevance judgments exist (e.g., highly relevant vs. marginally relevant).
  (MAP used as the primary metric in TREC tracks for decades. TREC = Text REtrieval Conference, 
  the benchmark Olympics of IR research.)

─────────────────────────────────────────────────────────────────────────────
METRIC 6 — MRR (Mean Reciprocal Rank)
─────────────────────────────────────────────────────────────────────────────
  For each query, find the rank of the FIRST relevant result:

  RR(q) = 1 / rank_of_first_relevant_doc

  MRR = (1/Q) × Σ RR(q)

  Ideal for tasks where only one answer is needed:
  - "What is the first-line treatment for C. difficile?"
  - Drug dose lookups, ICD-10 code lookup, FAQ-style queries

  "Relevant" = binary membership in the `binary_relevant` set defined per
  query in QUERIES (e.g. {"doc_a", "doc_c"}).  A retrieved doc_id is
  relevant if and only if it appears in that set — no grades, just yes/no.
  The check is simply:  if doc_id in relevant  (see reciprocal_rank()).

  If the first relevant document is at rank 3:  RR = 1/3 = 0.333
  If it is never found in top-k:                RR = 0

─────────────────────────────────────────────────────────────────────────────
METRIC 7 — nDCG@k (Normalized Discounted Cumulative Gain)
─────────────────────────────────────────────────────────────────────────────
  The gold standard for graded relevance + position-sensitive evaluation.

  Step 1 — DCG@k:  reward relevance, discounted by rank position
                k     rel_i
    DCG@k  =   Σ   ─────────
               i=1   log₂(i+1)

  Step 2 — IDCG@k: same formula but with grades sorted descending (ideal)

  Step 3 — nDCG@k = DCG@k / IDCG@k    (always in [0, 1])

  Grade scale used here (TREC-style):
    3 = Highly relevant   (directly answers the clinical question)
    2 = Relevant          (related condition or intervention)
    1 = Marginally relevant
    0 = Not relevant

─────────────────────────────────────────────────────────────────────────────
METRIC 8 — R-Precision
─────────────────────────────────────────────────────────────────────────────
  R = total number of relevant documents for a query
  R-Precision = Precision@R = (# relevant docs found in top-R) / R

  Useful when the total number of relevant docs is known (small corpora,
  rare disease literature, a curated guideline database).

  Intuition: if there are 4 relevant docs and your top-4 results contain
  3 of them, R-Precision = 3/4 = 0.75.

─────────────────────────────────────────────────────────────────────────────
METRIC CHOICE GUIDE
─────────────────────────────────────────────────────────────────────────────
  Use case                                  Recommended metric
  ──────────────────────────────────────── ─────────────────────────────────
  Clinician point-of-care search            P@1, P@5, MRR
  Systematic review / evidence synthesis    Recall@k, MAP
  EHR semantic search (graded relevance)    nDCG@10
  FAQ / single-answer lookup                MRR
  Rare-disease literature corpus            R-Precision
  Comparing two systems across queries      MAP or MRR (single number)
  Tuning a reranker                         nDCG@10 (sensitive to ordering)

─────────────────────────────────────────────────────────────────────────────
THIS DEMO
─────────────────────────────────────────────────────────────────────────────
  Synthetic corpus: 25 clinical documents across 5 specialties.
  5 queries with full binary + graded relevance judgments.
  Three retrieval systems compared: TF-IDF, BM25, a mock "dense" system.
  All 8 metrics computed and displayed side-by-side.
  Visualizations:
    • Precision-Recall curves per query and system
    • Metric comparison bar chart across three systems
    • Rank sensitivity diagram (how rank of first relevant doc affects MRR)

  Run:  python retriever_evals.py
  Deps: pip install scikit-learn rank-bm25 matplotlib numpy
=============================================================================
"""

import sys
import math
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

sys.stdout.reconfigure(encoding="utf-8")

try:
    from rank_bm25 import BM25Okapi
    HAVE_BM25 = True
except ImportError:
    HAVE_BM25 = False
    print("[WARN] rank-bm25 not installed — BM25 system will be skipped. pip install rank-bm25")

# ─────────────────────────────────────────────────────────────────────────────
# SYNTHETIC CORPUS — 25 clinical documents
# ─────────────────────────────────────────────────────────────────────────────
DOCUMENTS = [
    # ── Diabetes (IDs D01–D05) ───────────────────────────────────────────────
    {"id": "D01", "specialty": "Endocrinology",
     "text": "Type 2 diabetes insulin therapy: basal insulin glargine reduces fasting glucose and HbA1c. "
             "Randomised controlled trial comparing insulin glargine to metformin in uncontrolled type 2 diabetes. "
             "Primary endpoint HbA1c at 24 weeks. Hypoglycaemia was the main adverse event monitored."},
    {"id": "D02", "specialty": "Endocrinology",
     "text": "Metformin versus sulfonylurea for glycaemic control in type 2 diabetes mellitus. "
             "Double-blind randomised trial. Metformin achieved superior HbA1c reduction with lower hypoglycaemia risk. "
             "Weight neutral compared to sulfonylurea-associated weight gain."},
    {"id": "D03", "specialty": "Endocrinology",
     "text": "Continuous glucose monitoring reduces hypoglycaemia in insulin-treated type 1 diabetes patients. "
             "CGM time-in-range improved significantly versus fingerstick monitoring in 6-month RCT. "
             "Sensor-augmented pump therapy versus multiple daily injections compared."},
    {"id": "D04", "specialty": "Endocrinology",
     "text": "GLP-1 receptor agonist semaglutide weekly injection for type 2 diabetes. "
             "SUSTAIN trial: semaglutide reduced HbA1c by 1.5% and body weight by 4.5 kg versus placebo. "
             "Cardiovascular outcomes: reduction in MACE events in patients with established CVD."},
    {"id": "D05", "specialty": "Endocrinology",
     "text": "SGLT2 inhibitor empagliflozin in type 2 diabetes with chronic kidney disease. "
             "EMPA-KIDNEY trial: renal composite outcome reduced by 28% versus placebo. "
             "Secondary outcome cardiovascular death also significantly reduced."},
    # ── Cardiology (IDs C01–C05) ─────────────────────────────────────────────
    {"id": "C01", "specialty": "Cardiology",
     "text": "Aspirin versus ticagrelor dual antiplatelet therapy after percutaneous coronary intervention. "
             "Randomised trial in STEMI patients: ticagrelor plus aspirin versus clopidogrel plus aspirin. "
             "Primary outcome MACE at 12 months. Ticagrelor group had lower cardiovascular mortality."},
    {"id": "C02", "specialty": "Cardiology",
     "text": "Sacubitril-valsartan versus enalapril in heart failure with reduced ejection fraction. "
             "PARADIGM-HF trial: ARNI reduced cardiovascular death and heart failure hospitalisations by 20%. "
             "Patients with EF below 40% randomised to sacubitril-valsartan or ACE inhibitor."},
    {"id": "C03", "specialty": "Cardiology",
     "text": "Beta-blocker therapy in acute myocardial infarction. "
             "Carvedilol reduces post-MI ejection fraction decline and improves survival in randomised trial. "
             "Early versus late initiation of beta-blocker after STEMI compared."},
    {"id": "C04", "specialty": "Cardiology",
     "text": "Apixaban versus warfarin for stroke prevention in atrial fibrillation. "
             "ARISTOTLE trial: apixaban reduced stroke by 21% and bleeding by 31% versus warfarin. "
             "Renal function and age stratified analysis showed consistent benefit."},
    {"id": "C05", "specialty": "Cardiology",
     "text": "Cardiac rehabilitation after heart failure hospitalisation reduces readmission. "
             "Supervised exercise training versus usual care in patients with EF below 35%. "
             "Six-minute walk test and quality of life improved significantly at 3 months."},
    # ── Oncology (IDs O01–O05) ───────────────────────────────────────────────
    {"id": "O01", "specialty": "Oncology",
     "text": "Pembrolizumab immunotherapy for non-small cell lung cancer PD-L1 positive patients. "
             "KEYNOTE-024: pembrolizumab versus platinum-based chemotherapy in first-line NSCLC. "
             "Progression-free survival improved 10.3 months versus 6.0 months with chemotherapy."},
    {"id": "O02", "specialty": "Oncology",
     "text": "CDK4/6 inhibitor palbociclib plus letrozole for HR-positive HER2-negative breast cancer. "
             "PALOMA-2 trial: palbociclib significantly extended progression-free survival. "
             "Neutropenia was the most common grade 3-4 adverse event requiring dose reduction."},
    {"id": "O03", "specialty": "Oncology",
     "text": "FOLFOX chemotherapy versus FOLFIRI for metastatic colorectal cancer. "
             "Head-to-head randomised comparison: similar overall survival, different toxicity profiles. "
             "Oxaliplatin causes peripheral neuropathy; irinotecan causes diarrhoea predominantly."},
    {"id": "O04", "specialty": "Oncology",
     "text": "CAR-T cell therapy axicabtagene ciloleucel for diffuse large B-cell lymphoma. "
             "ZUMA-1 trial: 54% complete response rate in relapsed/refractory DLBCL. "
             "Cytokine release syndrome grade 3+ in 13% of patients; managed with tocilizumab."},
    {"id": "O05", "specialty": "Oncology",
     "text": "Osimertinib for EGFR-mutant non-small cell lung cancer with brain metastases. "
             "AURA3 trial: osimertinib versus platinum chemotherapy in T790M-positive NSCLC. "
             "CNS response rate 70% with osimertinib; superior PFS and OS compared to chemotherapy."},
    # ── Infectious Disease (IDs I01–I05) ─────────────────────────────────────
    {"id": "I01", "specialty": "Infectious Disease",
     "text": "Vancomycin versus daptomycin for MRSA bacteraemia treatment. "
             "Randomised non-inferiority trial: treatment success at day 42 similar in both arms. "
             "Vancomycin AUC-guided dosing strategy reduced nephrotoxicity significantly."},
    {"id": "I02", "specialty": "Infectious Disease",
     "text": "Procalcitonin-guided antibiotic therapy in sepsis reduces treatment duration. "
             "Randomised trial in ICU: procalcitonin group received antibiotics for 8 days versus 12 days. "
             "30-day mortality not significantly different; antibiotic resistance rates improved."},
    {"id": "I03", "specialty": "Infectious Disease",
     "text": "Fidaxomicin versus vancomycin for Clostridioides difficile infection. "
             "Randomised trial: fidaxomicin associated with lower recurrence rate at 28 days. "
             "Both treatments achieved similar clinical cure rates in non-hypervirulent strains."},
    {"id": "I04", "specialty": "Infectious Disease",
     "text": "Nirmatrelvir-ritonavir versus placebo for high-risk COVID-19 outpatients. "
             "EPIC-HR trial: 89% reduction in hospitalisation and death versus placebo. "
             "Must initiate within 5 days of symptom onset; drug interactions with ritonavir significant."},
    {"id": "I05", "specialty": "Infectious Disease",
     "text": "Ceftriaxone versus oral amoxicillin-clavulanate for community-acquired pneumonia. "
             "Non-inferiority trial in hospitalised patients: oral step-down therapy non-inferior. "
             "Early IV-to-oral switch safe and reduced length of stay by 1.5 days."},
    # ── Neurology (IDs N01–N05) ──────────────────────────────────────────────
    {"id": "N01", "specialty": "Neurology",
     "text": "Tenecteplase versus alteplase for acute ischemic stroke thrombolysis. "
             "Randomised trial: tenecteplase non-inferior to alteplase for 90-day functional outcomes. "
             "Single IV bolus of tenecteplase simpler to administer than alteplase infusion."},
    {"id": "N02", "specialty": "Neurology",
     "text": "Mechanical thrombectomy plus IV tPA versus IV tPA alone for large vessel occlusion stroke. "
             "Meta-analysis of 5 RCTs: combined therapy doubles functional independence at 90 days. "
             "Time from symptom onset to groin puncture is the strongest predictor of outcome."},
    {"id": "N03", "specialty": "Neurology",
     "text": "Levetiracetam versus valproate for generalised tonic-clonic seizures. "
             "Randomised open-label trial: levetiracetam non-inferior for seizure freedom at 12 months. "
             "Valproate superior for absence seizures; teratogenicity limits use in women."},
    {"id": "N04", "specialty": "Neurology",
     "text": "Natalizumab versus interferon beta-1a for relapsing multiple sclerosis. "
             "AFFIRM trial: natalizumab reduced annualised relapse rate by 68% versus placebo. "
             "Progressive multifocal leukoencephalopathy risk requires JC virus antibody monitoring."},
    {"id": "N05", "specialty": "Neurology",
     "text": "Deep brain stimulation versus best medical therapy for Parkinson disease. "
             "EARLYSTIM trial: DBS superior for motor function and quality of life in early PD. "
             "Surgical risks include infection, lead displacement, and stimulation-related side effects."},
]

# ─────────────────────────────────────────────────────────────────────────────
# QUERIES WITH RELEVANCE JUDGMENTS
#
# binary_relevant: set of doc IDs that are relevant (for P@k, R@k, MAP, MRR)
# graded_relevance: dict of doc_id → grade 0-3 (for nDCG)
# ─────────────────────────────────────────────────────────────────────────────
QUERIES = [
    {
        "id": "Q1",
        "text": "insulin therapy randomised trial type 2 diabetes HbA1c",
        "binary_relevant": {"D01", "D02", "D04"},
        "graded_relevance": {"D01": 3, "D02": 2, "D03": 1, "D04": 2, "D05": 1},
        "note": "Diabetes RCT — 3 clearly relevant, 2 partially relevant",
    },
    {
        "id": "Q2",
        "text": "stroke thrombolysis tPA treatment acute ischemic",
        "binary_relevant": {"N01", "N02"},
        "graded_relevance": {"N01": 3, "N02": 3, "N03": 0, "N04": 0, "N05": 0},
        "note": "Stroke treatment — only 2 relevant docs in corpus",
    },
    {
        "id": "Q3",
        "text": "antibiotic treatment infection randomised controlled trial",
        "binary_relevant": {"I01", "I02", "I03", "I04", "I05"},
        "graded_relevance": {"I01": 2, "I02": 3, "I03": 2, "I04": 2, "I05": 2},
        "note": "High-recall scenario — all 5 ID docs are relevant",
    },
    {
        "id": "Q4",
        "text": "heart failure ejection fraction treatment trial",
        "binary_relevant": {"C02", "C05"},
        "graded_relevance": {"C01": 1, "C02": 3, "C03": 2, "C04": 0, "C05": 2},
        "note": "Cardiology — graded relevance spanning multiple docs",
    },
    {
        "id": "Q5",
        "text": "cancer immunotherapy checkpoint inhibitor lung tumour",
        "binary_relevant": {"O01", "O05"},
        "graded_relevance": {"O01": 3, "O02": 1, "O03": 0, "O04": 1, "O05": 2},
        "note": "Oncology — immunotherapy focus, molecular therapy adjacent",
    },
]

CORPUS_TEXTS = [d["text"] for d in DOCUMENTS]
DOC_IDS = [d["id"] for d in DOCUMENTS]


# ─────────────────────────────────────────────────────────────────────────────
# RETRIEVAL SYSTEMS
# ─────────────────────────────────────────────────────────────────────────────
def retrieve_tfidf(query_text: str, top_k: int = 20) -> list[str]:
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, stop_words="english")
    matrix = vectorizer.fit_transform(CORPUS_TEXTS)
    q_vec = vectorizer.transform([query_text])
    scores = cosine_similarity(q_vec, matrix).flatten()
    ranked = np.argsort(scores)[::-1][:top_k]
    return [DOC_IDS[i] for i in ranked]


def retrieve_bm25(query_text: str, top_k: int = 20) -> list[str]:
    if not HAVE_BM25:
        return []
    tokenized = [t.lower().split() for t in CORPUS_TEXTS]
    bm25 = BM25Okapi(tokenized)
    scores = bm25.get_scores(query_text.lower().split())
    ranked = np.argsort(scores)[::-1][:top_k]
    return [DOC_IDS[i] for i in ranked]


def retrieve_mock_dense(query: dict, top_k: int = 20) -> list[str]:
    """
    Simulates a dense retriever that is better at semantic matching but
    occasionally returns a wrong document in the top-3. In a real demo
    you would replace this with sentence-transformers + FAISS (see Demo 3).
    The mock is intentionally slightly better than TF-IDF to demonstrate
    metric differences — it puts the highest-graded relevant doc at rank 1.
    """
    rel = query["graded_relevance"]
    # Sort relevant docs by grade descending, put them first
    relevant_sorted = sorted(rel.keys(), key=lambda d: rel[d], reverse=True)
    # Fill remaining slots with non-relevant docs in arbitrary order
    irrelevant = [d for d in DOC_IDS if d not in rel or rel[d] == 0]
    ranked = relevant_sorted + irrelevant
    return ranked[:top_k]


# ─────────────────────────────────────────────────────────────────────────────
# METRIC IMPLEMENTATIONS
# ─────────────────────────────────────────────────────────────────────────────

def precision_at_k(ranked_ids: list[str], relevant: set[str], k: int) -> float:
    """Fraction of top-k retrieved documents that are relevant."""
    top_k = ranked_ids[:k]
    hits = sum(1 for d in top_k if d in relevant)
    return hits / k


def recall_at_k(ranked_ids: list[str], relevant: set[str], k: int) -> float:
    """Fraction of all relevant documents found in top-k."""
    if not relevant:
        return 0.0
    top_k = ranked_ids[:k]
    hits = sum(1 for d in top_k if d in relevant)
    return hits / len(relevant)


def f1_at_k(ranked_ids: list[str], relevant: set[str], k: int) -> float:
    p = precision_at_k(ranked_ids, relevant, k)
    r = recall_at_k(ranked_ids, relevant, k)
    if p + r == 0:
        return 0.0
    return 2 * p * r / (p + r)


def average_precision(ranked_ids: list[str], relevant: set[str]) -> float:
    """
    AP = (1/R) × Σ P@k × rel(k)
    Computed only at positions where a relevant doc is retrieved.
    """
    R = len(relevant)
    if R == 0:
        return 0.0
    hits = 0
    ap = 0.0
    for k, doc_id in enumerate(ranked_ids, start=1):
        if doc_id in relevant:
            hits += 1
            ap += hits / k   # precision at this rank
    return ap / R


def mean_average_precision(all_ranked: list[list[str]], all_relevant: list[set[str]]) -> float:
    """MAP = mean of AP across all queries."""
    return float(np.mean([average_precision(r, rel) for r, rel in zip(all_ranked, all_relevant)]))


def reciprocal_rank(ranked_ids: list[str], relevant: set[str]) -> float:
    """1 / rank of the first relevant document. 0 if not found."""
    for rank, doc_id in enumerate(ranked_ids, start=1):
        if doc_id in relevant:
            return 1.0 / rank
    return 0.0


def mean_reciprocal_rank(all_ranked: list[list[str]], all_relevant: list[set[str]]) -> float:
    return float(np.mean([reciprocal_rank(r, rel) for r, rel in zip(all_ranked, all_relevant)]))


def dcg_at_k(ranked_ids: list[str], grades: dict[str, int], k: int) -> float:
    """DCG@k using rel_i / log2(i+1) formula."""
    dcg = 0.0
    for i, doc_id in enumerate(ranked_ids[:k], start=1):
        rel = grades.get(doc_id, 0)
        dcg += rel / math.log2(i + 1)
    return dcg


def ndcg_at_k(ranked_ids: list[str], grades: dict[str, int], k: int) -> float:
    """nDCG@k = DCG@k / IDCG@k."""
    ideal_order = sorted(grades.keys(), key=lambda d: grades[d], reverse=True)
    idcg = dcg_at_k(ideal_order, grades, k)
    if idcg == 0:
        return 0.0
    return dcg_at_k(ranked_ids, grades, k) / idcg


def r_precision(ranked_ids: list[str], relevant: set[str]) -> float:
    """Precision@R where R = number of relevant documents."""
    R = len(relevant)
    if R == 0:
        return 0.0
    return precision_at_k(ranked_ids, relevant, R)


def precision_recall_curve(ranked_ids: list[str], relevant: set[str]) -> tuple[list, list]:
    """Returns (precisions, recalls) at each rank where a relevant doc appears."""
    precisions, recalls = [], []
    hits = 0
    total_relevant = len(relevant)
    for k, doc_id in enumerate(ranked_ids, start=1):
        if doc_id in relevant:
            hits += 1
            precisions.append(hits / k)
            recalls.append(hits / total_relevant)
    return precisions, recalls


# ─────────────────────────────────────────────────────────────────────────────
# COMPUTE ALL METRICS FOR A SYSTEM
# ─────────────────────────────────────────────────────────────────────────────
def evaluate_system(system_name: str, ranked_lists: list[list[str]], k: int = 10) -> dict:
    results_per_query = []
    for q, ranked in zip(QUERIES, ranked_lists):
        rel = q["binary_relevant"]
        grades = q["graded_relevance"]
        results_per_query.append({
            "query_id": q["id"],
            "P@k":      precision_at_k(ranked, rel, k),
            "R@k":      recall_at_k(ranked, rel, k),
            "F1@k":     f1_at_k(ranked, rel, k),
            "AP":       average_precision(ranked, rel),
            "RR":       reciprocal_rank(ranked, rel),
            "nDCG@k":   ndcg_at_k(ranked, grades, k),
            "R-Prec":   r_precision(ranked, rel),
        })

    metric_names = ["P@k", "R@k", "F1@k", "AP", "RR", "nDCG@k", "R-Prec"]
    aggregated = {m: float(np.mean([r[m] for r in results_per_query])) for m in metric_names}
    aggregated["MAP"] = aggregated.pop("AP")   # rename for clarity in aggregate
    aggregated["MRR"] = aggregated.pop("RR")

    return {
        "system": system_name,
        "k": k,
        "per_query": results_per_query,
        "aggregated": aggregated,
    }


# ─────────────────────────────────────────────────────────────────────────────
# PRINT RESULTS
# ─────────────────────────────────────────────────────────────────────────────
def print_per_query_table(eval_result: dict):
    sys_name = eval_result["system"]
    k = eval_result["k"]
    print(f"\n{'─'*90}")
    print(f"  {sys_name}  (k={k})")
    print(f"{'─'*90}")
    header = f"  {'Query':<6}  {'P@k':>6}  {'R@k':>6}  {'F1@k':>6}  {'AP':>6}  {'RR':>6}  {'nDCG@k':>8}  {'R-Prec':>7}"
    print(header)
    print(f"  {'─'*84}")
    for r in eval_result["per_query"]:
        print(
            f"  {r['query_id']:<6}  {r['P@k']:>6.3f}  {r['R@k']:>6.3f}  {r['F1@k']:>6.3f}"
            f"  {r['AP']:>6.3f}  {r['RR']:>6.3f}  {r['nDCG@k']:>8.3f}  {r['R-Prec']:>7.3f}"
        )
    agg = eval_result["aggregated"]
    print(f"  {'─'*84}")
    print(
        f"  {'MEAN':<6}  {agg['P@k']:>6.3f}  {agg['R@k']:>6.3f}  {agg['F1@k']:>6.3f}"
        f"  {agg['MAP']:>6.3f}  {agg['MRR']:>6.3f}  {agg['nDCG@k']:>8.3f}  {agg['R-Prec']:>7.3f}"
    )


def print_system_comparison(eval_results: list[dict]):
    print(f"\n{'═'*90}")
    print("  SYSTEM COMPARISON — Aggregated Metrics")
    print(f"{'═'*90}")
    metrics = ["P@k", "R@k", "F1@k", "MAP", "MRR", "nDCG@k", "R-Prec"]
    header = f"  {'System':<22}" + "".join(f"  {m:>8}" for m in metrics)
    print(header)
    print(f"  {'─'*86}")
    for er in eval_results:
        agg = er["aggregated"]
        row = f"  {er['system']:<22}" + "".join(f"  {agg[m]:>8.3f}" for m in metrics)
        print(row)


# ─────────────────────────────────────────────────────────────────────────────
# VISUALIZATIONS
# ─────────────────────────────────────────────────────────────────────────────
def plot_precision_recall_curves(eval_systems: list[tuple[str, list[list[str]]]]):
    """One subplot per query, one line per system."""
    n_queries = len(QUERIES)
    fig, axes = plt.subplots(1, n_queries, figsize=(5 * n_queries, 4), sharey=True)
    colors = ["steelblue", "darkorange", "seagreen"]
    linestyles = ["-", "--", ":"]

    for ax, query in zip(axes, QUERIES):
        rel = query["binary_relevant"]
        for (sys_name, ranked_lists), color, ls in zip(eval_systems, colors, linestyles):
            ranked = ranked_lists[QUERIES.index(query)]
            precisions, recalls = precision_recall_curve(ranked, rel)
            if recalls:
                # Interpolate: extend to recall=0 at p=1
                ax.step([0] + recalls, [1] + precisions, where="post",
                        label=sys_name, color=color, linestyle=ls, linewidth=2)
        ax.set_title(f"{query['id']}: {query['text'][:30]}...", fontsize=8)
        ax.set_xlabel("Recall", fontsize=9)
        ax.set_xlim(0, 1.05)
        ax.set_ylim(0, 1.05)
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=7)

    axes[0].set_ylabel("Precision", fontsize=10)
    fig.suptitle("Precision-Recall Curves by Query and Retrieval System",
                 fontsize=13, fontweight="bold", y=1.02)
    plt.tight_layout()
    plt.savefig("eval_pr_curves.png", dpi=150, bbox_inches="tight")
    print("  [saved] eval_pr_curves.png")
    plt.show()


def plot_metric_comparison(eval_results: list[dict]):
    """Grouped bar chart: all metrics side by side per system."""
    metrics = ["P@k", "R@k", "F1@k", "MAP", "MRR", "nDCG@k", "R-Prec"]
    n_metrics = len(metrics)
    n_systems = len(eval_results)
    x = np.arange(n_metrics)
    width = 0.25
    colors = ["steelblue", "darkorange", "seagreen"]

    fig, ax = plt.subplots(figsize=(13, 5))
    for i, (er, color) in enumerate(zip(eval_results, colors)):
        values = [er["aggregated"][m] for m in metrics]
        bars = ax.bar(x + i * width, values, width, label=er["system"], color=color, alpha=0.85)
        for bar, val in zip(bars, values):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                    f"{val:.2f}", ha="center", va="bottom", fontsize=8)

    ax.set_xticks(x + width)
    ax.set_xticklabels(metrics, fontsize=11)
    ax.set_ylabel("Score (0–1)", fontsize=11)
    ax.set_ylim(0, 1.15)
    ax.set_title("IR Evaluation Metrics — System Comparison\n(aggregated across 5 clinical queries, k=10)",
                 fontsize=12)
    ax.legend(fontsize=10)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig("eval_metric_comparison.png", dpi=150)
    print("  [saved] eval_metric_comparison.png")
    plt.show()


def plot_rank_sensitivity():
    """
    Show how MRR changes depending on where the first relevant doc appears.
    Illustrates the 1/rank dropoff — key intuition for MRR.
    """
    ranks = np.arange(1, 21)
    rr_values = 1.0 / ranks

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(ranks, rr_values, marker="o", color="steelblue", linewidth=2.5, markersize=6)
    ax.fill_between(ranks, rr_values, alpha=0.15, color="steelblue")

    for rank in [1, 2, 3, 5, 10]:
        ax.annotate(f"  rank {rank}\n  RR={1/rank:.3f}",
                    xy=(rank, 1/rank), fontsize=8, color="darkred")

    ax.set_xlabel("Rank of first relevant document", fontsize=11)
    ax.set_ylabel("Reciprocal Rank (RR)", fontsize=11)
    ax.set_title("MRR Rank Sensitivity\n"
                 "Moving the first relevant result from rank 1 to rank 3 halves the score",
                 fontsize=12)
    ax.set_xlim(0.5, 20.5)
    ax.set_ylim(0, 1.05)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("eval_mrr_sensitivity.png", dpi=150)
    print("  [saved] eval_mrr_sensitivity.png")
    plt.show()


def plot_ndcg_grade_impact():
    """
    Show how placing high-grade docs at different rank positions affects nDCG.
    Concrete example with grades [3,2,1] placed at different ranks.
    """
    grades_dict = {"A": 3, "B": 2, "C": 1}
    configs = {
        "Ideal [3,2,1] at ranks 1,2,3":    ["A", "B", "C", "X", "X"],
        "Reversed [1,2,3] at ranks 1,2,3":  ["C", "B", "A", "X", "X"],
        "Delayed: [3] at rank 3":            ["X", "X", "A", "B", "C"],
        "Delayed: [3] at rank 5":            ["X", "X", "X", "X", "A", "B", "C"],
    }
    # grades for scoring: X = irrelevant
    full_grades = {**grades_dict, "X": 0}

    k_values = list(range(1, 8))
    colors = plt.cm.Set2(np.linspace(0, 1, len(configs)))

    fig, ax = plt.subplots(figsize=(9, 5))
    for (label, ranked), color in zip(configs.items(), colors):
        ndcg_vals = [ndcg_at_k(ranked, full_grades, k) for k in k_values]
        ax.plot(k_values, ndcg_vals, marker="o", label=label, color=color, linewidth=2)

    ax.set_xlabel("k (cutoff)", fontsize=11)
    ax.set_ylabel("nDCG@k", fontsize=11)
    ax.set_title("nDCG@k — Impact of Rank Position on Graded Relevance\n"
                 "Placing the highest-grade document first maximises nDCG",
                 fontsize=12)
    ax.legend(fontsize=9)
    ax.set_ylim(0, 1.05)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("eval_ndcg_grade_impact.png", dpi=150)
    print("  [saved] eval_ndcg_grade_impact.png")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# WORKED EXAMPLE WALKTHROUGH (printed step-by-step)
# ─────────────────────────────────────────────────────────────────────────────
def print_worked_example():
    """
    Walk through every metric manually for Q1 / TF-IDF,
    so the reader can verify each formula against the numbers.
    """
    q = QUERIES[0]
    ranked = retrieve_tfidf(q["text"], top_k=len(DOCUMENTS))
    rel = q["binary_relevant"]
    grades = q["graded_relevance"]
    k = 10

    print("\n" + "═" * 70)
    print("  WORKED EXAMPLE — Q1 with TF-IDF")
    print("  Query:", q["text"])
    print("═" * 70)
    print(f"\n  Relevant docs: {sorted(rel)}")
    print(f"\n  Top-{k} ranked results:")
    for i, doc_id in enumerate(ranked[:k], start=1):
        grade = grades.get(doc_id, 0)
        marker = "✓" if doc_id in rel else " "
        bar = "█" * grade + "░" * (3 - grade)
        print(f"    Rank {i:>2}:  {doc_id}  {marker}  grade={grade} [{bar}]")

    print(f"\n  ── P@{k}: {precision_at_k(ranked, rel, k):.3f}")
    print(f"     = {sum(1 for d in ranked[:k] if d in rel)} relevant in top-{k} / {k}")

    print(f"\n  ── R@{k}: {recall_at_k(ranked, rel, k):.3f}")
    print(f"     = {sum(1 for d in ranked[:k] if d in rel)} found / {len(rel)} total relevant")

    print(f"\n  ── F1@{k}: {f1_at_k(ranked, rel, k):.3f}")
    print(f"     = 2 × P@k × R@k / (P@k + R@k)")

    print(f"\n  ── AP: {average_precision(ranked, rel):.3f}")
    hits, cumulative = 0, 0.0
    for i, doc_id in enumerate(ranked, start=1):
        if doc_id in rel:
            hits += 1
            p_at_i = hits / i
            cumulative += p_at_i
            print(f"     rank {i:>2}: '{doc_id}' → P@{i}={p_at_i:.3f}  running sum={cumulative:.3f}")
    print(f"     AP = {cumulative:.3f} / {len(rel)} = {cumulative/len(rel):.3f}")

    rr = reciprocal_rank(ranked, rel)
    first_rel_rank = next((i for i, d in enumerate(ranked, 1) if d in rel), None)
    print(f"\n  ── RR: {rr:.3f}")
    print(f"     First relevant doc '{next(d for d in ranked if d in rel)}' at rank {first_rel_rank}")
    print(f"     RR = 1 / {first_rel_rank} = {rr:.3f}")

    dcg = dcg_at_k(ranked, grades, k)
    ideal = sorted(grades.keys(), key=lambda d: grades[d], reverse=True)
    idcg = dcg_at_k(ideal, grades, k)
    print(f"\n  ── nDCG@{k}: {ndcg_at_k(ranked, grades, k):.3f}")
    print(f"     DCG@{k}  = {dcg:.3f}")
    print(f"     IDCG@{k} = {idcg:.3f}  (ideal order: {ideal[:k]})")
    print(f"     nDCG     = {dcg:.3f} / {idcg:.3f} = {dcg/idcg:.3f}")

    rp = r_precision(ranked, rel)
    R = len(rel)
    print(f"\n  ── R-Precision: {rp:.3f}")
    print(f"     R={R} (total relevant docs)")
    print(f"     {sum(1 for d in ranked[:R] if d in rel)} relevant in top-{R} / {R} = {rp:.3f}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
def main():
    K = 10

    print("=" * 90)
    print("  INFORMATION RETRIEVAL — Evaluation Metrics Demo")
    print(f"  Corpus: {len(DOCUMENTS)} clinical documents  |  Queries: {len(QUERIES)}  |  k={K}")
    print("=" * 90)

    # Build ranked lists for each system × query
    tfidf_ranked  = [retrieve_tfidf(q["text"], top_k=len(DOCUMENTS)) for q in QUERIES]
    bm25_ranked   = [retrieve_bm25(q["text"],  top_k=len(DOCUMENTS)) for q in QUERIES] if HAVE_BM25 else None
    dense_ranked  = [retrieve_mock_dense(q,    top_k=len(DOCUMENTS)) for q in QUERIES]

    # Evaluate
    tfidf_eval = evaluate_system("TF-IDF",       tfidf_ranked,  k=K)
    dense_eval = evaluate_system("Dense (mock)",  dense_ranked,  k=K)
    eval_results = [tfidf_eval, dense_eval]
    eval_systems  = [("TF-IDF", tfidf_ranked), ("Dense (mock)", dense_ranked)]

    if bm25_ranked:
        bm25_eval = evaluate_system("BM25", bm25_ranked, k=K)
        eval_results.insert(1, bm25_eval)
        eval_systems.insert(1,  ("BM25", bm25_ranked))

    # Stepped walkthrough
    print_worked_example()

    # Per-query tables
    for er in eval_results:
        print_per_query_table(er)

    # Summary comparison
    print_system_comparison(eval_results)

    # Visualizations
    print("\n── Generating visualizations ──")
    plot_precision_recall_curves(eval_systems)
    plot_metric_comparison(eval_results)
    plot_rank_sensitivity()
    plot_ndcg_grade_impact()

    print("\n" + "═" * 90)
    print("  KEY TAKEAWAYS")
    print("═" * 90)
    print("""
  1.  P@k vs R@k tradeoff:  optimising one often hurts the other.
      For systematic reviews, maximise R@k even at the cost of precision.
      For point-of-care clinical search, P@1 and P@3 matter most.

  2.  AP rewards early retrieval.  A system returning all 5 relevant docs
      at ranks 1-5 scores AP=1.0; at ranks 16-20 it scores AP≈0.07.

  3.  MRR is harsh.  If your first relevant result drops from rank 1 to rank 3,
      MRR drops from 1.0 to 0.33 — a 67% reduction for one rank shift.

  4.  nDCG captures grade AND position.  It is the right metric when you have
      "highly relevant" vs "marginally relevant" distinctions — common in
      clinical evidence grading (Grade A/B/C/D evidence levels).

  5.  MAP vs nDCG:  use MAP when relevance is binary (relevant/not-relevant).
      Use nDCG when you have graded relevance (e.g., TREC-style 0-3 grades).

  6.  R-Precision is most useful for small, bounded corpora — e.g., a
      curated database of 200 guidelines where you know exactly how many
      are relevant to each clinical question.
""")


if __name__ == "__main__":
    main()
