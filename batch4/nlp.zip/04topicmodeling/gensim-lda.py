# =============================================================================
# Latent Dirichlet Allocation (LDA) - Topic Modeling
# =============================================================================
#
# CONCEPT:
#   LDA is a generative probabilistic model that discovers hidden "topics"
#   within a collection of documents. It assumes each document is a mixture
#   of topics, and each topic is a mixture of words. For example, a news
#   article about Tesla could be 70% "technology" and 30% "economy".
#
# Note this technique is different than classification
# Classification techniques in the nlp/classification folder use labeled training data, 
# predict from predefined categories, and are explicitly designed to be compared against each other 
# as a step-by-step progression. 
# Why LDA is different:
# Unsupervised — no labels, no predefined categories. It discovers structure rather than learning to predict known classes.
# Generative / probabilistic — models how documents are produced, not how to discriminate between classes.
# Topic modeling, not classification — the output is probability distributions over latent topics, not a predicted label.
# Different toolchain — Gensim + corpora/BoW format, vs. sklearn pipelines throughout the classification series.

# HOW IT WORKS:
#   1. Each document is represented as a probability distribution over topics.
#   2. Each topic is represented as a probability distribution over words.
#   3. LDA works backwards — given observed words, it infers the latent topic
#      structure that most likely produced them, using Bayesian inference
#      (typically via Gibbs sampling or variational Bayes).
#
# KEY PARAMETERS:
#   - num_topics : How many topics to discover (set manually).
#   - passes     : Number of training passes over the corpus (more = better
#                  convergence, slower training).
#   - alpha      : Controls document-topic density (low = documents focus on
#                  fewer topics).
#   - eta (beta) : Controls topic-word density (low = topics focus on fewer
#                  words).
#
# TECHNOLOGY — Gensim:
#   This script uses the Gensim library, a Python NLP toolkit optimized for
#   topic modeling. Key Gensim components used here:
#   - corpora.Dictionary : Maps words to integer IDs.
#   - doc2bow            : Converts a document to Bag-of-Words (word ID, count)
#                          format required by LDA.
#   - LdaModel           : Trains the LDA model on the BoW corpus.
#
# STOPWORD REMOVAL (NLTK):
#   Common words like "the", "and", "is" carry no topical signal and are
#   removed before training. NLTK provides a standard English stopword list.
#   Removing them forces LDA to focus on semantically meaningful words.
#
# USE-CASE — News Article Topic Discovery:
#   This script applies LDA to a small set of news headlines spanning two
#   domains: technology (AI, Apple, Tesla) and economics (inflation, interest
#   rates, stock market). With num_topics=2, LDA is expected to separate these
#   themes automatically — without any labeling — demonstrating unsupervised
#   topic discovery. Results are visualized as word clouds, one per topic,
#   where word size reflects its probability weight within that topic.
#
# CAN LDA BE USED FOR NER (Named Entity Recognition)?
#   No — LDA cannot perform NER. NER and LDA solve fundamentally different problems:
#
#   NER asks: "Is the word 'Apple' in this sentence a company or a fruit?"
#     → Requires understanding word position, context, and entity type (PERSON,
#       ORG, LOCATION, etc.)
#
#   LDA asks: "Across this corpus, which words tend to appear together?"
#     → Has no awareness of individual words in context — it works on
#       document-level word frequency (Bag-of-Words), discarding word order
#       and sentence structure entirely.
#
#   LDA would tell you that "Apple" and "Tesla" co-occur in a technology topic,
#   but it cannot label them as organizations, distinguish them from the fruit
#   "apple", or identify where they appear in a sentence.
#
# WHAT ABOUT N-GRAMS — Does LDA gain word-order awareness?
#   Partially, but not enough for NER.
#
#   Gensim's Phrases model can detect frequent bigrams/trigrams and treat them
#   as single tokens before LDA training. For example:
#     "New York" → "New_York"   "interest rates" → "interest_rates"
#   This is done by training a Phrases model on the corpus, then applying it
#   to convert token lists before building the dictionary/corpus for LDA.
#
#   What n-grams ADD:
#   - Multi-word expressions are kept intact ("machine_learning", "New_York")
#   - Topics become more interpretable — "interest_rates" is clearer than
#     "interest" and "rates" appearing separately.
#   - Reduces ambiguity for common compound terms.
#
#   What n-grams DON'T fix:
#   - Word order is still discarded after n-gram detection. "New_York is
#     beautiful" and "beautiful New_York" produce the same BoW vector.
#   - No positional context within a sentence — LDA still sees a bag of tokens,
#     some of which happen to be multi-word.
#   - No entity type labeling — "New_York" becomes a topic feature, not a
#     LOCATION. "Apple" and "apple_pie" are still just co-occurrence signals.
#   - Cannot distinguish "Apple" (company) from "apple" (fruit) by context,
#     because sentence-level semantics are never modeled.
#
#   BOTTOM LINE: N-grams make LDA topics richer and more readable, but they
#   do not make LDA capable of NER. NER requires sentence-level positional
#   context and entity-type classification — things BoW fundamentally cannot
#   provide regardless of n-gram size.
#
# LDA vs. spaCy — Technology and Capability:
#
#   TECHNOLOGY:
#   ┌─────────────────┬────────────────────────────────────────────────────┐
#   │ LDA (Gensim)    │ spaCy                                              │
#   ├─────────────────┼────────────────────────────────────────────────────┤
#   │ Probabilistic   │ Neural network (CNN/transformer-based pipelines)   │
#   │ Bayesian model  │ Trained on annotated corpora (OntoNotes, etc.)     │
#   │ Bag-of-Words    │ Processes full sentences with token/positional ctx │
#   │ Unsupervised    │ Supervised (pre-trained or fine-tuned)             │
#   │ No word order   │ Full linguistic pipeline: tokenize → POS → NER    │
#   └─────────────────┴────────────────────────────────────────────────────┘
#
#   CAPABILITY:
#   ┌─────────────────────────────┬────────────┬────────────┐
#   │ Task                        │ LDA        │ spaCy      │
#   ├─────────────────────────────┼────────────┼────────────┤
#   │ Discover hidden topics      │ YES        │ No         │
#   │ Named Entity Recognition    │ No         │ YES        │
#   │ Part-of-speech tagging      │ No         │ YES        │
#   │ Sentence / word structure   │ No         │ YES        │
#   │ Unsupervised (no labels)    │ YES        │ No         │
#   │ Works on large corpus       │ YES        │ YES        │
#   │ Interpretable topics        │ YES        │ N/A        │
#   └─────────────────────────────┴────────────┴────────────┘
#
#   WHEN TO USE WHICH:
#   - Use LDA when you have a large collection of documents and want to
#     discover what themes exist without any labeled data.
#   - Use spaCy when you need to extract specific entities (people, orgs,
#     places, dates) from text, understand sentence grammar, or build an NLP
#     pipeline that needs linguistic structure.
#   - They are complementary: you could use spaCy to extract entities first,
#     then run LDA on the remaining content words to find themes.
#
# LDA vs. TF-IDF:
#   Both are Bag-of-Words techniques — neither models word order or sentence
#   structure. But they serve very different purposes.
#
#   TF-IDF (Term Frequency–Inverse Document Frequency):
#     - Scores how important a word is to a specific document relative to the
#       whole corpus. A word that appears often in one doc but rarely elsewhere
#       gets a high score.
#     - Output: a high-dimensional sparse vector per document (one dimension
#       per vocabulary word). The vector space can have tens of thousands of
#       dimensions for a real corpus.
#     - No latent structure — it does not group words into themes or reduce
#       dimensionality conceptually. It just re-weights raw counts.
#     - Primary uses: keyword extraction, document retrieval/search (cosine
#       similarity between TF-IDF vectors), and as input features to a
#       downstream classifier (e.g. logistic regression on TF-IDF vectors).
#
#   LDA:
#     - Discovers latent topics — groups of words that co-occur across
#       documents — and represents each document as a low-dimensional mixture
#       of those topics (e.g. 70% tech, 30% economics).
#     - Output: a short probability vector per document (length = num_topics,
#       typically 10–200), plus a word distribution per topic.
#     - Reduces dimensionality semantically — "AI", "machine_learning", and
#       "neural_network" collapse into one "tech" topic dimension.
#     - Primary uses: exploratory analysis, corpus summarization, content
#       recommendation, and surfacing hidden themes with no labeled data.
#
#   COMPARISON:
#   ┌──────────────────────────────┬─────────────────────┬──────────────────────┐
#   │ Aspect                       │ TF-IDF              │ LDA                  │
#   ├──────────────────────────────┼─────────────────────┼──────────────────────┤
#   │ Technique                    │ Statistical weighting│ Probabilistic model  │
#   │ Output per document          │ Sparse word vector  │ Topic distribution   │
#   │ Output dimensionality        │ Vocabulary size (hi)│ num_topics (low)     │
#   │ Finds latent themes          │ No                  │ YES                  │
#   │ Keyword importance           │ YES                 │ No (topic words only)│
#   │ Unsupervised                 │ YES                 │ YES                  │
#   │ Used as classifier input     │ YES (common)        │ Sometimes            │
#   │ Document retrieval / search  │ YES (core use case) │ No                   │
#   │ Interpretable themes         │ No                  │ YES                  │
#   │ Word order aware             │ No                  │ No                   │
#   └──────────────────────────────┴─────────────────────┴──────────────────────┘
#
#   WHEN TO USE WHICH:
#   - Use TF-IDF when you need to find the most distinctive keywords in a
#     document, build a search/retrieval system, or create features for a
#     supervised classifier.
#   - Use LDA when you want to understand what broad themes run through a
#     corpus without any labels — exploration and summarization at scale.
#   - They are complementary: TF-IDF filtering (dropping very common or very
#     rare words) can be applied before LDA to improve topic quality.
# =============================================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
from gensim import corpora
from gensim.models import LdaModel
from wordcloud import WordCloud

# Download NLTK stopwords (if running for the first time)
nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

# Sample documents
documents = [
    "Apple releases a new iPhone while Tesla launches an electric car.",
    "The stock market is seeing a downturn due to inflation concerns.",
    "Tesla and other automakers are focusing on electric vehicles.",
    "Technology companies like Apple and Google are investing in AI.",
    "The economy is affected by rising interest rates and inflation.",
    "AI is transforming the way companies operate and innovate.",
    "New government policies impact the automobile industry.",
    "Machine learning and AI are the future of technology."
]

# Preprocessing: Tokenization + Lowercasing + Stopword Removal
texts = [
    [word.lower() for word in doc.split() if word.lower() not in stop_words]
    for doc in documents
]

# Create a dictionary and corpus
dictionary = corpora.Dictionary(texts)
corpus = [dictionary.doc2bow(text) for text in texts]

# Train LDA model (2 topics for demonstration)
lda_model = LdaModel(corpus, num_topics=2, id2word=dictionary, passes=10, random_state=42)

# Extract topics
topics = lda_model.print_topics(num_words=5)
topics_df = pd.DataFrame({"Topic": [f"Topic {i+1}" for i in range(len(topics))], 
                          "Words": [topic[1] for topic in topics]})

# Display extracted topics
print("\nExtracted Topics:")
print(topics_df)

# Generate word clouds for topics
fig, axes = plt.subplots(1, 2, figsize=(12, 6))
for i, topic in enumerate(lda_model.show_topics(num_topics=2, num_words=10, formatted=False)):
    topic_words = dict(topic[1])
    wordcloud = WordCloud(width=400, height=400, background_color='white').generate_from_frequencies(topic_words)
    axes[i].imshow(wordcloud, interpolation='bilinear')
    axes[i].set_title(f"Topic {i+1}")
    axes[i].axis("off")

plt.show()
