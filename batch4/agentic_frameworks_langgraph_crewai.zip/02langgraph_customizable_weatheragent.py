import os
import requests
from typing import TypedDict, Annotated

from dotenv import load_dotenv
from langchain_core.tools import tool
from langchain_core.messages import BaseMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from langchain_openai import AzureChatOpenAI

load_dotenv()


# LangGraph supports a highly flexible and extensible low-level orchestration framework for 
# long-running, stateful agents, with capabilities like durable execution, streaming, human-in-the-loop,
# persistence, and custom workflows that mix deterministic and agentic steps.

# By making tools first-class citizens in the graph, and separating the concerns of reasoning and execution, 
# we can create agents that seamlessly integrate LLM reasoning with tool execution,
# and have fine-grained control over the flow of information and execution between them.
# TypedDict / StateGraph / ToolNode are all optional components that can be used to build agents in a more structured way, 

# Here, we define the components (tools, state, model) and then connect them in a graph.
# This allows for more flexible and customizable agent designs, beyond the traditional LLM + tool agent structure.
# For a more traditional agent structure, we can create a simple graph with an LLM node and a tool node, 
# and route between them based on whether the LLM calls a tool or not.
# This separation of "thinking" (LLM) and "acting" (tool calls) is a common pattern in agent design, 
# and langgraph's graph-based approach allows us to implement it in a clean and modular way.

# So with LangGraph, 
# ┌───────────────┐
# │    START      │
# └──────┬────────┘
#        │
#        v
# ┌─────────────────────────────┐
# │ 1) LLM / Assistant Node     │
# │ - read current state        │
# │ - invoke model              │
# │ - append AI response)       │
# └──────────┬──────────────────┘
#            │
#            v
# ┌─────────────────────────────┐
# │ 2) Router / Conditional Edge│
# │ - inspect last AI message   │
# │ - does it contain tool_calls?│
# └───────┬───────────────┬─────┘
#         │ yes           │ no
#         v               v
# ┌──────────────────┐   ┌───────────────┐
# │ 3) Tool Node     │   │ 5) END        │
# │ - execute tools  │   │ - final answer│
# │ - append results │   │   already in  │
# │   as ToolMessage │   │   state       │
# └────────┬─────────┘   └───────────────┘
#          │
#          v
# ┌─────────────────────────────┐
# │ 4) Edge back to LLM node    │
# │ - model sees tool results   │
# │ - may answer or call tools  │
# │   again                     │
# └──────────┬──────────────────┘
#            │
#            └──── loop to step 1
#
# ---------------------------
# 1) Tool
# ---------------------------
@tool
def get_weather(location: str) -> str:
    """
    Retrieve current weather information for a location using OpenWeatherMap.
    """
    api_key = os.getenv("OPENWEATHERMAP_API_KEY")
    if not api_key:
        return "OpenWeatherMap API key is missing."

    # Step 1: geocode location
    geo_url = "http://api.openweathermap.org/geo/1.0/direct"
    geo_resp = requests.get(
        geo_url,
        params={"q": location, "limit": 1, "appid": api_key},
        timeout=20,
    )
    geo_resp.raise_for_status()
    geo_data = geo_resp.json()

    if not geo_data:
        return f"Could not find coordinates for '{location}'."

    lat = geo_data[0]["lat"]
    lon = geo_data[0]["lon"]

    # Step 2: current weather
    weather_url = "https://api.openweathermap.org/data/3.0/onecall"
    weather_resp = requests.get(
        weather_url,
        params={"lat": lat, "lon": lon, "appid": api_key, "units": "metric"},
        timeout=20,
    )
    weather_resp.raise_for_status()
    data = weather_resp.json()

    current = data.get("current", {})
    weather_list = current.get("weather", [])
    description = weather_list[0]["description"] if weather_list else "No description"
    humidity = current.get("humidity", "NA")
    uvi = current.get("uvi", "NA")
    temp = current.get("temp", "NA")
    feels_like = current.get("feels_like", "NA")

    return (
        f"Weather for {location}: {description}. "
        f"Temperature: {temp}°C, feels like {feels_like}°C, "
        f"humidity: {humidity}%, UV index: {uvi}."
    )

tools = [get_weather]
tool_node = ToolNode(tools)

# ---------------------------
# 2) State
# ---------------------------
class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]

# ---------------------------
# 3) Model
# ---------------------------
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    temperature=0,
)

llm_with_tools = llm.bind_tools(tools)

# ---------------------------
# 4) LLM node
# ---------------------------
def assistant_node(state: AgentState):
    role = "Weather specialist"
    goal = "Provide accurate current weather answers using live tools"
    backstory = "You are a careful meteorological assistant that never invents real-time conditions"
    
    system_prompt = f"""
        Role: {role}
        Goal: {goal}
        Backstory: {backstory}
        Rules:
        - Answer only weather-related questions.
        - Use tools for live weather.
        - If the tool fails, explain the limitation clearly.
    """
    
    system_message = {
        "role": "system",
        "content": system_prompt
    }

    response = llm_with_tools.invoke(
        [system_message] + 
        state["messages"])
    
    return {"messages": [response]}

# ---------------------------
# 5) Router
# ---------------------------
def route_after_assistant(state: AgentState):
    last_message = state["messages"][-1]
    if getattr(last_message, "tool_calls", None):
        return "tools"
    return END

# ---------------------------
# 6) Graph
# ---------------------------
graph = StateGraph(AgentState)

graph.add_node("assistant", assistant_node)
graph.add_node("tools", tool_node)

graph.set_entry_point("assistant")
graph.add_conditional_edges("assistant", route_after_assistant)
graph.add_edge("tools", "assistant")

app = graph.compile()

# ---------------------------
# 7) Run
# ---------------------------
if __name__ == "__main__":
    result = app.invoke(
        {
            "messages": [
                {"role": "user", "content": "How is the weather in Mumbai?"}
            ]
        }
    )


    # The final result will contain the entire conversation history, including tool calls and responses.
    for msg in result["messages"]:
        role = msg.type.upper()

        if role == "AI" and getattr(msg, "tool_calls", None):
            tool_names = [tc["name"] for tc in msg.tool_calls]
            print(f"[AI - TOOL CALL] {tool_names}")
        elif role == "TOOL":
            tool_name = getattr(msg, "name", "unknown_tool")
            print(f"[TOOL - {tool_name}] {msg.content}")
        else:
            print(f"[{role}] {msg.content}")