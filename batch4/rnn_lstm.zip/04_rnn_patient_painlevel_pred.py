# RNN Pain Level Prediction - Healthcare Analytics
# This notebook demonstrates using RNN to classify patient pain levels from clinical notes

import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
import re
from collections import Counter
import matplotlib.pyplot as plt

# Set random seed for reproducibility
torch.manual_seed(42)
np.random.seed(42)

print("RNN Pain Level Classification Model")
print("=" * 50)

# 1. DATA PREPARATION
print("\n1. Loading and Preparing Data...")

# Patient data — pain levels intentionally match the language in each note
data = {
    'Patient_Notes': [
        # --- Original 20 rows (pain levels corrected to match note sentiment) ---
        "I feel a little better today",            # mild improvement → 3
        "The pain is unbearable",                  # unbearable → 9
        "I am feeling much better now",            # much better → 2
        "Severe pain in my back today",            # severe → 8
        "Pain has reduced significantly",          # significant reduction → 2
        "Terrible pain all over my body",          # terrible → 9
        "Slight improvement in pain",              # slight improvement from moderate → 5
        "No pain at all today",                    # no pain → 1
        "Moderate pain but manageable",            # moderate → 5
        "Excruciating pain cannot move",           # excruciating, immobile → 10
        "Pain is getting worse every day",         # worsening → 8
        "Some relief from medication",             # some relief → 3
        "Sharp shooting pain constantly",          # sharp, constant → 8
        "Much better than yesterday",              # much better → 2
        "Dull aching pain persists",               # dull but persistent → 4
        "Perfect no discomfort today",             # perfect, no discomfort → 1
        "Intense pain disrupts sleep",             # intense, sleep-disrupting → 8
        "Gradual improvement in comfort",          # gradual improvement → 3
        "Agony with every movement",               # agony → 10
        "Comfortable and pain free",               # pain free → 1
        # --- 20 new rows with variety across all pain levels ---
        "Mild soreness after physical therapy",    # mild → 3
        "Screaming in pain cannot breathe",        # screaming → 10
        "Barely any pain just slight stiffness",   # barely any → 2
        "Constant throbbing headache all day",     # throbbing → 6
        "Pain completely gone feeling great",      # completely gone → 1
        "Burning stabbing pain in chest",          # burning stabbing → 9
        "Tolerable ache manageable with pills",    # tolerable → 4
        "Joints aching badly after surgery",       # aching badly → 7
        "Feeling numb overwhelmed by pain",        # overwhelmed → 9
        "Almost recovered minor discomfort only",  # almost recovered → 2
        "Pain flaring up severely again",          # flaring severely → 8
        "Stiff in the morning but improves",       # stiff, improving → 3
        "No discomfort resting comfortably",       # no discomfort → 1
        "Cramps unbearable cannot stand up",       # unbearable cramps → 10
        "Pain reduced after adjustment today",     # reduced → 3
        "Deep aching pressure in lower back",      # deep aching → 6
        "Significant pain relief after rest",      # significant relief → 2
        "Worst pain since admission today",        # worst ever → 10
        "Feeling sore but generally improving",    # sore, improving → 4
        "Excruciating headache light sensitivity", # excruciating → 9
    ],
    'Days_Admitted': [
        # Original 20
        7, 4, 5, 3, 8, 2, 6, 10, 4, 1, 3, 7, 2, 9, 5, 12, 1, 8, 2, 11,
        # New 20
        3, 1, 9, 5, 14, 1, 6, 2, 1, 11, 3, 7, 13, 1, 5, 4, 10, 1, 6, 2,
    ],
    'Treatment_Type': [
        # Original 20
        'Surgery', 'Brain Surgery', 'Physical Therapy', 'Surgery',
        'Medication', 'Emergency', 'Surgery', 'Physical Therapy',
        'Medication', 'Emergency', 'Surgery', 'Medication',
        'Emergency', 'Physical Therapy', 'Surgery', 'Physical Therapy',
        'Emergency', 'Medication', 'Emergency', 'Physical Therapy',
        # New 20
        'Physical Therapy', 'Emergency', 'Physical Therapy', 'Medication',
        'Physical Therapy', 'Emergency', 'Medication', 'Surgery',
        'Emergency', 'Physical Therapy', 'Surgery', 'Physical Therapy',
        'Physical Therapy', 'Emergency', 'Medication', 'Surgery',
        'Medication', 'Emergency', 'Surgery', 'Brain Surgery',
    ],
    'Surgery_Done': [
        # Original 20
        'Yes', 'Yes', 'No', 'Yes', 'No', 'No', 'Yes', 'No',
        'No', 'No', 'Yes', 'No', 'No', 'No', 'Yes', 'No',
        'No', 'No', 'No', 'No',
        # New 20
        'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Yes',
        'No', 'No', 'Yes', 'No', 'No', 'No', 'No', 'Yes',
        'No', 'No', 'Yes', 'Yes',
    ],
    'Pain_Level': [
        # Original 20
        3, 9, 2, 8, 2, 9, 5, 1, 5, 10, 8, 3, 8, 2, 4, 1, 8, 3, 10, 1,
        # New 20
        3, 10, 2, 6, 1, 9, 4, 7, 9, 2, 8, 3, 1, 10, 3, 6, 2, 10, 4, 9,
    ]
}

NUM_CLASSES = 10  # Pain levels 1 through 10

df = pd.DataFrame(data)
print(f"Dataset shape: {df.shape}")
print(f"Pain level classes: {sorted(df['Pain_Level'].unique())}")
print("\nFirst few records:")
print(df.head())

# 2. TEXT PREPROCESSING
print("\n2. Text Preprocessing...")

def preprocess_text(text):
    """Clean and preprocess text data"""
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
    return text.split()

# Build vocabulary from patient notes
all_words = []
for note in df['Patient_Notes']:
    words = preprocess_text(note)
    all_words.extend(words)

vocab = Counter(all_words)
vocab_size = len(vocab)
word_to_idx = {word: i+1 for i, word in enumerate(vocab.keys())}
word_to_idx['<PAD>'] = 0  # Padding token
idx_to_word = {i: word for word, i in word_to_idx.items()}

print(f"Vocabulary size: {vocab_size + 1}")
print(f"Most common words: {vocab.most_common(5)}")

def text_to_sequence(text, max_length=10):
    """Convert text to sequence of integers"""
    words = preprocess_text(text)
    sequence = [word_to_idx.get(word, 0) for word in words]

    # Pad or truncate to max_length
    if len(sequence) < max_length:
        sequence.extend([0] * (max_length - len(sequence)))
    else:
        sequence = sequence[:max_length]

    return sequence

# Convert text to sequences
sequences = [text_to_sequence(note) for note in df['Patient_Notes']]
X_text = np.array(sequences)

# Encode categorical features
le_treatment = LabelEncoder()
le_surgery = LabelEncoder()

X_days = df['Days_Admitted'].values.reshape(-1, 1)
X_treatment = le_treatment.fit_transform(df['Treatment_Type']).reshape(-1, 1)
X_surgery = le_surgery.fit_transform(df['Surgery_Done']).reshape(-1, 1)

# Target variable: convert pain levels 1-10 to 0-indexed classes 0-9
y = df['Pain_Level'].values - 1

print(f"Text sequences shape: {X_text.shape}")
# Each sequence is a list of word INDEX numbers (integers), NOT one-hot vectors yet.
# e.g. "I feel better" → [word_to_idx['i'], word_to_idx['feel'], word_to_idx['better'], 0, 0, ...]
#                       → [3, 17, 42, 0, 0, 0, 0, 0, 0, 0]  (padded to max_length=10)
# One-hot encoding happens later inside model() call/model.forward() just before the RNN sees the data.
print(f"Sample sequence (word indices, padded to length 10): {X_text[0]}")
print(f"Class labels (0-indexed): {np.unique(y)}")

# 3. RNN MODEL DEFINITION
print("\n3. Defining RNN Model...")

class PainLevelRNN(nn.Module):
    def __init__(self, vocab_size, hidden_dim, num_classes, num_features=3):
        super(PainLevelRNN, self).__init__()

        # Text processing layers
        # Demonstrate the RNN's ability to learn patterns directly from sequences of raw integers.
        # This highlights the importance of sequence learning in RNNs
        self.rnn = nn.RNN(vocab_size, hidden_dim, batch_first=True)

        # Limitations of this approach:
        # 1. The RNN processes raw integer indices, which do not convey semantic relationships.
        # 2. Learning patterns from raw indices is computationally expensive and requires more data.
        # 3. The model may overfit to specific indices, reducing generalization to unseen data.
        # These limitations motivate the use of embeddings, which provide dense, meaningful
        # representations of words and accelerate learning.

        # Combine text features with numerical features
        self.fc1 = nn.Linear(hidden_dim + num_features, 64)
        self.fc2 = nn.Linear(64, 32)
        # Output: 10 logits, one per pain level class (1-10)
        self.fc3 = nn.Linear(32, num_classes)
        self.relu = nn.ReLU()

    def forward(self, text_seq, numerical_features):
        # text_seq arriving here: (batch, seq_len) — integers (word indices)
        # e.g. shape (32, 10) for a batch of 32 notes, each padded to 10 words
        #
        # ONE-HOT ENCODING HAPPENS HERE:
        # F.one_hot converts each integer index → a binary vector of length vocab_size
        # e.g. index 42 (vocab_size=200) → [0,0,...,1,...,0]  (1 only at position 42)
        # After one_hot: shape becomes (batch, seq_len, vocab_size) — e.g. (32, 10, 200)
        # .float() converts from int (0/1) to float32 so the RNN can do math on it.
        text_seq = torch.nn.functional.one_hot(text_seq, num_classes=self.rnn.input_size).float()
        rnn_out, _ = self.rnn(text_seq)

        # Use last hidden state
        text_features = rnn_out[:, -1, :]

        # Combine with numerical features
        combined = torch.cat([text_features, numerical_features], dim=1)

        # Pass through fully connected layers → raw logits for each class
        x = self.relu(self.fc1(combined))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)  # shape: (batch, num_classes)

        return x

# Model parameters
VOCAB_SIZE = len(word_to_idx)
HIDDEN_DIM = 32
LEARNING_RATE = 0.001
EPOCHS = 100

# Initialize model
model = PainLevelRNN(VOCAB_SIZE, HIDDEN_DIM, num_classes=NUM_CLASSES)
criterion = nn.CrossEntropyLoss()  # expects raw logits + long integer class indices
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

print(f"Model initialized with {sum(p.numel() for p in model.parameters())} parameters")

# 4. PREPARE DATA FOR TRAINING
print("\n4. Preparing Training Data...")

# Combine numerical features
X_numerical = np.concatenate([X_days, X_treatment, X_surgery], axis=1)

# Split data
X_text_train, X_text_test, X_num_train, X_num_test, y_train, y_test = train_test_split(
    X_text, X_numerical, y, test_size=0.2, random_state=42
)

# Convert to tensors
X_text_train = torch.LongTensor(X_text_train)
X_text_test = torch.LongTensor(X_text_test)
X_num_train = torch.FloatTensor(X_num_train)
X_num_test = torch.FloatTensor(X_num_test)
y_train = torch.LongTensor(y_train)   # CrossEntropyLoss requires LongTensor class indices
y_test = torch.LongTensor(y_test)

print(f"Training samples: {len(X_text_train)}")
print(f"Test samples: {len(X_text_test)}")

# 5. TRAINING LOOP
print("\n5. Training Model...")

train_losses = []

model.train()
for epoch in range(EPOCHS):
    optimizer.zero_grad()
    logits = model(X_text_train, X_num_train)   # (batch, 10)
    loss = criterion(logits, y_train)            # cross-entropy over 10 classes
    loss.backward()
    optimizer.step()
    train_losses.append(loss.item())

    if (epoch + 1) % 20 == 0:
        print(f"Epoch [{epoch+1}/{EPOCHS}], Loss: {loss.item():.4f}")

# 6. MODEL EVALUATION
print("\n6. Evaluating Model...")

def evaluate_model(y_true, y_pred, split_name=""):
    """Calculate accuracy, precision, recall, and F1 score for classification."""
    acc = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    recall = recall_score(y_true, y_pred, average='weighted', zero_division=0)
    f1 = f1_score(y_true, y_pred, average='weighted', zero_division=0)

    print(f"\n{split_name} Results:")
    print(f"  Accuracy : {acc:.2f}")
    print(f"  Precision: {precision:.2f}")
    print(f"  Recall   : {recall:.2f}")
    print(f"  F1 Score : {f1:.2f}")

model.eval()
with torch.no_grad():
    train_logits = model(X_text_train, X_num_train)
    train_pred = torch.argmax(train_logits, dim=1).numpy()   # predicted class 0-9

    test_logits = model(X_text_test, X_num_test)
    test_pred = torch.argmax(test_logits, dim=1).numpy()     # predicted class 0-9

y_train_np = y_train.numpy()
y_test_np = y_test.numpy()

evaluate_model(y_train_np, train_pred, "Training")
evaluate_model(y_test_np, test_pred, "Test")

# 7. SAMPLE PREDICTIONS
print("\n7. Sample Predictions...")

sample_indices = range(len(X_text_test))
for i in sample_indices:
    actual_class = y_test[i].item() + 1        # convert back to 1-10
    predicted_class = test_pred[i] + 1          # convert back to 1-10

    # Decode the text sequence
    text_seq = X_text_test[i].numpy()
    words = [idx_to_word.get(idx, '<UNK>') for idx in text_seq if idx != 0]
    original_text = ' '.join(words)

    print(f"\nSample {i+1}:")
    print(f"  Text: '{original_text}'")
    print(f"  Actual Pain Level   : {actual_class}")
    print(f"  Predicted Pain Level: {predicted_class}")

# 8. VISUALIZATION
print("\n8. Creating Visualizations...")

plt.figure(figsize=(12, 4))

# Plot training loss
plt.subplot(1, 2, 1)
plt.plot(train_losses)
plt.title('RNN Training Loss (Cross-Entropy)')
plt.xlabel('Epoch')
plt.ylabel('Cross-Entropy Loss')
plt.grid(True)

# Plot predicted vs actual class distribution for test set
plt.subplot(1, 2, 2)
classes = np.arange(1, NUM_CLASSES + 1)
actual_counts = np.bincount(y_test_np + 1, minlength=NUM_CLASSES + 1)[1:]
pred_counts = np.bincount(test_pred + 1, minlength=NUM_CLASSES + 1)[1:]
x = np.arange(NUM_CLASSES)
width = 0.35
plt.bar(x - width/2, actual_counts, width, label='Actual')
plt.bar(x + width/2, pred_counts, width, label='Predicted')
plt.xticks(x, classes)
plt.xlabel('Pain Level')
plt.ylabel('Count')
plt.title('Actual vs Predicted Pain Level Distribution (Test Set)')
plt.legend()
plt.grid(True, axis='y')

plt.tight_layout()
plt.show()

# 9. NEW PATIENT PREDICTION
print("\n9. Predicting for New Patients...")

def predict_new_sample(note, days, treatment, surgery):
    """Predict pain level class for a new patient"""
    model.eval()
    with torch.no_grad():
        # Process text
        text_seq = torch.LongTensor([text_to_sequence(note)])

        # Process numerical features
        treatment_encoded = le_treatment.transform([treatment])[0]
        surgery_encoded = le_surgery.transform([surgery])[0]
        num_features = torch.FloatTensor([[days, treatment_encoded, surgery_encoded]])

        logits = model(text_seq, num_features)
        predicted_class = torch.argmax(logits, dim=1).item() + 1  # convert 0-9 → 1-10
        return predicted_class

print("\nTesting with new patient notes:")
test_cases = [
    ("I feel great today no pain", 5, "Physical Therapy", "No"),
    ("Horrible pain cannot sleep", 2, "Emergency", "Yes"),
    ("Getting better slowly", 7, "Medication", "No")
]

for note, days, treatment, surgery in test_cases:
    pred = predict_new_sample(note, days, treatment, surgery)
    print(f"  Note: '{note}' -> Predicted Pain Level: {pred}")

print(f"\n{'='*50}")
print("RNN Pain Level Classification Complete!")
print("The model classifies pain into 10 discrete levels (1-10)")
print("using Cross-Entropy loss over patient notes and clinical features.")
print(f"{'='*50}")

# =============================================================================
# DESIGN DISCUSSION: WHY NOT USE RAW WORD INDICES AS RNN INPUT?
# =============================================================================
#
# A natural question: word_to_idx already assigns each word a unique integer.
# Why not feed those integers directly into the RNN instead of one-hot vectors?
#
# PROBLEM 1 — FALSE ORDERING / MAGNITUDE
#   The model treats index 500 as numerically "greater than" index 1.
#   But "cat" (idx 1) and "dog" (idx 500) have no numeric relationship —
#   the assignment is arbitrary. The RNN will try to learn that higher-indexed
#   words are "more" of something, which is meaningless noise.
#
# PROBLEM 2 — FALSE DISTANCES
#   Index arithmetic implies similarity: the model thinks words at indices
#   100 and 101 are "closer" than words at 100 and 900.
#   But "apple" and "banana" are not necessarily more similar than "apple"
#   and "fruit" — proximity in the index space is accidental.
#
# WHY ONE-HOT ENCODING FIXES THIS (used in this file via F.one_hot)
#   Every word becomes a binary vector of length vocab_size with exactly one 1.
#   The dot product between any two distinct one-hot vectors is 0, so no word
#   is artificially "closer" or "larger" than any other. The RNN learns from
#   clean, unbiased input.
#
#   Comparison:
#     Raw index  →  scalar (e.g., 42)         ← implies false order & distance
#     One-hot    →  [0, 0, ..., 1, ..., 0]    ← all words equidistant, sparse
#     Embedding  →  [0.2, -0.5, 0.8, ...]     ← dense, learns semantic meaning
#
# =============================================================================
# CURRENT LIMITATIONS OF THIS MODEL
# =============================================================================
#
# 1. ONE-HOT IS SPARSE AND HIGH-DIMENSIONAL
#    Each word is a vector of size vocab_size (≈200+ here). For real clinical
#    corpora (50,000+ words), this becomes a 50,000-dim input per time step —
#    computationally expensive and memory-heavy.
#
# 2. NO SEMANTIC SIMILARITY BETWEEN WORDS
#    One-hot treats "pain" and "agony" as equally dissimilar as "pain" and
#    "hospital". Words with related meanings get no shared representation.
#
# 3. VANILLA RNN SUFFERS FROM VANISHING GRADIENTS
#    For long notes, gradients shrink exponentially during backpropagation.
#    The model struggles to retain information from early words by the time
#    it reaches the end of a sequence.
#
# 4. VERY SMALL DATASET (40 samples)
#    Only 32 training samples. The model can easily memorise rather than
#    generalise. High train accuracy with low test accuracy is expected.
#
# 5. PAIN LEVEL IS ORDINAL, TREATED AS NOMINAL
#    CrossEntropyLoss treats all misclassifications equally. Predicting level 3
#    when the true level is 4 is penalised the same as predicting level 10.
#    An ordinal loss (e.g., MSE on the predicted class index) would be more
#    appropriate.
#
# 6. NO HANDLING OF UNKNOWN WORDS
#    New words not seen during training silently map to index 0 (<PAD>),
#    losing their meaning entirely.
#
# 7. FIXED-LENGTH TRUNCATION
#    Notes longer than max_length=10 words are cut off, potentially losing
#    the most diagnostically important parts of the note.
#
# 8. NUMERICAL FEATURES NOT NORMALISED
#    Days_Admitted is passed as raw integers alongside encoded categoricals.
#    Different scales across features can cause unstable gradients.
#
# =============================================================================
# NEXT STEPS TO IMPROVE THIS MODEL
# =============================================================================
#
# STEP 1 — REPLACE ONE-HOT WITH LEARNED EMBEDDINGS  (see 04b_rnn_patient_painlevel_embedding.py)
#    Add nn.Embedding(vocab_size, embedding_dim) as the first layer.
#    Benefits:
#      • Dense vectors (e.g., 64 dims) instead of sparse vocab_size-dim vectors
#      • Semantically similar words (pain, agony, hurt) cluster together
#      • Far fewer parameters → faster training, better generalisation
#    Example:
#      self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
#      embedded = self.embedding(text_seq)   # (batch, seq_len, embedding_dim)
#      rnn_out, _ = self.rnn(embedded)
#
# STEP 2 — UPGRADE VANILLA RNN → LSTM OR GRU
#    nn.LSTM and nn.GRU have gating mechanisms that mitigate vanishing gradients
#    and retain long-range dependencies across longer clinical notes.
#
# STEP 3 — USE A PRE-TRAINED CLINICAL EMBEDDING (BioBERT / ClinicalBERT)
#    Words like "excruciating" and "unbearable" are already close in pre-trained
#    medical embedding space. Fine-tuning on this dataset would dramatically
#    improve performance even with limited data.
#
# STEP 4 — SWITCH TO AN ORDINAL LOSS
#    Use MSE on the predicted class index, or a dedicated ordinal regression
#    loss, so that off-by-one errors are penalised less than large errors.
#
# STEP 5 — NORMALISE NUMERICAL FEATURES
#    Apply StandardScaler or MinMaxScaler to Days_Admitted before training
#    so all input features share a comparable numeric range.
#
# STEP 6 — COLLECT MORE DATA / USE DATA AUGMENTATION
#    Clinical synonym substitution (pain → discomfort), back-translation, or
#    paraphrasing can multiply the effective training set size.
#
# STEP 7 — ADD DROPOUT AND EARLY STOPPING
#    Dropout between RNN and FC layers (p=0.3–0.5) reduces overfitting.
#    Early stopping on a validation split prevents training past the best epoch.
#
# STEP 8 — BIDIRECTIONAL RNN
#    A bidirectional layer reads the note left-to-right AND right-to-left,
#    giving the model full context at every time step rather than just the past.
#      self.rnn = nn.LSTM(embedding_dim, hidden_dim, bidirectional=True, batch_first=True)
# =============================================================================
