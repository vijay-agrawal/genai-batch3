# Autonomous Medical Billing Code Team (A2A)

This project implements an autonomous multi-agent system that processes clinical notes to extract medical information and generate standardized billing codes. The system uses AutoGen to coordinate multiple AI agents that work together to understand medical text, assign proper codes, and generate structured billing reports.

## 🌟 Features

- 🤖 **Multi-agent system** using Microsoft's AutoGen framework
- 📋 **Processes unstructured clinical notes** into structured billing data
- 🏥 **Assigns ICD-10-CM codes** for diagnoses
- ⚕️ **Assigns CPT codes** for procedures
- 📊 **Generates standardized JSON** billing reports
- 🖥️ **Modern Streamlit UI** for easy interaction
- ✅ **Includes validation** and error checking
- 🎯 **Ground truth comparison** for accuracy evaluation
- 🧪 **Comprehensive test suite** with sample data

## 🎮 Quick Start

### 🚀 Launch the Application

1. **Install dependencies:**
```bash
pip install -r requirements.txt
```

2. **Set up your .env file** (see Configuration section below)

3. **Run the application:**
   - **Windows**: Double-click `start.bat`
   - **Or from terminal**: `python launch.py`
   - **Or directly**: `streamlit run app.py`

4. **Open your browser** to `http://localhost:8501`

### ✨ Features
- 🏥 **Process clinical notes** and generate ICD-10/CPT codes
- 🔍 **ICD-10 API validation** with WHO and NLM databases
- � **Sample notes** included for testing
- � **Download results** as JSON
- 🎛️ **Toggle API validation** on/off

### Option 2: Command Line Interface

```bash
python src/main.py
```

## 🖥️ Web Interface Features

The Streamlit app provides two main tabs:

### 📝 Process Note
- **Enter clinical notes** or use sample notes
- **Toggle ICD-10 API validation** on/off
- **Real-time processing** with progress feedback
- **View results** with validation status
- **Download results** as JSON

### � Sample Notes
- **Browse included sample notes** covering various medical scenarios
- **One-click copying** to processing tab
- **Easy testing** with realistic clinical data

## 📁 Project Structure

```
## ⚙️ Configuration

### Environment Variables (.env)

Create a `.env` file with:

```env
# Choose API type ('azure' or 'openai')
API_TYPE=azure

# For Azure OpenAI
AZURE_OPENAI_API_KEY=your_azure_key_here
AZURE_OPENAI_ENDPOINT=https://your-resource.cognitiveservices.azure.com/
AZURE_OPENAI_DEPLOYMENT=your_deployment_name
AZURE_OPENAI_API_VERSION=2024-02-15-preview

# For standard OpenAI
OPENAI_API_KEY=your_key_here

# WHO ICD API (Optional - for enhanced validation)
WHO_ICD_CLIENT_ID=your_who_client_id
WHO_ICD_CLIENT_SECRET=your_who_client_secret

# Other configurations
MODEL_NAME=gpt-4
TEMPERATURE=0.3
MAX_TOKENS=1000
```

### 🌍 WHO ICD API Setup (Optional but Recommended)

For enhanced code validation, you can get free WHO ICD API access:

1. **Register** at [WHO ICD API](https://icd.who.int/icdapi)
2. **Get your credentials** (Client ID and Secret)
3. **Add to .env file** as shown above
4. **Benefits**: Real-time code validation against official WHO database

### Azure OpenAI Setup

1. Create an Azure OpenAI resource
2. Deploy a GPT-4 model
3. Get your:
   - API key
   - Endpoint URL
   - Deployment name
   - API version

## 🤖 Agent Architecture

The system uses **3 specialized AI agents** in sequence:

### 🔍 Clinical Extractor
- **Role**: Information Extraction
- **Task**: Reads raw clinical notes and extracts key medical information
- **Output**: Patient demographics, symptoms, conditions, procedures

### 📋 Medical Coder
- **Role**: Code Assignment  
- **Task**: Assigns appropriate ICD-10 and CPT codes
- **Output**: Coded diagnoses and procedures

### 📊 Report Generator
- **Role**: JSON Formatting
- **Task**: Creates structured billing reports
- **Output**: Final JSON with patient info and codes

## 📋 Sample Data

The system includes **6 synthetic clinical notes** covering:

1. **Simple Respiratory Infection** - Basic diagnosis coding
2. **Minor Injury with Procedure** - Injury with treatment
3. **Chronic Condition Management** - Multiple conditions
4. **Dermatological Issue** - Skin condition
5. **Laceration Repair** - Surgical procedure
6. **Diabetic Complications** - Complex multi-condition case

## 📊 Example Output

```json
{
  "patientName": "Emily White",
  "visitDate": "2025-09-18",
  "diagnoses": [
    {
      "condition": "Acute upper respiratory infection",
      "icd10Code": "J06.9"
    }
  ],
  "procedures": [
    {
      "procedureName": "Rapid strep test",
      "cptCode": "87880"
    }
  ]
}
```

## 🔧 Installation Details

### Prerequisites
- Python 3.8+
- Azure OpenAI access OR OpenAI API key
- Modern web browser for UI

### Step-by-step Installation

1. **Clone the repository:**
```bash
git clone [repository-url]
cd a2a-medical-coder
```

2. **Create virtual environment:**
```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate
```

3. **Install dependencies:**
```bash
pip install -r requirements.txt
```

4. **Configure environment:**
   - Copy `.env.example` to `.env`
   - Fill in your API credentials

5. **Launch the application:**
```bash
streamlit run streamlit_app.py
```

## 🧪 Testing

Run the test suite:
```bash
pytest tests/
```

## 🎯 Accuracy Evaluation

The system includes ground truth data for accuracy evaluation:

- **Patient Information**: Name and date extraction
- **Diagnosis Coding**: ICD-10 code accuracy
- **Procedure Coding**: CPT code accuracy
- **Overall Accuracy**: Comprehensive scoring

## 🛠️ Technology Stack

- **AutoGen**: Multi-agent conversation framework
- **Azure OpenAI/OpenAI**: Large language models
- **Streamlit**: Web interface framework
- **Python**: Core implementation
- **Pandas**: Data manipulation
- **PyYAML**: Configuration management

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- **Microsoft AutoGen** team for the agent framework
- **OpenAI/Azure OpenAI** for language models
- **Streamlit** team for the web framework
- **Healthcare coding standards** organizations
