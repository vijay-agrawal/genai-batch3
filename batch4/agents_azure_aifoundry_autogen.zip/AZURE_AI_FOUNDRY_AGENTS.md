# Azure AI Foundry — Agents & Agentic AI

> **What is Azure AI Foundry?**
> Azure AI Foundry (formerly Azure AI Studio) is Microsoft's unified platform for building, deploying, and operating enterprise-grade AI applications and agents. Think of it as the "factory" for AI: it provides models, tools, infrastructure, governance, and developer experiences all in one place.

---

## Table of Contents

1. [The Big Picture — What is Agentic AI?](#1-the-big-picture--what-is-agentic-ai)
2. [Foundry Agent Service — The Core Runtime](#2-foundry-agent-service--the-core-runtime)
3. [Three Agent Types](#3-three-agent-types)
4. [Built-in Tools Catalog](#4-built-in-tools-catalog)
5. [Knowledge & RAG — Foundry IQ](#5-knowledge--rag--foundry-iq)
6. [Multi-Agent Orchestration](#6-multi-agent-orchestration)
7. [Microsoft Agent Framework — AutoGen + Semantic Kernel Unified](#7-microsoft-agent-framework--autogen--semantic-kernel-unified)
8. [Creating Agents via the Portal (No-Code / Low-Code)](#8-creating-agents-via-the-portal-no-code--low-code)
9. [Creating Agents via Code (Python SDK)](#9-creating-agents-via-code-python-sdk)
10. [Interoperability — A2A, MCP, OpenAPI](#10-interoperability--a2a-mcp-openapi)
11. [Security & Governance](#11-security--governance)
12. [Observability & Lifecycle](#12-observability--lifecycle)
13. [Concept Map — How Everything Fits Together](#13-concept-map--how-everything-fits-together)

---

## 1. The Big Picture — What is Agentic AI?

A traditional AI app follows a **request → response** pattern: user asks a question, the model answers, done.

An **agent** follows a **goal → plan → act → observe → repeat** loop:

```
User gives a goal
        │
        ▼
  Agent makes a plan
        │
        ▼
  Agent calls tools (search, code, APIs, other agents…)
        │
        ▼
  Agent observes results
        │
        ▼
  Agent decides: done? or loop again?
        │
        ▼
  Agent delivers final answer
```

Azure AI Foundry provides the **infrastructure, tools, frameworks, and governance** to build agents that follow this loop reliably at enterprise scale.

---

## 2. Foundry Agent Service — The Core Runtime

**Foundry Agent Service** (GA since Microsoft Build 2025) is the managed platform that hosts, runs, and scales your agents. You do not manage compute, state storage, or thread management — the service does it for you.

### What it provides out of the box

| Capability | What it means |
|---|---|
| **Managed threads & state** | Conversation history and memory are stored automatically per agent session |
| **Tool orchestration** | The agent decides when and how to call each tool (no manual wiring) |
| **Stable endpoints** | Each deployed agent gets a versioned, stable REST/SDK endpoint |
| **Built-in safety** | Prompt shields, PII detection, task adherence guardrails |
| **Entra identity per agent** | Each agent gets its own Managed Identity for secure resource access |
| **Model flexibility** | Azure OpenAI, GPT-4o, o-series reasoning models, Claude (Anthropic), Cohere, and more |
| **Model Router** | Dynamically picks the best model per request — great for cost/quality tradeoffs |

### Endpoint (API version GA: 2025-05-01)

```
https://<your-foundry-project>.services.ai.azure.com/api/projects/<project-id>
```

---

## 3. Three Agent Types

Foundry Agent Service supports three distinct agent types. Choose based on how much control vs. convenience you need.

```
┌─────────────────────────────────────────────────────────────────┐
│                     AGENT TYPES                                 │
│                                                                 │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────────┐   │
│  │    PROMPT    │   │   WORKFLOW   │   │     HOSTED       │   │
│  │    AGENT     │   │    AGENT     │   │     AGENT        │   │
│  │              │   │              │   │                  │   │
│  │ No code      │   │ Visual flow  │   │ Full code        │   │
│  │ Portal UI    │   │ + code       │   │ Any framework    │   │
│  │ Config only  │   │ Branching    │   │ Containerised    │   │
│  │              │   │ Human-loop   │   │                  │   │
│  └──────────────┘   └──────────────┘   └──────────────────┘   │
│   ↑ Easiest                                   ↑ Most flexible  │
└─────────────────────────────────────────────────────────────────┘
```

### 3.1 Prompt Agent
- Defined entirely through **configuration**: system instructions, model choice, and tools
- No code needed — create, test, and deploy entirely in the Foundry portal
- The service handles all orchestration automatically
- Best for: customer support bots, Q&A agents, assistants with fixed toolsets

### 3.2 Workflow Agent
- A **visual, no-code/low-code designer** for multi-step processes
- Supports **branching logic** (if/else), variable handling, and loops
- Supports **human-in-the-loop** steps: approvals, clarification prompts, form inputs
- Each step in the workflow can call a model, a tool, another agent, or custom logic
- Best for: approval flows, structured research pipelines, multi-step business processes

### 3.3 Hosted Agent
- Fully **code-based** agents you build using any supported framework:
  - Microsoft Agent Framework (AutoGen + Semantic Kernel)
  - LangGraph
  - Custom Python/Node.js/C# code
- Deployed as a **container** managed by Foundry Agent Service
- Exposes an OpenAI-compatible API (responses endpoint)
- Still testable in the Agents Playground and publishable to Microsoft 365
- Best for: complex reasoning loops, custom orchestration, specialised agent behaviours

---

## 4. Built-in Tools Catalog

Agents are only as powerful as the tools they can call. Foundry provides 1,000+ curated tools out of the box, plus the ability to add your own.

### 4.1 Knowledge & Data Tools

| Tool | What it does |
|---|---|
| **Foundry IQ / File Search** | Semantic search over uploaded documents (RAG) |
| **Bing Search** | Live web search grounding |
| **SharePoint** | First-party connector to Microsoft 365 document stores |
| **Microsoft Fabric** | Access enterprise data lakes and semantic models |
| **Azure Blob Storage** | Read files from Azure storage accounts |

### 4.2 Action & Automation Tools

| Tool | What it does |
|---|---|
| **Azure Logic Apps** | 1,400+ pre-built connectors to SaaS apps (Salesforce, SAP, ServiceNow…) |
| **Azure Functions** | Call custom serverless code |
| **OpenAPI Tools** | Call any REST API described by an OpenAPI 3.0 spec |
| **Code Interpreter** | Execute Python code in a sandboxed environment for data analysis, charting, maths |

### 4.3 Advanced / Specialist Tools (Preview)

| Tool | What it does |
|---|---|
| **Computer Use** | Control a computer's UI: click, type, navigate apps |
| **Browser Automation** | Real browser sessions via Playwright Workspaces (natural-language driven) |
| **Deep Research** | Multi-step research using the o3-deep-research model + Bing grounding |

### 4.4 Custom Tools
- Bring your own tool via **OpenAPI spec** (any HTTP endpoint)
- Register **Azure Functions** as tools with automatic schema detection
- Use **MCP (Model Context Protocol)** servers as tool providers (see §10)

---

## 5. Knowledge & RAG — Foundry IQ

**Foundry IQ** is Foundry's built-in Retrieval-Augmented Generation (RAG) system. Instead of building a custom pipeline, you connect a knowledge source and the service handles chunking, embedding, indexing, and retrieval.

### How Foundry IQ works (agentic retrieval)

```
User query + conversation history
           │
           ▼
    LLM analyses context
    and generates sub-queries
           │
    ┌──────┴──────┐
    ▼             ▼
Sub-query 1   Sub-query 2   (run in parallel)
    │             │
    └──────┬──────┘
           ▼
  Semantic reranking across
  all retrieved chunks
           │
           ▼
  Top-K passages → LLM → Answer with citations
```

### Supported knowledge sources
- Uploaded files (PDF, DOCX, TXT, JSON, CSV)
- SharePoint sites
- Microsoft Fabric semantic models
- Azure AI Search indexes (bring your own)
- Web (via Bing Search)

### Key benefit vs. DIY RAG
Foundry IQ is **policy-aware**: it respects the original document's Microsoft Purview sensitivity labels and Entra permissions — users can only retrieve content they are authorised to see.

---

## 6. Multi-Agent Orchestration

Complex tasks are often better handled by **multiple specialised agents** working together than one monolithic agent trying to do everything.

### Patterns supported

```
Pattern 1 — Sequential (pipeline)
──────────────────────────────────
[Research Agent] → [Analysis Agent] → [Writing Agent] → Final Output

Pattern 2 — Supervisor / Orchestrator
──────────────────────────────────────
                [Orchestrator Agent]
               /         |          \
    [Research]      [Finance]     [Legal]
    Agent            Agent         Agent

Pattern 3 — Point-to-point (agents as tools)
─────────────────────────────────────────────
Agent A can call Agent B directly as a "tool"
Agent B's output is returned as Agent A's tool result
```

### Connected Agents (Agent-as-Tool)
- Register any deployed Foundry agent as a **tool** in another agent's tool list
- The calling agent decides when to invoke the sub-agent based on the task
- Sub-agent's full reasoning and tool usage is encapsulated — the caller only sees the result

### Workflow Agents for Multi-Step Orchestration
- Use the **visual workflow designer** to wire agents together with explicit branches and loops
- Human-in-the-loop steps can pause the workflow waiting for a human approval or input before continuing

---

## 7. Microsoft Agent Framework — AutoGen + Semantic Kernel Unified

### Background
Microsoft had two major open-source agent frameworks:
- **AutoGen** — Microsoft Research project; great for multi-agent conversations and rapid prototyping
- **Semantic Kernel** — Enterprise-grade SDK; type safety, plugins, filters, telemetry, memory

In October 2025, Microsoft **unified both** into the **Microsoft Agent Framework** (public preview).

### What Microsoft Agent Framework provides

```
┌─────────────────────────────────────────────────────────────────┐
│              Microsoft Agent Framework                          │
│                                                                 │
│  From AutoGen:                  From Semantic Kernel:           │
│  • Simple agent abstractions    • Type-safe plugins/tools       │
│  • Multi-agent conversations    • Session-based state mgmt      │
│  • Group chat patterns          • Middleware & filters          │
│  • Rapid prototyping            • OpenTelemetry telemetry       │
│                                 • Extensive model support       │
│                                                                 │
│  New in Agent Framework:                                        │
│  • Graph-based workflow execution                               │
│  • Explicit multi-agent execution paths                         │
│  • Long-running & human-in-the-loop scenarios                   │
│  • First-class Foundry Agent Service integration                │
└─────────────────────────────────────────────────────────────────┘
```

### Key concepts

| Concept | Description |
|---|---|
| **Agent** | An LLM + tools + instructions, with a defined role |
| **Tool / Plugin** | A typed function the agent can call (local or remote) |
| **Workflow** | An explicit graph of agents and steps with branching and loops |
| **Thread** | A persistent conversation session with managed history |
| **Filter** | Middleware that runs before/after agent calls (logging, safety, cost) |
| **Runtime** | The execution engine — manages agent lifecycles and message routing |

### Installation

```bash
pip install microsoft-agent-framework
# or for Foundry integration:
pip install azure-ai-projects azure-identity
```

### Minimal example — single agent

```python
from agent_framework import Agent, tool
from agent_framework.models import AzureOpenAIChatModel

@tool
def get_stock_price(ticker: str) -> float:
    """Return the current price for a stock ticker."""
    ...  # call a real API

model = AzureOpenAIChatModel(
    endpoint="https://<your-project>.services.ai.azure.com/api/projects/<id>",
    api_key="<key>",
    model="gpt-4o-mini",
)

agent = Agent(
    name="StockAdvisor",
    instructions="You are a helpful stock research assistant.",
    model=model,
    tools=[get_stock_price],
)

response = agent.run("Should I buy Tata Power today?")
print(response.content)
```

### Multi-agent example — group chat (AutoGen style)

```python
from agent_framework import GroupChat, Agent

researcher = Agent(name="Researcher", instructions="Gather financial data.", model=model)
analyst    = Agent(name="Analyst",    instructions="Analyse the data.",       model=model)
advisor    = Agent(name="Advisor",    instructions="Give a recommendation.",  model=model)

chat = GroupChat(
    agents=[researcher, analyst, advisor],
    max_turns=6,
    termination_condition="RECOMMENDATION COMPLETE",
)

result = chat.run("Analyse Infosys for a 1-year investment horizon.")
print(result.summary)
```

---

## 8. Creating Agents via the Portal (No-Code / Low-Code)

### Step 1 — Open the Foundry Portal
Navigate to [ai.azure.com](https://ai.azure.com) → sign in → select your **Project**.

### Step 2 — Go to Agents
In the left navigation: **Build** → **Agents** → **+ New Agent**

### Step 3 — Configure your Prompt Agent

```
┌─────────────────────────────────────────────────────┐
│  Agent Configuration Panel                          │
│                                                     │
│  Name:         [Stock Research Assistant       ]    │
│  Model:        [gpt-4o-mini              ▼    ]    │
│  Instructions: [You are a financial analyst  ]    │
│                [focused on Indian markets.   ]    │
│                                                     │
│  Tools:        ☑ Bing Search                        │
│                ☑ File Search (upload docs here)     │
│                ☑ Code Interpreter                   │
│                ☐ Azure Logic Apps                   │
│                                                     │
│  Knowledge:    [+ Add knowledge source       ]      │
│                                                     │
└─────────────────────────────────────────────────────┘
```

### Step 4 — Test in the Playground
- Click **Test** → the **Agents Playground** opens
- Chat with the agent in natural language
- Inspect each tool call and model response in the **trace panel** on the right
- See token usage, latency, and tool invocation details per turn

### Step 5 — Evaluate (optional but recommended)
- Click **Evaluate** → upload a test dataset (question + expected answer pairs)
- Foundry runs automated evaluation metrics: groundedness, relevance, coherence, citation accuracy

### Step 6 — Publish
- Click **Publish** → the agent gets a **stable versioned endpoint**
- Optionally click **Deploy to Microsoft 365** → agent appears in Teams Chat and Copilot in one click

### Workflow Agent — Visual Designer
1. **Build** → **Agents** → **+ New Workflow Agent**
2. Drag steps onto the canvas: Model step, Tool step, Human approval step, Condition (if/else)
3. Connect steps with arrows — the execution order is the diagram
4. Add a **Condition node** to branch: e.g., "if sentiment = bearish → risk analysis step, else → growth analysis step"
5. Add a **Human Input node** for approval checkpoints
6. Test, evaluate, and publish the same way as a Prompt Agent

---

## 9. Creating Agents via Code (Python SDK)

### Installation

```bash
pip install azure-ai-projects azure-identity openai
```

### Authentication

```python
from azure.identity import DefaultAzureCredential
from azure.ai.projects import AIProjectClient

client = AIProjectClient(
    endpoint="https://<your-project>.services.ai.azure.com/api/projects/<project-id>",
    credential=DefaultAzureCredential(),
)
```

> **Tip:** The endpoint is in the Azure AI Foundry portal under **Project Settings → Overview**.  
> `DefaultAzureCredential` works with local `az login`, Managed Identity in Azure, and service principals.

### Create a Prompt Agent

```python
agent = client.agents.create_agent(
    model="gpt-4o-mini",
    name="stock-research-assistant",
    instructions=(
        "You are a financial analyst focused on Indian stock markets. "
        "Use Bing Search to find the latest news and data."
    ),
    tools=[{"type": "bing_grounding"}],       # built-in Bing Search tool
    tool_resources={
        "bing_grounding": {
            "connection_id": "<your-bing-connection-id>",
        }
    },
)
print(f"Created agent: {agent.id}")
```

### Run a conversation thread

```python
# Create a new thread (session)
thread = client.agents.threads.create()

# Add user message
client.agents.messages.create(
    thread_id=thread.id,
    role="user",
    content="Should I invest in Tata Power right now?",
)

# Run the agent on this thread
run = client.agents.runs.create_and_process(
    thread_id=thread.id,
    agent_id=agent.id,
)

# Retrieve the assistant's response
messages = client.agents.messages.list(thread_id=thread.id)
for msg in messages:
    if msg.role == "assistant":
        print(msg.content[0].text.value)
```

### Add a File Search knowledge base

```python
# Upload a file
with open("annual_report.pdf", "rb") as f:
    uploaded_file = client.agents.files.upload(file=f, purpose="assistants")

# Create a vector store (Foundry IQ index)
vector_store = client.agents.vector_stores.create_and_poll(
    name="annual-reports",
    file_ids=[uploaded_file.id],
)

# Create agent with file search tool
agent = client.agents.create_agent(
    model="gpt-4o-mini",
    name="document-analyst",
    instructions="Answer questions using the uploaded documents.",
    tools=[{"type": "file_search"}],
    tool_resources={
        "file_search": {"vector_store_ids": [vector_store.id]}
    },
)
```

### Create a Connected (Multi-Agent) setup

```python
# Agent A — research specialist
research_agent = client.agents.create_agent(
    model="gpt-4o-mini",
    name="research-agent",
    instructions="Gather and summarise financial news for a given company.",
)

# Agent B — orchestrator that calls Agent A as a tool
orchestrator = client.agents.create_agent(
    model="gpt-4o-mini",
    name="orchestrator-agent",
    instructions="Coordinate research and produce investment recommendations.",
    tools=[{
        "type": "agent",                          # connected agent as tool
        "agent_id": research_agent.id,
        "description": "Gathers financial news for a company name you provide.",
    }],
)
```

### Stream responses (real-time output)

```python
with client.agents.runs.stream(
    thread_id=thread.id,
    agent_id=agent.id,
) as stream:
    for event in stream:
        if event.type == "thread.message.delta":
            print(event.data.delta.content[0].text.value, end="", flush=True)
```

---

## 10. Interoperability — A2A, MCP, OpenAPI

Azure AI Foundry is designed for the **open agentic web** — agents from different vendors and frameworks can work together.

### Agent2Agent (A2A) Protocol
- An open protocol for agents on **different runtimes** to call each other
- A Foundry agent can call a LangGraph agent, a CrewAI agent, or an agent on a completely different cloud
- Uses a standard HTTP-based message format with capability discovery
- Enables **cross-organisation agent collaboration** without sharing model weights or infrastructure

### Model Context Protocol (MCP)
- An open standard for **tool/resource servers** that any AI client can connect to
- Foundry agents can connect to **MCP servers** as tool providers (e.g., a database MCP server, a GitHub MCP server)
- Agent identities (Entra Managed Identity) can authenticate to MCP servers hosted on Azure Functions
- Think of MCP as "USB-C for AI tools" — a standard plug that works regardless of the model or platform

### OpenAPI Tools
- Register any REST API by uploading its **OpenAPI 3.0 spec**
- Foundry auto-generates the tool schema so the agent knows what parameters to pass
- No code needed — the agent reads the spec and calls the API directly

---

## 11. Security & Governance

### Per-Agent Entra Identity
- Each agent gets its own **Microsoft Entra Managed Identity**
- The agent authenticates to resources (storage, APIs, databases) using its own identity — no shared secrets
- Permissions are scoped to what that specific agent needs (principle of least privilege)

### Network Isolation
- Agents can run inside your **Azure Virtual Network**
- Private endpoints ensure no data traverses the public internet
- Data residency requirements are met — data stays in your chosen Azure region

### Foundry Control Plane (Preview)
A centralised governance layer for all your agents:

| Guardrail | What it checks |
|---|---|
| **Task adherence** | Is the agent staying on-topic, or going off-script? |
| **Prompt shields** | Detects prompt injection attacks in user messages |
| **PII detection** | Identifies personal information in inputs and outputs |
| **Groundedness** | Is the answer supported by retrieved documents, or hallucinated? |
| **Content safety** | Filters hate, violence, self-harm, and sexual content |

### Responsible AI
- Foundry Control Plane applies guardrails consistently across all tool calls and responses
- **Spotlighting** highlights risky or suspicious content in tool responses before the model acts on it
- **Continuous red teaming** runs automated adversarial tests against your deployed agents

---

## 12. Observability & Lifecycle

### Agent Development Lifecycle

```
  Create           Test            Evaluate        Publish        Monitor
────────────   ────────────    ────────────    ────────────   ────────────
Portal UI  →  Playground  →   Auto metrics →  Versioned   →  Azure Monitor
or Code        or locally      on datasets     endpoint       + traces
```

### Tracing (OpenTelemetry)
- Every agent run emits **OpenTelemetry traces**: model calls, tool invocations, token usage, latency
- Traces are viewable in the Foundry portal or exported to Azure Monitor / Application Insights
- The **VS Code extension** shows a **real-time execution graph** as the agent runs — see which node is active, what data is flowing, and where errors occur

### Evaluation metrics (built-in)

| Metric | What it measures |
|---|---|
| Groundedness | Response supported by retrieved context |
| Relevance | Response answers the question asked |
| Coherence | Response is logically consistent |
| Fluency | Response is well-written |
| Citation accuracy | Citations correctly reference source documents |
| Task completion | Agent achieved the stated goal |

### Publishing and versioning
- Agents are published as **versioned, immutable snapshots**
- Roll back to a previous version in one click if a new version regresses
- **One-click deploy to Microsoft 365** publishes the agent to Teams Chat and Copilot

---

## 13. Concept Map — How Everything Fits Together

```
┌──────────────────────────────────────────────────────────────────────┐
│                     AZURE AI FOUNDRY                                 │
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │  PORTAL (ai.azure.com)                                        │   │
│  │  Playground │ Workflow Designer │ Evaluate │ Publish │ Monitor│   │
│  └──────────────────────────────────────────────────────────────┘   │
│                              │                                       │
│  ┌───────────────────────────▼──────────────────────────────────┐   │
│  │  FOUNDRY AGENT SERVICE  (GA — managed runtime)               │   │
│  │                                                               │   │
│  │   Prompt Agents   Workflow Agents   Hosted Agents             │   │
│  │        │               │                │                    │   │
│  │        └───────────────┼────────────────┘                    │   │
│  │                        │  threads / state / endpoints         │   │
│  └───────────────────────────────────────────────────────────────┘   │
│                              │                                       │
│  ┌──────────┬───────────────┴──────────────┬──────────────────┐     │
│  │  TOOLS   │  KNOWLEDGE (Foundry IQ)      │  FRAMEWORKS      │     │
│  │          │                              │                  │     │
│  │ Bing     │  File Search                 │ Microsoft Agent  │     │
│  │ Logic    │  SharePoint                  │ Framework        │     │
│  │ Apps     │  Fabric                      │ (AutoGen +       │     │
│  │ Code     │  Azure AI Search             │  Semantic Kernel │     │
│  │ Interp.  │  Azure Blob                  │  unified)        │     │
│  │ Computer │                              │                  │     │
│  │ Use      │  Policy-aware, citation-     │ LangGraph        │     │
│  │ Browser  │  preserving RAG              │ Custom code      │     │
│  │ MCP      │                              │                  │     │
│  └──────────┴──────────────────────────────┴──────────────────┘     │
│                                                                      │
│  ┌───────────────────────────────────────────────────────────────┐   │
│  │  GOVERNANCE & SECURITY                                        │   │
│  │  Entra Identity per agent │ VNet isolation │ Control Plane   │   │
│  │  Prompt Shields │ PII detection │ Groundedness │ Red teaming  │   │
│  └───────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  ┌───────────────────────────────────────────────────────────────┐   │
│  │  INTEROPERABILITY                                             │   │
│  │  Agent2Agent (A2A) │ Model Context Protocol (MCP) │ OpenAPI  │   │
│  └───────────────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────────────┘
          │ deploy to                        │ integrate with
          ▼                                  ▼
   Microsoft 365                    External agents,
   Teams Chat                       any cloud, any
   Copilot                          framework (via A2A)
```

---

## Quick Reference — When to use what

| Scenario | Recommended approach |
|---|---|
| Simple Q&A bot with knowledge base | Prompt Agent + Foundry IQ (Portal, no-code) |
| Multi-step approval workflow | Workflow Agent (visual designer) |
| Custom orchestration logic (loops, branching) | Hosted Agent with Agent Framework / LangGraph |
| Multi-agent system (research + analysis + write) | Connected Agents (agent-as-tool) or Agent Framework GroupChat |
| Connect to 1,400+ SaaS apps | Prompt/Workflow Agent + Azure Logic Apps tool |
| Real-time web data | Any agent + Bing Search tool |
| Data analysis / charts / maths | Any agent + Code Interpreter tool |
| Enterprise document Q&A with permissions | Foundry IQ + SharePoint connector |
| Cross-vendor agent collaboration | A2A protocol |
| Bring your own tools / APIs | OpenAPI tool or MCP server |

---

## Further Reading

- [Azure AI Foundry Documentation](https://learn.microsoft.com/en-us/azure/ai-foundry/)
- [Foundry Agent Service Overview](https://learn.microsoft.com/en-us/azure/foundry/agents/overview)
- [Quickstart — Create an Agent (Portal)](https://learn.microsoft.com/en-us/azure/ai-foundry/agents/quickstart?pivots=ai-foundry-portal)
- [Quickstart — Create an Agent (Python SDK)](https://learn.microsoft.com/en-us/azure/ai-foundry/agents/quickstart)
- [Microsoft Agent Framework Overview](https://learn.microsoft.com/en-us/agent-framework/overview/)
- [Foundry IQ Knowledge Retrieval](https://learn.microsoft.com/en-us/azure/ai-foundry/agents/how-to/tools/knowledge-retrieval?view=foundry)
- [Hosted Agents (Preview)](https://learn.microsoft.com/en-us/azure/foundry/agents/concepts/hosted-agents?view=foundry)
- [Foundry Agent Service GA Announcement](https://techcommunity.microsoft.com/blog/azure-ai-foundry-blog/announcing-general-availability-of-azure-ai-foundry-agent-service/4414352)
- [Introducing Microsoft Agent Framework](https://azure.microsoft.com/en-us/blog/introducing-microsoft-agent-framework/)
