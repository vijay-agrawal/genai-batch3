"""
Medical Code Tools for AutoGen Agents
Provides ICD-10 and CPT code lookup and validation tools
"""

from typing import Dict, List, Any
import sys
from pathlib import Path

# Add src to path for absolute imports
sys.path.append(str(Path(__file__).parent.parent))

from services.medical_code_service import MedicalCodeLookupService


class MedicalCodeTools:
    """Tools for medical code lookup and validation"""
    
    def __init__(self):
        self.code_service = MedicalCodeLookupService()
    
    def search_icd10_codes(self, condition: str) -> Dict[str, Any]:
        """
        Search for ICD-10 codes for a medical condition.
        
        Args:
            condition (str): Medical condition to search for
            
        Returns:
            Dict with search results including codes, descriptions, and sources
        """
        try:
            results = self.code_service.search_condition(condition)
            
            if not results:
                return {
                    "success": False,
                    "message": f"No ICD-10 codes found for '{condition}'",
                    "codes": []
                }
            
            codes = []
            for result in results[:3]:  # Top 3 results
                codes.append({
                    "code": result.code,
                    "description": result.description,
                    "source": result.source,
                    "category": result.category
                })
            
            return {
                "success": True,
                "message": f"Found {len(codes)} ICD-10 code(s) for '{condition}'",
                "codes": codes,
                "recommended_code": codes[0]["code"] if codes else None
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Error searching ICD-10 codes: {str(e)}",
                "codes": []
            }
    
    def search_cpt_codes(self, procedure: str) -> Dict[str, Any]:
        """
        Search for CPT codes for a medical procedure.
        
        Args:
            procedure (str): Medical procedure to search for
            
        Returns:
            Dict with search results including codes, descriptions, and sources
        """
        try:
            results = self.code_service.search_procedure(procedure)
            
            if not results:
                return {
                    "success": False,
                    "message": f"No CPT codes found for '{procedure}'",
                    "codes": []
                }
            
            codes = []
            for result in results[:3]:  # Top 3 results
                codes.append({
                    "code": result.code,
                    "description": result.description,
                    "source": result.source,
                    "category": result.category
                })
            
            return {
                "success": True,
                "message": f"Found {len(codes)} CPT code(s) for '{procedure}'",
                "codes": codes,
                "recommended_code": codes[0]["code"] if codes else None
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Error searching CPT codes: {str(e)}",
                "codes": []
            }
    
    def validate_icd10_code(self, code: str) -> Dict[str, Any]:
        """
        Validate if an ICD-10 code is valid.
        
        Args:
            code (str): ICD-10 code to validate
            
        Returns:
            Dict with validation result
        """
        try:
            is_valid = self.code_service.validate_icd10_code(code)
            
            return {
                "success": True,
                "code": code,
                "is_valid": is_valid,
                "message": f"ICD-10 code '{code}' is {'valid' if is_valid else 'invalid'}"
            }
            
        except Exception as e:
            return {
                "success": False,
                "code": code,
                "is_valid": False,
                "message": f"Error validating ICD-10 code: {str(e)}"
            }
    
    def validate_cpt_code(self, code: str) -> Dict[str, Any]:
        """
        Validate if a CPT code is valid.
        
        Args:
            code (str): CPT code to validate
            
        Returns:
            Dict with validation result
        """
        try:
            is_valid = self.code_service.validate_cpt_code(code)
            
            return {
                "success": True,
                "code": code,
                "is_valid": is_valid,
                "message": f"CPT code '{code}' is {'valid' if is_valid else 'invalid'}"
            }
            
        except Exception as e:
            return {
                "success": False,
                "code": code,
                "is_valid": False,
                "message": f"Error validating CPT code: {str(e)}"
            }


# Create the tool functions that agents can call directly
def search_icd10_codes(condition: str) -> str:
    """Search for ICD-10 codes for a medical condition"""
    tools = MedicalCodeTools()
    result = tools.search_icd10_codes(condition)
    
    if result["success"]:
        codes_str = "\n".join([f"- {c['code']}: {c['description']} (Source: {c['source']})" 
                              for c in result["codes"]])
        return f"ICD-10 codes for '{condition}':\n{codes_str}\n\nRecommended: {result['recommended_code']}"
    else:
        return f"Error: {result['message']}"


def search_cpt_codes(procedure: str) -> str:
    """Search for CPT codes for a medical procedure"""
    tools = MedicalCodeTools()
    result = tools.search_cpt_codes(procedure)
    
    if result["success"]:
        codes_str = "\n".join([f"- {c['code']}: {c['description']} (Source: {c['source']})" 
                              for c in result["codes"]])
        return f"CPT codes for '{procedure}':\n{codes_str}\n\nRecommended: {result['recommended_code']}"
    else:
        return f"Error: {result['message']}"


def validate_icd10_code(code: str) -> str:
    """Validate if an ICD-10 code is valid"""
    tools = MedicalCodeTools()
    result = tools.validate_icd10_code(code)
    return result["message"]


def validate_cpt_code(code: str) -> str:
    """Validate if a CPT code is valid"""
    tools = MedicalCodeTools()
    result = tools.validate_cpt_code(code)
    return result["message"]
