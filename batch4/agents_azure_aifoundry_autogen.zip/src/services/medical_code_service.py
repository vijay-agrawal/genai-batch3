"""
Medical Code Lookup Service
Integrates with various APIs for ICD-10 and CPT code validation
"""

import requests
import urllib3
import os
from typing import Dict, List, Optional
from dataclasses import dataclass

# Disable SSL warnings for WHO ICD API
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Disable SSL warnings for WHO ICD API
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


@dataclass
class MedicalCode:
    code: str
    description: str
    category: str
    source: str
    code_type: str  # 'ICD-10' or 'CPT'


class MedicalCodeLookupService:
    """Service for looking up ICD-10 and CPT codes from various APIs"""

    def __init__(self):
        # WHO ICD API credentials
        self.who_client_id = os.getenv("WHO_ICD_CLIENT_ID")
        self.who_client_secret = os.getenv("WHO_ICD_CLIENT_SECRET")
        self.who_token = None

    def get_who_token(self) -> str:
        """Get OAuth2 token from WHO ICD API"""
        if not self.who_client_id or not self.who_client_secret:
            return None

        token_endpoint = "https://icdaccessmanagement.who.int/connect/token"
        payload = {
            "client_id": self.who_client_id,
            "client_secret": self.who_client_secret,
            "scope": "icdapi_access",
            "grant_type": "client_credentials",
        }

        try:
            response = requests.post(token_endpoint, data=payload, verify=False)
            response.raise_for_status()
            self.who_token = response.json()["access_token"]
            return self.who_token
        except Exception as e:
            print(f"Error getting WHO token: {e}")
            return None

    def get_common_icd10_codes(self) -> Dict[str, str]:
        """Common ICD-10 codes for fallback"""
        return {
            "acute upper respiratory infection": "J06.9",
            "upper respiratory infection": "J06.9", 
            "respiratory infection": "J06.9",
            "essential hypertension": "I10",
            "hypertension": "I10",
            "diabetes": "E11.9",
            "type 2 diabetes": "E11.9",
            "diabetes mellitus": "E11.9",
            "contact dermatitis": "L23.9",
            "dermatitis": "L23.9",
            "laceration": "S81.812A",
            "abrasion": "S50.811A",
            "wound": "S01.90XA",
            "diabetes with neuropathy": "E11.40",
            "diabetic neuropathy": "E11.40"
        }

    def search_condition_fallback(self, condition: str) -> List[MedicalCode]:
        """Search for condition using common ICD-10 codes"""
        common_codes = self.get_common_icd10_codes()
        condition_lower = condition.lower()
        
        results = []
        # Look for exact or partial matches
        for key, code in common_codes.items():
            if key in condition_lower or any(word in condition_lower for word in key.split()):
                results.append(
                    MedicalCode(
                        code=code,
                        description=condition,
                        category="ICD-10-CM",
                        source="Common",
                        code_type="ICD-10"
                    )
                )
                
        return results

    def search_who_icd(self, condition: str) -> List[MedicalCode]:
        """Search WHO ICD API for condition"""
        if not self.who_token:
            if not self.get_who_token():
                return []

        search_endpoint = "https://id.who.int/icd/release/11/2024-01/mms/search"
        headers = {
            "Authorization": f"Bearer {self.who_token}",
            "Accept": "application/json",
            "API-Version": "v2",
            "Accept-Language": "en",
        }

        params = {
            "q": condition,
            "subtreeFilterUsesFoundationDescendants": "false",
            "includeKeywordResult": "true",
            "useFlexisearch": "false",
            "flatResults": "false",
        }

        try:
            response = requests.get(search_endpoint, headers=headers, params=params, verify=False)
            response.raise_for_status()
            data = response.json()

            results = []
            if "destinationEntities" in data:
                for entity in data["destinationEntities"][:5]:  # Limit to top 5
                    if "theCode" in entity and "title" in entity:
                        # Handle both string and dict formats for title
                        title = entity["title"]
                        if isinstance(title, dict):
                            description = title.get("@value", "")
                        elif isinstance(title, str):
                            description = title
                        else:
                            description = str(title)
                            
                        results.append(
                            MedicalCode(
                                code=entity["theCode"],
                                description=description,
                                category="ICD-11",
                                source="WHO",
                                code_type="ICD-10"
                            )
                        )

            return results

        except Exception as e:
            print(f"Error searching WHO ICD: {e}")
            return []

    def search_nlm_icd10(self, condition: str) -> List[MedicalCode]:
        """Search NLM Clinical Tables API for ICD-10 codes"""
        search_endpoint = "https://clinicaltables.nlm.nih.gov/api/procedures/v3/search"
        params = {
            "sf": "code,name",
            "terms": condition,
            "maxList": 5,
        }

        try:
            response = requests.get(search_endpoint, params=params)
            response.raise_for_status()
            data = response.json()

            results = []
            if len(data) >= 2 and data[1]:  # Check if results exist
                for item in data[1]:
                    if len(item) >= 2:
                        results.append(
                            MedicalCode(
                                code=item[0],
                                description=item[1],
                                category="ICD-10-CM",
                                source="NLM",
                                code_type="ICD-10"
                            )
                        )

            return results

        except Exception as e:
            print(f"Error searching NLM ICD-10: {e}")
            return []

    def search_cpt_codes(self, procedure: str) -> List[MedicalCode]:
        """
        Search for CPT codes. Since there's no reliable free CPT API, we'll use a 
        fallback approach with common CPT code patterns.
        """
        # First try common CPT code mapping for frequent procedures
        common_cpt_codes = {
            "rapid strep test": "87880",
            "strep test": "87880",
            "throat culture": "87070",
            "office visit": "99213",
            "consultation": "99243",
            "wound repair": "12001",
            "simple repair": "12001",
            "dressing": "99212",
            "bandage": "99212",
            "suture": "12001",
            "injection": "96372",
            "blood pressure": "99212",
            "examination": "99213",
        }
        
        procedure_lower = procedure.lower()
        results = []
        
        # Check for exact matches first
        for key, code in common_cpt_codes.items():
            if key in procedure_lower:
                results.append(
                    MedicalCode(
                        code=code,
                        description=f"CPT code for {procedure}",
                        category="CPT",
                        source="Common",
                        code_type="CPT"
                    )
                )
                break
        
        # Try NLM CPT search as backup (even though it may fail)
        if not results:
            try:
                # Try alternative NLM endpoint
                search_endpoint = "https://clinicaltables.nlm.nih.gov/api/procedures/v3/search"
                params = {
                    "sf": "code,name",
                    "terms": procedure,
                    "maxList": 3,
                }

                response = requests.get(search_endpoint, params=params, timeout=5)
                if response.status_code == 200:
                    data = response.json()
                    if len(data) >= 2 and data[1]:
                        for item in data[1]:
                            if len(item) >= 2:
                                results.append(
                                    MedicalCode(
                                        code=item[0],
                                        description=item[1],
                                        category="CPT",
                                        source="NLM",
                                        code_type="CPT"
                                    )
                                )
            except Exception as e:
                print(f"NLM CPT search failed: {e}")
        
        return results[:3]  # Return top 3 results

    def validate_icd10_code(self, code: str) -> bool:
        """Validate if an ICD-10 code exists"""
        # Basic format validation first
        if not self._is_valid_icd10_format(code):
            return False

        # Try to find the code in both WHO and NLM APIs
        try:
            # Search WHO ICD by code
            if self.who_token or self.get_who_token():
                who_endpoint = f"https://id.who.int/icd/release/11/2024-01/mms/codeinfo/{code}"
                headers = {
                    "Authorization": f"Bearer {self.who_token}",
                    "Accept": "application/json",
                    "API-Version": "v2",
                }
                
                response = requests.get(who_endpoint, headers=headers, verify=False)
                if response.status_code == 200:
                    return True

            # Try NLM validation
            nlm_endpoint = "https://clinicaltables.nlm.nih.gov/api/icd10cm/v3/search"
            params = {"sf": "code", "terms": code, "maxList": 1}
            
            response = requests.get(nlm_endpoint, params=params)
            if response.status_code == 200:
                data = response.json()
                if len(data) >= 2 and data[1] and len(data[1]) > 0:
                    return data[1][0][0] == code

        except Exception:
            pass

        return False

    def validate_cpt_code(self, code: str) -> bool:
        """Validate if a CPT code exists"""
        # Basic format validation
        if not self._is_valid_cpt_format(code):
            return False

        try:
            # Try NLM CPT validation
            nlm_endpoint = "https://clinicaltables.nlm.nih.gov/api/cpt/v3/search"
            params = {"sf": "code", "terms": code, "maxList": 1}
            
            response = requests.get(nlm_endpoint, params=params)
            if response.status_code == 200:
                data = response.json()
                if len(data) >= 2 and data[1] and len(data[1]) > 0:
                    return data[1][0][0] == code

        except Exception:
            pass

        return False

    def _is_valid_icd10_format(self, code: str) -> bool:
        """Check if code follows ICD-10 format"""
        import re
        # ICD-10 format: Letter + 2-3 digits + optional decimal + optional additional characters
        pattern = r'^[A-Z]\d{2,3}(\.\d*)?[A-Z]?$'
        return bool(re.match(pattern, code))

    def _is_valid_cpt_format(self, code: str) -> bool:
        """Check if code follows CPT format"""
        import re
        # CPT format: 5 digits, some ranges are valid
        pattern = r'^\d{5}$'
        if not re.match(pattern, code):
            return False
        
        # Basic range validation (CPT codes are typically 00100-99999)
        try:
            code_num = int(code)
            return 100 <= code_num <= 99999
        except ValueError:
            return False

    def search_condition(self, condition: str) -> List[MedicalCode]:
        """Search all available sources for a condition"""
        all_results = []
        
        # First try common ICD-10 codes (most reliable)
        common_results = self.search_condition_fallback(condition)
        all_results.extend(common_results)
        
        # Then search NLM ICD-10 (more reliable than WHO for US codes)
        nlm_results = self.search_nlm_icd10(condition)
        all_results.extend(nlm_results)
        
        # Finally search WHO ICD (can be inaccurate)
        who_results = self.search_who_icd(condition)
        all_results.extend(who_results)
        
        return all_results

    def search_procedure(self, procedure: str) -> List[MedicalCode]:
        """Search for procedure CPT codes"""
        return self.search_cpt_codes(procedure)

    def get_best_match(self, condition: str) -> Optional[MedicalCode]:
        """Get the best matching code for a condition"""
        results = self.search_condition(condition)
        
        if not results:
            return None
            
        # Prefer WHO results, then NLM
        who_results = [r for r in results if r.source == "WHO"]
        if who_results:
            return who_results[0]
            
        return results[0]


# Backward compatibility alias
ICDLookupService = MedicalCodeLookupService
CPTLookupService = MedicalCodeLookupService
