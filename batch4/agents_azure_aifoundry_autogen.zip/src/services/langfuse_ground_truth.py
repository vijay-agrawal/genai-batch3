"""
Langfuse Ground Truth Management
Stores and retrieves ground truth data using Langfuse
"""

import os
import json
from typing import Dict, Optional, List
from datetime import datetime


class LangfuseGroundTruthManager:
    """Manages ground truth data using Langfuse as storage backend"""
    
    def __init__(self):
        self.langfuse_api_key = os.getenv("LANGFUSE_API_KEY")
        self.langfuse_secret_key = os.getenv("LANGFUSE_SECRET_KEY")
        self.langfuse_enabled = os.getenv("LANGFUSE_ENABLED", "true").lower() == "true"
        
        # Fallback to hardcoded ground truths if Langfuse is not available
        self.fallback_ground_truths = {
            "note_01": {
                "patientName": "Emily White",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {"condition": "Acute upper respiratory infection", "icd10Code": "J06.9"}
                ],
                "procedures": [],
            },
            "note_02": {
                "patientName": "Michael Chen",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {"condition": "Abrasion, right forearm", "icd10Code": "S50.811A"}
                ],
                "procedures": [
                    {
                        "procedureName": "Application of a small sterile dressing",
                        "cptCode": "99212",
                    }
                ],
            },
            "note_03": {
                "patientName": "Linda Rodriguez",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {"condition": "Essential (primary) hypertension", "icd10Code": "I10"},
                    {
                        "condition": "Type 2 diabetes mellitus without complications",
                        "icd10Code": "E11.9",
                    },
                ],
                "procedures": [],
            },
            "note_04": {
                "patientName": "David Patel",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {
                        "condition": "Allergic contact dermatitis of hands",
                        "icd10Code": "L23.9",
                    }
                ],
                "procedures": [],
            },
            "note_05": {
                "patientName": "Sarah Jenkins",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {
                        "condition": "Laceration without foreign body, left lower leg",
                        "icd10Code": "S81.812A",
                    }
                ],
                "procedures": [
                    {
                        "procedureName": "Simple repair of superficial wound, 2.0 cm, leg",
                        "cptCode": "12001",
                    }
                ],
            },
            "note_06": {
                "patientName": "Richard Davis",
                "visitDate": "2025-09-19",
                "diagnoses": [
                    {"condition": "Essential hypertension", "icd10Code": "I10"},
                    {
                        "condition": "Type 2 diabetes mellitus with diabetic neuropathy",
                        "icd10Code": "E11.40",
                    },
                ],
                "procedures": [],
            },
        }
    
    def _init_langfuse(self):
        """Initialize Langfuse client if available"""
        if not self.langfuse_api_key or not self.langfuse_secret_key or not self.langfuse_enabled:
            return None
            
        try:
            from langfuse import Langfuse
            return Langfuse(
                public_key=self.langfuse_api_key,
                secret_key=self.langfuse_secret_key,
                # Add other Langfuse configuration as needed
            )
        except ImportError:
            print("Langfuse not installed. Using fallback ground truths.")
            return None
        except Exception as e:
            print(f"Error initializing Langfuse: {e}. Using fallback ground truths.")
            return None
    
    def get_ground_truth(self, note_id: str) -> Optional[Dict]:
        """Get ground truth for a specific note"""
        
        # Try Langfuse first
        langfuse_client = self._init_langfuse()
        if langfuse_client:
            try:
                # Search for ground truth in Langfuse datasets
                # This is a placeholder - implement based on your Langfuse setup
                ground_truth = self._get_from_langfuse(langfuse_client, note_id)
                if ground_truth:
                    return ground_truth
            except Exception as e:
                print(f"Error fetching from Langfuse: {e}")
        
        # Fallback to hardcoded ground truths
        return self.fallback_ground_truths.get(note_id)
    
    def _get_from_langfuse(self, client, note_id: str) -> Optional[Dict]:
        """Get ground truth from Langfuse dataset"""
        try:
            # This is a placeholder implementation
            # You would implement this based on how you structure your data in Langfuse
            
            # For example, you might store ground truths as dataset items:
            # datasets = client.get_datasets()
            # ground_truth_dataset = next((d for d in datasets if d.name == "medical_coding_ground_truths"), None)
            # if ground_truth_dataset:
            #     items = client.get_dataset_items(ground_truth_dataset.id)
            #     item = next((i for i in items if i.input.get("note_id") == note_id), None)
            #     if item:
            #         return item.expected_output
            
            # For now, return None to use fallback
            return None
            
        except Exception as e:
            print(f"Error accessing Langfuse dataset: {e}")
            return None
    
    def store_ground_truth(self, note_id: str, ground_truth: Dict) -> bool:
        """Store ground truth in Langfuse"""
        langfuse_client = self._init_langfuse()
        if not langfuse_client:
            print(f"Cannot store ground truth for {note_id}: Langfuse not available")
            return False
        
        try:
            # This is a placeholder implementation
            # You would implement this based on how you want to structure your data
            
            # For example:
            # client.create_dataset_item(
            #     dataset_name="medical_coding_ground_truths",
            #     input={"note_id": note_id},
            #     expected_output=ground_truth,
            #     metadata={
            #         "created_at": datetime.now().isoformat(),
            #         "version": "1.0"
            #     }
            # )
            
            print(f"Ground truth for {note_id} would be stored in Langfuse")
            return True
            
        except Exception as e:
            print(f"Error storing ground truth in Langfuse: {e}")
            return False
    
    def list_available_notes(self) -> List[str]:
        """List all available notes with ground truth"""
        langfuse_client = self._init_langfuse()
        langfuse_notes = []
        
        if langfuse_client:
            try:
                # Get notes from Langfuse
                langfuse_notes = self._list_langfuse_notes(langfuse_client)
            except Exception as e:
                print(f"Error listing Langfuse notes: {e}")
        
        # Combine with fallback notes
        all_notes = list(set(langfuse_notes + list(self.fallback_ground_truths.keys())))
        return sorted(all_notes)
    
    def _list_langfuse_notes(self, client) -> List[str]:
        """List note IDs from Langfuse"""
        try:
            # Placeholder implementation
            # You would implement this based on your Langfuse data structure
            return []
        except Exception:
            return []
    
    def update_ground_truth_with_api_codes(self, note_id: str, api_enhanced_result: Dict) -> Dict:
        """Update ground truth with API-enhanced codes for better comparison"""
        current_gt = self.get_ground_truth(note_id)
        if not current_gt:
            return {}
        
        # Create an enhanced version of ground truth using API validation
        try:
            from services.medical_code_service import MedicalCodeLookupService
            code_service = MedicalCodeLookupService()
            
            enhanced_gt = current_gt.copy()
            
            # Enhance diagnosis codes
            for diagnosis in enhanced_gt.get("diagnoses", []):
                condition = diagnosis.get("condition", "")
                api_codes = code_service.search_condition(condition)
                if api_codes:
                    # Use the best API match if it's different
                    best_match = api_codes[0]
                    diagnosis["api_suggested_code"] = best_match.code
                    diagnosis["api_description"] = best_match.description
            
            # Enhance procedure codes  
            for procedure in enhanced_gt.get("procedures", []):
                procedure_name = procedure.get("procedureName", "")
                api_codes = code_service.search_procedure(procedure_name)
                if api_codes:
                    best_match = api_codes[0]
                    procedure["api_suggested_code"] = best_match.code
                    procedure["api_description"] = best_match.description
            
            return enhanced_gt
            
        except Exception as e:
            print(f"Error enhancing ground truth with API codes: {e}")
            return current_gt
