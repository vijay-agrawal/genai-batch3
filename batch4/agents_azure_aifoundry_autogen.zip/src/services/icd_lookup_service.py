"""
Medical Code Lookup Service
Integrates with various APIs for ICD-10 and CPT code validation
"""

import requests
import os
from typing import Dict, List, Optional
from dataclasses import dataclass


@dataclass
class MedicalCode:
    code: str
    description: str
    category: str
    source: str
    code_type: str  # 'ICD-10' or 'CPT'


class MedicalCodeLookupService:
    """Service for looking up ICD-10 codes from various APIs"""

    def __init__(self):
        # WHO ICD API credentials (from environment variables)
        self.who_client_id = os.getenv("WHO_ICD_CLIENT_ID")
        self.who_client_secret = os.getenv("WHO_ICD_CLIENT_SECRET")
        self.who_token = None

    def get_who_token(self) -> str:
        """Get OAuth2 token from WHO ICD API"""
        if not self.who_client_id or not self.who_client_secret:
            return None

        token_endpoint = "https://icdaccessmanagement.who.int/connect/token"
        payload = {
            "client_id": self.who_client_id,
            "client_secret": self.who_client_secret,
            "scope": "icdapi_access",
            "grant_type": "client_credentials",
        }

        try:
            response = requests.post(token_endpoint, data=payload, verify=False)
            response.raise_for_status()
            self.who_token = response.json()["access_token"]
            return self.who_token
        except Exception as e:
            print(f"Error getting WHO token: {e}")
            return None

    def search_who_icd(self, condition: str) -> List[ICDCode]:
        """Search WHO ICD API for condition"""
        if not self.who_token:
            if not self.get_who_token():
                return []

        try:
            # Use flexisearch for natural language queries
            uri = "https://id.who.int/icd/release/11/2023-01/mms/search"
            params = {
                "q": condition,
                "subtreeFilterUsesFoundationDescendants": "false",
                "includeKeywordResult": "true",
            }

            headers = {
                "Authorization": f"Bearer {self.who_token}",
                "Accept": "application/json",
                "Accept-Language": "en",
                "API-Version": "v2",
            }

            response = requests.get(uri, headers=headers, params=params, verify=False)
            response.raise_for_status()

            results = []
            data = response.json()

            if "destinationEntities" in data:
                for entity in data["destinationEntities"][:5]:  # Top 5 results
                    code = entity.get("theCode", "")

                    # Handle different title formats (fix from test.py)
                    title_data = entity.get("title", "")
                    if isinstance(title_data, dict):
                        title = title_data.get("@value", "")
                    elif isinstance(title_data, str):
                        title = title_data
                    else:
                        title = ""

                    if code and title:  # Only add if we have both code and title
                        results.append(
                            ICDCode(
                                code=code,
                                description=title,
                                category="ICD-11",
                                source="WHO",
                            )
                        )

            return results

        except Exception as e:
            print(f"Error searching WHO ICD: {e}")
            return []

    def search_nlm_icd10(self, condition: str) -> List[ICDCode]:
        """Search NLM Clinical Tables for ICD-10 CM codes"""
        try:
            url = "https://clinicaltables.nlm.nih.gov/api/icd10cm/v3/search"
            params = {"terms": condition, "maxList": 10, "df": "code,name"}

            response = requests.get(url, params=params)
            response.raise_for_status()

            results = []
            data = response.json()

            if len(data) >= 4 and data[3]:
                for item in data[3][:5]:  # Top 5 results
                    if len(item) >= 2:
                        code = item[0]
                        description = item[1]

                        results.append(
                            ICDCode(
                                code=code,
                                description=description,
                                category="ICD-10-CM",
                                source="NLM",
                            )
                        )

            return results

        except Exception as e:
            print(f"Error searching NLM ICD-10: {e}")
            return []

    def search_condition(self, condition: str) -> List[ICDCode]:
        """Search multiple sources for ICD codes"""
        all_results = []

        # Try NLM first (faster, no auth required)
        nlm_results = self.search_nlm_icd10(condition)
        all_results.extend(nlm_results)

        # Try WHO if available
        who_results = self.search_who_icd(condition)
        all_results.extend(who_results)

        # Remove duplicates and return top results
        seen_codes = set()
        unique_results = []

        for result in all_results:
            if result.code not in seen_codes:
                seen_codes.add(result.code)
                unique_results.append(result)

                if len(unique_results) >= 5:
                    break

        return unique_results

    def get_best_match(self, condition: str) -> Optional[ICDCode]:
        """Get the best matching ICD code for a condition"""
        results = self.search_condition(condition)

        if results:
            # Return the first result (usually most relevant)
            return results[0]

        return None


# CPT Code lookup (similar structure)
class CPTLookupService:
    """Service for looking up CPT codes"""

    def __init__(self):
        pass

    def search_procedure(self, procedure: str) -> List[Dict]:
        """Search for CPT codes - would need actual CPT API access"""
        # Note: CPT codes are proprietary to AMA and require licensing
        # This is a placeholder for demonstration

        # Common CPT codes mapping for demo purposes
        common_cpt_codes = {
            "office visit": {
                "code": "99213",
                "description": "Office visit, established patient",
            },
            "new patient": {
                "code": "99202",
                "description": "Office visit, new patient",
            },
            "wound repair": {
                "code": "12001",
                "description": "Simple repair, superficial wounds",
            },
            "laceration repair": {
                "code": "12001",
                "description": "Simple repair of superficial wounds",
            },
            "suture": {
                "code": "12001",
                "description": "Simple repair of superficial wounds",
            },
            "injection": {"code": "90788", "description": "Intramuscular injection"},
            "blood draw": {
                "code": "36415",
                "description": "Collection of venous blood",
            },
            "dressing": {"code": "97597", "description": "Debridement, selective"},
        }

        procedure_lower = procedure.lower()
        for key, value in common_cpt_codes.items():
            if key in procedure_lower:
                return [value]

        return []

    def get_best_match(self, procedure: str) -> Optional[Dict]:
        """Get the best matching CPT code"""
        results = self.search_procedure(procedure)
        return results[0] if results else None
