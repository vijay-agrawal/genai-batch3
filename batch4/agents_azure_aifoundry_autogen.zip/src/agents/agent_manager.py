from typing import Dict, Any
import autogen
import sys
from pathlib import Path

# Ensure stdout can handle Unicode on Windows
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# Add src to path for absolute imports
sys.path.append(str(Path(__file__).parent.parent))

from agents.clinical_extractor import ClinicalExtractorAgent
from agents.medical_coder import MedicalCoderAgent
from agents.coding_validator import CodingValidatorAgent
from agents.report_generator import ReportGeneratorAgent


class AgentManager:
    def __init__(self, config: Dict[str, Any]):
        self.config = config

        # Configure LLM settings based on API type
        self.llm_config = self._configure_llm()

        # Create the agents with proper LLM config
        self.clinical_extractor = ClinicalExtractorAgent()
        self.clinical_extractor.llm_config = self.llm_config

        self.medical_coder = MedicalCoderAgent()
        self.medical_coder.llm_config = self.llm_config

        self.coding_validator = CodingValidatorAgent()
        self.coding_validator.llm_config = self.llm_config

        self.report_generator = ReportGeneratorAgent()
        self.report_generator.llm_config = self.llm_config

        # Create the user proxy with tool execution enabled
        self.user_proxy = autogen.UserProxyAgent(
            name="User_Proxy",
            system_message="I am a user who provides clinical notes for processing.",
            code_execution_config=False,
            function_map=self._get_function_map(),
        )

    def _configure_llm(self) -> Dict[str, Any]:
        """Configure LLM settings based on API type."""
        api_type = self.config["api"]["type"]
        temperature = self.config.get("agents", {}).get("clinical_extractor", {}).get("temperature", 0.3)
        max_tokens = self.config.get("agents", {}).get("clinical_extractor", {}).get("max_tokens", 1000)

        if api_type == "azure":
            endpoint = self.config["api"]["azure_openai"]["api_base"]
            deployment = self.config["api"]["azure_openai"]["deployment"]
            api_key = self.config["api"]["azure_openai"]["api_key"]
            api_version = self.config["api"]["azure_openai"]["api_version"]

            # Azure AI Foundry endpoints use OpenAI-compatible /v1/ path and reject api_version
            if "/v1/" in endpoint:
                base_url = endpoint.split("/v1/")[0] + "/v1/"
                config_entry = {
                    "model": deployment,
                    "api_key": api_key,
                    "base_url": base_url,
                    "api_type": "openai",
                }
            else:
                config_entry = {
                    "model": deployment,
                    "api_key": api_key,
                    "base_url": endpoint,
                    "api_type": "azure",
                    "api_version": api_version,
                }
        else:  # standard OpenAI
            config_entry = {
                "model": self.config["api"]["model"],
                "api_key": self.config["api"]["openai"]["api_key"],
            }

        return {
            "config_list": [config_entry],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

    def _get_function_map(self) -> Dict[str, Any]:
        """Get the function map for tool execution."""
        try:
            from tools.medical_code_tools import (
                search_icd10_codes,
                search_cpt_codes,
                validate_icd10_code,
                validate_cpt_code,
            )

            return {
                "search_icd10_codes": search_icd10_codes,
                "search_cpt_codes": search_cpt_codes,
                "validate_icd10_code": validate_icd10_code,
                "validate_cpt_code": validate_cpt_code,
            }
        except ImportError:
            print("Warning: Medical code tools not available")
            return {}

    def process_clinical_note(self, note_text: str) -> Dict[str, Any]:
        """Process a clinical note through the agent workflow."""

        # Initialize debug tracking
        self._debug_info = []

        def add_debug(message):
            """Add debug message to tracking"""
            self._debug_info.append(f"🔍 {message}")
            print(f"DEBUG: {message}")

        try:
            add_debug("=== STARTING AGENT PIPELINE ===")

            # Create the assistant agents
            clinical_extractor = self.clinical_extractor.create_assistant()
            medical_coder = self.medical_coder.create_assistant()
            report_generator = self.report_generator.create_assistant()

            add_debug("Created all assistant agents successfully")

            # Step 1: Clinical Extractor processes the note
            add_debug("Step 1: Clinical Extractor processing...")
            self.user_proxy.initiate_chat(
                clinical_extractor,
                message=f"""Process this clinical note and extract key medical information:

                {note_text}

                IMPORTANT: Please identify and preserve the following:
                1. Patient name (extract from "Patient:" field)
                2. Visit date (extract from "Date of Visit:" field)  
                3. All diagnoses, symptoms, and procedures
                4. Patient demographics and visit information

                Format your response to clearly include the patient name and visit date at the top.""",
                max_turns=1,
            )

            # Get the clinical extractor's response
            clinical_extract = self.user_proxy.chat_messages[clinical_extractor][-1][
                "content"
            ]
            add_debug(f"Clinical extract completed: {clinical_extract[:100]}...")

            # Step 2: Medical Coder processes the extracted information
            add_debug("Step 2: Medical Coder processing...")

            # Create the coding validator once
            coding_validator = self.coding_validator.create_assistant()
            add_debug("Created coding validator agent")

            # Validation loop - allow up to 4 revision attempts for complex cases
            max_revisions = 4  # Increased from 2 to handle complex medical cases like diabetic neuropathy
            revision_count = 0
            coding_approved = False

            add_debug(f"🔄 Starting validation loop (max {max_revisions} revisions)...")

            while not coding_approved and revision_count <= max_revisions:
                add_debug(
                    f"📝 Validation attempt {revision_count + 1}/{max_revisions + 1}"
                )

                if revision_count == 0:
                    add_debug("Initiating initial coding attempt")
                    # Initial coding attempt
                    self.user_proxy.initiate_chat(
                        medical_coder,
                        message=f"""Based on this clinical information, assign appropriate ICD-10 and CPT codes:

                        {clinical_extract}

                        IMPORTANT: 
                        1. Preserve the patient name and visit date from the clinical extraction
                        2. Provide ICD-10 codes for all diagnoses and CPT codes for all procedures  
                        3. Ensure codes are specific and follow proper guidelines
                        4. Use combination codes when appropriate (e.g., diabetes with complications)

                        Please provide your initial coding.""",
                        max_turns=1,
                    )
                else:
                    add_debug(f"Initiating revision attempt #{revision_count}")
                    # Revision attempt based on validator feedback
                    validator_feedback = self.user_proxy.chat_messages[
                        coding_validator
                    ][-1]["content"]
                    add_debug(
                        f"Using validator feedback: {validator_feedback[:100]}..."
                    )

                    self.user_proxy.initiate_chat(
                        medical_coder,
                        message=f"""Please revise your coding based on the Coding_Validator's feedback:

                        {validator_feedback}

                        Original clinical information:
                        {clinical_extract}

                        Provide your revised coding addressing all the issues raised.""",
                        max_turns=1,
                    )

                # Get the medical coder's response
                coded_info = self.user_proxy.chat_messages[medical_coder][-1]["content"]
                add_debug(
                    f"Medical coding attempt {revision_count + 1}: {coded_info[:100]}..."
                )
                add_debug(f"🔍 Full coded info preview: {coded_info[:300]}...")

                # ENHANCED DEBUG: Check for specific patterns in coded_info
                if "E11.9" in coded_info:
                    add_debug("🚨 DETECTED E11.9 in coded_info!")
                if "E11.40" in coded_info:
                    add_debug("✅ DETECTED E11.40 in coded_info!")
                if "neuropathy" in coded_info.lower():
                    add_debug("🔍 DETECTED 'neuropathy' in coded_info!")

                # Step 3: Coding Validator reviews the work
                add_debug(
                    f"Step 3: Coding Validator reviewing attempt {revision_count + 1}..."
                )

                self.user_proxy.initiate_chat(
                    coding_validator,
                    message=f"""Please review this medical coding for accuracy and completeness:

                    ORIGINAL CLINICAL NOTE:
                    {note_text}

                    CLINICAL EXTRACTION:
                    {clinical_extract}

                    MEDICAL CODING TO VALIDATE:
                    {coded_info}

                    Validate that:
                    1. All codes are specific enough
                    2. Proper combination codes are used (especially for diabetes, hypertension complications)
                    3. Manifestations are linked to underlying causes
                    4. No symptoms are coded when definitive diagnoses exist
                    5. All codes follow official guidelines

                    Respond with either "APPROVED" or "REVISION REQUIRED" with detailed feedback.""",
                    max_turns=1,
                )

                # Get validator response
                validator_response = self.user_proxy.chat_messages[coding_validator][
                    -1
                ]["content"]
                add_debug(f"Validator response: {validator_response[:100]}...")
                add_debug(f"🔍 Full validator response: {validator_response}")

                # ENHANCED: Check for specific validation patterns
                validation_passed = self._detailed_validation_check(
                    validator_response, coded_info
                )
                add_debug(f"🔍 Additional validation check result: {validation_passed}")

                # Check if coding is approved
                approved_by_validator = "APPROVED" in validator_response.upper()
                add_debug(f"🔍 Validator approval status: {approved_by_validator}")
                add_debug(f"🔍 Additional validation passed: {validation_passed}")

                # CRITICAL FIX: Additional validation check should override validator approval
                # If our detailed check finds errors, we should NOT approve regardless of validator response
                if validation_passed and approved_by_validator:
                    coding_approved = True
                    add_debug(
                        "✅ Coding approved by validator AND passed additional checks"
                    )
                elif not validation_passed:
                    # Force revision if additional validation fails, regardless of validator response
                    revision_count += 1
                    add_debug(
                        f"🚨 FORCED REVISION due to additional validation failure (attempt {revision_count}/{max_revisions})"
                    )
                    add_debug(
                        "📋 Additional validation errors detected, overriding validator approval"
                    )

                    if revision_count > max_revisions:
                        add_debug(
                            "⚠️ Maximum revisions reached, proceeding with current coding"
                        )
                        break
                elif not approved_by_validator:
                    revision_count += 1
                    add_debug(
                        f"🔄 Revision required by validator (attempt {revision_count}/{max_revisions})"
                    )
                    add_debug(f"📋 Validation issues: {validator_response[:200]}...")

                    if revision_count > max_revisions:
                        add_debug(
                            "⚠️ Maximum revisions reached, proceeding with current coding"
                        )
                        break

            add_debug(
                f"🎯 Validation loop completed. Final approval status: {coding_approved}"
            )

            # Step 4: Report Generator creates final JSON
            add_debug("Step 4: Report Generator processing...")
            self.user_proxy.initiate_chat(
                report_generator,
                message=f"""Convert this VALIDATED coded medical information into the required JSON format.

                ORIGINAL CLINICAL NOTE:
                {note_text}

                CLINICAL EXTRACTION:
                {clinical_extract}

                VALIDATED MEDICAL CODING:
                {coded_info}

                VALIDATION STATUS: {"APPROVED" if coding_approved else "PARTIAL - MAX REVISIONS REACHED"}

                IMPORTANT INSTRUCTIONS:
                1. Extract the patient name from the ORIGINAL CLINICAL NOTE (look for "Patient:" field)
                2. Extract the visit date from the ORIGINAL CLINICAL NOTE (look for "Date of Visit:" field)
                3. Use the ICD-10 and CPT codes from the VALIDATED Medical Coding section
                4. Your response must be ONLY valid JSON with NO additional text

                Example format (use REAL data from above):
                {{
                "patientName": "Emily White",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {{
                    "condition": "Actual diagnosis name",
                    "icd10Code": "Actual ICD-10 code"
                    }}
                ],
                "procedures": [
                    {{
                    "procedureName": "Actual procedure name", 
                    "cptCode": "Actual CPT code"
                    }}
                ]
                }}""",
                max_turns=1,
            )

            # Get the final JSON response
            final_response = self.user_proxy.chat_messages[report_generator][-1][
                "content"
            ]
            add_debug(f"Report generation completed: {final_response[:100]}...")

            # Extract and parse the JSON
            result = self._extract_json_from_response(final_response)

            # FINAL DEBUG CHECK
            result_str = str(result)
            if "E11.9" in result_str:
                add_debug("🚨 FINAL RESULT CONTAINS E11.9!")
            if "E11.40" in result_str:
                add_debug("✅ FINAL RESULT CONTAINS E11.40!")

            add_debug("=== AGENT PIPELINE COMPLETED ===")

            # IMPORTANT: Add debug info to result so it can be accessed by app
            if hasattr(self, "_debug_info"):
                result["_debug_trace"] = self._debug_info.copy()

            # Also store validation status for debugging
            result["_validation_status"] = {
                "coding_approved": coding_approved,
                "revision_count": revision_count,
                "max_revisions": max_revisions,
            }

            return result

        except Exception as e:
            add_debug(f"❌ Exception occurred: {str(e)}")
            return {"error": f"Processing failed: {str(e)}", "raw_response": ""}

    def _extract_json_from_response(self, response: str) -> Dict[str, Any]:
        """Extract and parse JSON from agent response."""
        try:
            import re
            import json

            # Look for JSON content in the message
            json_match = re.search(r"\{.*\}", response, re.DOTALL)
            if json_match:
                json_str = json_match.group(0)
                # Parse the JSON string to validate and return as dict
                return json.loads(json_str)
            else:
                # If no JSON found, return the raw response wrapped in a simple structure
                return {
                    "error": "No valid JSON found in response",
                    "raw_response": response,
                }
        except json.JSONDecodeError as e:
            # If JSON parsing fails, return error info
            return {"error": f"JSON parsing failed: {str(e)}", "raw_response": response}

    def _detailed_validation_check(
        self, validator_response: str, coded_info: str
    ) -> bool:
        """Additional validation check to catch common errors."""
        # Check for the specific errors we're trying to fix
        errors_found = []

        # Add debug function
        def add_debug(message):
            """Add debug message to tracking"""
            if hasattr(self, "_debug_info"):
                self._debug_info.append(f"🔍 VALIDATION: {message}")
            print(f"VALIDATION DEBUG: {message}")

        add_debug("=== STARTING DETAILED VALIDATION CHECK ===")
        add_debug(f"Checking coded_info: {coded_info[:200]}...")

        # Error 1: Both E11.9 and E11.40 present
        if "E11.9" in coded_info and "E11.40" in coded_info:
            error_msg = "Both E11.9 and E11.40 present (redundant)"
            errors_found.append(error_msg)
            add_debug(f"❌ ERROR 1: {error_msg}")

        # Error 2: Foot pain assigned E11.40
        if "foot pain" in coded_info.lower() and "E11.40" in coded_info:
            error_msg = "Foot pain incorrectly assigned E11.40"
            errors_found.append(error_msg)
            add_debug(f"❌ ERROR 2: {error_msg}")

        # Error 3: Neuropathy mentioned but E11.9 used
        if (
            "neuropathy" in coded_info.lower()
            and "E11.9" in coded_info
            and "without complications" in coded_info.lower()
        ):
            error_msg = "Neuropathy mentioned but E11.9 used"
            errors_found.append(error_msg)
            add_debug(f"❌ ERROR 3: {error_msg}")

        # Error 4: Specific pattern - neuropathy condition with E11.9 code
        if (
            "polyneuropathy" in coded_info.lower() or "neuropathy" in coded_info.lower()
        ) and "E11.9" in coded_info:
            error_msg = "Neuropathy/polyneuropathy condition incorrectly coded as E11.9 instead of E11.40"
            errors_found.append(error_msg)
            add_debug(f"❌ ERROR 4: {error_msg}")

        # Error 5: "diabetes mellitus with" conditions using E11.9
        if "diabetes mellitus with" in coded_info.lower() and "E11.9" in coded_info:
            error_msg = "Diabetes with complications incorrectly coded as E11.9"
            errors_found.append(error_msg)
            add_debug(f"❌ ERROR 5: {error_msg}")

        # Add positive checks
        if "E11.40" in coded_info and "neuropathy" in coded_info.lower():
            add_debug("✅ POSITIVE: E11.40 correctly used with neuropathy")

        if "E11.9" in coded_info and "neuropathy" not in coded_info.lower():
            add_debug(
                "✅ POSITIVE: E11.9 used without neuropathy (potentially appropriate)"
            )

        if errors_found:
            add_debug(f"🚨 TOTAL ERRORS DETECTED: {len(errors_found)}")
            for i, error in enumerate(errors_found, 1):
                add_debug(f"   {i}. {error}")
            add_debug("❌ VALIDATION FAILED - SHOULD TRIGGER REVISION")
            return False
        else:
            add_debug("✅ NO ERRORS DETECTED - VALIDATION PASSED")
            return True
