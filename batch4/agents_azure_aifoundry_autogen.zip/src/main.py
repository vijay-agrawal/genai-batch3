import os
import json
from pathlib import Path
from typing import Dict, Any
import yaml
from dotenv import load_dotenv
from agents.agent_manager import AgentManager

# Load environment variables from project root
load_dotenv(Path(__file__).parent.parent.parent / ".env", override=True)


def load_config() -> Dict[str, Any]:
    """Load configuration from YAML file and inject environment variables."""
    config_path = Path(__file__).parent / "config/config.yaml"
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found at {config_path}")

    # Read the YAML file as a string
    with open(config_path, "r") as f:
        config_str = f.read()

    # Replace environment variables
    for key, value in os.environ.items():
        config_str = config_str.replace(f"${{{key}}}", value)

    # Load the configuration with replaced values
    return yaml.safe_load(config_str)


def process_file(file_path: str, agent_manager: AgentManager) -> Dict[str, Any]:
    """Process a single clinical note file."""
    with open(file_path, "r") as f:
        note_text = f.read()
    return agent_manager.process_clinical_note(note_text)


def main():
    # Load configuration
    config = load_config()

    # Initialize agent manager
    agent_manager = AgentManager(config)

    # Process all sample notes
    notes_dir = Path("src/data/sample_notes")
    results = {}

    for note_file in sorted(notes_dir.glob("*.txt")):
        print(f"\nProcessing {note_file.name}...")
        result = process_file(str(note_file), agent_manager)
        results[note_file.name] = result

        # Save individual result
        output_file = Path("src/data/results") / f"{note_file.stem}_result.json"
        output_file.parent.mkdir(exist_ok=True)
        with open(output_file, "w") as f:
            json.dump(result, f, indent=2)

        print(f"Result saved to {output_file}")


if __name__ == "__main__":
    main()
