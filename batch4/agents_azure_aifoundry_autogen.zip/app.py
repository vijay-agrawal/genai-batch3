"""
================================================================================
Medical Coding Application — AutoGen Multi-Agent Pipeline
================================================================================

OVERVIEW
--------
A Streamlit web app that uses a multi-agent AI pipeline (built with Microsoft
AutoGen) to process physician clinical notes and produce validated ICD-10-CM
diagnosis codes and CPT procedure codes for medical billing.

================================================================================
AUTOGEN FRAMEWORK — KEY COMPONENTS USED
================================================================================

autogen.AssistantAgent
    A conversational AI agent backed by an LLM (Azure OpenAI in this project).
    Each specialist role (extractor, coder, validator, reporter) is implemented
    as an AssistantAgent with a distinct system_message and llm_config.

autogen.UserProxyAgent  (agent_manager.py → self.user_proxy)
    Acts as the human-side orchestrator. It drives all conversations by calling
    user_proxy.initiate_chat(target_agent, message=..., max_turns=1).
    It also holds a function_map so tool calls from AssistantAgents are
    executed locally (search_icd10_codes, search_cpt_codes, etc.).

BaseAgent  (src/agents/base_agent.py)
    Thin wrapper class. Stores name, system_message, llm_config, and tools.
    Its create_assistant() method instantiates and returns an
    autogen.AssistantAgent — called fresh each pipeline run.

AgentManager  (src/agents/agent_manager.py)
    Owns the pipeline orchestration logic. Reads config.yaml, builds the
    shared llm_config (Azure OpenAI or standard OpenAI), instantiates all
    BaseAgent subclasses, and runs the full processing workflow inside
    process_clinical_note().

================================================================================
THE FOUR SPECIALIST AGENTS
================================================================================

1. ClinicalExtractorAgent  (Clinical_Extractor)
   Role    : Parse the raw physician note and surface structured facts.
   Extracts: Patient name, visit date, all diagnoses/conditions (verbatim),
             and only procedures that are explicitly documented as performed.
   LLM temp: 0.1 (near-deterministic extraction, no creative additions)
   Output  : Plain-text structured block used as input for the Medical Coder.

2. MedicalCoderAgent  (Medical_Coder)
   Role    : Assign ICD-10-CM codes to diagnoses and CPT codes to procedures.
   Tools   : search_icd10_codes(), search_cpt_codes(),
             validate_icd10_code(), validate_cpt_code()
             — these call external lookup APIs and are registered in the
             UserProxyAgent's function_map for local execution.
   Rules   : Extensive system_message rules enforce correct combination-code
             logic (e.g. diabetic neuropathy → E11.40, never E11.9).
   LLM temp: 0.1  |  Max tokens: 1000
   Output  : Structured list of condition→code and procedure→code mappings.

3. CodingValidatorAgent  (Coding_Validator)
   Role    : Quality-check the Medical Coder's output against ICD-10 guidelines.
   Checks  : Redundant diabetes codes, wrong specificity (E11.9 vs E11.40),
             symptom codes overshadowed by definitive diagnoses, etc.
   Response: Either "APPROVED" or "REVISION REQUIRED" with specific instructions.
   LLM temp: 0.0 (maximum consistency — this is a rules-enforcement agent)
   Max tokens: 1500

4. ReportGeneratorAgent  (Report_Generator)
   Role    : Render the validated coding as a strict JSON document.
   Schema  : { patientName, visitDate, diagnoses[{condition, icd10Code}],
               procedures[{procedureName, cptCode}] }
   Validates: ICD-10 codes ≥ 3 chars, CPT codes exactly 5 digits.
   LLM temp: 0.1  |  Max tokens: 1000

================================================================================
FULL VISUAL PIPELINE FLOW
================================================================================

  ┌─────────────────────────────────────────────────────┐
  │  STREAMLIT UI (app.py)                              │
  │                                                     │
  │  User inputs clinical note text                     │
  │  (typed, pasted, or picked from sample_notes/ dir)  │
  └──────────────────┬──────────────────────────────────┘
                     │ clinical_note string
                     ▼
  ┌─────────────────────────────────────────────────────┐
  │  AgentManager.process_clinical_note()               │
  │                                                     │
  │  STEP 1 — EXTRACTION                                │
  │  UserProxy ──► ClinicalExtractor (max_turns=1)      │
  │       LLM reads note, extracts patient info,        │
  │       diagnoses, and performed procedures verbatim  │
  │                         │ clinical_extract (text)   │
  │                         ▼                           │
  │  STEP 2+3 — CODING + VALIDATION LOOP               │
  │  (up to 4 revision attempts)                        │
  │                                                     │
  │  ┌──────────────────────────────────────────────┐   │
  │  │ attempt 0: UserProxy ──► MedicalCoder        │   │
  │  │   (uses search/validate tools via proxy)     │   │
  │  │             │ coded_info (text)               │   │
  │  │             ▼                                 │   │
  │  │           UserProxy ──► CodingValidator       │   │
  │  │   + _detailed_validation_check() (Python)    │   │
  │  │             │                                 │   │
  │  │     APPROVED?──Yes──────────────────────────►│   │
  │  │             │No                               │   │
  │  │     revision_count += 1                       │   │
  │  │     attempt N: UserProxy ──► MedicalCoder    │   │
  │  │       (includes validator feedback)           │   │
  │  │     repeat until APPROVED or max revisions   │   │
  │  └──────────────────────────────────────────────┘   │
  │                         │ coded_info (final)         │
  │                         ▼                           │
  │  STEP 4 — JSON REPORT GENERATION                    │
  │  UserProxy ──► ReportGenerator (max_turns=1)        │
  │    produces clean JSON matching the billing schema   │
  │                         │ final_response (JSON str)  │
  │                         ▼                           │
  │  _extract_json_from_response() → result dict        │
  │  _debug_trace and _validation_status appended       │
  └──────────────────┬──────────────────────────────────┘
                     │ result dict
                     ▼
  ┌─────────────────────────────────────────────────────┐
  │  validate_with_icd_api()  — app.py                  │
  │                                                     │
  │  For every diagnosis → MedicalCodeLookupService     │
  │    .search_condition() → ranked API results         │
  │    Decides: use agent code (if API validates it) or │
  │    substitute with best API match; marks validated/  │
  │    source; appends to api_validation dict           │
  │                                                     │
  │  For every procedure → .search_procedure()          │
  │    Same logic with CPT codes                        │
  └──────────────────┬──────────────────────────────────┘
                     │ result with api_validation key
                     ▼
  ┌─────────────────────────────────────────────────────┐
  │  filter_api_validated_only()  — app.py              │
  │  Keep only codes confirmed/replaced by external API │
  └──────────────────┬──────────────────────────────────┘
                     │ filtered_result
                     ▼
  ┌─────────────────────────────────────────────────────┐
  │  STREAMLIT DISPLAY                                  │
  │                                                     │
  │  Mode A — Process Single Note                       │
  │    • Shows JSON of API-validated codes              │
  │    • Shows per-code validation status (✅/⚠️)       │
  │    • Download button for JSON result                │
  │    • Real-time debug log (pipeline trace)           │
  │                                                     │
  │  Mode B — Ground Truth Comparison                   │
  │    • Runs same pipeline on a sample note            │
  │    • Loads ground truth from Langfuse (or fallback  │
  │      hardcoded dict) for the selected note          │
  │    • compare_results() computes ICD/CPT code        │
  │      match accuracy vs ground truth                 │
  │    • Displays side-by-side JSON + accuracy metrics  │
  └─────────────────────────────────────────────────────┘

================================================================================
EXTERNAL SERVICES
================================================================================
- Azure OpenAI (or OpenAI)   : LLM backend for all four AssistantAgents
- MedicalCodeLookupService   : Wraps multiple ICD-10/CPT lookup APIs
  (src/services/medical_code_service.py)
- LangfuseGroundTruthManager : Retrieves ground-truth coding datasets
  (src/services/langfuse_ground_truth.py)
================================================================================
"""

import streamlit as st
import json
import os
import sys
import yaml
import time
import pandas as pd
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

_here = Path(__file__).resolve().parent
_search_dirs = [_here, _here.parent, _here.parent.parent]
print(f"Searching for .env in:")
for _p in _search_dirs:
    print(f"  {_p.resolve()} -> exists={(_p / '.env').exists()}")

_env_path = next((p / ".env" for p in _search_dirs if (p / ".env").exists()), None)
if _env_path is None:
    raise FileNotFoundError("No .env found within 3 levels up from app.py")
print(f"Loading .env from: {_env_path.resolve()}")
load_dotenv(_env_path, override=True)

_required_vars = ["AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_DEPLOYMENT_NAME"]
_missing = [v for v in _required_vars if not os.getenv(v)]
if _missing:
    raise EnvironmentError(f"Missing required env vars: {_missing}. Check {_env_path.resolve()}")
print(f"ENV OK: endpoint={os.getenv('AZURE_OPENAI_ENDPOINT')}, model={os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME')}")

# Add src to path
# sys.path.append(str(Path(__file__).parent / "src"))

from src.agents.agent_manager import AgentManager


def is_valid_icd10_code(code):
    """Check if an ICD-10 code is complete and valid format"""
    if not code or not isinstance(code, str):
        return False
    # Remove any whitespace
    code = code.strip()
    # ICD-10 codes should be at least 3 characters
    if len(code) < 3:
        return False
    # Basic format check: starts with letter/digit, followed by alphanumeric
    # Include both traditional (J06.9) and WHO format (1E30) codes
    import re

    return bool(re.match(r"^[A-Z0-9]\w{2,}\.?[\w]*$", code))


def is_valid_cpt_code(code):
    """Check if a CPT code is complete and valid format"""
    if not code or not isinstance(code, str):
        return False
    # Remove any whitespace
    code = code.strip()
    # CPT codes should be exactly 5 digits
    return len(code) == 5 and code.isdigit()


# Page configuration
st.set_page_config(
    page_title="AI Driven Billing Code Assistant",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS
st.markdown(
    """
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .agent-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
        border-left: 4px solid #1f77b4;
    }
    .success-box {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        border-radius: 0.25rem;
        padding: 0.75rem;
        margin: 1rem 0;
    }
    .error-box {
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        border-radius: 0.25rem;
        padding: 0.75rem;
        margin: 1rem 0;
    }
</style>
""",
    unsafe_allow_html=True,
)


APP_DIR = Path(__file__).parent


def load_config():
    """Load configuration from YAML file and inject environment variables."""
    config_path = APP_DIR / "src/config/config.yaml"
    if not config_path.exists():
        st.error(f"Configuration file not found at {config_path}")
        st.stop()

    with open(config_path, "r") as f:
        config_str = f.read()

    # Replace environment variables
    for key, value in os.environ.items():
        config_str = config_str.replace(f"${{{key}}}", value)

    return yaml.safe_load(config_str)


def initialize_agent_manager():
    """Initialize the agent manager."""
    try:
        config = load_config()
        return AgentManager(config)
    except Exception as e:
        st.error(f"Failed to initialize agent manager: {str(e)}")
        st.stop()


def load_sample_notes():
    """Load all sample notes from the data directory."""
    notes_dir = APP_DIR / "src/data/sample_notes"
    sample_notes = {}

    if notes_dir.exists():
        for note_file in sorted(notes_dir.glob("*.txt")):
            with open(note_file, "r", encoding="utf-8") as f:
                sample_notes[note_file.stem] = f.read()

    return sample_notes


def load_ground_truth():
    """Load ground truth data using Langfuse (with fallback to hardcoded data)"""
    try:
        from src.services.langfuse_ground_truth import LangfuseGroundTruthManager

        return LangfuseGroundTruthManager()
    except Exception as e:
        st.warning(f"Could not initialize Langfuse ground truth manager: {e}")
        # Return hardcoded ground truth as fallback
        return {
            "note_01": {
                "patientName": "Emily White",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {
                        "condition": "Acute upper respiratory infection",
                        "icd10Code": "J06.9",
                    }
                ],
                "procedures": [],
            },
            "note_02": {
                "patientName": "Michael Chen",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {"condition": "Abrasion, right forearm", "icd10Code": "S50.811A"}
                ],
                "procedures": [
                    {
                        "procedureName": "Application of a small sterile dressing",
                        "cptCode": "99212",
                    }
                ],
            },
            "note_03": {
                "patientName": "Linda Rodriguez",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {
                        "condition": "Essential (primary) hypertension",
                        "icd10Code": "I10",
                    },
                    {
                        "condition": "Type 2 diabetes mellitus without complications",
                        "icd10Code": "E11.9",
                    },
                ],
                "procedures": [],
            },
            "note_04": {
                "patientName": "David Patel",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {
                        "condition": "Allergic contact dermatitis of hands",
                        "icd10Code": "L23.9",
                    }
                ],
                "procedures": [],
            },
            "note_05": {
                "patientName": "Sarah Jenkins",
                "visitDate": "2025-09-18",
                "diagnoses": [
                    {
                        "condition": "Laceration without foreign body, left lower leg",
                        "icd10Code": "S81.812A",
                    }
                ],
                "procedures": [
                    {
                        "procedureName": "Simple repair of superficial wound, 2.0 cm, leg",
                        "cptCode": "12001",
                    }
                ],
            },
            "note_06": {
                "patientName": "Richard Davis",
                "visitDate": "2025-09-19",
                "diagnoses": [
                    {"condition": "Essential hypertension", "icd10Code": "I10"},
                    {
                        "condition": "Type 2 diabetes mellitus with diabetic neuropathy",
                        "icd10Code": "E11.40",
                    },
                ],
                "procedures": [],
            },
        }


def validate_with_icd_api(result, use_api_validation):
    """Add comprehensive medical code validation and replace with API codes when available"""
    if not use_api_validation or "error" in result:
        return result

    # IMPORTANT: Preserve debug information from agent processing
    debug_trace = result.get("_debug_trace", [])
    validation_status = result.get("_validation_status", {})

    try:
        from src.services.medical_code_service import MedicalCodeLookupService

        code_service = MedicalCodeLookupService()

        validation_info = {"diagnoses": [], "procedures": []}

        # Process and validate diagnoses with ICD-10 codes
        updated_diagnoses = []
        for diagnosis in result.get("diagnoses", []):
            condition = diagnosis.get("condition", "")
            agent_icd_code = diagnosis.get("icd10Code", "")

            # Search for the best matching code from APIs
            api_codes = code_service.search_condition(condition)
            best_api_match = None
            validated = False

            if api_codes:
                # Find the best matching code - prefer ground truth if available
                best_api_match = api_codes[0]  # Top result from API
                validated = False

                # Check if agent's code matches any API result for validation tracking
                for api_code in api_codes:
                    if api_code.code == agent_icd_code:
                        validated = True
                        best_api_match = api_code  # Use the matching code
                        break

                # Decide which code to use based on validation and quality
                if validated and is_valid_icd10_code(agent_icd_code):
                    # Agent code is validated by API, use it
                    final_code = agent_icd_code
                elif is_valid_icd10_code(best_api_match.code):
                    # Use API code if it's valid
                    final_code = best_api_match.code
                else:
                    # Fallback to agent code if API code is invalid
                    final_code = agent_icd_code

                final_condition = condition  # Keep original condition name

                # Add to updated diagnoses only if we have API validation
                if is_valid_icd10_code(final_code) and best_api_match:
                    updated_diagnoses.append(
                        {
                            "condition": final_condition,
                            "icd10Code": final_code,
                            "validated": validated,
                            "source": best_api_match.source
                            if best_api_match
                            else "Agent",
                        }
                    )

                validation_info["diagnoses"].append(
                    {
                        "condition": condition,
                        "agent_code": agent_icd_code,
                        "api_code": best_api_match.code if best_api_match else None,
                        "final_code": final_code,
                        "validated": validated,
                        "source": best_api_match.source if best_api_match else "Agent",
                        "api_description": best_api_match.description
                        if best_api_match
                        else None,
                        "code_replaced": best_api_match.code != agent_icd_code
                        if best_api_match
                        else False,
                    }
                )
            else:
                # No API results, don't include in final result (API-only approach)
                # Just track in validation info
                validation_info["diagnoses"].append(
                    {
                        "condition": condition,
                        "agent_code": agent_icd_code,
                        "api_code": None,
                        "final_code": "NO_API_VALIDATION",
                        "validated": False,
                        "source": "Agent",
                        "code_replaced": False,
                    }
                )

        # Process and validate procedures with CPT codes
        updated_procedures = []
        for procedure in result.get("procedures", []):
            procedure_name = procedure.get("procedureName", "")
            agent_cpt_code = procedure.get("cptCode", "")

            # Search for the best matching CPT code from APIs
            api_codes = code_service.search_procedure(procedure_name)
            best_api_match = None
            validated = False

            if api_codes:
                # Always prioritize API codes - use the best match from API
                best_api_match = api_codes[0]  # Top result from API

                # Check if agent's code matches any API result for validation tracking
                for api_code in api_codes:
                    if api_code.code == agent_cpt_code:
                        validated = True
                        best_api_match = api_code  # Use the matching code
                        break

                # Decide which code to use based on validation and quality
                if validated and is_valid_cpt_code(agent_cpt_code):
                    # Agent code is validated by API, use it
                    final_code = agent_cpt_code
                elif is_valid_cpt_code(best_api_match.code):
                    # Use API code if it's valid
                    final_code = best_api_match.code
                else:
                    # Fallback to agent code if API code is invalid
                    final_code = agent_cpt_code

                # Add to updated procedures only if we have API validation
                if is_valid_cpt_code(final_code) and best_api_match:
                    updated_procedures.append(
                        {
                            "procedureName": procedure_name,
                            "cptCode": final_code,
                            "validated": validated,
                            "source": best_api_match.source
                            if best_api_match
                            else "Agent",
                        }
                    )

                validation_info["procedures"].append(
                    {
                        "procedureName": procedure_name,
                        "agent_code": agent_cpt_code,
                        "api_code": best_api_match.code if best_api_match else None,
                        "final_code": final_code,
                        "validated": validated,
                        "source": best_api_match.source if best_api_match else "Agent",
                        "api_description": best_api_match.description
                        if best_api_match
                        else None,
                        "code_replaced": best_api_match.code != agent_cpt_code
                        if best_api_match
                        else False,
                    }
                )
            else:
                # No API results, don't include in final result (API-only approach)
                # Just track in validation info
                validation_info["procedures"].append(
                    {
                        "procedureName": procedure_name,
                        "agent_code": agent_cpt_code,
                        "api_code": None,
                        "final_code": "NO_API_VALIDATION",
                        "validated": False,
                        "source": "Agent",
                        "code_replaced": False,
                    }
                )

        # Update the result with API-enhanced codes
        result["diagnoses"] = updated_diagnoses
        result["procedures"] = updated_procedures
        result["api_validation"] = validation_info

        # IMPORTANT: Restore debug information that was preserved
        if debug_trace:
            result["_debug_trace"] = debug_trace
        if validation_status:
            result["_validation_status"] = validation_status

    except Exception as e:
        st.warning(f"API validation failed: {str(e)}")

    return result


def compare_results(predicted, ground_truth):
    """Compare predicted results with ground truth focusing on CODE MATCHING."""
    if not ground_truth:
        return {
            "status": "no_ground_truth",
            "message": "No ground truth available for comparison",
        }

    # Extract API validation data from predicted results
    api_validation = predicted.get("api_validation", {})
    api_diagnoses = api_validation.get("diagnoses", [])
    api_procedures = api_validation.get("procedures", [])

    # Ground truth data
    gt_diagnoses = ground_truth.get("diagnoses", [])
    gt_procedures = ground_truth.get("procedures", [])

    comparison = {
        "patient_name_match": predicted.get("patientName")
        == ground_truth.get("patientName"),
        "visit_date_match": predicted.get("visitDate") == ground_truth.get("visitDate"),
    }

    # CODE-FOCUSED diagnosis comparison
    diagnosis_details = {
        "gt_count": len(gt_diagnoses),
        "api_count": len(api_diagnoses),
        "validated_api_count": len(
            [d for d in api_diagnoses if d.get("validated", False)]
        ),
        "code_matches": 0,
        "missed_codes": 0,
        "additional_codes": 0,
        "matched_gt_codes": [],
        "missed_gt_codes": [],
        "additional_api_codes": [],
        "missed_detections": 0,
        "additional_detections": 0,
    }

    # Get ground truth codes
    gt_codes = set()
    for gt_diag in gt_diagnoses:
        gt_code = gt_diag.get("icd10Code", "").upper().strip()
        if gt_code:
            gt_codes.add(gt_code)

    # Get API codes (only from final codes)
    api_codes = set()
    for api_diag in api_diagnoses:
        api_code = api_diag.get("final_code", "").upper().strip()
        if api_code and api_code != "INVALID_CODE" and api_code != "NO_API_VALIDATION":
            api_codes.add(api_code)

    # Find matches
    matched_codes = gt_codes.intersection(api_codes)
    missed_codes = gt_codes - api_codes
    additional_codes = api_codes - gt_codes

    diagnosis_details["code_matches"] = len(matched_codes)
    diagnosis_details["missed_codes"] = len(missed_codes)
    diagnosis_details["additional_codes"] = len(additional_codes)
    diagnosis_details["matched_gt_codes"] = list(matched_codes)
    diagnosis_details["missed_gt_codes"] = list(missed_codes)
    diagnosis_details["additional_api_codes"] = list(additional_codes)
    diagnosis_details["missed_detections"] = len(missed_codes)
    diagnosis_details["additional_detections"] = len(additional_codes)

    # CODE-FOCUSED procedure comparison
    procedure_details = {
        "gt_count": len(gt_procedures),
        "api_count": len(api_procedures),
        "validated_api_count": len(
            [p for p in api_procedures if p.get("validated", False)]
        ),
        "code_matches": 0,
        "missed_codes": 0,
        "additional_codes": 0,
        "matched_gt_codes": [],
        "missed_gt_codes": [],
        "additional_api_codes": [],
        "missed_detections": 0,
        "additional_detections": 0,
    }

    # Get ground truth procedure codes
    gt_proc_codes = set()
    for gt_proc in gt_procedures:
        gt_code = gt_proc.get("cptCode", "").strip()
        if gt_code:
            gt_proc_codes.add(gt_code)

    # Get API procedure codes
    api_proc_codes = set()
    for api_proc in api_procedures:
        api_code = api_proc.get("final_code", "").strip()
        if api_code and api_code != "INVALID_CODE" and api_code != "NO_API_VALIDATION":
            api_proc_codes.add(api_code)

    # Find procedure matches
    matched_proc_codes = gt_proc_codes.intersection(api_proc_codes)
    missed_proc_codes = gt_proc_codes - api_proc_codes
    additional_proc_codes = api_proc_codes - gt_proc_codes

    procedure_details["code_matches"] = len(matched_proc_codes)
    procedure_details["missed_codes"] = len(missed_proc_codes)
    procedure_details["additional_codes"] = len(additional_proc_codes)
    procedure_details["matched_gt_codes"] = list(matched_proc_codes)
    procedure_details["missed_gt_codes"] = list(missed_proc_codes)
    procedure_details["additional_api_codes"] = list(additional_proc_codes)
    procedure_details["missed_detections"] = len(missed_proc_codes)
    procedure_details["additional_detections"] = len(additional_proc_codes)

    # Calculate SMART accuracy - finding all required codes + extra is GOOD
    total_gt_codes = len(gt_codes) + len(gt_proc_codes)
    total_matched_codes = (
        diagnosis_details["code_matches"] + procedure_details["code_matches"]
    )
    total_missed_codes = (
        diagnosis_details["missed_codes"] + procedure_details["missed_codes"]
    )
    total_additional_codes = (
        diagnosis_details["additional_codes"] + procedure_details["additional_codes"]
    )

    # Core accuracy: did we find all the required codes?
    if total_gt_codes > 0:
        core_accuracy = (total_matched_codes / total_gt_codes) * 100
    else:
        core_accuracy = 100.0 if total_matched_codes == 0 else 0.0

    # Enhanced accuracy: bonus for finding additional relevant codes
    # Finding MORE is GOOD, missing codes is BAD
    if total_missed_codes == 0:
        # Found all GT codes - this is excellent
        api_accuracy = 100.0
        if total_additional_codes > 0:
            # Bonus points for finding additional valid codes (up to 110%)
            api_accuracy = min(110.0, 100.0 + (total_additional_codes * 2))
    else:
        # Missed some codes - penalty
        api_accuracy = core_accuracy

    # Determine overall match status
    all_gt_found = total_missed_codes == 0

    comparison["diagnoses_match"] = diagnosis_details["missed_codes"] == 0
    comparison["procedures_match"] = procedure_details["missed_codes"] == 0

    return {
        "status": "compared",
        "api_accuracy": api_accuracy,
        "all_gt_found": all_gt_found,
        "details": comparison,
        "diagnosis_details": diagnosis_details,
        "procedure_details": procedure_details,
        "summary": {
            "patient_info_correct": comparison["patient_name_match"]
            and comparison["visit_date_match"],
            "diagnoses_correct": comparison["diagnoses_match"],
            "procedures_correct": comparison["procedures_match"],
            "diagnosis_detection": f"Found {diagnosis_details['code_matches']}/{len(gt_codes)} GT codes + {diagnosis_details['additional_codes']} additional",
            "procedure_detection": f"Found {procedure_details['code_matches']}/{len(gt_proc_codes)} GT codes + {procedure_details['additional_codes']} additional",
            "missed_diagnoses": diagnosis_details["missed_detections"],
            "missed_procedures": procedure_details["missed_detections"],
            "additional_diagnoses": diagnosis_details["additional_detections"],
            "additional_procedures": procedure_details["additional_detections"],
        },
    }


def display_json_comparison(predicted, ground_truth, comparison_result):
    """Display side-by-side JSON comparison with API-focused analysis."""
    # Show only API validated data vs Ground Truth
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("🤖 API Validated Result")
        # Show only the API validation part
        api_validation = predicted.get("api_validation", {})
        display_data = {
            "patientName": predicted.get("patientName"),
            "visitDate": predicted.get("visitDate"),
            "diagnoses": [
                {
                    "condition": d.get("condition"),
                    "icd10Code": d.get("final_code"),
                    "validated": d.get("validated", False),
                    "source": d.get("source", "Agent"),
                }
                for d in api_validation.get("diagnoses", [])
            ],
            "procedures": [
                {
                    "procedureName": p.get("procedureName"),
                    "cptCode": p.get("final_code"),
                    "validated": p.get("validated", False),
                    "source": p.get("source", "Agent"),
                }
                for p in api_validation.get("procedures", [])
            ],
        }
        st.json(display_data)

    with col2:
        st.subheader("✅ Ground Truth")
        if ground_truth:
            st.json(ground_truth)
        else:
            st.info("No ground truth available for this note")

    if comparison_result["status"] == "compared":
        st.subheader("📊 API-Focused Accuracy Analysis")

        api_accuracy = comparison_result.get("api_accuracy", 0)
        all_gt_found = comparison_result.get("all_gt_found", False)
        additional_items = comparison_result.get("diagnosis_details", {}).get(
            "additional_detections", 0
        ) + comparison_result.get("procedure_details", {}).get(
            "additional_detections", 0
        )

        if all_gt_found and additional_items > 0:
            st.success(
                f"🎉 All GT Items Found + {additional_items} Extra! API Score: {api_accuracy:.1f}%"
            )
        elif all_gt_found:
            st.success(
                f"🎉 All Ground Truth Items Found! API Accuracy: {api_accuracy:.1f}%"
            )
        elif api_accuracy >= 75:
            st.warning(f"🟡 Most Items Found: {api_accuracy:.1f}%")
        else:
            st.error(f"🔴 Missing Important Items: {api_accuracy:.1f}%")

        # Summary metrics with additional detection info
        summary = comparison_result.get("summary", {})
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            status = "✅" if summary.get("patient_info_correct") else "❌"
            st.metric("Patient Info", status)

        with col2:
            status = "✅" if summary.get("diagnoses_correct") else "❌"
            missed = summary.get("missed_diagnoses", 0)
            additional = summary.get("additional_diagnoses", 0)
            if missed == 0 and additional > 0:
                st.metric(
                    "Diagnoses",
                    f"✅ + {additional} extra",
                    help="Found all required + additional items",
                )
            elif missed > 0:
                st.metric(
                    "Diagnoses",
                    f"❌ -{missed} missed",
                    help="Missing some required items",
                )
            else:
                st.metric("Diagnoses", status)

        with col3:
            status = "✅" if summary.get("procedures_correct") else "❌"
            missed = summary.get("missed_procedures", 0)
            additional = summary.get("additional_procedures", 0)
            if missed == 0 and additional > 0:
                st.metric(
                    "Procedures",
                    f"✅ + {additional} extra",
                    help="Found all required + additional items",
                )
            elif missed > 0:
                st.metric(
                    "Procedures",
                    f"❌ -{missed} missed",
                    help="Missing some required items",
                )
            else:
                st.metric("Procedures", status)

        with col4:
            st.metric("API Accuracy", f"{api_accuracy:.0f}%")


        # Procedure details
        # if "procedure_details" in comparison_result:
        #     with st.expander("🔧 Procedure Detection Details"):
        #         proc_details = comparison_result["procedure_details"]

        #         col1, col2, col3, col4 = st.columns(4)
        #         with col1:
        #             gt_count = proc_details.get("gt_count", 0)
        #             st.metric("Ground Truth", f"{gt_count} items")

        #         with col2:
        #             found_count = sum(proc_details.get("exact_matches", []))
        #             st.metric("Correctly Found", f"{found_count}/{gt_count}")

        #         with col3:
        #             missed = proc_details.get("missed_detections", 0)
        #             if missed == 0:
        #                 st.metric(
        #                     "Missed Items", "✅ 0", help="No ground truth items missed"
        #                 )
        #             else:
        #                 st.metric(
        #                     "Missed Items",
        #                     f"❌ {missed}",
        #                     help="Some ground truth items not detected",
        #                 )

        #         with col4:
        #             additional = proc_details.get("additional_detections", 0)
        #             if additional > 0:
        #                 st.metric(
        #                     "Extra Detections",
        #                     f"💡 +{additional}",
        #                     help="Additional items beyond ground truth (acceptable)",
        #                 )
        #             else:
        #                 st.metric("Extra Detections", "0")

        # Performance interpretation
        # st.subheader("🎯 Performance Interpretation")

        # total_missed = comparison_result.get("diagnosis_details", {}).get(
        #     "missed_detections", 0
        # ) + comparison_result.get("procedure_details", {}).get("missed_detections", 0)
        # total_additional = comparison_result.get("diagnosis_details", {}).get(
        #     "additional_detections", 0
        # ) + comparison_result.get("procedure_details", {}).get(
        #     "additional_detections", 0
        # )

        # if total_missed == 0 and total_additional == 0:
        #     st.success("🎯 **Perfect Match**: Found exactly what was expected")
        # elif total_missed == 0 and total_additional > 0:
        #     st.success(
        #         f"🌟 **Enhanced Detection**: Found all expected items + {total_additional} additional items (this is good!)"
        #     )
        # elif total_missed > 0 and total_additional == 0:
        #     st.error(
        #         f"⚠️ **Incomplete Detection**: Missing {total_missed} expected items"
        #     )
        # else:
        #     st.warning(
        #         f"🔄 **Mixed Results**: Missing {total_missed} items but found {total_additional} additional items"
        #     )

        # Overall breakdown table
        st.subheader("📝 Field-by-Field Breakdown")
        details = comparison_result["details"]
        breakdown_data = []
        for field, match in details.items():
            breakdown_data.append(
                {
                    "Field": field.replace("_", " ").title(),
                    "Match": "✅" if match else "❌",
                    "Status": "Correct" if match else "Incorrect",
                }
            )

        df = pd.DataFrame(breakdown_data)
        st.dataframe(df, width="stretch")


def filter_api_validated_only(result):
    """Filter result to ONLY include diagnoses and procedures that have API codes - clean JSON format"""
    if "api_validation" not in result:
        return result

    filtered_result = {
        "patientName": result.get("patientName", ""),
        "visitDate": result.get("visitDate", ""),
        "diagnoses": [],
        "procedures": [],
    }

    validation = result["api_validation"]

    # Filter diagnoses - ONLY include if APIs actually returned a valid code
    if "diagnoses" in validation:
        for diag_validation in validation["diagnoses"]:
            # Only include if API actually provided a code (not just agent code)
            api_code = diag_validation.get("api_code")
            agent_code = diag_validation.get("agent_code")

            # Include if API provided a different code OR if agent code was validated by API
            if (api_code and api_code != agent_code and len(api_code) >= 3) or (
                diag_validation.get("validated")
                and diag_validation.get("source") in ["WHO", "Common", "NLM"]
            ):
                final_code = (
                    api_code if (api_code and len(api_code) >= 3) else agent_code
                )
                filtered_result["diagnoses"].append(
                    {
                        "condition": diag_validation.get("condition", ""),
                        "icd10Code": final_code,
                    }
                )

    # Filter procedures - ONLY include if APIs actually returned a valid code
    if "procedures" in validation:
        for proc_validation in validation["procedures"]:
            # Only include if API actually provided a code (not just agent code)
            api_code = proc_validation.get("api_code")
            agent_code = proc_validation.get("agent_code")

            # Include if API provided a different code OR if agent code was validated by API
            if (api_code and api_code != agent_code and len(api_code) == 5) or (
                proc_validation.get("validated")
                and proc_validation.get("source") in ["Common", "NLM"]
            ):
                final_code = (
                    api_code if (api_code and len(api_code) == 5) else agent_code
                )
                filtered_result["procedures"].append(
                    {
                        "procedureName": proc_validation.get("procedureName", ""),
                        "cptCode": final_code,
                    }
                )

    return filtered_result


def main():
    """Main application"""

    # Header
    st.markdown(
        '<h1 class="main-header">🏥 AI Driven Billing Code Assistant</h1>',
        unsafe_allow_html=True,
    )

    # Sidebar
    st.sidebar.title("🔧 Control Panel")

    # Initialize agent manager
    agent_manager = initialize_agent_manager()

    # Sidebar diagnostics
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "NOT SET")
    model = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME") or os.getenv("AZURE_OPENAI_MODEL_NAME", "NOT SET")
    key_set = bool(os.getenv("AZURE_OPENAI_API_KEY"))
    with st.sidebar.expander("🔌 Connection Info"):
        st.write(f"**Model:** {model}")
        st.write(f"**API Key set:** {key_set}")
        st.write(f"**Endpoint:** {endpoint[:60]}..." if len(endpoint) > 60 else f"**Endpoint:** {endpoint}")

    # Load sample notes and ground truth
    sample_notes = load_sample_notes()
    ground_truth_data = load_ground_truth()

    # Always enable API validation (no toggle needed)
    use_api_validation = True

    # Always show enhanced mode message
    st.sidebar.success("Enhanced mode: API validation enabled")

    # Mode selection
    mode = st.sidebar.radio(
        "Select Mode:",
        [
            "📝 Process Single Note",
            "🎯 Ground Truth Comparison",
        ],
    )

    if mode == "📝 Process Single Note":
        st.header("� Single Note Processing")

        # Input method selection
        input_method = st.radio(
            "Choose input method:", ["Type/Paste Note", "Select Sample Note"]
        )

        clinical_note = ""

        if input_method == "Type/Paste Note":
            clinical_note = st.text_area(
                "Enter Clinical Note:",
                height=300,
                placeholder="Patient: Shubhangi Sharma\nDate of Visit: 2025-09-18\nSubjective: ...\nObjective: ...\nAssessment: ...\nPlan: ...",
            )
        else:
            if sample_notes:
                selected_note = st.selectbox(
                    "Select Sample Note:", list(sample_notes.keys())
                )
                if selected_note:
                    clinical_note = sample_notes[selected_note]
                    st.text_area(
                        "Clinical Note Content:",
                        value=clinical_note,
                        height=300,
                        disabled=True,
                    )
            else:
                st.warning("No sample notes found in src/data/sample_notes/")

        if st.button("🚀 Process Note", type="primary", width="stretch"):
            if clinical_note.strip():
                with st.spinner(
                    "Processing clinical note through AI agent pipeline..."
                ):
                    # Progress tracking
                    progress_bar = st.progress(0)
                    status_text = st.empty()

                    # DEBUGGING: Create debug container
                    debug_container = st.container()
                    debug_container.subheader("🔍 Real-time Validation Debug Log")
                    debug_log = debug_container.empty()

                    debug_messages = ["🚀 Starting processing pipeline..."]

                    # Simulate processing steps with progress updates
                    status_text.text("Step 1/4: Clinical information extraction...")
                    progress_bar.progress(25)

                    debug_messages.append(
                        "📝 Step 1: Calling agent_manager.process_clinical_note()"
                    )
                    debug_log.text_area(
                        "Debug Log:", value="\n".join(debug_messages), height=150
                    )

                    result = agent_manager.process_clinical_note(clinical_note)

                    debug_messages.append(
                        f"✅ Step 1 Complete: Got result with keys: {list(result.keys()) if isinstance(result, dict) else 'ERROR'}"
                    )
                    if isinstance(result, dict) and "error" not in result:
                        # NEW: Check for validation debug info in result
                        if "_debug_trace" in result:
                            debug_messages.append(
                                "🎯 FOUND AGENT PIPELINE DEBUG TRACE:"
                            )
                            debug_messages.extend(
                                result["_debug_trace"][-10:]
                            )  # Show last 10 debug messages

                        # NEW: Check validation status
                        if "_validation_status" in result:
                            val_status = result["_validation_status"]
                            debug_messages.append(
                                f"🔄 Validation Status: Approved={val_status.get('coding_approved')}, Revisions={val_status.get('revision_count')}/{val_status.get('max_revisions')}"
                            )

                        # Check if we have medical coding content
                        if "diagnoses" in result or "procedures" in result:
                            debug_messages.append(
                                f"📋 Found diagnoses: {len(result.get('diagnoses', []))}"
                            )
                            debug_messages.append(
                                f"🔧 Found procedures: {len(result.get('procedures', []))}"
                            )

                            # Check for specific codes we're tracking
                            all_text = str(result).upper()
                            if "E11.9" in all_text:
                                debug_messages.append("🚨 DETECTED E11.9 in result!")
                            if "E11.40" in all_text:
                                debug_messages.append("✅ DETECTED E11.40 in result!")
                            if "NEUROPATHY" in all_text:
                                debug_messages.append(
                                    "🔍 DETECTED 'NEUROPATHY' in result text"
                                )
                    debug_log.text_area(
                        "Debug Log:", value="\n".join(debug_messages), height=300
                    )

                    status_text.text("Step 2/4: Medical coding and validation...")
                    progress_bar.progress(50)

                    # Add API validation if enabled
                    debug_messages.append("🔍 Step 2: Starting API validation...")
                    debug_log.text_area(
                        "Debug Log:", value="\n".join(debug_messages), height=200
                    )

                    result = validate_with_icd_api(
                        result, True
                    )  # Always use API validation

                    debug_messages.append("✅ Step 2 Complete: API validation finished")
                    debug_log.text_area(
                        "Debug Log:", value="\n".join(debug_messages), height=200
                    )

                    status_text.text("Step 3/4: API validation and filtering...")
                    progress_bar.progress(75)

                    # Filter to only show API-validated items
                    debug_messages.append(
                        "🔍 Step 3: Filtering API-validated results..."
                    )
                    debug_log.text_area(
                        "Debug Log:", value="\n".join(debug_messages), height=200
                    )

                    filtered_result = filter_api_validated_only(result)

                    debug_messages.append(
                        f"✅ Step 3 Complete: Filtered result has {len(filtered_result.get('diagnoses', []))} diagnoses"
                    )
                    debug_log.text_area(
                        "Debug Log:", value="\n".join(debug_messages), height=200
                    )

                    status_text.text("Step 4/4: Final report generation...")
                    progress_bar.progress(100)

                    debug_messages.append("🎯 Step 4: Final processing complete")
                    debug_messages.append("=" * 50)
                    debug_messages.append("🔍 FINAL VALIDATION DEBUG SUMMARY:")

                    # Add comprehensive final debug info
                    if isinstance(result, dict):
                        if "error" in result:
                            debug_messages.append(
                                f"❌ Error in result: {result['error']}"
                            )
                        else:
                            # NEW: Check agent pipeline debug trace for validation execution
                            if "_debug_trace" in result:
                                validation_traces = [
                                    trace
                                    for trace in result["_debug_trace"]
                                    if "validation" in trace.lower()
                                    or "revision" in trace.lower()
                                ]
                                if validation_traces:
                                    debug_messages.append(
                                        f"✅ Found {len(validation_traces)} validation traces in agent pipeline"
                                    )
                                    debug_messages.append("🔍 Key validation traces:")
                                    for trace in validation_traces[
                                        -3:
                                    ]:  # Show last 3 validation traces
                                        debug_messages.append(f"   {trace}")
                                else:
                                    debug_messages.append(
                                        "⚠️ No validation traces found in agent pipeline debug"
                                    )
                            else:
                                debug_messages.append(
                                    "⚠️ No agent pipeline debug trace available"
                                )

                            # NEW: Check validation status
                            if "_validation_status" in result:
                                val_status = result["_validation_status"]
                                if val_status.get("coding_approved"):
                                    debug_messages.append(
                                        "🚨 PROBLEM: Validation was APPROVED despite errors!"
                                    )
                                else:
                                    debug_messages.append(
                                        f"⚠️ Validation NOT approved (revisions: {val_status.get('revision_count')}/{val_status.get('max_revisions')})"
                                    )

                            # Check for specific error patterns
                            result_str = str(result)
                            if "E11.9" in result_str and "E11.40" in result_str:
                                debug_messages.append(
                                    "🚨 BOTH E11.9 AND E11.40 DETECTED - Validation should have caught this!"
                                )
                            elif (
                                "E11.9" in result_str
                                and "neuropathy" in result_str.lower()
                            ):
                                debug_messages.append(
                                    "🚨 E11.9 WITH NEUROPATHY DETECTED - Validation should have caught this!"
                                )
                            elif "E11.40" in result_str:
                                debug_messages.append(
                                    "✅ E11.40 found - this is correct for neuropathy"
                                )
                            elif "E11.9" in result_str:
                                debug_messages.append(
                                    "⚠️ E11.9 found - check if this is appropriate"
                                )

                    debug_log.text_area(
                        "Debug Log:", value="\n".join(debug_messages), height=250
                    )
                    time.sleep(0.5)

                    # Clear progress indicators
                    progress_bar.empty()
                    status_text.empty()

                # Clean up debug info from result before displaying to user
                if isinstance(result, dict):
                    # Remove debug/internal keys from display result
                    display_result = {
                        k: v for k, v in result.items() if not k.startswith("_")
                    }
                else:
                    display_result = result

                # Display results
                if "error" in display_result:
                    st.markdown(
                        f'<div class="error-box">❌ <strong>Error:</strong> {display_result["error"]}</div>',
                        unsafe_allow_html=True,
                    )
                    if (
                        "raw_response" in display_result
                        and display_result["raw_response"]
                    ):
                        st.expander("🔍 Raw Response").text(
                            display_result["raw_response"]
                        )
                else:
                    st.markdown(
                        '<div class="success-box">✅ <strong>Processing Complete!</strong></div>',
                        unsafe_allow_html=True,
                    )

                    # Display formatted result (API-validated only)
                    st.subheader("📋 API Validated Medical Coding Result")
                    st.json(filtered_result)

                    # Show API validation status if available (use original result which has full data)
                    if "api_validation" in result:
                        st.subheader("🔍 Medical Code Validation Results")
                        validation = result["api_validation"]

                        # Show diagnosis validation
                        if validation.get("diagnoses"):
                            st.write("**Diagnosis Code Validation:**")
                            for diag in validation["diagnoses"]:
                                condition = diag.get("condition", "Unknown condition")
                                final_code = diag.get(
                                    "final_code",
                                    diag.get(
                                        "agent_code", diag.get("api_code", "No code")
                                    ),
                                )
                                if diag.get("validated"):
                                    st.success(
                                        f"✅ {condition} - Code {final_code} validated"
                                    )
                                else:
                                    st.warning(
                                        f"⚠️ {condition} - Code {final_code} not validated"
                                    )
                                    if diag.get("suggestions"):
                                        st.info("💡 Suggested alternatives:")
                                        for suggestion in diag["suggestions"][:2]:
                                            st.write(
                                                f"   • {suggestion['code']}: {suggestion['description']}"
                                            )

                        # Show procedure validation
                        if validation.get("procedures"):
                            st.write("**Procedure Code Validation:**")
                            for proc in validation["procedures"]:
                                procedure_name = proc.get(
                                    "procedureName", "Unknown procedure"
                                )
                                final_code = proc.get(
                                    "final_code",
                                    proc.get(
                                        "agent_code", proc.get("api_code", "No code")
                                    ),
                                )
                                if proc.get("validated"):
                                    st.success(
                                        f"✅ {procedure_name} - Code {final_code} validated"
                                    )
                                else:
                                    st.warning(
                                        f"⚠️ {procedure_name} - Code {final_code} not validated"
                                    )
                                    if proc.get("suggestions"):
                                        st.info("💡 Suggested alternatives:")
                                        for suggestion in proc["suggestions"][:2]:
                                            st.write(
                                                f"   • {suggestion['code']}: {suggestion['description']}"
                                            )

                    # Download option
                    json_str = json.dumps(filtered_result, indent=2)
                    st.download_button(
                        label="📥 Download API Validated JSON Result",
                        data=json_str,
                        file_name=f"api_validated_result_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                        mime="application/json",
                    )
            else:
                st.warning("Please enter a clinical note to process.")



    elif mode == "🎯 Ground Truth Comparison":
        st.header("🎯 Ground Truth Comparison")
        st.info(
            "Compare AI agent results with expected ground truth for accuracy evaluation."
        )

        if sample_notes:
            selected_note = st.selectbox(
                "Select Note for Comparison:", list(sample_notes.keys())
            )

            if selected_note:
                st.subheader(
                    f"Clinical Note: {selected_note.replace('_', ' ').title()}"
                )

                # Display the clinical note
                with st.expander("� View Clinical Note"):
                    st.text_area(
                        "Content:",
                        value=sample_notes[selected_note],
                        height=200,
                        disabled=True,
                    )

                if st.button("🔍 Process & Compare", type="primary", width="stretch"):
                    with st.spinner(
                        "Processing note and comparing with ground truth..."
                    ):
                        # Process the note
                        result = agent_manager.process_clinical_note(
                            sample_notes[selected_note]
                        )
                        result = validate_with_icd_api(result, use_api_validation)

                        # Get ground truth
                        # Get ground truth data for comparison
                        if hasattr(ground_truth_data, "get_ground_truth"):
                            # Using Langfuse manager
                            st.info("Using Langfuse for ground truth retrieval")
                            ground_truth = ground_truth_data.get_ground_truth(
                                selected_note
                            )
                        else:
                            # Using fallback dictionary
                            st.warning(
                                "Using fallback dictionary for ground truth retrieval"
                            )
                            ground_truth = ground_truth_data.get(selected_note)

                        if "error" not in result:
                            # Compare results
                            comparison = compare_results(result, ground_truth)

                            # Display comparison
                            display_json_comparison(result, ground_truth, comparison)
                        else:
                            st.error(f"Processing failed: {result['error']}")
        else:
            st.warning("No sample notes available for comparison.")


if __name__ == "__main__":
    main()
