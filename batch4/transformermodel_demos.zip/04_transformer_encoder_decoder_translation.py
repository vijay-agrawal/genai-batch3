# Transformer Encoder-Decoder Walk-Through
# Translating "Hello World" -> "Bonjour le monde"
# Illustrates how the encoder builds contextual representations and how the
# decoder turns them into French tokens.

# Setup: pip install transformers sentencepiece --upgrade

from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import torch, numpy as np

# ── 2. Load tokenizer & model ───────────────────────────────────────────────
# Shared vocabulary for both languages, classic encoder-decoder architecture.

model_name = "Helsinki-NLP/opus-mt-en-fr"
tokenizer  = AutoTokenizer.from_pretrained(model_name)
model      = AutoModelForSeq2SeqLM.from_pretrained(model_name)
model.eval()  # inference mode

# ── 3. Encode the English sentence ──────────────────────────────────────────
# The encoder processes token IDs into a matrix of contextual hidden states.

sentence_en = "Hello World"
inputs = tokenizer(sentence_en, return_tensors="pt")
print("Input IDs:", inputs["input_ids"][0].tolist(),
      "\nTokens   :", tokenizer.convert_ids_to_tokens(inputs["input_ids"][0]))

with torch.no_grad():
    encoder_outputs = model.get_encoder()(
        input_ids      = inputs["input_ids"],
        attention_mask = inputs["attention_mask"],
        return_dict    = True
    )

hidden_states = encoder_outputs.last_hidden_state  # shape: [batch, seq_len, hidden_dim]
print("Encoder hidden-state shape :", hidden_states.shape)

# ── 4. Decode step-by-step (greedy) ─────────────────────────────────────────
# Feed encoder representations to the decoder one token at a time to watch
# how it auto-regressively builds the French sentence.

def pretty(ids):
    return tokenizer.convert_ids_to_tokens(ids, skip_special_tokens=True)

enc_out = encoder_outputs.last_hidden_state

decoded_ids = [model.config.decoder_start_token_id]
for step in range(10):  # limit to 10 steps for safety
    decoder_input = torch.tensor([decoded_ids]).to(model.device)
    with torch.no_grad():
        outputs = model(
            encoder_outputs   = (enc_out,),
            decoder_input_ids = decoder_input,
            return_dict       = True
        )
    next_id = int(outputs.logits[0, -1].argmax())  # greedy
    decoded_ids.append(next_id)
    if next_id == tokenizer.eos_token_id:
        break
    print(f"Step {step+1}: {pretty(decoded_ids)}")

# ── 5. Full translation with .generate() ────────────────────────────────────
# model.generate() handles beam search, length penalties, etc.

translated_ids = model.generate(**inputs, max_length=40)
translation_fr = tokenizer.decode(translated_ids[0], skip_special_tokens=True)
print("\nEnglish :", sentence_en)
print("French  :", translation_fr)
