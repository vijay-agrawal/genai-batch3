# RoBERTa in Healthcare
# Setup: pip install transformers torch sentencepiece sentence-transformers

from transformers import pipeline
from sentence_transformers import SentenceTransformer, util
import torch, textwrap

SEP  = "=" * 70
SEP2 = "-" * 70

def banner(title):
    print(f"\n{SEP}")
    print(f"  {title}")
    print(SEP)

def section(text):
    print(f"\n{SEP2}")
    print(f"  {text}")
    print(SEP2)

# ─────────────────────────────────────────────────────────────────────────────
print(SEP)
print("  RoBERTa in Healthcare — Live Demo")
print("  How transformer models can read, understand, and reason over")
print("  clinical text — without any custom training.")
print(SEP)
print("""
Scenario:
  You are a data scientist working with a hospital system.
  Clinicians produce hundreds of free-text notes every day — discharge
  summaries, medication orders, progress notes.  Your task: show how
  off-the-shelf NLP models can extract value from that text instantly.

  We will walk through four real tasks, building from simple to complex.
""")

input("  Press Enter to begin ...\n")

# ─────────────────────────────────────────────────────────────────────────────
banner("TASK 1 of 4 — Sentiment / Risk Classification")
print("""
Goal:
  A busy charge nurse wants a quick red/green signal on incoming discharge
  notes — which patients are stable vs. which might need a second look?

Approach:
  We use siebert/sentiment-roberta-large-english — RoBERTa-large fine-tuned
  for sentiment across 15 diverse datasets.  It returns a clean POSITIVE /
  NEGATIVE label with a confidence score, no custom training needed.
""")

# siebert/sentiment-roberta-large-english is RoBERTa-large fine-tuned for
# sentiment on 15 datasets — returns clean POSITIVE / NEGATIVE labels.
classifier = pipeline('text-classification',
                      model='siebert/sentiment-roberta-large-english',
                      device=0 if torch.cuda.is_available() else -1)

notes = [
    "The patient's vitals are stable and she is ready for discharge today.",
    "Despite medication, the patient's blood pressure remains dangerously high."
]

print("  Loading model and classifying notes ...\n")
for i, note in enumerate(notes, 1):
    result = classifier(note)[0]
    label  = result['label']      # POSITIVE or NEGATIVE
    score  = result['score']
    flag   = "GREEN - Stable / positive outlook" if label == "POSITIVE" else "RED  - Concerning, flag for review"
    print(f"  Note {i}: {textwrap.fill(note, width=65, subsequent_indent='          ')}")
    print(f"  Model : {label}  (confidence {score:.1%})  =>  {flag}\n")

print("""
Takeaway:
  In under a second, the model triages two notes that would take a nurse
  30-60 seconds each to read and mentally classify.  At scale (500 notes/day)
  that's hours of saved cognitive load.
""")
input("  Press Enter for Task 2 ...\n")

# ─────────────────────────────────────────────────────────────────────────────
banner("TASK 2 of 4 — Named-Entity Recognition (NER)")
print("""
Goal:
  The pharmacy team needs to auto-populate a structured medication table
  from free-text prescriptions.  Manually copying drug names, dosages,
  and conditions into EHR fields is error-prone and slow.

Approach:
  A BERT-NER model labels each word with its entity type
  (Person, Organization, Location, Misc) — we repurpose it to highlight
  clinically relevant spans from an unstructured sentence.
""")

ner = pipeline('ner', model='dslim/bert-base-NER', grouped_entities=True,
               device=0 if torch.cuda.is_available() else -1)

sample = "The patient was prescribed 100 mg Metformin twice daily to manage type 2 diabetes."

print(f"  Input note:\n  \"{sample}\"\n")
print("  Running NER model ...\n")

entities = ner(sample)
print(f"  {'Entity Text':<30} {'Type':<12} {'Confidence':>10}")
print(f"  {'-'*30} {'-'*12} {'-'*10}")
for ent in entities:
    print(f"  {ent['word']:<30} {ent['entity_group']:<12} {ent['score']:>9.1%}")

print("""
Takeaway:
  The model pinpoints named spans in milliseconds.  With a healthcare-
  specific NER model (e.g. BioBERT-NER) you would also get DRUG, DOSAGE,
  and CONDITION labels directly — ready to write straight into the EHR.
""")
input("  Press Enter for Task 3 ...\n")

# ─────────────────────────────────────────────────────────────────────────────
banner("TASK 3 of 4 — Question Answering over Clinical Notes")
print("""
Goal:
  A covering physician picks up Mr. Smith's case at 2 AM.  She needs one
  specific fact buried in a two-paragraph note — the discharge medication —
  without reading the whole thing.

Approach:
  Extractive QA: we give the model the note as 'context' and a plain-English
  question.  RoBERTa finds the exact answer span inside the document.
  No summarisation, no hallucination — the answer comes verbatim from the note.
""")

qa = pipeline('question-answering', model='deepset/roberta-base-squad2',
              device=0 if torch.cuda.is_available() else -1)

context = (
    "Mr. Smith is a 67-year-old male with a history of COPD who was admitted "
    "due to shortness of breath. He was treated with bronchodilators and "
    "corticosteroids and showed significant improvement. He will be discharged "
    "with instructions to continue inhaled tiotropium once daily."
)
question = "What medication should Mr. Smith continue after discharge?"

print("  Clinical note:")
for line in textwrap.wrap(context, width=65):
    print(f"    {line}")
print(f"\n  Doctor's question:\n    \"{question}\"\n")
print("  Running QA model ...\n")

answer = qa(question=question, context=context)
print(f"  Answer found : \"{answer['answer']}\"")
print(f"  Confidence   : {answer['score']:.1%}")
print(f"  Location     : characters {answer['start']}–{answer['end']} of the note")

print("""
Takeaway:
  The covering physician gets a precise, sourced answer in < 1 second.
  Unlike a chatbot, extractive QA never invents information — it can only
  point to text that already exists in the document.
""")
input("  Press Enter for Task 4 ...\n")

# ─────────────────────────────────────────────────────────────────────────────
banner("TASK 4 of 4 — Semantic Similarity (Duplicate / Related Note Detection)")
print("""
Goal:
  The medical records team needs to flag duplicate or near-duplicate notes
  before they are filed — clinicians sometimes re-dictate the same event
  using different words, and duplicates distort analytics.

Approach:
  We encode sentences into dense vectors (embeddings) using a RoBERTa
  sentence-transformer.  Two sentences that *mean* the same thing land
  close together in vector space, even if they share no exact words.
  Cosine similarity gives a score from 0 (unrelated) to 1 (identical meaning).
""")

embedder = SentenceTransformer('sentence-transformers/all-roberta-large-v1')

pairs = [
    (
        "The patient complains of chest pain radiating to the left arm.",
        "Patient reports angina symptoms with discomfort spreading to the left arm.",
        "Clinically same event, different wording"
    ),
    (
        "The patient complains of chest pain radiating to the left arm.",
        "Patient was discharged home in stable condition after hip replacement.",
        "Completely unrelated notes"
    ),
]

print("  Loading sentence-transformer model ...\n")
for s1, s2, label in pairs:
    e1, e2 = embedder.encode([s1, s2], convert_to_tensor=True)
    sim = util.cos_sim(e1, e2).item()
    verdict = "DUPLICATE / near-match — flag for review" if sim > 0.8 else "Distinct notes — OK to file"
    print(f"  Pair: {label}")
    print(f"    A: {textwrap.fill(s1, width=60, subsequent_indent='       ')}")
    print(f"    B: {textwrap.fill(s2, width=60, subsequent_indent='       ')}")
    print(f"    Cosine similarity : {sim:.3f}  =>  {verdict}\n")

print("""
Takeaway:
  A similarity threshold (e.g. > 0.85) lets you auto-flag likely duplicates
  across thousands of notes in seconds — work that would take days by hand.
""")

# ─────────────────────────────────────────────────────────────────────────────
banner("SUMMARY")
print("""
  Task                    Model used                   Value delivered
  ----------------------  ---------------------------  ----------------------------
  1. Risk classification  siebert/sentiment-roberta    Triage notes at scale
  2. Entity extraction    dslim/bert-base-NER          Auto-populate structured EHR
  3. Question answering   deepset/roberta-base-squad2  Instant, sourced fact lookup
  4. Semantic similarity  all-roberta-large-v1         Duplicate / cohort detection

  All of this runs on a single GPU (or even CPU) with zero custom training.
  Fine-tuning on your own clinical data would push accuracy even higher.

  Key insight: transformer models don't just match keywords — they understand
  *meaning*, which is exactly what clinical language demands.
""")
print(SEP)
print("  End of demo.  Questions?")
print(SEP)
