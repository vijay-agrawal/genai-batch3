# Clinical NLP in Healthcare — Domain-Specific Transformer Demo
# Models: BioBERT / ClinicalBERT / PubMedBERT variants
# Setup: pip install transformers torch sentencepiece sentence-transformers

# ── Suppress all library noise upfront ──────────────────────────────────────
import os, warnings, logging
os.environ["TOKENIZERS_PARALLELISM"] = "false"   # avoids HF tokenizer fork warning
warnings.filterwarnings("ignore")                 # suppress Python-level warnings
logging.getLogger("transformers").setLevel(logging.ERROR)
logging.getLogger("sentence_transformers").setLevel(logging.ERROR)
logging.getLogger("huggingface_hub").setLevel(logging.ERROR)

from transformers import pipeline, logging as hf_logging
hf_logging.set_verbosity_error()                  # suppress HF model-load messages

from sentence_transformers import SentenceTransformer, util
import torch, textwrap

SEP  = "=" * 70
SEP2 = "-" * 70

def banner(title):
    print(f"\n{SEP}")
    print(f"  {title}")
    print(SEP)

# ─────────────────────────────────────────────────────────────────────────────
print(SEP)
print("  Clinical NLP in Healthcare — Live Demo")
print("  Domain-specific transformer models that understand medical language")
print("  out of the box — no custom training required.")
print(SEP)
print("""
Scenario:
  You are a data scientist working with a hospital system.
  Clinicians produce hundreds of free-text notes every day — discharge
  summaries, medication orders, progress notes.  Your task: show how
  biomedical-domain NLP models can extract value from that text instantly.

  Why domain-specific models?
  General-purpose models (trained on web text) struggle with abbreviations
  like "COPD", "tiotropium", or "PRN".  Models pre-trained on PubMed abstracts
  and clinical notes already speak the language — higher accuracy, out of the box.

  We will walk through four real tasks, building from simple to complex.
""")

input("  Press Enter to begin ...\n")

# ─────────────────────────────────────────────────────────────────────────────
banner("TASK 1 of 4 — Clinical Sentiment / Risk Classification")
print("""
Goal:
  A busy charge nurse wants a quick red/green signal on incoming discharge
  notes — which patients are stable vs. which might need a second look?

Model:  samrawal/bert-base-uncased_clinical-sentiment
  A BERT-base model fine-tuned specifically on MIMIC-III clinical notes.
  Returns: POSITIVE (stable/improving) or NEGATIVE (concerning/declining).
  Why it beats general models: trained on actual nursing and physician notes,
  so it handles clinical phrasing, negations, and medical abbreviations correctly.
""")

# Fine-tuned on MIMIC-III clinical notes — understands clinical language natively
classifier = pipeline('text-classification',
                      model='samrawal/bert-base-uncased_clinical-sentiment',
                      device=0 if torch.cuda.is_available() else -1)

notes = [
    "The patient's vitals are stable and she is ready for discharge today.",
    "Despite medication, the patient's blood pressure remains dangerously high.",
    "Patient is afebrile, tolerating PO intake well, ambulating independently."
]

print("  Classifying clinical notes ...\n")
for i, note in enumerate(notes, 1):
    result = classifier(note)[0]
    label  = result['label'].upper()
    score  = result['score']
    flag   = "GREEN - Stable / positive outlook" if "POS" in label else "RED  - Concerning, flag for review"
    print(f"  Note {i}: {textwrap.fill(note, width=65, subsequent_indent='          ')}")
    print(f"  Model : {label}  (confidence {score:.1%})  =>  {flag}\n")

print("""
Takeaway:
  In under a second, the model triages notes that a nurse would spend
  30-60 seconds reading.  At 500 notes/day, that is hours of saved
  cognitive load — and a clinically-trained model means fewer errors.
""")
input("  Press Enter for Task 2 ...\n")

# ─────────────────────────────────────────────────────────────────────────────
banner("TASK 2 of 4 — Biomedical Named-Entity Recognition (NER)")
print("""
Goal:
  The pharmacy team needs to auto-populate a structured medication table
  from free-text prescriptions — drug name, dosage, condition.
  Manually copying into EHR fields is error-prone and slow.

Model:  d4data/biomedical-ner-all
  Fine-tuned on multiple biomedical NER corpora (BC5CDR, NCBI-Disease,
  BC4CHEMD, JNLPBA).  Recognizes: Disease, Drug/Chemical, Gene, Species,
  Cell-type, DNA, RNA — the entities that matter in clinical text.
  Why it beats general NER: dslim/bert-base-NER only knows PER/ORG/LOC/MISC.
""")

# Fine-tuned on BC5CDR + NCBI-Disease + BC4CHEMD — true biomedical entity types
ner = pipeline('ner', model='d4data/biomedical-ner-all', grouped_entities=True,
               aggregation_strategy='simple',
               device=0 if torch.cuda.is_available() else -1)

samples = [
    "The patient was prescribed 100 mg Metformin twice daily to manage type 2 diabetes.",
    "She was diagnosed with non-Hodgkin lymphoma and started on rituximab 375 mg/m2."
]

for sample in samples:
    print(f"  Input: \"{sample}\"")
    print("  Running biomedical NER ...\n")
    entities = ner(sample)
    if entities:
        print(f"  {'Entity Text':<35} {'Type':<20} {'Confidence':>10}")
        print(f"  {'-'*35} {'-'*20} {'-'*10}")
        for ent in entities:
            print(f"  {ent['word']:<35} {ent['entity_group']:<20} {ent['score']:>9.1%}")
    else:
        print("  (no entities detected)")
    print()

print("""
Takeaway:
  The biomedical model correctly labels drugs, diseases, and dosages —
  exactly the structured fields an EHR needs.  A general NER model
  would have missed or mislabeled most of these.
""")
input("  Press Enter for Task 3 ...\n")

# ─────────────────────────────────────────────────────────────────────────────
banner("TASK 3 of 4 — Biomedical Question Answering over Clinical Notes")
print("""
Goal:
  A covering physician picks up Mr. Smith's case at 2 AM.  She needs one
  specific fact buried in a dense note — the discharge medication —
  without reading the whole thing.

Model:  deepset/biobert-base-cased-squad2
  BioBERT (pre-trained on PubMed + PMC full text) fine-tuned on SQuAD 2.0.
  Handles "no answer" cases (returns empty if the answer is not in the note).
  Why it beats generic RoBERTa-squad2: BioBERT understands drug names,
  procedures, and clinical context that confuse general-domain models.
""")

# BioBERT fine-tuned on SQuAD2 — handles unanswerable questions gracefully
qa = pipeline('question-answering', model='deepset/biobert-base-cased-squad2',
              device=0 if torch.cuda.is_available() else -1)

context = (
    "Mr. Smith is a 67-year-old male with a history of COPD who was admitted "
    "due to shortness of breath. He was treated with bronchodilators and "
    "corticosteroids and showed significant improvement. He will be discharged "
    "with instructions to continue inhaled tiotropium once daily."
)

qa_pairs = [
    ("What medication should Mr. Smith continue after discharge?", True),
    ("What is Mr. Smith's history?",                              True),
    ("What surgery did Mr. Smith have?",                          False),  # not in note
]

print("  Clinical note:")
for line in textwrap.wrap(context, width=65):
    print(f"    {line}")
print()

for question, has_answer in qa_pairs:
    answer = qa(question=question, context=context)
    print(f"  Q: {question}")
    if answer['score'] < 0.05:
        print(f"  A: [Model says: not mentioned in this note]")
    else:
        print(f"  A: \"{answer['answer']}\"  (confidence {answer['score']:.1%})")
    print()

print("""
Takeaway:
  The covering physician gets precise, sourced answers in < 1 second.
  Extractive QA never hallucates — it can only quote text that exists
  in the document.  BioBERT makes this reliable for clinical terminology.
""")
input("  Press Enter for Task 4 ...\n")

# ─────────────────────────────────────────────────────────────────────────────
banner("TASK 4 of 4 — Biomedical Semantic Similarity")
print("""
Goal:
  The medical records team needs to flag duplicate or near-duplicate notes,
  and the research team wants to find patients with similar presentations
  — even when clinicians describe the same thing in different words.

Model:  neuml/pubmedbert-base-embeddings
  PubMedBERT fine-tuned as a sentence encoder on biomedical text pairs.
  Produces dense vectors where clinically similar sentences cluster together.
  Why it beats all-roberta-large-v1: trained on medical literature, so
  "angina" and "chest pain radiating to the left arm" land close in vector
  space — a general model may not know they describe the same thing.
""")

# PubMedBERT sentence embeddings — small, fast, biomedical-aware
embedder = SentenceTransformer('neuml/pubmedbert-base-embeddings')

pairs = [
    (
        "The patient complains of chest pain radiating to the left arm.",
        "Patient reports angina symptoms with discomfort spreading to the left arm.",
        "Clinically identical — different wording"
    ),
    (
        "Patient presents with productive cough, fever 38.9C, and consolidation on CXR.",
        "Chest X-ray shows right lower lobe infiltrate consistent with pneumonia; patient febrile.",
        "Same diagnosis — dictated by two different clinicians"
    ),
    (
        "The patient complains of chest pain radiating to the left arm.",
        "Patient was discharged home in stable condition after hip replacement.",
        "Completely unrelated notes"
    ),
]

print("  Encoding sentences with PubMedBERT ...\n")
for s1, s2, label in pairs:
    e1, e2 = embedder.encode([s1, s2], convert_to_tensor=True)
    sim = util.cos_sim(e1, e2).item()
    if sim > 0.85:
        verdict = "DUPLICATE / near-match — flag for review"
    elif sim > 0.60:
        verdict = "RELATED — possibly same patient event"
    else:
        verdict = "Distinct notes — OK to file"
    print(f"  Pair  : {label}")
    print(f"    A : {textwrap.fill(s1, width=58, subsequent_indent='        ')}")
    print(f"    B : {textwrap.fill(s2, width=58, subsequent_indent='        ')}")
    print(f"    Sim : {sim:.3f}  =>  {verdict}\n")

print("""
Takeaway:
  A similarity threshold auto-flags duplicates across thousands of notes
  in seconds.  With a biomedical embedder, clinically equivalent phrases
  (even with different terminology) score high — something a keyword
  search or general-purpose model would completely miss.
""")

# ─────────────────────────────────────────────────────────────────────────────
banner("SUMMARY — Why Domain-Specific Models Matter")
print("""
  Task                    Model                                  Domain trained on
  ----------------------  -------------------------------------  -------------------
  1. Risk classification  samrawal/clinical-sentiment (BERT)     MIMIC-III notes
  2. Entity extraction    d4data/biomedical-ner-all (BERT)        BC5CDR, NCBI, JNLPBA
  3. Question answering   deepset/biobert-base-cased-squad2       PubMed + PMC + SQuAD2
  4. Semantic similarity  neuml/pubmedbert-base-embeddings        PubMed abstracts

  All models are BERT-base size (~110M params) — fast on CPU, no GPU needed.

  General models fail on clinical text because:
    - Medical abbreviations (COPD, PRN, CXR) are out-of-vocabulary
    - Drug and disease names appear rarely in web-crawled training data
    - Clinical negation ("no evidence of pneumonia") is handled differently

  Domain-specific pre-training + task fine-tuning = reliable clinical NLP
  without spending months collecting labelled data.
""")
print(SEP)
print("  End of demo.  Questions?")
print(SEP)
