"""
Loan Approval Prediction API
=============================
Loads the trained RandomForest model (best_loan_approval_model.pkl)
and exposes a /predict endpoint.

Prerequisites:
    pip install fastapi uvicorn scikit-learn pandas

Run:
    uvicorn loan_api:app --reload
"""

import pickle
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# ---------------------------------------------------------------------------
# Load model at startup (fail fast if pkl is missing)
# ---------------------------------------------------------------------------
MODEL_PATH = "best_loan_approval_model.pkl"

try:
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
except FileNotFoundError:
    raise RuntimeError(
        f"Model file '{MODEL_PATH}' not found. "
        "Run ml_loanapproval_prediction.py first to train and save the model."
    )

# ---------------------------------------------------------------------------
# Request schema
# Feature names must match exactly what the model was trained on (X columns).
# The ml-ready dataset uses log-transformed versions of income/loan amounts
# and encoded versions of categorical columns.
# ---------------------------------------------------------------------------
class LoanApplication(BaseModel):
    age: float
    gender: int                   # encoded: e.g. 0 = Female, 1 = Male
    occupation: int               # encoded: e.g. 0 = Employed, 1 = Self-Employed, ...
    dependents: int
    city: int                     # encoded city
    property_area: int            # encoded: e.g. 0 = Rural, 1 = Semiurban, 2 = Urban
    credit_score: float
    loan_purpose: int             # encoded loan purpose
    loan_term: float              # in months
    proposed_emi: float
    existing_emi: float
    debt_to_income_ratio: float
    co_applicant: int             # 0 = No, 1 = Yes
    monthly_income_log: float     # log(monthly_income)
    loan_amount_log: float        # log(loan_amount)
    co_applicant_income_log: float  # log(co_applicant_income + 1) to handle 0

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------
app = FastAPI(
    title="Loan Approval Prediction API",
    description="Predicts whether a loan will be approved using a tuned Random Forest model.",
    version="1.0.0",
)


@app.get("/")
def root():
    return {"message": "Loan Approval API is running. POST to /predict to get a prediction."}


@app.get("/health")
def health():
    return {"status": "ok", "model": type(model).__name__}


@app.post("/predict")
def predict(application: LoanApplication):
    """
    Returns:
        - prediction: 1 (Approved) or 0 (Rejected)
        - result: human-readable label
        - probability_approved: confidence score (0-1)
    """
    # Build a single-row DataFrame with the same column order the model expects
    input_data = pd.DataFrame([application.model_dump()])

    try:
        prediction = int(model.predict(input_data)[0])
        probability = float(model.predict_proba(input_data)[0][1])
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Prediction error: {str(e)}")

    return {
        "prediction": prediction,
        "result": "Approved" if prediction == 1 else "Rejected",
        "probability_approved": round(probability, 4),
    }
