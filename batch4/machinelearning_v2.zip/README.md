# ML Demo — Loan Approval Prediction & Customer Segmentation

End-to-end machine learning pipeline on a messy Indian loan approval dataset, plus a standalone clustering demo that compares unsupervised, rule-based, and supervised approaches to customer segmentation.
Covers data cleaning, EDA, feature engineering, model training, hyperparameter tuning, serving predictions via a REST API, and K-Means clustering.

---

## Files

| File | Purpose |
|------|---------|
| `indian_loan_approval_data_messy.csv` | Raw dataset with intentional messiness (mixed formats, missing values, irrelevant columns) |
| `eda_loandata.py` | Exploratory Data Analysis and feature engineering — produces the ML-ready dataset |
| `ml_loanapproval_prediction.py` | Model training, comparison, tuning, evaluation, and saving the best model |
| `api_loanapproval.py` | FastAPI REST service that loads the saved model and serves predictions |
| `loan_data_mlready.csv` | Cleaned, encoded, scaled dataset produced by `eda_loandata.py` (generated) |
| `best_loan_approval_model.pkl` | Serialised best Random Forest model produced by `ml_loanapproval_prediction.py` (generated) |
| `clustering.py` | Standalone demo comparing Rule-Based, Supervised ML, and K-Means Clustering for customer segmentation |
| `requirements.txt` | Python package dependencies |

---

## Execution Sequence

Run the scripts in this order:

### Step 1 — EDA & Feature Engineering
```bash
python eda_loandata.py
```
Reads `indian_loan_approval_data_messy.csv`, walks through the full EDA interactively (press Enter at each pause), and writes `loan_data_mlready.csv`.

### Step 2 — Model Training
```bash
python ml_loanapproval_prediction.py
```
Reads `loan_data_mlready.csv`, trains and compares three classifiers, tunes the best one with GridSearchCV, and saves `best_loan_approval_model.pkl`.

### Step 3 — API Server
```bash
uvicorn api_loanapproval:app --reload
```
Loads the saved model and exposes a REST endpoint. Open `http://127.0.0.1:8000/docs` for the interactive Swagger UI.

---

### Clustering Demo (standalone — no prerequisites)
```bash
python clustering.py
```
Self-contained script, runs independently of the loan pipeline. Press Enter at each pause to step through the three approaches.

---

## Key Learnings

### Data Quality & Cleaning
- Real datasets contain mixed formats (e.g. `Rs 45000`, `INR45000`, `45000`) — normalisation must happen before any analysis.
- Missing values need different strategies depending on column type: median for numericals, mode for categoricals.
- Some columns look like features but are pure noise (`shoe_size`, `favorite_color`, `hobby`) — domain knowledge and correlation analysis reveal them.

### Exploratory Data Analysis
- Always check the target variable distribution first — class imbalance will skew every metric downstream.
- Correlation heatmaps identify both useful features (high |r| with target) and multicollinearity traps (high |r| between features).
- Visualising distributions before and after transformations (log, scaling) builds intuition for *why* transformations help.

### Feature Engineering
- **Binning** (`pd.cut`, `pd.qcut`) converts continuous features into interpretable categories useful for analysis, though the raw/scaled versions are typically better for models.
- **Log transformation** reduces right skew in income and loan amount features, making distributions closer to normal.
- **Ordinal encoding** is appropriate when categories have a natural order (education levels, credit tiers). Use one-hot encoding for nominal categories.
- **StandardScaler** is essential for distance-based and regularised algorithms; tree-based models are scale-invariant but it does not hurt them.

### Model Selection & Evaluation
- No single algorithm always wins — comparing Logistic Regression, Random Forest, and Gradient Boosting on the same data reveals trade-offs between interpretability and performance.
- Accuracy alone is misleading on imbalanced classes — always check F1-score, precision/recall, and the confusion matrix together.
- The **ROC-AUC** score measures a model's ability to rank predictions correctly, independent of the classification threshold.
- **Feature importance** from tree models gives a post-hoc explanation of which inputs drove decisions.

### Hyperparameter Tuning
- Default hyperparameters rarely give the best model — GridSearchCV systematically searches the parameter space using cross-validation.
- Tuning `n_estimators`, `max_depth`, and `min_samples_split` in Random Forest controls the bias-variance trade-off.
- Cross-validation (CV) during tuning prevents the best parameters from being overfit to the test set.

### Clustering & Unsupervised Learning
- The core value of clustering is **label-free discovery** — it finds natural groupings without anyone pre-defining what those groups should look like.
- **Feature scaling is mandatory** before K-Means: without it, high-magnitude features (e.g. income in the tens of thousands) dominate the distance calculation and drown out low-magnitude ones (e.g. age).
- Single-feature rules fail on data where two very different groups share similar values on that feature (students and executives both spend ~$2,250 on tech). Clustering evaluates all features simultaneously and separates them cleanly.
- **Rule-based segmentation** bakes in human assumptions upfront — you can only find segments you already expected. Clustering surfaces patterns you didn't know to look for.
- **Supervised ML cannot bootstrap itself** for segmentation: you need labels to train, but discovering the labels is the whole goal — a circular dependency. Clustering has no such requirement.
- The **Elbow Method** (plotting inertia vs K) is a practical heuristic for choosing the number of clusters; look for the point where adding another cluster gives sharply diminishing returns.
- Cluster IDs are arbitrary numbers — the human's only job after clustering is to name the discovered segments by inspecting their profiles (e.g. high income + high age = "Executive").

### Model Deployment
- Saving a model with `pickle` decouples training from serving — the API loads the model once at startup and reuses it for every request.
- The API must reconstruct **exactly the same feature vector** (including one-hot column order) that the model was trained on — any mismatch causes silent wrong predictions.
- FastAPI + Pydantic enforces input validation at the schema level, rejecting invalid requests before they reach the model.

---

## Suggested Explorations & Enhancements

### Data & Features
- **Handle class imbalance** — try SMOTE (`imbalanced-learn`) or class-weight adjustments and observe the effect on recall for the minority class.
- **Feature selection pipeline** — use `SelectKBest` or Recursive Feature Elimination (RFE) instead of manually dropping columns based on correlation.
- **Interaction features** — create `emi_to_income_ratio = proposed_emi / monthly_income` or `total_emi_burden = proposed_emi + existing_emi` and check if they improve the model.
- **Outlier treatment** — instead of ignoring outliers, cap them at IQR bounds (winsorisation) and compare model performance before and after.

### Modelling
- **Try XGBoost or LightGBM** — add `xgboost` or `lightgbm` to the model comparison loop; they often outperform sklearn's GradientBoosting.
- **Calibrate probabilities** — use `CalibratedClassifierCV` to make the `probability_approved` output more reliable for threshold-based decisions.
- **Cross-validation scoring** — replace the single train/test split with `cross_val_score` to get more stable performance estimates.
- **Threshold tuning** — the default 0.5 classification threshold may not be optimal; plot precision-recall curves and choose a threshold that matches the business cost of false positives vs false negatives.
- **Explain individual predictions** — integrate SHAP (`shap` library) to show which features pushed a specific application toward approval or rejection.

### Clustering Explorations
- **Try different algorithms** — DBSCAN requires no upfront K and can identify outliers as noise; Agglomerative Clustering builds a dendrogram that shows how groups merge at different scales.
- **Silhouette score** — complement the Elbow Method with `sklearn.metrics.silhouette_score` to get a quantitative measure of how well-separated the clusters are.
- **Apply clustering to the loan dataset** — run K-Means on the loan applicants (unsupervised) and compare the discovered segments to the actual approval labels. Do applicants naturally cluster into "likely approved" vs "likely rejected"?
- **Cluster then classify** — use cluster assignments as an additional feature in the supervised loan approval model and measure whether it improves accuracy.
- **Visualise high-dimensional clusters** — reduce features to 2D with PCA or t-SNE before plotting; this works when you have more than 3 features and can't use a 3D scatter plot.
- **Customer personas** — extend the clustering demo with a fourth synthetic group (e.g. "Retired High-Savers": age 60+, high income, low spend) and observe whether K-Means still separates them with K=4.

### API & Deployment
- **Persist the scaler** — save the `StandardScaler` alongside the model with pickle so the API can accept raw input values and scale them server-side, removing the burden from the caller.
- **Add input preprocessing to the API** — accept raw `monthly_income` and compute `monthly_income_log` internally, making the API easier to consume.
- **Add a `/batch_predict` endpoint** — accept a list of applications and return predictions for all in one call.
- **Containerise with Docker** — write a `Dockerfile` that installs dependencies and runs `uvicorn`; the model then deploys anywhere without environment setup.
- **Monitor prediction drift** — log every request and response to a file or database; periodically compare the distribution of incoming features against the training data to detect drift.
- **A/B test two models** — extend the API to load two `.pkl` files and randomly route requests between them, logging outcomes to compare live performance.
