# -*- coding: utf-8 -*-
import sys, io
if hasattr(sys.stdout, 'buffer'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

"""
04_ocr_scanned_pdfs.py
=======================
Demo: Unstructured Data Processing in Healthcare
Topic: OCR from Scanned PDFs and Prescription Images

TWO POPULAR OCR LIBRARIES DEMONSTRATED:
  1. Tesseract OCR  — via pytesseract (Google, open-source, industry standard)
  2. EasyOCR        — via easyocr    (deep learning, better on degraded images)

PREREQUISITES:
  1. Run: python data/generate_synthetic_pdfs.py
  2. pip install pytesseract easyocr Pillow opencv-python-headless pdf2image
  3. Install Tesseract binary:
       Windows: https://github.com/UB-Mannheim/tesseract/wiki
       Ubuntu:  sudo apt-get install tesseract-ocr
       Mac:     brew install tesseract

DATA CHALLENGES HIGHLIGHTED:
  - Image quality: noise, blur, skew, low DPI
  - Handwriting vs typewritten text
  - Medical abbreviations + handwriting = high error rate
  - Table structure lost in scanned images
  - Special characters: µ, °, ×, arrows
  - Multi-column layouts in scanned forms
  - Post-OCR correction strategies
"""

import re
import time
from pathlib import Path
from collections import Counter

DATA_DIR = Path(__file__).parent / "data"
SEPARATOR = "\n" + "=" * 80 + "\n"
SEP_MINOR = "\n" + "-" * 60 + "\n"


# ─────────────────────────────────────────────────────────────────────────────
# DEPENDENCY CHECK
# ─────────────────────────────────────────────────────────────────────────────

def check_dependencies() -> dict:
    libs = {}
    for lib in ["pytesseract", "easyocr", "PIL", "cv2", "pdf2image"]:
        import_name = "PIL" if lib == "PIL" else lib
        try:
            __import__(import_name)
            libs[lib] = True
        except ImportError:
            libs[lib] = False

    # Check Tesseract binary
    if libs.get("pytesseract"):
        import pytesseract
        try:
            pytesseract.get_tesseract_version()
            libs["tesseract_binary"] = True
        except Exception:
            libs["tesseract_binary"] = False
            print("[WARN] Tesseract binary not found. Install from:")
            print("       Windows: https://github.com/UB-Mannheim/tesseract/wiki")
            print("       Ubuntu: sudo apt-get install tesseract-ocr")

    return libs


# ─────────────────────────────────────────────────────────────────────────────
# IMAGE PREPROCESSING — Critical for OCR Accuracy
# ─────────────────────────────────────────────────────────────────────────────

def preprocess_image_for_ocr(image_path: Path, method: str = "adaptive") -> "PIL.Image":
    """
    CHALLENGE: Scanned documents have noise, uneven lighting, skew.
    Preprocessing dramatically improves OCR accuracy.

    Methods:
      'none'      — no preprocessing (baseline)
      'grayscale' — convert to grayscale only
      'threshold' — Otsu's binarization (global threshold)
      'adaptive'  — adaptive thresholding (better for uneven lighting)
      'deskew'    — correct skew + adaptive threshold
    """
    from PIL import Image, ImageFilter, ImageEnhance, ImageOps

    img = Image.open(image_path)

    print(f"  Original: {img.size[0]}×{img.size[1]} px, mode={img.mode}")

    if method == "none":
        return img

    # Convert to RGB if needed
    if img.mode != "RGB":
        img = img.convert("RGB")

    if method == "grayscale":
        return img.convert("L")

    # Upscale if DPI is too low (< 200 DPI hurts Tesseract)
    w, h = img.size
    if w < 800:
        scale = 2
        img = img.resize((w * scale, h * scale), Image.LANCZOS)
        print(f"  Upscaled to: {img.size[0]}×{img.size[1]} px (DPI too low)")

    # Convert to grayscale
    gray = img.convert("L")

    # Enhance contrast
    enhancer = ImageEnhance.Contrast(gray)
    gray = enhancer.enhance(2.0)

    if method == "threshold":
        # Simple Otsu-like threshold via PIL
        gray = gray.point(lambda x: 0 if x < 128 else 255, "1")
        gray = gray.convert("L")

    elif method in ("adaptive", "deskew"):
        # Use OpenCV for better adaptive thresholding if available
        try:
            import cv2
            import numpy as np

            np_img = np.array(gray)

            # Adaptive Gaussian thresholding — handles uneven illumination
            thresh = cv2.adaptiveThreshold(
                np_img, 255,
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY,
                blockSize=11, C=2
            )

            # Deskew using Hough line transform
            if method == "deskew":
                edges = cv2.Canny(thresh, 50, 150, apertureSize=3)
                lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 100,
                                         minLineLength=100, maxLineGap=10)
                if lines is not None:
                    angles = []
                    for line in lines:
                        x1, y1, x2, y2 = line[0]
                        if x2 != x1:
                            angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
                            if abs(angle) < 15:
                                angles.append(angle)
                    if angles:
                        median_angle = float(np.median(angles))
                        if abs(median_angle) > 0.5:
                            center = (thresh.shape[1] // 2, thresh.shape[0] // 2)
                            rot_matrix = cv2.getRotationMatrix2D(center, median_angle, 1.0)
                            thresh = cv2.warpAffine(thresh, rot_matrix, thresh.shape[1::-1],
                                                     flags=cv2.INTER_LINEAR,
                                                     borderValue=255)
                            print(f"  Deskew applied: {median_angle:.2f}° correction")

            # Denoise
            denoised = cv2.fastNlMeansDenoising(thresh, h=10)
            gray = Image.fromarray(denoised)

        except ImportError:
            print("  [INFO] OpenCV not available — using basic PIL threshold")
            gray = gray.point(lambda x: 0 if x < 128 else 255, "1").convert("L")

    print(f"  Preprocessed: method='{method}'")
    return gray


# ─────────────────────────────────────────────────────────────────────────────
# LIBRARY 1: TESSERACT OCR (via pytesseract)
# ─────────────────────────────────────────────────────────────────────────────

def ocr_with_tesseract(image, lang: str = "eng", config: str = "") -> dict:
    """
    Tesseract OCR — Google's open-source OCR engine.
    Industry standard, excellent for typewritten English text.
    Config options:
      --psm 3  : Fully automatic page segmentation (default)
      --psm 6  : Uniform block of text (good for single-column)
      --psm 11 : Sparse text (good for sparse, multi-directional)
      --oem 3  : Default (neural nets LSTM engine)
    Returns dict with text, confidence, word-level data.
    """
    import pytesseract

    # Configure for medical documents
    if not config:
        config = "--oem 3 --psm 3"

    start = time.time()

    # Basic text extraction
    text = pytesseract.image_to_string(image, lang=lang, config=config)

    # Word-level confidence data
    data = pytesseract.image_to_data(image, lang=lang, config=config,
                                      output_type=pytesseract.Output.DICT)

    elapsed = time.time() - start

    # Calculate average confidence (ignore -1 values)
    confidences = [int(c) for c in data["conf"] if int(c) > 0]
    avg_conf = sum(confidences) / len(confidences) if confidences else 0
    low_conf_words = [(data["text"][i], int(data["conf"][i]))
                       for i in range(len(data["text"]))
                       if data["text"][i].strip() and int(data["conf"][i]) > 0 and int(data["conf"][i]) < 50]

    return {
        "library": "Tesseract",
        "text": text,
        "char_count": len(text),
        "word_count": len(text.split()),
        "avg_confidence": round(avg_conf, 1),
        "low_conf_words": low_conf_words[:10],
        "time_seconds": round(elapsed, 2),
    }


# ─────────────────────────────────────────────────────────────────────────────
# LIBRARY 2: EasyOCR
# ─────────────────────────────────────────────────────────────────────────────

def ocr_with_easyocr(image_path: Path, langs: list = None) -> dict:
    """
    EasyOCR — deep learning-based OCR (CRAFT + CRNN).
    Better on degraded, rotated, or scene text.
    Supports 80+ languages including Devanagari (Hindi).
    Returns dict with text, bounding boxes, and confidence.
    """
    import easyocr

    if langs is None:
        langs = ["en"]

    # Initialize reader (downloads model on first run ~100MB)
    print("  Initializing EasyOCR reader (may download model on first run)...")
    reader = easyocr.Reader(langs, gpu=False, verbose=False)

    start = time.time()
    results = reader.readtext(str(image_path))  # returns [(bbox, text, confidence)]
    elapsed = time.time() - start

    # Consolidate results
    full_text = "\n".join(r[1] for r in results)
    confidences = [r[2] for r in results]
    avg_conf = sum(confidences) / len(confidences) if confidences else 0

    low_conf_items = [(r[1], round(r[2] * 100, 1))
                       for r in results if r[2] < 0.5]

    return {
        "library": "EasyOCR",
        "text": full_text,
        "char_count": len(full_text),
        "word_count": len(full_text.split()),
        "avg_confidence": round(avg_conf * 100, 1),
        "low_conf_words": low_conf_items[:10],
        "detection_count": len(results),
        "time_seconds": round(elapsed, 2),
        "raw_results": results[:5],  # first 5 for inspection
    }


# ─────────────────────────────────────────────────────────────────────────────
# POST-OCR PROCESSING
# ─────────────────────────────────────────────────────────────────────────────

# Common OCR errors in medical text
OCR_CORRECTIONS = {
    # Character confusions (common in degraded scans)
    r'\b0(?=\s*mg|\s*ml|\s*mcg)': 'O',    # 0mg → Omg (if before dosage unit)
    r'\bl(?=\d)': '1',                      # l → 1 before digits (letter vs number)
    r'(?<=\d)l\b': '1',                     # 1l → 11 (trailing l)
    r'\bO(?=\d)': '0',                      # O → 0 before digits
    r'\bmetr0pol': 'metropol',               # specific drug name OCR error
    r'\bfurosemlde\b': 'furosemide',
    r'\bllsinopril\b': 'lisinopril',
    r'\basp1rin\b': 'aspirin',
    r'\bm9\b': 'mg',
    r'\bmg1\b': 'mg',
    r'\bTab\.\s+': 'Tab. ',
    # Number misreads
    r'\bS0\b': '50',
    r'\bl00\b': '100',
    r'\bl0mg\b': '10mg',
    # Unit OCR errors
    r'\bmg\s*[\|l]\s': 'mg ',
    r'\bm8\b': 'mg',
}

MEDICAL_WORD_LIST = {
    "furosemide", "lisinopril", "metoprolol", "telmisartan", "sertraline",
    "aspirin", "spironolactone", "enoxaparin", "rivaroxaban", "metformin",
    "amlodipine", "atenolol", "omeprazole", "paracetamol", "ibuprofen",
    "amoxicillin", "azithromycin", "ceftriaxone", "ondansetron", "tramadol",
    "insulin", "heparin", "warfarin", "digoxin", "atorvastatin", "ramipril",
    "hypertension", "diabetes", "cardiac", "renal", "hepatic",
    "twice", "daily", "morning", "evening", "tablet", "capsule", "injection",
    "blood", "pressure", "glucose", "weight", "kidney", "heart",
}


def correct_ocr_output(text: str) -> str:
    """
    CHALLENGE: OCR errors in medical text are dangerous.
    'furosemide' read as 'furose1nide' or '40mg' as '4Omg' can cause harm.
    Apply medical-domain-specific corrections.
    """
    for pattern, replacement in OCR_CORRECTIONS.items():
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
    return text


def spell_check_medical(text: str) -> list[dict]:
    """
    Simple medical spell-check using edit distance.
    Identify words that might be OCR errors of known medical terms.
    """
    try:
        from difflib import get_close_matches
    except ImportError:
        return []

    words = re.findall(r'\b[A-Za-z]{4,}\b', text)
    suspicious = []
    for word in words:
        word_lower = word.lower()
        if word_lower not in MEDICAL_WORD_LIST:
            # Check if it's close to a medical word (OCR error candidate)
            close = get_close_matches(word_lower, MEDICAL_WORD_LIST, n=1, cutoff=0.75)
            if close:
                suspicious.append({
                    "ocr_word": word,
                    "suggested": close[0],
                    "likely_ocr_error": True,
                })
    return suspicious[:10]


def extract_prescription_details(text: str) -> dict:
    """
    Extract structured prescription information from OCR text.
    CHALLENGE: OCR errors + handwriting = unreliable extraction.
    Must use fuzzy/robust patterns.
    """
    result = {}

    # Patient name — various formats
    name_m = re.search(r'(?:Name\s*[:;]?\s*|Patient\s*[:;]?\s*)(Mr\.?\s*|Mrs\.?\s*|Ms\.?\s*)?([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)',
                        text, re.IGNORECASE)
    if name_m:
        result["patient_name"] = (name_m.group(1) or "") + name_m.group(2)

    # Age/Sex
    age_m = re.search(r'Age\s*[:/]?\s*(\d{1,3})\s*(?:Yrs?|Y|Years?)?(?:\s*/\s*([MFmf]))?', text)
    if age_m:
        result["age"] = age_m.group(1)
        result["sex"] = {"M": "Male", "F": "Female"}.get((age_m.group(2) or "").upper(), "Unknown")

    # Date — OCR often garbles date separators
    date_m = re.search(r'Date\s*[:;]?\s*(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4})', text)
    if date_m:
        result["date"] = date_m.group(1)

    # Doctor name
    doc_m = re.search(r'Dr\.?\s+([A-Z][a-z.]+(?:\s+[A-Z][a-z.]+)*)', text)
    if doc_m:
        result["doctor"] = "Dr. " + doc_m.group(1)

    # Medications — numbered list
    meds = []
    med_pattern = re.compile(
        r'(\d+)[\.\)]\s*'
        r'(?:Tab\.?\s*|Cap\.?\s*|Inj\.?\s*)?'
        r'([A-Za-z][a-zA-Z\s]{3,25}?)\s+'
        r'(\d{1,4}(?:\.\d+)?)\s*(?:mg|mcg|ml|g|units?)\s*'
        r'[-–]?\s*'
        r'([\d\-OoXx]+(?:\s+(?:BD|OD|TID|QID|PRN|SOS))?)?',
        re.IGNORECASE
    )
    for m in med_pattern.finditer(text):
        meds.append({
            "number": m.group(1),
            "drug": m.group(2).strip(),
            "dose": m.group(3),
            "sig": (m.group(4) or "").strip(),
        })
    result["medications"] = meds

    return result


def compare_ocr_results(tesseract_result: dict, easyocr_result: dict, ground_truth: str = None):
    """
    Compare output from both OCR libraries.
    In production: use ground truth from manually verified samples.
    """
    print("\n── OCR Library Comparison ──")
    print(f"{'Metric':25s} {'Tesseract':>15s} {'EasyOCR':>15s}")
    print("─" * 57)

    metrics = [
        ("Characters extracted", "char_count"),
        ("Words extracted", "word_count"),
        ("Avg confidence (%)", "avg_confidence"),
        ("Processing time (s)", "time_seconds"),
    ]
    for label, key in metrics:
        t_val = tesseract_result.get(key, "N/A")
        e_val = easyocr_result.get(key, "N/A")
        print(f"  {label:23s} {str(t_val):>15s} {str(e_val):>15s}")

    # Word overlap between the two
    t_words = set(tesseract_result.get("text", "").lower().split())
    e_words = set(easyocr_result.get("text", "").lower().split())
    overlap = t_words & e_words
    union = t_words | e_words
    jaccard = len(overlap) / len(union) if union else 0
    print(f"  {'Word agreement (Jaccard)':23s} {jaccard:.2%}")
    print()

    if ground_truth:
        gt_words = set(ground_truth.lower().split())
        t_recall = len(t_words & gt_words) / len(gt_words) if gt_words else 0
        e_recall = len(e_words & gt_words) / len(gt_words) if gt_words else 0
        print(f"  {'Word Recall vs GT':23s} {t_recall:.2%}           {e_recall:.2%}")

    print()
    print("[CHALLENGE: FORMAT VARIATION] Each library has strengths:")
    print("  Tesseract: faster, well-tested on printed English, good PSM options")
    print("  EasyOCR  : better on rotated/degraded text, multi-language (incl. Hindi)")
    print("  Best practice: use both + ensemble/voting for critical medical docs")


# ─────────────────────────────────────────────────────────────────────────────
# DEMO: DPI AND QUALITY IMPACT
# ─────────────────────────────────────────────────────────────────────────────

def demonstrate_dpi_impact(image_path: Path, libs: dict):
    """
    CHALLENGE: Scanning quality critically affects OCR accuracy.
    Show effect of DPI/resolution on extraction quality.
    """
    print(SEPARATOR)
    print("SECTION: Impact of Image Quality on OCR")
    print(SEPARATOR)

    try:
        from PIL import Image
    except ImportError:
        print("[SKIP] Pillow not available")
        return

    img = Image.open(image_path)
    original_size = img.size

    print(f"Original image: {original_size[0]}×{original_size[1]} px\n")
    print("Quality levels tested:")

    quality_levels = [
        ("Low quality (50%)", 0.5),
        ("Medium quality (75%)", 0.75),
        ("Original (100%)", 1.0),
        ("High quality (150%)", 1.5),
    ]

    results = []
    for label, scale in quality_levels:
        new_w = int(original_size[0] * scale)
        new_h = int(original_size[1] * scale)
        resized = img.resize((new_w, new_h),
                             Image.LANCZOS if scale >= 1 else Image.BILINEAR)

        if libs.get("pytesseract") and libs.get("tesseract_binary"):
            import pytesseract
            try:
                text = pytesseract.image_to_string(resized.convert("L"), config="--oem 3 --psm 6")
                word_count = len(text.split())
                results.append((label, f"{new_w}×{new_h}", word_count))
            except Exception as e:
                results.append((label, f"{new_w}×{new_h}", f"Error: {e}"))
        else:
            results.append((label, f"{new_w}×{new_h}", "Tesseract not available"))

    print(f"  {'Quality':30s} {'Resolution':15s} {'Words Extracted':>15s}")
    print("  " + "─" * 60)
    for label, res, words in results:
        print(f"  {label:30s} {res:15s} {str(words):>15s}")

    print("\n[CHALLENGE: IMAGE QUALITY] Recommendation for medical documents:")
    print("  • Minimum 300 DPI for typed/printed documents")
    print("  • 400-600 DPI for handwritten prescriptions")
    print("  • Color scan (not grayscale) preserves ink color for better thresholding")
    print("  • Flatbed scanners > phone cameras for patient records")


# ─────────────────────────────────────────────────────────────────────────────
# DEMO: PREPROCESSING COMPARISON
# ─────────────────────────────────────────────────────────────────────────────

def demonstrate_preprocessing(image_path: Path, libs: dict):
    """Show how different preprocessing methods affect OCR output."""
    print(SEPARATOR)
    print("SECTION: Image Preprocessing Impact on OCR")
    print(SEPARATOR)

    if not (libs.get("pytesseract") and libs.get("tesseract_binary") and libs.get("PIL")):
        print("[SKIP] Requires pytesseract + tesseract binary + Pillow")
        return

    import pytesseract

    methods = ["none", "grayscale", "threshold", "adaptive", "deskew"]
    print(f"  {'Method':15s} {'Words':>8s} {'Chars':>8s} {'Notes'}")
    print("  " + "─" * 65)

    for method in methods:
        try:
            preprocessed = preprocess_image_for_ocr(image_path, method)
            text = pytesseract.image_to_string(preprocessed, config="--oem 3 --psm 3")
            words = len(text.split())
            chars = len(text.strip())
            note = "[BASELINE]" if method == "none" else ""
            if method == "adaptive":
                note = "[RECOMMENDED for medical docs]"
            print(f"  {method:15s} {words:>8d} {chars:>8d} {note}")
        except Exception as e:
            print(f"  {method:15s} {'ERROR':>8s}          {str(e)[:40]}")

    print("\n[CHALLENGE: NOISE] Preprocessing steps in order of importance:")
    print("  1. Upscale if < 300 DPI  → more pixels = better character recognition")
    print("  2. Deskew                → OCR accuracy drops sharply beyond 5° tilt")
    print("  3. Adaptive threshold    → handles uneven illumination in mobile scans")
    print("  4. Denoising             → remove scanner/JPEG artifacts")
    print("  5. Morphological ops     → fix broken characters, remove noise speckles")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN DEMO RUNNER
# ─────────────────────────────────────────────────────────────────────────────

def run_main_ocr_demo(libs: dict):
    """Run OCR on the two synthetic prescription images."""
    images = [
        ("Typewritten Prescription (with scan artifacts)", "scanned_prescription.png"),
        ("Handwritten-style Prescription (harder)", "handwritten_prescription.png"),
    ]

    for title, filename in images:
        print(SEPARATOR)
        print(f"OCR DEMO: {title}")
        print(SEPARATOR)

        image_path = DATA_DIR / filename
        if not image_path.exists():
            print(f"[ERROR] Image not found: {image_path}")
            print("  → Run: python data/generate_synthetic_pdfs.py")
            continue

        print(f"Image file: {filename}\n")

        # ── Library 1: Tesseract ──
        t_result = {"library": "Tesseract", "text": "", "char_count": 0,
                     "word_count": 0, "avg_confidence": 0, "time_seconds": 0}

        if libs.get("pytesseract") and libs.get("tesseract_binary"):
            print("── Tesseract OCR ──")
            try:
                preprocessed = preprocess_image_for_ocr(image_path, "adaptive")
                t_result = ocr_with_tesseract(preprocessed, config="--oem 3 --psm 6")
                print(f"  Words: {t_result['word_count']} | "
                      f"Confidence: {t_result['avg_confidence']}% | "
                      f"Time: {t_result['time_seconds']}s")

                if t_result["low_conf_words"]:
                    print(f"  Low-confidence words (< 50%):")
                    for word, conf in t_result["low_conf_words"][:6]:
                        print(f"    '{word}' → {conf}%")

                print(f"\n  Extracted text (first 400 chars):")
                print(f"  {t_result['text'][:400].replace(chr(10), ' | ')}")

                # Post-process
                corrected = correct_ocr_output(t_result["text"])
                suspects = spell_check_medical(corrected)
                if suspects:
                    print(f"\n  [POST-OCR] Likely OCR errors in medical terms:")
                    for s in suspects[:5]:
                        print(f"    '{s['ocr_word']}' → did you mean '{s['suggested']}'?")
            except Exception as e:
                print(f"  [ERROR] Tesseract failed: {e}")
        else:
            print("── Tesseract OCR ──")
            print("  [SKIP] Tesseract not available. Install pytesseract + tesseract binary")
            print("         pip install pytesseract")
            print("         Windows: install binary from UB-Mannheim GitHub")
            # Simulate with manual text for demo continuity
            t_result["text"] = "[Tesseract not installed — showing simulated output]\n" \
                                "Tab. Furosemide  40 mg  1-0-1  (BD) x 30 days\n" \
                                "Tab. Metopr0lol  50 mg  1-0-0  (OD) x 30 days"
            t_result["word_count"] = 20

        print()

        # ── Library 2: EasyOCR ──
        e_result = {"library": "EasyOCR", "text": "", "char_count": 0,
                     "word_count": 0, "avg_confidence": 0, "time_seconds": 0}

        if libs.get("easyocr"):
            print("── EasyOCR ──")
            try:
                e_result = ocr_with_easyocr(image_path, langs=["en"])
                print(f"  Detections: {e_result['detection_count']} regions | "
                      f"Words: {e_result['word_count']} | "
                      f"Confidence: {e_result['avg_confidence']}% | "
                      f"Time: {e_result['time_seconds']}s")

                if e_result["low_conf_words"]:
                    print(f"  Low-confidence detections (< 50%):")
                    for word, conf in e_result["low_conf_words"][:6]:
                        print(f"    '{word}' → {conf}%")

                print(f"\n  Extracted text (first 400 chars):")
                print(f"  {e_result['text'][:400].replace(chr(10), ' | ')}")

                # Show bounding box info for first few detections
                if e_result.get("raw_results"):
                    print(f"\n  Sample detections with bounding boxes:")
                    for bbox, text, conf in e_result["raw_results"][:3]:
                        print(f"    [{conf:.2%}] '{text}' @ bbox {[list(map(int,pt)) for pt in bbox]}")
            except Exception as e:
                print(f"  [ERROR] EasyOCR failed: {e}")
        else:
            print("── EasyOCR ──")
            print("  [SKIP] easyocr not installed. Install: pip install easyocr")
            print("         Note: Downloads ~100MB model on first run")
            e_result["text"] = "[EasyOCR not installed]\n" \
                                "Tab. Furosemide 40 mg — 1-0-1 x 30 days\n" \
                                "Tab. Metoprolol 50 mg — 1-0-0 x 30 days"
            e_result["word_count"] = 20
        print()

        # ── Comparison ──
        compare_ocr_results(t_result, e_result)

        # ── Structured extraction from OCR text ──
        print("── Structured Extraction from OCR Output ──")
        best_text = t_result["text"] if t_result.get("word_count", 0) >= e_result.get("word_count", 0) \
                    else e_result["text"]

        corrected_text = correct_ocr_output(best_text)
        prescription = extract_prescription_details(corrected_text)

        if prescription.get("patient_name"):
            print(f"  Patient : {prescription['patient_name']}")
        if prescription.get("doctor"):
            print(f"  Doctor  : {prescription['doctor']}")
        if prescription.get("date"):
            print(f"  Date    : {prescription['date']}")
        if prescription.get("medications"):
            print(f"  Medications ({len(prescription['medications'])}):")
            for med in prescription["medications"]:
                print(f"    {med['number']}. {med['drug']:25s} {med['dose']:6s} mg  {med['sig']}")
        print()


def run_pdf_to_image_demo():
    """Demonstrate converting scanned PDF to images for OCR."""
    print(SEPARATOR)
    print("SECTION: Scanned PDF → Image → OCR Pipeline")
    print(SEPARATOR)
    print("Scanned PDFs are IMAGE files inside a PDF wrapper.")
    print("They need: PDF → Image (pdf2image) → Preprocess → OCR\n")

    pipeline = [
        ("Step 1: Open scanned PDF",      "pdf2image.convert_from_path('scan.pdf', dpi=300)"),
        ("Step 2: Preprocess each page",  "preprocess_image_for_ocr(page_img, method='adaptive')"),
        ("Step 3: OCR with Tesseract",    "pytesseract.image_to_string(processed_img, lang='eng')"),
        ("Step 4: Post-process output",   "correct_ocr_output(raw_text)"),
        ("Step 5: Extract entities",      "extract_prescription_details(cleaned_text)"),
    ]

    try:
        import pdf2image
        print("[OK] pdf2image is available for PDF → Image conversion\n")
    except ImportError:
        print("[WARN] pdf2image not installed: pip install pdf2image")
        print("       Also requires Poppler: https://poppler.freedesktop.org/\n")

    print("OCR Pipeline for Scanned Healthcare PDFs:")
    for step, code in pipeline:
        print(f"  {step}")
        print(f"    Code: {code}\n")

    print("[CHALLENGE: NOISE] Scanned PDF specific issues:")
    issues = [
        ("Page orientation", "Upside-down pages, landscape pages need auto-rotation"),
        ("Multi-page",        "Each page needs separate OCR; results must be concatenated"),
        ("Handwriting",       "Handwritten prescriptions have 40-60% higher error rate"),
        ("Stamps & seals",    "Hospital stamps over text blocks character recognition"),
        ("Mixed languages",   "Hindi drug names + English dosage = multi-lang OCR needed"),
        ("Faded ink",         "Old records with faded ink → very low OCR confidence"),
        ("Table structure",   "OCR loses table structure — need layout analysis (LayoutParser)"),
    ]
    for issue, desc in issues:
        print(f"  [{issue}] {desc}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("  HEALTHCARE UNSTRUCTURED DATA PROCESSING — DEMO 4")
    print("  Topic: OCR from Scanned Images & PDFs")
    print("=" * 80)

    print("\nChecking dependencies...")
    libs = check_dependencies()
    print(f"\nLibrary availability:")
    for lib, avail in libs.items():
        status = "✓ Available" if avail else "✗ Not installed"
        print(f"  {lib:25s}: {status}")
    print()

    image_path = DATA_DIR / "scanned_prescription.png"
    run_main_ocr_demo(libs)
    demonstrate_preprocessing(image_path, libs)
    demonstrate_dpi_impact(image_path, libs)
    run_pdf_to_image_demo()

    print(SEPARATOR)
    print("SUMMARY OF CHALLENGES IN OCR PROCESSING:")
    print(SEPARATOR)
    challenges = {
        "IMAGE QUALITY":
            "Low DPI (<200), noise, blur → 30-50% word error rate vs <5% at 300 DPI+",
        "SKEW/ROTATION":
            "Even 5° skew drops Tesseract accuracy significantly — always deskew first",
        "HANDWRITING":
            "Tesseract is poor on handwriting; EasyOCR better; LLM-based OCR (GPT-4V) best",
        "MEDICAL VOCABULARY":
            "Drug names garbled by OCR errors → Furosemide → Furosemlde — dangerous",
        "SPECIAL CHARACTERS":
            "µg, ×10³, °C often lost or replaced — units crucial in medical context",
        "TABLE STRUCTURE":
            "OCR destroys table layout — use LayoutParser or Camelot for structured forms",
        "MULTI-LANGUAGE":
            "Indian prescriptions mix English + Hindi/regional — use multi-lang models",
        "CONFIDENCE THRESHOLDS":
            "Flag low-confidence words for human review — never auto-parse unchecked",
    }
    for k, v in challenges.items():
        print(f"  [{k}] {v}")

    print(SEPARATOR)
    print("LIBRARY CHOICE GUIDE:")
    print(SEPARATOR)
    guide = [
        ("Tesseract (pytesseract)", "Clean scanned documents, printed text, fast batch",
         "pip install pytesseract + tesseract binary"),
        ("EasyOCR",                 "Degraded images, rotated text, multi-language (80+)",
         "pip install easyocr"),
        ("pdf2image + Tesseract",   "Scanned PDFs (image-based, not text-based)",
         "pip install pdf2image + poppler"),
        ("pdfplumber/pypdf",        "Machine-readable PDFs (text layer present)",
         "pip install pdfplumber pypdf"),
        ("LayoutParser",            "Complex layouts: forms, tables, multi-column",
         "pip install layoutparser"),
        ("GPT-4V / Claude Vision",  "Handwriting, complex forms, highest accuracy",
         "API access — cloud-based, not local"),
    ]
    print(f"  {'Library':30s} {'Best For':40s} {'Install'}")
    print("  " + "─" * 100)
    for lib, best_for, install in guide:
        print(f"  {lib:30s} {best_for:40s} {install}")
    print()


# ─────────────────────────────────────────────────────────────────────────────
# FURTHER OCR OPTIONS — LIBRARIES, CLOUD SERVICES, AND VISION MODELS
# ─────────────────────────────────────────────────────────────────────────────
#
# This file demonstrates Tesseract and EasyOCR — both open-source, run locally.
# Below is a comparative guide to additional options, from other open-source
# libraries through to enterprise cloud services and large vision models.
#
#
# ── A. OTHER OPEN-SOURCE / LOCAL LIBRARIES ───────────────────────────────────
#
# 1. DOCLING  (IBM Research, 2024)
#    GitHub: https://github.com/DS4SD/docling
#    Install: pip install docling
#
#    What it does:
#      Docling is a document understanding pipeline that goes beyond OCR.
#      It reads PDFs (both native and scanned), Word/PPTX/HTML, and outputs
#      a richly structured document representation (Markdown, JSON, DoclingDocument).
#      It uses layout analysis (DocLayNet model from IBM), table structure
#      recovery, reading-order detection, and optional OCR backends
#      (Tesseract or RapidOCR) under the hood.
#
#    Strengths for healthcare documents:
#      - Preserves table structure from lab reports and discharge summaries —
#        something raw Tesseract cannot do.
#      - Identifies document sections (headers, paragraphs, footnotes) with
#        DocLayNet's trained layout model.
#      - Native PDF text layer extraction when available, OCR only on image pages.
#      - Outputs clean Markdown suitable as LLM context for downstream extraction.
#      - Actively maintained; integrates with LangChain and LlamaIndex out of
#        the box as a document loader.
#
#    Limitations:
#      - Heavier dependency (~1.5 GB model download on first run).
#      - Table recovery is better than raw OCR but still imperfect on
#        handwritten or heavily degraded tables.
#      - Does not solve handwriting OCR — still falls back to Tesseract for
#        handwritten regions.
#      - Currently primarily optimised for English; multilingual support is
#        improving but less mature than EasyOCR's 80-language coverage.
#
#    Best fit: Structured healthcare PDFs (lab reports, discharge summaries,
#    insurance forms) where layout and table preservation matter.
#
#    Quick example:
#      from docling.document_converter import DocumentConverter
#      converter = DocumentConverter()
#      result = converter.convert("lab_report.pdf")
#      markdown_text = result.document.export_to_markdown()
#
# ─────────────────────────────────────────────────────────────────────────────
#
# 2. PADDLEOCR  (Baidu, open-source)
#    Install: pip install paddlepaddle paddleocr
#
#    Strengths:
#      - Excellent accuracy on both printed and handwritten text in 80+ languages.
#      - Stronger than EasyOCR on Chinese/Japanese/Korean and Devanagari scripts —
#        relevant for Indian regional-language prescriptions.
#      - Provides layout analysis, table recognition, and key-value extraction
#        as part of the PP-Structure pipeline.
#      - GPU-accelerated; CPU mode available.
#
#    Limitations:
#      - Large install footprint (PaddlePaddle deep learning framework ~1-2 GB).
#      - Slower cold start than Tesseract.
#      - Less common in Western healthcare tech stacks; fewer tutorials for
#        medical document use cases.
#
#    Best fit: When multi-script Indian language support (Hindi, Tamil, Telugu)
#    is required alongside English on the same document.
#
# ─────────────────────────────────────────────────────────────────────────────
#
# 3. SURYA  (VikParuchuri, 2024)
#    Install: pip install surya-ocr
#
#    Strengths:
#      - State-of-the-art accuracy on printed documents, benchmarks above
#        Tesseract and EasyOCR on standard datasets.
#      - Built-in layout detection, reading order, and table parsing.
#      - Supports 90+ languages.
#      - Faster than cloud APIs for batch processing once model is downloaded.
#
#    Limitations:
#      - GPU strongly recommended for acceptable throughput.
#      - Model download ~500 MB.
#      - Handwriting support is limited (similar to Tesseract).
#
# ─────────────────────────────────────────────────────────────────────────────
#
# 4. MARKER  (VikParuchuri, same author as Surya)
#    Install: pip install marker-pdf
#
#    Strengths:
#      - Converts PDFs (scanned and native) to clean Markdown with high fidelity,
#        including equations, tables, and code blocks.
#      - Uses Surya under the hood for OCR, plus layout models for structure.
#      - Good choice for converting large archives of scanned clinical PDFs into
#        LLM-ready text.
#
#    Limitations:
#      - GPU required for reasonable speed at scale.
#      - Accuracy on degraded, low-quality scans is limited.
#
#
# ── B. CLOUD-BASED OCR SERVICES ──────────────────────────────────────────────
#
# 5. AZURE DOCUMENT INTELLIGENCE  (formerly Azure Form Recognizer)
#    SDK:  pip install azure-ai-documentintelligence
#    Docs: https://learn.microsoft.com/azure/ai-services/document-intelligence/
#
#    What it does:
#      Azure Document Intelligence is a cloud OCR + form understanding service
#      with pre-built and custom models. The most relevant models for healthcare:
#
#      a) Read model (layout + OCR)
#         - High-accuracy OCR with word-level bounding boxes and confidence scores.
#         - Preserves reading order across columns, tables, and headers.
#         - Supports 309 printed languages; 12 handwriting languages (including
#           English handwriting).
#         - Automatically rotates and deskews pages server-side.
#
#      b) Layout model
#         - Extracts tables (with cell-level coordinates), selection marks,
#           section headings, and paragraphs — critical for lab reports and
#           structured forms.
#         - Output is structured JSON with table row/column indices preserved.
#
#      c) Pre-built Health Insurance Card model
#         - Extracts member ID, plan name, payer, group number from insurance
#           cards — relevant for hospital intake and billing workflows.
#
#      d) Custom classification + extraction models
#         - Train on labelled hospital documents (prescriptions, discharge
#           summaries, referral letters) to extract named fields reliably.
#         - Requires ~5-10 labelled samples to start; accuracy improves with more.
#
#    Feasibility for healthcare in India:
#      - Data residency: Azure India Central (Pune) and India South (Chennai)
#        regions are available. Confirm DISHA-compliance and contractual DPA
#        before sending patient data — PHI in transit and at rest must be
#        covered by a BAA (Business Associate Agreement) or equivalent.
#      - API latency: typically 2-8 seconds per page depending on model.
#      - Cost: ~$1.50 per 1,000 pages (Read model, as of 2024 pricing).
#
#    Pros:
#      + Best-in-class accuracy on printed and semi-handwritten documents.
#      + Native table extraction with row/column structure preserved as JSON.
#      + No infrastructure to maintain — scales to millions of pages.
#      + Integrates with Azure Health Data Services and FHIR pipelines.
#      + Confidence scores per word, line, and page allow targeted human review.
#      + Document classification included (identify prescription vs lab report).
#
#    Cons:
#      - PHI leaves your network — requires data processing agreement and
#        DISHA/HIPAA compliance review before production use.
#      - Cost adds up at scale: 10M pages/year = ~$15,000.
#      - Internet dependency — no offline fallback.
#      - Custom model training requires a labelling effort and Azure AI Studio.
#      - Full handwriting accuracy (e.g., doctor's scrawl) still limited;
#        character error rate ~5-15% on poor handwriting.
#
#    Quick example:
#      from azure.ai.documentintelligence import DocumentIntelligenceClient
#      from azure.core.credentials import AzureKeyCredential
#      client = DocumentIntelligenceClient(endpoint, AzureKeyCredential(key))
#      with open("prescription.pdf", "rb") as f:
#          poller = client.begin_analyze_document("prebuilt-layout", f)
#      result = poller.result()
#      for table in result.tables:
#          for cell in table.cells:
#              print(cell.row_index, cell.column_index, cell.content)
#
# ─────────────────────────────────────────────────────────────────────────────
#
# 6. GOOGLE CLOUD DOCUMENT AI
#    SDK:  pip install google-cloud-documentai
#
#    Broadly equivalent to Azure Document Intelligence. Offers pre-built
#    parsers for healthcare forms (CDA documents, insurance claims) via its
#    Healthcare Natural Language API. Google Cloud Mumbai (asia-south1) region
#    available for data residency. Pricing similar to Azure (~$1.50/1,000 pages).
#
# ─────────────────────────────────────────────────────────────────────────────
#
# 7. AWS TEXTRACT
#    SDK:  pip install amazon-textract-caller
#
#    AWS equivalent; strong on structured forms (key-value pairs, tables).
#    Available in ap-south-1 (Mumbai). Often used in AWS HealthLake / FHIR
#    pipelines. Pricing comparable to Azure/GCP.
#
#
# ── C. VISION LANGUAGE MODELS (VLMs) FOR OCR ────────────────────────────────
#
# 8. GPT-4o / GPT-4V  (OpenAI)
#    API endpoint: chat completions with image input
#    Model: gpt-4o  (multimodal)
#
#    How to use for OCR:
#      Encode the prescription image as base64 and send it in the user message
#      with a structured extraction prompt:
#        "Extract all medication names, doses, and frequencies from this
#         prescription image. Return as JSON."
#      The model reads the image directly — no separate preprocessing needed.
#
#    Feasibility:
#      VERY HIGH for accuracy, especially on handwritten prescriptions. GPT-4V
#      achieves ~70-80% field-level accuracy on challenging handwritten scripts
#      where Tesseract achieves ~40-50%.
#
#    Pros:
#      + Best available accuracy on handwriting, mixed scripts, degraded images.
#      + No preprocessing pipeline required — handles rotation, noise, low DPI.
#      + Returns structured JSON in one API call — combines OCR + extraction.
#      + Handles context: "Rx" before a drug name is interpreted correctly.
#      + Works on multi-language documents without explicit language config.
#
#    Cons:
#      - PHI is sent to OpenAI's servers — requires HIPAA BAA and DPA review;
#        currently only available under OpenAI's enterprise tier.
#      - Cost: ~$0.01-0.03 per image (depends on resolution/token count).
#        At 100K prescriptions/month ≈ $1,000-3,000/month.
#      - Latency: 3-8 seconds per image — not suitable for real-time workflows.
#      - Non-deterministic: same image can produce slightly different extractions
#        on repeated calls — problematic for audit trails.
#      - Cannot run offline or on-premises.
#
# ─────────────────────────────────────────────────────────────────────────────
#
# 9. CLAUDE 3.5 SONNET / CLAUDE 3 OPUS  (Anthropic)
#    API: anthropic.Anthropic().messages.create() with image content blocks
#
#    How to use:
#      import anthropic, base64
#      with open("prescription.png", "rb") as f:
#          img_b64 = base64.b64encode(f.read()).decode()
#      client = anthropic.Anthropic()
#      response = client.messages.create(
#          model="claude-sonnet-4-5",
#          max_tokens=1024,
#          messages=[{
#              "role": "user",
#              "content": [
#                  {"type": "image", "source": {
#                      "type": "base64", "media_type": "image/png", "data": img_b64}},
#                  {"type": "text",
#                   "text": "Extract all medications with doses and frequencies as JSON."}
#              ]
#          }]
#      )
#
#    Pros/cons broadly similar to GPT-4V. Claude tends to follow structured
#    output instructions (JSON schema) more reliably. Available via AWS Bedrock
#    in ap-south-1 (Mumbai) which simplifies HIPAA/DISHA compliance within an
#    AWS architecture.
#
# ─────────────────────────────────────────────────────────────────────────────
#
# 10. PHI-3-VISION / FLORENCE-2  (Microsoft, open-source, run locally)
#     Install: pip install transformers torch
#     Model IDs: microsoft/Phi-3-vision-128k-instruct, microsoft/Florence-2-large
#
#     What they do:
#       Phi-3-Vision is a small (4B parameter) multimodal model that can read
#       images and answer questions or extract text. Florence-2 is a vision
#       foundation model that supports OCR as a task ("OCR" prompt returns
#       extracted text from an image).
#
#     Pros:
#       + Runs fully on-premises — PHI never leaves your network.
#       + Florence-2 is fast (< 1 second per image on GPU).
#       + Phi-3-Vision follows structured JSON instructions with reasonable
#         accuracy on printed documents.
#       + Free to use; quantised versions run on 8 GB GPU.
#
#     Cons:
#       - Accuracy on degraded handwriting is noticeably below GPT-4o/Claude.
#       - Requires GPU for practical throughput.
#       - Model setup (CUDA, transformers, flash-attention) is non-trivial.
#
#     Best fit: On-premises deployments where PHI cannot leave the hospital
#     network and GPU hardware is available (e.g., hospital server with A100).
#
#
# ── D. DECISION MATRIX — CHOOSING THE RIGHT APPROACH ────────────────────────
#
#  Scenario                            Recommended approach
#  ──────────────────────────────────  ─────────────────────────────────────────
#  Clean printed prescriptions,        Tesseract (fast, free, local)
#  offline, high volume
#
#  Degraded/rotated images, need        EasyOCR or PaddleOCR (free, local)
#  multi-language (Hindi, Tamil)
#
#  Structured lab reports / forms       Docling or Azure Document Intelligence
#  with tables, need layout preserved   (table recovery is critical)
#
#  Challenging handwriting, accuracy    GPT-4o / Claude via API (highest accuracy)
#  is paramount, cloud is acceptable    + human-review queue for low confidence
#
#  Handwriting, PHI must stay           Phi-3-Vision or Florence-2 on local GPU
#  on-premises                          (lower accuracy, no data egress)
#
#  Large-scale digitisation of          Azure Document Intelligence + custom
#  existing hospital record archive     model trained on hospital doc types
#
#  Real-time patient portal OCR,        EasyOCR (low latency, no API cost)
#  embedded in app, privacy-first       + post-OCR LLM correction step
#
#  Mixed pipeline (best of both)        Tesseract/EasyOCR for bulk OCR,
#                                       GPT-4o only for low-confidence pages
#                                       (cost-optimised hybrid approach)
#
# ── E. KEY COMPLIANCE NOTE ───────────────────────────────────────────────────
#
#  Before sending any patient document to a cloud OCR API (Azure, GCP, AWS,
#  OpenAI, Anthropic):
#    1. Confirm a signed Data Processing Agreement (DPA) is in place.
#    2. Check whether the API endpoint is covered by a HIPAA BAA (US) or
#       equivalent DISHA/IT Act contractual clause (India).
#    3. Enable audit logging on the API calls for compliance traceability.
#    4. Consider PII/PHI de-identification BEFORE sending to cloud if a DPA
#       cannot be obtained quickly (redact names/MRNs, process the rest).
#    5. Azure Document Intelligence with Azure Private Link keeps traffic
#       within the Azure VNet and avoids public internet exposure — preferred
#       for production healthcare deployments.
