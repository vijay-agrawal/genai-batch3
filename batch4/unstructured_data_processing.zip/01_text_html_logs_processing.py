# -*- coding: utf-8 -*-
import sys, io
if hasattr(sys.stdout, 'buffer'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

"""
01_text_html_logs_processing.py
================================
Demo: Unstructured Data Processing in Healthcare
Topic: Plain Text, HTML (EHR pages), and System Logs

DATA CHALLENGES HIGHLIGHTED:
  - Noise & abbreviations in clinical notes
  - Format inconsistencies (dates, units, shorthand)
  - Ambiguity (negations, context-dependent terms)
  - Semi-structured vs free-text sections in HTML
  - Log parsing: varied severity levels, event extraction

Requirements: pip install beautifulsoup4 pandas

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DATA FILES USED  (all under unstructured_data_processing/data/)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FILE 1 — clinical_notes.txt
  6 synthetic inpatient/outpatient notes from City General Hospital covering
  cardiology, general medicine, emergency triage, psychiatry, and oncology.
  All notes are for the same patient cohort (primary patient MRN CGH-2024-0431).

  ISSUE: Inconsistent date formats  (5 different styles in the same file)
    Note 001 header:  "03/15/2024"   ← MM/DD/YYYY (American style)
    Note 002 header:  "15-03-24"     ← DD-MM-YY (short Indian style)
    Note 003 header:  "March 20 2024"← Long month name, no comma
    Note 004 header:  "03/21/2024"   ← MM/DD/YYYY again
    Note 005 header:  "22nd March, 2024" ← Ordinal day + month name
    Note 006 header:  "25/03/2024"   ← DD/MM/YYYY (standard Indian)
    → The demo normalises all of these to ISO 8601 (YYYY-MM-DD).

  ISSUE: Pervasive medical abbreviations
    "Pt c/o SOB x 3 days ... Hx: HTN, DM type2, CAD (CABG 2019)."
    "O/E: BP 158/92  HR 88 irreg.  RR 20  O2 sat 94% RA."
    "Imp: Acute decompensated CHF. R/O ACS."
    → 40+ abbreviations are expanded by the MEDICAL_ABBREVIATIONS dictionary.

  ISSUE: Typos from rushed/non-native documentation (Note 002)
    "Patiennt:"     → patient
    "mornin"        → morning
    "blurrd vision" → blurred vision
    "Currnt meds:"  → current meds
    "orientd"       → oriented
    "amlodpine"     → amlodipine
    → fix_common_typos() applies a medical correction dictionary.

  ISSUE: Vital signs in multiple formats  (across notes)
    "BP 158/92"          (space-separated)
    "BP 178/110 (!)"     (with annotation)
    "SpO2 98% O2 mask"   (inline with device note)
    "Temp 98.6F"         (Fahrenheit — must convert to Celsius)
    → extract_vitals() uses several regex variants and unit conversion.

  ISSUE: Critical clinical negation  (Note 005 — psychiatry)
    "Denies: suicidal ideation, self-harm, psychotic sx, substance use"
    A naive keyword search for "suicidal" would flag this patient as at-risk.
    The negation window detects "denies" before "suicidal" and marks it ABSENT.

  ISSUE: Ambiguous abbreviations
    "OD" = once daily in prescriptions, but "overdose" in toxicology context.
    "BD" = twice daily, but "behaviour disorder" in psychiatry notes.
    "RA" = room air (Note 001/004) vs rheumatoid arthritis (other specialties).
    → Rule-based expansion always picks one meaning; context is ignored.

────────────────────────────────────────────────────────────────────────────────

FILE 2 — ehr_page.html
  A single-patient EHR export page (patient CGH-2024-0431) in legacy HTML
  format containing demographics, alerts, vitals table, medications, and labs.

  ISSUE: Duplicate alert entries  (id="alerts" section)
    The same allergy entry appears twice — a known bug in legacy EHR exports:
      <p>ALLERGY: Penicillin → Rash (Documented: 2019-03-10, Severity: Moderate)</p>
      <p>ALLERGY: Penicillin → Rash (Documented: 2019-03-10, Severity: Moderate)</p>
    → The demo deduplicates using a seen-set and reports the duplicate count.

  ISSUE: Missing vitals reading  (id="vitals" table)
    Six q4h readings are expected but only 5 rows are present.
    The HTML comment reveals the cause:
      <!-- MISSING: 06:00 next day – system timeout, data not captured -->
    → The demo flags this gap and the timestamp where data was lost.

  ISSUE: Duplicate / conflicting medication order  (id="medications" table)
    Furosemide appears twice with different dose and route:
      Furosemide  40mg  IV  OD  — Active
      Furosemide  20mg  PO  BD  — ⚠ DUPLICATE?
    This is actually an intentional IV→PO transition, but the EHR flagged it
    as a duplicate. The demo surfaces it for physician review.
    → Counter-based duplicate detection finds drug name collisions.

  ISSUE: Abnormal and critical lab values  (id="labs" table)
    BNP = 1890 pg/mL  (reference <100) → CRITICAL flag
    K   = 3.2 mEq/L   (reference 3.5–5.0) → LOW flag
    eGFR = 52*        — asterisk indicates a calculated/uncertain value
    → The demo separates CRITICAL from merely abnormal results.

  ISSUE: Hidden metadata in HTML comments  (invisible to clinicians)
    <!-- EHR_VERSION=2.1.4 | LOCK_STATUS=SIGNED | EDIT_TRAIL=3 edits -->
    <!-- PREVIOUS VERSION (deleted by Dr. Singh 16/03 07:55): "Patient much
         better" – insufficient detail, corrected -->
    <!-- EHR_EXPORT_TIMESTAMP: 2024-03-22T09:15:32Z | FORMAT: HTML_LEGACY_v2 -->
    These are structurally invisible but contain audit-relevant information.
    → BeautifulSoup Comment extraction surfaces them for processing.

────────────────────────────────────────────────────────────────────────────────

FILE 3 — hospital_system.log
  62-line structured log file covering admission-to-discharge of patient
  CGH-2024-0431 plus system-wide events (auth, interface errors, security).

  ISSUE: Varied severity levels requiring different triage
    INFO  — routine events (login, vitals saved, orders placed)
    WARN  — attention needed (allergy cross-reactivity, missed dose, fall risk)
    ERROR — system failures (HL7 parse failure, PACS timeout, dispense error)
    CRIT  — immediate action required (critical lab values, near-miss med error)
    → The demo categorises by level and highlights CRIT entries with patient MRN.

  ISSUE: Security anomaly embedded among routine entries  (not obvious by scan)
    2024-03-18 11:55:00 WARN  [AUTH] Unusual access pattern: User NurseTemp1
    accessed 47 patient records in 12 minutes | Flagged for audit
    → Keyword search ("Unusual access") surfaces this among 62 lines of noise.

  ISSUE: Near-miss medication error requiring root cause analysis
    2024-03-17 14:22:00 ERROR [MED] MRN:CGH-2024-0601 Medication dispense error
    – wrong strength dispensed: Metformin 500mg instead of 1000mg
    2024-03-17 14:25:00 CRIT  [MED] MRN:CGH-2024-0601 Near-miss medication error
    filed | RCA initiated
    → The demo extracts all MED-category WARN/ERROR/CRIT events as a safety report.

  ISSUE: Patient timeline reconstruction across scattered log entries
    Events for CGH-2024-0431 are interleaved with unrelated system events across
    38 lines spanning 5 days. The demo filters by MRN to reconstruct a chronological
    care timeline: admission → labs → CRIT alerts → fall → echo → discharge.

  ISSUE: Unparseable log lines (format deviations)
    Some lines start with '#' (comments) or have non-standard formats.
    The regex LOG_PATTERN silently skips these; unparsed count is reported.
    Any change to timestamp format or field order would silently drop events.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

import re
import json
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime

try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except ImportError:
    BS4_AVAILABLE = False
    print("[WARN] beautifulsoup4 not installed. HTML section will be skipped.")
    print("       Install with: pip install beautifulsoup4\n")

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False
    print("[WARN] pandas not installed. Tables will print as dicts instead.")

DATA_DIR = Path(__file__).parent / "data"

SEPARATOR = "\n" + "=" * 80 + "\n"
SEP_MINOR = "\n" + "-" * 60 + "\n"


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1: CLINICAL NOTES — PLAIN TEXT PROCESSING
# ─────────────────────────────────────────────────────────────────────────────

# Medical abbreviation dictionary — common in Indian/global healthcare
MEDICAL_ABBREVIATIONS = {
    r"\bpt\b": "patient",
    r"\bc/o\b": "complains of",
    r"\bhx\b": "history",
    r"\bpmh\b": "past medical history",
    r"\bdx\b": "diagnosis",
    r"\brx\b": "prescription/treatment",
    r"\bhtn\b": "hypertension",
    r"\bdm\b": "diabetes mellitus",
    r"\bcad\b": "coronary artery disease",
    r"\bchf\b": "congestive heart failure",
    r"\bacs\b": "acute coronary syndrome",
    r"\bsob\b": "shortness of breath",
    r"\bcvs\b": "cardiovascular system",
    r"\bo/e\b": "on examination",
    r"\bimp\b": "impression",
    r"\bbd\b": "twice daily",
    r"\bod\b": "once daily",
    r"\bprn\b": "as needed",
    r"\biv\b": "intravenous",
    r"\bpo\b": "oral",
    r"\bsc\b": "subcutaneous",
    r"\bra\b": "room air",
    r"\bspO2\b": "oxygen saturation",
    r"\bgcs\b": "Glasgow Coma Scale",
    r"\bloc\b": "loss of consciousness",
    r"\brta\b": "road traffic accident",
    r"\bich\b": "intracranial hemorrhage",
    r"\bcabg\b": "coronary artery bypass graft",
    r"\bef\b": "ejection fraction",
    r"\bbnp\b": "B-type natriuretic peptide",
    r"\becg\b": "electrocardiogram",
    r"\becho\b": "echocardiogram",
    r"\baf\b": "atrial fibrillation",
    r"\blbbb\b": "left bundle branch block",
    r"\baki\b": "acute kidney injury",
    r"\bckd\b": "chronic kidney disease",
    r"\bcbc\b": "complete blood count",
    r"\bcmp\b": "comprehensive metabolic panel",
    r"\bwbc\b": "white blood cell count",
    r"\bhb\b": "hemoglobin",
    r"\bhgb\b": "hemoglobin",
    r"\bplt\b": "platelets",
    r"\bcr\b": "creatinine",
    r"\bpcn\b": "penicillin",
    r"\bmse\b": "mental status examination",
    r"\bphq\b": "Patient Health Questionnaire",
    r"\bgad\b": "Generalized Anxiety Disorder scale",
    r"\btsh\b": "thyroid stimulating hormone",
    r"\bcbt\b": "cognitive behavioural therapy",
    r"\becog\b": "Eastern Cooperative Oncology Group",
    r"\bfolfox\b": "FOLFOX chemotherapy (folinic acid + fluorouracil + oxaliplatin)",
    r"\br0\b": "R0 (clear surgical margins)",
    r"\bjvp\b": "jugular venous pressure",
    r"\bnv\b": "nausea and vomiting",
    r"\btid\b": "three times daily",
    r"\bqid\b": "four times daily",
    r"\bnpo\b": "nothing by mouth",
    r"\bpca\b": "patient-controlled analgesia",
}

# Inconsistent date patterns in healthcare records
DATE_PATTERNS = [
    (r'\b(\d{2}/\d{2}/\d{4})\b', "%d/%m/%Y"),        # 15/03/2024
    (r'\b(\d{2}-\d{2}-\d{2})\b', "%d-%m-%y"),         # 15-03-24
    (r'\b(March\s+\d{1,2},?\s+\d{4})\b', "%B %d %Y"), # March 20 2024
    (r'\b(\d{1,2}(?:st|nd|rd|th)\s+\w+,?\s+\d{4})\b', None),  # 22nd March, 2024
]

# Negation words — critical for clinical NLP (don't extract negated findings as positive)
NEGATION_WORDS = ["no", "not", "deny", "denies", "denied", "without", "absent",
                  "negative", "rule out", "r/o", "non", "neither", "never"]


def load_clinical_notes(filepath: Path) -> list[dict]:
    """Load and split clinical notes file into individual note dicts."""
    text = filepath.read_text(encoding="utf-8")
    notes = []
    # Split on note headers like "=== NOTE 001 | ..."
    parts = re.split(r'={3,}.*?NOTE\s*(\d+).*?={3,}', text)
    raw_blocks = re.findall(r'(=== NOTE.*?(?==== NOTE|\Z))', text, re.DOTALL)

    for i, block in enumerate(raw_blocks, 1):
        # Extract header line
        header_match = re.match(r'=== (.*?) ===', block)
        header = header_match.group(1) if header_match else f"Note {i}"
        content = re.sub(r'=== .*? ===\n', '', block).strip()
        notes.append({"id": i, "header": header, "raw": content})
    return notes


def normalize_dates(text: str) -> str:
    """
    CHALLENGE: Date formats vary wildly across notes.
    Normalize all to YYYY-MM-DD for downstream processing.
    """
    # 03/15/2024 or 15/03/2024 — assume DD/MM/YYYY for Indian hospital
    def replace_ddmmyyyy(m):
        try:
            return datetime.strptime(m.group(1), "%d/%m/%Y").strftime("%Y-%m-%d")
        except ValueError:
            return m.group(0)

    def replace_ddmmyy(m):
        try:
            return datetime.strptime(m.group(1), "%d-%m-%y").strftime("%Y-%m-%d")
        except ValueError:
            return m.group(0)

    text = re.sub(r'\b(\d{2}/\d{2}/\d{4})\b', replace_ddmmyyyy, text)
    text = re.sub(r'\b(\d{2}-\d{2}-\d{2})\b', replace_ddmmyy, text)
    # "March 20 2024" → "2024-03-20"
    def replace_month_name(m):
        s = m.group(0).replace(',', '')
        for fmt in ["%B %d %Y", "%d %B %Y"]:
            try:
                return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
        return m.group(0)
    text = re.sub(r'\b([A-Z][a-z]+\s+\d{1,2}\s+\d{4})\b', replace_month_name, text)
    # "22nd March, 2024" style
    text = re.sub(r'\b(\d{1,2})(?:st|nd|rd|th)\s+([A-Z][a-z]+),?\s+(\d{4})\b',
                  lambda m: f"{m.group(3)}-{datetime.strptime(m.group(2),'%B').strftime('%m')}-{int(m.group(1)):02d}",
                  text)
    return text


def expand_abbreviations(text: str) -> str:
    """
    CHALLENGE: Abbreviations are pervasive in clinical text.
    Expand common ones (case-insensitive) for NLP/search readability.
    """
    for pattern, expansion in MEDICAL_ABBREVIATIONS.items():
        text = re.sub(pattern, expansion, text, flags=re.IGNORECASE)
    return text


def extract_vitals(text: str) -> dict:
    """
    CHALLENGE: Vitals appear in many formats:
    'BP 158/92', 'BP=158/92', 'Blood Pressure: 158/92 mmHg', 'BP158/92'
    """
    vitals = {}

    bp = re.search(r'BP[:\s=]*(\d{2,3})[/](\d{2,3})', text, re.IGNORECASE)
    if bp:
        vitals['bp_systolic'] = int(bp.group(1))
        vitals['bp_diastolic'] = int(bp.group(2))

    hr = re.search(r'(?:HR|Heart Rate|Pulse)[:\s=]*(\d{2,3})', text, re.IGNORECASE)
    if hr:
        vitals['heart_rate'] = int(hr.group(1))

    rr = re.search(r'RR[:\s=]*(\d{2})', text, re.IGNORECASE)
    if rr:
        vitals['resp_rate'] = int(rr.group(1))

    spo2 = re.search(r'(?:SpO2|O2 sat|SaO2)[:\s=]*(\d{2,3})\s*%?', text, re.IGNORECASE)
    if spo2:
        vitals['spo2_pct'] = int(spo2.group(1))

    temp = re.search(r'(?:Temp|Temperature)[:\s=]*(\d{2,3}(?:\.\d)?)\s*([CF°])?', text, re.IGNORECASE)
    if temp:
        val = float(temp.group(1))
        unit = temp.group(2) or ''
        # Normalize: if looks like Fahrenheit, convert
        if val > 42 or 'F' in unit.upper():
            val = round((val - 32) * 5 / 9, 1)
        vitals['temp_celsius'] = val

    wt = re.search(r'(?:Wt|Weight)[:\s=]*(\d{2,3}(?:\.\d)?)\s*kg', text, re.IGNORECASE)
    if wt:
        vitals['weight_kg'] = float(wt.group(1))

    return vitals


def extract_medications(text: str) -> list[dict]:
    """
    CHALLENGE: Medication entries appear in many formats.
    Extract drug name, dose, route, frequency.
    """
    meds = []
    # Pattern: drug dose route frequency
    patterns = [
        # "metoprolol 50mg BD" or "metoprolol 50mg PO BD"
        r'([A-Za-z][a-z]+(?:[\s-][a-z]+)?)\s+(\d+(?:\.\d+)?)\s*mg\s*(IV|PO|SC|SL|IM|PR)?\s*(BD|OD|TID|QID|PRN|SOS|STAT|weekly)?',
        # "Tab Furosemide 40mg OD"
        r'(?:Tab\.?|Inj\.?|Cap\.?)\s+([A-Za-z][a-z]+(?:\s[a-z]+)?)\s+(\d+(?:\.\d+)?)\s*(?:mg|mcg|g|ml|units?)',
    ]
    for pattern in patterns:
        for m in re.finditer(pattern, text, re.IGNORECASE):
            meds.append({
                "drug": m.group(1).strip().title(),
                "dose": m.group(2) + "mg" if len(m.groups()) >= 2 else "",
                "route": m.group(3) if len(m.groups()) >= 3 and m.group(3) else "unspecified",
                "frequency": m.group(4) if len(m.groups()) >= 4 and m.group(4) else "unspecified",
            })
    return meds


def detect_negations(text: str, target_terms: list[str]) -> dict[str, bool]:
    """
    CHALLENGE: Clinical negation is critical.
    'no chest pain' ≠ 'chest pain'. Must detect negation window.
    Returns True if term is NEGATED (absent), False if present/affirmed.
    """
    results = {}
    sentences = re.split(r'[.;!\n]', text)
    negation_window = 5  # words after negation trigger

    for term in target_terms:
        negated = False
        for sentence in sentences:
            words = sentence.lower().split()
            for i, word in enumerate(words):
                if term.lower() in word:
                    # Look back within window for negation words
                    start = max(0, i - negation_window)
                    context = words[start:i]
                    if any(neg in ' '.join(context) for neg in NEGATION_WORDS):
                        negated = True
                        break
        results[term] = negated
    return results


def fix_common_typos(text: str) -> str:
    """
    CHALLENGE: Clinical notes have typos (from rushed typing, non-English speakers).
    Apply a small medical-domain correction dictionary.
    """
    corrections = {
        r'\bpatiennt\b': 'patient',
        r'\bmornin\b': 'morning',
        r'\bblurrd\b': 'blurred',
        r'\bcurrnt\b': 'current',
        r'\borientd\b': 'oriented',
        r'\bamlodpine\b': 'amlodipine',
        r'\bdizy\b': 'dizzy',
        r'\bbreathlessnes\b': 'breathlessness',
        r'\bprescirption\b': 'prescription',
        r'\bmedcine\b': 'medicine',
    }
    for wrong, right in corrections.items():
        text = re.sub(wrong, right, text, flags=re.IGNORECASE)
    return text


def extract_diagnoses_icd(text: str) -> list[str]:
    """Extract ICD-10 codes mentioned in text."""
    return re.findall(r'\b([A-Z]\d{2}(?:\.\d{1,2})?)\b', text)


def run_clinical_notes_demo():
    print(SEPARATOR)
    print("SECTION 1: CLINICAL NOTES — PLAIN TEXT PROCESSING")
    print(SEPARATOR)

    filepath = DATA_DIR / "clinical_notes.txt"
    if not filepath.exists():
        print(f"[ERROR] File not found: {filepath}")
        return

    notes = load_clinical_notes(filepath)
    print(f"Loaded {len(notes)} clinical notes from {filepath.name}\n")

    for note in notes[:3]:  # process first 3 notes for demo
        print(f"{'─'*60}")
        print(f"NOTE {note['id']}: {note['header']}")
        print(f"{'─'*60}")

        raw = note['raw']
        print(f"\n[RAW EXCERPT - first 300 chars]:\n{raw[:300]}...\n")

        # Step 1: Fix typos
        cleaned = fix_common_typos(raw)
        typo_fixes = sum(1 for w, r in {
            'patiennt': 'patient', 'mornin': 'morning', 'blurrd': 'blurred',
            'currnt': 'current', 'orientd': 'oriented', 'amlodpine': 'amlodipine'
        }.items() if w in raw.lower())
        print(f"[CHALLENGE: NOISE] Typo corrections applied: {typo_fixes}")

        # Step 2: Normalize dates
        normalized = normalize_dates(cleaned)
        dates_found = re.findall(r'\d{4}-\d{2}-\d{2}', normalized)
        print(f"[CHALLENGE: FORMAT VARIATION] Dates normalized to ISO format: {dates_found}")

        # Step 3: Expand abbreviations (show before/after sample)
        abbrevs_found = [abbr for abbr in ['SOB', 'HTN', 'DM', 'BD', 'OD', 'CHF', 'ACS']
                         if abbr.lower() in raw.lower() or abbr in raw]
        print(f"[CHALLENGE: ABBREVIATIONS] Found in note: {abbrevs_found}")
        expanded = expand_abbreviations(cleaned)
        sample_abbr = "SOB" if "SOB" in raw else ("HTN" if "HTN" in raw else None)
        if sample_abbr:
            print(f"  '{sample_abbr}' → '{expand_abbreviations(sample_abbr)}'")

        # Step 4: Extract vitals
        vitals = extract_vitals(raw)
        if vitals:
            print(f"[EXTRACTION] Vitals extracted: {vitals}")
        else:
            print("[EXTRACTION] Vitals: none found in this note")

        # Step 5: Extract medications
        meds = extract_medications(raw)
        if meds:
            print(f"[EXTRACTION] Medications found ({len(meds)}):")
            for med in meds[:4]:
                print(f"  → {med}")

        # Step 6: Negation detection
        symptoms_to_check = ['fever', 'chest pain', 'suicidal', 'nausea', 'shortness of breath']
        negation_results = detect_negations(raw, symptoms_to_check)
        affirmed = {k: v for k, v in negation_results.items() if not v}
        negated = {k: v for k, v in negation_results.items() if v}
        if negated:
            print(f"[CHALLENGE: AMBIGUITY/NEGATION] Negated (ABSENT) terms: {list(negated.keys())}")
        if affirmed:
            print(f"[CHALLENGE: AMBIGUITY/NEGATION] Affirmed (PRESENT) terms: {list(affirmed.keys())}")

        # Step 7: ICD-10 codes
        icd_codes = extract_diagnoses_icd(raw)
        if icd_codes:
            print(f"[EXTRACTION] ICD-10 codes found: {icd_codes}")

        print()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2: HTML EHR PAGE PROCESSING
# ─────────────────────────────────────────────────────────────────────────────

def run_html_ehr_demo():
    print(SEPARATOR)
    print("SECTION 2: HTML EHR PAGE — STRUCTURED EXTRACTION")
    print(SEPARATOR)

    if not BS4_AVAILABLE:
        print("[SKIP] Install beautifulsoup4 to run this section.")
        return

    filepath = DATA_DIR / "ehr_page.html"
    if not filepath.exists():
        print(f"[ERROR] File not found: {filepath}")
        return

    html = filepath.read_text(encoding="utf-8")
    soup = BeautifulSoup(html, "html.parser")

    print(f"Loaded HTML EHR page: {filepath.name}")
    print(f"Raw HTML size: {len(html):,} characters\n")

    # ── 2a. Extract patient demographics ──────────────────────────────────────
    print("── 2a. Patient Demographics ──")
    demo_section = soup.find("div", id="demographics")
    if demo_section:
        rows = demo_section.find_all("tr")
        patient_info = {}
        for row in rows:
            cells = [td.get_text(strip=True) for td in row.find_all("td")]
            # Pairs: label, value, label, value
            for i in range(0, len(cells) - 1, 2):
                key = cells[i].replace(":", "").strip()
                val = cells[i + 1].strip()
                if key and val:
                    patient_info[key] = val
        print(json.dumps(patient_info, indent=2))
    print()

    # ── 2b. Duplicate alert detection ─────────────────────────────────────────
    print("── 2b. Active Alerts (with CHALLENGE: Duplicate Detection) ──")
    alerts_section = soup.find("div", id="alerts")
    if alerts_section:
        alerts = [p.get_text(strip=True) for p in alerts_section.find_all("p")]
        seen = set()
        unique_alerts = []
        duplicates = []
        for alert in alerts:
            clean = re.sub(r'\s+', ' ', alert).strip()
            if clean in seen:
                duplicates.append(clean[:60] + "...")
            else:
                seen.add(clean)
                unique_alerts.append(clean)
        print(f"Total alert entries: {len(alerts)}")
        print(f"Unique alerts: {len(unique_alerts)}")
        if duplicates:
            print(f"[CHALLENGE: NOISE] DUPLICATE ALERTS DETECTED ({len(duplicates)}):")
            for d in duplicates:
                print(f"  → {d}")
    print()

    # ── 2c. Vital signs table ─────────────────────────────────────────────────
    print("── 2c. Vital Signs Table Extraction ──")
    vitals_section = soup.find("div", id="vitals")
    if vitals_section:
        table = vitals_section.find("table")
        headers = [th.get_text(strip=True) for th in table.find_all("th")]
        vitals_records = []
        for row in table.find_all("tr")[1:]:  # skip header
            cells = [td.get_text(strip=True) for td in row.find_all("td")]
            if cells and len(cells) == len(headers):
                vitals_records.append(dict(zip(headers, cells)))

        if PANDAS_AVAILABLE:
            df = pd.DataFrame(vitals_records)
            print(df.to_string(index=False))
            # Detect missing slots
            if len(vitals_records) < 6:
                print(f"\n[CHALLENGE: MISSING DATA] Expected 6 readings (q4h), found {len(vitals_records)}")
                print("  → Gap at 06:00 next day — system timeout during data capture")
        else:
            for r in vitals_records:
                print(r)

        # Parse SpO2 values and flag low readings
        low_spo2 = [(r.get("Time"), r.get("SpO2 (%)"))
                    for r in vitals_records
                    if r.get("SpO2 (%)") and int(r.get("SpO2 (%)")) < 95]
        if low_spo2:
            print(f"\n[CLINICAL ALERT] Low SpO2 readings: {low_spo2}")
    print()

    # ── 2d. Medications — duplicate detection ─────────────────────────────────
    print("── 2d. Medication List (CHALLENGE: Duplicate/Conflicting Orders) ──")
    med_section = soup.find("div", id="medications")
    if med_section:
        med_table = med_section.find("table")
        med_headers = [th.get_text(strip=True) for th in med_table.find_all("th")]
        meds = []
        for row in med_table.find_all("tr")[1:]:
            cells = [td.get_text(strip=True) for td in row.find_all("td")]
            if cells:
                meds.append(dict(zip(med_headers, cells)))

        # Find duplicate drug names
        drug_names = [m.get("Drug", "").lower() for m in meds]
        drug_counts = Counter(drug_names)
        duplicates = {k: v for k, v in drug_counts.items() if v > 1}
        if duplicates:
            print(f"[CHALLENGE: NOISE] DUPLICATE MEDICATION ORDERS: {duplicates}")
        for med in meds:
            status = med.get("Status", "")
            flag = " ⚠ DUPLICATE?" if "DUPLICATE" in status.upper() else ""
            flag += " 🔴 HOLD" if "HOLD" in status.upper() else ""
            print(f"  {med.get('Drug'):25s} {med.get('Dose'):6s} {med.get('Frequency'):5s} "
                  f"{med.get('Status'):20s}{flag}")
    print()

    # ── 2e. Lab results with abnormal flagging ─────────────────────────────────
    print("── 2e. Lab Results — Abnormal Value Extraction ──")
    labs_section = soup.find("div", id="labs")
    if labs_section:
        lab_table = labs_section.find("table")
        lab_headers = [th.get_text(strip=True) for th in lab_table.find_all("th")]
        labs = []
        for row in lab_table.find_all("tr")[1:]:
            cells = [td.get_text(strip=True) for td in row.find_all("td")]
            if cells and len(cells) == len(lab_headers):
                rec = dict(zip(lab_headers, cells))
                labs.append(rec)

        critical = [l for l in labs if "CRITICAL" in l.get("Flag", "").upper()]
        abnormal = [l for l in labs if l.get("Flag", "Normal").upper() not in ["NORMAL", ""]]
        print(f"Total lab tests: {len(labs)}")
        print(f"Abnormal results: {len(abnormal)}")
        print(f"CRITICAL values: {len(critical)}")
        for c in critical:
            print(f"  🔴 CRITICAL: {c.get('Test')} = {c.get('Result')} {c.get('Unit')} "
                  f"(Ref: {c.get('Reference Range')})")
    print()

    # ── 2f. HTML comments as metadata ──────────────────────────────────────────
    print("── 2f. Hidden Metadata in HTML Comments ──")
    from bs4 import Comment
    comments = soup.find_all(string=lambda t: isinstance(t, Comment))
    print(f"[CHALLENGE: FORMAT VARIATION] Found {len(comments)} HTML comments with hidden metadata:")
    for c in comments:
        c_clean = c.strip()
        if c_clean:
            print(f"  <!-- {c_clean[:100]} -->")
    print()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3: HOSPITAL SYSTEM LOGS
# ─────────────────────────────────────────────────────────────────────────────

LOG_PATTERN = re.compile(
    r'^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s+'    # timestamp
    r'(INFO|WARN|ERROR|CRIT)\s+'                       # level
    r'\[(\w+)\]\s+'                                    # category
    r'(.+)$'                                           # message
)


def parse_log_line(line: str) -> dict | None:
    """Parse a single log line into structured fields."""
    m = LOG_PATTERN.match(line.strip())
    if not m:
        return None
    return {
        "timestamp": m.group(1),
        "level": m.group(2),
        "category": m.group(3),
        "message": m.group(4),
    }


def extract_patient_mrn(message: str) -> str | None:
    m = re.search(r'MRN:(\w+-\d+-\d+)', message)
    return m.group(1) if m else None


def extract_med_from_log(message: str) -> str | None:
    m = re.search(r'(?:Medication ordered|administered|dispensed|ordered):\s*([A-Za-z\s]+\d+\s*mg)', message)
    return m.group(1).strip() if m else None


def run_log_processing_demo():
    print(SEPARATOR)
    print("SECTION 3: HOSPITAL SYSTEM LOGS — EVENT EXTRACTION & ANALYSIS")
    print(SEPARATOR)

    filepath = DATA_DIR / "hospital_system.log"
    if not filepath.exists():
        print(f"[ERROR] File not found: {filepath}")
        return

    lines = filepath.read_text(encoding="utf-8").splitlines()
    print(f"Log file: {filepath.name}  |  Total lines: {len(lines)}\n")

    # Parse all lines
    parsed = [parse_log_line(l) for l in lines if l.strip() and not l.startswith('#')]
    parsed = [p for p in parsed if p is not None]

    unparsed = len([l for l in lines if l.strip() and not l.startswith('#')]) - len(parsed)
    print(f"Successfully parsed: {len(parsed)} entries")
    if unparsed:
        print(f"[CHALLENGE: FORMAT VARIATION] Unparseable lines: {unparsed} (comment/blank lines excluded)")

    # ── 3a. Summary by severity ────────────────────────────────────────────────
    print(SEP_MINOR)
    print("3a. Log Summary by Severity Level:")
    by_level = Counter(p["level"] for p in parsed)
    for level, count in sorted(by_level.items()):
        emoji = {"INFO": "ℹ", "WARN": "⚠", "ERROR": "✗", "CRIT": "🔴"}.get(level, "?")
        print(f"  {emoji} {level:5s} : {count:3d} entries")

    # ── 3b. Events by category ────────────────────────────────────────────────
    print(SEP_MINOR)
    print("3b. Events by Category:")
    by_cat = Counter(p["category"] for p in parsed)
    for cat, count in by_cat.most_common():
        print(f"  [{cat:10s}] : {count} events")

    # ── 3c. Critical events ────────────────────────────────────────────────────
    print(SEP_MINOR)
    print("3c. CRITICAL Events (require immediate action):")
    crits = [p for p in parsed if p["level"] == "CRIT"]
    for c in crits:
        mrn = extract_patient_mrn(c["message"])
        print(f"  [{c['timestamp']}] {c['category']:8s} | Patient: {mrn or 'N/A'}")
        print(f"    → {c['message'][:90]}")

    # ── 3d. Security events ────────────────────────────────────────────────────
    print(SEP_MINOR)
    print("3d. Security & Authentication Events:")
    auth_events = [p for p in parsed if p["category"] == "AUTH"]
    failed_logins = [p for p in auth_events if "Failed" in p["message"]]
    unusual_access = [p for p in parsed if "Unusual access" in p.get("message", "")]
    print(f"  Total auth events: {len(auth_events)}")
    print(f"  Failed login attempts: {len(failed_logins)}")
    print(f"  Unusual access alerts: {len(unusual_access)}")
    if unusual_access:
        for u in unusual_access:
            print(f"  [SECURITY ALERT] {u['timestamp']}: {u['message']}")

    # ── 3e. Medication safety events ──────────────────────────────────────────
    print(SEP_MINOR)
    print("3e. Medication Safety Events:")
    med_events = [p for p in parsed if p["category"] == "MED"]
    med_warnings = [p for p in med_events if p["level"] in ["WARN", "CRIT", "ERROR"]]
    print(f"  Medication events: {len(med_events)}  |  Warnings/Errors: {len(med_warnings)}")
    for me in med_warnings:
        print(f"  [{me['level']}] {me['timestamp']}: {me['message'][:90]}")

    # ── 3f. Patient timeline reconstruction ───────────────────────────────────
    print(SEP_MINOR)
    print("3f. Patient Timeline Reconstruction (MRN: CGH-2024-0431):")
    target_mrn = "CGH-2024-0431"
    patient_events = [p for p in parsed if target_mrn in p.get("message", "")]
    print(f"  Found {len(patient_events)} events for patient {target_mrn}:\n")
    for evt in patient_events:
        icon = {"INFO": " ", "WARN": "⚠", "ERROR": "✗", "CRIT": "🔴"}.get(evt["level"], "?")
        print(f"  {icon} {evt['timestamp']} [{evt['category']:8s}] {evt['message'][:75]}")

    # ── 3g. System reliability ────────────────────────────────────────────────
    print(SEP_MINOR)
    print("3g. System Errors & Reliability:")
    errors = [p for p in parsed if p["level"] == "ERROR"]
    print(f"  Total errors: {len(errors)}")
    by_error_cat = Counter(p["category"] for p in errors)
    for cat, count in by_error_cat.items():
        print(f"  {cat}: {count} errors")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("  HEALTHCARE UNSTRUCTURED DATA PROCESSING — DEMO 1")
    print("  Topic: Text, HTML & Log Files")
    print("=" * 80)

    run_clinical_notes_demo()
    run_html_ehr_demo()
    run_log_processing_demo()

    print(SEPARATOR)
    print("SUMMARY OF DATA CHALLENGES ADDRESSED:")
    print(SEPARATOR)
    challenges = {
        "NOISE":
            "Typos (patiennt→patient), OCR errors, rushed documentation",
        "FORMAT VARIATION":
            "15/03/2024 vs 15-03-24 vs March 20 2024 | mg vs mcg vs units | BD vs twice daily",
        "ABBREVIATIONS":
            "40+ medical shorthand terms expanded (SOB, HTN, DM, BD, OD...)",
        "AMBIGUITY":
            "Negation detection — 'denies chest pain' ≠ 'chest pain'",
        "DUPLICATE DATA":
            "Duplicate allergy alerts and medication orders in EHR HTML export",
        "MISSING DATA":
            "Vital signs gap at 06:00 — system timeout during data capture",
        "MIXED STRUCTURE":
            "Free-text narrative + structured tables + HTML comments with metadata",
        "SECURITY":
            "Failed logins, unusual bulk record access flagged in logs",
    }
    for challenge, desc in challenges.items():
        print(f"  [{challenge}] {desc}")
    print()


# ─────────────────────────────────────────────────────────────────────────────
# LIMITATIONS OF RULE-BASED APPROACHES & RECOMMENDATIONS
# ─────────────────────────────────────────────────────────────────────────────
#
# LIMITATIONS
# ───────────
#
# 1. BRITTLE PATTERN MATCHING
#    Regex and keyword lists break on any format not explicitly coded.
#    e.g., "BP: one-fifty over ninety" or "pressure 150/90 right arm sitting"
#    will not be captured by the bp extraction regex.
#
# 2. STATIC ABBREVIATION DICTIONARY
#    The MEDICAL_ABBREVIATIONS dict cannot handle context-dependent expansions.
#    "RA" means "room air" in ICU notes but "rheumatoid arthritis" in
#    rheumatology consults. A static lookup always picks one meaning.
#
# 3. SHALLOW NEGATION DETECTION
#    The sliding-window negation approach misses complex linguistic patterns:
#    - Scope errors: "no fever, chills, or chest pain" — "chest pain" is
#      negated, but only "fever" is within the 5-word window.
#    - Double negation: "not without pain" is incorrectly treated as negated.
#    - Speculative language: "rule out MI" should not be coded as "MI present".
#
# 4. ZERO RECALL ON UNSEEN FORMATS
#    Any medication, vital, or date format not anticipated in the patterns
#    is silently dropped — no warning, no fallback, just lost data.
#    New EHR vendors or regional documentation styles require manual pattern
#    updates each time.
#
# 5. NO SEMANTIC UNDERSTANDING
#    Rules operate on surface form, not meaning. They cannot:
#    - Resolve coreference ("the patient ... he/she ... they")
#    - Link a diagnosis to its associated treatment in the same note
#    - Understand that "FOLFOX cycle 3" implies an oncology context
#
# 6. HIGH MAINTENANCE COST
#    Each new hospital, department, or specialty requires a separate
#    dictionary and pattern set. Keeping these in sync across hundreds
#    of providers does not scale.
#
# 7. LOG PARSING IS FORMAT-LOCKED
#    LOG_PATTERN assumes a fixed log format. Any change in the logging
#    framework (timestamp format, added fields, JSON logs) silently discards
#    events as "unparseable".
#
#
# RECOMMENDATIONS — TECHNIQUES THAT PERFORM BETTER
# ─────────────────────────────────────────────────
#
# 1. CLINICAL NLP MODELS (NER)
#    Use pre-trained biomedical Named Entity Recognition models instead of
#    hand-crafted regex for entity extraction:
#    - scispaCy (en_core_sci_lg) for general clinical NER
#    - medspaCy for section detection, negation, and temporality
#    - cTAKES or MetaMap for UMLS-grounded concept extraction
#    These models generalise across unseen phrasings and handle context.
#
# 2. TRANSFORMER-BASED LANGUAGE MODELS
#    Fine-tuned BERT-family models vastly outperform regex on ambiguous text:
#    - BioBERT / ClinicalBERT for clinical note classification and NER
#    - PubMedBERT for research-grade biomedical language
#    - GatorTron (trained on 90B clinical words) for EHR-specific tasks
#    These capture long-range context, resolve abbreviation ambiguity, and
#    handle negation implicitly through attention.
#
# 3. LLM-BASED EXTRACTION (GPT-4 / Claude)
#    Prompt a large language model to extract structured data from free text:
#    - Zero-shot or few-shot prompting for vitals, medications, diagnoses
#    - Output as structured JSON, validated against a Pydantic schema
#    - Works out-of-the-box on novel formats with no pattern engineering
#    Ideal when volume is moderate and accuracy is paramount.
#
# 4. MEDSPACY / NEGEX FOR NEGATION
#    Replace the window-based negation heuristic with NegEx or medspaCy's
#    negation component, which uses dependency parse trees and learned
#    negation scopes — dramatically reduces false positives/negatives.
#
# 5. STRUCTURED LOG FORMATS + SEMANTIC SEARCH
#    Migrate to structured logging (JSON lines, OpenTelemetry) so log parsing
#    never fails on format changes. For ad-hoc log analysis, use vector
#    embeddings + approximate nearest-neighbour search to find semantically
#    similar events without knowing the exact format.
#
# 6. ACTIVE LEARNING PIPELINE
#    Combine rule-based extraction as a weak labeller with a human review
#    loop to train and iteratively improve an ML model. Tools like Prodigy
#    or Label Studio support this workflow for clinical annotation.
#
# 7. STANDARDISE AT INGESTION (FHIR / HL7)
#    The root cause of most format-variation challenges is the absence of
#    a canonical data model. Enforcing FHIR R4 resources (Observation,
#    MedicationRequest, Condition) at the point of ingestion eliminates the
#    need for downstream normalisation of dates, units, and abbreviations.
