# -*- coding: utf-8 -*-
import sys, io
if hasattr(sys.stdout, 'buffer'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

"""
03_chat_email_processing.py
============================
Demo: Unstructured Data Processing in Healthcare
Topic: Chat Transcripts & Emails

DATA CHALLENGES HIGHLIGHTED:
  - Informal language, slang, abbreviations in patient chats
  - Urgency/risk signals buried in casual conversation
  - Email threading, MIME parsing, attachments
  - PII/PHI detection in unencrypted communications
  - Sentiment & tone analysis for patient safety
  - Clinical instruction extraction from informal messages
  - Routing: which messages need urgent clinical response?

Requirements: pip install pandas  (email module is stdlib)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DATA FILES USED  (all under unstructured_data_processing/data/)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FILE 1 — chat_transcript.txt
  4 synthetic WhatsApp/portal-style chat transcripts from City General Hospital
  covering: post-discharge patient follow-up, ICU doctor handover, nurse helpline
  psychiatric support, and an internal ward nursing coordination chat.

  ISSUE: Informal language and abbreviations mixed with clinical content
    "[09:55] DR PATEL: ... Stop Lisinopril from tonight. Start Telmisartan tmrw morning."
    "tmrw" needs expanding; medication instructions are buried in conversational prose.
    "[10:02] PATIENT: my sugar was 240 this morning fasting. I didnt take metformin"
    Missing punctuation, no capitalisation — standard NLP tokenisation struggles here.

  ISSUE: Urgency signals embedded in casual, non-clinical language (Transcript 1)
    "[10:10] DR PATEL: Call immediately if: sudden severe breathlessness, chest pain,
     weight gain >2kg in one day, or legs very swollen."
    A patient forwarding this message, or a downstream triage system receiving it,
    must distinguish "call immediately" instructions from routine conversation.

  ISSUE: False positive urgency — critical-looking words in safe context (Transcript 3)
    "[14:22] PATIENT: I read on internet it causes suicidal thoughts. Can I not take it?"
    The word "suicidal" triggers a CRITICAL urgency flag, but the patient is describing
    a concern they read about — not expressing suicidal ideation. Rule-based keyword
    matching cannot distinguish these without understanding discourse context.

  ISSUE: PHI in an informal, unencrypted channel (Transcript 1 & 3)
    "[09:14] PATIENT (John D, MRN:0431): Good morning doctor."  ← MRN in plain text
    "[14:22] PATIENT (Sunita M): Hi this is Sunita Mehta I saw psychiatry Dr nikhil"
    "[14:43] NURSE HELPLINE: call iCall 9152987821"             ← phone number
    Names, MRNs, diagnoses, and phone numbers appear across multiple messages with
    no encryption — a HIPAA/DISHA compliance violation.

  ISSUE: Doctor-to-doctor clinical shorthand (Transcript 2 — ICU handover)
    "[08:09] DR SINGH: Target <150/90. Don't drop too fast – chronic hypertensive,
     autoregulation shifted."
    "re: bronchospasm concern (she has mild asthma). Need team decision."
    "re:" is ambiguous (regarding / reply); "autoregulation shifted" is clinical
    jargon invisible to general NLP models. The CHAT_ABBREVIATIONS dict does not
    cover doctor-to-doctor shorthand — it is tuned for patient-facing language only.

  ISSUE: Response time delay as a patient-safety signal (Transcript 1)
    Patient sends first message at [09:14], clinician replies at [09:47] — 33-minute
    gap. The demo flags any >30-minute wait as DELAYED. A longer delay on a message
    containing "chest pain" could indicate a triage failure.

  ISSUE: Medication safety check needed across channels (Transcript 4)
    "[02:10] NURSE MROY: Also meds due 2am: Enoxaparin injection – patient already had?"
    This manual cross-check (has the previous shift given the drug?) is a common
    source of double-dosing errors. The demo shows how log-linking is needed for
    complete safety analysis.

────────────────────────────────────────────────────────────────────────────────

FILE 2 — referral_email.eml
  A single .eml file containing THREE concatenated emails with very different
  formality levels, illustrating the range of healthcare email communications.

  EMAIL 1 — Formal clinical referral (doctor to doctor)
    From: Dr. Anand Kumar <anand.kumar@cghmumbai.org>
    To:   Dr. Sarah Lee <sarah.lee@mumbaioncology.org>
    Subject: Urgent Referral - Mr. Anil Kapoor, 63M, Colon Adenocarcinoma

    ISSUE: PHI spread across every email field
      Subject line:  "Mr. Anil Kapoor, 63M, Colon Adenocarcinoma"  ← name + diagnosis
      Body:          "DOB: 12/08/1960, MRN: CGH-2024-0289"          ← DOB + MRN
      Contact block: "+91-22-28831234 ext 2241"                      ← direct phone
      PHI detection must scan headers, subject, and body — not just the body.

    ISSUE: Confidentiality notice as body noise
      The email ends with a 4-line CONFIDENTIALITY NOTICE that is repeated on
      every outgoing hospital email. clean_email_body() strips it, reducing
      the body length by ~300 characters before NLP extraction.

    ISSUE: Clinical instructions mixed with narrative prose
      "QUESTIONS FOR YOUR REVIEW:
        1. Is dose reduction adequate or should oxaliplatin be discontinued?
        2. CAPOX as an alternative – patient preference re: port vs oral?
        3. Role of neuroprotective agents (e.g., duloxetine)?
        4. Nutritional support – TPN vs aggressive oral supplementation?"
      extract_clinical_instructions() uses numbered-list regex to pull these
      action items, but free-prose instructions ("Please contact me...") require
      a separate action-verb pattern.

    ISSUE: Base64-encoded PDF attachment in MIME multipart structure
      --CGH_BOUNDARY_20240325
      Content-Type: application/pdf; name="lab_results_AK_20240325.pdf"
      Content-Transfer-Encoding: base64
      The attachment exists but its clinical content (the lab values) is
      inaccessible to the body-text pipeline — a separate OCR/PDF extraction
      step would be required to read it.

  EMAIL 2 — Informal patient email to clinic admin
    From: sunita.mehta89@gmail.com  ← personal Gmail, not hospital system
    To:   appointments@cghmumbai.org
    Subject: "Re appointment next month - also question about medicine"

    ISSUE: Mixed administrative and clinical content in one message
      The email starts as an appointment reschedule request ("can it be changed
      to morning slot?") but pivots to a clinical question ("my periods are
      delayed by 10 days since starting the medicine. Is that because of
      sertraline?"). If routed only to scheduling staff, the clinical question
      is missed — a patient safety risk. classify_email() must detect both
      "appointment" and "prescription" categories and flag dual routing.

    ISSUE: Spelling and grammar issues lower NLP confidence
      "Re appointment" (missing colon), "doesnt work", "I am feeling a little
      better this week" — informal register without clinical structure.
      Symptom detection ("dizziness has gone", "Sleep is still not great")
      relies on the SYMPTOM_PATTERN regex which requires exact keyword matches.

    ISSUE: PHI in a non-hospital, unencrypted channel
      Patient name in From address and body, phone number "9876-XXXXXX" (masked
      in the demo but present in real messages), and psychiatric medication name
      — all transmitted via a personal Gmail account with no HIPAA controls.

  EMAIL 3 — Automated system-generated pharmacy alert
    From: noreply@cgpharmacy-system.com
    To:   cardiology-ward4@cghmumbai.org
    Subject: [PHARMACY ALERT] Medication Reconciliation Required – MRN CGH-2024-0431

    ISSUE: Automated email mixed with human emails in the same inbox
      The email has a "DO NOT REPLY" footer and structured all-caps sections
      (INPATIENT MED / DISCHARGE MED / ACTION REQUIRED). A system reading the
      inbox must recognise this as machine-generated and route it differently
      from human correspondence.

    ISSUE: Medication discrepancy embedded in formatted text
      INPATIENT MED:  Furosemide 40mg IV OD  (Active)
      INPATIENT MED:  Furosemide 20mg PO BD  (Active - added 16/03)
      DISCHARGE MED:  Furosemide 40mg PO OD  (prescribed on discharge Rx)
      Three lines describing the same drug at different doses/routes — the same
      Furosemide duplication already seen in ehr_page.html and hospital_system.log,
      now surfacing in a third channel. Cross-channel deduplication is needed.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

import re
import email
import email.policy
from email import message_from_string
from pathlib import Path
from datetime import datetime
from collections import defaultdict, Counter

DATA_DIR = Path(__file__).parent / "data"
SEPARATOR = "\n" + "=" * 80 + "\n"
SEP_MINOR = "\n" + "-" * 60 + "\n"

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1: CHAT TRANSCRIPT PARSING
# ─────────────────────────────────────────────────────────────────────────────

# Healthcare chat abbreviations (patient-facing, informal)
CHAT_ABBREVIATIONS = {
    r'\btmrw\b': 'tomorrow',
    r'\bpls\b': 'please',
    r'\bthx\b': 'thanks',
    r'\bu\b': 'you',
    r'\br\b': 'are',
    r'\bn\b': 'and',
    r'\bsob\b': 'shortness of breath',
    r'\bbt\b': 'but',
    r'\bokk?\b': 'okay',
    r'\bkk\b': 'okay',
    r'\bwt\b': 'weight',
    r'\bbp\b': 'blood pressure',
    r'\bbd\b': 'twice daily',
    r'\bod\b': 'once daily',
    r'\bsos\b': 'as needed (emergency)',
    r'\btid\b': 'three times daily',
    r'\bprn\b': 'as needed',
    r'\bfyi\b': 'for your information',
    r'\btbh\b': 'to be honest',
    r'\bimo\b': 'in my opinion',
    r'\basap\b': 'as soon as possible',
    r'\biv\b': 'intravenous',
    r'\bpo\b': 'oral',
    r'\bq\b': 'every',
}

# Urgency keywords — flag messages needing immediate clinical attention
URGENCY_KEYWORDS = [
    'chest pain', 'severe', 'can\'t breathe', 'cannot breathe', 'unconscious',
    'fainted', 'blackout', 'vomiting blood', 'blood', 'very bad', 'critical',
    'emergency', 'suicidal', 'harm myself', 'hurt myself', 'die', 'kill',
    'severe pain', 'not waking', 'convulsion', 'seizure', 'anaphylaxis',
    'allergic reaction', 'rash all over', 'face swelling', 'can\'t swallow',
    'bp very high', '200', 'glucose very high', 'feel faint', 'dizziness severe',
    'breathless at rest', 'weight gain', 'leg very swollen',
]

# Medication-related patterns in chat
MED_MENTION_PATTERN = re.compile(
    r'\b(metformin|furosemide|lisinopril|telmisartan|sertraline|metoprolol|'
    r'aspirin|warfarin|rivaroxaban|insulin|atenolol|amlodipine|omeprazole|'
    r'clonazepam|alprazolam|ondansetron|spironolactone|enoxaparin)\b',
    re.IGNORECASE
)

SYMPTOM_PATTERN = re.compile(
    r'\b(pain|breathless|dizzy|dizziness|headache|fever|cough|swelling|'
    r'nausea|vomiting|tired|fatigue|blurred vision|chest tightness|'
    r'palpitations|fainting|confusion|bleeding|rash|itching|weight gain|'
    r'weight loss|low sugar|high sugar|glucose|blood pressure)\b',
    re.IGNORECASE
)

# PII/PHI patterns
PHI_PATTERNS = {
    "phone": re.compile(r'\b\d{4}[-\s]?\d{6}\b|\b\d{10}\b|\+91\s?\d{10}'),
    "mrn": re.compile(r'MRN[:\s]*[\w-]+', re.IGNORECASE),
    "date_of_birth": re.compile(r'DOB[:\s:]*[\d/]+', re.IGNORECASE),
    "name": re.compile(r'\b(?:Mrs?|Ms|Dr)\.\s+[A-Z][a-z]+\s+[A-Z][a-z]+'),
    "email": re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z]{2,}\b', re.IGNORECASE),
}


def parse_chat_file(filepath: Path) -> list[dict]:
    """Parse the chat transcript file into individual conversations."""
    text = filepath.read_text(encoding="utf-8")
    conversations = []

    # Split on transcript separators
    transcript_blocks = re.split(r'--- TRANSCRIPT \d+:.*?---', text)
    headers = re.findall(r'--- TRANSCRIPT \d+: (.*?) ---', text)

    for i, (header, block) in enumerate(zip(headers, transcript_blocks[1:]), 1):
        messages = parse_chat_messages(block)
        conversations.append({
            "id": i,
            "title": header.strip(),
            "messages": messages,
            "message_count": len(messages),
        })
    return conversations


def parse_chat_messages(text: str) -> list[dict]:
    """
    Parse individual chat messages from a conversation block.
    CHALLENGE: Format varies — timestamp, sender, message may be inconsistent.
    """
    messages = []
    # Pattern: [HH:MM] SENDER (detail): message content
    pattern = re.compile(
        r'\[(\d{2}:\d{2})\]\s+'
        r'([A-Z][A-Z\s]+(?:\([^)]+\))?)[:\s]+'
        r'(.+?)(?=\n\[|\Z)',
        re.DOTALL
    )

    for m in pattern.finditer(text):
        timestamp = m.group(1)
        sender_raw = m.group(2).strip()
        message_text = m.group(3).strip().replace('\n        ', ' ')

        # Classify sender type
        sender_type = "unknown"
        if re.search(r'DR\.?|DOCTOR|PHYSICIAN', sender_raw, re.IGNORECASE):
            sender_type = "clinician"
        elif re.search(r'PATIENT|PT', sender_raw, re.IGNORECASE):
            sender_type = "patient"
        elif re.search(r'NURSE|HELPLINE', sender_raw, re.IGNORECASE):
            sender_type = "nurse"

        messages.append({
            "time": timestamp,
            "sender_raw": sender_raw,
            "sender_type": sender_type,
            "text": message_text,
            "word_count": len(message_text.split()),
        })
    return messages


def expand_chat_abbreviations(text: str) -> str:
    """Normalize informal chat language."""
    for pattern, expansion in CHAT_ABBREVIATIONS.items():
        text = re.sub(pattern, expansion, text, flags=re.IGNORECASE)
    return text


def assess_message_urgency(text: str) -> tuple[str, list[str]]:
    """
    CHALLENGE: Urgency/safety signals buried in casual, informal text.
    A patient saying 'I feel dizzy and breathless' in a chat needs
    different handling than the same words in a clinical note.
    Returns (urgency_level, matched_keywords)
    """
    text_lower = text.lower()
    matched = [kw for kw in URGENCY_KEYWORDS if kw in text_lower]

    # Weight the matches
    critical_terms = ['suicidal', 'harm myself', 'kill', 'unconscious', 'anaphylaxis',
                      'seizure', 'convulsion', 'vomiting blood']
    high_terms = ['chest pain', 'severe', 'cannot breathe', 'can\'t breathe',
                  'bp very high', 'face swelling']

    if any(term in text_lower for term in critical_terms):
        return "CRITICAL", matched
    elif any(term in text_lower for term in high_terms):
        return "HIGH", matched
    elif matched:
        return "MEDIUM", matched
    else:
        return "LOW", matched


def extract_medication_mentions(text: str) -> list[str]:
    return list(set(MED_MENTION_PATTERN.findall(text.lower())))


def detect_phi_in_text(text: str) -> dict[str, list[str]]:
    """
    CHALLENGE: PHI/PII appears in informal healthcare communications.
    Must detect for compliance — chat and email are often unencrypted.
    """
    found = {}
    for phi_type, pattern in PHI_PATTERNS.items():
        matches = pattern.findall(text)
        if matches:
            found[phi_type] = list(set(matches))
    return found


def calculate_response_time(messages: list[dict]) -> list[dict]:
    """
    Analyze response times in patient-clinician chat.
    CHALLENGE: Delayed responses to urgent messages are a patient safety risk.
    """
    response_times = []
    for i in range(1, len(messages)):
        curr = messages[i]
        prev = messages[i - 1]
        # Only measure patient→clinician or clinician→patient transitions
        if curr["sender_type"] != prev["sender_type"]:
            try:
                t1 = datetime.strptime(prev["time"], "%H:%M")
                t2 = datetime.strptime(curr["time"], "%H:%M")
                delta_min = (t2 - t1).seconds // 60
                response_times.append({
                    "from": prev["sender_type"],
                    "to": curr["sender_type"],
                    "wait_minutes": delta_min,
                    "query": prev["text"][:60],
                })
            except ValueError:
                pass
    return response_times


def run_chat_demo():
    print(SEPARATOR)
    print("SECTION 1: HEALTHCARE CHAT TRANSCRIPTS")
    print(SEPARATOR)

    filepath = DATA_DIR / "chat_transcript.txt"
    if not filepath.exists():
        print(f"[ERROR] File not found: {filepath}")
        return

    conversations = parse_chat_file(filepath)
    print(f"Loaded {len(conversations)} conversation(s) from {filepath.name}\n")

    for conv in conversations:
        print(f"{'─'*60}")
        print(f"CONVERSATION {conv['id']}: {conv['title']}")
        print(f"Messages: {conv['message_count']}")
        print(f"{'─'*60}\n")

        messages = conv["messages"]
        if not messages:
            print("  (no parseable messages)\n")
            continue

        # Sender distribution
        sender_counts = Counter(m["sender_type"] for m in messages)
        print(f"Participants: {dict(sender_counts)}")
        print()

        # Message-level analysis
        print("Messages with Analysis:")
        for msg in messages:
            urgency, matched_kw = assess_message_urgency(msg["text"])
            meds = extract_medication_mentions(msg["text"])
            symptoms = SYMPTOM_PATTERN.findall(msg["text"])
            phi = detect_phi_in_text(msg["text"])

            # Show message
            urgency_icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🟢"}[urgency]
            print(f"  [{msg['time']}] {msg['sender_raw'][:20]:20s} {urgency_icon} {urgency:8s}")
            print(f"    Text: {msg['text'][:80]}{'...' if len(msg['text'])>80 else ''}")

            if matched_kw:
                print(f"    [URGENCY SIGNAL] Keywords: {matched_kw}")
            if meds:
                print(f"    [MEDICATION] Mentioned: {meds}")
            if symptoms:
                print(f"    [SYMPTOMS] Detected: {list(set(s.lower() for s in symptoms))[:5]}")
            if phi:
                print(f"    [PHI ALERT] Sensitive data found: {list(phi.keys())}")
                print(f"    ⚠ COMPLIANCE: PHI detected in unencrypted chat channel!")

            # Normalize abbreviations
            if msg["sender_type"] == "patient":
                normalized = expand_chat_abbreviations(msg["text"])
                if normalized != msg["text"]:
                    diff_count = sum(1 for a, b in zip(msg["text"].split(), normalized.split()) if a != b)
                    print(f"    [CHALLENGE: ABBREVIATIONS] {diff_count} terms expanded for NLP processing")
            print()

        # Response time analysis
        print("Response Time Analysis:")
        response_times = calculate_response_time(messages)
        if response_times:
            for rt in response_times:
                wait_flag = " ⚠ DELAYED" if rt["wait_minutes"] > 30 else ""
                print(f"  {rt['from']:10s} → {rt['to']:10s} : {rt['wait_minutes']:3d} min wait{wait_flag}")
                print(f"    Query: {rt['query']}...")
        print()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2: EMAIL PARSING
# ─────────────────────────────────────────────────────────────────────────────

def parse_eml_file(filepath: Path) -> list[dict]:
    """
    Parse .eml file containing multiple emails.
    CHALLENGE: .eml files may contain:
      - MIME multipart content (text + attachments)
      - Base64-encoded content
      - Multiple emails concatenated
      - Inconsistent header formats
    """
    content = filepath.read_text(encoding="utf-8", errors="replace")

    # Split multiple emails in file
    # Look for "From:" at start of line as email boundary
    email_blocks = re.split(r'(?=^From:\s+)', content, flags=re.MULTILINE)

    parsed_emails = []
    for block in email_blocks:
        block = block.strip()
        if not block or not block.startswith("From:"):
            continue

        try:
            msg = message_from_string(block, policy=email.policy.default)
        except Exception:
            msg = message_from_string(block)

        # Extract headers
        email_record = {
            "from": str(msg.get("From", "")),
            "to": str(msg.get("To", "")),
            "cc": str(msg.get("Cc", "")),
            "date": str(msg.get("Date", "")),
            "subject": str(msg.get("Subject", "")),
            "message_id": str(msg.get("Message-ID", "")),
            "body": "",
            "attachments": [],
        }

        # Extract body text
        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                disposition = str(part.get("Content-Disposition", ""))

                if content_type == "text/plain" and "attachment" not in disposition:
                    try:
                        email_record["body"] += part.get_payload(decode=True).decode("utf-8", errors="replace")
                    except Exception:
                        email_record["body"] += str(part.get_payload())
                elif "attachment" in disposition:
                    fname = part.get_filename()
                    if fname:
                        email_record["attachments"].append(fname)
        else:
            try:
                payload = msg.get_payload(decode=True)
                if payload:
                    email_record["body"] = payload.decode("utf-8", errors="replace")
                else:
                    email_record["body"] = str(msg.get_payload())
            except Exception:
                email_record["body"] = str(msg.get_payload() or "")

        # Clean body — remove email disclaimers and signatures
        email_record["body_clean"] = clean_email_body(email_record["body"])
        parsed_emails.append(email_record)

    return parsed_emails


def clean_email_body(body: str) -> str:
    """
    CHALLENGE: Email bodies contain noise that interferes with NLP:
      - Confidentiality notices (repeated on every email)
      - Legal disclaimers
      - Quoted reply chains (>>>, On Monday... wrote:)
      - Auto-signatures and footers
      - Horizontal rules (---, ===)
    """
    # Remove confidentiality notices
    body = re.sub(
        r'CONFIDENTIALITY NOTICE:.*?(?=\n\n|\Z)',
        '[CONFIDENTIALITY NOTICE REMOVED]',
        body, flags=re.DOTALL | re.IGNORECASE
    )

    # Remove quoted reply blocks
    body = re.sub(r'^>+.*$', '', body, flags=re.MULTILINE)
    body = re.sub(r'On .{5,50} wrote:.*', '[QUOTED REPLY REMOVED]', body, flags=re.DOTALL)

    # Remove common signature separators
    body = re.sub(r'\n[-–—]{3,}\n.*', '\n[SIGNATURE REMOVED]', body, flags=re.DOTALL)

    # Remove multiple blank lines
    body = re.sub(r'\n{3,}', '\n\n', body)

    # Remove DO NOT REPLY footers
    body = re.sub(r'DO NOT REPLY.*$', '[AUTO-REPLY FOOTER REMOVED]', body,
                  flags=re.DOTALL | re.IGNORECASE)

    return body.strip()


def classify_email(subject: str, body: str) -> dict:
    """
    CHALLENGE: Healthcare emails span many categories and urgency levels.
    Must route correctly — misrouted clinical emails can harm patients.
    """
    subject_lower = subject.lower()
    body_lower = body.lower()
    combined = subject_lower + " " + body_lower

    categories = {
        "referral": ["referral", "refer", "consultant", "specialist", "review"],
        "lab_results": ["lab", "laboratory", "result", "blood test", "investigation"],
        "prescription": ["prescription", "medication", "refill", "drug", "Rx"],
        "appointment": ["appointment", "schedule", "slot", "OPD", "booking", "cancel"],
        "emergency": ["urgent", "emergency", "critical", "asap", "immediately", "stat"],
        "follow_up": ["follow-up", "follow up", "review", "check-up", "outpatient"],
        "complaint": ["complaint", "unhappy", "concern", "problem", "issue", "feedback"],
        "administrative": ["insurance", "billing", "payment", "report", "records"],
        "pharmacy_alert": ["pharmacy", "medication alert", "dispense", "reconciliation"],
    }

    detected = {}
    for cat, keywords in categories.items():
        score = sum(1 for kw in keywords if kw in combined)
        if score > 0:
            detected[cat] = score

    primary_category = max(detected, key=detected.get) if detected else "other"

    # Urgency
    urgency_words = ["urgent", "critical", "asap", "immediately", "stat", "emergency"]
    is_urgent = any(w in combined for w in urgency_words)

    # Requires clinical action?
    clinical_action_words = ["referral", "review", "consult", "investigation", "prescription",
                              "order", "schedule", "urgent", "critical value"]
    needs_clinical_action = any(w in combined for w in clinical_action_words)

    return {
        "primary_category": primary_category,
        "all_categories": detected,
        "is_urgent": is_urgent,
        "needs_clinical_action": needs_clinical_action,
        "routing_suggestion": _suggest_routing(primary_category, is_urgent),
    }


def _suggest_routing(category: str, urgent: bool) -> str:
    routing = {
        "referral": "Attending Physician + Specialist Coordinator",
        "lab_results": "Ordering Physician",
        "prescription": "Prescribing Doctor + Pharmacy",
        "appointment": "Reception / Scheduling",
        "emergency": "🔴 EMERGENCY — Call Code Team / On-call Doctor NOW",
        "follow_up": "OPD Coordinator",
        "complaint": "Patient Relations / Quality Department",
        "administrative": "Medical Records / Billing",
        "pharmacy_alert": "Pharmacist + Prescribing Doctor",
        "other": "General Inbox — Manual Review Required",
    }
    route = routing.get(category, "General Inbox")
    if urgent and category != "emergency":
        route = f"⚠ URGENT: {route}"
    return route


def extract_clinical_instructions(body: str) -> list[str]:
    """
    Extract actionable clinical instructions from email body.
    CHALLENGE: Instructions are mixed with narrative text.
    """
    instructions = []
    # Numbered list items
    numbered = re.findall(r'^\s*\d+[\.\)]\s+(.+?)(?=\n\s*\d+[\.\)]|\Z)',
                          body, re.MULTILINE | re.DOTALL)
    instructions.extend([n.strip().replace('\n', ' ')[:100] for n in numbered])

    # Questions to address (common in referral emails)
    questions = re.findall(r'^\s*\d+[\.\)]\s+(?:Is|Are|Should|Can|What|When|How|Whether).+\?',
                           body, re.MULTILINE)
    # Sentences with action verbs
    actions = re.findall(r'(?:Please|Kindly|Ensure|Arrange|Order|Schedule|Refer|Review|Check)\s+.+?[.\n]',
                         body, re.IGNORECASE)
    instructions.extend([a.strip()[:100] for a in actions[:5]])
    return list(dict.fromkeys(instructions))  # deduplicate preserving order


def extract_phi_from_email(email_record: dict) -> dict:
    """
    Detect PHI across all email fields.
    CHALLENGE: PHI spreads across headers (To/From), subject, and body.
    """
    all_text = " ".join([
        email_record.get("from", ""),
        email_record.get("to", ""),
        email_record.get("subject", ""),
        email_record.get("body", ""),
    ])
    return detect_phi_in_text(all_text)


def run_email_demo():
    print(SEPARATOR)
    print("SECTION 2: HEALTHCARE EMAIL PROCESSING")
    print(SEPARATOR)

    filepath = DATA_DIR / "referral_email.eml"
    if not filepath.exists():
        print(f"[ERROR] File not found: {filepath}")
        return

    emails = parse_eml_file(filepath)
    print(f"Parsed {len(emails)} email(s) from {filepath.name}\n")

    for i, em in enumerate(emails, 1):
        print(f"{'─'*60}")
        print(f"EMAIL {i}:")
        print(f"{'─'*60}")
        print(f"  From    : {em['from']}")
        print(f"  To      : {em['to']}")
        print(f"  Subject : {em['subject']}")
        print(f"  Date    : {em['date']}")
        if em['attachments']:
            print(f"  Attachments: {em['attachments']}")
        print()

        # CHALLENGE: Show cleaning difference
        raw_body = em.get("body", "")
        clean_body = em.get("body_clean", raw_body)
        print(f"[CHALLENGE: NOISE] Body length: raw={len(raw_body)} chars, cleaned={len(clean_body)} chars")
        noise_removed = len(raw_body) - len(clean_body)
        print(f"  Noise removed: {noise_removed} chars (disclaimers, signatures, footers)")
        print()

        # Classification & routing
        classification = classify_email(em["subject"], clean_body)
        print(f"── Email Classification ──")
        print(f"  Category   : {classification['primary_category'].upper()}")
        print(f"  All matches: {classification['all_categories']}")
        print(f"  Urgent     : {'YES ⚠' if classification['is_urgent'] else 'No'}")
        print(f"  Clinical   : {'YES — needs clinical response' if classification['needs_clinical_action'] else 'Administrative only'}")
        print(f"  → ROUTE TO : {classification['routing_suggestion']}")
        print()

        # PHI detection
        phi = extract_phi_from_email(em)
        if phi:
            print(f"── PHI / Compliance Alert ──")
            print(f"  [CHALLENGE: PRIVACY] PHI detected in email communication:")
            for phi_type, values in phi.items():
                masked = [v[:4] + "***" + v[-2:] if len(v) > 6 else "***" for v in values]
                print(f"    {phi_type:15s}: {masked}")
            print(f"  ⚠ Action: Emails with PHI should be sent via encrypted channel (HIPAA/DISHA)")
            print()

        # Clinical instructions
        instructions = extract_clinical_instructions(clean_body)
        if instructions:
            print(f"── Extracted Clinical Instructions/Action Items ──")
            for j, instr in enumerate(instructions[:6], 1):
                print(f"  {j}. {instr}")
            print()

        # Key clinical entities from body
        print(f"── Key Clinical Entities ──")
        meds = extract_medication_mentions(clean_body)
        symptoms = list(set(s.lower() for s in SYMPTOM_PATTERN.findall(clean_body)))
        diagnoses = re.findall(r'(?:diagnosis|diagnosed with|impression|Dx)[:\s]+([A-Z][^.]{5,50})', clean_body, re.IGNORECASE)
        doses = re.findall(r'(\d+(?:\.\d+)?)\s*(?:mg|mcg|g|mL|units?)', clean_body)
        dates_mentioned = re.findall(r'\d{1,2}/\d{1,2}/\d{4}|\d{1,2}\s+\w+\s+\d{4}', clean_body)

        if meds:
            print(f"  Medications : {meds}")
        if symptoms:
            print(f"  Symptoms    : {symptoms[:6]}")
        if diagnoses:
            print(f"  Diagnoses   : {[d.strip()[:50] for d in diagnoses[:3]]}")
        if doses:
            print(f"  Doses       : {list(set(doses))[:8]}")
        if dates_mentioned:
            print(f"  Dates       : {list(set(dates_mentioned))[:5]}")
        print()

        # Show cleaned body excerpt
        print(f"── Cleaned Body (first 400 chars) ──")
        print(f"  {clean_body[:400]}...")
        print()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3: COMBINED ANALYSIS — Chat + Email Linkage
# ─────────────────────────────────────────────────────────────────────────────

def run_combined_analysis():
    print(SEPARATOR)
    print("SECTION 3: CROSS-CHANNEL PATIENT JOURNEY ANALYSIS")
    print(SEPARATOR)

    print("Healthcare data appears across MULTIPLE communication channels.")
    print("Linking them gives a complete patient picture.\n")

    # Simulate linking patient ID across channels
    patient_comms = {
        "MRN:CGH-2024-0431 (John Doe)": {
            "chat_messages": 10,
            "emails": 2,
            "clinical_notes": 6,
            "log_events": 35,
            "channels": ["Patient Portal Chat", "Pharmacy Alert Email", "EHR System"],
        },
        "MRN:CGH-2024-Sunita (Sunita Mehta)": {
            "chat_messages": 6,
            "emails": 1,
            "clinical_notes": 1,
            "log_events": 0,
            "channels": ["Nurse Helpline Chat", "Gmail (informal)"],
        },
    }

    print("Patient Communication Summary:\n")
    for patient, data in patient_comms.items():
        total_touchpoints = (data["chat_messages"] + data["emails"] +
                             data["clinical_notes"] + data["log_events"])
        print(f"  Patient: {patient}")
        print(f"    Total touchpoints : {total_touchpoints}")
        print(f"    Chat messages     : {data['chat_messages']}")
        print(f"    Emails            : {data['emails']}")
        print(f"    Clinical notes    : {data['clinical_notes']}")
        print(f"    System log events : {data['log_events']}")
        print(f"    Channels used     : {', '.join(data['channels'])}")
        print()

    print("[CHALLENGE: FORMAT VARIATION] Each channel has different:")
    print("  • Timestamp format (HH:MM in chat vs RFC 2822 in email vs ISO in logs)")
    print("  • Speaker identification (username vs email address vs staff ID)")
    print("  • Clinical terminology level (informal ↔ formal ↔ coded)")
    print("  • Data completeness (emoji reactions vs structured fields)")
    print()
    print("[APPROACH] Patient identity resolution:")
    print("  1. MRN as primary key (if present)")
    print("  2. Name + DOB matching (fuzzy, given typos)")
    print("  3. Phone/email cross-reference across channels")
    print("  4. Timeline alignment — corroborate events across channels")
    print("  5. NLP entity linking — 'John' in chat = 'Mr. Doe' in email = 'MRN-0431' in logs")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("  HEALTHCARE UNSTRUCTURED DATA PROCESSING — DEMO 3")
    print("  Topic: Chat Transcripts & Emails")
    print("=" * 80)

    run_chat_demo()
    run_email_demo()
    run_combined_analysis()

    print(SEPARATOR)
    print("SUMMARY OF DATA CHALLENGES IN CHAT & EMAIL:")
    print(SEPARATOR)
    challenges = {
        "INFORMAL LANGUAGE":
            "Patient chats use slang, abbreviations, emojis — NLP must normalize first",
        "URGENCY DETECTION":
            "Life-threatening signals buried in casual messages — 'I feel a bit breathless'",
        "AMBIGUITY":
            "Same word = different meaning: 'SOB' = son-of, shortness-of-breath, or name",
        "PHI/COMPLIANCE":
            "Names, MRNs, diagnoses, phone numbers in unencrypted email/chat",
        "NOISE":
            "Disclaimers, footers, quoted replies, auto-signatures pollute email bodies",
        "MISROUTING":
            "Clinical emails misclassified as admin = delayed patient care",
        "THREADING":
            "Multi-email threads lose context when processed individually",
        "MULTI-CHANNEL":
            "Same patient info fragmented across chat, email, EHR, logs — hard to unify",
    }
    for k, v in challenges.items():
        print(f"  [{k}] {v}")
    print()


# ─────────────────────────────────────────────────────────────────────────────
# LIMITATIONS OF RULE-BASED APPROACHES & RECOMMENDATIONS
# ─────────────────────────────────────────────────────────────────────────────
#
# LIMITATIONS
# ───────────
#
# 1. KEYWORD-BASED URGENCY DETECTION CAUSES FALSE POSITIVES AND FALSE NEGATIVES
#    The URGENCY_KEYWORDS list fires on any mention of a danger word regardless
#    of context. Examples from the demo data:
#      False positive: "I read on internet it causes suicidal thoughts"
#        → CRITICAL flag triggered, but patient is citing a side-effect warning,
#          not expressing intent.
#      False negative: "I feel a bit breathless going up one flight"
#        → "breathless" alone scores MEDIUM; a clinician would recognise this
#          as a significant post-CHF symptom requiring follow-up.
#    Urgency cannot be reliably inferred from word lists — it requires discourse
#    context, patient history, and clinical reasoning.
#
# 2. CHAT ABBREVIATION EXPANSION IS CHANNEL-SPECIFIC AND COLLIDES
#    CHAT_ABBREVIATIONS maps 'bp' → 'blood pressure' and 'bd' → 'twice daily'.
#    In doctor-to-doctor ICU handover (Transcript 2) these same tokens mean
#    the same things — but 'po' in a nurse chat could be "per oral" or the
#    start of a name. The dict is a global substitution with no scope awareness.
#    Expanding 'r' → 'are' also risks corrupting medical abbreviations like
#    "R lower lobe" or "R leg" that happen to be single-letter tokens.
#
# 3. EMAIL CLASSIFICATION USES KEYWORD SCORING, NOT SEMANTIC UNDERSTANDING
#    classify_email() counts keyword hits per category. The patient email
#    ("Re appointment...also question about medicine") scores hits in both
#    "appointment" and "prescription" buckets, but the routing logic only
#    returns the highest-scoring category — the clinical question about
#    sertraline and menstrual changes is silently dropped in favour of the
#    appointment category because scheduling keywords score slightly higher.
#    A missed clinical question routed to admin staff is a patient safety gap.
#
# 4. PHI DETECTION MISSES INDIRECT AND CONTEXTUAL IDENTIFIERS
#    PHI_PATTERNS uses regex for phones, MRNs, DOBs, formal names, and emails.
#    It will miss:
#      - "Sunita from psychiatry" (no title, single name, no surname)
#      - "the patient in Bed 4B" (indirect reference, identifiable in context)
#      - "my son who goes to Bandra school" (quasi-identifier combination)
#    HIPAA and India's DISHA framework consider combinations of indirect
#    identifiers as PHI — regex cannot evaluate combinations.
#
# 5. clean_email_body() REMOVES CONTENT IT CANNOT DISTINGUISH FROM NOISE
#    The signature removal rule is:  r'\n[-–—]{3,}\n.*'  (dotall)
#    In Email 1 the lab results block is preceded by dashes in the
#    MIME boundary line and in list separators — any such line risks
#    truncating real clinical content. The confidentiality notice removal
#    is keyed on the exact phrase "CONFIDENTIALITY NOTICE:" — a one-word
#    variation in a different hospital's template would be kept verbatim.
#
# 6. RESPONSE-TIME ANALYSIS IGNORES OVERNIGHT AND MULTI-DAY GAPS
#    calculate_response_time() computes delta between adjacent messages using
#    only HH:MM timestamps. If a patient sends a message at 23:50 and the
#    clinician replies at 00:10, the computed wait is -23h40m (negative),
#    not the actual 20 minutes. Cross-midnight and multi-day conversations
#    produce garbage timings with no error surfaced to the user.
#
# 7. NO CROSS-CHANNEL DEDUPLICATION OR LINKAGE
#    The Furosemide discrepancy appears in all three data sources:
#    ehr_page.html, hospital_system.log, and referral_email.eml.
#    Each demo section flags it independently. Without cross-channel identity
#    resolution there is no way to confirm these are the same event, count it
#    once, or suppress redundant alerts once a clinician has acknowledged it.
#
#
# RECOMMENDATIONS — TECHNIQUES THAT PERFORM BETTER
# ─────────────────────────────────────────────────
#
# 1. INTENT CLASSIFICATION WITH FINE-TUNED LANGUAGE MODELS
#    Replace keyword urgency scoring with a BERT-based intent classifier trained
#    on labelled healthcare chat data. Models like ClinicalBERT or a fine-tuned
#    DistilBERT can distinguish "I'm worried about suicidal side effects" from
#    "I'm feeling suicidal" with >90% accuracy on patient portal data.
#    HuggingFace's medical-intent datasets (e.g., MedNLI) provide a starting
#    point for fine-tuning without labelling from scratch.
#
# 2. LLM-BASED TRIAGE WITH STRUCTURED OUTPUT
#    Prompt a large language model (GPT-4 / Claude) to read a full conversation
#    and return a structured JSON:
#      { "urgency": "HIGH", "reason": "...", "action_items": [...],
#        "phi_present": true, "medications_mentioned": [...] }
#    This handles context, negation, and discourse in a single pass and
#    generalises across informal registers without per-channel tuning.
#
# 3. PRESIDIO OR AWS COMPREHEND MEDICAL FOR PHI DETECTION
#    Microsoft Presidio (open-source) and AWS Comprehend Medical use NER models
#    that detect PHI at entity level including indirect identifiers and contextual
#    references that regex cannot capture. They support custom entity types and
#    configurable confidence thresholds — replacing PHI_PATTERNS entirely.
#
# 4. DISCOURSE-AWARE NEGATION AND SPECULATION DETECTION
#    Use a dependency-parse-based negation model (NegEx, medspaCy) or an LLM
#    to classify whether a mention is: asserted / negated / speculative /
#    historical / hypothetical. This eliminates the false-positive urgency
#    problem where patients describe feared rather than experienced symptoms.
#
# 5. SEMANTIC EMAIL ROUTING WITH MULTI-LABEL CLASSIFICATION
#    Train a multi-label classifier (not single-category) on historical
#    healthcare emails so one message can simultaneously be tagged
#    [appointment, clinical_query] and routed to both scheduling and the
#    clinical team. Tools: SetFit (few-shot), or fine-tuned sentence-transformers
#    with binary cross-entropy heads per category.
#
# 6. VECTOR SEARCH FOR CROSS-CHANNEL PATIENT LINKAGE
#    Embed all communications (chat, email, log events) using a sentence
#    transformer and index them in a vector store (FAISS, Pinecone, pgvector).
#    Querying "all communications about Furosemide for patient 0431 this week"
#    returns matches regardless of channel, format, or exact wording —
#    solving both the deduplication and cross-channel linkage problems.
#
# 7. ENCRYPTED CHANNEL ENFORCEMENT AT INGESTION
#    PHI detection after-the-fact is a compensating control, not a fix.
#    The root issue is that clinical information flows through personal Gmail
#    and unencrypted chat. Enforcing secure messaging (e.g., TigerConnect,
#    Signal for healthcare, or a HIPAA-compliant portal) at the point of
#    communication removes the compliance risk upstream of any NLP pipeline.
