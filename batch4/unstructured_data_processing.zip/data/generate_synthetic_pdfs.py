"""
generate_synthetic_pdfs.py
==========================
Generates synthetic healthcare PDFs (machine-readable) and a scanned prescription
image (for OCR demos). Run this ONCE to create data files used in demo scripts.

Requirements: pip install reportlab Pillow
"""

import os
from pathlib import Path

OUTPUT_DIR = Path(__file__).parent  # saves in data/ folder


# ─────────────────────────────────────────────────────────────────────────────
# 1. Machine-readable PDF: Lab Report
# ─────────────────────────────────────────────────────────────────────────────
def create_lab_report_pdf():
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.lib import colors
        from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle,
                                        Paragraph, Spacer, HRFlowable)
        from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
    except ImportError:
        print("  [SKIP] reportlab not installed. Run: pip install reportlab")
        return

    filepath = OUTPUT_DIR / "lab_report_CGH_0431.pdf"
    doc = SimpleDocTemplate(str(filepath), pagesize=A4,
                            leftMargin=15*mm, rightMargin=15*mm,
                            topMargin=15*mm, bottomMargin=15*mm)
    styles = getSampleStyleSheet()
    elements = []

    # Header
    header_style = ParagraphStyle("header", fontSize=14, fontName="Helvetica-Bold",
                                  alignment=TA_CENTER, spaceAfter=4)
    sub_style = ParagraphStyle("sub", fontSize=10, alignment=TA_CENTER, spaceAfter=2)
    label_style = ParagraphStyle("label", fontSize=9, fontName="Helvetica-Bold")
    normal = ParagraphStyle("norm", fontSize=9)

    elements.append(Paragraph("CITY GENERAL HOSPITAL", header_style))
    elements.append(Paragraph("Laboratory Investigation Report", sub_style))
    elements.append(Paragraph("Lab Accreditation: NABL | Report ID: LAB-2024-031522", sub_style))
    elements.append(HRFlowable(width="100%", thickness=2, color=colors.darkblue))
    elements.append(Spacer(1, 4*mm))

    # Patient info table
    patient_data = [
        ["Patient Name:", "John Doe", "MRN:", "CGH-2024-0431"],
        ["Age / Sex:", "66 Years / Male", "Ward / Bed:", "Cardiology / 4B"],
        ["Ref. Physician:", "Dr. R. Patel", "Collection Date:", "15/03/2024 22:45"],
        ["Diagnosis:", "Acute Decompensated CHF, T2DM, CAD", "Report Date:", "15/03/2024 23:15"],
    ]
    pt_table = Table(patient_data, colWidths=[38*mm, 62*mm, 30*mm, 50*mm])
    pt_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#EEF2FF")),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
        ("PADDING", (0, 0), (-1, -1), 4),
    ]))
    elements.append(pt_table)
    elements.append(Spacer(1, 5*mm))

    # Section: Hematology
    elements.append(Paragraph("HEMATOLOGY", ParagraphStyle("sec", fontSize=10,
                               fontName="Helvetica-Bold", backColor=colors.HexColor("#003366"),
                               textColor=colors.white, spaceAfter=2, spaceBefore=4,
                               leftIndent=2, rightIndent=2)))
    elements.append(Spacer(1, 1*mm))

    hema_headers = [["Test", "Result", "Unit", "Reference Range", "Flag"]]
    hema_data = [
        ["Hemoglobin (Hb)", "11.2", "g/dL", "13.0 – 17.0", "LOW ↓"],
        ["Hematocrit (PCV)", "34.1", "%", "40.0 – 52.0", "LOW ↓"],
        ["RBC Count", "3.82", "× 10⁶/µL", "4.5 – 5.9", "LOW ↓"],
        ["MCV", "89.3", "fL", "80 – 100", "Normal"],
        ["MCH", "29.3", "pg", "27 – 33", "Normal"],
        ["MCHC", "32.8", "g/dL", "31.5 – 36.0", "Normal"],
        ["WBC Count", "9.8", "× 10³/µL", "4.0 – 11.0", "Normal"],
        ["Neutrophils", "72", "%", "50 – 70", "High ↑"],
        ["Lymphocytes", "20", "%", "20 – 40", "Normal"],
        ["Eosinophils", "3", "%", "1 – 6", "Normal"],
        ["Platelet Count", "224", "× 10³/µL", "150 – 400", "Normal"],
    ]
    hema_table_data = hema_headers + hema_data
    hema_col_widths = [60*mm, 22*mm, 22*mm, 45*mm, 25*mm]
    hema_table = Table(hema_table_data, colWidths=hema_col_widths)
    hema_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9E1F2")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7F9FF")]),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
        ("PADDING", (0, 0), (-1, -1), 3),
        ("TEXTCOLOR", (4, 1), (4, 3), colors.red),   # flag LOW rows
        ("TEXTCOLOR", (4, 8), (4, 8), colors.HexColor("#CC6600")),  # High
    ]))
    elements.append(hema_table)
    elements.append(Spacer(1, 4*mm))

    # Section: Biochemistry
    elements.append(Paragraph("BIOCHEMISTRY", ParagraphStyle("sec2", fontSize=10,
                               fontName="Helvetica-Bold", backColor=colors.HexColor("#003366"),
                               textColor=colors.white, spaceAfter=2, spaceBefore=4)))
    elements.append(Spacer(1, 1*mm))

    bio_headers = [["Test", "Result", "Unit", "Reference Range", "Flag"]]
    bio_data = [
        ["Sodium (Na⁺)", "136", "mEq/L", "136 – 145", "Normal"],
        ["Potassium (K⁺)", "3.2", "mEq/L", "3.5 – 5.0", "LOW ↓ *CRITICAL*"],
        ["Chloride (Cl⁻)", "102", "mEq/L", "98 – 107", "Normal"],
        ["Bicarbonate (HCO₃⁻)", "22", "mEq/L", "22 – 29", "Normal"],
        ["Blood Urea Nitrogen", "28", "mg/dL", "7 – 20", "High ↑"],
        ["Creatinine", "1.4", "mg/dL", "0.7 – 1.2", "High ↑"],
        ["eGFR (CKD-EPI)", "52*", "mL/min/1.73m²", "> 60", "LOW ↓ *See note"],
        ["Glucose (Fasting)", "182", "mg/dL", "70 – 99", "High ↑"],
        ["HbA1c", "8.2", "%", "< 7.0 (DM target)", "High ↑"],
        ["ALT (SGPT)", "38", "U/L", "7 – 56", "Normal"],
        ["AST (SGOT)", "42", "U/L", "10 – 40", "High ↑"],
        ["Total Protein", "6.8", "g/dL", "6.0 – 8.3", "Normal"],
        ["Albumin", "3.6", "g/dL", "3.5 – 5.0", "Normal"],
        ["Total Bilirubin", "0.9", "mg/dL", "0.2 – 1.2", "Normal"],
    ]
    bio_table_data = bio_headers + bio_data
    bio_col_widths = [60*mm, 22*mm, 25*mm, 45*mm, 22*mm]
    bio_table = Table(bio_table_data, colWidths=bio_col_widths)
    bio_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9E1F2")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7F9FF")]),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
        ("PADDING", (0, 0), (-1, -1), 3),
        ("TEXTCOLOR", (4, 2), (4, 2), colors.red),
        ("FONTNAME", (4, 2), (4, 2), "Helvetica-Bold"),
    ]))
    elements.append(bio_table)
    elements.append(Spacer(1, 3*mm))
    elements.append(Paragraph(
        "* eGFR calculated using CKD-EPI equation. Verify creatinine value if clinically inconsistent.",
        ParagraphStyle("footnote", fontSize=7.5, textColor=colors.grey)
    ))
    elements.append(Spacer(1, 3*mm))

    # Section: Cardiac Markers
    elements.append(Paragraph("CARDIAC MARKERS", ParagraphStyle("sec3", fontSize=10,
                               fontName="Helvetica-Bold", backColor=colors.HexColor("#003366"),
                               textColor=colors.white, spaceAfter=2, spaceBefore=4)))
    elements.append(Spacer(1, 1*mm))

    cardiac_data = [
        ["Test", "Result", "Unit", "Reference Range", "Flag"],
        ["Troponin I (high-sensitivity)", "0.04", "ng/mL", "< 0.04", "Borderline ⚠"],
        ["BNP (B-type Natriuretic Peptide)", "1890", "pg/mL", "< 100", "CRITICAL ↑↑"],
        ["CK-MB", "4.2", "ng/mL", "< 5.0", "Normal"],
        ["D-Dimer", "0.62", "µg/mL FEU", "< 0.50", "High ↑"],
    ]
    cardiac_table = Table(cardiac_data, colWidths=[70*mm, 22*mm, 22*mm, 40*mm, 20*mm])
    cardiac_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9E1F2")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#FFF5F5")]),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
        ("PADDING", (0, 0), (-1, -1), 3),
        ("TEXTCOLOR", (4, 2), (4, 2), colors.red),
        ("FONTNAME", (4, 2), (4, 2), "Helvetica-Bold"),
        ("TEXTCOLOR", (4, 1), (4, 1), colors.HexColor("#CC6600")),
    ]))
    elements.append(cardiac_table)
    elements.append(Spacer(1, 5*mm))
    elements.append(HRFlowable(width="100%", thickness=1, color=colors.grey))
    elements.append(Spacer(1, 3*mm))

    footer = ParagraphStyle("footer", fontSize=7.5, textColor=colors.grey, alignment=TA_CENTER)
    elements.append(Paragraph(
        "Verified by: Dr. T. Rao, MD (Pathology) | Lab Director: Dr. S. Mehta | "
        "Results valid for 24hrs from collection. Clinical correlation advised.\n"
        "City General Hospital Laboratory | NABL Accredited | Tel: 022-28831234 Ext 3400",
        footer))

    doc.build(elements)
    print(f"  [OK] Created: {filepath.name}")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Machine-readable PDF: Discharge Summary
# ─────────────────────────────────────────────────────────────────────────────
def create_discharge_summary_pdf():
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import mm
        from reportlab.lib import colors
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, HRFlowable)
        from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
    except ImportError:
        print("  [SKIP] reportlab not installed.")
        return

    filepath = OUTPUT_DIR / "discharge_summary_CGH_0431.pdf"
    doc = SimpleDocTemplate(str(filepath), pagesize=A4,
                            leftMargin=20*mm, rightMargin=20*mm,
                            topMargin=15*mm, bottomMargin=15*mm)
    styles = getSampleStyleSheet()
    elements = []

    title = ParagraphStyle("t", fontSize=14, fontName="Helvetica-Bold", alignment=TA_CENTER)
    sub = ParagraphStyle("s", fontSize=10, alignment=TA_CENTER, spaceAfter=2)
    heading = ParagraphStyle("h", fontSize=10, fontName="Helvetica-Bold", spaceBefore=6, spaceAfter=2,
                              textColor=colors.HexColor("#003366"))
    body = ParagraphStyle("b", fontSize=9, leading=14, alignment=TA_JUSTIFY, spaceAfter=4)

    elements.append(Paragraph("CITY GENERAL HOSPITAL", title))
    elements.append(Paragraph("DISCHARGE SUMMARY", sub))
    elements.append(HRFlowable(width="100%", thickness=2, color=colors.darkblue))
    elements.append(Spacer(1, 3*mm))

    elements.append(Paragraph(
        "<b>Patient:</b> John Doe &nbsp;&nbsp; <b>MRN:</b> CGH-2024-0431 &nbsp;&nbsp; "
        "<b>DOB:</b> 14/09/1957 &nbsp;&nbsp; <b>Sex:</b> Male", body))
    elements.append(Paragraph(
        "<b>Admission:</b> 15/03/2024 &nbsp;&nbsp; <b>Discharge:</b> 20/03/2024 &nbsp;&nbsp; "
        "<b>LOS:</b> 5 days &nbsp;&nbsp; <b>Ward:</b> Cardiology 4B", body))
    elements.append(Paragraph(
        "<b>Attending:</b> Dr. Rajesh Patel, MD DM (Cardiology)", body))
    elements.append(HRFlowable(width="100%", thickness=0.5, color=colors.grey))
    elements.append(Spacer(1, 2*mm))

    sections = [
        ("PRINCIPAL DIAGNOSIS",
         "Acute Decompensated Heart Failure (ADHF) with reduced ejection fraction (HFrEF) — LVEF 35%.<br/>"
         "ICD-10: I50.9 | Secondary: Atrial Fibrillation (I48.19), Hypertension (I10), "
         "Type 2 Diabetes Mellitus (E11.9), CAD post-CABG (I25.10), CKD Stage 3 (N18.3)"),
        ("REASON FOR ADMISSION",
         "Patient presented via emergency with a 3-day history of progressive shortness of breath "
         "(worse on exertion and lying flat), bilateral leg swelling, and fatigue. "
         "Background of known hypertension, type 2 diabetes, and coronary artery disease (CABG 2019)."),
        ("SIGNIFICANT INVESTIGATIONS",
         "ECG: Atrial fibrillation with controlled ventricular rate (~88/min); LBBB pattern. "
         "ECHO (16/03/2024): LVEF 35% (severely reduced); dilated LV; moderate MR; IVC plethoric. "
         "Labs: BNP 1890 pg/mL (admission) → 890 pg/mL (discharge); K⁺ 3.2 (repleted); "
         "Creatinine 1.4 → 1.3 mg/dL; HbA1c 8.2%; Troponin I borderline (0.04 ng/mL, serial negative)."),
        ("HOSPITAL COURSE",
         "Patient admitted to cardiology ward and commenced on IV furosemide 40mg OD with close "
         "monitoring of fluid balance, electrolytes and renal function. Potassium was repleted IV "
         "overnight (K⁺ normalized by Day 2). Metformin was held on admission (AKI concern) and "
         "restarted on Day 4 (creatinine improving). Switched IV furosemide to oral Day 3. "
         "Spironolactone 25mg added for HFrEF. Sacubitril/Valsartan initiation deferred to outpatient "
         "follow-up given recent furosemide change. AF rate control maintained with metoprolol. "
         "Anticoagulation with enoxaparin initiated (CHA₂DS₂-VASc score = 5). "
         "Nutrition: patient maintained on low-sodium cardiac diet. Fluid restricted to 1.5L/day."),
        ("DISCHARGE CONDITION",
         "Stable. Ambulant. Able to climb one flight of stairs with mild dyspnea (NYHA Class II). "
         "Peripheral edema 1+ (was 3+ on admission). SpO2 97% on room air."),
        ("DISCHARGE MEDICATIONS",
         "1. Furosemide 40mg PO twice daily (BD)<br/>"
         "2. Metoprolol Succinate 50mg PO once daily (OD)<br/>"
         "3. Telmisartan 40mg PO OD (Lisinopril switched — dry cough side effect)<br/>"
         "4. Spironolactone 25mg PO OD<br/>"
         "5. Metformin 1000mg PO BD (with meals)<br/>"
         "6. Aspirin 81mg PO OD<br/>"
         "7. Rivaroxaban 20mg PO OD (with evening meal) — anticoagulation for AF<br/>"
         "<b>ALLERGY:</b> Penicillin (rash) — documented."),
        ("FOLLOW-UP PLAN",
         "1. Cardiology OPD — 2 weeks (Dr. Patel, ext. 2201). Bring weight diary.<br/>"
         "2. Repeat BMP (Na, K, Cr, BUN) and BNP — 1 week post-discharge.<br/>"
         "3. Diabetes review — HbA1c 8.2%; Endocrinology OPD — 4 weeks.<br/>"
         "4. Cardiac Rehabilitation — enrolled, starts 01/04/2024.<br/>"
         "5. Repeat ECHO — 3 months (assess response to HFrEF therapy).<br/>"
         "6. URGENT: Return to ED if — weight gain >2kg in one day, severe SOB, chest pain, syncope."),
        ("PATIENT EDUCATION",
         "Patient and spouse educated on: daily weight monitoring, fluid and sodium restriction "
         "(2g sodium/day), medication compliance, when to seek emergency care. Written instructions provided. "
         "Patient verbalized understanding. Discharge checklist signed."),
    ]

    for title_text, content in sections:
        elements.append(Paragraph(title_text, heading))
        elements.append(Paragraph(content, body))

    elements.append(Spacer(1, 4*mm))
    elements.append(HRFlowable(width="100%", thickness=1, color=colors.grey))
    elements.append(Spacer(1, 2*mm))
    elements.append(Paragraph(
        "<b>Electronically signed by:</b> Dr. Rajesh Patel | 20/03/2024 12:15 IST | "
        "City General Hospital, Mumbai | Tel: 022-28831234",
        ParagraphStyle("sig", fontSize=8, textColor=colors.grey)
    ))

    doc.build(elements)
    print(f"  [OK] Created: {filepath.name}")


# ─────────────────────────────────────────────────────────────────────────────
# 3. Scanned Prescription Image (for OCR demos)
# ─────────────────────────────────────────────────────────────────────────────
def create_scanned_prescription_image():
    try:
        from PIL import Image, ImageDraw, ImageFont, ImageFilter
        import random
    except ImportError:
        print("  [SKIP] Pillow not installed. Run: pip install Pillow")
        return

    filepath = OUTPUT_DIR / "scanned_prescription.png"

    # Create a white background slightly larger than A5
    width, height = 794, 1123  # A4 at 94dpi approx
    img = Image.new("RGB", (width, height), color=(252, 250, 245))  # slightly off-white (paper)
    draw = ImageDraw.Draw(img)

    # Try to use a monospace font, fall back to default
    try:
        font_lg = ImageFont.truetype("cour.ttf", 22)     # Courier on Windows
        font_md = ImageFont.truetype("cour.ttf", 18)
        font_sm = ImageFont.truetype("cour.ttf", 15)
        font_bold = ImageFont.truetype("courbd.ttf", 20)
    except Exception:
        font_lg = font_md = font_sm = font_bold = ImageFont.load_default()

    def text(draw, pos, txt, font=None, color=(20, 20, 20)):
        draw.text(pos, txt, fill=color, font=font or font_md)

    # Header box
    draw.rectangle([30, 30, width - 30, 130], outline=(30, 60, 120), width=2)
    text(draw, (width // 2 - 180, 40), "CITY GENERAL HOSPITAL", font=font_bold, color=(20, 40, 100))
    text(draw, (width // 2 - 200, 68), "Out-Patient Department — Prescription", font=font_md)
    text(draw, (width // 2 - 160, 93), "Tel: 022-28831234  |  Mumbai 400001", font=font_sm)

    # Patient info
    y = 150
    draw.line([(30, y), (width - 30, y)], fill=(150, 150, 150), width=1)
    y += 10
    text(draw, (40, y),  "Name  : Mr. John Doe", font=font_md)
    text(draw, (430, y), "Date : 20/03/2024", font=font_md)
    y += 30
    text(draw, (40, y),  "Age/Sex: 66 Yrs / Male", font=font_md)
    text(draw, (430, y), "MRN : CGH-2024-0431", font=font_md)
    y += 30
    text(draw, (40, y),  "Wt : 74 kg    BP: 135/82 mmHg", font=font_md)
    text(draw, (430, y), "Dr : Dr. R. Patel", font=font_md)
    y += 20
    draw.line([(30, y), (width - 30, y)], fill=(150, 150, 150), width=1)

    # Rx symbol
    y += 25
    text(draw, (40, y), "Rx", font=font_lg, color=(20, 40, 100))
    y += 40

    # Medications - slightly hand-written style (with intentional imperfections)
    meds = [
        ("1.", "Tab. Furosemide  40 mg",      "1-0-1  (BD) x 30 days"),
        ("2.", "Tab. Metopr0lol  50 mg",       "1-0-0  (OD) x 30 days"),   # intentional typo: 0 instead of o
        ("3.", "Tab. Telmisartan 40 mg",       "0-0-1  (OD) x 30 days"),
        ("4.", "Tab. Spironolactone 25 mg",    "1-0-0  (OD) x 30 days"),
        ("5.", "Tab. Metformin  1000 mg",      "1-0-1 with meals x 30days"),
        ("6.", "Tab. Aspirin  81 mg",          "0-1-0 after lunch x 30d"),
        ("7.", "Tab. Rivaroxaban  20 mg",      "0-0-1 with dinner x 30 days"),
    ]

    for num, med, sig in meds:
        text(draw, (60, y),   num, font=font_md)
        text(draw, (90, y),   med, font=font_md)
        text(draw, (430, y),  sig, font=font_sm, color=(60, 60, 60))
        y += 38

    y += 10
    draw.line([(30, y), (width - 30, y)], fill=(150, 150, 150), width=1)
    y += 15

    # Notes
    notes = [
        "ALLERGY: Penicillin (Rash) — NO PENICILLIN",
        "Daily weight monitoring. Target: gain < 2kg/day",
        "Low sodium diet (< 2g/day). Fluid: 1.5L/day",
        "URGENT: Go to ED if severe breathlessness or chest pain",
        "Follow-up: Cardiology OPD — 2 weeks (03/04/2024)",
    ]
    for note in notes:
        text(draw, (40, y), "* " + note, font=font_sm, color=(80, 40, 40))
        y += 26

    y += 20
    # Signature box
    draw.rectangle([width - 240, y, width - 40, y + 70], outline=(100, 100, 100), width=1)
    text(draw, (width - 230, y + 8),  "Dr. R. Patel", font=font_md)
    text(draw, (width - 230, y + 30), "MD, DM Cardiology", font=font_sm)
    text(draw, (width - 230, y + 50), "Reg No: MCI-2004-4421", font=font_sm)

    # Add noise/scan artifacts to simulate a scanned document
    random.seed(42)
    pixels = img.load()
    for _ in range(2000):
        x = random.randint(0, width - 1)
        yr = random.randint(0, height - 1)
        noise = random.randint(-15, 15)
        r, g, b = pixels[x, yr]
        pixels[x, yr] = (
            max(0, min(255, r + noise)),
            max(0, min(255, g + noise)),
            max(0, min(255, b + noise))
        )

    # Slight blur to simulate scanner softness
    img = img.filter(ImageFilter.GaussianBlur(radius=0.4))

    # Add a subtle skew effect (simulate imperfect scanning)
    img = img.rotate(0.8, fillcolor=(252, 250, 245), expand=False)

    img.save(str(filepath), dpi=(150, 150))
    print(f"  [OK] Created: {filepath.name}")


# ─────────────────────────────────────────────────────────────────────────────
# 4. Handwritten-style prescription image (for harder OCR challenge)
# ─────────────────────────────────────────────────────────────────────────────
def create_handwritten_style_image():
    try:
        from PIL import Image, ImageDraw, ImageFont, ImageFilter
        import random
    except ImportError:
        print("  [SKIP] Pillow not installed.")
        return

    filepath = OUTPUT_DIR / "handwritten_prescription.png"
    width, height = 700, 500
    img = Image.new("RGB", (width, height), color=(248, 244, 232))  # aged paper
    draw = ImageDraw.Draw(img)

    try:
        font = ImageFont.truetype("couri.ttf", 20)   # Courier Italic ~ handwriting
        font_sm = ImageFont.truetype("couri.ttf", 16)
    except Exception:
        font = font_sm = ImageFont.load_default()

    lines = [
        ("Dr. S. Mehta | Date: 22/03/24",                  (40, 30)),
        ("Pt: Mrs. Sunita Mehta  Age: 38F",                 (40, 65)),
        ("",                                                 (40, 95)),
        ("Rx",                                               (40, 95)),
        ("1) Tab Sertraline 50mg - 1 OD morning x 14 days", (70, 130)),
        ("   (increase to 100mg after 2 wks if ok)",        (70, 158)),
        ("2) Tab Clonazepam 0.5mg - SOS (max 1/day)",       (70, 190)),
        ("   (for sleep only, do NOT take daily)",           (70, 218)),
        ("",                                                 (40, 248)),
        ("CBT referral given.",                              (40, 248)),
        ("Repeat TFT in 6 wks.",                            (40, 278)),
        ("F/U: 4 weeks",                                     (40, 308)),
        ("Helpline if needed: 9152987821",                   (40, 338)),
        ("",                                                 (40, 370)),
        ("Sig: _________  Stamp",                            (40, 385)),
    ]

    for txt, pos in lines:
        if txt:
            draw.text(pos, txt, fill=(30, 20, 60), font=font if len(txt) > 5 else font_sm)

    # Add ink bleed / noise
    random.seed(7)
    pixels = img.load()
    for _ in range(1500):
        x = random.randint(0, width - 1)
        y = random.randint(0, height - 1)
        noise = random.randint(-25, 10)
        r, g, b = pixels[x, y]
        pixels[x, y] = (max(0, min(255, r + noise)),
                        max(0, min(255, g + noise)),
                        max(0, min(255, b + noise)))

    img = img.filter(ImageFilter.GaussianBlur(radius=0.6))
    img = img.rotate(-1.2, fillcolor=(248, 244, 232))
    img.save(str(filepath), dpi=(120, 120))
    print(f"  [OK] Created: {filepath.name}")


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Generating synthetic data files...")
    print(f"Output directory: {OUTPUT_DIR.resolve()}\n")

    print("1. Machine-readable PDF: Lab Report")
    create_lab_report_pdf()

    print("2. Machine-readable PDF: Discharge Summary")
    create_discharge_summary_pdf()

    print("3. Scanned Prescription Image (for OCR)")
    create_scanned_prescription_image()

    print("4. Handwritten-style Prescription Image (harder OCR)")
    create_handwritten_style_image()

    print("\nDone! Files created in data/ folder.")
    print("Now run the demo scripts: 01_... 02_... 03_... 04_...")
