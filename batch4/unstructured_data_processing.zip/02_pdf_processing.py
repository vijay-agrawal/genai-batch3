# -*- coding: utf-8 -*-
import sys, io
if hasattr(sys.stdout, 'buffer'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

"""
02_pdf_processing.py
====================
Demo: Unstructured Data Processing in Healthcare
Topic: Machine-Readable PDFs (Lab Reports, Discharge Summaries)

PREREQUISITES:
  1. Run data/generate_synthetic_pdfs.py first to create the PDF files.
  2. pip install pypdf pdfplumber pdfminer.six pandas

DATA CHALLENGES HIGHLIGHTED:
  - Text extraction differences across PDF libraries
  - Multi-column layout breaking logical reading order
  - Tables embedded in PDFs (without explicit table structure)
  - Headers/footers as noise
  - Inconsistent spacing and line breaks post-extraction
  - Lab values with units that get separated during extraction
  - Handling footnotes and cross-references
"""

import re
import json
from pathlib import Path
from collections import defaultdict

DATA_DIR = Path(__file__).parent / "data"
SEPARATOR = "\n" + "=" * 80 + "\n"
SEP_MINOR = "\n" + "-" * 60 + "\n"


def check_dependencies():
    available = {}
    for lib, import_name in [("pypdf", "pypdf"), ("pdfplumber", "pdfplumber"),
                               ("pandas", "pandas")]:
        try:
            __import__(import_name)
            available[lib] = True
        except ImportError:
            available[lib] = False
            print(f"[WARN] {lib} not installed. Install: pip install {lib}")
    return available


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1: Basic PDF Extraction with PyPDF
# ─────────────────────────────────────────────────────────────────────────────

def extract_with_pypdf(filepath: Path) -> str:
    """
    PyPDF (formerly PyPDF2) — lightweight, built-in Python.
    Good for simple text extraction; struggles with complex layouts.
    """
    import pypdf
    reader = pypdf.PdfReader(str(filepath))
    full_text = ""
    for i, page in enumerate(reader.pages):
        page_text = page.extract_text() or ""
        full_text += f"\n--- PAGE {i+1} ---\n{page_text}"
    return full_text


def extract_with_pdfplumber(filepath: Path) -> tuple[str, list]:
    """
    pdfplumber — better layout-aware extraction.
    Handles bounding boxes, character positioning.
    Returns (full_text, tables_as_list_of_rows).
    """
    import pdfplumber
    full_text = ""
    all_tables = []

    with pdfplumber.open(str(filepath)) as pdf:
        for i, page in enumerate(pdf.pages):
            # Extract text preserving layout (x_tolerance helps with spacing)
            page_text = page.extract_text(x_tolerance=2, y_tolerance=3) or ""
            full_text += f"\n--- PAGE {i+1} ---\n{page_text}"

            # Extract tables separately
            tables = page.extract_tables()
            for table in tables:
                if table:
                    all_tables.append({
                        "page": i + 1,
                        "rows": table,
                        "num_rows": len(table),
                        "num_cols": max(len(r) for r in table if r),
                    })

    return full_text, all_tables


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2: Post-Extraction Cleaning
# ─────────────────────────────────────────────────────────────────────────────

def clean_extracted_text(text: str) -> str:
    """
    CHALLENGE: Raw PDF extraction often produces:
      - Multiple spaces from column alignment
      - Line breaks mid-sentence (due to column wrapping)
      - Header/footer repeated on every page
      - Page numbers embedded in text
    """
    # Remove repeated headers/footers (detected by repetition)
    text = re.sub(r'--- PAGE \d+ ---', '', text)

    # Collapse multiple spaces (from PDF column spacing)
    text = re.sub(r' {3,}', '  ', text)  # keep 2 spaces as column separator

    # Fix broken lines — if line ends mid-sentence (no period), join with next
    lines = text.split('\n')
    merged = []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        # If line doesn't end with sentence-ending punctuation and next line starts lowercase
        if (line and not line[-1] in '.?!:|' and
                i + 1 < len(lines) and lines[i + 1].strip() and
                lines[i + 1].strip()[0].islower()):
            merged.append(line + ' ' + lines[i + 1].strip())
            i += 2
        else:
            merged.append(line)
            i += 1
    return '\n'.join(merged)


def extract_patient_header(text: str) -> dict:
    """
    Extract structured patient info from PDF header section.
    CHALLENGE: Header layout varies by PDF generator/template.
    """
    patterns = {
        "patient_name": r'Patient Name[:\s]+([A-Z][a-z]+\s+[A-Z][a-z]+)',
        "mrn": r'MRN[:\s]+(\S+)',
        "dob": r'DOB[:\s]+([\d/]+)',
        "age_sex": r'Age\s*/\s*Sex[:\s]+([\d]+\s+Years\s*/\s*\w+)',
        "ward": r'Ward\s*/\s*Bed[:\s]+([\w\s/]+?)(?:\n|$)',
        "collection_date": r'Collection Date[:\s]+([\d/]+\s+[\d:]+)',
        "report_date": r'Report Date[:\s]+([\d/]+\s+[\d:]+)',
        "physician": r'Ref\.\s*Physician[:\s]+(Dr\.\s+[\w\s.]+?)(?:\n|$)',
    }
    info = {}
    for key, pattern in patterns.items():
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            info[key] = m.group(1).strip()
    return info


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3: Lab Value Extraction & Parsing
# ─────────────────────────────────────────────────────────────────────────────

# Lab reference range pattern
LAB_VALUE_PATTERN = re.compile(
    r'([A-Za-z][A-Za-z0-9\s\(\)⁺⁻₂³/\-]+?)'   # test name
    r'\s+([\d.]+\*?)\s+'                          # result (possibly with *)
    r'([\w/µ%°⁺⁻²³×]+(?:\s+\d+[³²])?)\s+'        # unit
    r'([\d.\s\-–<>]+(?:[a-z/µ]+)?)'              # reference range
    r'(?:\s+(.*?))?$',                             # flag (optional)
    re.MULTILINE
)

FLAG_KEYWORDS = {
    "LOW": "↓ Below normal",
    "HIGH": "↑ Above normal",
    "CRITICAL": "🔴 Critical value — immediate action",
    "BORDERLINE": "⚠ Borderline — watch closely",
    "NORMAL": "✓ Within range",
}


def parse_lab_table_rows(table_rows: list) -> list[dict]:
    """
    CHALLENGE: PDF table extraction may:
      - Merge cells incorrectly
      - Split a single value across cells
      - Include header rows mixed with data
      - Have None values for empty cells
    """
    lab_results = []
    if not table_rows:
        return lab_results

    # First row is assumed header
    headers = table_rows[0] if table_rows else []
    headers = [str(h).strip() if h else "" for h in headers]

    for row in table_rows[1:]:
        if not row or all(cell is None or str(cell).strip() == "" for cell in row):
            continue  # skip empty rows

        cells = [str(c).strip() if c is not None else "" for c in row]

        # Skip if it looks like a section header (first cell has content, others empty)
        if cells[0] and all(not c for c in cells[1:]):
            continue

        record = {}
        for i, header in enumerate(headers):
            if i < len(cells):
                record[header] = cells[i]

        # Parse numeric result
        result_str = record.get("Result", "")
        result_clean = re.sub(r'[^\d.]', '', result_str)
        try:
            record["result_numeric"] = float(result_clean) if result_clean else None
        except ValueError:
            record["result_numeric"] = None

        # Classify flag
        flag = record.get("Flag", "").upper()
        for kw in FLAG_KEYWORDS:
            if kw in flag:
                record["flag_interpretation"] = FLAG_KEYWORDS[kw]
                break
        else:
            record["flag_interpretation"] = ""

        lab_results.append(record)
    return lab_results


def identify_critical_values(lab_results: list[dict]) -> list[dict]:
    """Identify critical lab values needing immediate attention."""
    critical = []
    for r in lab_results:
        flag = r.get("Flag", "").upper()
        if "CRITICAL" in flag or "CRITICAL" in r.get("flag_interpretation", "").upper():
            critical.append(r)
    return critical


def extract_medication_list_from_pdf(text: str) -> list[dict]:
    """
    CHALLENGE: Medication lists in discharge summaries have many formats.
    Pattern: numbered item, drug name, dose, route, frequency.
    """
    meds = []
    # Match numbered medication lines like: "1. Tab. Furosemide 40mg PO twice daily"
    pattern = re.compile(
        r'(\d+)\.\s+'
        r'(?:Tab\.?|Cap\.?|Inj\.?)?\s*'
        r'([A-Z][a-zA-Z\s/]+?)\s+'
        r'(\d+(?:\.\d+)?)\s*(mg|mcg|g|mL|units?|IU)\s*'
        r'(PO|IV|SC|IM|SL|PR|topical)?\s*'
        r'(OD|BD|TID|QID|PRN|SOS|STAT|once daily|twice daily|three times daily)?',
        re.IGNORECASE
    )
    for m in pattern.finditer(text):
        meds.append({
            "item": int(m.group(1)),
            "drug": m.group(2).strip().rstrip(),
            "dose": m.group(3) + m.group(4),
            "route": m.group(5) or "PO",
            "frequency": m.group(6) or "",
        })
    return meds


def extract_icd_codes(text: str) -> list[dict]:
    """Extract ICD-10 codes and their descriptions from discharge summary."""
    results = []
    # Pattern: ICD-10: I50.9 or (I50.9)
    pattern = re.compile(r'(?:ICD-10|ICD10)[:\s]?\(?\s*([A-Z]\d{2}(?:\.\d{1,2})?)\s*\)?')
    for m in pattern.finditer(text):
        code = m.group(1)
        # Try to get surrounding text as description
        start = max(0, m.start() - 60)
        context = text[start:m.start()].strip().split('\n')[-1]
        results.append({"code": code, "context": context.strip()})
    return results


def compare_extraction_methods(filepath: Path) -> None:
    """
    CHALLENGE: Different PDF libraries extract text differently.
    Demonstrate the differences in output quality.
    """
    print(f"\n── Comparing PyPDF vs pdfplumber on: {filepath.name} ──")

    # PyPDF extraction
    try:
        pypdf_text = extract_with_pypdf(filepath)
        pypdf_chars = len(pypdf_text)
        pypdf_lines = pypdf_text.count('\n')
        print(f"\nPyPDF:      {pypdf_chars:,} chars, {pypdf_lines} lines")
        print(f"  First 200 chars: {pypdf_text.replace(chr(10), ' ')[:200]}...")
    except Exception as e:
        print(f"  PyPDF failed: {e}")
        pypdf_text = ""

    # pdfplumber extraction
    try:
        plumber_text, plumber_tables = extract_with_pdfplumber(filepath)
        plumber_chars = len(plumber_text)
        plumber_lines = plumber_text.count('\n')
        print(f"\npdfplumber: {plumber_chars:,} chars, {plumber_lines} lines, "
              f"{len(plumber_tables)} table(s) found")
        print(f"  First 200 chars: {plumber_text.replace(chr(10), ' ')[:200]}...")
    except Exception as e:
        print(f"  pdfplumber failed: {e}")
        plumber_text = ""
        plumber_tables = []

    # Quality comparison
    if pypdf_text and plumber_text:
        diff = abs(len(plumber_text) - len(pypdf_text))
        pct = diff / max(len(pypdf_text), 1) * 100
        print(f"\n[CHALLENGE: FORMAT VARIATION] Extraction difference: {diff:,} chars ({pct:.1f}%)")
        print("  pdfplumber typically preserves layout better than pypdf for complex PDFs.")

    return plumber_text, plumber_tables


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4: Multi-Page PDF — Discharge Summary
# ─────────────────────────────────────────────────────────────────────────────

def run_discharge_summary_demo():
    print(SEPARATOR)
    print("SECTION: Discharge Summary PDF — Structured Data Extraction")
    print(SEPARATOR)

    filepath = DATA_DIR / "discharge_summary_CGH_0431.pdf"
    if not filepath.exists():
        print(f"[ERROR] PDF not found: {filepath}")
        print("  → Run: python data/generate_synthetic_pdfs.py")
        return

    try:
        text, tables = extract_with_pdfplumber(filepath)
    except ImportError:
        print("[SKIP] pdfplumber not installed.")
        return

    cleaned = clean_extracted_text(text)
    print(f"Extracted {len(cleaned):,} characters from discharge summary\n")

    # Patient header
    print("── Patient Information ──")
    patient_info = extract_patient_header(cleaned)
    if patient_info:
        for k, v in patient_info.items():
            print(f"  {k:20s}: {v}")
    else:
        # Try to extract from first few lines
        first_lines = cleaned.strip().split('\n')[:8]
        print("  (Pattern match limited — raw header lines:)")
        for l in first_lines:
            if l.strip():
                print(f"  {l.strip()}")
    print()

    # Extract diagnoses section
    print("── Diagnoses & ICD Codes ──")
    icd_codes = extract_icd_codes(cleaned)
    if icd_codes:
        for code_entry in icd_codes:
            print(f"  {code_entry['code']} — {code_entry['context'][:70]}")
    else:
        # Fallback: search for diagnosis section
        diag_match = re.search(r'PRINCIPAL DIAGNOSIS\s*\n([^─]{50,300})', cleaned, re.DOTALL)
        if diag_match:
            print(f"  {diag_match.group(1).strip()[:200]}")
    print()

    # Extract medications
    print("── Discharge Medications ──")
    meds = extract_medication_list_from_pdf(cleaned)
    if meds:
        for med in meds:
            print(f"  {med['item']}. {med['drug']:30s} {med['dose']:8s} {med['route']:4s} {med['frequency']}")
    else:
        # Show raw medication section
        med_match = re.search(r'DISCHARGE MEDICATIONS?\s*\n((?:.*\n){3,10})', cleaned)
        if med_match:
            print(med_match.group(1))
    print()

    # Follow-up plan
    print("── Follow-Up Plan ──")
    followup_match = re.search(r'FOLLOW[\-\s]?UP PLAN\s*\n((?:.*\n){2,8})', cleaned, re.IGNORECASE)
    if followup_match:
        print(followup_match.group(1).strip())
    print()


# ─────────────────────────────────────────────────────────────────────────────
# MAIN DEMO RUNNER
# ─────────────────────────────────────────────────────────────────────────────

def run_lab_report_demo():
    print(SEPARATOR)
    print("SECTION: Lab Report PDF — Multi-Library Extraction & Table Parsing")
    print(SEPARATOR)

    filepath = DATA_DIR / "lab_report_CGH_0431.pdf"
    if not filepath.exists():
        print(f"[ERROR] PDF not found: {filepath}")
        print("  → Run: python data/generate_synthetic_pdfs.py")
        return

    # 1. Compare extraction methods
    try:
        plumber_text, plumber_tables = compare_extraction_methods(filepath)
    except Exception as e:
        print(f"[ERROR] Extraction failed: {e}")
        return

    print(SEP_MINOR)
    print("── Cleaning extracted text ──")
    cleaned = clean_extracted_text(plumber_text)

    # CHALLENGE: Show specific extraction artifacts
    print("[CHALLENGE: NOISE] Sample raw vs cleaned (first 200 chars of each):")
    print(f"  RAW:     {plumber_text[:200].replace(chr(10), '↵')}")
    print(f"  CLEANED: {cleaned[:200].replace(chr(10), '↵')}")
    print()

    # 2. Patient header
    print("── Patient Information from PDF Header ──")
    patient_info = extract_patient_header(cleaned)
    for k, v in patient_info.items():
        print(f"  {k:20s}: {v}")
    print()

    # 3. Table extraction
    print(f"── Lab Tables Extracted by pdfplumber: {len(plumber_tables)} table(s) ──")
    all_lab_results = []
    for t_info in plumber_tables:
        print(f"\n  Table on page {t_info['page']}: "
              f"{t_info['num_rows']} rows × {t_info['num_cols']} cols")

        lab_results = parse_lab_table_rows(t_info["rows"])
        if lab_results:
            all_lab_results.extend(lab_results)
            # Show first 5 results
            for r in lab_results[:5]:
                test = r.get("Test", "")
                result = r.get("Result", "")
                unit = r.get("Unit", "")
                ref = r.get("Reference Range", "")
                flag = r.get("Flag", "")
                flag_icon = "🔴" if "CRITICAL" in flag.upper() else \
                            "⚠" if "HIGH" in flag.upper() or "LOW" in flag.upper() else "✓"
                print(f"    {flag_icon} {test:40s} {result:8s} {unit:15s} ref: {ref}")
            if len(lab_results) > 5:
                print(f"    ... and {len(lab_results) - 5} more results")

    # 4. Critical values
    print(SEP_MINOR)
    print("── Critical Values Summary ──")
    critical = identify_critical_values(all_lab_results)
    if critical:
        print(f"[CLINICAL ALERT] {len(critical)} critical value(s) found:")
        for c in critical:
            print(f"  🔴 {c.get('Test', ''):35s} = {c.get('Result', ''):8s} {c.get('Unit', '')}")
            print(f"     Reference: {c.get('Reference Range', '')} | Flag: {c.get('Flag', '')}")
    else:
        print("  No critical values flagged in extracted tables.")
        print("  [NOTE] pdfplumber table detection may miss tables in some PDF layouts")
        print("  → Fallback: use regex on cleaned text to extract lab values")
        # Regex fallback
        print("\n── Regex-based lab value extraction (fallback) ──")
        lines = cleaned.split('\n')
        for line in lines:
            # Look for lines with pattern: text + number + unit + range
            m = re.search(r'([A-Za-z][\w\s\(\)⁺]+?)\s+([\d.]+\*?)\s+([\w/µ%]+)\s+([\d.\s\-–<>]+)\s+(.*)', line)
            if m and len(m.group(1).strip()) > 3:
                flag_text = m.group(5).strip()
                if any(kw in flag_text.upper() for kw in ["LOW", "HIGH", "CRIT"]):
                    print(f"  ⚠ {m.group(1).strip():35s} = {m.group(2):8s} {m.group(3):12s} | {flag_text}")

    # 5. Demonstrate unit normalization
    print(SEP_MINOR)
    print("── Unit Normalization ──")
    print("[CHALLENGE: FORMAT VARIATION] Lab reports use varying unit notations:")
    unit_variations = {
        "Hemoglobin": ["g/dL", "g/dl", "gm%", "g/100mL", "gram/deciliter"],
        "WBC Count": ["× 10³/µL", "× 10^3/uL", "K/µL", "10^9/L", "cells/mm³"],
        "Glucose": ["mg/dL", "mg/dl", "mmol/L", "mg%"],
        "Creatinine": ["mg/dL", "µmol/L", "μmol/L"],
    }
    for test, units in unit_variations.items():
        print(f"  {test}: {' | '.join(units)}")
    print("\n  Approach: map all variations to a canonical unit (e.g., SI units)")
    print("  Glucose: mg/dL × 0.0555 = mmol/L | Creatinine: mg/dL × 88.4 = µmol/L")


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("  HEALTHCARE UNSTRUCTURED DATA PROCESSING — DEMO 2")
    print("  Topic: Machine-Readable PDFs")
    print("=" * 80)

    deps = check_dependencies()
    if not deps.get("pypdf") and not deps.get("pdfplumber"):
        print("\n[ERROR] No PDF library available. Install: pip install pypdf pdfplumber")
    else:
        run_lab_report_demo()
        run_discharge_summary_demo()

    print(SEPARATOR)
    print("SUMMARY OF DATA CHALLENGES IN PDF PROCESSING:")
    print(SEPARATOR)
    challenges = {
        "LIBRARY DIFFERENCES":
            "PyPDF vs pdfplumber produce different outputs for the same file",
        "TABLE EXTRACTION":
            "PDF tables have no explicit structure — inferred from bounding boxes",
        "READING ORDER":
            "Multi-column PDFs may merge columns incorrectly during extraction",
        "BROKEN LINES":
            "Sentence fragments from column wrapping need to be re-joined",
        "UNITS SEPARATION":
            "Lab value, unit, and reference range may be split across 'cells'",
        "HEADER/FOOTER NOISE":
            "Page numbers, watermarks, document titles repeat and pollute text",
        "ENCODING":
            "Special characters (µ, ⁺, ²) may garble or disappear in extraction",
        "SCANNED vs DIGITAL":
            "Machine-readable PDFs ≠ scanned image PDFs — OCR needed for latter",
    }
    for k, v in challenges.items():
        print(f"  [{k}] {v}")
    print()
