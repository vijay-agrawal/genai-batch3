// Run them on Neo4j Browser Query Console against the patient demo database.
// https://console.neo4j.io/
// These can be run on any Neo4j instance with the patient demo dataset loaded.
// Load the dataset first by running kg/01create_patientdb.cypher
// ======================================================


// 1. Patient “clinical snapshot”
//“Give me everything relevant about patient with id P_002 before I see them.”
:param pid => 'P_002'
MATCH (p:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e:Encounter)
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
OPTIONAL MATCH (e)-[pr:PRESCRIBED]->(m:Medication)
OPTIONAL MATCH (n:ClinicalNote)-[:ABOUT_ENCOUNTER]->(e)
WITH p, e,
     collect(DISTINCT {icd10:d.icd10, name:d.name}) AS dx,
     collect(DISTINCT {rxnorm:m.rxnorm, name:m.name, dose:pr.dose, frequency:pr.frequency}) AS meds,
     collect(DISTINCT {note_id:n.note_id, text:substring(n.text,0,180)}) AS notes
ORDER BY e.date DESC
WITH p, collect({
  enc_id:e.enc_id, date:e.date, reason:e.reason,
  bp_systolic:e.bp_systolic, bp_diastolic:e.bp_diastolic, hba1c:e.hba1c,
  diagnoses:dx, medications:meds, notes:notes
}) AS encounters
RETURN {
  patient: {patient_id:p.patient_id, name:p.name, dob:p.dob, sex:p.sex},
  encounters: encounters
} AS patient_snapshot;


//2. “Newly hypertensive” patients in last 90 days (first-ever I10)
//Real-life question: “Which patients were newly diagnosed with hypertension recently?”
//Needs first occurrence detection, not string matching
//Requires historical reasoning across encounters
MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)-[:HAS_DIAGNOSIS]->(d:Diagnosis {icd10:'I10'})
WHERE e.date >= date() - duration('P90D')
WITH p, min(e.date) AS first_i10_date
// Ensure no prior HTN diagnosis before that date
OPTIONAL MATCH (p)-[:HAD_ENCOUNTER]->(e2:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:'I10'})
WHERE e2.date < first_i10_date
WITH p, first_i10_date, count(e2) AS prior_count
WHERE prior_count = 0
RETURN p.patient_id, p.name, first_i10_date
ORDER BY first_i10_date DESC;

// 3. Patients with uncontrolled hypertension (BP >140/90) in last 30 days
//Use: clinical quality monitoring
//Requires filtering on encounter properties
MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)
WHERE e.date >= date() - duration('P30D')
  AND e.bp_systolic > 140
  AND e.bp_diastolic > 90
RETURN p.patient_id, p.name, e.enc_id, e.date, e.bp_systolic, e.bp_diastolic
ORDER BY e.date DESC;

// 4. Providers prescribing Metformin (rxnorm:860975) more than 5 times in last 6 months
//Use: identify high-volume prescribers for review
//Requires relationship traversal and aggregationon relationships with properties
// Note: adjust duration as needed for your data e.g., P180D = 180 days = ~6 months
// Also ensure that the date property exists on Encounter nodesto support temporal filtering.
MATCH (pr:Provider)-[:PROVIDED_CARE]->(e:Encounter)-[:PRESCRIBED]->(m:Medication {rxnorm:'860975'})
WHERE e.date >= date() - duration('P180D')  
WITH pr, count(e) AS metformin_count
WHERE metformin_count > 5
RETURN pr.npi, pr.name, metformin_count
ORDER BY metformin_count DESC;

//5. Facility-level insight: top diagnoses by volume (last 30 days)
//Real-life question: “What conditions are driving patient volume at each facility right now?”
//Use: operational planning / demand patterns.
//Requires aggregation across relationships and temporal filtering.
//Graph helps here with Easy aggregation across encounters → facilities → diagnoses
//Time-windowed insight without joins exploding
//Supports staffing decisions, resource allocation, seasonal trend detection.
MATCH (f:Facility)<-[:AT_FACILITY]-(e:Encounter)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
WHERE e.date >= date() - duration('P30D')
WITH f, d, count(e) AS diag_count
ORDER BY diag_count DESC
RETURN f.facility_id, f.name, d.icd10, d.name, diag_count
LIMIT 10;


//6  Provider “practice pattern” — most prescribed meds and for which diagnoses
//“How are we treating hypertension or diabetes?”
//Why graph helps:
//Traverses Provider → Encounter → Diagnosis → Medication
//Exposes practice variation, not just counts
//Use: clinical variation / audit.  
MATCH (pr:Provider)-[:PROVIDED_CARE]->(e:Encounter)-[:HAS_DIAGNOSIS]->(d:Diagnosis)<-[:HAS_DIAGNOSIS]-(e)-[r:PRESCRIBED]->(m:Medication)
WHERE d.icd10 IN ['I10','E11']
WITH pr, d, m, count(r) AS presc_count
ORDER BY presc_count DESC 
RETURN pr.npi, pr.name, d.icd10, d.name, m.rxnorm, m.name, presc_count
LIMIT 20;

// 7. Clinical notes mentioning “Amlodipine” (rxnorm:314076) with sentiment score
//Use: pharmacovigilance, ADE detection
//Requires text relationship traversal and filtering on relationship properties
//Graph helps: direct linkage of notes to meds via MENTIONS relationship
MATCH (n:ClinicalNote)-[ment:MENTIONS]->(m:Medication {rxnorm:'314076'})
RETURN n.note_id, substring(n.text,0,200) AS note_snippet, ment.mention, ment.method, ment.score
ORDER BY ment.score DESC;

// 8. Patients with both Hypertension (I10) and Diabetes (E11)
//Use: comorbidity analysis
//Requires multi-hop relationship traversal and filtering
//Graph helps: easily find patients linked to multiple diagnoses without complex joins
//Real-life question: “Which patients have both hypertension and diabetes diagnoses?”
MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e1:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:'I10'}),
      (p)-[:HAD_ENCOUNTER]->(e2:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:'E11'})
RETURN p.patient_id, p.name
ORDER BY p.name;

// 9. Possible data quality issue: “medication without diagnosis” encounters
//Use: detect incomplete coding or ingestion gaps.
//Requires filtering encounters based on absence of certain relationships
//Graph helps: easily find nodes missing expected links
//Real-life question: “Which encounters have prescribed medications but no associated diagnoses?”
MATCH (e:Encounter)-[:PRESCRIBED]->(:Medication)
WHERE NOT (e)-[:HAS_DIAGNOSIS]->(:Diagnosis)
RETURN e.enc_id, e.date, e.reason
ORDER BY e.date DESC
LIMIT 50;

// 10. Count of encounters per patient in last year
//Use: patient engagement metrics
//Requires aggregation across relationships with temporal filtering
//Graph helps: straightforward traversal from Patient to Encounter
MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)
WHERE e.date >= date() - duration('P365D')
WITH p, count(e) AS encounter_count
RETURN p.patient_id, p.name, encounter_count
ORDER BY encounter_count DESC;

//11. Path traversal: Find patient care pathway of length 3–5 hops
//Use: explainability: “why did the model link this med to this patient?”
//Graph helps: flexible path length traversal to explore connections
//Real-life question: “Show me the care pathway for patient P_002 up to 5 steps away.”
// Params: $pid
Parameters {
  pid: 'P_002'
};
MATCH (p:Patient {patient_id:$pid})
MATCH path = (p)-[:HAD_ENCOUNTER]->(:Encounter)-[:HAS_DIAGNOSIS|PRESCRIBED|AT_FACILITY|ABOUT_ENCOUNTER*3..5]->(x)
RETURN path
LIMIT 25;
//Practical: use in Neo4j Browser to visually inspect pathways.

//12. Complex: Patients similar to P001 by shared diagnosis + medication (Jaccard)
//Use: case-based similarity without GDS.Clinical decision support systems, Care management teams
//Risk stratification workflows
//Real-life question: “Which patients have similar clinical profiles to patient P_002?”
//Requires set operations across multiple relationship types
//Graph helps: easily aggregate and compare sets of related nodes
// Params: $pid 
Parameters {
  pid: 'P_002'
};
MATCH (p0:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e0:Encounter)
OPTIONAL MATCH (e0)-[:HAS_DIAGNOSIS]->(d0:Diagnosis)
OPTIONAL MATCH (e0)-[:PRESCRIBED]->(m0:Medication)
WITH p0,
     collect(DISTINCT d0.icd10) AS p0_dx,
     collect(DISTINCT m0.rxnorm) AS p0_meds

MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)
WHERE p <> p0
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
OPTIONAL MATCH (e)-[:PRESCRIBED]->(m:Medication)
WITH p0, p0_dx, p0_meds, p,
     collect(DISTINCT d.icd10) AS dx,
     collect(DISTINCT m.rxnorm) AS meds

WITH p, p0_dx, p0_meds, dx, meds,
     apoc.coll.toSet(p0_dx + p0_meds) AS A,
     apoc.coll.toSet(dx + meds) AS B
WITH p, A, B,
     size(apoc.coll.intersection(A,B)) AS inter,
     size(apoc.coll.toSet(A + B)) AS uni
WHERE uni > 0
RETURN p.patient_id, p.name, (1.0*inter/uni) AS jaccard_similarity,
       apoc.coll.intersection(A,B) AS shared_codes
ORDER BY jaccard_similarity DESC
LIMIT 10;

//13. Update: Add a new encounter + diagnosis + prescription (real ingest)
//Use: realistic “write path” pattern.
// “A new visit just happened — how do we record it correctly?”
// Params: $pid, $enc_id, $date, $reason, $icd10, $rxnorm, $dose, $freq
Parameters {
  pid: 'P_002',
  enc_id: 'ENC_104',
  date: '2026-01-15',
  reason: 'Routine check-up',
  icd10: 'I10',
  dx_name: 'Essential (primary) hypertension',
  rxnorm: '314076',
  med_name: 'Amlodipine',
  dose: '10mg',
  freq: 'OD'
};

MATCH (p:Patient {patient_id:$pid})
MERGE (e:Encounter {enc_id:$enc_id})
ON CREATE SET e.date = date($date), e.reason = $reason
MERGE (p)-[:HAD_ENCOUNTER]->(e)

MERGE (d:Diagnosis {icd10:$icd10})
ON CREATE SET d.name = coalesce($dx_name, 'UNKNOWN')
MERGE (e)-[:HAS_DIAGNOSIS]->(d)

MERGE (m:Medication {rxnorm:$rxnorm})
ON CREATE SET m.name = coalesce($med_name, 'UNKNOWN')
MERGE (e)-[r:PRESCRIBED]->(m)
SET r.dose = $dose, r.frequency = $freq

RETURN p.patient_id, e.enc_id, d.icd10, m.rxnorm;

//14. Delete: Remove a clinical note by note_id
//Use: realistic “delete path” pattern.
Parameters {
  note_id: 'N_902'
};
MATCH (n:ClinicalNote {note_id:$note_id})
DETACH DELETE n
RETURN 'Deleted note ' + $note_id AS result;

// 15. Aggregate: Count of diagnoses across all patients
// Use: population health analytics.
// Real-life question: “What are the most common diagnoses in our patient population?”
//Requires aggregation across relationships.
//Graph helps: easily traverse from Diagnosis to Patients and aggregate counts.
MATCH (d:Diagnosis)<-[:HAS_DIAGNOSIS]-(e:Encounter)<-[:HAD_ENCOUNTER]-(p:Patient)
WITH d, count(DISTINCT p) AS patient_count
RETURN d.icd10, d.name, patient_count
ORDER BY patient_count DESC
LIMIT 20;


//16. Update: Add a new encounter + diagnosis + prescription (real ingest)
//Use: realistic “write path” pattern
// Params: $pid, $enc_id, $date, $reason, $icd10, $rxnorm, $dose, $freq
Parameters {
  pid: 'P_002',
  enc_id: 'ENC_104',
  date: '2026-01-15',
  reason: 'Routine check-up',
  icd10: 'I10',
  dx_name: 'Essential (primary) hypertension',
  rxnorm: '314076',
  med_name: 'Amlodipine',
  dose: '10mg',
  freq: 'OD'
};

MATCH (p:Patient {patient_id:$pid})
MERGE (e:Encounter {enc_id:$enc_id})
ON CREATE SET e.date = date($date), e.reason = $reason
MERGE (p)-[:HAD_ENCOUNTER]->(e)

MERGE (d:Diagnosis {icd10:$icd10})
ON CREATE SET d.name = coalesce($dx_name, 'UNKNOWN')
MERGE (e)-[:HAS_DIAGNOSIS]->(d)

MERGE (m:Medication {rxnorm:$rxnorm})
ON CREATE SET m.name = coalesce($med_name, 'UNKNOWN')
MERGE (e)-[r:PRESCRIBED]->(m)
SET r.dose = $dose, r.frequency = $freq

RETURN p.patient_id, e.enc_id, d.icd10, m.rxnorm;


//17. Update: Fix common duplicate concept nodes (hypertension variants)
//Use: real-life cleanup after messy ingestion.

// Example: merge duplicate Diagnosis nodes by normalizing to ICD10='I10'
//Requires Awesome Procedures on Cypher (APOC). This is a very common cleanup step in KG projects.
//APOC is installed as a plugin on your Neo4j server and can be called directly in Cypher queries. 
//You can check if it's available by running 
//CALL apoc.version() or 
//CALL dbms.functions() YIELD name WHERE name STARTS WITH 'apoc' to list available procedures.
MATCH (d:Diagnosis)
WHERE toLower(d.name) IN ['hypertension', 'high blood pressure', 'htn']
WITH collect(d) AS ds
CALL apoc.refactor.mergeNodes(ds, {properties:'discard', mergeRels:true}) YIELD node
SET node.icd10 = 'I10', node.name = 'Essential (primary) hypertension'
RETURN node;


//18. Evidence verification query: “Is HTN present for P002?” (diagnosis vs mention)
//Use: exactly the kind of “grounded” query GraphRAG must do.
//param: $pid
//This explicitly separates:
//confirmed diagnosis (Encounter → HAS_DIAGNOSIS)

Parameters {pid: 'P_002'};
// Separates confirmed diagnosis (Encounter → HAS_DIAGNOSIS) from text mention (Note → MENTIONS)
MATCH (p:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e:Encounter)
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(dx:Diagnosis {icd10:'I10'})
OPTIONAL MATCH (n:ClinicalNote)-[:ABOUT_ENCOUNTER]->(e)
OPTIONAL MATCH (n)-[mn:MENTIONS]->(dxm:Diagnosis {icd10:'I10'})
WITH p,
     collect(DISTINCT {enc_id:e.enc_id, date:e.date, confirmed: dx IS NOT NULL}) AS enc_dx,
     collect(DISTINCT {note_id:n.note_id, mention:mn.mention, method:mn.method, score:mn.score}) AS note_mentions
RETURN {
  patient_id: p.patient_id,
  confirmed_diagnosis_by_encounter: enc_dx,
  note_mentions_of_I10: [x IN note_mentions WHERE x.note_id IS NOT NULL]
} AS hypertension_evidence;

