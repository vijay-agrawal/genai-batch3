import os
import re
from pathlib import Path
from dotenv import load_dotenv
from rich import print

from langchain_openai import AzureChatOpenAI
from langchain_core.tools import tool

"""
================================================================================
PATTERN: ReWOO (Reasoning WithOut Observation)
================================================================================

WHAT IT IS:
  ReWOO is an agentic design pattern where the model first creates a complete
  execution plan, and then executes it step-by-step using intermediate variables.

  Unlike ReAct (which interleaves reasoning and acting), ReWOO separates:
    1) Planning
    2) Execution

CORE IDEA:
  The model writes a plan with symbolic references like:
    E1, E2, E3 ...

  Each step can reuse previous outputs via:
    #E1, #E2, ...

  This allows:
    - deterministic execution
    - reduced repeated reasoning
    - better control and observability

--------------------------------------------------------------------------------

FLOW OVERVIEW:

                    ┌────────────────────────────┐
                    │        USER QUERY          │
                    └────────────┬───────────────┘
                                 │
                                 ▼
                    ┌────────────────────────────┐
                    │        PLANNER LLM         │
                    │  (Creates full plan once)  │
                    └────────────┬───────────────┘
                                 │
                                 ▼
                    ┌────────────────────────────┐
                    │          PLAN              │
                    │                            │
                    │  E1: get_weather[Mumbai]   │
                    │  E2: get_pollen[Mumbai]    │
                    │  E3: LLM[#E1 + #E2 → ans]  │
                    │                            │
                    └────────────┬───────────────┘
                                 │
                                 ▼
                    ┌────────────────────────────┐
                    │        EXECUTOR LOOP       │
                    │                            │
                    │  Step E1 → run tool        │
                    │  Step E2 → run tool        │
                    │  Step E3 → run LLM         │
                    │                            │
                    └────────────┬───────────────┘
                                 │
                                 ▼
                    ┌────────────────────────────┐
                    │      VARIABLE STORE        │
                    │                            │
                    │  E1 = weather output       │
                    │  E2 = pollen output        │
                    │                            │
                    └────────────┬───────────────┘
                                 │
                                 ▼
                    ┌────────────────────────────┐
                    │       FINAL ANSWER         │
                    └────────────────────────────┘


--------------------------------------------------------------------------------

KEY COMPONENTS:

1) PLANNER
   - LLM generates a full execution plan upfront
   - Uses structured steps: E1, E2, E3...

2) EXECUTOR
   - Runs each step sequentially
   - Calls tools or LLM based on step type

3) VARIABLE MEMORY
   - Stores outputs of each step
   - Enables reuse via #E1, #E2...

4) SOLVER (Final LLM step)
   - Combines all results into final answer

--------------------------------------------------------------------------------
EXAMPLE USE CASE:
  "Should I go for a morning run in Mumbai? I have mild pollen allergy."

  The planner might create a plan like:
    E1: get_weather[Mumbai]
    E2: get_pollen_index[Mumbai]
    E3: LLM[Based on #E1 and #E2, should the user go for a run?]

  The executor runs each step, stores results, and the final LLM step produces the answer.
"""

# ── Load env ─────────────────────────────────────────────
load_dotenv(Path(__file__).parent.parent / ".env")

# ── LLM ──────────────────────────────────────────────────
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
        or os.getenv("AZURE_OPENAI_MODEL_NAME"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    temperature=0,
)

# ── Tools ────────────────────────────────────────────────
@tool
def get_weather(city: str) -> str:
    """Get current weather conditions for a city."""
    samples = {
        "mumbai": "Mumbai weather: 31°C, humid, light breeze, no rain right now.",
        "pune": "Pune weather: 29°C, dry, mild breeze.",
    }
    return samples.get(city.lower(), f"{city} weather: 30°C, moderate conditions.")

@tool
def get_pollen_index(city: str) -> str:
    """Get current pollen/allergy conditions for a city."""
    samples = {
        "mumbai": "Mumbai pollen: High tree pollen today.",
        "pune": "Pune pollen: Moderate pollen today.",
    }
    return samples.get(city.lower(), f"{city} pollen: Moderate pollen today.")

TOOLS = {
    "get_weather": get_weather,
    "get_pollen_index": get_pollen_index,
}

# ── ReWOO Planner Prompt ─────────────────────────────────
PLANNER_PROMPT = """
You are a ReWOO-style planner.

Given a user query, create:
1. A short Plan
2. A list of executable steps in this exact format:

Plan:
<short plan>

Execution:
E1: tool_name[arg]
E2: tool_name[arg]
E3: LLM[question that may reference #E1, #E2, etc.]

Rules:
- Use variable references like #E1, #E2 in later steps if needed.
- Only use these tools: get_weather, get_pollen_index
- Final step should usually be an LLM step.
- Keep it simple and minimal.
"""

# ── Solver Prompt ────────────────────────────────────────
SOLVER_PROMPT = """
You are the solver in a ReWOO workflow.

User query:
{query}

Plan:
{plan}

Resolved execution context:
{context}

Write a concise final answer to the user.
"""

def generate_plan(query: str) -> str:
    response = llm.invoke([
        ("system", PLANNER_PROMPT),
        ("user", query)
    ])
    return response.content

def parse_plan(plan_text: str):
    """
    Extract execution lines like:
    E1: get_weather[Mumbai]
    E2: get_pollen_index[Mumbai]
    E3: LLM[Based on #E1 and #E2, should the user go for a run?]
    """
    steps = []
    for line in plan_text.splitlines():
        line = line.strip()
        match = re.match(r"^(E\d+):\s*([A-Za-z_]+)\[(.*)\]$", line)
        if match:
            step_id, action, arg = match.groups()
            steps.append({
                "id": step_id,
                "action": action,
                "arg": arg.strip()
            })
    return steps

def substitute_vars(text: str, memory: dict) -> str:
    for key, value in memory.items():
        text = text.replace(f"#{key}", value)
    return text

def execute_steps(query: str, plan_text: str):
    steps = parse_plan(plan_text)
    memory = {}

    print("\n[bold cyan]ReWOO Trace[/bold cyan]\n")

    # Print plan section for demo clarity
    print("[bold yellow]Planner Output[/bold yellow]")
    print(plan_text)

    print("\n[bold green]Execution[/bold green]\n")

    for step in steps:
        step_id = step["id"]
        action = step["action"]
        raw_arg = step["arg"]
        resolved_arg = substitute_vars(raw_arg, memory)

        print(f"[{step_id}] {action}[{resolved_arg}]")

        if action in TOOLS:
            result = TOOLS[action].invoke({"city": resolved_arg})
            memory[step_id] = result
            print(f"      -> {result}\n")

        elif action == "LLM":
            response = llm.invoke([
                ("system", SOLVER_PROMPT.format(
                    query=query,
                    plan=plan_text,
                    context="\n".join([f"{k} = {v}" for k, v in memory.items()])
                )),
                ("user", resolved_arg)
            ])
            memory[step_id] = response.content
            print(f"      -> {response.content}\n")

        else:
            memory[step_id] = f"Unsupported action: {action}"
            print(f"      -> Unsupported action: {action}\n")

    return memory

def main():
    query = "Should I go for a morning run in Mumbai? I have mild pollen allergy."

    print("[bold magenta]User Query[/bold magenta]")
    print(query)

    plan_text = generate_plan(query)
    memory = execute_steps(query, plan_text)

    final_step = max(memory.keys(), key=lambda x: int(x[1:]))
    print("[bold blue]Final Answer[/bold blue]")
    print(memory[final_step])

if __name__ == "__main__":
    main()