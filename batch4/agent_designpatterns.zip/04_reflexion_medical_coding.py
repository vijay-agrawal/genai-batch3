"""
================================================================================
PATTERN: Reflexion
================================================================================

WHAT IT IS:
  Reflexion extends Critique/ReAct by giving the agent a VERBAL MEMORY of its
  own past failures. After each failed attempt, a Reflection LLM:
    1. Diagnoses WHY the attempt failed
    2. Writes a concrete lesson ("Next time, remember to…")
    3. Stores that lesson in a persistent reflection buffer

  On the next attempt, the actor reads ALL prior reflections before trying again.
  This creates a self-improving agent that accumulates domain knowledge through
  trial and error — similar to how humans learn from mistakes.

KEY DIFFERENCE FROM CRITIQUE:
  - Critique: revise the SAME output in the same attempt
  - Reflexion: retry the ENTIRE task with MEMORY of what went wrong before
  Reflexion is better for tasks where failures reveal systematic gaps in
  understanding, not just surface-level wording issues.

GRAPH STRUCTURE:
  [START] → [actor] → [evaluator] → passed? → YES → [END]
                ↑                  ↘ NO (& iterations left) → [reflector] ↗

  The reflector writes a new lesson to the shared reflections list,
  then routes back to the actor for a full retry.

HEALTHCARE USE CASE:
  Medical Coding Accuracy (ICD-10-CM / CPT).
  Given a clinical encounter note, the agent assigns diagnosis (ICD-10) and
  procedure (CPT) codes. An evaluator checks the codes against official
  guidelines. If wrong, the reflector identifies the specific coding rule
  violated and stores it. The actor tries again, informed by accumulated lessons.
================================================================================
"""

import os
from typing import TypedDict, Literal
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from pydantic import BaseModel, Field

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, START, END

load_dotenv()
console = Console()

llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0,
)

# ── Structured Outputs ────────────────────────────────────────────────────────
class CodingAssignment(BaseModel):
    primary_icd10: str = Field(description="Primary ICD-10-CM diagnosis code e.g. E11.621")
    secondary_icd10: list[str] = Field(description="Additional ICD-10 codes")
    cpt_code: str = Field(description="Primary CPT procedure code e.g. 99214")
    coding_rationale: str = Field(description="Brief justification for each code selected")

class CodingEvaluation(BaseModel):
    icd10_correct: bool
    cpt_correct: bool
    errors_found: list[str] = Field(description="List of specific coding errors or guideline violations")
    passed: bool = Field(description="True only if BOTH icd10_correct and cpt_correct are True")

# ── State ─────────────────────────────────────────────────────────────────────
class CodingState(TypedDict):
    encounter_note: str
    reflections: list[str]      # accumulated lessons from past failures
    coding_attempt: dict        # latest coding assignment
    evaluation: dict            # latest evaluation
    iteration: int
    max_iterations: int

# ── Nodes ─────────────────────────────────────────────────────────────────────
ACTOR_SYSTEM = """You are a Certified Professional Coder (CPC) specializing in ICD-10-CM and CPT coding.
Assign the most accurate codes for the given clinical encounter.

ICD-10-CM Rules:
- Code to the highest level of specificity
- Sequence the principal diagnosis first
- Include all relevant comorbidities that affect care
- Use combination codes where available (e.g., E11.621 = T2DM + foot ulcer)

CPT Rules:
- Select E/M level based on medical decision making (MDM) or time
- New vs. established patient distinction matters
- Include relevant procedure codes if documented

If you have prior reflections/lessons learned, apply them precisely."""

def actor_node(state: CodingState) -> CodingState:
    it = state["iteration"] + 1
    console.print(f"[bold blue]\n[ACTOR] Coding attempt {it}...[/bold blue]")

    reflection_text = ""
    if state["reflections"]:
        reflection_text = "\n\nLESSONS FROM PREVIOUS FAILED ATTEMPTS:\n" + "\n".join(
            f"  [{i+1}] {r}" for i, r in enumerate(state["reflections"])
        )

    coding_llm = llm.with_structured_output(CodingAssignment)
    result: CodingAssignment = coding_llm.invoke([
        SystemMessage(content=ACTOR_SYSTEM + reflection_text),
        HumanMessage(content=f"ENCOUNTER NOTE:\n{state['encounter_note']}"),
    ])

    console.print(f"  Primary ICD-10: [cyan]{result.primary_icd10}[/cyan]")
    console.print(f"  Secondary ICD-10: [cyan]{result.secondary_icd10}[/cyan]")
    console.print(f"  CPT: [cyan]{result.cpt_code}[/cyan]")
    console.print(f"  Rationale: {result.coding_rationale[:150]}…")

    return {**state, "coding_attempt": result.model_dump(), "iteration": it}

# Simulated coding guideline evaluator (in production: query official code sets)
EVALUATOR_SYSTEM = """You are an ICD-10-CM/CPT coding auditor with expertise in CMS guidelines.
Given a clinical encounter and the coder's assignment, determine if the codes are correct.

Check:
1. ICD-10: Is the primary code the most specific available? Are combination codes used properly?
   Are all documented conditions affecting management coded? Sequencing correct?
2. CPT: Does the E/M level match the documented MDM? (Low=99202/99212, Moderate=99203/99213,
   High=99204/99214 for new pts; 99211-99215 for established)
3. Are there guideline violations (e.g., coding a symptom when a definitive diagnosis is known)?

Common errors to check:
- Using E11.9 (T2DM unspecified) when a more specific complication code exists
- Not coding hypertension with CKD using the combination code (I12.x)
- Wrong E/M level for the complexity documented"""

def evaluator_node(state: CodingState) -> CodingState:
    console.print("[bold magenta]\n[EVALUATOR] Auditing coding assignment...[/bold magenta]")
    eval_llm = llm.with_structured_output(CodingEvaluation)
    evaluation: CodingEvaluation = eval_llm.invoke([
        SystemMessage(content=EVALUATOR_SYSTEM),
        HumanMessage(content=(
            f"ENCOUNTER:\n{state['encounter_note']}\n\n"
            f"CODING SUBMITTED:\n"
            f"Primary ICD-10: {state['coding_attempt']['primary_icd10']}\n"
            f"Secondary ICD-10: {state['coding_attempt']['secondary_icd10']}\n"
            f"CPT: {state['coding_attempt']['cpt_code']}\n"
            f"Rationale: {state['coding_attempt']['coding_rationale']}"
        )),
    ])

    status = "[green]PASSED[/green]" if evaluation.passed else "[red]FAILED[/red]"
    console.print(f"  Audit Result: {status}")
    if evaluation.errors_found:
        for err in evaluation.errors_found:
            console.print(f"  [red]  ✗ {err}[/red]")

    return {**state, "evaluation": evaluation.model_dump()}

REFLECTOR_SYSTEM = """You are a coding educator reviewing a failed medical coding attempt.
Given the encounter, the incorrect codes, and the audit errors, write ONE concise lesson
(2-3 sentences) that the coder should remember for their next attempt.
Format: Start with "Remember:" and be specific about the rule or code that was wrong."""

def reflector_node(state: CodingState) -> CodingState:
    console.print("[bold yellow]\n[REFLECTOR] Generating lesson from failure...[/bold yellow]")
    errors = "\n".join(state["evaluation"].get("errors_found", []))
    reflection_response = llm.invoke([
        SystemMessage(content=REFLECTOR_SYSTEM),
        HumanMessage(content=(
            f"ENCOUNTER:\n{state['encounter_note']}\n\n"
            f"INCORRECT CODES:\n"
            f"Primary: {state['coding_attempt']['primary_icd10']}, "
            f"Secondary: {state['coding_attempt']['secondary_icd10']}, "
            f"CPT: {state['coding_attempt']['cpt_code']}\n\n"
            f"ERRORS FOUND:\n{errors}"
        )),
    ])
    lesson = reflection_response.content
    console.print(f"  [yellow]Lesson learned: {lesson[:200]}[/yellow]")
    return {**state, "reflections": state["reflections"] + [lesson]}

def should_retry(state: CodingState) -> Literal["reflector", "__end__"]:
    if state["evaluation"].get("passed") or state["iteration"] >= state["max_iterations"]:
        return "__end__"
    return "reflector"

# ── Graph ─────────────────────────────────────────────────────────────────────
graph = StateGraph(CodingState)
graph.add_node("actor",     actor_node)
graph.add_node("evaluator", evaluator_node)
graph.add_node("reflector", reflector_node)
graph.add_edge(START,       "actor")
graph.add_edge("actor",     "evaluator")
graph.add_conditional_edges("evaluator", should_retry, {
    "reflector": "reflector",
    "__end__":   END,
})
graph.add_edge("reflector", "actor")
app = graph.compile()

# ── Demo ──────────────────────────────────────────────────────────────────────
def main():
    console.print(Panel.fit("[bold cyan]Reflexion Pattern — Medical Coding Accuracy[/bold cyan]", border_style="cyan"))

    encounter = """
    ENCOUNTER NOTE — Established Patient Visit
    Patient: James Wu, 63M, MRN 445566
    Provider: Dr. Okonkwo, Nephrology
    Date: Today

    Chief Complaint: Follow-up for CKD and diabetes management.

    History: Patient with Type 2 DM and stage 3b CKD (eGFR 32, baseline). Also has HTN.
    Today's visit involves review of labs, medication adjustment, and dietary counseling.
    Patient reports 3 new painful sores on the sole of his right foot discovered last week.
    No fever, no chills. Wound assessed — 2 open ulcers on plantar right foot, stage 2, no infection.

    Vitals: BP 152/94, HR 72, BMI 31.2
    Labs: HbA1c 9.1%, eGFR 29 (declining from 32), K+ 5.4 (high), Creatinine 2.1

    Assessment:
    - Type 2 DM with diabetic peripheral neuropathy and foot ulcer (right, plantar)
    - CKD stage 3b (now borderline 4) with hypertension
    - Hyperkalemia — dietary counseling provided

    Plan: Adjust insulin, increase nephrology follow-up to monthly, dietary sodium and potassium restriction,
    wound care referral, renal diet education. Medical decision making: High complexity.
    Time spent: 45 minutes.
    """

    result = app.invoke({
        "encounter_note":  encounter,
        "reflections":     [],
        "coding_attempt":  {},
        "evaluation":      {},
        "iteration":       0,
        "max_iterations":  3,
    })

    console.print(Panel(
        f"Final ICD-10 Primary: [bold]{result['coding_attempt'].get('primary_icd10')}[/bold]\n"
        f"Secondary: {result['coding_attempt'].get('secondary_icd10')}\n"
        f"CPT: [bold]{result['coding_attempt'].get('cpt_code')}[/bold]\n\n"
        f"Reflections accumulated: {len(result['reflections'])}\n"
        f"Total iterations: {result['iteration']}",
        title="[bold green]Final Coding Assignment[/bold green]",
        border_style="green",
    ))

if __name__ == "__main__":
    main()
