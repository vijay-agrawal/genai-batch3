"""
================================================================================
PATTERN: State Management in LangGraph
================================================================================

WHAT IT IS:
  State is the data container that flows through a LangGraph graph.
  Every node reads from it and writes updates back to it.
  LangGraph makes state explicit, typed, and composable via TypedDict.

  This demo is NOT about memory between sessions (that is 05_memory).
  State is the in-execution data bus for a single graph run.

  Three core LangGraph state mechanics are demonstrated here:

  1. STATE SCHEMA (TypedDict with type annotations)
     Every field in the state has an explicit Python type.
     LangGraph validates state transitions against this schema.
     You can nest TypedDicts to group related fields logically.
     Benefit: makes data contracts between nodes explicit and checkable.

  2. REDUCER STRATEGIES (how fields are updated across nodes)
     When a node returns a partial state dict, LangGraph must decide
     how to merge it with the existing state. Two built-in strategies:

     a) OVERWRITE (default): the new value replaces the old one.
        Use for: current status, latest reading, scalar counters.
        Example: `alert_level: str` — each analysis overwrites the last.

     b) APPEND (operator.add or add_messages): new value is concatenated.
        Use for: logs, timelines, accumulators — anything that must grow.
        Declared with: `field: Annotated[list[X], operator.add]`
        Example: `vitals_history` accumulates every reading across cycles.

     c) CUSTOM REDUCERS: any function `(old_val, new_val) -> merged_val`.
        Use for: deduplication, capped lists, priority queues, etc.

  3. THREAD ISOLATION (one state machine instance per patient)
     LangGraph's checkpointer assigns each invocation a thread_id.
     Threads are completely independent — sharing zero state.
     The same compiled graph serves all threads; state is isolated by id.
     Critical in healthcare: Patient A's monitoring state NEVER bleeds
     into Patient B's, even when the same graph code processes both.
     Isolation is enforced by the checkpointer, not the application code.

HOW STATE DIFFERS FROM MEMORY:
  Memory (05): information persisted in an EXTERNAL store BETWEEN sessions.
              What the agent "knows" across separate invocations.
  State  (06): data that flows WITHIN a single graph execution.
              What the graph "carries" from one node to the next in one run.
  They interact: a load_memory node READS from external memory INTO state;
  a save_memory node WRITES state fields OUT to external memory.

GRAPH STRUCTURE:
  [START] → [ingest_vitals] → [rule_check] → [ai_analysis] → [alert] → [END]

  ingest_vitals : appends new reading to vitals_history (APPEND reducer)
  rule_check    : fast threshold check, sets alert_level (OVERWRITE)
  ai_analysis   : trend reasoning over accumulated history, may upgrade alert
  alert         : appends alert event to events_log (APPEND reducer)

HEALTHCARE USE CASE:
  ICU Continuous Vitals Monitoring.
  Multiple patients are monitored in parallel as isolated threads.
  Each monitoring cycle appends to the patient's vitals timeline (append
  reducer) so trend analysis has history to work with. Alert level and
  analysis text are overwritten each cycle. A running events log accumulates
  via append reducer. Thread isolation ensures patients never share state.
================================================================================
"""

import os
import operator
from datetime import datetime, timedelta
from typing import Annotated, TypedDict, Optional
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver

load_dotenv()
console = Console()

llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0,
)

# ── Clinical thresholds (static config, not part of state) ───────────────────
THRESHOLDS = {
    "hr":     (50,  130),
    "bp_sys": (85,  180),
    "spo2":   (90,  100),
    "rr":     (8,   30),
    "temp":   (35.5, 38.5),
}

# ── State Schema ──────────────────────────────────────────────────────────────
# Demonstrates the three reducer strategies in one schema.

class VitalsReading(TypedDict):
    timestamp: str
    hr:     int    # heart rate bpm
    bp_sys: int    # systolic BP mmHg
    bp_dia: int    # diastolic BP mmHg
    spo2:   float  # oxygen saturation %
    rr:     int    # respiratory rate /min
    temp:   float  # temperature °C
    gcs:    int    # Glasgow Coma Scale 3-15

class ICUState(TypedDict):
    # ── Identity fields — set once, never change (overwrite strategy, but stable) ──
    patient_id:          str
    patient_name:        str
    admission_diagnosis: str

    # ── Input for this cycle — overwritten each invocation ───────────────────
    current_vitals: VitalsReading

    # ── APPEND reducer — vitals_history grows every cycle ────────────────────
    # Annotated[list, operator.add] means: new_list is concatenated to old_list
    # Node returns: {"vitals_history": [one_new_reading]} → it gets appended
    vitals_history: Annotated[list[VitalsReading], operator.add]

    # ── APPEND reducer — events_log is a running audit trail ─────────────────
    events_log: Annotated[list[str], operator.add]

    # ── OVERWRITE fields — each cycle replaces the previous value ────────────
    breached_params: list[str]    # which vitals are out of range THIS cycle
    alert_level:     str          # "none" | "advisory" | "urgent" | "immediate"
    trend_analysis:  str          # LLM's analysis narrative, latest cycle only

# ── Node 1: ingest_vitals — APPEND reducer in action ─────────────────────────
def ingest_vitals(state: ICUState) -> dict:
    """
    Appends the current reading to vitals_history.
    Returns only the fields this node changes — LangGraph merges the rest.
    """
    reading = state["current_vitals"]
    ts = reading.get("timestamp", datetime.now().strftime("%H:%M:%S"))
    log_line = (f"[{ts}] HR={reading['hr']}, BP={reading['bp_sys']}/{reading['bp_dia']}, "
                f"SpO2={reading['spo2']}%, RR={reading['rr']}, "
                f"Temp={reading['temp']}°C, GCS={reading['gcs']}")
    console.print(f"[dim]  [ingest] {log_line}[/dim]")

    # Returning a LIST — operator.add will concatenate it to vitals_history
    return {
        "vitals_history": [reading],
        "events_log":     [f"Vitals ingested at {ts}"],
    }

# ── Node 2: rule_check — fast deterministic threshold check ──────────────────
def rule_check(state: ICUState) -> dict:
    """
    Deterministic rules — no LLM needed.
    Sets alert_level and breached_params. OVERWRITES previous values.
    """
    r = state["current_vitals"]
    breached = []

    checks = [
        ("hr",     r["hr"],     "HR"),
        ("bp_sys", r["bp_sys"], "BP_sys"),
        ("spo2",   r["spo2"],   "SpO2"),
        ("rr",     r["rr"],     "RR"),
        ("temp",   r["temp"],   "Temp"),
    ]
    critical_flags = []
    for key, val, label in checks:
        lo, hi = THRESHOLDS[key]
        if not (lo <= val <= hi):
            breached.append(f"{label}={val}")
        # Immediate critical rules
        if key == "spo2"   and val < 85:  critical_flags.append("SpO2 CRITICAL")
        if key == "hr"     and val > 150: critical_flags.append("HR CRITICAL")
        if key == "hr"     and val < 40:  critical_flags.append("HR CRITICAL LOW")
        if key == "bp_sys" and val < 70:  critical_flags.append("BP CRITICAL")

    if critical_flags:
        level = "immediate"
    elif len(breached) >= 2:
        level = "urgent"
    elif len(breached) == 1:
        level = "advisory"
    else:
        level = "none"

    console.print(f"  [rule_check] Breached: {breached or 'none'} → alert={level}")
    # These fields OVERWRITE — no Annotated needed, just plain dict merge
    return {
        "breached_params": breached,
        "alert_level":     level,
    }

# ── Node 3: ai_analysis — trend reasoning using accumulated history ───────────
def ai_analysis(state: ICUState) -> dict:
    """
    Reads the FULL vitals_history (accumulated via append reducer across ALL
    prior cycles for this thread) to detect trends, not just point alarms.
    May escalate alert_level beyond what the rule_check set.
    Overwrites trend_analysis.
    """
    history = state["vitals_history"]
    console.print(f"[bold blue]\n  [ai_analysis] Analysing {len(history)} reading(s)...[/bold blue]")

    # Format the accumulated timeline for the LLM
    history_text = "\n".join(
        f"  t{i+1} [{r['timestamp']}]: HR={r['hr']}, BP={r['bp_sys']}/{r['bp_dia']}, "
        f"SpO2={r['spo2']}%, RR={r['rr']}, Temp={r['temp']}°C, GCS={r['gcs']}"
        for i, r in enumerate(history[-8:])
    )

    response = llm.invoke([
        SystemMessage(content=f"""You are an ICU monitoring AI for:
Patient: {state['patient_name']} | Admission: {state['admission_diagnosis']}
Alarm thresholds: {THRESHOLDS}
Current rule-based alert: {state['alert_level']} | Breached params: {state['breached_params']}

Analyse the TREND across all readings (not just the latest).
Provide:
1. Trend direction: improving / stable / deteriorating (with evidence from the timeline)
2. Clinical concern if any (sepsis? respiratory failure? hemodynamic instability?)
3. Final alert level: NONE / ADVISORY / URGENT / IMMEDIATE
   (may escalate beyond rule-based level if trend warrants it)
4. Recommended action if alert > NONE"""),
        HumanMessage(content=f"VITALS TIMELINE ({len(history)} readings):\n{history_text}"),
    ])

    analysis = response.content

    # Escalate alert_level if LLM detects a worse trend than rules caught
    final_level = state["alert_level"]
    upper = analysis.upper()
    if "IMMEDIATE" in upper:
        final_level = "immediate"
    elif "URGENT" in upper and final_level not in ("immediate",):
        final_level = "urgent"
    elif "ADVISORY" in upper and final_level == "none":
        final_level = "advisory"

    return {
        "trend_analysis": analysis,
        "alert_level":    final_level,   # overwrite with potentially escalated level
    }

# ── Node 4: alert — appends alert event to audit log ─────────────────────────
def alert_node(state: ICUState) -> dict:
    """
    Displays alert and appends to events_log (APPEND reducer).
    Note: only returns the new event; LangGraph concatenates it.
    """
    level = state["alert_level"]
    styles = {
        "none":      ("dim",         "●"),
        "advisory":  ("yellow",      "⚠"),
        "urgent":    ("bold orange3","⚡"),
        "immediate": ("bold red",    "CRITICAL"),
    }
    style, icon = styles.get(level, ("white", "?"))
    console.print(f"\n  [{style}]{icon} ALERT: {level.upper()}[/{style}]")
    if level != "none":
        console.print(f"  [{style}]{state['trend_analysis'][:300]}[/{style}]")

    ts = datetime.now().strftime("%H:%M:%S")
    return {
        "events_log": [f"[{ts}] Alert={level.upper()} | Breached={state['breached_params']}"]
    }

# ── Graph ─────────────────────────────────────────────────────────────────────
checkpointer = MemorySaver()   # enables thread isolation + state persistence between cycles

graph = StateGraph(ICUState)
graph.add_node("ingest_vitals", ingest_vitals)
graph.add_node("rule_check",    rule_check)
graph.add_node("ai_analysis",   ai_analysis)
graph.add_node("alert",         alert_node)

graph.add_edge(START,           "ingest_vitals")
graph.add_edge("ingest_vitals", "rule_check")
graph.add_edge("rule_check",    "ai_analysis")
graph.add_edge("ai_analysis",   "alert")
graph.add_edge("alert",         END)

app = graph.compile(checkpointer=checkpointer)

# ── Demo ──────────────────────────────────────────────────────────────────────
def monitoring_cycle(patient_id: str, patient_name: str, diagnosis: str,
                     vitals: VitalsReading, cycle: int) -> dict:
    """
    Each call reuses the SAME thread_id for a patient → state accumulates.
    Different patients get different thread_ids → isolated state.
    """
    config = {"configurable": {"thread_id": f"icu-{patient_id}"}}
    console.print(f"\n[bold]─── Cycle {cycle} | {patient_name} | Thread: icu-{patient_id} ───[/bold]")

    # LangGraph merges this input with EXISTING checkpointed state for this thread.
    # vitals_history and events_log will be APPENDED to (not replaced).
    return app.invoke(
        {
            "patient_id":          patient_id,
            "patient_name":        patient_name,
            "admission_diagnosis": diagnosis,
            "current_vitals":      vitals,
            "vitals_history":      [],   # starts empty; grows via append reducer
            "events_log":          [],
            "breached_params":     [],
            "alert_level":         "none",
            "trend_analysis":      "",
        },
        config=config,
    )

def main():
    console.print(Panel.fit(
        "[bold cyan]State Pattern — ICU Vitals Monitoring[/bold cyan]\n"
        "[dim]Demonstrates: Schema Design · Reducer Strategies (append vs overwrite) · Thread Isolation[/dim]",
        border_style="cyan",
    ))

    # Show reducer strategy table
    rt = Table(title="State Reducer Strategies in this Graph", show_header=True)
    rt.add_column("Field",            style="cyan")
    rt.add_column("Strategy",         style="bold")
    rt.add_column("Effect")
    rt.add_row("vitals_history",  "APPEND (operator.add)",  "Each cycle's reading joins the timeline")
    rt.add_row("events_log",      "APPEND (operator.add)",  "Audit trail grows; entries never lost")
    rt.add_row("breached_params", "OVERWRITE (default)",    "Only current cycle's violations matter")
    rt.add_row("alert_level",     "OVERWRITE (default)",    "Latest assessment replaces prior one")
    rt.add_row("trend_analysis",  "OVERWRITE (default)",    "Latest LLM narrative replaces prior one")
    console.print(rt)

    # ── Patient A: deteriorating over 3 cycles (one thread) ──────────────────
    now = datetime.now()
    vitals_a = [
        VitalsReading(timestamp=(now - timedelta(hours=2)).strftime("%H:%M"), hr=88,  bp_sys=118, bp_dia=76, spo2=97.0, rr=16, temp=37.1, gcs=15),
        VitalsReading(timestamp=(now - timedelta(hours=1)).strftime("%H:%M"), hr=104, bp_sys=104, bp_dia=68, spo2=93.5, rr=23, temp=38.3, gcs=14),
        VitalsReading(timestamp=now.strftime("%H:%M"),                        hr=120, bp_sys=86,  bp_dia=55, spo2=88.0, rr=29, temp=39.1, gcs=12),
    ]

    # ── Patient B: stable (different thread — completely isolated state) ──────
    vitals_b = [
        VitalsReading(timestamp=now.strftime("%H:%M"), hr=72, bp_sys=124, bp_dia=80, spo2=98.5, rr=14, temp=36.9, gcs=15),
    ]

    console.print("\n[bold magenta]══ PATIENT A — 3 monitoring cycles (state accumulates in one thread) ══[/bold magenta]")
    result_a = None
    for i, v in enumerate(vitals_a, 1):
        result_a = monitoring_cycle("ICU001", "Thomas Osei", "Post-op abdominal sepsis", v, i)

    console.print("\n[bold magenta]══ PATIENT B — 1 cycle (isolated thread, state never touches Patient A) ══[/bold magenta]")
    result_b = monitoring_cycle("ICU002", "Linda Park", "Post-CABG, day 1", vitals_b[0], 1)

    # Show accumulated state for Patient A
    console.print(Panel(
        result_a["trend_analysis"],
        title=f"[bold red]Patient A — Final Trend Analysis (after {len(result_a['vitals_history'])} accumulated readings)[/bold red]",
        border_style="red",
    ))

    # Demonstrate thread isolation
    it = Table(title="Thread Isolation — State Comparison", show_header=True)
    it.add_column("Patient",            style="bold")
    it.add_column("Thread ID",          style="cyan")
    it.add_column("Readings accumulated")
    it.add_column("Events logged")
    it.add_column("Final alert")
    it.add_row("Thomas Osei (A)", "icu-ICU001",
               str(len(result_a["vitals_history"])),
               str(len(result_a["events_log"])),
               f"[bold red]{result_a['alert_level'].upper()}[/bold red]")
    it.add_row("Linda Park (B)",  "icu-ICU002",
               str(len(result_b["vitals_history"])),
               str(len(result_b["events_log"])),
               f"[green]{result_b['alert_level'].upper()}[/green]")
    console.print(it)
    console.print("[dim]Note: Patient A accumulated 3 readings across 3 cycles via the append reducer.[/dim]")
    console.print("[dim]      Patient B's thread has no knowledge of Patient A's state.[/dim]")

if __name__ == "__main__":
    main()
