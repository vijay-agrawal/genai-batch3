"""
================================================================================
PATTERN: Critique (Generate → Critique → Revise)
================================================================================

WHAT IT IS:
  The Critique pattern uses two (or more) LLM roles in a refinement loop:
    1. GENERATOR — produces an initial draft of the output
    2. CRITIC    — evaluates the draft against specific quality criteria,
                   returning structured feedback (pass/fail per criterion)
    3. REVISER   — (same or different LLM) rewrites the draft using the critique
  The loop continues until the critic is satisfied or a max iteration cap is hit.

WHY IT WORKS:
  A single LLM pass often misses edge cases or produces mediocre first drafts.
  Separating "generation" from "critique" allows specialized evaluation prompts
  tuned to domain standards, while the generator can focus purely on content.
  This mirrors human peer-review workflows and significantly improves output
  quality on structured, high-stakes documents.

VARIANTS:
  - Constitutional AI critique (fixed rules)
  - Self-critique (same LLM, different prompt)
  - Cross-model critique (different model as critic)
  - Rubric-based scoring (critic returns numeric scores)

GRAPH STRUCTURE:
  [START] → [generator] → [critic] → should_revise? → YES → [reviser] → [critic] (loop)
                                                      ↘ NO → [END]

HEALTHCARE USE CASE:
  Clinical SOAP Note (Subjective, Objective, Assessment, Plan) Generation and Quality Review.
  Given encounter data (patient complaint, vitals, exam findings, plan),
  generate a structured SOAP note, then have an AI critic evaluate it
  against clinical documentation standards (completeness, accuracy,
  legibility, billing compliance). Revise until all criteria pass.
================================================================================
"""

import os
from typing import TypedDict, Literal
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from pydantic import BaseModel, Field

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, START, END

load_dotenv()
console = Console()

llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0,
)

# ── Structured Critique Schema ────────────────────────────────────────────────
class CritiqueCriterion(BaseModel):
    criterion: str
    passed: bool
    feedback: str

class SOAPCritique(BaseModel):
    criteria: list[CritiqueCriterion]
    overall_pass: bool = Field(description="True only if ALL criteria pass")
    summary: str = Field(description="One paragraph summarizing what to fix")

# ── State ─────────────────────────────────────────────────────────────────────
class SOAPState(TypedDict):
    encounter_data: str
    soap_note: str
    critique: dict          # serialized SOAPCritique
    iteration: int
    max_iterations: int
    final_note: str

# ── Nodes ─────────────────────────────────────────────────────────────────────
GENERATOR_SYSTEM = """You are an experienced clinical documentation specialist.
Given encounter data, write a complete SOAP note in this exact format:

SUBJECTIVE:
  Chief Complaint: ...
  HPI: ...
  ROS: ...
  PMH/PSH/FH/SH: ...
  Medications: ...
  Allergies: ...

OBJECTIVE:
  Vitals: ...
  Physical Exam: ...
  Diagnostic Results: ...

ASSESSMENT:
  Primary Diagnosis: ...
  Differential Diagnoses: ...
  ICD-10 Code: ...

PLAN:
  Medications: ...
  Orders/Referrals: ...
  Patient Education: ...
  Follow-up: ...

Be thorough, precise, and use proper medical terminology."""

def generator_node(state: SOAPState) -> SOAPState:
    it = state["iteration"] + 1
    console.print(f"[bold blue]\n[GENERATOR] Iteration {it} — drafting SOAP note...[/bold blue]")

    prompt_parts = [state["encounter_data"]]
    if state.get("soap_note") and state.get("critique"):
        critique_summary = state["critique"].get("summary", "")
        prompt_parts.append(f"\n\nPREVIOUS DRAFT (needs revision):\n{state['soap_note']}")
        prompt_parts.append(f"\nCRITIQUE — please address these issues:\n{critique_summary}")

    response = llm.invoke([
        SystemMessage(content=GENERATOR_SYSTEM),
        HumanMessage(content="\n".join(prompt_parts)),
    ])
    console.print(Panel(response.content[:800] + "…", title=f"Draft SOAP Note (Iteration {it})", border_style="blue"))
    return {**state, "soap_note": response.content, "iteration": it}

CRITIC_SYSTEM = """You are a clinical documentation quality auditor and medical coding specialist.
Evaluate the provided SOAP note against these criteria:

1. COMPLETENESS — All four SOAP sections present and adequately populated
2. SUBJECTIVE_ACCURACY — Chief complaint and HPI clearly documented
3. OBJECTIVE_COMPLETENESS — Vitals, exam findings, and relevant labs included
4. ASSESSMENT_QUALITY — Primary diagnosis with ICD-10 code; differentials listed
5. PLAN_ACTIONABILITY — Specific medications, doses, orders, and follow-up timeline
6. BILLING_COMPLIANCE — Documentation supports the level of service claimed
7. MEDICAL_TERMINOLOGY — Appropriate clinical language; no dangerous abbreviations

For each criterion return passed=True only if fully satisfied.
Return overall_pass=True ONLY if every single criterion passes."""

critic_llm = llm.with_structured_output(SOAPCritique)

def critic_node(state: SOAPState) -> SOAPState:
    console.print("[bold magenta]\n[CRITIC] Evaluating SOAP note quality...[/bold magenta]")

    critique: SOAPCritique = critic_llm.invoke([
        SystemMessage(content=CRITIC_SYSTEM),
        HumanMessage(content=f"SOAP NOTE TO REVIEW:\n\n{state['soap_note']}"),
    ])

    table = Table(title="Quality Critique", show_header=True)
    table.add_column("Criterion", style="cyan")
    table.add_column("Pass", style="bold")
    table.add_column("Feedback", style="white", max_width=55)

    for c in critique.criteria:
        status = "[green]✓ PASS[/green]" if c.passed else "[red]✗ FAIL[/red]"
        table.add_row(c.criterion, status, c.feedback)

    console.print(table)
    overall = "[green]ALL PASS — Document Accepted[/green]" if critique.overall_pass else "[red]REVISION NEEDED[/red]"
    console.print(f"Overall: {overall}\n")

    return {**state, "critique": critique.model_dump()}

def should_revise(state: SOAPState) -> Literal["generator", "finalize"]:
    if state["critique"].get("overall_pass") or state["iteration"] >= state["max_iterations"]:
        return "finalize"
    return "generator"

def finalize_node(state: SOAPState) -> SOAPState:
    return {**state, "final_note": state["soap_note"]}

# ── Graph ─────────────────────────────────────────────────────────────────────
graph = StateGraph(SOAPState)
graph.add_node("generator", generator_node)
graph.add_node("critic",    critic_node)
graph.add_node("finalize",  finalize_node)
graph.add_edge(START,       "generator")
graph.add_edge("generator", "critic")
graph.add_conditional_edges("critic", should_revise, {
    "generator": "generator",
    "finalize":  "finalize",
})
graph.add_edge("finalize", END)
app = graph.compile()

# ── Demo ──────────────────────────────────────────────────────────────────────
def main():
    console.print(Panel.fit("[bold cyan]Critique Pattern — Clinical SOAP Note Review[/bold cyan]", border_style="cyan"))

    encounter = """
    ENCOUNTER DATA:
    Patient: Maria Santos, 52F, MRN 789012
    Date: Today
    Provider: Dr. Patel, Internal Medicine

    Reason for visit: Follow-up for poorly controlled diabetes and new foot wound.

    History: Patient reports blood sugars running 280-350 mg/dL despite insulin.
    She noticed a small wound on her right heel 2 weeks ago that hasn't healed.
    Denies fever. Reports occasional tingling in both feet for past 6 months.

    Vitals: BP 148/92, HR 84, Temp 37.3°C, RR 16, SpO2 97%, Weight 94 kg, Height 162 cm, BMI 35.8

    Exam: Right heel — 1.5 cm × 1.0 cm wound, depth 3mm, no exposed bone, mild surrounding erythema,
    no purulent drainage. Diminished monofilament sensation bilateral feet.
    Pedal pulses present but diminished.

    Labs (today): HbA1c 10.2%, Fasting glucose 298 mg/dL, Creatinine 1.1, eGFR 68.
    Wound culture pending.

    Current meds: Metformin 1000mg BID, Glargine 20 units QHS, Lisinopril 10mg QD.
    Allergies: Sulfa drugs (rash).
    """

    result = app.invoke({
        "encounter_data": encounter,
        "soap_note": "",
        "critique": {},
        "iteration": 0,
        "max_iterations": 3,
        "final_note": "",
    })

    console.print(Panel(
        result["final_note"],
        title=f"[bold green]Final Accepted SOAP Note (after {result['iteration']} iteration(s))[/bold green]",
        border_style="green",
    ))

if __name__ == "__main__":
    main()
