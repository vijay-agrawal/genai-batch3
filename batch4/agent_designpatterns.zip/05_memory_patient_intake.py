"""
================================================================================
PATTERN: Agentic Memory + Tool-Calling (LangGraph)
================================================================================

WHAT IT IS:
  This pattern combines:
    1) Working Memory (conversation context)
    2) Semantic Memory (patient facts)
    3) Episodic Memory (past interactions)
    4) Tool-Calling Agent (dynamic reasoning + actions)

  The agent behaves like a real clinical assistant:
    - remembers who the patient is
    - recalls past interactions
    - reasons over current symptoms
    - calls tools when needed
    - updates memory after the session

--------------------------------------------------------------------------------

MEMORY TYPES (Cognitive Model):

  1. WORKING MEMORY
     - Current conversation (state["messages"])
     - Short-term, session-bound
     - Automatically updated by LangGraph

  2. SEMANTIC MEMORY
     - Facts about the patient (identity, allergies, conditions)
     - Stored in external DB (PATIENT_STORE)
     - Updated only when facts change

  3. EPISODIC MEMORY
     - Timeline of past interactions (date + summary)
     - Append-only history
     - Used for continuity and context

--------------------------------------------------------------------------------

GRAPH STRUCTURE (LangGraph):

                 ┌──────────────────────┐
                 │        START         │
                 └──────────┬───────────┘
                            │
                            ▼
                 ┌──────────────────────┐
                 │    load_memory       │
                 │ (semantic + episodic)│
                 └──────────┬───────────┘
                            │
                            ▼
                 ┌──────────────────────┐
                 │        agent         │
                 │ (LLM + tools + mem) │
                 └───────┬─────┬────────┘
                         │     │
          tool_calls? ───┘     └── no tool calls
                         │
                         ▼
                 ┌──────────────────────┐
                 │        tools         │
                 │ (ToolNode executes)  │
                 └──────────┬───────────┘
                            │
                            ▼
                         (loop)
                            │
                            ▼
                 ┌──────────────────────┐
                 │     save_memory      │
                 │ (extract + persist)  │
                 └──────────┬───────────┘
                            │
                            ▼
                          [END]

--------------------------------------------------------------------------------

EXECUTION FLOW:

1. LOAD MEMORY
   - Fetch patient profile (semantic)
   - Fetch recent history (episodic)

2. AGENT REASONING
   - LLM receives:
       - working memory (conversation)
       - semantic memory (facts)
       - episodic memory (history)
   - Decides whether to call tools

3. TOOL EXECUTION (if needed)
   - ToolNode runs tool(s)
   - Results fed back to agent
   - Agent continues reasoning loop

4. SAVE MEMORY (session end)
   - Extract:
       - new/updated facts → semantic memory
       - summary of session → episodic memory
   - Persist to external store

--------------------------------------------------------------------------------

KEY DESIGN PRINCIPLES:

  ✔ Separation of memory types (working / semantic / episodic)
  ✔ Agent decides tool usage dynamically (agentic behavior)
  ✔ Memory is injected into system prompt (not hidden state)
  ✔ Semantic memory is UPDATED
  ✔ Episodic memory is APPEND-ONLY
  ✔ Tools are executed via ToolNode (LangGraph best practice)

--------------------------------------------------------------------------------

HEALTHCARE USE CASE:

  Patient Intake Assistant with longitudinal memory:
    - Remembers patient identity and conditions
    - References past visits naturally
    - Detects worsening symptoms
    - Suggests next actions (appointments, meds)
    - Maintains continuity across sessions

--------------------------------------------------------------------------------

MENTAL MODEL:

  This system behaves like a clinician:

    Working Memory  → "What is happening right now?"
    Semantic Memory → "Who is this patient?"
    Episodic Memory → "What happened before?"
    Tools           → "What external info do I need?"
    LLM             → "What should I do next?"

================================================================================
"""
import os
import json
from datetime import datetime
from typing import Annotated, TypedDict
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from pydantic import BaseModel, Field

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, BaseMessage
from langchain_openai import AzureChatOpenAI
from langchain_core.tools import tool
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.checkpoint.memory import MemorySaver

load_dotenv()
console = Console()

llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0,
)

# ── External Memory Store ──────────────────────────────────────────────────────
# Production: replace with PostgreSQL / Redis / a vector store.
# Keyed by MRN. Two top-level buckets: semantic facts and episodic log.
PATIENT_STORE: dict[str, dict] = {
    "P010": {
        # ── SEMANTIC: timeless facts about who this patient IS ──────────────
        "semantic": {
            "name":               "Rosa Martinez",
            "dob":                "1978-03-15",
            "mrn":                "P010",
            "allergies":          ["penicillin", "sulfa"],
            "chronic_conditions": ["asthma", "GERD"],
            "current_medications":["albuterol PRN", "omeprazole 20mg QD"],
            "primary_care":       "Dr. Nguyen",
            "insurance":          "BlueCross PPO",
        },
        # ── EPISODIC: timestamped log of what HAPPENED in past interactions ─
        "episodic": [
            {
                "date": "2026-03-10",
                "summary": (
                    "Patient called about asthma flare; using rescue inhaler >3×/week. "
                    "Montelukast 10mg QD added. Asthma action plan reviewed. "
                    "Follow-up in 4 weeks."
                ),
            },
            {
                "date": "2026-04-01",
                "summary": (
                    "Refill request for albuterol and omeprazole. No acute complaints. "
                    "Patient mentioned upcoming travel to Denver. "
                    "Counselled on altitude effects on asthma. Refills approved."
                ),
            },
        ],
    }
}

def load_patient_store(mrn: str) -> dict:
    return PATIENT_STORE.get(mrn, {"semantic": {}, "episodic": []})

def save_patient_store(mrn: str, data: dict):
    PATIENT_STORE[mrn] = data

# ── Structured Output: what the LLM extracts at session end ──────────────────
class SessionExtract(BaseModel):
    # Semantic updates — facts that changed or were newly discovered
    updated_allergies:   list[str] = Field(default_factory=list, description="Newly reported allergies")
    updated_conditions:  list[str] = Field(default_factory=list, description="New diagnoses mentioned")
    updated_medications: list[str] = Field(default_factory=list, description="New medications added")
    # Episodic entry — what happened in THIS call
    episode_summary:     str = Field(description="2-3 sentence factual summary of this specific interaction")

# ── Graph State ───────────────────────────────────────────────────────────────
class IntakeState(TypedDict):
    # Working memory — live conversation buffer for THIS session
    messages: Annotated[list[BaseMessage], add_messages]

    patient_mrn:       str
    # Semantic memory loaded from store at session start
    semantic_memory:   dict
    # Episodic memory loaded from store at session start
    episodic_memory:   list[dict]

# ── Tools available to the agent ──────────────────────────────────────────────
@tool
def check_appointment_slots(provider: str, preferred_date: str) -> str:
    """Check available appointment slots for a provider on or near a preferred date."""
    slots = {
        "Dr. Nguyen": ["2026-04-28 9:00 AM", "2026-04-28 2:30 PM", "2026-04-29 11:00 AM"],
        "Dr. Patel":  ["2026-04-29 10:00 AM", "2026-04-30 3:00 PM"],
    }
    available = slots.get(provider, ["No availability found"])
    return f"Available slots with {provider}: " + ", ".join(available)

@tool
def lookup_medication_info(medication: str) -> str:
    """Return prescribing summary and key interaction warnings for a medication."""
    info = {
        "montelukast": "Leukotriene receptor antagonist for asthma/allergic rhinitis. Evening dosing. Monitor for mood changes.",
        "albuterol":   "SABA rescue inhaler. Max 2 puffs q4-6h PRN. >2× weekly use suggests uncontrolled asthma.",
        "omeprazole":  "PPI for GERD. Take 30-60 min before first meal. Long-term use: monitor Mg, B12.",
        "prednisone":  "Oral corticosteroid. Asthma burst: 40-60mg QD × 5 days with food. Monitor glucose.",
    }
    return info.get(medication.lower(), f"No formulary entry for '{medication}'. Consult clinical pharmacist.")

tools = [check_appointment_slots, lookup_medication_info]
llm_with_tools = llm.bind_tools(tools)

# ── Nodes ─────────────────────────────────────────────────────────────────────
def load_memory_node(state: IntakeState) -> IntakeState:
    """Load semantic facts + episodic log from external store into working state."""
    data = load_patient_store(state["patient_mrn"])
    console.print(f"[dim]\n[MEMORY LOAD] MRN {state['patient_mrn']} — "
                  f"{len(data['semantic'])} semantic fields, "
                  f"{len(data['episodic'])} episodic entries[/dim]")
    return {**state, "semantic_memory": data["semantic"], "episodic_memory": data["episodic"]}

def build_system_prompt(semantic: dict, episodic: list[dict]) -> str:
    """Compose system prompt injecting all three memory types."""
    # Semantic: inject as structured facts
    semantic_text = json.dumps(semantic, indent=2) if semantic else "No profile on record."

    # Episodic: inject as chronological event log (most recent 3)
    recent = episodic[-3:]
    episodic_text = (
        "\n".join(f"  [{ep['date']}] {ep['summary']}" for ep in recent)
        or "  No prior interactions recorded."
    )

    return f"""You are a compassionate patient intake assistant for City Medical Group.
You have access to the patient's profile (semantic memory) and recent interaction history (episodic memory).
Use both naturally — greet them by first name, reference relevant history without being robotic.

SEMANTIC MEMORY — who this patient is (timeless facts):
{semantic_text}

EPISODIC MEMORY — what happened in their last {len(recent)} interaction(s):
{episodic_text}

Guidelines:
- Always check allergies before suggesting any medication
- Flag if new symptoms contradict or worsen known conditions
- For anything urgent, advise the patient to seek immediate care
- Be warm, clear, and concise"""

def agent_node(state: IntakeState) -> IntakeState:
    """The agent works from working memory (messages) + injected semantic + episodic context."""
    prompt = build_system_prompt(state["semantic_memory"], state["episodic_memory"])
    # Working memory = SystemMessage + current message list
    messages = [SystemMessage(content=prompt)] + state["messages"]
    response = llm_with_tools.invoke(messages)
    return {"messages": [response]}

def save_memory_node(state: IntakeState) -> IntakeState:
    """
    At session end:
      - Extract semantic UPDATES (new facts discovered this session)
      - Create a new EPISODIC entry summarising what happened
      - Persist both back to the store
    """
    console.print("[dim]\n[MEMORY SAVE] Extracting session facts and writing episode entry...[/dim]")

    extractor = llm.with_structured_output(SessionExtract)
    conversation = "\n".join(
        f"{m.__class__.__name__}: {m.content[:400]}"
        for m in state["messages"] if hasattr(m, "content") and m.content
    )
    extract: SessionExtract = extractor.invoke([
        SystemMessage(content=(
            "Extract any NEW or CHANGED medical facts from this conversation "
            "(semantic updates) and write a concise factual summary of what occurred "
            "(episodic entry). Be precise — only include things explicitly stated."
        )),
        HumanMessage(content=conversation),
    ])

    # Merge semantic updates
    updated_semantic = dict(state["semantic_memory"])
    if extract.updated_allergies:
        updated_semantic.setdefault("allergies", [])
        updated_semantic["allergies"] = list(set(updated_semantic["allergies"] + extract.updated_allergies))
    if extract.updated_conditions:
        updated_semantic.setdefault("chronic_conditions", [])
        updated_semantic["chronic_conditions"] = list(set(updated_semantic["chronic_conditions"] + extract.updated_conditions))
    if extract.updated_medications:
        updated_semantic.setdefault("current_medications", [])
        updated_semantic["current_medications"] = list(set(updated_semantic["current_medications"] + extract.updated_medications))

    # Append new episodic entry (append-only; never rewrite history)
    new_episode = {
        "date":    datetime.now().strftime("%Y-%m-%d"),
        "summary": extract.episode_summary,
    }
    updated_episodic = state["episodic_memory"] + [new_episode]

    save_patient_store(state["patient_mrn"], {
        "semantic": updated_semantic,
        "episodic": updated_episodic[-10:],   # keep last 10 episodes
    })

    console.print(f"[dim]  Semantic updates: allergies={extract.updated_allergies}, "
                  f"conditions={extract.updated_conditions}, meds={extract.updated_medications}[/dim]")
    console.print(f"[dim]  New episode: {extract.episode_summary[:100]}…[/dim]")
    return state

# ── Graph ─────────────────────────────────────────────────────────────────────
tool_node   = ToolNode(tools)
checkpointer = MemorySaver()

graph = StateGraph(IntakeState)
graph.add_node("load_memory",  load_memory_node)
graph.add_node("agent",        agent_node)
graph.add_node("tools",        tool_node)
graph.add_node("save_memory",  save_memory_node)

graph.add_edge(START,          "load_memory")
graph.add_edge("load_memory",  "agent")
graph.add_conditional_edges("agent", tools_condition, {
    "tools":    "tools",
    "__end__":  "save_memory",
})
graph.add_edge("tools",        "agent")
graph.add_edge("save_memory",  END)

app = graph.compile(checkpointer=checkpointer)

# ── Demo ──────────────────────────────────────────────────────────────────────
def run_turn(mrn: str, message: str, session_id: str) -> str:
    config = {"configurable": {"thread_id": session_id}}
    result = app.invoke(
        {"messages": [HumanMessage(content=message)], "patient_mrn": mrn,
         "semantic_memory": {}, "episodic_memory": []},
        config=config,
    )
    return next(
        m.content for m in reversed(result["messages"])
        if isinstance(m, AIMessage) and not getattr(m, "tool_calls", None)
    )

def main():
    console.print(Panel.fit("[bold cyan]Memory Pattern — Patient Intake (Working · Semantic · Episodic)[/bold cyan]", border_style="cyan"))

    # Show what's pre-loaded in the store
    data = PATIENT_STORE["P010"]
    t = Table(title="External Store — Rosa Martinez (P010)", show_header=True)
    t.add_column("Memory Type", style="bold cyan", width=14)
    t.add_column("Key", style="cyan")
    t.add_column("Value")
    for k, v in data["semantic"].items():
        t.add_row("SEMANTIC", k, str(v))
    for ep in data["episodic"]:
        t.add_row("EPISODIC", ep["date"], ep["summary"][:80] + "…")
    console.print(t)

    console.print("\n[bold]Simulating Rosa's call — session uses all three memory types[/bold]\n")

    turns = [
        "Hi, I've been having more trouble breathing this week. My inhaler barely helps now.",
        "Can I get an appointment with Dr. Nguyen next week?",
        "Also — is prednisone safe for me to take?",
    ]
    session = "rosa-20260422"
    for msg in turns:
        console.print(f"\n[bold yellow]Rosa:[/bold yellow] {msg}")
        reply = run_turn("P010", msg, session)
        console.print(f"[bold green]Assistant:[/bold green] {reply}")

    console.print("\n[bold dim]--- Memory state after session ---[/bold dim]")
    updated = PATIENT_STORE["P010"]
    console.print(f"[dim]Semantic — conditions: {updated['semantic'].get('chronic_conditions')}[/dim]")
    console.print(f"[dim]Episodic — total entries: {len(updated['episodic'])}[/dim]")
    console.print(f"[dim]Latest episode: {updated['episodic'][-1]['summary'][:120]}…[/dim]")

if __name__ == "__main__":
    main()
