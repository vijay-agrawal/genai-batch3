import os
from pathlib import Path
from dotenv import load_dotenv
from rich import print

from langchain_core.tools import tool
from langchain_core.messages import HumanMessage
from langchain_openai import AzureChatOpenAI
from langchain.agents import create_agent

# Load environment variables
load_dotenv(Path(__file__).parent.parent / ".env")


# ── Azure OpenAI Setup ────────────────────────────────────────────────────────
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
        or os.getenv("AZURE_OPENAI_MODEL_NAME"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    temperature=0,
)


# ── Tools ─────────────────────────────────────────────────────────────────────
from typing import Optional

@tool
def lookup_vitals_norms(vital_sign: str, patient_age: Optional[int] = None) -> str:
    """Look up normal ranges for a vital sign given patient age. If age is unknown, assume adult unless stated otherwise."""
    norms = {
        "heart_rate": {"adult": "60-100 bpm", "pediatric": "70-120 bpm"},
        "blood_pressure": {"adult": "90-120/60-80", "pediatric": "80-110/50-70"},
        "respiratory_rate": {"adult": "12-20/min", "pediatric": "20-30/min"},
        "oxygen_saturation": {"adult": "95-100%", "pediatric": "95-100%"},
        "temperature": {"adult": "36.1-37.2°C", "pediatric": "36.1-37.5°C"},
    }

    key_map = {
        "heart rate": "heart_rate",
        "hr": "heart_rate",
        "pulse": "heart_rate",
        "blood pressure": "blood_pressure",
        "bp": "blood_pressure",
        "respiratory rate": "respiratory_rate",
        "rr": "respiratory_rate",
        "spo2": "oxygen_saturation",
        "oxygen saturation": "oxygen_saturation",
        "o2 saturation": "oxygen_saturation",
        "temperature": "temperature",
        "temp": "temperature",
    }

    normalized = vital_sign.lower().strip()
    key = key_map.get(normalized, normalized.replace(" ", "_"))

    category = "adult" if patient_age is None else ("pediatric" if patient_age < 18 else "adult")
    norm = norms.get(key, {}).get(category, "Reference not found")

    if patient_age is None:
        return f"Normal {vital_sign} for {category} (age unknown): {norm}"
    return f"Normal {vital_sign} for {category} (age {patient_age}): {norm}"

@tool
def query_symptom_severity(symptoms: str) -> str:
    """Assess clinical severity of a symptom cluster and suggest ESI triage level."""
    critical = ["chest pain", "difficulty breathing", "unconscious", "stroke", "seizure"]
    urgent = ["high fever", "abdominal pain", "fracture", "severe headache"]

    symptoms_lower = symptoms.lower()

    for s in critical:
        if s in symptoms_lower:
            return (
                f"CRITICAL symptoms detected ('{s}'). "
                f"Suggested ESI Level 1-2. Immediate physician evaluation."
            )

    for s in urgent:
        if s in symptoms_lower:
            return (
                f"URGENT symptoms detected ('{s}'). "
                f"Suggested ESI Level 2-3. Rapid assessment needed."
            )

    return "Non-urgent presentation. Suggested ESI Level 4-5. Standard triage queue appropriate."


tools = [lookup_vitals_norms, query_symptom_severity]


# ── System Prompt ─────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """You are an experienced emergency department triage assistant.

Role:
- Emergency Department Assistant

Goal:
- Assist in triaging patients by reasoning about symptoms and vitals,
  using tools when needed, and assigning an ESI triage level.

Guidelines:
- Use query_symptom_severity to assess symptom-cluster severity.
- Use lookup_vitals_norms when you need normal ranges for a specific vital sign.
- If patient age is not provided, assume adult unless the prompt clearly indicates pediatric.
- Do not fail just because age is missing.
- Base your answer on the tool outputs and the provided patient details.
- Be concise, clinically clear, and explicit about the triage priority.
- This is a triage support demo, not a final medical diagnosis.
"""

# ── Agent ─────────────────────────────────────────────────────────────────────
agent = create_agent(
    model=llm,
    tools=tools,
    system_prompt=SYSTEM_PROMPT,
    name="healthcare_triage_agent",
)


# ── Demo ──────────────────────────────────────────────────────────────────────
def main():
    print("[bold cyan]ReAct-style Agent — Healthcare Demo[/bold cyan]")

    query = (
        "Patient ID P001 just arrived. She is complaining of chest pain radiating to the left arm "
        "and difficulty breathing. Vitals: HR 110 bpm, BP 160/95, SpO2 91%, Temp 37.0°C. "
        "She was given aspirin by EMS. Please assess and assign triage priority."
    )
    print(f"\n[bold yellow]Patient Presentation:[/bold yellow]\n{query}\n")

    result = agent.invoke(
        {
            "messages": [
                HumanMessage(content=query)
            ]
        }
    )

    print("\n[bold green]─── Agent Messages / Trace ───[/bold green]")

    iteration = 0

    for msg in result["messages"]:
            role = msg.type.upper()

            if role == "HUMAN":
                print(f"[HUMAN] {msg.content}")

            elif role == "AI" and getattr(msg, "tool_calls", None):
                for tc in msg.tool_calls:
                    iteration += 1
                    tool_name = tc["name"]
                    args = tc.get("args", {})

                    if tool_name == "query_symptom_severity":
                        think = "Assess whether the symptom cluster indicates a critical presentation."
                    elif tool_name == "lookup_vitals_norms":
                        think = f"Compare reported {args.get('vital_sign', 'vital sign')} with normal range."
                    else:
                        think = f"Need more information via {tool_name}."

                    print(f"[AI - THINK {iteration}] {think}")
                    print(f"[AI - ACT {iteration}] Calling {tool_name} with args={args}")

            elif role == "TOOL":
                tool_name = getattr(msg, "name", "unknown_tool")
                print(f"[TOOL - {tool_name}] {msg.content}")

            else:
                print(f"[AI - FINAL] {msg.content}")

if __name__ == "__main__":
    main()
