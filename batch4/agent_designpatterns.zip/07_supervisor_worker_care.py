"""
================================================================================
PATTERN: Supervisor-Worker (Multi-Agent Orchestration)
================================================================================

WHAT IT IS:
  The Supervisor-Worker pattern uses one "orchestrator" agent to coordinate
  multiple specialized "worker" agents. The supervisor:
    1. Receives the overall task
    2. Decides which worker(s) to call and in what order
    3. Routes results between workers as needed
    4. Synthesizes the final output from all workers

  Workers are domain-specialized — each excels at a narrow task. The supervisor
  has no domain knowledge itself; its intelligence is in coordination.

VARIANTS:
  - Sequential routing: supervisor calls workers one at a time
  - Parallel fan-out: supervisor triggers multiple workers simultaneously
  - Hierarchical: workers can themselves be supervisor-worker subgraphs

THIS DEMO USES: Sequential routing via structured output routing decisions.

GRAPH STRUCTURE:
  [START] → [supervisor] → route decision → [cardiologist_worker]  ↘
                        ↗ (after each worker) ← [pharmacist_worker]  → [supervisor] → FINISH → [END]
                                               ← [radiologist_worker] ↗
                                               ← [lab_analyst_worker] ↗

  The supervisor uses a structured output to pick the next worker or "FINISH".
  After each worker completes, control returns to the supervisor for the next
  routing decision.

HEALTHCARE USE CASE:
  Multidisciplinary Care Team (MDT) Coordination.
  A complex patient case is presented to the supervisor (attending physician AI).
  The supervisor routes to specialist agents: Cardiologist, Pharmacist, Radiologist,
  Lab Analyst. Each specialist provides their domain assessment. The supervisor
  synthesizes a unified care plan from all inputs.
================================================================================
"""

import os
from typing import Annotated, Literal, TypedDict
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from pydantic import BaseModel, Field

from langchain_core.messages import HumanMessage, SystemMessage, AIMessage, BaseMessage
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

load_dotenv()
console = Console()

llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0,
)

# ── Routing Schema ────────────────────────────────────────────────────────────
WORKERS = ["cardiologist", "pharmacist", "radiologist", "lab_analyst"]

class RoutingDecision(BaseModel):
    next_worker: Literal["cardiologist", "pharmacist", "radiologist", "lab_analyst", "FINISH"]
    reasoning: str = Field(description="Why this worker is needed next")

# ── State ─────────────────────────────────────────────────────────────────────
class MDTState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]
    case_summary: str
    worker_reports: dict[str, str]   # worker_name → specialist report
    next_worker: str
    final_care_plan: str

# ── Supervisor Node ───────────────────────────────────────────────────────────
SUPERVISOR_SYSTEM = """You are the attending physician coordinating a multidisciplinary team (MDT).
Your role is to orchestrate specialist consultations for a complex patient case.

Available specialists:
- cardiologist: cardiac assessment, ECG interpretation, heart failure, arrhythmia
- pharmacist: medication review, drug interactions, dosing adjustments for organ impairment
- radiologist: imaging review (CT, MRI, CXR, Echo), radiology report interpretation
- lab_analyst: comprehensive lab interpretation, biomarker trends, CBC/CMP/BNP analysis

You have received reports from these workers so far: {completed}

Choose the NEXT most important specialist to consult, or FINISH if you have sufficient
information from all relevant specialists to write a care plan.
Do NOT call the same specialist twice."""

router_llm = llm.with_structured_output(RoutingDecision)

def supervisor_node(state: MDTState) -> MDTState:
    completed = list(state["worker_reports"].keys())
    console.print(f"\n[bold cyan][SUPERVISOR] Routing decision. Completed: {completed or 'none'}[/bold cyan]")

    context = state["case_summary"]
    if completed:
        reports_text = "\n".join(
            f"[{w.upper()} REPORT]: {r[:300]}" for w, r in state["worker_reports"].items()
        )
        context += f"\n\nREPORTS RECEIVED SO FAR:\n{reports_text}"

    decision: RoutingDecision = router_llm.invoke([
        SystemMessage(content=SUPERVISOR_SYSTEM.format(completed=completed or "none")),
        HumanMessage(content=context),
    ])

    console.print(f"  → Next: [bold]{decision.next_worker}[/bold] | Reason: {decision.reasoning[:100]}")
    return {**state, "next_worker": decision.next_worker}

# ── Worker Nodes ──────────────────────────────────────────────────────────────
def make_worker(specialty: str, system_prompt: str):
    def worker_node(state: MDTState) -> MDTState:
        console.print(f"[bold magenta]\n[{specialty.upper()}] Preparing specialist report...[/bold magenta]")
        response = llm.invoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"CASE:\n{state['case_summary']}\n\n"
                                  f"Other reports received so far:\n" +
                                  "\n".join(f"[{w}]: {r[:200]}" for w, r in state["worker_reports"].items())),
        ])
        report = response.content
        console.print(f"  Report preview: {report[:150]}…")
        updated_reports = {**state["worker_reports"], specialty: report}
        return {**state, "worker_reports": updated_reports}
    worker_node.__name__ = f"{specialty}_node"
    return worker_node

cardiologist_node = make_worker("cardiologist", """You are a consultant cardiologist in a hospital MDT.
Provide a focused cardiac assessment covering: cardiac risk stratification, relevant cardiac diagnoses,
ECG findings if available, heart failure staging (if applicable), arrhythmia concerns,
and cardiology-specific recommendations. Be concise and clinically precise.""")

pharmacist_node = make_worker("pharmacist", """You are a clinical pharmacist in a hospital MDT.
Review the patient's medications for: drug-drug interactions, dose adjustments for organ impairment
(renal/hepatic), high-alert medications requiring monitoring, de-prescribing opportunities,
and any contraindicated medications given the clinical picture. List recommendations clearly.""")

radiologist_node = make_worker("radiologist", """You are a consultant radiologist in a hospital MDT.
Interpret any imaging mentioned and recommend: which imaging modalities are most diagnostic for
this case, key findings expected, contraindications to contrast or specific modalities,
and imaging urgency (stat vs routine). Provide a structured radiology input.""")

lab_analyst_node = make_worker("lab_analyst", """You are a clinical laboratory specialist in a hospital MDT.
Interpret available lab results and: identify critical values, explain trend significance,
recommend additional targeted labs, interpret biomarkers in clinical context (BNP, troponin,
lactate, procalcitonin), and flag any lab-guided treatment adjustments.""")

# ── Synthesis Node ────────────────────────────────────────────────────────────
SYNTHESIS_SYSTEM = """You are the attending physician synthesizing a multidisciplinary care plan.
Using all specialist reports, write a comprehensive, prioritized care plan including:
1. Integrated Problem List (ranked by acuity)
2. Immediate Actions (next 2 hours)
3. Short-term Plan (24-48 hours)
4. Medications changes (with rationale)
5. Monitoring parameters
6. Escalation criteria
7. Anticipated discharge criteria"""

def synthesis_node(state: MDTState) -> MDTState:
    console.print("[bold green]\n[SYNTHESIS] Generating unified care plan...[/bold green]")
    all_reports = "\n\n".join(
        f"═══ {w.upper()} REPORT ═══\n{r}" for w, r in state["worker_reports"].items()
    )
    response = llm.invoke([
        SystemMessage(content=SYNTHESIS_SYSTEM),
        HumanMessage(content=f"PATIENT CASE:\n{state['case_summary']}\n\n{all_reports}"),
    ])
    return {**state, "final_care_plan": response.content}

# ── Router Function ───────────────────────────────────────────────────────────
def route_to_worker(state: MDTState) -> str:
    w = state["next_worker"]
    if w == "FINISH":
        return "synthesis"
    if w in WORKERS:
        return w
    return "synthesis"

# ── Graph ─────────────────────────────────────────────────────────────────────
graph = StateGraph(MDTState)
graph.add_node("supervisor",   supervisor_node)
graph.add_node("cardiologist", cardiologist_node)
graph.add_node("pharmacist",   pharmacist_node)
graph.add_node("radiologist",  radiologist_node)
graph.add_node("lab_analyst",  lab_analyst_node)
graph.add_node("synthesis",    synthesis_node)

graph.add_edge(START, "supervisor")
graph.add_conditional_edges("supervisor", route_to_worker, {
    "cardiologist": "cardiologist",
    "pharmacist":   "pharmacist",
    "radiologist":  "radiologist",
    "lab_analyst":  "lab_analyst",
    "synthesis":    "synthesis",
})
# All workers return to supervisor for next routing decision
for w in WORKERS:
    graph.add_edge(w, "supervisor")
graph.add_edge("synthesis", END)
app = graph.compile()

# ── Demo ──────────────────────────────────────────────────────────────────────
def main():
    console.print(Panel.fit("[bold cyan]Supervisor-Worker Pattern — MDT Care Coordination[/bold cyan]", border_style="cyan"))

    case = """
    PATIENT CASE FOR MDT REVIEW:
    Patient: Mr. Amir Hassan, 74M, MRN 990011
    Admitted: Today, via ED

    Presenting complaint: Acute shortness of breath and bilateral leg swelling × 3 days.
    Chest pain: mild, non-radiating. No fever.

    PMH: Hypertension, Type 2 DM, CKD Stage 3a (eGFR 45), Atrial fibrillation (on warfarin),
    Prior MI (2019, stented LAD).

    Medications: Warfarin 5mg, Bisoprolol 5mg, Furosemide 40mg, Amlodipine 5mg,
    Metformin 500mg, Atorvastatin 40mg.
    Allergies: ACE inhibitors (angioedema).

    Vitals: BP 158/96, HR 102 (irregular), RR 24, SpO2 88% on RA → 94% on 4L O2, Temp 37.0°C.

    Exam: JVP elevated 5cm above clavicle. Bilateral crackles to mid zones. 3+ pitting edema to knees.
    S3 gallop heard. No focal neuro deficits.

    Labs: BNP 1840 pg/mL (high), Troponin 0.08 (mildly elevated), Creatinine 2.4 (up from 1.6 baseline),
    eGFR 26, K+ 5.6, INR 3.8 (supratherapeutic), HbA1c 8.9%.
    CXR: Bilateral pulmonary infiltrates, cardiomegaly, Kerley B lines.

    Impression: Acute decompensated heart failure with AKI. Rule out new MI.
    """

    result = app.invoke({
        "messages":        [],
        "case_summary":    case,
        "worker_reports":  {},
        "next_worker":     "",
        "final_care_plan": "",
    })

    console.print("\n[bold]─── Worker Reports Collected ───[/bold]")
    for worker, report in result["worker_reports"].items():
        console.print(f"[cyan]{worker.upper()}[/cyan]: {report[:120]}…\n")

    console.print(Panel(
        result["final_care_plan"],
        title="[bold green]MDT Integrated Care Plan[/bold green]",
        border_style="green",
    ))

if __name__ == "__main__":
    main()
