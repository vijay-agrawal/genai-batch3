import os
from pathlib import Path
from dotenv import load_dotenv
from rich import print

from langchain_core.tools import tool
from langchain_core.messages import SystemMessage
from langchain_openai import AzureChatOpenAI

from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.prebuilt import ToolNode

# ── Load env ─────────────────────────────────────────────
load_dotenv(Path(__file__).parent.parent / ".env")

# Demonstrates Chain of Thought (CoT) reasoning with tool calls in a LangGraph agent, 
# using AzureChatOpenAI as the model and simple tools for weather and pollen information. The graph routes between the model and tools based on whether the model's response includes tool calls, allowing for a dynamic flow of reasoning and action.

# ── Model ────────────────────────────────────────────────
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
        or os.getenv("AZURE_OPENAI_MODEL_NAME"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    temperature=0,
)

# ── Tools ────────────────────────────────────────────────
@tool
def get_weather(city: str) -> str:
    """Get current weather conditions for a city."""
    samples = {
        "mumbai": "Mumbai weather: 31°C, humid, light breeze, no rain right now.",
        "pune": "Pune weather: 29°C, dry, mild breeze.",
    }
    return samples.get(city.lower(), f"{city} weather: 30°C, moderate conditions.")

@tool
def get_pollen_index(city: str) -> str:
    """Get current pollen/allergy conditions for a city."""
    samples = {
        "mumbai": "Mumbai pollen: High tree pollen today.",
        "pune": "Pune pollen: Moderate pollen today.",
    }
    return samples.get(city.lower(), f"{city} pollen: Moderate pollen today.")

tools = [get_weather, get_pollen_index]
model_with_tools = llm.bind_tools(tools)

# ── Nodes ────────────────────────────────────────────────
def call_model(state: MessagesState):
    response = model_with_tools.invoke(
        [
            SystemMessage(
                content=(
                    "You are a helpful assistant advising whether someone should go outside. "
                    "Use tools when helpful. If the question mentions allergies, you may want "
                    "to check pollen in addition to weather. Be concise and practical."
                )
            )
        ] + state["messages"]
    )
    return {"messages": [response]}

tool_node = ToolNode(tools)

# ── Routing ──────────────────────────────────────────────
def should_continue(state: MessagesState):
    last_message = state["messages"][-1]
    if last_message.tool_calls:
        return "tools"
    return END

# ── Build graph ──────────────────────────────────────────
builder = StateGraph(MessagesState)
builder.add_node("model", call_model)
builder.add_node("tools", tool_node)

builder.add_edge(START, "model")
builder.add_conditional_edges(
    "model",
    should_continue,
    {
        "tools": "tools",
        END: END,
    },
)
builder.add_edge("tools", "model")

graph = builder.compile()

# ── Trace printing ───────────────────────────────────────
def print_loose_trace(events):
    print("\n[bold cyan]Weather + Allergy Agentic Demo[/bold cyan]\n")

    step_num = 0
    for event in events:
        for _, value in event.items():
            msgs = value.get("messages", [])
            for msg in msgs:
                msg_type = getattr(msg, "type", "").lower()

                if msg_type == "human":
                    print(f"[HUMAN] {msg.content}\n")

                elif msg_type == "ai":
                    tool_calls = getattr(msg, "tool_calls", None)
                    if tool_calls:
                        for tc in tool_calls:
                            step_num += 1
                            print(
                                f"[STEP {step_num}] Model chose {tc['name']} "
                                f"with args={tc.get('args', {})}"
                            )
                    elif msg.content:
                        print(f"\n[FINAL ANSWER] {msg.content}")

                elif msg_type == "tool":
                    tool_name = getattr(msg, "name", "tool")
                    print(f"          ↳ {tool_name} returned: {msg.content}\n")

if __name__ == "__main__":
    user_query = "Should I go for a morning run in Mumbai? I have mild pollen allergy."

    events = graph.stream(
        {"messages": [("user", user_query)]},
        stream_mode="updates",
    )

    print_loose_trace(events)