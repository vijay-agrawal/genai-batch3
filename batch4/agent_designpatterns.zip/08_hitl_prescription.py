"""
================================================================================
PATTERN: Human in the Loop (HITL)
================================================================================

WHAT IT IS:
  Human in the Loop places a human decision point INSIDE the agent graph.
  The graph pauses mid-execution, presents information to a human,
  waits for their input, then resumes with the human's decision incorporated.

  LangGraph implements HITL via:
  1. interrupt() — suspends the current node, serializes state to checkpointer,
     returns control to the caller with the graph in a "paused" state
  2. MemorySaver / checkpointer — persists the paused graph state so it can
     be resumed later (even across process restarts)
  3. Command(resume=value) — resumes execution, passing the human's input
     back into the interrupted node as the return value of interrupt()

WHY IT MATTERS:
  Fully autonomous agents are unacceptable for high-stakes decisions
  (prescriptions, surgeries, financial transactions).
  HITL provides the safety valve: AI handles the cognitive heavy lifting
  (aggregating data, checking guidelines, generating options), while a
  human retains final decision authority. The key insight is that AI and
  human each do what they're best at.

AUDIT TRAIL:
  Every interrupt/resume is recorded in the checkpointer, creating an
  immutable audit log of: what AI recommended, when, and what the human
  decided — essential for regulatory compliance in healthcare.

GRAPH STRUCTURE:
  [START] → [ai_analysis] → [prepare_review] → [human_review ← INTERRUPT]
                                                     ↓ (human resumes with decision)
                                               [process_decision] → [generate_order] → [END]

HEALTHCARE USE CASE:
  High-Risk Medication Prescription Workflow.
  AI analyzes patient data and generates a prescription recommendation.
  The graph pauses for physician review — the physician sees the AI's
  reasoning, risk flags, and proposed order. They approve, reject, or
  modify. The graph resumes and either completes the order or documents
  the rejection. Full audit trail maintained.
================================================================================
"""

import os
from typing import TypedDict, Literal, Optional
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from pydantic import BaseModel, Field

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import AzureChatOpenAI
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import interrupt, Command

load_dotenv()
console = Console()

llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0,
)

# ── Structured Outputs ────────────────────────────────────────────────────────
class PrescriptionRecommendation(BaseModel):
    drug_name: str
    dose: str
    route: str
    frequency: str
    duration: str
    indication: str
    risk_flags: list[str] = Field(description="Safety concerns the physician must review")
    alternatives: list[str] = Field(description="Alternative options if primary is rejected")
    monitoring_parameters: list[str]
    guideline_reference: str

class HumanDecision(BaseModel):
    decision: Literal["approved", "rejected", "modified"]
    modification: Optional[str] = None
    physician_notes: Optional[str] = None

# ── State ─────────────────────────────────────────────────────────────────────
class PrescriptionState(TypedDict):
    patient_case: str
    ai_analysis: str
    recommendation: dict               # PrescriptionRecommendation as dict
    human_decision: dict               # HumanDecision as dict
    final_order: str
    order_status: str                  # "pending" | "approved" | "rejected"
    audit_log: list[str]

# ── Nodes ─────────────────────────────────────────────────────────────────────
AI_ANALYSIS_SYSTEM = """You are a clinical decision support AI assisting physicians with
complex prescribing decisions. Your role is to:
1. Analyze the patient case comprehensively
2. Apply evidence-based prescribing guidelines
3. Check for contraindications, drug interactions, dose adjustments
4. Generate a prescription recommendation WITH transparent risk flagging

You do NOT prescribe — you RECOMMEND. A physician must review and approve.
Always flag every risk, no matter how small. Your job is to inform, not to reassure."""

def ai_analysis_node(state: PrescriptionState) -> PrescriptionState:
    console.print("[bold blue]\n[AI] Analyzing patient case and generating recommendation...[/bold blue]")

    rec_llm = llm.with_structured_output(PrescriptionRecommendation)
    rec: PrescriptionRecommendation = rec_llm.invoke([
        SystemMessage(content=AI_ANALYSIS_SYSTEM),
        HumanMessage(content=f"PATIENT CASE:\n{state['patient_case']}\n\nGenerate a prescription recommendation."),
    ])

    analysis_llm = llm
    analysis = analysis_llm.invoke([
        SystemMessage(content="Summarize the clinical reasoning behind this prescription in 3-4 sentences for a physician reviewer."),
        HumanMessage(content=f"Case: {state['patient_case']}\nRecommendation: {rec.model_dump()}"),
    ])

    audit_entry = f"AI analysis completed at step 1. Drug: {rec.drug_name} {rec.dose}."
    return {
        **state,
        "ai_analysis":    analysis.content,
        "recommendation": rec.model_dump(),
        "audit_log":      state["audit_log"] + [audit_entry],
    }

def prepare_review_node(state: PrescriptionState) -> PrescriptionState:
    """Format the recommendation for human review display."""
    rec = state["recommendation"]

    review_display = f"""
╔══════════════════════════════════════════════════════════════╗
║          AI PRESCRIPTION RECOMMENDATION — PENDING REVIEW          ║
╠══════════════════════════════════════════════════════════════╣
║ Drug:       {rec['drug_name']} {rec['dose']} {rec['route']} {rec['frequency']}
║ Duration:   {rec['duration']}
║ Indication: {rec['indication']}
╠══════════════════════════════════════════════════════════════╣
║ CLINICAL REASONING:
║ {state['ai_analysis'][:200]}
╠══════════════════════════════════════════════════════════════╣
║ ⚠  RISK FLAGS (must review):
""" + "\n".join(f"║   • {flag}" for flag in rec['risk_flags']) + f"""
╠══════════════════════════════════════════════════════════════╣
║ Alternatives: {', '.join(rec['alternatives'])}
║ Monitor:      {', '.join(rec['monitoring_parameters'][:3])}
║ Guideline:    {rec['guideline_reference']}
╚══════════════════════════════════════════════════════════════╝
"""
    return {**state, "order_status": "pending", "audit_log": state["audit_log"] + ["Review package prepared."]}

def human_review_node(state: PrescriptionState) -> PrescriptionState:
    """
    INTERRUPT POINT — graph pauses here, waiting for physician input.
    The interrupt() call:
      1. Serializes the full graph state to the checkpointer
      2. Raises a GraphInterrupt exception that bubbles up to the caller
      3. Returns the payload to whoever called app.stream() / app.invoke()
    The graph resumes when app.invoke(Command(resume=decision)) is called.
    """
    rec = state["recommendation"]

    # Display review panel to the physician
    console.print(Panel(
        f"[bold]Drug:[/bold] {rec['drug_name']} {rec['dose']} {rec['route']} {rec['frequency']}\n"
        f"[bold]Duration:[/bold] {rec['duration']}\n"
        f"[bold]Indication:[/bold] {rec['indication']}\n\n"
        f"[bold yellow]RISK FLAGS:[/bold yellow]\n" +
        "\n".join(f"  ⚠ {f}" for f in rec['risk_flags']) +
        f"\n\n[bold]AI Reasoning:[/bold]\n{state['ai_analysis'][:300]}",
        title="[bold red]⚕ PHYSICIAN REVIEW REQUIRED[/bold red]",
        border_style="red",
    ))

    # ← THIS IS THE INTERRUPT — graph pauses and waits for human input
    physician_response = interrupt({
        "action_required": "physician_prescription_review",
        "recommendation": rec,
        "risk_flags": rec["risk_flags"],
        "prompt": "Enter your decision: 'approve', 'reject', or 'modify: <changes>'",
    })

    # Execution resumes here after Command(resume=physician_response) is called
    decision_str = str(physician_response).lower().strip()

    if decision_str.startswith("approve"):
        decision = HumanDecision(decision="approved", physician_notes=decision_str)
    elif decision_str.startswith("reject"):
        decision = HumanDecision(decision="rejected", physician_notes=decision_str)
    elif decision_str.startswith("modify"):
        modification = decision_str.replace("modify:", "").replace("modify", "").strip()
        decision = HumanDecision(decision="modified", modification=modification)
    else:
        decision = HumanDecision(decision="approved", physician_notes=f"Approved with note: {decision_str}")

    return {
        **state,
        "human_decision": decision.model_dump(),
        "audit_log": state["audit_log"] + [
            f"Physician decision recorded: {decision.decision}. "
            f"Notes: {decision.physician_notes or decision.modification}"
        ],
    }

def process_decision_node(state: PrescriptionState) -> PrescriptionState:
    """Generate final order based on physician decision."""
    console.print("[bold green]\n[ORDER] Processing physician decision...[/bold green]")
    decision = state["human_decision"]
    rec      = state["recommendation"]

    if decision["decision"] == "rejected":
        order = (
            f"PRESCRIPTION REJECTED by physician.\n"
            f"Proposed: {rec['drug_name']} {rec['dose']}.\n"
            f"Reason: {decision.get('physician_notes', 'No reason given')}.\n"
            f"No order placed. Consider alternatives: {', '.join(rec['alternatives'])}."
        )
        status = "rejected"
    elif decision["decision"] == "modified":
        modification = decision.get("modification", "")
        order_response = llm.invoke([
            SystemMessage(content="Generate a formal prescription order incorporating the physician modification."),
            HumanMessage(content=f"Original recommendation:\n{rec}\n\nPhysician modification: {modification}"),
        ])
        order = f"MODIFIED PRESCRIPTION ORDER:\n{order_response.content}"
        status = "approved"
    else:
        order = (
            f"APPROVED PRESCRIPTION ORDER\n"
            f"{'='*50}\n"
            f"Patient: [From case]\n"
            f"Drug: {rec['drug_name']}\n"
            f"Dose: {rec['dose']}\n"
            f"Route: {rec['route']}\n"
            f"Frequency: {rec['frequency']}\n"
            f"Duration: {rec['duration']}\n"
            f"Indication: {rec['indication']}\n"
            f"Monitoring: {', '.join(rec['monitoring_parameters'])}\n"
            f"Physician approved. AI review completed.\n"
            f"{'='*50}"
        )
        status = "approved"

    return {
        **state,
        "final_order":  order,
        "order_status": status,
        "audit_log":    state["audit_log"] + [f"Order {status}. Final order generated."],
    }

# ── Graph ─────────────────────────────────────────────────────────────────────
checkpointer = MemorySaver()
graph = StateGraph(PrescriptionState)
graph.add_node("ai_analysis",    ai_analysis_node)
graph.add_node("prepare_review", prepare_review_node)
graph.add_node("human_review",   human_review_node)
graph.add_node("process",        process_decision_node)
graph.add_edge(START,            "ai_analysis")
graph.add_edge("ai_analysis",    "prepare_review")
graph.add_edge("prepare_review", "human_review")
graph.add_edge("human_review",   "process")
graph.add_edge("process",        END)
app = graph.compile(checkpointer=checkpointer)

# ── Demo ──────────────────────────────────────────────────────────────────────
def main():
    console.print(Panel.fit(
        "[bold cyan]Human-in-the-Loop Pattern — Prescription Approval[/bold cyan]",
        border_style="cyan"
    ))

    patient_case = """
    Patient: Ms. Fatima Al-Rashidi, 58F, MRN 774422
    Current visit: Admitted for acute exacerbation of heart failure.

    PMH: Heart failure (EF 35%, HFrEF), Type 2 DM, CKD Stage 3b (eGFR 38),
    Hypertension, Prior DVT (2023).

    Current Meds: Furosemide 40mg QD, Carvedilol 12.5mg BID, Spironolactone 25mg QD,
    Metformin 500mg BID, Insulin Glargine 18 units QHS, Rivaroxaban 20mg QD.

    Presentation: Worsening dyspnea, 6 kg weight gain over 5 days, JVP elevated,
    bilateral crackles, 3+ pitting edema. BNP 2800 pg/mL. Creatinine 2.1 (baseline 1.7).
    K+ 5.2 mEq/L. BP 162/98. HR 88 (regular).

    Clinical question: Patient needs IV diuresis. Generate prescription recommendation
    for IV furosemide dosing for this acutely decompensated HF patient with CKD.
    """

    config = {"configurable": {"thread_id": "rx-774422-20260422"}}

    initial_state = {
        "patient_case":   patient_case,
        "ai_analysis":    "",
        "recommendation": {},
        "human_decision": {},
        "final_order":    "",
        "order_status":   "pending",
        "audit_log":      [],
    }

    console.print("\n[bold]Phase 1: Running graph until human review is needed...[/bold]\n")

    # Run the graph. It will pause at interrupt().
    app.invoke(initial_state, config=config)

    console.print("\n[bold yellow]⏸ GRAPH PAUSED — Human decision required[/bold yellow]\n")

    console.print("[bold]Enter one of:[/bold]")
    console.print("  [green]approve[/green]")
    console.print("  [red]reject[/red]")
    console.print("  [blue]modify: <changes>[/blue]\n")

    user_input = Prompt.ask(
        "[bold yellow]Your decision[/bold yellow]",
        default="modify: reduce initial dose to 80mg IV given CKD, recheck Cr and K+ in 4h before repeat dosing"
    )

    console.print("\n[bold]Phase 2: Resuming graph with human input...[/bold]\n")

    final_result = app.invoke(Command(resume=user_input), config=config)

    console.print(Panel(
        final_result["final_order"],
        title=f"[bold green]Final Order — Status: {final_result['order_status'].upper()}[/bold green]",
        border_style="green",
    ))

    console.print("\n[bold]Audit Trail:[/bold]")
    for i, entry in enumerate(final_result["audit_log"], 1):
        console.print(f"  [{i}] {entry}")

if __name__ == "__main__":
    main()
