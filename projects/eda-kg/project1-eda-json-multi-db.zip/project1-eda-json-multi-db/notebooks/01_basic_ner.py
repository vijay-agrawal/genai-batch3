"""
01_basic_ner.py - Introduction to Named Entity Recognition (NER)

This script introduces basic NER using spaCy and demonstrates why 
domain-specific models matter for medical text extraction.

Learning Goals:
- Understand what NER does
- Compare general vs. medical NER models
- See the limitations of general models on clinical text
"""

import spacy
import json
from pathlib import Path

# ============================================================================
# STEP 1: Load the sample clinical notes
# ============================================================================

def load_clinical_notes():
    """Load sample clinical notes from JSON file"""
    data_path = Path("data/sample_notes.json")
    
    with open(data_path, 'r') as f:
        data = json.load(f)
    
    return data['patients']


# ============================================================================
# STEP 2: Basic NER with General spaCy Model
# ============================================================================

def basic_ner_demo():
    """
    Demonstrate basic NER using the general English model.
    This shows what entities spaCy can recognize out-of-the-box.
    """
    
    print("=" * 80)
    print("STEP 2: Basic NER with General English Model (en_core_web_sm)")
    print("=" * 80)
    
    # Load the general English model
    # This model is trained on general text (news, web, etc.)
    nlp = spacy.load("en_core_web_sm")
    
    # Get our sample notes
    patients = load_clinical_notes()
    
    # Let's analyze the first patient's note
    patient = patients[0]
    text = patient['clinical_note']
    
    print(f"\nPatient ID: {patient['patient_id']}")
    print(f"Clinical Note:\n{text[:200]}...\n")
    
    # Process the text with spaCy
    doc = nlp(text)
    
    # Extract entities
    print("Entities found by general model:")
    print("-" * 80)
    
    for ent in doc.ents:
        print(f"Text: '{ent.text:30}' | Label: {ent.label_:15} | Confidence: N/A")
    
    # OBSERVATION: The general model finds some entities like CARDINAL (numbers),
    # DATE, and QUANTITY, but it misses most medical terms!
    # It doesn't recognize "hypertension", "diabetes", "metoprolol" etc.
    
    print("\n" + "=" * 80)
    print("ANALYSIS: Why does the general model miss medical entities?")
    print("=" * 80)
    print("""
The general spaCy model (en_core_web_sm) is trained on general domain text:
- News articles
- Web pages  
- General conversation

It's NOT trained on medical text, so it doesn't know:
- Disease names (hypertension, diabetes, COPD)
- Medication names (metoprolol, metformin, aspirin)
- Medical procedures (ECG, stress test, MRI)
- Medical abbreviations (BID, PRN, HTN)

This is why we need DOMAIN-SPECIFIC models for healthcare!
    """)
    
    return doc


# ============================================================================
# STEP 3: Medical NER with SciSpacy Model
# ============================================================================

def medical_ner_demo():
    """
    Demonstrate NER using a medical-domain model (SciSpacy).
    This shows significant improvement in medical entity recognition.
    """
    
    print("\n" + "=" * 80)
    print("STEP 3: Medical NER with SciSpacy Model (en_core_sci_sm)")
    print("=" * 80)
    
    # Load the medical/scientific model
    # This model is trained on biomedical literature
    try:
        nlp_sci = spacy.load("en_core_sci_sm")
    except OSError:
        print("\nERROR: Medical model not found!")
        print("Please install it with:")
        print("pip install https://s3-us-west-2.amazonaws.com/ai2-s2-scispacy/releases/v0.5.4/en_core_sci_sm-0.5.4.tar.gz")
        return None
    
    # Get our sample notes
    patients = load_clinical_notes()
    patient = patients[0]
    text = patient['clinical_note']
    
    print(f"\nPatient ID: {patient['patient_id']}")
    print(f"Analyzing same clinical note with medical model...\n")
    
    # Process with medical model
    doc_sci = nlp_sci(text)
    
    # Extract entities
    print("Entities found by medical model:")
    print("-" * 80)
    
    for ent in doc_sci.ents:
        print(f"Text: '{ent.text:30}' | Label: {ent.label_:15}")
    
    print("\n" + "=" * 80)
    print("COMPARISON: General vs Medical Model")
    print("=" * 80)
    print("""
The medical model (en_core_sci_sm) does MUCH better:
✓ Recognizes disease names (hypertension, diabetes, ischemia)
✓ Identifies medications (aspirin, metoprolol, metformin)
✓ Catches medical procedures and tests (ECG, stress test)
✓ Understands clinical context better

However, even medical NER models have limitations:
✗ May miss rare diseases or new medications
✗ Struggles with abbreviations (HTN, BID, PRN)
✗ Doesn't always disambiguate (e.g., "cold" = illness or temperature?)
✗ Doesn't link entities to standard terminologies (ICD-10, SNOMED)

This is why we'll add dictionary-based matching in the next script!
    """)
    
    return doc_sci


# ============================================================================
# STEP 4: Entity Analysis Helper Functions
# ============================================================================

def analyze_entity_types(doc):
    """
    Analyze what types of entities were found and their frequencies.
    This helps us understand what the model is good/bad at.
    """
    
    from collections import Counter
    
    # Count entity types
    entity_types = Counter([ent.label_ for ent in doc.ents])
    
    print("\nEntity Type Distribution:")
    print("-" * 50)
    for entity_type, count in entity_types.most_common():
        print(f"{entity_type:20} : {count:3} occurrences")
    
    return entity_types


def extract_potential_medical_terms(doc):
    """
    Extract noun chunks that might be medical terms even if not 
    recognized by NER. This shows what we're missing.
    """
    
    print("\nPotential Medical Terms (from noun chunks):")
    print("-" * 50)
    
    medical_chunks = []
    for chunk in doc.noun_chunks:
        # Simple heuristic: look for multi-word medical-sounding phrases
        if len(chunk.text.split()) > 1 and chunk.text.lower() not in [
            'the patient', 'no history', 'last month', 'next week'
        ]:
            medical_chunks.append(chunk.text)
            print(f"  - {chunk.text}")
    
    print(f"\nFound {len(medical_chunks)} potential medical noun phrases")
    print("Many of these should be recognized as entities!")
    
    return medical_chunks


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """
    Run the complete NER demonstration comparing general and medical models.
    """
    
    print("\n" + "=" * 80)
    print(" CLINICAL NOTES NER - PART 1: Why Domain Models Matter")
    print("=" * 80)
    
    # Step 1: Show what general NER finds (not much!)
    doc_general = basic_ner_demo()
    
    # Step 2: Show what medical NER finds (much better!)
    doc_medical = medical_ner_demo()
    
    if doc_medical:
        # Step 3: Analyze what we found
        print("\n" + "=" * 80)
        print("DETAILED ANALYSIS")
        print("=" * 80)
        
        analyze_entity_types(doc_medical)
        extract_potential_medical_terms(doc_medical)
    
    print("\n" + "=" * 80)
    print("KEY TAKEAWAYS")
    print("=" * 80)
    print("""
1. General NER models miss most medical entities
2. Domain-specific models (like SciSpacy) perform much better
3. Even medical models have gaps - need additional strategies
4. Next steps: Dictionary/terminology-driven extraction (next script!)

NEXT: Run 02_dictionary_ner.py to add dictionary-based entity matching
    """)
    
    print("\n" + "=" * 80)
    print("EXERCISE FOR YOU")
    print("=" * 80)
    print("""
Try the following:
1. Run this script and examine the output carefully
2. Look at the clinical notes in data/sample_notes.json
3. Identify medical terms that the model MISSED
4. Think about how a dictionary could help catch these terms

When ready, move on to 02_dictionary_ner.py!
    """)


if __name__ == "__main__":
    main()
