"""
03_entity_linking.py - Entity Linking Strategies

This script demonstrates different strategies for linking extracted entities
to standardized medical terminologies. This is crucial for creating a 
knowledge graph where entities are properly normalized.

Learning Goals:
- Exact matching (codes, canonical names)
- Fuzzy matching (handle typos, variations)
- Semantic matching (embeddings for similarity)
- Negation detection (critical in clinical text!)
- Confidence scoring and thresholding
"""

import spacy
from spacy.matcher import PhraseMatcher
import json
from pathlib import Path
from rapidfuzz import fuzz, process
from sentence_transformers import SentenceTransformer
import numpy as np
from collections import defaultdict

# ============================================================================
# STEP 1: Load Resources
# ============================================================================

def load_resources():
    """Load clinical notes and medical terminologies"""
    
    with open("data/sample_notes.json", 'r') as f:
        patients_data = json.load(f)
    
    with open("data/medical_terminologies.json", 'r') as f:
        terminologies = json.load(f)
    
    return patients_data['patients'], terminologies


# ============================================================================
# STEP 2: Exact Matching
# ============================================================================

class ExactMatcher:
    """
    Exact matching: Find entities that exactly match standard terminologies.
    This is the fastest and most precise method.
    """
    
    def __init__(self, terminologies):
        self.terminologies = terminologies
        
        # Build lookup tables for fast exact matching
        self._build_lookups()
    
    def _build_lookups(self):
        """Create hash tables for O(1) lookup"""
        
        # Disease lookup by name, code, and synonyms
        self.disease_by_name = {}
        self.disease_by_code = {}
        
        for disease in self.terminologies['diseases']:
            canonical = disease['canonical_name'].lower()
            
            # Index by canonical name
            self.disease_by_name[canonical] = disease
            
            # Index by ICD-10 code
            self.disease_by_code[disease['icd10_code']] = disease
            
            # Index by synonyms
            for synonym in disease['synonyms']:
                self.disease_by_name[synonym.lower()] = disease
        
        # Medication lookup
        self.medication_by_name = {}
        self.medication_by_code = {}
        
        for med in self.terminologies['medications']:
            generic = med['generic_name'].lower()
            
            # Index by generic name
            self.medication_by_name[generic] = med
            
            # Index by RxNorm code
            self.medication_by_code[med['rxnorm_code']] = med
            
            # Index by brand names
            for brand in med['brand_names']:
                self.medication_by_name[brand.lower()] = med
        
        print(f"✓ Exact matcher initialized:")
        print(f"  - {len(self.disease_by_name)} disease terms")
        print(f"  - {len(self.medication_by_name)} medication terms")
    
    def link(self, entity_text):
        """
        Try to find an exact match for the entity.
        
        Args:
            entity_text: String to match
            
        Returns:
            Matched entity info or None
        """
        text_lower = entity_text.lower()
        
        # Try disease lookup
        if text_lower in self.disease_by_name:
            return {
                'match_type': 'exact',
                'confidence': 1.0,
                'entity_type': 'DISEASE',
                **self.disease_by_name[text_lower]
            }
        
        # Try medication lookup
        if text_lower in self.medication_by_name:
            return {
                'match_type': 'exact',
                'confidence': 1.0,
                'entity_type': 'MEDICATION',
                **self.medication_by_name[text_lower]
            }
        
        return None


# ============================================================================
# STEP 3: Fuzzy Matching
# ============================================================================

class FuzzyMatcher:
    """
    Fuzzy matching: Handle typos, misspellings, and variations.
    Uses RapidFuzz for fast string similarity.
    """
    
    def __init__(self, terminologies, threshold=80):
        """
        Args:
            terminologies: Medical terminologies dictionary
            threshold: Minimum similarity score (0-100) to consider a match
        """
        self.terminologies = terminologies
        self.threshold = threshold
        
        # Build lists of all possible terms
        self._build_term_lists()
    
    def _build_term_lists(self):
        """Create lists of all searchable terms"""
        
        self.disease_terms = []
        self.disease_lookup = {}
        
        for disease in self.terminologies['diseases']:
            # Add canonical name
            canonical = disease['canonical_name']
            self.disease_terms.append(canonical)
            self.disease_lookup[canonical] = disease
            
            # Add synonyms
            for synonym in disease['synonyms']:
                self.disease_terms.append(synonym)
                self.disease_lookup[synonym] = disease
        
        self.medication_terms = []
        self.medication_lookup = {}
        
        for med in self.terminologies['medications']:
            # Add generic name
            generic = med['generic_name']
            self.medication_terms.append(generic)
            self.medication_lookup[generic] = med
            
            # Add brand names
            for brand in med['brand_names']:
                self.medication_terms.append(brand)
                self.medication_lookup[brand] = med
        
        print(f"✓ Fuzzy matcher initialized:")
        print(f"  - Threshold: {self.threshold}")
        print(f"  - Disease terms: {len(self.disease_terms)}")
        print(f"  - Medication terms: {len(self.medication_terms)}")
    
    def link(self, entity_text):
        """
        Find the best fuzzy match for the entity.
        
        Args:
            entity_text: String to match
            
        Returns:
            Best matched entity info or None if below threshold
        """
        
        # Try matching against diseases
        disease_match = process.extractOne(
            entity_text,
            self.disease_terms,
            scorer=fuzz.ratio,
            score_cutoff=self.threshold
        )
        
        # Try matching against medications
        med_match = process.extractOne(
            entity_text,
            self.medication_terms,
            scorer=fuzz.ratio,
            score_cutoff=self.threshold
        )
        
        # Pick the best match
        best_match = None
        best_score = 0
        match_type = None
        
        if disease_match and disease_match[1] > best_score:
            best_match = disease_match
            best_score = disease_match[1]
            match_type = 'DISEASE'
        
        if med_match and med_match[1] > best_score:
            best_match = med_match
            best_score = med_match[1]
            match_type = 'MEDICATION'
        
        if best_match:
            matched_term = best_match[0]
            score = best_match[1] / 100.0  # Normalize to 0-1
            
            # Look up the full entity info
            if match_type == 'DISEASE':
                entity_info = self.disease_lookup[matched_term]
            else:
                entity_info = self.medication_lookup[matched_term]
            
            return {
                'match_type': 'fuzzy',
                'confidence': score,
                'matched_term': matched_term,
                'entity_type': match_type,
                **entity_info
            }
        
        return None


# ============================================================================
# STEP 4: Semantic Matching
# ============================================================================

class SemanticMatcher:
    """
    Semantic matching: Use embeddings to find semantically similar entities.
    This can handle paraphrases and conceptual similarities.
    """
    
    def __init__(self, terminologies, threshold=0.7):
        """
        Args:
            terminologies: Medical terminologies dictionary
            threshold: Minimum cosine similarity (0-1) to consider a match
        """
        self.terminologies = terminologies
        self.threshold = threshold
        
        # Load sentence transformer model
        print("Loading sentence embedding model...")
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # Encode all terms
        self._encode_terms()
    
    def _encode_terms(self):
        """Compute embeddings for all medical terms"""
        
        # Collect all disease terms
        self.disease_terms = []
        self.disease_lookup = {}
        
        for disease in self.terminologies['diseases']:
            canonical = disease['canonical_name']
            self.disease_terms.append(canonical)
            self.disease_lookup[canonical] = disease
            
            # Also add synonyms
            for synonym in disease['synonyms']:
                self.disease_terms.append(synonym)
                self.disease_lookup[synonym] = disease
        
        # Collect all medication terms
        self.medication_terms = []
        self.medication_lookup = {}
        
        for med in self.terminologies['medications']:
            generic = med['generic_name']
            self.medication_terms.append(generic)
            self.medication_lookup[generic] = med
        
        # Compute embeddings
        print("Computing embeddings for disease terms...")
        self.disease_embeddings = self.model.encode(
            self.disease_terms,
            show_progress_bar=False
        )
        
        print("Computing embeddings for medication terms...")
        self.medication_embeddings = self.model.encode(
            self.medication_terms,
            show_progress_bar=False
        )
        
        print(f"✓ Semantic matcher initialized:")
        print(f"  - Threshold: {self.threshold}")
        print(f"  - Disease embeddings: {len(self.disease_embeddings)}")
        print(f"  - Medication embeddings: {len(self.medication_embeddings)}")
    
    def link(self, entity_text):
        """
        Find semantically similar entities using embeddings.
        
        Args:
            entity_text: String to match
            
        Returns:
            Best semantically matched entity or None
        """
        
        # Encode the query
        query_embedding = self.model.encode([entity_text])[0]
        
        # Compute similarities with diseases
        disease_sims = np.dot(self.disease_embeddings, query_embedding)
        best_disease_idx = np.argmax(disease_sims)
        best_disease_score = disease_sims[best_disease_idx]
        
        # Compute similarities with medications
        med_sims = np.dot(self.medication_embeddings, query_embedding)
        best_med_idx = np.argmax(med_sims)
        best_med_score = med_sims[best_med_idx]
        
        # Pick the best match
        if best_disease_score > best_med_score and best_disease_score >= self.threshold:
            matched_term = self.disease_terms[best_disease_idx]
            entity_info = self.disease_lookup[matched_term]
            match_type = 'DISEASE'
            score = float(best_disease_score)
        elif best_med_score >= self.threshold:
            matched_term = self.medication_terms[best_med_idx]
            entity_info = self.medication_lookup[matched_term]
            match_type = 'MEDICATION'
            score = float(best_med_score)
        else:
            return None
        
        return {
            'match_type': 'semantic',
            'confidence': score,
            'matched_term': matched_term,
            'entity_type': match_type,
            **entity_info
        }


# ============================================================================
# STEP 5: Negation Detection
# ============================================================================

class NegationDetector:
    """
    Detect negated entities in clinical text.
    CRITICAL: "no diabetes" is very different from "diabetes"!
    """
    
    def __init__(self, nlp):
        """
        Args:
            nlp: spaCy language model with negation detection
        """
        self.nlp = nlp
        
        # Add negation patterns
        # In production, use negspacy or similar library
        self.negation_words = {
            'no', 'not', 'without', 'denies', 'absent',
            'negative', 'never', 'none', 'neither'
        }
    
    def is_negated(self, entity_span, doc):
        """
        Check if an entity is negated in context.
        
        Args:
            entity_span: spaCy Span object
            doc: spaCy Doc object
            
        Returns:
            bool: True if entity is negated
        """
        
        # Simple rule: check for negation words in window before entity
        window_size = 5  # words before entity
        start_idx = max(0, entity_span.start - window_size)
        
        # Check tokens before the entity
        for i in range(start_idx, entity_span.start):
            token = doc[i]
            if token.text.lower() in self.negation_words:
                return True
        
        return False


# ============================================================================
# STEP 6: Unified Entity Linker
# ============================================================================

class UnifiedEntityLinker:
    """
    Combines all linking strategies with a waterfall approach:
    1. Try exact matching first (fastest, most confident)
    2. If no exact match, try fuzzy matching
    3. If still no match, try semantic matching
    4. Check for negation
    """
    
    def __init__(self, terminologies, nlp):
        self.exact_matcher = ExactMatcher(terminologies)
        self.fuzzy_matcher = FuzzyMatcher(terminologies, threshold=80)
        self.semantic_matcher = SemanticMatcher(terminologies, threshold=0.7)
        self.negation_detector = NegationDetector(nlp)
        
        print("\n✓ Unified entity linker ready!")
    
    def link_entity(self, entity_text, entity_span, doc):
        """
        Link an entity using waterfall strategy.
        
        Args:
            entity_text: Text of the entity
            entity_span: spaCy Span object
            doc: spaCy Doc object
            
        Returns:
            Linked entity info with confidence and negation status
        """
        
        # Try exact match first
        result = self.exact_matcher.link(entity_text)
        
        # If no exact match, try fuzzy
        if not result:
            result = self.fuzzy_matcher.link(entity_text)
        
        # If still no match, try semantic
        if not result:
            result = self.semantic_matcher.link(entity_text)
        
        # If we found a match, check for negation
        if result:
            is_negated = self.negation_detector.is_negated(entity_span, doc)
            result['is_negated'] = is_negated
            result['original_text'] = entity_text
            
            # Reduce confidence if negated (still important to capture!)
            if is_negated:
                result['confidence'] *= 0.9  # Slight reduction
        
        return result


# ============================================================================
# STEP 7: Demonstration
# ============================================================================

def demo_entity_linking():
    """
    Demonstrate entity linking with various test cases.
    """
    
    print("\n" + "=" * 80)
    print(" ENTITY LINKING DEMONSTRATION")
    print("=" * 80)
    
    # Load resources
    patients, terminologies = load_resources()
    nlp = spacy.load("en_core_web_sm")
    
    # Create unified linker
    print("\nInitializing entity linker...")
    linker = UnifiedEntityLinker(terminologies, nlp)
    
    # Test cases showing different matching strategies
    test_cases = [
        "hypertension",           # Exact match
        "diabetis",              # Fuzzy match (typo)
        "high blood pressure",   # Semantic match
        "no diabetes",           # Negation
        "HTN",                   # Abbreviation
    ]
    
    print("\n" + "=" * 80)
    print("TEST CASES - Different Matching Strategies")
    print("=" * 80)
    
    for test_text in test_cases:
        doc = nlp(test_text)
        # Treat whole text as entity for demo
        span = doc[:]
        
        result = linker.link_entity(test_text, span, doc)
        
        print(f"\nInput: '{test_text}'")
        if result:
            print(f"  Match Type: {result['match_type']}")
            print(f"  Entity Type: {result['entity_type']}")
            print(f"  Canonical: {result.get('canonical_name') or result.get('generic_name')}")
            print(f"  Confidence: {result['confidence']:.2f}")
            print(f"  Negated: {result.get('is_negated', False)}")
            if result['match_type'] != 'exact':
                print(f"  Matched to: {result.get('matched_term')}")
        else:
            print("  No match found")
    
    return linker


def analyze_patient_with_linking(patient, linker, nlp):
    """
    Extract and link all entities from a patient's clinical note.
    """
    
    print("\n" + "=" * 80)
    print(f"ANALYZING PATIENT: {patient['patient_id']}")
    print("=" * 80)
    print(f"\nNote: {patient['clinical_note'][:150]}...\n")
    
    doc = nlp(patient['clinical_note'])
    
    # For demo, let's use a simple approach: extract noun chunks
    # In practice, you'd use NER + dictionary matching from previous scripts
    linked_entities = []
    
    for ent in doc.ents:
        result = linker.link_entity(ent.text, ent, doc)
        if result:
            linked_entities.append(result)
    
    # Display results
    print("Linked Entities:")
    print("-" * 80)
    
    diseases = [e for e in linked_entities if e['entity_type'] == 'DISEASE']
    medications = [e for e in linked_entities if e['entity_type'] == 'MEDICATION']
    
    if diseases:
        print("\n🦠 DISEASES:")
        for entity in diseases:
            negation_marker = " ❌ [NEGATED]" if entity.get('is_negated') else " ✓"
            print(f"  {entity['original_text']}{negation_marker}")
            print(f"    → {entity['canonical_name']} ({entity['icd10_code']})")
            print(f"    Confidence: {entity['confidence']:.2f} | Method: {entity['match_type']}")
    
    if medications:
        print("\n💊 MEDICATIONS:")
        for entity in medications:
            print(f"  {entity['original_text']}")
            print(f"    → {entity['generic_name']} ({entity.get('rxnorm_code', 'N/A')})")
            print(f"    Confidence: {entity['confidence']:.2f} | Method: {entity['match_type']}")
    
    return linked_entities


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """
    Run complete entity linking demonstration.
    """
    
    print("\n" + "=" * 80)
    print(" CLINICAL NOTES NER - PART 3: Entity Linking")
    print("=" * 80)
    
    # Demo linking strategies
    linker = demo_entity_linking()
    
    # Analyze a patient
    patients, _ = load_resources()
    nlp = spacy.load("en_core_web_sm")
    
    patient = patients[0]
    linked = analyze_patient_with_linking(patient, linker, nlp)
    
    print("\n" + "=" * 80)
    print("KEY TAKEAWAYS")
    print("=" * 80)
    print("""
1. Entity Linking normalizes variations to standard terminologies
2. Three matching strategies:
   - Exact: Fastest, highest confidence (codes, canonical names)
   - Fuzzy: Handles typos and variations (RapidFuzz)
   - Semantic: Understands meaning (Sentence-Transformers)
3. Negation detection is CRITICAL in clinical text
4. Confidence scores help flag uncertain matches for review
5. Waterfall approach: Try exact → fuzzy → semantic

NEXT: Run 04_cypher_generation.py to generate the knowledge graph!
    """)
    
    print("\n" + "=" * 80)
    print("REAL-WORLD CONSIDERATIONS")
    print("=" * 80)
    print("""
- Disambiguation: "cold" (illness vs temperature), "dressing" (wound vs salad)
- Context: "Family history of diabetes" vs "Patient has diabetes"
- Temporality: Past conditions vs current conditions
- Severity: "Mild pain" vs "Severe pain"
- HITL: Flag low-confidence matches for human review

These would be addressed in a production system!
    """)


if __name__ == "__main__":
    main()
