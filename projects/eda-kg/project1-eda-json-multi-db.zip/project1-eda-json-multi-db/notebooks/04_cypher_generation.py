"""
04_cypher_generation.py - Generate Neo4j Cypher Scripts

This script brings everything together to generate Cypher scripts that
create a knowledge graph in Neo4j. We'll create nodes for patients,
diagnoses, diseases, and treatments, with relationships between them.

Learning Goals:
- Design a medical knowledge graph schema
- Generate CREATE statements for nodes
- Generate MATCH + CREATE for relationships
- Handle entity properties and metadata
- Create a complete, executable Cypher script
"""

import spacy
from spacy.matcher import PhraseMatcher
import json
from pathlib import Path
from datetime import datetime
from rapidfuzz import fuzz, process
from sentence_transformers import SentenceTransformer
import numpy as np

# Import utilities from previous scripts
import sys
sys.path.append('notebooks')

# ============================================================================
# STEP 1: Knowledge Graph Schema
# ============================================================================

SCHEMA = """
# Medical Knowledge Graph Schema

## Nodes

(Patient)
  - patient_id: string (unique identifier)
  - name: string
  - age: integer
  - gender: string
  
(Diagnosis)
  - diagnosis_id: string (generated)
  - date: date
  - is_negated: boolean
  - confidence: float
  
(Disease)
  - disease_id: string (ICD-10 or SNOMED code)
  - canonical_name: string
  - icd10_code: string
  - snomed_code: string
  - category: string
  
(Medication)
  - medication_id: string (RxNorm code)
  - generic_name: string
  - drug_class: string
  - dosage: string (extracted from text)
  
(Symptom)
  - symptom_id: string
  - name: string

## Relationships

(Patient)-[:HAS_DIAGNOSIS]->(Diagnosis)
  - Properties: confidence, extraction_method
  
(Diagnosis)-[:IS_DISEASE]->(Disease)
  - Properties: matched_text, match_type
  
(Patient)-[:PRESCRIBED]->(Medication)
  - Properties: date, dosage, frequency
  
(Patient)-[:HAS_SYMPTOM]->(Symptom)
  - Properties: date, severity

(Disease)-[:TREATED_WITH]->(Medication)
  - Properties: evidence_level
"""


# ============================================================================
# STEP 2: Cypher Script Builder
# ============================================================================

class CypherScriptBuilder:
    """
    Builds Cypher scripts for creating a medical knowledge graph.
    """
    
    def __init__(self):
        self.statements = []
        self.constraints = []
        
        # Track created entities to avoid duplicates
        self.created_diseases = set()
        self.created_medications = set()
    
    def add_constraint(self, constraint):
        """Add a uniqueness constraint"""
        self.constraints.append(constraint)
    
    def add_statement(self, statement):
        """Add a Cypher statement"""
        self.statements.append(statement)
    
    def create_patient_node(self, patient_data):
        """
        Generate CREATE statement for a Patient node.
        
        Args:
            patient_data: Dict with patient information
            
        Returns:
            Cypher CREATE statement
        """
        cypher = f"""
// Create Patient: {patient_data['name']}
CREATE (p:Patient {{
  patient_id: '{patient_data['patient_id']}',
  name: '{patient_data['name']}',
  age: {patient_data['age']},
  gender: '{patient_data['gender']}',
  date_of_visit: date('{patient_data['date_of_visit']}')
}})
"""
        self.add_statement(cypher)
        return cypher
    
    def create_disease_node(self, disease_data):
        """
        Generate CREATE statement for a Disease node (only once).
        
        Args:
            disease_data: Dict with disease information
            
        Returns:
            Cypher MERGE statement
        """
        disease_id = disease_data.get('icd10_code', disease_data.get('canonical_name', '').replace(' ', '_'))
        
        # Skip if already created
        if disease_id in self.created_diseases:
            return None
        
        self.created_diseases.add(disease_id)
        
        cypher = f"""
// Create/Merge Disease: {disease_data['canonical_name']}
MERGE (d:Disease {{disease_id: '{disease_id}'}})
ON CREATE SET
  d.canonical_name = '{disease_data['canonical_name']}',
  d.icd10_code = '{disease_data.get('icd10_code', 'N/A')}',
  d.snomed_code = '{disease_data.get('snomed_code', 'N/A')}',
  d.category = '{disease_data.get('category', 'Unknown')}'
"""
        self.add_statement(cypher)
        return cypher
    
    def create_medication_node(self, medication_data):
        """
        Generate CREATE statement for a Medication node (only once).
        
        Args:
            medication_data: Dict with medication information
            
        Returns:
            Cypher MERGE statement
        """
        med_id = medication_data.get('rxnorm_code', medication_data.get('generic_name', '').replace(' ', '_'))
        
        # Skip if already created
        if med_id in self.created_medications:
            return None
        
        self.created_medications.add(med_id)
        
        cypher = f"""
// Create/Merge Medication: {medication_data['generic_name']}
MERGE (m:Medication {{medication_id: '{med_id}'}})
ON CREATE SET
  m.generic_name = '{medication_data['generic_name']}',
  m.drug_class = '{medication_data.get('drug_class', 'Unknown')}',
  m.rxnorm_code = '{medication_data.get('rxnorm_code', 'N/A')}'
"""
        self.add_statement(cypher)
        return cypher
    
    def create_diagnosis_relationship(self, patient_id, disease_data, metadata):
        """
        Create a diagnosis relationship between patient and disease.
        
        Args:
            patient_id: Patient identifier
            disease_data: Disease information
            metadata: Extraction metadata (confidence, negation, etc.)
        """
        disease_id = disease_data.get('icd10_code', disease_data.get('canonical_name', '').replace(' ', '_'))
        
        is_negated = metadata.get('is_negated', False)
        confidence = metadata.get('confidence', 0.0)
        match_type = metadata.get('match_type', 'unknown')
        original_text = metadata.get('original_text', '')
        
        cypher = f"""
// Create Diagnosis relationship
MATCH (p:Patient {{patient_id: '{patient_id}'}})
MATCH (d:Disease {{disease_id: '{disease_id}'}})
CREATE (p)-[r:HAS_DIAGNOSIS]->(diag:Diagnosis)-[r2:IS_DISEASE]->(d)
SET diag.diagnosis_id = randomUUID(),
    diag.date = date('{metadata.get('date', datetime.now().strftime('%Y-%m-%d'))}'),
    diag.is_negated = {str(is_negated).lower()},
    diag.original_text = '{original_text}',
    r.confidence = {confidence:.2f},
    r.extraction_method = '{match_type}',
    r2.matched_text = '{original_text}'
"""
        self.add_statement(cypher)
        return cypher
    
    def create_prescription_relationship(self, patient_id, medication_data, metadata):
        """
        Create a prescription relationship between patient and medication.
        
        Args:
            patient_id: Patient identifier
            medication_data: Medication information
            metadata: Prescription metadata (dosage, frequency, etc.)
        """
        med_id = medication_data.get('rxnorm_code', medication_data.get('generic_name', '').replace(' ', '_'))
        
        dosage = metadata.get('dosage', 'N/A')
        frequency = metadata.get('frequency', 'N/A')
        date = metadata.get('date', datetime.now().strftime('%Y-%m-%d'))
        
        cypher = f"""
// Create Prescription relationship
MATCH (p:Patient {{patient_id: '{patient_id}'}})
MATCH (m:Medication {{medication_id: '{med_id}'}})
CREATE (p)-[r:PRESCRIBED]->(m)
SET r.date = date('{date}'),
    r.dosage = '{dosage}',
    r.frequency = '{frequency}',
    r.original_text = '{metadata.get('original_text', '')}'
"""
        self.add_statement(cypher)
        return cypher
    
    def generate_script(self):
        """
        Generate the complete Cypher script.
        
        Returns:
            Complete Cypher script as string
        """
        script_parts = []
        
        # Header
        script_parts.append("""
// ============================================================================
// Medical Knowledge Graph - Auto-generated Cypher Script
// Generated: """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + """
// ============================================================================

// Clear existing data (CAUTION: Only for demo purposes!)
MATCH (n) DETACH DELETE n;

""")
        
        # Constraints
        if self.constraints:
            script_parts.append("// Constraints\n")
            for constraint in self.constraints:
                script_parts.append(constraint + "\n")
            script_parts.append("\n")
        
        # Main statements
        script_parts.append("// Create Nodes and Relationships\n")
        for statement in self.statements:
            script_parts.append(statement)
            script_parts.append(";\n\n")
        
        return "".join(script_parts)


# ============================================================================
# STEP 3: Complete Pipeline
# ============================================================================

class EntityLinkerSimplified:
    """Simplified version of entity linker for this demo"""
    
    def __init__(self, terminologies):
        self.terminologies = terminologies
        self._build_lookups()
    
    def _build_lookups(self):
        """Build lookup tables"""
        self.disease_lookup = {}
        for disease in self.terminologies['diseases']:
            canonical = disease['canonical_name'].lower()
            self.disease_lookup[canonical] = disease
            for synonym in disease['synonyms']:
                self.disease_lookup[synonym.lower()] = disease
        
        self.med_lookup = {}
        for med in self.terminologies['medications']:
            generic = med['generic_name'].lower()
            self.med_lookup[generic] = med
            for brand in med['brand_names']:
                self.med_lookup[brand.lower()] = med
    
    def link_disease(self, text):
        """Link disease entity"""
        result = self.disease_lookup.get(text.lower())
        if result:
            return {
                'entity_type': 'DISEASE',
                'confidence': 1.0,
                'match_type': 'exact',
                'original_text': text,
                'is_negated': False,
                **result
            }
        return None
    
    def link_medication(self, text):
        """Link medication entity"""
        result = self.med_lookup.get(text.lower())
        if result:
            return {
                'entity_type': 'MEDICATION',
                'confidence': 1.0,
                'match_type': 'exact',
                'original_text': text,
                **result
            }
        return None


def extract_dosage_info(text, medication_name):
    """
    Extract dosage and frequency from text near medication mention.
    Simple regex-based extraction for demo.
    """
    import re
    
    # Look for patterns like "50mg BID" or "1000mg daily"
    dosage_pattern = r'(\d+(?:\.\d+)?)\s*(mg|mcg|g)'
    frequency_pattern = r'\b(daily|BID|TID|QID|PRN|once|twice|three times)\b'
    
    # Find dosage
    dosage_match = re.search(dosage_pattern, text, re.IGNORECASE)
    dosage = dosage_match.group(0) if dosage_match else 'N/A'
    
    # Find frequency
    freq_match = re.search(frequency_pattern, text, re.IGNORECASE)
    frequency = freq_match.group(1) if freq_match else 'N/A'
    
    return dosage, frequency


def process_patient_to_cypher(patient_data, terminologies, builder):
    """
    Process a patient's clinical note and generate Cypher statements.
    
    Args:
        patient_data: Patient information and clinical note
        terminologies: Medical terminologies dictionary
        builder: CypherScriptBuilder instance
    """
    
    print(f"\nProcessing Patient: {patient_data['patient_id']}")
    
    # Create patient node
    builder.create_patient_node(patient_data)
    
    # Initialize entity linker
    linker = EntityLinkerSimplified(terminologies)
    
    # Simple entity extraction (in practice, use full NER pipeline)
    clinical_note = patient_data['clinical_note']
    
    # Extract diseases
    extracted_diseases = []
    for disease in terminologies['diseases']:
        # Check canonical name
        if disease['canonical_name'].lower() in clinical_note.lower():
            linked = linker.link_disease(disease['canonical_name'])
            if linked:
                # Check for negation (simple approach)
                context_start = max(0, clinical_note.lower().find(disease['canonical_name'].lower()) - 50)
                context = clinical_note[context_start:context_start + 100].lower()
                linked['is_negated'] = any(neg in context for neg in ['no ', 'not ', 'denies ', 'without '])
                extracted_diseases.append(linked)
        
        # Check synonyms
        for synonym in disease['synonyms']:
            if synonym.lower() in clinical_note.lower():
                linked = linker.link_disease(synonym)
                if linked and linked not in extracted_diseases:
                    context_start = max(0, clinical_note.lower().find(synonym.lower()) - 50)
                    context = clinical_note[context_start:context_start + 100].lower()
                    linked['is_negated'] = any(neg in context for neg in ['no ', 'not ', 'denies ', 'without '])
                    extracted_diseases.append(linked)
    
    # Extract medications
    extracted_medications = []
    for med in terminologies['medications']:
        if med['generic_name'].lower() in clinical_note.lower():
            linked = linker.link_medication(med['generic_name'])
            if linked:
                # Extract dosage and frequency
                dosage, frequency = extract_dosage_info(clinical_note, med['generic_name'])
                linked['dosage'] = dosage
                linked['frequency'] = frequency
                extracted_medications.append(linked)
    
    print(f"  Found {len(extracted_diseases)} diseases")
    print(f"  Found {len(extracted_medications)} medications")
    
    # Create disease nodes and relationships
    for disease in extracted_diseases:
        builder.create_disease_node(disease)
        
        metadata = {
            'date': patient_data['date_of_visit'],
            'is_negated': disease['is_negated'],
            'confidence': disease['confidence'],
            'match_type': disease['match_type'],
            'original_text': disease['original_text']
        }
        builder.create_diagnosis_relationship(
            patient_data['patient_id'],
            disease,
            metadata
        )
    
    # Create medication nodes and relationships
    for medication in extracted_medications:
        builder.create_medication_node(medication)
        
        metadata = {
            'date': patient_data['date_of_visit'],
            'dosage': medication.get('dosage', 'N/A'),
            'frequency': medication.get('frequency', 'N/A'),
            'original_text': medication['original_text']
        }
        builder.create_prescription_relationship(
            patient_data['patient_id'],
            medication,
            metadata
        )


# ============================================================================
# STEP 4: Main Pipeline
# ============================================================================

def generate_knowledge_graph():
    """
    Main pipeline: Process all patients and generate Cypher script.
    """
    
    print("\n" + "=" * 80)
    print(" GENERATING KNOWLEDGE GRAPH CYPHER SCRIPT")
    print("=" * 80)
    
    # Load data
    print("\nLoading data...")
    with open("data/sample_notes.json", 'r') as f:
        patients_data = json.load(f)
    
    with open("data/medical_terminologies.json", 'r') as f:
        terminologies = json.load(f)
    
    patients = patients_data['patients']
    print(f"Loaded {len(patients)} patients")
    
    # Initialize builder
    builder = CypherScriptBuilder()
    
    # Add constraints
    print("\nAdding constraints...")
    builder.add_constraint("CREATE CONSTRAINT IF NOT EXISTS FOR (p:Patient) REQUIRE p.patient_id IS UNIQUE")
    builder.add_constraint("CREATE CONSTRAINT IF NOT EXISTS FOR (d:Disease) REQUIRE d.disease_id IS UNIQUE")
    builder.add_constraint("CREATE CONSTRAINT IF NOT EXISTS FOR (m:Medication) REQUIRE m.medication_id IS UNIQUE")
    
    # Process each patient
    print("\nProcessing patients...")
    for patient in patients:
        process_patient_to_cypher(patient, terminologies, builder)
    
    # Generate final script
    print("\nGenerating Cypher script...")
    cypher_script = builder.generate_script()
    
    # Save to file
    output_path = Path("output/knowledge_graph.cypher")
    output_path.parent.mkdir(exist_ok=True)
    
    with open(output_path, 'w') as f:
        f.write(cypher_script)
    
    print(f"\n✓ Cypher script saved to: {output_path}")
    print(f"  Total statements: {len(builder.statements)}")
    print(f"  Diseases created: {len(builder.created_diseases)}")
    print(f"  Medications created: {len(builder.created_medications)}")
    
    return cypher_script, output_path


def show_sample_output(cypher_script):
    """Show a sample of the generated Cypher script"""
    
    print("\n" + "=" * 80)
    print(" SAMPLE OUTPUT (first 1500 characters)")
    print("=" * 80)
    print(cypher_script[:1500])
    print("\n... (see output/knowledge_graph.cypher for complete script)")


def show_graph_stats():
    """Show statistics about the generated graph"""
    
    print("\n" + "=" * 80)
    print(" KNOWLEDGE GRAPH STATISTICS")
    print("=" * 80)
    
    print("""
To view the graph statistics in Neo4j, run these Cypher queries:

// Count nodes by type
MATCH (n) RETURN labels(n) as NodeType, count(n) as Count

// Count relationships by type
MATCH ()-[r]->() RETURN type(r) as RelationType, count(r) as Count

// Find patients with most diagnoses
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->()
RETURN p.name, count(*) as DiagnosisCount
ORDER BY DiagnosisCount DESC

// Find most prescribed medications
MATCH ()-[r:PRESCRIBED]->(m:Medication)
RETURN m.generic_name, count(r) as PrescriptionCount
ORDER BY PrescriptionCount DESC

// Find co-occurring diseases
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->(d1:Diagnosis)-[:IS_DISEASE]->(dis1:Disease)
MATCH (p)-[:HAS_DIAGNOSIS]->(d2:Diagnosis)-[:IS_DISEASE]->(dis2:Disease)
WHERE dis1.disease_id < dis2.disease_id
RETURN dis1.canonical_name, dis2.canonical_name, count(p) as PatientCount
ORDER BY PatientCount DESC
    """)


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """
    Run the complete Cypher generation pipeline.
    """
    
    print("\n" + "=" * 80)
    print(" CLINICAL NOTES NER - PART 4: Cypher Generation")
    print("=" * 80)
    
    # Generate the Cypher script
    cypher_script, output_path = generate_knowledge_graph()
    
    # Show sample output
    show_sample_output(cypher_script)
    
    # Show how to query the graph
    show_graph_stats()
    
    print("\n" + "=" * 80)
    print(" HOW TO USE THE GENERATED SCRIPT")
    print("=" * 80)
    print(f"""
1. Install Neo4j Desktop or use Neo4j Aura (cloud)
2. Create a new database
3. Open Neo4j Browser
4. Copy the contents of {output_path}
5. Paste into Neo4j Browser and execute
6. Explore your knowledge graph!

Alternative: Use the Neo4j Python driver to execute programmatically:

from neo4j import GraphDatabase

driver = GraphDatabase.driver("bolt://localhost:7687", 
                              auth=("neo4j", "password"))

with driver.session() as session:
    with open("{output_path}", 'r') as f:
        cypher = f.read()
    session.run(cypher)

driver.close()
    """)
    
    print("\n" + "=" * 80)
    print(" KEY TAKEAWAYS")
    print("=" * 80)
    print("""
1. Knowledge graphs represent complex relationships between entities
2. Cypher is Neo4j's query language for graph operations
3. Node creation: CREATE or MERGE (avoid duplicates)
4. Relationship creation: MATCH nodes, then CREATE relationship
5. Properties store metadata: confidence, dates, original text
6. Generated graph can be queried for insights:
   - Patient history and timeline
   - Disease co-occurrence patterns
   - Treatment effectiveness
   - Population health analytics

NEXT STEPS:
- Add more entity types (symptoms, procedures, labs)
- Implement temporal relationships (before/after)
- Add evidence links to medical literature
- Create visualization dashboards
- Build query APIs for applications
    """)
    
    print("\n" + "=" * 80)
    print(" PROJECT COMPLETE! 🎉")
    print("=" * 80)
    print("""
Congratulations! You've built a complete pipeline:

✓ NER with general and medical models
✓ Dictionary-based entity extraction
✓ Entity linking (exact, fuzzy, semantic)
✓ Negation detection
✓ Knowledge graph generation

Your knowledge graph is ready to use in Neo4j!
    """)


if __name__ == "__main__":
    main()
