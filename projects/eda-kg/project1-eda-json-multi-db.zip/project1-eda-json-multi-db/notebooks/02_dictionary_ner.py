"""
02_dictionary_ner.py - Dictionary/Terminology-Driven Entity Recognition

This script demonstrates how to use medical dictionaries and terminologies
to find entities that NER models might miss. This is crucial for healthcare
where we have standardized terminologies (ICD-10, SNOMED, RxNorm).

Learning Goals:
- Build a dictionary-based entity matcher
- Combine dictionary matching with NER
- Handle abbreviations and synonyms
- Understand precision vs recall tradeoffs
"""

import spacy
from spacy.matcher import PhraseMatcher
import json
from pathlib import Path
from collections import defaultdict

# ============================================================================
# STEP 1: Load Medical Terminologies
# ============================================================================

def load_medical_terminologies():
    """
    Load standardized medical terminologies from our dictionary.
    In real systems, these come from:
    - ICD-10 (diseases)
    - SNOMED CT (clinical terms)
    - RxNorm (medications)
    - LOINC (lab tests)
    """
    
    data_path = Path("data/medical_terminologies.json")
    
    with open(data_path, 'r') as f:
        terminologies = json.load(f)
    
    return terminologies


# ============================================================================
# STEP 2: Build Dictionary-Based Matchers
# ============================================================================

class MedicalDictionaryMatcher:
    """
    A dictionary-based matcher for medical entities.
    Uses spaCy's PhraseMatcher for efficient string matching.
    """
    
    def __init__(self, nlp, terminologies):
        """
        Initialize the matcher with medical terminologies.
        
        Args:
            nlp: spaCy language model
            terminologies: Dict containing diseases, medications, etc.
        """
        self.nlp = nlp
        self.terminologies = terminologies
        
        # Create separate matchers for different entity types
        self.disease_matcher = PhraseMatcher(nlp.vocab, attr="LOWER")
        self.medication_matcher = PhraseMatcher(nlp.vocab, attr="LOWER")
        self.abbreviation_matcher = PhraseMatcher(nlp.vocab, attr="TEXT")
        
        # Build the matchers
        self._build_disease_matcher()
        self._build_medication_matcher()
        self._build_abbreviation_matcher()
        
        print("✓ Dictionary matchers initialized")
    
    def _build_disease_matcher(self):
        """
        Add disease terms and their synonyms to the matcher.
        """
        patterns = []
        self.disease_lookup = {}  # Map matched text to disease info
        
        for disease in self.terminologies['diseases']:
            canonical = disease['canonical_name']
            
            # Add canonical name
            pattern = self.nlp.make_doc(canonical.lower())
            patterns.append(pattern)
            self.disease_lookup[canonical.lower()] = disease
            
            # Add synonyms
            for synonym in disease['synonyms']:
                pattern = self.nlp.make_doc(synonym.lower())
                patterns.append(pattern)
                self.disease_lookup[synonym.lower()] = disease
        
        # Add all patterns at once (more efficient)
        self.disease_matcher.add("DISEASE", patterns)
        print(f"  - Added {len(patterns)} disease term patterns")
    
    def _build_medication_matcher(self):
        """
        Add medication names (generic and brand) to the matcher.
        """
        patterns = []
        self.medication_lookup = {}
        
        for med in self.terminologies['medications']:
            generic = med['generic_name']
            
            # Add generic name
            pattern = self.nlp.make_doc(generic.lower())
            patterns.append(pattern)
            self.medication_lookup[generic.lower()] = med
            
            # Add brand names
            for brand in med['brand_names']:
                pattern = self.nlp.make_doc(brand.lower())
                patterns.append(pattern)
                self.medication_lookup[brand.lower()] = med
        
        self.medication_matcher.add("MEDICATION", patterns)
        print(f"  - Added {len(patterns)} medication patterns")
    
    def _build_abbreviation_matcher(self):
        """
        Add medical abbreviations. Note: Uses exact text matching (case-sensitive).
        This is important because 'BP' should match 'BP' but not 'bp' in a word.
        """
        patterns = []
        self.abbreviation_lookup = {}
        
        for abbr, expansion in self.terminologies['abbreviations'].items():
            # For abbreviations, we match the exact text (case matters!)
            pattern = self.nlp.make_doc(abbr)
            patterns.append(pattern)
            self.abbreviation_lookup[abbr] = expansion
        
        self.abbreviation_matcher.add("ABBREVIATION", patterns)
        print(f"  - Added {len(patterns)} abbreviation patterns")
    
    def match_entities(self, doc):
        """
        Find all dictionary-based matches in the document.
        
        Args:
            doc: spaCy Doc object
            
        Returns:
            List of tuples: (start, end, label, text, metadata)
        """
        matches = []
        
        # Find disease matches
        disease_matches = self.disease_matcher(doc)
        for match_id, start, end in disease_matches:
            span = doc[start:end]
            matched_text = span.text.lower()
            disease_info = self.disease_lookup.get(matched_text, {})
            
            matches.append({
                'start': start,
                'end': end,
                'label': 'DISEASE',
                'text': span.text,
                'canonical_name': disease_info.get('canonical_name', ''),
                'icd10_code': disease_info.get('icd10_code', ''),
                'category': disease_info.get('category', ''),
                'source': 'dictionary'
            })
        
        # Find medication matches
        med_matches = self.medication_matcher(doc)
        for match_id, start, end in med_matches:
            span = doc[start:end]
            matched_text = span.text.lower()
            med_info = self.medication_lookup.get(matched_text, {})
            
            matches.append({
                'start': start,
                'end': end,
                'label': 'MEDICATION',
                'text': span.text,
                'generic_name': med_info.get('generic_name', ''),
                'drug_class': med_info.get('drug_class', ''),
                'rxnorm_code': med_info.get('rxnorm_code', ''),
                'source': 'dictionary'
            })
        
        # Find abbreviation matches
        abbr_matches = self.abbreviation_matcher(doc)
        for match_id, start, end in abbr_matches:
            span = doc[start:end]
            expansion = self.abbreviation_lookup.get(span.text, '')
            
            matches.append({
                'start': start,
                'end': end,
                'label': 'ABBREVIATION',
                'text': span.text,
                'expansion': expansion,
                'source': 'dictionary'
            })
        
        return matches


# ============================================================================
# STEP 3: Combine NER and Dictionary Matching
# ============================================================================

def combine_ner_and_dictionary(doc, dict_matches):
    """
    Combine NER predictions with dictionary matches.
    
    Strategy:
    1. Keep all dictionary matches (high precision)
    2. Add NER entities that don't overlap with dictionary matches
    3. Prefer dictionary matches in case of overlap (more reliable)
    
    Args:
        doc: spaCy Doc with NER predictions
        dict_matches: List of dictionary matches
        
    Returns:
        Combined list of entities
    """
    
    # Convert dictionary matches to spans for overlap detection
    dict_spans = set()
    for match in dict_matches:
        for i in range(match['start'], match['end']):
            dict_spans.add(i)
    
    # Collect all entities
    all_entities = list(dict_matches)
    
    # Add NER entities that don't overlap
    for ent in doc.ents:
        # Check if this NER entity overlaps with dictionary matches
        ent_tokens = set(range(ent.start, ent.end))
        if not ent_tokens.intersection(dict_spans):
            all_entities.append({
                'start': ent.start,
                'end': ent.end,
                'label': ent.label_,
                'text': ent.text,
                'source': 'ner'
            })
    
    # Sort by start position
    all_entities.sort(key=lambda x: x['start'])
    
    return all_entities


# ============================================================================
# STEP 4: Demonstration
# ============================================================================

def demo_dictionary_matching():
    """
    Demonstrate dictionary-based entity matching on clinical notes.
    """
    
    print("\n" + "=" * 80)
    print(" DICTIONARY-BASED ENTITY RECOGNITION")
    print("=" * 80)
    
    # Load model and terminologies
    nlp = spacy.load("en_core_web_sm")
    terminologies = load_medical_terminologies()
    
    # Create dictionary matcher
    print("\nInitializing dictionary matcher...")
    matcher = MedicalDictionaryMatcher(nlp, terminologies)
    
    # Load clinical notes
    print("\nLoading clinical notes...")
    with open("data/sample_notes.json", 'r') as f:
        data = json.load(f)
    
    patients = data['patients']
    patient = patients[0]  # Analyze first patient
    
    print(f"\nPatient ID: {patient['patient_id']}")
    print(f"Clinical Note:\n{patient['clinical_note'][:200]}...\n")
    
    # Process text
    doc = nlp(patient['clinical_note'])
    
    # Get dictionary matches
    dict_matches = matcher.match_entities(doc)
    
    # Display dictionary matches
    print("\n" + "=" * 80)
    print("DICTIONARY MATCHES FOUND")
    print("=" * 80)
    
    for match in dict_matches:
        if match['label'] == 'DISEASE':
            print(f"\n🦠 DISEASE: {match['text']}")
            print(f"   Canonical: {match['canonical_name']}")
            print(f"   ICD-10: {match['icd10_code']}")
            print(f"   Category: {match['category']}")
        
        elif match['label'] == 'MEDICATION':
            print(f"\n💊 MEDICATION: {match['text']}")
            print(f"   Generic: {match['generic_name']}")
            print(f"   Class: {match['drug_class']}")
            print(f"   RxNorm: {match['rxnorm_code']}")
        
        elif match['label'] == 'ABBREVIATION':
            print(f"\n📝 ABBREVIATION: {match['text']}")
            print(f"   Expands to: {match['expansion']}")
    
    # Compare with NER
    print("\n" + "=" * 80)
    print("COMPARISON: Dictionary vs NER Alone")
    print("=" * 80)
    
    print(f"\nDictionary found: {len(dict_matches)} entities")
    print(f"NER found: {len(doc.ents)} entities")
    
    # Combine both approaches
    combined = combine_ner_and_dictionary(doc, dict_matches)
    print(f"Combined approach found: {len(combined)} entities")
    
    # Show what dictionary caught that NER missed
    print("\n" + "=" * 80)
    print("ENTITIES CAUGHT BY DICTIONARY (but missed by NER)")
    print("=" * 80)
    
    ner_texts = {ent.text.lower() for ent in doc.ents}
    unique_dict_matches = [m for m in dict_matches 
                           if m['text'].lower() not in ner_texts]
    
    for match in unique_dict_matches:
        print(f"  ✓ {match['text']} ({match['label']})")
    
    return doc, dict_matches, combined


# ============================================================================
# STEP 5: Analyze Multiple Patients
# ============================================================================

def analyze_all_patients():
    """
    Run dictionary matching on all patients to see aggregate results.
    """
    
    print("\n" + "=" * 80)
    print(" ANALYZING ALL PATIENTS")
    print("=" * 80)
    
    # Setup
    nlp = spacy.load("en_core_web_sm")
    terminologies = load_medical_terminologies()
    matcher = MedicalDictionaryMatcher(nlp, terminologies)
    
    # Load all patients
    with open("data/sample_notes.json", 'r') as f:
        data = json.load(f)
    
    # Aggregate statistics
    total_diseases = 0
    total_medications = 0
    total_abbreviations = 0
    disease_frequency = defaultdict(int)
    medication_frequency = defaultdict(int)
    
    # Process each patient
    for patient in data['patients']:
        doc = nlp(patient['clinical_note'])
        matches = matcher.match_entities(doc)
        
        for match in matches:
            if match['label'] == 'DISEASE':
                total_diseases += 1
                disease_frequency[match['canonical_name']] += 1
            elif match['label'] == 'MEDICATION':
                total_medications += 1
                medication_frequency[match['generic_name']] += 1
            elif match['label'] == 'ABBREVIATION':
                total_abbreviations += 1
    
    # Display results
    print(f"\nTotal entities found across {len(data['patients'])} patients:")
    print(f"  - Diseases: {total_diseases}")
    print(f"  - Medications: {total_medications}")
    print(f"  - Abbreviations: {total_abbreviations}")
    
    print("\nMost common diseases:")
    for disease, count in sorted(disease_frequency.items(), 
                                  key=lambda x: x[1], reverse=True)[:5]:
        print(f"  - {disease}: {count}")
    
    print("\nMost common medications:")
    for med, count in sorted(medication_frequency.items(), 
                             key=lambda x: x[1], reverse=True)[:5]:
        print(f"  - {med}: {count}")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """
    Run the complete dictionary-based NER demonstration.
    """
    
    print("\n" + "=" * 80)
    print(" CLINICAL NOTES NER - PART 2: Dictionary Matching")
    print("=" * 80)
    
    # Demo on single patient
    doc, dict_matches, combined = demo_dictionary_matching()
    
    # Analyze all patients
    analyze_all_patients()
    
    print("\n" + "=" * 80)
    print("KEY TAKEAWAYS")
    print("=" * 80)
    print("""
1. Dictionary matching catches many entities NER models miss
2. Especially good for:
   - Standardized terms (ICD-10, SNOMED, RxNorm)
   - Abbreviations (HTN, BID, PRN)
   - Synonyms and brand names
3. Combining NER + Dictionary gives best results
4. Tradeoffs:
   - Dictionary: High precision, but limited to known terms
   - NER: Better generalization, but lower precision

NEXT: Run 03_entity_linking.py to link entities to standard terminologies
with fuzzy matching and semantic similarity!
    """)
    
    print("\n" + "=" * 80)
    print("EXERCISE FOR YOU")
    print("=" * 80)
    print("""
1. Look at the entities found by dictionary matching
2. Add a new disease or medication to medical_terminologies.json
3. Re-run this script and see if it catches your new term
4. Think about: What if there's a typo in the clinical note?
   (e.g., "diabtes" instead of "diabetes")

Next script will handle fuzzy matching to address this!
    """)


if __name__ == "__main__":
    main()
