# Integrated Analytics with KG, SQL, Vector DB, nested JSON

---

## PROJECT OVERVIEW

This mini-project demonstrates advanced healthcare analytics by combining:
1. **SQL Server** - Structured clinical and operational data
2. **ChromaDB (Vector Database)** - Medical literature with semantic search
3. **Neo4j (Knowledge Graph)** - Clinical pathways and relationships
4. **Nested JSON** - Complex hierarchical treatment protocols

The project is designed to showcase data quality engineering, exploratory data analysis, intelligent insights extraction, and the power of combining multiple data modalities.

---

## DATA ARCHITECTURE

### 1. SQL Database (Relational)
- **patients** - Demographics, chronic conditions
- **clinical_encounters** - Visits, diagnoses, costs, outcomes
- **medications_prescribed** - Prescriptions with dosing details
- **lab_results** - Test results with abnormal flags

### 2. Vector Database (Semantic)
- **medical_literature collection** - Research papers, guidelines, protocols, case studies
- Embedded using state-of-the-art models for semantic similarity search

### 3. Knowledge Graph (Relationships)
- **Nodes**: Patient, Condition, Medication, Physician, Department, Clinical_Pathway, Risk_Factor
- **Relationships**: HAS_CONDITION, PRESCRIBED, TREATS, CONTRAINDICATES, INTERACTS_WITH, etc.

### 4. Nested JSON (Hierarchical)
- **clinical_pathways** - Multi-level care protocols with:
  - Care stages with sequential activities
  - Medication algorithms with decision trees
  - Risk stratification criteria
  - Quality metrics and cost benchmarks

---

## FIVE ADVANCED ANALYTICAL QUESTIONS

### Question 1: Multi-Source Readmission Risk Intelligence

**Question:** *"For heart failure patients who were readmitted within 30 days, synthesize insights from clinical data (SQL), medical literature (Vector DB), treatment pathways (Neo4j), and risk stratification criteria (JSON) to create evidence-based intervention plans and estimate cost savings."*

**Technologies Exercised:**
- ✓ SQL: Complex joins, window functions, LAG for temporal analysis, composite risk scoring
- ✓ Vector DB: Semantic search for "readmission prevention," "transitional care," "BNP predictors"
- ✓ Neo4j: Traverse PATIENT→HAS_RISK_FACTOR→RISK_FACTOR→LEADS_TO→OUTCOME
- ✓ JSON: Flatten nested discharge planning criteria from HF pathway

**Key Techniques:**
1. Calculate composite risk scores using literature-backed multipliers (BNP>800 = 2.8x risk)
2. Identify patients with multiple risk factors using SQL CTEs
3. Search vector DB for intervention strategies
4. Extract discharge planning activities from nested JSON pathway
5. Cost-benefit analysis: $2,400 savings per prevented readmission

**Reasoning Prompt Template:**
```
Given multi-source data:
- SQL: {patient_demographics, lab_values, prior_admissions, risk_scores}
- Vector DB: {research_findings_on_predictors}
- Neo4j: {pathway_activities, recommended_interventions}
- JSON: {risk_stratification_thresholds}

Task: Synthesize into actionable insights
1. Segment patients: high-risk (score>3), moderate (1.5-3), low (<1.5)
2. Map risk factors → evidence-based interventions
3. Calculate ROI: (prevented_readmissions × $15,000) - (program_cost × patients)
4. Prioritize by impact: BNP-guided therapy > medication reconciliation > phone follow-up

Output format:
- Risk Profile Summary
- Top 3 Interventions (with evidence citations)
- Cost-Benefit Analysis
- Implementation Roadmap
```

**Expected Insights:**
- Patients with BNP>800 + Creatinine>1.5 + prior admission = 45% readmission rate
- Transitional care programs reduce readmissions by 32% (from literature)
- Missing 48-hour follow-up calls correlates with 2.1x readmission risk
- **Estimated savings: $67,200 for 10 high-risk patients enrolled in program**

---

### Question 2: Medication Optimization via Drug Interaction Network Analysis

**Question:** *"For diabetic + hypertensive patients experiencing adverse events (worsening renal function, hypoglycemia), analyze medication combinations against guidelines, identify problematic drug-drug interactions, and recommend evidence-based alternatives using semantic search and graph traversal."*

**Technologies Exercised:**
- ✓ SQL: Self-joins for pairwise medication combinations, temporal lab value changes (LAG)
- ✓ Vector DB: Search "ACE inhibitor alternatives," "SGLT2 renal protection," "beta blocker hypoglycemia"
- ✓ Neo4j: MATCH (drug1)-[:INTERACTS_WITH]->(drug2), (drug)-[:CONTRAINDICATES]->(condition)
- ✓ JSON: Extract medication selection algorithms from nested diabetes pathway decision tree

**Key Techniques:**
1. Detect adverse events: Creatinine increase >0.3 mg/dL over time
2. Correlate with medication start dates
3. Graph query to find alternative drugs without contraindications
4. Flatten 4-pillar GDMT algorithm from JSON
5. Semantic search for comparative efficacy data

**Implementation Highlights:**
```sql
-- Identify medication pairs with temporal adverse events
SELECT m1.drug_name, m2.drug_name, 
       (l2.value - l1.value) as creatinine_change
FROM medications m1, medications m2, labs l1, labs l2
WHERE m1.patient_id = m2.patient_id
  AND m1.start_date < m2.start_date
  AND l2.test_date > m2.start_date
  AND l1.test_name = 'Creatinine'
  AND (l2.value - l1.value) > 0.3
```

```cypher
// Neo4j: Find safe alternatives
MATCH (current:Medication {name: 'Lisinopril'})
MATCH (current)-[:CONTRAINDICATES]->(c:Condition {name: 'Bilateral RAS'})
MATCH (alt:Medication)-[:TREATS]->(:Condition {name: 'Hypertension'})
WHERE NOT (alt)-[:CONTRAINDICATES]->(c)
  AND NOT (alt)-[:INTERACTS_WITH]->(current)
RETURN alt.name, alt.drug_class
```

**Reasoning Prompt:**
```
Patient Profile:
- Age: 68, Conditions: T2DM, HTN, CKD Stage 3b (eGFR 38)
- Current Meds: Lisinopril 20mg, Metformin 1000mg BID
- Lab Change: Creatinine 1.2 → 1.8 over 3 months

Data Sources:
- SQL: Medication timeline, lab trends
- Neo4j: Lisinopril CONTRAINDICATES {Bilateral RAS, Pregnancy}, INTERACTS_WITH {NSAIDs}
- Vector DB: "SGLT2 inhibitors show 40% reduction in CKD progression at eGFR≥20"
- JSON: Diabetes pathway recommends "First-line: Metformin, Add SGLT2i or GLP-1 RA for CKD"

Chain-of-Thought Reasoning:
1. ACE inhibitor (Lisinopril) causing renal deterioration? Check for RAS, consider dose reduction
2. Metformin safe to continue (eGFR>30), but monitor
3. SGLT2 inhibitor (Dapagliflozin 10mg) indicated: both CKD protection AND diabetes control
4. Alternative to Lisinopril: ARB (Losartan) or CCB (Amlodipine) if BP not controlled
5. Avoid: Sulfonylureas (hypoglycemia risk in CKD)

Recommended Regimen:
1. Continue Metformin 1000mg BID (safe at eGFR 38)
2. ADD: Dapagliflozin 10mg daily (SGLT2i for renal protection + glucose control)
3. SWITCH: Lisinopril → Amlodipine 5mg if BP remains elevated
4. Monitor: BMP in 2 weeks, adjust doses based on K+ and Cr

Expected Outcomes:
- HbA1c: 7.8% → ~7.0% (Metformin 1% + SGLT2i 0.8% reduction)
- eGFR stabilization or slower decline
- BP control maintained
```

**Expected Insights:**
- 23% of diabetic-HTN patients on ACE inhibitors show worsening renal function
- SGLT2 inhibitors provide dual benefit: glucose control + nephroprotection
- Switching to SGLT2i + discontinuing sulfonylureas reduces hypoglycemia by 60%

---

### Question 3: Outlier Detection with Root Cause Analysis

**Question:** *"Detect cost and length-of-stay outliers using statistical methods. For outliers, perform root cause analysis by checking pathway compliance (Neo4j), comparing to benchmark costs (JSON), analyzing lab trends (SQL), and finding similar cases in literature (Vector DB)."*

**Technologies Exercised:**
- ✓ SQL: Z-score calculation, percentile ranking, time-series with LEAD/LAG
- ✓ Vector DB: Search for "average cost heart failure admission," "LOS benchmarks"
- ✓ Neo4j: Pathway compliance checking via (Encounter)-[:COMPLETED_ACTIVITY]->(Activity)
- ✓ JSON: Extract quality metrics, avg_cost_per_admission, target readmission rates

**Key Techniques:**
1. **Statistical Outlier Detection:**
   - Z-score: (value - mean) / std_dev
   - Flag if |Z-score| > 2 (95th percentile)
   - Separate analysis by department and encounter type

2. **Temporal Lab Trend Analysis:**
   - Calculate rate of change: (current - previous) / time_delta
   - Flag rapid deterioration: BNP increase >50% in 12 hours

3. **Pathway Compliance:**
   - Compare required activities vs completed activities
   - Calculate compliance score: completed / required × 100

4. **Benchmark Comparison:**
   - Extract pathway cost targets from JSON
   - Compare actual vs expected using vector DB literature

**Implementation Example:**
```python
# Outlier Detection
df['cost_zscore'] = (df['cost'] - df['cost'].mean()) / df['cost'].std()
outliers = df[abs(df['cost_zscore']) > 2]

# Root Cause: Pathway Compliance
cypher = """
MATCH (e:Encounter {id: 'ENC003'})-[:SHOULD_FOLLOW]->(p:Pathway)
MATCH (p)-[:HAS_STAGE]->(s)-[:REQUIRES]->(a:Activity {mandatory: true})
OPTIONAL MATCH (e)-[:COMPLETED]->(completed:Activity)
RETURN 
  collect(a.name) as required,
  collect(completed.name) as completed,
  [x IN collect(a.name) WHERE NOT x IN collect(completed.name)] as missing
"""

# Temporal Analysis
df_labs['change_rate'] = df_labs.groupby('patient_id')['value'].pct_change()
rapid_changes = df_labs[df_labs['change_rate'].abs() > 0.5]
```

**Reasoning Prompt:**
```
Outlier Case Analysis:

Encounter ID: ENC003
- Cost: $18,500 (Z-score: +2.8, 98th percentile)
- LOS: 72 hours (Z-score: +2.3, 95th percentile)
- Department: Cardiology
- Diagnosis: Heart Failure Exacerbation
- Outcome: Readmitted within 30 days

Data Synthesis:
1. SQL Findings:
   - BNP: 400 → 850 pg/mL (112% increase over 12 hours)
   - Creatinine: 1.2 → 1.8 mg/dL (50% increase)
   - Patient had 1 prior admission in past 90 days

2. Neo4j Pathway Analysis:
   - Required activities: 12
   - Completed: 8 (67% compliance)
   - Missing: [Medication reconciliation, 48-hr follow-up call, Patient education, Cardiac rehab referral]

3. Vector DB Benchmarks:
   - National average HF admission cost: $13,500
   - Average LOS: 4.2 days (48 hours)
   - Readmission rate benchmark: <20%

4. JSON Quality Metrics:
   - Pathway target cost: $15,000
   - Target readmission: <20%
   - Actual for this case: $18,500 (23% over target), Readmitted (vs 20% target)

Root Cause Hypothesis:
1. Clinical: Rapid BNP rise suggests inadequate initial diuresis
2. Process: Low pathway compliance (67%) → missed critical discharge steps
3. System: No transitional care program enrollment despite high-risk profile
4. Cost Driver: Extended LOS (72 vs 48 hours) due to suboptimal diuresis + readmission cost

Corrective Actions:
1. Implement BNP-guided diuretic therapy (check BNP at 24h, titrate furosemide)
2. Mandatory pathway compliance >90% via EHR alerts
3. Auto-enroll high-risk patients (BNP>600 + prior admission) in transitional care
4. Cost impact: Prevent 1 readmission = $15,000 savings - $800 program cost = $14,200 net

Estimated ROI:
- Current: 30% readmission rate on 100 HF patients = 30 readmissions = $450,000 cost
- With intervention: 20% rate (32% reduction) = 20 readmissions = $300,000 cost
- Savings: $150,000 - (100 × $800 program cost) = $70,000 annual net savings
```

**Visualization Needs:**
- Scatter plot: Cost vs LOS, colored by severity, sized by readmission
- Time-series: Lab value trends with intervention timestamps
- Heatmap: Pathway compliance across departments

---

### Question 4: Personalized Treatment Recommendation Engine

**Question:** *"For a complex patient (68yo with T2DM, HFrEF EF 35%, CKD Stage 3b), generate personalized medication recommendations by: (1) semantic search for drug efficacy in this population, (2) graph traversal for contraindications, (3) pathway decision tree extraction, (4) SQL profile building."*

**Technologies Exercised:**
- ✓ SQL: Build comprehensive patient profile with all comorbidities, labs, current meds
- ✓ Vector DB: Multi-query semantic search for each comorbidity + drug class
- ✓ Neo4j: Traverse (Patient)-[:HAS_CONDITION]->(Condition)<-[:TREATS]-(Med), check CONTRAINDICATES
- ✓ JSON: Navigate nested medication selection algorithm with conditional branching

**Key Techniques:**
1. **Patient Profiling (SQL):**
   ```sql
   SELECT p.*, 
          STRING_AGG(m.medication_name, ', ') as current_meds,
          MAX(CASE WHEN l.test = 'HbA1c' THEN l.value END) as hba1c,
          MAX(CASE WHEN l.test = 'eGFR' THEN l.value END) as egfr,
          MAX(CASE WHEN l.test = 'BNP' THEN l.value END) as bnp,
          MAX(CASE WHEN l.test = 'EF' THEN l.value END) as ejection_fraction
   FROM patients p
   LEFT JOIN medications m ON p.id = m.patient_id
   LEFT JOIN labs l ON p.id = l.patient_id
   WHERE p.id = 'P003'
   GROUP BY p.patient_id
   ```

2. **Multi-Faceted Semantic Search (Vector DB):**
   - Query 1: "SGLT2 inhibitor heart failure reduced ejection fraction chronic kidney disease outcomes"
   - Query 2: "GLP-1 agonist diabetes CKD dosing renal impairment cardiovascular benefit"
   - Query 3: "heart failure GDMT elderly patients tolerability safety"
   - Aggregate results, extract key recommendations

3. **Contraindication Network (Neo4j):**
   ```cypher
   MATCH (p:Patient {id: 'P003'})-[:HAS_CONDITION]->(cond:Condition)
   MATCH (med:Medication)-[:TREATS]->(cond)
   WHERE NOT (med)-[:CONTRAINDICATES]->(cond)
     AND NOT (med)-[:REQUIRES]->(test:Lab_Value {result: 'abnormal'})
   RETURN med.name, med.class, collect(cond.name) as treats
   ORDER BY med.evidence_level DESC
   ```

4. **Decision Tree Navigation (JSON):**
   ```python
   def extract_medication_algorithm(pathway_json, patient_profile):
       # Navigate nested structure
       for scenario in pathway['care_stages'][1]['decision_tree']['scenarios']:
           if matches_patient_criteria(scenario['scenario'], patient_profile):
               return scenario['preferred_agents']
   ```

**Reasoning Prompt:**
```
Patient: 68yo Male
Conditions: Type 2 Diabetes (15 years), Heart Failure (HFrEF, EF 35%), CKD Stage 3b
Labs: HbA1c 8.2%, eGFR 38 mL/min, BNP 450 pg/mL, BP 142/88
Current Meds: Metformin 1000mg BID, Lisinopril 10mg daily, Furosemide 40mg BID
Goals: Optimize glycemic control, reduce HF hospitalization risk, slow CKD progression

Data Sources:
1. SQL Profile: {demographics, full_lab_panel, med_history}
2. Vector DB Results:
   - "EMPEROR-Reduced trial: Empagliflozin reduced HF hosp by 30% and slowed CKD progression"
   - "DAPA-CKD: Dapagliflozin safe and effective at eGFR ≥25"
   - "Sacubitril/Valsartan superior to ACEI in HFrEF, 20% mortality reduction"
3. Neo4j Graph:
   - SGLT2i TREATS {T2DM, HF, CKD}
   - GLP-1 RA TREATS {T2DM}, PROVIDES_CV_BENEFIT
   - Sacubitril/Valsartan TREATS {HF}, CONTRAINDICATES {Angioedema_history}
4. JSON Pathway:
   - Diabetes pathway: "CKD present → SGLT2i first-line regardless of glucose control"
   - HF pathway: "HFrEF → 4 pillars: ARNI/ACEI, Beta-blocker, MRA, SGLT2i"

Multi-Step Reasoning:
Step 1: Prioritize Conditions by Impact
   - HF with reduced EF = highest mortality risk → prioritize HF GDMT
   - T2DM + CKD = progressive kidney disease → add renal-protective agents
   - HTN adequately controlled

Step 2: Identify Gaps in Current Regimen
   - Missing: Beta-blocker (Carvedilol), MRA (Spironolactone), SGLT2i (Dapagliflozin)
   - Suboptimal: Lisinopril should be Sacubitril/Valsartan in HFrEF
   - Glucose control: HbA1c 8.2% on Metformin alone → need add-on

Step 3: Evidence-Based Additions (with prioritization)
   Priority 1: SGLT2 Inhibitor (Dapagliflozin 10mg daily)
      - Rationale: Treats all 3 conditions (T2DM, HF, CKD)
      - Evidence: 30% ↓ HF hosp, 40% ↓ CKD progression, 0.5-0.8% HbA1c reduction
      - Safety: Safe at eGFR ≥25, monitor for UTI/genital infections
   
   Priority 2: Switch to ARNI (Sacubitril/Valsartan 49/51mg BID → titrate to 97/103mg BID)
      - Rationale: Superior to ACEI in HFrEF (20% mortality benefit vs enalapril)
      - Requires: Lisinopril washout (48 hours), check BP tolerance
      - Monitor: BP, K+, Cr after 1-2 weeks
   
   Priority 3: Beta-Blocker (Carvedilol 3.125mg BID → titrate to 25mg BID)
      - Rationale: Core HF therapy, proven mortality benefit
      - Start low: Risk of hypotension, bradycardia
      - Titrate: Double dose every 2 weeks as tolerated
   
   Priority 4: MRA (Spironolactone 12.5mg daily)
      - Rationale: 30% mortality reduction in NYHA II-IV HFrEF
      - Caution: K+ at baseline 4.8, eGFR 38 → close monitoring
      - Monitor: K+ and Cr at 1 week, 1 month, then q3-6 months

Step 4: Medication Interactions & Contraindications Check
   - Neo4j confirms: No interactions between proposed regimen
   - Spironolactone + ACEI/ARNI → hyperkalemia risk → MONITOR K+ closely
   - SGLT2i + Loop diuretic → potential hypovolemia → monitor BP, Cr

Step 5: Dosing Adjustments for CKD
   - Metformin: Safe to continue at eGFR 38 (contraindicated if <30)
   - Dapagliflozin: Standard dose (no adjustment needed at eGFR ≥25)
   - Sacubitril/Valsartan: No dose adjustment for CKD
   - Spironolactone: Use cautiously, lower dose (12.5mg vs 25mg)

Step 6: Expected Outcomes (6 months)
   - HbA1c: 8.2% → ~7.0% (Metformin 1% + SGLT2i 0.7% reduction)
   - HF: Reduced symptoms, 30% lower hospitalization risk
   - CKD: Stabilized eGFR (vs expected 3-4 mL/min/year decline)
   - BP: Well-controlled with ARNI
   - Quality of Life: Improved exercise tolerance, reduced dyspnea

Final Recommended Regimen:
1. CONTINUE: Metformin 1000mg BID, Furosemide 40mg BID
2. ADD: Dapagliflozin 10mg daily (SGLT2i)
3. SWITCH: Lisinopril → Sacubitril/Valsartan 49/51mg BID (titrate to 97/103mg)
4. ADD: Carvedilol 3.125mg BID (titrate to 25mg BID over 8 weeks)
5. ADD: Spironolactone 12.5mg daily (if K+ <5.0)

Monitoring Plan:
- Week 1: BP, HR, BMP (K+, Cr)
- Week 2-8: Titrate Carvedilol, monitor BP/HR
- Month 1: BMP, assess tolerance
- Month 3: HbA1c, BMP, BNP, reassess doses
- Month 6: Full evaluation including echo for EF reassessment

Cost Consideration:
- SGLT2i: ~$500/month (check insurance, patient assistance programs)
- Sacubitril/Valsartan: ~$600/month (vs Lisinopril $10/month)
- Total added cost: ~$1,100/month
- Offset: Reduced hospitalizations = $15,000-20,000 per avoided HF admission
```

**Expected Outcome:**
A fully personalized, evidence-based, guideline-concordant regimen that addresses all three conditions simultaneously, with clear monitoring parameters and expected clinical outcomes.

---

### Question 5: Population Health Analytics with Predictive Insights

**Question:** *"Aggregate all patients with polypharmacy (≥5 medications). Using SQL for cohort analysis, Vector DB for adherence predictors, Neo4j for medication burden networks, and JSON for intervention protocols, predict which patients are at highest risk for non-adherence and recommend targeted interventions."*

**Technologies Exercised:**
- ✓ SQL: Cohort building, medication count aggregation, statistical analysis, risk scoring
- ✓ Vector DB: Semantic search for "medication adherence predictors," "polypharmacy interventions"
- ✓ Neo4j: Visualize medication networks, identify high-complexity regimens
- ✓ JSON: Extract quality metrics on adherence rates, intervention strategies

**Key Techniques:**

1. **Cohort Identification (SQL):**
   ```sql
   WITH patient_med_count AS (
       SELECT patient_id, 
              COUNT(DISTINCT medication_name) as med_count,
              COUNT(DISTINCT medication_class) as class_count,
              SUM(CASE WHEN frequency LIKE '%daily%' THEN 1 
                       WHEN frequency LIKE '%BID%' THEN 2 
                       WHEN frequency LIKE '%TID%' THEN 3 
                       ELSE 4 END) as daily_pill_burden
       FROM medications_prescribed
       WHERE prescribed_date >= DATEADD(MONTH, -3, GETDATE())
       GROUP BY patient_id
   )
   SELECT p.*, pmc.med_count, pmc.daily_pill_burden,
          CASE 
              WHEN med_count >= 10 THEN 'Extreme Polypharmacy'
              WHEN med_count >= 5 THEN 'Polypharmacy'
              ELSE 'Normal'
          END as polypharmacy_category
   FROM patients p
   INNER JOIN patient_med_count pmc ON p.patient_id = pmc.patient_id
   WHERE pmc.med_count >= 5
   ```

2. **Adherence Risk Scoring (SQL + Vector DB insights):**
   ```sql
   SELECT patient_id,
          -- Risk factors from literature (vector DB)
          CASE WHEN med_count > 8 THEN 3 ELSE 0 END +  -- Complexity
          CASE WHEN daily_pill_burden > 10 THEN 2 ELSE 0 END +  -- Pill burden
          CASE WHEN age > 75 THEN 1 ELSE 0 END +  -- Age
          CASE WHEN chronic_conditions LIKE '%Depression%' THEN 2 ELSE 0 END +  -- Cognitive
          CASE WHEN insurance_provider = 'Self-Pay' THEN 3 ELSE 0 END  -- Cost
          AS adherence_risk_score
   FROM patients
   ```

3. **Medication Network Analysis (Neo4j):**
   ```cypher
   MATCH (p:Patient)-[:PRESCRIBED]->(m:Medication)
   WITH p, collect(m) as medications
   WHERE size(medications) >= 5
   UNWIND medications as med1
   UNWIND medications as med2
   WHERE id(med1) < id(med2)
   MATCH (med1)-[:INTERACTS_WITH]->(med2)
   RETURN p.patient_id, 
          size(medications) as med_count,
          count(*) as interaction_count,
          collect(med1.name + ' <-> ' + med2.name) as interactions
   ORDER BY interaction_count DESC
   ```

4. **Intervention Matching (JSON extraction):**
   ```python
   # Extract adherence intervention strategies from pathways
   interventions = []
   for pathway in json_data['clinical_pathways']:
       if 'patient_education_priorities' in pathway:
           interventions.extend(
               pathway['patient_education_priorities'].get('medication_adherence', [])
           )
   ```

**Implementation:**
```python
def predict_non_adherence_risk(engine, collection, neo4j_driver, json_path):
    # Step 1: Build polypharmacy cohort
    cohort_query = """
        -- (SQL query from above)
    """
    df_cohort = pd.read_sql(cohort_query, engine)
    
    # Step 2: Retrieve adherence predictors from literature
    search_results = collection.query(
        query_texts=[
            "medication adherence predictors polypharmacy risk factors",
            "interventions improve medication compliance complex regimens",
            "pharmacist-led medication management"
        ],
        n_results=5
    )
    
    # Extract predictors from literature: number of meds, dosing frequency, cost, cognitive factors
    predictors = extract_predictors_from_docs(search_results)
    
    # Step 3: Score each patient based on predictors
    df_cohort['adherence_risk_score'] = (
        (df_cohort['med_count'] > 8).astype(int) * 3 +
        (df_cohort['daily_pill_burden'] > 10).astype(int) * 2 +
        (df_cohort['age'] > 75).astype(int) * 1 +
        (df_cohort['chronic_conditions'].str.contains('Depression')).astype(int) * 2 +
        (df_cohort['insurance_provider'] == 'Self-Pay').astype(int) * 3
    )
    
    # Step 4: Identify high-risk patients (top 20%)
    threshold = df_cohort['adherence_risk_score'].quantile(0.8)
    high_risk = df_cohort[df_cohort['adherence_risk_score'] >= threshold]
    
    # Step 5: Neo4j - Assess medication complexity via interaction networks
    with neo4j_driver.session() as session:
        for patient_id in high_risk['patient_id']:
            result = session.run("""
                MATCH (p:Patient {patient_id: $pid})-[:PRESCRIBED]->(m:Medication)
                WITH p, collect(m) as meds
                UNWIND meds as med1
                UNWIND meds as med2
                WHERE id(med1) < id(med2) AND (med1)-[:INTERACTS_WITH]-(med2)
                RETURN count(*) as interactions
                """, pid=patient_id)
            high_risk.loc[high_risk['patient_id'] == patient_id, 'interactions'] = \
                result.single()['interactions']
    
    # Step 6: Match patients to interventions based on risk profile
    interventions = {
        'high_complexity': 'Pharmacist-led medication therapy management (MTM)',
        'cost_barriers': 'Patient assistance programs, generic substitutions',
        'cognitive_issues': 'Simplified regimen, pill organizers, caregiver education',
        'high_pill_burden': 'Combination medications, extended-release formulations'
    }
    
    return high_risk, interventions
```

**Reasoning Prompt:**
```
Population Cohort: 150 patients with polypharmacy (≥5 medications)

Risk Stratification Results:
- High Risk (score ≥8): 30 patients (20%)
- Moderate Risk (score 4-7): 70 patients (47%)
- Low Risk (score <4): 50 patients (33%)

Risk Factor Analysis (from SQL + Vector DB):
1. Medication count >8: OR 2.3 for non-adherence (present in 18 high-risk patients)
2. Daily pill burden >10: OR 1.9 (present in 22 high-risk patients)
3. Depression/cognitive: OR 2.1 (present in 12 high-risk patients)
4. Out-of-pocket costs >$100/month: OR 1.8 (present in 15 high-risk patients)
5. Prior non-adherence: OR 3.2 (present in 8 high-risk patients)

Neo4j Network Insights:
- Patient P001: 12 medications, 8 drug-drug interactions
- Patient P003: 9 medications, 5 interactions, includes 3 twice-daily + 2 three-times-daily
- High complexity correlated with 40% lower adherence

Literature Evidence (Vector DB):
- "Pharmacist MTM interventions improve adherence from 61% → 84% (23% absolute increase)"
- "Simplifying regimens (once-daily formulations) improves adherence by 15-20%"
- "Patient assistance programs reduce cost-related non-adherence by 35%"

Targeted Intervention Strategy:

Tier 1 - High Risk (30 patients):
1. Pharmacist MTM: Comprehensive medication review, simplification where possible
   - Estimated cost: $150 per patient
   - Expected benefit: 23% adherence improvement
   
2. Medication synchronization: Align refill dates to reduce pharmacy visits
   - Cost: $50 per patient
   - Benefit: 10-15% adherence improvement

3. Digital adherence tools: Medication reminder apps, smart pill bottles
   - Cost: $100 per patient/year
   - Benefit: 12% adherence improvement

Total Investment: 30 patients × $300 = $9,000
Expected Outcome: Adherence improves from 60% → 80%

Tier 2 - Moderate Risk (70 patients):
1. Medication education: Group classes on importance of adherence
   - Cost: $50 per patient
   - Benefit: 8-10% improvement

2. Generic substitution review: Reduce out-of-pocket costs
   - Cost: minimal
   - Benefit: 5-8% improvement for cost-sensitive patients

Total Investment: 70 patients × $50 = $3,500

ROI Calculation:
- Poor adherence causes $300B in preventable healthcare costs nationally
- For CHF patients, non-adherence → 2x hospitalization risk
- Preventing 1 HF hospitalization = $15,000 saved
- If intervention prevents 5 hospitalizations among 30 high-risk patients:
  - Savings: 5 × $15,000 = $75,000
  - Cost: $9,000 (Tier 1) + $3,500 (Tier 2) = $12,500
  - Net Savings: $62,500
  - ROI: 500%
```

**Visualization Needs:**
- Network diagram: Patient → Medications → Interactions (Neo4j visualization)
- Risk score distribution histogram
- Adherence improvement: Before/After intervention (bar chart)
- Cost-benefit waterfall chart

---

## IMPLEMENTATION ROADMAP FOR PARTICIPANTS

### Phase 1: Data Preparation
1. Create CSV files from sample data provided
2. Design and create SQL tables
3. Prepare text documents for vector embedding
4. Structure nested JSON clinical pathways

### Phase 2: Infrastructure Setup
1. Install SQL Server / PostgreSQL
2. Set up ChromaDB (local or cloud)
3. Install Neo4j (Desktop or Docker)
4. Configure Python environment with required libraries

### Phase 3: Data Quality Engineering
1. Load data into respective databases
2. Run data quality checks (null checks, referential integrity, JSON validation)
3. Document data quality issues and remediation steps

### Phase 4: EDA & Visualization
1. Flatten nested JSON structures
2. Create visualizations (cost distributions, temporal trends, outlier detection)
3. Generate statistical summaries

### Phase 5: Advanced Analytics
1. Implement Question 1: Readmission risk analysis
2. Implement Question 2: Medication optimization
3. Implement Question 3: Outlier root cause analysis
4. Implement Question 4: Personalized treatment recommendations
5. Implement Question 5: Population health & adherence prediction

### Phase 6: Integration & Reasoning
1. Develop reasoning prompts for LLM integration
2. Create end-to-end pipelines combining all data sources
3. Build dashboard for insights visualization
4. Document findings and recommendations

---

## KEY LEARNING OUTCOMES

By completing this project, participants will demonstrate mastery of:

✓ **SQL Proficiency**: Complex joins, CTEs, window functions, statistical calculations
✓ **Vector Database**: Semantic search, embedding generation, similarity matching
✓ **Graph Database**: Cypher queries, relationship traversal, network analysis
✓ **JSON Processing**: Flattening nested structures, hierarchical data extraction
✓ **Data Quality**: Comprehensive validation across multiple data modalities
✓ **EDA**: Statistical analysis, outlier detection, temporal trend analysis
✓ **Integration**: Combining insights from heterogeneous data sources
✓ **Prompt Engineering**: Crafting effective reasoning prompts for LLMs
✓ **Healthcare Domain**: Clinical pathways, medication management, risk stratification

---

## TECHNOLOGIES & TOOLS

**Required:**
- Python 3.8+
- SQL Server or PostgreSQL
- ChromaDB
- Neo4j Desktop/Community Edition
- Libraries: pandas, sqlalchemy, chromadb, neo4j, matplotlib, seaborn, scipy

**Optional:**
- Jupyter Notebook for interactive analysis
- Docker for containerized deployment
- Streamlit for dashboard creation
- LangChain for LLM integration

---

## DELIVERABLES

1. **Datasets**: CSV files, vector embeddings, knowledge graph exports, JSON files
2. **Quality Reports**: Data quality assessment documents with pass/fail metrics
3. **EDA Notebooks**: Jupyter notebooks with visualizations and statistical analyses
4. **Code Repository**: Well-documented Python scripts for all analyses
5. **Analytical Insights**: Answers to all 5 questions with supporting evidence
6. **Dashboard**: Interactive visualization of key findings
7. **Presentation**: Summary of insights and recommendations for leadership

---

## CONCLUSION

This mini-project provides a comprehensive, real-world healthcare analytics scenario that exercises the full spectrum of modern data engineering and analytics capabilities. By successfully completing all components, participants will demonstrate their ability to:

- Work with heterogeneous data sources
- Ensure data quality and integrity
- Extract intelligent insights through multi-modal analysis
- Apply domain knowledge to healthcare use cases
- Leverage advanced technologies including vector search, graph databases, and LLM reasoning

The project is designed to be impressive, challenging, and directly applicable to professional healthcare analytics roles at organizations.

**Good luck!**
