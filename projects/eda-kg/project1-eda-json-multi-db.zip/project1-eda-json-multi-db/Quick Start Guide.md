# CITIUS HEALTHCARE PROJECT - QUICK START GUIDE

## 🚀 Getting Started in 30 Minutes

### Prerequisites
- Python 3.8 or higher
- Basic knowledge of SQL, JSON, and Python
- 8GB RAM minimum
- 10GB free disk space

---

## Step 1: Install Required Software (10 minutes)

### A. SQL Database (Choose One)
```bash
# Option 1: PostgreSQL (Recommended for beginners)
# Download from: https://www.postgresql.org/download/

# Option 2: SQL Server Express
# Download from: https://www.microsoft.com/en-us/sql-server/sql-server-downloads
```

### B. Neo4j Graph Database
```bash
# Download Neo4j Desktop from: https://neo4j.com/download/
# Or use Docker:
docker run -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password neo4j:latest
```

### C. Python Libraries
```bash
pip install pandas sqlalchemy pyodbc psycopg2-binary \
            chromadb neo4j matplotlib seaborn scipy numpy
```

---

## Step 2: Prepare Your Data (10 minutes)

### A. Create Project Directory
```bash
mkdir citius_healthcare_project
cd citius_healthcare_project
mkdir data outputs visualizations
```

### B. Create CSV Files
Copy the sample data from `SAMPLE_DATA_FILES.md` into these files:
- `data/patients.csv`
- `data/clinical_encounters.csv`
- `data/medications_prescribed.csv`
- `data/lab_results.csv`

### C. Create JSON File
Copy the clinical pathways JSON from the main project document:
- `data/clinical_pathways.json`

---

## Step 3: Load Data (5 minutes)

### A. Load to SQL Database

```python
import pandas as pd
from sqlalchemy import create_engine

# PostgreSQL connection
engine = create_engine('postgresql://username:password@localhost:5432/citius_healthcare')

# OR SQL Server connection
# engine = create_engine('mssql+pyodbc://username:password@localhost/citius_healthcare?driver=ODBC+Driver+17+for+SQL+Server')

# Load CSV files
tables = {
    'patients': 'data/patients.csv',
    'clinical_encounters': 'data/clinical_encounters.csv',
    'medications_prescribed': 'data/medications_prescribed.csv',
    'lab_results': 'data/lab_results.csv'
}

for table_name, csv_path in tables.items():
    df = pd.read_csv(csv_path)
    df.to_sql(table_name, engine, if_exists='replace', index=False)
    print(f"✓ Loaded {table_name}: {len(df)} rows")
```

### B. Load to ChromaDB

```python
import chromadb
import json

client = chromadb.Client()
collection = client.create_collection(name="medical_literature")

# Sample documents (expand with full documents from project)
documents = [
    {
        'doc_id': 'DOC001',
        'title': 'Hypertension Management in Diabetic Patients',
        'content': 'Hypertension management in patients with type 2 diabetes...',
        'doc_type': 'clinical_guideline',
        'specialty': 'Cardiology'
    },
    # Add more documents...
]

for doc in documents:
    collection.add(
        documents=[doc['content']],
        metadatas=[{
            'doc_id': doc['doc_id'],
            'title': doc['title'],
            'doc_type': doc['doc_type'],
            'specialty': doc['specialty']
        }],
        ids=[doc['doc_id']]
    )

print(f"✓ Loaded {len(documents)} documents to ChromaDB")
```

### C. Load to Neo4j

```python
from neo4j import GraphDatabase

driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", "password"))

with open('data/clinical_pathways.json', 'r') as f:
    pathways = json.load(f)

with driver.session() as session:
    for pathway in pathways['clinical_pathways']:
        session.run("""
            CREATE (p:Clinical_Pathway {
                pathway_id: $pathway_id,
                pathway_name: $pathway_name,
                specialty: $specialty
            })
            """,
            pathway_id=pathway['pathway_id'],
            pathway_name=pathway['pathway_name'],
            specialty=pathway['specialty']
        )

print("✓ Loaded clinical pathways to Neo4j")
```

---

## Step 4: Run Your First Analysis (5 minutes)

### Quick Test: Patient Count by Condition

```python
import pandas as pd
from sqlalchemy import create_engine

engine = create_engine('postgresql://username:password@localhost:5432/citius_healthcare')

# Simple query
query = """
SELECT 
    chronic_conditions,
    COUNT(*) as patient_count
FROM patients
WHERE chronic_conditions IS NOT NULL AND chronic_conditions != 'None'
GROUP BY chronic_conditions
ORDER BY patient_count DESC
"""

df = pd.read_sql(query, engine)
print("\nPatient Distribution by Condition:")
print(df)

# Visualization
import matplotlib.pyplot as plt

df.plot(kind='barh', x='chronic_conditions', y='patient_count', 
        title='Patients by Chronic Condition', figsize=(10, 6))
plt.xlabel('Number of Patients')
plt.tight_layout()
plt.savefig('outputs/patient_distribution.png')
print("\n✓ Visualization saved to outputs/patient_distribution.png")
```

Expected Output:
```
Patient Distribution by Condition:
                          chronic_conditions  patient_count
0                    Hypertension,CHF,COPD             1
1       Hypertension,Type 2 Diabetes,CKD...             1
2             Hypertension,Type 2 Diabetes              1
3          Type 2 Diabetes,Hyperlipidemia              1
...
```

---

## Step 5: Run Data Quality Checks (Optional but Recommended)

```python
# Check 1: Null primary keys
query = "SELECT COUNT(*) as null_count FROM patients WHERE patient_id IS NULL"
result = pd.read_sql(query, engine)
print(f"Null Patient IDs: {result['null_count'].iloc[0]} (should be 0)")

# Check 2: Orphaned encounters
query = """
SELECT COUNT(*) as orphaned
FROM clinical_encounters ce
LEFT JOIN patients p ON ce.patient_id = p.patient_id
WHERE p.patient_id IS NULL
"""
result = pd.read_sql(query, engine)
print(f"Orphaned Encounters: {result['orphaned'].iloc[0]} (should be 0)")

# Check 3: Invalid lab values
query = """
SELECT COUNT(*) as invalid
FROM lab_results
WHERE test_name IN ('BNP', 'Creatinine') AND result_value < 0
"""
result = pd.read_sql(query, engine)
print(f"Invalid Lab Values: {result['invalid'].iloc[0]} (should be 0)")

print("\n✓ Data quality checks completed")
```

---

## Step 6: Try an Advanced Query (Example from Question 1)

```python
# Readmission Risk Analysis
query = """
WITH hf_patients AS (
    SELECT 
        ce.patient_id,
        ce.encounter_id,
        ce.readmission_30day,
        p.chronic_conditions,
        EXTRACT(YEAR FROM AGE(ce.encounter_date::date, p.date_of_birth)) as age
    FROM clinical_encounters ce
    INNER JOIN patients p ON ce.patient_id = p.patient_id
    WHERE ce.primary_diagnosis_name LIKE '%Heart Failure%'
),
lab_data AS (
    SELECT 
        lr.patient_id,
        lr.encounter_id,
        MAX(CASE WHEN lr.test_name = 'BNP' THEN lr.result_value END) as bnp,
        MAX(CASE WHEN lr.test_name = 'Creatinine' THEN lr.result_value END) as creatinine
    FROM lab_results lr
    GROUP BY lr.patient_id, lr.encounter_id
)
SELECT 
    hf.patient_id,
    hf.chronic_conditions,
    hf.age,
    ld.bnp,
    ld.creatinine,
    hf.readmission_30day,
    CASE 
        WHEN ld.bnp > 800 THEN 'High Risk'
        WHEN ld.bnp > 400 THEN 'Moderate Risk'
        ELSE 'Low Risk'
    END as risk_category
FROM hf_patients hf
LEFT JOIN lab_data ld ON hf.encounter_id = ld.encounter_id
WHERE hf.readmission_30day = TRUE
ORDER BY ld.bnp DESC NULLS LAST
"""

df_risk = pd.read_sql(query, engine)
print("\nHeart Failure Patients with Readmissions:")
print(df_risk)
```

Expected Output:
```
  patient_id chronic_conditions  age    bnp  creatinine readmission_30day risk_category
0       P003  Hypertension,CH... 71  850.0        1.8        True          High Risk
1       P009  CHF,COPD,Hypert... 79  780.0        1.9        True          Moderate Risk
```

---

## Common Issues & Troubleshooting

### Issue 1: Connection Refused (PostgreSQL)
```bash
# Solution: Start PostgreSQL service
sudo service postgresql start

# Or on Mac with Homebrew:
brew services start postgresql
```

### Issue 2: ChromaDB Import Error
```bash
# Solution: Reinstall with specific version
pip uninstall chromadb
pip install chromadb==0.4.22
```

### Issue 3: Neo4j Authentication Failed
```bash
# Solution: Reset password
# In Neo4j Desktop: Go to Database -> Manage -> Password -> Reset
# Or use cypher-shell:
cypher-shell -u neo4j -p neo4j
ALTER CURRENT USER SET PASSWORD FROM 'neo4j' TO 'newpassword'
```

### Issue 4: SQL Date Format Errors
```python
# Solution: Convert dates during load
df['encounter_date'] = pd.to_datetime(df['encounter_date'])
df['date_of_birth'] = pd.to_datetime(df['date_of_birth']).dt.date
```

---

## Next Steps

### Beginner Path
1. ✅ Complete Steps 1-6 above
2. Run all SQL queries in the implementation file
3. Implement data quality checks
4. Create basic visualizations (bar charts, scatter plots)
5. Answer Question 1 (Readmission Risk)

### Intermediate Path
1. ✅ Complete Beginner Path
2. Implement semantic search with ChromaDB
3. Create Neo4j graph relationships
4. Answer Questions 1-3
5. Create interactive dashboard with Streamlit

### Advanced Path
1. ✅ Complete Intermediate Path
2. Implement all 5 analytical questions
3. Develop reasoning prompts for LLM integration
4. Create comprehensive dashboard
5. Write technical report with insights

---

## Useful Commands Reference

### SQL Queries
```sql
-- View all tables
SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';

-- Count records
SELECT COUNT(*) FROM patients;

-- Check for duplicates
SELECT patient_id, COUNT(*) FROM patients GROUP BY patient_id HAVING COUNT(*) > 1;
```

### ChromaDB Queries
```python
# Simple search
results = collection.query(
    query_texts=["heart failure management"],
    n_results=5
)

# Filtered search
results = collection.query(
    query_texts=["diabetes treatment"],
    where={"doc_type": "clinical_guideline"},
    n_results=3
)
```

### Neo4j Cypher Queries
```cypher
// View all nodes
MATCH (n) RETURN n LIMIT 25;

// Count relationships
MATCH ()-[r]->() RETURN type(r), count(r);

// Find pathways
MATCH (p:Clinical_Pathway) RETURN p.pathway_name, p.specialty;
```

---

## Resources

**Documentation:**
- PostgreSQL: https://www.postgresql.org/docs/
- ChromaDB: https://docs.trychroma.com/
- Neo4j: https://neo4j.com/docs/
- Pandas: https://pandas.pydata.org/docs/

**Learning:**
- SQL Tutorial: https://www.w3schools.com/sql/
- Cypher Tutorial: https://neo4j.com/developer/cypher/
- Vector DB Guide: https://www.pinecone.io/learn/vector-database/

**Community:**
- Stack Overflow: https://stackoverflow.com/
- Neo4j Community: https://community.neo4j.com/
- ChromaDB Discord: https://discord.gg/MMeYNTmh3x

---

## Project Checklist

### Data Preparation ✓
- [ ] Install all required software
- [ ] Create project directory structure
- [ ] Prepare CSV files
- [ ] Create JSON file
- [ ] Load data to SQL
- [ ] Load data to ChromaDB
- [ ] Load data to Neo4j

### Quality Checks ✓
- [ ] Run SQL quality checks
- [ ] Validate JSON structure
- [ ] Check for data consistency
- [ ] Document any issues found

### Analysis ✓
- [ ] Implement Question 1 (Readmission Risk)
- [ ] Implement Question 2 (Medication Optimization)
- [ ] Implement Question 3 (Outlier Detection)
- [ ] Implement Question 4 (Personalized Treatment)
- [ ] Implement Question 5 (Population Health)

### Deliverables ✓
- [ ] Code repository with documentation
- [ ] Data quality report
- [ ] EDA visualizations
- [ ] Analytical insights document
- [ ] Final presentation

---

## Getting Help

If you encounter issues:
1. Check the troubleshooting section above
2. Review error messages carefully
3. Search Stack Overflow
4. Check official documentation
5. Ask in relevant community forums

**Good luck with your project! 🎉**

Remember: The goal is not just to complete the tasks, but to understand the power of combining multiple data modalities for healthcare analytics.
