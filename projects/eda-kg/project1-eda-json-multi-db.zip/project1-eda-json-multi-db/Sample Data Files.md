# CITIUS HEALTHCARE - SAMPLE DATA FILES (Ready to Use)

## File 1: patients.csv

```csv
patient_id,name,date_of_birth,gender,blood_type,primary_physician_id,registration_date,insurance_provider,chronic_conditions
P001,John Anderson,1965-03-15,Male,O+,PHY001,2020-01-10,BlueCross Shield,"Hypertension,Type 2 Diabetes"
P002,Maria Rodriguez,1978-07-22,Female,A+,PHY002,2019-05-20,Aetna,Asthma
P003,David Chen,1952-11-08,Male,B+,PHY001,2018-03-15,Medicare,"Hypertension,CHF,COPD"
P004,Sarah Johnson,1988-09-30,Female,AB-,PHY003,2021-02-14,United Healthcare,None
P005,Robert Williams,1970-05-18,Male,O-,PHY002,2019-08-22,Cigna,"Type 2 Diabetes,Hyperlipidemia"
P006,Jennifer Lee,1955-12-03,Female,A-,PHY001,2020-06-18,Medicare,"Hypertension,Type 2 Diabetes,CKD Stage 3"
P007,Michael Brown,1980-04-25,Male,O+,PHY003,2021-11-08,BlueCross Shield,None
P008,Linda Martinez,1968-08-14,Female,B-,PHY002,2019-12-20,Aetna,"Hypertension,Hyperlipidemia"
P009,James Taylor,1945-02-28,Male,AB+,PHY001,2018-07-15,Medicare,"CHF,COPD,Hypertension,Type 2 Diabetes"
P010,Patricia Wilson,1972-10-09,Female,A+,PHY003,2020-09-03,Cigna,"Asthma,Hyperlipidemia"
```

## File 2: clinical_encounters.csv

```csv
encounter_id,patient_id,encounter_date,encounter_type,primary_diagnosis_code,primary_diagnosis_name,secondary_diagnoses,severity_score,department,attending_physician_id,length_of_stay_hours,total_cost,readmission_30day
ENC001,P001,2024-01-15 09:30:00,Emergency,I10,Essential Hypertension,"[""E11.9"",""Z79.4""]",6,Emergency,PHY001,4.5,2500.00,FALSE
ENC002,P002,2024-01-20 14:15:00,Outpatient,J45.909,Unspecified Asthma,"[]",3,Pulmonology,PHY002,1.0,450.00,FALSE
ENC003,P003,2024-02-10 08:00:00,Inpatient,I50.9,Heart Failure,"[""J44.1"",""I10""]",8,Cardiology,PHY001,72.0,18500.00,TRUE
ENC004,P001,2024-02-18 10:00:00,Emergency,I10,Essential Hypertension,"[""E11.65""]",7,Emergency,PHY001,6.0,3200.00,TRUE
ENC005,P004,2024-03-05 11:30:00,Outpatient,Z00.00,General Adult Medical Exam,"[]",1,Primary Care,PHY003,0.5,280.00,FALSE
ENC006,P005,2024-03-12 13:45:00,Outpatient,E11.9,Type 2 Diabetes,"[""E78.5""]",4,Endocrinology,PHY002,1.5,620.00,FALSE
ENC007,P003,2024-03-18 07:30:00,Inpatient,I50.23,Acute on Chronic Systolic Heart Failure,"[""J44.1"",""I10"",""N18.3""]",9,Cardiology,PHY001,96.0,22400.00,FALSE
ENC008,P006,2024-04-02 10:15:00,Outpatient,E11.9,Type 2 Diabetes,"[""I10"",""N18.3""]",5,Endocrinology,PHY001,1.0,580.00,FALSE
ENC009,P008,2024-04-10 08:45:00,Emergency,I10,Hypertensive Urgency,"[]",6,Emergency,PHY002,5.0,2800.00,FALSE
ENC010,P009,2024-04-15 06:00:00,Inpatient,I50.9,Heart Failure,"[""J44.1"",""E11.9""]",8,Cardiology,PHY001,84.0,19200.00,TRUE
ENC011,P002,2024-04-22 16:30:00,Emergency,J45.901,Asthma Exacerbation,"[]",7,Emergency,PHY002,8.0,3500.00,FALSE
ENC012,P007,2024-05-01 09:00:00,Outpatient,Z00.00,Preventive Care,"[]",1,Primary Care,PHY003,0.5,250.00,FALSE
ENC013,P001,2024-05-08 14:20:00,Outpatient,I10,Essential Hypertension,"[""E11.9""]",4,Primary Care,PHY001,1.0,380.00,FALSE
ENC014,P010,2024-05-15 11:00:00,Outpatient,J45.909,Asthma,"[""E78.5""]",3,Pulmonology,PHY003,1.0,480.00,FALSE
ENC015,P005,2024-05-20 10:30:00,Outpatient,E11.9,Type 2 Diabetes,"[""E78.5"",""I10""]",5,Endocrinology,PHY002,1.5,650.00,FALSE
```

## File 3: medications_prescribed.csv

```csv
prescription_id,encounter_id,patient_id,medication_name,medication_class,dosage,frequency,prescribed_date,duration_days,prescribing_physician_id,indication
RX001,ENC001,P001,Lisinopril,ACE Inhibitor,10mg,Once Daily,2024-01-15,90,PHY001,Hypertension
RX002,ENC001,P001,Metformin,Biguanide,500mg,Twice Daily,2024-01-15,90,PHY001,Type 2 Diabetes
RX003,ENC002,P002,Albuterol,Bronchodilator,90mcg,As Needed,2024-01-20,30,PHY002,Asthma
RX004,ENC003,P003,Furosemide,Loop Diuretic,40mg,Twice Daily,2024-02-10,30,PHY001,Heart Failure
RX005,ENC003,P003,Carvedilol,Beta Blocker,6.25mg,Twice Daily,2024-02-10,30,PHY001,Heart Failure
RX006,ENC003,P003,Spironolactone,MRA,25mg,Once Daily,2024-02-10,30,PHY001,Heart Failure
RX007,ENC003,P003,Sacubitril/Valsartan,ARNI,49/51mg,Twice Daily,2024-02-10,30,PHY001,Heart Failure
RX008,ENC004,P001,Amlodipine,Calcium Channel Blocker,5mg,Once Daily,2024-02-18,90,PHY001,Hypertension
RX009,ENC005,P004,Multivitamin,Supplement,1 tablet,Once Daily,2024-03-05,90,PHY003,General Health
RX010,ENC006,P005,Metformin ER,Biguanide,1000mg,Twice Daily,2024-03-12,90,PHY002,Type 2 Diabetes
RX011,ENC006,P005,Atorvastatin,Statin,40mg,Once Daily,2024-03-12,90,PHY002,Hyperlipidemia
RX012,ENC007,P003,Furosemide,Loop Diuretic,80mg,Twice Daily,2024-03-18,30,PHY001,Heart Failure
RX013,ENC007,P003,Metolazone,Thiazide Diuretic,2.5mg,Once Daily,2024-03-18,14,PHY001,Heart Failure (Diuretic Resistance)
RX014,ENC008,P006,Dapagliflozin,SGLT2 Inhibitor,10mg,Once Daily,2024-04-02,90,PHY001,Type 2 Diabetes + CKD
RX015,ENC008,P006,Lisinopril,ACE Inhibitor,20mg,Once Daily,2024-04-02,90,PHY001,Hypertension + CKD
RX016,ENC009,P008,Amlodipine,Calcium Channel Blocker,10mg,Once Daily,2024-04-10,90,PHY002,Hypertension
RX017,ENC009,P008,Atorvastatin,Statin,20mg,Once Daily,2024-04-10,90,PHY002,Hyperlipidemia
RX018,ENC010,P009,Dapagliflozin,SGLT2 Inhibitor,10mg,Once Daily,2024-04-15,90,PHY001,Heart Failure + Diabetes
RX019,ENC011,P002,Prednisone,Corticosteroid,40mg,Once Daily,2024-04-22,5,PHY002,Asthma Exacerbation
RX020,ENC011,P002,Albuterol,Bronchodilator,90mcg,As Needed,2024-04-22,30,PHY002,Asthma
RX021,ENC013,P001,Metformin ER,Biguanide,1000mg,Twice Daily,2024-05-08,90,PHY001,Type 2 Diabetes
RX022,ENC014,P010,Fluticasone/Salmeterol,Inhaled Corticosteroid,250/50mcg,Twice Daily,2024-05-15,90,PHY003,Asthma
RX023,ENC015,P005,Empagliflozin,SGLT2 Inhibitor,10mg,Once Daily,2024-05-20,90,PHY002,Type 2 Diabetes
```

## File 4: lab_results.csv

```csv
lab_result_id,patient_id,encounter_id,test_name,test_category,result_value,result_unit,reference_range_low,reference_range_high,abnormal_flag,test_date
LAB001,P001,ENC001,Hemoglobin A1c,Diabetes,7.8,%,4.0,5.6,TRUE,2024-01-15 10:00:00
LAB002,P001,ENC001,Systolic BP,Vitals,165,mmHg,90,120,TRUE,2024-01-15 09:30:00
LAB003,P001,ENC001,Creatinine,Renal,1.2,mg/dL,0.6,1.2,FALSE,2024-01-15 10:00:00
LAB004,P002,ENC002,Peak Flow,Pulmonary,380,L/min,400,600,TRUE,2024-01-20 14:20:00
LAB005,P003,ENC003,BNP,Cardiac,850,pg/mL,0,100,TRUE,2024-02-10 08:30:00
LAB006,P003,ENC003,Creatinine,Renal,1.8,mg/dL,0.6,1.2,TRUE,2024-02-10 08:30:00
LAB007,P003,ENC003,Potassium,Electrolyte,4.8,mEq/L,3.5,5.0,FALSE,2024-02-10 08:30:00
LAB008,P001,ENC004,Hemoglobin A1c,Diabetes,7.2,%,4.0,5.6,TRUE,2024-02-18 10:30:00
LAB009,P001,ENC004,Systolic BP,Vitals,158,mmHg,90,120,TRUE,2024-02-18 10:00:00
LAB010,P001,ENC004,Creatinine,Renal,1.3,mg/dL,0.6,1.2,TRUE,2024-02-18 10:30:00
LAB011,P004,ENC005,Total Cholesterol,Lipid,185,mg/dL,0,200,FALSE,2024-03-05 11:45:00
LAB012,P004,ENC005,LDL,Lipid,110,mg/dL,0,100,TRUE,2024-03-05 11:45:00
LAB013,P005,ENC006,Hemoglobin A1c,Diabetes,8.5,%,4.0,5.6,TRUE,2024-03-12 14:00:00
LAB014,P005,ENC006,LDL,Lipid,142,mg/dL,0,100,TRUE,2024-03-12 14:00:00
LAB015,P003,ENC007,BNP,Cardiac,920,pg/mL,0,100,TRUE,2024-03-18 08:00:00
LAB016,P003,ENC007,Creatinine,Renal,2.1,mg/dL,0.6,1.2,TRUE,2024-03-18 08:00:00
LAB017,P003,ENC007,Potassium,Electrolyte,5.2,mEq/L,3.5,5.0,TRUE,2024-03-18 08:00:00
LAB018,P006,ENC008,Hemoglobin A1c,Diabetes,7.9,%,4.0,5.6,TRUE,2024-04-02 10:30:00
LAB019,P006,ENC008,eGFR,Renal,38,mL/min/1.73m2,60,120,TRUE,2024-04-02 10:30:00
LAB020,P006,ENC008,Urine Albumin-Creatinine Ratio,Renal,180,mg/g,0,30,TRUE,2024-04-02 10:30:00
LAB021,P008,ENC009,Systolic BP,Vitals,188,mmHg,90,120,TRUE,2024-04-10 08:45:00
LAB022,P008,ENC009,LDL,Lipid,155,mg/dL,0,100,TRUE,2024-04-10 09:00:00
LAB023,P009,ENC010,BNP,Cardiac,780,pg/mL,0,100,TRUE,2024-04-15 06:30:00
LAB024,P009,ENC010,Hemoglobin A1c,Diabetes,8.8,%,4.0,5.6,TRUE,2024-04-15 06:30:00
LAB025,P009,ENC010,Creatinine,Renal,1.9,mg/dL,0.6,1.2,TRUE,2024-04-15 06:30:00
LAB026,P002,ENC011,Peak Flow,Pulmonary,320,L/min,400,600,TRUE,2024-04-22 16:45:00
LAB027,P002,ENC011,Oxygen Saturation,Vitals,88,%,95,100,TRUE,2024-04-22 16:30:00
LAB028,P007,ENC012,Total Cholesterol,Lipid,172,mg/dL,0,200,FALSE,2024-05-01 09:15:00
LAB029,P007,ENC012,Blood Glucose,Diabetes,94,mg/dL,70,100,FALSE,2024-05-01 09:15:00
LAB030,P001,ENC013,Hemoglobin A1c,Diabetes,6.9,%,4.0,5.6,TRUE,2024-05-08 14:30:00
LAB031,P001,ENC013,Systolic BP,Vitals,132,mmHg,90,120,FALSE,2024-05-08 14:20:00
LAB032,P010,ENC014,Peak Flow,Pulmonary,450,L/min,400,600,FALSE,2024-05-15 11:15:00
LAB033,P005,ENC015,Hemoglobin A1c,Diabetes,7.6,%,4.0,5.6,TRUE,2024-05-20 10:45:00
LAB034,P005,ENC015,LDL,Lipid,118,mg/dL,0,100,TRUE,2024-05-20 10:45:00
```

## File 5: clinical_pathways.json

The complete JSON is provided in the main project document. It includes:
- CP001: Hypertensive Crisis Management
- CP002: Heart Failure Decompensation Protocol
- CP003: Type 2 Diabetes Comprehensive Management

Each pathway contains:
- Multi-level care stages
- Nested medication algorithms
- Decision points with branching logic
- Quality metrics and cost benchmarks
- Evidence-based references

---

## HOW TO USE THESE FILES

### For SQL Database:
```python
import pandas as pd
from sqlalchemy import create_engine

# Read CSV
df_patients = pd.read_csv('patients.csv')
df_encounters = pd.read_csv('clinical_encounters.csv')
df_medications = pd.read_csv('medications_prescribed.csv')
df_labs = pd.read_csv('lab_results.csv')

# Create SQL engine
engine = create_engine('mssql+pyodbc://username:password@server/database?driver=ODBC+Driver+17+for+SQL+Server')

# Load to SQL
df_patients.to_sql('patients', engine, if_exists='replace', index=False)
df_encounters.to_sql('clinical_encounters', engine, if_exists='replace', index=False)
df_medications.to_sql('medications_prescribed', engine, if_exists='replace', index=False)
df_labs.to_sql('lab_results', engine, if_exists='replace', index=False)
```

### For Vector Database (ChromaDB):
```python
import chromadb

client = chromadb.Client()
collection = client.create_collection(name="medical_literature")

# Documents are provided in the main project file
# Load and embed each document
```

### For Knowledge Graph (Neo4j):
```python
from neo4j import GraphDatabase

driver = GraphDatabase.driver("bolt://localhost:7687", auth=("neo4j", "password"))

# Load clinical_pathways.json and create nodes/relationships
# Code provided in implementation file
```

---

## DATA STATISTICS

**Patients**: 10 records
- Age range: 38-78 years
- 6 with chronic conditions (60%)
- Multiple comorbidities: 4 patients (40%)

**Clinical Encounters**: 15 records
- Emergency: 5 (33%)
- Inpatient: 3 (20%)
- Outpatient: 7 (47%)
- Readmissions: 3 (20%)
- Cost range: $250 - $22,400

**Medications**: 23 prescriptions
- 12 unique medication classes
- Polypharmacy (≥5 meds): 3 patients
- SGLT2 inhibitors: 3 (reflecting current best practices)

**Lab Results**: 34 test results
- Abnormal results: 26 (76%)
- Most common abnormal: HbA1c, BNP, BP
- Temporal trends available for 3 patients

**Clinical Pathways**: 3 comprehensive protocols
- Total care stages: 12
- Medications documented: 25+
- Decision points: 8
- Nested depth: up to 5 levels

---

This sample dataset is realistic, clinically accurate, and rich enough to demonstrate all analytical capabilities while being manageable for a mini-project.
