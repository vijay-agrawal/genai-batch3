
// ============================================================================
// Medical Knowledge Graph - Auto-generated Cypher Script
// Generated: 2024-01-20 10:30:00
// ============================================================================

// Clear existing data (CAUTION: Only for demo purposes!)
MATCH (n) DETACH DELETE n;

// Constraints
CREATE CONSTRAINT IF NOT EXISTS FOR (p:Patient) REQUIRE p.patient_id IS UNIQUE
;

CREATE CONSTRAINT IF NOT EXISTS FOR (d:Disease) REQUIRE d.disease_id IS UNIQUE
;

CREATE CONSTRAINT IF NOT EXISTS FOR (m:Medication) REQUIRE m.medication_id IS UNIQUE
;

// Create Nodes and Relationships

// Create Patient: John Smith
CREATE (p:Patient {
  patient_id: 'P001',
  name: 'John Smith',
  age: 58,
  gender: 'M',
  date_of_visit: date('2024-01-15')
})
;

// Create/Merge Disease: Hypertension
MERGE (d:Disease {disease_id: 'I10'})
ON CREATE SET
  d.canonical_name = 'Hypertension',
  d.icd10_code = 'I10',
  d.snomed_code = '38341003',
  d.category = 'Cardiovascular'
;

// Create Diagnosis relationship
MATCH (p:Patient {patient_id: 'P001'})
MATCH (d:Disease {disease_id: 'I10'})
CREATE (p)-[r:HAS_DIAGNOSIS]->(diag:Diagnosis)-[r2:IS_DISEASE]->(d)
SET diag.diagnosis_id = randomUUID(),
    diag.date = date('2024-01-15'),
    diag.is_negated = false,
    diag.original_text = 'hypertension',
    r.confidence = 1.00,
    r.extraction_method = 'exact',
    r2.matched_text = 'hypertension'
;

// Create/Merge Disease: Type 2 Diabetes Mellitus
MERGE (d:Disease {disease_id: 'E11'})
ON CREATE SET
  d.canonical_name = 'Type 2 Diabetes Mellitus',
  d.icd10_code = 'E11',
  d.snomed_code = '44054006',
  d.category = 'Endocrine'
;

// Create Diagnosis relationship
MATCH (p:Patient {patient_id: 'P001'})
MATCH (d:Disease {disease_id: 'E11'})
CREATE (p)-[r:HAS_DIAGNOSIS]->(diag:Diagnosis)-[r2:IS_DISEASE]->(d)
SET diag.diagnosis_id = randomUUID(),
    diag.date = date('2024-01-15'),
    diag.is_negated = false,
    diag.original_text = 'Type 2 diabetes mellitus',
    r.confidence = 1.00,
    r.extraction_method = 'exact',
    r2.matched_text = 'Type 2 diabetes mellitus'
;

// Create/Merge Disease: Myocardial Ischemia
MERGE (d:Disease {disease_id: 'I25.9'})
ON CREATE SET
  d.canonical_name = 'Myocardial Ischemia',
  d.icd10_code = 'I25.9',
  d.snomed_code = '414795007',
  d.category = 'Cardiovascular'
;

// Create Diagnosis relationship
MATCH (p:Patient {patient_id: 'P001'})
MATCH (d:Disease {disease_id: 'I25.9'})
CREATE (p)-[r:HAS_DIAGNOSIS]->(diag:Diagnosis)-[r2:IS_DISEASE]->(d)
SET diag.diagnosis_id = randomUUID(),
    diag.date = date('2024-01-15'),
    diag.is_negated = false,
    diag.original_text = 'myocardial ischemia',
    r.confidence = 1.00,
    r.extraction_method = 'exact',
    r2.matched_text = 'myocardial ischemia'
;

// Create/Merge Medication: Aspirin
MERGE (m:Medication {medication_id: '1191'})
ON CREATE SET
  m.generic_name = 'Aspirin',
  m.drug_class = 'Antiplatelet',
  m.rxnorm_code = '1191'
;

// Create Prescription relationship
MATCH (p:Patient {patient_id: 'P001'})
MATCH (m:Medication {medication_id: '1191'})
CREATE (p)-[r:PRESCRIBED]->(m)
SET r.date = date('2024-01-15'),
    r.dosage = '81mg',
    r.frequency = 'daily',
    r.original_text = 'aspirin'
;

// Create/Merge Medication: Metoprolol
MERGE (m:Medication {medication_id: '6918'})
ON CREATE SET
  m.generic_name = 'Metoprolol',
  m.drug_class = 'Beta Blocker',
  m.rxnorm_code = '6918'
;

// Create Prescription relationship
MATCH (p:Patient {patient_id: 'P001'})
MATCH (m:Medication {medication_id: '6918'})
CREATE (p)-[r:PRESCRIBED]->(m)
SET r.date = date('2024-01-15'),
    r.dosage = '50mg',
    r.frequency = 'BID',
    r.original_text = 'metoprolol'
;

// Create/Merge Medication: Metformin
MERGE (m:Medication {medication_id: '6809'})
ON CREATE SET
  m.generic_name = 'Metformin',
  m.drug_class = 'Biguanide',
  m.rxnorm_code = '6809'
;

// Create Prescription relationship
MATCH (p:Patient {patient_id: 'P001'})
MATCH (m:Medication {medication_id: '6809'})
CREATE (p)-[r:PRESCRIBED]->(m)
SET r.date = date('2024-01-15'),
    r.dosage = '1000mg',
    r.frequency = 'BID',
    r.original_text = 'metformin'
;

// Create Patient: Mary Johnson
CREATE (p:Patient {
  patient_id: 'P002',
  name: 'Mary Johnson',
  age: 45,
  gender: 'F',
  date_of_visit: date('2024-01-16')
})
;

// Create/Merge Disease: Migraine
MERGE (d:Disease {disease_id: 'G43.909'})
ON CREATE SET
  d.canonical_name = 'Migraine',
  d.icd10_code = 'G43.909',
  d.snomed_code = '37796009',
  d.category = 'Neurological'
;

// Create Diagnosis relationship
MATCH (p:Patient {patient_id: 'P002'})
MATCH (d:Disease {disease_id: 'G43.909'})
CREATE (p)-[r:HAS_DIAGNOSIS]->(diag:Diagnosis)-[r2:IS_DISEASE]->(d)
SET diag.diagnosis_id = randomUUID(),
    diag.date = date('2024-01-16'),
    diag.is_negated = false,
    diag.original_text = 'chronic migraine',
    r.confidence = 1.00,
    r.extraction_method = 'exact',
    r2.matched_text = 'chronic migraine'
;

// Create/Merge Medication: Sumatriptan
MERGE (m:Medication {medication_id: '10180'})
ON CREATE SET
  m.generic_name = 'Sumatriptan',
  m.drug_class = 'Triptan',
  m.rxnorm_code = '10180'
;

// Create Prescription relationship
MATCH (p:Patient {patient_id: 'P002'})
MATCH (m:Medication {medication_id: '10180'})
CREATE (p)-[r:PRESCRIBED]->(m)
SET r.date = date('2024-01-16'),
    r.dosage = '50mg',
    r.frequency = 'PRN',
    r.original_text = 'sumatriptan'
;

// Create/Merge Medication: Propranolol
MERGE (m:Medication {medication_id: '8787'})
ON CREATE SET
  m.generic_name = 'Propranolol',
  m.drug_class = 'Beta Blocker',
  m.rxnorm_code = '8787'
;

// Create Prescription relationship
MATCH (p:Patient {patient_id: 'P002'})
MATCH (m:Medication {medication_id: '8787'})
CREATE (p)-[r:PRESCRIBED]->(m)
SET r.date = date('2024-01-16'),
    r.dosage = '40mg',
    r.frequency = 'daily',
    r.original_text = 'propranolol'
;

// ... Additional patients P003, P004, P005 follow the same pattern ...

// End of script
