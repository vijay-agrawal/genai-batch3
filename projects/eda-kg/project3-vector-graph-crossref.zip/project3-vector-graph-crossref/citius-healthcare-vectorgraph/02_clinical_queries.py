#!/usr/bin/env python3
"""
Clinical Queries: Demonstrating Hybrid Vector + Graph Search
============================================================

This script shows real-world clinical queries that leverage BOTH databases.
Each query demonstrates a different cross-linking pattern.

Run this after 01_setup_healthcare_dbs.py
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent))

from utils.vector_db_manager import VectorDBManager
from utils.graph_db_manager import GraphDBManager
from utils.clinical_search import ClinicalSearch


def query_1_similar_symptoms():
    """
    Query 1: Find patients with similar symptoms
    
    Pattern: Vector Search → Graph Traversal
    Use case: Doctor sees a patient with specific symptoms, wants to find similar cases
    """
    print("\n" + "="*80)
    print("QUERY 1: Find Similar Clinical Cases")
    print("="*80)
    print("\nScenario: A physician sees a patient presenting with:")
    print("  'Fatigue, joint pain, and elevated inflammatory markers'")
    print("\nLet's find similar cases and explore their diagnoses...\n")
    
    input("Press Enter to run the query...")
    
    # Initialize databases
    vector_db = VectorDBManager(persist_directory="./chroma_citius_db")
    graph_db = GraphDBManager()
    clinical_search = ClinicalSearch(vector_db, graph_db)
    
    # Run hybrid search
    results = clinical_search.find_similar_cases_with_relationships(
        query="fatigue joint pain elevated inflammatory markers",
        n_results=3
    )
    
    # Display enriched results
    clinical_search.print_enriched_results(results)
    
    print("\n💡 Key Insight:")
    print("   Vector DB found semantically similar clinical presentations")
    print("   Graph DB revealed diagnoses: Rheumatoid Arthritis, Lupus")
    print("   This helps the physician narrow differential diagnosis!")
    
    graph_db.close()


def query_2_drug_interactions():
    """
    Query 2: Check for dangerous drug interactions
    
    Pattern: Graph Traversal for Safety
    Use case: Prevent adverse drug reactions
    """
    print("\n" + "="*80)
    print("QUERY 2: Drug Interaction Safety Check")
    print("="*80)
    print("\nScenario: Patient PAT007 is on multiple medications.")
    print("Let's check for potentially dangerous interactions...\n")
    
    input("Press Enter to run the query...")
    
    graph_db = GraphDBManager()
    
    # Get patient's current medications
    print("📋 Current Medications:")
    medications = graph_db.get_patient_medications("PAT007")
    for med in medications:
        print(f"  • {med['name']} (since {med['start_date']})")
    
    # Check for interactions
    print("\n⚠️  Checking for drug interactions...")
    interactions = graph_db.check_drug_interactions("PAT007")
    
    if interactions:
        print(f"\n🚨 WARNING: {len(interactions)} interaction(s) detected!\n")
        for interaction in interactions:
            print(f"{'─'*60}")
            print(f"Interaction: {interaction['medication1']} + {interaction['medication2']}")
            print(f"Severity: {interaction['severity']}")
            print(f"Details: {interaction['description']}")
            print(f"{'─'*60}\n")
    else:
        print("\n✅ No interactions detected")
    
    print("\n💡 Key Insight:")
    print("   Graph database's relationship model makes it easy to check")
    print("   for complex multi-way interactions across a patient's medications")
    print("   This is CRITICAL for patient safety!")
    
    graph_db.close()


def query_3_comorbidity_cohort():
    """
    Query 3: Find patients with specific comorbidities
    
    Pattern: Graph Query → Vector Retrieval
    Use case: Clinical research, cohort discovery
    """
    print("\n" + "="*80)
    print("QUERY 3: Comorbidity Cohort Discovery")
    print("="*80)
    print("\nScenario: Research team wants to study patients with both:")
    print("  - Type 2 Diabetes (COND001)")
    print("  - Chronic Kidney Disease (COND003)")
    print("\nLet's find this cohort and review their clinical narratives...\n")
    
    input("Press Enter to run the query...")
    
    vector_db = VectorDBManager(persist_directory="./chroma_citius_db")
    graph_db = GraphDBManager()
    clinical_search = ClinicalSearch(vector_db, graph_db)
    
    # Find patients with both conditions
    results = clinical_search.find_cases_by_comorbidities(
        condition_ids=["COND001", "COND003"]  # Diabetes + CKD
    )
    
    print(f"\n📊 Found {len(results)} patients with both conditions:\n")
    
    for i, result in enumerate(results, 1):
        print(f"{'─'*80}")
        print(f"Patient {i}: {result['patient_id']}")
        print(f"Age: {result['patient_info']['age']}")
        
        print(f"\n🔬 All Conditions:")
        for cond in result['conditions']:
            print(f"  • {cond['name']} (diagnosed: {cond['diagnosed_date']})")
        
        print(f"\n💊 Current Medications:")
        for med in result['medications'][:5]:  # Show first 5
            print(f"  • {med['name']}")
        
        print(f"\n📝 Clinical Notes: {len(result['clinical_notes'])} notes available")
        if result['clinical_notes']:
            print(f"\n   Most recent note excerpt:")
            first_note = result['clinical_notes'][0][:250]
            print(f"   '{first_note}...'")
    
    print(f"\n{'─'*80}")
    print("\n💡 Key Insight:")
    print("   Graph DB efficiently found patients with BOTH conditions")
    print("   Vector DB provided rich clinical narratives for context")
    print("   This enables targeted clinical research and personalized care!")
    
    graph_db.close()


def query_4_treatment_patterns():
    """
    Query 4: Analyze treatment patterns for a condition
    
    Pattern: Combined Analysis
    Use case: Evidence-based medicine, quality improvement
    """
    print("\n" + "="*80)
    print("QUERY 4: Treatment Pattern Analysis")
    print("="*80)
    print("\nScenario: Clinical team wants to understand treatment patterns for:")
    print("  Rheumatoid Arthritis (COND004)")
    print("\nLet's analyze what medications are commonly prescribed...\n")
    
    input("Press Enter to run the query...")
    
    vector_db = VectorDBManager(persist_directory="./chroma_citius_db")
    graph_db = GraphDBManager()
    clinical_search = ClinicalSearch(vector_db, graph_db)
    
    # Analyze treatment patterns
    analysis = clinical_search.get_treatment_patterns(
        condition_id="COND004"  # Rheumatoid Arthritis
    )
    
    print(f"\n📊 Treatment Pattern Analysis Results:")
    print(f"   Condition: Rheumatoid Arthritis")
    print(f"   Cohort Size: {analysis['total_patients']} patients")
    
    print("\n💡 Key Insight:")
    print("   By combining graph relationships and clinical narratives,")
    print("   we can identify best practices and improve treatment protocols!")
    
    graph_db.close()


def query_5_patient_journey():
    """
    Query 5: Trace a patient's complete medical journey
    
    Pattern: Comprehensive Cross-Linked View
    Use case: Care coordination, case review
    """
    print("\n" + "="*80)
    print("QUERY 5: Complete Patient Medical Journey")
    print("="*80)
    print("\nScenario: Care coordinator needs complete view of patient PAT001")
    print("\nLet's trace their entire medical journey...\n")
    
    input("Press Enter to run the query...")
    
    vector_db = VectorDBManager(persist_directory="./chroma_citius_db")
    graph_db = GraphDBManager()
    
    patient_id = "PAT001"
    
    # Get structured data from graph
    print("🔍 Retrieving structured medical data from Graph DB...")
    conditions = graph_db.get_patient_conditions(patient_id)
    medications = graph_db.get_patient_medications(patient_id, active_only=False)
    interactions = graph_db.check_drug_interactions(patient_id)
    
    # Get clinical narratives from vector DB
    print("📝 Retrieving clinical narratives from Vector DB...")
    notes = vector_db.search_by_patient(patient_id)
    
    # Display comprehensive view
    print(f"\n{'='*80}")
    print(f"PATIENT MEDICAL SUMMARY: {patient_id}")
    print(f"{'='*80}")
    
    print(f"\n🔬 Medical Conditions ({len(conditions)}):")
    for cond in conditions:
        print(f"  • {cond['name']}")
        print(f"    Category: {cond['category']}")
        print(f"    Diagnosed: {cond['diagnosed_date']}")
        print()
    
    print(f"\n💊 Medication History ({len(medications)}):")
    active_meds = [m for m in medications if m['active']]
    inactive_meds = [m for m in medications if not m['active']]
    
    print(f"  Active ({len(active_meds)}):")
    for med in active_meds:
        print(f"    ✓ {med['name']} (started: {med['start_date']})")
    
    if inactive_meds:
        print(f"  Discontinued ({len(inactive_meds)}):")
        for med in inactive_meds:
            print(f"    ✗ {med['name']} (started: {med['start_date']})")
    
    if interactions:
        print(f"\n⚠️  Active Drug Interactions ({len(interactions)}):")
        for interaction in interactions:
            print(f"  ! {interaction['medication1']} + {interaction['medication2']}")
            print(f"    Severity: {interaction['severity']}")
    else:
        print(f"\n✅ No active drug interactions detected")
    
    print(f"\n📋 Clinical Notes ({len(notes['documents'])}):")
    for i, (note_id, note_meta) in enumerate(zip(notes['ids'], notes['metadatas']), 1):
        print(f"  {i}. {note_meta['note_type']} - {note_meta['date']}")
    
    print(f"\n{'─'*80}")
    print("\n💡 Key Insight:")
    print("   Cross-linking gives us a COMPLETE patient view:")
    print("   • Structured data (diagnoses, meds) from Graph DB")
    print("   • Rich narratives (clinical context) from Vector DB")
    print("   • Safety checks (interactions) via graph traversal")
    print("   • All connected through bidirectional references!")
    
    graph_db.close()


def main():
    """
    Run all example queries.
    """
    print("\n" + "="*80)
    print("🏥 CITIUS HEALTHCARE - CLINICAL QUERIES DEMONSTRATION")
    print("   Hybrid Vector + Graph Database Queries")
    print("="*80)
    
    print("\nThis demo shows 5 real-world clinical queries that leverage")
    print("cross-linking between Vector and Graph databases.\n")
    
    queries = [
        ("Query 1: Similar Symptoms Search", query_1_similar_symptoms),
        ("Query 2: Drug Interaction Check", query_2_drug_interactions),
        ("Query 3: Comorbidity Cohort Discovery", query_3_comorbidity_cohort),
        ("Query 4: Treatment Pattern Analysis", query_4_treatment_patterns),
        ("Query 5: Patient Journey View", query_5_patient_journey)
    ]
    
    print("Available queries:")
    for i, (name, _) in enumerate(queries, 1):
        print(f"  {i}. {name}")
    
    print("\nOptions:")
    print("  • Press Enter to run all queries sequentially")
    print("  • Type a number (1-5) to run a specific query")
    print("  • Type 'q' to quit")
    
    choice = input("\nYour choice: ").strip()
    
    if choice.lower() == 'q':
        print("Exiting...")
        return
    elif choice.isdigit() and 1 <= int(choice) <= len(queries):
        # Run specific query
        _, query_func = queries[int(choice) - 1]
        query_func()
    else:
        # Run all queries
        for i, (name, query_func) in enumerate(queries, 1):
            print(f"\n\n{'#'*80}")
            print(f"# {i}/{len(queries)}: {name}")
            print(f"{'#'*80}")
            query_func()
            
            if i < len(queries):
                print("\n" + "─"*80)
                input("\nPress Enter to continue to next query...")
    
    print("\n" + "="*80)
    print("🎉 DEMONSTRATION COMPLETE!")
    print("="*80)
    print("\n✅ You've seen how cross-linking Vector and Graph databases")
    print("   enables powerful clinical intelligence queries!")
    
    print("\nNext Steps:")
    print("   • Run: python 03_demonstrate_value.py")
    print("     (See side-by-side comparison)")
    print("   • Run: python 04_interactive_demo.py")
    print("     (Try your own queries)")


if __name__ == "__main__":
    main()
