"""
Graph Database Manager for Clinical Data
========================================

This module handles all interactions with the Graph Database (Neo4j).
It stores entities (patients, conditions, medications) and their relationships.

Key Concepts:
- Nodes: Entities like patients, conditions, medications
- Relationships: Connections between nodes (e.g., Patient -HAS_CONDITION-> Condition)
- Properties: Attributes of nodes (including vector chunk IDs for cross-linking)
- Cypher: Neo4j's query language (similar to SQL)
"""

from neo4j import GraphDatabase
from typing import List, Dict, Any, Optional
import json


class GraphDBManager:
    """
    Manages the Graph Database for storing clinical entities and relationships.
    
    This class provides methods to:
    1. Initialize the graph database
    2. Create nodes for patients, conditions, medications, etc.
    3. Create relationships between entities
    4. Query the graph to find related entities
    5. Cross-link to vector database chunks
    """
    
    def __init__(self, uri: str = "bolt://localhost:7687", user: str = "neo4j", password: str = "citius123"):
        """
        Initialize the Graph Database Manager.
        
        Args:
            uri: Neo4j connection string
            user: Database username
            password: Database password
        """
        print("🟢 Initializing Graph Database (Neo4j)...")
        
        try:
            # Create a driver for Neo4j connection
            self.driver = GraphDatabase.driver(uri, auth=(user, password))
            
            # Test the connection
            self.driver.verify_connectivity()
            print("✅ Successfully connected to Neo4j!")
            
            # Create indexes for better performance
            self._create_indexes()
            
        except Exception as e:
            print(f"❌ Failed to connect to Neo4j: {e}")
            print("   Make sure Neo4j is running on localhost:7687")
            print("   with username='neo4j' and password='citius123'")
            raise
    
    def _create_indexes(self):
        """
        Create indexes on frequently queried properties.
        Indexes make lookups much faster (like in SQL).
        """
        with self.driver.session() as session:
            # Create index on Patient ID
            session.run("CREATE INDEX patient_id_index IF NOT EXISTS FOR (p:Patient) ON (p.id)")
            # Create index on Condition ID
            session.run("CREATE INDEX condition_id_index IF NOT EXISTS FOR (c:Condition) ON (c.id)")
            # Create index on Medication ID
            session.run("CREATE INDEX medication_id_index IF NOT EXISTS FOR (m:Medication) ON (m.id)")
    
    def close(self):
        """Close the database connection."""
        self.driver.close()
        print("🔴 Neo4j connection closed")
    
    # ============================================================
    # NODE CREATION METHODS
    # ============================================================
    
    def create_patient(
        self,
        patient_id: str,
        name: str,
        age: int,
        gender: str,
        mrn: str,
        chunk_ids: List[str] = None
    ) -> None:
        """
        Create a Patient node in the graph.
        
        IMPORTANT: The chunk_ids list contains IDs of documents in the vector database.
        This is how we cross-link from graph to vector database!
        
        Args:
            patient_id: Unique patient identifier
            name: Patient name
            age: Patient age
            gender: Patient gender
            mrn: Medical Record Number
            chunk_ids: List of vector database chunk IDs related to this patient
        """
        with self.driver.session() as session:
            # Cypher query to create a Patient node
            # MERGE means "create if doesn't exist, otherwise update"
            query = """
            MERGE (p:Patient {id: $patient_id})
            SET p.name = $name,
                p.age = $age,
                p.gender = $gender,
                p.mrn = $mrn,
                p.chunk_ids = $chunk_ids
            RETURN p
            """
            
            session.run(
                query,
                patient_id=patient_id,
                name=name,
                age=age,
                gender=gender,
                mrn=mrn,
                chunk_ids=chunk_ids or []  # Empty list if None
            )
            
            print(f"  ✅ Created/Updated Patient: {patient_id} ({name})")
    
    def create_condition(
        self,
        condition_id: str,
        name: str,
        icd10: str,
        category: str
    ) -> None:
        """
        Create a Condition node in the graph.
        
        Args:
            condition_id: Unique condition identifier
            name: Condition name (e.g., "Type 2 Diabetes")
            icd10: ICD-10 code
            category: Category (e.g., "Endocrine", "Cardiovascular")
        """
        with self.driver.session() as session:
            query = """
            MERGE (c:Condition {id: $condition_id})
            SET c.name = $name,
                c.icd10 = $icd10,
                c.category = $category
            RETURN c
            """
            
            session.run(
                query,
                condition_id=condition_id,
                name=name,
                icd10=icd10,
                category=category
            )
            
            print(f"  ✅ Created/Updated Condition: {condition_id} ({name})")
    
    def create_medication(
        self,
        medication_id: str,
        name: str,
        drug_class: str,
        indications: List[str],
        warnings: List[str]
    ) -> None:
        """
        Create a Medication node in the graph.
        
        Args:
            medication_id: Unique medication identifier
            name: Medication name (e.g., "Metformin")
            drug_class: Drug class (e.g., "Biguanide")
            indications: List of what it's used for
            warnings: List of warnings/contraindications
        """
        with self.driver.session() as session:
            query = """
            MERGE (m:Medication {id: $medication_id})
            SET m.name = $name,
                m.class = $drug_class,
                m.indications = $indications,
                m.warnings = $warnings
            RETURN m
            """
            
            session.run(
                query,
                medication_id=medication_id,
                name=name,
                drug_class=drug_class,
                indications=indications,
                warnings=warnings
            )
            
            print(f"  ✅ Created/Updated Medication: {medication_id} ({name})")
    
    def create_symptom(self, symptom_id: str, name: str, severity_range: str) -> None:
        """Create a Symptom node."""
        with self.driver.session() as session:
            query = """
            MERGE (s:Symptom {id: $symptom_id})
            SET s.name = $name,
                s.severity_range = $severity_range
            RETURN s
            """
            session.run(query, symptom_id=symptom_id, name=name, severity_range=severity_range)
            print(f"  ✅ Created/Updated Symptom: {symptom_id} ({name})")
    
    # ============================================================
    # RELATIONSHIP CREATION METHODS
    # ============================================================
    
    def create_patient_condition_relationship(
        self,
        patient_id: str,
        condition_id: str,
        diagnosed_date: str
    ) -> None:
        """
        Create a relationship: Patient -[HAS_CONDITION]-> Condition
        
        This represents "Patient X was diagnosed with Condition Y"
        
        Args:
            patient_id: The patient
            condition_id: The condition
            diagnosed_date: When it was diagnosed
        """
        with self.driver.session() as session:
            query = """
            MATCH (p:Patient {id: $patient_id})
            MATCH (c:Condition {id: $condition_id})
            MERGE (p)-[r:HAS_CONDITION]->(c)
            SET r.diagnosed_date = $diagnosed_date
            RETURN p, r, c
            """
            
            session.run(
                query,
                patient_id=patient_id,
                condition_id=condition_id,
                diagnosed_date=diagnosed_date
            )
            
            print(f"  ✅ Linked {patient_id} -[HAS_CONDITION]-> {condition_id}")
    
    def create_patient_medication_relationship(
        self,
        patient_id: str,
        medication_id: str,
        start_date: str,
        active: bool = True
    ) -> None:
        """
        Create a relationship: Patient -[TAKES_MEDICATION]-> Medication
        
        Args:
            patient_id: The patient
            medication_id: The medication
            start_date: When they started taking it
            active: Whether they're currently taking it
        """
        with self.driver.session() as session:
            query = """
            MATCH (p:Patient {id: $patient_id})
            MATCH (m:Medication {id: $medication_id})
            MERGE (p)-[r:TAKES_MEDICATION]->(m)
            SET r.start_date = $start_date,
                r.active = $active
            RETURN p, r, m
            """
            
            session.run(
                query,
                patient_id=patient_id,
                medication_id=medication_id,
                start_date=start_date,
                active=active
            )
            
            print(f"  ✅ Linked {patient_id} -[TAKES_MEDICATION]-> {medication_id}")
    
    def create_drug_interaction(
        self,
        med1_id: str,
        med2_id: str,
        severity: str,
        description: str
    ) -> None:
        """
        Create a relationship between two medications showing they interact.
        
        This is critical for clinical safety!
        
        Args:
            med1_id: First medication
            med2_id: Second medication
            severity: "Major", "Moderate", or "Minor"
            description: What the interaction is
        """
        with self.driver.session() as session:
            query = """
            MATCH (m1:Medication {id: $med1_id})
            MATCH (m2:Medication {id: $med2_id})
            MERGE (m1)-[r:INTERACTS_WITH]->(m2)
            SET r.severity = $severity,
                r.description = $description
            RETURN m1, r, m2
            """
            
            session.run(
                query,
                med1_id=med1_id,
                med2_id=med2_id,
                severity=severity,
                description=description
            )
            
            print(f"  ⚠️  Created drug interaction: {med1_id} <-> {med2_id} ({severity})")
    
    # ============================================================
    # QUERY METHODS - THE POWER OF GRAPHS!
    # ============================================================
    
    def get_patient_conditions(self, patient_id: str) -> List[Dict[str, Any]]:
        """
        Get all conditions for a patient.
        
        This demonstrates graph traversal: follow relationships from a patient node.
        
        Args:
            patient_id: The patient to query
        
        Returns:
            List of conditions with their properties
        """
        with self.driver.session() as session:
            query = """
            MATCH (p:Patient {id: $patient_id})-[r:HAS_CONDITION]->(c:Condition)
            RETURN c.id AS id, c.name AS name, c.category AS category, 
                   r.diagnosed_date AS diagnosed_date
            ORDER BY r.diagnosed_date
            """
            
            result = session.run(query, patient_id=patient_id)
            return [dict(record) for record in result]
    
    def get_patient_medications(self, patient_id: str, active_only: bool = True) -> List[Dict[str, Any]]:
        """
        Get all medications for a patient.
        
        Args:
            patient_id: The patient to query
            active_only: If True, only return currently active medications
        
        Returns:
            List of medications with their properties
        """
        with self.driver.session() as session:
            if active_only:
                query = """
                MATCH (p:Patient {id: $patient_id})-[r:TAKES_MEDICATION]->(m:Medication)
                WHERE r.active = true
                RETURN m.id AS id, m.name AS name, m.class AS class, 
                       r.start_date AS start_date, r.active AS active
                ORDER BY r.start_date
                """
            else:
                query = """
                MATCH (p:Patient {id: $patient_id})-[r:TAKES_MEDICATION]->(m:Medication)
                RETURN m.id AS id, m.name AS name, m.class AS class, 
                       r.start_date AS start_date, r.active AS active
                ORDER BY r.start_date
                """
            
            result = session.run(query, patient_id=patient_id)
            return [dict(record) for record in result]
    
    def check_drug_interactions(self, patient_id: str) -> List[Dict[str, Any]]:
        """
        Check for drug interactions in a patient's current medications.
        
        This is a CRITICAL safety check! It finds if any two medications
        the patient is taking have known interactions.
        
        Args:
            patient_id: The patient to check
        
        Returns:
            List of interactions found
        """
        with self.driver.session() as session:
            # This query:
            # 1. Finds all active medications for the patient
            # 2. Checks if any pairs have INTERACTS_WITH relationships
            # 3. Returns the interaction details
            query = """
            MATCH (p:Patient {id: $patient_id})-[r1:TAKES_MEDICATION]->(m1:Medication)
            WHERE r1.active = true
            MATCH (p)-[r2:TAKES_MEDICATION]->(m2:Medication)
            WHERE r2.active = true AND m1.id < m2.id
            MATCH (m1)-[interaction:INTERACTS_WITH]-(m2)
            RETURN m1.name AS medication1, 
                   m2.name AS medication2,
                   interaction.severity AS severity,
                   interaction.description AS description
            """
            
            result = session.run(query, patient_id=patient_id)
            return [dict(record) for record in result]
    
    def find_patients_with_condition(self, condition_id: str) -> List[Dict[str, Any]]:
        """
        Find all patients who have a specific condition.
        
        Useful for cohort discovery and research.
        
        Args:
            condition_id: The condition to search for
        
        Returns:
            List of patients with that condition
        """
        with self.driver.session() as session:
            query = """
            MATCH (p:Patient)-[r:HAS_CONDITION]->(c:Condition {id: $condition_id})
            RETURN p.id AS patient_id, p.name AS name, p.age AS age, 
                   r.diagnosed_date AS diagnosed_date,
                   p.chunk_ids AS chunk_ids
            ORDER BY p.name
            """
            
            result = session.run(query, condition_id=condition_id)
            return [dict(record) for record in result]
    
    def find_patients_with_multiple_conditions(
        self,
        condition_ids: List[str]
    ) -> List[Dict[str, Any]]:
        """
        Find patients who have ALL of the specified conditions (comorbidities).
        
        This is powerful for clinical research and decision support.
        
        Args:
            condition_ids: List of condition IDs
        
        Returns:
            Patients with all specified conditions
        """
        with self.driver.session() as session:
            # Dynamic query based on number of conditions
            match_clauses = []
            for i, cond_id in enumerate(condition_ids):
                match_clauses.append(
                    f"MATCH (p)-[:HAS_CONDITION]->(c{i}:Condition {{id: $cond{i}}})"
                )
            
            query = f"""
            MATCH (p:Patient)
            {' '.join(match_clauses)}
            RETURN p.id AS patient_id, p.name AS name, p.age AS age, p.chunk_ids AS chunk_ids
            ORDER BY p.name
            """
            
            # Build parameters dictionary
            params = {f"cond{i}": cond_id for i, cond_id in enumerate(condition_ids)}
            
            result = session.run(query, **params)
            return [dict(record) for record in result]
    
    def get_patient_graph_summary(self, patient_id: str) -> Dict[str, Any]:
        """
        Get a complete summary of a patient's health graph.
        
        Returns conditions, medications, and any drug interactions.
        
        Args:
            patient_id: The patient to summarize
        
        Returns:
            Dictionary with all patient graph data
        """
        return {
            "patient_id": patient_id,
            "conditions": self.get_patient_conditions(patient_id),
            "medications": self.get_patient_medications(patient_id),
            "drug_interactions": self.check_drug_interactions(patient_id)
        }
    
    def add_chunk_reference_to_patient(self, patient_id: str, chunk_id: str) -> None:
        """
        Add a vector database chunk ID to a patient's node.
        
        This maintains the cross-link from graph to vector database.
        
        Args:
            patient_id: The patient node to update
            chunk_id: The vector chunk ID to add
        """
        with self.driver.session() as session:
            query = """
            MATCH (p:Patient {id: $patient_id})
            SET p.chunk_ids = COALESCE(p.chunk_ids, []) + $chunk_id
            RETURN p
            """
            session.run(query, patient_id=patient_id, chunk_id=chunk_id)
    
    def clear_database(self) -> None:
        """
        Delete ALL nodes and relationships.
        Use with caution! Only for development/testing.
        """
        with self.driver.session() as session:
            session.run("MATCH (n) DETACH DELETE n")
            print("🗑️  Cleared all data from graph database")
    
    def get_database_stats(self) -> Dict[str, int]:
        """Get statistics about the database."""
        with self.driver.session() as session:
            result = session.run("""
                MATCH (n)
                RETURN labels(n)[0] AS label, count(n) AS count
                ORDER BY label
            """)
            
            stats = {record["label"]: record["count"] for record in result}
            
            # Count relationships
            rel_result = session.run("MATCH ()-[r]->() RETURN count(r) AS count")
            stats["Total Relationships"] = rel_result.single()["count"]
            
            return stats


# Example usage
if __name__ == "__main__":
    print("Testing Graph DB Manager...")
    
    try:
        # Initialize
        graph_db = GraphDBManager()
        
        # Create a test patient
        graph_db.create_patient(
            patient_id="PAT999",
            name="Test Patient",
            age=50,
            gender="M",
            mrn="MRN-TEST-999",
            chunk_ids=["TEST001"]  # Link to vector DB
        )
        
        # Create a test condition
        graph_db.create_condition(
            condition_id="COND999",
            name="Test Condition",
            icd10="Z99.9",
            category="Test"
        )
        
        # Link them
        graph_db.create_patient_condition_relationship(
            patient_id="PAT999",
            condition_id="COND999",
            diagnosed_date="2024-01-01"
        )
        
        # Query
        conditions = graph_db.get_patient_conditions("PAT999")
        print(f"\nPatient conditions: {conditions}")
        
        # Show stats
        stats = graph_db.get_database_stats()
        print(f"\nDatabase stats: {stats}")
        
        # Close connection
        graph_db.close()
        
        print("\n✅ Graph DB Manager test complete!")
        
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        print("Make sure Neo4j is running!")
