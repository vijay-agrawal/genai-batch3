"""
Vector Database Manager for Clinical Data
==========================================

This module handles all interactions with the Vector Database (ChromaDB).
It stores clinical text chunks with embeddings and metadata that links to the graph database.

Key Concepts:
- Embeddings: Numeric vectors representing the semantic meaning of text
- Chunks: Segments of clinical notes that are embedded
- Metadata: Additional information about each chunk (including graph node IDs)
- Collection: A group of related documents in the vector database
"""

import chromadb
from chromadb.utils import embedding_functions
from typing import List, Dict, Any
import json


class VectorDBManager:
    """
    Manages the Vector Database for storing and searching clinical text.
    
    This class provides methods to:
    1. Initialize the vector database
    2. Add clinical notes with embeddings
    3. Search for similar clinical content
    4. Cross-link to graph database entities
    """
    
    def __init__(self, persist_directory: str = "./chroma_db"):
        """
        Initialize the Vector Database Manager.
        
        Args:
            persist_directory: Where to store the database files on disk
        """
        print("🔵 Initializing Vector Database (ChromaDB)...")
        
        # Create a persistent client (data saved to disk)
        self.client = chromadb.PersistentClient(path=persist_directory)
        
        # Use sentence transformers for embeddings
        # This model converts text to 384-dimensional vectors
        self.embedding_function = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="all-MiniLM-L6-v2"
        )
        
        # Create or get the collection for clinical notes
        # A collection is like a table in a traditional database
        self.collection = self.client.get_or_create_collection(
            name="clinical_notes",
            embedding_function=self.embedding_function,
            metadata={"description": "Clinical notes with embeddings"}
        )
        
        print(f"✅ Vector DB initialized with {self.collection.count()} existing documents")
    
    def add_clinical_note(
        self,
        note_id: str,
        text: str,
        patient_id: str,
        condition_ids: List[str],
        medication_ids: List[str],
        note_type: str,
        date: str
    ) -> None:
        """
        Add a clinical note to the vector database.
        
        This method:
        1. Takes the clinical text
        2. Generates an embedding (done automatically by ChromaDB)
        3. Stores it with metadata that includes graph node IDs
        
        Args:
            note_id: Unique identifier for the note
            text: The actual clinical text content
            patient_id: ID of the patient (links to graph node)
            condition_ids: List of condition IDs mentioned (links to graph nodes)
            medication_ids: List of medication IDs mentioned (links to graph nodes)
            note_type: Type of note (e.g., "Progress Note", "Consult")
            date: Date of the note
        """
        
        # IMPORTANT: The metadata contains IDs that reference nodes in the graph database
        # This is the KEY to cross-linking between vector and graph databases
        metadata = {
            "patient_id": patient_id,              # Link to Patient node in graph
            "condition_ids": json.dumps(condition_ids),  # Link to Condition nodes
            "medication_ids": json.dumps(medication_ids),  # Link to Medication nodes
            "note_type": note_type,
            "date": date,
            "chunk_type": "clinical_note"
        }
        
        # Add to the collection
        # ChromaDB will automatically generate the embedding
        self.collection.add(
            ids=[note_id],           # Unique ID for this document
            documents=[text],         # The text to embed and store
            metadatas=[metadata]      # Additional information
        )
        
        print(f"  ✅ Added note {note_id} for patient {patient_id}")
    
    def add_chunk(
        self,
        chunk_id: str,
        text: str,
        metadata: Dict[str, Any]
    ) -> None:
        """
        Add a generic text chunk to the vector database.
        
        This is a more flexible method for adding any type of clinical text,
        not just complete notes.
        
        Args:
            chunk_id: Unique identifier for the chunk
            text: The text content
            metadata: Dictionary of metadata (should include graph node IDs)
        """
        self.collection.add(
            ids=[chunk_id],
            documents=[text],
            metadatas=[metadata]
        )
        print(f"  ✅ Added chunk {chunk_id}")
    
    def search_similar(
        self,
        query: str,
        n_results: int = 5,
        filter_metadata: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Search for clinically similar text using semantic search.
        
        This is where the magic happens! The query is converted to an embedding,
        and ChromaDB finds the most similar document embeddings using vector similarity.
        
        How it works:
        1. Your query is converted to a vector (embedding)
        2. ChromaDB calculates the distance between your query vector and all stored vectors
        3. Returns the closest matches (most semantically similar)
        
        Args:
            query: The search query (natural language)
            n_results: How many results to return
            filter_metadata: Optional filters (e.g., {"patient_id": "PAT001"})
        
        Returns:
            Dictionary containing:
            - ids: List of matching document IDs
            - documents: List of matching text content
            - metadatas: List of metadata for each match
            - distances: How similar each match is (lower = more similar)
        """
        print(f"\n🔍 Searching vector DB for: '{query}'")
        
        # Perform the semantic search
        results = self.collection.query(
            query_texts=[query],
            n_results=n_results,
            where=filter_metadata  # Optional: filter by metadata
        )
        
        print(f"  Found {len(results['ids'][0])} similar documents")
        return results
    
    def get_by_id(self, doc_id: str) -> Dict[str, Any]:
        """
        Retrieve a specific document by its ID.
        
        Args:
            doc_id: The document ID to retrieve
        
        Returns:
            Dictionary with document data
        """
        result = self.collection.get(
            ids=[doc_id],
            include=["documents", "metadatas", "embeddings"]
        )
        return result
    
    def search_by_patient(self, patient_id: str) -> Dict[str, Any]:
        """
        Find all chunks related to a specific patient.
        
        This demonstrates using metadata filtering.
        
        Args:
            patient_id: The patient ID to search for
        
        Returns:
            All documents for that patient
        """
        results = self.collection.get(
            where={"patient_id": patient_id},
            include=["documents", "metadatas"]
        )
        return results
    
    def get_all_documents(self) -> Dict[str, Any]:
        """
        Retrieve all documents in the collection.
        Useful for debugging and demonstrations.
        
        Returns:
            All documents with their metadata
        """
        return self.collection.get(include=["documents", "metadatas"])
    
    def clear_collection(self) -> None:
        """
        Delete all documents from the collection.
        Useful for resetting the database during development.
        """
        # Get all IDs
        all_docs = self.collection.get()
        if all_docs['ids']:
            self.collection.delete(ids=all_docs['ids'])
            print("🗑️  Cleared all documents from vector database")
    
    def print_search_results(self, results: Dict[str, Any], max_text_length: int = 200) -> None:
        """
        Pretty print search results for easy viewing.
        
        Args:
            results: The results from a search query
            max_text_length: How much of each document text to show
        """
        print("\n" + "="*80)
        print("VECTOR SEARCH RESULTS")
        print("="*80)
        
        for i, (doc_id, document, metadata, distance) in enumerate(zip(
            results['ids'][0],
            results['documents'][0],
            results['metadatas'][0],
            results['distances'][0]
        ), 1):
            print(f"\n📄 Result {i}:")
            print(f"  ID: {doc_id}")
            print(f"  Similarity Score: {1 - distance:.4f}")  # Convert distance to similarity
            print(f"  Patient: {metadata.get('patient_id', 'N/A')}")
            print(f"  Type: {metadata.get('note_type', 'N/A')}")
            print(f"  Date: {metadata.get('date', 'N/A')}")
            
            # Show truncated text
            text_preview = document[:max_text_length] + "..." if len(document) > max_text_length else document
            print(f"  Text: {text_preview}")
            
            # Show graph links
            if 'condition_ids' in metadata:
                conditions = json.loads(metadata['condition_ids']) if metadata['condition_ids'] else []
                print(f"  🔗 Linked Conditions: {conditions}")
            
            print("-" * 80)


# Example usage
if __name__ == "__main__":
    # This code runs if you execute this file directly
    # It's useful for testing the VectorDBManager
    
    print("Testing Vector DB Manager...")
    
    # Initialize the manager
    vector_db = VectorDBManager(persist_directory="./test_chroma_db")
    
    # Add a sample clinical note
    vector_db.add_clinical_note(
        note_id="TEST001",
        text="Patient presents with chest pain and shortness of breath. ECG shows ST elevation.",
        patient_id="PAT999",
        condition_ids=["COND005"],
        medication_ids=["MED015"],
        note_type="Emergency Note",
        date="2024-01-15"
    )
    
    # Search for similar content
    results = vector_db.search_similar("heart attack symptoms", n_results=1)
    vector_db.print_search_results(results)
    
    print("\n✅ Vector DB Manager test complete!")
