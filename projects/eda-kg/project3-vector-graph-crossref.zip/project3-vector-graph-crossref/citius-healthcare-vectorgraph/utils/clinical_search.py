"""
Clinical Search - Hybrid Vector + Graph Database Queries
========================================================

This module demonstrates the POWER of cross-linking!
It combines semantic search (vector DB) with relationship traversal (graph DB).

This is where the magic happens - showing why cross-linking is valuable.
"""

from typing import List, Dict, Any, Optional
import json
from utils.vector_db_manager import VectorDBManager
from utils.graph_db_manager import GraphDBManager


class ClinicalSearch:
    """
    Hybrid search combining Vector DB and Graph DB.
    
    This class demonstrates various patterns of cross-linked queries:
    1. Vector search → Graph traversal
    2. Graph query → Vector retrieval
    3. Combined filtering and ranking
    """
    
    def __init__(self, vector_db: VectorDBManager, graph_db: GraphDBManager):
        """
        Initialize with both database managers.
        
        Args:
            vector_db: Vector database manager
            graph_db: Graph database manager
        """
        self.vector_db = vector_db
        self.graph_db = graph_db
        print("🔗 Clinical Search initialized with cross-linked databases")
    
    # ============================================================
    # PATTERN 1: Vector Search → Graph Traversal
    # ============================================================
    
    def find_similar_cases_with_relationships(
        self,
        query: str,
        n_results: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Find semantically similar cases, then explore their medical relationships.
        
        Workflow:
        1. Search vector DB for similar clinical text
        2. Extract patient IDs from results (cross-link!)
        3. Query graph DB for those patients' conditions and medications
        4. Return enriched results
        
        This demonstrates: Vector search gives us relevant cases,
        graph traversal gives us structured medical knowledge about those cases.
        
        Args:
            query: Natural language clinical query
            n_results: How many similar cases to find
        
        Returns:
            List of cases with full medical context
        """
        print(f"\n{'='*80}")
        print(f"HYBRID SEARCH: Find Similar Cases with Relationships")
        print(f"Query: '{query}'")
        print(f"{'='*80}\n")
        
        # STEP 1: Semantic search in vector DB
        print("📊 Step 1: Searching vector database for similar clinical text...")
        vector_results = self.vector_db.search_similar(query, n_results=n_results)
        
        enriched_results = []
        
        # STEP 2: For each result, get graph data
        for i, (doc_id, document, metadata, distance) in enumerate(zip(
            vector_results['ids'][0],
            vector_results['documents'][0],
            vector_results['metadatas'][0],
            vector_results['distances'][0]
        ), 1):
            print(f"\n🔍 Processing result {i}...")
            
            # Extract patient ID (this is the cross-link!)
            patient_id = metadata.get('patient_id')
            
            if not patient_id:
                print(f"  ⚠️  No patient_id in metadata, skipping graph lookup")
                continue
            
            # STEP 3: Use the patient_id to query the graph database
            print(f"  🔗 Following cross-link to graph DB for patient {patient_id}...")
            
            # Get all graph data for this patient
            conditions = self.graph_db.get_patient_conditions(patient_id)
            medications = self.graph_db.get_patient_medications(patient_id)
            interactions = self.graph_db.check_drug_interactions(patient_id)
            
            # Combine vector and graph data
            enriched_result = {
                "note_id": doc_id,
                "similarity_score": round(1 - distance, 4),
                "clinical_text": document,
                "metadata": metadata,
                "patient_id": patient_id,
                "conditions": conditions,  # From graph DB!
                "medications": medications,  # From graph DB!
                "drug_interactions": interactions  # From graph DB!
            }
            
            enriched_results.append(enriched_result)
            
            print(f"  ✅ Found {len(conditions)} conditions, {len(medications)} medications")
            if interactions:
                print(f"  ⚠️  WARNING: {len(interactions)} drug interactions detected!")
        
        return enriched_results
    
    # ============================================================
    # PATTERN 2: Graph Query → Vector Retrieval
    # ============================================================
    
    def find_cases_by_comorbidities(
        self,
        condition_ids: List[str],
        semantic_query: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Find patients with specific comorbidities, then retrieve their clinical notes.
        
        Workflow:
        1. Query graph DB for patients with specific conditions
        2. Extract chunk_ids from patient nodes (cross-link!)
        3. Retrieve those chunks from vector DB
        4. Optionally rank by semantic similarity to a query
        
        This demonstrates: Graph gives us structured queries (who has diabetes + CKD?),
        vector retrieval gives us the rich clinical narratives.
        
        Args:
            condition_ids: List of condition IDs (all must be present)
            semantic_query: Optional query to rank results semantically
        
        Returns:
            List of patients with their clinical narratives
        """
        print(f"\n{'='*80}")
        print(f"HYBRID SEARCH: Find Cases by Comorbidities")
        print(f"Conditions: {condition_ids}")
        print(f"{'='*80}\n")
        
        # STEP 1: Query graph DB for patients with these conditions
        print("📊 Step 1: Querying graph database for patients with specified conditions...")
        patients = self.graph_db.find_patients_with_multiple_conditions(condition_ids)
        
        print(f"  Found {len(patients)} patients with all specified conditions")
        
        if not patients:
            return []
        
        results = []
        
        # STEP 2: For each patient, get their clinical notes from vector DB
        for patient in patients:
            patient_id = patient['patient_id']
            chunk_ids = patient.get('chunk_ids', [])
            
            print(f"\n🔍 Processing patient {patient_id}...")
            print(f"  🔗 Following cross-link to vector DB ({len(chunk_ids)} chunks)...")
            
            # Get all chunks for this patient
            patient_notes = self.vector_db.search_by_patient(patient_id)
            
            # Also get graph data
            conditions = self.graph_db.get_patient_conditions(patient_id)
            medications = self.graph_db.get_patient_medications(patient_id)
            
            result = {
                "patient_id": patient_id,
                "patient_info": patient,
                "clinical_notes": patient_notes['documents'],
                "note_metadata": patient_notes['metadatas'],
                "conditions": conditions,
                "medications": medications
            }
            
            results.append(result)
            
            print(f"  ✅ Retrieved {len(patient_notes['documents'])} clinical notes")
        
        # STEP 3: If semantic query provided, rank results
        if semantic_query:
            print(f"\n📊 Step 3: Ranking results by similarity to '{semantic_query}'...")
            # This would rank the results by semantic similarity
            # For simplicity, we'll skip the implementation here
            pass
        
        return results
    
    # ============================================================
    # PATTERN 3: Safety Check with Cross-Linking
    # ============================================================
    
    def check_treatment_safety(
        self,
        patient_id: str,
        proposed_medication_id: str
    ) -> Dict[str, Any]:
        """
        Check if a proposed medication is safe for a patient.
        
        Workflow:
        1. Query graph DB for patient's current medications
        2. Check for interactions with proposed medication
        3. Query graph DB for patient's conditions
        4. Check for contraindications
        5. Retrieve relevant clinical notes from vector DB
        
        This is a CRITICAL clinical use case!
        
        Args:
            patient_id: The patient
            proposed_medication_id: Medication being considered
        
        Returns:
            Safety assessment with warnings
        """
        print(f"\n{'='*80}")
        print(f"SAFETY CHECK: Treatment Safety Assessment")
        print(f"Patient: {patient_id}, Proposed Medication: {proposed_medication_id}")
        print(f"{'='*80}\n")
        
        # Get patient's current medications
        current_meds = self.graph_db.get_patient_medications(patient_id)
        
        # Get patient's conditions
        conditions = self.graph_db.get_patient_conditions(patient_id)
        
        # Check for drug interactions
        # (This would need a more sophisticated query in production)
        interactions = []
        
        # Get relevant clinical notes
        print("🔗 Retrieving clinical history from vector DB...")
        notes = self.vector_db.search_by_patient(patient_id)
        
        safety_assessment = {
            "patient_id": patient_id,
            "proposed_medication": proposed_medication_id,
            "current_medications": current_meds,
            "conditions": conditions,
            "interactions_found": interactions,
            "clinical_notes_reviewed": len(notes['documents']),
            "safe_to_prescribe": len(interactions) == 0  # Simplified
        }
        
        return safety_assessment
    
    # ============================================================
    # PATTERN 4: Clinical Decision Support
    # ============================================================
    
    def get_treatment_patterns(
        self,
        condition_id: str,
        outcome_query: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Find treatment patterns for a condition from similar cases.
        
        Workflow:
        1. Graph: Find all patients with the condition
        2. Graph: Get their medications
        3. Vector: Search their notes for outcomes
        4. Analyze: What treatments led to good outcomes?
        
        Args:
            condition_id: The condition to analyze
            outcome_query: Optional semantic search for outcomes
        
        Returns:
            Treatment patterns and outcomes
        """
        print(f"\n{'='*80}")
        print(f"CLINICAL DECISION SUPPORT: Treatment Pattern Analysis")
        print(f"Condition: {condition_id}")
        print(f"{'='*80}\n")
        
        # Find all patients with this condition
        patients = self.graph_db.find_patients_with_condition(condition_id)
        
        print(f"📊 Found {len(patients)} patients with this condition")
        
        # Aggregate medication patterns
        medication_counts = {}
        
        for patient in patients:
            patient_id = patient['patient_id']
            medications = self.graph_db.get_patient_medications(patient_id)
            
            for med in medications:
                med_name = med['name']
                medication_counts[med_name] = medication_counts.get(med_name, 0) + 1
        
        # Sort by frequency
        sorted_meds = sorted(
            medication_counts.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        print(f"\n💊 Most common medications for this condition:")
        for med, count in sorted_meds[:5]:
            print(f"  - {med}: {count} patients ({count/len(patients)*100:.1f}%)")
        
        return {
            "condition_id": condition_id,
            "total_patients": len(patients),
            "medication_patterns": dict(sorted_meds),
            "patients": patients
        }
    
    # ============================================================
    # UTILITY METHODS
    # ============================================================
    
    def print_enriched_results(self, results: List[Dict[str, Any]]) -> None:
        """Pretty print enriched search results."""
        print(f"\n{'='*80}")
        print(f"ENRICHED RESULTS ({len(results)} cases)")
        print(f"{'='*80}\n")
        
        for i, result in enumerate(results, 1):
            print(f"{'─'*80}")
            print(f"📋 Case {i} (Similarity: {result['similarity_score']})")
            print(f"{'─'*80}")
            
            print(f"\n📝 Clinical Text:")
            text = result['clinical_text']
            print(f"  {text[:300]}..." if len(text) > 300 else f"  {text}")
            
            print(f"\n🏥 Patient: {result['patient_id']}")
            
            print(f"\n🔬 Conditions ({len(result['conditions'])}):")
            for cond in result['conditions']:
                print(f"  • {cond['name']} (diagnosed: {cond.get('diagnosed_date', 'N/A')})")
            
            print(f"\n💊 Medications ({len(result['medications'])}):")
            for med in result['medications']:
                status = "✓ Active" if med.get('active') else "✗ Inactive"
                print(f"  • {med['name']} ({status})")
            
            if result['drug_interactions']:
                print(f"\n⚠️  DRUG INTERACTIONS DETECTED:")
                for interaction in result['drug_interactions']:
                    print(f"  ! {interaction['medication1']} + {interaction['medication2']}")
                    print(f"    Severity: {interaction['severity']}")
                    print(f"    {interaction['description']}")
            
            print()


# Example usage
if __name__ == "__main__":
    print("Testing Clinical Search...")
    
    # This requires both databases to be initialized
    # See 01_setup_healthcare_dbs.py for full setup
    
    print("✅ Clinical Search module loaded successfully!")
    print("   Run 02_clinical_queries.py to see it in action!")
