# Citius Healthcare: Vector-Graph Cross-Linking Project

## Clinical Intelligence System with Hybrid Database Architecture

### Project Overview

This mini-project demonstrates how **cross-linking Vector and Graph databases** creates powerful clinical insights by combining:

- **Semantic Search** (Vector DB) - Find similar clinical cases, symptoms, and treatments
- **Medical Knowledge Graph** (Graph DB) - Navigate relationships between diseases, drugs, symptoms, and patients
- **Cross-Linking** - Reference graph entities from clinical text chunks and vice versa

## The Healthcare Problem

**Scenario:** A physician sees a patient with complex symptoms. They need to:
1. Find similar cases based on symptom descriptions (semantic search)
2. Understand drug interactions and contraindications (relationship traversal)
3. Discover treatment patterns from patients with similar conditions
4. Navigate from a clinical note to the patient's full medical graph

**Traditional Approaches Fall Short:**
- ❌ Keyword search misses semantically similar cases
- ❌ Structured databases can't search free-text clinical notes effectively
- ❌ Graph databases alone can't find "similar" unstructured content
- ❌ Vector databases alone miss critical relationships (drug interactions, comorbidities)

**Cross-Linked Solution:**
- ✅ Semantic search finds relevant clinical narratives
- ✅ Instant traversal to related entities (patient, conditions, medications)
- ✅ Navigate the medical knowledge graph from any search result
- ✅ Unified view of structured and unstructured clinical data

## Architecture

```
┌─────────────────────────────┐         ┌──────────────────────────────┐
│      Vector Database        │◄───────►│      Graph Database          │
│       (ChromaDB)            │         │        (Neo4j)               │
│                             │ Cross-  │                              │
│ • Clinical Note Chunks      │ Linked  │ • Patients (nodes)           │
│ • Symptom Descriptions      │         │ • Conditions (nodes)         │
│ • Treatment Narratives      │         │ • Medications (nodes)        │
│ • Embeddings                │         │ • Symptoms (nodes)           │
│                             │         │ • Procedures (nodes)         │
│ Metadata contains:          │         │                              │
│ - patient_id (graph node)   │         │ Properties contain:          │
│ - condition_id (graph node) │         │ - chunk_ids (vector refs)    │
│ - medication_ids            │         │ - note_ids                   │
└─────────────────────────────┘         └──────────────────────────────┘
```

## Use Case: Clinical Decision Support

### Example Workflow

**1. Doctor's Query:** "Find cases with chronic fatigue, joint pain, and elevated inflammatory markers"

**2. Hybrid System Response:**
- Vector DB finds semantically similar clinical notes
- Each note links to patient nodes in the graph
- Graph reveals:
  - Diagnosed conditions (Lupus, Rheumatoid Arthritis, Fibromyalgia)
  - Current medications and known interactions
  - Comorbidities and contraindications
  - Treatment outcomes

**3. Clinical Insights:**
- Similar cases across the patient population
- Treatment patterns that worked
- Drug interactions to avoid
- Specialist referral patterns

## Quick Start


### Installation

```bash
# 1. Install Python dependencies
pip install chromadb neo4j sentence-transformers pandas numpy

# 3. Run the project
python 01_setup_healthcare_dbs.py      # Initialize databases with sample data
python 02_clinical_queries.py          # Run example clinical queries
python 03_demonstrate_value.py         # See the power of cross-linking
```

## Project Structure

```
citius-healthcare-vectorgraph/
├── README.md                          # This file
├── clinical_data.json                 # Sample patient data
├── 01_setup_healthcare_dbs.py         # Load sample data into both DBs
├── 02_clinical_queries.py             # Example hybrid queries
├── 03_demonstrate_value.py            # Demonstrate cross-linking benefits
├── 04_interactive_demo.py             # Interactive CLI demo
└── utils/
    ├── vector_db_manager.py          # Vector DB operations
    ├── graph_db_manager.py           # Graph DB operations
    └── clinical_search.py            # Cross-linked search functions
```

## Learning Objectives

### 1. Understand Database Strengths
- **Vector DB:** Semantic similarity in clinical narratives
- **Graph DB:** Medical relationships and contraindications
- **Together:** Comprehensive clinical intelligence

### 2. Cross-Linking Patterns
- Store graph node IDs in vector metadata
- Store vector chunk IDs in graph node properties
- Bidirectional navigation between systems

### 3. Real Healthcare Applications
- Clinical decision support
- Similar case retrieval
- Drug interaction checking
- Patient journey analysis
- Research cohort discovery

## Example Queries You'll Build

### Query 1: Symptom-Based Case Finding
```
"Find patients with unexplained weight loss and night sweats"
→ Vector search finds similar symptom descriptions
→ Link to patient graphs
→ Reveal diagnoses: Lymphoma, Tuberculosis, Hyperthyroidism
```

### Query 2: Drug Interaction Discovery
```
"Show me patients on warfarin who were prescribed antibiotics"
→ Graph traversal finds medication combinations
→ Link to clinical notes documenting outcomes
→ Identify interaction patterns and adverse events
```

### Query 3: Treatment Pattern Analysis
```
"For Type 2 Diabetes with CKD, what treatments have best outcomes?"
→ Graph finds patients with both conditions
→ Vector search retrieves treatment notes
→ Analyze outcomes and medication effectiveness
```

### Query 4: Comorbidity Navigation
```
"Find similar cases to this patient with multiple chronic conditions"
→ Vector search on clinical presentation
→ Graph reveals comorbidity networks
→ Discover hidden associations and risk factors
```

## Expected Outcomes

After completing this project, you'll see:

✅ **Better Clinical Search:** Semantic understanding of medical terminology
✅ **Relationship Discovery:** Hidden connections in patient data
✅ **Safety Checks:** Drug interactions and contraindications
✅ **Evidence-Based Insights:** Treatment patterns from real cases
✅ **Unified View:** Structured + unstructured data together

## ample Data Included

- **8 Patients** with realistic clinical profiles
- **12 Medical Conditions** (Diabetes, Hypertension, Cancer, etc.)
- **15 Medications** with interaction data
- **20+ Clinical Notes** with rich narratives
- **Symptoms, Procedures, Labs** interconnected in the graph

## Key Concepts Demonstrated

### 1. **Bidirectional Cross-Linking**
```python
# In Vector DB metadata:
{
    "patient_id": "PAT001",           # Link to graph node
    "condition_ids": ["COND001"],     # Links to condition nodes
    "chunk_type": "clinical_note"
}

# In Graph DB node properties:
Patient {
    id: "PAT001",
    chunk_ids: ["chunk_001", "chunk_002"]  # Links to vector chunks
}
```

### 2. **Semantic + Structural Search**
Combine the power of:
- Finding semantically similar text
- Traversing medical knowledge relationships
- Filtering by structured attributes

### 3. **Clinical Safety**
- Check drug interactions via graph traversal
- Find contraindications based on conditions
- Identify risk factors through relationship patterns

## Healthcare Compliance Notes

This is a **demonstration project with synthetic data only**. 

For production use in healthcare:
- Implement proper HIPAA compliance
- Add audit logging
- Implement access controls
- Encrypt PHI (Protected Health Information)
- Follow data retention policies

## Notes for Workshop Participants

This project includes:
- ✅ **Extensive comments** explaining every step
- ✅ **Print statements** to see what's happening
- ✅ **Error handling** with helpful messages
- ✅ **Modular code** that's easy to understand
- ✅ **Progressive complexity** from simple to advanced
- ✅ **Interactive demo** to explore on your own

**No prior experience with vector or graph databases required!**

## Interactive Demo

Run the interactive demo to explore queries yourself:
```bash
python 04_interactive_demo.py
```

Try queries like:
- "chest pain and shortness of breath"
- "diabetes medication with kidney problems"
- "patients with multiple chronic conditions"

## Next Steps

After completing this project:
1. Add your own clinical scenarios
2. Implement more complex graph patterns (3+ hop traversals)
3. Add temporal analysis (disease progression over time)
4. Build a simple web UI
5. Integrate with HL7 FHIR data standards