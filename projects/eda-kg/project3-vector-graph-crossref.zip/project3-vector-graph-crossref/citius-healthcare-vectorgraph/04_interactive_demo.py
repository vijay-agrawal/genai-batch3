#!/usr/bin/env python3
"""
Interactive Demo: Explore Cross-Linked Databases
================================================

This script provides an interactive CLI for participants to explore
the hybrid database system with their own queries.
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent))

from utils.vector_db_manager import VectorDBManager
from utils.graph_db_manager import GraphDBManager
from utils.clinical_search import ClinicalSearch


class InteractiveDemo:
    """Interactive demonstration interface."""
    
    def __init__(self):
        """Initialize the demo with database connections."""
        print("🔄 Initializing databases...")
        self.vector_db = VectorDBManager(persist_directory="./chroma_citius_db")
        self.graph_db = GraphDBManager()
        self.clinical_search = ClinicalSearch(self.vector_db, self.graph_db)
        print("✅ Ready!\n")
    
    def show_menu(self):
        """Display the main menu."""
        print("\n" + "="*80)
        print("INTERACTIVE DEMO MENU")
        print("="*80)
        print("""
Choose an option:

1. Semantic Search - Find similar clinical cases
2. Patient Lookup - Get complete patient information
3. Drug Interaction Check - Check for medication interactions
4. Comorbidity Search - Find patients with multiple conditions
5. Treatment Patterns - Analyze medications for a condition
6. Custom Query - Enter your own search

7. View Database Stats
8. Example Queries - See sample queries you can try

0. Exit

Type the number of your choice...
        """)
    
    def semantic_search(self):
        """Interactive semantic search."""
        print("\n" + "─"*80)
        print("SEMANTIC SEARCH")
        print("─"*80)
        print("\nEnter clinical terms to search for similar cases.")
        print("Examples:")
        print("  • 'chest pain shortness of breath'")
        print("  • 'fatigue joint pain inflammatory markers'")
        print("  • 'diabetes kidney disease'")
        
        query = input("\nYour search query: ").strip()
        
        if not query:
            print("❌ Please enter a search query")
            return
        
        n_results = input("How many results? (default: 3): ").strip()
        n_results = int(n_results) if n_results.isdigit() else 3
        
        print(f"\n🔍 Searching for: '{query}'...")
        results = self.clinical_search.find_similar_cases_with_relationships(
            query=query,
            n_results=n_results
        )
        
        self.clinical_search.print_enriched_results(results)
    
    def patient_lookup(self):
        """Look up complete patient information."""
        print("\n" + "─"*80)
        print("PATIENT LOOKUP")
        print("─"*80)
        print("\nAvailable patients: PAT001, PAT002, PAT003, PAT004, PAT005,")
        print("                    PAT006, PAT007, PAT008")
        
        patient_id = input("\nEnter patient ID: ").strip().upper()
        
        if not patient_id:
            print("❌ Please enter a patient ID")
            return
        
        print(f"\n🔍 Looking up patient: {patient_id}...")
        
        # Get graph data
        try:
            conditions = self.graph_db.get_patient_conditions(patient_id)
            medications = self.graph_db.get_patient_medications(patient_id)
            interactions = self.graph_db.check_drug_interactions(patient_id)
            
            # Get vector data
            notes = self.vector_db.search_by_patient(patient_id)
            
            # Display results
            print(f"\n{'='*80}")
            print(f"PATIENT PROFILE: {patient_id}")
            print(f"{'='*80}")
            
            print(f"\n🔬 Conditions ({len(conditions)}):")
            for cond in conditions:
                print(f"  • {cond['name']} (diagnosed: {cond['diagnosed_date']})")
            
            print(f"\n💊 Active Medications ({len(medications)}):")
            for med in medications:
                print(f"  • {med['name']} (since: {med['start_date']})")
            
            if interactions:
                print(f"\n⚠️  Drug Interactions ({len(interactions)}):")
                for interaction in interactions:
                    print(f"  ! {interaction['medication1']} + {interaction['medication2']}")
                    print(f"    Severity: {interaction['severity']}")
            else:
                print(f"\n✅ No drug interactions detected")
            
            print(f"\n📝 Clinical Notes ({len(notes['documents'])}):")
            for i, metadata in enumerate(notes['metadatas'][:5], 1):
                print(f"  {i}. {metadata['note_type']} - {metadata['date']}")
            
            if len(notes['documents']) > 5:
                print(f"  ... and {len(notes['documents']) - 5} more")
            
        except Exception as e:
            print(f"❌ Error: {e}")
            print("   Make sure the patient ID is valid")
    
    def drug_interaction_check(self):
        """Check drug interactions for a patient."""
        print("\n" + "─"*80)
        print("DRUG INTERACTION CHECK")
        print("─"*80)
        
        patient_id = input("\nEnter patient ID to check: ").strip().upper()
        
        if not patient_id:
            print("❌ Please enter a patient ID")
            return
        
        print(f"\n🔍 Checking medications for patient: {patient_id}...")
        
        try:
            medications = self.graph_db.get_patient_medications(patient_id)
            interactions = self.graph_db.check_drug_interactions(patient_id)
            
            print(f"\n💊 Current Medications ({len(medications)}):")
            for med in medications:
                print(f"  • {med['name']}")
            
            if interactions:
                print(f"\n🚨 INTERACTIONS DETECTED ({len(interactions)}):")
                for interaction in interactions:
                    print(f"\n  {'─'*60}")
                    print(f"  {interaction['medication1']} + {interaction['medication2']}")
                    print(f"  Severity: {interaction['severity']}")
                    print(f"  Details: {interaction['description']}")
                    print(f"  {'─'*60}")
            else:
                print(f"\n✅ No interactions detected - medications appear safe together")
        
        except Exception as e:
            print(f"❌ Error: {e}")
    
    def comorbidity_search(self):
        """Search for patients with multiple conditions."""
        print("\n" + "─"*80)
        print("COMORBIDITY SEARCH")
        print("─"*80)
        print("\nAvailable conditions:")
        print("  COND001 - Type 2 Diabetes")
        print("  COND002 - Hypertension")
        print("  COND003 - Chronic Kidney Disease")
        print("  COND004 - Rheumatoid Arthritis")
        print("  COND005 - Coronary Artery Disease")
        print("  COND006 - Systemic Lupus Erythematosus")
        print("  COND007 - Non-Small Cell Lung Cancer")
        print("  COND008 - Atrial Fibrillation")
        
        print("\nEnter condition IDs separated by commas")
        print("Example: COND001,COND003")
        
        condition_input = input("\nCondition IDs: ").strip().upper()
        
        if not condition_input:
            print("❌ Please enter at least one condition ID")
            return
        
        condition_ids = [c.strip() for c in condition_input.split(',')]
        
        print(f"\n🔍 Finding patients with: {', '.join(condition_ids)}...")
        
        try:
            results = self.clinical_search.find_cases_by_comorbidities(
                condition_ids=condition_ids
            )
            
            print(f"\n✅ Found {len(results)} patients with all specified conditions")
            
            for i, result in enumerate(results, 1):
                print(f"\n{'─'*60}")
                print(f"Patient {i}: {result['patient_id']}")
                print(f"Age: {result['patient_info']['age']}")
                
                print(f"\nAll Conditions:")
                for cond in result['conditions']:
                    print(f"  • {cond['name']}")
                
                print(f"\nMedications:")
                for med in result['medications'][:5]:
                    print(f"  • {med['name']}")
                
                print(f"\nClinical Notes: {len(result['clinical_notes'])} available")
        
        except Exception as e:
            print(f"❌ Error: {e}")
    
    def treatment_patterns(self):
        """Analyze treatment patterns."""
        print("\n" + "─"*80)
        print("TREATMENT PATTERN ANALYSIS")
        print("─"*80)
        
        condition_id = input("\nEnter condition ID (e.g., COND001): ").strip().upper()
        
        if not condition_id:
            print("❌ Please enter a condition ID")
            return
        
        print(f"\n🔍 Analyzing treatment patterns for: {condition_id}...")
        
        try:
            results = self.clinical_search.get_treatment_patterns(condition_id=condition_id)
            
            print(f"\n✅ Analysis complete!")
            print(f"   Cohort size: {results['total_patients']} patients")
        
        except Exception as e:
            print(f"❌ Error: {e}")
    
    def custom_query(self):
        """Allow custom queries."""
        print("\n" + "─"*80)
        print("CUSTOM QUERY")
        print("─"*80)
        print("""
This is a flexible search that will:
1. Find semantically similar clinical content (Vector DB)
2. Retrieve complete patient medical graphs (Graph DB)
3. Show you the cross-linked results

Enter any clinical query in natural language.
        """)
        
        query = input("Your query: ").strip()
        
        if not query:
            print("❌ Please enter a query")
            return
        
        print(f"\n🔍 Processing query: '{query}'...")
        
        results = self.clinical_search.find_similar_cases_with_relationships(
            query=query,
            n_results=3
        )
        
        self.clinical_search.print_enriched_results(results)
    
    def show_stats(self):
        """Show database statistics."""
        print("\n" + "─"*80)
        print("DATABASE STATISTICS")
        print("─"*80)
        
        # Vector DB stats
        vector_count = self.vector_db.collection.count()
        print(f"\n📊 Vector Database:")
        print(f"   Clinical notes/chunks: {vector_count}")
        
        # Graph DB stats
        stats = self.graph_db.get_database_stats()
        print(f"\n📊 Graph Database:")
        for label, count in sorted(stats.items()):
            print(f"   {label}: {count}")
    
    def show_examples(self):
        """Show example queries."""
        print("\n" + "─"*80)
        print("EXAMPLE QUERIES")
        print("─"*80)
        print("""
Here are some interesting queries you can try:

Semantic Search (Option 1):
  • "chest pain and shortness of breath"
  • "fatigue joint pain elevated inflammatory markers"
  • "kidney disease diabetes"
  • "cancer chemotherapy side effects"
  • "depression anxiety mental health"

Patient Lookup (Option 2):
  • PAT001 - Diabetes, Hypertension, CKD
  • PAT002 - Rheumatoid Arthritis
  • PAT003 - Coronary Artery Disease
  • PAT007 - Multiple chronic conditions

Drug Interaction Check (Option 3):
  • PAT007 - Has multiple medications with potential interactions

Comorbidity Search (Option 4):
  • COND001,COND003 - Diabetes + Chronic Kidney Disease
  • COND002,COND005 - Hypertension + Coronary Artery Disease

Custom Queries (Option 6):
  • "patients with autoimmune conditions"
  • "heart attack treatment outcomes"
  • "blood pressure management in elderly"
        """)
    
    def run(self):
        """Run the interactive demo."""
        print("\n" + "="*80)
        print("🏥 CITIUS HEALTHCARE - INTERACTIVE DEMO")
        print("   Explore Cross-Linked Vector + Graph Databases")
        print("="*80)
        
        while True:
            self.show_menu()
            
            choice = input("Your choice: ").strip()
            
            if choice == '0':
                print("\n👋 Thank you for exploring the demo!")
                self.graph_db.close()
                break
            elif choice == '1':
                self.semantic_search()
            elif choice == '2':
                self.patient_lookup()
            elif choice == '3':
                self.drug_interaction_check()
            elif choice == '4':
                self.comorbidity_search()
            elif choice == '5':
                self.treatment_patterns()
            elif choice == '6':
                self.custom_query()
            elif choice == '7':
                self.show_stats()
            elif choice == '8':
                self.show_examples()
            else:
                print("❌ Invalid choice. Please enter a number 0-8.")
            
            input("\nPress Enter to continue...")


def main():
    """Main entry point."""
    try:
        demo = InteractiveDemo()
        demo.run()
    except KeyboardInterrupt:
        print("\n\n👋 Demo interrupted. Goodbye!")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("\nMake sure you've run 01_setup_healthcare_dbs.py first!")


if __name__ == "__main__":
    main()
