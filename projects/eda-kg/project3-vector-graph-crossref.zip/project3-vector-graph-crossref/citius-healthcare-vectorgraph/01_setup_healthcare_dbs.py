#!/usr/bin/env python3
"""
Setup Script: Initialize Both Databases with Clinical Data
==========================================================

This script:
1. Loads sample clinical data from JSON
2. Populates the Vector Database with clinical notes
3. Populates the Graph Database with entities and relationships
4. Creates CROSS-LINKS between the two databases

This is a complete, runnable example with extensive comments to help participants
understand every step of the process.

Run this first to set up your databases!
"""

import json
import sys
from pathlib import Path

# Add utils to path
sys.path.append(str(Path(__file__).parent))

from utils.vector_db_manager import VectorDBManager
from utils.graph_db_manager import GraphDBManager


def load_clinical_data(filename: str = "clinical_data.json") -> dict:
    """
    Load the sample clinical data from JSON file.
    
    Args:
        filename: Path to the JSON data file
    
    Returns:
        Dictionary with all clinical data
    """
    print(f"\n📂 Loading clinical data from {filename}...")
    
    with open(filename, 'r') as f:
        data = json.load(f)
    
    print(f"✅ Loaded:")
    print(f"   - {len(data['patients'])} patients")
    print(f"   - {len(data['conditions'])} conditions")
    print(f"   - {len(data['medications'])} medications")
    print(f"   - {len(data['clinical_notes'])} clinical notes")
    print(f"   - {len(data['symptoms'])} symptoms")
    print(f"   - {len(data['drug_interactions'])} drug interactions")
    
    return data


def setup_vector_database(data: dict) -> VectorDBManager:
    """
    Initialize and populate the Vector Database.
    
    This database will store:
    - Clinical note text as embeddings
    - Metadata with graph node IDs (the cross-link!)
    
    Args:
        data: The clinical data dictionary
    
    Returns:
        Initialized VectorDBManager
    """
    print(f"\n{'='*80}")
    print("STEP 1: Setting up Vector Database")
    print(f"{'='*80}\n")
    
    # Initialize the vector database
    vector_db = VectorDBManager(persist_directory="./chroma_citius_db")
    
    # Clear existing data (for clean setup)
    vector_db.clear_collection()
    
    print("\n📝 Adding clinical notes to vector database...")
    print("   (This generates embeddings for semantic search)\n")
    
    # Add each clinical note
    for note in data['clinical_notes']:
        # IMPORTANT: We're storing the graph node IDs in the metadata
        # This is the KEY to cross-linking from vector → graph
        vector_db.add_clinical_note(
            note_id=note['note_id'],
            text=note['text'],
            patient_id=note['patient_id'],  # ← Links to Patient node in graph
            condition_ids=note['conditions'],  # ← Links to Condition nodes
            medication_ids=note['medications'],  # ← Links to Medication nodes
            note_type=note['type'],
            date=note['date']
        )
    
    print(f"\n✅ Vector database setup complete!")
    print(f"   Total documents: {vector_db.collection.count()}")
    
    return vector_db


def setup_graph_database(data: dict) -> GraphDBManager:
    """
    Initialize and populate the Graph Database.
    
    This database will store:
    - Entities (patients, conditions, medications) as nodes
    - Relationships between entities
    - Properties including vector chunk IDs (the cross-link!)
    
    Args:
        data: The clinical data dictionary
    
    Returns:
        Initialized GraphDBManager
    """
    print(f"\n{'='*80}")
    print("STEP 2: Setting up Graph Database")
    print(f"{'='*80}\n")
    
    # Initialize the graph database
    try:
        graph_db = GraphDBManager()
    except Exception as e:
        print(f"\n❌ Failed to connect to Neo4j!")
        print(f"   Error: {e}")
        print(f"\n💡 Make sure Neo4j is running:")
        print(f"   docker run --name neo4j-citius -p 7474:7474 -p 7687:7687 \\")
        print(f"              -e NEO4J_AUTH=neo4j/citius123 neo4j:latest")
        sys.exit(1)
    
    # Clear existing data (for clean setup)
    graph_db.clear_database()
    
    # ============================================================
    # CREATE NODES
    # ============================================================
    
    print("\n👤 Creating Patient nodes...")
    for patient in data['patients']:
        # For each patient, find their associated clinical notes
        # These note_ids will be stored as chunk_ids (cross-link to vector DB)
        patient_notes = [
            note['note_id'] 
            for note in data['clinical_notes'] 
            if note['patient_id'] == patient['id']
        ]
        
        graph_db.create_patient(
            patient_id=patient['id'],
            name=patient['name'],
            age=patient['age'],
            gender=patient['gender'],
            mrn=patient['mrn'],
            chunk_ids=patient_notes  # ← Links to vector DB documents!
        )
    
    print("\n🔬 Creating Condition nodes...")
    for condition in data['conditions']:
        graph_db.create_condition(
            condition_id=condition['id'],
            name=condition['name'],
            icd10=condition['icd10'],
            category=condition['category']
        )
    
    print("\n💊 Creating Medication nodes...")
    for medication in data['medications']:
        graph_db.create_medication(
            medication_id=medication['id'],
            name=medication['name'],
            drug_class=medication['class'],
            indications=medication['indications'],
            warnings=medication['warnings']
        )
    
    print("\n🤒 Creating Symptom nodes...")
    for symptom in data['symptoms']:
        graph_db.create_symptom(
            symptom_id=symptom['id'],
            name=symptom['name'],
            severity_range=symptom['severity_range']
        )
    
    # ============================================================
    # CREATE RELATIONSHIPS
    # ============================================================
    
    print("\n🔗 Creating relationships...")
    
    print("  → Patient-Condition relationships...")
    for rel in data['relationships']['patient_conditions']:
        graph_db.create_patient_condition_relationship(
            patient_id=rel['patient'],
            condition_id=rel['condition'],
            diagnosed_date=rel['diagnosed_date']
        )
    
    print("  → Patient-Medication relationships...")
    for rel in data['relationships']['patient_medications']:
        graph_db.create_patient_medication_relationship(
            patient_id=rel['patient'],
            medication_id=rel['medication'],
            start_date=rel['start_date'],
            active=rel['active']
        )
    
    print("  → Drug-Interaction relationships...")
    for interaction in data['drug_interactions']:
        graph_db.create_drug_interaction(
            med1_id=interaction['medication1'],
            med2_id=interaction['medication2'],
            severity=interaction['severity'],
            description=interaction['description']
        )
    
    # ============================================================
    # SHOW STATISTICS
    # ============================================================
    
    print(f"\n✅ Graph database setup complete!")
    stats = graph_db.get_database_stats()
    print(f"\n📊 Database Statistics:")
    for label, count in stats.items():
        print(f"   - {label}: {count}")
    
    return graph_db


def verify_cross_linking(vector_db: VectorDBManager, graph_db: GraphDBManager) -> None:
    """
    Verify that cross-linking is working correctly.
    
    This demonstrates:
    1. Finding a patient in the graph
    2. Using chunk_ids to retrieve documents from vector DB
    3. Finding a document in vector DB
    4. Using patient_id to query the graph
    
    Args:
        vector_db: The vector database manager
        graph_db: The graph database manager
    """
    print(f"\n{'='*80}")
    print("STEP 3: Verifying Cross-Linking")
    print(f"{'='*80}\n")
    
    # Test 1: Graph → Vector
    print("🔍 Test 1: Graph → Vector Database")
    print("   Starting from a patient node in the graph...")
    
    test_patient_id = "PAT001"
    
    # Get patient data from graph including chunk_ids
    conditions = graph_db.get_patient_conditions(test_patient_id)
    print(f"   Patient {test_patient_id} has {len(conditions)} conditions")
    
    # Use patient_id to search vector database
    patient_notes = vector_db.search_by_patient(test_patient_id)
    print(f"   ✅ Found {len(patient_notes['documents'])} clinical notes in vector DB")
    
    # Test 2: Vector → Graph
    print(f"\n🔍 Test 2: Vector Database → Graph")
    print("   Starting from a vector search...")
    
    # Search for clinical content
    search_results = vector_db.search_similar("diabetes kidney disease", n_results=1)
    
    if search_results['ids'][0]:
        # Get the patient_id from metadata (the cross-link!)
        first_result_metadata = search_results['metadatas'][0][0]
        linked_patient_id = first_result_metadata.get('patient_id')
        
        print(f"   Search found note for patient: {linked_patient_id}")
        
        # Now query graph for this patient
        patient_conditions = graph_db.get_patient_conditions(linked_patient_id)
        patient_meds = graph_db.get_patient_medications(linked_patient_id)
        
        print(f"   ✅ Retrieved {len(patient_conditions)} conditions and {len(patient_meds)} medications from graph")
    
    print(f"\n✅ Cross-linking verified successfully!")
    print(f"   Vector ↔ Graph bidirectional links are working!")


def main():
    """
    Main setup function.
    
    This orchestrates the entire setup process:
    1. Load data
    2. Setup vector database
    3. Setup graph database
    4. Verify cross-linking
    """
    print("\n" + "="*80)
    print("🏥 CITIUS HEALTHCARE - DATABASE SETUP")
    print("   Vector + Graph Cross-Linking Demonstration")
    print("="*80)
    
    try:
        # Load the data
        data = load_clinical_data()
        
        # Setup vector database
        vector_db = setup_vector_database(data)
        
        # Setup graph database
        graph_db = setup_graph_database(data)
        
        # Verify cross-linking works
        verify_cross_linking(vector_db, graph_db)
        
        # Final summary
        print(f"\n{'='*80}")
        print("🎉 SETUP COMPLETE!")
        print(f"{'='*80}")
        print(f"\n✅ Both databases are initialized and cross-linked!")
        print(f"\n📊 Summary:")
        print(f"   Vector DB: {vector_db.collection.count()} clinical note embeddings")
        stats = graph_db.get_database_stats()
        print(f"   Graph DB: {stats.get('Patient', 0)} patients, "
              f"{stats.get('Condition', 0)} conditions, "
              f"{stats.get('Medication', 0)} medications")
        print(f"   Cross-links: ✓ Bidirectional references established")
        
        print(f"\n🚀 Next Steps:")
        print(f"   1. Run: python 02_clinical_queries.py")
        print(f"      (See example hybrid queries in action)")
        print(f"   2. Run: python 03_demonstrate_value.py")
        print(f"      (See side-by-side comparison of approaches)")
        print(f"   3. Run: python 04_interactive_demo.py")
        print(f"      (Try your own queries!)")
        
        print(f"\n💡 View your graph in Neo4j Browser:")
        print(f"   Try query: MATCH (n) RETURN n LIMIT 25")
        
        # Close connections
        graph_db.close()
        
    except FileNotFoundError:
        print(f"\n❌ Error: clinical_data.json not found!")
        print(f"   Make sure you're running this from the project directory.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Setup failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
