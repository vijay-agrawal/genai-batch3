# Clinical Notes to Knowledge Graph - Workshop Guide

## Overview
This mini-project teaches you how to extract structured information from clinical notes and build a medical knowledge graph. You'll work through four progressive scripts that demonstrate real-world NLP techniques used in healthcare.

## Time Estimate
- Total: 3-4 hours
- Part 1 (Basic NER): 45 minutes
- Part 2 (Dictionary NER): 45 minutes
- Part 3 (Entity Linking): 60 minutes
- Part 4 (Cypher Generation): 45 minutes

## Prerequisites
- Basic Python knowledge
- Familiarity with NLP concepts (helpful but not required)
- Understanding of graphs (nodes, relationships)

## Setup (15 minutes)

### 1. Install Dependencies
```bash
# Navigate to project directory
cd clinical-notes-kg

# Install Python packages
pip install -r requirements.txt

# Download spaCy models
python -m spacy download en_core_web_sm
python -m spacy download en_core_sci_sm
```

### 2. Verify Installation
```bash
# Test that models are installed
python -c "import spacy; nlp = spacy.load('en_core_web_sm'); print('✓ General model loaded')"
python -c "import spacy; nlp = spacy.load('en_core_sci_sm'); print('✓ Medical model loaded')"
```

### 3. Review Sample Data
Open and review:
- `data/sample_notes.json` - 5 realistic clinical notes
- `data/medical_terminologies.json` - Disease and medication dictionaries

## Part 1: Understanding NER and Domain Models (45 min)

### Learning Objectives
- Understand what Named Entity Recognition (NER) does
- See why general NER fails on medical text
- Compare general vs. medical NER models

### Activities

#### 1.1 Read the Introduction (10 min)
Read the docstring at the top of `notebooks/01_basic_ner.py`

#### 1.2 Run Basic NER (10 min)
```bash
cd notebooks
python 01_basic_ner.py
```

**Observe:**
- How many entities does the general model find?
- What types of entities are recognized?
- What medical terms are MISSED?

#### 1.3 Analyze Results (15 min)

**Exercise Questions:**
1. Why does the general model find "3 days" but miss "hypertension"?
2. What entity types would be useful for a medical knowledge graph?
3. Look at the medical model results - what improvements do you see?

**Expected Insights:**
- General models are trained on news/web text, not medical literature
- Medical models recognize diseases, medications, and procedures
- Even medical models have gaps - not all medical terms are caught

#### 1.4 Hands-On Task (10 min)
1. Open `data/sample_notes.json`
2. Pick Patient P002 (migraine patient)
3. List all medical terms you see
4. Compare your list to what the models found

## Part 2: Dictionary-Based Extraction (45 min)

### Learning Objectives
- Build a dictionary/terminology-based matcher
- Handle synonyms and abbreviations
- Combine NER + dictionary approaches

### Activities

#### 2.1 Understand the Approach (10 min)
- Read about PhraseMatcher in spaCy docs
- Review the medical terminologies structure
- Understand why dictionaries provide high precision

#### 2.2 Run Dictionary Matching (10 min)
```bash
python 02_dictionary_ner.py
```

**Observe:**
- How many entities are found vs. NER alone?
- Which entities are caught by dictionary but not NER?
- How does the matcher handle abbreviations (HTN, BID)?

#### 2.3 Hands-On Task (15 min)

**Add a New Disease:**
1. Open `data/medical_terminologies.json`
2. Add a new disease entry:
```json
{
  "canonical_name": "Asthma",
  "icd10_code": "J45.9",
  "snomed_code": "195967001",
  "synonyms": ["bronchial asthma", "reactive airway disease"],
  "category": "Respiratory"
}
```
3. Add "Patient has asthma" to a clinical note
4. Re-run the script and verify it catches your new term

#### 2.4 Discussion Questions (10 min)
1. What are the tradeoffs between NER and dictionary matching?
2. When would you prefer dictionary matching?
3. What happens if there's a typo in the clinical note?

**Key Insight:** Dictionary matching is precise but brittle. Typos break it. Next part addresses this!

## Part 3: Entity Linking Strategies (60 min)

### Learning Objectives
- Link entities to standard terminologies (ICD-10, SNOMED, RxNorm)
- Implement fuzzy matching for typos and variations
- Use semantic similarity for conceptual matching
- Detect negation in clinical text

### Activities

#### 3.1 Understand Entity Linking (15 min)

**Why Entity Linking Matters:**
- "diabetes" → ICD-10: E11, SNOMED: 44054006
- "high blood pressure" → Same disease as "hypertension"
- Links enable: querying, analytics, interoperability

**Read:** Entity linking waterfall strategy in script header

#### 3.2 Test Matching Strategies (15 min)
```bash
python 03_entity_linking.py
```

**Examine the test cases:**
- "hypertension" → Exact match
- "diabetis" (typo) → Fuzzy match
- "high blood pressure" → Semantic match
- "no diabetes" → Negation detection

**Exercise:** Add your own test cases:
```python
test_cases = [
    "HTN",                    # Your prediction: ?
    "diabetic",              # Your prediction: ?
    "elevated blood sugar",  # Your prediction: ?
    "patient denies chest pain",  # Your prediction: ?
]
```

#### 3.3 Deep Dive: Fuzzy Matching (15 min)

**Understand RapidFuzz:**
- Levenshtein distance: character edits needed
- Threshold: 80% similarity required
- Handles typos, misspellings, variations

**Try This:**
```python
from rapidfuzz import fuzz

# Test similarity scores
print(fuzz.ratio("diabetes", "diabtes"))      # ~87
print(fuzz.ratio("diabetes", "hyperglycemia")) # ~30
```

**Discussion:**
- Why does "diabtes" match "diabetes"?
- Why doesn't "hyperglycemia" match "diabetes"?
- What's a good threshold? Too high? Too low?

#### 3.4 Deep Dive: Semantic Matching (15 min)

**Understand Sentence Embeddings:**
- Convert text to numerical vectors (embeddings)
- Similar meaning → similar vectors
- Cosine similarity measures closeness

**Key Insight:** "high blood pressure" and "hypertension" have similar embeddings even though the words are different!

**Experiment:**
```python
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('all-MiniLM-L6-v2')

# Encode and compare
emb1 = model.encode(["hypertension"])
emb2 = model.encode(["high blood pressure"])
similarity = np.dot(emb1, emb2.T)
print(f"Similarity: {similarity}")  # High!

emb3 = model.encode(["diabetes"])
similarity2 = np.dot(emb1, emb3.T)
print(f"Similarity: {similarity2}")  # Low!
```

## Part 4: Generating Knowledge Graphs (45 min)

### Learning Objectives
- Design a medical knowledge graph schema
- Generate Cypher CREATE statements
- Build relationships between entities
- Create an executable Neo4j script

### Activities

#### 4.1 Understand Graph Schema (10 min)

**Review the schema in script header:**
- Nodes: Patient, Diagnosis, Disease, Medication
- Relationships: HAS_DIAGNOSIS, IS_DISEASE, PRESCRIBED
- Properties: confidence, dates, codes

**Draw it out:**
```
(Patient)-[:HAS_DIAGNOSIS]->(Diagnosis)-[:IS_DISEASE]->(Disease)
(Patient)-[:PRESCRIBED]->(Medication)
```

#### 4.2 Generate Cypher Script (10 min)
```bash
python 04_cypher_generation.py
```

**Review the output:**
- Open `output/knowledge_graph.cypher`
- Count the CREATE statements
- Find a MATCH...CREATE pattern

#### 4.3 Understand Cypher Syntax (15 min)

**Node Creation:**
```cypher
CREATE (p:Patient {
  patient_id: 'P001',
  name: 'John Smith',
  age: 58
})
```

**Relationship Creation:**
```cypher
MATCH (p:Patient {patient_id: 'P001'})
MATCH (d:Disease {disease_id: 'I10'})
CREATE (p)-[r:HAS_DIAGNOSIS]->(d)
SET r.confidence = 0.95
```

**Exercise:** Write a Cypher query to find all patients with diabetes:
```cypher
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d:Disease)
WHERE d.canonical_name = 'Type 2 Diabetes Mellitus'
RETURN p.name, p.age
```

#### 4.4 Visualize in Neo4j (10 min)

**Option 1: Neo4j Desktop**
1. Download Neo4j Desktop (free)
2. Create new database
3. Paste cypher script into Browser
4. Execute and visualize

**Option 2: Neo4j Aura (Cloud)**
1. Sign up at neo4j.com/aura (free tier)
2. Create database
3. Connect and execute script

**Query Examples:**
```cypher
// Find all diseases for a patient
MATCH (p:Patient {patient_id: 'P001'})-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d:Disease)
RETURN d.canonical_name

// Find co-occurring diseases
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d1:Disease)
MATCH (p)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d2:Disease)
WHERE d1.disease_id < d2.disease_id
RETURN d1.canonical_name, d2.canonical_name, count(p) as patients
ORDER BY patients DESC
```

## Advanced Challenges

### Challenge 1: Add Symptoms (30 min)
1. Create a symptom dictionary in `medical_terminologies.json`
2. Extract symptoms from clinical notes
3. Add Symptom nodes and relationships to Cypher script

### Challenge 2: Temporal Relationships (45 min)
1. Extract dates when conditions were diagnosed
2. Create DIAGNOSED_AFTER relationships
3. Query for disease progression timelines

### Challenge 3: Confidence Thresholding (30 min)
1. Add a confidence threshold parameter
2. Only create relationships above threshold
3. Flag low-confidence entities for human review

### Challenge 4: HITL Interface (60 min)
1. Build a simple web interface
2. Show low-confidence extractions
3. Allow humans to confirm/reject
4. Re-generate Cypher with corrections

## Key Takeaways

### What You Learned
1. ✓ NER basics and importance of domain models
2. ✓ Dictionary-based entity extraction
3. ✓ Entity linking strategies (exact, fuzzy, semantic)
4. ✓ Negation detection in clinical text
5. ✓ Knowledge graph design and Cypher generation

### Real-World Applications
- **Clinical Decision Support**: Alert doctors to drug interactions
- **Population Health**: Identify disease patterns and risk factors
- **Research**: Link patient data to clinical trials
- **Quality Metrics**: Track treatment adherence and outcomes

### Next Steps
- Explore larger medical terminologies (UMLS, full SNOMED)
- Add more entity types (procedures, labs, vitals)
- Implement temporal reasoning
- Build query APIs for applications
- Deploy as a production NLP pipeline

## Resources

### Documentation
- spaCy: https://spacy.io/
- SciSpacy: https://allenai.github.io/scispacy/
- Neo4j Cypher: https://neo4j.com/docs/cypher-manual/
- RapidFuzz: https://github.com/maxbachmann/RapidFuzz
- Sentence Transformers: https://www.sbert.net/

### Medical Terminologies
- ICD-10: https://www.who.int/classifications/icd/
- SNOMED CT: https://www.snomed.org/
- RxNorm: https://www.nlm.nih.gov/research/umls/rxnorm/
- UMLS: https://www.nlm.nih.gov/research/umls/

### Papers
- "ClinicalBERT" - Medical language models
- "Med7" - Medical NER models
- "MIMIC-III" - Clinical notes dataset

## Troubleshooting

### Issue: Model not found
```bash
pip install https://s3-us-west-2.amazonaws.com/ai2-s2-scispacy/releases/v0.5.4/en_core_sci_sm-0.5.4.tar.gz
```

### Issue: Memory errors with semantic matching
- Use smaller model: 'paraphrase-MiniLM-L3-v2'
- Process in batches
- Reduce embedding dimension

### Issue: Cypher script fails in Neo4j
- Check for special characters in strings
- Verify all MATCH statements find nodes
- Run constraints before CREATE statements

## Feedback & Questions
This is a learning project! If you have questions or suggestions:
1. Review the inline comments in each script
2. Check the troubleshooting section
3. Experiment with the code
4. Share your insights with the group
