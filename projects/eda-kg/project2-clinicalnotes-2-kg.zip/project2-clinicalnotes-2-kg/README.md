# Clinical Notes to Knowledge Graph Mini-Project

## Overview
This mini-project guides you through extracting structured information from clinical notes and generating Cypher scripts to build a medical knowledge graph in Neo4j. You'll learn various entity recognition and linking techniques used in real-world healthcare NLP systems.

## Learning Objectives
- Understand Named Entity Recognition (NER) in healthcare domain
- Learn why domain-specific models matter for medical text
- Implement dictionary/terminology-driven entity extraction
- Apply Entity Linking strategies (exact, fuzzy, semantic matching)
- Handle real-world complications: negation, abbreviations, disambiguation
- Generate Cypher scripts for Neo4j graph database

## Project Structure
```
clinical-notes-kg/
├── README.md                          # This file
├── requirements.txt                   # Python dependencies
├── data/
│   ├── sample_notes.json             # Sample clinical notes
│   └── medical_terminologies.json    # Disease/drug dictionaries
├── notebooks/
│   ├── 01_basic_ner.py               # Basic NER with spaCy
│   ├── 02_dictionary_ner.py          # Dictionary-based extraction
│   ├── 03_entity_linking.py          # Entity linking strategies
│   └── 04_cypher_generation.py       # Generate Cypher scripts
├── src/
│   ├── __init__.py
│   ├── ner_extractor.py              # NER utilities
│   ├── entity_linker.py              # Entity linking utilities
│   ├── negation_detector.py          # Negation handling
│   └── cypher_builder.py             # Cypher script generation
└── output/
    └── knowledge_graph.cypher         # Final output script
```

## Setup Instructions

### 1. Install Dependencies
```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
python -m spacy download en_core_sci_sm
```

### 2. Run the Notebooks in Order
Each notebook builds on the previous one:
1. `01_basic_ner.py` - Learn basic NER
2. `02_dictionary_ner.py` - Add dictionary-based extraction
3. `03_entity_linking.py` - Implement entity linking
4. `04_cypher_generation.py` - Generate final Cypher script

### 3. Expected Output
A Cypher script that creates:
- **Patient** nodes with demographics
- **Diagnosis** nodes with dates and codes
- **Disease** nodes linked to standard terminologies
- **Treatment** nodes (medications, procedures)
- **Relationships** connecting these entities

## Knowledge Graph Schema

```
(Patient)-[:HAS_DIAGNOSIS]->(Diagnosis)-[:IS_DISEASE]->(Disease)
(Patient)-[:PRESCRIBED]->(Medication)
(Diagnosis)-[:TREATED_WITH]->(Treatment)
(Disease)-[:SAME_AS]->(StandardTerm)
```

## Key Concepts Covered

### Entity Recognition Techniques
1. **General NER (spaCy)**: Good baseline, but misses medical specifics
2. **Medical NER (SciSpacy)**: Better for clinical text
3. **Dictionary/Rule-based**: Highest precision for known terms

### Entity Linking Strategies
1. **Exact Match**: Match codes (ICD-10, SNOMED) or canonical names
2. **Fuzzy Match**: Handle typos, abbreviations using RapidFuzz
3. **Semantic Match**: Use embeddings (Sentence-Transformers) for similarity

### Real-World Challenges
- **Negation**: "no diabetes" vs "diabetes"
- **Abbreviations**: "HTN" = "Hypertension"
- **Disambiguation**: "cold" (common cold vs temperature)
- **Confidence Scoring**: When to trust extractions
- **Human-in-the-Loop (HITL)**: Flag uncertain cases

## Getting Started
Start with `01_basic_ner.py` and follow the comments. Each script is heavily documented to guide you through the implementation.

Good luck! 🏥📊
