# Clinical Notes to Knowledge Graph - Mini Project

## Project Overview

This comprehensive mini-project teaches participants how to extract structured medical entities from clinical notes and generate Neo4j Cypher scripts to build a medical knowledge graph. The project emphasizes practical, real-world NLP techniques used in healthcare AI systems.

## What's Included

### Core Files
- **README.md** - Project overview and setup instructions
- **WALKTHROUGH.md** - Detailed step-by-step guide (3-4 hours)
- **QUICK_REFERENCE.md** - Command cheat sheet and code snippets
- **INSTRUCTOR_GUIDE.md** - Teaching guide with lecture outlines
- **requirements.txt** - All Python dependencies

### Data
- **data/sample_notes.json** - 5 realistic clinical notes with diverse conditions
- **data/medical_terminologies.json** - Disease and medication dictionaries with ICD-10, SNOMED, RxNorm codes

### Notebooks (Progressive Learning)
1. **01_basic_ner.py** - Introduction to NER, comparing general vs. medical models
2. **02_dictionary_ner.py** - Dictionary/terminology-driven entity extraction
3. **03_entity_linking.py** - Entity linking with exact, fuzzy, and semantic matching
4. **04_cypher_generation.py** - Generate complete Neo4j Cypher scripts

### Supporting Files
- **src/** - Reusable utility modules
- **output/** - Generated Cypher scripts and sample outputs

## 🎓 Learning Objectives

Participants will learn:
1. ✅ Named Entity Recognition (NER) fundamentals
2. ✅ Why domain-specific models matter for medical text
3. ✅ Dictionary-based entity extraction techniques
4. ✅ Entity linking strategies (exact, fuzzy, semantic)
5. ✅ Negation detection in clinical text
6. ✅ Knowledge graph design and Cypher generation
7. ✅ Real-world complications: abbreviations, disambiguation, confidence scoring

## 🔧 Key Technologies

- **spaCy** - NER framework
- **SciSpacy** - Medical NER models
- **RapidFuzz** - Fuzzy string matching for typos
- **Sentence-Transformers** - Semantic similarity with embeddings
- **Neo4j/Cypher** - Graph database and query language

## 📊 Knowledge Graph Schema

```
Nodes:
- Patient (demographics)
- Diagnosis (with dates and confidence)
- Disease (ICD-10, SNOMED codes)
- Medication (RxNorm codes, dosages)

Relationships:
- (Patient)-[:HAS_DIAGNOSIS]->(Diagnosis)
- (Diagnosis)-[:IS_DISEASE]->(Disease)
- (Patient)-[:PRESCRIBED]->(Medication)
```

## 🚀 Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt
python -m spacy download en_core_web_sm
python -m spacy download en_core_sci_sm

# 2. Run the notebooks in order
cd notebooks
python 01_basic_ner.py
python 02_dictionary_ner.py
python 03_entity_linking.py
python 04_cypher_generation.py

# 3. Load into Neo4j
# Open Neo4j Browser and execute: output/knowledge_graph.cypher
```

## Sample Clinical Note

```
Patient presents with complaints of chest pain and shortness of 
breath for the past 3 days. History of hypertension and Type 2 
diabetes mellitus. Physical exam reveals elevated BP at 160/95. 
ECG shows signs of myocardial ischemia. Patient denies any history 
of smoking. Started on aspirin 81mg daily and metoprolol 50mg BID.
```

## What Gets Extracted

From the above note, the system extracts:

**Diseases:**
- Hypertension (ICD-10: I10)
- Type 2 Diabetes Mellitus (ICD-10: E11)
- Myocardial Ischemia (ICD-10: I25.9)

**Medications:**
- Aspirin 81mg daily (RxNorm: 1191)
- Metoprolol 50mg BID (RxNorm: 6918)

**Negations:**
- "denies any history of smoking" (correctly identified as negated)

## Real-World Features

### Entity Recognition Techniques
1. **General NER (spaCy)** - Baseline, finds dates/numbers
2. **Medical NER (SciSpacy)** - Trained on biomedical literature
3. **Dictionary Matching** - Uses PhraseMatcher for exact matches
4. **Combined Approach** - Merges NER + dictionary for best coverage

### Entity Linking Strategies
1. **Exact Matching** - Direct lookup in terminologies (fastest, most confident)
2. **Fuzzy Matching** - Handles typos using RapidFuzz (e.g., "diabtes" → "diabetes")
3. **Semantic Matching** - Uses embeddings for conceptual similarity (e.g., "high blood pressure" → "hypertension")
4. **Waterfall Approach** - Try exact → fuzzy → semantic in order

### Complications Handled
- ✅ **Negation Detection** - "no diabetes" vs "diabetes"
- ✅ **Abbreviations** - HTN, BID, PRN, SOB
- ✅ **Confidence Scoring** - Track extraction reliability
- ✅ **Multiple Synonyms** - "T2DM", "Type 2 diabetes", "diabetes mellitus type 2"
- ⚠️  **Disambiguation** - Partially addressed (context needed for full solution)
- ⚠️  **HITL (Human-in-the-Loop)** - Flagging strategy discussed

## 📈 Example Cypher Queries

```cypher
// Find all patients with diabetes
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d:Disease)
WHERE d.canonical_name = 'Type 2 Diabetes Mellitus'
RETURN p.name, p.age

// Find co-occurring diseases
MATCH (p:Patient)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d1:Disease)
MATCH (p)-[:HAS_DIAGNOSIS]->()-[:IS_DISEASE]->(d2:Disease)
WHERE d1.disease_id < d2.disease_id
RETURN d1.canonical_name, d2.canonical_name, count(p) as patients
ORDER BY patients DESC

// Find most prescribed medications
MATCH ()-[r:PRESCRIBED]->(m:Medication)
RETURN m.generic_name, count(r) as prescriptions
ORDER BY prescriptions DESC
```

## Workshop Structure

### For Participants (3-4 hours)
1. **Part 1 (45 min)**: Basic NER and domain models
2. **Part 2 (45 min)**: Dictionary-based extraction
3. **Part 3 (60 min)**: Entity linking strategies
4. **Part 4 (45 min)**: Cypher generation

### For Instructors
- Detailed lecture slides outline
- Live demo scripts
- Discussion questions
- Exercise solutions
- Troubleshooting tips
- Assessment rubrics

## Unique Features of This Project

1. **Heavily Commented Code** - Every script has extensive inline documentation
2. **Progressive Learning** - Each script builds on the previous one
3. **Real Clinical Notes** - Authentic medical scenarios (de-identified)
4. **Complete Pipeline** - From raw text to executable Cypher
5. **Production Considerations** - Discusses real-world complications
6. **Multiple Resources** - Walkthrough, quick reference, instructor guide
7. **Hands-On Exercises** - Participants code and modify actively

## Advanced Extensions

Ready to go further? Try these challenges:

1. **Add Symptoms** - Extract and link symptom entities
2. **Temporal Relations** - Track condition onset and progression
3. **Lab Results** - Parse and normalize lab values
4. **Procedure Codes** - Add CPT codes for procedures
5. **Web Interface** - Build a Flask/FastAPI demo
6. **HITL Dashboard** - Review and correct low-confidence extractions
7. **Fine-tune Models** - Train custom NER on your data
8. **Scaling** - Process 10,000+ notes efficiently

## Additional Resources

### Medical Terminologies
- **UMLS** - Unified Medical Language System (comprehensive)
- **ICD-10** - International Classification of Diseases
- **SNOMED CT** - Systematized Nomenclature of Medicine
- **RxNorm** - Normalized drug names
- **LOINC** - Lab test codes

### NLP Libraries
- **medSpaCy** - Advanced clinical NER
- **ClinicalBERT** - Transformer model for clinical text
- **negspacy** - Advanced negation detection
- **scispacy** - Scientific text processing

### Datasets
- **MIMIC-III** - Intensive care unit notes
- **i2b2** - Clinical NLP challenges
- **n2c2** - Clinical informatics datasets

## Assessment Ideas

### For Self-Study
- Complete all exercises in WALKTHROUGH.md
- Add a new entity type (symptoms)
- Achieve 90%+ accuracy on test set

### For Workshops
- Participation in discussions
- Completion of hands-on exercises
- Final project: Process 3 custom clinical notes
- Quiz on key concepts (NER, entity linking, Cypher)

## Contributing & Feedback

This is an educational project. To improve it:
1. Try the exercises yourself
2. Note unclear sections
3. Test on different clinical notes
4. Suggest additional features
5. Share your custom extensions

## Ethical Considerations

**Important Notes:**
- This project uses **synthetic clinical data** for educational purposes
- **Never** upload real patient data to public systems without de-identification
- Always comply with **HIPAA** and local privacy regulations
- Consider bias in medical AI systems
- Understand limitations of automated clinical NLP

## Checklist for Success

Before starting:
- [ ] Python 3.8+ installed
- [ ] 4GB RAM available
- [ ] 2GB disk space free
- [ ] Internet connection for downloads

After completion:
- [ ] All 4 notebooks run successfully
- [ ] Cypher script generated
- [ ] Neo4j graph created and queryable
- [ ] Understand extraction pipeline
- [ ] Can explain each matching strategy

## What Participants Will Create

By the end, participants will have:
1. ✅ A working clinical NLP pipeline
2. ✅ Understanding of multiple entity extraction techniques
3. ✅ A Neo4j knowledge graph of 5 patients
4. ✅ Executable Cypher scripts
5. ✅ Foundation for production healthcare NLP systems

## Expected Results

**Entities Extracted (from 5 sample patients):**
- 12-15 unique diseases
- 8-10 unique medications
- 20+ total diagnoses
- 15+ prescriptions
- 5-8 negated conditions

**Knowledge Graph:**
- 5 Patient nodes
- 12-15 Disease nodes
- 8-10 Medication nodes
- 20+ Diagnosis nodes
- 35+ relationships

## Success Stories

Participants who complete this project will be able to:
- Build clinical NLP pipelines
- Work with medical terminologies
- Design healthcare knowledge graphs
- Interview for healthcare AI roles
- Contribute to medical informatics projects
