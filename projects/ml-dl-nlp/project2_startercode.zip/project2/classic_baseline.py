import pandas as pd, numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

df = pd.read_csv("drug_reviews_10k.csv") # columns: text, sentiment in {neg,neu,pos}, adverse_event in {0,1}
X_train, X_test, y_train, y_test = train_test_split(df["text"], df["sentiment"], test_size=0.2, random_state=42, stratify=df["sentiment"])

pipe = Pipeline([
    ("tfidf", TfidfVectorizer(min_df=5, ngram_range=(1,2))),
    ("clf", LogisticRegression(max_iter=200))
])
pipe.fit(X_train, y_train)
pred = pipe.predict(X_test)
print(classification_report(y_test, pred))
