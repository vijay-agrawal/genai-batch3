# Hugging Face Trainer for sentiment (3-way)
from datasets import Dataset, ClassLabel
from transformers import AutoTokenizer, AutoModelForSequenceClassification, TrainingArguments, Trainer
import numpy as np, evaluate

label2id = {"neg":0,"neu":1,"pos":2}; id2label = {v:k for k,v in label2id.items()}
def to_ds(df):
    return Dataset.from_pandas(pd.DataFrame({
        "text": df["text"].tolist(),
        "label": [label2id[s] for s in df["sentiment"]]
    }))

train_ds = to_ds(df.sample(frac=0.8, random_state=42))
test_ds  = to_ds(df.drop(train_ds.to_pandas().index))

model_name = "distilbert-base-uncased"  # try "emilyalsentzer/Bio_ClinicalBERT"
tok = AutoTokenizer.from_pretrained(model_name)
def tok_fn(ex): return tok(ex["text"], truncation=True, padding="max_length", max_length=256)
train_ds = train_ds.map(tok_fn, batched=True)
test_ds  = test_ds.map(tok_fn, batched=True)

metric = evaluate.load("f1")
def compute_metrics(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=-1)
    return {"f1_macro": metric.compute(predictions=preds, references=labels, average="macro")["f1"]}

model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=3, id2label=id2label, label2id=label2id)
args = TrainingArguments("sentiment_out", per_device_train_batch_size=16, per_device_eval_batch_size=32, eval_strategy="epoch", num_train_epochs=2, fp16=True)
trainer = Trainer(model=model, args=args, train_dataset=train_ds, eval_dataset=test_ds, tokenizer=tok, compute_metrics=compute_metrics)
trainer.train()
