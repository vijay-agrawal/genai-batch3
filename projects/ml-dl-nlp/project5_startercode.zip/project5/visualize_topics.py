# lda_viz.py
import gensim, pyLDAvis, pyLDAvis.gensim_models as gensimvis
from gensim import corpora
from joblib import load

lda = gensim.models.LdaModel.load("lda.model")
dictionary = corpora.Dictionary.load("lda.dict")
import pandas as pd, spacy, re
nlp = spacy.load("en_core_web_sm", disable=["ner","parser","tagger"])

def clean_tokens(text):
    text = re.sub(r"[^a-zA-Z\s\|]", " ", text.lower())
    doc = nlp(text)
    return [t.lemma_ for t in doc if t.is_alpha and not t.is_stop and len(t) > 2]

df = pd.read_csv("notes.csv")
corpus = [dictionary.doc2bow(clean_tokens(t)) for t in df["text"]]
vis = gensimvis.prepare(lda, corpus, dictionary)
pyLDAvis.save_html(vis, "lda_topics.html")
print("Saved lda_topics.html")
