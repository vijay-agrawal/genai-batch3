# downstream_compare.py
import pandas as pd, numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer

notes = pd.read_csv("notes.csv")
lda_feat = pd.read_csv("lda_features.csv")
df = notes.merge(lda_feat[["note_id"]+[c for c in lda_feat.columns if c.startswith("topic_")]], on="note_id")

X_train_txt, X_test_txt, y_train, y_test = train_test_split(
    df["text"], notes["needs_icu_review"], test_size=0.2, stratify=notes["needs_icu_review"], random_state=42
)

# A) TF-IDF baseline
tfidf = TfidfVectorizer(min_df=5, ngram_range=(1,2))
Xtr = tfidf.fit_transform(X_train_txt); Xte = tfidf.transform(X_test_txt)
logit = LogisticRegression(max_iter=500)
logit.fit(Xtr, y_train); p_tfidf = logit.predict_proba(Xte)[:,1]

# B) LDA topic features
X = df[[c for c in df.columns if c.startswith("topic_")]].values
X_train, X_test, _, _ = train_test_split(X, notes["needs_icu_review"], test_size=0.2, stratify=notes["needs_icu_review"], random_state=42)
logit2 = LogisticRegression(max_iter=500)
logit2.fit(X_train, y_train); p_lda = logit2.predict_proba(X_test)[:,1]

print("TF-IDF AUC:", roc_auc_score(y_test, p_tfidf))
print("LDA-topics AUC:", roc_auc_score(y_train.index.map(lambda i: y_test.iloc[i%len(y_test)] if i>=len(y_train) else 0), p_lda))  # quick print; see note below
