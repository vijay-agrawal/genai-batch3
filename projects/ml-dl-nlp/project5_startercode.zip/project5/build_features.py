# lda_features.py
import pandas as pd, gensim, re, spacy
from gensim import corpora

nlp = spacy.load("en_core_web_sm", disable=["ner","parser","tagger"])
def clean_tokens(text):
    text = re.sub(r"[^a-zA-Z\s\|]", " ", text.lower())
    doc = nlp(text)
    return [t.lemma_ for t in doc if t.is_alpha and not t.is_stop and len(t) > 2]

lda = gensim.models.LdaModel.load("lda.model")
dictionary = corpora.Dictionary.load("lda.dict")

df = pd.read_csv("notes.csv")
rows=[]
K = lda.num_topics
for _,r in df.iterrows():
    bow = dictionary.doc2bow(clean_tokens(r["text"]))
    topic_vec = [0.0]*K
    for tid, prob in lda.get_document_topics(bow):
        topic_vec[tid] = prob
    rows.append([r["note_id"], r["needs_icu_review"], *topic_vec])

cols = ["note_id","needs_icu_review"] + [f"topic_{i}" for i in range(K)]
feat = pd.DataFrame(rows, columns=cols)
feat.to_csv("lda_features.csv", index=False)
print("Saved lda_features.csv")
