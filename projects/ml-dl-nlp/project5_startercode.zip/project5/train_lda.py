# lda_train.py
import pandas as pd, re, spacy
from gensim import corpora, models
from gensim.models.coherencemodel import CoherenceModel

nlp = spacy.load("en_core_web_sm", disable=["ner","parser","tagger"])
STOP_ADD = {"afebrile","monitoring","noted","started"}  # small domain add-on

def clean_tokens(text):
    text = re.sub(r"[^a-zA-Z\s\|]", " ", text.lower())
    doc = nlp(text)
    toks = [t.lemma_ for t in doc if t.is_alpha and not t.is_stop and len(t) > 2]
    return [t for t in toks if t not in STOP_ADD]

df = pd.read_csv("notes.csv")
docs = [clean_tokens(t) for t in df["text"]]

dictionary = corpora.Dictionary(docs)
dictionary.filter_extremes(no_below=5, no_above=0.4)
corpus = [dictionary.doc2bow(d) for d in docs]

best_k, best_coh, best_model = None, -1, None
for k in [5,7,10]:
    lda = models.LdaModel(
        corpus=corpus, id2word=dictionary, num_topics=k,
        passes=8, random_state=42, alpha='auto', eta='auto'
    )
    cm = CoherenceModel(model=lda, texts=docs, dictionary=dictionary, coherence='c_v')
    coh = cm.get_coherence()
    print(f"k={k} coherence={coh:.3f}")
    if coh > best_coh:
        best_k, best_coh, best_model = k, coh, lda

print(f"Selected k={best_k} (coherence={best_coh:.3f})")
best_model.save("lda.model")
dictionary.save("lda.dict")
# Optional: show top words per topic
for tid in range(best_k):
    print(tid, best_model.print_topic(tid, topn=8))
