# make_notes.py
import numpy as np, pandas as pd, random
np.random.seed(7); random.seed(7)

N = 8000
stable_phrases = [
  "stable vitals, monitoring", "afebrile, no acute changes",
  "pain controlled, ambulating", "no respiratory distress"
]
risk_phrases = [
  "lactate rising, tachycardia noted", "pressors started, hypotension",
  "fever spikes, increased RR", "worsening oxygenation, low SpO2"
]

rows=[]
for i in range(N):
    y = int(np.random.rand()<0.35)  # 35% positive
    chunks=[]
    for _ in range(np.random.randint(2,6)):
        if y and np.random.rand()<0.6:
            chunks.append(random.choice(risk_phrases))
        else:
            chunks.append(random.choice(stable_phrases))
    rows.append({"note_id": i, "text": " | ".join(chunks), "needs_icu_review": y})

df = pd.DataFrame(rows)
df.to_csv("notes.csv", index=False)
print("Saved notes.csv")
