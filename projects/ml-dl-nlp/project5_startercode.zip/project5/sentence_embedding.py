from sentence_transformers import SentenceTransformer
emb = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
E_tr = emb.encode(X_train_txt.tolist(), show_progress_bar=True)
E_te = emb.encode(X_test_txt.tolist(), show_progress_bar=True)
logit3 = LogisticRegression(max_iter=500)
logit3.fit(E_tr, y_train)
p_emb = logit3.predict_proba(E_te)[:,1]
from sklearn.metrics import roc_auc_score
print("MiniLM Embeddings AUC:", roc_auc_score(y_test, p_emb))
