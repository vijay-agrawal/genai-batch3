import pandas as pd
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from sklearn.model_selection import train_test_split

# --- Assume HAM10000_metadata.csv and image folders are available ---
# 1. Prepare the dataframe (this is a simplified example)
# metadata_df = pd.read_csv('HAM10000_metadata.csv')
# # Add image paths and create a binary 'label' column ('benign' vs 'malignant')
# # For demonstration, let's create a dummy dataframe
d = {'image_path': ['img1.jpg', 'img2.jpg', 'img3.jpg', 'img4.jpg'], 'label': ['benign', 'malignant', 'benign', 'malignant']}
df = pd.DataFrame(data=d)
train_df, val_df = train_test_split(df, test_size=0.2) # Create train/validation splits

# 2. Setup ImageDataGenerator for data augmentation
train_datagen = ImageDataGenerator(rescale=1./255, rotation_range=20, horizontal_flip=True)
val_datagen = ImageDataGenerator(rescale=1./255)

# NOTE: The 'directory' and 'x_col'/'y_col' will point to your actual image folder and dataframe columns
# This code will not run without the actual data paths.
# train_generator = train_datagen.flow_from_dataframe(
#     train_df, directory='path/to/images', x_col='image_path', y_col='label',
#     target_size=(224, 224), class_mode='binary', batch_size=32)
# validation_generator = val_datagen.flow_from_dataframe(...)

# 3. Build the model using Transfer Learning
base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
base_model.trainable = False # Freeze base layers

x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(128, activation='relu')(x)
predictions = Dense(1, activation='sigmoid')(x) # Sigmoid for binary classification

model = Model(inputs=base_model.input, outputs=predictions)

# 4. Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
model.summary()

# 5. Train the model (example call)
# history = model.fit(train_generator, validation_data=validation_generator, epochs=10)