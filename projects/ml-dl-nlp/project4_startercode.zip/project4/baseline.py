# LSTM vs Transformer
import torch, torch.nn as nn, numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score

data = np.load("series.npz")
X, y = data["X"], data["y"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
device = "cuda" if torch.cuda.is_available() else "cpu"

class LSTMModel(nn.Module):
    def __init__(self, F, H=64):
        super().__init__()
        self.lstm = nn.LSTM(F, H, batch_first=True)
        self.fc = nn.Linear(H, 1)
    def forward(self, x):
        o, _ = self.lstm(x)
        h = o[:,-1,:]
        return self.fc(h).squeeze(-1)

class TransEnc(nn.Module):
    def __init__(self, F, H=64, heads=4, layers=2):
        super().__init__()
        self.inp = nn.Linear(F, H)
        enc_layer = nn.TransformerEncoderLayer(d_model=H, nhead=heads, batch_first=True)
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=layers)
        self.fc = nn.Linear(H,1)
    def forward(self, x):
        z = self.inp(x)
        z = self.enc(z)
        return self.fc(z[:,-1,:]).squeeze(-1)

def train_eval(model):
    model.to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
    bce = nn.BCEWithLogitsLoss()
    for epoch in range(5):
        model.train()
        for i in range(0, len(X_train), 64):
            xb = torch.tensor(X_train[i:i+64], dtype=torch.float32, device=device)
            yb = torch.tensor(y_train[i:i+64], dtype=torch.float32, device=device)
            opt.zero_grad(); logits = model(xb); loss = bce(logits, yb); loss.backward(); opt.step()
    model.eval()
    with torch.no_grad():
        logits = []
        for i in range(0, len(X_test), 256):
            xb = torch.tensor(X_test[i:i+256], dtype=torch.float32, device=device)
            logits.append(torch.sigmoid(model(xb)).cpu().numpy())
    proba = np.concatenate(logits)
    return roc_auc_score(y_test, proba)

print("LSTM AUC:", train_eval(LSTMModel(F=8)))
print("Transformer AUC:", train_eval(TransEnc(F=8)))
