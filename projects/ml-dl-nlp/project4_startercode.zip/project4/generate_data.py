import numpy as np, pandas as pd, random
np.random.seed(7); random.seed(7)

N, T, F = 8000, 36, 8
X = np.zeros((N,T,F), dtype=np.float32)
y = np.zeros(N, dtype=np.int64)
notes = []

for i in range(N):
    hr = np.clip(np.random.normal(82, 8, T), 55, 140)
    sbp = np.clip(np.random.normal(115, 12, T), 80, 180)
    dbp = np.clip(np.random.normal(72, 8, T), 50, 110)
    rr = np.clip(np.random.normal(18, 4, T), 10, 35)
    temp = np.clip(np.random.normal(37, 0.4, T), 35.5, 40.5)
    spo2 = np.clip(np.random.normal(97, 1.5, T), 86, 100)
    wbc = np.clip(np.random.normal(8, 2, T), 2, 30)
    lact = np.clip(np.random.normal(1.2, 0.3, T), 0.5, 6)

    label = np.random.rand() < 0.35
    if label:
        # deterioration in last 12h
        for t in range(T-12, T):
            hr[t] += np.random.uniform(5, 15)
            rr[t] += np.random.uniform(2, 6)
            lact[t] += np.random.uniform(0.4, 1.2)
            sbp[t] -= np.random.uniform(5, 12)
            spo2[t] -= np.random.uniform(1, 4)
    y[i] = int(label)

    X[i,:,0],X[i,:,1],X[i,:,2],X[i,:,3]=hr,sbp,dbp,rr
    X[i,:,4],X[i,:,5],X[i,:,6],X[i,:,7]=temp,spo2,wbc,lact

    # generate short notes
    txt = []
    for t in range(0,T,6):
        if label and t>=T-12:
            txt.append(random.choice([
                "lactate rising, tachycardia noted",
                "pressors started, hypotension",
                "fever spikes and increased RR"
            ]))
        else:
            txt.append(random.choice([
                "stable vitals, monitoring",
                "unremarkable, afebrile",
                "no acute changes"
            ]))
    notes.append(" | ".join(txt))

np.savez_compressed("series.npz", X=X, y=y)
pd.DataFrame({"episode_id": range(N), "notes": notes}).to_csv("notes.csv", index=False)
print("Saved series.npz and notes.csv")
