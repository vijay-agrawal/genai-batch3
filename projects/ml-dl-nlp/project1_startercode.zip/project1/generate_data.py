# 1) Generate synthetic tabular + notes
import numpy as np, pandas as pd, random, os
from pathlib import Path

np.random.seed(42); random.seed(42)
N = 12000
Path("notes").mkdir(exist_ok=True)

ages = np.clip(np.random.normal(62, 14, N).round(), 18, 95).astype(int)
sex = np.random.choice(["F","M"], N)
cci = np.clip(np.random.poisson(2, N), 0, 10)  # Charlson-like
los = np.clip(np.random.gamma(3, 1.2, N).round(), 1, 30).astype(int)
prev_adm = np.clip(np.random.poisson(0.8, N), 0, 8)
dx = np.random.choice(["CHF","COPD","DM","CKD","HTN","AFib","PNA"], N, p=[.15,.12,.18,.12,.22,.06,.15])
hr = np.clip(np.random.normal(80, 12, N), 40, 140).round(1)
creat = np.clip(np.random.normal(1.1, 0.4, N), 0.4, 3.5).round(2)

# latent logit with effects
logit = -2.0 + 0.02*(ages-60) + 0.35*cci + 0.15*prev_adm + 0.05*(los-5) + 0.3*(dx=="CHF") + 0.25*(dx=="CKD") + 0.4*(creat>1.4)
p = 1/(1+np.exp(-logit))
y = (np.random.rand(N) < p).astype(int)

df = pd.DataFrame({
    "patient_id": [f"P{i:05d}" for i in range(N)],
    "age": ages, "sex": sex, "comorbidity_index": cci, "los_days": los,
    "num_prev_adm": prev_adm, "primary_dx": dx, "avg_hr": hr,
    "avg_creatinine": creat, "readmitted_30d": y
})
df.to_csv("patients.csv", index=False)

templates = [
    "Patient with {dx} and {cci} comorbidities. {flag} Discharged after {los} days.",
    "History notable for {dx}. {flag} Follow-up arranged due to risk factors.",
    "Comorbid burden {cci}. {flag} Discharge counseling provided."
]
def note_line(dx, cci, los, high_risk):
    flag = "Multiple readmission risk indicators present." if high_risk else "Low immediate readmission concerns."
    t = random.choice(templates)
    return t.format(dx=dx, cci=cci, los=los, flag=flag)

for pid, dxi, ccii, losi, yi in zip(df.patient_id, df.primary_dx, df.comorbidity_index, df.los_days, df.readmitted_30d):
    with open(f"notes/{pid}.txt", "w") as f:
        for _ in range(np.random.randint(3,6)):
            f.write(note_line(dxi, ccii, losi, bool(yi))+"\n")
print("Done: patients.csv + notes/*.txt")
