# 2) Baselines: XGBoost (tabular) vs. Fusion (tabular + text embeddings)
import pandas as pd, glob, numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier
from sentence_transformers import SentenceTransformer

df = pd.read_csv("patients.csv")
# join text (concatenate each patient's note lines)
texts = []
for pid in df.patient_id:
    chunks = open(f"notes/{pid}.txt").read().splitlines()
    texts.append(" ".join(chunks))
df["notes_text"] = texts

X_tab = df.drop(columns=["patient_id","readmitted_30d","notes_text"])
y = df["readmitted_30d"].values

cat = ["sex","primary_dx"]
num = [c for c in X_tab.columns if c not in cat]
pre = ColumnTransformer([
    ("ohe", OneHotEncoder(handle_unknown="ignore"), cat)
], remainder="passthrough")

X_train, X_test, y_train, y_test, T_train, T_test = train_test_split(
    X_tab, y, df["notes_text"], test_size=0.2, random_state=42, stratify=y
)

tab_model = Pipeline([
    ("prep", pre),
    ("clf", XGBClassifier(n_estimators=400, max_depth=4, subsample=0.9, colsample_bytree=0.8, eval_metric="logloss", random_state=42))
])
tab_model.fit(X_train, y_train)
print("Tabular AUC:", tab_model.score(X_test, y_test))  # quick; replace with proper AUC later

# text embeddings
sbert = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")  # try BioClinicalBERT later
E_train = sbert.encode(T_train.tolist(), show_progress_bar=True)
E_test  = sbert.encode(T_test.tolist(),  show_progress_bar=True)

# simple fusion: concat tabular features (after transform) + text embeddings
X_train_tabular = pre.fit_transform(X_train)
X_test_tabular  = pre.transform(X_test)
from scipy.sparse import csr_matrix, hstack
# make dense for concat
X_train_dense = csr_matrix(X_train_tabular).toarray()
X_test_dense  = csr_matrix(X_test_tabular).toarray()
X_train_fuse = np.hstack([X_train_dense, E_train])
X_test_fuse  = np.hstack([X_test_dense, E_test])

fuse = XGBClassifier(n_estimators=500, max_depth=5, subsample=0.9, colsample_bytree=0.8, eval_metric="logloss", random_state=42)
fuse.fit(X_train_fuse, y_train)
from sklearn.metrics import roc_auc_score
print("Fusion AUC:", roc_auc_score(y_test, fuse.predict_proba(X_test_fuse)[:,1]))
