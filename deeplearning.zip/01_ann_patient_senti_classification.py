import numpy as np
import pandas as pd
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

df = pd.read_csv('genaitraining/deeplearning/patient_pain_data.csv')
# Preprocessing
vectorizer = TfidfVectorizer(max_features=20)
X_text = vectorizer.fit_transform(df["Patient Notes"]).toarray()

encoder = OneHotEncoder(sparse_output=False, drop="first")
X_treatment = encoder.fit_transform(df[["Treatment Type"]])
X_surgery = (df["Surgery Done"] == "Yes").astype(int).values.reshape(-1, 1)
X_days = df["Days Admitted"].values.reshape(-1, 1)

scaler = StandardScaler()
X_days = scaler.fit_transform(X_days)

# Combine features
X = np.hstack((X_text, X_treatment, X_surgery, X_days))
y = df["Pain Level"].values.reshape(-1, 1)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Convert to tensors for TensorFlow
X_train_tf = X_train.astype(np.float32)
y_train_tf = y_train.astype(np.float32)
X_test_tf = X_test.astype(np.float32)
y_test_tf = y_test.astype(np.float32)

# Define the ANN model using TensorFlow/Keras
model_tf = keras.Sequential([
    layers.Dense(32, activation='relu', input_shape=(X_train_tf.shape[1],)),
    layers.Dense(16, activation='relu'),
    layers.Dense(8, activation='relu'),
    layers.Dense(1, activation='linear')  # Regression output for pain level
])

# Compile the model
model_tf.compile(optimizer='adam', loss='mean_squared_error', metrics=['mae'])

# Train the model
history_tf = model_tf.fit(X_train_tf, y_train_tf, epochs=50, batch_size=5, validation_data=(X_test_tf, y_test_tf), verbose=1)

# Evaluate the model
loss_tf, mae_tf = model_tf.evaluate(X_test_tf, y_test_tf)
print(f"Test Loss: {loss_tf}, Mean Absolute Error: {mae_tf}")
