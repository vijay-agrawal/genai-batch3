import numpy as np
import tensorflow as tf
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


# Generate synthetic patient history data
def generate_synthetic_data(n_samples=1000, sequence_length=10):
    # Features for each time step: temperature, heart_rate, blood_pressure, oxygen_level
    n_features = 4
    
    # Generate random sequences
    X = np.random.randn(n_samples, sequence_length, n_features)
    
    # Add some patterns that indicate diseases
    # Disease 1: Consistently high temperature and heart rate
    # Disease 2: Fluctuating blood pressure with low oxygen
    # Disease 0: Normal/Healthy
    
    y = np.zeros(n_samples)
    
    for i in range(n_samples):
        if np.mean(X[i, :, 0]) > 0.5 and np.mean(X[i, :, 1]) > 0.5:
            # Disease 1 pattern
            X[i, :, 0] += 1.5  # Higher temperature
            X[i, :, 1] += 1.2  # Higher heart rate
            y[i] = 1
        elif np.std(X[i, :, 2]) > 1.2 and np.mean(X[i, :, 3]) < -0.5:
            # Disease 2 pattern
            X[i, :, 2] = np.sin(np.linspace(0, 4*np.pi, sequence_length)) * 2  # Fluctuating blood pressure
            X[i, :, 3] -= 1.0  # Lower oxygen
            y[i] = 2
    
    #print it in a dataframe
    # Reshape X to 2D: (n_samples * sequence_length, n_features)
    X_flat = X.reshape(n_samples * sequence_length, n_features)

    # Repeat y values to match the number of rows
    y_flat = np.repeat(y, sequence_length)

    # Create DataFrame
    df = pd.DataFrame(X_flat, columns=['Temperature', 'Heart_Rate', 'Blood_Pressure', 'Oxygen_Level'])
    df["Label"] = y_flat  # Add disease labels

    # Display DataFrame
    print(df.head())

    return X, y

# Create and compile the RNN model
def create_rnn_model(sequence_length, n_features):
    model = tf.keras.Sequential([
        tf.keras.layers.LSTM(64, input_shape=(sequence_length, n_features), return_sequences=True),
        tf.keras.layers.Dropout(0.2),
        tf.keras.layers.LSTM(32),
        tf.keras.layers.Dropout(0.2),
        tf.keras.layers.Dense(16, activation='relu'),
        tf.keras.layers.Dense(3, activation='softmax')  # 3 classes: healthy, disease1, disease2
    ])
    
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

# Generate data
X, y = generate_synthetic_data()


# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale the features
scaler = StandardScaler()
X_train_reshaped = X_train.reshape(-1, X_train.shape[-1])
X_test_reshaped = X_test.reshape(-1, X_test.shape[-1])

X_train_scaled = scaler.fit_transform(X_train_reshaped).reshape(X_train.shape)
X_test_scaled = scaler.transform(X_test_reshaped).reshape(X_test.shape)

# Create and train the model
model = create_rnn_model(sequence_length=10, n_features=4)

history = model.fit(
    X_train_scaled,
    y_train,
    epochs=20,
    batch_size=32,
    validation_split=0.2,
    verbose=1
)

# Evaluate the model
test_loss, test_accuracy = model.evaluate(X_test_scaled, y_test)
print(f"\nTest accuracy: {test_accuracy:.4f}")

# Function to make predictions on new patient data
def predict_disease(model, patient_history, scaler):
    """
    Make predictions on new patient data.
    
    Args:
        model: Trained RNN model
        patient_history: Array of shape (sequence_length, n_features)
        scaler: Fitted StandardScaler
    
    Returns:
        Predicted disease class and probabilities
    """
    # Reshape and scale the input
    patient_history = patient_history.reshape(1, *patient_history.shape)
    patient_history_reshaped = patient_history.reshape(-1, patient_history.shape[-1])
    patient_history_scaled = scaler.transform(patient_history_reshaped).reshape(patient_history.shape)
    
    # Make prediction
    probabilities = model.predict(patient_history_scaled)[0]
    predicted_class = np.argmax(probabilities)
    
    return predicted_class, probabilities

# Example usage of the prediction function
sample_patient = X_test[0]
predicted_class, probabilities = predict_disease(model, sample_patient, scaler)
print("\nSample Prediction:")
print(f"Predicted Class: {predicted_class}")
print(f"Class Probabilities: {probabilities}")