import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from transformers import BertTokenizer, TFBertModel

# Load dataset
file_path = "patientdata.csv"
df = pd.read_csv(file_path)

# Load BERT tokenizer
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")

# Tokenization and Encoding
def encode_texts(texts, tokenizer, max_length=50):
    return tokenizer(texts.tolist(), padding=True, truncation=True, max_length=max_length, return_tensors="tf")

encoded_texts = encode_texts(df["Patient Notes"].astype(str), tokenizer)
X_text_input_ids = encoded_texts["input_ids"]
X_text_attention_mask = encoded_texts["attention_mask"]

# Encode categorical and numerical features
encoder = OneHotEncoder(sparse_output=False, drop="first")
X_treatment = encoder.fit_transform(df[["Treatment Type"]])
X_surgery = (df["Surgery Done"] == "Yes").astype(int).values.reshape(-1, 1)
X_days = df["Days Admitted"].values.reshape(-1, 1)

scaler = StandardScaler()
X_days = scaler.fit_transform(X_days)

# Combine non-text features
X_numeric = np.hstack((X_treatment, X_surgery, X_days))
y = df["Pain Level"].values.reshape(-1, 1)

# Train-test split
X_train_text, X_test_text, X_train_mask, X_test_mask, X_train, X_test, y_train, y_test = train_test_split(
    X_text_input_ids, X_text_attention_mask, X_numeric, y, test_size=0.2, random_state=42
)

# Convert to TensorFlow tensors
X_train_tf = X_train.astype(np.float32)
y_train_tf = y_train.astype(np.float32)
X_test_tf = X_test.astype(np.float32)
y_test_tf = y_test.astype(np.float32)

# Load BERT model
bert_model = TFBertModel.from_pretrained("bert-base-uncased")

# Define Transformer-based Model
input_text_ids = layers.Input(shape=(50,), dtype=tf.int32, name="input_text_ids")
input_attention_mask = layers.Input(shape=(50,), dtype=tf.int32, name="input_attention_mask")

bert_output = bert_model(input_text_ids, attention_mask=input_attention_mask)[1]

input_numeric = layers.Input(shape=(X_train_tf.shape[1],))
concat = layers.concatenate([bert_output, input_numeric])

hidden = layers.Dense(32, activation='relu')(concat)
hidden = layers.Dense(16, activation='relu')(hidden)
hidden = layers.Dense(8, activation='relu')(hidden)
output = layers.Dense(1, activation='sigmoid')(hidden)  # Sigmoid for class range 1-10

model_tf = keras.Model(inputs=[input_text_ids, input_attention_mask, input_numeric], outputs=output)

# Compile model
model_tf.compile(optimizer='adam', loss='mean_squared_error', metrics=['mae'])

# Train the model
history_tf = model_tf.fit(
    [X_train_text, X_train_mask, X_train_tf], y_train_tf, 
    epochs=10, batch_size=4, validation_data=([X_test_text, X_test_mask, X_test_tf], y_test_tf), verbose=1
)

# Predictions
y_pred = model_tf.predict([X_test_text, X_test_mask, X_test_tf])

# Calculate Metrics
mse = mean_squared_error(y_test_tf, y_pred)
mae = mean_absolute_error(y_test_tf, y_pred)

print(f"Test Loss (MSE): {mse:.4f}")
print(f"Mean Absolute Error (MAE): {mae:.4f}")

# Baseline Comparison (Predicting Mean Pain Level)
y_baseline = np.full_like(y_test_tf, np.mean(y_train_tf))
baseline_mse = mean_squared_error(y_test_tf, y_baseline)
baseline_mae = mean_absolute_error(y_test_tf, y_baseline)

print(f"Baseline MSE (Predicting Mean Pain Level): {baseline_mse:.4f}")
print(f"Baseline MAE: {baseline_mae:.4f}")

# Performance Summary
if mae < baseline_mae:
    print("The BERT model outperforms the baseline and makes better predictions!")
else:
    print("The BERT model is not significantly better than predicting the mean pain level. Consider tuning.")
