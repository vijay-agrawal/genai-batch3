# RNN Pain Level Prediction - Healthcare Analytics
# This notebook demonstrates using RNN to predict patient pain levels from clinical notes

import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error
import re
from collections import Counter
import matplotlib.pyplot as plt

# Set random seed for reproducibility
torch.manual_seed(42)
np.random.seed(42)

print("RNN Pain Level Prediction Model")
print("=" * 50)

# 1. DATA PREPARATION
print("\n1. Loading and Preparing Data...")

# Sample patient data (expanded for better training)
data = {
    'Patient_Notes': [
        "I feel a little better today",
        "The pain is unbearable", 
        "I am feeling much better now",
        "Severe pain in my back today",
        "Pain has reduced significantly",
        "Terrible pain all over my body",
        "Slight improvement in pain",
        "No pain at all today",
        "Moderate pain but manageable",
        "Excruciating pain cannot move",
        "Pain is getting worse every day",
        "Some relief from medication",
        "Sharp shooting pain constantly",
        "Much better than yesterday",
        "Dull aching pain persists",
        "Perfect no discomfort today",
        "Intense pain disrupts sleep",
        "Gradual improvement in comfort",
        "Agony with every movement",
        "Comfortable and pain free"
    ],
    'Days_Admitted': [7, 4, 5, 3, 8, 2, 6, 10, 4, 1, 3, 7, 2, 9, 5, 12, 1, 8, 2, 11],
    'Treatment_Type': ['Surgery', 'Brain Surgery', 'Physical Therapy', 'Surgery', 
                      'Medication', 'Emergency', 'Surgery', 'Physical Therapy',
                      'Medication', 'Emergency', 'Surgery', 'Medication',
                      'Emergency', 'Physical Therapy', 'Surgery', 'Physical Therapy',
                      'Emergency', 'Medication', 'Emergency', 'Physical Therapy'],
    'Surgery_Done': ['Yes', 'Yes', 'No', 'Yes', 'No', 'No', 'Yes', 'No',
                    'No', 'No', 'Yes', 'No', 'No', 'No', 'Yes', 'No',
                    'No', 'No', 'No', 'No'],
    'Pain_Level': [3, 7, 2, 6, 2, 8, 4, 0, 5, 9, 7, 3, 8, 1, 4, 0, 9, 2, 10, 0]
}

df = pd.DataFrame(data)
print(f"Dataset shape: {df.shape}")
print("\nFirst few records:")
print(df.head())

# 2. TEXT PREPROCESSING
print("\n2. Text Preprocessing...")

def preprocess_text(text):
    """Clean and preprocess text data"""
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
    return text.split()

# Build vocabulary from patient notes
all_words = []
for note in df['Patient_Notes']:
    words = preprocess_text(note)
    all_words.extend(words)

vocab = Counter(all_words)
vocab_size = len(vocab)
word_to_idx = {word: i+1 for i, word in enumerate(vocab.keys())}
word_to_idx['<PAD>'] = 0  # Padding token
idx_to_word = {i: word for word, i in word_to_idx.items()}

print(f"Vocabulary size: {vocab_size + 1}")
print(f"Most common words: {vocab.most_common(5)}")

def text_to_sequence(text, max_length=10):
    """Convert text to sequence of integers"""
    words = preprocess_text(text)
    sequence = [word_to_idx.get(word, 0) for word in words]
    
    # Pad or truncate to max_length
    if len(sequence) < max_length:
        sequence.extend([0] * (max_length - len(sequence)))
    else:
        sequence = sequence[:max_length]
    
    return sequence

# Convert text to sequences
sequences = [text_to_sequence(note) for note in df['Patient_Notes']]
X_text = np.array(sequences)

# Encode categorical features
le_treatment = LabelEncoder()
le_surgery = LabelEncoder()

X_days = df['Days_Admitted'].values.reshape(-1, 1)
X_treatment = le_treatment.fit_transform(df['Treatment_Type']).reshape(-1, 1)
X_surgery = le_surgery.fit_transform(df['Surgery_Done']).reshape(-1, 1)

# Target variable
y = df['Pain_Level'].values

print(f"Text sequences shape: {X_text.shape}")
print(f"Sample sequence: {X_text[0]}")

# 3. RNN MODEL DEFINITION
print("\n3. Defining RNN Model...")

class PainLevelRNN(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim, num_features=3):
        super(PainLevelRNN, self).__init__()
        
        # Text processing layers
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.rnn = nn.RNN(embedding_dim, hidden_dim, batch_first=True)
        self.dropout = nn.Dropout(0.3)
        
        # Combine text features with numerical features
        self.fc1 = nn.Linear(hidden_dim + num_features, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)
        self.relu = nn.ReLU()
        
    def forward(self, text_seq, numerical_features):
        # Process text sequence
        embedded = self.embedding(text_seq)
        rnn_out, hidden = self.rnn(embedded)
        
        # Use last hidden state
        text_features = rnn_out[:, -1, :]
        text_features = self.dropout(text_features)
        
        # Combine with numerical features
        combined = torch.cat([text_features, numerical_features], dim=1)
        
        # Pass through fully connected layers
        x = self.relu(self.fc1(combined))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)
        
        return x

# Model parameters
VOCAB_SIZE = len(word_to_idx)
EMBEDDING_DIM = 16
HIDDEN_DIM = 32
LEARNING_RATE = 0.001
EPOCHS = 100

# Initialize model
model = PainLevelRNN(VOCAB_SIZE, EMBEDDING_DIM, HIDDEN_DIM)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

print(f"Model initialized with {sum(p.numel() for p in model.parameters())} parameters")

# 4. PREPARE DATA FOR TRAINING
print("\n4. Preparing Training Data...")

# Combine numerical features
X_numerical = np.concatenate([X_days, X_treatment, X_surgery], axis=1)

# Split data
X_text_train, X_text_test, X_num_train, X_num_test, y_train, y_test = train_test_split(
    X_text, X_numerical, y, test_size=0.2, random_state=42
)

# Convert to tensors
X_text_train = torch.LongTensor(X_text_train)
X_text_test = torch.LongTensor(X_text_test)
X_num_train = torch.FloatTensor(X_num_train)
X_num_test = torch.FloatTensor(X_num_test)
y_train = torch.FloatTensor(y_train).view(-1, 1)
y_test = torch.FloatTensor(y_test).view(-1, 1)

print(f"Training samples: {len(X_text_train)}")
print(f"Test samples: {len(X_text_test)}")

# 5. MODEL TRAINING
print("\n5. Training RNN Model...")

train_losses = []
model.train()

for epoch in range(EPOCHS):
    optimizer.zero_grad()
    
    # Forward pass
    outputs = model(X_text_train, X_num_train)
    loss = criterion(outputs, y_train)
    
    # Backward pass
    loss.backward()
    optimizer.step()
    
    train_losses.append(loss.item())
    
    if (epoch + 1) % 20 == 0:
        print(f'Epoch [{epoch+1}/{EPOCHS}], Loss: {loss.item():.4f}')

# 6. MODEL EVALUATION
print("\n6. Evaluating Model...")

model.eval()
with torch.no_grad():
    # Training predictions
    train_pred = model(X_text_train, X_num_train)
    train_mse = mean_squared_error(y_train.numpy(), train_pred.numpy())
    train_mae = mean_absolute_error(y_train.numpy(), train_pred.numpy())
    
    # Test predictions
    test_pred = model(X_text_test, X_num_test)
    test_mse = mean_squared_error(y_test.numpy(), test_pred.numpy())
    test_mae = mean_absolute_error(y_test.numpy(), test_pred.numpy())

print(f"\nTraining Results:")
print(f"MSE: {train_mse:.4f}, MAE: {train_mae:.4f}")

print(f"\nTest Results:")
print(f"MSE: {test_mse:.4f}, MAE: {test_mae:.4f}")

# 7. SAMPLE PREDICTIONS
print("\n7. Sample Predictions...")

sample_indices = np.random.choice(len(X_text_test), 3, replace=False)
for i in sample_indices:
    actual = y_test[i].item()
    predicted = test_pred[i].item()
    
    # Decode the text sequence
    text_seq = X_text_test[i].numpy()
    words = [idx_to_word.get(idx, '<UNK>') for idx in text_seq if idx != 0]
    original_text = ' '.join(words)
    
    print(f"\nSample {i+1}:")
    print(f"Text: '{original_text}'")
    print(f"Actual Pain Level: {actual:.1f}")
    print(f"Predicted Pain Level: {predicted:.1f}")
    print(f"Numerical features: {X_num_test[i].numpy()}")

# 8. VISUALIZATION
print("\n8. Creating Visualizations...")

# Plot training loss
plt.figure(figsize=(12, 4))

plt.subplot(1, 2, 1)
plt.plot(train_losses)
plt.title('RNN Training Loss')
plt.xlabel('Epoch')
plt.ylabel('MSE Loss')
plt.grid(True)

# Plot predictions vs actual
plt.subplot(1, 2, 2)
test_actual = y_test.numpy().flatten()
test_predicted = test_pred.numpy().flatten()

plt.scatter(test_actual, test_predicted, alpha=0.7)
plt.plot([0, 10], [0, 10], 'r--', label='Perfect Prediction')
plt.xlabel('Actual Pain Level')
plt.ylabel('Predicted Pain Level')
plt.title('RNN: Predicted vs Actual')
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.show()

# 9. FEATURE IMPORTANCE ANALYSIS
print("\n9. Model Analysis...")

def predict_new_sample(note, days, treatment, surgery):
    """Predict pain level for a new patient"""
    model.eval()
    with torch.no_grad():
        # Process text
        text_seq = torch.LongTensor([text_to_sequence(note)])
        
        # Process numerical features
        treatment_encoded = le_treatment.transform([treatment])[0]
        surgery_encoded = le_surgery.transform([surgery])[0]
        num_features = torch.FloatTensor([[days, treatment_encoded, surgery_encoded]])
        
        prediction = model(text_seq, num_features)
        return prediction.item()

# Test with new samples
print("\nTesting with new patient notes:")
test_cases = [
    ("I feel great today no pain", 5, "Physical Therapy", "No"),
    ("Horrible pain cannot sleep", 2, "Emergency", "Yes"),
    ("Getting better slowly", 7, "Medication", "No")
]

for note, days, treatment, surgery in test_cases:
    pred = predict_new_sample(note, days, treatment, surgery)
    print(f"Note: '{note}' -> Predicted Pain Level: {pred:.1f}")

print(f"\n{'='*50}")
print("RNN Model Training Complete!")
print("The model has learned to predict pain levels from patient notes")
print("and clinical features using Recurrent Neural Networks.")
print(f"{'='*50}")