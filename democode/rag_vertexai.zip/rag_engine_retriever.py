"""
Vertex AI RAG Engine - Retriever
Query and retrieve from RAG corpus using Vertex AI RAG Engine
"""

from turtle import pd
from anyio import Path
from vertexai.preview import rag
from vertexai.preview.generative_models import GenerativeModel, Tool
import vertexai
import os
from config import (
    PROJECT_ID, LOCATION,
    GENERATION_MODEL, TEMPERATURE, MAX_OUTPUT_TOKENS
)


class RAGEngineRetriever:
    """Retriever for Vertex AI RAG Engine"""
    
    def __init__(self, corpus_name=None):
        self.project_id = PROJECT_ID
        self.location = LOCATION
        
        # Initialize Vertex AI
        vertexai.init(project=PROJECT_ID, location=LOCATION)
        
        # Get corpus name
        self.corpus_name = corpus_name or self._load_corpus_name()
        
        if not self.corpus_name:
            raise ValueError(
                "Corpus name not provided and not found in rag_corpus_name.txt. "
                "Please run the indexer first or provide corpus name."
            )
        
        print(f"Using RAG corpus: {self.corpus_name}")
        
        # Initialize model with RAG tool
        self._setup_rag_tool()
    
    def _load_corpus_name(self):
        """Load corpus name from file"""
        try:
            from pathlib import Path
            print(Path(__file__).resolve().parent)
            if os.path.exists(Path(__file__).resolve().parent / "rag_corpus_name.txt"):
                with open(Path(__file__).resolve().parent / "rag_corpus_name.txt", "r") as f:
                    return f.read().strip()
        except Exception as e:
            print(f"Warning: Could not load corpus name: {e}")
        return None
    
    def _setup_rag_tool(self):
        """Setup RAG tool for the model"""
        try:
            # Create RAG retrieval tool
            self.rag_tool = Tool.from_retrieval(
                retrieval=rag.Retrieval(
                    source=rag.VertexRagStore(
                        rag_resources=[
                            rag.RagResource(
                                rag_corpus=self.corpus_name,
                            )
                        ],
                        similarity_top_k=10,  # Number of similar chunks to retrieve
                        vector_distance_threshold=0.5,  # Similarity threshold
                    ),
                )
            )
            
            # Initialize model with RAG tool
            self.model = GenerativeModel(
                model_name=GENERATION_MODEL,
                tools=[self.rag_tool],
            )
            
            print("[OK] RAG tool configured successfully")
            
        except Exception as e:
            print(f"[ERROR] Error setting up RAG tool: {e}")
            raise
    
    def retrieve_relevant_chunks(self, query, top_k=5):
        """
        Retrieve relevant chunks from the RAG corpus
        """
        print(f"\nRetrieving relevant chunks for: '{query}'")
        print("-" * 60)

        try:
            # Use RAG retrieval to get relevant chunks
            retrieval_results = rag.retrieval_query(
                rag_resources=[
                    rag.RagResource(rag_corpus=self.corpus_name)
                ],
                text=query,
                similarity_top_k=top_k,
            )

            # Process results
            chunks = []

            # Check if results exist
            if hasattr(retrieval_results, 'contexts') and retrieval_results.contexts:
                if hasattr(retrieval_results.contexts, 'contexts'):
                    # Iterate through contexts
                    for i, context in enumerate(retrieval_results.contexts.contexts, 1):
                        chunk_info = {
                            "rank": i,
                            "text": context.text,
                            "distance": context.distance if hasattr(context, 'distance') else None,
                            "source": context.source_uri if hasattr(context, 'source_uri') else "Unknown",
                        }
                        chunks.append(chunk_info)

            if chunks:
                print(f"[OK] Retrieved {len(chunks)} chunk(s)")
            else:
                print("[INFO] No chunks retrieved via direct API (model RAG tool will handle retrieval)")

            return chunks

        except Exception as e:
            print(f"[INFO] Direct retrieval not available: {e}")
            print("[INFO] Model will use RAG tool for automatic retrieval")
            import traceback
            print(f"Debug: {traceback.format_exc()}")
            return []
    
    def display_chunks(self, chunks):
        """Display retrieved chunks"""
        if not chunks:
            # Don't print misleading message - the model's RAG tool handles retrieval
            return

        print(f"\nFound {len(chunks)} relevant chunk(s):\n")

        for chunk in chunks:
            distance_str = f"{chunk.get('distance', 'N/A'):.3f}" if chunk.get('distance') is not None else 'N/A'
            print(f"{chunk['rank']}. [Distance: {distance_str}]")
            print(f"   Source: {chunk['source']}")
            print(f"   Content: {chunk['text'][:300]}...")
            print()
    
    def answer_with_rag(self, query):
        """
        Answer query using RAG Engine
        The model will automatically retrieve and use relevant context
        """
        print("\n" + "="*60)
        print(f"Query: {query}")
        print("="*60)
        
        try:
            # First, show what chunks are retrieved
            print("\n[Retrieving relevant context...]")
            chunks = self.retrieve_relevant_chunks(query, top_k=5)
            self.display_chunks(chunks)
            
            # Generate answer using model with RAG tool
            print("\n" + "="*60)
            print("Generated Answer:")
            print("="*60)
            
            # The model will automatically use the RAG tool to retrieve context
            response = self.model.generate_content(
                query,
                generation_config={
                    "temperature": TEMPERATURE,
                    "max_output_tokens": MAX_OUTPUT_TOKENS,
                }
            )
            
            answer = response.text
            print(answer)
            
            # Show grounding metadata if available
            if hasattr(response, 'candidates') and response.candidates:
                candidate = response.candidates[0]
                if hasattr(candidate, 'grounding_metadata'):
                    print("\n" + "-"*60)
                    print("Grounding Information:")
                    print("-"*60)
                    metadata = candidate.grounding_metadata
                    if hasattr(metadata, 'retrieval_queries'):
                        print(f"Retrieval queries used: {metadata.retrieval_queries}")
                    if hasattr(metadata, 'grounding_chunks'):
                        print(f"Number of grounding chunks: {len(metadata.grounding_chunks)}")
            
            return answer
            
        except Exception as e:
            print(f"[ERROR] Error generating answer: {e}")
            return "Error generating answer."
    
    def answer_with_custom_prompt(self, query, context_instruction=None):
        """
        Answer query with custom prompting
        Useful for more control over the response format
        """
        print("\n" + "="*60)
        print(f"Query: {query}")
        print("="*60)
        
        try:
            # Retrieve context
            chunks = self.retrieve_relevant_chunks(query, top_k=10)
            
            if not chunks:
                return "I couldn't find relevant information to answer your question."
            
            # Build context
            context_parts = []
            for chunk in chunks[:5]:  # Use top 5 chunks
                context_parts.append(f"[Source: {chunk['source']}]")
                context_parts.append(chunk['text'])
                context_parts.append("")
            
            context = "\n".join(context_parts)
            
            # Build prompt
            system_instruction = context_instruction or """
            You are a helpful assistant for DBS Bank. Answer questions based on the provided context.
            If the context doesn't contain enough information, say so.
            """
            
            prompt = f"""{system_instruction}

Context from documents:
{context}

User Question: {query}

Please provide a clear and helpful answer based on the context above."""
            
            # Generate answer
            print("\n" + "="*60)
            print("Generated Answer:")
            print("="*60)
            
            model_without_tool = GenerativeModel(GENERATION_MODEL)
            response = model_without_tool.generate_content(
                prompt,
                generation_config={
                    "temperature": TEMPERATURE,
                    "max_output_tokens": MAX_OUTPUT_TOKENS,
                }
            )
            
            answer = response.text
            print(answer)
            
            return answer
            
        except Exception as e:
            print(f"[ERROR] Error: {e}")
            return "Error generating answer."
    
    def interactive_qa(self):
        """Interactive Q&A session"""
        print("\n" + "="*80)
        print("VERTEX AI RAG ENGINE - INTERACTIVE Q&A")
        print("="*80)
        print(f"\nCorpus: {self.corpus_name}")
        print("\nAsk questions about:")
        print("  • Employee skills and experience (e.g., 'recommend a Java developer')")
        print("  • Financial reports (e.g., 'what was the net profit in Q4 2024?')")
        print("  • Electricity bills (e.g., 'how much was the electricity bill in Jan 2025?')")
        print("\nType 'quit' to exit")
        print("="*80)
        
        while True:
            try:
                query = input("\n>> Your question: ").strip()
                
                if query.lower() in ['quit', 'exit', 'q']:
                    print("\nGoodbye!")
                    break
                
                if not query:
                    continue
                
                # Answer with RAG
                self.answer_with_rag(query)
                
            except KeyboardInterrupt:
                print("\n\nGoodbye!")
                break
            except Exception as e:
                print(f"[ERROR] Error: {e}")
    
    def run_demo_queries(self):
        """Run predefined demo queries"""
        print("\n" + "="*80)
        print("VERTEX AI RAG ENGINE - DEMO QUERIES")
        print("="*80)
        
        demo_queries = [
            "recommend a Java developer with experience in Spring Boot",
            "what was the net profit in Q4 2024?",
            "how much was the electricity bill in January 2025?",
            "who has machine learning experience?",
            "what were DBS Bank's total assets in Q3 2024?",
            "compare the electricity consumption between November and December 2024",
        ]
        
        for query in demo_queries:
            self.answer_with_rag(query)
            input("\nPress Enter to continue to next query...")
        
        print("\n" + "="*80)
        print("Demo complete!")
        print("="*80)
    
    def list_corpus_info(self):
        """Display corpus information"""
        print("\n" + "="*60)
        print("RAG Corpus Information")
        print("="*60)
        
        try:
            files = list(rag.list_files(corpus_name=self.corpus_name))
            print(f"\nCorpus Name: {self.corpus_name}")
            print(f"Total Files: {len(files)}")
            
            print("\nFiles in corpus:")
            for i, file in enumerate(files, 1):
                print(f"  {i}. {file.display_name}")
            
        except Exception as e:
            print(f"[ERROR] Error: {e}")


def main():
    """Main function"""
    import sys
    
    # Check for corpus name argument
    corpus_name = None
    if len(sys.argv) > 1 and sys.argv[1].startswith("projects/"):
        corpus_name = sys.argv[1]
        sys.argv.pop(1)
    
    try:
        retriever = RAGEngineRetriever(corpus_name=corpus_name)
        
        if len(sys.argv) > 1:
            if sys.argv[1] == "demo":
                # Run demo queries
                retriever.run_demo_queries()
            elif sys.argv[1] == "info":
                # Show corpus info
                retriever.list_corpus_info()
            else:
                # Single query from command line
                query = " ".join(sys.argv[1:])
                retriever.answer_with_rag(query)
        else:
            # Interactive mode
            retriever.interactive_qa()
            
    except Exception as e:
        print(f"\n[ERROR] Error: {e}")
        print("\nMake sure you have:")
        print("1. Run the indexer first: python rag_engine_indexer.py")
        print("2. Or provide corpus name: python rag_engine_retriever.py <corpus_name>")


if __name__ == "__main__":
    main()
