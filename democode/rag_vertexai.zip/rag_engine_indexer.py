"""
Vertex AI RAG Engine - Indexer
Creates RAG corpus and imports documents
"""

from vertexai.preview import rag
from vertexai.preview.generative_models import Tool
from google.cloud import storage
import vertexai
import time
from config import (
    PROJECT_ID, LOCATION, BUCKET_NAME,
    RAG_CORPUS_DISPLAY_NAME, RAG_CORPUS_DESCRIPTION,
    EMBEDDING_MODEL
)


class RAGEngineIndexer:
    """Indexer for Vertex AI RAG Engine"""
    
    def __init__(self):
        self.project_id = PROJECT_ID
        self.location = LOCATION
        self.bucket_name = BUCKET_NAME
        
        # Initialize Vertex AI
        vertexai.init(project=PROJECT_ID, location=LOCATION)
        
        self.storage_client = storage.Client(project=PROJECT_ID)
        self.rag_corpus = None
    
    def create_rag_corpus(self):
        """Create a RAG corpus"""
        print("\n" + "="*60)
        print("Creating RAG Corpus")
        print("="*60)
        
        try:
            # Create RAG corpus
            self.rag_corpus = rag.create_corpus(
                display_name=RAG_CORPUS_DISPLAY_NAME,
                description=RAG_CORPUS_DESCRIPTION,
            )
            
            print(f"[OK] RAG Corpus created")
            print(f"  Name: {self.rag_corpus.name}")
            print(f"  Display Name: {RAG_CORPUS_DISPLAY_NAME}")
            
            return self.rag_corpus
            
        except Exception as e:
            print(f"[ERROR] Error creating RAG corpus: {e}")
            print(f"   Error type: {type(e).__name__}")
            import traceback
            print(f"   Traceback: {traceback.format_exc()}")

            # Try to list and use existing corpus
            try:
                print("\nChecking for existing corpus...")
                corpora = rag.list_corpora()
                for corpus in corpora:
                    if corpus.display_name == RAG_CORPUS_DISPLAY_NAME:
                        print(f"[OK] Using existing corpus: {corpus.name}")
                        self.rag_corpus = corpus
                        return corpus

                print(f"\n[ERROR] No existing corpus found with display name: {RAG_CORPUS_DISPLAY_NAME}")
                raise Exception(f"No existing corpus found and failed to create new one. Original error: {e}")

            except Exception as e2:
                print(f"[ERROR] Error checking existing corpora: {e2}")
                print(f"   Original corpus creation error: {e}")
                raise
    
    def import_files_from_gcs(self, corpus_name):
        """Import files from GCS into RAG corpus"""
        print("\n" + "="*60)
        print("Importing Files from GCS")
        print("="*60)
        
        try:
            bucket = self.storage_client.bucket(self.bucket_name)
            
            # Collect all PDF files
            all_files = []
            
            # Get resumes
            print("\nCollecting resumes...")
            resume_blobs = list(bucket.list_blobs(prefix="resumes/"))
            for blob in resume_blobs:
                if blob.name.endswith('.pdf'):
                    all_files.append({
                        "gcs_uri": f"gs://{self.bucket_name}/{blob.name}",
                        "display_name": blob.name.split('/')[-1].replace('.pdf', '').replace('_', ' ').title(),
                        "description": f"Resume of {blob.name.split('/')[-1].replace('.pdf', '').replace('_', ' ').title()}"
                    })
                    print(f"  • {blob.name}")
            
            # Get financial reports
            print("\nCollecting financial reports...")
            financial_blobs = list(bucket.list_blobs(prefix="financial_reports/"))
            for blob in financial_blobs:
                if blob.name.endswith('.pdf'):
                    all_files.append({
                        "gcs_uri": f"gs://{self.bucket_name}/{blob.name}",
                        "display_name": blob.name.split('/')[-1].replace('.pdf', '').replace('_', ' '),
                        "description": "DBS Bank quarterly earnings report"
                    })
                    print(f"  • {blob.name}")
            
            # Get electricity bills
            print("\nCollecting electricity bills...")
            bill_blobs = list(bucket.list_blobs(prefix="electricity_bills/"))
            for blob in bill_blobs:
                if blob.name.endswith('.pdf'):
                    all_files.append({
                        "gcs_uri": f"gs://{self.bucket_name}/{blob.name}",
                        "display_name": blob.name.split('/')[-1].replace('.pdf', '').replace('_', ' '),
                        "description": "Office electricity bill"
                    })
                    print(f"  • {blob.name}")
            
            print(f"\nTotal files to import: {len(all_files)}")
            
            # Import files in batches (RAG Engine has limits on batch size)
            batch_size = 10
            imported_count = 0
            
            for i in range(0, len(all_files), batch_size):
                batch = all_files[i:i + batch_size]
                print(f"\nImporting batch {i//batch_size + 1} ({len(batch)} files)...")
                
                try:
                    # Import files one by one for better error handling
                    for file_info in batch:
                        try:
                            gcs_uri = file_info["gcs_uri"]
                            print(f"  Importing: {gcs_uri}")

                            # Import single file
                            response = rag.import_files(
                                corpus_name=corpus_name,
                                paths=[gcs_uri],
                                chunk_size=512,  # Chunk size in tokens
                                chunk_overlap=100,  # Overlap between chunks
                                
                            )

                            imported_count += 1
                            print(f"    [OK] Imported successfully")
                            time.sleep(1)  # Rate limiting

                        except Exception as file_error:
                            print(f"    [ERROR] Failed to import: {file_error}")
                            import traceback
                            print(f"    {traceback.format_exc()}")

                    # Brief pause between batches
                    if i + batch_size < len(all_files):
                        time.sleep(2)

                except Exception as e:
                    print(f"  [ERROR] Error in batch processing: {e}")
                    print(f"  Continuing with next batch...")
            
            print(f"\n[OK] Import complete!")
            print(f"  Total files imported: {imported_count}/{len(all_files)}")
            
            return imported_count
            
        except Exception as e:
            print(f"[ERROR] Error importing files: {e}")
            raise
    
    def upload_files_individually(self, corpus_name):
        """
        Alternative method: Upload files one by one with more control
        Better for handling metadata and error recovery
        """
        print("\n" + "="*60)
        print("Uploading Files Individually")
        print("="*60)
        
        try:
            bucket = self.storage_client.bucket(self.bucket_name)
            uploaded_count = 0
            failed_count = 0
            
            # Process resumes
            print("\nProcessing resumes...")
            resume_blobs = list(bucket.list_blobs(prefix="resumes/"))
            for blob in resume_blobs:
                if blob.name.endswith('.pdf'):
                    try:
                        gcs_uri = f"gs://{self.bucket_name}/{blob.name}"
                        display_name = blob.name.split('/')[-1].replace('.pdf', '').replace('_', ' ').title()
                        
                        # Upload file
                        rag.upload_file(
                            corpus_name=corpus_name,
                            path=gcs_uri,
                            display_name=display_name,
                            description=f"Resume of {display_name}",
                        )
                        
                        print(f"  [OK] {display_name}")
                        uploaded_count += 1
                        time.sleep(1)  # Rate limiting
                        
                    except Exception as e:
                        print(f"  [ERROR] Error uploading {blob.name}: {e}")
                        failed_count += 1
            
            # Process financial reports
            print("\nProcessing financial reports...")
            financial_blobs = list(bucket.list_blobs(prefix="financial_reports/"))
            for blob in financial_blobs:
                if blob.name.endswith('.pdf'):
                    try:
                        gcs_uri = f"gs://{self.bucket_name}/{blob.name}"
                        display_name = blob.name.split('/')[-1].replace('.pdf', '').replace('_', ' ')
                        
                        rag.upload_file(
                            corpus_name=corpus_name,
                            path=gcs_uri,
                            display_name=display_name,
                            description="DBS Bank quarterly earnings report",
                        )
                        
                        print(f"  [OK] {display_name}")
                        uploaded_count += 1
                        time.sleep(1)
                        
                    except Exception as e:
                        print(f"  [ERROR] Error uploading {blob.name}: {e}")
                        failed_count += 1
            
            # Process electricity bills
            print("\nProcessing electricity bills...")
            bill_blobs = list(bucket.list_blobs(prefix="electricity_bills/"))
            for blob in bill_blobs:
                if blob.name.endswith('.pdf'):
                    try:
                        gcs_uri = f"gs://{self.bucket_name}/{blob.name}"
                        display_name = blob.name.split('/')[-1].replace('.pdf', '').replace('_', ' ')
                        
                        rag.upload_file(
                            corpus_name=corpus_name,
                            path=gcs_uri,
                            display_name=display_name,
                            description="Office electricity bill",
                        )
                        
                        print(f"  [OK] {display_name}")
                        uploaded_count += 1
                        time.sleep(1)
                        
                    except Exception as e:
                        print(f"  [ERROR] Error uploading {blob.name}: {e}")
                        failed_count += 1
            
            print(f"\n[OK] Upload complete!")
            print(f"  Successful: {uploaded_count}")
            print(f"  Failed: {failed_count}")
            
            return uploaded_count
            
        except Exception as e:
            print(f"[ERROR] Error uploading files: {e}")
            raise
    
    def list_corpus_files(self, corpus_name):
        """List all files in the corpus"""
        print("\n" + "="*60)
        print("Corpus Files")
        print("="*60)
        
        try:
            files = rag.list_files(corpus_name=corpus_name)
            
            file_list = list(files)
            print(f"\nTotal files in corpus: {len(file_list)}")
            
            for i, file in enumerate(file_list, 1):
                print(f"\n{i}. {file.display_name}")
                print(f"   Name: {file.name}")
                if hasattr(file, 'description') and file.description:
                    print(f"   Description: {file.description}")
            
            return file_list
            
        except Exception as e:
            print(f"[ERROR] Error listing files: {e}")
            return []
    
    def run_indexing(self, use_batch_import=True):
        """Run the complete indexing process"""
        print("\n" + "="*80)
        print("VERTEX AI RAG ENGINE - INDEXER")
        print("="*80)
        
        try:
            # Step 1: Create RAG corpus
            corpus = self.create_rag_corpus()
            
            if not corpus:
                raise Exception("Failed to create or retrieve RAG corpus")
            
            corpus_name = corpus.name
            print(f"\nUsing corpus: {corpus_name}")
            
            # Step 2: Import files
            if use_batch_import:
                # Batch import (faster)
                self.import_files_from_gcs(corpus_name)
            else:
                # Individual upload (more control)
                self.upload_files_individually(corpus_name)
            
            # Step 3: List files to verify
            time.sleep(5)  # Wait for indexing to start
            self.list_corpus_files(corpus_name)
            
            print("\n" + "="*80)
            print("INDEXING COMPLETE!")
            print("="*80)
            print("\nNext steps:")
            print("1. Wait 5-10 minutes for full indexing and embedding generation")
            print("2. Run the retriever: python rag_engine_retriever.py")
            print(f"\nCorpus Name: {corpus_name}")
            print("\nNote: Save this corpus name for the retriever!")
            
            # Save corpus name to file for retriever
            with open("rag_corpus_name.txt", "w") as f:
                f.write(corpus_name)
            print("\n[OK] Corpus name saved to: rag_corpus_name.txt")
            
        except Exception as e:
            print(f"\n[ERROR] Indexing failed: {e}")
            raise


if __name__ == "__main__":
    indexer = RAGEngineIndexer()

    # Use batch import for faster processing
    # Set to False for individual file upload with more control
    indexer.run_indexing(use_batch_import=True)
