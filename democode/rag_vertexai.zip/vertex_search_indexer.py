"""
Vertex AI Search (Discovery Engine) - Indexer
Creates and populates a Vertex AI Search datastore with documents
"""

from google.cloud import discoveryengine_v1 as discoveryengine
from google.cloud import storage
from google.api_core.client_options import ClientOptions
import time
from config import (
    PROJECT_ID, LOCATION, BUCKET_NAME,
    VERTEX_SEARCH_DATASTORE_ID, VERTEX_SEARCH_ENGINE_ID,
    VERTEX_SEARCH_DATASTORE_DISPLAY_NAME
)


class VertexAISearchIndexer:
    """Indexer for Vertex AI Search (Discovery Engine)"""
    
    def __init__(self):
        self.project_id = PROJECT_ID
        self.location = LOCATION
        self.bucket_name = BUCKET_NAME
        
        # Initialize clients
        # Note: Discovery Engine is only available in specific global regions
        # Use 'global' location for Discovery Engine regardless of LOCATION config
        discovery_location = "global"
        self.client_options = ClientOptions(
            api_endpoint=f"{discovery_location}-discoveryengine.googleapis.com",
            quota_project_id=PROJECT_ID  # Set quota project explicitly
        )
        self.datastore_client = discoveryengine.DataStoreServiceClient(
            client_options=self.client_options
        )
        self.document_client = discoveryengine.DocumentServiceClient(
            client_options=self.client_options
        )
        self.engine_client = discoveryengine.EngineServiceClient(
            client_options=self.client_options
        )
        
        self.storage_client = storage.Client(project=PROJECT_ID)
    
    def create_datastore(self):
        """Create a Vertex AI Search datastore"""
        # Discovery Engine uses 'global' location for resource paths
        parent = f"projects/{self.project_id}/locations/global/collections/default_collection"

        print("\n" + "="*60)
        print("Creating Vertex AI Search Datastore")
        print("="*60)

        try:
            # Check if datastore already exists
            datastore_path = f"{parent}/dataStores/{VERTEX_SEARCH_DATASTORE_ID}"
            try:
                existing = self.datastore_client.get_data_store(name=datastore_path)
                print(f"[OK] Datastore already exists: {existing.name}")
                return existing
            except Exception:
                pass  # Datastore doesn't exist, create it

            # Create datastore
            datastore = discoveryengine.DataStore(
                display_name=VERTEX_SEARCH_DATASTORE_DISPLAY_NAME,
                industry_vertical=discoveryengine.IndustryVertical.GENERIC,
                content_config=discoveryengine.DataStore.ContentConfig.CONTENT_REQUIRED,
                solution_types=[discoveryengine.SolutionType.SOLUTION_TYPE_SEARCH],
            )

            request = discoveryengine.CreateDataStoreRequest(
                parent=parent,
                data_store=datastore,
                data_store_id=VERTEX_SEARCH_DATASTORE_ID,
            )

            operation = self.datastore_client.create_data_store(request=request)
            print(f"Creating datastore (async operation)...")
            print(f"Operation name: {operation.operation.name}")
            print(f"This is a long-running operation. Waiting for completion (timeout: 600s)...")

            response = operation.result(timeout=600)
            print(f"[OK] Datastore created: {response.name}")
            return response

        except Exception as e:
            print(f"[ERROR] Error creating datastore: {e}")
            raise
    
    def create_search_engine(self):
        """Create a search engine linked to the datastore"""
        # Discovery Engine uses 'global' location for resource paths
        parent = f"projects/{self.project_id}/locations/global/collections/default_collection"

        print("\n" + "="*60)
        print("Creating Search Engine")
        print("="*60)

        try:
            # Check if engine already exists
            engine_path = f"{parent}/engines/{VERTEX_SEARCH_ENGINE_ID}"
            try:
                existing = self.engine_client.get_engine(name=engine_path)
                print(f"[OK] Search engine already exists: {existing.name}")
                return existing
            except Exception:
                pass  # Engine doesn't exist, create it

            # Create search engine
            engine = discoveryengine.Engine(
                display_name="DBS Bank Search Engine",
                solution_type=discoveryengine.SolutionType.SOLUTION_TYPE_SEARCH,
                search_engine_config=discoveryengine.Engine.SearchEngineConfig(
                    search_tier=discoveryengine.SearchTier.SEARCH_TIER_ENTERPRISE,
                    search_add_ons=[
                        discoveryengine.SearchAddOn.SEARCH_ADD_ON_LLM
                    ],
                ),
                data_store_ids=[VERTEX_SEARCH_DATASTORE_ID],
            )

            request = discoveryengine.CreateEngineRequest(
                parent=parent,
                engine=engine,
                engine_id=VERTEX_SEARCH_ENGINE_ID,
            )

            operation = self.engine_client.create_engine(request=request)
            print(f"Creating search engine (async operation)...")
            print(f"Operation name: {operation.operation.name}")
            print(f"This is a long-running operation. Waiting for completion (timeout: 600s)...")

            response = operation.result(timeout=600)
            print(f"[OK] Search engine created: {response.name}")
            return response

        except Exception as e:
            print(f"[ERROR] Error creating search engine: {e}")
            raise
    
    def import_documents_from_gcs(self):
        """Import documents from GCS to the datastore"""
        # Discovery Engine uses 'global' location for resource paths
        parent = f"projects/{self.project_id}/locations/global/collections/default_collection/dataStores/{VERTEX_SEARCH_DATASTORE_ID}/branches/default_branch"
        
        print("\n" + "="*60)
        print("Importing Documents from GCS")
        print("="*60)
        
        try:
            # Configure import - using GCS URIs with metadata
            gcs_source = discoveryengine.GcsSource(
                input_uris=[
                    f"gs://{BUCKET_NAME}/resumes/*.pdf",
                    f"gs://{BUCKET_NAME}/financial_reports/*.pdf",
                    f"gs://{BUCKET_NAME}/electricity_bills/*.pdf",
                ],
                data_schema="content",  # Use content schema for PDF parsing
            )
            
            import_config = discoveryengine.ImportDocumentsRequest(
                parent=parent,
                gcs_source=gcs_source,
                reconciliation_mode=discoveryengine.ImportDocumentsRequest.ReconciliationMode.INCREMENTAL,
            )
            
            operation = self.document_client.import_documents(request=import_config)
            print("Importing documents... (this may take several minutes)")
            
            # Wait for operation to complete
            response = operation.result(timeout=600)
            
            print(f"✓ Documents imported successfully")
            print(f"  Success count: {response.success_count}")
            print(f"  Failure count: {response.failure_count}")
            
            return response
            
        except Exception as e:
            print(f"✗ Error importing documents: {e}")
            raise
    
    def create_documents_with_metadata(self):
        """
        Alternative method: Create documents individually with custom metadata
        This provides more control over metadata extraction
        """
        # Discovery Engine uses 'global' location for resource paths
        parent = f"projects/{self.project_id}/locations/global/collections/default_collection/dataStores/{VERTEX_SEARCH_DATASTORE_ID}/branches/default_branch"
        
        print("\n" + "="*60)
        print("Creating Documents with Custom Metadata")
        print("="*60)
        
        bucket = self.storage_client.bucket(BUCKET_NAME)
        document_count = 0
        
        # Process resumes
        print("\nProcessing resumes...")
        blobs = bucket.list_blobs(prefix="resumes/")
        for blob in blobs:
            if blob.name.endswith('.pdf'):
                # Extract employee name from filename
                filename = blob.name.split('/')[-1].replace('.pdf', '')
                employee_name = filename.replace('_', ' ').title()
                
                doc_id = f"resume-{filename}"
                
                # Create document with metadata
                document = discoveryengine.Document(
                    id=doc_id,
                    struct_data={
                        "title": f"Resume - {employee_name}",
                        "employee_name": employee_name,
                        "document_type": "resume",
                        "uri": f"gs://{BUCKET_NAME}/{blob.name}",
                    },
                    content=discoveryengine.Document.Content(
                        mime_type="application/pdf",
                        uri=f"gs://{BUCKET_NAME}/{blob.name}",
                    ),
                )
                
                request = discoveryengine.CreateDocumentRequest(
                    parent=parent,
                    document=document,
                    document_id=doc_id,
                )
                
                try:
                    self.document_client.create_document(request=request)
                    print(f"  ✓ Created: {employee_name}")
                    document_count += 1
                except Exception as e:
                    print(f"  ✗ Error creating document for {employee_name}: {e}")
        
        # Process financial reports
        print("\nProcessing financial reports...")
        blobs = bucket.list_blobs(prefix="financial_reports/")
        for blob in blobs:
            if blob.name.endswith('.pdf'):
                filename = blob.name.split('/')[-1].replace('.pdf', '')
                
                doc_id = f"financial-{filename.lower().replace(' ', '-')}"
                
                document = discoveryengine.Document(
                    id=doc_id,
                    struct_data={
                        "title": filename.replace('_', ' '),
                        "document_type": "financial_report",
                        "uri": f"gs://{BUCKET_NAME}/{blob.name}",
                    },
                    content=discoveryengine.Document.Content(
                        mime_type="application/pdf",
                        uri=f"gs://{BUCKET_NAME}/{blob.name}",
                    ),
                )
                
                request = discoveryengine.CreateDocumentRequest(
                    parent=parent,
                    document=document,
                    document_id=doc_id,
                )
                
                try:
                    self.document_client.create_document(request=request)
                    print(f"  ✓ Created: {filename}")
                    document_count += 1
                except Exception as e:
                    print(f"  ✗ Error creating document: {e}")
        
        # Process electricity bills
        print("\nProcessing electricity bills...")
        blobs = bucket.list_blobs(prefix="electricity_bills/")
        for blob in blobs:
            if blob.name.endswith('.pdf'):
                filename = blob.name.split('/')[-1].replace('.pdf', '')
                
                doc_id = f"bill-{filename.lower().replace(' ', '-')}"
                
                document = discoveryengine.Document(
                    id=doc_id,
                    struct_data={
                        "title": filename.replace('_', ' '),
                        "document_type": "electricity_bill",
                        "uri": f"gs://{BUCKET_NAME}/{blob.name}",
                    },
                    content=discoveryengine.Document.Content(
                        mime_type="application/pdf",
                        uri=f"gs://{BUCKET_NAME}/{blob.name}",
                    ),
                )
                
                request = discoveryengine.CreateDocumentRequest(
                    parent=parent,
                    document=document,
                    document_id=doc_id,
                )
                
                try:
                    self.document_client.create_document(request=request)
                    print(f"  ✓ Created: {filename}")
                    document_count += 1
                except Exception as e:
                    print(f"  ✗ Error creating document: {e}")
        
        print(f"\n✓ Total documents created: {document_count}")
    
    def run_indexing(self, use_custom_metadata=True):
        """Run the complete indexing process"""
        print("\n" + "="*80)
        print("VERTEX AI SEARCH (DISCOVERY ENGINE) - INDEXER")
        print("="*80)
        
        try:
            # Step 1: Create datastore
            self.create_datastore()
            
            # Step 2: Create search engine
            self.create_search_engine()
            
            # Step 3: Import documents
            if use_custom_metadata:
                # Use custom metadata approach for better control
                self.create_documents_with_metadata()
            else:
                # Use bulk import (faster but less control over metadata)
                self.import_documents_from_gcs()
            
            print("\n" + "="*80)
            print("INDEXING COMPLETE!")
            print("="*80)
            print("\nNext steps:")
            print("1. Wait 5-10 minutes for documents to be fully processed")
            print("2. Run the retriever: python vertex_search_retriever.py")
            print(f"\nDatastore ID: {VERTEX_SEARCH_DATASTORE_ID}")
            print(f"Engine ID: {VERTEX_SEARCH_ENGINE_ID}")
            
        except Exception as e:
            print(f"\n✗ Indexing failed: {e}")
            raise


if __name__ == "__main__":
    indexer = VertexAISearchIndexer()
    
    # Use custom metadata approach for better control over employee names and document types
    indexer.run_indexing(use_custom_metadata=True)
