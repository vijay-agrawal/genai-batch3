"""
Data Generator for DBS Bank RAG Demo
Generates sample PDFs: resumes, financial reports, and electricity bills
"""

import os
from datetime import datetime
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
import random

from config import SAMPLE_EMPLOYEES, SAMPLE_SKILLS, FINANCIAL_QUARTERS, ELECTRICITY_MONTHS


class SampleDataGenerator:
    """Generate sample PDF documents for the demo"""
    
    def __init__(self, output_dir="sample_data"):
        self.output_dir = output_dir
        self.styles = getSampleStyleSheet()
        self._create_directories()
    
    def _create_directories(self):
        """Create output directories"""
        os.makedirs(f"{self.output_dir}/resumes", exist_ok=True)
        os.makedirs(f"{self.output_dir}/financial_reports", exist_ok=True)
        os.makedirs(f"{self.output_dir}/electricity_bills", exist_ok=True)
    
    def generate_all(self):
        """Generate all sample data"""
        print("Generating sample resumes...")
        self.generate_resumes()
        print("Generating financial reports...")
        self.generate_financial_reports()
        print("Generating electricity bills...")
        self.generate_electricity_bills()
        print(f"\nAll sample data generated in '{self.output_dir}' directory")
    
    def generate_resumes(self):
        """Generate sample resume PDFs"""
        for employee in SAMPLE_EMPLOYEES:
            filepath = f"{self.output_dir}/resumes/{employee}.pdf"
            self._create_resume(employee, filepath)
            print(f"  Created: {filepath}")
    
    def _create_resume(self, employee_name, filepath):
        """Create a single resume PDF"""
        doc = SimpleDocTemplate(filepath, pagesize=letter)
        story = []
        
        # Format name
        name_parts = employee_name.split('_')
        formatted_name = ' '.join([part.capitalize() for part in name_parts])
        
        # Header
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1a73e8'),
            spaceAfter=6,
            alignment=TA_CENTER
        )
        story.append(Paragraph(formatted_name, title_style))
        
        contact_style = ParagraphStyle(
            'Contact',
            parent=self.styles['Normal'],
            fontSize=10,
            alignment=TA_CENTER
        )
        contact_info = f"{employee_name}@dbsbank.com | +65 9XXX XXXX | Singapore"
        story.append(Paragraph(contact_info, contact_style))
        story.append(Spacer(1, 0.3*inch))
        
        # Professional Summary
        story.append(Paragraph("<b>PROFESSIONAL SUMMARY</b>", self.styles['Heading2']))
        skills = SAMPLE_SKILLS.get(employee_name, ["General IT"])
        years_exp = random.randint(3, 12)
        
        if "Java" in skills:
            summary = f"Experienced software engineer with {years_exp} years specializing in Java development, "
            summary += "enterprise applications, and cloud technologies. Proven track record in delivering "
            summary += "scalable solutions for banking and financial services."
        elif "Python" in skills:
            summary = f"Data-focused professional with {years_exp} years in Python development, analytics, and "
            summary += "machine learning. Expert in building data pipelines and analytical solutions for financial institutions."
        else:
            summary = f"Technology professional with {years_exp} years of experience in software development "
            summary += "and system design. Strong background in modern development practices and agile methodologies."
        
        story.append(Paragraph(summary, self.styles['Normal']))
        story.append(Spacer(1, 0.2*inch))
        
        # Technical Skills
        story.append(Paragraph("<b>TECHNICAL SKILLS</b>", self.styles['Heading2']))
        skills_text = " • ".join(skills)
        story.append(Paragraph(skills_text, self.styles['Normal']))
        story.append(Spacer(1, 0.2*inch))
        
        # Experience
        story.append(Paragraph("<b>PROFESSIONAL EXPERIENCE</b>", self.styles['Heading2']))
        
        # Current role at DBS
        story.append(Paragraph("<b>DBS Bank</b> - Senior Software Engineer", self.styles['Heading3']))
        story.append(Paragraph("<i>January 2020 - Present</i>", self.styles['Normal']))
        
        responsibilities = []
        if "Java" in skills:
            responsibilities = [
                "Developed and maintained core banking microservices using Java Spring Boot",
                "Implemented RESTful APIs for mobile and web banking applications",
                "Optimized database queries improving transaction processing by 40%",
                "Mentored junior developers and conducted code reviews"
            ]
        elif "Python" in skills:
            responsibilities = [
                "Built machine learning models for fraud detection and risk assessment",
                "Developed data pipelines processing millions of transactions daily",
                "Created automated reporting systems for compliance and analytics",
                "Collaborated with business stakeholders to define data requirements"
            ]
        else:
            responsibilities = [
                "Designed and implemented software solutions for banking operations",
                "Collaborated with cross-functional teams on product development",
                "Improved system performance and reliability through optimization",
                "Participated in agile development and continuous improvement initiatives"
            ]
        
        for resp in responsibilities:
            story.append(Paragraph(f"• {resp}", self.styles['Normal']))
        story.append(Spacer(1, 0.2*inch))
        
        # Previous experience
        prev_company = random.choice(["Standard Chartered", "OCBC Bank", "UOB", "Citibank Singapore"])
        story.append(Paragraph(f"<b>{prev_company}</b> - Software Engineer", self.styles['Heading3']))
        story.append(Paragraph("<i>2017 - 2019</i>", self.styles['Normal']))
        story.append(Paragraph("• Contributed to various banking software projects", self.styles['Normal']))
        story.append(Paragraph("• Gained experience in financial technology and regulations", self.styles['Normal']))
        story.append(Spacer(1, 0.2*inch))
        
        # Education
        story.append(Paragraph("<b>EDUCATION</b>", self.styles['Heading2']))
        university = random.choice([
            "National University of Singapore",
            "Nanyang Technological University",
            "Singapore Management University"
        ])
        degree = "Bachelor of Science in Computer Science" if "Java" in skills or "Python" in skills else "Bachelor of Computing"
        story.append(Paragraph(f"<b>{university}</b>", self.styles['Normal']))
        story.append(Paragraph(degree, self.styles['Normal']))
        
        doc.build(story)
    
    def generate_financial_reports(self):
        """Generate sample financial report PDFs"""
        for quarter in FINANCIAL_QUARTERS:
            filepath = f"{self.output_dir}/financial_reports/DBS_Bank_{quarter}_Earnings.pdf"
            self._create_financial_report(quarter, filepath)
            print(f"  Created: {filepath}")
    
    def _create_financial_report(self, quarter, filepath):
        """Create a single financial report PDF"""
        doc = SimpleDocTemplate(filepath, pagesize=A4)
        story = []
        
        # Title
        title_style = ParagraphStyle(
            'ReportTitle',
            parent=self.styles['Title'],
            fontSize=20,
            textColor=colors.HexColor('#d32f2f'),
            alignment=TA_CENTER
        )
        story.append(Paragraph("DBS BANK LTD", title_style))
        story.append(Paragraph(f"{quarter.replace('_', ' ')} Earnings Report", self.styles['Heading1']))
        story.append(Spacer(1, 0.3*inch))
        
        # Financial Highlights
        story.append(Paragraph("<b>FINANCIAL HIGHLIGHTS</b>", self.styles['Heading2']))
        
        # Generate realistic financial numbers
        base_revenue = 4500 if quarter == "Q3_2024" else 4800
        base_profit = 2100 if quarter == "Q3_2024" else 2300
        
        financial_data = [
            ["Metric", "Amount (SGD Million)", "YoY Change"],
            ["Total Income", f"{base_revenue:,}", "+8.5%"],
            ["Net Profit", f"{base_profit:,}", "+12.3%"],
            ["Total Assets", "825,000", "+6.2%"],
            ["Customer Loans", "420,000", "+7.8%"],
            ["Customer Deposits", "485,000", "+5.9%"]
        ]
        
        table = Table(financial_data, colWidths=[2.5*inch, 2*inch, 1.5*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a73e8')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 11),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        story.append(table)
        story.append(Spacer(1, 0.3*inch))
        
        # Business Performance
        story.append(Paragraph("<b>BUSINESS PERFORMANCE</b>", self.styles['Heading2']))
        
        performance_text = f"""
        DBS Bank delivered strong results in {quarter.replace('_', ' ')} with net profit reaching 
        SGD {base_profit:,} million, representing a year-on-year increase of 12.3%. 
        Total income grew to SGD {base_revenue:,} million driven by robust growth across all business segments.
        <br/><br/>
        <b>Key Achievements:</b><br/>
        • Consumer Banking: Strong mortgage and wealth management performance<br/>
        • Institutional Banking: Increased trade finance and cash management revenues<br/>
        • Treasury Markets: Solid trading income and investment gains<br/>
        • Digital Initiatives: Mobile banking users increased by 15% to 5.2 million<br/>
        <br/>
        Asset quality remained strong with NPL ratio at 1.1%. The bank maintained a healthy 
        capital position with CET1 ratio at 14.8%, well above regulatory requirements.
        """
        
        story.append(Paragraph(performance_text, self.styles['Normal']))
        story.append(Spacer(1, 0.2*inch))
        
        # Outlook
        story.append(Paragraph("<b>OUTLOOK</b>", self.styles['Heading2']))
        outlook_text = """
        Management remains optimistic about growth prospects given the strong regional economic fundamentals 
        and continued digital transformation initiatives. The bank will continue to invest in technology 
        and innovation while maintaining disciplined cost management and strong risk controls.
        """
        story.append(Paragraph(outlook_text, self.styles['Normal']))
        
        # Footer
        story.append(Spacer(1, 0.5*inch))
        footer_style = ParagraphStyle(
            'Footer',
            parent=self.styles['Normal'],
            fontSize=8,
            textColor=colors.grey
        )
        story.append(Paragraph(
            f"DBS Bank Ltd | Company Registration No. 196800306E | Report Date: {datetime.now().strftime('%B %Y')}",
            footer_style
        ))
        
        doc.build(story)
    
    def generate_electricity_bills(self):
        """Generate sample electricity bill PDFs"""
        for i, month in enumerate(ELECTRICITY_MONTHS):
            filepath = f"{self.output_dir}/electricity_bills/DBS_Office_Electricity_{month}.pdf"
            self._create_electricity_bill(month, filepath, i)
            print(f"  Created: {filepath}")
    
    def _create_electricity_bill(self, month, filepath, index):
        """Create a single electricity bill PDF"""
        doc = SimpleDocTemplate(filepath, pagesize=A4)
        story = []
        
        # Header
        header_style = ParagraphStyle(
            'BillHeader',
            parent=self.styles['Title'],
            fontSize=18,
            textColor=colors.HexColor('#ff9800'),
            alignment=TA_CENTER
        )
        story.append(Paragraph("SP UTILITIES", header_style))
        story.append(Paragraph("Electricity Bill", self.styles['Heading2']))
        story.append(Spacer(1, 0.2*inch))
        
        # Bill details
        month_name = month.replace('_', ' ')
        bill_date = {
            "November_2024": "30 November 2024",
            "December_2024": "31 December 2024",
            "January_2025": "31 January 2025"
        }[month]
        
        account_info = [
            ["Account Number:", "1234-5678-90"],
            ["Account Name:", "DBS Bank Ltd - Marina Bay Office"],
            ["Billing Period:", f"01 {month_name} - {bill_date}"],
            ["Due Date:", f"15 {month_name.split()[0]} {month_name.split()[1]}"]
        ]
        
        info_table = Table(account_info, colWidths=[2*inch, 4*inch])
        info_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8)
        ]))
        story.append(info_table)
        story.append(Spacer(1, 0.3*inch))
        
        # Usage details
        story.append(Paragraph("<b>ELECTRICITY CONSUMPTION</b>", self.styles['Heading3']))
        
        # Vary consumption slightly by month
        base_kwh = 45000
        kwh_variations = [43200, 47800, 41500]  # Nov, Dec, Jan
        kwh = kwh_variations[index]
        rate_per_kwh = 0.28  # SGD
        total_charge = kwh * rate_per_kwh
        gst = total_charge * 0.09
        total_amount = total_charge + gst
        
        usage_data = [
            ["Description", "Quantity", "Rate (SGD)", "Amount (SGD)"],
            ["Electricity Consumption", f"{kwh:,} kWh", f"{rate_per_kwh:.2f}", f"{total_charge:,.2f}"],
            ["", "", "Subtotal:", f"{total_charge:,.2f}"],
            ["", "", "GST (9%):", f"{gst:,.2f}"],
            ["", "", "<b>Total Amount Due:</b>", f"<b>{total_amount:,.2f}</b>"]
        ]
        
        usage_table = Table(usage_data, colWidths=[2.5*inch, 1.5*inch, 1.5*inch, 1.5*inch])
        usage_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#ff9800')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('ALIGN', (2, 1), (2, -1), 'RIGHT'),
            ('ALIGN', (3, 1), (3, -1), 'RIGHT'),
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#ffe0b2')),
            ('FONTNAME', (2, -1), (-1, -1), 'Helvetica-Bold')
        ]))
        story.append(usage_table)
        story.append(Spacer(1, 0.3*inch))
        
        # Consumption comparison
        story.append(Paragraph("<b>CONSUMPTION COMPARISON</b>", self.styles['Heading3']))
        
        prev_month_kwh = kwh_variations[(index - 1) % 3]
        change_pct = ((kwh - prev_month_kwh) / prev_month_kwh) * 100
        change_text = "increase" if change_pct > 0 else "decrease"
        
        comparison_text = f"""
        This month's consumption: {kwh:,} kWh<br/>
        Previous month's consumption: {prev_month_kwh:,} kWh<br/>
        Change: {abs(change_pct):.1f}% {change_text}
        """
        story.append(Paragraph(comparison_text, self.styles['Normal']))
        story.append(Spacer(1, 0.3*inch))
        
        # Payment info
        story.append(Paragraph("<b>PAYMENT INFORMATION</b>", self.styles['Heading3']))
        payment_text = """
        Please make payment by the due date to avoid late payment charges.<br/>
        Payment methods: GIRO, Internet Banking, AXS, SAM, Cheque
        """
        story.append(Paragraph(payment_text, self.styles['Normal']))
        
        # Footer
        story.append(Spacer(1, 0.5*inch))
        footer_style = ParagraphStyle(
            'Footer',
            parent=self.styles['Normal'],
            fontSize=8,
            textColor=colors.grey
        )
        story.append(Paragraph(
            "SP Utilities | For enquiries: 1800-222-2333 | www.spgroup.com.sg",
            footer_style
        ))
        
        doc.build(story)


if __name__ == "__main__":
    generator = SampleDataGenerator()
    generator.generate_all()
    
    print("\n" + "="*60)
    print("Sample data generation complete!")
    print("="*60)
    print("\nNext steps:")
    print("1. Review the generated PDFs in the 'sample_data' directory")
    print("2. Upload them to GCS using: python upload_to_gcs.py")
    print("3. Run the indexers for each RAG option")
