# RAG Demo - Google Vertex AI

This demo showcases three different RAG (Retrieval-Augmented Generation) approaches using Google Vertex AI:

1. **Vertex AI Search (Discovery Engine)** - Managed search with built-in relevance
2. **Vertex AI RAG Engine** - Purpose-built RAG with automatic chunking and retrieval
3. **Vertex AI Vector Search** - Custom vector search with full control over embeddings

## Use Case

A Q&A bot  that answers questions from three types of documents:
- **Resumes** (5-10 employee resumes with skills and experience)
- **Financial Reports** (2 quarterly earnings reports)
- **Electricity Bills** (3 months of utility bills)

### Example Questions
- "Recommend a Java developer"
- "How much was the electricity bill in Jan 2025?"
- "What was the net profit in Q4 2024?"
- "Who has machine learning experience?"

## Project Structure

```
.
├── config.py                      # Common configuration
├── requirements.txt               # Python dependencies
├── generate_sample_data.py        # Generate sample PDFs
├── upload_to_gcs.py              # Upload data to GCS
│
├── vertex_search_indexer.py      # Indexer for Vertex AI Search
├── vertex_search_retriever.py    # Retriever for Vertex AI Search
│
├── rag_engine_indexer.py         # Indexer for RAG Engine
├── rag_engine_retriever.py       # Retriever for RAG Engine
│
├── vector_search_indexer.py      # Indexer for Vector Search
└── vector_search_retriever.py    # Retriever for Vector Search
```

## Prerequisites

### 1. Google Cloud Setup

```bash
# Install Google Cloud SDK
# https://cloud.google.com/sdk/docs/install

# Login to Google Cloud
gcloud auth login
gcloud auth application-default login

# Set your project
gcloud config set project YOUR_PROJECT_ID
```

### 2. Enable Required APIs

```bash
gcloud services enable aiplatform.googleapis.com
gcloud services enable storage.googleapis.com
gcloud services enable discoveryengine.googleapis.com
```

### 3. IAM Permissions

Ensure your account has these roles:
- Vertex AI User
- Storage Admin
- Discovery Engine Admin

### 4. Python Environment

```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Mac/Linux)
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

## Configuration

1. Edit `config.py` and update:
   - `PROJECT_ID` - Your GCP project ID
   - `LOCATION` - Your preferred region (default: us-central1)
   - `BUCKET_NAME` - Your GCS bucket name (will be created if doesn't exist)

## Step-by-Step Demo Setup

### Step 1: Generate Sample Data

```bash
python generate_sample_data.py
```

This creates:
- `sample_data/resumes/` - 8 employee resumes with different skills
- `sample_data/financial_reports/` - 2 quarterly earnings reports
- `sample_data/electricity_bills/` - 3 monthly electricity bills

### Step 2: Upload to GCS

```bash
python upload_to_gcs.py
```

Creates/uses GCS bucket and uploads all PDFs.

---

## Option 1: Vertex AI Search (Discovery Engine)

**Best for**: Enterprise search with minimal setup, built-in relevance tuning

### Indexing

```bash
python vertex_search_indexer.py
```

This will:
1. Create a Discovery Engine datastore
2. Create a search engine
3. Import and index documents with metadata
4. Wait 5-10 minutes for full processing

### Retrieval & Q&A

```bash
# Interactive mode
python vertex_search_retriever.py

# Demo mode (predefined queries)
python vertex_search_retriever.py demo

# Single query
python vertex_search_retriever.py "recommend a Java developer"
```

**Key Features**:
- Automatic document parsing and chunking
- Built-in extractive answers and snippets
- Native support for filters and facets
- LLM-enhanced search results
- Query expansion and spell correction

---

## Option 2: Vertex AI RAG Engine

**Best for**: Purpose-built RAG with automatic optimization

### Indexing

```bash
python rag_engine_indexer.py
```

This will:
1. Create a RAG corpus
2. Import documents from GCS
3. Automatically chunk and embed documents
4. Build vector index
5. Save corpus name for retriever

### Retrieval & Q&A

```bash
# Interactive mode
python rag_engine_retriever.py

# Demo mode (predefined queries)
python rag_engine_retriever.py demo

# Show corpus info
python rag_engine_retriever.py info

# Single query
python rag_engine_retriever.py "what was the net profit in Q4 2024?"
```

**Key Features**:
- Automatic chunking strategy
- Optimized for RAG workflows
- Built-in grounding and citations
- Seamless integration with Gemini models
- Simple API for retrieval

---

## Option 3: Vertex AI Vector Search

**Best for**: Custom control over embeddings and search logic

### Indexing

```bash
python vector_search_indexer.py
```

This will:
1. Extract text from all PDFs
2. Chunk documents with overlap
3. Generate embeddings using text-embedding-004
4. Upload embeddings to GCS
5. Create vector index
6. Create and deploy index endpoint
7. **Note**: This process takes 30-60 minutes

### Retrieval & Q&A

```bash
# Interactive mode
python vector_search_retriever.py

# Demo mode (predefined queries)
python vector_search_retriever.py demo

# Single query
python vector_search_retriever.py "who has machine learning skills?"
```

**Key Features**:
- Full control over chunking strategy
- Custom embedding models
- Advanced filtering capabilities
- Scalable to billions of vectors
- Fine-grained distance metrics

---

## Comparison of the Three Approaches

| Feature | Vertex AI Search | RAG Engine | Vector Search |
|---------|-----------------|------------|---------------|
| **Setup Complexity** | Low | Medium | High |
| **Time to Deploy** | 10-15 min | 15-20 min | 30-60 min |
| **Document Parsing** | Automatic | Automatic | Manual |
| **Chunking Control** | No | Limited | Full |
| **Embedding Control** | No | Limited | Full |
| **Metadata Support** | Excellent | Good | Custom |
| **Query Expansion** | Built-in | No | Manual |
| **Filtering** | Native | Limited | Custom |
| **Cost** | Pay per query | Pay per corpus | Pay per hour |
| **Best For** | Enterprise search | Quick RAG | Custom workflows |

## Demo Queries to Try

### Employee Search
- "Recommend a Java developer"
- "Who has experience with Spring Boot?"
- "Find someone with machine learning skills"
- "Who knows Python and data science?"

### Financial Questions
- "What was the net profit in Q4 2024?"
- "What were Bank's total assets?"
- "How did revenue perform year-over-year?"
- "What were the key achievements in Q3 2024?"

### Utility Bills
- "How much was the electricity bill in January 2025?"
- "Compare electricity consumption in November and December 2024"
- "What is the trend in electricity usage?"

## Troubleshooting

### Authentication Issues
```bash
# Re-authenticate
gcloud auth application-default login

# Check current credentials
gcloud auth list
```

### API Not Enabled
```bash
# Enable all required APIs
gcloud services enable aiplatform.googleapis.com storage.googleapis.com discoveryengine.googleapis.com
```

### Permission Denied
```bash
# Check your project
gcloud config get-value project

# Verify IAM permissions in Cloud Console
# https://console.cloud.google.com/iam-admin/iam
```

### Import Errors
```bash
# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

### Vector Search Deployment Taking Too Long
- This is normal - deployment can take 30-60 minutes
- Check status in Cloud Console: Vertex AI > Vector Search
- You can monitor progress with: `gcloud ai index-endpoints list`

### No Results Returned
1. Verify documents are properly indexed
2. Wait 5-10 minutes after indexing completes
3. Check if embeddings were generated correctly
4. Try broader queries

## Cost Considerations

### Vertex AI Search
- ~$0.10 per 1K queries (volume discounts apply)
- Storage: ~$0.02 per GB/month

### RAG Engine
- ~$0.50 per GB stored per month
- Query costs included in corpus storage

### Vector Search
- Index storage: ~$0.10 per GB/month
- Deployed endpoint: ~$1.20 per hour
- Query costs: ~$0.003 per 1K queries

**Recommendation for Demo**: 
- Start with RAG Engine (easiest and most cost-effective for demos)
- Use Vector Search for production with high query volumes
- Use Vertex AI Search for enterprise-wide search solutions

## Clean Up Resources

### Delete Vertex AI Search Resources
```bash
# Note: Use Cloud Console for Discovery Engine cleanup
# https://console.cloud.google.com/gen-app-builder/engines
```

### Delete RAG Engine Resources
```python
# In Python shell
from vertexai.preview import rag
import vertexai

vertexai.init(project="YOUR_PROJECT_ID", location="us-central1")

# List and delete corpora
corpora = rag.list_corpora()
for corpus in corpora:
    rag.delete_corpus(name=corpus.name)
```

### Delete Vector Search Resources
```bash
# Undeploy index
gcloud ai index-endpoints undeploy-index INDEX_ENDPOINT_ID \
  --deployed-index-id=DEPLOYED_INDEX_ID \
  --region=us-central1

# Delete endpoint
gcloud ai index-endpoints delete INDEX_ENDPOINT_ID --region=us-central1

# Delete index
gcloud ai indexes delete INDEX_ID --region=us-central1
```

### Delete GCS Bucket
```bash
gsutil -m rm -r gs://YOUR_BUCKET_NAME
```

## Additional Resources

- [Vertex AI Search Documentation](https://cloud.google.com/generative-ai-app-builder/docs/enterprise-search-introduction)
- [Vertex AI RAG Engine Documentation](https://cloud.google.com/vertex-ai/docs/generative-ai/rag-overview)
- [Vertex AI Vector Search Documentation](https://cloud.google.com/vertex-ai/docs/vector-search/overview)
- [Vertex AI Pricing](https://cloud.google.com/vertex-ai/pricing)

