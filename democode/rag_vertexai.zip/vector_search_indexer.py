"""
Vertex AI Vector Search - Indexer
Creates vector index and index endpoint, processes and embeds documents
"""

from google.cloud import aiplatform
from google.cloud import storage
from vertexai.language_models import TextEmbeddingModel
import vertexai
import json
import time
import PyPDF2
from io import BytesIO
from config import (
    PROJECT_ID, LOCATION, BUCKET_NAME,
    VECTOR_SEARCH_INDEX_DISPLAY_NAME,
    VECTOR_SEARCH_INDEX_ENDPOINT_DISPLAY_NAME,
    VECTOR_SEARCH_DEPLOYED_INDEX_ID,
    DIMENSIONS, EMBEDDING_MODEL
)


class VectorSearchIndexer:
    """Indexer for Vertex AI Vector Search"""
    
    def __init__(self):
        self.project_id = PROJECT_ID
        self.location = LOCATION
        self.bucket_name = BUCKET_NAME
        
        # Initialize clients
        vertexai.init(project=PROJECT_ID, location=LOCATION)
        aiplatform.init(project=PROJECT_ID, location=LOCATION)
        
        self.storage_client = storage.Client(project=PROJECT_ID)
        self.embedding_model = TextEmbeddingModel.from_pretrained(EMBEDDING_MODEL)
        
        self.index = None
        self.index_endpoint = None
    
    def extract_text_from_pdf(self, gcs_uri):
        """Extract text from PDF in GCS"""
        try:
            # Parse GCS URI
            path_parts = gcs_uri.replace("gs://", "").split("/", 1)
            bucket_name = path_parts[0]
            blob_name = path_parts[1]
            
            # Download PDF
            bucket = self.storage_client.bucket(bucket_name)
            blob = bucket.blob(blob_name)
            pdf_bytes = blob.download_as_bytes()
            
            # Extract text
            pdf_reader = PyPDF2.PdfReader(BytesIO(pdf_bytes))
            text_parts = []
            
            for page in pdf_reader.pages:
                text = page.extract_text()
                if text:
                    text_parts.append(text)
            
            full_text = "\n".join(text_parts)
            return full_text
            
        except Exception as e:
            print(f"  ✗ Error extracting text from {gcs_uri}: {e}")
            return ""
    
    def chunk_text(self, text, chunk_size=1000, overlap=200):
        """Split text into overlapping chunks"""
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + chunk_size
            chunk = text[start:end]
            
            # Find last sentence boundary in chunk
            if end < len(text):
                last_period = chunk.rfind('.')
                last_newline = chunk.rfind('\n')
                boundary = max(last_period, last_newline)
                
                if boundary > chunk_size * 0.5:  # If we found a good boundary
                    end = start + boundary + 1
                    chunk = text[start:end]
            
            chunks.append(chunk.strip())
            start = end - overlap if end < len(text) else end
        
        return chunks
    
    def create_embeddings(self, texts, batch_size=5):
        """Generate embeddings for texts"""
        embeddings = []
        
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            try:
                result = self.embedding_model.get_embeddings(batch)
                embeddings.extend([emb.values for emb in result])
                time.sleep(0.5)  # Rate limiting
            except Exception as e:
                print(f"  ✗ Error generating embeddings for batch {i//batch_size + 1}: {e}")
                # Add zero vectors as placeholders
                embeddings.extend([[0.0] * DIMENSIONS for _ in batch])
        
        return embeddings
    
    def process_and_embed_documents(self):
        """Process all documents and create embeddings"""
        print("\n" + "="*60)
        print("Processing and Embedding Documents")
        print("="*60)
        
        bucket = self.storage_client.bucket(self.bucket_name)
        all_embeddings = []
        
        # Process resumes
        print("\nProcessing resumes...")
        resume_blobs = list(bucket.list_blobs(prefix="resumes/"))
        
        for blob in resume_blobs:
            if not blob.name.endswith('.pdf'):
                continue
            
            filename = blob.name.split('/')[-1].replace('.pdf', '')
            employee_name = filename.replace('_', ' ').title()
            gcs_uri = f"gs://{self.bucket_name}/{blob.name}"
            
            print(f"  Processing: {employee_name}")
            
            # Extract text
            text = self.extract_text_from_pdf(gcs_uri)
            
            if not text:
                print(f"    ⚠ No text extracted")
                continue
            
            # Chunk text
            chunks = self.chunk_text(text, chunk_size=800, overlap=150)
            print(f"    Created {len(chunks)} chunks")
            
            # Generate embeddings
            chunk_embeddings = self.create_embeddings(chunks)
            
            # Store with metadata
            for i, (chunk, embedding) in enumerate(zip(chunks, chunk_embeddings)):
                all_embeddings.append({
                    "id": f"resume-{filename}-chunk-{i}",
                    "embedding": embedding,
                    "metadata": {
                        "document_type": "resume",
                        "employee_name": employee_name,
                        "source_file": blob.name,
                        "gcs_uri": gcs_uri,
                        "chunk_index": i,
                        "text": chunk[:500]  # Store truncated text for reference
                    }
                })
        
        # Process financial reports
        print("\nProcessing financial reports...")
        financial_blobs = list(bucket.list_blobs(prefix="financial_reports/"))
        
        for blob in financial_blobs:
            if not blob.name.endswith('.pdf'):
                continue
            
            filename = blob.name.split('/')[-1].replace('.pdf', '')
            gcs_uri = f"gs://{self.bucket_name}/{blob.name}"
            
            print(f"  Processing: {filename}")
            
            text = self.extract_text_from_pdf(gcs_uri)
            
            if not text:
                print(f"    ⚠ No text extracted")
                continue
            
            chunks = self.chunk_text(text, chunk_size=1000, overlap=200)
            print(f"    Created {len(chunks)} chunks")
            
            chunk_embeddings = self.create_embeddings(chunks)
            
            for i, (chunk, embedding) in enumerate(zip(chunks, chunk_embeddings)):
                all_embeddings.append({
                    "id": f"financial-{filename.lower().replace(' ', '-')}-chunk-{i}",
                    "embedding": embedding,
                    "metadata": {
                        "document_type": "financial_report",
                        "report_name": filename,
                        "source_file": blob.name,
                        "gcs_uri": gcs_uri,
                        "chunk_index": i,
                        "text": chunk[:500]
                    }
                })
        
        # Process electricity bills
        print("\nProcessing electricity bills...")
        bill_blobs = list(bucket.list_blobs(prefix="electricity_bills/"))
        
        for blob in bill_blobs:
            if not blob.name.endswith('.pdf'):
                continue
            
            filename = blob.name.split('/')[-1].replace('.pdf', '')
            gcs_uri = f"gs://{self.bucket_name}/{blob.name}"
            
            print(f"  Processing: {filename}")
            
            text = self.extract_text_from_pdf(gcs_uri)
            
            if not text:
                print(f"    ⚠ No text extracted")
                continue
            
            chunks = self.chunk_text(text, chunk_size=600, overlap=100)
            print(f"    Created {len(chunks)} chunks")
            
            chunk_embeddings = self.create_embeddings(chunks)
            
            for i, (chunk, embedding) in enumerate(zip(chunks, chunk_embeddings)):
                all_embeddings.append({
                    "id": f"bill-{filename.lower().replace(' ', '-')}-chunk-{i}",
                    "embedding": embedding,
                    "metadata": {
                        "document_type": "electricity_bill",
                        "bill_name": filename,
                        "source_file": blob.name,
                        "gcs_uri": gcs_uri,
                        "chunk_index": i,
                        "text": chunk[:500]
                    }
                })
        
        print(f"\n✓ Total embeddings created: {len(all_embeddings)}")
        return all_embeddings
    
    def upload_embeddings_to_gcs(self, embeddings):
        """Upload embeddings in JSONL format to GCS"""
        print("\n" + "="*60)
        print("Uploading Embeddings to GCS")
        print("="*60)
        
        bucket = self.storage_client.bucket(self.bucket_name)
        blob = bucket.blob("vector_index/embeddings.jsonl")
        
        # Convert to JSONL format required by Vector Search
        jsonl_lines = []
        for item in embeddings:
            # Format for Vector Search
            vector_record = {
                "id": item["id"],
                "embedding": item["embedding"],
                # Restricts: metadata fields that can be used for filtering
                "restricts": [
                    {"namespace": "document_type", "allow": [item["metadata"]["document_type"]]},
                ]
            }
            
            # Add employee name for resumes
            if "employee_name" in item["metadata"]:
                vector_record["restricts"].append({
                    "namespace": "employee_name",
                    "allow": [item["metadata"]["employee_name"]]
                })
            
            jsonl_lines.append(json.dumps(vector_record))
        
        jsonl_content = "\n".join(jsonl_lines)
        
        blob.upload_from_string(jsonl_content, content_type="application/jsonl")
        
        gcs_uri = f"gs://{self.bucket_name}/vector_index/embeddings.jsonl"
        print(f"✓ Embeddings uploaded to: {gcs_uri}")
        
        # Also save metadata separately for retrieval
        metadata_blob = bucket.blob("vector_index/metadata.json")
        metadata_content = json.dumps(
            {item["id"]: item["metadata"] for item in embeddings},
            indent=2
        )
        metadata_blob.upload_from_string(metadata_content, content_type="application/json")
        print(f"✓ Metadata saved to: gs://{self.bucket_name}/vector_index/metadata.json")
        
        return gcs_uri
    
    def create_vector_index(self, embeddings_gcs_uri):
        """Create Vector Search index"""
        print("\n" + "="*60)
        print("Creating Vector Search Index")
        print("="*60)
        
        try:
            # Check if index already exists
            existing_indexes = aiplatform.MatchingEngineIndex.list(
                filter=f'display_name="{VECTOR_SEARCH_INDEX_DISPLAY_NAME}"'
            )
            
            if existing_indexes:
                print(f"✓ Index already exists: {existing_indexes[0].resource_name}")
                self.index = existing_indexes[0]
                return self.index
            
            # Create index
            print("Creating new index... (this may take 20-30 minutes)")
            
            self.index = aiplatform.MatchingEngineIndex.create_tree_ah_index(
                display_name=VECTOR_SEARCH_INDEX_DISPLAY_NAME,
                contents_delta_uri=embeddings_gcs_uri,
                dimensions=DIMENSIONS,
                approximate_neighbors_count=10,
                distance_measure_type="DOT_PRODUCT_DISTANCE",
                leaf_node_embedding_count=500,
                leaf_nodes_to_search_percent=7,
                description="DBS Bank document embeddings for RAG",
            )
            
            print(f"✓ Index created: {self.index.resource_name}")
            return self.index
            
        except Exception as e:
            print(f"✗ Error creating index: {e}")
            raise
    
    def create_index_endpoint(self):
        """Create Vector Search index endpoint"""
        print("\n" + "="*60)
        print("Creating Index Endpoint")
        print("="*60)
        
        try:
            # Check if endpoint already exists
            existing_endpoints = aiplatform.MatchingEngineIndexEndpoint.list(
                filter=f'display_name="{VECTOR_SEARCH_INDEX_ENDPOINT_DISPLAY_NAME}"'
            )
            
            if existing_endpoints:
                print(f"✓ Endpoint already exists: {existing_endpoints[0].resource_name}")
                self.index_endpoint = existing_endpoints[0]
                return self.index_endpoint
            
            # Create endpoint
            print("Creating new endpoint... (this may take 10-15 minutes)")
            
            self.index_endpoint = aiplatform.MatchingEngineIndexEndpoint.create(
                display_name=VECTOR_SEARCH_INDEX_ENDPOINT_DISPLAY_NAME,
                description="Endpoint for DBS Bank RAG demo",
                public_endpoint_enabled=True,
            )
            
            print(f"✓ Endpoint created: {self.index_endpoint.resource_name}")
            return self.index_endpoint
            
        except Exception as e:
            print(f"✗ Error creating endpoint: {e}")
            raise
    
    def deploy_index(self):
        """Deploy index to endpoint"""
        print("\n" + "="*60)
        print("Deploying Index to Endpoint")
        print("="*60)
        
        try:
            # Check if already deployed
            deployed_indexes = self.index_endpoint.deployed_indexes
            for deployed_index in deployed_indexes:
                if deployed_index.id == VECTOR_SEARCH_DEPLOYED_INDEX_ID:
                    print(f"✓ Index already deployed: {VECTOR_SEARCH_DEPLOYED_INDEX_ID}")
                    return
            
            # Deploy index
            print("Deploying index... (this may take 20-30 minutes)")
            
            self.index_endpoint.deploy_index(
                index=self.index,
                deployed_index_id=VECTOR_SEARCH_DEPLOYED_INDEX_ID,
                display_name=VECTOR_SEARCH_INDEX_DISPLAY_NAME,
                machine_type="e2-standard-2",
                min_replica_count=1,
                max_replica_count=1,
            )
            
            print(f"✓ Index deployed successfully")
            
        except Exception as e:
            print(f"✗ Error deploying index: {e}")
            raise
    
    def run_indexing(self):
        """Run the complete indexing process"""
        print("\n" + "="*80)
        print("VERTEX AI VECTOR SEARCH - INDEXER")
        print("="*80)
        
        try:
            # Step 1: Process documents and create embeddings
            embeddings = self.process_and_embed_documents()
            
            if not embeddings:
                raise Exception("No embeddings created")
            
            # Step 2: Upload embeddings to GCS
            embeddings_uri = self.upload_embeddings_to_gcs(embeddings)
            
            # Step 3: Create Vector Search index
            self.create_vector_index(embeddings_uri)
            
            # Step 4: Create index endpoint
            self.create_index_endpoint()
            
            # Step 5: Deploy index to endpoint
            self.deploy_index()
            
            print("\n" + "="*80)
            print("INDEXING COMPLETE!")
            print("="*80)
            print("\nNext steps:")
            print("1. Wait for deployment to complete (~30 minutes total)")
            print("2. Run the retriever: python vector_search_retriever.py")
            print(f"\nIndex: {self.index.resource_name}")
            print(f"Endpoint: {self.index_endpoint.resource_name}")
            
            # Save resource names for retriever
            with open("vector_search_resources.json", "w") as f:
                json.dump({
                    "index_name": self.index.resource_name,
                    "endpoint_name": self.index_endpoint.resource_name,
                    "deployed_index_id": VECTOR_SEARCH_DEPLOYED_INDEX_ID,
                }, f, indent=2)
            
            print("\n✓ Resource names saved to: vector_search_resources.json")
            
        except Exception as e:
            print(f"\n✗ Indexing failed: {e}")
            raise


if __name__ == "__main__":
    indexer = VectorSearchIndexer()
    indexer.run_indexing()
