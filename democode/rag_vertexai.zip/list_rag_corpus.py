"""
Quick script to list RAG corpora and their files
"""
from vertexai.preview import rag
import vertexai
from config import PROJECT_ID, LOCATION

# Initialize Vertex AI
vertexai.init(project=PROJECT_ID, location=LOCATION)

print("="*80)
print(f"RAG Corpora in {LOCATION}")
print("="*80)

try:
    # List all corpora
    corpora = rag.list_corpora()
    corpus_list = list(corpora)

    print(f"\nTotal corpora found: {len(corpus_list)}")

    for i, corpus in enumerate(corpus_list, 1):
        print(f"\n{i}. Corpus: {corpus.display_name}")
        print(f"   Name: {corpus.name}")
        if hasattr(corpus, 'description') and corpus.description:
            print(f"   Description: {corpus.description}")

        # List files in this corpus
        try:
            print(f"\n   Files in corpus:")
            files = rag.list_files(corpus_name=corpus.name)
            file_list = list(files)

            if len(file_list) == 0:
                print("   No files found (may still be processing)")
            else:
                for j, file in enumerate(file_list, 1):
                    print(f"   {j}. {file.display_name}")
                    if hasattr(file, 'size_bytes'):
                        print(f"      Size: {file.size_bytes} bytes")

        except Exception as e:
            print(f"   [ERROR] Could not list files: {e}")

        print("-" * 80)

except Exception as e:
    print(f"[ERROR] Failed to list corpora: {e}")
    import traceback
    print(traceback.format_exc())
