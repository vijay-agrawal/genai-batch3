"""
Script to empty a RAG corpus by deleting all files from it
Keeps the corpus itself, only removes the indexed files
"""
from vertexai.preview import rag
import vertexai
from config import PROJECT_ID, LOCATION
import sys

# Initialize Vertex AI
vertexai.init(project=PROJECT_ID, location=LOCATION)

def empty_corpus(corpus_name):
    """Delete all files from a RAG corpus"""
    print("="*80)
    print("RAG Corpus File Deletion")
    print("="*80)

    try:
        print(f"\nCorpus: {corpus_name}")

        # List all files in the corpus
        print("\nListing files in corpus...")
        files = rag.list_files(corpus_name=corpus_name)
        file_list = list(files)

        if len(file_list) == 0:
            print("[INFO] Corpus is already empty (no files found)")
            return

        print(f"\nFound {len(file_list)} file(s) to delete:")
        for i, file in enumerate(file_list, 1):
            print(f"  {i}. {file.display_name}")

        # Ask for confirmation
        print("\n" + "="*80)
        response = input(f"Do you want to delete all {len(file_list)} file(s)? (yes/no): ").strip().lower()

        if response not in ['yes', 'y']:
            print("\n[INFO] Deletion cancelled")
            return

        # Delete files
        print("\n" + "="*80)
        print("Deleting files...")
        print("="*80)

        deleted_count = 0
        failed_count = 0

        for i, file in enumerate(file_list, 1):
            try:
                print(f"\n{i}/{len(file_list)} Deleting: {file.display_name}")
                rag.delete_file(name=file.name)
                print(f"  [OK] Deleted successfully")
                deleted_count += 1
            except Exception as e:
                print(f"  [ERROR] Failed to delete: {e}")
                failed_count += 1

        # Summary
        print("\n" + "="*80)
        print("Deletion Summary")
        print("="*80)
        print(f"Successfully deleted: {deleted_count}/{len(file_list)}")
        print(f"Failed: {failed_count}/{len(file_list)}")
        print(f"\nCorpus '{corpus_name}' is now empty")

    except Exception as e:
        print(f"\n[ERROR] Failed to empty corpus: {e}")
        import traceback
        print(traceback.format_exc())

def load_corpus_name_from_file():
    """Load corpus name from rag_corpus_name.txt"""
    try:
        with open("rag_corpus_name.txt", "r") as f:
            return f.read().strip()
    except Exception as e:
        print(f"[ERROR] Could not load corpus name from file: {e}")
        return None

def main():
    """Main function"""
    print("\n" + "="*80)
    print("EMPTY RAG CORPUS - File Deletion Tool")
    print("="*80)

    # Get corpus name
    corpus_name = None

    # Check command line argument
    if len(sys.argv) > 1:
        corpus_name = sys.argv[1]
    else:
        # Try to load from file
        corpus_name = load_corpus_name_from_file()

    if not corpus_name:
        print("\n[ERROR] No corpus name provided!")
        print("\nUsage:")
        print("  python empty_rag_corpus.py <corpus_name>")
        print("  OR")
        print("  python empty_rag_corpus.py  (uses corpus from rag_corpus_name.txt)")
        print("\nExample:")
        print("  python empty_rag_corpus.py projects/123/locations/us-west1/ragCorpora/456")
        return

    # Confirm corpus name
    print(f"\nTarget corpus: {corpus_name}")

    # Empty the corpus
    empty_corpus(corpus_name)

if __name__ == "__main__":
    main()
