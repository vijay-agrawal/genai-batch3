"""
Script to delete empty RAG corpora and keep only the one with files
"""
from vertexai.preview import rag
import vertexai
from config import PROJECT_ID, LOCATION

# Initialize Vertex AI
vertexai.init(project=PROJECT_ID, location=LOCATION)

print("="*80)
print("RAG Corpus Cleanup")
print("="*80)

try:
    # List all corpora
    corpora = rag.list_corpora()
    corpus_list = list(corpora)

    print(f"\nFound {len(corpus_list)} corpora")

    corpora_to_delete = []
    corpus_to_keep = None

    for corpus in corpus_list:
        print(f"\nChecking corpus: {corpus.display_name}")
        print(f"  Name: {corpus.name}")

        # Count files in this corpus
        try:
            files = rag.list_files(corpus_name=corpus.name)
            file_count = len(list(files))
            print(f"  Files: {file_count}")

            if file_count == 0:
                corpora_to_delete.append(corpus)
                print(f"  [MARKED FOR DELETION] - Empty corpus")
            else:
                corpus_to_keep = corpus
                print(f"  [KEEP] - Has {file_count} files")

        except Exception as e:
            print(f"  [ERROR] Could not count files: {e}")

    # Delete empty corpora
    print("\n" + "="*80)
    print("Deleting empty corpora...")
    print("="*80)

    for corpus in corpora_to_delete:
        try:
            print(f"\nDeleting: {corpus.name}")
            rag.delete_corpus(name=corpus.name)
            print(f"  [OK] Deleted successfully")
        except Exception as e:
            print(f"  [ERROR] Failed to delete: {e}")

    if corpus_to_keep:
        print("\n" + "="*80)
        print("Corpus to use:")
        print("="*80)
        print(f"\nName: {corpus_to_keep.name}")
        print(f"Display Name: {corpus_to_keep.display_name}")

        # Update the corpus name file
        with open("rag_corpus_name.txt", "w") as f:
            f.write(corpus_to_keep.name)
        print("\n[OK] Updated rag_corpus_name.txt with the correct corpus")
    else:
        print("\n[WARNING] No corpus with files found!")

except Exception as e:
    print(f"\n[ERROR] Cleanup failed: {e}")
    import traceback
    print(traceback.format_exc())
