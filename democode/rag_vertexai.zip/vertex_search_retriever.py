"""
Vertex AI Search (Discovery Engine) - Retriever
Query and retrieve documents from Vertex AI Search datastore
"""

from google.cloud import discoveryengine_v1 as discoveryengine
from google.api_core.client_options import ClientOptions
from vertexai.generative_models import GenerativeModel
import vertexai
from config import (
    PROJECT_ID, LOCATION,
    VERTEX_SEARCH_ENGINE_ID,
    GENERATION_MODEL, TEMPERATURE, MAX_OUTPUT_TOKENS
)


class VertexAISearchRetriever:
    """Retriever for Vertex AI Search (Discovery Engine)"""
    
    def __init__(self):
        self.project_id = PROJECT_ID
        self.location = LOCATION

        # Initialize Discovery Engine client
        # Note: Discovery Engine is only available in specific global regions
        # Use 'global' location for Discovery Engine regardless of LOCATION config
        discovery_location = "global"
        self.client_options = ClientOptions(
            api_endpoint=f"{discovery_location}-discoveryengine.googleapis.com",
            quota_project_id=PROJECT_ID  # Set quota project explicitly
        )
        self.search_client = discoveryengine.SearchServiceClient(
            client_options=self.client_options
        )
        
        # Initialize Vertex AI for generation
        vertexai.init(project=PROJECT_ID, location=LOCATION)
        self.llm = GenerativeModel(GENERATION_MODEL)
        
        # Serving config path - Discovery Engine uses 'global' location
        self.serving_config = (
            f"projects/{PROJECT_ID}/locations/global/collections/default_collection/"
            f"engines/{VERTEX_SEARCH_ENGINE_ID}/servingConfigs/default_config"
        )
    
    def search(self, query, page_size=10, use_semantic_search=True):
        """
        Search documents in the datastore
        
        Args:
            query: Search query string
            page_size: Number of results to return
            use_semantic_search: Use semantic/natural language search
        """
        print(f"\nSearching for: '{query}'")
        print("-" * 60)
        
        try:
            # Configure search request
            request = discoveryengine.SearchRequest(
                serving_config=self.serving_config,
                query=query,
                page_size=page_size,
                # Enable content search with extractive answers
                content_search_spec=discoveryengine.SearchRequest.ContentSearchSpec(
                    snippet_spec=discoveryengine.SearchRequest.ContentSearchSpec.SnippetSpec(
                        return_snippet=True,
                        max_snippet_count=3,
                    ),
                    extractive_content_spec=discoveryengine.SearchRequest.ContentSearchSpec.ExtractiveContentSpec(
                        max_extractive_answer_count=3,
                        max_extractive_segment_count=3,
                    ),
                    search_result_mode=discoveryengine.SearchRequest.ContentSearchSpec.SearchResultMode.DOCUMENTS,
                ),
                # Query expansion for better matching
                query_expansion_spec=discoveryengine.SearchRequest.QueryExpansionSpec(
                    condition=discoveryengine.SearchRequest.QueryExpansionSpec.Condition.AUTO,
                ),
                # Spell correction
                spell_correction_spec=discoveryengine.SearchRequest.SpellCorrectionSpec(
                    mode=discoveryengine.SearchRequest.SpellCorrectionSpec.Mode.AUTO,
                ),
            )
            
            # Execute search
            response = self.search_client.search(request=request)
            
            # Process results
            results = []
            for result in response.results:
                doc = result.document
                
                # Extract document data
                doc_data = {
                    "id": doc.id,
                    "name": doc.name,
                    "uri": doc.struct_data.get("uri", ""),
                    "title": doc.struct_data.get("title", ""),
                    "document_type": doc.struct_data.get("document_type", ""),
                    "employee_name": doc.struct_data.get("employee_name", ""),
                }
                
                # Extract snippets
                snippets = []
                if hasattr(result, 'document') and hasattr(result.document, 'derived_struct_data'):
                    derived_data = result.document.derived_struct_data
                    if 'snippets' in derived_data:
                        for snippet in derived_data['snippets']:
                            snippets.append(snippet.get('snippet', ''))
                    
                    # Get extractive answers
                    if 'extractive_answers' in derived_data:
                        for answer in derived_data['extractive_answers']:
                            snippets.append(answer.get('content', ''))
                
                doc_data["snippets"] = snippets
                results.append(doc_data)
            
            return results
            
        except Exception as e:
            print(f"[ERROR] Search error: {e}")
            return []
    
    def display_results(self, results):
        """Display search results in a formatted way"""
        if not results:
            print("No results found.")
            return
        
        print(f"\nFound {len(results)} result(s):\n")
        
        for i, result in enumerate(results, 1):
            print(f"{i}. {result['title']}")
            print(f"   Type: {result['document_type']}")
            if result.get('employee_name'):
                print(f"   Employee: {result['employee_name']}")
            print(f"   URI: {result['uri']}")
            
            if result['snippets']:
                print(f"   Relevant excerpts:")
                for j, snippet in enumerate(result['snippets'][:2], 1):
                    # Clean and truncate snippet
                    clean_snippet = snippet.strip().replace('\n', ' ')[:200]
                    print(f"     {j}. {clean_snippet}...")
            print()
    
    def answer_with_rag(self, query):
        """
        Answer query using RAG approach:
        1. Search for relevant documents
        2. Use LLM to generate answer based on retrieved context
        """
        print("\n" + "="*60)
        print(f"Query: {query}")
        print("="*60)
        
        # Step 1: Retrieve relevant documents
        results = self.search(query, page_size=5)
        
        if not results:
            return "I couldn't find any relevant documents to answer your question."
        
        # Display search results
        self.display_results(results)
        
        # Step 2: Prepare context from retrieved documents
        context_parts = []
        for result in results:
            context_parts.append(f"Document: {result['title']}")
            context_parts.append(f"Type: {result['document_type']}")
            if result.get('employee_name'):
                context_parts.append(f"Employee: {result['employee_name']}")
            
            if result['snippets']:
                context_parts.append("Content:")
                for snippet in result['snippets'][:2]:
                    context_parts.append(f"- {snippet.strip()}")
            context_parts.append("\n")
        
        context = "\n".join(context_parts)
        
        # Step 3: Generate answer using LLM
        prompt = f"""Based on the following retrieved documents, please answer the user's question.
If the information is not sufficient to answer the question completely, say so.

Retrieved Documents:
{context}

User Question: {query}

Please provide a clear, concise answer based only on the information in the retrieved documents."""
        
        print("\n" + "="*60)
        print("Generated Answer:")
        print("="*60)
        
        try:
            response = self.llm.generate_content(
                prompt,
                generation_config={
                    "temperature": TEMPERATURE,
                    "max_output_tokens": MAX_OUTPUT_TOKENS,
                }
            )
            
            answer = response.text
            print(answer)
            return answer
            
        except Exception as e:
            print(f"[ERROR] Error generating answer: {e}")
            return "Error generating answer."
    
    def interactive_qa(self):
        """Interactive Q&A session"""
        print("\n" + "="*80)
        print("VERTEX AI SEARCH (DISCOVERY ENGINE) - INTERACTIVE Q&A")
        print("="*80)
        print("\nAsk questions about:")
        print("  • Employee skills and experience (e.g., 'recommend a Java developer')")
        print("  • Financial reports (e.g., 'what was the net profit in Q4 2024?')")
        print("  • Electricity bills (e.g., 'how much was the electricity bill in Jan 2025?')")
        print("\nType 'quit' to exit")
        print("="*80)
        
        while True:
            try:
                query = input("\n>> Your question: ").strip()
                
                if query.lower() in ['quit', 'exit', 'q']:
                    print("\nGoodbye!")
                    break
                
                if not query:
                    continue
                
                # Answer with RAG
                self.answer_with_rag(query)
                
            except KeyboardInterrupt:
                print("\n\nGoodbye!")
                break
            except Exception as e:
                print(f"[ERROR] Error: {e}")
    
    def run_demo_queries(self):
        """Run predefined demo queries"""
        print("\n" + "="*80)
        print("VERTEX AI SEARCH (DISCOVERY ENGINE) - DEMO QUERIES")
        print("="*80)
        
        demo_queries = [
            "recommend a Java developer",
            "what was the net profit in Q4 2024?",
            "how much was the electricity bill in January 2025?",
            "who has experience with machine learning?",
            "what were the total assets in Q3 2024?",
        ]
        
        for query in demo_queries:
            self.answer_with_rag(query)
            input("\nPress Enter to continue to next query...")
        
        print("\n" + "="*80)
        print("Demo complete!")
        print("="*80)


def main():
    """Main function"""
    retriever = VertexAISearchRetriever()
    
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "demo":
            # Run demo queries
            retriever.run_demo_queries()
        else:
            # Single query from command line
            query = " ".join(sys.argv[1:])
            retriever.answer_with_rag(query)
    else:
        # Interactive mode
        retriever.interactive_qa()


if __name__ == "__main__":
    main()
