"""
Configuration file for DBS Bank RAG Demo
Contains all common configurations for the three Vertex AI RAG options
"""

# GCP Project Configuration
PROJECT_ID = "gen-ai-training-476514"  # Replace with your GCP project ID
LOCATION = "us-west1"  # Changed from us-central1 due to RAG Engine capacity limitations
BUCKET_NAME = "genai-training-rag"  # Replace with your GCS bucket name

# Data Paths in GCS
GCS_RESUME_PATH = f"gs://{BUCKET_NAME}/resumes/"
GCS_FINANCIAL_PATH = f"gs://{BUCKET_NAME}/financial_reports/"
GCS_BILLS_PATH = f"gs://{BUCKET_NAME}/electricity_bills/"

# Vector Search Configuration
VECTOR_SEARCH_INDEX_ENDPOINT_DISPLAY_NAME = "genai-training-vector-endpoint"
VECTOR_SEARCH_INDEX_DISPLAY_NAME = "genai-training-vector-index"
VECTOR_SEARCH_DEPLOYED_INDEX_ID = "genai_training_deployed_index"
DIMENSIONS = 768  # For textembedding-gecko@003

# Vertex AI Search Configuration
VERTEX_SEARCH_DATASTORE_ID = "genai-training-datastore"
VERTEX_SEARCH_ENGINE_ID = "genai-training-search-engine"
VERTEX_SEARCH_DATASTORE_DISPLAY_NAME = "GenAI Training Document Store"

# RAG Engine Configuration
RAG_CORPUS_DISPLAY_NAME = "genai-training-rag-corpus"
RAG_CORPUS_DESCRIPTION = "RAG Corpus documents including resumes, financial reports, and utility bills"

# Embedding Model
EMBEDDING_MODEL = "text-embedding-004"
EMBEDDING_TASK_TYPE = "RETRIEVAL_DOCUMENT"

# LLM Configuration
GENERATION_MODEL = "gemini-2.5-flash"
TEMPERATURE = 0.2
MAX_OUTPUT_TOKENS = 2048

# Sample Data Structure
SAMPLE_EMPLOYEES = [
    "john_smith",
    "sarah_johnson", 
    "michael_chen",
    "priya_patel",
    "david_wong",
    "emily_taylor",
    "raj_kumar",
    "lisa_anderson"
]

SAMPLE_SKILLS = {
    "john_smith": ["Java", "Spring Boot", "Microservices", "AWS", "Docker"],
    "sarah_johnson": ["Python", "Machine Learning", "TensorFlow", "Data Science"],
    "michael_chen": ["Java", "Kotlin", "Android", "Firebase", "REST APIs"],
    "priya_patel": ["React", "Node.js", "TypeScript", "MongoDB"],
    "david_wong": ["Java", "Spring Framework", "PostgreSQL", "Kubernetes"],
    "emily_taylor": ["DevOps", "CI/CD", "Jenkins", "Terraform", "AWS"],
    "raj_kumar": ["Java", "Scala", "Apache Spark", "Big Data", "Kafka"],
    "lisa_anderson": ["Python", "Django", "FastAPI", "Docker", "Redis"]
}

FINANCIAL_QUARTERS = ["Q3_2024", "Q4_2024"]
ELECTRICITY_MONTHS = ["November_2024", "December_2024", "January_2025"]

# Authentication
# Ensure you have set GOOGLE_APPLICATION_CREDENTIALS environment variable
# or run: gcloud auth application-default login
