"""
Comprehensive RAG Corpus Management Tool
Provides options to:
1. List all corpora and their files
2. Empty a corpus (delete all files)
3. Delete a corpus entirely
4. Delete all empty corpora
"""
from vertexai.preview import rag
import vertexai
from config import PROJECT_ID, LOCATION
import sys

# Initialize Vertex AI
vertexai.init(project=PROJECT_ID, location=LOCATION)

def list_all_corpora():
    """List all RAG corpora and their files"""
    print("\n" + "="*80)
    print("All RAG Corpora")
    print("="*80)

    try:
        corpora = rag.list_corpora()
        corpus_list = list(corpora)

        if len(corpus_list) == 0:
            print("\n[INFO] No corpora found")
            return []

        print(f"\nFound {len(corpus_list)} corpus/corpora:\n")

        corpus_info = []

        for i, corpus in enumerate(corpus_list, 1):
            print(f"{i}. {corpus.display_name}")
            print(f"   ID: {corpus.name}")

            # Count files
            try:
                files = rag.list_files(corpus_name=corpus.name)
                file_count = len(list(files))
                print(f"   Files: {file_count}")
                corpus_info.append({
                    'corpus': corpus,
                    'file_count': file_count,
                    'index': i
                })
            except Exception as e:
                print(f"   Files: [ERROR] {e}")
                corpus_info.append({
                    'corpus': corpus,
                    'file_count': 0,
                    'index': i
                })

            print()

        return corpus_info

    except Exception as e:
        print(f"[ERROR] Failed to list corpora: {e}")
        return []

def empty_corpus(corpus_name):
    """Delete all files from a RAG corpus"""
    print("\n" + "="*80)
    print("Empty Corpus - Delete All Files")
    print("="*80)

    try:
        print(f"\nCorpus: {corpus_name}")

        # List all files
        files = rag.list_files(corpus_name=corpus_name)
        file_list = list(files)

        if len(file_list) == 0:
            print("[INFO] Corpus is already empty")
            return True

        print(f"\nFiles to delete: {len(file_list)}")

        # Ask for confirmation
        response = input(f"\nDelete all {len(file_list)} file(s)? (yes/no): ").strip().lower()

        if response not in ['yes', 'y']:
            print("[INFO] Cancelled")
            return False

        # Delete files
        print("\nDeleting files...")
        deleted_count = 0

        for i, file in enumerate(file_list, 1):
            try:
                print(f"  {i}/{len(file_list)} Deleting {file.display_name}...", end=" ")
                rag.delete_file(name=file.name)
                print("[OK]")
                deleted_count += 1
            except Exception as e:
                print(f"[ERROR] {e}")

        print(f"\n[OK] Deleted {deleted_count}/{len(file_list)} files")
        return True

    except Exception as e:
        print(f"\n[ERROR] Failed: {e}")
        return False

def delete_corpus(corpus_name):
    """Delete a RAG corpus entirely"""
    print("\n" + "="*80)
    print("Delete Corpus")
    print("="*80)

    try:
        print(f"\nCorpus: {corpus_name}")

        # Ask for confirmation
        response = input("\nAre you sure you want to DELETE this corpus? (yes/no): ").strip().lower()

        if response not in ['yes', 'y']:
            print("[INFO] Cancelled")
            return False

        # Delete corpus
        print("\nDeleting corpus...")
        rag.delete_corpus(name=corpus_name)
        print("[OK] Corpus deleted successfully")
        return True

    except Exception as e:
        print(f"\n[ERROR] Failed: {e}")
        return False

def delete_empty_corpora():
    """Delete all empty corpora"""
    print("\n" + "="*80)
    print("Delete All Empty Corpora")
    print("="*80)

    try:
        # List all corpora
        corpora = rag.list_corpora()
        corpus_list = list(corpora)

        empty_corpora = []

        print("\nChecking corpora...")
        for corpus in corpus_list:
            files = rag.list_files(corpus_name=corpus.name)
            file_count = len(list(files))

            if file_count == 0:
                empty_corpora.append(corpus)
                print(f"  [EMPTY] {corpus.display_name}")
            else:
                print(f"  [HAS FILES] {corpus.display_name} ({file_count} files)")

        if len(empty_corpora) == 0:
            print("\n[INFO] No empty corpora found")
            return True

        # Ask for confirmation
        print(f"\nFound {len(empty_corpora)} empty corpus/corpora")
        response = input(f"\nDelete all {len(empty_corpora)} empty corpus/corpora? (yes/no): ").strip().lower()

        if response not in ['yes', 'y']:
            print("[INFO] Cancelled")
            return False

        # Delete empty corpora
        print("\nDeleting empty corpora...")
        deleted_count = 0

        for i, corpus in enumerate(empty_corpora, 1):
            try:
                print(f"  {i}/{len(empty_corpora)} Deleting {corpus.display_name}...", end=" ")
                rag.delete_corpus(name=corpus.name)
                print("[OK]")
                deleted_count += 1
            except Exception as e:
                print(f"[ERROR] {e}")

        print(f"\n[OK] Deleted {deleted_count}/{len(empty_corpora)} empty corpora")
        return True

    except Exception as e:
        print(f"\n[ERROR] Failed: {e}")
        return False

def interactive_menu():
    """Interactive menu for corpus management"""
    while True:
        print("\n" + "="*80)
        print("RAG CORPUS MANAGEMENT")
        print("="*80)
        print("\nOptions:")
        print("  1. List all corpora")
        print("  2. Empty a corpus (delete all files, keep corpus)")
        print("  3. Delete a corpus entirely")
        print("  4. Delete all empty corpora")
        print("  5. Exit")
        print("="*80)

        choice = input("\nEnter your choice (1-5): ").strip()

        if choice == '1':
            list_all_corpora()

        elif choice == '2':
            corpus_info = list_all_corpora()
            if corpus_info:
                corpus_num = input("\nEnter corpus number to empty (or 'c' to cancel): ").strip()
                if corpus_num.lower() != 'c':
                    try:
                        idx = int(corpus_num) - 1
                        if 0 <= idx < len(corpus_info):
                            empty_corpus(corpus_info[idx]['corpus'].name)
                        else:
                            print("[ERROR] Invalid corpus number")
                    except ValueError:
                        print("[ERROR] Invalid input")

        elif choice == '3':
            corpus_info = list_all_corpora()
            if corpus_info:
                corpus_num = input("\nEnter corpus number to DELETE (or 'c' to cancel): ").strip()
                if corpus_num.lower() != 'c':
                    try:
                        idx = int(corpus_num) - 1
                        if 0 <= idx < len(corpus_info):
                            delete_corpus(corpus_info[idx]['corpus'].name)
                        else:
                            print("[ERROR] Invalid corpus number")
                    except ValueError:
                        print("[ERROR] Invalid input")

        elif choice == '4':
            delete_empty_corpora()

        elif choice == '5':
            print("\nGoodbye!")
            break

        else:
            print("[ERROR] Invalid choice. Please enter 1-5")

def main():
    """Main function"""
    if len(sys.argv) > 1:
        # Command line mode
        action = sys.argv[1].lower()

        if action == 'list':
            list_all_corpora()

        elif action == 'empty':
            if len(sys.argv) > 2:
                empty_corpus(sys.argv[2])
            else:
                print("[ERROR] Please provide corpus name")
                print("Usage: python manage_rag_corpus.py empty <corpus_name>")

        elif action == 'delete':
            if len(sys.argv) > 2:
                delete_corpus(sys.argv[2])
            else:
                print("[ERROR] Please provide corpus name")
                print("Usage: python manage_rag_corpus.py delete <corpus_name>")

        elif action == 'cleanup':
            delete_empty_corpora()

        else:
            print("[ERROR] Invalid action")
            print("\nUsage:")
            print("  python manage_rag_corpus.py list")
            print("  python manage_rag_corpus.py empty <corpus_name>")
            print("  python manage_rag_corpus.py delete <corpus_name>")
            print("  python manage_rag_corpus.py cleanup")
            print("  python manage_rag_corpus.py  (interactive mode)")
    else:
        # Interactive mode
        interactive_menu()

if __name__ == "__main__":
    main()
