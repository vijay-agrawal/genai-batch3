"""
Vertex AI Vector Search - Retriever
Query vector index and generate answers using retrieved context
"""

from google.cloud import aiplatform
from google.cloud import storage
from vertexai.language_models import TextEmbeddingModel
from vertexai.generative_models import GenerativeModel
import vertexai
import json
import os
from config import (
    PROJECT_ID, LOCATION, BUCKET_NAME,
    VECTOR_SEARCH_DEPLOYED_INDEX_ID,
    EMBEDDING_MODEL, GENERATION_MODEL,
    TEMPERATURE, MAX_OUTPUT_TOKENS
)


class VectorSearchRetriever:
    """Retriever for Vertex AI Vector Search"""
    
    def __init__(self):
        self.project_id = PROJECT_ID
        self.location = LOCATION
        self.bucket_name = BUCKET_NAME
        
        # Initialize clients
        vertexai.init(project=PROJECT_ID, location=LOCATION)
        aiplatform.init(project=PROJECT_ID, location=LOCATION)
        
        self.storage_client = storage.Client(project=PROJECT_ID)
        self.embedding_model = TextEmbeddingModel.from_pretrained(EMBEDDING_MODEL)
        self.llm = GenerativeModel(GENERATION_MODEL)
        
        # Load resources
        self._load_resources()
        self._load_metadata()
    
    def _load_resources(self):
        """Load index and endpoint resource names"""
        if not os.path.exists("vector_search_resources.json"):
            raise FileNotFoundError(
                "vector_search_resources.json not found. "
                "Please run the indexer first: python vector_search_indexer.py"
            )
        
        with open("vector_search_resources.json", "r") as f:
            resources = json.load(f)
        
        self.index_name = resources["index_name"]
        self.endpoint_name = resources["endpoint_name"]
        self.deployed_index_id = resources["deployed_index_id"]
        
        print(f"Using index endpoint: {self.endpoint_name}")
        
        # Get endpoint object
        self.index_endpoint = aiplatform.MatchingEngineIndexEndpoint(
            index_endpoint_name=self.endpoint_name
        )
    
    def _load_metadata(self):
        """Load document metadata from GCS"""
        try:
            bucket = self.storage_client.bucket(self.bucket_name)
            blob = bucket.blob("vector_index/metadata.json")
            metadata_json = blob.download_as_text()
            self.metadata = json.loads(metadata_json)
            print(f"✓ Loaded metadata for {len(self.metadata)} chunks")
        except Exception as e:
            print(f"⚠ Warning: Could not load metadata: {e}")
            self.metadata = {}
    
    def embed_query(self, query):
        """Generate embedding for query"""
        try:
            embeddings = self.embedding_model.get_embeddings([query])
            return embeddings[0].values
        except Exception as e:
            print(f"✗ Error generating query embedding: {e}")
            return None
    
    def search(self, query, num_neighbors=10, filter_document_type=None):
        """
        Search for similar vectors
        
        Args:
            query: Query string
            num_neighbors: Number of nearest neighbors to return
            filter_document_type: Optional filter by document type
        """
        print(f"\nSearching for: '{query}'")
        print("-" * 60)
        
        try:
            # Generate query embedding
            query_embedding = self.embed_query(query)
            
            if query_embedding is None:
                return []
            
            # Prepare filter if specified
            filter_config = None
            if filter_document_type:
                filter_config = [
                    aiplatform.matching_engine.matching_engine_index_endpoint.Namespace(
                        name="document_type",
                        allow_tokens=[filter_document_type]
                    )
                ]
            
            # Search index
            response = self.index_endpoint.find_neighbors(
                deployed_index_id=self.deployed_index_id,
                queries=[query_embedding],
                num_neighbors=num_neighbors,
            )
            
            # Process results
            results = []
            for neighbor in response[0]:
                chunk_id = neighbor.id
                distance = neighbor.distance
                
                # Get metadata
                metadata = self.metadata.get(chunk_id, {})
                
                result = {
                    "id": chunk_id,
                    "distance": distance,
                    "metadata": metadata,
                    "text": metadata.get("text", ""),
                    "document_type": metadata.get("document_type", "unknown"),
                    "source_file": metadata.get("source_file", ""),
                }
                
                results.append(result)
            
            return results
            
        except Exception as e:
            print(f"✗ Search error: {e}")
            import traceback
            traceback.print_exc()
            return []
    
    def display_results(self, results):
        """Display search results"""
        if not results:
            print("No results found.")
            return
        
        print(f"\nFound {len(results)} result(s):\n")
        
        for i, result in enumerate(results, 1):
            print(f"{i}. [Distance: {result['distance']:.3f}]")
            print(f"   Type: {result['document_type']}")
            print(f"   Source: {result['source_file']}")
            
            # Display employee name for resumes
            if result['metadata'].get('employee_name'):
                print(f"   Employee: {result['metadata']['employee_name']}")
            
            # Display text snippet
            if result['text']:
                text_preview = result['text'][:200].replace('\n', ' ')
                print(f"   Content: {text_preview}...")
            
            print()
    
    def answer_with_rag(self, query, num_neighbors=10):
        """
        Answer query using RAG approach:
        1. Embed query
        2. Search for similar vectors
        3. Retrieve full chunks
        4. Generate answer with LLM
        """
        print("\n" + "="*60)
        print(f"Query: {query}")
        print("="*60)
        
        # Step 1: Search for relevant chunks
        results = self.search(query, num_neighbors=num_neighbors)
        
        if not results:
            return "I couldn't find any relevant information to answer your question."
        
        # Display results
        self.display_results(results)
        
        # Step 2: Prepare context
        context_parts = []
        seen_sources = set()
        
        for result in results[:5]:  # Use top 5 results
            source = result['source_file']
            
            # Add source header if not seen before
            if source not in seen_sources:
                doc_type = result['document_type'].replace('_', ' ').title()
                context_parts.append(f"\n[Source: {source} ({doc_type})]")
                seen_sources.add(source)
                
                # Add employee name for resumes
                if result['metadata'].get('employee_name'):
                    context_parts.append(f"Employee: {result['metadata']['employee_name']}")
            
            # Add chunk text
            if result['text']:
                context_parts.append(result['text'])
        
        context = "\n".join(context_parts)
        
        # Step 3: Generate answer
        prompt = f"""Based on the following retrieved information from documents, please answer the user's question.
Provide a clear, helpful answer. If the information is incomplete, acknowledge what's available.

Retrieved Information:
{context}

User Question: {query}

Answer:"""
        
        print("\n" + "="*60)
        print("Generated Answer:")
        print("="*60)
        
        try:
            response = self.llm.generate_content(
                prompt,
                generation_config={
                    "temperature": TEMPERATURE,
                    "max_output_tokens": MAX_OUTPUT_TOKENS,
                }
            )
            
            answer = response.text
            print(answer)
            return answer
            
        except Exception as e:
            print(f"✗ Error generating answer: {e}")
            return "Error generating answer."
    
    def search_by_type(self, query, document_type):
        """Search within specific document type"""
        print(f"\nSearching {document_type} for: '{query}'")
        return self.search(query, filter_document_type=document_type)
    
    def find_employees(self, query):
        """Specialized search for employee resumes"""
        print("\n" + "="*60)
        print("Employee Search")
        print("="*60)
        
        results = self.search(query, num_neighbors=15)
        
        # Filter and group by employee
        employees = {}
        for result in results:
            if result['document_type'] == 'resume':
                emp_name = result['metadata'].get('employee_name')
                if emp_name:
                    if emp_name not in employees:
                        employees[emp_name] = {
                            "name": emp_name,
                            "relevance": result['distance'],
                            "chunks": []
                        }
                    employees[emp_name]["chunks"].append(result['text'])
        
        # Sort by relevance
        sorted_employees = sorted(
            employees.values(),
            key=lambda x: x['relevance']
        )
        
        if not sorted_employees:
            print("\nNo matching employees found.")
            return []
        
        # Display results
        print(f"\nFound {len(sorted_employees)} matching employee(s):\n")
        
        for i, emp in enumerate(sorted_employees[:5], 1):
            print(f"{i}. {emp['name']}")
            print(f"   Relevance Score: {emp['relevance']:.3f}")
            
            # Show relevant excerpt
            if emp['chunks']:
                excerpt = emp['chunks'][0][:200].replace('\n', ' ')
                print(f"   Excerpt: {excerpt}...")
            print()
        
        return sorted_employees
    
    def interactive_qa(self):
        """Interactive Q&A session"""
        print("\n" + "="*80)
        print("VERTEX AI VECTOR SEARCH - INTERACTIVE Q&A")
        print("="*80)
        print("\nAsk questions about:")
        print("  • Employee skills and experience (e.g., 'recommend a Java developer')")
        print("  • Financial reports (e.g., 'what was the net profit in Q4 2024?')")
        print("  • Electricity bills (e.g., 'how much was the electricity bill in Jan 2025?')")
        print("\nType 'quit' to exit")
        print("="*80)
        
        while True:
            try:
                query = input("\n🔍 Your question: ").strip()
                
                if query.lower() in ['quit', 'exit', 'q']:
                    print("\nGoodbye!")
                    break
                
                if not query:
                    continue
                
                # Answer with RAG
                self.answer_with_rag(query)
                
            except KeyboardInterrupt:
                print("\n\nGoodbye!")
                break
            except Exception as e:
                print(f"✗ Error: {e}")
    
    def run_demo_queries(self):
        """Run predefined demo queries"""
        print("\n" + "="*80)
        print("VERTEX AI VECTOR SEARCH - DEMO QUERIES")
        print("="*80)
        
        demo_queries = [
            "recommend a Java developer with Spring Boot experience",
            "what was the net profit in Q4 2024?",
            "how much was the electricity bill in January 2025?",
            "who has machine learning skills?",
            "what were DBS Bank's total income and assets?",
            "compare electricity bills over the last 3 months",
        ]
        
        for query in demo_queries:
            self.answer_with_rag(query)
            input("\nPress Enter to continue to next query...")
        
        print("\n" + "="*80)
        print("Demo complete!")
        print("="*80)


def main():
    """Main function"""
    import sys
    
    try:
        retriever = VectorSearchRetriever()
        
        if len(sys.argv) > 1:
            if sys.argv[1] == "demo":
                # Run demo queries
                retriever.run_demo_queries()
            else:
                # Single query from command line
                query = " ".join(sys.argv[1:])
                retriever.answer_with_rag(query)
        else:
            # Interactive mode
            retriever.interactive_qa()
            
    except Exception as e:
        print(f"\n✗ Error: {e}")
        print("\nMake sure you have:")
        print("1. Run the indexer first: python vector_search_indexer.py")
        print("2. Wait for deployment to complete")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
