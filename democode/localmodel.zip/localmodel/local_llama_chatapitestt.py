import openai

# Configure OpenAI client for LM Studio
openai.api_base = "http://127.0.0.1:1234/v1"
openai.api_key = "lm-studio"  # LM Studio accepts any string as API key

# Disable SSL verification for local testing
openai.verify_ssl_certs = False

from openai import OpenAI

client = OpenAI(
    base_url="http://127.0.0.1:1234/v1",
    api_key="lm-studio"  # Can be any string for LM Studio
)

response = client.chat.completions.create(
    model="llama-3.2-3b-instruct",
    messages=[
        {"role": "user", "content": "What is the capital of France?"}
    ],
    max_tokens=150,
    temperature=0.7
)

print(response.choices[0].message.content)
