import openai

# Configure OpenAI client for LM Studio
openai.api_key = "lm-studio"  # LM Studio accepts any string as API key

# Disable SSL verification for local testing
openai.verify_ssl_certs = False

from openai import OpenAI

client = OpenAI(
    base_url="http://127.0.0.1:1234/v1",
    api_key="lm-studio"  # Can be any string for LM Studio
)

prompt = "What is the capital of France?"

print("Question: ", prompt)

print("Sending request to local LLM...")

response = client.chat.completions.create(
    model="meta-llama-3-8b-instruct",
    #model="openai/gpt-oss-20b",
    messages=[
        { "role": "system", "content": "Always answer in rhymes. Today is Thursday" },
        {"role": "user", "content": prompt}
    ],
    max_tokens=150,
    temperature=0.7
)

print(response.model_dump_json(indent=2))
print("Local LLM Response: ", response.choices[0].message.content)
#print(response["choices"][0]["message"]["content"])