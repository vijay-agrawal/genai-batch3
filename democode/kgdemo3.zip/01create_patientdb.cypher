// ---------- Uniqueness constraints (identity) ----------
CREATE CONSTRAINT patient_id IF NOT EXISTS
FOR (p:Patient) REQUIRE p.patient_id IS UNIQUE;

CREATE CONSTRAINT encounter_id IF NOT EXISTS
FOR (e:Encounter) REQUIRE e.enc_id IS UNIQUE;

CREATE CONSTRAINT diagnosis_icd10 IF NOT EXISTS
FOR (d:Diagnosis) REQUIRE d.icd10 IS UNIQUE;

CREATE CONSTRAINT medication_rxnorm IF NOT EXISTS
FOR (m:Medication) REQUIRE m.rxnorm IS UNIQUE;

CREATE CONSTRAINT provider_npi IF NOT EXISTS
FOR (pr:Provider) REQUIRE pr.npi IS UNIQUE;

CREATE CONSTRAINT facility_id IF NOT EXISTS
FOR (f:Facility) REQUIRE f.facility_id IS UNIQUE;

CREATE CONSTRAINT note_id IF NOT EXISTS
FOR (n:ClinicalNote) REQUIRE n.note_id IS UNIQUE;

// ---------- Useful indexes (search / filtering) ----------
CREATE INDEX diagnosis_name IF NOT EXISTS
FOR (d:Diagnosis) ON (d.name);

CREATE INDEX medication_name IF NOT EXISTS
FOR (m:Medication) ON (m.name);

CREATE INDEX encounter_date IF NOT EXISTS
FOR (e:Encounter) ON (e.date);


// Patient journey
//(:Patient)-[:HAD_ENCOUNTER]->(:Encounter)

// Clinical facts inside an encounter
//(:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis)
//(:Encounter)-[:PRESCRIBED]->(:Medication)
//(:Provider)-[:PROVIDED_CARE]->(:Encounter)
//(:Encounter)-[:AT_FACILITY]->(:Facility)

// Unstructured evidence
//(:ClinicalNote)-[:ABOUT_ENCOUNTER]->(:Encounter)
//(:ClinicalNote)-[:MENTIONS {method, score, mention}]->(:Diagnosis|:Medication)
