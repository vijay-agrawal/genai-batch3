// Patients
MERGE (:Patient {patient_id:'P_001', name:'Asha Mehta', dob:date('1988-02-14'), sex:'F'});
MERGE (:Patient {patient_id:'P_002', name:'Ravi Kumar', dob:date('1975-11-01'), sex:'M'});
MERGE (:Patient {patient_id:'P_003', name:'Neha Singh', dob:date('1992-07-19'), sex:'F'});

// Encounters (event nodes)
MERGE (:Encounter {enc_id:'ENC_101', date:date('2025-12-01'), reason:'Follow-up BP', bp_systolic:150, bp_diastolic:95});
MERGE (:Encounter {enc_id:'ENC_102', date:date('2025-12-03'), reason:'Hypertension review', bp_systolic:145, bp_diastolic:92});
MERGE (:Encounter {enc_id:'ENC_103', date:date('2025-12-05'), reason:'Diabetes follow-up', hba1c:8.2});

// Diagnoses (reusable concepts)
MERGE (:Diagnosis {icd10:'I10', name:'Essential (primary) hypertension'});
MERGE (:Diagnosis {icd10:'E11', name:'Type 2 diabetes mellitus'});

// Medications (reusable concepts)
MERGE (:Medication {rxnorm:'314076', name:'Amlodipine'});
MERGE (:Medication {rxnorm:'860975', name:'Metformin'});


// Patient → Encounter
MATCH (p1:Patient {patient_id:'P_001'}), (e1:Encounter {enc_id:'ENC_101'})
MERGE (p1)-[:HAD_ENCOUNTER]->(e1);

MATCH (p2:Patient {patient_id:'P_002'}), (e2:Encounter {enc_id:'ENC_102'})
MERGE (p2)-[:HAD_ENCOUNTER]->(e2);

MATCH (p3:Patient {patient_id:'P_003'}), (e3:Encounter {enc_id:'ENC_103'})
MERGE (p3)-[:HAD_ENCOUNTER]->(e3);

// Encounter → Diagnosis
MATCH (e1:Encounter {enc_id:'ENC_101'}), (dxHTN:Diagnosis {icd10:'I10'})
MERGE (e1)-[:HAS_DIAGNOSIS]->(dxHTN);

MATCH (e2:Encounter {enc_id:'ENC_102'}), (dxHTN:Diagnosis {icd10:'I10'})
MERGE (e2)-[:HAS_DIAGNOSIS]->(dxHTN);

MATCH (e3:Encounter {enc_id:'ENC_103'}), (dxDM:Diagnosis {icd10:'E11'})
MERGE (e3)-[:HAS_DIAGNOSIS]->(dxDM);

// Encounter → Medication (relationship properties allowed if needed)
MATCH (e1:Encounter {enc_id:'ENC_101'}), (aml:Medication {rxnorm:'314076'})
MERGE (e1)-[:PRESCRIBED {dose:'5mg', frequency:'OD'}]->(aml);

MATCH (e2:Encounter {enc_id:'ENC_102'}), (aml:Medication {rxnorm:'314076'})
MERGE (e2)-[:PRESCRIBED {dose:'5mg', frequency:'OD'}]->(aml);

MATCH (e3:Encounter {enc_id:'ENC_103'}), (met:Medication {rxnorm:'860975'})
MERGE (e3)-[:PRESCRIBED {dose:'500mg', frequency:'BD'}]->(met);


// Notes + entity linking
MERGE (n1:ClinicalNote {note_id:'N_901', text:'BP is high. Continue amlodipine.'});
MERGE (n2:ClinicalNote {note_id:'N_902', text:'Diabetes follow-up: metformin continued. No hypertension symptoms.'});

MATCH (n1:ClinicalNote {note_id:'N_901'}), (e2:Encounter {enc_id:'ENC_102'})
MERGE (n1)-[:ABOUT_ENCOUNTER]->(e2);

MATCH (n2:ClinicalNote {note_id:'N_902'}), (e3:Encounter {enc_id:'ENC_103'})
MERGE (n2)-[:ABOUT_ENCOUNTER]->(e3);

// Mentions (this is where scores/method go)
MATCH (n1:ClinicalNote {note_id:'N_901'}), (aml:Medication {rxnorm:'314076'})
MERGE (n1)-[:MENTIONS {mention:'amlodipine', method:'synonym_exact', score:1.0}]->(aml);

MATCH (n1:ClinicalNote {note_id:'N_901'}), (dxHTN:Diagnosis {icd10:'I10'})
MERGE (n1)-[:MENTIONS {mention:'bp is high', method:'fuzzy', score:0.91}]->(dxHTN);

MATCH (n2:ClinicalNote {note_id:'N_902'}), (met:Medication {rxnorm:'860975'})
MERGE (n2)-[:MENTIONS {mention:'metformin', method:'synonym_exact', score:1.0}]->(met);
