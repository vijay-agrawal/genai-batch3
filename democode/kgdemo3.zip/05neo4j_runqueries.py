"""
citius_neo4j_nl2cypher_demo.py

- Connects to Neo4j using the official neo4j Python driver
- Runs 5 practical queries from the Citius healthcare schema
- Converts some outputs to nested JSON (GraphRAG-ready)
- Converts some outputs to pandas DataFrames (analytics-ready)

Install:
  pip install neo4j pandas

Env vars (recommended):
  NEO4J_URI=bolt://localhost:7687
  NEO4J_USER=neo4j
  NEO4J_PASSWORD=neo4j_password
"""

from __future__ import annotations

import os
import json
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from neo4j import GraphDatabase
from dotenv import load_dotenv


# -----------------------------
# Cypher queries (5)
# -----------------------------

Q1_PATIENT_SUMMARY = """
MATCH (p:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e:Encounter)
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
OPTIONAL MATCH (e)-[pr:PRESCRIBED]->(m:Medication)
OPTIONAL MATCH (n:ClinicalNote)-[:ABOUT_ENCOUNTER]->(e)
WITH p, e,
     collect(DISTINCT {icd10:d.icd10, name:d.name}) AS diagnoses,
     collect(DISTINCT {rxnorm:m.rxnorm, name:m.name, dose:pr.dose, frequency:pr.frequency}) AS meds,
     collect(DISTINCT {note_id:n.note_id, snippet:substring(n.text,0,160)}) AS notes
ORDER BY e.date DESC
WITH p, collect({
  enc_id:e.enc_id, date:e.date, reason:e.reason,
  bp_systolic:e.bp_systolic, bp_diastolic:e.bp_diastolic, hba1c:e.hba1c,
  diagnoses:diagnoses, medications:meds, notes:notes
})[0..$limit] AS last_encounters
RETURN {
  patient: {patient_id:p.patient_id, name:p.name, dob:p.dob, sex:p.sex},
  encounters: last_encounters
} AS patient_summary;
"""

Q2_NEWLY_HTN_LAST_N_DAYS = """
MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:$icd10})
WHERE e.date >= date() - duration({days:$days})
WITH p, min(e.date) AS first_dx_date
OPTIONAL MATCH (p)-[:HAD_ENCOUNTER]->(e2:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:$icd10})
WHERE e2.date < first_dx_date
WITH p, first_dx_date, count(e2) AS prior_count
WHERE prior_count = 0
RETURN p.patient_id AS patient_id, p.name AS name, first_dx_date AS first_dx_date
ORDER BY first_dx_date DESC;
"""

Q3_FACILITY_TOP_DX_LAST_30_DAYS = """
MATCH (f:Facility)<-[:AT_FACILITY]-(e:Encounter)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
WHERE e.date >= date() - duration({days:$days})
RETURN f.facility_id AS facility_id, f.name AS facility_name,
       d.icd10 AS icd10, d.name AS diagnosis_name,
       count(*) AS dx_count
ORDER BY facility_id, dx_count DESC;
"""

Q4_PROVIDER_TOP_PATTERNS = """
MATCH (pr:Provider {npi:$npi})-[:PROVIDED_CARE]->(e:Encounter)
MATCH (e)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
MATCH (e)-[:PRESCRIBED]->(m:Medication)
WITH d, m, count(*) AS c
ORDER BY c DESC
RETURN collect({
  icd10:d.icd10, diagnosis:d.name,
  rxnorm:m.rxnorm, medication:m.name,
  count:c
})[0..$topk] AS top_patterns;
"""

Q5_CONFIRMED_VS_MENTIONED_EVIDENCE = """
MATCH (p:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e:Encounter)
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(dx:Diagnosis {icd10:$icd10})
OPTIONAL MATCH (n:ClinicalNote)-[:ABOUT_ENCOUNTER]->(e)
OPTIONAL MATCH (n)-[mn:MENTIONS]->(dxm:Diagnosis {icd10:$icd10})
WITH p, e, dx, n, mn
ORDER BY e.date DESC
WITH p,
     collect(DISTINCT {
       enc_id:e.enc_id, date:e.date, reason:e.reason,
       confirmed: dx IS NOT NULL
     }) AS encounter_confirmation,
     collect(DISTINCT {
       note_id:n.note_id,
       mention: mn.mention,
       method: mn.method,
       score: mn.score
     }) AS mentions
RETURN {
  patient_id: p.patient_id,
  condition: $icd10,
  encounter_confirmation: encounter_confirmation,
  note_mentions: [m IN mentions WHERE m.note_id IS NOT NULL]
} AS evidence;
"""


# -----------------------------
# Helpers: Neo4j result -> Python types safe for JSON
# -----------------------------

def _json_safe(obj: Any) -> Any:
    """Recursively convert Neo4j temporal types and other non-JSON values."""
    # Neo4j date/time objects typically implement iso_format() or str() well
    if hasattr(obj, "iso_format"):
        try:
            return obj.iso_format()
        except Exception:
            return str(obj)

    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}

    if isinstance(obj, (list, tuple)):
        return [_json_safe(x) for x in obj]

    return obj


def run_query(driver, cypher: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Run a Cypher query and return list of dict rows."""
    params = params or {}
    with driver.session() as session:
        result = session.run(cypher, **params)
        rows = result.data()  # list[dict]
    return _json_safe(rows)


def first_value(rows: List[Dict[str, Any]], key: str) -> Any:
    """Convenience: return the first row's key value (or None)."""
    if not rows:
        return None
    return rows[0].get(key)


def to_dataframe(rows: List[Dict[str, Any]]) -> pd.DataFrame:
    """Convert list-of-dict rows into a pandas DataFrame."""
    return pd.DataFrame(rows)


# -----------------------------
# Demo runner
# -----------------------------

def main() -> None:

    load_dotenv()  # loads variables from .env  
    NEO4J_URI = os.getenv("NEO4J_URI")
    NEO4J_USER = os.getenv("NEO4J_USER")
    NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")
    if not all([NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD]):
        raise ValueError("❌ Missing one or more Neo4j env variables")

    driver = GraphDatabase.driver(
        NEO4J_URI,
        auth=(NEO4J_USER, NEO4J_PASSWORD)
    )

    # Example inputs (edit for your dataset)
    pid = os.getenv("DEMO_PID", "P_001")
    icd10 = os.getenv("DEMO_ICD10", "I10")       # Hypertension
    npi = os.getenv("DEMO_NPI", "12345")         # Example provider NPI

    try:
        # 1) Nested JSON: Patient Summary
        rows = run_query(driver, Q1_PATIENT_SUMMARY, {"pid": pid, "limit": 5})
        patient_summary = first_value(rows, "patient_summary")
        print("\n=== 1) Patient Summary (Nested JSON) ===")
        print(json.dumps(patient_summary, indent=2))

        # 2) DataFrame: Newly diagnosed HTN in last 90 days
        rows = run_query(driver, Q2_NEWLY_HTN_LAST_N_DAYS, {"icd10": icd10, "days": 90})
        df_new = to_dataframe(rows)
        print("\n=== 2) Newly Diagnosed (DataFrame preview) ===")
        print(df_new.head(10).to_string(index=False))

        # 3) DataFrame: Facility diagnosis trends (last 30 days)
        rows = run_query(driver, Q3_FACILITY_TOP_DX_LAST_30_DAYS, {"days": 30})
        df_fac = to_dataframe(rows)
        print("\n=== 3) Facility Dx Trends (DataFrame preview) ===")
        print(df_fac.head(10).to_string(index=False))

        # 4) Nested JSON (or DF if you want): Provider patterns
        rows = run_query(driver, Q4_PROVIDER_TOP_PATTERNS, {"npi": npi, "topk": 10})
        patterns = first_value(rows, "top_patterns") or []
        print("\n=== 4) Provider Top Patterns (Nested JSON) ===")
        print(json.dumps({"npi": npi, "top_patterns": patterns}, indent=2))

        # Optionally convert patterns to DataFrame
        df_patterns = pd.DataFrame(patterns)
        print("\n=== 4b) Provider Top Patterns (DataFrame preview) ===")
        print(df_patterns.head(10).to_string(index=False))

        # 5) Nested JSON: Confirmed vs Mentioned evidence
        rows = run_query(driver, Q5_CONFIRMED_VS_MENTIONED_EVIDENCE, {"pid": pid, "icd10": icd10})
        evidence = first_value(rows, "evidence")
        print("\n=== 5) Confirmed vs Mentioned Evidence (Nested JSON) ===")
        print(json.dumps(evidence, indent=2))

    finally:
        driver.close()

if __name__ == "__main__":
    main()
