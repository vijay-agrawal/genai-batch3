"""
graphrag.py  (Neo4j + GraphRAG + Azure OpenAI)

What this does:
- Takes a natural-language healthcare question
- Detects anchors (patient_id, icd10 condition, provider npi, facility)
- Routes to 1+ Cypher queries (Neo4j) to build an Evidence Pack (nested JSON)
- Calls Azure OpenAI chat completion with a *grounded* prompt:
  - The LLM MUST answer using only the Evidence Pack
  - Outputs an answer + citations using [enc:ENC_...] and [note:N_...]

Prereqs:
  pip install neo4j pandas python-dotenv openai

Env vars needed:
  # Neo4j
  NEO4J_URI=bolt://localhost:7687
  NEO4J_USER=neo4j
  NEO4J_PASSWORD=your_password

  # Azure OpenAI
  AZURE_OPENAI_ENDPOINT=...
  AZURE_OPENAI_API_KEY=...
  AZURE_OPENAI_API_VERSION=...
  AZURE_OPENAI_MODEL_NAME=...

Optional:
  DEMO_PID=P_001
  DEMO_NPI=12345
"""

from __future__ import annotations

import os
import re
import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from dotenv import load_dotenv
from neo4j import GraphDatabase
from openai import AzureOpenAI

load_dotenv()


# -----------------------------
# Cypher queries (same schema as discussed)
# -----------------------------

Q_PATIENT_SUMMARY = """
MATCH (p:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e:Encounter)
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
OPTIONAL MATCH (e)-[pr:PRESCRIBED]->(m:Medication)
OPTIONAL MATCH (n:ClinicalNote)-[:ABOUT_ENCOUNTER]->(e)
WITH p, e,
     collect(DISTINCT {icd10:d.icd10, name:d.name}) AS diagnoses,
     collect(DISTINCT {rxnorm:m.rxnorm, name:m.name, dose:pr.dose, frequency:pr.frequency}) AS meds,
     collect(DISTINCT {note_id:n.note_id, snippet:substring(n.text,0,160)}) AS notes
ORDER BY e.date DESC
WITH p, collect({
  enc_id:e.enc_id, date:e.date, reason:e.reason,
  bp_systolic:e.bp_systolic, bp_diastolic:e.bp_diastolic, hba1c:e.hba1c,
  diagnoses:diagnoses, medications:meds, notes:notes
})[0..$limit] AS last_encounters
RETURN {
  patient: {patient_id:p.patient_id, name:p.name, dob:p.dob, sex:p.sex},
  encounters: last_encounters
} AS patient_summary;
"""

Q_CONFIRMED_VS_MENTIONED_EVIDENCE = """
MATCH (p:Patient {patient_id:$pid})-[:HAD_ENCOUNTER]->(e:Encounter)
OPTIONAL MATCH (e)-[:HAS_DIAGNOSIS]->(dx:Diagnosis {icd10:$icd10})
OPTIONAL MATCH (n:ClinicalNote)-[:ABOUT_ENCOUNTER]->(e)
OPTIONAL MATCH (n)-[mn:MENTIONS]->(dxm:Diagnosis {icd10:$icd10})
WITH p, e, dx, n, mn
ORDER BY e.date DESC
WITH p,
     collect(DISTINCT {
       enc_id:e.enc_id, date:e.date, reason:e.reason,
       confirmed: dx IS NOT NULL
     }) AS encounter_confirmation,
     collect(DISTINCT {
       note_id:n.note_id,
       mention: mn.mention,
       method: mn.method,
       score: mn.score
     }) AS mentions
RETURN {
  patient_id: p.patient_id,
  condition: $icd10,
  encounter_confirmation: encounter_confirmation,
  note_mentions: [m IN mentions WHERE m.note_id IS NOT NULL]
} AS evidence;
"""

Q_NEWLY_DIAGNOSED = """
MATCH (p:Patient)-[:HAD_ENCOUNTER]->(e:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:$icd10})
WHERE e.date >= date() - duration({days:$days})
WITH p, min(e.date) AS first_dx_date
OPTIONAL MATCH (p)-[:HAD_ENCOUNTER]->(e2:Encounter)-[:HAS_DIAGNOSIS]->(:Diagnosis {icd10:$icd10})
WHERE e2.date < first_dx_date
WITH p, first_dx_date, count(e2) AS prior_count
WHERE prior_count = 0
RETURN p.patient_id AS patient_id, p.name AS name, first_dx_date AS first_dx_date
ORDER BY first_dx_date DESC;
"""

Q_FACILITY_TOP_DX = """
MATCH (f:Facility)<-[:AT_FACILITY]-(e:Encounter)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
WHERE e.date >= date() - duration({days:$days})
RETURN f.facility_id AS facility_id, f.name AS facility_name,
       d.icd10 AS icd10, d.name AS diagnosis_name,
       count(*) AS dx_count
ORDER BY facility_id, dx_count DESC;
"""

Q_PROVIDER_TOP_PATTERNS = """
MATCH (pr:Provider {npi:$npi})-[:PROVIDED_CARE]->(e:Encounter)
MATCH (e)-[:HAS_DIAGNOSIS]->(d:Diagnosis)
MATCH (e)-[:PRESCRIBED]->(m:Medication)
WITH d, m, count(*) AS c
ORDER BY c DESC
RETURN collect({
  icd10:d.icd10, diagnosis:d.name,
  rxnorm:m.rxnorm, medication:m.name,
  count:c
})[0..$topk] AS top_patterns;
"""


# -----------------------------
# Utilities: JSON safety + Neo4j runner
# -----------------------------

def _json_safe(obj: Any) -> Any:
    if hasattr(obj, "iso_format"):
        try:
            return obj.iso_format()
        except Exception:
            return str(obj)
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(x) for x in obj]
    return obj


def run_query(driver, cypher: str, params: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    params = params or {}
    with driver.session() as session:
        rows = session.run(cypher, **params).data()
    return _json_safe(rows)


def first_value(rows: List[Dict[str, Any]], key: str) -> Any:
    return rows[0].get(key) if rows else None


# -----------------------------
# Anchor detection + routing
# -----------------------------

@dataclass
class Anchors:
    patient_id: Optional[str] = None
    icd10: Optional[str] = None
    npi: Optional[str] = None
    facility_id: Optional[str] = None


def detect_anchors(question: str) -> Anchors:
    q = question.strip()

    pid = None
    m = re.search(r"\bP_\d+\b", q, flags=re.IGNORECASE)
    if m:
        pid = m.group(0).upper()

    # ICD10 patterns like I10, E11, J45, etc. (very simplified)
    icd10 = None
    m = re.search(r"\b([A-TV-Z]\d{2}(?:\.\d+)?)\b", q, flags=re.IGNORECASE)
    if m:
        icd10 = m.group(1).upper()

    # Provider NPI (example: NPI 12345 or npi:12345)
    npi = None
    m = re.search(r"\bNPI[:\s]+(\d{5,15})\b", q, flags=re.IGNORECASE)
    if m:
        npi = m.group(1)

    # Facility id (example: FAC_001)
    facility_id = None
    m = re.search(r"\bFAC_\d+\b", q, flags=re.IGNORECASE)
    if m:
        facility_id = m.group(0).upper()

    return Anchors(patient_id=pid, icd10=icd10, npi=npi, facility_id=facility_id)


def route(question: str, anchors: Anchors) -> str:
    q = question.lower()

    # Evidence/grounding questions
    if any(k in q for k in ["confirm", "actually have", "evidence", "mentioned", "mention", "rule out", "ruled out"]):
        return "EVIDENCE"

    # Patient summary questions
    if any(k in q for k in ["summary", "snapshot", "history", "last encounters", "overview"]):
        return "PATIENT_SUMMARY"

    # Provider patterns
    if any(k in q for k in ["provider", "doctor", "npi", "prescrib", "pattern"]):
        return "PROVIDER_PATTERNS"

    # Facility trends
    if any(k in q for k in ["facility", "hospital", "site", "center", "trends", "top diagnoses"]):
        return "FACILITY_TRENDS"

    # Newly diagnosed cohort
    if any(k in q for k in ["newly", "first time", "recently diagnosed", "new diagnosis", "last 90"]):
        return "NEWLY_DIAGNOSED"

    # Default: if patient present, give summary
    if anchors.patient_id:
        return "PATIENT_SUMMARY"

    # Otherwise: facility trends as a safe default insight
    return "FACILITY_TRENDS"


# -----------------------------
# Evidence pack builder
# -----------------------------

def build_evidence_pack(driver, question: str) -> Dict[str, Any]:
    anchors = detect_anchors(question)
    intent = route(question, anchors)

    evidence: Dict[str, Any] = {
        "question": question,
        "intent": intent,
        "anchors": {k: v for k, v in anchors.__dict__.items() if v},
        "facts": {},
        "provenance": {"source": "neo4j", "queries_used": []},
    }

    # Helpers for defaults
    default_pid = os.getenv("DEMO_PID", "P_001")
    default_npi = os.getenv("DEMO_NPI", "12345")

    if intent == "PATIENT_SUMMARY":
        pid = anchors.patient_id or default_pid
        rows = run_query(driver, Q_PATIENT_SUMMARY, {"pid": pid, "limit": 5})
        evidence["facts"]["patient_summary"] = first_value(rows, "patient_summary")
        evidence["provenance"]["queries_used"].append("Q_PATIENT_SUMMARY")

    elif intent == "EVIDENCE":
        pid = anchors.patient_id or default_pid
        icd10 = anchors.icd10 or "I10"
        rows = run_query(driver, Q_CONFIRMED_VS_MENTIONED_EVIDENCE, {"pid": pid, "icd10": icd10})
        evidence["facts"]["condition_evidence"] = first_value(rows, "evidence")
        evidence["provenance"]["queries_used"].append("Q_CONFIRMED_VS_MENTIONED_EVIDENCE")

        # Often useful to attach a mini patient snapshot too (for context)
        rows2 = run_query(driver, Q_PATIENT_SUMMARY, {"pid": pid, "limit": 3})
        evidence["facts"]["patient_summary_brief"] = first_value(rows2, "patient_summary")
        evidence["provenance"]["queries_used"].append("Q_PATIENT_SUMMARY")

    elif intent == "NEWLY_DIAGNOSED":
        icd10 = anchors.icd10 or "I10"
        rows = run_query(driver, Q_NEWLY_DIAGNOSED, {"icd10": icd10, "days": 90})
        evidence["facts"]["newly_diagnosed_patients"] = rows  # list of rows
        evidence["provenance"]["queries_used"].append("Q_NEWLY_DIAGNOSED")

    elif intent == "FACILITY_TRENDS":
        rows = run_query(driver, Q_FACILITY_TOP_DX, {"days": 30})
        evidence["facts"]["facility_top_diagnoses_30d"] = rows
        evidence["provenance"]["queries_used"].append("Q_FACILITY_TOP_DX")

    elif intent == "PROVIDER_PATTERNS":
        npi = anchors.npi or default_npi
        rows = run_query(driver, Q_PROVIDER_TOP_PATTERNS, {"npi": npi, "topk": 10})
        evidence["facts"]["provider_top_patterns"] = {"npi": npi, "top_patterns": first_value(rows, "top_patterns") or []}
        evidence["provenance"]["queries_used"].append("Q_PROVIDER_TOP_PATTERNS")

    else:
        # Safe fallback
        rows = run_query(driver, Q_FACILITY_TOP_DX, {"days": 30})
        evidence["facts"]["facility_top_diagnoses_30d"] = rows
        evidence["provenance"]["queries_used"].append("Q_FACILITY_TOP_DX")

    return evidence


# -----------------------------
# Azure OpenAI grounded answer generator
# -----------------------------

def call_azure_openai_grounded(question: str, evidence_pack: Dict[str, Any]) -> str:
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    )
    model_name = os.getenv("AZURE_OPENAI_MODEL_NAME")

    system = """
You are a clinical analytics assistant for a healthcare setting.
You MUST answer using ONLY the provided EVIDENCE PACK JSON.
If the evidence pack does not contain enough information, say: "Insufficient evidence in the evidence pack."
You MUST include citations wherever you state facts, using these formats:
- Encounter citation: [enc:ENC_...]
- Note citation: [note:N_...]
- Diagnosis citation: [dx:ICD10]
- Medication citation: [med:RXNORM]

Do NOT invent encounter IDs or note IDs.
Do NOT use outside medical knowledge beyond what is present in the evidence pack.
Keep the answer concise and structured.
"""

    user = f"""
QUESTION:
{question}

EVIDENCE PACK (JSON):
{json.dumps(evidence_pack, indent=2)}
"""

    response = client.chat.completions.create(
        model=model_name,
        temperature=0,
        max_tokens=900,
        messages=[
            {"role": "system", "content": system.strip()},
            {"role": "user", "content": user.strip()},
        ],
    )
    return response.choices[0].message.content.strip()


# -----------------------------
# Optional: DataFrames for analytics views
# -----------------------------

def maybe_make_dataframes(evidence_pack: Dict[str, Any]) -> Dict[str, pd.DataFrame]:
    dfs: Dict[str, pd.DataFrame] = {}

    intent = evidence_pack.get("intent")
    facts = evidence_pack.get("facts", {})

    if intent in ("NEWLY_DIAGNOSED",):
        rows = facts.get("newly_diagnosed_patients", [])
        dfs["newly_diagnosed_patients"] = pd.DataFrame(rows)

    if intent in ("FACILITY_TRENDS",):
        rows = facts.get("facility_top_diagnoses_30d", [])
        dfs["facility_top_diagnoses_30d"] = pd.DataFrame(rows)

    if intent in ("PROVIDER_PATTERNS",):
        patterns = facts.get("provider_top_patterns", {}).get("top_patterns", [])
        dfs["provider_top_patterns"] = pd.DataFrame(patterns)

    return dfs


# -----------------------------
# CLI runner
# -----------------------------

def main() -> None:
    # Neo4j connection
    neo4j_uri = os.getenv("NEO4J_URI", "bolt://localhost:7687")
    neo4j_user = os.getenv("NEO4J_USER", "neo4j")
    neo4j_password = os.getenv("NEO4J_PASSWORD", "")

    if not neo4j_password:
        raise RuntimeError("NEO4J_PASSWORD env var is missing.")

    driver = GraphDatabase.driver(neo4j_uri, auth=(neo4j_user, neo4j_password))

    try:
        print("\nGraphRAG Runner (Neo4j + Azure OpenAI)\n")
        print("Examples you can try:")
        print("  - 'Show patient summary for P_001'")
        print("  - 'Does patient P_002 actually have I10? show evidence'")
        print("  - 'List newly diagnosed I10 patients in last 90 days'")
        print("  - 'For provider NPI 12345 show prescribing patterns'")
        print("  - 'Facility trends: top diagnoses in last 30 days'\n")

        question = input("Ask a question: ").strip()
        if not question:
            question = "Does patient P_001 actually have I10? Show evidence."

        evidence_pack = build_evidence_pack(driver, question)

        print("\n--- Evidence Pack (retrieved from Neo4j) ---")
        print(json.dumps(evidence_pack, indent=2))

        # Optional dataframes
        dfs = maybe_make_dataframes(evidence_pack)
        if dfs:
            print("\n--- DataFrame previews ---")
            for name, df in dfs.items():
                print(f"\n[{name}]")
                if df.empty:
                    print("(empty)")
                else:
                    print(df.head(10).to_string(index=False))

        # Grounded generation
        print("\n--- Grounded Answer (Azure OpenAI) ---")
        answer = call_azure_openai_grounded(question, evidence_pack)
        print(answer)

    finally:
        driver.close()


if __name__ == "__main__":
    main()
