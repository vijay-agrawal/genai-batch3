from langchain_google_vertexai import ChatVertexAI
from langchain_google_community import VertexAISearchRetriever

def simple_rag_query(question, project_id, search_engine_id):
    """Simple RAG without complex chains"""
    
    # Initialize retriever
    retriever = VertexAISearchRetriever(
        project_id=project_id,
        search_engine_id=search_engine_id,
        location_id="global",
        max_documents=5,
    )
    
    # Initialize LLM
    llm = ChatVertexAI(model_name="gemini-pro")
    
    # Retrieve documents
    docs = retriever.get_relevant_documents(question)
    
    # Build context
    context = "\n\n".join([doc.page_content for doc in docs])
    
    # Build prompt
    full_prompt = f"""Based on the context below, answer the question.

Context:
{context}

Question: {question}

Answer:"""
    
    # Get answer
    response = llm.invoke(full_prompt)
    
    return response.content, docs

# Usage
answer, sources = simple_rag_query(
    question="What is the main topic?",
    project_id="your-project-id",
    search_engine_id="your-search-engine-id"
)

print("Answer:", answer)
print("\nSources:", len(sources))