from langchain_google_community import VertexAISearchRetriever
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import TextLoader
from google.cloud import discoveryengine_v1beta as discoveryengine
from google.api_core.client_options import ClientOptions

class VertexAISearchIndexer:
    def __init__(self, project_id: str, location: str, data_store_id: str):
        self.project_id = project_id
        self.location = location
        self.data_store_id = data_store_id
        
        client_options = ClientOptions(
            api_endpoint=f"{location}-discoveryengine.googleapis.com"
        )
        self.client = discoveryengine.DocumentServiceClient(client_options=client_options)
        self.parent = f"projects/{project_id}/locations/{location}/dataStores/{data_store_id}/branches/default_branch"
    
    def index_document(self, doc_id: str, content: str, metadata: dict = None):
        """Index a single document"""
        struct_data = {
            "content": content,
            **(metadata or {})
        }
        
        document = discoveryengine.Document(
            id=doc_id,
            struct_data=struct_data
        )
        
        request = discoveryengine.CreateDocumentRequest(
            parent=self.parent,
            document=document,
            document_id=doc_id
        )
        
        response = self.client.create_document(request=request)
        return response
    
    def index_documents_batch(self, documents: list):
        """Index multiple documents"""
        for i, doc in enumerate(documents):
            doc_id = doc.get("id", f"doc-{i}")
            content = doc.get("content", "")
            metadata = doc.get("metadata", {})
            
            self.index_document(doc_id, content, metadata)
            print(f"Indexed document: {doc_id}")
    
    def delete_document(self, doc_id: str):
        """Delete a document from the index"""
        name = f"{self.parent}/documents/{doc_id}"
        request = discoveryengine.DeleteDocumentRequest(name=name)
        self.client.delete_document(request=request)
        print(f"Deleted document: {doc_id}")

# Usage example
indexer = VertexAISearchIndexer(
    project_id="your-project-id",
    location="global",
    data_store_id="your-data-store-id"
)

# Index a single document
indexer.index_document(
    doc_id="doc-001",
    content="This is my document content to be indexed",
    metadata={
        "title": "My Document",
        "category": "technical",
        "author": "John Doe"
    }
)

# Index multiple documents
documents = [
    {
        "id": "doc-002",
        "content": "Content of document 2",
        "metadata": {"title": "Doc 2", "category": "sales"}
    },
    {
        "id": "doc-003",
        "content": "Content of document 3",
        "metadata": {"title": "Doc 3", "category": "marketing"}
    }
]

indexer.index_documents_batch(documents)