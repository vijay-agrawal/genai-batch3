from google.cloud import discoveryengine_v1beta as discoveryengine
from google.api_core.client_options import ClientOptions

# Initialize the client
project_id = "your-project-id"
location = "global"  # or "us", "eu"
data_store_id = "your-data-store-id"

client_options = ClientOptions(
    api_endpoint=f"{location}-discoveryengine.googleapis.com"
)

client = discoveryengine.DocumentServiceClient(client_options=client_options)

# Parent path for documents
parent = f"projects/{project_id}/locations/{location}/dataStores/{data_store_id}/branches/default_branch"

# Create and index a document
document = discoveryengine.Document(
    id="doc-001",
    struct_data={
        "title": "Example Document",
        "content": "This is the document content that will be indexed",
        "category": "documentation",
        "url": "https://example.com/doc1"
    }
)

request = discoveryengine.CreateDocumentRequest(
    parent=parent,
    document=document,
    document_id="doc-001"
)

response = client.create_document(request=request)
print(f"Document created: {response.name}")