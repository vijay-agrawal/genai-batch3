#!/usr/bin/env python3
"""
Complete Vertex AI Search Indexer with Local File Support
"""

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from google.cloud import discoveryengine_v1beta as discoveryengine
from google.api_core.client_options import ClientOptions
import uuid
import os

class VertexAISearchIndexer:
    """Indexer for Vertex AI Search"""
    
    def __init__(self, project_id: str, location: str, data_store_id: str):
        self.project_id = project_id
        self.location = location
        self.data_store_id = data_store_id
        
        client_options = ClientOptions(
            api_endpoint=f"{location}-discoveryengine.googleapis.com"
        )
        self.client = discoveryengine.DocumentServiceClient(client_options=client_options)
        self.parent = f"projects/{project_id}/locations/{location}/dataStores/{data_store_id}/branches/default_branch"
    
    def index_document(self, doc_id: str, content: str, metadata: dict = None):
        """Index a single document"""
        struct_data = {
            "content": content,
            **(metadata or {})
        }
        
        document = discoveryengine.Document(
            id=doc_id,
            struct_data=struct_data
        )
        
        request = discoveryengine.CreateDocumentRequest(
            parent=self.parent,
            document=document,
            document_id=doc_id
        )
        
        try:
            response = self.client.create_document(request=request)
            print(f"✓ Indexed: {doc_id}")
            return response
        except Exception as e:
            print(f"✗ Error indexing {doc_id}: {e}")
            return None
    
    def index_from_directory(self, directory_path: str, file_pattern: str = "**/*.txt"):
        """Load and index documents from a directory"""
        print(f"\nLoading documents from {directory_path}...")
        
        # Load documents
        loader = DirectoryLoader(directory_path, glob=file_pattern, loader_cls=TextLoader)
        documents = loader.load()
        print(f"Loaded {len(documents)} documents")
        
        # Split documents into chunks
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
        splits = text_splitter.split_documents(documents)
        print(f"Split into {len(splits)} chunks")
        
        # Index each chunk
        print("\nIndexing chunks...")
        for i, split in enumerate(splits):
            doc_id = f"{os.path.basename(split.metadata.get('source', 'unknown'))}-chunk-{i}"
            self.index_document(
                doc_id=doc_id,
                content=split.page_content,
                metadata={
                    "source": split.metadata.get("source", ""),
                    "chunk_index": i,
                    **split.metadata
                }
            )
        
        print(f"\n✓ Indexing complete! Indexed {len(splits)} chunks from {len(documents)} documents")

# Main execution
if __name__ == "__main__":
    # Configuration
    PROJECT_ID = "your-project-id"
    LOCATION = "global"
    DATA_STORE_ID = "your-data-store-id"
    DOCUMENTS_PATH = "./documents"
    
    # Create indexer instance
    print("Initializing Vertex AI Search Indexer...")
    indexer = VertexAISearchIndexer(
        project_id=PROJECT_ID,
        location=LOCATION,
        data_store_id=DATA_STORE_ID
    )
    
    # Index documents from directory
    indexer.index_from_directory(DOCUMENTS_PATH)
    
    # Or index a single document
    # indexer.index_document(
    #     doc_id="test-doc-001",
    #     content="This is a test document",
    #     metadata={"title": "Test", "type": "example"}
    # )