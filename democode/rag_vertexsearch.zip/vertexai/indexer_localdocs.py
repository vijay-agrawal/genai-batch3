from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from google.cloud import discoveryengine_v1beta as discoveryengine
from google.api_core.client_options import ClientOptions
import uuid

# Step 1: Create the Indexer class (from Option 3)
class VertexAISearchIndexer:
    def __init__(self, project_id: str, location: str, data_store_id: str):
        self.project_id = project_id
        self.location = location
        self.data_store_id = data_store_id
        
        client_options = ClientOptions(
            api_endpoint=f"{location}-discoveryengine.googleapis.com"
        )
        self.client = discoveryengine.DocumentServiceClient(client_options=client_options)
        self.parent = f"projects/{project_id}/locations/{location}/dataStores/{data_store_id}/branches/default_branch"
    
    def index_document(self, doc_id: str, content: str, metadata: dict = None):
        """Index a single document"""
        struct_data = {
            "content": content,
            **(metadata or {})
        }
        
        document = discoveryengine.Document(
            id=doc_id,
            struct_data=struct_data
        )
        
        request = discoveryengine.CreateDocumentRequest(
            parent=self.parent,
            document=document,
            document_id=doc_id
        )
        
        response = self.client.create_document(request=request)
        return response
    
    def index_documents_batch(self, documents: list):
        """Index multiple documents"""
        for i, doc in enumerate(documents):
            doc_id = doc.get("id", f"doc-{i}")
            content = doc.get("content", "")
            metadata = doc.get("metadata", {})
            
            self.index_document(doc_id, content, metadata)
            print(f"Indexed document: {doc_id}")
    
    def delete_document(self, doc_id: str):
        """Delete a document from the index"""
        name = f"{self.parent}/documents/{doc_id}"
        request = discoveryengine.DeleteDocumentRequest(name=name)
        self.client.delete_document(request=request)
        print(f"Deleted document: {doc_id}")

# Step 2: Function to index from directory
def index_from_directory(indexer, directory_path: str):
    """Load and index documents from a directory"""
    # Load documents
    loader = DirectoryLoader(directory_path, glob="**/*.txt", loader_cls=TextLoader)
    documents = loader.load()
    
    # Split documents into chunks
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )
    splits = text_splitter.split_documents(documents)
    
    # Index each chunk
    for split in splits:
        doc_id = str(uuid.uuid4())
        indexer.index_document(
            doc_id=doc_id,
            content=split.page_content,
            metadata={
                "source": split.metadata.get("source", ""),
                **split.metadata
            }
        )
        print(f"Indexed chunk: {doc_id}")

# Step 3: CREATE THE INDEXER and use it
if __name__ == "__main__":
    # Initialize the indexer
    indexer = VertexAISearchIndexer(
        project_id="your-project-id",
        location="global",  # or "us", "eu"
        data_store_id="your-data-store-id"
    )
    
    # Index documents from a directory
    index_from_directory(indexer, "./documents")
    
    # Or index a single document directly
    indexer.index_document(
        doc_id="manual-doc-001",
        content="This is a manually added document",
        metadata={
            "title": "Manual Document",
            "category": "test",
            "date": "2025-11-08"
        }
    )