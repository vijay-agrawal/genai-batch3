from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_vertexai import ChatVertexAI
from langchain_google_community import VertexAISearchRetriever

# Setup retriever
retriever = VertexAISearchRetriever(
    project_id="your-project-id",
    search_engine_id="your-search-engine-id",
    location_id="global",
)

# Setup LLM
llm = ChatVertexAI(model_name="gemini-pro")

# Create prompt
system_prompt = (
    "You are an assistant for question-answering tasks. "
    "Use the following pieces of retrieved context to answer "
    "the question. If you don't know the answer, say that you "
    "don't know. Use three sentences maximum and keep the "
    "answer concise."
    "\n\n"
    "{context}"
)

prompt = ChatPromptTemplate.from_messages([
    ("system", system_prompt),
    ("human", "{input}"),
])

# Create chains
question_answer_chain = create_stuff_documents_chain(llm, prompt)
rag_chain = create_retrieval_chain(retriever, question_answer_chain)

# Use it
response = rag_chain.invoke({"input": "What is the main topic?"})
print(response["answer"])
print("\nSources:")
for doc in response["context"]:
    print(f"- {doc.page_content[:100]}...")