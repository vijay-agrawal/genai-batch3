from google.cloud import discoveryengine_v1beta as discoveryengine
from google.api_core.client_options import ClientOptions

def index_documents_from_gcs(
    project_id: str,
    location: str,
    data_store_id: str,
    gcs_uri: str  # e.g., "gs://your-bucket/documents/*.json"
):
    client_options = ClientOptions(
        api_endpoint=f"{location}-discoveryengine.googleapis.com"
    )
    
    client = discoveryengine.DocumentServiceClient(client_options=client_options)
    
    parent = f"projects/{project_id}/locations/{location}/dataStores/{data_store_id}/branches/default_branch"
    
    # Import documents from GCS
    request = discoveryengine.ImportDocumentsRequest(
        parent=parent,
        gcs_source=discoveryengine.GcsSource(
            input_uris=[gcs_uri],
            data_schema="content"  # or "custom", "csv"
        ),
        reconciliation_mode=discoveryengine.ImportDocumentsRequest.ReconciliationMode.INCREMENTAL
    )
    
    operation = client.import_documents(request=request)
    print(f"Import operation started: {operation.operation.name}")
    
    # Wait for operation to complete (optional)
    response = operation.result()
    print(f"Import completed: {response}")

# Usage
index_documents_from_gcs(
    project_id="your-project-id",
    location="global",
    data_store_id="your-data-store-id",
    gcs_uri="gs://your-bucket/documents/*.jsonl"
)