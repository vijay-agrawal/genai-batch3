from langchain_google_vertexai import ChatVertexAI
from langchain_google_community import VertexAISearchRetriever

class SimpleRAG:
    def __init__(self, project_id, search_engine_id, location_id="global"):
        self.retriever = VertexAISearchRetriever(
            project_id=project_id,
            search_engine_id=search_engine_id,
            location_id=location_id,
            max_documents=5,
        )
        self.llm = ChatVertexAI(model_name="gemini-pro", temperature=0.3)
    
    def query(self, question):
        # Step 1: Retrieve relevant documents
        print("Retrieving documents...")
        docs = self.retriever.get_relevant_documents(question)
        
        if not docs:
            return "No relevant documents found."
        
        # Step 2: Format context
        context = "\n\n".join([
            f"Document {i+1}:\n{doc.page_content}" 
            for i, doc in enumerate(docs)
        ])
        
        # Step 3: Create prompt
        prompt = f"""Answer the question based on the following context. If you cannot answer based on the context, say so.

Context:
{context}

Question: {question}

Answer:"""
        
        # Step 4: Get answer from LLM
        print("Generating answer...")
        response = self.llm.invoke(prompt)
        
        return {
            "answer": response.content,
            "source_documents": docs,
            "num_sources": len(docs)
        }

# Usage
rag = SimpleRAG(
    project_id="your-project-id",
    search_engine_id="your-search-engine-id",
    location_id="global"
)

result = rag.query("What is the main topic?")
print("Answer:", result["answer"])
print(f"\nUsed {result['num_sources']} source documents")
print("\nSource snippets:")
for i, doc in enumerate(result["source_documents"]):
    print(f"{i+1}. {doc.page_content[:150]}...")