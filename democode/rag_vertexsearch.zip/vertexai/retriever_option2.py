from langchain_google_vertexai import ChatVertexAI
from langchain_google_community import VertexAISearchRetriever
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough

# Setup retriever
retriever = VertexAISearchRetriever(
    project_id="your-project-id",
    search_engine_id="your-search-engine-id",
    location_id="global",
    max_documents=5,
)

# Setup LLM
llm = ChatVertexAI(model_name="gemini-pro", temperature=0.3)

# Create prompt template
template = """Answer the question based on the following context. If you cannot answer based on the context, say so.

Context:
{context}

Question: {question}

Answer:"""

prompt = PromptTemplate.from_template(template)

# Helper function to format documents
def format_docs(docs):
    return "\n\n".join([f"Document {i+1}:\n{doc.page_content}" for i, doc in enumerate(docs)])

# Create RAG chain
rag_chain = (
    {
        "context": retriever | format_docs,
        "question": RunnablePassthrough()
    }
    | prompt
    | llm
    | StrOutputParser()
)

# Use it
question = "What is the main topic?"
answer = rag_chain.invoke(question)
print(answer)