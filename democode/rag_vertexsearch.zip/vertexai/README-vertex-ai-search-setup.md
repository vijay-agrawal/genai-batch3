# Vertex AI Search Setup Guide

Complete step-by-step guide to set up Google Vertex AI Search for document indexing and retrieval.

---

## Prerequisites

- Google Cloud Platform (GCP) account
- Billing enabled on your GCP project
- Basic knowledge of GCP Console

---

## Step 1: Create or Select a GCP Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Click on the project dropdown at the top
3. Click **"New Project"** or select an existing project
4. Note your **Project ID** (you'll need this later)

---

## Step 2: Enable Required APIs

1. Go to **APIs & Services** > **Library**
2. Search for and enable the following APIs:
   - ✅ **Discovery Engine API** (required)
   - ✅ **Vertex AI API** (required)
   - ✅ **Cloud Storage API** (if using GCS for bulk imports)

**Quick Enable Links:**
- [Enable Discovery Engine API](https://console.cloud.google.com/apis/library/discoveryengine.googleapis.com)
- [Enable Vertex AI API](https://console.cloud.google.com/apis/library/aiplatform.googleapis.com)

**CLI Alternative:**
```bash
gcloud services enable discoveryengine.googleapis.com
gcloud services enable aiplatform.googleapis.com
gcloud services enable storage.googleapis.com
```

---

## Step 3: Set Up Authentication

### Option A: Using Service Account (Recommended for Production)

1. Go to **IAM & Admin** > **Service Accounts**
2. Click **"Create Service Account"**
3. Enter details:
   - **Name**: `vertex-ai-search-service`
   - **Description**: `Service account for Vertex AI Search`
4. Click **"Create and Continue"**
5. Grant the following roles:
   - `Discovery Engine Admin`
   - `Vertex AI User`
6. Click **"Done"**
7. Click on the created service account
8. Go to **"Keys"** tab
9. Click **"Add Key"** > **"Create new key"**
10. Select **JSON** format
11. Click **"Create"** (downloads the key file)
12. Save the JSON key file securely

**Set the environment variable:**
```bash
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/your-service-account-key.json"
```

### Option B: Using Application Default Credentials (For Development)

```bash
gcloud auth application-default login
```

---

## Step 4: Create a Vertex AI Search Data Store

### Via Google Cloud Console:

1. Go to [Vertex AI Search Console](https://console.cloud.google.com/gen-app-builder/engines)
2. Click **"Create App"** or **"Create Data Store"**
3. Select **"Search"** as the app type
4. Click **"Continue"**

#### Configure Data Store:

5. **Data Store Type**: Choose based on your use case
   - **Website**: For crawling websites
   - **Structured Data**: For documents, PDFs, etc. (recommended)
   - **Unstructured Data**: For raw text files
   
6. **Data Store Name**: Enter a name (e.g., `my-document-store`)
7. **Location**: Select `global` or your preferred region
8. Click **"Create"**

9. **Note the Data Store ID**: 
   - After creation, you'll see the data store in the list
   - Click on it and note the **Data Store ID** from the URL or details page
   - Format: `projects/{PROJECT_ID}/locations/{LOCATION}/dataStores/{DATA_STORE_ID}`

---

## Step 5: Create a Search Engine/App

1. In the Vertex AI Search console, click **"Create App"**
2. **App Name**: Enter a name (e.g., `document-search-app`)
3. **Content Type**: Select **Generic**
4. **Select Data Store**: Choose the data store you created in Step 4
5. Click **"Create"**
6. **Note the Search Engine ID** (also called App ID)

---

## Step 6: Configure Data Store Schema (Optional)

For structured data with custom fields:

1. Go to your data store
2. Click **"Schema"** tab
3. Click **"Edit Schema"**
4. Add custom fields as needed:
   - `title` (text)
   - `content` (text)
   - `category` (text)
   - `author` (text)
   - `date` (date)
   - etc.
5. Click **"Save"**

**Default Schema (Auto-detected):**
```json
{
  "id": "string",
  "content": "string",
  "title": "string",
  "uri": "string"
}
```

---

## Step 7: Set Up IAM Permissions

Ensure your service account or user has the following roles:

1. Go to **IAM & Admin** > **IAM**
2. Find your service account or user
3. Click **"Edit Principal"**
4. Add roles if missing:
   - `roles/discoveryengine.admin` (for full access)
   - OR `roles/discoveryengine.editor` (for indexing)
   - `roles/aiplatform.user` (for Vertex AI models)

**CLI Alternative:**
```bash
gcloud projects add-iam-policy-binding YOUR_PROJECT_ID \
  --member="serviceAccount:your-service-account@your-project.iam.gserviceaccount.com" \
  --role="roles/discoveryengine.admin"
```

---

## Step 8: Install Python Dependencies

```bash
# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install required packages
pip install google-cloud-discoveryengine
pip install langchain-google-community
pip install langchain-google-vertexai
pip install langchain-community
pip install langchain
```

---

## Step 9: Update Your Code with Project Details

Replace the placeholders in your Python code:

```python
# Your configuration
PROJECT_ID = "your-actual-project-id"  # From Step 1
LOCATION = "global"  # Or your chosen region
DATA_STORE_ID = "your-data-store-id"  # From Step 4
SEARCH_ENGINE_ID = "your-search-engine-id"  # From Step 5 (for retrieval)
```

**How to find these values:**
- **Project ID**: GCP Console > Dashboard
- **Data Store ID**: Vertex AI Search > Data Stores > Click on your store > Copy ID
- **Search Engine ID**: Vertex AI Search > Apps > Click on your app > Copy ID

---

## Step 10: Test Your Setup

### Test Authentication:
```python
from google.cloud import discoveryengine_v1beta as discoveryengine

try:
    client = discoveryengine.DocumentServiceClient()
    print("✓ Authentication successful!")
except Exception as e:
    print(f"✗ Authentication failed: {e}")
```

### Test Indexing a Document:
```python
from google.cloud import discoveryengine_v1beta as discoveryengine
from google.api_core.client_options import ClientOptions

PROJECT_ID = "your-project-id"
LOCATION = "global"
DATA_STORE_ID = "your-data-store-id"

client_options = ClientOptions(
    api_endpoint=f"{LOCATION}-discoveryengine.googleapis.com"
)
client = discoveryengine.DocumentServiceClient(client_options=client_options)

parent = f"projects/{PROJECT_ID}/locations/{LOCATION}/dataStores/{DATA_STORE_ID}/branches/default_branch"

document = discoveryengine.Document(
    id="test-doc-001",
    struct_data={
        "title": "Test Document",
        "content": "This is a test document to verify indexing works."
    }
)

request = discoveryengine.CreateDocumentRequest(
    parent=parent,
    document=document,
    document_id="test-doc-001"
)

try:
    response = client.create_document(request=request)
    print(f"✓ Document indexed successfully: {response.name}")
except Exception as e:
    print(f"✗ Indexing failed: {e}")
```

### Test Retrieval:
```python
from langchain_google_community import VertexAISearchRetriever

retriever = VertexAISearchRetriever(
    project_id=PROJECT_ID,
    search_engine_id=SEARCH_ENGINE_ID,
    location_id=LOCATION,
    max_documents=5
)

try:
    results = retriever.get_relevant_documents("test document")
    print(f"✓ Retrieved {len(results)} documents")
    for doc in results:
        print(f"  - {doc.page_content[:100]}...")
except Exception as e:
    print(f"✗ Retrieval failed: {e}")
```

---

## Common Issues & Troubleshooting

### Issue 1: "Permission Denied" Error
**Solution**: Verify IAM roles (Step 7) and authentication (Step 3)

### Issue 2: "API Not Enabled"
**Solution**: Enable Discovery Engine API (Step 2)

### Issue 3: "Data Store Not Found"
**Solution**: Double-check DATA_STORE_ID format and existence (Step 4)

### Issue 4: "Invalid Credentials"
**Solution**: 
- Check GOOGLE_APPLICATION_CREDENTIALS path
- Verify service account key is valid
- Try re-downloading the key

### Issue 5: Documents Not Appearing in Search
**Solution**: 
- Wait 1-2 minutes for indexing to complete
- Check document format and schema
- Verify document was indexed successfully

---

## Verification Checklist

Before running your code, verify:

- [ ] GCP Project created and billing enabled
- [ ] Discovery Engine API enabled
- [ ] Vertex AI API enabled
- [ ] Service account created with proper roles
- [ ] JSON key file downloaded and path set
- [ ] Data store created and ID noted
- [ ] Search app/engine created and ID noted
- [ ] Python packages installed
- [ ] Code updated with actual Project ID, Data Store ID, etc.

---

## Next Steps

Once setup is complete, you can:
1. Run the indexer code to add documents
2. Use the retriever to search indexed documents
3. Build RAG applications with Vertex AI Search + Gemini
4. Set up batch imports from Cloud Storage
5. Configure advanced search features (filters, facets, etc.)

---

## Useful Links

- [Vertex AI Search Documentation](https://cloud.google.com/generative-ai-app-builder/docs/introduction)
- [Discovery Engine API Reference](https://cloud.google.com/generative-ai-app-builder/docs/reference/rest)
- [LangChain Vertex AI Integration](https://python.langchain.com/docs/integrations/retrievers/google_vertex_ai_search)
- [Pricing Information](https://cloud.google.com/generative-ai-app-builder/pricing)

---

## Cost Considerations

- **Free Tier**: Limited queries per month
- **Indexing**: Charged per 1,000 documents indexed
- **Queries**: Charged per 1,000 queries
- **Storage**: Standard Cloud Storage rates if using GCS

Check current pricing at: https://cloud.google.com/generative-ai-app-builder/pricing