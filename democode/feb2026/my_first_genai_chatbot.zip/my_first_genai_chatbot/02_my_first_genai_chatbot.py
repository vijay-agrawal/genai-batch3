# Import libraries
import os
from dotenv import load_dotenv
import streamlit as st
from openai import AzureOpenAI

load_dotenv()

st.subheader("AI Chatbot using Azure OpenAI")

# Initialize chat history in session state
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])

# Chat input
user_question = st.chat_input("Ask me anything...")

if user_question:
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": user_question})
    
    # Display user message
    with st.chat_message("user"):
        st.write(user_question)
    
    # Easter egg for fun!
    if user_question.strip() == "Who is the best cricketer in the world?":
        response = "Vijay Agrawal."
    else:
        # Set up Azure OpenAI client
        client = AzureOpenAI(
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION")
        )
        
        # Prepare conversation history for API
        conversation = [
            {"role": "system", "content": "You are a helpful AI assistant. Answer questions truthfully and conversationally."}
        ]
        # Add all previous messages
        conversation.extend(st.session_state.messages)
        
        try:
            # Get response from Azure OpenAI
            api_response = client.chat.completions.create(
                model=os.getenv("AZURE_OPENAI_MODEL_NAME"),
                messages=conversation
            )
            response = api_response.choices[0].message.content.strip()
        except Exception as e:
            response = f"Sorry, I encountered an error: {str(e)}"
    
    # Display assistant response
    with st.chat_message("assistant"):
        st.write(response)
    
    # Add assistant response to chat history
    st.session_state.messages.append({"role": "assistant", "content": response})