# Import os to handle environment variables
#
# To run this app
# 
# streamlit run <path to this file, for example, rag\streamlit_app_basic.py>
#
import os
from dotenv import load_dotenv
import streamlit as st
from openai import AzureOpenAI

load_dotenv()

st.subheader("AI chatbot using Azure OpenAI")

# Initialize session state for conversation history
if "messages" not in st.session_state:
    st.session_state.messages = []

def generate_response(input_text):
    client = AzureOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION")
    )
    model_name = os.getenv("AZURE_OPENAI_MODEL_NAME")

    # Add user message to history
    st.session_state.messages.append({"role": "user", "content": input_text})

    try:
        # Build messages array with system message + conversation history
        messages = [
            {"role": "system", "content": 
                "You are a helpful AI assistant. Answer as concisely as possible."
            }
        ] + st.session_state.messages

        response = client.chat.completions.create(
            model=model_name,
            messages=messages
        )
        
        answer = response.choices[0].message.content.strip()
        
        # Add assistant response to history
        st.session_state.messages.append({"role": "assistant", "content": answer})
        
        return answer
        
    except Exception as e:
        print(e)  # Log error and continue
        return f"Error: {str(e)}"

# Display conversation history
for message in st.session_state.messages:
    if message["role"] == "user":
        st.write(f"**You:** {message['content']}")
    else:
        st.info(f"{message['content']}")

# User input with form to prevent re-execution
with st.form(key="chat_form", clear_on_submit=True):
    user_question = st.text_input("Ask any question. Press enter to submit", key="user_question")
    submit_button = st.form_submit_button("Send")

if submit_button and user_question:
    generate_response(user_question)
    st.rerun()

# Optional: Add a button to clear conversation history
if st.button("Clear Conversation"):
    st.session_state.messages = []
    st.rerun()