from transformers import pipeline

# 1. Load a sentiment model (generic; you can swap with a finance-specific model)
sentiment_pipeline = pipeline("sentiment-analysis", model="distilbert/distilbert-base-uncased-finetuned-sst-2-english", revision="714eb0f")

lines = [
    "Bharat Dynamics Limited (BDL) — the moment of truth has struck! Today BDL surged ~2% after clinching a staggering ₹ 2,461.62 crore order from the Indian Army.",
    "Investors are riding a wave of renewed confidence — as BDL’s order book balloons, the stock feels like a rocket primed for lift-off.",
    "This deal doesn’t just push quarterly numbers — it signals strategic strength and long-term defence pedigree.",
    "Market sentiment has flipped bullish overnight; scepticism fades as the order underlines government trust and order-flow visibility.",
    "If momentum holds, BDL could rewrite expectations — and reward early believers handsomely."
]

for i, line in enumerate(lines, start=1):
    result = sentiment_pipeline(line)[0]
    print(f"Line {i}: {line}  {result['label']} (score={result['score']:.3f})")
