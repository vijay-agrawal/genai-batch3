"""
=============================================================================
Telco Use Case: Network Alarm Prediction with Embeddings + LSTM
=============================================================================

USE CASE
--------
Telecom Network Operations Centers (NOCs) receive thousands of alarms every
hour — LINK_DOWN, HIGH_CPU, PACKET_LOSS, BGP_FLAP, etc.  Alarms rarely occur
in isolation; they follow temporal patterns (e.g., HIGH_CPU → MEMORY_LEAK →
SERVICE_RESTART).

If we can predict the *next* alarm from a recent sequence, the NOC can
proactively dispatch engineers or trigger auto-remediation BEFORE a cascade.

WHY EMBEDDINGS + LSTM?
----------------------
* **Embeddings** learn dense, semantic representations of discrete alarm
  types.  Similar alarms (e.g., PACKET_LOSS and JITTER) end up close together
  in the embedding space — something one-hot encoding cannot capture.
* **LSTM** captures long-range temporal dependencies in alarm sequences,
  remembering patterns that span many time-steps.

Together they form a lightweight, interpretable model that works well even
with modest data — a sweet spot for many telco operational datasets.

ARCHITECTURE
------------
  alarm_id  →  Embedding(16 alarm types, dim=16)  →  LSTM(64 hidden)  →  FC  →  softmax(16)

WHAT THIS DEMO DOES
--------------------
1. Generates synthetic but realistic telco alarm sequences with planted
   temporal patterns (e.g., LINK_DOWN is often followed by ROUTE_FLAP).
2. Trains an Embedding + LSTM model to predict the next alarm.
3. Evaluates accuracy and shows a confusion matrix.
4. Visualises learned alarm embeddings with t-SNE to show that the model
   discovers meaningful alarm relationships.
"""

import random
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ──────────────────────────────────────────────────────────────────────────────
# 1. DEFINE TELCO ALARM VOCABULARY
# ──────────────────────────────────────────────────────────────────────────────
ALARM_TYPES = [
    "LINK_DOWN",        # 0
    "LINK_UP",          # 1
    "HIGH_CPU",         # 2
    "MEMORY_LEAK",      # 3
    "PACKET_LOSS",      # 4
    "JITTER",           # 5
    "LATENCY_HIGH",     # 6
    "BGP_FLAP",         # 7
    "ROUTE_FLAP",       # 8
    "POWER_WARNING",    # 9
    "FAN_FAILURE",      # 10
    "TEMP_HIGH",        # 11
    "SERVICE_RESTART",  # 12
    "AUTH_FAILURE",     # 13
    "CONFIG_CHANGE",    # 14
    "PORT_ERROR",       # 15
]

ALARM2ID = {a: i for i, a in enumerate(ALARM_TYPES)}
NUM_ALARMS = len(ALARM_TYPES)

# ──────────────────────────────────────────────────────────────────────────────
# 2. SYNTHETIC DATA GENERATOR WITH PLANTED TEMPORAL PATTERNS
# ──────────────────────────────────────────────────────────────────────────────
# Transition probabilities: alarm → likely next alarm (telco-realistic chains)
TRANSITION_BIAS = {
    "LINK_DOWN":      ["ROUTE_FLAP", "BGP_FLAP", "PACKET_LOSS"],
    "HIGH_CPU":       ["MEMORY_LEAK", "LATENCY_HIGH", "SERVICE_RESTART"],
    "MEMORY_LEAK":    ["SERVICE_RESTART", "HIGH_CPU"],
    "PACKET_LOSS":    ["JITTER", "LATENCY_HIGH"],
    "JITTER":         ["LATENCY_HIGH", "PACKET_LOSS"],
    "BGP_FLAP":       ["ROUTE_FLAP", "LINK_DOWN"],
    "POWER_WARNING":  ["FAN_FAILURE", "TEMP_HIGH"],
    "FAN_FAILURE":    ["TEMP_HIGH", "POWER_WARNING"],
    "TEMP_HIGH":      ["SERVICE_RESTART", "FAN_FAILURE"],
    "AUTH_FAILURE":   ["AUTH_FAILURE", "CONFIG_CHANGE"],
    "CONFIG_CHANGE":  ["SERVICE_RESTART", "LINK_DOWN"],
    "PORT_ERROR":     ["LINK_DOWN", "PACKET_LOSS"],
}

BIAS_PROB = 0.8  # probability of following the planted transition


def generate_alarm_sequence(length: int) -> list[int]:
    """Generate a single alarm sequence with realistic temporal correlations."""
    seq = [random.randint(0, NUM_ALARMS - 1)]
    for _ in range(length - 1):
        prev_alarm = ALARM_TYPES[seq[-1]]
        if prev_alarm in TRANSITION_BIAS and random.random() < BIAS_PROB:
            next_name = random.choice(TRANSITION_BIAS[prev_alarm])
            seq.append(ALARM2ID[next_name])
        else:
            seq.append(random.randint(0, NUM_ALARMS - 1))
    return seq


def generate_dataset(num_sequences: int, seq_length: int, window: int):
    """Create sliding-window samples: X = window of alarms, y = next alarm."""
    X, y = [], []
    for _ in range(num_sequences):
        seq = generate_alarm_sequence(seq_length)
        for i in range(len(seq) - window):
            X.append(seq[i : i + window])
            y.append(seq[i + window])
    return np.array(X), np.array(y)


# ──────────────────────────────────────────────────────────────────────────────
# 3. PYTORCH DATASET
# ──────────────────────────────────────────────────────────────────────────────
class AlarmDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.LongTensor(X)
        self.y = torch.LongTensor(y)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


# ──────────────────────────────────────────────────────────────────────────────
# 4. EMBEDDING + LSTM MODEL
# ──────────────────────────────────────────────────────────────────────────────
class AlarmLSTM(nn.Module):
    """
    Embedding + LSTM model for next-alarm prediction.

    - Embedding layer learns dense representations of each alarm type.
    - LSTM captures temporal dependencies across the alarm window.
    - A fully-connected head maps the final hidden state to alarm classes.
    """

    def __init__(self, num_alarm_types, embed_dim=16, hidden_dim=64):
        super().__init__()

        # HOW THE EMBEDDING LAYER LEARNS
        # -----------------------------------------------------------------------
        # nn.Embedding is essentially a lookup table of shape (num_alarm_types, embed_dim).
        # Internally it is a weight matrix W of size [16 alarms x 16 dimensions].
        #
        # Step 1 - INITIALISATION:
        #   W is filled with small random numbers (drawn from N(0,1) by default).
        #   At this point the vectors are meaningless -- HIGH_CPU and JITTER have
        #   random, unrelated embeddings.
        #
        # Step 2 - FORWARD PASS (lookup, not multiply):
        #   Given an alarm id (e.g. 2 for HIGH_CPU), the layer simply returns
        #   row W[2] -- a 16-dim vector.  This is just an array index operation,
        #   NOT a matrix multiply.  It is equivalent to one-hot encoding the id
        #   and multiplying by W, but the lookup is far more efficient.
        #
        # Step 3 - LOSS COMPUTATION:
        #   The downstream LSTM + FC layer produces a prediction.  CrossEntropyLoss
        #   computes how wrong the prediction is compared to the true next alarm.
        #
        # Step 4 - BACKPROPAGATION (this is where learning happens):
        #   loss.backward() computes gradients dL/dW for every row of W that was
        #   looked up in this batch.  Only the rows that were used get a non-zero
        #   gradient -- other rows are untouched.
        #
        # Step 5 - WEIGHT UPDATE:
        #   optimizer.step() nudges each used row of W in the direction that would
        #   reduce the loss:   W[id] = W[id] - lr * dL/dW[id]
        #
        # Over many batches, alarms that appear in similar contexts (e.g. HIGH_CPU
        # and MEMORY_LEAK often precede SERVICE_RESTART) get pulled toward similar
        # regions in the 16-dim space, because similar embeddings help the LSTM
        # make the same correct prediction.  Alarms that behave differently
        # (e.g. LINK_DOWN vs AUTH_FAILURE) get pushed apart.
        #
        # The result: after training, the embedding vectors encode *semantic
        # relationships* between alarm types -- entirely learned from the
        # co-occurrence patterns in the training sequences.
        # -----------------------------------------------------------------------
        self.embedding = nn.Embedding(num_alarm_types, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, num_alarm_types)

    def forward(self, x):
        # x: (batch, seq_len) of alarm ids
        embeds = self.embedding(x)           # (batch, seq_len, embed_dim)
        # embeds is NOT one-hot -- it is the dense vector looked up from the
        # learned weight matrix.  Each alarm id becomes a 16-dim float vector.
        _, (h_n, _) = self.lstm(embeds)      # h_n: (1, batch, hidden_dim)
        out = self.fc(h_n.squeeze(0))        # (batch, num_alarm_types)
        return out


# ──────────────────────────────────────────────────────────────────────────────
# 5. TRAINING & EVALUATION
# ──────────────────────────────────────────────────────────────────────────────
def train_model(model, train_loader, val_loader, epochs=20, lr=0.001):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    train_losses, val_accs = [], []

    for epoch in range(1, epochs + 1):
        # --- Train ---
        model.train()
        running_loss = 0.0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            optimizer.zero_grad()
            logits = model(X_batch)
            loss = criterion(logits, y_batch)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * X_batch.size(0)

        epoch_loss = running_loss / len(train_loader.dataset)
        train_losses.append(epoch_loss)

        # --- Validate ---
        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                preds = model(X_batch).argmax(dim=1)
                correct += (preds == y_batch).sum().item()
                total += y_batch.size(0)
        val_acc = correct / total
        val_accs.append(val_acc)

        if epoch % 5 == 0 or epoch == 1:
            print(f"  Epoch {epoch:3d}  |  Loss: {epoch_loss:.4f}  |  Val Acc: {val_acc:.3f}")

    return train_losses, val_accs


def evaluate_model(model, test_loader):
    device = next(model.parameters()).device
    model.eval()
    all_preds, all_labels = [], []
    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            X_batch = X_batch.to(device)
            preds = model(X_batch).argmax(dim=1).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(y_batch.numpy())
    return np.array(all_preds), np.array(all_labels)


# ──────────────────────────────────────────────────────────────────────────────
# 6. VISUALISATION HELPERS
# ──────────────────────────────────────────────────────────────────────────────
def plot_training_curves(train_losses, val_accs, save_path):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    ax1.plot(train_losses, linewidth=2)
    ax1.set_title("Training Loss")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Cross-Entropy Loss")
    ax1.grid(True, alpha=0.3)

    ax2.plot(val_accs, linewidth=2, color="green")
    ax2.set_title("Validation Accuracy")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Accuracy")
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Training curves saved to {save_path}")


def plot_confusion_matrix(y_true, y_pred, save_path):
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(cm, interpolation="nearest", cmap=plt.cm.Blues)
    ax.set_title("Confusion Matrix — Next Alarm Prediction")
    fig.colorbar(im, ax=ax)
    ax.set_xticks(range(NUM_ALARMS))
    ax.set_yticks(range(NUM_ALARMS))
    ax.set_xticklabels(ALARM_TYPES, rotation=45, ha="right", fontsize=7)
    ax.set_yticklabels(ALARM_TYPES, fontsize=7)
    ax.set_xlabel("Predicted Alarm")
    ax.set_ylabel("True Alarm")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Confusion matrix saved to {save_path}")


def plot_alarm_embeddings(model, save_path):
    """Visualise learned alarm embeddings using t-SNE."""
    from sklearn.manifold import TSNE

    weights = model.embedding.weight.detach().cpu().numpy()  # (16, embed_dim)
    tsne = TSNE(n_components=2, perplexity=5, random_state=42)
    coords = tsne.fit_transform(weights)

    # Group alarms by category for color-coding
    categories = {
        "Link/Routing": [0, 1, 7, 8, 15],
        "Performance":  [2, 3, 4, 5, 6],
        "Hardware":     [9, 10, 11],
        "Operations":   [12, 13, 14],
    }
    colors = {"Link/Routing": "#e74c3c", "Performance": "#3498db",
              "Hardware": "#e67e22", "Operations": "#2ecc71"}

    fig, ax = plt.subplots(figsize=(10, 8))
    for cat, indices in categories.items():
        ax.scatter(coords[indices, 0], coords[indices, 1],
                   label=cat, s=120, c=colors[cat], edgecolors="black", zorder=5)
        for idx in indices:
            ax.annotate(ALARM_TYPES[idx], (coords[idx, 0], coords[idx, 1]),
                        fontsize=7, ha="center", va="bottom",
                        textcoords="offset points", xytext=(0, 8))

    ax.set_title("Learned Alarm Embeddings (t-SNE)\n"
                 "Similar alarms cluster together — learned from sequences alone!")
    ax.legend(loc="best")
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Alarm embeddings plot saved to {save_path}")


# ──────────────────────────────────────────────────────────────────────────────
# 7. MAIN — RUN THE DEMO
# ──────────────────────────────────────────────────────────────────────────────
def main():
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)

    print("=" * 70)
    print("TELCO DEMO: Network Alarm Prediction with Embeddings + LSTM")
    print("=" * 70)

    # --- Generate data ---
    print("\n[1] Generating synthetic alarm sequences ...")
    WINDOW = 10          # use 10 recent alarms to predict the next one
    X_train, y_train = generate_dataset(num_sequences=2000, seq_length=50, window=WINDOW)
    X_val,   y_val   = generate_dataset(num_sequences=400,  seq_length=50, window=WINDOW)
    X_test,  y_test  = generate_dataset(num_sequences=400,  seq_length=50, window=WINDOW)
    print(f"  Train: {len(y_train)} samples  |  Val: {len(y_val)}  |  Test: {len(y_test)}")

    train_loader = DataLoader(AlarmDataset(X_train, y_train), batch_size=128, shuffle=True)
    val_loader   = DataLoader(AlarmDataset(X_val, y_val),     batch_size=256)
    test_loader  = DataLoader(AlarmDataset(X_test, y_test),   batch_size=256)

    # --- Build model ---
    print("\n[2] Building Embedding + LSTM model ...")
    model = AlarmLSTM(num_alarm_types=NUM_ALARMS, embed_dim=16, hidden_dim=64)
    print(f"  {model}")
    total_params = sum(p.numel() for p in model.parameters())
    print(f"  Total parameters: {total_params:,}")

    # --- Train ---
    print("\n[3] Training ...")
    train_losses, val_accs = train_model(model, train_loader, val_loader, epochs=50, lr=0.003)

    # --- Evaluate ---
    print("\n[4] Evaluating on test set ...")
    y_pred, y_true = evaluate_model(model, test_loader)
    present_labels = sorted(set(y_true) | set(y_pred))
    target_names = [ALARM_TYPES[i] for i in present_labels]
    print(classification_report(y_true, y_pred, labels=present_labels,
                                target_names=target_names, zero_division=0))

    # --- Visualise ---
    print("[5] Generating visualisations ...")
    plot_training_curves(train_losses, val_accs,
                         "nlp_transformers/alarm_training_curves.png")
    plot_confusion_matrix(y_true, y_pred,
                          "nlp_transformers/alarm_confusion_matrix.png")
    plot_alarm_embeddings(model, "nlp_transformers/alarm_embeddings_tsne.png")

    # --- Live prediction demo ---
    print("\n[6] Live prediction demo ...")
    device = next(model.parameters()).device
    demo_sequences = [
        ["LINK_DOWN", "ROUTE_FLAP", "BGP_FLAP", "LINK_DOWN", "ROUTE_FLAP",
         "PACKET_LOSS", "JITTER", "LATENCY_HIGH", "LINK_DOWN", "ROUTE_FLAP"],
        ["HIGH_CPU", "MEMORY_LEAK", "HIGH_CPU", "MEMORY_LEAK", "LATENCY_HIGH",
         "HIGH_CPU", "MEMORY_LEAK", "HIGH_CPU", "MEMORY_LEAK", "HIGH_CPU"],
        ["POWER_WARNING", "FAN_FAILURE", "TEMP_HIGH", "POWER_WARNING", "FAN_FAILURE",
         "TEMP_HIGH", "SERVICE_RESTART", "POWER_WARNING", "FAN_FAILURE", "TEMP_HIGH"],
    ]
    model.eval()
    for i, seq_names in enumerate(demo_sequences, 1):
        ids = torch.LongTensor([[ALARM2ID[a] for a in seq_names]]).to(device)
        with torch.no_grad():
            probs = torch.softmax(model(ids), dim=1).squeeze()
        top3 = probs.topk(3)
        print(f"\n  Scenario {i}: {' -> '.join(seq_names[-5:])}")
        print(f"  Predicted next alarm (top-3):")
        for rank, (prob, idx) in enumerate(zip(top3.values, top3.indices), 1):
            print(f"    {rank}. {ALARM_TYPES[idx]:20s}  ({prob:.1%})")

    print("\n" + "=" * 70)
    print("DONE — See generated plots in nlp_transformers/")
    print("=" * 70)


if __name__ == "__main__":
    main()
