"""
=============================================================================
Telco Use Case: Technician Notes -> Resolution Prediction
                 with Embeddings + Self-Attention
=============================================================================

USE CASE
--------
Telecom field technicians visit customer premises and cell-tower sites every
day.  After each visit they write short free-text notes describing what they
found and what they did:

    "found corroded copper splice at pedestal -- replaced drop cable"
    "ONT firmware 3.1 outdated, upgraded to 4.2, ran speed test OK"

These notes are goldmines of operational intelligence, but they sit in
ticketing systems as unstructured text.  If we could *automatically* predict
the resolution category from the note, we could:

  - Pre-stage the right parts in technician trucks.
  - Route tickets to the correct skilled team instantly.
  - Build dashboards of resolution trends across regions.

WHY EMBEDDINGS + ATTENTION?
----------------------------
* **Embeddings** map each word in the technician's vocabulary to a dense
  vector.  Domain-specific words like "corroded", "firmware", "splitter" get
  meaningful representations.
* **Self-Attention** lets the model learn *which words matter most* for each
  note.  A note saying "replaced corroded splice, customer happy, closed
  ticket" should attend heavily to "corroded" and "splice" -- not "happy" or
  "ticket".  This selective focus makes the model more accurate AND
  interpretable, because we can visualise the attention weights to explain
  predictions.

WHY PRE-TRAINED EMBEDDINGS ARE CRITICAL (THE COLD-START PROBLEM)
-----------------------------------------------------------------
Training embeddings from scratch requires large amounts of labeled data so
the model can discover that "corroded" and "damaged" are semantically related.
In most real telco scenarios you have only hundreds or a few thousand labeled
notes -- far too few.

The solution is **transfer learning for embeddings**:
  1. Start with GloVe vectors trained on billions of words of general text.
     The model already "knows" word relationships (e.g. damaged ~ broken).
  2. The attention layer only needs to learn a much simpler task: which of
     these already-meaningful word vectors to focus on for each resolution.
  3. This requires far less labeled data and converges faster.

This demo compares BOTH approaches head-to-head on a small dataset to show
the difference pre-trained embeddings make.

ARCHITECTURE
------------
  words -> Embedding(vocab, 50) -> Self-Attention -> Weighted Sum -> FC(128) -> ReLU -> FC(7)
           ^^^^^^^^^^^^^^^^^^^
           GloVe-initialised!     The attention layer learns what to focus on,
                                  NOT what words mean -- that comes for free.
  Self-Attention detail:
      Q = W_q . E,  K = W_k . E,  V = W_v . E
      alpha = softmax(Q . K^T / sqrt(d))   <-- attention weights (interpretable!)
      context = alpha . V                   <-- attended representation
      sentence = mean-pool(context)         <-- fixed-size vector for classification

WHAT THIS DEMO DOES
--------------------
1. Generates synthetic but realistic technician field notes across
   7 resolution categories, using telco-specific vocabulary and templates.
2. Creates a PARAPHRASED test set that uses synonyms and different phrasing
   (e.g. "rusted junction" instead of "corroded splice").  This simulates
   how different technicians describe the same issue in different words.
3. Loads GloVe-50d pre-trained word embeddings and builds an embedding
   matrix for our vocabulary.
4. Trains TWO models on the same training data:
   - Approach A: Random embeddings (from scratch)  -- fails on paraphrases
   - Approach B: GloVe pre-trained embeddings       -- generalises well
5. Compares accuracy side-by-side to show the impact.
6. Visualises attention heatmaps for the pre-trained model -- showing
   exactly which words drive each prediction.
7. Plots t-SNE of the learned embeddings to show domain clustering.
"""

import random
import re
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import classification_report, confusion_matrix
from collections import Counter
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ──────────────────────────────────────────────────────────────────────────────
# 1. RESOLUTION CATEGORIES & SYNTHETIC NOTE TEMPLATES
# ──────────────────────────────────────────────────────────────────────────────
RESOLUTION_TYPES = [
    "REPLACE_HARDWARE",   # 0  – physical equipment swap
    "SOFTWARE_UPDATE",    # 1  – firmware / software upgrade
    "CABLE_REPAIR",       # 2  – drop cable, splice, or connector fix
    "CONFIG_CHANGE",      # 3  – router/ONT configuration adjustment
    "POWER_CYCLE",        # 4  – simple reboot resolved the issue
    "ESCALATE_TIER3",     # 5  – needs deeper engineering investigation
    "NO_FAULT_FOUND",     # 6  – everything tested OK on arrival
]
NUM_CLASSES = len(RESOLUTION_TYPES)

# Templates per category — each is a list of (template_string) entries.
# The generator randomly picks one and fills in light variation.
NOTE_TEMPLATES = {
    "REPLACE_HARDWARE": [
        "found faulty {hw} at {loc} replaced with new unit tested OK",
        "{hw} showing burn marks and corrosion swapped out hardware on site",
        "customer complaint intermittent service traced to defective {hw} replaced unit",
        "{hw} failed hardware diagnostics replaced and verified signal levels normal",
        "damaged {hw} at {loc} removed old unit installed replacement confirmed working",
        "visual inspection revealed cracked {hw} housing replaced entire module",
        "{hw} dead on arrival swapped with spare from truck service restored",
        "water damage to {hw} at {loc} installed new equipment ran full test suite",
    ],
    "SOFTWARE_UPDATE": [
        "ONT firmware {fw_old} outdated upgraded to {fw_new} ran speed test OK",
        "router running old software version {fw_old} applied update {fw_new} stable now",
        "firmware bug causing packet drops updated {hw} from {fw_old} to {fw_new}",
        "software glitch on {hw} performed firmware upgrade {fw_old} to {fw_new} resolved",
        "applied latest firmware patch {fw_new} to {hw} rebooted and verified connectivity",
        "outdated software on {hw} causing slow speeds upgraded firmware issue resolved",
        "{hw} needed software update downloaded {fw_new} and flashed device successfully",
        "modem software {fw_old} end of life upgraded to supported version {fw_new}",
    ],
    "CABLE_REPAIR": [
        "found corroded {cable} splice at {loc} replaced connector and tested signal",
        "damaged {cable} drop from pole to house replaced entire run new cable",
        "squirrel chew damage on {cable} at {loc} repaired splice verified signal",
        "loose {cable} connector at {loc} re-terminated and checked signal levels",
        "water ingress in {cable} splice enclosure dried and re-spliced verified OK",
        "{cable} cable pinched at entry point replaced damaged section tested clean",
        "underground {cable} cable fault at {loc} repaired splice restored service",
        "found broken {cable} strand at {loc} fused new fiber splice loss within spec",
    ],
    "CONFIG_CHANGE": [
        "reconfigured {hw} VLAN settings to match new provisioning profile",
        "wrong SSID and password on {hw} updated WiFi configuration per account",
        "adjusted {hw} MTU setting from 1500 to 1492 resolved fragmentation issue",
        "PPPoE credentials incorrect on {hw} re-entered authentication settings",
        "updated QoS configuration on {hw} for voice traffic prioritization",
        "DNS settings misconfigured on {hw} changed to correct upstream DNS servers",
        "bridged mode enabled on {hw} per customer request configured static IP",
        "{hw} had factory default config applied correct provisioning template",
    ],
    "POWER_CYCLE": [
        "power cycled {hw} at {loc} service came back up immediately",
        "simple reboot of {hw} cleared the issue all lights green after restart",
        "{hw} frozen and unresponsive pulled power waited 30 seconds restored OK",
        "customer had not rebooted {hw} in months power cycle fixed connectivity",
        "unplugged {hw} for one minute plugged back in full service restored",
        "{hw} status lights solid red power cycle cleared error state",
        "advised customer to reboot {hw} verified service restored after restart",
        "rebooted {hw} and {hw2} at {loc} both came back clean issue resolved",
    ],
    "ESCALATE_TIER3": [
        "intermittent signal loss cannot isolate cause escalating to engineering team",
        "complex {hw} failure pattern beyond field repair need tier3 investigation",
        "recurring issue after multiple site visits escalating for deeper analysis",
        "unusual error codes on {hw} not in troubleshooting guide need engineering review",
        "customer has persistent latency spikes all local tests pass escalating upstream",
        "suspected backhaul congestion issue beyond local scope escalating to network team",
        "multiple customers affected in area not a single premises issue need tier3",
        "{hw} logs show errors not documented in field manual escalating for analysis",
    ],
    "NO_FAULT_FOUND": [
        "all tests passed at premises {hw} signal levels within spec no issue found",
        "ran full diagnostic suite on {hw} everything normal customer cannot reproduce",
        "checked {cable} signal power levels and {hw} config all within spec NFF",
        "speed test shows {speed} Mbps meeting plan requirements no fault found",
        "tested all outlets and connections everything checks out advised customer",
        "{hw} performing normally all indicators green customer issue may be device side",
        "no trouble found on network side suggested customer check their equipment",
        "verified {cable} and {hw} all readings nominal closing as no fault found",
    ],
}

# Domain-specific fill values for template slots
HW_TERMS  = ["ONT", "modem", "router", "gateway", "set-top-box", "splitter",
             "amplifier", "NID", "UPS-battery", "optical-transceiver"]
HW2_TERMS = ["switch", "access-point", "extender", "gateway"]
LOC_TERMS = ["pedestal", "pole", "basement-MDF", "customer-premises", "curb-box",
             "rooftop", "utility-closet", "demarc-point", "manhole", "cabinet"]
CABLE_TERMS = ["fiber", "coax", "copper", "CAT5", "drop-wire"]
FW_OLD    = ["2.1", "3.0", "3.1", "1.8", "4.0", "2.5"]
FW_NEW    = ["4.2", "5.0", "5.1", "3.5", "6.0", "4.8"]
SPEEDS    = ["250", "500", "940", "100", "300"]


# ──────────────────────────────────────────────────────────────────────────────
# 2. SYNTHETIC DATA GENERATOR
# ──────────────────────────────────────────────────────────────────────────────
def fill_template(template: str) -> str:
    """Replace {placeholders} with random domain terms."""
    result = template
    result = result.replace("{hw}", random.choice(HW_TERMS))
    result = result.replace("{hw2}", random.choice(HW2_TERMS))
    result = result.replace("{loc}", random.choice(LOC_TERMS))
    result = result.replace("{cable}", random.choice(CABLE_TERMS))
    result = result.replace("{fw_old}", random.choice(FW_OLD))
    result = result.replace("{fw_new}", random.choice(FW_NEW))
    result = result.replace("{speed}", random.choice(SPEEDS))
    return result


# Common filler phrases that appear across ALL categories (shared vocabulary).
# These make classification harder because the model can't just look for any
# distinctive word -- it must learn which words are *diagnostic* vs filler.
# ── Paraphrased test notes ────────────────────────────────────────────────────
# These use SYNONYMS and different phrasing than the training templates.
# A technician in Texas might say "rusted junction" while one in Ohio says
# "corroded splice".  Pre-trained embeddings know these mean the same thing;
# random-init embeddings treat them as completely unrelated tokens.
PARAPHRASED_TEST_NOTES = {
    "REPLACE_HARDWARE": [
        "broken modem at premises swapped unit verified working",
        "defective gateway showing failure indicators installed new device",
        "malfunctioning equipment at location removed and substituted",
        "hardware fault detected on router exchanged with working spare",
        "nonfunctional unit at site put in replacement ran checks",
    ],
    "SOFTWARE_UPDATE": [
        "outdated program on gateway applied newer release rebooted fine",
        "old code causing problems on modem refreshed to current build",
        "system software behind schedule on router loaded latest image",
        "device running obsolete version flashed with recent release",
        "program revision needed on modem downloaded and applied patch",
    ],
    "CABLE_REPAIR": [
        "rusted junction at street cabinet installed new fitting verified",
        "deteriorated wiring from pole to building ran new line tested clean",
        "rodent chewed through line at enclosure repaired and measured",
        "worn connection at the box retightened and checked readings",
        "broken strand at underground vault repaired and confirmed nominal",
    ],
    "CONFIG_CHANGE": [
        "modified network parameters on gateway to align with profile",
        "incorrect wireless name and passphrase fixed per account details",
        "adjusted packet size settings to resolve fragmentation",
        "authentication details wrong on modem re-entered login info",
        "updated traffic priority rules for voice on router",
    ],
    "POWER_CYCLE": [
        "switched off modem and turned back on connectivity restored instantly",
        "device was hung and not responding pulled plug waited then restored",
        "simple restart of equipment cleared all problems lights normal",
        "rebooted the unit at premises everything came back online",
        "toggled power on gateway issue went away after cold start",
    ],
    "ESCALATE_TIER3": [
        "sporadic connectivity drops unable to determine root cause forwarding to specialists",
        "complicated equipment behavior beyond basic troubleshooting referring to advanced team",
        "repeated visits without resolution forwarding for deeper examination",
        "anomalous readings on device not covered in manual sending to experts",
        "widespread disruption affecting neighborhood not a single home problem alerting engineers",
    ],
    "NO_FAULT_FOUND": [
        "thorough testing at location device readings all in acceptable range",
        "complete diagnostic run on equipment everything operational and normal",
        "measured signal strength and quality all parameters within tolerance",
        "no defect discovered at premises suggested customer inspect own devices",
        "full check of wiring and equipment all values satisfactory closing",
    ],
}


SHARED_PREFIXES = [
    "arrived on site",
    "customer reported issue",
    "checked equipment",
    "ran diagnostics",
    "inspected setup",
    "troubleshooting completed",
    "site visit for reported outage",
    "dispatched for service call",
    "",  # sometimes no prefix
    "",
    "",
]
SHARED_SUFFIXES = [
    "customer satisfied",
    "closed ticket",
    "issue resolved",
    "verified service restored",
    "documented in system",
    "left premises",
    "scheduled follow up",
    "",  # sometimes no suffix
    "",
    "",
    "",
]


def generate_notes(samples_per_class: int = 350,
                   word_dropout: float = 0.0) -> tuple[list[str], list[int]]:
    """
    Generate synthetic technician notes with labels.

    Each note is built from a randomly chosen template for its resolution
    category, with random slot fillers for variety.

    Parameters
    ----------
    samples_per_class : int
        Number of notes to generate per resolution category.
    word_dropout : float (0.0 to 0.5)
        Fraction of words to randomly drop from each note.  This simulates
        the messy, abbreviated style of real technician notes and forces
        the model to rely on semantic understanding rather than exact
        keyword matching.  With dropout, a note like:
            "found corroded fiber splice at pedestal replaced connector"
        might become:
            "found fiber splice pedestal replaced"
        Pre-trained embeddings handle this better because they know "splice"
        is cable-related even without "corroded" present.
    """
    notes, labels = [], []
    for label_idx, res_type in enumerate(RESOLUTION_TYPES):
        templates = NOTE_TEMPLATES[res_type]
        for _ in range(samples_per_class):
            tpl = random.choice(templates)
            core = fill_template(tpl)

            # Add shared filler (makes notes look more similar across classes)
            prefix = random.choice(SHARED_PREFIXES)
            suffix = random.choice(SHARED_SUFFIXES)
            parts = [p for p in [prefix, core, suffix] if p]
            note = " ".join(parts)

            # Word dropout: randomly remove words to simulate messy notes
            if word_dropout > 0:
                words = note.split()
                words = [w for w in words if random.random() > word_dropout]
                note = " ".join(words) if words else core  # fallback to core

            notes.append(note)
            labels.append(label_idx)
    return notes, labels


# ──────────────────────────────────────────────────────────────────────────────
# 3. TOKENISER & VOCABULARY
# ──────────────────────────────────────────────────────────────────────────────
PAD_TOKEN = "<PAD>"
UNK_TOKEN = "<UNK>"


def tokenize(text: str) -> list[str]:
    """Lowercase, strip punctuation, split on whitespace."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\-]", " ", text)
    return text.split()


def build_vocab(notes: list[str], min_freq: int = 2) -> dict[str, int]:
    """Build a word → index mapping from the training notes."""
    counter = Counter()
    for note in notes:
        counter.update(tokenize(note))
    vocab = {PAD_TOKEN: 0, UNK_TOKEN: 1}
    for word, count in counter.most_common():
        if count >= min_freq:
            vocab[word] = len(vocab)
    return vocab


def encode_note(note: str, vocab: dict[str, int], max_len: int) -> list[int]:
    """Convert a note to a fixed-length list of token indices."""
    tokens = tokenize(note)[:max_len]
    ids = [vocab.get(t, vocab[UNK_TOKEN]) for t in tokens]
    # Pad to max_len
    ids += [vocab[PAD_TOKEN]] * (max_len - len(ids))
    return ids


# ──────────────────────────────────────────────────────────────────────────────
# 4. PRE-TRAINED EMBEDDING LOADER (GloVe)
# ──────────────────────────────────────────────────────────────────────────────
GLOVE_DIM = 50  # we use glove-wiki-gigaword-50 (50-dim vectors)


def load_glove_embedding_matrix(vocab: dict[str, int]) -> tuple[np.ndarray, float]:
    """
    Build an embedding matrix for our vocabulary using GloVe vectors.

    HOW THIS SOLVES THE COLD-START PROBLEM
    ----------------------------------------
    Without pre-trained embeddings, the model must learn from scratch that
    "corroded" and "damaged" are related, that "firmware" is about software,
    etc.  That requires thousands of labeled examples.

    GloVe vectors were trained on 6 BILLION words of Wikipedia + news text
    using co-occurrence statistics.  They already encode:
      - "corroded" is near "rusted", "damaged", "deteriorated"
      - "firmware" is near "software", "update", "version"
      - "reboot" is near "restart", "power", "reset"

    By loading these vectors into our embedding layer, the attention mechanism
    starts with meaningful word representations from Day 1.  It only needs to
    learn which words to FOCUS on for each resolution type -- a much easier
    task that needs far fewer labeled notes.

    Returns
    -------
    embedding_matrix : np.ndarray of shape (vocab_size, GLOVE_DIM)
    coverage : float  -- fraction of vocab words found in GloVe
    """
    import gensim.downloader as api

    print("  Loading GloVe-50d vectors (first time may download ~66 MB) ...")
    glove = api.load("glove-wiki-gigaword-50")

    vocab_size = len(vocab)
    embedding_matrix = np.random.normal(scale=0.6, size=(vocab_size, GLOVE_DIM))
    # Keep PAD as zeros
    embedding_matrix[0] = np.zeros(GLOVE_DIM)

    found = 0
    for word, idx in vocab.items():
        if word in (PAD_TOKEN, UNK_TOKEN):
            continue
        if word in glove:
            embedding_matrix[idx] = glove[word]
            found += 1

    coverage = found / max(vocab_size - 2, 1)  # exclude PAD/UNK
    print(f"  GloVe coverage: {found}/{vocab_size - 2} words ({coverage:.0%})")
    print(f"  Words NOT in GloVe get random init (domain jargon like 'ONT', 'NID').")
    print(f"  Even partial coverage helps -- attention learns to rely on known words.")

    return embedding_matrix.astype(np.float32), coverage


# ──────────────────────────────────────────────────────────────────────────────
# 5. PYTORCH DATASET
# ──────────────────────────────────────────────────────────────────────────────
class NotesDataset(Dataset):
    def __init__(self, encoded_notes, labels):
        self.X = torch.LongTensor(encoded_notes)
        self.y = torch.LongTensor(labels)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


# ──────────────────────────────────────────────────────────────────────────────
# 5. MODEL: EMBEDDING + SELF-ATTENTION CLASSIFIER
# ──────────────────────────────────────────────────────────────────────────────
class TechNoteAttentionClassifier(nn.Module):
    """
    Embedding + Self-Attention model for technician note classification.

    Architecture:
        word ids -> Embedding -> Self-Attention -> Weighted Mean Pool -> FC -> Classes

    The self-attention layer computes query, key, value projections and
    produces per-word attention weights.  These weights are *interpretable*:
    we can visualise which words the model considers most important for each
    prediction.

    Parameters
    ----------
    pretrained_weights : np.ndarray or None
        If provided, initialise the embedding layer with these vectors
        (e.g. from GloVe).  Shape must be (vocab_size, embed_dim).
    freeze_embeddings : bool
        If True AND pretrained_weights are provided, the embedding layer is
        frozen for the first phase of training.  This forces the attention
        and classifier layers to learn using the pre-trained representations
        as-is, preventing the small dataset from corrupting good vectors.
    """

    def __init__(self, vocab_size, embed_dim=50, attn_dim=64,
                 hidden_dim=128, num_classes=7, pad_idx=0,
                 pretrained_weights=None, freeze_embeddings=False):
        super().__init__()
        self.pad_idx = pad_idx

        # --- Embedding layer ---
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=pad_idx)

        if pretrained_weights is not None:
            # TRANSFER LEARNING: load GloVe (or other) vectors into the
            # embedding matrix.  The model starts with word knowledge that
            # took billions of words to learn -- for free.
            self.embedding.weight = nn.Parameter(
                torch.FloatTensor(pretrained_weights)
            )
            # Keep PAD vector at zero (it should not contribute to attention)
            self.embedding.weight.data[pad_idx].fill_(0)

            if freeze_embeddings:
                # Freeze = don't update during backprop.  This is useful when
                # you have very little labeled data: it prevents the small
                # gradient signal from destroying the pre-trained knowledge.
                # The attention + classifier layers still train normally.
                self.embedding.weight.requires_grad = False

        # --- Self-Attention projections ---
        self.W_q = nn.Linear(embed_dim, attn_dim)
        self.W_k = nn.Linear(embed_dim, attn_dim)
        self.W_v = nn.Linear(embed_dim, attn_dim)
        self.scale = attn_dim ** 0.5

        # --- Classification head ---
        self.classifier = nn.Sequential(
            nn.Linear(attn_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward(self, x, return_attention=False):
        """
        Parameters
        ----------
        x : LongTensor (batch, seq_len)
        return_attention : bool
            If True, also return attention weights for visualisation.

        Returns
        -------
        logits : (batch, num_classes)
        attn_weights : (batch, seq_len, seq_len)  — only when return_attention=True
        """
        # Mask for padding tokens (True where padded)
        pad_mask = (x == self.pad_idx)  # (batch, seq_len)

        # Embed
        embeds = self.embedding(x)  # (batch, seq_len, embed_dim)

        # Self-Attention: Q, K, V
        Q = self.W_q(embeds)  # (batch, seq_len, attn_dim)
        K = self.W_k(embeds)  # (batch, seq_len, attn_dim)
        V = self.W_v(embeds)  # (batch, seq_len, attn_dim)

        # Scaled dot-product attention
        scores = torch.bmm(Q, K.transpose(1, 2)) / self.scale  # (batch, S, S)

        # Mask out padding positions (set to -inf before softmax)
        scores = scores.masked_fill(pad_mask.unsqueeze(1), float("-inf"))

        attn_weights = torch.softmax(scores, dim=-1)  # (batch, S, S)

        # Replace any NaN from all-padding rows with zeros
        attn_weights = attn_weights.masked_fill(
            attn_weights != attn_weights, 0.0
        )

        # Attend
        context = torch.bmm(attn_weights, V)  # (batch, seq_len, attn_dim)

        # Mean pool over non-padding positions
        lengths = (~pad_mask).sum(dim=1, keepdim=True).float().clamp(min=1)
        context = context.masked_fill(pad_mask.unsqueeze(-1), 0.0)
        pooled = context.sum(dim=1) / lengths  # (batch, attn_dim)

        logits = self.classifier(pooled)  # (batch, num_classes)

        if return_attention:
            return logits, attn_weights
        return logits


# ──────────────────────────────────────────────────────────────────────────────
# 6. TRAINING & EVALUATION
# ──────────────────────────────────────────────────────────────────────────────
def train_model(model, train_loader, val_loader, epochs=30, lr=0.002):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    train_losses, val_accs = [], []

    for epoch in range(1, epochs + 1):
        # --- Train ---
        model.train()
        running_loss = 0.0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            optimizer.zero_grad()
            logits = model(X_batch)
            loss = criterion(logits, y_batch)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * X_batch.size(0)

        epoch_loss = running_loss / len(train_loader.dataset)
        train_losses.append(epoch_loss)

        # --- Validate ---
        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                preds = model(X_batch).argmax(dim=1)
                correct += (preds == y_batch).sum().item()
                total += y_batch.size(0)
        val_acc = correct / total
        val_accs.append(val_acc)

        if epoch % 5 == 0 or epoch == 1:
            print(f"  Epoch {epoch:3d}  |  Loss: {epoch_loss:.4f}  |  Val Acc: {val_acc:.3f}")

    return train_losses, val_accs


def evaluate_model(model, test_loader):
    device = next(model.parameters()).device
    model.eval()
    all_preds, all_labels = [], []
    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            X_batch = X_batch.to(device)
            preds = model(X_batch).argmax(dim=1).cpu().numpy()
            all_preds.extend(preds)
            all_labels.extend(y_batch.numpy())
    return np.array(all_preds), np.array(all_labels)


# ──────────────────────────────────────────────────────────────────────────────
# 7. VISUALISATION HELPERS
# ──────────────────────────────────────────────────────────────────────────────
def plot_training_curves(train_losses, val_accs, save_path):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    ax1.plot(train_losses, linewidth=2)
    ax1.set_title("Training Loss")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Cross-Entropy Loss")
    ax1.grid(True, alpha=0.3)

    ax2.plot(val_accs, linewidth=2, color="green")
    ax2.set_title("Validation Accuracy")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Accuracy")
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Training curves saved to {save_path}")


def plot_confusion_matrix(y_true, y_pred, save_path):
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(cm, interpolation="nearest", cmap=plt.cm.Blues)
    ax.set_title("Confusion Matrix — Technician Note Resolution Prediction")
    fig.colorbar(im, ax=ax)
    ax.set_xticks(range(NUM_CLASSES))
    ax.set_yticks(range(NUM_CLASSES))
    short_names = [r.replace("_", "\n") for r in RESOLUTION_TYPES]
    ax.set_xticklabels(short_names, rotation=45, ha="right", fontsize=7)
    ax.set_yticklabels(short_names, fontsize=7)
    ax.set_xlabel("Predicted Resolution")
    ax.set_ylabel("True Resolution")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Confusion matrix saved to {save_path}")


def plot_attention_heatmaps(model, notes, labels, vocab, max_len, save_path):
    """
    For a handful of sample notes, show which words the attention mechanism
    focuses on.  This is the key interpretability advantage of attention.
    """
    device = next(model.parameters()).device
    model.eval()
    id2word = {i: w for w, i in vocab.items()}

    n = len(notes)
    fig, axes = plt.subplots(n, 1, figsize=(14, 3.0 * n))
    if n == 1:
        axes = [axes]

    for ax, note, true_label in zip(axes, notes, labels):
        tokens = tokenize(note)[:max_len]
        encoded = encode_note(note, vocab, max_len)
        x = torch.LongTensor([encoded]).to(device)

        with torch.no_grad():
            logits, attn_w = model(x, return_attention=True)
        pred_label = logits.argmax(dim=1).item()

        # Average attention across all query positions for each key position
        # This gives a single importance score per word
        attn = attn_w.squeeze(0).cpu().numpy()  # (seq_len, seq_len)
        word_importance = attn[:len(tokens), :len(tokens)].mean(axis=0)

        # Normalise for colour mapping
        if word_importance.max() > 0:
            word_importance = word_importance / word_importance.max()

        # Draw coloured bar per word
        cmap = plt.cm.YlOrRd
        for i, (token, score) in enumerate(zip(tokens, word_importance)):
            ax.barh(0, 1, left=i, color=cmap(score), edgecolor="white",
                    linewidth=0.5, height=0.6)
            ax.text(i + 0.5, 0, token, ha="center", va="center",
                    fontsize=7, rotation=45)

        ax.set_xlim(0, len(tokens))
        ax.set_ylim(-0.5, 0.5)
        ax.set_yticks([])
        correct = "OK" if pred_label == true_label else "X"
        ax.set_title(
            f"{correct}  True: {RESOLUTION_TYPES[true_label]}  |  "
            f"Pred: {RESOLUTION_TYPES[pred_label]}    "
            f"(darker = higher attention)",
            fontsize=9, loc="left",
        )

    plt.suptitle(
        "Attention Heatmaps — Which Words Drive the Prediction?",
        fontsize=12, fontweight="bold", y=1.02,
    )
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Attention heatmaps saved to {save_path}")


def plot_comparison_bar(acc_scratch, acc_glove, save_path):
    """Side-by-side bar chart comparing the two approaches."""
    fig, ax = plt.subplots(figsize=(7, 5))
    bars = ax.bar(
        ["Random Init\n(from scratch)", "GloVe Pre-trained\n(transfer learning)"],
        [acc_scratch * 100, acc_glove * 100],
        color=["#e74c3c", "#2ecc71"],
        edgecolor="black",
        width=0.5,
    )
    for bar, val in zip(bars, [acc_scratch, acc_glove]):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1,
                f"{val:.1%}", ha="center", fontsize=12, fontweight="bold")
    ax.set_ylabel("Test Accuracy (%)")
    ax.set_title(
        "Small Data Showdown: Random vs Pre-trained Embeddings\n"
        "(Same attention architecture, same small training set)",
    )
    ax.set_ylim(0, 110)
    ax.grid(True, alpha=0.3, axis="y")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Comparison chart saved to {save_path}")


def plot_word_embeddings(model, vocab, save_path, top_n=80):
    """Visualise the learned word embeddings with t-SNE, color-coded by the
    resolution category they are most associated with."""
    from sklearn.manifold import TSNE

    # Pick the top_n most frequent non-special tokens
    id2word = {i: w for w, i in vocab.items() if i >= 2}  # skip PAD, UNK
    if len(id2word) < top_n:
        top_n = len(id2word)
    selected_ids = sorted(id2word.keys())[:top_n]
    selected_words = [id2word[i] for i in selected_ids]

    weights = model.embedding.weight.detach().cpu().numpy()
    selected_vecs = weights[selected_ids]

    perp = min(15, top_n - 1)
    tsne = TSNE(n_components=2, perplexity=perp, random_state=42, max_iter=1000)
    coords = tsne.fit_transform(selected_vecs)

    # Assign colours based on which category template a word most likely came
    # from (heuristic: look at the templates)
    CATEGORY_KEYWORDS = {
        "REPLACE_HARDWARE":  {"faulty", "replaced", "swapped", "burn", "defective",
                              "cracked", "housing", "spare", "damaged", "dead",
                              "installed", "replacement", "water", "module"},
        "SOFTWARE_UPDATE":   {"firmware", "upgraded", "software", "update", "patch",
                              "flashed", "download", "version", "glitch", "bug"},
        "CABLE_REPAIR":      {"corroded", "splice", "cable", "chew", "fiber", "coax",
                              "copper", "strand", "fused", "terminated", "ingress",
                              "pinched", "drop", "underground"},
        "CONFIG_CHANGE":     {"configured", "vlan", "ssid", "mtu", "pppoe", "dns",
                              "qos", "bridged", "provisioning", "credentials",
                              "reconfigured", "settings", "template"},
        "POWER_CYCLE":       {"reboot", "power", "cycled", "restart", "unplugged",
                              "frozen", "unresponsive", "plugged", "pulled"},
        "ESCALATE_TIER3":    {"escalating", "intermittent", "recurring", "complex",
                              "engineering", "investigation", "tier3", "upstream",
                              "backhaul", "congestion", "documented", "multiple"},
        "NO_FAULT_FOUND":    {"passed", "normal", "spec", "nominal", "nff",
                              "reproduce", "indicators", "no", "fault", "found",
                              "checks", "meeting"},
    }
    cat_colors = {
        "REPLACE_HARDWARE": "#e74c3c",
        "SOFTWARE_UPDATE":  "#3498db",
        "CABLE_REPAIR":     "#e67e22",
        "CONFIG_CHANGE":    "#9b59b6",
        "POWER_CYCLE":      "#2ecc71",
        "ESCALATE_TIER3":   "#1abc9c",
        "NO_FAULT_FOUND":   "#95a5a6",
    }

    def word_category(w):
        for cat, kws in CATEGORY_KEYWORDS.items():
            if w in kws:
                return cat
        return "general"

    fig, ax = plt.subplots(figsize=(14, 10))

    # Plot general words first (grey, small)
    for i, word in enumerate(selected_words):
        cat = word_category(word)
        if cat == "general":
            ax.scatter(coords[i, 0], coords[i, 1], s=30, c="#cccccc",
                       edgecolors="grey", alpha=0.5, zorder=3)
            ax.annotate(word, (coords[i, 0], coords[i, 1]), fontsize=5,
                        alpha=0.5, ha="center", va="bottom",
                        textcoords="offset points", xytext=(0, 4))

    # Plot category words on top (coloured, larger)
    plotted_cats = set()
    for i, word in enumerate(selected_words):
        cat = word_category(word)
        if cat != "general":
            label = cat if cat not in plotted_cats else None
            plotted_cats.add(cat)
            ax.scatter(coords[i, 0], coords[i, 1], s=100, c=cat_colors[cat],
                       edgecolors="black", zorder=5, label=label)
            ax.annotate(word, (coords[i, 0], coords[i, 1]), fontsize=6,
                        fontweight="bold", ha="center", va="bottom",
                        textcoords="offset points", xytext=(0, 6))

    ax.set_title(
        "Learned Word Embeddings (t-SNE)\n"
        "Words associated with the same resolution cluster together",
        fontsize=11,
    )
    ax.legend(loc="best", fontsize=7, ncol=2)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  Word embeddings plot saved to {save_path}")


# ──────────────────────────────────────────────────────────────────────────────
# 8. MAIN — RUN THE DEMO
# ──────────────────────────────────────────────────────────────────────────────
def run_experiment(label, model, train_loader, val_loader, test_loader,
                   epochs=40, lr=0.002):
    """Train + evaluate a single model.  Returns (test_acc, y_pred, y_true,
    train_losses, val_accs)."""
    print(f"\n  --- {label} ---")
    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"  Trainable parameters: {total_params:,}")

    train_losses, val_accs = train_model(model, train_loader, val_loader,
                                         epochs=epochs, lr=lr)
    y_pred, y_true = evaluate_model(model, test_loader)
    test_acc = (y_pred == y_true).mean()
    print(f"  >> Test accuracy: {test_acc:.1%}")
    return test_acc, y_pred, y_true, train_losses, val_accs


def main():
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)

    MAX_LEN = 20  # max words per note (covers 99 % of templates)

    print("=" * 72)
    print("TELCO DEMO: Technician Notes -> Resolution Prediction")
    print("         Embeddings + Self-Attention (Pre-trained vs Scratch)")
    print("=" * 72)

    # ── Generate data ────────────────────────────────────────────────────
    # We intentionally use a SMALL dataset (50 notes per class = 350 total)
    # to simulate a realistic telco scenario where labeled data is scarce.
    # This is where pre-trained embeddings make a dramatic difference.
    print("\n[1] Generating synthetic technician field notes ...")
    print("  Training data uses the standard templates (50 notes/class).")
    print("  Test data uses PARAPHRASED notes with synonyms -- different words,")
    print("  same meaning.  This is the real challenge: can the model generalise")
    print("  to vocabulary it has NEVER seen in training?")

    # --- Training + validation from templates ---
    all_notes, all_labels = generate_notes(samples_per_class=50, word_dropout=0.0)
    combined = list(zip(all_notes, all_labels))
    random.shuffle(combined)
    all_notes, all_labels = zip(*combined)
    all_notes, all_labels = list(all_notes), list(all_labels)

    n = len(all_notes)
    n_train = int(0.80 * n)
    train_notes, train_labels = all_notes[:n_train], all_labels[:n_train]
    val_notes,   val_labels   = all_notes[n_train:], all_labels[n_train:]

    # --- Test set from paraphrased notes (synonyms the model has NOT trained on) ---
    test_notes, test_labels = [], []
    for label_idx, res_type in enumerate(RESOLUTION_TYPES):
        for note in PARAPHRASED_TEST_NOTES[res_type]:
            test_notes.append(note)
            test_labels.append(label_idx)

    print(f"  Train (templates) : {len(train_notes)}")
    print(f"  Val (templates)   : {len(val_notes)}")
    print(f"  Test (PARAPHRASED): {len(test_notes)}  <-- uses synonyms unseen in training!")
    print(f"  Classes : {NUM_CLASSES}  ({', '.join(RESOLUTION_TYPES)})")

    # Show a few examples
    print("\n  Sample notes:")
    for i in range(4):
        print(f"    [{RESOLUTION_TYPES[train_labels[i]]:20s}]  \"{train_notes[i]}\"")

    # ── Build vocabulary ─────────────────────────────────────────────────
    # In production you'd build vocab from ALL available text (labeled +
    # unlabeled tickets, knowledge base articles, etc.), not just the small
    # labeled training set.  We simulate this by including test notes in
    # vocab building.  This means words like "rusted" and "junction" get
    # vocab entries -- but only the GloVe model will have MEANINGFUL vectors
    # for them.  The random-init model will have random garbage vectors.
    print("\n[2] Building vocabulary from all available text ...")
    vocab = build_vocab(train_notes + val_notes + test_notes, min_freq=1)
    vocab_size = len(vocab)
    print(f"  Vocabulary size: {vocab_size} words")
    print(f"  (Built from train + test text, like a real domain corpus.)")
    print(f"  This means paraphrased words get vocab entries, but only GloVe")
    print(f"  gives them meaningful vectors -- random init gives random noise.)")

    # Encode
    X_train = [encode_note(n, vocab, MAX_LEN) for n in train_notes]
    X_val   = [encode_note(n, vocab, MAX_LEN) for n in val_notes]
    X_test  = [encode_note(n, vocab, MAX_LEN) for n in test_notes]

    train_loader = DataLoader(NotesDataset(X_train, train_labels), batch_size=32, shuffle=True)
    val_loader   = DataLoader(NotesDataset(X_val, val_labels),     batch_size=64)
    test_loader  = DataLoader(NotesDataset(X_test, test_labels),   batch_size=64)

    # ── Load pre-trained GloVe embeddings ────────────────────────────────
    print("\n[3] Loading pre-trained GloVe embeddings ...")
    glove_matrix, coverage = load_glove_embedding_matrix(vocab)

    # ══════════════════════════════════════════════════════════════════════
    # [4] HEAD-TO-HEAD: Random Init vs GloVe Pre-trained
    # ══════════════════════════════════════════════════════════════════════
    print("\n" + "=" * 72)
    print("[4] HEAD-TO-HEAD COMPARISON (same architecture, same small data)")
    print("=" * 72)
    print("""
  Both models have the EXACT same attention architecture.  The only
  difference is how the embedding layer is initialised:

    Approach A: Random vectors     -- attention must learn word meanings
                                      AND what to focus on (hard with few examples)
    Approach B: GloVe pre-trained  -- attention only learns what to focus on
                                      (word meanings come for free)
""")

    EPOCHS = 40
    LR = 0.002

    # --- Approach A: Random init (from scratch) ---
    torch.manual_seed(42)
    model_scratch = TechNoteAttentionClassifier(
        vocab_size=vocab_size,
        embed_dim=GLOVE_DIM,
        attn_dim=64,
        hidden_dim=128,
        num_classes=NUM_CLASSES,
        pad_idx=vocab[PAD_TOKEN],
        pretrained_weights=None,  # <-- random init
    )
    acc_scratch, _, _, losses_scratch, vaccs_scratch = run_experiment(
        "Approach A: Random Embeddings (from scratch)",
        model_scratch, train_loader, val_loader, test_loader,
        epochs=EPOCHS, lr=LR,
    )

    # --- Approach B: GloVe pre-trained ---
    torch.manual_seed(42)
    model_glove = TechNoteAttentionClassifier(
        vocab_size=vocab_size,
        embed_dim=GLOVE_DIM,
        attn_dim=64,
        hidden_dim=128,
        num_classes=NUM_CLASSES,
        pad_idx=vocab[PAD_TOKEN],
        pretrained_weights=glove_matrix,  # <-- GloVe vectors loaded!
        freeze_embeddings=False,          # fine-tune embeddings during training
    )
    acc_glove, y_pred, y_true, losses_glove, vaccs_glove = run_experiment(
        "Approach B: GloVe Pre-trained Embeddings",
        model_glove, train_loader, val_loader, test_loader,
        epochs=EPOCHS, lr=LR,
    )

    # ── Summary ──────────────────────────────────────────────────────────
    print("\n" + "-" * 72)
    print("  RESULT SUMMARY")
    print("-" * 72)
    print(f"  Random init accuracy : {acc_scratch:.1%}")
    print(f"  GloVe pre-trained    : {acc_glove:.1%}")
    delta = acc_glove - acc_scratch
    if delta > 0:
        print(f"  Improvement          : +{delta:.1%}")
        print(f"\n  Pre-trained embeddings give the attention mechanism a huge")
        print(f"  head start -- it already knows word meanings, so it only needs")
        print(f"  to learn WHICH words to attend to for each resolution class.")
    print("-" * 72)

    # ── Detailed report for the GloVe model ──────────────────────────────
    print("\n[5] Detailed classification report (GloVe model) ...")
    present_labels = sorted(set(y_true) | set(y_pred))
    target_names = [RESOLUTION_TYPES[i] for i in present_labels]
    print(classification_report(y_true, y_pred, labels=present_labels,
                                target_names=target_names, zero_division=0))

    # ── Visualisations ───────────────────────────────────────────────────
    print("[6] Generating visualisations ...")

    # Comparison bar chart
    plot_comparison_bar(
        acc_scratch, acc_glove,
        "nlp_transformers/embeddings/technote_pretrained_vs_scratch.png",
    )

    # Training curves for both models overlaid
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    ax1.plot(losses_scratch, linewidth=2, label="Random init", color="#e74c3c")
    ax1.plot(losses_glove, linewidth=2, label="GloVe pre-trained", color="#2ecc71")
    ax1.set_title("Training Loss")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Cross-Entropy Loss")
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    ax2.plot(vaccs_scratch, linewidth=2, label="Random init", color="#e74c3c")
    ax2.plot(vaccs_glove, linewidth=2, label="GloVe pre-trained", color="#2ecc71")
    ax2.set_title("Validation Accuracy")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Accuracy")
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig("nlp_transformers/embeddings/technote_training_curves.png",
                dpi=150, bbox_inches="tight")
    plt.close()
    print("  Training curves (both models) saved to technote_training_curves.png")

    # Confusion matrix for GloVe model
    plot_confusion_matrix(
        y_true, y_pred,
        "nlp_transformers/embeddings/technote_confusion_matrix.png",
    )

    # Attention heatmaps for GloVe model
    sample_notes, sample_labels = [], []
    seen = set()
    for note, label in zip(test_notes, test_labels):
        if label not in seen:
            sample_notes.append(note)
            sample_labels.append(label)
            seen.add(label)
        if len(seen) == NUM_CLASSES:
            break

    plot_attention_heatmaps(
        model_glove, sample_notes, sample_labels, vocab, MAX_LEN,
        "nlp_transformers/embeddings/technote_attention_heatmaps.png",
    )
    plot_word_embeddings(
        model_glove, vocab,
        "nlp_transformers/embeddings/technote_word_embeddings_tsne.png",
    )

    # ── Live prediction demo (GloVe model) ───────────────────────────────
    print("\n[7] Live prediction demo (GloVe pre-trained model) ...")
    device = next(model_glove.parameters()).device
    model_glove.eval()

    demo_notes = [
        "found corroded fiber splice at pedestal replaced connector and tested signal",
        "ONT firmware 3.1 outdated upgraded to 5.0 ran speed test OK",
        "power cycled router at customer-premises service came back up immediately",
        "intermittent signal loss cannot isolate cause escalating to engineering team",
        "all tests passed at premises ONT signal levels within spec no issue found",
    ]

    for note in demo_notes:
        encoded = encode_note(note, vocab, MAX_LEN)
        x = torch.LongTensor([encoded]).to(device)
        with torch.no_grad():
            logits, attn_w = model_glove(x, return_attention=True)
            probs = torch.softmax(logits, dim=1).squeeze()

        top3 = probs.topk(3)
        tokens = tokenize(note)[:MAX_LEN]

        # Get word-level attention for display
        attn = attn_w.squeeze(0).cpu().numpy()[:len(tokens), :len(tokens)]
        word_imp = attn.mean(axis=0)
        if word_imp.max() > 0:
            word_imp = word_imp / word_imp.max()
        top_words_idx = word_imp.argsort()[-3:][::-1]
        top_words = [tokens[i] for i in top_words_idx]

        print(f"\n  Note: \"{note}\"")
        print(f"  Top-3 predictions:")
        for rank, (prob, idx) in enumerate(zip(top3.values, top3.indices), 1):
            print(f"    {rank}. {RESOLUTION_TYPES[idx]:20s}  ({prob:.1%})")
        print(f"  Key attention words: {', '.join(top_words)}")

    # ── Takeaways ────────────────────────────────────────────────────────
    print("\n" + "=" * 72)
    print("KEY TAKEAWAYS")
    print("=" * 72)
    print("""
  1. PRE-TRAINED EMBEDDINGS solve the cold-start problem.  GloVe vectors
     give the model word knowledge learned from 6B words of text.  When
     the test set uses SYNONYMS unseen in training (e.g. "rusted junction"
     instead of "corroded splice"), GloVe knows these are related -- random
     init treats them as meaningless noise.

  2. WITHOUT pre-trained embeddings, the random-init model memorises
     training keywords but CANNOT generalise to paraphrased notes.  It must
     learn both what words MEAN and what to FOCUS on from the same small
     dataset -- and the synonym gap makes this impossible.

  3. SELF-ATTENTION learns which words matter for the prediction.  It
     up-weights diagnostic words ("corroded", "firmware", "escalating") and
     down-weights filler ("at", "and", "OK").

  4. INTERPRETABILITY is a major benefit.  The attention heatmaps let a
     supervisor audit WHY the model made a prediction -- critical for
     operational trust in telco environments.

  5. This architecture is a stepping stone to full Transformer encoders
     (like BERT), which stack multiple pre-trained attention layers and
     add positional encodings for even richer representations.
""")
    print("DONE -- See generated plots in nlp_transformers/embeddings/")
    print("=" * 72)


if __name__ == "__main__":
    main()
