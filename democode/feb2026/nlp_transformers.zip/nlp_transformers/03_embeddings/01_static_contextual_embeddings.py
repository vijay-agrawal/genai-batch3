"""
==============================================================================
  TELCO DEMO: Static Embeddings vs Contextual Embeddings
==============================================================================

USE CASE — Customer Support Ticket Semantic Search
----------------------------------------------------
A telecom company receives thousands of customer support tickets daily.
The system must find tickets similar to an incoming complaint so agents can:
  1. Check if the issue is already known
  2. Route the ticket to the right team
  3. Suggest resolutions from past tickets

THE PROBLEM — Polysemy (words with multiple meanings):
  Telecom jargon is full of ambiguous terms:
    "drop"    → dropped call  vs  cancel a plan  vs  decrease in speed
    "cell"    → cell tower    vs  cell phone     vs  biological cell
    "network" → mobile network vs social network
    "charge"  → battery charge vs billing charge
    "port"    → port a number  vs network port

  Static embeddings assign ONE fixed vector per word regardless of context.
  Contextual embeddings produce DIFFERENT vectors based on surrounding words.

  This demo shows how static embeddings FAIL on polysemous telco terms,
  and how contextual embeddings handle them CORRECTLY.

DESIGN OF THE EXPERIMENT
  The query talks about "call drops" (connectivity issue).
  - RELEVANT tickets describe the SAME problem but use DIFFERENT words:
    "disconnect", "fail", "cut out", "lose connection"
  - TRAP tickets use the word "drop" but mean CANCEL / REMOVE:
    "drop my plan", "drop the calling features"

  Static embeddings see "drop" ↔ "drop" (exact match, high similarity)
  but cannot see "drop" ↔ "disconnect" (different words, low similarity).
  So the TRAPS score higher than the genuinely relevant tickets.

  Contextual embeddings understand meaning from context:
    "call drops" ≈ "calls disconnect"  (same meaning → high similarity)
    "call drops" ≠ "drop my plan"      (different meaning → low similarity)

MODELS (all laptop-friendly):
  Static:      GloVe 50d via gensim  (glove-wiki-gigaword-50, ~66 MB)
  Contextual:  all-MiniLM-L6-v2 via sentence-transformers (~80 MB)
  Token-level: distilbert-base-uncased via transformers (~250 MB)

INSTALL:
  pip install gensim sentence-transformers scikit-learn torch transformers
==============================================================================
"""

import warnings
warnings.filterwarnings("ignore")

import re
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity


# ─────────────────────────────────────────────────────────────────────────────
#  DATA: Telco Customer Support Tickets
# ─────────────────────────────────────────────────────────────────────────────

QUERY = "Customers complaining about frequent call drops across the city"

TICKETS = [
    # ── Relevant: call-drop / signal-loss symptoms described WITHOUT "drop" ──
    "Phone calls get disconnected in the middle of conversations downtown",    # 0
    "Losing cellular connection and calls fail when entering the tunnel",     # 1
    "Widespread voice call disconnections reported during peak hours",        # 2
    "Poor reception causing calls to cut out in residential neighborhoods",   # 3

    # ── TRAP: word "drop" used as cancel/remove, heavy telco vocabulary ──
    "Customer called to drop the cell phone plan and cancel the account",     # 4
    "Subscriber wants to drop the premium calling features from the line",    # 5

    # ── Unrelated telco topics ──
    "How do I check my remaining data balance for this billing cycle",        # 6
    "I want to trade in my old phone and upgrade to the newest model",        # 7
]

# True = relevant to the query (call-drop / connectivity issues)
GROUND_TRUTH = [True, True, True, True, False, False, False, False]

TICKET_TAGS = [
    "Calls disconnected downtown ",
    "Connection fails in tunnel  ",
    "Disconnections at peak hours",
    "Calls cut out at home       ",
    "DROP cell plan     (TRAP!)  ",
    "DROP call features (TRAP!)  ",
    "Check data balance          ",
    "Upgrade phone               ",
]


# ─────────────────────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────────────────────

def header(title):
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)


def subheader(title):
    print(f"\n--- {title} ---\n")


def tokenize(text):
    """Lowercase and strip punctuation — good enough for GloVe look-ups."""
    return re.findall(r"[a-z0-9]+", text.lower())


def print_ranked(similarities):
    """Print tickets ranked by similarity to the query."""
    ranked_idx = np.argsort(similarities)[::-1]

    print(f'  Query: "{QUERY}"\n')
    print(f"  {'Rank':<5} {'Score':>7}   {'Ticket':<35} {'Relevant?'}")
    print(f"  {'---':<5} {'-----':>7}   {'---':<35} {'---'}")

    for rank, i in enumerate(ranked_idx, 1):
        tag   = TICKET_TAGS[i]
        score = similarities[i]
        mark  = "YES" if GROUND_TRUTH[i] else " no"
        print(f"  {rank:<5} {score:>7.4f}   {tag} {mark}")

    top4 = ranked_idx[:4]
    precision = sum(GROUND_TRUTH[i] for i in top4)
    print(f"\n  >> Top-4 precision: {precision}/4 relevant tickets in top 4")
    return precision


# ═════════════════════════════════════════════════════════════════════════════
#  PART 1 — STATIC EMBEDDINGS  (GloVe via gensim)
# ═════════════════════════════════════════════════════════════════════════════

def part1_static_embeddings():
    header("PART 1: STATIC EMBEDDINGS  (GloVe 50-d)")

    print("\n  Loading GloVe vectors (first run downloads ~66 MB) ...")
    import gensim.downloader as api
    glove = api.load("glove-wiki-gigaword-50")      # 50-dimensional, fast
    print("  Loaded.\n")

    # ── 1A  Word-level neighbours ────────────────────────────────────────
    subheader("1A · Nearest neighbours for telco words")

    for word in ["drop", "cell", "network", "signal", "tower", "charge"]:
        if word in glove:
            neighbours = glove.most_similar(word, topn=5)
            fmt = ", ".join(f"{w} ({s:.2f})" for w, s in neighbours)
            print(f"  {word:>8} -> {fmt}")

    # ── 1B  The polysemy problem ─────────────────────────────────────────
    subheader("1B · The polysemy problem")

    def extract_word_vector(sentence, target="drop"):
        """Tokenize a sentence and return the GloVe vector for `target`.
        This is exactly how static embeddings work: the surrounding words
        are completely ignored — only the target token is looked up."""
        tokens = tokenize(sentence)
        # find 'drop' or 'drops' (GloVe stores the lemma 'drop')
        for tok in tokens:
            if tok == target or tok == target + "s":
                return glove[target]           # always the same lookup
        return None

    polysemy_sentences = [
        ("Connectivity", "Customer reports frequent call drops in the city"),
        ("Cancellation", "I want to drop my cell phone plan immediately"),
        ("Degradation",  "There was a sudden drop in download speed"),
    ]

    print("  Passing three DIFFERENT sentences through GloVe and extracting")
    print("  the vector for 'drop' from each:\n")

    vecs = []
    for meaning, sent in polysemy_sentences:
        vec = extract_word_vector(sent)
        vecs.append(vec)
        preview = f"[{vec[0]:+.4f}, {vec[1]:+.4f}, {vec[2]:+.4f}, {vec[3]:+.4f}, ...]"
        print(f"    ({meaning:>12})  \"{sent}\"")
        print(f"                   -> 'drop' vector = {preview}\n")

    # Prove they are literally identical
    all_same = all(np.array_equal(vecs[0], v) for v in vecs[1:])
    print(f"  Are all three vectors IDENTICAL?  {'YES — exactly the same!' if all_same else 'NO'}")
    print("  GloVe completely ignores the rest of the sentence.")

    # Show that GloVe sees "drop" as DISTANT from its contextual synonyms
    print("\n  GloVe word-pair similarities:")
    for w1, w2 in [("drop", "disconnect"), ("drop", "fail"),
                    ("drop", "cancel"), ("drop", "remove"), ("drop", "fall")]:
        if w1 in glove and w2 in glove:
            print(f"    sim('{w1}', '{w2:>12}') = {glove.similarity(w1, w2):.4f}")

    print("""
  KEY INSIGHT:
    'drop' and 'disconnect' have LOW GloVe similarity even though
    'dropped call' and 'disconnected call' mean the SAME thing.

    'drop' and 'cancel' also have LOW similarity, yet that IS what
    'drop my plan' actually means.

    Because every occurrence of 'drop' maps to the SAME vector, the
    model cannot tell these apart.  This is the core limitation.
    """)

    # ── 1C  Ticket search with averaged word vectors ─────────────────────
    subheader("1C · Ticket search — averaging GloVe word vectors")

    def sentence_vector(text):
        """Average word vectors — standard bag-of-words approach."""
        vecs = [glove[w] for w in tokenize(text) if w in glove]
        return np.mean(vecs, axis=0) if vecs else np.zeros(glove.vector_size)

    q_vec = sentence_vector(QUERY)
    t_vecs = np.array([sentence_vector(t) for t in TICKETS])
    sims = cosine_similarity([q_vec], t_vecs)[0]

    precision = print_ranked(sims)

    # Explain result
    ranked = np.argsort(sims)[::-1]
    trap_positions = [list(ranked).index(4) + 1, list(ranked).index(5) + 1]
    print(f"\n  TRAP tickets ranked at positions: #{trap_positions[0]} and #{trap_positions[1]}")
    if min(trap_positions) <= 4:
        print("  !! At least one TRAP ticket infiltrated the top 4 because")
        print("     'drop' in the query directly matches 'drop' in the traps,")
        print("     while relevant tickets use 'disconnect'/'fail'/'cut out'")
        print("     which are DIFFERENT GloVe vectors.")

    return glove, sentence_vector, sims


# ═════════════════════════════════════════════════════════════════════════════
#  PART 2 — CONTEXTUAL EMBEDDINGS  (Sentence-Transformers)
# ═════════════════════════════════════════════════════════════════════════════

def part2_contextual_embeddings(glove, static_sv_fn):
    header("PART 2: CONTEXTUAL EMBEDDINGS  (all-MiniLM-L6-v2)")

    print("\n  Loading sentence-transformers model (~80 MB) ...")
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer("all-MiniLM-L6-v2")
    print("  Loaded.\n")

    # ── 2A  Ticket search ────────────────────────────────────────────────
    subheader("2A · Ticket search — contextual sentence embeddings")

    q_emb = model.encode([QUERY])
    t_embs = model.encode(TICKETS)
    sims = cosine_similarity(q_emb, t_embs)[0]

    precision = print_ranked(sims)

    ranked = np.argsort(sims)[::-1]
    trap_positions = [list(ranked).index(4) + 1, list(ranked).index(5) + 1]
    print(f"\n  TRAP tickets ranked at positions: #{trap_positions[0]} and #{trap_positions[1]}")
    if min(trap_positions) > 4:
        print("  All 4 relevant tickets are in the top 4!")
        print("  The model understands 'disconnected calls' ≈ 'call drops'")
        print("  and 'drop a plan' ≠ 'call drops'.")

    # ── 2B  Head-to-head pairwise comparison (the "smoking gun") ─────────
    subheader("2B · HEAD-TO-HEAD PAIRWISE COMPARISON")

    pair_relevant   = "Calls getting disconnected frequently in the city center"
    pair_irrelevant = "Customer wants to drop the cell phone calling plan"

    print(f'  Query (Q):       "{QUERY}"')
    print(f'  A (relevant):    "{pair_relevant}"')
    print(f'  B (irrelevant):  "{pair_irrelevant}"')

    # Static similarities
    q_s = static_sv_fn(QUERY)
    a_s = static_sv_fn(pair_relevant)
    b_s = static_sv_fn(pair_irrelevant)
    s_sim_a = cosine_similarity([q_s], [a_s])[0][0]
    s_sim_b = cosine_similarity([q_s], [b_s])[0][0]

    # Contextual similarities
    embs = model.encode([QUERY, pair_relevant, pair_irrelevant])
    c_sim_a = cosine_similarity([embs[0]], [embs[1]])[0][0]
    c_sim_b = cosine_similarity([embs[0]], [embs[2]])[0][0]

    print()
    print(f"  {'Method':<25} {'sim(Q,A)':>10} {'sim(Q,B)':>10}  {'Correct (A>B)?':>15}")
    print(f"  {'─' * 25} {'─' * 10} {'─' * 10}  {'─' * 15}")
    s_correct = "YES" if s_sim_a > s_sim_b else "NO  <-- WRONG"
    c_correct = "YES" if c_sim_a > c_sim_b else "NO  <-- WRONG"
    print(f"  {'Static  (GloVe avg)':<25} {s_sim_a:>10.4f} {s_sim_b:>10.4f}  {s_correct:>15}")
    print(f"  {'Contextual (MiniLM)':<25} {c_sim_a:>10.4f} {c_sim_b:>10.4f}  {c_correct:>15}")

    if s_sim_a < s_sim_b and c_sim_a > c_sim_b:
        print("""
  STATIC gets it WRONG:
    The irrelevant ticket (B) scores HIGHER than the relevant one (A)!
    Why? Because B contains 'drop' and 'calling' which match the query's
    'drops' and 'call' directly in GloVe vector space.  Meanwhile, A uses
    'disconnected' — a totally different GloVe vector, even though it means
    the same thing as 'dropped' in this context.

  CONTEXTUAL gets it RIGHT:
    MiniLM understands that 'calls getting disconnected' describes the same
    problem as 'call drops', and that 'drop the phone plan' is about
    cancellation — a completely different intent.
        """)
    elif c_sim_a > c_sim_b:
        print("\n  Contextual model correctly ranks A > B (meaning over words).")
    print()

    return sims


# ═════════════════════════════════════════════════════════════════════════════
#  PART 3 — WHY IT WORKS: Token-Level Context Sensitivity
# ═════════════════════════════════════════════════════════════════════════════

def part3_token_analysis():
    header("PART 3: WHY IT WORKS — Token-Level Analysis  (DistilBERT)")

    print("\n  Extracting the hidden-state vector for the token 'drop' in")
    print("  four different sentences.  If embeddings are truly contextual,")
    print("  the vectors should DIFFER depending on meaning.\n")

    import torch
    from transformers import AutoTokenizer, AutoModel

    tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
    bert = AutoModel.from_pretrained("distilbert-base-uncased")
    bert.eval()

    # Four sentences — same word "drop", different meanings
    sentences = {
        "call_drop":    "the customer experienced a call drop in the city",
        "cancel_plan":  "I want to drop my current cell phone plan today",
        "speed_drop":   "there was a big drop in network speed last night",
        "signal_drop":  "the phone signal drop happens inside the elevator",
    }

    nice_labels = {
        "call_drop":    "call drop   (connectivity)",
        "cancel_plan":  "drop plan   (cancellation)",
        "speed_drop":   "speed drop  (degradation) ",
        "signal_drop":  "signal drop (connectivity)",
    }

    def extract_drop_vector(sentence):
        """Return the last-hidden-state vector at the position of 'drop'."""
        inputs = tokenizer(sentence, return_tensors="pt")
        token_ids = inputs["input_ids"][0].tolist()
        tokens = tokenizer.convert_ids_to_tokens(token_ids)

        # find first occurrence of 'drop'
        drop_idx = next(i for i, t in enumerate(tokens) if t == "drop")

        with torch.no_grad():
            hidden = bert(**inputs).last_hidden_state      # (1, seq, 768)
        return hidden[0, drop_idx].numpy()

    vecs = {k: extract_drop_vector(s) for k, s in sentences.items()}

    # ── Pairwise similarity matrix ───────────────────────────────────────
    subheader("Cosine similarity of 'drop' token across contexts")

    keys = list(sentences.keys())
    short = ["call_drop", "cancel", "speed", "signal"]

    # header row
    print(f"  {'':>30}", end="")
    for s in short:
        print(f" {s:>10}", end="")
    print()

    for k1, s1 in zip(keys, short):
        print(f"  {nice_labels[k1]:>30}", end="")
        for k2 in keys:
            sim = cosine_similarity([vecs[k1]], [vecs[k2]])[0][0]
            print(f" {sim:>10.3f}", end="")
        print()

    print("""
  KEY OBSERVATIONS
  ---------------------------------------------------------------
  * "call drop" and "signal drop" should have HIGH similarity
      -> DistilBERT recognises both refer to connectivity loss.

  * "call drop" and "drop plan" should have LOWER similarity
      -> DistilBERT recognises 'drop' means cancellation there.

  * "speed drop" may cluster differently from both — it refers
    to degradation, a third distinct meaning of "drop".

  * With static embeddings, ALL four would have the EXACT SAME
    vector for 'drop' — making these distinctions impossible.
  ---------------------------------------------------------------
    """)


# ═════════════════════════════════════════════════════════════════════════════
#  PART 4 — SIDE-BY-SIDE COMPARISON
# ═════════════════════════════════════════════════════════════════════════════

def part4_summary(static_sims, contextual_sims):
    header("PART 4: SIDE-BY-SIDE COMPARISON")

    print(f"\n  {'Ticket':<35} {'Static':>8} {'Context':>8} {'Relevant':>9}")
    print(f"  {'─' * 35} {'─' * 8} {'─' * 8} {'─' * 9}")

    for i in range(len(TICKETS)):
        tag = TICKET_TAGS[i]
        ss  = static_sims[i]
        cs  = contextual_sims[i]
        rel = "YES" if GROUND_TRUTH[i] else " no"
        print(f"  {tag:<35} {ss:>8.4f} {cs:>8.4f} {rel:>9}")

    s_ranked = np.argsort(static_sims)[::-1]
    c_ranked = np.argsort(contextual_sims)[::-1]
    s_top4 = sum(GROUND_TRUTH[i] for i in s_ranked[:4])
    c_top4 = sum(GROUND_TRUTH[i] for i in c_ranked[:4])

    print(f"""
  ┌────────────────────────────────────────────────────────────────┐
  │  METRIC               STATIC (GloVe)    CONTEXTUAL (MiniLM)   │
  │  Top-4 precision         {s_top4}/4                {c_top4}/4              │
  └────────────────────────────────────────────────────────────────┘

  TAKEAWAYS
  ─────────────────────────────────────────────────────────────────
  Static Embeddings (Word2Vec / GloVe)
    + Fast, lightweight, easy to train
    + Good baseline for simple keyword matching
    - ONE fixed vector per word — ignores context
    - Cannot bridge synonyms:  "drop" ≠ "disconnect" in GloVe
      even when they mean the same thing ("dropped call")
    - Fooled by polysemy: "drop a plan" looks like "call drops"

  Contextual Embeddings (BERT / Sentence-Transformers)
    + Each token's vector depends on the FULL sentence
    + Bridges synonyms: understands "disconnect" ≈ "drop" for calls
    + Resists polysemy: "drop plan" ≠ "call drops"
    + Far better for semantic search, NLU, and classification
    - Slightly heavier compute (but still runs on a laptop)
  ─────────────────────────────────────────────────────────────────
    """)


# ═════════════════════════════════════════════════════════════════════════════
#  MAIN
# ═════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":

    banner = """
    ╔══════════════════════════════════════════════════════════════╗
    ║   TELCO DEMO: Static vs Contextual Embeddings              ║
    ║   Scenario — Customer Support Ticket Semantic Search        ║
    ╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)

    glove, sv_fn, static_sims = part1_static_embeddings()
    contextual_sims = part2_contextual_embeddings(glove, sv_fn)
    part3_token_analysis()
    part4_summary(static_sims, contextual_sims)

    print("  Demo complete.  All models ran locally on this machine.\n")
