"""
TF-IDF News Article Classifier
================================
Classifies news articles into Sports, Entertainment, or Politics
using TF-IDF vectorization and a Naive Bayes classifier.

This demo uses a small labelled training set to train the model,
then classifies the articles stored in the data/ folder.
"""

import os
import glob
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_score
import numpy as np

# ---------------------------------------------------------------------------
# 1. Training data – short Indian-context snippets for each category
# ---------------------------------------------------------------------------
training_texts = [
    # --- Sports ---
    "India won the cricket world cup final with a brilliant batting performance by Virat Kohli",
    "Jasprit Bumrah took five wickets to bowl out England in the Test match at Wankhede Stadium",
    "PV Sindhu clinched the badminton gold medal at the Asian Games representing India",
    "The Indian hockey team defeated Pakistan in a thrilling Champions Trophy semifinal",
    "Neeraj Chopra broke the national javelin record at the National Athletics Championship in Bhubaneswar",
    "IPL auction saw Mumbai Indians bid 16 crore for the star all-rounder ahead of the new season",
    "Indian football team qualified for the AFC Asian Cup with a win over Kuwait in Kolkata",
    "Mary Kom won her sixth World Boxing Championship title bringing glory to Indian sports",
    "Rohit Sharma scored a double century in ODI cricket against Sri Lanka at Eden Gardens",
    "The Pro Kabaddi League final saw Patna Pirates defeat Jaipur Pink Panthers",

    # --- Entertainment ---
    "Aamir Khan's new film earned 200 crore at the Bollywood box office in opening weekend",
    "AR Rahman won the National Film Award for best music direction for a Tamil movie",
    "The new web series on Netflix featuring Nawazuddin Siddiqui received rave reviews from critics",
    "Arijit Singh's concert tour across Indian cities sold out within minutes of ticket release",
    "Deepika Padukone and Ranveer Singh starred in the highest grossing Hindi film this year",
    "South Indian blockbuster RRR directed by Rajamouli swept awards at international film festivals",
    "Priyanka Chopra returned to Bollywood with a new movie produced by Dharma Productions",
    "The Filmfare Awards ceremony was held in Mumbai celebrating the best of Indian cinema",
    "Allu Arjun's Pushpa sequel shattered box office records across all Indian languages",
    "Lata Mangeshkar was honoured with a lifetime achievement award at the IIFA ceremony",

    # --- Politics ---
    "Prime Minister Narendra Modi addressed the nation on Independence Day from the Red Fort in Delhi",
    "The Lok Sabha passed the new GST amendment bill after heated debate between BJP and Congress",
    "Rahul Gandhi led the Bharat Jodo Yatra across states demanding action on unemployment",
    "Chief Minister Mamata Banerjee announced new welfare schemes for farmers in West Bengal",
    "The Election Commission announced dates for assembly elections in five states including Uttar Pradesh",
    "Rajya Sabha witnessed a stormy session as opposition demanded discussion on price rise and inflation",
    "Arvind Kejriwal inaugurated new government schools and hospitals in Delhi under AAP governance",
    "The Supreme Court of India delivered a landmark verdict on the constitutional validity of reservations",
    "Finance Minister Nirmala Sitharaman presented the Union Budget allocating funds for rural development",
    "State elections in Karnataka saw a massive voter turnout with Congress and BJP in a close contest",
]

training_labels = (
    ["sports"] * 10 + ["entertainment"] * 10 + ["politics"] * 10
)

# ---------------------------------------------------------------------------
# 2. Build a TF-IDF + Naive Bayes pipeline
# ---------------------------------------------------------------------------

#ngram_range=(1, 2) allows the model to capture both single words (unigrams) and pairs of consecutive words (bigrams). 
# This can help the model learn more contextual information from the text, such as common phrases or collocations that are 
# characteristic of each category.
# For example, "cricket world cup" or "box office" are bigrams that might be strong indicators of sports and entertainment articles,
# respectively.

# Naive Bayes is a simple yet effective algorithm for text classification tasks, especially when combined with TF-IDF features.
# It works well with high-dimensional data like text and can capture the importance of words in different categories based on their 
# frequency and distribution in the training data.
# It differs from just doing frequency counts by weighting the features according to their importance in the corpus, which can lead 
# to better performance in classification tasks.
# alpha is a hyperparameter for smoothing in Naive Bayes. Setting alpha=0.1 means that we are applying a small amount of smoothing 
# to the feature probabilities, which can help prevent zero probabilities for features that may not appear in the training data
# for a given class. This can improve the model's ability to generalize to unseen data and reduce overfitting, especially when working with a small training set.
pipeline = Pipeline([
    ("tfidf", TfidfVectorizer(
        stop_words="english",
        max_features=5000,
        ngram_range=(1, 2), 
    )),
    ("clf", MultinomialNB(alpha=0.1)),
])

print("=" * 65)
print("  TF-IDF News Article Classifier – Indian News Demo")
print("=" * 65)

# Cross-validation on training data
# Cross validation is important to get a more reliable estimate of model performance, especially with a small training set. 
# It helps us understand how well the model might generalize to unseen data.
# With cross validation, we split the training data into 5 folds, train on 4 folds and test on the remaining fold, repeating this process 5 times. 
# This gives us a better estimate of the model's performance and helps identify if it's overfitting to the small training set.
scores = cross_val_score(pipeline, training_texts, training_labels, cv=5)
print(f"\nTraining cross-validation accuracy: {scores.mean():.2f} "
      f"(+/- {scores.std():.2f})")

# Fit on full training set
pipeline.fit(training_texts, training_labels)

# ---------------------------------------------------------------------------
# 3. Show top TF-IDF features per category
# ---------------------------------------------------------------------------
tfidf = pipeline.named_steps["tfidf"]
clf = pipeline.named_steps["clf"]
feature_names = np.array(tfidf.get_feature_names_out())

print("\n--- Top TF-IDF features per category ---")
for i, category in enumerate(clf.classes_):
    top_indices = np.argsort(clf.feature_log_prob_[i])[-8:][::-1]
    top_features = feature_names[top_indices]
    print(f"  {category.upper():>15s}: {', '.join(top_features)}")

# ---------------------------------------------------------------------------
# 4. Classify articles from the data/ folder
# ---------------------------------------------------------------------------
data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
article_paths = sorted(glob.glob(os.path.join(data_dir, "*.txt")))

if not article_paths:
    print(f"\nNo .txt articles found in {data_dir}")
else:
    print(f"\n{'=' * 65}")
    print(f"  Classifying {len(article_paths)} articles from data/ folder")
    print(f"{'=' * 65}")

    for path in article_paths:
        with open(path, encoding="utf-8") as f:
            text = f.read()

        filename = os.path.basename(path)
        predicted = pipeline.predict([text])[0]
        probabilities = pipeline.predict_proba([text])[0]
        class_labels = pipeline.classes_

        print(f"\n  File: {filename}")
        print(f"  Predicted category: ** {predicted.upper()} **")
        print(f"  Confidence scores:")
        for label, prob in sorted(zip(class_labels, probabilities),
                                  key=lambda x: -x[1]):
            bar = "#" * int(prob * 40)
            print(f"    {label:>15s}: {prob:.3f}  {bar}")

print(f"\n{'=' * 65}")
print("  Demo complete.")
print(f"{'=' * 65}")
