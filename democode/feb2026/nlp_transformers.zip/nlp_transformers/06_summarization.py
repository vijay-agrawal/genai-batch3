"""
06_summarization.py - Text Summarization with a Small Language Model (Telco Context)

Demonstrates four summarization techniques using an SLM on a CPU laptop:
  1. Extractive-style summary  - condense to key facts and figures
  2. Abstractive summary       - generate a fluent natural-language rewrite
  3. Audience-targeted summary - same source, different audiences (exec vs engineer)
  4. Multi-document summary    - combine several NOC tickets into one brief

Default model : Qwen/Qwen2.5-1.5B-Instruct  (1.5 B params, ~6 GB RAM)
Alternatives are listed below; swap via MODEL_ID env variable.
"""

import os
import time
import torch
from transformers import pipeline

# ---------------------------------------------------------------------------
# Model selection
# Override via environment variable:  MODEL_ID="Qwen/Qwen2.5-0.5B-Instruct" python 06_summarization.py
# ---------------------------------------------------------------------------
MODEL_ID = os.getenv("MODEL_ID", "Qwen/Qwen2.5-1.5B-Instruct")

# Alternatives (uncomment one or set MODEL_ID env variable):
# MODEL_ID = "Qwen/Qwen2.5-0.5B-Instruct"              # 0.5B  ~2 GB RAM  - fastest
# MODEL_ID = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"      # 1.1B  ~4.5 GB RAM
# MODEL_ID = "microsoft/Phi-3-mini-4k-instruct"         # 3.8B  ~15 GB RAM - best quality
# MODEL_ID = "google/gemma-2-2b-it"                     # 2.0B  ~8 GB RAM

# ---------------------------------------------------------------------------
# Load model
# ---------------------------------------------------------------------------
print(f"Loading model: {MODEL_ID}")
print("(First run downloads the weights; subsequent runs use the cache.)")
print("(Downloaded models are saved in ~/.cache/huggingface/hub/models)\n")

t_load = time.time()
generator = pipeline(
    "text-generation",
    model=MODEL_ID,
    torch_dtype=torch.float32,   # float32 for broad CPU compatibility
    device="cpu",
    trust_remote_code=True,
)
print(f"Model loaded in {time.time() - t_load:.1f}s\n")


def summarize(system: str, user: str, max_tokens: int = 300) -> str:
    """Send a chat-style prompt to the SLM and return the response."""
    messages = [
        {"role": "system", "content": system},
        {"role": "user",   "content": user},
    ]
    t0 = time.time()
    output = generator(
        messages,
        max_new_tokens=max_tokens,
        do_sample=False,
        return_full_text=False,
    )
    elapsed = time.time() - t0

    # Handle different return formats across transformers versions
    result = output[0]["generated_text"]
    if isinstance(result, list):
        text = result[-1].get("content", str(result[-1]))
    elif isinstance(result, dict):
        text = result.get("content", str(result))
    else:
        text = str(result)

    print(f"  [generated in {elapsed:.1f}s]\n")
    return text.strip()


def banner(title: str) -> None:
    width = 70
    print("\n" + "=" * width)
    print(f"  {title}")
    print("=" * width)


# ---------------------------------------------------------------------------
# Source documents (telco-themed)
# ---------------------------------------------------------------------------

INCIDENT_REPORT = """\
INCIDENT REPORT — INC-2025-07-1842

Date/Time  : 2025-07-14  02:47 UTC
Severity   : P1 — Service Affecting
Region     : Midwest — Milwaukee Metro
Duration   : 4 hours 23 minutes (02:47 – 07:10 UTC)

Summary of Events:
At 02:47 UTC, the Network Operations Center (NOC) received S1 interface
DOWN alarms for eNodeB site MKE-0093, serving the downtown Milwaukee
business district. Approximately 1,200 LTE subscribers lost service.
Neighbouring sites MKE-0091 and MKE-0095 experienced a 35% traffic
surge as displaced users attempted to re-attach.

Root Cause Analysis:
Investigation revealed that a third-party fiber contractor performing
overnight duct work on West Wisconsin Avenue accidentally severed the
primary fiber-backhaul span feeding MKE-0093. The redundant path had
been taken out of service three days earlier for a planned splice
upgrade (CHG-2025-07-0455) and had not yet been restored.

Impact:
- 1,200 subscribers without LTE for up to 4 h 23 min.
- 3 enterprise customers on dedicated APN reported SLA breaches.
- Estimated revenue impact: $18,400 (SLA credits + churn risk).
- 22 customer complaints logged via IVR and retail channels.

Resolution:
The field team performed an emergency fiber splice at 05:30 UTC.
Service was incrementally restored starting at 06:15 UTC, with full
restoration confirmed at 07:10 UTC. The redundant backhaul path was
expedited and brought online at 11:00 UTC the same day.

Follow-up Actions:
1. Mandatory dig-notification process update for third-party contractors.
2. Change-management policy update: no single-path window > 24 hours
   for P1-class cell sites.
3. Proactive SLA-credit issuance to the 3 affected enterprise accounts.
4. Post-incident review scheduled for 2025-07-18.\
"""

NETWORK_PERFORMANCE_REPORT = """\
QUARTERLY NETWORK PERFORMANCE REPORT — Q2 2025
Region: South-Central (Texas, Oklahoma, Arkansas, Louisiana)

1. Traffic & Capacity
   - Total data traffic grew 14% QoQ to 285 PB, driven by 5G mid-band
     adoption and streaming video.
   - Peak-hour cell utilization averaged 68%, up from 61% in Q1.
   - 42 cell sites exceeded the 85% utilization threshold during peak
     hours, up from 29 last quarter — these are flagged for capacity
     augmentation in the H2 2025 capital plan.

2. Coverage & Availability
   - Network availability held at 99.97%, exceeding the 99.95% target.
   - FirstNet (Band 14) availability reached 99.99%.
   - 38 new small cells deployed in DFW metro to address in-building
     coverage gaps identified through drive-test campaigns.

3. Customer Experience
   - Median download speed on 5G mid-band: 224 Mbps (up 12% QoQ).
   - Median download speed on LTE: 48 Mbps (flat QoQ).
   - VoLTE MOS score averaged 3.9 across the region (target ≥ 3.7).
   - Customer complaints related to coverage dropped 9% QoQ.

4. Incidents & Reliability
   - Total P1 incidents: 7 (down from 11 in Q1).
   - Mean-Time-To-Restore (MTTR) for P1 incidents: 2.8 hours
     (improved from 3.4 hours in Q1).
   - Two fiber-cut events accounted for 4 of the 7 P1 incidents;
     contractor coordination improvements are underway.

5. Capital Projects
   - C-band (n77) deployment reached 72% of planned sites (target 80%
     by year-end).
   - ORAN Phase 1 lab validation complete; field trials scheduled for
     Q3 in Oklahoma City.
   - Legacy 3G CDMA shutdown completed on schedule; spectrum re-farmed
     to LTE/NR.\
"""

NOC_TICKETS = [
    {
        "id": "TT-90421",
        "time": "2025-08-02 14:12 UTC",
        "site": "DAL-0217",
        "summary": (
            "Multiple RRC setup failures reported on cell sector 2 of site "
            "DAL-0217 (North Dallas). RRC success rate dropped to 74% from a "
            "baseline of 99.2%. Sectors 1 and 3 are unaffected. RF team "
            "dispatched; preliminary analysis points to a faulty RRU on the "
            "sector-2 antenna. 850 subscribers on sector 2 are experiencing "
            "degraded service. Parts ordered; ETA 6 hours."
        ),
    },
    {
        "id": "TT-90433",
        "time": "2025-08-02 15:05 UTC",
        "site": "DAL-0218",
        "summary": (
            "Neighbouring site DAL-0218 reports 28% traffic increase on all "
            "three sectors following DAL-0217 degradation, as displaced users "
            "re-select. Peak-hour PRB utilization has risen to 91%. No alarms "
            "yet, but site is approaching congestion threshold. Capacity "
            "boost (additional carrier activation) being evaluated."
        ),
    },
    {
        "id": "TT-90447",
        "time": "2025-08-02 16:30 UTC",
        "site": "DAL-0217",
        "summary": (
            "Field technician confirms RRU hardware failure on DAL-0217 "
            "sector 2. Replacement unit installed and powered on at 16:20 UTC. "
            "RRC success rate recovering — currently at 96.1% and trending "
            "upward. Full restoration expected within 30 minutes once the "
            "baseband re-optimizes. DAL-0218 traffic levels beginning to "
            "normalize."
        ),
    },
    {
        "id": "TT-90452",
        "time": "2025-08-02 17:15 UTC",
        "site": "DAL-0217",
        "summary": (
            "DAL-0217 sector 2 fully restored. RRC success rate back to "
            "99.1%. DAL-0218 traffic has returned to baseline. Total outage "
            "duration: 3 hours 3 minutes. 850 subscribers impacted. Root "
            "cause: RRU hardware failure (thermal shutdown due to fan "
            "malfunction). Preventive maintenance review requested for all "
            "RRUs deployed in the same batch (Batch RRU-2024-Q3-017)."
        ),
    },
]


# ===================================================================
# 1. EXTRACTIVE-STYLE SUMMARY — Key facts and figures
# ===================================================================
banner("1. EXTRACTIVE-STYLE SUMMARY")
print("""
Technique: Instruct the model to extract only the key facts, dates,
           and figures — no paraphrasing, just the essential data points.
Source   : A P1 network-outage incident report.
""")

prompt_extractive = f"""\
Extract the key facts from this incident report as a concise bullet-point
list. Include only: date/time, affected site, root cause, impact numbers,
resolution time, and follow-up actions. Do not paraphrase — use the
original wording where possible.

INCIDENT REPORT:
{INCIDENT_REPORT}"""

print("Source document: INC-2025-07-1842 (incident report, ~250 words)")
print("\nExtracted summary:")
print(summarize(
    system="You are a telecom NOC analyst. Extract key facts concisely.",
    user=prompt_extractive,
    max_tokens=350,
))

# ===================================================================
# 2. ABSTRACTIVE SUMMARY — Fluent natural-language rewrite
# ===================================================================
banner("2. ABSTRACTIVE SUMMARY")
print("""
Technique: The model generates a new, fluent paragraph that captures
           the essence of the report in its own words.
Source   : Same incident report as above.
""")

prompt_abstractive = f"""\
Write a concise 3-4 sentence summary of the following incident report.
Use natural language and capture the what, why, impact, and resolution.

INCIDENT REPORT:
{INCIDENT_REPORT}"""

print("Abstractive summary:")
print(summarize(
    system="You are a telecom technical writer. Summarize clearly and concisely.",
    user=prompt_abstractive,
    max_tokens=200,
))

# ===================================================================
# 3. AUDIENCE-TARGETED SUMMARY — Same source, different readers
# ===================================================================
banner("3. AUDIENCE-TARGETED SUMMARY")
print("""
Technique: Summarize the same report for two different audiences:
           (a) A VP / executive stakeholder  (business impact focus)
           (b) A network engineer            (technical detail focus)
Source   : Quarterly network performance report.
""")

# --- 3a: Executive summary ---
prompt_exec = f"""\
Summarize the following quarterly network report for a VP-level audience.
Focus on business impact: revenue risk, customer experience trends, SLA
performance, and strategic capital investment progress. Keep it under
5 bullet points.

REPORT:
{NETWORK_PERFORMANCE_REPORT}"""

print("--- 3a. Executive Summary (VP audience) ---")
print(summarize(
    system="You are a telecom strategy advisor writing for senior leadership.",
    user=prompt_exec,
    max_tokens=300,
))

# --- 3b: Engineering summary ---
prompt_eng = f"""\
Summarize the following quarterly network report for a network engineering
audience. Focus on: capacity hotspots, KPI trends (RRC, PRB, MOS, MTTR),
deployment milestones, and any sites requiring immediate action. Keep it
under 5 bullet points.

REPORT:
{NETWORK_PERFORMANCE_REPORT}"""

print("--- 3b. Engineering Summary (network engineer audience) ---")
print(summarize(
    system="You are a senior RF engineer summarizing for the engineering team.",
    user=prompt_eng,
    max_tokens=300,
))

# ===================================================================
# 4. MULTI-DOCUMENT SUMMARY — Combine several NOC tickets
# ===================================================================
banner("4. MULTI-DOCUMENT SUMMARY")
print("""
Technique: Consolidate a sequence of related trouble tickets into a
           single coherent narrative — timeline, root cause, resolution.
Source   : Four NOC trouble tickets for a site outage event.
""")

tickets_text = "\n\n".join(
    f"TICKET {t['id']} ({t['time']}) — Site {t['site']}:\n{t['summary']}"
    for t in NOC_TICKETS
)

prompt_multi = f"""\
The following four NOC trouble tickets describe a single outage event.
Consolidate them into one concise summary paragraph that covers:
timeline, root cause, impact, resolution, and recommended follow-up.

{tickets_text}"""

print(f"Source: {len(NOC_TICKETS)} related trouble tickets")
print("\nConsolidated summary:")
print(summarize(
    system="You are a telecom NOC shift lead writing a consolidated incident brief.",
    user=prompt_multi,
    max_tokens=300,
))

# ===================================================================
# Summary
# ===================================================================
banner("SUMMARY")
print("""
  Technique             | What it does                          | Telco Use Case
  ----------------------+---------------------------------------+-------------------------------
  Extractive-style      | Pulls key facts verbatim              | Incident fact sheets
  Abstractive           | Rewrites in fluent natural language    | Stakeholder notifications
  Audience-targeted     | Same data, different depth & focus     | Exec vs engineering briefs
  Multi-document        | Merges related docs into one brief     | NOC shift-handover summaries

  Model used: {model}
""".format(model=MODEL_ID))
