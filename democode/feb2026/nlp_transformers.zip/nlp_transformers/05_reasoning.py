"""
05_reasoning.py - Reasoning Capabilities of a Small Language Model (Telco Context)

Demonstrates four types of reasoning using an SLM that runs on a CPU laptop:
  1. Inferencing        - drawing conclusions from stated facts
  2. Deductive reasoning - general rule  -> specific conclusion
  3. Inductive reasoning - specific observations -> general rule
  4. Abductive reasoning - observations -> most likely explanation

Default model : Qwen/Qwen2.5-1.5B-Instruct  (1.5 B params, ~6 GB RAM)
Alternatives are listed below; swap via MODEL_ID env variable.
"""

import os
import time
import torch
from transformers import pipeline

# ---------------------------------------------------------------------------
# Model selection
# Override via environment variable:  MODEL_ID="Qwen/Qwen2.5-1.5B-Instruct" python 05_reasoning.py
# ---------------------------------------------------------------------------
MODEL_ID = os.getenv("MODEL_ID", "Qwen/Qwen2.5-1.5B-Instruct")

# Alternatives (uncomment one or set MODEL_ID env variable):
# MODEL_ID = "Qwen/Qwen2.5-0.5B-Instruct"              # 0.5B  ~2 GB RAM  - fastest
# MODEL_ID = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"      # 1.1B  ~4.5 GB RAM
# MODEL_ID = "microsoft/Phi-3-mini-4k-instruct"         # 3.8B  ~15 GB RAM - best quality
# MODEL_ID = "google/gemma-2-2b-it"                     # 2.0B  ~8 GB RAM

# ---------------------------------------------------------------------------
# Load model
# ---------------------------------------------------------------------------
print(f"Loading model: {MODEL_ID}")
print("(First run downloads the weights; subsequent runs use the cache.)\n")
print("(Downloaded models are saved in ~/.cache/huggingface/hub/models)\n")

t_load = time.time()
generator = pipeline(
    "text-generation",
    model=MODEL_ID,
    torch_dtype=torch.float32,   # float32 for broad CPU compatibility
    device="cpu",
    trust_remote_code=True,
)
print(f"Model loaded in {time.time() - t_load:.1f}s\n")

SYSTEM_PROMPT = (
    "You are a senior telecom network engineer at a major US carrier. "
    "Provide clear, concise, and technically accurate answers."
)


def reason(prompt: str, max_tokens: int = 300) -> str:
    """Send a chat-style prompt to the SLM and return the response."""
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user",   "content": prompt},
    ]
    t0 = time.time()
    output = generator(
        messages,
        max_new_tokens=max_tokens,
        do_sample=False,
        return_full_text=False,
    )
    elapsed = time.time() - t0

    # Handle different return formats across transformers versions
    result = output[0]["generated_text"]
    if isinstance(result, list):
        text = result[-1].get("content", str(result[-1]))
    elif isinstance(result, dict):
        text = result.get("content", str(result))
    else:
        text = str(result)

    print(f"  [generated in {elapsed:.1f}s]\n")
    return text.strip()


def banner(title: str) -> None:
    width = 70
    print("\n" + "=" * width)
    print(f"  {title}")
    print("=" * width)


# ===================================================================
# 1. INFERENCING - Draw conclusions from stated facts
# ===================================================================
banner("1. INFERENCING")
print("""
Type : Drawing conclusions directly from given information.
Scenario: A customer's account data is provided; the model infers
          likely behaviour and recommended actions.
""")

prompt_inference = """\
A postpaid wireless customer shows the following account signals:
- Data usage jumped from 5 GB/month to 45 GB/month over the last 60 days.
- Three new lines were added to the account last month.
- Mobile-hotspot usage is now active daily.
- The customer called the IVR twice asking about international roaming rates.

Based on these facts, what can you infer about this customer's situation
and what proactive steps should the carrier take?"""

print("Prompt:", prompt_inference)
print("\nResponse:", reason(prompt_inference))

# ===================================================================
# 2. DEDUCTIVE REASONING - General rule -> specific conclusion
# ===================================================================
banner("2. DEDUCTIVE REASONING")
print("""
Type : Applying a known general rule to a specific case to reach
       a guaranteed conclusion (top-down logic).
Scenario: Network QoS policy applied to a specific subscriber.
""")

prompt_deductive = """\
Consider the following two premises:

Premise 1 (General Rule):
  "All subscribers on the Unlimited Premium plan who exceed 50 GB of
   data in a single billing cycle are subject to network management
   (deprioritization) during periods of congestion."

Premise 2 (Specific Fact):
  "Subscriber Alice is on the Unlimited Premium plan and has consumed
   67 GB this billing cycle. Her serving cell site is currently
   experiencing congestion with 95 % PRB utilization."

Using deductive reasoning, what conclusion can you draw about Alice's
current network experience? Explain step by step."""

print("Prompt:", prompt_deductive)
print("\nResponse:", reason(prompt_deductive, max_tokens=400))

# ===================================================================
# 3. INDUCTIVE REASONING - Specific observations -> general rule
# ===================================================================
banner("3. INDUCTIVE REASONING")
print("""
Type : Observing a pattern in specific instances and generalizing
       it into a broader rule (bottom-up logic).
Scenario: Repeated cell-tower performance data across multiple days.
""")

prompt_inductive = """\
A network engineer reviews the following observations for cell tower
TX-4421 located in a downtown business district:

  Monday    5-6 PM : 15 dropped calls, 40 RRC connection failures
  Tuesday   5-6 PM : 18 dropped calls, 44 RRC connection failures
  Wednesday 5-6 PM : 20 dropped calls, 51 RRC connection failures
  Thursday  5-6 PM : 14 dropped calls, 38 RRC connection failures
  Friday    5-6 PM : 22 dropped calls, 55 RRC connection failures

  Monday    10-11 AM: 1 dropped call,  3 RRC connection failures
  Tuesday   10-11 AM: 0 dropped calls, 2 RRC connection failures

Using inductive reasoning, what general rule or pattern can you derive
from these observations? What action would you recommend?"""

print("Prompt:", prompt_inductive)
print("\nResponse:", reason(prompt_inductive, max_tokens=400))

# ===================================================================
# 4. ABDUCTIVE REASONING - Observations -> best explanation
# ===================================================================
banner("4. ABDUCTIVE REASONING")
print("""
Type : Given a set of surprising or incomplete observations, infer
       the most likely explanation (inference to the best explanation).
Scenario: NOC alarm triage — multiple symptoms, unknown root cause.
""")

prompt_abductive = """\
The Network Operations Center (NOC) observes the following alarms
all starting at 02:47 AM:

  1. eNodeB site MKE-0093 reports S1 link DOWN.
  2. Approximately 1,200 subscribers in a 2-mile radius lose LTE service.
  3. Neighbouring sites MKE-0091 and MKE-0095 show a sudden 35 % traffic
     spike as displaced users re-attach.
  4. The fiber-backhaul link to MKE-0093 shows zero throughput.
  5. Power monitoring at MKE-0093 shows generators and batteries are normal.
  6. Weather is clear with no storms reported.

Using abductive reasoning, what is the most likely root cause?
List your reasoning step by step, rule out alternatives, and suggest
immediate troubleshooting actions."""

print("Prompt:", prompt_abductive)
print("\nResponse:", reason(prompt_abductive, max_tokens=500))

# ===================================================================
# Summary
# ===================================================================
banner("SUMMARY")
print("""
  Reasoning Type  | Direction           | Telco Example
  ----------------+---------------------+--------------------------------------
  Inferencing     | Facts -> Conclusion | Customer usage signals -> next action
  Deductive       | Rule  -> Specific   | QoS policy + subscriber -> outcome
  Inductive       | Specific -> Rule    | Tower KPIs across days -> pattern
  Abductive       | Clues -> Best Cause | NOC alarms -> likely root cause

  Model used: {model}
""".format(model=MODEL_ID))
