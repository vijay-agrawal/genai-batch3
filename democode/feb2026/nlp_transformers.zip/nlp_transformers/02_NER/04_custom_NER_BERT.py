import torch
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from transformers import BertTokenizerFast, BertForTokenClassification
import webbrowser
import os

# ============================================================================
# CUSTOM NER: FINE-TUNING BERT FOR TELECOM DOMAIN
# ============================================================================
# IMPORTANT: pip install transformers torch
#
# In 02_custom_NER_spacy.py we fine-tuned spaCy's CNN-based model.
# Here we fine-tune BERT — a Transformer model — on the SAME telecom data.
#
# WHY BERT FOR CUSTOM NER?
# ============================================================================
#   - BERT's self-attention captures long-range context better than CNNs
#   - WordPiece tokenization handles unknown telecom terms like "gNodeB"
#     by splitting them into known subwords: ["g", "##Node", "##B"]
#   - Pre-trained on massive corpora (BookCorpus + Wikipedia, 3.3B words),
#     so it has strong general language understanding to transfer from
#   - Typically achieves higher F1 on NER benchmarks than CNN-based models
#
# HOW FINE-TUNING BERT FOR NER WORKS:
# ============================================================================
#   1. TOKENIZE: Convert text to WordPiece subwords and align entity labels
#      - "The eNodeB reported" -> ["The", "e", "##Node", "##B", "reported"]
#      - Labels must be aligned: eNodeB's label applies to all 3 subwords
#
#   2. FORWARD PASS: Each subword token passes through BERT's 12 layers
#      - Self-attention lets each token attend to every other token
#      - Output: 768-dim contextual embedding per subword
#
#   3. CLASSIFICATION HEAD: A linear layer maps each 768-dim embedding
#      to one of our custom labels (B-NETWORK_ELEMENT, I-TECH, O, etc.)
#
#   4. LOSS & UPDATE: Cross-entropy loss is computed on predicted vs true
#      labels, and backpropagation updates BERT's weights
#
# BIO TAGGING SCHEME:
# ============================================================================
#   We use BIO (Beginning-Inside-Outside) tags:
#     B-NETWORK_ELEMENT = first token of a NETWORK_ELEMENT entity
#     I-NETWORK_ELEMENT = continuation token of a NETWORK_ELEMENT entity
#     O                 = not part of any entity
#
#   Example: "The eNodeB reported a Link Failure alarm"
#   Tags:     O   B-NE   O        O B-ALARM I-ALARM  O
#
# CUSTOM TELECOM ENTITY TYPES (same as 02_custom_NER_spacy.py):
#   NETWORK_ELEMENT - eNodeB, gNodeB, MME, SGW, PGW, PCRF
#   PROTOCOL        - S1-AP, GTP-U, SIP, DIAMETER, X2, N2
#   TECH            - LTE, 5G NR, VoLTE, IMS, MIMO
#   KPI             - RSRP, SINR, Throughput, Latency
#   ALARM           - Alarm 7001, Link Failure, RLF
# ============================================================================


# ---------------------------------------------------------------------------
# STEP 1: SAME TRAINING DATA AS 02_custom_NER_spacy.py
# ---------------------------------------------------------------------------
# Format: (text, {"entities": [(start_char, end_char, label), ...]})

TRAIN_DATA = [
    (
        "The eNodeB at site 4012 reported a Link Failure alarm on the S1-AP interface causing LTE service degradation.",
        {"entities": [
            (4, 10, "NETWORK_ELEMENT"),   # eNodeB
            (34, 46, "ALARM"),            # Link Failure
            (60, 65, "PROTOCOL"),         # S1-AP
            (84, 87, "TECH"),             # LTE
        ]}
    ),
    (
        "RSRP dropped below -120 dBm on the gNodeB sector 3 after the 5G NR carrier was reconfigured.",
        {"entities": [
            (0, 4, "KPI"),                # RSRP
            (35, 41, "NETWORK_ELEMENT"),  # gNodeB
            (61, 66, "TECH"),             # 5G NR
        ]}
    ),
    (
        "The MME logged a GTP-U tunnel failure toward the SGW causing VoLTE call drops in the Dallas region.",
        {"entities": [
            (4, 7, "NETWORK_ELEMENT"),    # MME
            (17, 22, "PROTOCOL"),         # GTP-U
            (45, 48, "NETWORK_ELEMENT"),  # SGW
            (57, 62, "TECH"),             # VoLTE
        ]}
    ),
    (
        "Engineers observed SINR values below 0 dB near the PGW after DIAMETER authentication timeouts.",
        {"entities": [
            (19, 23, "KPI"),              # SINR
            (50, 53, "NETWORK_ELEMENT"),  # PGW
            (60, 68, "PROTOCOL"),         # DIAMETER
        ]}
    ),
    (
        "Alarm 7001 was raised on the PCRF node when SIP session setup failures exceeded the threshold.",
        {"entities": [
            (0, 10, "ALARM"),             # Alarm 7001
            (29, 33, "NETWORK_ELEMENT"),  # PCRF
            (44, 47, "PROTOCOL"),         # SIP
        ]}
    ),
    (
        "Throughput on the X2 handover interface between eNodeB sites dropped during the LTE to 5G NR migration.",
        {"entities": [
            (0, 10, "KPI"),               # Throughput
            (18, 20, "PROTOCOL"),         # X2
            (47, 53, "NETWORK_ELEMENT"),  # eNodeB
            (74, 77, "TECH"),             # LTE
            (81, 86, "TECH"),             # 5G NR
        ]}
    ),
    (
        "The gNodeB experienced RLF events after MIMO antenna reconfiguration on the N2 interface.",
        {"entities": [
            (4, 10, "NETWORK_ELEMENT"),   # gNodeB
            (23, 26, "ALARM"),            # RLF
            (41, 45, "TECH"),             # MIMO
            (77, 79, "PROTOCOL"),         # N2
        ]}
    ),
    (
        "Latency spikes were observed on GTP-U bearers toward the SGW after the IMS core upgrade.",
        {"entities": [
            (0, 7, "KPI"),                # Latency
            (31, 36, "PROTOCOL"),         # GTP-U
            (56, 59, "NETWORK_ELEMENT"),  # SGW
            (70, 73, "TECH"),             # IMS
        ]}
    ),
    (
        "The eNodeB reported Alarm 3045 on the S1-AP link and RSRP measurements became unreliable.",
        {"entities": [
            (4, 10, "NETWORK_ELEMENT"),   # eNodeB
            (20, 30, "ALARM"),            # Alarm 3045
            (38, 43, "PROTOCOL"),         # S1-AP
            (53, 57, "KPI"),              # RSRP
        ]}
    ),
    (
        "After the VoLTE platform migration the PCRF started rejecting DIAMETER credit control requests.",
        {"entities": [
            (10, 15, "TECH"),             # VoLTE
            (40, 44, "NETWORK_ELEMENT"),  # PCRF
            (62, 70, "PROTOCOL"),         # DIAMETER
        ]}
    ),
]


# ---------------------------------------------------------------------------
# STEP 2: BUILD THE BIO LABEL SET
# ---------------------------------------------------------------------------
# Convert entity types to BIO tags: O, B-NETWORK_ELEMENT, I-NETWORK_ELEMENT, ...

ENTITY_TYPES = ["NETWORK_ELEMENT", "PROTOCOL", "TECH", "KPI", "ALARM"]

def build_label_list(entity_types):
    """Create BIO label list: O + B-<type> + I-<type> for each entity type."""
    labels = ["O"]
    for etype in entity_types:
        labels.append(f"B-{etype}")
        labels.append(f"I-{etype}")
    return labels

LABELS = build_label_list(ENTITY_TYPES)
LABEL2ID = {label: i for i, label in enumerate(LABELS)}
ID2LABEL = {i: label for i, label in enumerate(LABELS)}

print(f"BIO Label set ({len(LABELS)} labels):")
for i, label in enumerate(LABELS):
    print(f"  {i:>2}: {label}")


# ---------------------------------------------------------------------------
# STEP 3: TOKENIZE AND ALIGN LABELS
# ---------------------------------------------------------------------------
# BERT uses WordPiece tokenization which splits words into subwords.
# We need to align our character-level entity annotations to subword tokens.
#
# Key concept: offset_mapping from the tokenizer tells us which characters
# each subword token corresponds to, allowing precise label alignment.

TOKENIZER = BertTokenizerFast.from_pretrained("bert-base-uncased")


def align_labels_with_tokens(text, entities, tokenizer):
    """
    Tokenize text and align character-level entity spans to BIO token labels.

    Steps:
      1. Tokenize with offset_mapping to get character spans per subword
      2. For each token, check if it falls within an entity span
      3. Assign B- tag to the first token of an entity, I- tag to continuation tokens
      4. Special tokens ([CLS], [SEP], padding) get label -100 (ignored in loss)
    """
    encoding = tokenizer(
        text,
        return_offsets_mapping=True,
        padding="max_length",
        truncation=True,
        max_length=128,
    )

    offset_mapping = encoding["offset_mapping"]
    labels = [-100] * len(offset_mapping)  # -100 = ignore in cross-entropy loss

    for i, (start, end) in enumerate(offset_mapping):
        if start == end:
            # Special token ([CLS], [SEP], [PAD]) - skip
            continue

        labels[i] = LABEL2ID["O"]  # Default: not an entity

        for ent_start, ent_end, ent_type in entities:
            if start >= ent_start and end <= ent_end:
                # This token is inside an entity span
                if start == ent_start:
                    labels[i] = LABEL2ID[f"B-{ent_type}"]
                else:
                    labels[i] = LABEL2ID[f"I-{ent_type}"]
                break

    return encoding, labels


class TelecomNERDataset(Dataset):
    """PyTorch dataset that tokenizes texts and aligns entity labels."""

    def __init__(self, data, tokenizer):
        self.encodings = []
        self.labels = []
        for text, annot in data:
            encoding, labels = align_labels_with_tokens(
                text, annot["entities"], tokenizer
            )
            self.encodings.append(encoding)
            self.labels.append(labels)

    def __len__(self):
        return len(self.encodings)

    def __getitem__(self, idx):
        item = {
            key: torch.tensor(val)
            for key, val in self.encodings[idx].items()
            if key != "offset_mapping"
        }
        item["labels"] = torch.tensor(self.labels[idx])
        return item


# ---------------------------------------------------------------------------
# STEP 4: SHOW THE PROBLEM - BASE BERT FAILS ON TELECOM TEXT
# ---------------------------------------------------------------------------
def show_base_bert_results(text):
    """Run generic BERT NER (dslim/bert-base-NER) to show it misses telecom entities."""
    from transformers import pipeline as hf_pipeline

    print("\n" + "=" * 60)
    print("BEFORE fine-tuning (dslim/bert-base-NER - generic model)")
    print("=" * 60)

    ner_pipe = hf_pipeline(
        "ner",
        model="dslim/bert-base-NER",
        aggregation_strategy="simple",
    )
    results = ner_pipe(text)

    if results:
        for ent in results:
            print(f"  {ent['word']:<35} {ent['entity_group']:<6}  (conf: {ent['score']:.2%})")
    else:
        print("  (No entities detected!)")

    return results


# ---------------------------------------------------------------------------
# STEP 5: FINE-TUNE BERT
# ---------------------------------------------------------------------------
def train_custom_bert(train_data, n_epochs=15, lr=5e-5):
    """
    Fine-tune bert-base-uncased for telecom NER.

    Steps:
      1. Load pre-trained BERT with a token classification head
      2. Configure head for our 11 BIO labels
      3. Train on our annotated telecom dataset
      4. Use AdamW optimizer (weight decay regularization)
    """
    print("\n" + "=" * 60)
    print("TRAINING custom BERT NER model...")
    print(f"  Base model: bert-base-uncased")
    print(f"  Epochs: {n_epochs}")
    print(f"  Learning rate: {lr}")
    print(f"  Training examples: {len(train_data)}")
    print(f"  Custom labels: {', '.join(ENTITY_TYPES)}")
    print(f"  BIO tag count: {len(LABELS)}")
    print("=" * 60)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"  Device: {device}")

    # Load BERT with a classification head sized for our label set
    model = BertForTokenClassification.from_pretrained(
        "bert-base-uncased",
        num_labels=len(LABELS),
        id2label=ID2LABEL,
        label2id=LABEL2ID,
    )
    model.to(device)

    dataset = TelecomNERDataset(train_data, TOKENIZER)
    dataloader = DataLoader(dataset, batch_size=2, shuffle=True)

    optimizer = AdamW(model.parameters(), lr=lr)

    model.train()
    for epoch in range(n_epochs):
        total_loss = 0
        for batch in dataloader:
            batch = {k: v.to(device) for k, v in batch.items()}
            outputs = model(**batch)
            loss = outputs.loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        avg_loss = total_loss / len(dataloader)
        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"  Epoch {epoch+1:>3}/{n_epochs}  Loss: {avg_loss:.4f}")

    print("  Training complete!")
    model.eval()
    return model


# ---------------------------------------------------------------------------
# STEP 6: INFERENCE WITH FINE-TUNED MODEL
# ---------------------------------------------------------------------------
def predict_with_custom_bert(model, text):
    """
    Run inference with the fine-tuned BERT model.

    Steps:
      1. Tokenize the input text with offset_mapping
      2. Forward pass through BERT -> logits for each token
      3. argmax to get predicted label IDs
      4. Group consecutive B-/I- tokens into entity spans
      5. Map back to original text using offset_mapping
    """
    print("\n" + "=" * 60)
    print("AFTER fine-tuning (custom telecom BERT NER)")
    print("=" * 60)

    device = next(model.parameters()).device

    encoding = TOKENIZER(
        text,
        return_offsets_mapping=True,
        padding="max_length",
        truncation=True,
        max_length=128,
        return_tensors="pt",
    )

    offset_mapping = encoding.pop("offset_mapping")[0].tolist()
    inputs = {k: v.to(device) for k, v in encoding.items()}

    with torch.no_grad():
        outputs = model(**inputs)
        predictions = torch.argmax(outputs.logits, dim=2)[0].tolist()

    # Group subword predictions into full entity spans
    entities = []
    current_entity = None

    for i, (pred_id, (start, end)) in enumerate(zip(predictions, offset_mapping)):
        if start == end:
            # Special token - skip
            if current_entity:
                entities.append(current_entity)
                current_entity = None
            continue

        label = ID2LABEL.get(pred_id, "O")

        if label.startswith("B-"):
            if current_entity:
                entities.append(current_entity)
            etype = label[2:]
            current_entity = {"start": start, "end": end, "entity_group": etype, "word": text[start:end]}
        elif label.startswith("I-") and current_entity and label[2:] == current_entity["entity_group"]:
            current_entity["end"] = end
            current_entity["word"] = text[current_entity["start"]:end]
        else:
            if current_entity:
                entities.append(current_entity)
                current_entity = None

    if current_entity:
        entities.append(current_entity)

    if entities:
        for ent in entities:
            print(f"  {ent['word']:<35} {ent['entity_group']}")
    else:
        print("  (No entities detected)")

    return entities


# ---------------------------------------------------------------------------
# STEP 7: VISUALIZE BEFORE vs AFTER
# ---------------------------------------------------------------------------
ENTITY_COLORS = {
    "NETWORK_ELEMENT": "#ff6b6b",  # Red
    "PROTOCOL": "#4ecdc4",         # Teal
    "TECH": "#45b7d1",             # Blue
    "KPI": "#96ceb4",              # Green
    "ALARM": "#ffeaa7",            # Yellow
    # Generic BERT NER labels (for the "before" section)
    "PER": "#aa9cfc", "ORG": "#7aecec", "LOC": "#ff9561", "MISC": "#c887fb",
}


def _escape_html(text):
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _build_highlighted_html(text, entities):
    """Build HTML with colored entity highlights from a list of entity dicts."""
    sorted_ents = sorted(entities, key=lambda e: e["start"])
    html_parts = []
    last_end = 0

    for ent in sorted_ents:
        start = ent["start"]
        end = ent["end"]
        label = ent["entity_group"]
        color = ENTITY_COLORS.get(label, "#ddd")

        html_parts.append(_escape_html(text[last_end:start]))
        entity_text = _escape_html(text[start:end])
        html_parts.append(
            f'<mark style="background:{color};padding:2px 6px;border-radius:4px;">'
            f'{entity_text}'
            f'<span style="font-size:10px;font-weight:bold;margin-left:4px;'
            f'vertical-align:super;">{label}</span></mark>'
        )
        last_end = end

    html_parts.append(_escape_html(text[last_end:]))
    return "".join(html_parts)


def visualize_comparison(text, results_list, filename="custom_bert_ner_results.html"):
    """Generate HTML comparison page: generic BERT vs fine-tuned BERT."""
    sections = ""
    for label, results in results_list:
        highlighted = _build_highlighted_html(text, results)

        labels_in_results = sorted(set(ent["entity_group"] for ent in results))
        legend = "".join(
            f'<span style="background:{ENTITY_COLORS.get(l,"#ddd")};padding:4px 8px;'
            f'margin:4px;border-radius:4px;font-weight:bold;">{l}</span>'
            for l in labels_in_results
        )

        sections += f"""
        <div style="border:1px solid #ccc;border-radius:10px;padding:20px;margin-bottom:30px;">
            <h2 style="color:#333;">{label}</h2>
            <div style="background:#4a5ae8;padding:12px;border-radius:8px;margin-bottom:15px;">
                {legend if legend else '<span style="color:white;">No entities detected</span>'}
            </div>
            <div style="line-height:2.5;">{highlighted}</div>
        </div>
        """

    page = f"""<html><body style="font-size:18px;font-family:Arial;padding:20px;">
    <h1 style="text-align:center;">Custom Telecom NER: BERT Before vs After Fine-Tuning</h1>
    <p style="text-align:center;color:#666;">Same text processed by generic BERT and telecom fine-tuned BERT</p>
    {sections}
    </body></html>"""

    filepath = os.path.join(os.path.dirname(__file__), filename)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(page)
    webbrowser.open("file://" + filepath.replace("\\", "/"))
    print(f"\nOpened visualization in browser: {filepath}")


# ---------------------------------------------------------------------------
# MAIN: RUN THE FULL DEMO
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # Same test text as 02_custom_NER_spacy.py (unseen during training)
    test_text = (
        "The gNodeB at cell site 7821 raised Alarm 7001 after SINR degradation was "
        "detected on the N2 interface. Engineers suspect the 5G NR MIMO antenna "
        "reconfiguration caused GTP-U bearer path failures toward the SGW, "
        "resulting in VoLTE call drops across the region."
    )

    # BEFORE: Generic BERT NER (trained on news, doesn't know telecom)
    base_results = show_base_bert_results(test_text)

    # TRAIN: Fine-tune BERT on our annotated telecom data
    custom_model = train_custom_bert(TRAIN_DATA, n_epochs=15)

    # AFTER: Run fine-tuned model on the SAME test text
    custom_results = predict_with_custom_bert(custom_model, test_text)

    # VISUALIZE: Side-by-side comparison in browser
    visualize_comparison(test_text, [
        ("BEFORE - Generic BERT NER (dslim/bert-base-NER)", base_results),
        ("AFTER - Fine-tuned BERT on telecom data", custom_results),
    ])
