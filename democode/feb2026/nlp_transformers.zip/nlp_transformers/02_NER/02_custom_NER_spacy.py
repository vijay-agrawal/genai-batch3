import spacy
from spacy.tokens import DocBin
from spacy.training import Example
import webbrowser
import os
import random

# ============================================================================
# CUSTOM NER: FINE-TUNING SPACY FOR TELECOM DOMAIN
# ============================================================================
# Out-of-the-box, spaCy recognizes generic entities like PERSON, ORG, DATE.
# But in telecom, we care about domain-specific entities such as:
#
#   NETWORK_ELEMENT - physical/logical nodes: eNodeB, gNodeB, MME, SGW, PGW, PCRF
#   PROTOCOL        - telecom protocols: S1-AP, GTP-U, SIP, DIAMETER, X2, N2
#   TECH            - radio/network technologies: LTE, 5G NR, VoLTE, IMS, MIMO
#   KPI             - key performance indicators: RSRP, SINR, throughput, latency
#   ALARM           - fault/alarm identifiers: Alarm 7001, Link Failure, RLF
#
# WHY FINE-TUNE?
#   A vanilla spaCy model sees "gNodeB" as unknown, "RSRP" as gibberish,
#   and "S1-AP" as noise. Fine-tuning teaches the model to recognize these
#   as meaningful telecom concepts.
#
# HOW FINE-TUNING WORKS:
#   1. Start from a pre-trained model (en_core_web_sm) that already understands
#      English syntax and grammar.
#   2. Add our custom entity labels to the NER component.
#   3. Feed it annotated telecom text: (text, {entities: [(start, end, label)]})
#   4. The model updates its weights to recognize the new entity patterns
#      while retaining its general English understanding.
#   5. This is called "transfer learning" - we transfer the base model's
#      knowledge and specialize it for our domain.
#
# INSTALL: python -m spacy download en_core_web_sm
# ============================================================================


# ---------------------------------------------------------------------------
# STEP 1: ANNOTATED TRAINING DATA
# ---------------------------------------------------------------------------
# Each example is a tuple: (text, {"entities": [(start, end, label), ...]})
# The start/end are character offsets into the text string.
# TIP: In real projects, use annotation tools like Prodigy, Label Studio, or
#      Doccano to annotate hundreds of examples. Here we use a small set for demo.

TRAIN_DATA = [
    (
        "The eNodeB at site 4012 reported a Link Failure alarm on the S1-AP interface causing LTE service degradation.",
        {"entities": [
            (4, 10, "NETWORK_ELEMENT"),   # eNodeB
            (34, 46, "ALARM"),            # Link Failure
            (60, 65, "PROTOCOL"),         # S1-AP
            (84, 87, "TECH"),             # LTE
        ]}
    ),
    (
        "RSRP dropped below -120 dBm on the gNodeB sector 3 after the 5G NR carrier was reconfigured.",
        {"entities": [
            (0, 4, "KPI"),                # RSRP
            (35, 41, "NETWORK_ELEMENT"),  # gNodeB
            (61, 66, "TECH"),             # 5G NR
        ]}
    ),
    (
        "The MME logged a GTP-U tunnel failure toward the SGW causing VoLTE call drops in the Dallas region.",
        {"entities": [
            (4, 7, "NETWORK_ELEMENT"),    # MME
            (17, 22, "PROTOCOL"),         # GTP-U
            (45, 48, "NETWORK_ELEMENT"),  # SGW
            (57, 62, "TECH"),             # VoLTE
        ]}
    ),
    (
        "Engineers observed SINR values below 0 dB near the PGW after DIAMETER authentication timeouts.",
        {"entities": [
            (19, 23, "KPI"),              # SINR
            (50, 53, "NETWORK_ELEMENT"),  # PGW
            (60, 68, "PROTOCOL"),         # DIAMETER
        ]}
    ),
    (
        "Alarm 7001 was raised on the PCRF node when SIP session setup failures exceeded the threshold.",
        {"entities": [
            (0, 10, "ALARM"),             # Alarm 7001
            (29, 33, "NETWORK_ELEMENT"),  # PCRF
            (44, 47, "PROTOCOL"),         # SIP
        ]}
    ),
    (
        "Throughput on the X2 handover interface between eNodeB sites dropped during the LTE to 5G NR migration.",
        {"entities": [
            (0, 10, "KPI"),               # Throughput
            (18, 20, "PROTOCOL"),         # X2
            (47, 53, "NETWORK_ELEMENT"),  # eNodeB
            (74, 77, "TECH"),             # LTE
            (81, 86, "TECH"),             # 5G NR
        ]}
    ),
    (
        "The gNodeB experienced RLF events after MIMO antenna reconfiguration on the N2 interface.",
        {"entities": [
            (4, 10, "NETWORK_ELEMENT"),   # gNodeB
            (23, 26, "ALARM"),            # RLF
            (41, 45, "TECH"),             # MIMO
            (77, 79, "PROTOCOL"),         # N2
        ]}
    ),
    (
        "Latency spikes were observed on GTP-U bearers toward the SGW after the IMS core upgrade.",
        {"entities": [
            (0, 7, "KPI"),                # Latency
            (31, 36, "PROTOCOL"),         # GTP-U
            (56, 59, "NETWORK_ELEMENT"),  # SGW
            (70, 73, "TECH"),             # IMS
        ]}
    ),
    (
        "The eNodeB reported Alarm 3045 on the S1-AP link and RSRP measurements became unreliable.",
        {"entities": [
            (4, 10, "NETWORK_ELEMENT"),   # eNodeB
            (20, 30, "ALARM"),            # Alarm 3045
            (38, 43, "PROTOCOL"),         # S1-AP
            (53, 57, "KPI"),              # RSRP
        ]}
    ),
    (
        "After the VoLTE platform migration the PCRF started rejecting DIAMETER credit control requests.",
        {"entities": [
            (10, 15, "TECH"),             # VoLTE
            (40, 44, "NETWORK_ELEMENT"),  # PCRF
            (62, 70, "PROTOCOL"),         # DIAMETER
        ]}
    ),
]


# ---------------------------------------------------------------------------
# STEP 2: SHOW THE PROBLEM - BASE MODEL FAILS ON TELECOM TEXT
# ---------------------------------------------------------------------------
def show_base_model_results(text):
    """Show that the base spaCy model cannot recognize telecom entities."""
    nlp = spacy.load("en_core_web_sm")
    doc = nlp(text)
    print("\n" + "=" * 60)
    print("BEFORE fine-tuning (en_core_web_sm base model)")
    print("=" * 60)
    if doc.ents:
        for ent in doc.ents:
            print(f"  {ent.text:<35} {ent.label_}")
    else:
        print("  (No entities detected!)")
    return doc


# ---------------------------------------------------------------------------
# STEP 3: FINE-TUNE THE NER MODEL
# ---------------------------------------------------------------------------
def train_custom_ner(train_data, n_iter=30):
    """
    Fine-tune spaCy's NER on telecom training data.

    Steps:
      1. Load the base model (en_core_web_sm)
      2. Add custom entity labels to the NER pipe
      3. Disable other pipes (tagger, parser) so only NER gets updated
      4. Train for n_iter epochs with dropout for regularization
    """
    nlp = spacy.load("en_core_web_sm")
    ner = nlp.get_pipe("ner")

    # Add our custom labels to the NER component
    for _, annotations in train_data:
        for ent in annotations["entities"]:
            ner.add_label(ent[2])

    # Only train the NER pipe, freeze everything else
    other_pipes = [pipe for pipe in nlp.pipe_names if pipe != "ner"]

    print("\n" + "=" * 60)
    print("TRAINING custom NER model...")
    print(f"  Epochs: {n_iter}")
    print(f"  Training examples: {len(train_data)}")
    print(f"  Custom labels: NETWORK_ELEMENT, PROTOCOL, TECH, KPI, ALARM")
    print("=" * 60)

    with nlp.disable_pipes(*other_pipes):
        optimizer = nlp.resume_training()
        for epoch in range(n_iter):
            random.shuffle(train_data)
            losses = {}
            for text, annotations in train_data:
                doc = nlp.make_doc(text)
                example = Example.from_dict(doc, annotations)
                nlp.update([example], drop=0.3, sgd=optimizer, losses=losses)
            if (epoch + 1) % 10 == 0:
                print(f"  Epoch {epoch+1:>3}/{n_iter}  Loss: {losses['ner']:.4f}")

    print("  Training complete!")
    return nlp


# ---------------------------------------------------------------------------
# STEP 4: TEST THE FINE-TUNED MODEL
# ---------------------------------------------------------------------------
def test_custom_model(nlp, text):
    """Run NER with the fine-tuned model and print results."""
    doc = nlp(text)
    print("\n" + "=" * 60)
    print("AFTER fine-tuning (custom telecom NER model)")
    print("=" * 60)
    if doc.ents:
        for ent in doc.ents:
            print(f"  {ent.text:<35} {ent.label_}")
    else:
        print("  (No entities detected)")
    return doc


# ---------------------------------------------------------------------------
# STEP 5: VISUALIZE BEFORE vs AFTER
# ---------------------------------------------------------------------------
ENTITY_COLORS = {
    "NETWORK_ELEMENT": "#ff6b6b",  # Red
    "PROTOCOL": "#4ecdc4",         # Teal
    "TECH": "#45b7d1",             # Blue
    "KPI": "#96ceb4",              # Green
    "ALARM": "#ffeaa7",            # Yellow
    # Standard spaCy labels (in case base model detects some)
    "PERSON": "#aa9cfc", "ORG": "#7aecec", "GPE": "#feca74",
    "LOC": "#ff9561", "DATE": "#bfe1d9", "MONEY": "#e4e7d2",
    "CARDINAL": "#e4e7d2", "ORDINAL": "#e4e7d2", "PERCENT": "#e4e7d2",
}


def visualize_comparison(docs_with_labels, filename="custom_ner_results.html"):
    """Generate an HTML comparison of base vs fine-tuned NER."""
    sections = ""
    for label, doc in docs_with_labels:
        # displacy options to use our custom colors
        options = {"colors": {l: ENTITY_COLORS.get(l, "#ddd") for l in ENTITY_COLORS}}
        html = spacy.displacy.render(doc, style="ent", options=options)

        labels_in_doc = sorted(set(ent.label_ for ent in doc.ents))
        legend = "".join(
            f'<span style="background:{ENTITY_COLORS.get(l,"#ddd")};padding:4px 8px;'
            f'margin:4px;border-radius:4px;font-weight:bold;">{l}</span>'
            for l in labels_in_doc
        )

        sections += f"""
        <div style="border:1px solid #ccc;border-radius:10px;padding:20px;margin-bottom:30px;">
            <h2 style="color:#333;">{label}</h2>
            <div style="background:#4a5ae8;padding:12px;border-radius:8px;margin-bottom:15px;">
                {legend if legend else '<span style="color:white;">No entities detected</span>'}
            </div>
            {html}
        </div>
        """

    page = f"""<html><body style="font-size:18px;font-family:Arial;padding:20px;">
    <h1 style="text-align:center;">Custom Telecom NER: Before vs After Fine-Tuning</h1>
    <p style="text-align:center;color:#666;">Same text processed by base model and fine-tuned model</p>
    {sections}
    </body></html>"""

    filepath = os.path.join(os.path.dirname(__file__), filename)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(page)
    webbrowser.open("file://" + filepath.replace("\\", "/"))
    print(f"\nOpened visualization in browser: {filepath}")


# ---------------------------------------------------------------------------
# MAIN: RUN THE FULL DEMO
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # Test text - the model has NOT seen this exact sentence during training
    test_text = (
        "The gNodeB at cell site 7821 raised Alarm 7001 after SINR degradation was "
        "detected on the N2 interface. Engineers suspect the 5G NR MIMO antenna "
        "reconfiguration caused GTP-U bearer path failures toward the SGW, "
        "resulting in VoLTE call drops across the region."
    )

    # BEFORE: Show base model's (poor) results on telecom text
    doc_before = show_base_model_results(test_text)

    # TRAIN: Fine-tune on our annotated telecom data
    custom_nlp = train_custom_ner(TRAIN_DATA, n_iter=30)

    # AFTER: Show fine-tuned model's results on the SAME text
    doc_after = test_custom_model(custom_nlp, test_text)

    # VISUALIZE: Side-by-side comparison in browser
    visualize_comparison([
        ("BEFORE - Base en_core_web_sm (no telecom knowledge)", doc_before),
        ("AFTER - Fine-tuned on telecom data", doc_after),
    ])
