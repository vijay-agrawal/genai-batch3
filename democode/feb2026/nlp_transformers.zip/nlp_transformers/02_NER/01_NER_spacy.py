import spacy
import webbrowser
import os

# ============================================================================
# IMPORTANT!!!  IMPORTANT!!!  IMPORTANT!!!  IMPORTANT!!!  IMPORTANT!!!
# BEFORE RUNNING THIS SCRIPT, MAKE SURE TO INSTALL THE SPACY MODELS:
# INSTALL MODELS:
#   python -m spacy download en_core_web_sm
#   python -m spacy download en_core_web_md
#
# ============================================================================

# ============================================================================
# WHAT IS SPACY?
# ============================================================================
# spaCy is an open-source NLP (Natural Language Processing) library built by
# Explosion AI. It provides industrial-strength tools for tokenization, POS
# tagging, dependency parsing, Named Entity Recognition (NER), and more.
#
# HIGH-LEVEL ARCHITECTURE:
#   Text --> Tokenizer --> Language Pipeline --> Doc object
#
#   The pipeline typically includes these components (in order):
#     1. Tokenizer    - splits raw text into tokens
#     2. Tagger       - assigns Part-of-Speech (POS) tags
#     3. Parser       - builds a dependency parse tree
#     4. NER          - identifies named entities (PERSON, ORG, GPE, DATE, etc.)
#     5. Lemmatizer   - reduces words to their base form
#
#   Each component is a trained neural network model that processes the Doc
#   and adds its annotations (tags, entities, dependencies) in place.
#
# HOW IS IT TRAINED?
#   - spaCy models are trained using supervised learning on annotated corpora.
#   - The English models (en_core_web_*) are trained on the OntoNotes 5.0 corpus
#     which contains ~1.7M words of annotated text from news, broadcast, web, etc.
#   - The architecture uses a CNN-based (Tok2Vec) or Transformer-based encoder
#     that produces contextual word representations, followed by task-specific
#     prediction heads for NER, POS tagging, and parsing.
#
# MODEL SIZES & TRADE-OFFS:
#   en_core_web_sm  (~12 MB)  - No word vectors, fastest, least accurate
#   en_core_web_md  (~40 MB)  - 20K word vectors (300d), balanced speed/accuracy
#   en_core_web_lg  (~560 MB) - 685K word vectors (300d), most accurate
#
# INSTALL MODELS:
#   python -m spacy download en_core_web_sm
#   python -m spacy download en_core_web_md
# ============================================================================

# Legend colors for entity visualization
ENTITY_COLORS = {
    "PERSON": "#aa9cfc", "ORG": "#7aecec", "GPE": "#feca74",
    "LOC": "#ff9561", "DATE": "#bfe1d9", "MONEY": "#e4e7d2",
    "NORP": "#c887fb", "EVENT": "#ffeb80", "PRODUCT": "#ddd",
    "CARDINAL": "#e4e7d2", "ORDINAL": "#e4e7d2", "QUANTITY": "#e4e7d2",
    "PERCENT": "#e4e7d2", "TIME": "#bfe1d9", "FAC": "#ddd",
}


def run_ner(model_name, text):
    """Load a spaCy model, run NER on the text, print entities, and return the doc."""
    print(f"\n{'='*60}")
    print(f"Model: {model_name}")
    print(f"{'='*60}")

    nlp = spacy.load(model_name)
    doc = nlp(text)

    print("Named Entities:")
    for ent in doc.ents:
        print(f"  {ent.text:<35} {ent.label_}")

    return doc


def visualize_comparison(docs_with_labels, filename="entities.html"):
    """Generate an HTML page comparing NER results from multiple models side by side."""
    sections = ""
    for label, doc in docs_with_labels:
        html = spacy.displacy.render(doc, style="ent")

        labels_in_doc = sorted(set(ent.label_ for ent in doc.ents))
        legend = "".join(
            f'<span style="background:{ENTITY_COLORS.get(l,"#ddd")};padding:4px 8px;'
            f'margin:4px;border-radius:4px;font-weight:bold;">{l}</span>'
            for l in labels_in_doc
        )

        sections += f"""
        <div style="border:1px solid #ccc;border-radius:10px;padding:20px;margin-bottom:30px;">
            <h2 style="color:#333;">{label}</h2>
            <div style="background:#4a5ae8;padding:12px;border-radius:8px;margin-bottom:15px;">{legend}</div>
            {html}
        </div>
        """

    page = f"""<html><body style="font-size:18px;font-family:Arial;padding:20px;">
    <h1 style="text-align:center;">NER Model Comparison</h1>
    {sections}
    </body></html>"""

    filepath = os.path.join(os.path.dirname(__file__), filename)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(page)
    webbrowser.open("file://" + filepath.replace("\\", "/"))
    print(f"\nOpened comparison visualization in browser: {filepath}")


# --- Main ---
text = """
Bharat Dynamics Limited (BDL) — the moment of truth has struck! Today BDL surged ~2% after clinching a staggering ₹ 2,461.62 crore order from the Indian Army.
Investors are riding a wave of renewed confidence — as BDL's order book balloons, the stock feels like a rocket primed for lift-off.
This deal doesn't just push quarterly numbers — it signals strategic strength and long-term defence pedigree.
Market sentiment has flipped bullish overnight; scepticism fades as the order underlines government trust and order-flow visibility.
If momentum holds, BDL could rewrite expectations — and reward early believers handsomely.
"""

# Run NER with the small model
doc_sm = run_ner("en_core_web_sm", text)

# Run NER with the medium model to demonstrate improved accuracy
doc_md = run_ner("en_core_web_md", text)

# Visualize both results side by side
visualize_comparison([
    ("en_core_web_sm (Small Model - 12MB)", doc_sm),
    ("en_core_web_md (Medium Model - 40MB)", doc_md),
])
