from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
import webbrowser
import os

# ============================================================================
# IMPORTANT!!!  IMPORTANT!!!  IMPORTANT!!!  IMPORTANT!!!  IMPORTANT!!!
# BEFORE RUNNING THIS SCRIPT, MAKE SURE TO INSTALL:
#   pip install transformers torch
#
# The model "dslim/bert-base-NER" will be auto-downloaded on first run (~430 MB).
# ============================================================================

# ============================================================================
# WHAT IS BERT?
# ============================================================================
# BERT (Bidirectional Encoder Representations from Transformers) is a
# pre-trained language model developed by Google in 2018.
#
# KEY DIFFERENCES: BERT vs spaCy for NER
# ============================================================================
#
#   ASPECT              spaCy                       BERT
#   ─────────────────   ─────────────────────────   ───────────────────────────
#   Architecture        CNN-based (Tok2Vec)         Transformer (self-attention)
#   Context             Local window (~4 tokens)    Full sentence (bidirectional)
#   Pre-training        Task-specific               Masked Language Modeling (MLM)
#                                                   + Next Sentence Prediction
#   Parameters          ~2M (sm) to ~18M (lg)       ~110M (base) to ~340M (large)
#   Speed               Very fast (~10K docs/sec)   Slower (~100 docs/sec on CPU)
#   Accuracy on NER     Good (F1 ~85% on CoNLL)     Excellent (F1 ~92% on CoNLL)
#   Tokenization        Rule-based (word-level)     WordPiece (subword-level)
#
# HOW BERT NER WORKS:
#   1. Text is tokenized into WordPiece subwords: "gNodeB" -> ["g", "##Node", "##B"]
#   2. Each subword passes through 12 Transformer layers (self-attention)
#   3. The final hidden state of each token is fed to a classification head
#   4. The head predicts a BIO tag: B-PER, I-PER, B-ORG, I-ORG, O, etc.
#      - B = Beginning of entity, I = Inside entity, O = Outside (not an entity)
#
# MODEL USED HERE: dslim/bert-base-NER
#   - Fine-tuned on CoNLL-2003 dataset (Reuters news articles)
#   - Recognizes 4 entity types: PER, ORG, LOC, MISC
#   - F1 score: ~91.3% on CoNLL-2003 test set
# ============================================================================


# Same text used in 01_NER_spacy.py for direct comparison
TEXT = """
Bharat Dynamics Limited (BDL) — the moment of truth has struck! Today BDL surged ~2% after clinching a staggering ₹ 2,461.62 crore order from the Indian Army.
Investors are riding a wave of renewed confidence — as BDL's order book balloons, the stock feels like a rocket primed for lift-off.
This deal doesn't just push quarterly numbers — it signals strategic strength and long-term defence pedigree.
Market sentiment has flipped bullish overnight; scepticism fades as the order underlines government trust and order-flow visibility.
If momentum holds, BDL could rewrite expectations — and reward early believers handsomely.
"""

# Entity colors for visualization
# BERT NER uses PER/ORG/LOC/MISC instead of spaCy's PERSON/ORG/GPE/etc.
ENTITY_COLORS = {
    "PER": "#aa9cfc",   # Purple  - Person
    "ORG": "#7aecec",   # Cyan    - Organization
    "LOC": "#ff9561",   # Orange  - Location
    "MISC": "#c887fb",  # Violet  - Miscellaneous
}


def run_bert_ner(text, model_name="dslim/bert-base-NER"):
    """
    Run NER using a BERT-based model via HuggingFace Transformers.

    The pipeline handles:
      1. Tokenization (WordPiece)
      2. Model inference (forward pass through BERT + classification head)
      3. BIO tag decoding and entity grouping

    aggregation_strategy="simple" merges subword tokens like ["B", "##DL"] -> "BDL"
    """
    print(f"\n{'='*60}")
    print(f"Model: {model_name} (BERT-based NER)")
    print(f"{'='*60}")

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForTokenClassification.from_pretrained(model_name)

    # aggregation_strategy="simple" merges B-/I- subword tokens into full entities
    ner_pipeline = pipeline(
        "ner",
        model=model,
        tokenizer=tokenizer,
        aggregation_strategy="simple",
    )

    results = ner_pipeline(text)

    print("Named Entities:")
    for ent in results:
        label = ent["entity_group"]
        word = ent["word"]
        score = ent["score"]
        print(f"  {word:<35} {label:<6}  (confidence: {score:.2%})")

    return results


def visualize_bert_results(text, results_list, filename="bert_ner_results.html"):
    """
    Generate an HTML page with highlighted entities, matching the spaCy visualization style.
    Since BERT doesn't use displacy, we build the HTML manually.
    """
    sections = ""
    for label, results in results_list:
        # Build highlighted text by inserting HTML spans around entities
        highlighted = _build_highlighted_html(text, results)

        labels_in_results = sorted(set(ent["entity_group"] for ent in results))
        legend = "".join(
            f'<span style="background:{ENTITY_COLORS.get(l,"#ddd")};padding:4px 8px;'
            f'margin:4px;border-radius:4px;font-weight:bold;">{l}</span>'
            for l in labels_in_results
        )

        sections += f"""
        <div style="border:1px solid #ccc;border-radius:10px;padding:20px;margin-bottom:30px;">
            <h2 style="color:#333;">{label}</h2>
            <div style="background:#4a5ae8;padding:12px;border-radius:8px;margin-bottom:15px;">{legend}</div>
            <div style="line-height:2.5;">{highlighted}</div>
        </div>
        """

    page = f"""<html><body style="font-size:18px;font-family:Arial;padding:20px;">
    <h1 style="text-align:center;">BERT NER Results</h1>
    <p style="text-align:center;color:#666;">Using dslim/bert-base-NER (fine-tuned on CoNLL-2003)</p>
    {sections}
    </body></html>"""

    filepath = os.path.join(os.path.dirname(__file__), filename)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(page)
    webbrowser.open("file://" + filepath.replace("\\", "/"))
    print(f"\nOpened visualization in browser: {filepath}")


def _build_highlighted_html(text, entities):
    """
    Insert colored <mark> spans around detected entities in the original text.
    Entities are sorted by start position and processed left-to-right.
    """
    # Sort entities by start position
    sorted_ents = sorted(entities, key=lambda e: e["start"])
    html_parts = []
    last_end = 0

    for ent in sorted_ents:
        start = ent["start"]
        end = ent["end"]
        label = ent["entity_group"]
        color = ENTITY_COLORS.get(label, "#ddd")

        # Add the plain text before this entity
        html_parts.append(_escape_html(text[last_end:start]))

        # Add the highlighted entity
        entity_text = _escape_html(text[start:end])
        html_parts.append(
            f'<mark style="background:{color};padding:2px 6px;border-radius:4px;">'
            f'{entity_text}'
            f'<span style="font-size:10px;font-weight:bold;margin-left:4px;'
            f'vertical-align:super;">{label}</span></mark>'
        )
        last_end = end

    # Add any remaining text after the last entity
    html_parts.append(_escape_html(text[last_end:]))

    return "".join(html_parts)


def _escape_html(text):
    """Escape HTML special characters."""
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # Run BERT NER on the same text as 01_NER_spacy.py
    results = run_bert_ner(TEXT)

    # Visualize with highlighted entities in browser
    visualize_bert_results(TEXT, [
        ("dslim/bert-base-NER (BERT base, CoNLL-2003)", results),
    ])
