# Test Your Understanding: Network Fault Anomaly Detection

## Demo
`machinelearning/03_call_drop_rate_prediction.py`

---

### Pre-requisite

Run the above python script/demo and 
1) review the graphs and analysis it is presenting on screen and in the terminal
2) take the effort to understand the code and get your questions/doubts answered by using github copilot/claude or any other AI chatbot.

Only **after** you carry out the above activity, review this document to test and reinforce your learning.

## Questions

### Inferences from call drop rate distribution plot
![CDR Distribution Plot](reports/03_cdr_distribution.jpg)

**Key Observations:**

1. **Right-Skewed (Positively Skewed) Distribution** — The distribution is not normal. It has a long tail to the right. Most cell towers/regions experience low drop rates, but a few have significantly higher rates (up to ~20%).

2. **Mean = 2.85%, but the Mode is lower (~1.5–2%)** — The peak frequency (~4800) occurs around 1.5–2%, meaning the most common experience is better than the average suggests. The mean is pulled up by outliers in the right tail.

3. **Majority of observations fall below 4%** — The bulk of data is concentrated in the 0–4% range, indicating most network areas maintain reasonably low call drop rates.

4. **Secondary bump around 4.5–6%** — A noticeable secondary cluster suggests a possible sub-population — perhaps towers in congested areas, rural zones, or regions with infrastructure issues that consistently perform worse.

5. **Outliers exist (10–20% range)** — A small number of observations show very high drop rates. These are likely problem areas that warrant targeted investigation and intervention.

6. **Modeling implication** — Log-transform or robust scaling may be needed before regression given the skewness. Outlier treatment (capping or separate modeling) should be considered for extreme right-tail values.

### Inferences from box plots
![Box Plots](reports/03_boxplot.jpg)

**Key Observations:**

**Left Plot — SINR-Load Risk Pattern:**

1. **The combination of poor signal quality (SINR < -5) + high tower load (> 80%) is a strong risk factor.** The median drop rate jumps roughly 4x (from ~2.3% to ~9%).

2. **The "False" group has many upper outliers** (up to ~14%), meaning even under normal conditions some towers still perform badly — likely due to other factors (hardware, geography).

3. **The "True" group has a tight IQR** — when both conditions are met, high drop rates are almost guaranteed, not just occasional. This makes it a reliable predictor.

4. **Minimal overlap** between the two boxes indicates this binary feature would have strong discriminative power in a model.

**Right Plot — Humidity Impact on Drop Rate (Low RSRP only):**

5. **High humidity (>80%) significantly worsens drop rates on weak-signal towers.** The median roughly doubles from dry/medium (~3–3.5%) to humid (~7%).

6. **Dry and Medium humidity behave similarly** — humidity only becomes a problem above 80%, suggesting a threshold effect rather than a linear relationship.

7. **The humid group has outliers reaching ~20%**, indicating that weak RSRP + high humidity can create severe service degradation.

8. **Combined takeaway** — Call drops are driven by interaction effects, not single factors in isolation. The model should include interaction features (e.g., `sinr_load_risk`, `rsrp_humidity_interaction`).

### Inference from CDR by hour plot
![CDR by hour Plot](reports/03_cdr_by_hour.jpg)

**Key Observations:**

1. **Clear diurnal (daily cycle) pattern** — The drop rate follows a smooth bell-shaped curve that mirrors typical human activity: low at night, high during the day.

2. **Peak at ~11 AM, NOT evening** — The highest drop rate (~3.62%) occurs around 11 AM, not during the typical evening "internet rush hour." This suggests the network is most stressed during business hours, likely driven by enterprise/commercial usage.

3. **Steep morning rise vs. gradual evening decline** — Drop rate climbs sharply between 6 AM and 11 AM (~2.6% to ~3.6%, a 38% increase in 5 hours). The decline is more gradual, taking ~12 hours to return to baseline. This asymmetry suggests congestion builds rapidly but subsides slowly.

4. **Nighttime baseline is ~2.2–2.3%, never zero** — Even at lowest usage hours (1–2 AM), drop rates remain above 2%. This represents the irreducible baseline caused by factors unrelated to load (hardware issues, signal interference, geographic constraints).

5. **Peak-to-trough difference is ~1.4 percentage points (~60%)** — This indicates network load is a meaningful but not dominant driver of call drops. Other factors (SINR, RSRP, humidity) account for the remaining variance.

6. **Modeling implication** — Hour of day should be included as a feature, ideally as a cyclical encoding (sin/cos transform) or a binary `is_peak_hour` flag (hours 8–14).

### Inference from correlation heatmap
![Correlation Plot](reports/03_correlation.jpg)

**Key Observations:**

1. **No single feature is strongly correlated with `call_drop_rate`.** The two strongest predictors are `tower_load_pct` (+0.30) and `rsrp_dbm` (-0.30). This confirms call drops are driven by multiple interacting factors.

2. **`tower_load_pct` and `active_users` are nearly redundant (r=0.88)** — More users means more load. Including both in a linear model will cause multicollinearity. Recommendation: drop `active_users` or combine them into a single feature.

3. **`humidity_pct` and `temperature_c` are inversely coupled (r=-0.69)** — High humidity tends to occur at lower temperatures. Consider keeping only one or creating a composite weather feature.

4. **`rsrp_dbm` is nearly independent of all other features (~0.00)** except `call_drop_rate` (-0.30). Signal strength is determined by geography/infrastructure, not by load or weather. It provides unique, non-redundant information — a clean, highly valuable predictor.

5. **`tower_load_pct` is a hub variable** — correlated with almost everything (`active_users` 0.88, `humidity_pct` 0.66, `handover_attempts` 0.61, `sinr_db` -0.62). Yet its direct correlation with `call_drop_rate` is only 0.30, reinforcing the need for non-linear models or interaction terms.

6. **Low linear correlations with target suggest a non-linear model** (Random Forest, XGBoost) will significantly outperform linear regression. Engineered interaction features like `sinr_db x tower_load_pct` and `rsrp_dbm x humidity_pct` should improve performance.
