"""
================================================================================
USE-CASE 2: Customer Churn Prediction
================================================================================

BUSINESS CONTEXT
    Marketing teams want to proactively identify customers likely to switch to
    a competitor. Retaining an existing customer costs 5-7x less than acquiring
    a new one. By predicting churn *before* it happens, targeted retention
    campaigns (discounts, loyalty offers, proactive support) can be deployed.

FEATURES THAT DRIVE CHURN
    - Usage patterns (declining data/voice usage)
    - Payment delays (late payments = dissatisfaction signal)
    - Complaint frequency (unresolved issues)
    - Tenure (new customers churn more)
    - Recent plan changes (downgrade = disengagement signal)
    - Contract type, monthly charges, support interactions

ML APPROACH
    Type       : Binary Classification (Supervised Learning)
    Algorithms : Logistic Regression (interpretable) vs Gradient Boosting (accuracy)
    Why two?   : LR provides clear coefficient-based explanations;
                 GB captures non-linear interactions.

STEP-BY-STEP ROADMAP
    Step 1 : Generate synthetic customer data
    Step 2 : Exploratory Data Analysis (EDA)
    Step 3 : Feature Engineering & Preprocessing
    Step 4 : Train Logistic Regression & Gradient Boosting
    Step 5 : Evaluate & Compare
    Step 6 : Hyperparameter Tuning
    Step 7 : Findings & Analysis
================================================================================
"""

# =============================================================================
# STEP 0 -- IMPORTS
# =============================================================================
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score,
    roc_curve, precision_recall_curve, f1_score, accuracy_score
)
import warnings
warnings.filterwarnings('ignore')

plt.style.use('seaborn-v0_8-whitegrid')
pd.set_option('display.max_columns', None)
print("All imports successful.")


# =============================================================================
# STEP 1 -- GENERATE SYNTHETIC CUSTOMER DATA
# =============================================================================
# We simulate 10,000 customers with realistic telecom attributes.
# Churn is generated with a logistic model so that specific features have
# known effects:
#   - Higher complaint frequency --> higher churn probability
#   - Payment delays --> higher churn probability
#   - Longer tenure --> lower churn probability (up to a point)
#   - Recent plan downgrade --> higher churn probability
# =============================================================================
print("\n" + "=" * 60)
print("STEP 1: Generating synthetic customer data...")
print("=" * 60)

np.random.seed(42)
n_customers = 10000

# --- Categorical features ---
gender = np.random.choice(['Male', 'Female'], n_customers)
contract_type = np.random.choice(['Month-to-Month', 'One-Year', 'Two-Year'],
                                  n_customers, p=[0.50, 0.30, 0.20])
payment_method = np.random.choice(['Credit Card', 'Bank Transfer', 'Electronic Check', 'Mailed Check'],
                                   n_customers, p=[0.30, 0.25, 0.30, 0.15])
internet_service = np.random.choice(['Fiber Optic', 'DSL', 'None'],
                                     n_customers, p=[0.45, 0.40, 0.15])
plan_change = np.random.choice(['No Change', 'Upgrade', 'Downgrade'],
                                n_customers, p=[0.65, 0.15, 0.20])

# --- Numeric features ---
tenure_months = np.random.exponential(24, n_customers).astype(int).clip(1, 72)
monthly_charges = np.where(
    internet_service == 'Fiber Optic',
    np.random.normal(85, 15, n_customers),
    np.where(internet_service == 'DSL',
             np.random.normal(55, 10, n_customers),
             np.random.normal(25, 5, n_customers))
).clip(15, 120).round(2)

total_charges = (monthly_charges * tenure_months + np.random.normal(0, 50, n_customers)).clip(0).round(2)

avg_monthly_usage_gb = np.where(
    internet_service == 'Fiber Optic',
    np.random.normal(50, 20, n_customers),
    np.where(internet_service == 'DSL',
             np.random.normal(25, 10, n_customers),
             np.random.normal(2, 1, n_customers))
).clip(0).round(2)

avg_monthly_voice_min = np.random.normal(300, 120, n_customers).clip(0).round(0)
complaint_count_6m = np.random.poisson(1.2, n_customers)
support_calls_6m = complaint_count_6m + np.random.poisson(0.8, n_customers)
payment_delay_days = np.random.exponential(3, n_customers).clip(0, 60).round(0)

# Usage trend: negative = declining usage (churn signal)
usage_trend_3m = np.random.normal(0, 10, n_customers).round(2)

# --- Generate churn with a logistic model ---
# This creates a KNOWN relationship so learners can verify the model discovers it
logit = (
    -2.5                                                     # base (most customers don't churn)
    + 0.8 * (contract_type == 'Month-to-Month').astype(int)  # month-to-month = easier to leave
    + 0.4 * (plan_change == 'Downgrade').astype(int)         # downgrade = disengagement
    + 0.3 * (payment_method == 'Electronic Check').astype(int)
    + 0.05 * complaint_count_6m                              # more complaints = higher churn
    + 0.02 * payment_delay_days                              # late payers churn more
    - 0.03 * tenure_months                                   # longer tenure = stickier
    + 0.01 * monthly_charges                                 # higher bill = more likely to switch
    - 0.02 * usage_trend_3m                                  # declining usage = churn signal
    + np.random.normal(0, 0.5, n_customers)                  # noise
)
churn_prob = 1 / (1 + np.exp(-logit))
churned = (np.random.rand(n_customers) < churn_prob).astype(int)

# --- Build DataFrame ---
df = pd.DataFrame({
    'customer_id': [f'CUST_{i:05d}' for i in range(n_customers)],
    'gender': gender,
    'tenure_months': tenure_months,
    'contract_type': contract_type,
    'payment_method': payment_method,
    'internet_service': internet_service,
    'monthly_charges': monthly_charges,
    'total_charges': total_charges,
    'avg_monthly_usage_gb': avg_monthly_usage_gb,
    'avg_monthly_voice_min': avg_monthly_voice_min,
    'usage_trend_3m': usage_trend_3m,
    'plan_change': plan_change,
    'complaint_count_6m': complaint_count_6m,
    'support_calls_6m': support_calls_6m,
    'payment_delay_days': payment_delay_days,
    'churned': churned
})

# Define the base path for the data folder
data_folder = Path(__file__).parent / 'data'

# Save to CSV
df.to_csv( data_folder / 'customer_churn_data.csv', index=False)
print(f"Dataset shape: {df.shape}")
print(f"\nChurn distribution:")
print(df['churned'].value_counts())
print(f"\nChurn rate: {df['churned'].mean():.1%}")
print(df.head())


# =============================================================================
# STEP 2 -- EXPLORATORY DATA ANALYSIS (EDA)
# =============================================================================
print("\n" + "=" * 60)
print("STEP 2: Exploratory Data Analysis")
print("=" * 60)

# 2.1  Basic statistics
print("\nDESCRIPTIVE STATISTICS")
print(df.describe().round(2))

# 2.2  Churn rate by categorical features
cat_cols = ['contract_type', 'payment_method', 'internet_service', 'plan_change', 'gender']

fig, axes = plt.subplots(2, 3, figsize=(16, 9))
axes = axes.flatten()

for i, col in enumerate(cat_cols):
    churn_rates = df.groupby(col)['churned'].mean().sort_values(ascending=False)
    churn_rates.plot(kind='bar', ax=axes[i], color='steelblue', edgecolor='navy')
    axes[i].set_title(f'Churn Rate by {col}')
    axes[i].set_ylabel('Churn Rate')
    axes[i].tick_params(axis='x', rotation=45)
    for j, (idx, val) in enumerate(churn_rates.items()):
        axes[i].text(j, val + 0.01, f'{val:.1%}', ha='center', fontsize=9)

axes[5].axis('off')
plt.suptitle('Churn Rate by Categorical Features', fontsize=14)
plt.tight_layout()
plt.savefig(data_folder / 'eda_churn_by_category.png', dpi=120, bbox_inches='tight')
plt.show()

print("\n** INSIGHT: Month-to-Month contracts and Electronic Check payments")
print("   show the highest churn rates -- consistent with industry patterns. **")

# 2.3  Numeric feature distributions by churn status
num_cols = ['tenure_months', 'monthly_charges', 'complaint_count_6m',
            'payment_delay_days', 'usage_trend_3m', 'avg_monthly_usage_gb']

fig, axes = plt.subplots(2, 3, figsize=(16, 9))
axes = axes.flatten()

for i, col in enumerate(num_cols):
    for label, color in [(0, 'steelblue'), (1, 'crimson')]:
        df[df['churned'] == label][col].hist(
            bins=40, alpha=0.5, ax=axes[i], color=color,
            label='Retained' if label == 0 else 'Churned'
        )
    axes[i].set_title(col)
    axes[i].legend(fontsize=8)

plt.suptitle('Feature Distributions -- Retained vs Churned', fontsize=14)
plt.tight_layout()
plt.savefig(data_folder / 'eda_churn_distributions.png', dpi=120, bbox_inches='tight')
plt.show()

print("\n** INSIGHT: Churned customers tend to have shorter tenure,")
print("   higher payment delays, and negative usage trends. **")

# 2.4  Correlation heatmap
corr_cols = num_cols + ['support_calls_6m', 'total_charges', 'churned']

fig, ax = plt.subplots(figsize=(10, 8))
corr = df[corr_cols].corr()
sns.heatmap(corr, annot=True, fmt='.2f', cmap='RdBu_r', center=0, ax=ax)
ax.set_title('Feature Correlation Matrix')
plt.tight_layout()
plt.savefig(data_folder / 'eda_churn_correlation.png', dpi=120, bbox_inches='tight')
plt.show()


# =============================================================================
# STEP 3 -- FEATURE ENGINEERING & PREPROCESSING
# =============================================================================
print("\n" + "=" * 60)
print("STEP 3: Feature Engineering & Preprocessing")
print("=" * 60)

# 3.1  Encode categorical variables
df_model = df.drop(columns=['customer_id']).copy()
df_model = pd.get_dummies(df_model, columns=cat_cols, drop_first=True)

print(f"Shape after encoding: {df_model.shape}")
print(f"\nColumns: {list(df_model.columns)}")

# 3.2  Create derived features
df_model['charge_per_tenure'] = df_model['total_charges'] / df_model['tenure_months'].clip(1)
df_model['complaint_intensity'] = df_model['complaint_count_6m'] / df_model['tenure_months'].clip(1)

if 'contract_type_Month-to-Month' in df_model.columns and 'payment_method_Electronic Check' in df_model.columns:
    df_model['high_risk_profile'] = (
        df_model['contract_type_Month-to-Month'].astype(int) +
        df_model['payment_method_Electronic Check'].astype(int) +
        df_model.get('plan_change_Downgrade', pd.Series(0, index=df_model.index)).astype(int)
    )

print(f"Final shape: {df_model.shape}")
print(df_model.head())

# 3.3  Train / Test Split
X = df_model.drop(columns=['churned'])
y = df_model['churned']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled  = scaler.transform(X_test)

print(f"\nTrain: {X_train.shape[0]:,} samples | Test: {X_test.shape[0]:,} samples")
print(f"Train churn rate: {y_train.mean():.1%} | Test churn rate: {y_test.mean():.1%}")


# =============================================================================
# STEP 4 -- MODEL TRAINING
# =============================================================================
# Algorithm Selection Rationale:
#   Logistic Regression : Interpretable coefficients, fast, linear boundary
#                         Use for baseline, compliance, explainability
#   Gradient Boosting   : Captures non-linear patterns, feature interactions
#                         Use when prediction accuracy is the priority
# =============================================================================
print("\n" + "=" * 60)
print("STEP 4: Model Training")
print("=" * 60)

# ---------- 4A: Logistic Regression ----------
print("\n--- Training Logistic Regression ---")
lr_model = LogisticRegression(
    max_iter=1000,
    random_state=42,
    class_weight='balanced'
)
lr_model.fit(X_train_scaled, y_train)

lr_pred = lr_model.predict(X_test_scaled)
lr_prob = lr_model.predict_proba(X_test_scaled)[:, 1]

print("\n" + "=" * 55)
print("LOGISTIC REGRESSION -- Test Results")
print("=" * 55)
print(classification_report(y_test, lr_pred, target_names=['Retained', 'Churned']))
print(f"ROC-AUC: {roc_auc_score(y_test, lr_prob):.4f}")

# ---------- 4B: Gradient Boosting Classifier ----------
print("\n--- Training Gradient Boosting ---")
gb_model = GradientBoostingClassifier(
    n_estimators=200, #n_estimators means number of boosting stages to be run
    learning_rate=0.1,
    max_depth=4,
    random_state=42,
    subsample=0.8
)
gb_model.fit(X_train_scaled, y_train)

gb_pred = gb_model.predict(X_test_scaled)
gb_prob = gb_model.predict_proba(X_test_scaled)[:, 1]

print("\n" + "=" * 55)
print("GRADIENT BOOSTING -- Test Results")
print("=" * 55)
print(classification_report(y_test, gb_pred, target_names=['Retained', 'Churned']))
print(f"ROC-AUC: {roc_auc_score(y_test, gb_prob):.4f}")


# =============================================================================
# STEP 5 -- EVALUATION & COMPARISON
# =============================================================================
print("\n" + "=" * 60)
print("STEP 5: Evaluation & Comparison")
print("=" * 60)

# 5.1  Confusion matrices side-by-side
fig, axes = plt.subplots(1, 2, figsize=(12, 4))

for ax, preds, title in [
    (axes[0], lr_pred, 'Logistic Regression'),
    (axes[1], gb_pred, 'Gradient Boosting')
]:
    cm = confusion_matrix(y_test, preds)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                xticklabels=['Retained', 'Churned'],
                yticklabels=['Retained', 'Churned'])
    ax.set_title(title)
    ax.set_xlabel('Predicted')
    ax.set_ylabel('Actual')

plt.tight_layout()
plt.savefig(data_folder / 'confusion_matrices_churn.png', dpi=120, bbox_inches='tight')
plt.show()

# 5.2  ROC Curves
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

for name, probs, color in [('Logistic Regression', lr_prob, 'blue'),
                            ('Gradient Boosting', gb_prob, 'green')]:
    fpr, tpr, _ = roc_curve(y_test, probs)
    auc = roc_auc_score(y_test, probs)
    axes[0].plot(fpr, tpr, color=color, label=f'{name} (AUC={auc:.3f})')

axes[0].plot([0, 1], [0, 1], 'k--', label='Random')
axes[0].set_xlabel('False Positive Rate')
axes[0].set_ylabel('True Positive Rate')
axes[0].set_title('ROC Curve')
axes[0].legend()

for name, probs, color in [('Logistic Regression', lr_prob, 'blue'),
                            ('Gradient Boosting', gb_prob, 'green')]:
    precision, recall, _ = precision_recall_curve(y_test, probs)
    axes[1].plot(recall, precision, color=color, label=name)

axes[1].set_xlabel('Recall')
axes[1].set_ylabel('Precision')
axes[1].set_title('Precision-Recall Curve')
axes[1].legend()

plt.tight_layout()
plt.savefig(data_folder / 'roc_pr_curves_churn.png', dpi=120, bbox_inches='tight')
plt.show()

# 5.3  Logistic Regression Coefficients (Interpretability)
coef_df = pd.DataFrame({
    'feature': X_train.columns,
    'coefficient': lr_model.coef_[0]
}).sort_values('coefficient', ascending=False)

fig, ax = plt.subplots(figsize=(10, 8))
colors = ['crimson' if c > 0 else 'steelblue' for c in coef_df['coefficient']]
ax.barh(range(len(coef_df)), coef_df['coefficient'], color=colors, edgecolor='gray')
ax.set_yticks(range(len(coef_df)))
ax.set_yticklabels(coef_df['feature'], fontsize=8)
ax.invert_yaxis()
ax.set_xlabel('Coefficient Value')
ax.set_title('Logistic Regression Coefficients\n(Red = increases churn, Blue = decreases churn)')
ax.axvline(0, color='black', linewidth=0.8)
plt.tight_layout()
plt.savefig(data_folder / 'lr_coefficients_churn.png', dpi=120, bbox_inches='tight')
plt.show()

print("\n** INSIGHT: The model has discovered the relationships we encoded:")
print("   Month-to-Month contract, payment delays, and complaints INCREASE churn;")
print("   tenure and Two-Year contracts DECREASE churn. **")

# 5.4  Gradient Boosting Feature Importance
gb_importance = pd.DataFrame({
    'feature': X_train.columns,
    'importance': gb_model.feature_importances_
}).sort_values('importance', ascending=False)

fig, ax = plt.subplots(figsize=(10, 8))
top_n = min(20, len(gb_importance))
top_feats = gb_importance.head(top_n)
ax.barh(range(top_n), top_feats['importance'],
        color='forestgreen', edgecolor='darkgreen')
ax.set_yticks(range(top_n))
ax.set_yticklabels(top_feats['feature'], fontsize=9)
ax.invert_yaxis()
ax.set_xlabel('Feature Importance')
ax.set_title('Gradient Boosting -- Top Feature Importances')
plt.tight_layout()
plt.savefig(data_folder / 'gb_feature_importance_churn.png', dpi=120, bbox_inches='tight')
plt.show()


# =============================================================================
# STEP 6 -- HYPERPARAMETER TUNING
# =============================================================================
print("\n" + "=" * 60)
print("STEP 6: Hyperparameter Tuning")
print("=" * 60)

# 6.1  Logistic Regression -- Tune regularization
# Regularization helps prevent overfitting by adding a penalty to large coefficients. 
# C is the inverse of regularization strength (smaller C = stronger regularization). 
# We also tune the penalty type (L1 vs L2) and solver to find the best combination for our dataset.
# L1 (Lasso) can produce sparse models by driving some coefficients to zero,
# while L2 (Ridge) tends to shrink coefficients smoothly.
# Sparse models means fewer features are used, which can aid interpretability.
param_grid_lr = {
    'C': [0.01, 0.1, 0.5, 1.0, 5.0, 10.0], # C is inverse of regularization strength
    'penalty': ['l1', 'l2'], # L1 = Lasso (sparse), L2 = Ridge (smooth)
    'solver': ['saga'] # saga supports both l1 and l2 penalties, and works well with large datasets
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

grid_lr = GridSearchCV(
    LogisticRegression(max_iter=1000, random_state=42, class_weight='balanced'),
    param_grid_lr,
    cv=cv,
    scoring='roc_auc',
    n_jobs=-1,
    verbose=0
)
grid_lr.fit(X_train_scaled, y_train)

print(f"Best LR params: {grid_lr.best_params_}")
print(f"Best CV ROC-AUC: {grid_lr.best_score_:.4f}")

# 6.2  Gradient Boosting -- Tune key parameters
param_grid_gb = {
    'n_estimators': [100, 200, 300],
    'learning_rate': [0.05, 0.1, 0.2],
    'max_depth': [3, 4, 5],
    'subsample': [0.8, 1.0]
}

grid_gb = GridSearchCV(
    GradientBoostingClassifier(random_state=42),
    param_grid_gb,
    cv=cv,
    scoring='roc_auc',
    n_jobs=-1,
    verbose=0
)
grid_gb.fit(X_train_scaled, y_train)

print(f"Best GB params: {grid_gb.best_params_}")
print(f"Best CV ROC-AUC: {grid_gb.best_score_:.4f}")

# 6.3  Final evaluation with tuned models
lr_tuned_pred = grid_lr.predict(X_test_scaled)
lr_tuned_prob = grid_lr.predict_proba(X_test_scaled)[:, 1]

gb_tuned_pred = grid_gb.predict(X_test_scaled)
gb_tuned_prob = grid_gb.predict_proba(X_test_scaled)[:, 1]

print("\n" + "=" * 60)
print("TUNED LOGISTIC REGRESSION")
print("=" * 60)
print(classification_report(y_test, lr_tuned_pred, target_names=['Retained', 'Churned']))
print(f"ROC-AUC: {roc_auc_score(y_test, lr_tuned_prob):.4f}")

print("\n" + "=" * 60)
print("TUNED GRADIENT BOOSTING")
print("=" * 60)
print(classification_report(y_test, gb_tuned_pred, target_names=['Retained', 'Churned']))
print(f"ROC-AUC: {roc_auc_score(y_test, gb_tuned_prob):.4f}")


# =============================================================================
# STEP 7 -- FINDINGS & ANALYSIS
# =============================================================================
# Model Comparison:
#   Logistic Regression : High interpretability, linear boundary, fast
#   Gradient Boosting   : Higher accuracy, captures non-linear interactions
#
# Key Insights for the Business:
#   1. Month-to-Month contracts are the single biggest churn risk factor
#   2. Payment delays > 10 days + recent plan downgrades = high-risk segment
#   3. Declining usage trend (usage_trend_3m < 0) is an early warning
#   4. Tenure is protective -- customers past 12 months have lower churn risk
#   5. Electronic Check payment method correlates with churn
#
# Recommended Actions:
#   - Score all customers monthly; flag those with churn_probability > 0.6
#   - Create tiered retention campaigns based on risk score
#   - Feed top features into CRM for sales team visibility
# =============================================================================
print("\n" + "=" * 60)
print("STEP 7: Findings & Analysis")
print("=" * 60)

summary = pd.DataFrame({
    'Model': ['Logistic Regression (tuned)', 'Gradient Boosting (tuned)'],
    'Accuracy': [
        accuracy_score(y_test, lr_tuned_pred),
        accuracy_score(y_test, gb_tuned_pred)
    ],
    'F1 (Churned)': [
        f1_score(y_test, lr_tuned_pred),
        f1_score(y_test, gb_tuned_pred)
    ],
    'ROC-AUC': [
        roc_auc_score(y_test, lr_tuned_prob),
        roc_auc_score(y_test, gb_tuned_prob)
    ],
    'Best Params': [str(grid_lr.best_params_), str(grid_gb.best_params_)]
})
print("\nFINAL MODEL COMPARISON")
print("=" * 80)
print(summary.round(4).to_string(index=False))
