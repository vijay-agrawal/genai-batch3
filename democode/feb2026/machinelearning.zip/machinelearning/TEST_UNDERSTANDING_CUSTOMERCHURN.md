# Test Your Understanding: Network Fault Anomaly Detection

## Demo
`machinelearning/02_customer_churn_prediction.py`

---

### Pre-requisite

Run the above python script/demo and 
1) review the graphs and analysis it is presenting on screen and in the terminal
2) take the effort to understand the code and get your questions/doubts answered by using github copilot/claude or any other AI chatbot.

Only **after** you carry out the above activity, review this document to test and reinforce your learning.

## Questions

### 1. The demo uses Logistic Regression (LR) and Gradient Boosting (GB) algorithms. Why are 2 needed?
**Answer:**  
LR learns only linear patterns. GB can learn non-linear patterns as well

In the context of customer churn prediction with Gradient Boosting, here are concrete examples of non-linear patterns:

1. Threshold effects on tenure: 

   Churn risk doesn't decrease linearly with tenure. A customer with 1 month tenure might have 60% churn risk, at 6 months it drops to 20%, but after that it barely changes (12 months = 18%, 24 months = 17%). There's a steep cliff early on that a linear model can't capture well.

2. U-shaped relationship with usage: 

   Customers who use the service very little churn (not engaged), and customers who use it very heavily also churn (frustrated/overloaded). Moderate users are the most loyal. This is a non-linear, U-shaped curve.
   
3. Interaction effects: 

   A high monthly charge alone might not predict churn, and a short contract alone might not either — but the combination of high charges AND a month-to-month contract strongly predicts churn. Gradient Boosting naturally captures these feature interactions through its tree splits.
   
4. Diminishing sensitivity to price: 

   Going from $20/month to $40/month might significantly increase churn probability, but going from $80 to $100 might have almost no additional effect (customers at that tier already accepted high costs).
   
5. Step functions in support calls: 

   Customers with 0-1 support calls = low churn, 2-3 = moderate, but 4+ = very high churn. The relationship jumps at certain thresholds rather than increasing smoothly.

Logistic Regression can only draw a straight decision boundary through these features, so it would miss these patterns. Gradient Boosting  uses an ensemble of decision trees, where each tree can split on different thresholds and feature combinations, naturally modeling all of the above.

### Inferences from frequency distribution plots
![Distribution Plots](reports/02_distribution_plots.jpg)

**Key Observations:**

#### 1. `tenure_months` — Non-Linear Pattern
- Churned customers skew heavily toward low tenure (0–15 months). New customers are far more likely to churn.
- Long-tenure customers (40+ months) rarely churn — loyalty increases with time.
- This is a **decaying/exponential pattern**, not a straight-line relationship. A linear model would struggle to capture the steep early drop-off.

#### 2. `monthly_charges` — Approximately Linear Pattern
- Churned customers tend to have higher monthly charges (skewed right, prominent in the 70–110 range).
- Retained customers are more spread out, with a peak around 50–60. Higher bills may drive dissatisfaction.
- A linear model could reasonably capture this **monotonic, gradual trend**, though there may be slight non-linearity at the extremes.

#### 3. `complaint_count_6m` — Non-Linear (Step/Threshold) Pattern
- Most customers (both groups) have 0 complaints, but churned customers have a noticeably higher proportion with 1+ complaints.
- Filing even one complaint significantly increases churn likelihood.
- The jump from 0 to 1 complaint causes a **disproportionate increase** in churn. Going from 1→2 or 2→3 adds less marginal risk. This is a threshold effect, not a linear gradient.

#### 4. `payment_delay_days` — Non-Linear (Threshold) Pattern
- Churned customers show a higher concentration at low delay values (1–5 days) compared to retained.
- Most customers in both groups have minimal delays, so this feature may be a weaker predictor on its own.
- The relationship is **concentrated at the lower end** rather than increasing linearly with more delay days.

#### 5. `usage_trend_3m` — Approximately Linear Pattern
- Churned customers have a negatively shifted usage trend — their usage is declining over 3 months.
- Retained customers center around 0 or slightly positive, meaning stable/growing usage.
- There is a fairly **smooth, monotonic relationship**: more negative trend → more churn. This is likely a **strong churn signal**.

#### 6. `avg_monthly_usage_gb` — Non-Linear Pattern
- Churned customers cluster at lower usage (0–20 GB).
- Retained customers have a broader, higher-usage distribution. Low engagement correlates with churn.
- This is a **diminishing/logarithmic pattern** — the difference between 5 GB and 20 GB matters much more than between 50 GB and 80 GB.

#### Summary

| Feature | Pattern | Best Captured By |
|---|---|---|
| `tenure_months` | Non-linear (exponential decay) | Tree-based / polynomial |
| `monthly_charges` | ~Linear (monotonic) | Linear models work |
| `complaint_count_6m` | Non-linear (step/threshold) | Tree-based / binning |
| `payment_delay_days` | Non-linear (threshold) | Tree-based / binning |
| `usage_trend_3m` | ~Linear (monotonic) | Linear models work |
| `avg_monthly_usage_gb` | Non-linear (logarithmic) | Tree-based / log transform |

Since **4 out of 6 features show non-linear patterns**, a tree-based model (Random Forest, XGBoost) would likely outperform a plain Logistic Regression. Alternatively, feature engineering (log transforms, binning, polynomial terms) could help linear models capture these patterns.

---

### Inferences and actions from correlation plot
![Distribution Plots](reports/02_correlation.jpg)

#### Strong Feature-to-Feature Correlations (Multicollinearity)

| Pair | Correlation | Implication |
|---|---|---|
| `tenure_months` ↔ `total_charges` | **0.87** | Near-redundant — longer tenure = more total charges. Consider dropping one. |
| `complaint_count_6m` ↔ `support_calls_6m` | **0.77** | Highly correlated — complaints drive support calls. Keep one or combine into a single "dissatisfaction" feature. |
| `monthly_charges` ↔ `avg_monthly_usage_gb` | **0.66** | Moderate — higher usage leads to higher bills. Both can be kept, but watch for collinearity in linear models. |

#### Correlation with Target (`churned`)

| Feature | Correlation | Interpretation |
|---|---|---|
| `tenure_months` | **-0.17** | Strongest negative — longer tenure = lower churn (loyalty effect) |
| `total_charges` | **-0.12** | Negative — high-value customers churn less |
| `monthly_charges` | **+0.10** | Positive — higher bills push customers to churn |
| `usage_trend_3m` | **-0.07** | Negative — declining usage predicts churn |
| `avg_monthly_usage_gb` | **+0.06** | Weak positive |
| `complaint_count_6m` | **+0.03** | Very weak |
| `support_calls_6m` | **+0.02** | Very weak |
| `payment_delay_days` | **+0.02** | Very weak |

#### Key Takeaways

1. **Low linear correlations with `churned` don't mean features are unimportant.** From the distribution plots, features like `complaint_count_6m` and `payment_delay_days` showed clear non-linear/threshold patterns with churn. Pearson correlation only captures linear relationships, so it underestimates their true predictive power.

2. **Multicollinearity concerns for linear models:**
   - `tenure_months` and `total_charges` (0.87) — drop `total_charges` since it's a derived feature (tenure × monthly charges)
   - `complaint_count_6m` and `support_calls_6m` (0.77) — keep one, or engineer a combined feature

3. **Most features are independent of each other** — correlations near 0.00 between features like `payment_delay_days`, `usage_trend_3m`, and others. This is good — each feature brings unique information to the model.

#### Recommended Actions

| Action | Reason |
|---|---|
| Drop `total_charges` | Redundant with `tenure_months` (r=0.87) |
| Drop one of `complaint_count_6m` / `support_calls_6m` | High collinearity (r=0.77) |
| Don't rely on Pearson correlation alone for feature selection | Non-linear features like `complaint_count_6m` appear weak here but were strong in the distribution plots |
| Use tree-based feature importance or mutual information | These capture non-linear relationships that Pearson misses |
