# Test Your Understanding: Network Fault Anomaly Detection

## Demo
`machinelearning/01_network_fault_anomaly_prediction.py`

---

### Pre-requisite

Run the above python script/demo and 
1) review the graphs and analysis it is presenting on screen and in the terminal
2) take the effort to understand the code and get your questions/doubts answered by using github copilot/claude or any other AI chatbot.

Only **after** you carry out the above activity, review this document to test and reinforce your learning.

## Questions

### 1. Does the presence of `is_anomaly` make this supervised learning?
**Answer:**  
No. The `is_anomaly` field is introduced during synthetic data generation to label deliberately injected anomalies.  
It is **not used during training** and exists only for **evaluation and validation** of model performance.  
The models are trained exclusively on normal data, making this a **novelty detection / semi-supervised anomaly detection** setup.

---

### 2. Inferences from correlation analysis
![Correlation Heatmap](reports/01_correlation.jpg)

**Answer:**  
- In anomalous data, `device_temperature` becomes correlated with `memory_usage` (~0.37), a relationship absent in normal data.  
- The strong `cpu_load ↔ temperature` correlation (~0.90) persists.  
- The key signal is the **emergence of new correlations**, not the breakdown of existing ones—indicating abnormal system behavior.

---

### 3. Inferences from frequency distribution plots
![Distribution Plots](reports/01_distribution_plots.jpg)

**Key Observations:**

1. **Severe class imbalance**  
   Anomalies are vastly outnumbered by normal samples.

2. **No single-feature separation**  
   Anomalous distributions overlap heavily with normal ones—no feature alone can detect anomalies reliably.

3. **Feature-specific notes**
   - `cpu_load`: Normal is bimodal; anomalies cluster at lower values.
   - `device_temperature`: Anomalies extend into higher temperatures.
   - `memory_usage`: Slight anomaly spread toward higher values.
   - `packet_drop_rate`: Anomalies show marginally higher values.
   - `interface_errors`: Mostly zero; low information.
   - `latency_ms`: Fully overlapping distributions.

**Bottom line:**  
Detection requires **multivariate patterns**, not thresholds on individual features.

---

### 4. How can anomalies be detected without training on anomaly data?
**Answer:**  
These models learn **what normal looks like** and flag deviations.

This approach is known as **novelty detection**.

#### Isolation Forest
- Uses random feature splits to isolate points.
- Normal points require many splits.
- Anomalies are isolated quickly.
- Shorter average path length → anomaly.

#### One-Class Support Vevtor Machine (SVM)
- Learns a tight boundary around normal data.
- Points outside the boundary are anomalies.
- Uses kernel tricks for non-linear boundaries.

This works well because:
- Real-world anomalies are rare and diverse.
- Normal behavior is stable and learnable.
- New, unseen faults still deviate from learned normal patterns.

---

### 5. Algorithms used and comparison with K-Means

#### Algorithms Used
- **Isolation Forest**
- **One-Class SVM**

# Anomaly Detection: Key Insights & Algorithms

# Anomaly Detection Algorithms

## Core Paradigm: Novelty Detection

**Key insight**: These are not classifiers. They don't learn "what anomalies look like." Instead, they learn what normal looks like and flag anything that deviates. This paradigm is called **novelty detection** or **semi-supervised anomaly detection**.

---

## Isolation Forest

### Core Idea
Anomalies are few and different, so they're easier to isolate.

### How It Works
- Builds an ensemble of random decision trees
- Each tree randomly picks a feature and a random split value, recursively partitioning data
- Normal points sit in dense clusters → need many splits to isolate a single point
- Anomalies are sparse/outlying → need few splits to isolate

### Example Comparison

**Normal point (buried in cluster):**
```
Split 1 → still many points
Split 2 → still many points
Split 3 → still many points
...
Split 8 → finally isolated
```

**Anomaly (isolated quickly):**
```
Split 1 → only a few points
Split 2 → isolated!
```

**The anomaly score** = average path length across all trees. Short path = anomaly.

### Detailed Mechanism

#### Step 1: Build random trees
Pick a random feature, pick a random split value within that feature's range, and partition the data. Repeat recursively until every point is isolated.

```
                    cpu_load < 35?
                   /              \
          temp < 42?              temp < 50?
          /       \               /        \
      mem < 30?   (point A)   (point X)   latency < 8?
      /      \                             /          \
  (...)    (...)                       (...)        (...)
```

#### Step 2: Measure path length
Count how many splits it took to isolate each point.

**Normal point (in a dense cluster):**
```
Split 1: cpu_load < 35     → still 5000 points in this partition
Split 2: temp < 42         → still 2300 points
Split 3: mem < 38          → still 900 points
Split 4: latency < 7.5     → still 400 points
...
Split 11: finally isolated

Path length = 11  →  NORMAL (hard to isolate)
```

**Anomalous point (unusual values):**
```
Split 1: cpu_load < 35     → only 12 points in this partition
Split 2: temp < 58         → just 1 point — isolated!

Path length = 2   →  ANOMALY (easy to isolate)
```

#### Step 3: Average across many trees
Build ~100 random trees, average the path lengths. Short average path = anomaly.

### Intuition: Why Random Splits Work

Think of it spatially:

**Dense region (normal):**
```
○ ○ ○ ○ ○ ○ ○
○ ○ ○ ○ ○ ○ ○
○ ○ ○ ○ ○ ○ ○
○ ○ ○ ○ ○ ○ ○

A random line through here
still leaves many points on
both sides → need more cuts
```

**Sparse region (anomaly):**
```
                    ×


A random line near here
likely separates × from
everything → isolated fast
```

**No distance computation needed.** The structure of random partitioning itself reveals density — dense regions require deep trees, sparse regions produce shallow paths.

---

## One-Class SVM

### Core Idea
Learn a tight boundary around normal data in a high-dimensional space.

### How It Works
- Uses a kernel (typically RBF) to map data into a higher-dimensional feature space
- Finds a hyperplane that separates all the normal data from the origin with maximum margin
- This effectively creates a "bubble" around the normal data distribution

### At Test Time
- Points inside the boundary → normal
- Points outside the boundary → anomaly

---

## Why This Works for Network Faults

The training strategy makes practical sense:

1. **You rarely have labeled anomalies** in real-world network data. Faults are rare and varied — you can't collect examples of every possible failure mode.

2. **Normal behavior is well-defined** — devices under healthy operation produce consistent, learnable patterns.

3. **Anomalies are diverse** — a new fault type you've never seen should still be caught because it deviates from normal, even though no similar example was in training.

So the model learns: "this is what healthy network telemetry looks like" → anything sufficiently outside that pattern gets flagged.

### Zero Anomalies in Training?

**Yes!** Even if training data has zero anomalies, the model will be able to detect anomalies as and when they arise. That's the fundamental design of these algorithms — they define a boundary of "normality" from clean data, and anything that falls outside that boundary is flagged, even if the model has never seen that specific type of anomaly before.

In fact, algorithms such as SVM require that the training data does not contain anomlaies (contamination) - it is therefore also called semi-supervised learning.
In a typical telecom scenario, you can collect data during normal operation and make it the training data for SVM.

---

## Comparison: Novelty Detection vs. Supervised Classifiers

| Aspect | Novelty Detection (IF, OC-SVM) | Supervised Classifier (e.g., Random Forest) |
|--------|--------------------------------|---------------------------------------------|
| Needs labeled anomalies? | No | Yes |
| Detects unseen anomaly types? | Yes | Only types seen in training |
| Precision on known anomaly types? | Lower | Higher |
| Real-world practicality? | High — anomalies are rare | Hard — need enough labeled examples of each fault type |

In practice for network monitoring, novelty detection is often preferred because you can't anticipate every failure mode. A new kind of hardware fault or traffic pattern will still deviate from the learned normal profile and get caught.

---

## K-Means for Anomaly Detection

K-Means can be adapted for anomaly detection, but it wasn't designed for it.

### How K-Means Works for Anomaly Detection

K-Means clusters all data into K groups, then you use distance from the nearest cluster center as an anomaly score. Points far from any center are flagged.

```
Cluster 1 center: [40, 45, 35, 0.01, 0, 7]   ← "normal profile A"
Cluster 2 center: [15, 38, 42, 0.02, 0, 6]   ← "normal profile B"

New point:         [60, 62, 55, 0.15, 3, 11]  ← far from both → anomaly
```

---

## Algorithm Comparison

| Feature | Isolation Forest | One-Class SVM | K-Means |
|---------|-----------------|---------------|---------|
| **Designed for** | Anomaly detection | Novelty detection | Clustering |
| **How it detects** | Ease of isolation (path length) | Distance from learned boundary | Distance from cluster centers |
| **Handles non-spherical shapes?** | Yes — tree splits adapt to data | Yes — kernel maps to flexible boundaries | No — assumes spherical/convex clusters |
| **Sensitive to K or hyperparams?** | Minimal tuning | Kernel and nu need tuning | Must choose K; results vary significantly |
| **Scales to high dimensions?** | Well | Poorly (kernel computation) | Poorly (distance becomes meaningless) |
| **Outlier robustness** | High — outliers get short paths naturally | High — trained only on normal | Low — outliers pull cluster centers |
| **Training data requirement** | Semi-supervised (mostly normal data); tolerates 10-20% contamination | Semi-supervised (clean normal data preferred); sensitive to contamination | Unsupervised (accepts mixed data); but anomalies distort cluster centers |
| **Learning paradigm** | Learn what's normal, flag deviations | Learn what's normal, flag deviations | Cluster all data, use distance to flag outliers |


---

## The Core Problem with K-Means

K-Means minimizes within-cluster variance — it's solving a different objective entirely. Two practical issues for anomaly detection:

1. **Arbitrary threshold**: You have to manually decide "how far is too far?" There's no principled boundary like OC-SVM gives you.

2. **Shape assumption**: K-Means assumes clusters are roughly spherical. If normal data forms an irregular shape in feature space (which is common), K-Means will either miss anomalies inside the gaps or flag normal points on the edges.

```
K-Means sees this:          Reality might be this:

    ○ ○ ○ ○                     ○ ○ ○ ○
    ○ [C] ○        but          ○       ○
    ○ ○ ○ ○                     ○ ○ ○ ○
                                (hollow/irregular shape)
   → circular boundary          → point at center is actually anomalous
```

### Bottom Line

- **Isolation Forest / OC-SVM**: purpose-built for "learn normal, flag deviations" — no need to define distance thresholds or cluster counts
- **K-Means**: a general clustering algorithm that can be repurposed for anomaly detection, but requires manual threshold tuning and makes geometric assumptions that often don't hold

For the network fault use case, Isolation Forest and OC-SVM are the more natural fit.

---

## Support Vector Machine (SVM) - Further Reading

### The Fundamental Idea

Given two classes of data, find the hyperplane (decision boundary) that separates them with the maximum margin.

### What is "Margin"?

The margin is the distance between the decision boundary and the nearest data points from each class. Those nearest points are the **support vectors** — they "support" (define) the boundary.

```
Class A (○)          Class B (●)

  ○                         ●
  ○  ○                   ●  ●
  ○  ○  ○    |margin|   ●  ●
  ○  ○  ←SV  |=====|  SV→  ●
  ○  ○  ○    |     |   ●  ●
  ○  ○                   ●  ●
  ○                         ●
             ↑
        decision boundary
```

**Why maximize margin?** A wider margin means better generalization — the boundary is as far as possible from both classes, so unseen points are less likely to be misclassified.

---

## The Kernel Trick — Handling Non-Linear Data

Real data is often not linearly separable:

```
Can't draw a straight line here:

        ●  ●  ●
      ●  ○  ○  ●
      ●  ○  ○  ●
        ●  ●  ●
```

The kernel trick maps data to a higher-dimensional space where it becomes linearly separable, without actually computing the transformation.

```
2D (not separable)          3D (separable!)

  ● ○ ○ ●                     ●         ●
                    →            ○  ○
                               --------  ← hyperplane
                                 ●  ●
```

### Common Kernels

| Kernel | What it does |
|--------|--------------|
| Linear | No transformation — straight line/plane |
| RBF (Gaussian) | Maps to infinite dimensions — creates flexible, curved boundaries |
| Polynomial | Maps to polynomial feature space |

The kernel function computes the dot product in the higher-dimensional space directly from the original coordinates — this is what makes it computationally feasible.

---

## One-Class SVM (Detailed)

Standard SVM separates two classes. One-Class SVM has only one class (normal data):

- Maps normal data to high-dimensional space via kernel
- Finds a hyperplane that separates the data from the origin with maximum margin
- The origin represents "nothingness" — the absence of data

```
Feature space:

                /  ○ ○ ○  \
origin   / ○  ○  ○ ○ \    ← boundary
       ×     |  ○  ○  ○    |
               \ ○  ○  ○  /
                \________/

New point outside boundary → anomaly
```

---

## SVM Summary

| Concept | Role |
|---------|------|
| Hyperplane | The decision boundary |
| Support vectors | The closest points that define the boundary |
| Margin | Gap between boundary and support vectors — maximized |
| Kernel | Transforms data so non-linear problems become linear |
| One-Class variant | Learns a boundary around a single class (normal) |

**The elegance of SVMs** is that the entire model is defined by just a handful of support vectors, regardless of how large the dataset is.

---

## High-Level Model Comparison

### Problem Characteristics

| Problem | K-Means | SVM | Isolation Forest |
|---------|---------|-----|------------------|
| **Curse of dimensionality** | Yes — raw Euclidean distance degrades | Mitigated — kernel operates in transformed space | Immune — no distance computation |
| **Shape assumption** | Spherical clusters | Flexible — kernel creates curved boundaries | None |
| **Threshold tuning** | Manual | Principled (margin optimization) | Automatic (path length) |

---

## When to Use Each Algorithm

### SVM Wins When:
- Dataset is small to moderate
- You need a precise, well-defined decision boundary
- The data has clear structure that a kernel can exploit

### Isolation Forest Wins When:
- Dataset is large (SVM training is O(n²) to O(n³), IF is O(n log n))
- High dimensionality — kernels become expensive to compute
- Minimal tuning needed — IF works well out of the box
- You want interpretable anomaly scores (path length is intuitive; SVM's decision function is less so)

---

## Key Takeaway

Isolation Forest doesn't ask "how far is this point from normal?" — it asks "how easy is this point to isolate?" That's a fundamentally different question, and it's answered purely through tree structure, not distance metrics.
