import os
from langchain_openai import AzureOpenAIEmbeddings
import warnings
from dotenv import load_dotenv
import glob
import shutil

load_dotenv()
warnings.filterwarnings("ignore")

CHROMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'chroma_db')

# Clear existing vector database
if os.path.exists(CHROMA_PATH):
    print(f"Clearing existing vector database at {CHROMA_PATH}")
    shutil.rmtree(CHROMA_PATH)

def load_document(file):
    name, extension = os.path.splitext(file)

    if extension == '.pdf':
        from langchain_community.document_loaders import PyPDFLoader
        print(f'Loading {file}')
        loader = PyPDFLoader(file)
    elif extension == '.docx':
        from langchain_community.document_loaders import Docx2txtLoader
        print(f'Loading {file}')
        loader = Docx2txtLoader(file)
    elif extension == '.txt':
        from langchain_community.document_loaders import TextLoader
        loader = TextLoader(file)
    else:
        print('Document format is not supported!')
        return None

    data = loader.load()
    return data

def chunk_data(data, chunk_size=256):
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, 
        chunk_overlap=20  # Added some overlap
    )
    chunks = text_splitter.split_documents(data)
    print(f"Created {len(chunks)} chunks")
    return chunks 

def create_embeddings_chroma(chunks, persist_directory=CHROMA_PATH):
    from langchain_community.vectorstores import Chroma
 
    # Load credentials from environment
    embeddings = AzureOpenAIEmbeddings(
        model=os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME"),
        api_key=os.getenv("AZURE_OPENAI_EMBEDDING_KEY"),
        azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT")
    )

    #Here's the exact pipeline inside the embedding model:

    # Step 1: Tokenization
    # The chunk text is split into tokens using the model's tokenizer 
    # (e.g., BPE for OpenAI models). "Machine learning is great" might become 
    # ["Machine", " learning", " is", " great"] → token IDs like [22137, 6975, 374, 2294].

    # Step 2: Token-level embeddings
    # Each token ID is mapped to an initial vector via a lookup table. 
    # So now you have N vectors (one per token), each of some internal dimension.

    # Step 3: Transformer processing
    # These token vectors pass through multiple transformer layers. 
    # Each layer applies self-attention, so every token's vector gets updated based on
    #  the context of all other tokens. 
    # After this, each token has a contextualized embedding — 
    # the vector for "bank" would be different in "river bank" vs "bank account".

    # Step 4: Pooling → single vector
    # This is the key step. The model collapses all the per-token vectors into 
    # one vector for the entire input. Common strategies:
    # Mean pooling: average all token vectors
    # [CLS] token: use the first special token's vector as the summary
    # OpenAI models use their own pooling strategy (not publicly documented)
    # The output is a single 1536-dimensional vector for the model we are using,
    # that represents the semantic meaning of the entire chunk.

    # So to summarize:
    # "chunk text" → [token IDs] → [N token vectors] → Transformer → [N contextualized vectors] → Pooling → 1 vector (1536-d)
    # The per-token embeddings from steps 2-3 exist internally but are discarded. 
    # Only the final pooled vector is returned by the API and stored in Chroma.
    try:
        vector_store = Chroma.from_documents(chunks, embeddings, persist_directory=persist_directory)
        print(f"Successfully created {vector_store._collection.count()} embeddings in Chroma vector store")
        print(f"""Number of embeddings are same as number of chunks
This is because the model takes entire input (your chunk of ~256 characters)
and produces a single vector that represents the semantic meaning of that whole chunk. 
So 265 chunks = 265 embeddings. 
At query time, your question also gets converted into one embedding vector
That query vector is compared against the 265 chunk vectors to find the most semantically similar chunks
The matching chunks are then passed as context to the LLM.
              """)
    except Exception as e:
        print(f"Error creating embeddings: {e}")
        raise

#### MAIN PROCESSING STARTS HERE

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
print(f'Looking for PDF files in {data_dir}')
pdf_files = glob.glob(os.path.join(data_dir, '*.pdf'))

print(f'Found {len(pdf_files)} PDF files to process.')

# Load all PDF documents - flatten the structure
all_documents = []  # Renamed for clarity
for pdf_file in pdf_files:
    try:
        print(f'Processing file: {pdf_file}')
        docs = load_document(pdf_file)
        if docs:
            all_documents.extend(docs)  # Use extend instead of append
            print(f"Loaded: {os.path.basename(pdf_file)}")
    except Exception as e:
        print(f"Error loading {pdf_file}: {e}")

if not all_documents:
    print("No documents loaded successfully!")
    exit(1)

print(f'Loaded {len(all_documents)} document pages...')

# Split the documents into chunks
print('Splitting documents into chunks')
chunks = chunk_data(all_documents, chunk_size=256)

if chunks:
    create_embeddings_chroma(chunks)
    print('Chroma vector db created successfully')
else:
    print('No chunks created - check your documents')