# Assignment: Fixing RAG Retrieval Using Metadata

## The Problem

Run the `03streamlit_retriever.py` app and ask the following question:

> **"Suggest a talent acquisition specialist"**

You will notice that the app responds with **"I don't know"** even though the indexed resumes clearly contain information about talent acquisition.

### Why is this happening?

1. Inspect the Source Documents in the UI, (**chunks that are being retrieved**). You will see that the retriever *is* finding relevant chunks — chunks that mention "talent acquisition", "recruiting", "HR strategy", etc.

2. However, look closely at those chunks. **The candidate's name is missing from them.** This is because the person's name appears at the **top of the resume** (page 1, first few lines), while the skills and experience content appears further down.

3. When the document is split into chunks of ~256 characters, the **name ends up in one chunk** and the **talent acquisition skills end up in a completely different chunk**. There is no overlap between them.

4. So when the LLM receives the retrieved chunks as context, it sees descriptions of talent acquisition experience **but has no idea who the person is**. Since it cannot name a candidate, it correctly says "I don't know."

This is a common and important limitation of naive chunking in RAG systems.

## Your Task

Solve this problem using the **metadata filtering** technique. The idea is simple: **attach the candidate's name as metadata to every chunk** that originates from their resume. That way, even when a chunk doesn't explicitly contain the name, the metadata carries it along.

### Steps

#### Step 1: Modify the Indexer (`01indexer.py`)

Update the indexing pipeline so that each chunk carries metadata identifying which candidate it belongs to.

- After loading a PDF, **extract the candidate's name**. You can do this by:
  - Parsing it from the **filename** (e.g., `Pankaj_Resume.pdf` -> `Pankaj`), OR
  - Extracting it from the **first few lines of the first page** of the document
- Before chunking (or after chunking), **inject this name into the metadata** of every chunk from that document:
  ```python
  # Example: adding metadata to each chunk
  for chunk in chunks:
      chunk.metadata["candidate_name"] = candidate_name
  ```
- Re-run the indexer to rebuild the vector database with the updated metadata.

#### Step 2: Modify the Retriever (`03streamlit_retriever.py`)

Update the `ask_and_get_answer` function so that the **prompt template** instructs the LLM to use chunk metadata.

- Modify the `format_docs` helper to **include metadata** alongside the chunk content:
  ```python
  def format_docs(docs):
      formatted = []
      for doc in docs:
          candidate = doc.metadata.get("candidate_name", "Unknown")
          formatted.append(f"[Candidate: {candidate}]\n{doc.page_content}")
      return "\n\n".join(formatted)
  ```
- Optionally, update the prompt template to tell the LLM that each chunk is tagged with a candidate name and that it should use this information when answering.

#### Step 3: Test

1. Re-run `01indexer.py` to rebuild the ChromaDB with metadata.
2. Launch `03streamlit_retriever.py` and ask:
   - "Suggest a talent acquisition specialist"
   - "Who has experience in machine learning?"
   - "Recommend a candidate for a project management role"
3. Verify that the app now **returns candidate names** in its answers.

## Expected Outcome

After your changes, asking "Suggest a talent acquisition specialist" should return a response that **names the relevant candidate(s)** from the indexed resumes, along with a brief summary of their relevant experience.

## Hints

- Each LangChain `Document` object has a `.metadata` dictionary — you can add any key-value pairs to it.
- ChromaDB stores metadata alongside embeddings automatically, so no extra configuration is needed on the DB side.
- The `source` key already exists in the metadata (added by the PDF loader). You are adding `candidate_name` as an additional key.
- If you want to verify your metadata is stored correctly, you can inspect it in the retriever:
  ```python
  docs = retriever.invoke("talent acquisition")
  for doc in docs:
      print(doc.metadata)
  ```
