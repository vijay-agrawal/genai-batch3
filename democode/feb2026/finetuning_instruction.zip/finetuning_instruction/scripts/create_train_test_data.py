import json
import random
from typing import List, Dict, Tuple
from sklearn.model_selection import train_test_split
from datasets import Dataset
import pandas as pd


def load_training_data(file_path: str) -> List[Dict[str, str]]:
    """
    Load training data from JSON file.
    
    Args:
        file_path: Path to the JSON file containing training data
        
    Returns:
        List of training examples
    """
    print(f"Loading data from {file_path}...")
    
    with open(file_path, 'r') as f:
        data = json.load(f)
    
    print(f"✓ Loaded {len(data)} examples")
    return data


def create_train_val_split(
    data: List[Dict[str, str]], 
    val_size: float = 0.2,
    random_seed: int = 42,
    stratify_by_anomaly: bool = True
) -> Tuple[List[Dict[str, str]], List[Dict[str, str]]]:
    """
    Split data into training and validation sets.
    
    Args:
        data: List of training examples
        val_size: Proportion of data to use for validation (default: 0.2 = 20%)
        random_seed: Random seed for reproducibility
        stratify_by_anomaly: Whether to stratify split by anomaly presence
        
    Returns:
        Tuple of (train_data, val_data)
    """
    print(f"\nSplitting data: {int((1-val_size)*100)}% train, {int(val_size*100)}% validation")
    
    if stratify_by_anomaly:
        # Create labels for stratification (has anomaly or not)
        labels = []
        for item in data:
            # Check if response contains anomaly flag other than "None"
            response = json.loads(item['response'])
            has_anomaly = response.get('anomaly_flag', 'None') != 'None'
            labels.append(1 if has_anomaly else 0)
        
        train_data, val_data = train_test_split(
            data,
            test_size=val_size,
            random_state=random_seed,
            stratify=labels
        )
        
        print("✓ Stratified split (balanced anomaly distribution)")
    else:
        train_data, val_data = train_test_split(
            data,
            test_size=val_size,
            random_state=random_seed
        )
        
        print("✓ Random split")
    
    return train_data, val_data


def analyze_dataset_split(train_data: List[Dict], val_data: List[Dict]):
    """
    Print statistics about the dataset split.
    """
    def count_anomalies(dataset):
        anomaly_count = 0
        for item in dataset:
            response = json.loads(item['response'])
            if response.get('anomaly_flag', 'None') != 'None':
                anomaly_count += 1
        return anomaly_count
    
    train_anomalies = count_anomalies(train_data)
    val_anomalies = count_anomalies(val_data)
    
    print("\n" + "="*50)
    print("DATASET STATISTICS")
    print("="*50)
    
    print(f"\nTraining Set:")
    print(f"  Total examples: {len(train_data)}")
    print(f"  With anomalies: {train_anomalies} ({train_anomalies/len(train_data)*100:.1f}%)")
    print(f"  Without anomalies: {len(train_data)-train_anomalies} ({(len(train_data)-train_anomalies)/len(train_data)*100:.1f}%)")
    
    print(f"\nValidation Set:")
    print(f"  Total examples: {len(val_data)}")
    print(f"  With anomalies: {val_anomalies} ({val_anomalies/len(val_data)*100:.1f}%)")
    print(f"  Without anomalies: {len(val_data)-val_anomalies} ({(len(val_data)-val_anomalies)/len(val_data)*100:.1f}%)")
    
    print("="*50)


def convert_to_huggingface_dataset(data: List[Dict[str, str]]) -> Dataset:
    """
    Convert list of dicts to HuggingFace Dataset format.
    
    Args:
        data: List of training examples
        
    Returns:
        HuggingFace Dataset object
    """
    # Convert to format expected by HuggingFace
    formatted_data = {
        'instruction': [item['instruction'] for item in data],
        'response': [item['response'] for item in data]
    }
    
    return Dataset.from_dict(formatted_data)


def save_datasets(
    train_data: List[Dict], 
    val_data: List[Dict],
    output_dir: str = "./datasets"
):
    """
    Save training and validation datasets to JSON files.
    
    Args:
        train_data: Training dataset
        val_data: Validation dataset
        output_dir: Directory to save files
    """
    import os
    
    os.makedirs(output_dir, exist_ok=True)
    
    train_path = os.path.join(output_dir, "train.json")
    val_path = os.path.join(output_dir, "val.json")
    
    with open(train_path, 'w') as f:
        json.dump(train_data, f, indent=2)
    
    with open(val_path, 'w') as f:
        json.dump(val_data, f, indent=2)
    
    print(f"\n✓ Saved training data to {train_path}")
    print(f"✓ Saved validation data to {val_path}")


def create_dataframe_view(data: List[Dict[str, str]]) -> pd.DataFrame:
    """
    Create a pandas DataFrame for easy viewing and analysis.
    
    Args:
        data: List of training examples
        
    Returns:
        DataFrame with parsed information
    """
    records = []
    
    for item in data:
        response = json.loads(item['response'])
        records.append({
            'document_number': response.get('document_number', ''),
            'vendor_name': response.get('vendor_name', ''),
            'amount': response.get('amount', ''),
            'transaction_type': response.get('transaction_type', ''),
            'anomaly_flag': response.get('anomaly_flag', 'None'),
            'has_anomaly': response.get('anomaly_flag', 'None') != 'None'
        })
    
    return pd.DataFrame(records)


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """
    Complete pipeline to load and split the dataset.
    """
    # Configuration
    INPUT_FILE = "sap_training_enhanced.json"
    VALIDATION_SIZE = 0.2  # 20% for validation
    RANDOM_SEED = 42
    
    try:
        # Step 1: Load data
        data = load_training_data(INPUT_FILE)
        
        # Step 2: Split into train/val
        train_data, val_data = create_train_val_split(
            data,
            val_size=VALIDATION_SIZE,
            random_seed=RANDOM_SEED,
            stratify_by_anomaly=True
        )
        
        # Step 3: Analyze the split
        analyze_dataset_split(train_data, val_data)
        
        # Step 4: Convert to HuggingFace datasets (optional)
        print("\nConverting to HuggingFace Dataset format...")
        train_dataset = convert_to_huggingface_dataset(train_data)
        val_dataset = convert_to_huggingface_dataset(val_data)
        print("✓ Datasets converted")
        
        # Step 5: Save to separate files
        save_datasets(train_data, val_data)
        
        # Step 6: Create DataFrame view (optional)
        print("\nCreating DataFrame view...")
        train_df = create_dataframe_view(train_data)
        val_df = create_dataframe_view(val_data)
        
        print("\nSample from Training Set:")
        print(train_df.head())
        
        print("\nAномaly Distribution in Training Set:")
        print(train_df['has_anomaly'].value_counts())
        
        # Return datasets for further use
        return {
            'train_list': train_data,
            'val_list': val_data,
            'train_hf': train_dataset,
            'val_hf': val_dataset,
            'train_df': train_df,
            'val_df': val_df
        }
        
    except FileNotFoundError:
        print(f"\n❌ Error: File '{INPUT_FILE}' not found!")
        print("Please ensure you've run the data generation script first.")
        return None
    except Exception as e:
        print(f"\n❌ Error: {e}")
        return None


# Example usage for different frameworks
def example_pytorch_dataloader(train_data: List[Dict]):
    """
    Example: Create PyTorch DataLoader (if needed)
    """
    from torch.utils.data import DataLoader, Dataset as TorchDataset
    
    class SAPDataset(TorchDataset):
        def __init__(self, data):
            self.data = data
        
        def __len__(self):
            return len(self.data)
        
        def __getitem__(self, idx):
            return {
                'instruction': self.data[idx]['instruction'],
                'response': self.data[idx]['response']
            }
    
    dataset = SAPDataset(train_data)
    dataloader = DataLoader(dataset, batch_size=4, shuffle=True)
    
    return dataloader


if __name__ == "__main__":
    # Run the complete pipeline
    datasets = main()
    
    if datasets:
        print("\n" + "="*50)
        print("✓ DATASETS READY FOR TRAINING")
        print("="*50)
        print("\nAvailable datasets:")
        print("  - datasets['train_list']: Training data as list")
        print("  - datasets['val_list']: Validation data as list")
        print("  - datasets['train_hf']: HuggingFace Dataset (train)")
        print("  - datasets['val_hf']: HuggingFace Dataset (val)")
        print("  - datasets['train_df']: Pandas DataFrame (train)")
        print("  - datasets['val_df']: Pandas DataFrame (val)")
        
        # Optional: Show a sample example
        print("\n" + "="*50)
        print("SAMPLE TRAINING EXAMPLE")
        print("="*50)
        sample = random.choice(datasets['train_list'])
        print(f"\nInstruction:\n{sample['instruction']}")
        print(f"\nResponse:\n{sample['response']}")