import json
import random
from typing import List, Dict
from datetime import datetime, timedelta

def generate_sap_training_data(n_samples: int = 150) -> List[Dict[str, str]]:
    """
    Generate synthetic SAP training data with emphasis on anomaly detection.
    Increased sample size and anomaly diversity for better model training.
    """
    vendors = [
        "Acme Corp", "Global Tech", "Premier Solutions", "Enterprise Systems",
        "Digital Dynamics", "Innovation Labs", "Strategic Partners", "Tech Vendors Inc"
    ]
    
    gl_accounts = {
        "5000": "Office Supplies",
        "5100": "Travel & Entertainment",
        "6200": "Software",
        "6300": "Hardware",
        "7000": "Consulting Services",
        "7100": "Professional Services"
    }
    
    transaction_types = ["Invoice", "Credit Memo", "Payment"]
    
    training_data = []
    
    # Generate diverse examples with higher anomaly rate
    for i in range(n_samples):
        vendor = random.choice(vendors)
        gl = random.choice(list(gl_accounts.keys()))
        trans_type = random.choice(transaction_types)
        
        # Create varied amount distribution with more high-value and large-credit examples
        if i % 5 == 0:  # 20% high-value invoices
            amount = random.uniform(40000, 100000)
        elif i % 7 == 0:  # ~14% large credits
            amount = -random.uniform(15000, 50000)
            trans_type = "Credit Memo"
        else:
            amount = random.uniform(100, 35000)
        
        date = datetime(2024, 1, 1) + timedelta(days=random.randint(0, 365))
        doc_num = f"SAP-{100000 + i}"
        
        # Determine anomalies
        anomalies = []
        if amount > 40000:
            anomalies.append("HIGH_VALUE - Requires additional approval")
        if trans_type == "Credit Memo" and abs(amount) > 15000:
            anomalies.append("LARGE_CREDIT - Requires supervisor review")
        
        anomaly_flag = "; ".join(anomalies) if anomalies else "None"
        
        # Create instruction
        instruction = f"""Analyze this SAP document and extract key information. Flag any anomalies:

{doc_num}
{trans_type}
Vendor: {vendor}
Amount: ${amount:,.2f}
GL: {gl}
Date: {date.strftime('%Y-%m-%d')}"""
        
        # Create response
        response_data = {
            "document_number": doc_num,
            "vendor_name": vendor,
            "amount": f"${amount:,.2f}",
            "gl_account": f"{gl} - {gl_accounts[gl]}",
            "transaction_type": trans_type,
            "date": date.strftime('%Y-%m-%d'),
            "anomaly_flag": anomaly_flag,
            "audit_summary": f"{trans_type} from {vendor} totaling ${abs(amount):,.2f}. "
                           f"{'Alert: ' + anomaly_flag if anomaly_flag != 'None' else 'No anomalies detected.'}"
        }
        
        training_data.append({
            "instruction": instruction,
            "response": json.dumps(response_data, indent=2)
        })
    
    return training_data


def add_explicit_anomaly_examples() -> List[Dict[str, str]]:
    """
    Add explicit training examples that emphasize anomaly detection rules.
    These serve as clear templates for the model to learn patterns.
    """
    explicit_examples = [
        # High-value invoice example
        {
            "instruction": """Analyze this SAP document and extract key information. Flag any anomalies:

SAP-999001
Invoice
Vendor: MegaCorp International
Amount: $52,000.00
GL: 6200
Date: 2024-03-15

Remember: Flag HIGH_VALUE if amount > $40,000""",
            "response": json.dumps({
                "document_number": "SAP-999001",
                "vendor_name": "MegaCorp International",
                "amount": "$52,000.00",
                "gl_account": "6200 - Software",
                "transaction_type": "Invoice",
                "date": "2024-03-15",
                "anomaly_flag": "HIGH_VALUE - Requires additional approval",
                "audit_summary": "Invoice from MegaCorp International totaling $52,000.00. Alert: HIGH_VALUE - Requires additional approval"
            }, indent=2)
        },
        # Large credit memo example
        {
            "instruction": """Analyze this SAP document and extract key information. Flag any anomalies:

SAP-999002
Credit Memo
Vendor: Tech Solutions Ltd
Amount: $-18,500.00
GL: 7000
Date: 2024-04-22

Remember: Flag LARGE_CREDIT if credit > $15,000""",
            "response": json.dumps({
                "document_number": "SAP-999002",
                "vendor_name": "Tech Solutions Ltd",
                "amount": "$-18,500.00",
                "gl_account": "7000 - Consulting Services",
                "transaction_type": "Credit Memo",
                "date": "2024-04-22",
                "anomaly_flag": "LARGE_CREDIT - Requires supervisor review",
                "audit_summary": "Credit Memo from Tech Solutions Ltd totaling $18,500.00. Alert: LARGE_CREDIT - Requires supervisor review"
            }, indent=2)
        },
        # Multiple anomalies example
        {
            "instruction": """Analyze this SAP document and extract key information. Flag any anomalies:

SAP-999003
Credit Memo
Vendor: Premium Services Inc
Amount: $-45,000.00
GL: 7100
Date: 2024-05-10

Check for both HIGH_VALUE and LARGE_CREDIT conditions""",
            "response": json.dumps({
                "document_number": "SAP-999003",
                "vendor_name": "Premium Services Inc",
                "amount": "$-45,000.00",
                "gl_account": "7100 - Professional Services",
                "transaction_type": "Credit Memo",
                "date": "2024-05-10",
                "anomaly_flag": "HIGH_VALUE - Requires additional approval; LARGE_CREDIT - Requires supervisor review",
                "audit_summary": "Credit Memo from Premium Services Inc totaling $45,000.00. Alert: HIGH_VALUE - Requires additional approval; LARGE_CREDIT - Requires supervisor review"
            }, indent=2)
        },
        # Normal transaction (no anomaly)
        {
            "instruction": """Analyze this SAP document and extract key information. Flag any anomalies:

SAP-999004
Invoice
Vendor: Office Supply Co
Amount: $1,250.00
GL: 5000
Date: 2024-06-01

Check for anomalies""",
            "response": json.dumps({
                "document_number": "SAP-999004",
                "vendor_name": "Office Supply Co",
                "amount": "$1,250.00",
                "gl_account": "5000 - Office Supplies",
                "transaction_type": "Invoice",
                "date": "2024-06-01",
                "anomaly_flag": "None",
                "audit_summary": "Invoice from Office Supply Co totaling $1,250.00. No anomalies detected."
            }, indent=2)
        }
    ]
    
    return explicit_examples


def prepare_enhanced_training_dataset():
    """
    Combine all improvements: more samples, explicit examples, and better distribution.
    """
    print("Generating base training data (150 samples)...")
    train_data = generate_sap_training_data(n_samples=150)
    
    print("Adding explicit anomaly examples...")
    explicit_examples = add_explicit_anomaly_examples()
    train_data.extend(explicit_examples)
    
    print(f"\nTotal training examples: {len(train_data)}")
    
    # Calculate anomaly statistics
    anomaly_count = sum(1 for item in train_data 
                       if '"anomaly_flag": "None"' not in item['response'])
    print(f"Examples with anomalies: {anomaly_count} ({anomaly_count/len(train_data)*100:.1f}%)")
    
    return train_data


def train_model_with_enhanced_config(train_data: List[Dict[str, str]]):
    """
    Training configuration with improved hyperparameters.
    """
    from transformers import TrainingArguments
    
    training_args = TrainingArguments(
        output_dir="./sap-anomaly-detector",
        num_train_epochs=5,  # Increased from 3 to 5 for better learning
        per_device_train_batch_size=4,
        warmup_steps=50,
        logging_steps=10,
        save_steps=100,
        eval_strategy="steps",
        eval_steps=50,
        learning_rate=2e-5,
        weight_decay=0.01,
        fp16=True,  # Mixed precision training if GPU available
        report_to="none"
    )
    
    print("\nTraining Configuration:")
    print(f"  Epochs: {training_args.num_train_epochs}")
    print(f"  Batch Size: {training_args.per_device_train_batch_size}")
    print(f"  Learning Rate: {training_args.learning_rate}")
    
    return training_args


# Example usage
if __name__ == "__main__":
    # Prepare enhanced dataset
    enhanced_dataset = prepare_enhanced_training_dataset()
    
    # Save to file
    output_file = "sap_training_enhanced.json"
    with open(output_file, 'w') as f:
        json.dump(enhanced_dataset, f, indent=2)
    
    print(f"\n✓ Enhanced training data saved to {output_file}")
    
    # Display sample
    print("\n--- Sample Training Example ---")
    sample = random.choice([ex for ex in enhanced_dataset 
                           if '"anomaly_flag": "HIGH_VALUE' in ex['response']])
    print(f"\nInstruction:\n{sample['instruction']}")
    print(f"\nResponse:\n{sample['response']}")
    
    # Get training config
    training_config = train_model_with_enhanced_config(enhanced_dataset)
    print("\n✓ Training configuration ready")
    print("\nNext steps:")
    print("1. Load your base model (e.g., distilbert, t5-small)")
    print("2. Apply the training_config")
    print("3. Train with the enhanced dataset")
    print("4. Evaluate on test set with varied anomaly types")