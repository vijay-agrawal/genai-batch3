"""
SAP Financial Document - Test Data Generator
Generates synthetic test cases and saves to JSON file

Run this script first to create test_data.json
"""

import json
import random
from typing import List, Dict

def generate_sap_test_cases(n_cases: int = 10) -> List[Dict]:
    """
    Generate diverse SAP financial document test cases
    Includes normal transactions and anomaly scenarios
    """
    
    vendors = [
        "Accenture Services", "Microsoft Corporation", "SAP SE", 
        "Deloitte Consulting", "AWS Inc", "Oracle Systems",
        "IBM Global Services", "Capgemini Technology", "TCS Limited",
        "Infosys Technologies", "PwC Advisory", "KPMG Consulting",
        "Ernst & Young", "Cisco Systems", "Adobe Inc"
    ]
    
    gl_accounts = {
        "6100": "Professional Services",
        "6200": "Software Licenses",
        "6300": "IT Infrastructure",
        "6400": "Travel & Entertainment",
        "6500": "Marketing & Advertising",
        "5100": "Office Supplies",
        "5200": "Utilities",
        "7100": "Training & Development"
    }
    
    transaction_types = ["Invoice", "Credit Memo", "Debit Memo", "Payment"]
    
    test_cases = []
    
    # Generate normal transactions (60%)
    for i in range(int(n_cases * 0.6)):
        vendor = random.choice(vendors)
        gl_code = random.choice(list(gl_accounts.keys()))
        gl_desc = gl_accounts[gl_code]
        amount = round(random.uniform(1000, 35000), 2)  # Normal range
        doc_num = f"SAP-{random.randint(100000, 999999)}"
        trans_type = random.choice(["Invoice", "Payment"])
        
        document = f"""SAP Document Number: {doc_num}
Transaction Type: {trans_type}
Vendor: {vendor}
Amount: ${amount:,.2f}
GL Account: {gl_code}
Posting Date: 2024-{random.randint(1,12):02d}-{random.randint(1,28):02d}
Description: {gl_desc} expenses for Q{random.randint(1,4)} 2024"""
        
        test_cases.append({
            "test_name": f"Normal_{trans_type}_{i+1}",
            "document": document,
            "expected_anomaly": "None",
            "scenario_type": "normal"
        })
    
    # Generate HIGH_VALUE transactions (20%)
    for i in range(int(n_cases * 0.2)):
        vendor = random.choice(vendors)
        gl_code = random.choice(list(gl_accounts.keys()))
        gl_desc = gl_accounts[gl_code]
        amount = round(random.uniform(40000, 80000), 2)  # High value
        doc_num = f"SAP-{random.randint(100000, 999999)}"
        trans_type = random.choice(["Invoice", "Payment"])
        
        document = f"""SAP Document Number: {doc_num}
Transaction Type: {trans_type}
Vendor: {vendor}
Amount: ${amount:,.2f}
GL Account: {gl_code}
Posting Date: 2024-{random.randint(1,12):02d}-{random.randint(1,28):02d}
Description: {gl_desc} expenses for Q{random.randint(1,4)} 2024"""
        
        test_cases.append({
            "test_name": f"HighValue_{trans_type}_{i+1}",
            "document": document,
            "expected_anomaly": "HIGH_VALUE - Requires additional approval",
            "scenario_type": "high_value"
        })
    
    # Generate LARGE_CREDIT transactions (20%)
    for i in range(int(n_cases * 0.2)):
        vendor = random.choice(vendors)
        gl_code = random.choice(list(gl_accounts.keys()))
        gl_desc = gl_accounts[gl_code]
        amount = round(random.uniform(10000, 25000), 2)  # Large credit
        doc_num = f"SAP-{random.randint(100000, 999999)}"
        trans_type = "Credit Memo"
        
        document = f"""SAP Document Number: {doc_num}
Transaction Type: {trans_type}
Vendor: {vendor}
Amount: ${amount:,.2f}
GL Account: {gl_code}
Posting Date: 2024-{random.randint(1,12):02d}-{random.randint(1,28):02d}
Description: {gl_desc} expenses for Q{random.randint(1,4)} 2024"""
        
        test_cases.append({
            "test_name": f"LargeCredit_{i+1}",
            "document": document,
            "expected_anomaly": "LARGE_CREDIT - Review vendor relationship",
            "scenario_type": "large_credit"
        })
    
    # Shuffle test cases
    random.shuffle(test_cases)
    
    return test_cases


def save_test_data(test_cases: List[Dict], filename: str = "sap_test_data.json"):
    """Save test cases to JSON file"""
    with open(filename, 'w') as f:
        json.dump(test_cases, f, indent=2)
    print(f"✓ Saved {len(test_cases)} test cases to {filename}")


def generate_curated_test_suite() -> List[Dict]:
    """
    Generate a curated test suite with specific edge cases
    for comprehensive evaluation
    """
    
    curated_cases = [
        {
            "test_name": "Standard_Invoice_LowValue",
            "document": """SAP Document Number: SAP-100001
Transaction Type: Invoice
Vendor: Deloitte Consulting
Amount: $5,250.00
GL Account: 6100
Posting Date: 2024-03-15
Description: Professional Services expenses for Q1 2024""",
            "expected_anomaly": "None",
            "scenario_type": "normal"
        },
        {
            "test_name": "High_Value_Software_License",
            "document": """SAP Document Number: SAP-100002
Transaction Type: Invoice
Vendor: Microsoft Corporation
Amount: $48,000.00
GL Account: 6200
Posting Date: 2024-06-20
Description: Software Licenses expenses for Q2 2024""",
            "expected_anomaly": "HIGH_VALUE - Requires additional approval",
            "scenario_type": "high_value"
        },
        {
            "test_name": "Large_Credit_AWS",
            "document": """SAP Document Number: SAP-100003
Transaction Type: Credit Memo
Vendor: AWS Inc
Amount: $15,000.00
GL Account: 6300
Posting Date: 2024-07-10
Description: IT Infrastructure expenses for Q3 2024""",
            "expected_anomaly": "LARGE_CREDIT - Review vendor relationship",
            "scenario_type": "large_credit"
        },
        {
            "test_name": "Extreme_High_Value",
            "document": """SAP Document Number: SAP-100004
Transaction Type: Invoice
Vendor: SAP SE
Amount: $95,000.00
GL Account: 6200
Posting Date: 2024-09-01
Description: Software Licenses expenses for Q3 2024""",
            "expected_anomaly": "HIGH_VALUE - Requires additional approval",
            "scenario_type": "high_value"
        },
        {
            "test_name": "Normal_Credit_Small",
            "document": """SAP Document Number: SAP-100005
Transaction Type: Credit Memo
Vendor: Oracle Systems
Amount: $3,500.00
GL Account: 6200
Posting Date: 2024-10-15
Description: Software Licenses expenses for Q4 2024""",
            "expected_anomaly": "None",
            "scenario_type": "normal"
        },
        {
            "test_name": "Borderline_High_Value",
            "document": """SAP Document Number: SAP-100006
Transaction Type: Invoice
Vendor: IBM Global Services
Amount: $40,500.00
GL Account: 6100
Posting Date: 2024-11-20
Description: Professional Services expenses for Q4 2024""",
            "expected_anomaly": "HIGH_VALUE - Requires additional approval",
            "scenario_type": "high_value"
        },
        {
            "test_name": "Borderline_Large_Credit",
            "document": """SAP Document Number: SAP-100007
Transaction Type: Credit Memo
Vendor: Cisco Systems
Amount: $10,100.00
GL Account: 6300
Posting Date: 2024-12-01
Description: IT Infrastructure expenses for Q4 2024""",
            "expected_anomaly": "LARGE_CREDIT - Review vendor relationship",
            "scenario_type": "large_credit"
        },
        {
            "test_name": "Travel_Expense_Normal",
            "document": """SAP Document Number: SAP-100008
Transaction Type: Invoice
Vendor: Accenture Services
Amount: $8,750.00
GL Account: 6400
Posting Date: 2024-05-12
Description: Travel & Entertainment expenses for Q2 2024""",
            "expected_anomaly": "None",
            "scenario_type": "normal"
        },
        {
            "test_name": "Marketing_High_Value",
            "document": """SAP Document Number: SAP-100009
Transaction Type: Invoice
Vendor: Adobe Inc
Amount: $52,000.00
GL Account: 6500
Posting Date: 2024-08-30
Description: Marketing & Advertising expenses for Q3 2024""",
            "expected_anomaly": "HIGH_VALUE - Requires additional approval",
            "scenario_type": "high_value"
        },
        {
            "test_name": "Training_Normal",
            "document": """SAP Document Number: SAP-100010
Transaction Type: Invoice
Vendor: Capgemini Technology
Amount: $12,300.00
GL Account: 7100
Posting Date: 2024-04-18
Description: Training & Development expenses for Q2 2024""",
            "expected_anomaly": "None",
            "scenario_type": "normal"
        }
    ]
    
    return curated_cases


if __name__ == "__main__":
    print("="*80)
    print("SAP Financial Document - Test Data Generator")
    print("="*80)
    
    # Generate curated test suite (recommended for demo)
    print("\n1. Generating curated test suite...")
    curated_tests = generate_curated_test_suite()
    save_test_data(curated_tests, "sap_test_data_curated.json")
    
    # Generate random test suite (for larger scale testing)
    print("\n2. Generating random test suite...")
    random_tests = generate_sap_test_cases(n_cases=20)
    save_test_data(random_tests, "sap_test_data_random.json")
    
    # Generate combined test suite
    print("\n3. Generating combined test suite...")
    combined_tests = curated_tests + random_tests
    save_test_data(combined_tests, "sap_test_data_full.json")
    
    print("\n" + "="*80)
    print("Test Data Generation Complete!")
    print("="*80)
    print("\nFiles created:")
    print("  • sap_test_data_curated.json  - 10 hand-crafted edge cases")
    print("  • sap_test_data_random.json   - 20 randomly generated cases")
    print("  • sap_test_data_full.json     - 30 combined test cases")
    print("\nTest case distribution:")
    
    for test_file in ["curated", "random", "full"]:
        filename = f"sap_test_data_{test_file}.json"
        with open(filename, 'r') as f:
            data = json.load(f)
        
        normal = sum(1 for case in data if case['scenario_type'] == 'normal')
        high_value = sum(1 for case in data if case['scenario_type'] == 'high_value')
        large_credit = sum(1 for case in data if case['scenario_type'] == 'large_credit')
        
        print(f"\n  {test_file.upper()}:")
        print(f"    - Normal: {normal}")
        print(f"    - High Value: {high_value}")
        print(f"    - Large Credit: {large_credit}")
        print(f"    - Total: {len(data)}")
    
    print("\n✓ Ready to use in main training script!")