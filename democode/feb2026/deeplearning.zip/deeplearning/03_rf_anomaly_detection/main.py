"""
RF (Radio Frequency) Anomaly Detection Demo
=============================================
This script demonstrates a two-model deep learning pipeline for detecting
anomalies in cellular network RSRP (Reference Signal Received Power) maps:

  1. CLASSIFICATION  (ResNet-18) -- "Is there an anomaly, and what type?"
     Classifies each RSRP heatmap into one of three categories:
       - Normal (label 0): healthy signal propagation
       - Jammer (label 1): localized circular signal blackout
       - Misalignment (label 2): linear dead-zone stripe from antenna mis-pointing

  2. SEGMENTATION   (U-Net)     -- "Where exactly is the anomaly?"
     Produces a pixel-level mask highlighting the affected region.

NOTE: Both models use RANDOM (untrained) weights here. This is a structural
demo showing how the pipeline is wired, not a trained production system.
Real deployment would require training on labelled RSRP data.
"""

import torch
from torch.utils.data import DataLoader
from data_gen import RFAnomalyDataset
from models import RFClassifier, UNet
import matplotlib.pyplot as plt

def run_demo():
    # -------------------------------------------------------------------------
    # STEP 1: Generate synthetic RSRP heatmaps
    # -------------------------------------------------------------------------
    # RFAnomalyDataset creates 128x128 RSRP maps using the log-distance path
    # loss model: RSRP = P_tx - 10*n*log10(d), with added shadow fading.
    # Each sample is randomly assigned as normal, jammer, or misalignment.
    # Returns: (image [1,128,128], label [int], mask [1,128,128])
    dataset = RFAnomalyDataset(num_samples=10)

    # DataLoader batches samples together for efficient processing.
    # batch_size=2 means we process 2 RSRP maps at a time.
    loader = DataLoader(dataset, batch_size=2)

    # Grab the first batch: 2 images, their labels, and ground-truth masks
    images, labels, masks = next(iter(loader))

    # -------------------------------------------------------------------------
    # STEP 2: Initialize models (with random weights -- untrained)
    # -------------------------------------------------------------------------
    # RFClassifier: A ResNet-18 backbone modified for single-channel (grayscale)
    # input. Outputs 3 logits (one per class: Normal, Jammer, Misalignment).
    classifier = RFClassifier()

    # UNet: An encoder-decoder segmentation network that takes a 1-channel
    # RSRP map and outputs a 1-channel pixel-wise anomaly mask (0.0 to 1.0).
    # Skip connections between encoder and decoder preserve spatial detail.
    segmenter = UNet()

    # -------------------------------------------------------------------------
    # STEP 3: Run inference (forward pass only, no gradient computation)
    # -------------------------------------------------------------------------
    print("\n--- Starting Inference ---")
    with torch.no_grad():  # Disables gradient tracking -- saves memory, faster
        # Classification: image -> 3 raw scores (logits)
        cls_output = classifier(images)

        # Segmentation: image -> pixel-level anomaly probability map
        seg_output = segmenter(images)

        # --- CLASSIFICATION PIPELINE ---

        # 3a. Raw logits: unnormalized scores, one per class.
        #     Higher value = model is more confident about that class.
        #     These can be negative and don't sum to 1.
        print("\n1. Raw Classifier Scores (Logits):")
        print(cls_output)

        # 3b. Softmax converts logits to probabilities (0-1, sum to 1).
        #     Formula: P(class_i) = exp(logit_i) / sum(exp(all logits))
        #     This makes the scores interpretable as confidence percentages.
        probabilities = torch.softmax(cls_output, dim=1)
        print("\n2. Probabilities (Confidence):")
        print(probabilities)

        # 3c. Argmax picks the class index with the highest probability.
        #     This is the model's final prediction for each image.
        predictions = torch.argmax(probabilities, dim=1)
        class_names = ['Normal', 'Jammer', 'Misalignment']

        for i, pred in enumerate(predictions):
            print(f"   Result for Map {i}: {class_names[pred]}")

        # --- INTERPRETING THE OUTPUT ---
        #
        # Example output from an UNTRAINED model:
        #
        #   Logits:        [[ 0.8519, -0.1742,  0.9737],
        #                   [ 0.6490, -0.1072,  0.9981]]
        #
        #   Probabilities: [[0.4020,  0.1441,  0.4540],
        #                   [0.3463,  0.1626,  0.4911]]
        #
        # Reading row 0 (Map 0):
        #   Logits:  Normal=0.8519, Jammer=-0.1742, Misalignment=0.9737
        #            Misalignment has the highest raw score (0.9737).
        #
        #   After softmax:  Normal=40.2%, Jammer=14.4%, Misalignment=45.4%
        #            The probabilities sum to 1.0 (100%).
        #            Misalignment wins with 45.4%, but Normal is close at 40.2%.
        #
        #   Prediction: Misalignment (argmax picks index 2, the highest probability).
        #
        # IMPORTANT: These predictions are essentially RANDOM because the model
        # weights were never trained. The near-uniform probability split (40%/14%/45%)
        # confirms the model is guessing -- it has no learned knowledge of what
        # jammers or misalignments look like.
        #
        # With a TRAINED model, you would expect confident predictions like:
        #   Normal case:       [0.97, 0.02, 0.01]  (97% confident it's normal)
        #   Jammer case:       [0.01, 0.96, 0.03]  (96% confident it's a jammer)
        #   Misalignment case: [0.02, 0.01, 0.97]  (97% confident it's misalignment)

    # -------------------------------------------------------------------------
    # STEP 4: Visualize one sample -- input RSRP map vs. ground-truth mask
    # -------------------------------------------------------------------------
    # Left panel:  The synthetic RSRP heatmap (input to both models).
    #              'viridis' colormap: yellow=strong signal, purple=weak signal.
    #              A jammer would appear as a dark circular patch;
    #              a misalignment as a dark linear stripe.
    #
    # Right panel: The ground-truth binary mask (1=anomaly region, 0=normal).
    #              This is what the U-Net segmenter is trying to predict.
    #              For "normal" samples, this mask is all zeros (blank).
    print("\n3. Opening Image Window... (Close it to finish the script)")

    fig, ax = plt.subplots(1, 2, figsize=(10, 5))
    ax[0].imshow(images[0, 0], cmap='viridis')
    ax[0].set_title(f"Input: {class_names[labels[0]]}")

    ax[1].imshow(masks[0, 0], cmap='gray')
    ax[1].set_title("Ground Truth Mask")

    plt.show()

    print("\n--- Script Finished ---")

if __name__ == "__main__":
    run_demo()