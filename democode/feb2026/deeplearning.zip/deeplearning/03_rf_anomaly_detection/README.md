# RF Anomaly Detection Demo

## What This Demo Does

This project demonstrates a **deep learning pipeline for detecting anomalies in cellular network RF (Radio Frequency) signal maps**. It works with **RSRP (Reference Signal Received Power)** heatmaps -- 2D grids representing signal strength across a geographic area around a cell tower.

The demo detects two types of RF anomalies:

| Anomaly | Visual Pattern | Real-World Cause |
|---------|---------------|-----------------|
| **Jammer** | Circular dark patch (localized signal drop) | An active RF jammer creating a signal blackout zone |
| **Misalignment** | Linear stripe of weak signal | Antenna physically mis-pointed, creating a dead-zone corridor |

## How It Works

The pipeline uses **two complementary deep learning models**:

### 1. Classification (ResNet-18) -- "What type of anomaly?"
- Takes a 128x128 single-channel RSRP heatmap as input
- Outputs probabilities for 3 classes: **Normal**, **Jammer**, **Misalignment**
- Built on ResNet-18 with the first conv layer modified for grayscale (1-channel) input

#### What is ResNet?

ResNet (Residual Network) is a CNN architecture introduced by Microsoft Research in 2015. Its key innovation is **skip connections** (also called residual connections) that allow the input of a layer to bypass one or more layers and be added directly to the output:

```
Input ---> [Conv -> ReLU -> Conv] ---> (+) ---> Output
  |                                     ^
  +----------(skip connection)----------+
```

**Why this matters:** Without skip connections, very deep networks (20+ layers) suffer from the **vanishing gradient problem** -- gradients become extremely small during backpropagation, so early layers barely learn. Skip connections let gradients flow directly through the shortcut path, making it possible to train networks with 50, 101, or even 152 layers effectively.

**ResNet-18** (used here) has 18 layers organized into 4 groups of residual blocks. It's the smallest ResNet variant -- a good fit for our 128x128 single-channel input where the classification task (3 classes) is relatively simple. In this demo, the first convolutional layer is modified from 3-channel (RGB) to 1-channel (grayscale RSRP).

### 2. Segmentation (U-Net) -- "Where is the anomaly?"
- Takes the same RSRP heatmap as input
- Outputs a pixel-level mask highlighting the exact affected region
- Encoder-decoder architecture with skip connections to preserve spatial detail

#### What is U-Net?

U-Net is a segmentation architecture originally designed for biomedical image segmentation (2015, University of Freiburg). It gets its name from its **U-shaped architecture**:

```
Input (128x128)                                    Output Mask (128x128)
     |                                                   ^
     v                                                   |
 [Encoder Block 1] --- skip connection ----------> [Decoder Block 1]
     |  (32 filters)                                (32 filters)  ^
     v  MaxPool (64x64)                       ConvTranspose (128x128)
 [Encoder Block 2] --- skip connection ----------> [Decoder Block 2]
     |  (64 filters)                                (64 filters)  ^
     v  MaxPool (32x32)                        ConvTranspose (64x64)
 [          Bottleneck (128 filters, 32x32)           ]
```

**How it works:**
- **Encoder (left side):** Progressively downsamples the image using convolutions + max pooling, capturing *what* features exist (edges, blobs, patterns) at increasing levels of abstraction
- **Bottleneck (bottom):** The compressed representation at the lowest resolution
- **Decoder (right side):** Progressively upsamples back to original resolution using transposed convolutions, recovering *where* things are spatially
- **Skip connections (horizontal):** Concatenate encoder features with decoder features at each level. This is critical -- the encoder knows *what* was detected, the decoder knows *where* to place it, and the skip connections combine both

**Why U-Net for this task:** We need pixel-level precision to pinpoint *exactly which cells* in the RSRP map are affected by a jammer or misalignment. A classifier can only say "there's a jammer somewhere." U-Net says "these specific pixels are the jammer region."

> **Note:** Both models use **random (untrained) weights** in this demo. This is a structural/pipeline demo, not a trained system. Real deployment would require training on labelled RSRP data.

## Synthetic Data Generation

Since real RSRP data is proprietary, the demo generates synthetic heatmaps using physics-based models:

1. **Base RSRP map** -- Log-distance path loss: `RSRP = P_tx - 10 * n * log10(d)` with Gaussian shadow fading
2. **Jammer injection** -- Circular region with steep signal drop (25 dB)
3. **Misalignment injection** -- Linear stripe with signal drop (20 dB)

## Project Structure

```
03_rf_anomaly_detection/
    main.py             -- Entry point: runs the full inference demo
    data_gen.py         -- PyTorch Dataset that generates synthetic RSRP maps
    models.py           -- Model definitions (RFClassifier and UNet)
    view_rf_data.py     -- Standalone visualization script (NOT used by the demo)
```

## How to Run

```bash
cd deeplearning/03_rf_anomaly_detection
python main.py
```

## Dependencies

- PyTorch
- torchvision (for ResNet-18 backbone)
- NumPy
- SciPy (for Gaussian filtering in data generation)
- Matplotlib (for visualization)
