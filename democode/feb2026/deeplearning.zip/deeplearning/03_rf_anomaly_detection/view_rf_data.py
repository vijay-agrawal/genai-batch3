import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter

def create_base_rsrp(grid_size=128, bs_pos=(64, 64), p_tx=30, n=3.5):
    """
    Generates a normal RSRP map using Log-Distance Path Loss model.
    RSRP = P_tx - 10*n*log10(d)
    """
    x, y = np.indices((grid_size, grid_size))
    dist = np.sqrt((x - bs_pos[0])**2 + (y - bs_pos[1])**2)
    dist[dist == 0] = 1  # Avoid log(0)
    
    rsrp = p_tx - 10 * n * np.log10(dist)
    # Add shadow fading (log-normal)
    shadowing = np.random.normal(0, 2, (grid_size, grid_size))
    rsrp += gaussian_filter(shadowing, sigma=2)
    
    return rsrp

def inject_jammer(rsrp, center=(30, 30), radius=15, drop_db=25):
    """
    Circular low-RSRP patch with strong gradient boundary.
    Simulates an active jammer causing a localized signal 'blackout'.
    """
    grid_size = rsrp.shape[0]
    x, y = np.indices((grid_size, grid_size))
    dist = np.sqrt((x - center[0])**2 + (y - center[1])**2)
    
    # Create a mask with a sharp gradient at the edge
    mask = 1 / (1 + np.exp(2 * (dist - radius))) # Sigmoid for smooth but steep transition
    jammed_rsrp = rsrp - (mask * drop_db)
    return jammed_rsrp

def inject_misalignment(rsrp, angle_deg=45, width=8, drop_db=20):
    """
    Linear stripe pattern (Azimuth misalignment / Sector gap).
    Simulates a 'dead zone' strip caused by antenna mis-pointing.
    """
    grid_size = rsrp.shape[0]
    x, y = np.indices((grid_size, grid_size))
    
    # Rotate coordinates to find the stripe
    angle_rad = np.radians(angle_deg)
    dist_from_line = np.abs((x - grid_size//2) * np.sin(angle_rad) - (y - grid_size//2) * np.cos(angle_rad))
    
    mask = np.where(dist_from_line < width, 1.0, 0.0)
    # Smooth the edges of the stripe
    mask = gaussian_filter(mask, sigma=1)
    
    misaligned_rsrp = rsrp - (mask * drop_db)
    return misaligned_rsrp

def generate_dataset_sample(anomaly_type='none'):
    grid_size = 128
    data = create_base_rsrp(grid_size)
    
    if anomaly_type == 'jammer':
        center = np.random.randint(20, 100, 2)
        data = inject_jammer(data, center=center)
    elif anomaly_type == 'misalignment':
        angle = np.random.randint(0, 180)
        data = inject_misalignment(data, angle_deg=angle)
        
    # Normalize for CNN (0 to 1 range)
    data_min, data_max = data.min(), data.max()
    data_norm = (data - data_min) / (data_max - data_min)
    return data_norm

# --- Visualization ---
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
titles = ['Normal Map', 'Jammer (Circular)', 'Misalignment (Linear)']
types = ['none', 'jammer', 'misalignment']

for ax, t, ty in zip(axes, titles, types):
    img = generate_dataset_sample(ty)
    im = ax.imshow(img, cmap='viridis')
    ax.set_title(t)
    plt.colorbar(im, ax=ax, label='Normalized RSRP')

plt.tight_layout()
plt.show()