import torch
import numpy as np
from torch.utils.data import Dataset
from scipy.ndimage import gaussian_filter

class RFAnomalyDataset(Dataset):
    def __init__(self, num_samples=100, grid_size=128):
        self.num_samples = num_samples
        self.grid_size = grid_size

    def __len__(self):
        return self.num_samples

    def create_base_rsrp(self):
        x, y = np.indices((self.grid_size, self.grid_size))
        dist = np.sqrt((x - 64)**2 + (y - 64)**2) + 1
        rsrp = 30 - 35 * np.log10(dist)
        shadowing = np.random.normal(0, 2, (self.grid_size, self.grid_size))
        return rsrp + gaussian_filter(shadowing, sigma=2)

    def __getitem__(self, idx):
        img = self.create_base_rsrp()
        mask = np.zeros((self.grid_size, self.grid_size))
        label = 0 
        
        choice = np.random.choice(['none', 'jammer', 'misalignment'])
        if choice == 'jammer':
            center = np.random.randint(20, 100, 2)
            dist = np.sqrt((np.indices(img.shape)[0]-center[0])**2 + (np.indices(img.shape)[1]-center[1])**2)
            mask = np.where(dist < 15, 1.0, 0.0)
            img -= (mask * 25)
            label = 1
        elif choice == 'misalignment':
            angle = np.radians(np.random.randint(0, 180))
            x, y = np.indices(img.shape)
            dist_line = np.abs((x-64)*np.sin(angle) - (y-64)*np.cos(angle))
            mask = np.where(dist_line < 6, 1.0, 0.0)
            img -= (mask * 20)
            label = 2
            
        img = (img - img.min()) / (img.max() - img.min())
        return (torch.tensor(img, dtype=torch.float32).unsqueeze(0), 
                torch.tensor(label, dtype=torch.long), 
                torch.tensor(mask, dtype=torch.float32).unsqueeze(0))