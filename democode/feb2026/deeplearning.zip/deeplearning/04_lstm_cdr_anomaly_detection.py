"""
================================================================================
USE-CASE 1: Call-Detail-Record (CDR) Sequence Anomaly Detection
================================================================================

BUSINESS CONTEXT
    Telecom operators generate billions of CDRs daily. Hidden within these
    streams are fraudulent patterns -- SIM-boxing (routing international calls
    through local SIMs), cloned SIMs, and bot-generated traffic. Traditional
    rule-based systems (e.g., "flag if > 100 calls/day") are easy for fraudsters
    to evade by staying just below thresholds.

    GOAL: Detect fraudulent or abnormal CDR *sequences* by learning what normal
    subscriber behaviour looks like over TIME, then flagging sequences whose
    temporal pattern deviates -- even if individual metrics look fine.

WHY DEEP LEARNING? WHY LSTM?
    CDR data is inherently SEQUENTIAL. A subscriber's behaviour unfolds over
    time -- calls happen in bursts (morning commute, lunch, evening), with
    natural gaps overnight and on weekends. This temporal structure is the KEY
    signal:

    Normal subscriber:
        Mon-Fri : call bursts at 8-9 AM, 12-1 PM, 6-8 PM
        Weekends: minimal activity, occasional long calls
        Duration: varies naturally (30s voicemail, 5min chat, 20min catch-up)
        Gaps    : long overnight gaps (11 PM to 7 AM)

    Fraudulent SIM (SIM-box / bot):
        24x7    : uniform call rate, no day/night pattern
        Duration: suspiciously identical (e.g., always 60s or always 180s)
        Gaps    : machine-like regularity, identical inter-call intervals
        Weekends: same activity as weekdays (no human rest pattern)

    WHY CAN'T TRADITIONAL ML CATCH THIS?
        A Random Forest or Logistic Regression sees each HOUR independently.
        It might flag "50 calls in an hour" but CANNOT see that those 50 calls
        were spread with EXACTLY 72-second gaps (bot pattern). It cannot learn
        that "morning burst followed by evening burst with quiet afternoon" is
        normal ACROSS a 24-hour window.

    WHY LSTM?
        LSTM (Long Short-Term Memory) networks maintain a MEMORY CELL that
        carries information across time steps. This lets the model learn:
        1. "After a morning burst, expect a quiet period" (temporal dependency)
        2. "Weekend patterns differ from weekday patterns" (long-range context)
        3. "This subscriber's gap pattern has been regular for 48 hours" (memory)

    WHY AUTOENCODER?
        We have NO labelled fraud data (fraud patterns evolve constantly).
        An autoencoder learns to COMPRESS and RECONSTRUCT normal sequences.
        Normal sequences -> low reconstruction error (model knows the pattern).
        Fraudulent sequences -> high reconstruction error (never seen this
        pattern during training).

        Anomaly Score = Reconstruction Error (MSE)

    HOW THE LSTM AUTOENCODER WORKS -- STEP BY STEP

        Given one training sample: a 24-hour CDR sequence with 6 features
        Shape: (24 time_steps, 6 features)

        ┌─────────────────────────────────────────────────────────────────┐
        │  ENCODER (Compresses the sequence into a fixed-size summary)   │
        ├─────────────────────────────────────────────────────────────────┤
        │                                                                 │
        │  1. Input at each time step t (t = 0,1,...,23):                │
        │     x_t = [num_calls, avg_duration, unique_dest,               │
        │            inter_call_gap, hour_of_day, is_weekend]            │
        │     This is a 6-dimensional vector for that hour.              │
        │                                                                 │
        │  2. The LSTM processes these 24 vectors ONE AT A TIME,         │
        │     left to right (hour 0 → hour 23). At each step:           │
        │                                                                 │
        │     ┌──────────────────────────────────────────────┐           │
        │     │ LSTM Cell at time t:                         │           │
        │     │                                              │           │
        │     │  • Forget gate: decides what to DISCARD      │           │
        │     │    from the previous memory. E.g., "the      │           │
        │     │    exact call count at hour 3 is no longer   │           │
        │     │    relevant by hour 20."                     │           │
        │     │                                              │           │
        │     │  • Input gate: decides what NEW info to      │           │
        │     │    STORE. E.g., "this hour had unusually     │           │
        │     │    high activity, remember that."            │           │
        │     │                                              │           │
        │     │  • Output gate: decides what to OUTPUT       │           │
        │     │    as the hidden state. E.g., "the running   │           │
        │     │    pattern so far looks like a normal        │           │
        │     │    morning burst."                           │           │
        │     │                                              │           │
        │     │  Inputs:  x_t (current hour's 6 features)   │           │
        │     │           h_{t-1} (previous hidden state)    │           │
        │     │           c_{t-1} (previous cell state)      │           │
        │     │                                              │           │
        │     │  Outputs: h_t (updated hidden state, 64-dim) │           │
        │     │           c_t (updated cell state, 64-dim)   │           │
        │     └──────────────────────────────────────────────┘           │
        │                                                                 │
        │  3. With n_layers=2, the output h_t of layer-1's LSTM feeds   │
        │     into layer-2's LSTM as input. This stacking lets layer-1  │
        │     capture LOW-LEVEL patterns (e.g., "calls are increasing") │
        │     and layer-2 capture HIGHER-LEVEL patterns (e.g., "this    │
        │     looks like a morning-to-afternoon transition").            │
        │                                                                 │
        │  4. After processing ALL 24 hours, we take the FINAL hidden   │
        │     state h_23 from the LAST LSTM layer.                      │
        │     Shape: (64,) -- this is the LATENT VECTOR (z).            │
        │                                                                 │
        │     This 64-dim vector is the COMPRESSED SUMMARY of the       │
        │     entire 24-hour sequence. It must encode everything the    │
        │     decoder needs to reconstruct the original 24x6 = 144      │
        │     values. This bottleneck FORCES the model to learn the     │
        │     underlying pattern, not memorize individual values.       │
        │                                                                 │
        │     Compression ratio: 144 input values → 64 latent dims     │
        │     (2.25:1 compression)                                      │
        └─────────────────────────────────────────────────────────────────┘

        ┌─────────────────────────────────────────────────────────────────┐
        │  DECODER (Reconstructs the sequence from the summary)          │
        ├─────────────────────────────────────────────────────────────────┤
        │                                                                 │
        │  5. The latent vector z (64-dim) is REPEATED 24 times to      │
        │     create a (24, 64) input for the decoder LSTM.             │
        │     Each time step receives the SAME latent code as input.    │
        │                                                                 │
        │  6. The decoder LSTM processes these 24 copies sequentially.  │
        │     Even though the input is the same at each step, the       │
        │     LSTM's hidden state evolves, allowing it to generate      │
        │     DIFFERENT outputs at each time step:                      │
        │       - Step 0: decode "what hour 0 should look like"         │
        │       - Step 1: decode "what hour 1 should look like"         │
        │       - ...                                                    │
        │       - Step 23: decode "what hour 23 should look like"       │
        │                                                                 │
        │  7. At each time step, the decoder LSTM's hidden state (64d)  │
        │     passes through a LINEAR layer (64 → 6) to produce the    │
        │     reconstructed feature vector:                              │
        │     x̂_t = [num_calls, avg_duration, unique_dest,             │
        │            inter_call_gap, hour_of_day, is_weekend]            │
        │                                                                 │
        │  8. Final output shape: (24, 6) -- same as input.             │
        └─────────────────────────────────────────────────────────────────┘

        ┌─────────────────────────────────────────────────────────────────┐
        │  LOSS & TRAINING                                               │
        ├─────────────────────────────────────────────────────────────────┤
        │                                                                 │
        │  9. Loss = MSE(input, reconstruction)                          │
        │     = mean( (x_t - x̂_t)² ) averaged over all 24 steps and   │
        │       all 6 features.                                          │
        │                                                                 │
        │  10. Backpropagation through time (BPTT) computes gradients   │
        │      that flow BACKWARDS through the decoder, through the     │
        │      latent bottleneck, and through the encoder's 24 time     │
        │      steps. Adam optimizer updates all weights.               │
        │                                                                 │
        │  11. Training uses ONLY normal subscriber sequences. The      │
        │      model never sees fraud during training. Over epochs,     │
        │      it gets very good at compressing and reconstructing      │
        │      normal circadian patterns.                               │
        └─────────────────────────────────────────────────────────────────┘

        ┌─────────────────────────────────────────────────────────────────┐
        │  INFERENCE (Anomaly Detection)                                 │
        ├─────────────────────────────────────────────────────────────────┤
        │                                                                 │
        │  12. For a NEW unseen sequence, compute:                       │
        │      anomaly_score = MSE(input, reconstruction)                │
        │                                                                 │
        │      Normal sequence: model reconstructs it well → LOW MSE    │
        │      Fraud sequence:  model cannot reconstruct it → HIGH MSE  │
        │                                                                 │
        │  Example:                                                      │
        │    Normal input:  [0,0,0,0,0,0,0,3,4,2,1,0,2,1,0,0,0,4,5,3,1,0,0,0]  │
        │    Reconstruction:[0,0,0,0,0,0,1,3,3,2,1,0,2,1,0,0,0,4,4,3,1,0,0,0]  │
        │    → MSE = 0.25 (LOW -- model knows this circadian pattern)   │
        │                                                                 │
        │    SIM-box input: [10,11,10,10,11,10,10,11,10,10,11,10,...]    │
        │    Reconstruction:[ 0, 0, 0, 0, 0, 0, 1, 3, 3, 2, 1, 0,...]   │
        │    → MSE = 3.80 (HIGH -- model tries to output normal pattern) │
        │                                                                 │
        │  13. Threshold at 95th percentile of normal validation errors. │
        │      Anything above → flagged as anomalous.                    │
        └─────────────────────────────────────────────────────────────────┘

    TRAINING DATA SHOULD NOT BE CONTAMINATED WITH FRAUD
        If fraudulent sequences are included in training, the model will learn to reconstruct 
        them as well, leading to LOW reconstruction error for fraud -- the opposite of what we want. 
        This is a common pitfall in anomaly detection. 
        We must ensure that the training set consists ONLY of normal subscriber data.

    DROPOUT -- WHAT IT DOES AND WHY WE USE IT

        Dropout randomly ZEROES OUT a fraction of neuron outputs during
        training (e.g., dropout=0.2 means 20% of values set to 0 each batch).

        Where dropout is applied in our LSTM Autoencoder:
        - Between LSTM layers (NOT within a single layer's recurrence).
          With n_layers=2: the output of LSTM layer-1 is dropout-masked
          before feeding into LSTM layer-2. This prevents layer-2 from
          over-relying on specific features from layer-1.
        - Dropout is ONLY applied when n_layers > 1. A single-layer LSTM
          has no inter-layer connection to dropout, so PyTorch ignores it.
        - At inference time (model.eval()), dropout is DISABLED -- all
          neurons are active, and outputs are scaled accordingly.

        Why it matters for our use case:
        - Without dropout, the autoencoder might MEMORIZE specific normal
          sequences instead of learning the GENERAL circadian pattern.
        - With dropout, the model is forced to learn REDUNDANT, ROBUST
          representations -- multiple neurons encode "morning burst" so
          that even when some are dropped, the pattern is preserved.
        - This makes the model better at generalizing to new normal
          subscribers AND more sensitive to genuinely anomalous patterns.

        Typical values used in this demo:
          dropout=0.1  : light regularization (used with smaller models)
          dropout=0.2  : moderate (default -- good balance)
          dropout=0.3  : heavier (used with larger models to prevent overfit)

DEEP LEARNING APPROACH
    Architecture : LSTM Autoencoder (Encoder-Decoder)
    Input        : Sequences of hourly CDR feature vectors (24h windows)
    Training     : On NORMAL subscriber data only (unsupervised)
    Inference    : Reconstruction error = anomaly score
    Threshold    : Calibrated on validation set (percentile-based)

STEP-BY-STEP ROADMAP
    Step 1 : Generate realistic synthetic CDR data
    Step 2 : Exploratory Data Analysis (EDA)
    Step 3 : Sequence Preparation for LSTM
    Step 4 : Build & Train LSTM Autoencoder
    Step 5 : Evaluate & Detect Anomalies
    Step 6 : Hyperparameter Tuning
    Step 7 : Findings & Analysis
================================================================================
"""

# =============================================================================
# STEP 0 -- IMPORTS
# =============================================================================
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    classification_report, confusion_matrix, f1_score,
    precision_recall_curve, roc_auc_score, roc_curve
)
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

plt.style.use('seaborn-v0_8-whitegrid')
pd.set_option('display.max_columns', None)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"All imports successful. Using device: {device}")


# =============================================================================
# STEP 1 -- GENERATE SYNTHETIC CDR DATA
# =============================================================================
# We simulate 14 days of HOURLY aggregated CDR features for 200 subscribers.
#
# Each row = 1 hour for 1 subscriber, with features:
#   - num_calls          : number of calls made in that hour
#   - avg_call_duration  : average call length (seconds)
#   - num_unique_dest    : unique destination numbers called
#   - avg_inter_call_gap : avg seconds between consecutive calls
#   - hour_of_day        : 0-23 (cyclical)
#   - is_weekend         : 0 or 1
#
# Subscriber types:
#   - 180 NORMAL subscribers  (realistic human patterns)
#   -  10 SIM-BOX fraudsters  (uniform 24x7, identical durations)
#   -  10 CLONED SIM / bots   (burst patterns, machine-like regularity)
# =============================================================================
print("\n" + "=" * 60)
print("STEP 1: Generating synthetic CDR data...")
print("=" * 60)

np.random.seed(42)

n_days = 14
hours_per_day = 24
n_hours = n_days * hours_per_day  # 336 hours total

n_normal = 180
n_simbox = 10
n_cloned = 10
n_subscribers = n_normal + n_simbox + n_cloned

all_records = []


def generate_normal_subscriber(sub_id, n_hours):
    """
    Generate realistic human CDR patterns:
    - Morning burst (7-9 AM), lunch (12-1 PM), evening burst (6-9 PM)
    - Very few calls at night (11 PM - 6 AM)
    - Reduced activity on weekends
    - Natural variation in call durations
    """
    records = []
    for h in range(n_hours):
        hour_of_day = h % 24
        day_of_week = (h // 24) % 7  # 0=Mon, 6=Sun
        is_weekend = 1 if day_of_week >= 5 else 0

        # Base call rate by hour (human circadian pattern)
        if 7 <= hour_of_day <= 9:      # morning commute
            base_calls = np.random.poisson(3.5)
        elif 12 <= hour_of_day <= 13:   # lunch break
            base_calls = np.random.poisson(2.0)
        elif 17 <= hour_of_day <= 21:   # evening
            base_calls = np.random.poisson(4.0)
        elif 22 <= hour_of_day or hour_of_day <= 5:  # night
            base_calls = np.random.poisson(0.2)
        else:                           # work hours / afternoon
            base_calls = np.random.poisson(1.5)

        # Weekend reduction
        if is_weekend:
            base_calls = max(0, int(base_calls * 0.4))

        # Add personal variation
        base_calls = max(0, base_calls + np.random.choice([-1, 0, 0, 0, 1]))

        num_calls = base_calls
        num_unique_dest = min(num_calls, max(0, int(num_calls * 0.7 + np.random.normal(0, 1))))

        # Call duration: varies naturally (short voicemails to long chats)
        if num_calls > 0:
            avg_duration = np.random.lognormal(mean=4.5, sigma=0.8)  # ~90s median, wide spread
            avg_duration = np.clip(avg_duration, 10, 1800)
            avg_gap = np.random.exponential(scale=600)  # ~10 min avg gap, high variance
            avg_gap = np.clip(avg_gap, 30, 3600)
        else:
            avg_duration = 0.0
            avg_gap = 0.0

        records.append({
            'subscriber_id': sub_id,
            'hour_index': h,
            'hour_of_day': hour_of_day,
            'day_of_week': day_of_week,
            'is_weekend': is_weekend,
            'num_calls': num_calls,
            'avg_call_duration': round(avg_duration, 1),
            'num_unique_dest': num_unique_dest,
            'avg_inter_call_gap': round(avg_gap, 1),
            'label': 'normal'
        })
    return records


def generate_simbox_subscriber(sub_id, n_hours):
    """
    SIM-box fraud pattern:
    - Uniform call rate 24x7 (no day/night variation)
    - Identical or near-identical call durations (automated routing)
    - Regular inter-call gaps (machine-generated)
    - No weekend reduction
    """
    records = []
    # Fixed call rate and duration for this SIM-box
    fixed_rate = np.random.randint(8, 15)          # 8-15 calls per hour, constant
    fixed_duration = np.random.uniform(55, 65)     # ~60 seconds, very tight
    fixed_gap = 3600.0 / fixed_rate                # evenly spaced

    for h in range(n_hours):
        hour_of_day = h % 24
        day_of_week = (h // 24) % 7
        is_weekend = 1 if day_of_week >= 5 else 0

        # Slight noise but fundamentally uniform
        num_calls = max(1, fixed_rate + np.random.choice([-1, 0, 0, 1]))
        avg_duration = fixed_duration + np.random.normal(0, 2)
        avg_gap = fixed_gap + np.random.normal(0, 5)

        records.append({
            'subscriber_id': sub_id,
            'hour_index': h,
            'hour_of_day': hour_of_day,
            'day_of_week': day_of_week,
            'is_weekend': is_weekend,
            'num_calls': num_calls,
            'avg_call_duration': round(np.clip(avg_duration, 30, 120), 1),
            'num_unique_dest': max(1, num_calls - np.random.randint(0, 3)),
            'avg_inter_call_gap': round(np.clip(avg_gap, 20, 600), 1),
            'label': 'simbox'
        })
    return records


def generate_cloned_subscriber(sub_id, n_hours):
    """
    Cloned SIM / bot pattern:
    - Irregular high-volume bursts at odd hours (3-5 AM)
    - Very short calls (probing / testing)
    - Extremely regular inter-call gaps (scripted)
    - Activity on weekends same as weekdays
    """
    records = []
    for h in range(n_hours):
        hour_of_day = h % 24
        day_of_week = (h // 24) % 7
        is_weekend = 1 if day_of_week >= 5 else 0

        # Bots are active during off-peak (cheaper routes)
        if 1 <= hour_of_day <= 5:
            num_calls = np.random.poisson(12)  # heavy burst at night
        elif 10 <= hour_of_day <= 14:
            num_calls = np.random.poisson(8)   # moderate midday burst
        else:
            num_calls = np.random.poisson(3)   # lower but still present

        # Very short, probing calls
        avg_duration = np.random.uniform(5, 20) if num_calls > 0 else 0.0

        # Machine-like gap regularity
        avg_gap = 120 + np.random.normal(0, 3) if num_calls > 0 else 0.0

        records.append({
            'subscriber_id': sub_id,
            'hour_index': h,
            'hour_of_day': hour_of_day,
            'day_of_week': day_of_week,
            'is_weekend': is_weekend,
            'num_calls': max(0, num_calls),
            'avg_call_duration': round(max(0, avg_duration), 1),
            'num_unique_dest': max(0, min(num_calls, np.random.randint(1, num_calls + 1))) if num_calls > 0 else 0,
            'avg_inter_call_gap': round(max(0, avg_gap), 1),
            'label': 'cloned'
        })
    return records


# Generate all subscribers
for i in range(n_normal):
    all_records.extend(generate_normal_subscriber(f'NORM_{i:04d}', n_hours))

for i in range(n_simbox):
    all_records.extend(generate_simbox_subscriber(f'SBOX_{i:04d}', n_hours))

for i in range(n_cloned):
    all_records.extend(generate_cloned_subscriber(f'CLON_{i:04d}', n_hours))

df = pd.DataFrame(all_records)

# Add binary anomaly label for evaluation
df['is_anomaly'] = (df['label'] != 'normal').astype(int)

# Save to CSV
data_folder = Path(__file__).parent / 'data'
data_folder.mkdir(exist_ok=True)
data_file = data_folder / 'cdr_data.csv'
df.to_csv(data_file, index=False)

print(f"Dataset shape: {df.shape}")
print(f"Subscribers: {df['subscriber_id'].nunique()} "
      f"(Normal: {n_normal}, SIM-box: {n_simbox}, Cloned: {n_cloned})")
print(f"Hours per subscriber: {n_hours}")
print(f"\nLabel distribution:")
print(df['label'].value_counts())
print(f"\nSample rows:")
print(df.head(10))


# =============================================================================
# STEP 2 -- EXPLORATORY DATA ANALYSIS (EDA)
# =============================================================================
# EDA reveals WHY sequential models are needed:
# - Individual hourly stats OVERLAP between normal and fraud
# - But the TEMPORAL PATTERN is strikingly different
# =============================================================================
print("\n" + "=" * 60)
print("STEP 2: Exploratory Data Analysis")
print("=" * 60)

# 2.1  Basic statistics by label
print("\nDESCRIPTIVE STATISTICS BY LABEL")
print(df.groupby('label')[['num_calls', 'avg_call_duration', 'num_unique_dest',
                            'avg_inter_call_gap']].describe().round(1))

# 2.2  Hourly call pattern -- the KEY visual
# This plot shows WHY sequential analysis matters
fig, axes = plt.subplots(3, 1, figsize=(14, 12), sharex=True)

for label, color, title in [
    ('normal', 'steelblue', 'NORMAL Subscriber -- Hourly Call Pattern (1 week)'),
    ('simbox', 'crimson', 'SIM-BOX Fraudster -- Hourly Call Pattern (1 week)'),
    ('cloned', 'darkorange', 'CLONED SIM / Bot -- Hourly Call Pattern (1 week)')
]:
    # Pick one representative subscriber, show first 7 days (168 hours)
    sub = df[df['label'] == label]['subscriber_id'].unique()[0]
    sub_data = df[(df['subscriber_id'] == sub) & (df['hour_index'] < 168)]
    ax_idx = ['normal', 'simbox', 'cloned'].index(label)
    axes[ax_idx].bar(sub_data['hour_index'], sub_data['num_calls'],
                     color=color, alpha=0.7, width=0.8)
    axes[ax_idx].set_ylabel('Calls / Hour')
    axes[ax_idx].set_title(title)

    # Mark day boundaries
    for d in range(8):
        axes[ax_idx].axvline(d * 24, color='gray', ls='--', alpha=0.3)
    # Mark weekends
    for d in range(7):
        if d >= 5:  # Sat, Sun
            axes[ax_idx].axvspan(d * 24, (d + 1) * 24, alpha=0.1, color='yellow')

axes[2].set_xlabel('Hour Index (Day boundaries shown as dashed lines, weekends in yellow)')
plt.tight_layout()
plt.savefig(data_folder / 'eda_hourly_patterns.png', dpi=120, bbox_inches='tight')
plt.show()

#Circadian rhythm is the natural 24-hour cycle of human activity. 
# Normal subscribers show a clear circadian pattern with peaks during typical waking hours and quiet periods at night. 
# In contrast, SIM-box fraudsters exhibit a flat, uniform pattern with no regard for time of day, 
# while cloned SIMs show irregular bursts that do not align with normal human behavior. 
# This temporal structure is the critical signal that our LSTM model will learn to identify and use for anomaly detection.
print("\n** KEY OBSERVATION: Normal subscriber shows clear circadian rhythm")
print("   (peaks at morning/evening, quiet at night, reduced on weekends).")
print("   SIM-box is FLAT 24x7. Cloned SIM has INVERTED peaks (active at night).")
print("   This TEMPORAL STRUCTURE is what the LSTM will learn. **")

# 2.3  Call duration distribution by type
fig, axes = plt.subplots(1, 3, figsize=(15, 4))

for i, (label, color) in enumerate([('normal', 'steelblue'),
                                     ('simbox', 'crimson'),
                                     ('cloned', 'darkorange')]):
    durations = df[(df['label'] == label) & (df['avg_call_duration'] > 0)]['avg_call_duration']
    axes[i].hist(durations, bins=50, color=color, alpha=0.7, edgecolor='white')
    axes[i].set_title(f'{label.upper()} -- Call Duration Distribution')
    axes[i].set_xlabel('Avg Call Duration (seconds)')
    axes[i].set_ylabel('Frequency')
    axes[i].axvline(durations.median(), color='black', ls='--',
                    label=f'Median: {durations.median():.0f}s')
    axes[i].legend()

plt.tight_layout()
plt.savefig(data_folder / 'eda_call_duration_dist.png', dpi=120, bbox_inches='tight')
plt.show()

print("\n** INSIGHT: Normal subscribers have a WIDE, log-normal duration distribution.")
print("   SIM-box durations cluster tightly around 60s (automated routing).")
print("   Cloned SIM durations are very short (5-20s probing calls). **")

# 2.4  Inter-call gap regularity analysis
fig, axes = plt.subplots(1, 3, figsize=(15, 4))

for i, (label, color) in enumerate([('normal', 'steelblue'),
                                     ('simbox', 'crimson'),
                                     ('cloned', 'darkorange')]):
    gaps = df[(df['label'] == label) & (df['avg_inter_call_gap'] > 0)]['avg_inter_call_gap']
    axes[i].hist(gaps, bins=50, color=color, alpha=0.7, edgecolor='white')
    axes[i].set_title(f'{label.upper()} -- Inter-Call Gap Distribution')
    axes[i].set_xlabel('Avg Inter-Call Gap (seconds)')
    axes[i].set_ylabel('Frequency')
    std_val = gaps.std()
    axes[i].axvline(gaps.mean(), color='black', ls='--',
                    label=f'Mean: {gaps.mean():.0f}s, Std: {std_val:.0f}s')
    axes[i].legend(fontsize=8)

plt.tight_layout()
plt.savefig(data_folder / 'eda_intercall_gap_dist.png', dpi=120, bbox_inches='tight')
plt.show()

print("\n** INSIGHT: Normal gaps have HIGH variance (human unpredictability).")
print("   SIM-box gaps cluster tightly (machine regularity).")
print("   Cloned SIM gaps are extremely narrow (scripted 120s intervals). **")

# 2.5  Correlation heatmap by type
feature_cols = ['num_calls', 'avg_call_duration', 'num_unique_dest',
                'avg_inter_call_gap', 'hour_of_day', 'is_weekend']

fig, axes = plt.subplots(1, 3, figsize=(18, 5))
for i, label in enumerate(['normal', 'simbox', 'cloned']):
    corr = df[df['label'] == label][feature_cols].corr()
    sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm', ax=axes[i],
                vmin=-1, vmax=1, cbar=i == 2)
    axes[i].set_title(f'{label.upper()} Correlations')

plt.tight_layout()
plt.savefig(data_folder / 'eda_correlation_by_type.png', dpi=120, bbox_inches='tight')
plt.show()

print("\n** INSIGHT: In normal data, num_calls correlates with hour_of_day")
print("   (circadian rhythm). In SIM-box data, this correlation VANISHES")
print("   because activity is uniform across all hours. **")


# =============================================================================
# STEP 3 -- SEQUENCE PREPARATION FOR LSTM
# =============================================================================
# LSTMs require input shaped as (batch, sequence_length, features).
#
# We create 24-hour (24-step) sliding windows of CDR features per subscriber.
# Each window becomes one training sample.
#
# Why 24 hours?
#   - Captures a full circadian cycle (the primary pattern to learn)
#   - Long enough for the LSTM to learn day/night transitions
#   - Short enough to detect anomalies within a single day
#
# The LSTM's hidden state carries information from hour 0 to hour 23,
# learning patterns like "if morning was busy, afternoon should be quiet".
# =============================================================================
print("\n" + "=" * 60)
print("STEP 3: Sequence Preparation for LSTM")
print("=" * 60)

SEQ_LEN = 24  # 24 hours = 1 full circadian cycle

feature_names = ['num_calls', 'avg_call_duration', 'num_unique_dest',
                 'avg_inter_call_gap', 'hour_of_day', 'is_weekend']
n_features = len(feature_names)

# Scale features BEFORE creating sequences
scaler = StandardScaler()
df[feature_names] = scaler.fit_transform(df[feature_names])

# Create sequences per subscriber using sliding windows
def create_sequences(sub_df, seq_len, label):
    """Create overlapping sequences from a single subscriber's data."""
    values = sub_df[feature_names].values
    sequences = []
    for i in range(0, len(values) - seq_len + 1, seq_len // 2):  # 50% overlap
        seq = values[i:i + seq_len]
        if len(seq) == seq_len:
            sequences.append(seq)
    return sequences, [label] * len(sequences)

all_sequences = []
all_labels = []

for sub_id in df['subscriber_id'].unique():
    sub_df = df[df['subscriber_id'] == sub_id].sort_values('hour_index')
    label = sub_df['label'].iloc[0]
    seqs, labs = create_sequences(sub_df, SEQ_LEN, label)
    all_sequences.extend(seqs)
    all_labels.extend(labs)

all_sequences = np.array(all_sequences)
all_labels = np.array(all_labels)

print(f"Total sequences created: {all_sequences.shape[0]}")
print(f"Sequence shape: {all_sequences.shape}  (samples, time_steps, features)")
print(f"\nLabel distribution in sequences:")
for lbl in ['normal', 'simbox', 'cloned']:
    count = (all_labels == lbl).sum()
    print(f"  {lbl:8s}: {count:5d} sequences ({count / len(all_labels):.1%})")

# Split: Train on NORMAL only, test on ALL
normal_mask = all_labels == 'normal'
X_normal = all_sequences[normal_mask]
X_anomaly = all_sequences[~normal_mask]
y_anomaly_labels = all_labels[~normal_mask]

# Split normal data: 80% train, 20% validation
n_train = int(0.8 * len(X_normal))
indices = np.random.permutation(len(X_normal))
X_train = X_normal[indices[:n_train]]
X_val = X_normal[indices[n_train:]]

# Test set: validation normal + all anomalies
X_test = np.concatenate([X_val, X_anomaly], axis=0)
y_test = np.array([0] * len(X_val) + [1] * len(X_anomaly))
y_test_detailed = np.array(['normal'] * len(X_val) +
                            list(y_anomaly_labels))

print(f"\nTrain (normal only)    : {X_train.shape[0]:,} sequences")
print(f"Validation (normal)    : {X_val.shape[0]:,} sequences")
print(f"Test (normal + anomaly): {X_test.shape[0]:,} sequences")
print(f"  - Normal in test : {(y_test == 0).sum():,}")
print(f"  - Anomaly in test: {(y_test == 1).sum():,}")

# Convert to PyTorch tensors
train_tensor = torch.FloatTensor(X_train)
val_tensor = torch.FloatTensor(X_val)
test_tensor = torch.FloatTensor(X_test)

train_loader = DataLoader(TensorDataset(train_tensor, train_tensor),
                          batch_size=64, shuffle=True)
val_loader = DataLoader(TensorDataset(val_tensor, val_tensor),
                        batch_size=64, shuffle=False)

print("\n** SEQUENCE SHAPE EXPLAINED:")
print(f"   Each sample = {SEQ_LEN} time steps x {n_features} features")
print(f"   Time step = 1 hour of aggregated CDR data")
print(f"   The LSTM will read this sequence LEFT to RIGHT (hour 0 -> hour 23)")
print(f"   building up a MEMORY of the subscriber's daily pattern. **")


# =============================================================================
# STEP 4 -- BUILD & TRAIN LSTM AUTOENCODER
# =============================================================================
# Architecture:
#
#   ENCODER:
#     Input (24, 6) --> LSTM(hidden=64, layers=2) --> Last hidden state (64,)
#     The encoder COMPRESSES the 24-step sequence into a single 64-dim vector.
#     This vector must capture the ESSENCE of the temporal pattern.
#
#   DECODER:
#     Latent (64,) --> Repeat 24 times --> LSTM(hidden=64, layers=2) --> Linear --> (24, 6)
#     The decoder RECONSTRUCTS the original sequence from the compressed code.
#
#   Loss = MSE(input, reconstruction)
#
#   WHY THIS WORKS:
#     The bottleneck forces the model to learn EFFICIENT representations.
#     Normal patterns (circadian rhythm) are COMPRESSIBLE -- a few parameters
#     describe "morning burst + evening burst + quiet night".
#     Fraudulent patterns are NOT seen during training, so the model cannot
#     reconstruct them well --> HIGH reconstruction error = ANOMALY.
# =============================================================================
print("\n" + "=" * 60)
print("STEP 4: Build & Train LSTM Autoencoder")
print("=" * 60)


class LSTMEncoder(nn.Module):
    """Encodes a sequence into a fixed-size latent vector."""
    def __init__(self, n_features, hidden_dim, n_layers, dropout):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=n_features,
            hidden_size=hidden_dim,
            num_layers=n_layers,
            batch_first=True,
            dropout=dropout if n_layers > 1 else 0.0
        )

    def forward(self, x):
        # x: (batch, seq_len, features)
        _, (hidden, _) = self.lstm(x)
        # hidden: (n_layers, batch, hidden_dim) --> take last layer
        return hidden[-1]  # (batch, hidden_dim)


class LSTMDecoder(nn.Module):
    """Decodes a latent vector back into a sequence."""
    def __init__(self, n_features, hidden_dim, n_layers, seq_len, dropout):
        super().__init__()
        self.seq_len = seq_len
        self.hidden_dim = hidden_dim
        self.lstm = nn.LSTM(
            input_size=hidden_dim,
            hidden_size=hidden_dim,
            num_layers=n_layers,
            batch_first=True,
            dropout=dropout if n_layers > 1 else 0.0
        )
        self.output_layer = nn.Linear(hidden_dim, n_features)

    def forward(self, z):
        # z: (batch, hidden_dim) --> repeat across time steps
        z_repeated = z.unsqueeze(1).repeat(1, self.seq_len, 1)  # (batch, seq_len, hidden)
        lstm_out, _ = self.lstm(z_repeated)                      # (batch, seq_len, hidden)
        reconstruction = self.output_layer(lstm_out)             # (batch, seq_len, features)
        return reconstruction


class LSTMAutoencoder(nn.Module):
    """Complete LSTM Autoencoder for sequence anomaly detection."""
    def __init__(self, n_features, hidden_dim, n_layers, seq_len, dropout=0.2):
        super().__init__()
        self.encoder = LSTMEncoder(n_features, hidden_dim, n_layers, dropout)
        self.decoder = LSTMDecoder(n_features, hidden_dim, n_layers, seq_len, dropout)

    def forward(self, x):
        z = self.encoder(x)
        reconstruction = self.decoder(z)
        return reconstruction


def train_model(model, train_loader, val_loader, n_epochs, lr, patience=10):
    """Train with early stopping on validation loss."""
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.MSELoss()

    train_losses = []
    val_losses = []
    best_val_loss = float('inf')
    #patience_counter counts how many consecutive epochs we've gone without improvement in validation loss.
    #It is an early stopping mechanism to prevent overfitting. If patience_counter reaches the specified patience threshold, training will stop.
    #patience 1/20 means model has gone 1 epoch without improvement, and if it reaches 20 epochs without improvement, training will stop.
    patience_counter = 0
    best_state = None

    for epoch in range(n_epochs):
        # --- Training ---
        model.train()
        epoch_train_loss = 0.0
        for batch_x, _ in train_loader:
            batch_x = batch_x.to(device)
            reconstruction = model(batch_x)
            loss = criterion(reconstruction, batch_x)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            epoch_train_loss += loss.item() * batch_x.size(0)

        epoch_train_loss /= len(train_loader.dataset)
        train_losses.append(epoch_train_loss)

        # --- Validation ---
        model.eval()
        epoch_val_loss = 0.0
        with torch.no_grad():
            for batch_x, _ in val_loader:
                batch_x = batch_x.to(device)
                reconstruction = model(batch_x)
                loss = criterion(reconstruction, batch_x)
                epoch_val_loss += loss.item() * batch_x.size(0)

        epoch_val_loss /= len(val_loader.dataset)
        val_losses.append(epoch_val_loss)

        # --- Early stopping ---
        if epoch_val_loss < best_val_loss:
            best_val_loss = epoch_val_loss
            patience_counter = 0
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
        else:
            patience_counter += 1

        if (epoch + 1) % 10 == 0 or epoch == 0:
            print(f"  Epoch {epoch + 1:3d}/{n_epochs} | "
                  f"Train Loss: {epoch_train_loss:.6f} | "
                  f"Val Loss: {epoch_val_loss:.6f} | "
                  f"Patience: {patience_counter}/{patience}")

        if patience_counter >= patience:
            print(f"  Early stopping at epoch {epoch + 1}")
            break

    # Restore best model
    if best_state is not None:
        model.load_state_dict(best_state)

    return train_losses, val_losses


# Initialize and train
HIDDEN_DIM = 64
N_LAYERS = 2
N_EPOCHS = 100
LEARNING_RATE = 1e-3
DROPOUT = 0.2

model = LSTMAutoencoder(
    n_features=n_features,
    hidden_dim=HIDDEN_DIM,
    n_layers=N_LAYERS,
    seq_len=SEQ_LEN,
    dropout=DROPOUT
).to(device)

print(f"\nModel architecture:")
print(model)
total_params = sum(p.numel() for p in model.parameters())
print(f"Total parameters: {total_params:,}")

print(f"\nTraining on {len(train_loader.dataset):,} normal sequences...")
print(f"Hyperparameters: hidden={HIDDEN_DIM}, layers={N_LAYERS}, "
      f"lr={LEARNING_RATE}, dropout={DROPOUT}")

train_losses, val_losses = train_model(
    model, train_loader, val_loader,
    n_epochs=N_EPOCHS, lr=LEARNING_RATE, patience=15
)

# Plot training curve
fig, ax = plt.subplots(figsize=(10, 4))
ax.plot(train_losses, label='Train Loss', color='steelblue')
ax.plot(val_losses, label='Validation Loss', color='crimson')
ax.set_xlabel('Epoch')
ax.set_ylabel('MSE Loss')
ax.set_title('LSTM Autoencoder -- Training Curve')
ax.legend()
ax.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(data_folder / 'training_curve.png', dpi=120, bbox_inches='tight')
plt.show()

print(f"\nFinal train loss: {train_losses[-1]:.6f}")
print(f"Best val loss:    {min(val_losses):.6f}")


# =============================================================================
# STEP 5 -- EVALUATE & DETECT ANOMALIES
# =============================================================================
# The anomaly score = per-sequence reconstruction error (MSE).
# Normal sequences --> low error (model knows how to reconstruct them).
# Fraudulent sequences --> high error (never seen during training).
#
# Threshold selection:
#   We use the 95th percentile of NORMAL validation reconstruction errors.
#   Anything above this threshold is flagged as anomalous.
# =============================================================================
print("\n" + "=" * 60)
print("STEP 5: Evaluate & Detect Anomalies")
print("=" * 60)


def compute_reconstruction_error(model, data_tensor, batch_size=256):
    """Compute per-sequence MSE reconstruction error."""
    model.eval()
    loader = DataLoader(TensorDataset(data_tensor, data_tensor),
                        batch_size=batch_size, shuffle=False)
    errors = []
    with torch.no_grad():
        for batch_x, _ in loader:
            batch_x = batch_x.to(device)
            reconstruction = model(batch_x)
            # Per-sequence MSE: mean over (seq_len, features)
            mse = ((batch_x - reconstruction) ** 2).mean(dim=(1, 2))
            errors.extend(mse.cpu().numpy())
    return np.array(errors)


# Compute errors for all sets
train_errors = compute_reconstruction_error(model, train_tensor)
val_errors = compute_reconstruction_error(model, val_tensor)
test_errors = compute_reconstruction_error(model, test_tensor)

# Set threshold at 95th percentile of normal validation errors
threshold = np.percentile(val_errors, 95)
print(f"\nAnomaly threshold (95th percentile of normal): {threshold:.6f}")

# 5.1  Error distribution: Normal vs Anomaly
normal_test_errors = test_errors[y_test == 0]
anomaly_test_errors = test_errors[y_test == 1]

# Further break down anomaly types
simbox_mask = y_test_detailed == 'simbox'
cloned_mask = y_test_detailed == 'cloned'
simbox_errors = test_errors[simbox_mask]
cloned_errors = test_errors[cloned_mask]

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Histogram
axes[0].hist(normal_test_errors, bins=50, alpha=0.6, color='steelblue',
             label=f'Normal (n={len(normal_test_errors)})', density=True)
axes[0].hist(anomaly_test_errors, bins=50, alpha=0.6, color='crimson',
             label=f'Anomaly (n={len(anomaly_test_errors)})', density=True)
axes[0].axvline(threshold, color='black', ls='--', linewidth=2,
                label=f'Threshold: {threshold:.4f}')
axes[0].set_xlabel('Reconstruction Error (MSE)')
axes[0].set_ylabel('Density')
axes[0].set_title('Reconstruction Error Distribution')
axes[0].legend()

# Box plot by type
error_data = pd.DataFrame({
    'Reconstruction Error': test_errors,
    'Type': y_test_detailed
})
sns.boxplot(data=error_data, x='Type', y='Reconstruction Error', ax=axes[1],
            palette={'normal': 'steelblue', 'simbox': 'crimson', 'cloned': 'darkorange'})
axes[1].axhline(threshold, color='black', ls='--', linewidth=2, label='Threshold')
axes[1].set_title('Reconstruction Error by Subscriber Type')
axes[1].legend()

plt.tight_layout()
plt.savefig(data_folder / 'error_distribution.png', dpi=120, bbox_inches='tight')
plt.show()

print(f"\nMean reconstruction error:")
print(f"  Normal  : {normal_test_errors.mean():.6f} (std: {normal_test_errors.std():.6f})")
print(f"  SIM-box : {simbox_errors.mean():.6f} (std: {simbox_errors.std():.6f})")
print(f"  Cloned  : {cloned_errors.mean():.6f} (std: {cloned_errors.std():.6f})")

# 5.2  Classification results
test_pred = (test_errors > threshold).astype(int)

print("\n" + "=" * 55)
print("LSTM AUTOENCODER -- Test Results (Binary: Normal vs Anomaly)")
print("=" * 55)
print(classification_report(y_test, test_pred, target_names=['Normal', 'Anomaly']))

# Confusion matrix
fig, axes = plt.subplots(1, 2, figsize=(13, 5))

cm = confusion_matrix(y_test, test_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[0],
            xticklabels=['Normal', 'Anomaly'],
            yticklabels=['Normal', 'Anomaly'])
axes[0].set_title('LSTM Autoencoder -- Confusion Matrix')
axes[0].set_xlabel('Predicted')
axes[0].set_ylabel('Actual')

# ROC curve
if len(np.unique(y_test)) > 1:
    fpr, tpr, _ = roc_curve(y_test, test_errors)
    auc = roc_auc_score(y_test, test_errors)
    axes[1].plot(fpr, tpr, color='navy', linewidth=2, label=f'LSTM AE (AUC={auc:.3f})')
    axes[1].plot([0, 1], [0, 1], 'k--', label='Random')
    axes[1].set_xlabel('False Positive Rate')
    axes[1].set_ylabel('True Positive Rate')
    axes[1].set_title('ROC Curve')
    axes[1].legend()

plt.tight_layout()
plt.savefig(data_folder / 'confusion_roc.png', dpi=120, bbox_inches='tight')
plt.show()

# 5.3  Visualize reconstruction: Normal vs Fraudulent sequence
fig, axes = plt.subplots(3, 2, figsize=(14, 12))

model.eval()
with torch.no_grad():
    for row, (label, data_slice, color) in enumerate([
        ('Normal', test_tensor[y_test == 0][:1], 'steelblue'),
        ('SIM-box', test_tensor[simbox_mask][:1], 'crimson'),
        ('Cloned', test_tensor[cloned_mask][:1], 'darkorange')
    ]):
        sample = data_slice.to(device)
        recon = model(sample).cpu().numpy()[0]
        original = data_slice.numpy()[0]

        # Plot num_calls (feature 0)
        axes[row][0].plot(range(SEQ_LEN), original[:, 0], 'o-', color=color,
                          label='Original', markersize=4)
        axes[row][0].plot(range(SEQ_LEN), recon[:, 0], 's--', color='gray',
                          label='Reconstructed', markersize=4, alpha=0.7)
        mse = ((original - recon) ** 2).mean()
        axes[row][0].set_title(f'{label} -- num_calls (MSE: {mse:.4f})')
        axes[row][0].set_ylabel('Scaled Value')
        axes[row][0].legend(fontsize=8)

        # Plot avg_call_duration (feature 1)
        axes[row][1].plot(range(SEQ_LEN), original[:, 1], 'o-', color=color,
                          label='Original', markersize=4)
        axes[row][1].plot(range(SEQ_LEN), recon[:, 1], 's--', color='gray',
                          label='Reconstructed', markersize=4, alpha=0.7)
        axes[row][1].set_title(f'{label} -- avg_call_duration')
        axes[row][1].set_ylabel('Scaled Value')
        axes[row][1].legend(fontsize=8)

axes[2][0].set_xlabel('Hour (within 24h window)')
axes[2][1].set_xlabel('Hour (within 24h window)')
plt.suptitle('LSTM Autoencoder Reconstruction: Normal vs Fraudulent Sequences',
             fontsize=13, y=1.01)
plt.tight_layout()
plt.savefig(data_folder / 'reconstruction_comparison.png', dpi=120, bbox_inches='tight')
plt.show()

print("\n** KEY INSIGHT: The model reconstructs NORMAL sequences accurately (low error)")
print("   but FAILS to reconstruct fraudulent sequences (high error).")
print("   This is because the autoencoder only learned normal temporal patterns. **")

# 5.4  Per-subscriber anomaly scoring
print("\n--- Per-Subscriber Anomaly Scoring ---")
sub_scores = []
for sub_id in df['subscriber_id'].unique():
    label = df[df['subscriber_id'] == sub_id]['label'].iloc[0]
    sub_df = df[df['subscriber_id'] == sub_id].sort_values('hour_index')
    values = sub_df[feature_names].values

    # Create sequences for this subscriber
    sequences = []
    for i in range(0, len(values) - SEQ_LEN + 1, SEQ_LEN // 2):
        seq = values[i:i + SEQ_LEN]
        if len(seq) == SEQ_LEN:
            sequences.append(seq)

    if len(sequences) > 0:
        seqs_tensor = torch.FloatTensor(np.array(sequences))
        errors = compute_reconstruction_error(model, seqs_tensor)
        sub_scores.append({
            'subscriber_id': sub_id,
            'label': label,
            'mean_error': errors.mean(),
            'max_error': errors.max(),
            'pct_flagged': (errors > threshold).mean()
        })

sub_scores_df = pd.DataFrame(sub_scores).sort_values('mean_error', ascending=False)

print("\nTop 25 most anomalous subscribers:")
print(sub_scores_df.head(25).to_string(index=False))

print(f"\nAll SIM-box subscribers in top-{n_simbox + n_cloned}? "
      f"{sub_scores_df.head(n_simbox + n_cloned)['label'].isin(['simbox', 'cloned']).all()}")


# =============================================================================
# STEP 6 -- HYPERPARAMETER TUNING
# =============================================================================
# For the LSTM Autoencoder, we tune:
#   - hidden_dim: size of the latent representation (16, 32, 64, 128)
#   - n_layers: depth of the LSTM (1, 2, 3)
#   - learning_rate: step size for optimization
#
# Since this is unsupervised, we evaluate using:
#   - F1-score on the test set (using the 95th percentile threshold)
#   - ROC-AUC score (threshold-independent)
# =============================================================================
print("\n" + "=" * 60)
print("STEP 6: Hyperparameter Tuning")
print("=" * 60)

configs = [
    {'hidden_dim': 32,  'n_layers': 1, 'lr': 1e-3, 'dropout': 0.1},
    {'hidden_dim': 64,  'n_layers': 1, 'lr': 1e-3, 'dropout': 0.2},
    {'hidden_dim': 64,  'n_layers': 2, 'lr': 1e-3, 'dropout': 0.2},
    {'hidden_dim': 128, 'n_layers': 2, 'lr': 1e-3, 'dropout': 0.2},
    {'hidden_dim': 64,  'n_layers': 2, 'lr': 5e-4, 'dropout': 0.3},
    {'hidden_dim': 128, 'n_layers': 3, 'lr': 5e-4, 'dropout': 0.3},
]

tuning_results = []

for i, cfg in enumerate(configs):
    print(f"\n--- Config {i + 1}/{len(configs)}: {cfg} ---")

    m = LSTMAutoencoder(
        n_features=n_features,
        hidden_dim=cfg['hidden_dim'],
        n_layers=cfg['n_layers'],
        seq_len=SEQ_LEN,
        dropout=cfg['dropout']
    ).to(device)

    _, v_losses = train_model(m, train_loader, val_loader,
                              n_epochs=80, lr=cfg['lr'], patience=12)

    # Evaluate
    val_errs = compute_reconstruction_error(m, val_tensor)
    test_errs = compute_reconstruction_error(m, test_tensor)
    thr = np.percentile(val_errs, 95)
    preds = (test_errs > thr).astype(int)

    f1 = f1_score(y_test, preds)
    auc = roc_auc_score(y_test, test_errs)

    result = {**cfg, 'best_val_loss': min(v_losses), 'f1_anomaly': f1,
              'roc_auc': auc, 'threshold': thr}
    tuning_results.append(result)
    print(f"  F1: {f1:.4f} | AUC: {auc:.4f} | Val Loss: {min(v_losses):.6f}")

tuning_df = pd.DataFrame(tuning_results).sort_values('f1_anomaly', ascending=False)
print("\n" + "=" * 60)
print("TUNING RESULTS (sorted by F1-score)")
print("=" * 60)
print(tuning_df.to_string(index=False))

# Retrain best configuration
best_cfg = tuning_df.iloc[0]
print(f"\nBest config: hidden={int(best_cfg['hidden_dim'])}, "
      f"layers={int(best_cfg['n_layers'])}, lr={best_cfg['lr']}, "
      f"dropout={best_cfg['dropout']}")

best_model = LSTMAutoencoder(
    n_features=n_features,
    hidden_dim=int(best_cfg['hidden_dim']),
    n_layers=int(best_cfg['n_layers']),
    seq_len=SEQ_LEN,
    dropout=best_cfg['dropout']
).to(device)

print("\nRetraining best configuration with more epochs...")
best_train_losses, best_val_losses = train_model(
    best_model, train_loader, val_loader,
    n_epochs=150, lr=best_cfg['lr'], patience=20
)

# Final evaluation with best model
best_val_errs = compute_reconstruction_error(best_model, val_tensor)
best_test_errs = compute_reconstruction_error(best_model, test_tensor)
best_threshold = np.percentile(best_val_errs, 95)
best_preds = (best_test_errs > best_threshold).astype(int)

print("\n" + "=" * 55)
print("BEST LSTM AUTOENCODER -- Final Test Results")
print("=" * 55)
print(classification_report(y_test, best_preds, target_names=['Normal', 'Anomaly']))
print(f"ROC-AUC: {roc_auc_score(y_test, best_test_errs):.4f}")

# Plot tuning comparison
fig, ax = plt.subplots(figsize=(10, 5))
configs_labels = [f"h={int(r['hidden_dim'])}\nl={int(r['n_layers'])}\nlr={r['lr']}"
                  for _, r in tuning_df.iterrows()]
x = range(len(tuning_df))
bars = ax.bar(x, tuning_df['f1_anomaly'], color='steelblue', edgecolor='navy', alpha=0.8)
ax.bar(x, tuning_df['roc_auc'], alpha=0.3, color='crimson', edgecolor='darkred',
       label='ROC-AUC')
ax.set_xticks(x)
ax.set_xticklabels(configs_labels, fontsize=8)
ax.set_ylabel('Score')
ax.set_title('Hyperparameter Tuning -- F1 (Anomaly) & ROC-AUC')
ax.legend(['F1 (Anomaly)', 'ROC-AUC'])

for bar, val in zip(bars, tuning_df['f1_anomaly']):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
            f'{val:.3f}', ha='center', fontsize=9)

plt.tight_layout()
plt.savefig(data_folder / 'tuning_comparison.png', dpi=120, bbox_inches='tight')
plt.show()


# =============================================================================
# STEP 7 -- FINDINGS & ANALYSIS
# =============================================================================
# Key Takeaways:
#   1. LSTM captures TEMPORAL patterns that tabular ML cannot.
#      - The circadian rhythm (morning/evening bursts) is a SEQUENCE pattern.
#      - The uniform 24x7 activity of SIM-box breaks this pattern completely.
#      - The inverted night-active pattern of cloned SIMs is also detected.
#
#   2. The autoencoder approach is UNSUPERVISED -- no labelled fraud data needed.
#      - Learns "normal" from clean subscriber data
#      - Flags ANY deviation, including novel fraud types not seen before
#      - Adapts to new patterns by retraining on recent normal data
#
#   3. Reconstruction error as anomaly score provides GRANULARITY:
#      - Not just binary fraud/no-fraud
#      - Higher error = more confident the pattern is abnormal
#      - Enables tiered alerting (Warning at 90th pctl, Critical at 99th pctl)
#
#   4. WHY LSTM SPECIFICALLY (vs. other sequence models):
#      - LSTM's gating mechanism (forget gate, input gate, output gate) allows
#        it to selectively remember or forget information across time steps
#      - For CDR data: it can remember "this subscriber had morning activity"
#        when processing evening data, and notice the ABSENCE of the expected
#        evening quiet period (for a SIM-box)
#      - The cell state provides a "conveyor belt" of information that doesn't
#        suffer from vanishing gradients over 24 time steps
#
# Production Deployment Considerations:
#   - Process CDRs in real-time: aggregate hourly, score with sliding window
#   - Use anomaly score percentile tiers: P90=Warning, P95=Alert, P99=Critical
#   - Retrain monthly on verified normal subscriber data
#   - Combine with rule-based filters for known fraud patterns
#   - Feature engineering can add more signals: cell tower changes, IMEI shifts
# =============================================================================
print("\n" + "=" * 60)
print("STEP 7: Findings & Analysis")
print("=" * 60)

# 7.1  Feature-level reconstruction error analysis
# Which CDR features contribute most to the anomaly signal?
model_to_analyze = best_model
model_to_analyze.eval()

feature_errors = {fname: {'normal': [], 'simbox': [], 'cloned': []} for fname in feature_names}

with torch.no_grad():
    for label_type in ['normal', 'simbox', 'cloned']:
        mask = y_test_detailed == label_type
        if mask.sum() == 0:
            continue
        data = test_tensor[mask].to(device)
        recon = model_to_analyze(data).cpu().numpy()
        original = test_tensor[mask].numpy()

        for f_idx, fname in enumerate(feature_names):
            per_seq_error = ((original[:, :, f_idx] - recon[:, :, f_idx]) ** 2).mean(axis=1)
            feature_errors[fname][label_type] = per_seq_error

# Plot feature-level errors
fig, axes = plt.subplots(2, 3, figsize=(16, 9))
axes = axes.flatten()

for i, fname in enumerate(feature_names):
    data_to_plot = []
    labels_to_plot = []
    for lbl in ['normal', 'simbox', 'cloned']:
        errs = feature_errors[fname][lbl]
        if len(errs) > 0:
            data_to_plot.extend(errs)
            labels_to_plot.extend([lbl] * len(errs))

    plot_df = pd.DataFrame({'Error': data_to_plot, 'Type': labels_to_plot})
    sns.boxplot(data=plot_df, x='Type', y='Error', ax=axes[i],
                palette={'normal': 'steelblue', 'simbox': 'crimson', 'cloned': 'darkorange'})
    axes[i].set_title(f'{fname}')
    axes[i].set_xlabel('')

plt.suptitle('Per-Feature Reconstruction Error by Subscriber Type', fontsize=14)
plt.tight_layout()
plt.savefig(data_folder / 'feature_level_errors.png', dpi=120, bbox_inches='tight')
plt.show()

print("\n** INSIGHT: The features contributing most to anomaly detection are:")
print("   - num_calls: SIM-box's uniform rate vs normal's circadian rhythm")
print("   - avg_call_duration: SIM-box's tight 60s vs normal's wide distribution")
print("   - avg_inter_call_gap: Cloned SIM's machine-like 120s regularity")
print("   - is_weekend: Fraud patterns show NO weekend reduction **")

# 7.2  Why LSTM beats tabular ML -- demonstration
print("\n" + "-" * 60)
print("WHY LSTM SUCCEEDS WHERE TABULAR ML WOULD FAIL")
print("-" * 60)

print("""
Consider two hourly snapshots:
  Hour A: num_calls=5, avg_duration=90s, gap=300s
  Hour B: num_calls=5, avg_duration=90s, gap=300s

To a Random Forest, these look IDENTICAL -- same features, same values.
But in CONTEXT:
  - If Hour A is 8 AM on Monday    --> NORMAL (morning commute calls)
  - If Hour B is 3 AM on Sunday    --> ANOMALOUS (who makes 5 calls at 3 AM?)

The LSTM sees the SEQUENCE: [..., hour_22=0_calls, hour_23=0_calls,
hour_0=0_calls, hour_1=0_calls, hour_2=0_calls, hour_3=5_calls, ...]
and recognizes "5 calls after hours of silence at 3 AM" as abnormal.

A tabular model would need MANUALLY ENGINEERED features like
"calls_at_3am" or "night_to_day_ratio" -- and would still miss
NOVEL patterns. The LSTM learns these temporal relationships
AUTOMATICALLY from data.

This is the fundamental advantage of deep learning for sequential data:
the model discovers relevant temporal features WITHOUT human feature
engineering, and the LSTM's memory cell preserves context across the
entire 24-hour window.
""")

# 7.3  Final summary table
final_test_errs = compute_reconstruction_error(best_model, test_tensor)
final_threshold = np.percentile(
    compute_reconstruction_error(best_model, val_tensor), 95)
final_preds = (final_test_errs > final_threshold).astype(int)

summary = pd.DataFrame({
    'Metric': [
        'F1-Score (Anomaly class)',
        'ROC-AUC',
        'Precision (Anomaly)',
        'Recall (Anomaly)',
        'Anomaly Threshold (95th pctl)',
        'Mean Error - Normal',
        'Mean Error - SIM-box',
        'Mean Error - Cloned SIM',
        'Architecture',
        'Training Sequences',
        'Sequence Length'
    ],
    'Value': [
        f"{f1_score(y_test, final_preds):.4f}",
        f"{roc_auc_score(y_test, final_test_errs):.4f}",
        f"{confusion_matrix(y_test, final_preds)[1, 1] / max(final_preds.sum(), 1):.4f}",
        f"{confusion_matrix(y_test, final_preds)[1, 1] / max(y_test.sum(), 1):.4f}",
        f"{final_threshold:.6f}",
        f"{final_test_errs[y_test == 0].mean():.6f}",
        f"{final_test_errs[simbox_mask].mean():.6f}",
        f"{final_test_errs[cloned_mask].mean():.6f}",
        f"LSTM AE (h={int(best_cfg['hidden_dim'])}, l={int(best_cfg['n_layers'])})",
        f"{len(train_loader.dataset):,}",
        f"{SEQ_LEN} hours"
    ]
})

print("\n" + "=" * 60)
print("FINAL RESULTS SUMMARY")
print("=" * 60)
print(summary.to_string(index=False))

# Save model
model_path = data_folder / 'lstm_autoencoder_cdr.pt'
torch.save({
    'model_state_dict': best_model.state_dict(),
    'scaler_mean': scaler.mean_,
    'scaler_scale': scaler.scale_,
    'threshold': final_threshold,
    'config': {
        'hidden_dim': int(best_cfg['hidden_dim']),
        'n_layers': int(best_cfg['n_layers']),
        'seq_len': SEQ_LEN,
        'n_features': n_features,
        'dropout': best_cfg['dropout']
    }
}, model_path)
print(f"\nModel saved to: {model_path}")

print("\n" + "=" * 60)
print("DEMO COMPLETE")
print("=" * 60)
print("""
KEY TAKEAWAYS FOR TELECOM CDR FRAUD DETECTION:

1. SEQUENTIAL NATURE: CDR data is inherently temporal. The ORDER of events
   matters as much as the events themselves. LSTM captures this naturally.

2. UNSUPERVISED DETECTION: The autoencoder learns "normal" without needing
   labelled fraud examples -- critical because fraud patterns evolve constantly.

3. ANOMALY SCORE: Reconstruction error provides a continuous score, not just
   binary classification. This enables tiered alerting and prioritization.

4. PATTERN DISCOVERY: The LSTM automatically discovers:
   - Circadian call rhythm (morning/evening peaks, night silence)
   - Weekend behaviour changes
   - Natural variation in call durations and gaps
   And flags deviations from these learned patterns.

5. ADAPTABILITY: Retraining on recent normal data allows the model to adapt
   to changing subscriber behaviour without manual rule updates.
""")
