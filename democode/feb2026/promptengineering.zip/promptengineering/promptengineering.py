"""
=============================================================================
Prompt Engineering Demo — Telecom (Telco) Context
=============================================================================
Uses Azure OpenAI  (same setup as my_first_genai_chatbot/01_azure_openai_basicapp.py)

Covers:
  1. Power of the System Prompt
  2. Few-Shot Prompting
  3. Chain-of-Thought (CoT) Prompting
  4. Temperature & Max-Tokens Settings
  5. Other Useful Patterns
     - Role + Audience framing
     - Output-format control (JSON, Markdown)
     - Delimiters / structured input
     - Self-consistency (multiple samples)
=============================================================================
"""

import os
import json
from openai import AzureOpenAI
from dotenv import load_dotenv

load_dotenv()

# ── Azure OpenAI client setup (identical to reference app) ──────────────────
client = AzureOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
)
MODEL = os.getenv("AZURE_OPENAI_MODEL_NAME")


# ── Helper ──────────────────────────────────────────────────────────────────
def call_llm(messages, temperature=0.0, max_tokens=1024, n=1):
    """Thin wrapper so every demo can stay focused on the prompt itself."""
    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            n=n,
        )
        if n == 1:
            return response.choices[0].message.content.strip()
        return [c.message.content.strip() for c in response.choices]
    except Exception as e:
        return f"[ERROR] {e}"


def banner(title):
    width = 70
    print("\n" + "=" * width)
    print(f"  {title}")
    print("=" * width)


def show(label, text):
    print(f"\n--- {label} ---")
    print(text)


# ============================================================================
# DEMO 1 — Power of the System Prompt
# ============================================================================
def demo_system_prompt():
    banner("DEMO 1: Power of the System Prompt")

    user_query = "My internet has been slow for the past two days."

    # 1a – Generic assistant (no telco system prompt)
    generic = call_llm([
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user",   "content": user_query},
    ])
    show("Generic assistant", generic)

    # 1b – Telco-specific L1 support agent
    telco_l1 = call_llm([
        {"role": "system", "content": (
            "You are an L1 technical-support agent for a major telecom provider. "
            "Always greet the customer, ask for their account or ticket number, "
            "walk them through basic troubleshooting (restart modem, check cables, "
            "run speed test), and offer to escalate to L2 if the issue persists. "
            "Be empathetic and professional. Keep answers concise."
        )},
        {"role": "user", "content": user_query},
    ])
    show("Telco L1 Support Agent (system prompt)", telco_l1)

    # 1c – Telco network engineer persona
    net_eng = call_llm([
        {"role": "system", "content": (
            "You are a senior network engineer at a telecom company. "
            "When a problem is described, respond with a structured root-cause "
            "analysis: list possible causes ranked by likelihood, suggest "
            "diagnostic commands or KPIs to check (e.g. SINR, RSRP, packet loss), "
            "and recommend next steps. Use technical language appropriate for "
            "an engineering audience."
        )},
        {"role": "user", "content": user_query},
    ])
    show("Network Engineer persona (system prompt)", net_eng)

    print("\n>> TAKEAWAY: The *same* user message produces vastly different "
          "responses depending on the system prompt.")


# ============================================================================
# DEMO 2 — Few-Shot Prompting
# ============================================================================
def demo_few_shot():
    banner("DEMO 2: Few-Shot Prompting")

    # Task: classify customer messages into intent categories
    system = (
        "You are a telco customer-intent classifier. "
        "Given a customer message, output exactly ONE label from: "
        "BILLING, TECH_SUPPORT, PLAN_CHANGE, CANCELLATION, GENERAL_INQUIRY."
    )

    # 2a – Zero-shot
    zero_shot = call_llm([
        {"role": "system", "content": system},
        {"role": "user",   "content": "I want to switch to the unlimited data plan."},
    ])
    show("Zero-shot classification", zero_shot)

    # 2b – Few-shot (provide examples so the model learns the exact format)
    few_shot = call_llm([
        {"role": "system", "content": system},
        # example 1
        {"role": "user",      "content": "Why was I charged $15 extra this month?"},
        {"role": "assistant", "content": "BILLING"},
        # example 2
        {"role": "user",      "content": "My voicemail is not working after the update."},
        {"role": "assistant", "content": "TECH_SUPPORT"},
        # example 3
        {"role": "user",      "content": "I'd like to cancel my contract effective immediately."},
        {"role": "assistant", "content": "CANCELLATION"},
        # example 4
        {"role": "user",      "content": "Can you add international roaming to my plan?"},
        {"role": "assistant", "content": "PLAN_CHANGE"},
        # actual query
        {"role": "user",      "content": "I want to switch to the unlimited data plan."},
    ])
    show("Few-shot classification (4 examples)", few_shot)

    # Harder example
    ambiguous = "I was double-charged and I want to cancel if this isn't fixed."
    few_shot_hard = call_llm([
        {"role": "system", "content": system},
        {"role": "user",      "content": "Why was I charged $15 extra this month?"},
        {"role": "assistant", "content": "BILLING"},
        {"role": "user",      "content": "My voicemail is not working after the update."},
        {"role": "assistant", "content": "TECH_SUPPORT"},
        {"role": "user",      "content": "I'd like to cancel my contract effective immediately."},
        {"role": "assistant", "content": "CANCELLATION"},
        {"role": "user",      "content": "Can you add international roaming to my plan?"},
        {"role": "assistant", "content": "PLAN_CHANGE"},
        {"role": "user",      "content": ambiguous},
    ])
    show(f"Few-shot on ambiguous input: \"{ambiguous}\"", few_shot_hard)

    print("\n>> TAKEAWAY: Few-shot examples steer the model toward the exact "
          "output format and improve accuracy on edge cases.")


# ============================================================================
# DEMO 3 — Chain-of-Thought (CoT) Prompting
# ============================================================================
def demo_chain_of_thought():
    banner("DEMO 3: Chain-of-Thought Prompting")

    problem = (
        "A telecom company offers three plans:\n"
        "  - Basic: $30/mo, 10 GB data, $10/GB overage\n"
        "  - Standard: $50/mo, 30 GB data, $8/GB overage\n"
        "  - Premium: $80/mo, unlimited data\n"
        "A customer used 42 GB last month. Which plan is cheapest for them?"
    )

    # 3a – Direct answer (no CoT)
    direct = call_llm([
        {"role": "system", "content": "You are a helpful telco billing assistant."},
        {"role": "user",   "content": problem + "\nGive only the plan name."},
    ])
    show("Direct answer (no CoT)", direct)

    # 3b – Chain-of-Thought
    cot = call_llm([
        {"role": "system", "content": "You are a helpful telco billing assistant."},
        {"role": "user",   "content": (
            problem +
            "\n\nThink step by step. For each plan calculate the total monthly "
            "cost for 42 GB usage, then recommend the cheapest option."
        )},
    ], max_tokens=1500)
    show("Chain-of-Thought answer", cot)

    print("\n>> TAKEAWAY: Asking the model to 'think step by step' produces "
          "a transparent reasoning trace and reduces calculation errors.")


# ============================================================================
# DEMO 4 — Temperature & Max-Tokens
# ============================================================================
def demo_temperature_and_tokens():
    banner("DEMO 4: Temperature & Max-Tokens Settings")

    prompt = (
        "Write a one-paragraph marketing blurb for a new 5G home internet "
        "plan called 'LightSpeed 5G' that costs $55/month with unlimited data."
    )

    # 4a – temperature=0 (deterministic, factual)
    t0 = call_llm([
        {"role": "system", "content": "You are a telco marketing copywriter."},
        {"role": "user",   "content": prompt},
    ], temperature=0.0)
    show("temperature=0.0 (deterministic)", t0)

    # 4b – temperature=0.7 (balanced creativity)
    t07 = call_llm([
        {"role": "system", "content": "You are a telco marketing copywriter."},
        {"role": "user",   "content": prompt},
    ], temperature=0.7)
    show("temperature=0.7 (balanced)", t07)

    # 4c – temperature=1.3 (highly creative / varied)
    t13 = call_llm([
        {"role": "system", "content": "You are a telco marketing copywriter."},
        {"role": "user",   "content": prompt},
    ], temperature=1.3)
    show("temperature=1.3 (high creativity)", t13)

    # 4d – max_tokens effect
    short = call_llm([
        {"role": "system", "content": "You are a telco marketing copywriter."},
        {"role": "user",   "content": prompt},
    ], temperature=0.0, max_tokens=40)
    show("max_tokens=40 (truncated output)", short)

    long_ = call_llm([
        {"role": "system", "content": "You are a telco marketing copywriter."},
        {"role": "user",   "content": prompt},
    ], temperature=0.0, max_tokens=500)
    show("max_tokens=500 (full output)", long_)

    print("\n>> TAKEAWAY: temperature controls randomness (0=deterministic, "
          ">1=creative). max_tokens caps output length — set it to avoid "
          "runaway responses or to force brevity.")


# ============================================================================
# DEMO 5 — Other Useful Patterns
# ============================================================================
def demo_other_patterns():
    banner("DEMO 5: Other Useful Prompt Patterns")

    # ── 5a  Role + Audience framing ─────────────────────────────────────────
    print("\n--- 5a: Role + Audience framing ---")
    technical = call_llm([
        {"role": "system", "content": (
            "You are a 5G network architect. Explain concepts to a fellow "
            "engineer. Use precise technical terminology."
        )},
        {"role": "user", "content": "Explain network slicing in 5G."},
    ], max_tokens=400)
    show("For engineers", technical)

    simple = call_llm([
        {"role": "system", "content": (
            "You are a friendly telco customer-service rep. Explain concepts "
            "in plain, simple language a non-technical customer can understand. "
            "Avoid jargon."
        )},
        {"role": "user", "content": "Explain network slicing in 5G."},
    ], max_tokens=400)
    show("For customers", simple)

    # ── 5b  Output-format control (JSON) ────────────────────────────────────
    print("\n--- 5b: Output-format control (JSON) ---")
    json_out = call_llm([
        {"role": "system", "content": (
            "You are a telco data extraction assistant. "
            "Always respond with valid JSON only — no markdown, no explanation."
        )},
        {"role": "user", "content": (
            "Extract structured information from this trouble ticket:\n\n"
            "\"Customer John Smith (Acct #88421) called at 3:15 PM on Jan 8 "
            "reporting no dial tone on his landline. He is located at "
            "742 Evergreen Terrace, Springfield. Issue started after the "
            "storm last night. Priority: High.\"\n\n"
            "Return JSON with keys: customer_name, account_number, issue, "
            "location, priority, reported_time."
        )},
    ])
    show("Structured JSON extraction", json_out)
    # Validate that it is parseable JSON
    try:
        parsed = json.loads(json_out)
        print("  [JSON is valid ✓]")
    except json.JSONDecodeError:
        print("  [JSON parsing failed — model may have added extra text]")

    # ── 5c  Delimiters / structured input ───────────────────────────────────
    print("\n--- 5c: Delimiters for structured input ---")
    delimited = call_llm([
        {"role": "system", "content": (
            "You are a telco compliance assistant. Given a customer complaint "
            "inside <complaint> tags and a company policy inside <policy> tags, "
            "determine if the complaint is covered by the policy. "
            "Answer with COVERED or NOT_COVERED and a one-sentence explanation."
        )},
        {"role": "user", "content": (
            "<complaint>\n"
            "I was charged an early termination fee even though my 2-year "
            "contract ended last month.\n"
            "</complaint>\n\n"
            "<policy>\n"
            "Early termination fees apply only during the active contract "
            "period. If the contract has expired, no ETF shall be charged.\n"
            "</policy>"
        )},
    ])
    show("Delimiter-based compliance check", delimited)

    # ── 5d  Self-consistency (sample multiple answers) ──────────────────────
    print("\n--- 5d: Self-consistency (n=3 samples) ---")
    question = (
        "A customer's 4G signal shows RSRP = -112 dBm and SINR = 2 dB. "
        "Is this a coverage problem, an interference problem, or both?"
    )
    answers = call_llm([
        {"role": "system", "content": "You are a telco RF engineer. Answer in one sentence."},
        {"role": "user",   "content": question},
    ], temperature=0.8, n=3)
    for i, ans in enumerate(answers, 1):
        print(f"  Sample {i}: {ans}")
    print("\n  >> Pick the majority answer or synthesize from all three.")

    print("\n>> TAKEAWAY: Combine patterns — role/audience framing, output "
          "format control, delimiters, and self-consistency — to build "
          "robust, production-quality prompts.")


# ============================================================================
# Run all demos
# ============================================================================
if __name__ == "__main__":
    demo_system_prompt()
    demo_few_shot()
    demo_chain_of_thought()
    demo_temperature_and_tokens()
    demo_other_patterns()

    banner("ALL DEMOS COMPLETE")
    print("\nKey Prompt-Engineering Principles Demonstrated:")
    print("  1. System prompt sets persona, tone, constraints, and format.")
    print("  2. Few-shot examples anchor the model's output style & accuracy.")
    print("  3. Chain-of-Thought unlocks step-by-step reasoning.")
    print("  4. Temperature (creativity) and max_tokens (length) are your dials.")
    print("  5. Combine patterns (role, format, delimiters, self-consistency)")
    print("     for production-grade prompt designs.\n")
