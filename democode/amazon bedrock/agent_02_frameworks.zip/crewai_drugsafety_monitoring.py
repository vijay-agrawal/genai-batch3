#!/usr/bin/env python3
"""
Healthcare Drug Safety Monitoring System
=========================================
CrewAI demo using:
  - Amazon Bedrock LLM (via LiteLLM)
  - Serper API for real-time web search
  - 3 sequential agents with shared state/memory
  - Task context chaining for inter-agent state sharing

Use Case: Drug Safety Monitoring for a given drug + clinical condition.

Agents (sequential pipeline):
  1. Adverse Event Researcher     -> searches for drug safety data
  2. Clinical Evidence Synthesizer -> analyzes and rates the evidence (context from Agent 1)
  3. Safety Report Writer         -> compiles the final report (context from Agents 1 & 2)
"""

import os
import sys

# Force UTF-8 output so CrewAI's emoji-heavy internal logging
# doesn't crash on Windows terminals using cp1252 / charmap codecs.
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if sys.stderr.encoding and sys.stderr.encoding.lower() != "utf-8":
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from dotenv import load_dotenv

from crewai import Agent, Task, Crew, Process, LLM
from crewai_tools import SerperDevTool

load_dotenv()

# ─────────────────────────────────────────────────────────────────────────────
# SHARED STATE
# A plain Python dict that both captures crew-wide configuration and is
# updated with key findings as the pipeline progresses. This is an explicit
# "application-level" shared state that complements CrewAI's built-in memory.
# ─────────────────────────────────────────────────────────────────────────────
shared_state: dict = {
    "drug_name": "metformin",
    "condition": "type 2 diabetes",
    # Populated after each task via CrewAI callbacks
    "adverse_events_found": [],
    "evidence_quality": "",
    "report_ready": False,
    "final_report_snippet": "",
}


# ─────────────────────────────────────────────────────────────────────────────
# CALLBACKS – update shared_state as each task completes
# ─────────────────────────────────────────────────────────────────────────────
def on_research_done(output):
    """Called when the Adverse Event Researcher finishes."""
    text = str(output)
    shared_state["adverse_events_found"] = [
        line.strip()
        for line in text.splitlines()
        if line.strip().startswith(("-", "*", "•"))
    ][:10]
    print(f"\n[Shared State Update] Adverse events captured: "
          f"{len(shared_state['adverse_events_found'])} items\n")


def on_synthesis_done(output):
    """Called when the Clinical Evidence Synthesizer finishes."""
    shared_state["evidence_quality"] = str(output)[:300]
    print(f"\n[Shared State Update] Evidence quality summary stored.\n")


def on_report_done(output):
    """Called when the Safety Report Writer finishes."""
    shared_state["report_ready"] = True
    shared_state["final_report_snippet"] = str(output)[:400]
    print(f"\n[Shared State Update] Report marked as ready.\n")


# ─────────────────────────────────────────────────────────────────────────────
# BEDROCK LLM
# LiteLLM (used internally by CrewAI) resolves 'bedrock/<model_id>' using
# AWS credentials from the environment (.env already sets them).
# ─────────────────────────────────────────────────────────────────────────────
# Nova models (nova-micro, nova-lite, nova-pro) issue multiple tool calls in a
# single turn, but CrewAI's Bedrock provider sends tool results one-by-one,
# violating the Converse API requirement that ALL pending tool results be
# returned in one message.  Claude models on Bedrock do not exhibit this
# behaviour and are fully supported by CrewAI's Bedrock integration.
# nova-lite handles tool-call argument formatting reliably; nova-micro is too
# small and frequently omits required fields (e.g. search_query).
model_id = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-lite-v1:0")

bedrock_llm = LLM(
    model=f"bedrock/{model_id}",
    max_tokens=int(os.getenv("BEDROCK_MAX_TOKENS", 1024)),
    temperature=float(os.getenv("BEDROCK_TEMPERATURE", 0.3)),
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    aws_region_name=os.getenv("AWS_REGION", "us-east-1"),
)

# ─────────────────────────────────────────────────────────────────────────────
# TOOLS
# SerperDevTool reads SERPER_API_KEY from the environment automatically.
# ─────────────────────────────────────────────────────────────────────────────
search_tool = SerperDevTool(n_results=5)

# ─────────────────────────────────────────────────────────────────────────────
# AGENTS
# ─────────────────────────────────────────────────────────────────────────────
drug = shared_state["drug_name"]
condition = shared_state["condition"]

adverse_event_researcher = Agent(
    role="Adverse Drug Event Researcher",
    goal=(
        f"Research and compile the latest adverse event reports, regulatory safety "
        f"alerts, and pharmacovigilance data for {drug} used in {condition} patients."
    ),
    backstory=(
        "You are a clinical pharmacovigilance specialist with 15 years of experience "
        "monitoring drug safety signals. You have deep expertise searching FDA MedWatch, "
        "EMA databases, and peer-reviewed literature for adverse drug reactions, serious "
        "side effects, and regulatory warnings. You are thorough and evidence-driven. "
        "IMPORTANT: Always run ONE search at a time and wait for the result before "
        "running the next search. Never issue multiple searches simultaneously."
    ),
    tools=[search_tool],
    llm=bedrock_llm,
    verbose=True,
    max_iter=10,
    memory=False,
)

clinical_evidence_synthesizer = Agent(
    role="Clinical Evidence Synthesizer",
    goal=(
        f"Analyze the adverse event research for {drug} in {condition}, rate the "
        "quality of evidence, identify risk patterns, and assess benefit vs. risk."
    ),
    backstory=(
        "You are a clinical epidemiologist specializing in systematic evidence synthesis "
        "and benefit-risk assessment. You use GRADE methodology to evaluate evidence "
        "quality, identify confounders, and translate pharmacological complexity into "
        "clear clinical insights. You build your analysis directly on prior research. "
        "IMPORTANT: Always run ONE search at a time and wait for the result before "
        "running the next search. Never issue multiple searches simultaneously."
    ),
    tools=[search_tool],
    llm=bedrock_llm,
    verbose=True,
    max_iter=10,
    memory=False,
)

safety_report_writer = Agent(
    role="Clinical Safety Report Writer",
    goal=(
        "Synthesize all research and evidence analysis into a structured, "
        "professionally formatted Drug Safety Report for healthcare providers."
    ),
    backstory=(
        "You are a medical communications expert who has authored hundreds of "
        "regulatory submissions, Dear Healthcare Professional letters, and clinical "
        "practice safety summaries. Your reports are concise, evidence-based, "
        "and immediately actionable by clinicians and patients alike."
    ),
    llm=bedrock_llm,
    verbose=True,
    memory=False,
)

# ─────────────────────────────────────────────────────────────────────────────
# TASKS
# Shared state between agents is achieved via:
#   (a) context=[previous_task] — passes the prior task's output as input
#   (b) crew memory=True        — all agents read/write a shared short-term store
#   (c) Python callbacks        — update the shared_state dict after each task
# ─────────────────────────────────────────────────────────────────────────────
task_research = Task(
    description=(
        f"Search for and compile a comprehensive adverse event profile for **{drug}** "
        f"used in **{condition}** patients. Your research must cover:\n\n"
        "1. Current FDA and EMA safety alerts or black-box warnings\n"
        "2. Top 5 most commonly reported adverse events with frequency estimates\n"
        "3. Serious / life-threatening adverse events\n"
        "4. Known drug-drug and drug-food interactions\n"
        "5. High-risk patient subgroups (e.g., renal impairment, elderly, pregnancy)\n"
        "6. Any recent label updates in the past 2 years\n\n"
        "Use web search to find the most current information. Be specific and cite sources."
    ),
    expected_output=(
        "A structured adverse event research summary containing: drug overview, "
        "regulatory warnings, a list of adverse events (with severity levels), "
        "drug interactions, and at-risk populations. Use bullet points for clarity."
    ),
    agent=adverse_event_researcher,
    callback=on_research_done,
)

task_synthesize = Task(
    description=(
        f"Using the adverse event research provided as context, perform a rigorous "
        f"clinical evidence synthesis for **{drug}** in **{condition}**:\n\n"
        "1. Rate the quality of evidence for each adverse event (High / Moderate / Low / Very Low)\n"
        "2. Identify the top 3 risk patterns or signals\n"
        "3. Estimate incidence rates per 1000 patients where data is available\n"
        "4. Conduct a benefit vs. risk assessment\n"
        "5. Highlight gaps in current safety knowledge\n"
        "6. Perform any supplementary searches needed to fill evidence gaps\n\n"
        "Your synthesis MUST explicitly reference and build upon the research findings "
        "from the previous agent."
    ),
    expected_output=(
        "A clinical evidence synthesis document organized as: evidence quality table, "
        "top risk patterns, incidence data, benefit-risk narrative, and knowledge gaps. "
        "Use GRADE-like ratings (High/Moderate/Low/Very Low) for each adverse event."
    ),
    agent=clinical_evidence_synthesizer,
    context=[task_research],        # <-- shared state: receives Agent 1's full output
    callback=on_synthesis_done,
)

task_report = Task(
    description=(
        "Using the research and evidence synthesis from the previous agents as context, "
        f"write a complete Drug Safety Report for **{drug}** ({condition}).\n\n"
        "The report MUST include all of these sections:\n\n"
        "## 1. Executive Summary\n"
        "   - 3-4 sentence overview of key safety findings\n\n"
        "## 2. Drug Overview\n"
        "   - Drug class, mechanism of action, approved indications\n\n"
        "## 3. Adverse Event Profile\n"
        "   - Organized by organ system (e.g., GI, renal, cardiovascular)\n"
        "   - Severity (mild / moderate / serious) and frequency for each\n\n"
        "## 4. Risk Factors & Vulnerable Populations\n"
        "   - Patient groups requiring special precautions\n\n"
        "## 5. Benefit-Risk Assessment\n"
        "   - Balanced evaluation citing evidence quality\n\n"
        "## 6. Recommendations for Healthcare Providers\n"
        "   - Prescribing guidance, monitoring requirements\n\n"
        "## 7. Patient Counseling Points\n"
        "   - Plain-language safety information for patients\n\n"
        "## 8. Monitoring Parameters\n"
        "   - Lab tests, clinical signs, follow-up intervals\n\n"
        "Format the entire report in clean Markdown."
    ),
    expected_output=(
        "A complete, professionally formatted Drug Safety Report in Markdown covering "
        "all 8 sections. The report should be comprehensive yet concise, suitable for "
        "distribution to healthcare providers."
    ),
    agent=safety_report_writer,
    context=[task_research, task_synthesize],   # <-- shared state from both agents
    callback=on_report_done,
)

# ─────────────────────────────────────────────────────────────────────────────
# CREW
# Process.sequential ensures Agent 1 -> Agent 2 -> Agent 3 order.
# memory=True activates CrewAI's built-in shared short-term memory store,
# allowing all agents to read and contribute to a common conversation context.
# ─────────────────────────────────────────────────────────────────────────────
crew = Crew(
    agents=[adverse_event_researcher, clinical_evidence_synthesizer, safety_report_writer],
    tasks=[task_research, task_synthesize, task_report],
    process=Process.sequential,
    # memory=True requires an OpenAI key (for gpt-4o-mini) or a configured LLM
    # for its entity/long-term analysis layer.  Inter-agent state sharing is
    # handled by context=[previous_task] on each Task, which is sufficient.
    memory=False,
    verbose=True,
    share_crew=False,
)

# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("  HEALTHCARE DRUG SAFETY MONITORING SYSTEM")
    print("  CrewAI  |  Amazon Bedrock  |  Serper Search")
    print("=" * 70)
    print(f"\n  Drug    : {drug.title()}")
    print(f"  Context : {condition.title()}")
    print(f"  Model   : {model_id}")
    print(f"  Process : Sequential (3 agents)")
    print("-" * 70 + "\n")

    result = crew.kickoff()

    print("\n" + "=" * 70)
    print("  FINAL DRUG SAFETY REPORT")
    print("=" * 70)
    print(result)

    print("\n" + "=" * 70)
    print("  SHARED STATE SNAPSHOT (post-run)")
    print("=" * 70)
    for key, value in shared_state.items():
        display = str(value)
        if len(display) > 120:
            display = display[:120] + "..."
        print(f"  {key:30s}: {display}")
    print("=" * 70)
