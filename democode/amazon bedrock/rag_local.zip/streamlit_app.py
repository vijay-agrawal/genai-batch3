import os
import boto3
import streamlit as st
from langchain_aws import BedrockEmbeddings, ChatBedrock
from langchain_chroma import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
import warnings
warnings.filterwarnings("ignore")

from dotenv import load_dotenv
load_dotenv()

CHROMA_PATH = os.path.join(os.path.dirname(__file__), "chroma_db_new2")

st.set_page_config(page_title="RAG Chat", page_icon="🔍", layout="wide")
st.title("RAG Question Answering")
st.caption("Powered by Amazon Bedrock + ChromaDB")

# --- Session state init ---
if "messages" not in st.session_state:
    st.session_state.messages = []
if "vector_store" not in st.session_state:
    st.session_state.vector_store = None

# --- Sidebar config ---
with st.sidebar:
    st.header("Settings")
    k = st.slider("Number of retrieved chunks (k)", min_value=1, max_value=10, value=3)
    model_id = st.selectbox(
        "Bedrock model",
        ["amazon.nova-micro-v1:0", "amazon.nova-lite-v1:0", "amazon.nova-pro-v1:0",
         "anthropic.claude-3-haiku-20240307-v1:0"],
        index=0,
    )
    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.rerun()

    st.divider()
    st.subheader("Vector DB")
    if st.button("Load / Reload vector store"):
        st.session_state.vector_store = None  # force reload

# --- Load vector store (cached in session state) ---
@st.cache_resource(show_spinner="Loading vector store...")
def get_vector_store(chroma_path):
    bedrock_client = boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )
    embeddings = BedrockEmbeddings(
        client=bedrock_client,
        model_id=os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0"),
    )
    return Chroma(persist_directory=chroma_path, embedding_function=embeddings)

try:
    vector_store = get_vector_store(CHROMA_PATH)
    with st.sidebar:
        st.success("Vector store loaded")
        count = vector_store._collection.count()
        st.metric("Chunks in DB", count)
except Exception as e:
    st.error(f"Failed to load vector store: {e}")
    st.stop()


def build_prompt_text(context_text: str, question: str) -> str:
    return f"""You are an assistant for question-answering tasks.
Use the following pieces of retrieved context to answer the question.
If you don't know the answer, say that you don't know.
Use three sentences maximum and keep the answer concise.

Context: {context_text}

Question: {question}

Answer:"""


def run_rag(question: str, k: int, model_id: str):
    bedrock_client = boto3.client(
        "bedrock-runtime",
        region_name=os.getenv("AWS_REGION", "us-east-1"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )
    llm = ChatBedrock(
        client=bedrock_client,
        model_id=model_id,
        model_kwargs={"temperature": 0},
    )
    retriever = vector_store.as_retriever(search_type="similarity", search_kwargs={"k": k})
    source_docs = retriever.invoke(question)
    context_text = "\n\n".join(doc.page_content for doc in source_docs)
    prompt_text = build_prompt_text(context_text, question)

    template = """You are an assistant for question-answering tasks.
Use the following pieces of retrieved context to answer the question.
If you don't know the answer, say that you don't know.
Use three sentences maximum and keep the answer concise.

Context: {context}

Question: {question}

Answer:"""
    prompt = ChatPromptTemplate.from_template(template)
    chain = prompt | llm | StrOutputParser()
    answer = chain.invoke({"context": context_text, "question": question})
    return answer, source_docs, prompt_text


# --- Render conversation history ---
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg["role"] == "assistant" and "chunks" in msg:
            with st.expander("Retrieved chunks", expanded=False):
                for i, chunk in enumerate(msg["chunks"], 1):
                    st.markdown(f"**Chunk {i}** — `{chunk.get('source', 'unknown')}`")
                    st.text(chunk["content"])
                    st.divider()
            with st.expander("Full prompt sent to LLM", expanded=False):
                st.code(msg["prompt_sent"], language="markdown")

# --- Chat input ---
if question := st.chat_input("Ask a question about your documents..."):
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("Retrieving and generating..."):
            try:
                answer, source_docs, prompt_text = run_rag(question, k, model_id)
            except Exception as e:
                st.error(f"Error: {e}")
                st.stop()

        st.markdown(answer)

        chunks_data = [
            {
                "content": doc.page_content,
                "source": doc.metadata.get("source", "unknown"),
            }
            for doc in source_docs
        ]

        with st.expander("Retrieved chunks", expanded=True):
            for i, chunk in enumerate(chunks_data, 1):
                st.markdown(f"**Chunk {i}** — `{chunk['source']}`")
                st.text(chunk["content"])
                st.divider()

        with st.expander("Full prompt sent to LLM", expanded=False):
            st.code(prompt_text, language="markdown")

    st.session_state.messages.append({
        "role": "assistant",
        "content": answer,
        "chunks": chunks_data,
        "prompt_sent": prompt_text,
    })
