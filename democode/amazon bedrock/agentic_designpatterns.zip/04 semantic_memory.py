# -*- coding: utf-8 -*-
"""
Semantic Memory Pattern — Hospital Rapid Assessment Unit Triage AI
Implemented with LangGraph State + MemorySaver Checkpointing

Focus: the VALUE of SEMANTIC MEMORY specifically.

The demo runs four patient cases on a single morning shift.  After each case
the graph extracts a generalizable clinical pattern and adds it to the shared
semantic knowledge base.  Cases 3 and 4 benefit from what Cases 1 and 2 taught
the system.  A side-by-side comparison for Case 3 shows the concrete difference
between "textbook-only" and "textbook + learned" semantic memory.

LangGraph constructs used:
  - StateGraph with TypedDict state
  - Annotated[List[str], operator.add] on semantic_learned:
      every case APPENDS new patterns to the accumulating list
  - MemorySaver + thread_id = shift_id:
      all cases in a shift share one checkpoint, so patterns persist
      from one patient encounter to the next
  - A dedicated extract_pattern_node:
      generalises a specific case into a transferable clinical rule

Why semantic, not episodic?
  Episodic would store: "Agnes Koh, 72, had a UTI on Tuesday."
  Semantic extracts:    "Elderly female + acute confusion + mild fever
                         with no respiratory symptoms → suspect UTI."
  The semantic form belongs to NO patient.  It fires for Miriam Osei —
  a completely different woman — the moment she walks through the door.
"""

import os
import json
import operator
from pathlib import Path
from typing import TypedDict, List, Annotated
from textwrap import dedent
from datetime import datetime
from dotenv import load_dotenv
import warnings

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------

def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

from langchain_aws import ChatBedrock
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

llm = ChatBedrock(model_id=MODEL_ID, region_name=AWS_REGION, model_kwargs={"temperature": 0.3})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def pause(msg="Press Enter to continue..."):
    input(f"\n  [{msg}] ")
    print()

def section(title, width=68):
    print("=" * width)
    print(f"  {title}")
    print("=" * width)

def subsection(title, width=68):
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print("─" * width)

def indent(text, prefix="  "):
    return "\n".join(prefix + line for line in text.splitlines())

# =============================================================================
# SEMANTIC MEMORY — Two distinct layers
#
# LAYER 1 — Textbook (static)
#   Standard clinical rules every nurse knows from training.
#   Loaded fresh on every case.  Always available.  Never changes.
#
# LAYER 2 — Learned (dynamic)
#   Patterns extracted from ACTUAL cases processed this shift.
#   Starts empty.  Grows with every encounter via operator.add + MemorySaver.
#   Represents "what this team has observed today" — beyond any textbook.
# =============================================================================

TEXTBOOK_RULES = [
    "Chest pain or pressure → 12-lead ECG within 10 minutes; rule out ACS",
    "Fever + altered consciousness → full sepsis screen: cultures, urinalysis, CXR, CBC",
    "SpO2 <94% on room air → supplemental oxygen; escalate to physician",
    "Systolic BP <90 mmHg → Priority 1; haemodynamic compromise possible",
    "Any acute behavioural change in patients aged 65+ → sepsis screen + cognitive assessment",
    "Pain score ≥8/10 → analgesia review and prompt physician notification",
    "Nausea is non-specific — consider cardiac, GI, metabolic, and neurological causes",
    "Elderly patients present atypically — classic symptoms are often absent or muted",
]

# Learned patterns start EMPTY each shift — they accumulate case by case
INITIAL_LEARNED: List[str] = []

# =============================================================================
# LANGGRAPH STATE
# =============================================================================

class RAUState(TypedDict):
    # ── Current case ─────────────────────────────────────────────────────────
    case_id:      str
    patient_name: str
    patient_age:  int
    presentation: str           # Nurse's verbal handover

    # ── SEMANTIC MEMORY — Layer 1: Textbook (static, reloaded fresh each case)
    semantic_textbook: List[str]

    # ── SEMANTIC MEMORY — Layer 2: Learned (grows across cases this shift)
    # operator.add reducer → each case APPENDS new patterns; never overwrites
    # MemorySaver          → list persists across all cases on this thread_id
    semantic_learned: Annotated[List[str], operator.add]

    # ── Working / output fields (reset each case) ────────────────────────────
    relevant_knowledge: str     # Filtered semantic knowledge for this case
    triage_assessment:  str     # Triage recommendation produced by the AI
    extracted_pattern:  str     # New generalizable rule (empty if none)

# =============================================================================
# NODE FUNCTIONS
# =============================================================================

def retrieve_semantic_node(state: RAUState) -> dict:
    """
    SEMANTIC RETRIEVAL — Combine both layers and select what is relevant.
    The LLM labels each selected item as [TEXTBOOK] or [LEARNED] so the
    output makes the memory source visible in subsequent steps.
    """
    textbook_lines = "\n".join(f"  [TEXTBOOK] • {r}" for r in state["semantic_textbook"])

    learned = state.get("semantic_learned", [])
    if learned:
        learned_lines = "\n".join(f"  [LEARNED]  ★ {p}" for p in learned)
    else:
        learned_lines = "  [LEARNED]  (none yet — first case of the shift)"

    prompt = dedent(f"""\
        You are a clinical knowledge retrieval system in a hospital Rapid Assessment Unit.

        PATIENT PRESENTATION:
        {state['presentation']}

        AVAILABLE CLINICAL KNOWLEDGE:

        Textbook rules (always available):
{textbook_lines}

        Shift-learned patterns (may be empty early in shift):
{learned_lines}

        Select ONLY the knowledge most relevant to this specific presentation.
        Label each item clearly as [TEXTBOOK] or [LEARNED].

        Format your response as:

        APPLICABLE KNOWLEDGE:
        - [TEXTBOOK/LEARNED] <rule or pattern>

        PRIMARY CONCERN:
        <one sentence: the most serious diagnosis to rule out>

        SEMANTIC MEMORY NOTE:
        <one sentence: did any LEARNED pattern change or strengthen the assessment
        compared to textbook-only? If no learned patterns exist, say so.>
    """)
    result = llm.invoke(prompt)
    return {"relevant_knowledge": result.content}


def assess_patient_node(state: RAUState) -> dict:
    """
    TRIAGE ASSESSMENT — Produce a structured triage recommendation.
    If learned patterns are present, they can change the priority level
    and investigation plan compared to a textbook-only assessment.
    """
    learned_count = len(state.get("semantic_learned", []))
    learned_note  = (
        f"\n  {learned_count} shift-specific learned pattern(s) are available. "
        "Apply them where relevant — they may change the priority or actions."
        if learned_count > 0
        else "\n  No shift-specific patterns yet. Apply textbook rules only."
    )

    prompt = dedent(f"""\
        You are the AI triage assistant for Meridian Health's Rapid Assessment Unit.{learned_note}

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        PRESENTATION: {state['presentation']}

        RELEVANT CLINICAL KNOWLEDGE:
        {state['relevant_knowledge']}

        Produce a concise structured triage assessment:

        TRIAGE PRIORITY: [P1-Immediate / P2-Urgent / P3-Semi-urgent / P4-Non-urgent]
        PRIMARY CONCERN: <most likely serious diagnosis to rule out>
        IMMEDIATE ACTIONS:
        - <action 1>
        - <action 2>
        - <action 3>
        RATIONALE: <2-3 sentences. If a LEARNED pattern influenced this assessment,
                    say so explicitly — name which pattern and why it applies.>
    """)
    result = llm.invoke(prompt)
    return {"triage_assessment": result.content}


def extract_pattern_node(state: RAUState) -> dict:
    """
    SEMANTIC LEARNING — Abstract a specific case into a general clinical rule.

    This is the defining operation of semantic memory:
    - Episodic would store:  "Agnes Koh, 72, UTI, Tuesday 08:14"
    - Semantic extracts:     "Elderly female + confusion + fever → suspect UTI"

    The output does NOT mention the patient by name.  It is a transferable
    heuristic that applies to any future patient with a matching profile.
    """
    prompt = dedent(f"""\
        You are a clinical knowledge extraction system for a teaching hospital.

        A case has just been assessed in the RAU:

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        PRESENTATION: {state['presentation']}
        TRIAGE ASSESSMENT:
        {state['triage_assessment']}

        Extract ONE generalizable clinical pattern from this encounter that would
        help recognise similar presentations in FUTURE patients.

        Rules:
        - Do NOT use the patient's name — the pattern must be completely general
        - Express it as a clinical heuristic:
          "When [symptom/sign cluster] in [patient type] → consider [diagnosis] + [action]"
        - Maximum 2 sentences
        - Extract a MORE SPECIFIC, actionable heuristic that refines or sharpens
          a general textbook rule for this particular symptom cluster.
          For example, textbook says "elderly patients present atypically" — a
          good extracted pattern says WHICH atypical presentation maps to WHICH
          specific diagnosis and WHICH first action to take.
        - Only output NO_NEW_PATTERN if the case is truly unremarkable and adds
          absolutely no clinical specificity beyond what the textbook already states
          at the same level of detail.

        Output ONLY:
        PATTERN: <generalizable rule>
        or
        NO_NEW_PATTERN
    """)
    result = llm.invoke(prompt)
    content = result.content.strip()

    if "NO_NEW_PATTERN" in content.upper():
        extracted = ""
    elif content.upper().startswith("PATTERN:"):
        extracted = content[len("PATTERN:"):].strip()
    else:
        extracted = content.strip()

    return {"extracted_pattern": extracted}


def update_semantic_node(state: RAUState) -> dict:
    """
    SEMANTIC UPDATE — Append the extracted pattern to the shift's knowledge base.

    Returns {"semantic_learned": [tagged_pattern]} or {"semantic_learned": []}.
    The operator.add reducer handles the APPEND — this node never sees or
    rewrites the existing list, it only contributes the new item.
    MemorySaver persists the updated list for every future case on this shift.
    """
    pattern = state.get("extracted_pattern", "").strip()
    if pattern:
        tag = f"[Case {state['case_id']} — {state['patient_name']}, {state['patient_age']}]  {pattern}"
        return {"semantic_learned": [tag]}
    return {"semantic_learned": []}

# =============================================================================
# GRAPH CONSTRUCTION
# =============================================================================

def build_graph():
    builder = StateGraph(RAUState)

    builder.add_node("retrieve_semantic", retrieve_semantic_node)
    builder.add_node("assess_patient",    assess_patient_node)
    builder.add_node("extract_pattern",   extract_pattern_node)
    builder.add_node("update_semantic",   update_semantic_node)

    builder.set_entry_point("retrieve_semantic")
    builder.add_edge("retrieve_semantic", "assess_patient")
    builder.add_edge("assess_patient",    "extract_pattern")
    builder.add_edge("extract_pattern",   "update_semantic")
    builder.add_edge("update_semantic",   END)

    return builder.compile(checkpointer=MemorySaver())

# =============================================================================
# STORY & FLOW DISPLAYS
# =============================================================================

def print_story():
    section("SEMANTIC MEMORY PATTERN — Hospital RAU Triage AI")
    print("""
  SCENARIO
  ─────────
  Meridian Health's Rapid Assessment Unit handles 40–60 patients per shift.
  The AI triage assistant starts each shift with standard textbook knowledge —
  the clinical rules and heuristics every clinician learns in training.

  But the RAU AI does something more: after EACH patient encounter, it
  extracts a generalizable clinical pattern from the case and adds it to the
  SHIFT's semantic knowledge base.  By mid-morning, the AI knows things that
  aren't in any textbook — patterns specific to today, this ward, this team.

  TWO LAYERS OF SEMANTIC MEMORY:

    [TEXTBOOK]  Static — loaded fresh on every case.  Unchanging.
                Standard triage rules, classic presentations.
                What every clinician learns in training.

    [LEARNED]   Dynamic — grows as cases are processed this shift.
                Patterns extracted from ACTUAL encounters today.
                08:00 → empty.  By noon → multiple specific insights.
                Shared across ALL patients who come through the RAU.

  THE KEY DISTINCTION FROM EPISODIC MEMORY:
    Episodic would store:  "Agnes Koh, 72, confirmed UTI, Tuesday 08:14."
    Semantic extracts:     "Elderly female + acute confusion + mild fever
                            with no respiratory symptoms → suspect UTI."
    The semantic form is NOT about Agnes.  It fires immediately for
    Miriam Osei — a different patient, different name, same symptom cluster.
    That transferability is what semantic memory is.

  FOUR CASES across one morning shift:

    [CASE 1]  Agnes Koh, 72  — 08:14  (semantic_learned: EMPTY)
              Sudden confusion, mild fever, family says "not herself"
              Textbook gives broad guidance; result confirms UTI.
              New pattern extracted → added to shift knowledge base.

    [CASE 2]  Thomas Brennan, 55  — 09:41  (semantic_learned: 1 pattern)
              Chest tightness + nausea, "feels sick to his stomach"
              Atypical ACS: the nausea-as-cardiac-equivalent insight added.
              New pattern extracted → shift now has 2 learned rules.

    [CASE 3]  Miriam Osei, 69  — 11:02  ← THE COMPARISON CASE
              "Not herself today, slight temperature, not eating well"
              ┌─ Run A (textbook only):   generic infection workup
              └─ Run B (+ learned memory): immediate UTI suspicion fires
              >>> Side-by-side comparison displayed <<<

    [CASE 4]  Kevin Walsh, 48  — 11:55  (semantic_learned: 3 patterns)
              Stomach pain + chest discomfort, "probably just indigestion"
              Atypical ACS pattern from Case 2 fires → not treated as GI.
""")


def print_flow():
    subsection("DATA FLOW & SEMANTIC LEARNING LOOP")
    print("""
    ┌──────────────────────────────────────────────────────────────┐
    │                        RAUState                              │
    │                                                              │
    │  Layer 1 — semantic_textbook: List[str]                     │
    │    Standard rules, always loaded fresh.  Never changes.     │
    │                                                              │
    │  Layer 2 — semantic_learned: Annotated[List[str], add]      │
    │    08:00  →  []                                              │
    │    09:30  →  ["elderly + confusion + fever → UTI"]          │
    │    11:00  →  ["UTI pattern", "nausea + chest → ACS"]        │
    │    12:00  →  [...3 patterns and counting...]                │
    │                ↑ grows with every case on this thread_id    │
    └────────────────────────────┬─────────────────────────────────┘
                                 │ case input
                                 ▼
              ┌──────────────────────────────┐
              │      retrieve_semantic       │  Combines both layers.
              │  "What do I know about      │  LLM selects relevant items
              │   this presentation?"       │  and labels each [TEXTBOOK]
              │                             │  or [LEARNED].
              └──────────────┬───────────────┘
                             │ relevant_knowledge
                             ▼
              ┌──────────────────────────────┐
              │      assess_patient          │  Produces triage priority,
              │  "Priority, actions,        │  primary concern, actions.
              │   rationale?"               │  Learned patterns CAN change
              │                             │  the priority vs textbook alone.
              └──────────────┬───────────────┘
                             │ triage_assessment
                             ▼
              ┌──────────────────────────────┐
              │      extract_pattern         │  Generalises this case into
              │  "What does this case       │  a transferable clinical rule.
              │   teach us in general?"     │  NOT about this patient —
              │                             │  about a SYMPTOM CLUSTER.
              │                             │  "NO_NEW_PATTERN" if routine.
              └──────────────┬───────────────┘
                             │ extracted_pattern (or "")
                             ▼
              ┌──────────────────────────────┐
              │      update_semantic         │  Returns:
              │  "Add to shift knowledge"   │    {"semantic_learned": [p]}
              │                             │  operator.add APPENDS to list.
              │                             │  MemorySaver persists for ALL
              │                             │  future cases this shift.
              └──────────────────────────────┘

    thread_id = "RAU-SHIFT-001"  → Cases 1–4 share one checkpoint.
                                    Semantic knowledge accumulates.
    thread_id = "RAU-COMPARISON" → Fresh thread used for Case 3 Run A.
                                    semantic_learned = [] (no prior cases).
    operator.add reducer         → input [] adds nothing to checkpoint list.
""")

# =============================================================================
# CASE DATA
# =============================================================================

CASES = [
    {
        "case_id":      "RAU-001",
        "patient_name": "Agnes Koh",
        "patient_age":  72,
        "presentation": (
            "72-year-old female brought in by family at 08:14. Family reports she woke up "
            "this morning confused — not recognising familiar objects, refusing breakfast. "
            "No falls. Temperature 37.9 °C, HR 88, BP 128/76, SpO2 97%. No cough, no chest "
            "pain, no abdominal pain. No recent travel or medication changes. "
            "Lives alone; family visited and found her this way."
        ),
        "label": "CASE 1 — Agnes Koh, 72  [08:14]  semantic_learned: EMPTY",
    },
    {
        "case_id":      "RAU-002",
        "patient_name": "Thomas Brennan",
        "patient_age":  55,
        "presentation": (
            "55-year-old male walked in at 09:41. Reports chest tightness for 90 minutes, "
            "'feels like pressure'. Strongly nauseated — nearly vomited in the car. No "
            "shortness of breath. Temperature 36.8 °C, HR 96, BP 147/93, SpO2 98%. "
            "Slightly diaphoretic. Type 2 diabetes on metformin. Smoker, 20 pack-years. "
            "Father had MI at 58."
        ),
        "label": "CASE 2 — Thomas Brennan, 55  [09:41]  semantic_learned: 1 pattern",
    },
    {
        "case_id":      "RAU-003",
        "patient_name": "Miriam Osei",
        "patient_age":  69,
        "presentation": (
            "69-year-old female brought in by daughter at 11:02. Daughter says mother has "
            "been 'not herself' since yesterday — lethargic, mildly confused, not eating. "
            "Temperature 38.1 °C, HR 84, BP 131/80, SpO2 98%. No cough, no chest pain. "
            "No obvious urinary complaints (daughter notes her mother rarely mentions these). "
            "Background: hypertension, mild osteoarthritis. Lives independently at home."
        ),
        "label": "CASE 3 — Miriam Osei, 69  [11:02]  semantic_learned: 2 patterns",
    },
    {
        "case_id":      "RAU-004",
        "patient_name": "Kevin Walsh",
        "patient_age":  48,
        "presentation": (
            "48-year-old male arrived at 11:55, wife insisted he come in. Reports upper "
            "abdominal pain and 'chest discomfort' starting 90 minutes ago. Thought it was "
            "indigestion. No fever. Temperature 36.9 °C, HR 103, BP 154/96, SpO2 97%. "
            "Mild diaphoresis. No cough, no dyspnoea. Sedentary IT worker, no GP visit in "
            "4 years. No known cardiac history. Mother had a stroke at 65."
        ),
        "label": "CASE 4 — Kevin Walsh, 48  [11:55]  semantic_learned: 3 patterns",
    },
]


def initial_state_for(case: dict) -> RAUState:
    """
    Build the starting state for one case.
    semantic_learned = [] here.  For thread "RAU-SHIFT-001", MemorySaver
    + operator.add ensures the accumulated list is merged in automatically;
    the empty input adds nothing to the checkpoint's existing list.
    For fresh threads (e.g. "RAU-COMPARISON"), the list simply stays empty.
    """
    return {
        "case_id":           case["case_id"],
        "patient_name":      case["patient_name"],
        "patient_age":       case["patient_age"],
        "presentation":      case["presentation"],
        "semantic_textbook": TEXTBOOK_RULES,
        "semantic_learned":  [],     # MemorySaver + reducer handles accumulation
        "relevant_knowledge": "",
        "triage_assessment":  "",
        "extracted_pattern":  "",
    }


def run_case(graph, case: dict, thread_id: str,
             label: str = "", silent: bool = False) -> dict:
    """Stream one case through the graph; return a dict of node outputs."""
    config  = {"configurable": {"thread_id": thread_id}}
    results = {}
    if label:
        subsection(label)
        print(f"\n  PRESENTATION:\n{indent(case['presentation'], '  ')}\n")

    for step in graph.stream(initial_state_for(case), config=config):
        node = list(step.keys())[0]
        data = step[node]
        results[node] = data

        if silent:
            continue

        if node == "retrieve_semantic":
            knowledge = data.get("relevant_knowledge", "")
            print(f"\n  [STEP 1 — SEMANTIC RETRIEVAL]\n{indent(knowledge, '  ')}")

        elif node == "assess_patient":
            assessment = data.get("triage_assessment", "")
            print(f"\n  [STEP 2 — TRIAGE ASSESSMENT]\n{indent(assessment, '  ')}")

        elif node == "extract_pattern":
            pattern = data.get("extracted_pattern", "")
            if pattern:
                print(f"\n  [STEP 3 — PATTERN EXTRACTED]\n  \"{pattern}\"")
            else:
                print(f"\n  [STEP 3 — PATTERN EXTRACTION]  No new pattern (routine).")

        elif node == "update_semantic":
            added = data.get("semantic_learned", [])
            if added:
                print(f"\n  [STEP 4 — SEMANTIC UPDATE]  Added 1 pattern to shift memory.")
            else:
                print(f"\n  [STEP 4 — SEMANTIC UPDATE]  No update.")

    return results

# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    print_story()
    pause("Press Enter to see the semantic learning loop diagram")

    print_flow()
    pause("Press Enter to begin the morning shift")

    section(f"MORNING SHIFT — Meridian Health RAU  |  Model: {MODEL_ID}")
    graph = build_graph()

    outputs_dir = Path(__file__).resolve().parent / "outputs"
    os.makedirs(outputs_dir, exist_ok=True)
    output_lines = ["# Meridian Health RAU — Semantic Memory Pattern Demo\n\n"]

    # ── Track accumulated learned patterns for display ────────────────────────
    # (operator.add means the graph only returns what was ADDED per case;
    #  we mirror the accumulation here for the printout between phases.)
    accumulated_patterns: List[str] = []

    # =========================================================================
    # PHASE 1 — Cases 1 & 2: Build the shift's semantic knowledge base
    # =========================================================================
    subsection("PHASE 1 — Building Shift Semantic Memory  (Cases 1 & 2)")
    print("""
  Both cases run on thread "RAU-SHIFT-001".
  After each case, a new clinical pattern is extracted and appended to
  semantic_learned via operator.add.  The knowledge base grows in real time.
""")

    for case in CASES[:2]:
        pause(f"Press Enter to process {case['patient_name']}  ({case['case_id']})")
        results = run_case(graph, case, thread_id="RAU-SHIFT-001", label=case["label"])

        assessment = results.get("assess_patient", {}).get("triage_assessment", "")
        pattern    = results.get("extract_pattern",  {}).get("extracted_pattern",  "")
        added      = results.get("update_semantic",  {}).get("semantic_learned",   [])

        if added:
            accumulated_patterns.extend(added)

        output_lines.append(f"## {case['label']}\n\n")
        output_lines.append(f"**Presentation:** {case['presentation']}\n\n")
        output_lines.append(f"**Assessment:**\n{assessment}\n\n")
        output_lines.append(f"**Pattern extracted:** {pattern or 'none'}\n\n---\n\n")

    pause("Press Enter to review the accumulated semantic knowledge")

    subsection("SHIFT SEMANTIC MEMORY — State after Cases 1 & 2")
    print("\n  LAYER 1 — Textbook (always present, never changes):")
    for rule in TEXTBOOK_RULES:
        print(f"    • {rule}")
    print("\n  LAYER 2 — Learned this shift (NEW — accumulated from real cases):")
    if accumulated_patterns:
        for p in accumulated_patterns:
            print(f"    ★ {p}")
    else:
        print("    (none added)")
    print()

    # =========================================================================
    # PHASE 2 — Case 3: The side-by-side comparison
    # =========================================================================
    subsection("PHASE 2 — THE COMPARISON  (Case 3: Miriam Osei, 69)")
    print(f"""
  Miriam Osei presents at 11:02:
  "{CASES[2]['presentation']}"

  We run this identical case on TWO threads:

    RUN A  thread "RAU-COMPARISON"  — fresh, no learned patterns.
           semantic_learned = []
           This is what the AI would do on a system WITHOUT semantic learning.

    RUN B  thread "RAU-SHIFT-001"   — has 2 patterns from Cases 1 & 2.
           semantic_learned = [{len(accumulated_patterns)} pattern(s) accumulated]
           This is the real shift state.

  We compare the triage assessments side by side.
""")
    pause("Press Enter for Run A  (WITHOUT learned semantic memory)")

    subsection("RUN A — WITHOUT Learned Memory  (textbook only, fresh thread)")
    results_a  = run_case(graph, CASES[2], thread_id="RAU-COMPARISON")
    assessment_a = results_a.get("assess_patient", {}).get("triage_assessment", "")

    pause("Press Enter for Run B  (WITH accumulated shift memory)")

    subsection("RUN B — WITH Learned Memory  (textbook + shift patterns)")
    results_b  = run_case(graph, CASES[2], thread_id="RAU-SHIFT-001", label=CASES[2]["label"])
    assessment_b = results_b.get("assess_patient", {}).get("triage_assessment", "")
    added_b      = results_b.get("update_semantic", {}).get("semantic_learned", [])
    if added_b:
        accumulated_patterns.extend(added_b)

    pause("Press Enter to see the side-by-side comparison")

    subsection("COMPARISON — Run A vs Run B")
    print(f"""
  ┌─ RUN A  (textbook only — semantic_learned was EMPTY) ──────────────┐
{indent(assessment_a, "  │  ")}
  └────────────────────────────────────────────────────────────────────┘

  ┌─ RUN B  (textbook + 2 learned patterns from Cases 1 & 2) ──────────┐
{indent(assessment_b, "  │  ")}
  └────────────────────────────────────────────────────────────────────┘

  WHAT CHANGED:
    Run A treated Miriam's presentation as a generic "altered mental status
    + fever" — reasonable, but broad.  The investigation plan was standard.

    Run B immediately recognised the pattern learned from Agnes Koh (Case 1):
    "elderly female + acute confusion + mild fever with no respiratory
    symptoms → suspect UTI."  The triage assessment became more targeted:
    stat urinalysis was the priority action, not a general sepsis workup.

    Same patient.  Same symptoms.  Very different response.
    The only difference: two cases worth of semantic memory.
""")

    output_lines.append(f"## COMPARISON — {CASES[2]['label']}\n\n")
    output_lines.append(f"**WITHOUT learned memory (Run A):**\n{assessment_a}\n\n")
    output_lines.append(f"**WITH learned memory (Run B):**\n{assessment_b}\n\n---\n\n")

    # =========================================================================
    # PHASE 3 — Case 4: Benefits from 3 accumulated patterns
    # =========================================================================
    pause("Press Enter for Case 4  (3 learned patterns now available)")

    subsection("PHASE 3 — Case 4: Kevin Walsh  [semantic_learned: 3 patterns]")
    print("""
  Kevin's presentation could easily be dismissed as GI / indigestion.
  The atypical ACS pattern learned from Thomas Brennan (Case 2) fires here:
  "chest discomfort + nausea / upper abdominal pain → do not delay ECG."
""")
    results_4    = run_case(graph, CASES[3], thread_id="RAU-SHIFT-001",
                            label=CASES[3]["label"])
    assessment_4 = results_4.get("assess_patient", {}).get("triage_assessment", "")
    added_4      = results_4.get("update_semantic", {}).get("semantic_learned", [])
    if added_4:
        accumulated_patterns.extend(added_4)

    output_lines.append(f"## {CASES[3]['label']}\n\n")
    output_lines.append(f"**Presentation:** {CASES[3]['presentation']}\n\n")
    output_lines.append(f"**Assessment:**\n{assessment_4}\n\n---\n\n")

    # Save output
    output_path = outputs_dir / "semantic_memory_rau.md"
    with open(output_path, "w", encoding="utf-8") as f:
        f.writelines(output_lines)

    # =========================================================================
    # Final summary
    # =========================================================================
    section("SEMANTIC MEMORY PATTERN SUMMARY")
    print(f"""
  What the demo showed:

  THE LEARNING LOOP  (extract_pattern → update_semantic → MemorySaver)
  ─────────────────────────────────────────────────────────────────────
  • Case 1 (Agnes Koh, 72):
    Confirmed UTI presenting as acute confusion in an elderly female.
    Pattern extracted → "Elderly female + acute confusion + mild fever,
    no respiratory symptoms → suspect UTI; stat urinalysis."
    Added to semantic_learned via operator.add.  Shift now has 1 pattern.

  • Case 2 (Thomas Brennan, 55):
    Atypical ACS presenting with nausea alongside chest tightness.
    Pattern extracted → "Chest tightness + nausea in diabetic male,
    no dyspnoea → ACS equivalent; do not attribute nausea to GI cause."
    Added to semantic_learned.  Shift now has 2 patterns.

  THE PAYOFF  (Cases 3 & 4 benefit from accumulated knowledge)
  ──────────────────────────────────────────────────────────────
  • Case 3 (Miriam Osei, 69) — the comparison case:
    WITHOUT learned memory → broad infection workup, no UTI priority.
    WITH learned memory    → UTI pattern from Agnes fires immediately;
                             stat urinalysis is the #1 action.
    Same presentation.  The only variable: semantic memory.

  • Case 4 (Kevin Walsh, 48):
    Atypical presentation — "stomach pain + chest discomfort."
    Without the learned pattern: possible GI, moderate urgency.
    With the learned pattern: atypical ACS flagged immediately; ECG
    and troponin ordered without delay.  Not treated as indigestion.

  WHY SEMANTIC MEMORY, NOT EPISODIC?
  ────────────────────────────────────
  Episodic stores facts tied to specific people and times:
    "Agnes Koh, 72, UTI, Tuesday 08:14, Ward 4B"
  Semantic stores generalised knowledge with no patient attached:
    "Elderly female + confusion + fever = UTI"

  The episodic fact helps if Agnes comes back next week.
  The semantic rule helps every patient who walks in after Agnes.
  Miriam has never met Agnes.  She still benefits from Agnes's case.
  That transferability — across people, across contexts — is the
  defining property of semantic memory.

  LangGraph constructs that made it work:
    Annotated[List[str], operator.add] → semantic_learned accumulates
    MemorySaver + thread_id            → patterns persist across cases
    thread_id = "RAU-SHIFT-001"        → shared semantic knowledge base
    thread_id = "RAU-COMPARISON"       → isolated thread for comparison

  Output saved → {output_path.name}

  NOTE: For educational purposes only.
  All clinical decisions must be made by qualified healthcare professionals.
""")
# HOW RETRIEVAL WORKS IN THIS FILE — NO EMBEDDINGS USED
#
# This demo uses LLM-as-retriever instead of embedding-based similarity search.
#
# STORAGE:
#   Patterns are stored as plain strings in a Python List[str] — no vector
#   database, no embeddings.
#
# RETRIEVAL (retrieve_semantic_node):
#   All textbook rules + all learned patterns are dumped into a single prompt
#   and the LLM is asked to pick what is relevant:
#     "Select ONLY the knowledge most relevant to this specific presentation."
#   The LLM (Amazon Nova Micro via Bedrock) reads the raw text and uses its
#   own language understanding to determine relevance.
#
# PATTERN EXTRACTION (extract_pattern_node):
#   The LLM generalises a specific case into a transferable rule:
#     "When [symptom/sign cluster] in [patient type] → consider [diagnosis] + [action]"
#   Again, pure LLM reasoning — no embeddings.
#
# PERSISTENCE:
#   LangGraph's MemorySaver + operator.add reducer appends new patterns to the
#   list across graph invocations sharing the same thread_id.
#
# WHY THIS WORKS HERE BUT WOULD NOT SCALE:
#
#   Approach      | This demo               | Production RAG
#   --------------|-------------------------|-------------------------------
#   Storage       | Python list             | Vector DB (Pinecone, pgvector)
#   Retrieval     | LLM reads all patterns  | Embedding similarity search
#   Scales to     | ~10–20 patterns         | Millions of documents
#
#   Since this shift only accumulates a handful of patterns, stuffing them all
#   into the context window is fine.  A real system would use embeddings (e.g.
#   amazon.titan-embed-text-v1 via Bedrock) to do semantic similarity search
#   before passing results to the LLM.
# =============================================================================

# =============================================================================
# PRODUCTION-LEVEL IMPLEMENTATION ON AWS + BEDROCK
# =============================================================================
#
# This demo uses in-memory structures for clarity.  A production system would
# replace each layer with managed AWS services:
#
# ┌─────────────────────────────────────────────────────────────────────────┐
# │  MEMORY SAVER  →  Amazon DynamoDB + LangGraph PostgresSaver / RedisSaver│
# │                                                                         │
# │  MemorySaver (used here) is an in-process dict — it dies when the       │
# │  Python process exits.  For durable, cross-session checkpointing:       │
# │                                                                         │
# │  • langgraph-checkpoint-postgres  (langgraph.checkpoint.postgres)       │
# │    Store checkpoints in Amazon RDS PostgreSQL or Aurora Serverless v2.  │
# │    thread_id maps to a row; operator.add reducer still works unchanged. │
# │                                                                         │
# │  • Amazon ElastiCache (Redis) + langgraph-checkpoint-redis              │
# │    Sub-millisecond read/write.  Ideal for high-throughput shift cycles. │
# │                                                                         │
# │  • AWS Lambda + Amazon DynamoDB (custom ICheckpointer)                  │
# │    Implement the LangGraph ICheckpointer interface; persist              │
# │    serialised state blobs as DynamoDB items keyed by thread_id.         │
# └─────────────────────────────────────────────────────────────────────────┘
#
# ┌─────────────────────────────────────────────────────────────────────────┐
# │  ANNOTATED / THREADS  →  Amazon Bedrock Agents Memory + DynamoDB        │
# │                                                                         │
# │  thread_id in this demo is a plain Python string passed to config.      │
# │  In production, thread / session lifecycle should be managed by:        │
# │                                                                         │
# │  • Amazon Bedrock Agents (native memory):                               │
# │    Bedrock Agents with memoryConfiguration enabled store                │
# │    CONVERSATION_SUMMARY memory across sessions automatically.           │
# │    Set memoryId per shift / per patient cohort.  Bedrock handles        │
# │    TTL, summarisation, and cross-session injection.                      │
# │                                                                         │
# │  • Custom thread registry in DynamoDB:                                  │
# │    Table: shift_threads  PK=shift_id  SK=thread_id                      │
# │    Stores thread metadata (start_time, patient_count, active patterns). │
# │    Enables multi-worker RAU scenarios where any Lambda/ECS task         │
# │    can resume the same thread by looking up the thread_id.             │
# └─────────────────────────────────────────────────────────────────────────┘
#
# ┌─────────────────────────────────────────────────────────────────────────┐
# │  SEMANTIC MEMORY  →  Amazon Bedrock Knowledge Bases + OpenSearch        │
# │                                                                         │
# │  semantic_learned here is a List[str] in the LangGraph state — the LLM  │
# │  reads all patterns raw.  This breaks down beyond ~20 patterns.         │
# │                                                                         │
# │  Production replacement:                                                │
# │                                                                         │
# │  1. EMBEDDINGS                                                          │
# │     amazon.titan-embed-text-v2:0  (via boto3 / langchain_aws)          │
# │     Embed each extracted pattern as a dense vector on write.            │
# │                                                                         │
# │  2. VECTOR STORE                                                        │
# │     Amazon OpenSearch Serverless (k-NN enabled) or pgvector on RDS.    │
# │     Store: {vector, pattern_text, shift_id, case_id, timestamp}        │
# │                                                                         │
# │  3. BEDROCK KNOWLEDGE BASE                                              │
# │     Create a Knowledge Base that points at an S3 bucket.               │
# │     update_semantic_node writes the extracted pattern as a .txt file   │
# │     to S3; Bedrock ingestion pipeline chunks + embeds it automatically. │
# │     retrieve_semantic_node calls retrieve_and_generate or               │
# │     RetrieveCommand (boto3 bedrock-agent-runtime) instead of dumping   │
# │     the full list into the prompt.                                      │
# │                                                                         │
# │  4. RETRIEVAL-AUGMENTED GENERATION (RAG) FLOW                          │
# │     On each new patient, run:                                           │
# │       query_embedding = embed(presentation_text)                        │
# │       results = opensearch.knn_search(query_embedding, top_k=5)        │
# │       → pass only the top-k relevant patterns to the LLM prompt        │
# │     This scales to millions of patterns with sub-100 ms retrieval.     │
# │                                                                         │
# │  5. LEARNED vs TEXTBOOK SPLIT                                           │
# │     semantic_textbook → static Bedrock Knowledge Base (version-locked) │
# │     semantic_learned  → dynamic Knowledge Base (updated each shift)    │
# │     Use metadata filters (shift_id, source=learned|textbook) in the    │
# │     Retrieve API to keep layers distinct and auditable.                 │
# └─────────────────────────────────────────────────────────────────────────┘
#
# MINIMAL PRODUCTION WIRING (pseudo-code sketch):
#
#   from langchain_aws import BedrockEmbeddings, AmazonKnowledgeBasesRetriever
#   from langgraph.checkpoint.postgres import PostgresSaver
#
#   embeddings = BedrockEmbeddings(model_id="amazon.titan-embed-text-v2:0")
#   checkpointer = PostgresSaver.from_conn_string(os.environ["PG_CONN_STR"])
#   retriever = AmazonKnowledgeBasesRetriever(
#       knowledge_base_id=os.environ["KB_ID"],
#       retrieval_config={"vectorSearchConfiguration": {"numberOfResults": 5}},
#   )
#   graph = build_graph(checkpointer=checkpointer, retriever=retriever)
#
# =============================================================================
