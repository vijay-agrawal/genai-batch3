# -*- coding: utf-8 -*-
"""
Hierarchical Agent Pattern with Critic Feedback Loop
Implemented with LangGraph conditional edges and multi-level agent hierarchy

Pattern:
  Agents are organised in THREE levels.  Work flows bottom-up through
  the hierarchy.  A Critic agent reviews the top-level output and can
  route feedback back to ANY level that produced a gap — the hierarchy
  then re-runs from that point upward.

  Level 3 (Specialists) → Level 2 (Supervisor) → Level 1 (MDT Chair)
                                    ↑                    ↑
                                    └────── Critic ───────┘
                                       (conditional routing)

LangGraph constructs used:
  - StateGraph with TypedDict — levels share a single state
  - add_conditional_edges from the Critic node:
      routes to "department_supervisor", "mdt_chair", or "finalize"
      based on the critic's assessment of where the gap originated
  - revision_round counter: prevents infinite loops (max 2 revisions)
  - No MemorySaver needed: the entire flow is one graph.stream() call

Healthcare use case: Meridian Health Complex Case MDT
  A patient with three intersecting serious conditions requires a
  full multidisciplinary review.  The critic reviews the final plan
  and finds a clinically significant gap.  It identifies WHICH level
  of the hierarchy produced the gap and routes back precisely there.
  The hierarchy re-runs from that point — not from the beginning.

Why hierarchical + critic?
  Hierarchical flow ensures each level adds appropriate expertise.
  The critic closes the quality loop: the top-level plan is only
  approved when it meets the safety standard the critic enforces.
  Without the critic, a gap in the supervisor's synthesis would
  silently propagate into the final plan.
"""

import os
from pathlib import Path
from typing import TypedDict, Literal
from textwrap import dedent
from dotenv import load_dotenv
import warnings

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------

def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

from langchain_aws import ChatBedrock
from langgraph.graph import StateGraph, END

llm = ChatBedrock(model_id=MODEL_ID, region_name=AWS_REGION, model_kwargs={"temperature": 0.4})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def pause(msg="Press Enter to continue..."):
    input(f"\n  [{msg}] ")
    print()

def section(title, width=68):
    print("=" * width)
    print(f"  {title}")
    print("=" * width)

def subsection(title, width=68):
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print("─" * width)

def indent(text, prefix="  "):
    return "\n".join(prefix + line for line in text.splitlines())

def critic_banner(msg: str, width=68):
    print(f"\n  {'!' * width}")
    print(f"  CRITIC: {msg}")
    print(f"  {'!' * width}")

# =============================================================================
# STATE — Shared across all three hierarchy levels
#
# Fields are written by exactly one level; the levels above read them.
# revision_round guards against infinite critique loops.
# =============================================================================

class MDTState(TypedDict):
    # ── Case input (immutable throughout) ───────────────────────────────────
    patient_name: str
    patient_age:  int
    case_summary: str

    # ── Level 3 — Specialist outputs (written once, read by all above) ───────
    oncology_report:   str
    cardiology_report: str

    # ── Level 2 — Supervisor synthesis ──────────────────────────────────────
    # Overwritten on each supervisor pass (no reducer — intentional).
    department_synthesis: str

    # ── Level 1 — MDT Chair plan ─────────────────────────────────────────────
    # Overwritten on each chair pass.
    treatment_plan: str

    # ── Critic feedback loop ─────────────────────────────────────────────────
    critic_verdict:   str   # "approved" | "revise_supervisor" | "revise_chair"
    critic_feedback:  str   # Specific gaps the critic identified
    revision_round:   int   # Incremented each time critic runs; max = MAX_REVISIONS

    # ── Final approved output ────────────────────────────────────────────────
    approved_plan: str

MAX_REVISIONS = 2   # Critic can send feedback at most this many times

# =============================================================================
# LEVEL 3 — SPECIALIST NODES
# Each specialist produces an independent report.
# They run once.  The critic never routes back to this level — their
# assessments are assumed sound; the gap is in the synthesis above them.
# =============================================================================

def oncologist_node(state: MDTState) -> dict:
    """
    Level 3 — Oncologist.
    Reviews the case purely from an oncology perspective.
    Unaware of what the cardiologist will say.
    """
    prompt = dedent(f"""\
        You are a consultant oncologist at Meridian Health.

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        CASE SUMMARY: {state['case_summary']}

        Provide your oncology specialist report (4-5 sentences):
        - Cancer staging and treatment urgency
        - Recommended first-line systemic therapy and regimen
        - Key oncology monitoring requirements
        - Any flags relevant to this patient's comorbidities

        Be specific. Do not defer to other specialties — give your oncology view.
    """)
    result = llm.invoke(prompt)
    return {"oncology_report": result.content}


def cardiologist_node(state: MDTState) -> dict:
    """
    Level 3 — Cardiologist.
    Reviews the case purely from a cardiology perspective.
    Reads the oncology report to note the proposed treatment.
    """
    prompt = dedent(f"""\
        You are a consultant cardiologist at Meridian Health.

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        CASE SUMMARY: {state['case_summary']}

        ONCOLOGY REPORT (for context):
        {state['oncology_report']}

        Provide your cardiology specialist report (4-5 sentences):
        - Cardiac risk stratification for the proposed oncology treatment
        - Current cardiac medications and any interactions to flag
        - Required cardiac investigations before starting treatment
        - Recommended cardiac monitoring during treatment

        Be specific about drug interactions and bleeding risk quantification.
    """)
    result = llm.invoke(prompt)
    return {"cardiology_report": result.content}

# =============================================================================
# LEVEL 2 — DEPARTMENT SUPERVISOR NODE
# Synthesises the two specialist reports into a unified recommendation.
# If critic feedback is present (revision round ≥ 1), the supervisor must
# explicitly address each gap the critic identified.
# =============================================================================

def department_supervisor_node(state: MDTState) -> dict:
    """
    Level 2 — Senior Physician / Department Supervisor.
    Reads both specialist reports and synthesises them.
    On revision rounds, receives and must address critic feedback.
    """
    critic_fb    = state.get("critic_feedback", "")
    revision_note = ""
    if critic_fb:
        revision_note = dedent(f"""
        ── CRITIC FEEDBACK (you MUST address every point below) ────────────
        {critic_fb}
        ────────────────────────────────────────────────────────────────────
        Your revised synthesis must explicitly resolve each issue flagged above.
        """)

    prompt = dedent(f"""\
        You are the Senior Physician and Department Supervisor at Meridian Health.
        Your role: synthesise specialist inputs into a unified department recommendation
        that the MDT Chair will use to produce the final treatment plan.
        {revision_note}
        PATIENT: {state['patient_name']}, {state['patient_age']} years old

        ONCOLOGY REPORT:
        {state['oncology_report']}

        CARDIOLOGY REPORT:
        {state['cardiology_report']}

        Produce a structured department synthesis (5-6 sentences):
        INTEGRATED RISK ASSESSMENT: <how the conditions interact>
        RECOMMENDED APPROACH: <unified recommendation reconciling both specialties>
        CRITICAL SAFETY POINTS: <non-negotiable safety requirements before treatment>
        UNRESOLVED TENSIONS: <any remaining clinical dilemmas for the MDT Chair>
    """)
    result = llm.invoke(prompt)
    return {"department_synthesis": result.content}

# =============================================================================
# LEVEL 1 — MDT CHAIR NODE
# Receives the supervisor's synthesis and produces the final treatment plan.
# On revision rounds, receives critic feedback and must address it.
# =============================================================================

def mdt_chair_node(state: MDTState) -> dict:
    """
    Level 1 — MDT Chair (Consultant Physician).
    Receives the department synthesis and produces the definitive treatment plan.
    On revision rounds, must address any critic feedback targeted at this level.
    """
    critic_fb     = state.get("critic_feedback", "")
    verdict       = state.get("critic_verdict", "")
    revision_note = ""

    if critic_fb and verdict == "revise_chair":
        revision_note = dedent(f"""
        ── CRITIC FEEDBACK FOR YOUR PLAN (address every point) ─────────────
        {critic_fb}
        ────────────────────────────────────────────────────────────────────
        """)

    prompt = dedent(f"""\
        You are the MDT Chair — Consultant Physician at Meridian Health.
        You chair the multidisciplinary team and produce the definitive care plan.
        {revision_note}
        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        CASE SUMMARY: {state['case_summary']}

        DEPARTMENT SYNTHESIS (from your Senior Physician):
        {state['department_synthesis']}

        Produce the final MDT treatment plan:

        MDT DECISION: <one sentence overall decision>
        TREATMENT PATHWAY:
        - Step 1: <action with responsible team>
        - Step 2: <action with responsible team>
        - Step 3: <action with responsible team>
        SAFETY REQUIREMENTS: <mandatory safeguards before treatment begins>
        MONITORING PLAN: <frequency and parameters>
        ESCALATION CRITERIA: <when to convene an urgent MDT review>
        REVIEW DATE: <when this plan is reviewed>
    """)
    result = llm.invoke(prompt)
    return {"treatment_plan": result.content}

# =============================================================================
# CRITIC NODE
# Reviews the final treatment plan against clinical safety standards.
# Decides: approve, or route feedback back to a specific hierarchy level.
# The critic NAMES the level responsible for the gap — not just "fix it."
# =============================================================================

def critic_node(state: MDTState) -> dict:
    """
    Critic — Clinical Quality Reviewer.
    Evaluates the MDT Chair's plan for safety, completeness, and consistency.
    Returns one of three verdicts:
      "approved"         — plan is safe and complete; proceed to finalise
      "revise_supervisor" — a gap in the Level 2 synthesis caused the problem
      "revise_chair"      — the specialist synthesis was adequate but the chair's
                            plan failed to translate it correctly
    Also increments revision_round to enforce the loop limit.
    """
    round_num = state.get("revision_round", 0)

    prompt = dedent(f"""\
        You are the Clinical Quality Critic at Meridian Health.
        Your role: review the MDT treatment plan and determine if it is safe,
        complete, and internally consistent.  If you find a gap, you must:
          1. Describe the gap precisely (1-3 sentences)
          2. Identify WHICH level of the hierarchy produced the gap:
             - "revise_supervisor" if the department synthesis missed or
               mishandled something that the specialist reports covered
             - "revise_chair"      if the synthesis was adequate but the
               MDT Chair's plan failed to include or address it correctly
          3. Provide specific corrective feedback that the targeted level
             must address in its revision

        This is revision round {round_num + 1} of {MAX_REVISIONS}.

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        CASE SUMMARY: {state['case_summary']}

        SPECIALIST REPORTS:
        --- ONCOLOGY ---
        {state['oncology_report']}

        --- CARDIOLOGY ---
        {state['cardiology_report']}

        DEPARTMENT SYNTHESIS (Level 2):
        {state['department_synthesis']}

        FINAL MDT PLAN (Level 1):
        {state['treatment_plan']}

        Respond in EXACTLY this format:

        VERDICT: approved | revise_supervisor | revise_chair
        GAP: <precise description of what is missing or unsafe, or "None" if approved>
        FEEDBACK: <specific instruction to the targeted level, or "None" if approved>
        RATIONALE: <one sentence explaining why this verdict was chosen>
    """)
    result = llm.invoke(prompt)
    content = result.content.strip()

    # Parse the structured critic response
    verdict  = "approved"
    gap      = ""
    feedback = ""

    for line in content.splitlines():
        if line.startswith("VERDICT:"):
            raw = line.replace("VERDICT:", "").strip().lower()
            if "revise_supervisor" in raw:
                verdict = "revise_supervisor"
            elif "revise_chair" in raw:
                verdict = "revise_chair"
            else:
                verdict = "approved"
        elif line.startswith("GAP:"):
            gap = line.replace("GAP:", "").strip()
        elif line.startswith("FEEDBACK:"):
            feedback = line.replace("FEEDBACK:", "").strip()

    combined_feedback = f"GAP IDENTIFIED: {gap}\n\nREQUIRED FIX: {feedback}" if gap and gap != "None" else ""

    return {
        "critic_verdict":  verdict,
        "critic_feedback": combined_feedback,
        "revision_round":  round_num + 1,
    }


def finalize_node(state: MDTState) -> dict:
    """
    Finalize — stamps the treatment plan as approved.
    If we reached here via the revision limit (not via "approved" verdict),
    include a note that the plan was accepted under revision constraints.
    """
    verdict = state.get("critic_verdict", "approved")
    rounds  = state.get("revision_round", 1)

    if verdict == "approved":
        note = f"Plan approved by Clinical Quality Critic after {rounds} review round(s)."
    else:
        note = (f"Plan finalised after reaching maximum revision limit ({MAX_REVISIONS}). "
                f"Remaining critic concerns should be addressed at next MDT meeting.")

    approved = f"{state['treatment_plan']}\n\n──\n{note}"
    return {"approved_plan": approved}

# =============================================================================
# ROUTING FUNCTION — Conditional edge from critic
# =============================================================================

def route_from_critic(state: MDTState) -> Literal["department_supervisor", "mdt_chair", "finalize"]:
    """
    The critic's verdict determines where control returns in the hierarchy.

      approved         → finalize (done)
      revise_supervisor → department_supervisor (Level 2 revises, then Level 1, then critic again)
      revise_chair      → mdt_chair only (Level 2 was fine; only Level 1 needs revision)

    If the revision limit is reached, always route to finalize regardless.
    """
    if state.get("revision_round", 0) >= MAX_REVISIONS:
        return "finalize"
    verdict = state.get("critic_verdict", "approved")
    if verdict == "revise_supervisor":
        return "department_supervisor"
    elif verdict == "revise_chair":
        return "mdt_chair"
    else:
        return "finalize"

# =============================================================================
# GRAPH CONSTRUCTION
# =============================================================================

def build_graph():
    builder = StateGraph(MDTState)

    # Register all nodes
    builder.add_node("oncologist",            oncologist_node)
    builder.add_node("cardiologist",          cardiologist_node)
    builder.add_node("department_supervisor", department_supervisor_node)
    builder.add_node("mdt_chair",             mdt_chair_node)
    builder.add_node("critic",                critic_node)
    builder.add_node("finalize",              finalize_node)

    # Bottom-up linear flow through the hierarchy
    builder.set_entry_point("oncologist")
    builder.add_edge("oncologist",            "cardiologist")
    builder.add_edge("cardiologist",          "department_supervisor")
    builder.add_edge("department_supervisor", "mdt_chair")
    builder.add_edge("mdt_chair",             "critic")

    # Critic's conditional routing — the feedback loop
    builder.add_conditional_edges(
        "critic",
        route_from_critic,
        {
            "department_supervisor": "department_supervisor",   # revise Level 2 → Level 1 → critic
            "mdt_chair":             "mdt_chair",               # revise Level 1 only → critic
            "finalize":              "finalize",                # approved or limit reached
        }
    )
    builder.add_edge("finalize", END)

    return builder.compile()

# =============================================================================
# STORY & FLOW DISPLAYS
# =============================================================================

def print_story():
    section("HIERARCHICAL AGENTS + CRITIC FEEDBACK — MDT Case Review")
    print("""
  SCENARIO
  ─────────
  Meridian Health's MDT team reviews complex cases that no single specialist
  can handle alone.  The review follows a strict three-level hierarchy:

    Level 3 — SPECIALISTS
      Each specialist produces an independent domain report.
      They work at the bottom of the hierarchy.

    Level 2 — DEPARTMENT SUPERVISOR  (Senior Physician)
      Reads all specialist reports and synthesises them into a
      unified department recommendation — resolving tensions and
      flagging critical safety points.

    Level 1 — MDT CHAIR  (Consultant Physician)
      Receives the synthesis and produces the definitive treatment plan.
      This is the plan that will be enacted.

    CRITIC — Clinical Quality Reviewer
      Reviews the final plan against safety standards.
      If a gap is found, the critic NAMES which level produced it
      and routes feedback BACK to exactly that level.
      The hierarchy re-runs from that point upward — not from scratch.

  THE CRITIC'S ROUTING LOGIC:
    "revise_supervisor" → feedback goes to Level 2.
       The supervisor revises the synthesis, then the chair produces
       a new plan, then the critic reviews again.

    "revise_chair"      → feedback goes to Level 1 only.
       The synthesis was adequate; only the chair's plan needs fixing.
       Supervisor is not re-run — efficient targeted revision.

    "approved"          → the plan is finalised.

  THE PATIENT — Robert Carver, 67:
    Three intersecting serious conditions make this a genuinely hard case:

    [1] Aggressive non-small cell lung cancer (NSCLC) stage IIIA
        Requires systemic chemotherapy urgently.
        Standard first line: cisplatin-based doublet therapy.

    [2] Recent NSTEMI (3 months ago)
        Currently on DUAL antiplatelet therapy: aspirin + clopidogrel.
        Dual antiplatelet + chemotherapy = serious haemorrhagic risk.

    [3] Chronic kidney disease stage 3b (eGFR 32 mL/min)
        Cisplatin is highly nephrotoxic.
        Standard chemo regimen may be contraindicated.

  THE CLINICAL STAKES:
    If the treatment plan does not explicitly address the haemorrhagic
    risk from combining chemotherapy with dual antiplatelet therapy, and
    does not substitute a renal-safe agent for cisplatin, the patient
    could suffer catastrophic haemorrhage or acute kidney injury.

    The critic's job: catch these gaps before the plan is enacted.
""")


def print_flow():
    subsection("HIERARCHICAL FLOW WITH CRITIC FEEDBACK LOOP")
    print("""
    ┌──────────────────────────────────────────────────────────────┐
    │                     MDTState                                 │
    │  patient_name, age, case_summary                            │
    │  oncology_report     ← written by oncologist node           │
    │  cardiology_report   ← written by cardiologist node         │
    │  department_synthesis← written (and rewritten) by supervisor│
    │  treatment_plan      ← written (and rewritten) by chair     │
    │  critic_verdict      ← "approved" | "revise_*"              │
    │  critic_feedback     ← specific gap description             │
    │  revision_round      ← 0 → 1 → 2 (loop guard)              │
    │  approved_plan       ← written by finalize node             │
    └──────────────────────────────────────────────────────────────┘

    LEVEL 3 — SPECIALISTS
    ┌──────────────┐    ┌──────────────┐
    │  oncologist  │ →  │ cardiologist │
    └──────────────┘    └──────┬───────┘
                               │
    LEVEL 2 — SUPERVISOR       │
                   ┌───────────▼──────────────────────────────────┐
                   │          department_supervisor                │ ◄─────┐
                   │  Synthesises specialist reports.             │       │
                   │  On revision: addresses critic feedback.     │       │
                   └───────────────────────┬──────────────────────┘       │
                                           │                              │
    LEVEL 1 — MDT CHAIR                    │                              │
                   ┌───────────▼──────────────────────────────────┐       │
                   │              mdt_chair                        │ ◄──┐  │
                   │  Produces definitive treatment plan.         │    │  │
                   │  On revision: addresses targeted feedback.   │    │  │
                   └───────────────────────┬──────────────────────┘    │  │
                                           │                           │  │
    CRITIC                                 │                           │  │
                   ┌───────────▼──────────────────────────────────┐    │  │
                   │                critic                         │    │  │
                   │  Reviews plan vs specialist reports.         │    │  │
                   │  Identifies gap + responsible level.         │    │  │
                   └───────┬───────────────┬──────────────────────┘    │  │
                           │               │                           │  │
              "revise_chair"│  "revise_supervisor"│   "approved"        │  │
                           │               │       │                   │  │
                           └───────────────┼───────┼──► finalize → END │  │
                                           │       │                   │  │
                    routes to mdt_chair ───┘       └── routes to ──────┘  │
                    (Level 1 only revises)              department_supervisor
                                                        (Level 2 + Level 1 revise)
""")

# =============================================================================
# CASE DATA
# =============================================================================

PATIENT = {
    "patient_name": "Robert Carver",
    "patient_age":  67,
    "case_summary": (
        "67-year-old male with newly confirmed stage IIIA non-small cell lung cancer "
        "(NSCLC, adenocarcinoma, EGFR negative, PD-L1 40%). Presents for MDT review "
        "to agree a treatment plan. "
        "Significant comorbidities: (1) Recent NSTEMI 3 months ago, managed conservatively; "
        "currently on dual antiplatelet therapy — aspirin 75 mg + clopidogrel 75 mg — "
        "and bisoprolol 5 mg, ramipril 10 mg, atorvastatin 40 mg. "
        "(2) Chronic kidney disease stage 3b: eGFR 32 mL/min at last check. "
        "(3) Type 2 diabetes on metformin. "
        "Oncology team is considering cisplatin + pemetrexed as first-line systemic therapy. "
        "Patient is PS 1, motivated to pursue treatment."
    ),
}

def initial_state() -> MDTState:
    return {
        "patient_name":       PATIENT["patient_name"],
        "patient_age":        PATIENT["patient_age"],
        "case_summary":       PATIENT["case_summary"],
        "oncology_report":    "",
        "cardiology_report":  "",
        "department_synthesis": "",
        "treatment_plan":     "",
        "critic_verdict":     "",
        "critic_feedback":    "",
        "revision_round":     0,
        "approved_plan":      "",
    }

# =============================================================================
# MAIN
# =============================================================================

LEVEL_LABELS = {
    "oncologist":            ("LEVEL 3", "ONCOLOGIST"),
    "cardiologist":          ("LEVEL 3", "CARDIOLOGIST"),
    "department_supervisor": ("LEVEL 2", "DEPARTMENT SUPERVISOR"),
    "mdt_chair":             ("LEVEL 1", "MDT CHAIR"),
    "critic":                ("CRITIC",  "CLINICAL QUALITY REVIEWER"),
    "finalize":              ("FINAL",   "APPROVED PLAN"),
}

if __name__ == "__main__":
    print_story()
    pause("Press Enter to see the hierarchical flow diagram")

    print_flow()
    pause("Press Enter to begin the MDT review")

    section(f"MDT CASE REVIEW — {PATIENT['patient_name']}, {PATIENT['patient_age']}  |  Model: {MODEL_ID}")
    print(f"\n  CASE SUMMARY:\n{indent(PATIENT['case_summary'], '  ')}\n")
    pause("Press Enter to start the specialist assessments")

    graph = build_graph()

    outputs_dir = Path(__file__).resolve().parent / "outputs"
    os.makedirs(outputs_dir, exist_ok=True)
    output_lines = [f"# Meridian Health MDT — Hierarchical + Critic Demo\n\n"
                    f"**Patient:** {PATIENT['patient_name']}, {PATIENT['patient_age']}\n\n"
                    f"**Case:** {PATIENT['case_summary']}\n\n---\n\n"]

    # Track how many times each node runs so we can label revisions
    node_run_count: dict = {}
    approved_plan  = ""

    for step in graph.stream(initial_state()):
        node_name = list(step.keys())[0]
        data      = step[node_name]
        node_run_count[node_name] = node_run_count.get(node_name, 0) + 1
        run_num   = node_run_count[node_name]

        level_tag, role_tag = LEVEL_LABELS.get(node_name, ("", node_name.upper()))
        revision_tag = f"  [REVISION {run_num}]" if run_num > 1 else ""

        # ── Specialist nodes ─────────────────────────────────────────────────
        if node_name == "oncologist":
            subsection(f"{level_tag} — {role_tag}")
            report = data.get("oncology_report", "")
            print(indent(report, "  "))
            output_lines.append(f"## Oncology Report\n\n{report}\n\n---\n\n")
            pause("Press Enter for Cardiology assessment")

        elif node_name == "cardiologist":
            subsection(f"{level_tag} — {role_tag}")
            report = data.get("cardiology_report", "")
            print(indent(report, "  "))
            output_lines.append(f"## Cardiology Report\n\n{report}\n\n---\n\n")
            pause("Press Enter for Department Supervisor synthesis")

        # ── Supervisor node (may run more than once) ──────────────────────────
        elif node_name == "department_supervisor":
            subsection(f"{level_tag} — {role_tag}{revision_tag}")
            if run_num > 1:
                print(f"\n  [Revising synthesis to address critic feedback...]\n")
            synthesis = data.get("department_synthesis", "")
            print(indent(synthesis, "  "))
            output_lines.append(f"## Department Synthesis (Round {run_num})\n\n{synthesis}\n\n---\n\n")
            pause("Press Enter for MDT Chair plan")

        # ── MDT Chair node (may run more than once) ───────────────────────────
        elif node_name == "mdt_chair":
            subsection(f"{level_tag} — {role_tag}{revision_tag}")
            if run_num > 1:
                print(f"\n  [Revising treatment plan based on feedback...]\n")
            plan = data.get("treatment_plan", "")
            print(indent(plan, "  "))
            output_lines.append(f"## MDT Chair Treatment Plan (Round {run_num})\n\n{plan}\n\n---\n\n")
            pause("Press Enter for Critic review")

        # ── Critic node ──────────────────────────────────────────────────────
        elif node_name == "critic":
            verdict   = data.get("critic_verdict",  "approved")
            feedback  = data.get("critic_feedback",  "")
            rev_round = data.get("revision_round",   1)

            if verdict == "approved":
                subsection(f"{level_tag} — {role_tag}  ✓ APPROVED")
                print(f"\n  Verdict: APPROVED")
                print(f"  The treatment plan meets clinical safety and completeness standards.")
                output_lines.append(f"## Critic Review (Round {rev_round})\n\n**VERDICT: APPROVED**\n\n---\n\n")

            elif verdict == "revise_supervisor":
                critic_banner(f"REVISE REQUIRED → routing back to LEVEL 2 (Department Supervisor)")
                print(f"\n  Feedback:\n{indent(feedback, '  ')}")
                print(f"\n  Routing: Critic → Department Supervisor → MDT Chair → Critic")
                output_lines.append(
                    f"## Critic Review (Round {rev_round})\n\n"
                    f"**VERDICT: REVISE — Level 2 (Department Supervisor)**\n\n"
                    f"{feedback}\n\n---\n\n"
                )
                pause("Press Enter to send feedback to Department Supervisor")

            elif verdict == "revise_chair":
                critic_banner(f"REVISE REQUIRED → routing back to LEVEL 1 (MDT Chair only)")
                print(f"\n  Feedback:\n{indent(feedback, '  ')}")
                print(f"\n  Routing: Critic → MDT Chair → Critic  (supervisor adequate)")
                output_lines.append(
                    f"## Critic Review (Round {rev_round})\n\n"
                    f"**VERDICT: REVISE — Level 1 (MDT Chair)**\n\n"
                    f"{feedback}\n\n---\n\n"
                )
                pause("Press Enter to send feedback to MDT Chair")

        # ── Finalize node ─────────────────────────────────────────────────────
        elif node_name == "finalize":
            subsection(f"{level_tag} — {role_tag}")
            approved_plan = data.get("approved_plan", "")
            print(indent(approved_plan, "  "))
            output_lines.append(f"## Approved Plan\n\n{approved_plan}\n\n---\n\n")

    # Save output
    output_path = outputs_dir / "hierarchical_mdt_review.md"
    with open(output_path, "w", encoding="utf-8") as f:
        f.writelines(output_lines)

    # ── Summary ───────────────────────────────────────────────────────────────
    section("HIERARCHICAL + CRITIC PATTERN SUMMARY")
    supervisor_runs = node_run_count.get("department_supervisor", 0)
    chair_runs      = node_run_count.get("mdt_chair", 0)
    critic_runs     = node_run_count.get("critic", 0)

    print(f"""
  What the demo showed:

  NODE EXECUTION TRACE
  ─────────────────────
    oncologist            × 1   (Level 3 — specialists run once only)
    cardiologist          × 1   (Level 3 — specialists run once only)
    department_supervisor × {supervisor_runs}   (Level 2 — ran {'once' if supervisor_runs == 1 else f'{supervisor_runs} times (revised by critic)'})
    mdt_chair             × {chair_runs}   (Level 1 — ran {'once' if chair_runs == 1 else f'{chair_runs} times (revised by critic)'})
    critic                × {critic_runs}   (reviewed {critic_runs} time(s))
    finalize              × 1

  THE CRITIC'S ROLE IN THE HIERARCHY
  ─────────────────────────────────────
  The critic does NOT re-run the entire pipeline when it finds a gap.
  It identifies WHICH level produced the gap and routes back precisely:

    "revise_supervisor" → Level 2 revises the synthesis.
      Then Level 1 produces a new plan using the revised synthesis.
      Then the critic reviews the new plan.
      Specialists (Level 3) are NOT re-run — their reports were adequate.

    "revise_chair"      → Only Level 1 revises the plan.
      Level 2's synthesis was adequate; no need to re-synthesise.
      The chair addresses the specific gap in the plan.
      Targeted, efficient correction.

    "approved"          → Plan is stamped and finalised.

  CLINICAL GAPS THE CRITIC TARGETED
  ───────────────────────────────────
  Robert Carver's case has two clinically critical intersections:
    1. Cisplatin + dual antiplatelet therapy → nephrotoxicity + bleeding risk
    2. eGFR 32 → cisplatin contraindicated; carboplatin should be substituted

  Without the critic, a synthesis that mentioned these issues briefly but
  did not resolve them would propagate into the final plan unchanged.
  The critic ensures these gaps are RESOLVED before the plan is enacted.

  LANGGRAPH CONSTRUCTS
  ─────────────────────
  add_conditional_edges("critic", route_from_critic, {{...}})
    → The key mechanism. After every critic run, control flows to one
      of three destinations based on critic_verdict in the state.

  revision_round counter
    → Prevents infinite feedback loops. After {MAX_REVISIONS} critic rounds,
      route_from_critic always returns "finalize" regardless of verdict.

  Plain state fields (no reducer) for synthesis and plan
    → department_synthesis and treatment_plan are OVERWRITTEN on each
      revision pass — the new version replaces the old one in state.
      This is intentional; the old (flawed) version is discarded.

  Output saved → {output_path.name}

  NOTE: For educational purposes only.
  All clinical decisions must be made by qualified healthcare professionals.
""")

# =============================================================================
# DEPLOYING THIS PATTERN ON AWS — OPTIONS & RECOMMENDATIONS
# =============================================================================
#
# This demo already runs on Amazon Bedrock (via ChatBedrock / langchain_aws).
# Below are your options for moving from a local script to a production
# AWS deployment, from simplest to most powerful.
#
# ─────────────────────────────────────────────────────────────────────────────
# OPTION 1 — AWS Lambda  (simplest, good for short cases)
# ─────────────────────────────────────────────────────────────────────────────
#
#   Package this file + dependencies in a container image and deploy to Lambda.
#   The graph.stream() call becomes the Lambda handler body.
#
#   Limit: 15-minute max execution time.  For a full MDT review with 2 critic
#   revisions this may be tight if the model is slow.  Use provisioned
#   concurrency + a step-function wrapper if latency is a concern.
#
#   IAM role needs: bedrock:InvokeModel on the model ARN.
#
#   Code change needed — wrap graph.stream() in a handler:
#
#       import json
#       def handler(event, context):
#           state = {**initial_state(), **event.get("overrides", {})}
#           final = {}
#           for step in graph.stream(state):
#               final.update(step)
#           return {"approved_plan": final.get("finalize", {}).get("approved_plan", "")}
#
# ─────────────────────────────────────────────────────────────────────────────
# OPTION 2 — Amazon Bedrock AgentCore Runtime  (recommended for production)
# ─────────────────────────────────────────────────────────────────────────────
#
#   Bedrock AgentCore (GA 2025) is a managed, serverless runtime that runs
#   ANY agent framework — LangGraph, CrewAI, Strands — with:
#     • Up to 8-hour task execution (no Lambda timeout issue)
#     • Automatic scaling, IAM-native auth, built-in observability
#     • AWS Secrets Manager for API key injection
#     • OpenTelemetry → CloudWatch + X-Ray traces per node run
#
#   Install:  pip install amazon-bedrock-agentcore
#
#   Add checkpointing (optional but recommended):
#
#       from amazon_bedrock_agentcore.memory import AgentCoreMemorySaver
#
#       checkpointer = AgentCoreMemorySaver()
#       graph = build_graph(checkpointer=checkpointer)   # pass to .compile()
#
#   Deploy in one command:
#
#       agentcore launch --name meridian-mdt --region us-east-1
#
#   The AgentCore runtime calls your graph exactly like the local main() block.
#   Checkpointing lets you resume a paused MDT review mid-graph (e.g., waiting
#   for a human approval step between the critic and the finalize node).
#
#   Docs:  https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/
#   Samples: https://github.com/awslabs/amazon-bedrock-agentcore-samples
#
# ─────────────────────────────────────────────────────────────────────────────
# OPTION 3 — Native Bedrock Multi-Agent Collaboration  (low-code alternative)
# ─────────────────────────────────────────────────────────────────────────────
#
#   If you want to avoid managing graph state yourself, Bedrock's native
#   multi-agent collaboration (GA March 2025) maps naturally to this hierarchy:
#
#     Hierarchy level      →  Bedrock construct
#     ─────────────────────────────────────────
#     Oncologist / Cardio  →  Sub-agents (specialist agents with instructions)
#     Dept. Supervisor     →  Inline supervisor agent (dynamically created)
#     MDT Chair + Critic   →  Orchestrator / supervisor agent with a custom
#                              action group that implements the review loop
#
#   Create via the Bedrock console, CDK (aws-cdk-lib.aws_bedrock), or API.
#   The supervisor orchestrates sub-agents automatically; Bedrock handles
#   routing, retries, and parallel execution.
#
#   Best for: teams that want managed infrastructure and less framework code.
#   Trade-off: less explicit control over conditional routing than LangGraph.
#
#   Docs:  https://docs.aws.amazon.com/bedrock/latest/userguide/agents-multi-agent-collaboration.html
#
# ─────────────────────────────────────────────────────────────────────────────
# OPTION 4 — AWS Strands Agents  (lightweight AWS-native SDK)
# ─────────────────────────────────────────────────────────────────────────────
#
#   Strands Agents (open-source, May 2025) is AWS's own agent SDK.
#   It has native AgentCore deployment and replaces much of the LangGraph
#   boilerplate with model-driven orchestration.
#
#   The hierarchical + critic pattern translates to a Strands multi-agent
#   setup where each level is a Strands Agent and the critic is a tool or
#   a dedicated evaluator agent.  The LLM itself reasons about routing
#   rather than using explicit conditional edges.
#
#   Install:  pip install strands-agents strands-agents-tools
#
#   Docs:  https://strandsagents.com
#
# ─────────────────────────────────────────────────────────────────────────────
# OPTION 5 — ECS Fargate  (long-running, high-throughput production)
# ─────────────────────────────────────────────────────────────────────────────
#
#   For high-volume MDT processing (many cases in parallel), containerise this
#   script and run it on ECS Fargate behind an ALB or triggered by SQS.
#
#   Architecture sketch:
#     SQS queue (one message per case) → ECS Fargate task (this script) →
#     results written to S3 / Aurora → SNS notification to clinical team
#
#   No execution time limits; scales horizontally with the queue depth.
#   Pair with LangGraph Platform (BYOC) if you also want a hosted graph API.
#
# ─────────────────────────────────────────────────────────────────────────────
# QUICK DECISION GUIDE
# ─────────────────────────────────────────────────────────────────────────────
#
#   Situation                              Recommended option
#   ──────────────────────────────────────────────────────────
#   Prototype / single case on demand     Option 1 — Lambda
#   Production agentic service            Option 2 — AgentCore Runtime ★
#   Low-code / managed orchestration      Option 3 — Bedrock native agents
#   Prefer AWS-native SDK over LangGraph  Option 4 — Strands Agents
#   High-volume batch processing          Option 5 — ECS Fargate + SQS
#
#   ★ AgentCore is the recommended path for this LangGraph pattern because it
#     is framework-agnostic, supports the full graph.stream() execution model,
#     removes the Lambda timeout constraint, and adds production observability
#     with zero changes to the LangGraph graph definition itself.
