# -*- coding: utf-8 -*-
"""
Memory Isolation Pattern — Clinical Trial Data Privacy
Implemented with LangGraph State-Based Memory Isolation

LangGraph Memory Constructs Used:
  - StateGraph with TypedDict state: the shared "database" of the entire trial
  - Per-node INPUT SCHEMAS: each node only sees the state fields it's authorized to read
  - MemorySaver checkpointer: persists full state across steps (but nodes still see only their view)

The key insight: LangGraph's graph.add_node(..., input=RestrictedSchema) enforces
that a node function ONLY receives the fields defined in its restricted schema —
even though the full state lives in the graph. This is true memory isolation.
"""

import os
import sys
import time
from pathlib import Path
from typing import TypedDict
from textwrap import dedent
from dotenv import load_dotenv
import warnings

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------

def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

from langchain_aws import ChatBedrock
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

llm = ChatBedrock(model_id=MODEL_ID, region_name=AWS_REGION, model_kwargs={"temperature": 0.7})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def pause(msg="Press Enter to continue..."):
    input(f"\n  [{msg}] ")
    print()

def section(title, width=68):
    print("=" * width)
    print(f"  {title}")
    print("=" * width)

def subsection(title, width=68):
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print("─" * width)

# =============================================================================
# TRIAL DATA — The full "database" (no agent sees all of this)
# =============================================================================

DEIDENTIFIED_OUTCOMES = dedent("""\
    CARDIOPROTECT-HF Phase III Trial — De-identified Outcomes (Week 24)
    Total Enrolled: 480 patients (240 per arm)

    PRIMARY ENDPOINT — 6-Minute Walk Distance (6MWD) change from baseline:
      Arm A (n=240): Mean change +58m (SD 32), 95% CI [54, 62]
      Arm B (n=240): Mean change +21m (SD 28), 95% CI [17, 25]
      Between-group difference: 37m, p < 0.001

    SECONDARY ENDPOINTS:
      NT-proBNP reduction:   Arm A: -42%  |  Arm B: -14%  (p < 0.001)
      NYHA class improvement: Arm A: 64%  |  Arm B: 31%  (p < 0.001)
      HF hospitalization:    Arm A: 8.3%  |  Arm B: 16.7%  HR 0.47 (p = 0.006)

    SUBGROUP ANALYSES:
      Age ≥65: consistent effect (interaction p = 0.42)
      Diabetes: slightly attenuated (interaction p = 0.08)
      LVEF <30%: enhanced benefit (interaction p = 0.03)
""")

ADVERSE_EVENTS_DATA = dedent("""\
    CARDIOPROTECT-HF Phase III Trial — Adverse Events (Week 24)
    DSMB Review — Blinded (no arm assignments)

    SERIOUS ADVERSE EVENTS (SAEs):
      PT-0042: Acute kidney injury (Day 45), hospitalized 4 days, recovered
      PT-0118: Symptomatic hypotension (Day 30), dose reduced, resolved
      PT-0205: Hyperkalemia K+ 6.2 mEq/L (Day 60), treated, resolved
      PT-0287: Syncope (Day 15), ER visit, resolved after dose adjustment
      PT-0331: Hepatic enzyme elevation ALT 3x ULN (Day 90), drug held, normalized
      PT-0419: Fatal MI (Day 112) — adjudication committee review PENDING

    ADVERSE EVENT RATES (all grades, pooled):
      Hypotension: 18.5%   Dizziness: 22.1%   eGFR drop >30%: 7.3%
      Hyperkalemia: 5.4%   Hepatic elevation: 3.1%   GI symptoms: 14.6%

    DEATHS: 3 total (1 MI, 1 stroke, 1 non-cardiac) — all under review
    DROPOUTS: 38 (7.9%) — 22 AE-related, 16 non-medical

    ALERT: Fatal MI (PT-0419) and 18.5% hypotension rate warrant
    committee discussion on dose-adjustment protocol adequacy.
""")

OPERATIONAL_STATUS = dedent("""\
    CARDIOPROTECT-HF Phase III Trial — Operational Status
    Sponsor: CardioPharm Inc. | NCT-EXAMPLE-2024

    ENROLLMENT: 480/480 (100%)   SITES: 28 across 6 countries
    PHASE: Week 24 primary endpoint analysis
    DATABASE LOCK: Completed 2 weeks ago
    NEXT MILESTONE: DSMB interim analysis presentation
    REGULATORY: FDA pre-NDA meeting scheduled in 3 months
""")

# =============================================================================
# LANGGRAPH STATE — Full trial "database" (no single node sees all fields)
# =============================================================================

class TrialState(TypedDict):
    """Complete graph state. Each node only receives the fields it's authorized to see."""
    # Raw data inputs — access controlled via per-node input schemas
    deidentified_outcomes: str   # → biostatistician ONLY
    adverse_events: str          # → safety monitor ONLY
    operational_status: str      # → coordinator ONLY

    # Agent outputs — summaries flow downstream
    efficacy_analysis: str       # ← written by biostatistician
    safety_review: str           # ← written by safety monitor
    combined_report: str         # ← written by coordinator

# ─── Per-node restricted views (LangGraph input schema = memory isolation) ───

class BiostatView(TypedDict):
    """Biostatistician sees ONLY de-identified outcomes. No AEs, no patient IDs."""
    deidentified_outcomes: str

class SafetyView(TypedDict):
    """Safety monitor sees ONLY adverse events (with patient IDs). No efficacy data."""
    adverse_events: str

class CoordinatorView(TypedDict):
    """Coordinator sees ONLY summaries + operational data. No raw patient data."""
    operational_status: str
    efficacy_analysis: str
    safety_review: str

# =============================================================================
# NODE FUNCTIONS — Each receives only its restricted view
# =============================================================================

def biostatistician_node(state: BiostatView) -> dict:
    """Receives only de-identified outcomes. Cannot see adverse events or patient IDs."""
    prompt = dedent(f"""\
        You are a PhD biostatistician on the CARDIOPROTECT-HF Phase III trial.
        You are blinded — Arm A and Arm B are labels only. You do NOT know which
        is drug vs placebo, and you have NO access to adverse events or patient IDs.

        DE-IDENTIFIED OUTCOMES DATA:
        {state['deidentified_outcomes']}

        Provide a concise analysis (3-4 short paragraphs):
        1. Primary endpoint assessment (clinical and statistical significance)
        2. Secondary endpoint highlights
        3. Notable subgroup findings
        4. Overall efficacy conclusion

        Do NOT speculate about which arm is drug vs placebo.
    """)
    response = llm.invoke(prompt)
    return {"efficacy_analysis": response.content}


def safety_monitor_node(state: SafetyView) -> dict:
    """Receives only adverse events data. Cannot see efficacy results or arm assignments."""
    prompt = dedent(f"""\
        You are an independent DSMB physician for the CARDIOPROTECT-HF trial.
        You have patient IDs for safety tracking but you do NOT know which
        treatment arm patients are in, and you have NO access to efficacy data.

        ADVERSE EVENTS DATA:
        {state['adverse_events']}

        Provide a concise safety review (3-4 short paragraphs):
        1. Key safety signals identified
        2. Specific patient cases requiring follow-up
        3. Risk assessment based on safety data alone
        4. Recommendation: Continue / Modify protocol / Pause / Stop

        Base your recommendation ONLY on safety data.
    """)
    response = llm.invoke(prompt)
    return {"safety_review": response.content}


def coordinator_node(state: CoordinatorView) -> dict:
    """Receives only summaries + operational data. Cannot see raw patient data."""
    prompt = dedent(f"""\
        You are the trial coordinator compiling a sponsor status report.
        You receive SUMMARIES from specialists — you do NOT have raw patient data.

        If any patient identifiers appear in the summaries, replace with [REDACTED].

        OPERATIONAL STATUS:
        {state['operational_status']}

        BIOSTATISTICIAN EFFICACY SUMMARY:
        {state['efficacy_analysis']}

        SAFETY MONITOR REVIEW:
        {state['safety_review']}

        Produce a concise combined status report:
        1. Executive Summary (3 bullet points)
        2. Efficacy Highlights
        3. Safety Highlights
        4. Key Risks & Recommended Next Steps
    """)
    response = llm.invoke(prompt)
    return {"combined_report": response.content}

# =============================================================================
# GRAPH CONSTRUCTION — Isolation enforced at the graph level via input schemas
# =============================================================================

def build_graph():
    builder = StateGraph(TrialState)

    # input_schema= restricts what state fields each node function receives
    builder.add_node("biostatistician", biostatistician_node, input_schema=BiostatView)
    builder.add_node("safety_monitor",  safety_monitor_node,  input_schema=SafetyView)
    builder.add_node("coordinator",     coordinator_node,     input_schema=CoordinatorView)

    # Biostatistician and safety monitor run in sequence (parallel requires Send API)
    builder.set_entry_point("biostatistician")
    builder.add_edge("biostatistician", "safety_monitor")
    builder.add_edge("safety_monitor",  "coordinator")
    builder.add_edge("coordinator",     END)

    checkpointer = MemorySaver()
    return builder.compile(checkpointer=checkpointer)

# =============================================================================
# MAIN
# =============================================================================

def print_story():
    section("MEMORY ISOLATION PATTERN — Clinical Trial Data Privacy")
    print("""
  SCENARIO
  ─────────
  CardioPharm Inc. is running CARDIOPROTECT-HF, a Phase III clinical trial
  for a new heart failure medication. 480 patients enrolled across 28 sites.

  The trial database contains everything: patient IDs, outcomes, adverse
  events, and treatment arm assignments. But strict regulatory rules (HIPAA,
  ICH-GCP, FDA 21 CFR Part 11) require that different roles only see the
  data they are authorized to access.

  THREE SPECIALISTS process the trial data — each blinded to what the
  others see:

    [STAT] Biostatistician   → De-identified outcomes ONLY
                              (no patient IDs, no adverse events, no arm labels)

    [DSMB] Safety Monitor    → Adverse events + patient IDs ONLY
                              (no efficacy data, no arm assignments — stays blinded)

    [MGMT] Trial Coordinator → Summaries ONLY from the two specialists
                              (never touches raw patient data)

  THE PATTERN: Memory Isolation
  ──────────────────────────────
  In LangGraph, the FULL trial state lives in the graph. But each node is
  given an INPUT SCHEMA — a TypedDict that is a restricted subset of the
  full state. LangGraph enforces that the node function ONLY receives the
  fields defined in its schema. This is true memory isolation at the
  graph level, not just by convention.

    TrialState (full)          Node Input Schema (restricted view)
    ─────────────────          ──────────────────────────────────
    deidentified_outcomes  →   BiostatView:    deidentified_outcomes
    adverse_events         →   SafetyView:     adverse_events
    operational_status  ─┐
    efficacy_analysis   ─┤ →   CoordinatorView: all three (summaries only)
    safety_review       ─┘
""")

def print_flow():
    subsection("DATA FLOW & ACCESS BOUNDARIES")
    print("""
    ┌──────────────────────┐         ┌─────────────────────┐
    │   Biostatistician    │         │    Safety Monitor    │
    │  input: BiostatView  │         │  input: SafetyView   │
    │                      │         │                      │
    │  ✓ deidentified data │         │  ✓ adverse events    │
    │  ✓ outcomes / stats  │         │  ✓ patient IDs       │
    │  ✗ adverse events    │         │  ✗ efficacy data     │
    │  ✗ patient IDs       │         │  ✗ arm assignments   │
    │  ✗ arm assignments   │         │  ✗ arm assignments   │
    └──────────┬───────────┘         └──────────┬──────────┘
               │ efficacy_analysis              │ safety_review
               │ (written to state)             │ (written to state)
               └──────────────┐   ┌────────────┘
                               ▼   ▼
                    ┌─────────────────────────┐
                    │     Trial Coordinator    │
                    │  input: CoordinatorView  │
                    │                          │
                    │  ✓ operational_status    │
                    │  ✓ efficacy_analysis     │  ← summary only
                    │  ✓ safety_review         │  ← summary only
                    │  ✗ raw outcomes          │
                    │  ✗ adverse events        │
                    │  ✗ patient IDs           │
                    └─────────────────────────┘

    MemorySaver checkpointer stores FULL state between steps,
    but input schemas prevent nodes from reading unauthorized fields.
""")

if __name__ == "__main__":
    print_story()
    pause("Press Enter to see the data flow diagram")

    print_flow()
    pause("Press Enter to start the trial analysis")

    section(f"RUNNING ANALYSIS  —  Model: {MODEL_ID}")
    print()

    graph = build_graph()
    config = {"configurable": {"thread_id": "trial-001"}}

    initial_state: TrialState = {
        "deidentified_outcomes": DEIDENTIFIED_OUTCOMES,
        "adverse_events":        ADVERSE_EVENTS_DATA,
        "operational_status":    OPERATIONAL_STATUS,
        "efficacy_analysis":     "",
        "safety_review":         "",
        "combined_report":       "",
    }

    # Stream node-by-node so we can show progress with pauses
    final_state = None
    for step in graph.stream(initial_state, config=config):
        node_name = list(step.keys())[0]

        if node_name == "biostatistician":
            subsection("STEP 1 / 3 — Biostatistician  [sees: de-identified outcomes only]")
            print(step[node_name]["efficacy_analysis"])
            pause("Press Enter to run Safety Monitor")

        elif node_name == "safety_monitor":
            subsection("STEP 2 / 3 — Safety Monitor  [sees: adverse events + patient IDs only]")
            print(step[node_name]["safety_review"])
            pause("Press Enter to run Trial Coordinator")

        elif node_name == "coordinator":
            subsection("STEP 3 / 3 — Trial Coordinator  [sees: summaries + operational data only]")
            print(step[node_name]["combined_report"])
            final_state = step[node_name]

    # Save output
    if final_state:
        outputs_dir = Path(__file__).resolve().parent / "outputs"
        os.makedirs(outputs_dir, exist_ok=True)
        output_path = outputs_dir / "memory_isolation_langgraph.md"
        with open(output_path, "w") as f:
            f.write("# CARDIOPROTECT-HF Trial — Combined Status Report\n\n")
            f.write(final_state["combined_report"])

        print()
        section("ISOLATION VERIFICATION")
        print("""
  What each node could read (enforced by LangGraph input schemas):

    biostatistician_node(state: BiostatView)
      ✓ state["deidentified_outcomes"]   — de-identified trial outcomes
      ✗ state["adverse_events"]          — KeyError: not in BiostatView
      ✗ state["adverse_events"]          — KeyError: not in BiostatView

    safety_monitor_node(state: SafetyView)
      ✓ state["adverse_events"]          — adverse events with patient IDs
      ✗ state["deidentified_outcomes"]   — KeyError: not in SafetyView
      ✗ state["efficacy_analysis"]       — KeyError: not in SafetyView

    coordinator_node(state: CoordinatorView)
      ✓ state["operational_status"]      — operational metadata
      ✓ state["efficacy_analysis"]       — biostatistician's summary
      ✓ state["safety_review"]           — safety monitor's summary
      ✗ state["deidentified_outcomes"]   — KeyError: not in CoordinatorView
      ✗ state["adverse_events"]          — KeyError: not in CoordinatorView

  The MemorySaver checkpointer holds the COMPLETE TrialState between steps.
  Isolation is not achieved by deleting data — it's achieved by restricting
  what each node function is ALLOWED to read, enforced at the graph level.
""")
        print(f"  Combined report saved → {output_path.name}")
        print()
