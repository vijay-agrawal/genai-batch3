# -*- coding: utf-8 -*-
"""
Episodic & Semantic Memory Pattern — Hospital Patient Support Chatbot
Implemented with LangGraph State + MemorySaver Checkpointing

LangGraph Memory Constructs Used:
  - StateGraph with TypedDict state (Annotated reducer for episode_log)
  - MemorySaver checkpointer: thread_id = patient_id provides EPISODIC memory
    by persisting each patient's conversation history across separate sessions
  - Pre-loaded clinical semantic knowledge in initial state: SEMANTIC memory
    (hospital protocols, care guidelines, and escalation policies shared
    across all patients)

The key insight:
  EPISODIC  = MemorySaver per thread_id  — "what this patient has told us before"
  SEMANTIC  = shared clinical knowledge  — "what we know about care in general"
  Together  → personalised guidance grounded in safe, consistent clinical policy

DISCLAIMER: This demo is for educational purposes only. The chatbot responses
shown here are illustrative and must NOT be used as actual medical advice.
All clinical decisions must be made by qualified healthcare professionals.
"""

import os
import json
import operator
from pathlib import Path
from typing import TypedDict, List, Dict, Annotated
from textwrap import dedent
from datetime import datetime
from dotenv import load_dotenv
import warnings

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------

def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

from langchain_aws import ChatBedrock
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

llm = ChatBedrock(model_id=MODEL_ID, region_name=AWS_REGION, model_kwargs={"temperature": 0.3})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def pause(msg="Press Enter to continue..."):
    input(f"\n  [{msg}] ")
    print()

def section(title, width=68):
    print("=" * width)
    print(f"  {title}")
    print("=" * width)

def subsection(title, width=68):
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print("─" * width)

# =============================================================================
# SEMANTIC MEMORY — Clinical knowledge base (shared across ALL patients)
# Loaded fresh on every session; belongs to no individual patient.
# In a production system these would be retrieved from a clinical knowledge
# graph or evidence-based guideline database using embedding similarity.
# =============================================================================

SEMANTIC_RULES = [
    "EMERGENCY: Chest pain, difficulty breathing, sudden weakness/numbness, or slurred speech "
    "→ instruct patient to call 911 immediately; do not attempt to handle through chat",
    "Post-surgical fever >38.5 °C (101.3 °F) reported within 7 days of discharge "
    "→ flag for urgent nurse callback within 2 hours; do not advise 'wait and see'",
    "Wound site showing increasing redness, warmth, swelling, or discharge after surgery "
    "→ escalate to care team same day; possible signs of surgical site infection",
    "Medication questions involving dosage changes or potential overdose "
    "→ advise patient to call the pharmacy helpline; never recommend dose changes in chat",
    "Patients reporting suicidal ideation or self-harm intent "
    "→ provide crisis line (988) immediately and escalate to social worker on call",
    "Patient missing 2+ scheduled follow-up appointments → flag for care coordinator outreach",
    "Post-discharge patients contacting support within 72 hours → heightened monitoring; "
    "review prior concerns before responding",
]

SEMANTIC_PATTERNS = [
    "Pain level reported as 7+ out of 10, combined with a new physical symptom "
    "→ likely requires clinical review, not just reassurance",
    "Patient asks about same symptom across multiple sessions without resolution "
    "→ prior guidance was insufficient; escalate to nurse or care team",
    "Patient expresses anxiety about lab results multiple times "
    "→ consider requesting care team to proactively call the patient",
    "Vague or minimising language ('it's probably nothing', 'I don't want to bother anyone') "
    "→ patient may be downplaying a serious concern; probe gently and take seriously",
    "Questions about medications combined with questions about alcohol or other substances "
    "→ flag for pharmacist or physician review",
    "Elderly patients (65+) post-discharge asking about falls, dizziness, or confusion "
    "→ high fall risk; escalate to care team and provide fall-prevention guidance",
]

SEMANTIC_PROTOCOLS = {
    "post_surgical_concern": (
        "Acknowledge symptom, compare against normal post-op expectations, "
        "list red-flag signs requiring immediate contact, schedule nurse callback if any red flags present"
    ),
    "medication_question": (
        "Provide general information only, remind patient to follow discharge paperwork, "
        "direct all dose/timing changes to prescribing physician or pharmacy helpline"
    ),
    "lab_results_inquiry": (
        "Confirm results are visible in patient portal (MyMeridian), explain typical turnaround times, "
        "reassure that care team contacts patient directly if results need urgent discussion"
    ),
    "appointment_scheduling": (
        "Direct to MyMeridian portal or scheduling line (555-MERIDIAN), "
        "offer to flag urgency to scheduling team if clinically needed"
    ),
    "symptom_query": (
        "Provide general educational information, clearly state chatbot cannot diagnose, "
        "advise when to seek urgent or emergency care based on symptom severity"
    ),
    "pain_management": (
        "Validate the patient's pain experience, confirm whether pain is within expected post-op range, "
        "advise on prescribed pain regimen, escalate if pain is severe or worsening"
    ),
}

# =============================================================================
# LANGGRAPH STATE
# episode_log uses Annotated[List, operator.add] so MemorySaver accumulates
# entries across sessions for the same thread_id (= patient_id).
# =============================================================================

class PatientState(TypedDict):
    # ── Current session ───────────────────────────────────────────────────────
    patient_id:   str
    patient_name: str
    message:      str                          # Patient's current message

    # ── SEMANTIC memory — loaded fresh, shared across ALL patients ────────────
    semantic_rules:     List[str]
    semantic_patterns:  List[str]
    semantic_protocols: Dict[str, str]

    # ── EPISODIC memory — persisted per-patient via MemorySaver ──────────────
    # operator.add reducer: new entries APPEND to existing list automatically.
    # MemorySaver persists the list across sessions for the same thread_id.
    episode_log: Annotated[List[Dict], operator.add]

    # ── Working / output fields (reset each session) ──────────────────────────
    patient_context:  str    # Formatted prior-session history for this patient
    relevant_guidance: str   # Clinical rules and protocol selected for this message
    response:         str    # Final chatbot response sent to patient
    episode_entry:    Dict   # New episode to store after this session
    escalation_flag:  str    # "none" | "nurse_callback" | "emergency" | "care_team"

# =============================================================================
# NODE FUNCTIONS
# =============================================================================

def retrieve_episodic_node(state: PatientState) -> dict:
    """
    EPISODIC RETRIEVAL — Reconstruct what this patient has told the chatbot
    in prior sessions.  episode_log is empty on first contact; MemorySaver
    automatically populates it for all subsequent sessions sharing this thread_id.
    """
    episodes = state.get("episode_log", [])

    if not episodes:
        context = "No previous sessions on record — this is the patient's first contact."
    else:
        lines = [
            f"Prior session history for {state['patient_name']} "
            f"({state['patient_id']}) — {len(episodes)} previous session(s):"
        ]
        for i, ep in enumerate(episodes[-5:], 1):
            lines.append(
                f"  [{i}] {ep.get('timestamp', '?')}  |  "
                f"Concern: {ep.get('message_summary', '?')}  |  "
                f"Action taken: {ep.get('action', '?')}  |  "
                f"Escalation: {ep.get('escalation', 'none')}"
            )
        context = "\n".join(lines)

    return {"patient_context": context}


def retrieve_semantic_node(state: PatientState) -> dict:
    """
    SEMANTIC RETRIEVAL — Identify which clinical rules, patterns, and protocols
    apply to the patient's current message.  Production systems use embedding
    similarity against a clinical knowledge graph; here the LLM selects from
    the pre-loaded lists.
    """
    message       = state["message"]
    all_rules     = "\n".join(f"  • {r}" for r in state["semantic_rules"])
    all_patterns  = "\n".join(f"  • {p}" for p in state["semantic_patterns"])
    protocols_txt = json.dumps(state["semantic_protocols"], indent=2)

    prompt = dedent(f"""\
        You are a clinical knowledge retrieval system for Meridian Health hospital.

        PATIENT MESSAGE:
        {message}

        AVAILABLE CLINICAL RULES (escalation triggers and safety policies):
{all_rules}

        AVAILABLE CARE PATTERNS (observed patient behaviour signals):
{all_patterns}

        AVAILABLE CARE PROTOCOLS (response templates by concern type):
{protocols_txt}

        Select and return ONLY the rules, patterns, and protocol most relevant
        to this patient message. Be conservative — when in doubt, include a rule.

        Format your answer as:

        RELEVANT RULES:
        - <rule text>

        RELEVANT PATTERNS:
        - <pattern text>

        RECOMMENDED PROTOCOL:
        <protocol name>: <one sentence on how to apply it here>

        ESCALATION LEVEL: <none | care_team | nurse_callback | emergency>
    """)
    result = llm.invoke(prompt)
    return {"relevant_guidance": result.content}


def generate_response_node(state: PatientState) -> dict:
    """
    RESPONSE GENERATION — Combines both memory types:
    • Episodic:  acknowledges prior sessions, tracks symptom progression,
                 escalates faster if the same concern is recurring
    • Semantic:  applies correct clinical protocols and safety rules
    """
    prior_sessions = len(state.get("episode_log", []))
    repeat_note = (
        "\n  IMPORTANT: This patient has contacted us before. Review their prior "
        "session history carefully. If the same or a related symptom is recurring "
        "without resolution, escalate — do not repeat the same guidance."
        if prior_sessions >= 1 else ""
    )

    prompt = dedent(f"""\
        You are the Meridian Health patient support chatbot — a friendly, calm,
        and trustworthy assistant that helps patients navigate their care.
        You are NOT a doctor. You provide information and guidance, and you
        escalate to clinical staff whenever safety requires it.{repeat_note}

        PATIENT: {state['patient_name']} (ID: {state['patient_id']})

        PATIENT'S MESSAGE:
        {state['message']}

        ── EPISODIC MEMORY (this patient's prior sessions) ──────────────────
        {state['patient_context']}

        ── SEMANTIC MEMORY (relevant clinical rules & protocols) ─────────────
        {state['relevant_guidance']}

        Response instructions:
        1. Address the patient by first name. Be warm and reassuring, not clinical.
        2. If there is prior session history, reference it — show the patient
           you remember them and are tracking their situation.
        3. Apply the relevant clinical protocol exactly.
        4. If escalation is needed, tell the patient clearly what will happen next
           (e.g. "A nurse will call you within 2 hours").
        5. Always end with a clear next step the patient can take.
        6. Keep the response under 180 words.
        7. Always include: "This chat cannot replace medical advice. If you feel
           your symptoms are an emergency, call 911 immediately."
    """)
    result = llm.invoke(prompt)

    # Determine escalation level from semantic guidance
    guidance_lower = state.get("relevant_guidance", "").lower()
    if "emergency" in guidance_lower:
        escalation = "emergency"
    elif "nurse_callback" in guidance_lower:
        escalation = "nurse_callback"
    elif "care_team" in guidance_lower:
        escalation = "care_team"
    else:
        escalation = "none"

    new_episode = {
        "timestamp":       datetime.now().strftime("%Y-%m-%d %H:%M"),
        "message_summary": (
            state["message"][:90] + "..."
            if len(state["message"]) > 90
            else state["message"]
        ),
        "action":          "Chatbot response provided",
        "escalation":      escalation,
    }
    return {
        "response":        result.content,
        "episode_entry":   new_episode,
        "escalation_flag": escalation,
    }


def update_episodic_node(state: PatientState) -> dict:
    """
    EPISODIC UPDATE — Append this session's record to the patient's episode_log.
    operator.add reducer + MemorySaver ensures the log grows automatically;
    the next session for this patient_id will see the full accumulated history.
    """
    new_entry = state.get("episode_entry", {})
    return {"episode_log": [new_entry] if new_entry else []}

# =============================================================================
# GRAPH CONSTRUCTION
# =============================================================================

def build_graph():
    builder = StateGraph(PatientState)

    builder.add_node("retrieve_episodic",  retrieve_episodic_node)
    builder.add_node("retrieve_semantic",  retrieve_semantic_node)
    builder.add_node("generate_response",  generate_response_node)
    builder.add_node("update_episodic",    update_episodic_node)

    builder.set_entry_point("retrieve_episodic")
    builder.add_edge("retrieve_episodic", "retrieve_semantic")
    builder.add_edge("retrieve_semantic",  "generate_response")
    builder.add_edge("generate_response",  "update_episodic")
    builder.add_edge("update_episodic",    END)

    return builder.compile(checkpointer=MemorySaver())

# =============================================================================
# STORY & FLOW DISPLAYS
# =============================================================================

def print_story():
    section("EPISODIC & SEMANTIC MEMORY — Hospital Patient Support Chatbot")
    print("""
  SCENARIO
  ─────────
  Meridian Health runs a 24/7 patient-facing chatbot — "Meridian Care Chat" —
  available through the hospital's MyMeridian portal.  It answers questions
  between appointments, flags concerns to clinical staff, and helps patients
  navigate their care journey.  Two memory types keep every patient safe:

  EPISODIC MEMORY  — "What this patient has told us before"
    Stored per-patient using LangGraph's MemorySaver checkpointer.
    Each session that shares the same thread_id (= patient_id) accumulates
    a timestamped log: what the patient asked, what guidance was given, and
    whether escalation occurred.  When Eleanor contacts the chatbot about a
    red and swollen surgical wound, the AI already knows she reported high
    pain levels 18 hours earlier — and connects the dots.

  SEMANTIC MEMORY  — "What we know about care in general"
    Pre-loaded clinical rules, care patterns, and response protocols shared
    across ALL patients.  These are hospital policy, not personal history:
      "Post-surgical fever within 7 days → nurse callback within 2 hours"
      "Redness + swelling at wound site → escalate same day"
      "Chest pain → 911 immediately; never handle through chat"
    Semantic memory is loaded fresh every session and belongs to no one.

  THE STORY:
    Eleanor Vasquez, 68, had a right knee replacement three days ago and was
    discharged yesterday morning.  She is managing her recovery at home with
    her husband.  During her first night home she contacts the chatbot, worried
    that her pain seems worse than she expected.  The chatbot provides post-op
    pain guidance and records the episode.

    Eighteen hours later Eleanor contacts the chatbot again.  The surgical
    site looks red and feels warm to the touch.  She says "it's probably
    nothing."  The chatbot — which remembers the prior pain complaint — now
    sees a pattern: escalating pain plus wound-site changes.  It flags the
    combination immediately for a same-day nurse callback.

    David Park, 45, had his annual physical last week and is waiting for his
    blood panel results.  He contacts the chatbot for the first time, slightly
    anxious, asking when the results will be ready and whether he should be
    worried.

  THREE SESSIONS demonstrate the dual-memory pattern:

    [SESSION 1]  Eleanor Vasquez (PT-7731) — first contact  (episode_log: empty)
                 Post-discharge pain level concern, night after knee replacement
                 → Semantic protocol: pain_management; episode recorded

    [SESSION 2]  Eleanor Vasquez (PT-7731) — follow-up      (episode_log: 1 entry)
                 Wound site red, warm, slightly swollen — "probably nothing"
                 → Episodic memory surfaces prior pain complaint; escalation triggered

    [SESSION 3]  David Park (PT-4402) — first contact  (separate thread_id)
                 Anxious about blood panel results from annual physical
                 → Completely separate episodic timeline; lab_results protocol
""")

def print_flow():
    subsection("DATA FLOW & MEMORY ARCHITECTURE")
    print("""
    ┌───────────────────────────────────────────────────────────────┐
    │                       PatientState                            │
    │                                                               │
    │  EPISODIC  (per-patient, MemorySaver + operator.add reducer)  │
    │    episode_log: List[{timestamp, message_summary,             │
    │                        action, escalation}]                   │
    │                        ↑ grows automatically across sessions  │
    │                                                               │
    │  SEMANTIC  (shared, loaded fresh on every session)            │
    │    semantic_rules     — clinical safety & escalation rules    │
    │    semantic_patterns  — observed patient behaviour signals    │
    │    semantic_protocols — care response templates by type       │
    └───────────────────────────┬───────────────────────────────────┘
                                │ initial state (input)
                                ▼
             ┌──────────────────────────────┐
             │      retrieve_episodic       │  Reads episode_log from state.
             │  "What has this patient     │  MemorySaver injects the full
             │   told us before?"          │  history for this thread_id.
             └──────────────┬───────────────┘
                            │ patient_context (prior session summary)
                            ▼
             ┌──────────────────────────────┐
             │      retrieve_semantic       │  LLM selects applicable rules,
             │  "What clinical protocols   │  patterns, and protocols from
             │   apply to this message?"   │  the shared knowledge base.
             └──────────────┬───────────────┘
                            │ relevant_guidance + escalation level
                            ▼
             ┌──────────────────────────────┐
             │      generate_response       │  Uses BOTH memories together:
             │  Personalised, protocol-    │  episodic (this patient's story)
             │  compliant patient reply    │  + semantic (clinical policy)
             └──────────────┬───────────────┘
                            │ response + episode_entry + escalation_flag
                            ▼
             ┌──────────────────────────────┐
             │      update_episodic         │  Returns {"episode_log": [entry]}
             │  "Remember this session     │  operator.add appends to the
             │   for Eleanor's next visit" │  existing list in MemorySaver.
             └──────────────────────────────┘

    MemorySaver key insight:
      thread_id = patient_id → each patient owns an isolated session timeline
      Same graph, same clinical rules, but DIFFERENT episodic histories per patient
      operator.add reducer   → entries accumulate; the initial [] adds nothing
      Eleanor's second session sees her first — David's session is completely clean
""")

# =============================================================================
# PATIENT SESSION DATA
# =============================================================================

SESSIONS = [
    {
        "patient_id":   "PT-7731",
        "patient_name": "Eleanor Vasquez",
        "message": (
            "Hello, I had my knee replacement surgery three days ago and was discharged "
            "this morning. I'm home now but I'm worried — the pain feels worse tonight "
            "than I was told to expect. I've taken my prescribed pain medication but it "
            "doesn't seem to be helping much. My pain is about a 7 out of 10. "
            "Is this normal? Should I be concerned?"
        ),
        "label": "SESSION 1 — Eleanor Vasquez, first contact  [episode_log: empty]",
    },
    {
        "patient_id":   "PT-7731",
        "patient_name": "Eleanor Vasquez",
        "message": (
            "Hi again, it's me from last night. I don't want to make a fuss but I noticed "
            "this morning that the skin around my knee incision looks a bit red and it feels "
            "warmer than the other knee. There's also some swelling around the stitches. "
            "It's probably nothing — I just wanted to check. The pain is still about a 7."
        ),
        "label": "SESSION 2 — Eleanor Vasquez, follow-up  [episode_log: 1 entry]",
    },
    {
        "patient_id":   "PT-4402",
        "patient_name": "David Park",
        "message": (
            "Hi, I had my annual physical last week and they took blood for a full panel. "
            "I haven't heard anything back yet. How long does it usually take to get results? "
            "My doctor mentioned checking my cholesterol and blood sugar. I'm a little anxious "
            "because my father had heart disease. Will someone call me if something is wrong?"
        ),
        "label": "SESSION 3 — David Park, first contact  [separate thread_id]",
    },
]

def initial_state_for(session_data: dict) -> PatientState:
    """
    Build the initial state for one patient session.
    episode_log is [] — MemorySaver injects the accumulated log automatically
    for returning patients; operator.add ensures [] adds nothing to it.
    """
    return {
        "patient_id":         session_data["patient_id"],
        "patient_name":       session_data["patient_name"],
        "message":            session_data["message"],
        "semantic_rules":     SEMANTIC_RULES,
        "semantic_patterns":  SEMANTIC_PATTERNS,
        "semantic_protocols": SEMANTIC_PROTOCOLS,
        "episode_log":        [],    # MemorySaver merges via operator.add reducer
        "patient_context":    "",
        "relevant_guidance":  "",
        "response":           "",
        "episode_entry":      {},
        "escalation_flag":    "none",
    }

# =============================================================================
# MAIN
# =============================================================================

ESCALATION_LABELS = {
    "none":           "No escalation — chatbot response only",
    "care_team":      "Care team notified",
    "nurse_callback": "*** NURSE CALLBACK SCHEDULED within 2 hours ***",
    "emergency":      "!!! EMERGENCY — 911 guidance provided !!!",
}

if __name__ == "__main__":
    print_story()
    pause("Press Enter to see the memory architecture diagram")

    print_flow()
    pause("Press Enter to start patient sessions")

    section(f"RUNNING PATIENT SUPPORT DEMO  —  Model: {MODEL_ID}")
    graph = build_graph()

    outputs_dir = Path(__file__).resolve().parent / "outputs"
    os.makedirs(outputs_dir, exist_ok=True)
    output_lines = ["# Meridian Health — Patient Support Chatbot Demo\n\n"]

    for idx, session_data in enumerate(SESSIONS):
        pid    = session_data["patient_id"]
        config = {"configurable": {"thread_id": pid}}

        subsection(session_data["label"])
        print(f"\n  PATIENT MESSAGE:\n  {session_data['message']}\n")
        pause("Press Enter to process this session")

        final_response = ""
        escalation     = "none"

        for step in graph.stream(initial_state_for(session_data), config=config):
            node_name = list(step.keys())[0]
            data      = step[node_name]

            if node_name == "retrieve_episodic":
                ctx = data.get("patient_context", "")
                print(f"\n  [STEP 1 — EPISODIC RETRIEVAL]\n  {ctx.replace(chr(10), chr(10)+'  ')}")

            elif node_name == "retrieve_semantic":
                guidance = data.get("relevant_guidance", "")
                print(f"\n  [STEP 2 — SEMANTIC RETRIEVAL]\n  {guidance.replace(chr(10), chr(10)+'  ')}")

            elif node_name == "generate_response":
                resp = data.get("response", "")
                escalation = data.get("escalation_flag", "none")
                print(f"\n  [STEP 3 — RESPONSE GENERATED]\n  {resp.replace(chr(10), chr(10)+'  ')}")
                print(f"\n  [ESCALATION STATUS]  {ESCALATION_LABELS.get(escalation, escalation)}")
                final_response = resp

            elif node_name == "update_episodic":
                added = data.get("episode_log", [])
                print(f"\n  [STEP 4 — EPISODIC UPDATE]  Appended {len(added)} new session record.")

        prior_sessions = idx if pid == "PT-7731" else 0
        print(f"\n  [MEMORY STATE] episode_log for {pid} now has "
              f"≥{prior_sessions + 1} session(s) stored in MemorySaver.")

        output_lines.append(f"## {session_data['label']}\n\n")
        output_lines.append(f"**Patient message:** {session_data['message']}\n\n")
        output_lines.append(f"**Escalation:** {ESCALATION_LABELS.get(escalation, escalation)}\n\n")
        output_lines.append(f"**Chatbot response:**\n{final_response}\n\n---\n\n")

        if idx < len(SESSIONS) - 1:
            pause("Press Enter for the next session")

    # Save combined output
    output_path = outputs_dir / "patient_support_memory.md"
    with open(output_path, "w") as f:
        f.writelines(output_lines)

    # ── Final explanation ──────────────────────────────────────────────────
    section("MEMORY PATTERN SUMMARY")
    print(f"""
  What just happened — two memory types in a clinical context:

  EPISODIC MEMORY  (MemorySaver + thread_id + operator.add reducer)
  ─────────────────────────────────────────────────────────────────
  • Session 1 → Eleanor (PT-7731): episode_log was EMPTY — first contact.
    Chatbot applied pain_management protocol; session recorded in MemorySaver.
    Escalation: none (high pain but within post-op window, medication advised).

  • Session 2 → Eleanor (PT-7731): episode_log had 1 ENTRY from Session 1.
    MemorySaver injected it automatically via the same thread_id.
    The chatbot now saw TWO signals together: prior pain (7/10) + new wound
    redness and warmth.  Combined, these match the post-surgical infection
    rule — escalation triggered → nurse callback scheduled within 2 hours.
    Without episodic memory the chatbot would have seen only "a bit red" and
    possibly said "that's normal" — missing a clinically significant pattern.

  • Session 3 → David (PT-4402): episode_log was EMPTY — different thread_id.
    Completely isolated episodic timeline.
    Eleanor's escalation had zero effect on David's session.
    Chatbot applied lab_results protocol: calm reassurance, portal guidance,
    explanation that care team calls proactively if results are abnormal.

  SEMANTIC MEMORY  (pre-loaded in state, shared across all patients)
  ──────────────────────────────────────────────────────────────────
  • All sessions loaded the same clinical rules, patterns, and protocols.
  • The retrieve_semantic node selected only what was relevant per message:
      Eleanor Session 1 → pain_management protocol, post-surgical care rules
      Eleanor Session 2 → post_surgical_concern protocol, wound-infection rule,
                          "same symptom recurring" escalation pattern
      David   Session 3 → lab_results_inquiry protocol, anxiety pattern
  • Semantic knowledge is hospital-wide — it belongs to no single patient.

  WHY IT MATTERS IN HEALTHCARE
  ─────────────────────────────
  Without episodic memory → Eleanor's second message is read in isolation.
    "A bit red, probably nothing" looks minor.  The chatbot misses that she
    also reported 7/10 pain the night before — a combination that warrants
    clinical review.  Patients are discharged home; continuity matters.

  Without semantic memory → responses are improvised with no clinical grounding.
    The chatbot cannot reliably know when to escalate vs. reassure, which
    symptoms are post-op normal vs. warning signs, or which protocol to apply.

  With BOTH → Eleanor gets the right care at the right time.
    David gets calm, accurate guidance without unnecessary alarm.
    Each patient is known and safe.

  Combined output saved → {output_path.name}

  NOTE: This demo is for educational purposes only.
  All clinical decisions must be made by qualified healthcare professionals.
""")
