#!/usr/bin/env python3
"""
Reflection Pattern Demonstration - Healthcare Discharge Summary

================================================================================
CRITIC PATTERN vs REFLECTION PATTERN — Key Difference:
================================================================================
CRITIC pattern   : A SEPARATE agent evaluates another agent's output within one
                   execution.  External quality control.  ("Is this good right now?")
                   → See demo 03 healthcare_critic.py

REFLECTION pattern : The SAME agent reviews its OWN previous outputs across
                     multiple iterations, accumulates self-critique notes, and
                     uses them to improve the NEXT attempt.
                     ("How do I get better over time / across iterations?")
                     → This demo

================================================================================
REFLECTION PATTERN — HOW IT WORKS:
================================================================================
Key characteristics:
  - Single agent identity (same role, same goal, same system prompt)
  - The agent reads back its OWN previous draft(s)
  - It writes explicit self-critique notes ("what did I miss?")
  - Those notes are carried in state and fed into the NEXT generation pass
  - This loop repeats N times — each iteration the draft gets better
  - The improvement comes from accumulated self-knowledge, not an external reviewer

Mechanics implemented in this demo:
  1. GraphState holds:  current_draft, reflection_notes (list), iteration count,
                        evaluation_scores (list of metric dicts per draft)
  2. generate_node  :  reads clinical notes + ALL previous reflection notes
                        → produces a new/improved draft
  3. evaluate_node  :  scores the current draft on 5 rule-based metrics
                        → completeness, medication detail, red flag coverage,
                           jargon clarity, word count — all 0-100
                        → computes a weighted OVERALL score
  4. reflect_node   :  reads the current draft
                        → writes honest self-critique (what's missing, what's vague)
                        → appends critique to reflection_notes list
  5. router         :  STOP if overall score >= QUALITY_THRESHOLD  ← early stop
                        STOP if iteration > MAX_REFLECTIONS        ← hard cap
                        CONTINUE → reflect (and then generate again)
  6. Each generate pass explicitly tells the LLM:
        "This is your Nth attempt.  Here is what you wrote before.
         Here are your own reflection notes.  Now do better."

Why this is Reflection, not Critic:
  - There is NO second agent.  The same Clinical Author generates AND reflects.
  - The "memory" of past mistakes accumulates in reflection_notes across iterations.
  - The agent is literally given its own words back and asked to improve on them.

================================================================================
EVALUATION METRICS (rule-based, deterministic — no extra LLM calls):
================================================================================
Metric                  Weight  What it measures
────────────────────────────────────────────────────────────────────────────────
Section Completeness      30%   Are all 4 required sections present?
Medication Detail         30%   Do mentioned medications have doses + schedules?
Red Flag Coverage         20%   Does the summary tell the patient when to call
                                911 vs. when to call the doctor?
Jargon Clarity            10%   Are medical terms explained in plain language?
Word Count Score          10%   Proxy for thoroughness (length vs. quality)
────────────────────────────────────────────────────────────────────────────────
OVERALL (weighted)              Combined score used for stop decision

Stop conditions (evaluated after EVERY draft):
  1. QUALITY_THRESHOLD : if OVERALL >= threshold AND >= MIN_REFLECTIONS passes done
                         → stop early (goal achieved, improvement already visible)
  2. MIN_REFLECTIONS   : early stop is BLOCKED until this many passes have run
                         → guarantees the improvement trend is demonstrable
  3. MAX_REFLECTIONS   : hard cap → stop regardless of score after this many passes

================================================================================
DEMO DESCRIPTION:
================================================================================
Use Case: John Smith, 67 y/o STEMI patient + new diabetes diagnosis.

WHY DOES DRAFT 1 SCORE POORLY? — intentional staging:
  The clinical notes are in raw medical shorthand (ASA qd, Clopi bid, EF 45%,
  DES to LAD, DM2, HbA1c, etc.).  The first-pass prompt gives the agent NO
  section guidance and asks for a "quick first draft", so it writes a clinical-
  style summary that leaves abbreviations unexplained, skips the patient
  instructions section, and omits emergency/red-flag guidance.

  Reflection then identifies exactly these gaps → later drafts fix them →
  metrics visibly rise.  Each evaluate pass prints a WHY DID SCORES CHANGE?
  explanation that traces: reflection note → agent action → metric movement.

Loop:
  - Draft 1   : Quick first draft from raw abbreviated notes (baseline — low scores)
  - Evaluate 1: Metrics reveal abbreviation + section gaps
  - Reflect  1: Agent critiques its own abbreviations, missing sections, jargon
  - Draft 2   : Rewrites — expands drugs, adds sections  (scores improve)
  - Evaluate 2: WHY? explanation + routing check
  - Reflect  2: Critiques remaining gaps (red flags, detail, clarity)
  - Draft 3   : Further improvement — eligible for early stop if OVERALL >= 90%
  - ...up to Draft 5 (MAX_REFLECTIONS=4) if threshold not reached
  - Final     : Progression table shows the full metric trajectory

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework : LangGraph  (StateGraph with a loop — generate → evaluate → reflect)
  - Conditional edge: router decides whether to loop or end (early or hard cap)
  - GraphState: TypedDict carrying drafts, reflection history, eval scores

LLM Model : AWS Bedrock via langchain-aws ChatBedrock
  - Model ID : amazon.nova-micro-v1:0  (overridable via BEDROCK_MODEL_ID)
  - Region   : us-east-1               (overridable via AWS_REGION)

Data:
  - Input  : data/clinical_notes.txt
  - Output : outputs/healthcare_reflection_summary.md
================================================================================
"""

import os
import re
import sys
from pathlib import Path
from typing import TypedDict

from dotenv import load_dotenv
from langchain_aws import ChatBedrock
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph

import warnings
warnings.filterwarnings("ignore")

# Ensure UTF-8 output on Windows (avoids cp1252 errors with LLM Unicode output)
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------
def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent


PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")

# Single LLM instance — the SAME model is used for both generate and reflect nodes.
# This is the core characteristic of the Reflection pattern: one agent, two roles.
llm = ChatBedrock(
    model_id=MODEL_ID,
    region_name=AWS_REGION,
    model_kwargs={"temperature": 0.7},
)

MAX_REFLECTIONS   = 4     # hard cap: number of reflect→generate loops after first draft
MIN_REFLECTIONS   = 2     # minimum reflect passes before early stop is eligible
QUALITY_THRESHOLD = 90.0  # early-stop: if OVERALL score reaches this AND MIN_REFLECTIONS done


# ---------------------------------------------------------------------------
# GRAPH STATE
# ---------------------------------------------------------------------------
class GraphState(TypedDict):
    clinical_notes:    str          # raw input — set once, never changed
    current_draft:     str          # latest generated discharge summary
    reflection_notes:  list[str]    # self-critique from each reflection pass
    draft_history:     list[str]    # every draft produced so far (for comparison)
    iteration:         int          # which generation pass we are on (starts at 1)
    evaluation_scores: list[dict]   # quality metrics dict for each draft produced


# ---------------------------------------------------------------------------
# PROMPTS — module-level constants so they can be printed before the run
# ---------------------------------------------------------------------------

# Shared system prompt — the agent identity never changes across iterations.
# This is crucial to the Reflection pattern: the SAME agent generates and reflects.
AGENT_SYSTEM = (
    "You are a Clinical Author — a hospitalist who writes patient discharge summaries. "
    "You care deeply about patient safety and plain language. "
    "When asked to reflect, you review your own work honestly and identify every gap. "
    "When asked to generate, you use your own reflection notes to produce a better version."
)

# Generation prompt — first iteration (deliberately minimal: no section guidance,
# no instruction to translate abbreviations or write for a patient audience).
# The clinical notes use medical shorthand (ASA, Clopi, DES, EF, DM2, qd, bid, etc.).
# A first-pass LLM on raw abbreviated notes will produce a clinical-style draft that:
#   - leaves abbreviations unexplained
#   - may lack a "Patient Instructions" section
#   - may omit emergency/red-flag guidance
#   - scores poorly on jargon and red-flag metrics
# This intentional weakness is what reflection then corrects, iteration by iteration.
GENERATE_FIRST_PROMPT = """\
You are a hospitalist writing a first-draft discharge summary from the clinical notes below.
The notes use standard medical shorthand and abbreviations.

Write a discharge summary from these notes. This is a quick first draft.

--- CLINICAL NOTES (medical shorthand) ---
{clinical_notes}
-------------------------------------------
"""

# Generation prompt — subsequent iterations (agent sees its own previous draft
# AND its own accumulated reflection notes — this is the "learning" mechanism)
GENERATE_IMPROVE_PROMPT = """\
This is your REVISION PASS #{iteration} of the discharge summary.

You have already written {iteration_minus_1} version(s) of this summary.
Below are your own reflection notes — issues you identified in your previous work.
Use these notes to produce a BETTER, SAFER, and CLEARER version.

--- YOUR PREVIOUS DRAFT ---
{previous_draft}
---------------------------

--- YOUR OWN REFLECTION NOTES (accumulated across all passes) ---
{all_reflection_notes}
-----------------------------------------------------------------

Now write the improved discharge summary.  Address EVERY point in your reflection notes.
Keep the same sections:
1. Diagnosis & Hospital Course
2. Medications  (name, dose, schedule, critical warnings)
3. Follow-up & Monitoring  (named providers + timelines)
4. Patient Instructions  (plain language — no unexplained medical jargon)
"""

# Reflection prompt — agent reviews its own draft and writes self-critique.
# Framed as internal monologue / honest self-assessment, not an external review.
# Targets the specific weaknesses of a first draft written from abbreviated notes:
#   - unexpanded abbreviations (ASA, Clopi, DES, EF, DM2, BB, ACEi, qd, bid, qhs)
#   - missing patient-facing sections (Patient Instructions, emergency guidance)
#   - incomplete medication details
REFLECT_PROMPT = """\
You are reviewing YOUR OWN discharge summary draft.
Be brutally honest.  Patients and families will read this — any gap could harm them.

The ORIGINAL clinical notes used medical shorthand abbreviations.
Check whether you translated EVERY abbreviation into plain English a patient understands.

Answer each question with specific, numbered findings:

1. ABBREVIATIONS  : List every medical abbreviation or term in YOUR DRAFT that a
                    non-medical patient would NOT understand.  For each one state:
                    what it means and what plain-language replacement to use.
                    Check especially: ASA, Clopi, DES, EF, HbA1c, DM2, BB, ACEi,
                    PCI, qd, bid, qhs, LAD, STEMI, hypokinesis, troponin.

2. MISSING SECTIONS: Does your draft have ALL four required sections?
                    - Diagnosis & Hospital Course
                    - Medications (with full name, dose in mg, schedule for EACH drug)
                    - Follow-up & Monitoring (named providers + specific timelines)
                    - Patient Instructions (plain language — when to call 911 vs doctor)
                    List any section that is absent or incomplete.

3. MEDICATIONS    : For each of the 6 discharge medications, did you write the
                    FULL drug name, exact dose (mg), and exact schedule (daily/twice daily/
                    at bedtime/with meals)?  Flag any medication with missing details.
                    Also: did you warn about Clopidogrel — never stop without calling cardiology?

4. RED FLAGS      : Did you explicitly tell the patient WHEN to call 911 (chest pain,
                    trouble breathing, sudden weakness) vs. WHEN to call the doctor?
                    If this section is missing or vague, say so.

5. COMPLETENESS   : What important information from the original notes did you omit?

Write your critique as a specific numbered list.
("'ASA' was not translated — replace with 'Aspirin 81 mg'" is useful.
 "Improve clarity" is useless.)

--- YOUR DRAFT ---
{current_draft}
-----------------
"""


# ===========================================================================
# EVALUATION METRICS — rule-based, deterministic, no LLM calls
# ===========================================================================

# Medications present in John Smith's clinical notes — FULL names only.
# Abbreviated forms (ASA, Clopi, Metop, etc.) are intentionally excluded here:
# if the agent copies abbreviations from the notes without expanding them, the
# medication won't be "found" → the detail score stays low → reflection notices →
# later drafts expand abbreviations → score improves.  This is the learning signal.
KNOWN_MEDICATIONS = [
    "aspirin",
    "clopidogrel", "plavix",
    "metoprolol",
    "lisinopril",
    "atorvastatin",
    "metformin",
]

# Medical jargon / abbreviations a layperson would NOT understand.
# Includes the shorthand from the new abbreviated clinical notes so the jargon
# metric scores low on a first draft that simply copies the abbreviations unchanged.
MEDICAL_JARGON = [
    # Clinical abbreviations from the new notes
    "asa",          # → aspirin
    "clopi",        # → clopidogrel / Plavix
    "metop succ",   # → metoprolol succinate
    "lisinopr",     # → lisinopril
    "atorvast",     # → atorvastatin
    "metfm",        # → metformin
    " qd",          # → once daily
    " bid",         # → twice daily
    " qhs",         # → at bedtime
    "dm2",          # → type 2 diabetes
    "hba1c",        # → blood sugar control test
    " ef ",         # → ejection fraction (pumping strength)
    "des ",         # → drug-eluting stent
    # Longer medical terms
    "stemi", "pci", "percutaneous coronary intervention", "hypokinesis",
    "ejection fraction", "lvef", "nstemi",
    "troponin", "revascularization", "angioplasty",
    "diaphoresis", "drug-eluting stent", "antiplatelet",
]

_DOSE_RE     = re.compile(r"\d+\s*mg|\d+\s*units|\d+\s*mcg|\d+\s*ml", re.IGNORECASE)
_SCHEDULE_KW = [
    "daily", "twice", "bid", "morning", "evening", "night",
    "once a day", "twice a day", "weekly", "with meals", "as needed", "prn",
    "every", "hours",
]
_EMERGENCY_RE = [
    r"call\s+9\s*1\s*1", r"go\s+to\s+the\s+er\b", r"go\s+to\s+the\s+emergency",
    r"emergency\s+room", r"call\s+emergency", r"\b911\b",
]
_DOCTOR_CALL_KW = [
    "call your doctor", "contact your doctor", "call dr.",
    "notify your doctor", "call the clinic", "call your provider",
    "call your cardiologist", "call your physician",
]


def evaluate_draft(draft: str) -> dict:
    """
    Score a discharge summary draft on 5 rule-based metrics (all 0–100).

    No LLM is used here — evaluation is instant and deterministic.
    """
    text       = draft.lower()
    word_count = len(draft.split())

    # ------------------------------------------------------------------
    # 1. Section Completeness (0-100)
    #    Are all four required sections present?
    # ------------------------------------------------------------------
    section_checks = [
        any(k in text for k in [
            "diagnosis", "hospital course", "admission",
            "what happened", "your hospital stay", "your condition",
            "your diagnosis", "during your stay",
        ]),
        any(k in text for k in ["medication", "medications", "prescription", "your medicines"]),
        any(k in text for k in [
            "follow-up", "follow up", "appointment", "outpatient",
            "monitoring", "after discharge", "your next visit",
        ]),
        any(k in text for k in [
            "patient instruction", "instructions", "warning sign", "what to do",
            "when to call", "seek help", "seek care", "emergency", "warning",
            "signs to watch", "call 911", "go to the er",
        ]),
    ]
    completeness = sum(section_checks) / len(section_checks) * 100

    # ------------------------------------------------------------------
    # 2. Medication Detail Score (0-100)
    #    For each medication found: does it have a dose AND a schedule?
    #    Full credit (1.0) if both; half credit (0.5) if only one.
    # ------------------------------------------------------------------
    meds_found = [m for m in KNOWN_MEDICATIONS if m in text]
    if not meds_found:
        med_detail = 0.0
    else:
        detail_pts = 0.0
        for med in meds_found:
            idx     = text.find(med)
            context = text[max(0, idx - 50): idx + 400]
            has_dose     = bool(_DOSE_RE.search(context))
            has_schedule = any(w in context for w in _SCHEDULE_KW)
            if has_dose and has_schedule:
                detail_pts += 1.0
            elif has_dose or has_schedule:
                detail_pts += 0.5
        med_detail = (detail_pts / len(meds_found)) * 100

    # ------------------------------------------------------------------
    # 3. Red Flag Coverage (0-100)
    #    Does the summary tell the patient when to call 911 vs. the doctor?
    # ------------------------------------------------------------------
    has_emergency   = any(re.search(p, text) for p in _EMERGENCY_RE)
    has_chest_pain  = "chest pain" in text
    has_doctor_call = any(w in text for w in _DOCTOR_CALL_KW)
    has_symptom_kw  = any(w in text for w in [
        "shortness of breath", "dizziness", "bleeding", "blood sugar", "swelling",
    ])
    red_flag = (
          (40 if has_emergency   else 0)
        + (20 if has_chest_pain  else 0)
        + (20 if has_doctor_call else 0)
        + (20 if has_symptom_kw  else 0)
    )

    # ------------------------------------------------------------------
    # 4. Jargon Clarity Score (0-100)
    #    Penalise each medical term that appears without an inline explanation.
    #    Explanation markers: "(", "meaning", "which means", "also known", etc.
    # ------------------------------------------------------------------
    unexplained = 0
    for term in MEDICAL_JARGON:
        if term in text:
            idx           = text.find(term)
            context_after = text[idx: idx + 130]
            has_explain   = any(m in context_after for m in [
                "(", "meaning", "which means", "also known", "or ", " — ", " - ", "=",
            ])
            if not has_explain:
                unexplained += 1
    jargon = max(0.0, 100.0 - unexplained * 15)

    # ------------------------------------------------------------------
    # 5. Word Count Score (0-100) — proxy for thoroughness
    # ------------------------------------------------------------------
    if   word_count < 150:  wc_score = 10
    elif word_count < 300:  wc_score = 40
    elif word_count < 500:  wc_score = 65
    elif word_count < 700:  wc_score = 80
    elif word_count < 1000: wc_score = 90
    else:                   wc_score = 100

    # ------------------------------------------------------------------
    # Weighted overall score
    # ------------------------------------------------------------------
    overall = (
        completeness * 0.30
        + med_detail * 0.30
        + red_flag   * 0.20
        + jargon     * 0.10
        + wc_score   * 0.10
    )

    return {
        "completeness":      round(completeness, 1),
        "medication_detail": round(med_detail,   1),
        "red_flag_coverage": round(red_flag,     1),
        "jargon_clarity":    round(jargon,       1),
        "word_count_score":  round(wc_score,     1),
        "word_count":        word_count,
        "overall":           round(overall,      1),
    }


# ---------------------------------------------------------------------------
# Display helpers for metrics
# ---------------------------------------------------------------------------
_METRIC_LABELS = {
    "completeness":      "Section Completeness    (30%)",
    "medication_detail": "Medication Detail       (30%)",
    "red_flag_coverage": "Red Flag Coverage       (20%)",
    "jargon_clarity":    "Jargon Clarity          (10%)",
    "word_count_score":  "Word Count / Depth      (10%)",
}

_METRIC_NOTES = {
    "completeness":      lambda v: "(missing sections)" if v < 100 else "",
    "medication_detail": lambda v: "(missing dose/schedule details)" if v < 70 else "",
    "red_flag_coverage": lambda v: "(missing 911 / doctor-call guidance)" if v < 60 else "",
    "jargon_clarity":    lambda v: "(unexplained medical terms found)" if v < 70 else "",
    "word_count_score":  lambda v: "(summary is brief)" if v < 65 else "",
}


def _bar(score: float, width: int = 12) -> str:
    """ASCII progress bar for a 0-100 score."""
    filled = round(score / 100 * width)
    return "█" * filled + "░" * (width - filled)


def print_metrics_table(scores: dict) -> None:
    """Print a formatted, single-draft metrics table."""
    print(f"  {'Metric':<38}  {'Score':>6}  {'Progress':<13}  Notes")
    print("  " + "─" * 80)
    for key, label in _METRIC_LABELS.items():
        val  = scores[key]
        note = _METRIC_NOTES[key](val)
        print(f"  {label:<38}  {val:>5.1f}  {_bar(val):<13}  {note}")
    print("  " + "─" * 80)
    overall = scores["overall"]
    status  = (
        f"THRESHOLD {QUALITY_THRESHOLD} MET — early stop!"
        if overall >= QUALITY_THRESHOLD
        else f"below threshold {QUALITY_THRESHOLD} — loop continues"
    )
    print(f"  {'OVERALL SCORE (weighted)':<38}  {overall:>5.1f}  {_bar(overall):<13}  [{status}]")
    print(f"  (word count: {scores['word_count']} words)")
    print()


def print_progression_table(all_scores: list[dict]) -> None:
    """Print a side-by-side metric comparison across all drafts."""
    n     = len(all_scores)
    col_w = 9

    print(f"  {'Metric':<34}", end="")
    for i in range(n):
        lbl = f"Draft {i + 1}" + (" (final)" if i == n - 1 else "")
        print(f"  {lbl:>{col_w}}", end="")
    print(f"  {'Change':>{col_w}}")
    print("  " + "─" * (34 + (col_w + 2) * (n + 1) + 2))

    row_keys = list(_METRIC_LABELS.keys()) + ["overall"]
    row_labels = {**{k: v.split(" (")[0].strip() for k, v in _METRIC_LABELS.items()},
                  "overall": "OVERALL SCORE"}

    for key in row_keys:
        label  = row_labels[key]
        values = [s[key] for s in all_scores]
        change = values[-1] - values[0]
        arrow  = "▲" if change > 0 else ("▼" if change < 0 else "─")
        ch_str = f"{arrow} {abs(change):.1f}"
        marker = "  ◄ KEY" if key == "overall" else ""
        print(f"  {label:<34}", end="")
        for val in values:
            print(f"  {val:>{col_w}.1f}", end="")
        print(f"  {ch_str:>{col_w}}{marker}")

    # Stop-reason row
    stop_draft = next(
        (i + 1 for i, s in enumerate(all_scores) if s["overall"] >= QUALITY_THRESHOLD),
        None,
    )
    print()
    if stop_draft and stop_draft < len(all_scores) + 1:
        if all_scores[-1]["overall"] >= QUALITY_THRESHOLD and len(all_scores) <= MAX_REFLECTIONS:
            print(f"  >> EARLY STOP triggered at Draft {len(all_scores)}: "
                  f"overall score {all_scores[-1]['overall']} >= threshold {QUALITY_THRESHOLD}")
        else:
            print(f"  >> Hard cap ({MAX_REFLECTIONS} reflections) reached.")
    else:
        print(f"  >> Hard cap ({MAX_REFLECTIONS} reflections) reached.")
    print()


# ---------------------------------------------------------------------------
# WHY DID SCORES CHANGE? — per-metric improvement explanations
# ---------------------------------------------------------------------------
_CHANGE_REASONS = {
    "completeness": {
        "up":   (
            "The agent added sections that were missing from the previous draft.\n"
            "    Reflection explicitly listed which of the 4 required sections were absent\n"
            "    (Diagnosis / Medications / Follow-up / Patient Instructions), so the\n"
            "    agent included them in the rewrite."
        ),
        "down": (
            "A section heading that was previously detected is no longer found.\n"
            "    The agent may have merged or renamed a section — the metric uses keyword\n"
            "    matching, so heading wording matters."
        ),
        "same": "All required section headings are still present (or still absent).",
    },
    "medication_detail": {
        "up":   (
            "The agent expanded abbreviated drug names (ASA→Aspirin, Clopi→Clopidogrel,\n"
            "    Metop→Metoprolol, etc.) and/or added explicit mg doses and plain-English\n"
            "    schedules (daily / twice daily / at bedtime).  Reflection listed each drug\n"
            "    that was missing detail — the agent addressed those gaps."
        ),
        "down": (
            "Some medications lost their detail in the rewrite (e.g. dose or schedule\n"
            "    dropped, or a drug name changed back to abbreviation form)."
        ),
        "same": "Medication name/dose/schedule coverage unchanged between drafts.",
    },
    "red_flag_coverage": {
        "up":   (
            "The agent added a dedicated emergency section.  Reflection asked:\n"
            "    'When should the patient call 911 vs. call the doctor?' — the agent\n"
            "    then added explicit 911 guidance, symptom lists, and doctor-call triggers."
        ),
        "down": (
            "Some emergency keywords (911 / call your doctor / chest pain) are no longer\n"
            "    present in the new draft.  The agent may have condensed or dropped the\n"
            "    patient-safety section."
        ),
        "same": "Emergency guidance coverage unchanged.",
    },
    "jargon_clarity": {
        "up":   (
            "The agent translated more medical abbreviations and jargon into plain language.\n"
            "    Reflection gave a specific list of unexplained terms (EF, DM2, PCI, qd,\n"
            "    bid, HbA1c, etc.).  The agent replaced or parenthetically explained each\n"
            "    one — e.g. 'EF 45%' → 'your heart pumps at 45% strength (normal ≥ 55%)'."
        ),
        "down": (
            "The agent introduced new medical terms or abbreviations without explanation,\n"
            "    or removed previously-added inline explanations."
        ),
        "same": "Jargon level unchanged — same terms explained (or unexplained) as before.",
    },
    "word_count_score": {
        "up":   (
            "The summary grew longer because the agent added the missing sections and\n"
            "    expanded terse abbreviations into full sentences.  Longer here means\n"
            "    more thorough, not more verbose."
        ),
        "down": "The agent condensed the summary — it moved to a lower word-count bracket.",
        "same": "Word count stayed in the same bracket (no tier change).",
    },
}


def explain_score_changes(prev: dict, curr: dict, draft_num: int) -> None:
    """
    Print a per-metric explanation of why scores changed between two consecutive drafts.

    Called after the evaluate node fires for Draft 2, 3, 4 ... (not Draft 1).
    The explanations map directly to what the reflection prompt asks about, so the
    audience can trace: reflection identifies gap → agent addresses it → metric rises.
    """
    overall_delta = curr["overall"] - prev["overall"]
    direction     = "improved" if overall_delta > 0 else ("declined" if overall_delta < 0 else "unchanged")

    print(f"  WHY DID SCORES CHANGE?  (Draft {draft_num - 1} → Draft {draft_num})")
    print("  " + "─" * 68)
    print(f"  OVERALL: {prev['overall']:.1f} → {curr['overall']:.1f}  "
          f"({'+'if overall_delta >= 0 else ''}{overall_delta:.1f})  — {direction}")
    print()

    for key, label_raw in _METRIC_LABELS.items():
        label = label_raw.split("(")[0].strip()
        delta = curr[key] - prev[key]
        if delta > 1:
            arrow, reason = "▲", _CHANGE_REASONS[key]["up"]
        elif delta < -1:
            arrow, reason = "▼", _CHANGE_REASONS[key]["down"]
        else:
            arrow, reason = "─", _CHANGE_REASONS[key]["same"]
        sign = f"+{delta:.0f}" if delta > 0 else f"{delta:.0f}"
        print(f"  {arrow} {label}:  {prev[key]:.0f} → {curr[key]:.0f}  ({sign})")
        print(f"    {reason}")
        print()


# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------
def read_notes() -> str:
    data_path = Path(__file__).resolve().parent / "data" / "clinical_notes.txt"
    with open(data_path, "r") as f:
        return f.read()


def pause(msg: str = "") -> None:
    """Print an optional message then wait for Enter.
    Falls back silently when stdin is not a TTY."""
    if msg:
        print(msg)
    try:
        input("  >>> Press Enter to continue... ")
    except EOFError:
        print("  [non-interactive: continuing automatically]")
    print()


def format_reflection_notes(notes: list[str]) -> str:
    """Format all accumulated reflection notes for injection into a prompt."""
    if not notes:
        return "(none yet)"
    sections = []
    for i, note in enumerate(notes, 1):
        sections.append(f"[Reflection pass {i}]\n{note}")
    return "\n\n".join(sections)


# ---------------------------------------------------------------------------
# LANGGRAPH NODE: generate
# ---------------------------------------------------------------------------
def generate_node(state: GraphState) -> dict:
    """
    The agent writes (or rewrites) the discharge summary.

    Iteration 1 : only has clinical notes → writes from scratch
    Iteration 2+: has previous draft + ALL reflection notes → improves
    """
    iteration = state["iteration"]

    if iteration == 1:
        user_prompt = GENERATE_FIRST_PROMPT.format(
            clinical_notes=state["clinical_notes"]
        )
    else:
        user_prompt = GENERATE_IMPROVE_PROMPT.format(
            iteration=iteration,
            iteration_minus_1=iteration - 1,
            previous_draft=state["current_draft"],
            all_reflection_notes=format_reflection_notes(state["reflection_notes"]),
        )

    messages = [
        SystemMessage(content=AGENT_SYSTEM),
        HumanMessage(content=user_prompt),
    ]
    response  = llm.invoke(messages)
    new_draft = response.content

    updated_history = state["draft_history"] + [new_draft]

    return {
        "current_draft": new_draft,
        "draft_history": updated_history,
        "iteration":     iteration,   # iteration incremented by reflect_node
    }


# ---------------------------------------------------------------------------
# LANGGRAPH NODE: evaluate
# ---------------------------------------------------------------------------
def evaluate_node(state: GraphState) -> dict:
    """
    Score the current draft on 5 rule-based metrics and append results to state.

    This node fires after EVERY generate pass — no LLM call, instant.
    The router reads evaluation_scores[-1]["overall"] to decide whether to stop.
    """
    scores          = evaluate_draft(state["current_draft"])
    updated_scores  = state["evaluation_scores"] + [scores]
    return {"evaluation_scores": updated_scores}


# ---------------------------------------------------------------------------
# LANGGRAPH NODE: reflect
# ---------------------------------------------------------------------------
def reflect_node(state: GraphState) -> dict:
    """
    The SAME agent reads its own current draft and writes self-critique notes.
    These notes are appended to reflection_notes in the state — they persist
    and accumulate across all iterations.  The next generate pass will see ALL
    of them.
    """
    user_prompt = REFLECT_PROMPT.format(current_draft=state["current_draft"])

    messages = [
        SystemMessage(content=AGENT_SYSTEM),
        HumanMessage(content=user_prompt),
    ]
    response       = llm.invoke(messages)
    new_reflection = response.content

    updated_reflections = state["reflection_notes"] + [new_reflection]

    return {
        "reflection_notes": updated_reflections,
        "iteration":        state["iteration"] + 1,   # increment for next generate pass
    }


# ---------------------------------------------------------------------------
# ROUTER — conditional edge after evaluate
#
# Two stop conditions (checked in priority order):
#   1. QUALITY_THRESHOLD : overall score reached the target → early stop
#   2. MAX_REFLECTIONS   : hard cap on reflection passes     → stop
# Otherwise continue → reflect → generate (another loop)
#
# Flow with MAX_REFLECTIONS=2, NO early stop:
#   generate(1) → evaluate → reflect(→2) → generate(2)
#   → evaluate → reflect(→3) → generate(3) → evaluate → END
#   = 3 drafts, 3 evaluations, 2 reflection passes, 5 LLM calls
#
# Flow with early stop at Draft 2 (score >= threshold after 1 reflection):
#   generate(1) → evaluate → reflect(→2) → generate(2) → evaluate → END
#   = 2 drafts, 2 evaluations, 1 reflection pass, 3 LLM calls  [saved work!]
# ---------------------------------------------------------------------------
def router(state: GraphState) -> str:
    """After evaluate: early-stop, hard-cap stop, or continue to reflect."""
    scores = state.get("evaluation_scores", [])

    # Priority 1 — quality threshold (early stop), but only after MIN_REFLECTIONS passes.
    # len(scores) == number of drafts evaluated so far.
    # len(scores) > MIN_REFLECTIONS means at least MIN_REFLECTIONS reflect passes have run,
    # so the improvement trend is visible before we commit to stopping.
    if len(scores) > MIN_REFLECTIONS and scores[-1]["overall"] >= QUALITY_THRESHOLD:
        return END

    # Priority 2 — hard cap
    if state["iteration"] > MAX_REFLECTIONS:
        return END

    return "reflect"


# ---------------------------------------------------------------------------
# BUILD LANGGRAPH PIPELINE
#
#   START → generate → evaluate → router ──► reflect ─┐
#                                └─► END              │
#                    ◄───────────────────────────────────┘
#
# generate and reflect are the only nodes that call the LLM.
# evaluate is a pure Python function — no LLM, no latency.
# ---------------------------------------------------------------------------
graph_builder = StateGraph(GraphState)
graph_builder.add_node("generate", generate_node)
graph_builder.add_node("evaluate", evaluate_node)
graph_builder.add_node("reflect",  reflect_node)

graph_builder.add_edge(START,      "generate")
graph_builder.add_edge("generate", "evaluate")            # always score after draft
graph_builder.add_conditional_edges("evaluate", router)   # early-stop / hard-cap / continue
graph_builder.add_edge("reflect",  "generate")            # loop back

app = graph_builder.compile()


# ===========================================================================
# MAIN — narrated walkthrough of the Reflection pattern
# ===========================================================================
if __name__ == "__main__":

    # -----------------------------------------------------------------------
    # INTRODUCTION
    # -----------------------------------------------------------------------
    print("=" * 70)
    print("  REFLECTION PATTERN DEMO  —  Healthcare Discharge Summary")
    print("=" * 70)
    print()
    print("WHAT IS THE REFLECTION PATTERN?")
    print("-" * 70)
    print("The Reflection pattern uses a SINGLE agent that iterates on its own")
    print("output.  After each draft, the same agent reads back what it wrote,")
    print("identifies gaps and mistakes, and carries those self-critique notes")
    print("into the next generation pass.")
    print()
    print("  Same agent  : Clinical Author (generates AND reflects)")
    print("  Loop        : generate → evaluate → reflect → generate → ...")
    print(f"  Max drafts  : {MAX_REFLECTIONS + 1}  (hard cap at {MAX_REFLECTIONS} reflect passes)")
    print(f"  Min passes  : {MIN_REFLECTIONS} reflection pass(es) always run (to show improvement)")
    print(f"  Early stop  : if OVERALL >= {QUALITY_THRESHOLD} AND >= {MIN_REFLECTIONS} passes done")
    print()
    print("  HOW IT DIFFERS FROM THE CRITIC PATTERN (demo 03):")
    print("    Critic  = separate QA agent, one shot, external evaluation")
    print("    Reflect = same agent, multiple loops, self-accumulated memory")
    print()
    print("  NEW IN THIS DEMO — EVALUATION METRICS:")
    print("    After every draft, 5 rule-based metrics are scored (0-100):")
    print("      • Section Completeness  (30% weight)")
    print("      • Medication Detail     (30% weight)")
    print("      • Red Flag Coverage     (20% weight)")
    print("      • Jargon Clarity        (10% weight)")
    print("      • Word Count / Depth    (10% weight)")
    print("    The OVERALL weighted score drives the stop decision:")
    print(f"      >= {QUALITY_THRESHOLD}  → early stop (quality target reached)")
    print(f"      < {QUALITY_THRESHOLD} and reflections remain → continue loop")
    print()
    print(f"  LLM backend : {MODEL_ID}  (AWS Bedrock)")
    print(f"  AWS region  : {AWS_REGION}")
    print(f"  Framework   : LangGraph  (generate → evaluate → reflect loop)")
    print()
    pause(
        "PATIENT SCENARIO\n"
        + "-" * 70 + "\n"
        + "John Smith, 67 y/o male, admitted with an acute heart attack (STEMI).\n"
        + "Emergency stent surgery.  Newly diagnosed diabetes.  7 medications.\n"
        + "\n"
        + "WHY DOES DRAFT 1 SCORE POORLY?  (intentional design)\n"
        + "  The clinical notes are in raw medical shorthand:\n"
        + "    ASA 81 qd / Clopi 75 qd / Metop succ 50 / DES to LAD / EF 45%\n"
        + "  The first-pass prompt gives NO section guidance and asks for a 'quick draft'.\n"
        + "  A hospitalist writing fast will:\n"
        + "    - Leave abbreviations unexplained (patients don't know ASA = Aspirin)\n"
        + "    - Skip the Patient Instructions / emergency guidance section\n"
        + "    - Miss doses/schedules for abbreviated drug names\n"
        + "  → Low scores on Jargon, Red Flags, Medication Detail.\n"
        + "\n"
        + "  Each reflection pass explicitly asks 'which abbreviations did you miss?'\n"
        + "  The agent fixes them → metrics visibly rise iteration by iteration.\n"
        + "  After EACH draft you will see a 'WHY DID SCORES CHANGE?' explanation."
    )

    # -----------------------------------------------------------------------
    # SHOW AGENT CONFIGURATION
    # -----------------------------------------------------------------------
    print("AGENT CONFIGURATION  (identical for generate AND reflect nodes)")
    print("-" * 70)
    print("Because this is the Reflection pattern, the SAME system prompt governs")
    print("both the generation pass and the self-reflection pass.")
    print()
    print("  [SYSTEM PROMPT — used for every LLM call in this pipeline]")
    print(f'  "{AGENT_SYSTEM}"')
    print()
    pause()

    # -----------------------------------------------------------------------
    # SHOW THE EVALUATION METRICS DESIGN
    # -----------------------------------------------------------------------
    print("EVALUATION DESIGN — How Each Draft is Scored")
    print("-" * 70)
    print("  Five metrics are computed from the draft text using string matching.")
    print("  No LLM needed — evaluation is instant and objective.")
    print()
    print("  Metric                      Weight  What triggers a LOW score on Draft 1?")
    print("  " + "-" * 72)
    print("  Section Completeness          30%   Missing Patient Instructions section —")
    print("                                      a 'quick clinical draft' often skips it")
    print("  Medication Detail             30%   Abbreviated drug names (ASA, Clopi, Metop)")
    print("                                      not detected as the full drug name —")
    print("                                      must expand to Aspirin/Clopidogrel/etc.")
    print("  Red Flag Coverage             20%   No 911 or 'call your doctor' section —")
    print("                                      clinical drafts omit patient-safety text")
    print("  Jargon Clarity                10%   Abbreviations (qd, bid, DES, EF, DM2)")
    print("                                      appear without plain-English explanation")
    print("  Word Count / Depth            10%   Short draft = lower word-count bracket")
    print()
    print(f"  EARLY STOP threshold  : OVERALL >= {QUALITY_THRESHOLD}  (eligible after {MIN_REFLECTIONS} passes)")
    print(f"  MINIMUM passes        : {MIN_REFLECTIONS}  (early stop blocked until this many passes run)")
    print(f"  HARD CAP              : {MAX_REFLECTIONS} reflection passes "
          f"({MAX_REFLECTIONS + 1} drafts max)")
    print()
    pause()

    # -----------------------------------------------------------------------
    # SHOW THE THREE PROMPTS
    # -----------------------------------------------------------------------
    notes = read_notes()

    print("PROMPT 1 — First-pass generation  (Iteration 1, no prior history)")
    print("-" * 70)
    for line in GENERATE_FIRST_PROMPT.format(clinical_notes=notes).splitlines():
        print(f"    {line}")
    print()
    pause()

    print("PROMPT 2 — Self-reflection  (agent reviews its own draft)")
    print("-" * 70)
    print("  [The agent reads its own draft back and writes an honest self-critique.]")
    print("  [{current_draft} will contain the actual draft at runtime.]")
    print()
    template_reflect = REFLECT_PROMPT.replace(
        "{current_draft}", "<< agent's current draft will be inserted here >>"
    )
    for line in template_reflect.splitlines():
        print(f"    {line}")
    print()
    pause()

    print("PROMPT 3 — Improvement pass  (Iteration 2+, uses accumulated reflection)")
    print("-" * 70)
    print("  [This is the LEARNING mechanism: the agent explicitly sees its own")
    print("   previous drafts and ALL its own reflection notes before rewriting.]")
    print()
    template_improve = (
        GENERATE_IMPROVE_PROMPT
        .replace("{iteration}",         "N")
        .replace("{iteration_minus_1}", "N-1")
        .replace("{previous_draft}",    "<< agent's previous draft >>")
        .replace("{all_reflection_notes}",
                 "<< all self-reflection notes accumulated so far >>")
    )
    for line in template_improve.splitlines():
        print(f"    {line}")
    print()
    pause(
        ">> The LangGraph pipeline will now run.\n"
        "   You will see each generate, evaluate, and reflect pass appear as it completes.\n"
        f"   Max LLM calls: {(MAX_REFLECTIONS + 1) + MAX_REFLECTIONS} "
        f"({MAX_REFLECTIONS + 1} generate + {MAX_REFLECTIONS} reflect).\n"
        f"   Evaluation is rule-based — no LLM, instant after each draft.\n"
        f"   Early stop fires if OVERALL >= {QUALITY_THRESHOLD} after >= {MIN_REFLECTIONS} passes."
    )

    # -----------------------------------------------------------------------
    # RUN THE PIPELINE
    # -----------------------------------------------------------------------
    print("=" * 70)
    print("  RUNNING REFLECTION PIPELINE")
    print("=" * 70)
    print()

    final_state: dict = {}
    generate_count = 0
    reflect_count  = 0
    stopped_early  = False

    print("  [ Iteration 1 — generate node executing... calling Bedrock LLM ]")
    print()

    for event in app.stream(
        {
            "clinical_notes":    notes,
            "current_draft":     "",
            "reflection_notes":  [],
            "draft_history":     [],
            "iteration":         1,
            "evaluation_scores": [],
        },
        stream_mode="updates",
    ):
        node_name, node_output = next(iter(event.items()))

        # ---- generate node completed ----
        if node_name == "generate":
            generate_count += 1
            print(f"[ GENERATE NODE — DRAFT {generate_count} COMPLETED ]")
            print("-" * 70)
            if generate_count == 1:
                print("First-pass draft written directly from clinical notes.")
                print("No prior history — this is the baseline. Scoring next...")
            else:
                print(f"Revision {generate_count} written after {reflect_count} "
                      f"round(s) of self-reflection. Scoring next...")
            print()
            print(node_output["current_draft"])
            print()
            final_state.update(node_output)
            print("  [ Evaluate node executing... (rule-based, no LLM) ]")
            print()

        # ---- evaluate node completed ----
        elif node_name == "evaluate":
            all_eval   = node_output["evaluation_scores"]
            latest     = all_eval[-1]
            final_state.update(node_output)

            print(f"[ EVALUATE NODE — DRAFT {generate_count} QUALITY METRICS ]")
            print("-" * 70)
            print_metrics_table(latest)

            # From Draft 2 onwards: explain WHY each metric changed
            if len(all_eval) >= 2:
                explain_score_changes(all_eval[-2], latest, generate_count)

            # Determine routing decision so we can narrate it
            # Mirror the router logic exactly: eligible only after MIN_REFLECTIONS passes
            min_met         = len(all_eval) > MIN_REFLECTIONS
            will_early_stop = min_met and latest["overall"] >= QUALITY_THRESHOLD
            is_hard_cap     = generate_count > MAX_REFLECTIONS

            if will_early_stop:
                stopped_early = True
                pause(
                    f"  >> EARLY STOP triggered!\n"
                    f"     OVERALL score {latest['overall']} >= threshold {QUALITY_THRESHOLD}\n"
                    f"     Minimum {MIN_REFLECTIONS} reflection pass(es) already completed.\n"
                    f"     Quality target reached — remaining pass(es) SKIPPED."
                )
            elif is_hard_cap:
                pause(
                    f"  >> HARD CAP reached: {MAX_REFLECTIONS} reflection passes used.\n"
                    f"     This is the final draft."
                )
            elif not min_met and latest["overall"] >= QUALITY_THRESHOLD:
                # Score is already good but minimum passes not yet satisfied
                remaining_min = MIN_REFLECTIONS - reflect_count
                pause(
                    f"  >> Score {latest['overall']} already >= threshold {QUALITY_THRESHOLD},\n"
                    f"     but minimum {MIN_REFLECTIONS} reflection pass(es) required.\n"
                    f"     {remaining_min} more pass(es) enforced to demonstrate improvement.\n"
                    f"     Continuing: agent will critique Draft {generate_count}..."
                )
            else:
                remaining = MAX_REFLECTIONS - reflect_count
                pause(
                    f"  >> Score {latest['overall']} below threshold {QUALITY_THRESHOLD}.\n"
                    f"     {remaining} reflection pass(es) remaining.\n"
                    f"     Continuing: agent will critique Draft {generate_count}..."
                )
                print(f"  [ Reflect node {reflect_count + 1} executing... calling Bedrock LLM ]")
                print()

        # ---- reflect node completed ----
        elif node_name == "reflect":
            reflect_count += 1
            print(f"[ REFLECT NODE — SELF-CRITIQUE {reflect_count} COMPLETED ]")
            print("-" * 70)
            print(f"The agent reviewed its own Draft {reflect_count} and identified issues.")
            print("These notes are stored in state and injected into the NEXT generate pass.")
            print(f"Accumulated reflection passes so far: {reflect_count}")
            print()
            latest_reflection = node_output["reflection_notes"][-1]
            print(latest_reflection)
            print()
            final_state.update(node_output)

            next_draft_num = reflect_count + 1
            pause(
                f"  >> Self-critique {reflect_count} done.\n"
                f"     Generating Draft {next_draft_num} with all {reflect_count} "
                f"reflection note(s) injected..."
            )
            print(f"  [ Iteration {next_draft_num} — generate node executing... calling Bedrock LLM ]")
            print()

    # -----------------------------------------------------------------------
    # SAVE OUTPUTS
    # -----------------------------------------------------------------------
    os.makedirs("outputs", exist_ok=True)
    output_path    = "outputs/healthcare_reflection_summary.md"
    draft_history  = final_state.get("draft_history",     [])
    reflect_notes  = final_state.get("reflection_notes",  [])
    eval_scores    = final_state.get("evaluation_scores", [])

    with open(output_path, "w", encoding="utf-8") as f:
        for i, draft in enumerate(draft_history, 1):
            label = "FINAL DRAFT" if i == len(draft_history) else f"DRAFT {i}"
            f.write(f"# {label}  (Iteration {i})\n\n")
            f.write(draft)
            f.write("\n\n")

            if i <= len(eval_scores):
                s = eval_scores[i - 1]
                f.write(f"## EVALUATION METRICS — DRAFT {i}\n\n")
                f.write(f"| Metric | Score |\n|---|---|\n")
                for key, lbl in _METRIC_LABELS.items():
                    f.write(f"| {lbl.split('(')[0].strip()} | {s[key]:.1f} |\n")
                f.write(f"| **OVERALL** | **{s['overall']:.1f}** |\n\n")

            if i <= len(reflect_notes):
                f.write(f"## SELF-REFLECTION NOTES AFTER DRAFT {i}\n\n")
                f.write(reflect_notes[i - 1])
                f.write("\n\n---\n\n")

    print(f"All drafts, metrics, and reflection notes saved to: {output_path}")
    print()

    # -----------------------------------------------------------------------
    # EVALUATION PROGRESSION TABLE
    # -----------------------------------------------------------------------
    print("=" * 70)
    print("  EVALUATION PROGRESSION — Metrics Across All Iterations")
    print("=" * 70)
    print()
    print("  This table shows how each metric changed from Draft 1 to the final draft.")
    print("  The OVERALL score is the weighted combination that controls the stop decision.")
    print()
    print_progression_table(eval_scores)

    # -----------------------------------------------------------------------
    # SIDE-BY-SIDE COMPARISON: Draft 1 vs Final Draft
    # -----------------------------------------------------------------------
    print("=" * 70)
    print("  BEFORE vs AFTER  —  What Self-Reflection Added")
    print("=" * 70)
    print()
    if len(draft_history) >= 2:
        print("DRAFT 1  (before any reflection — baseline):")
        print("-" * 70)
        print(draft_history[0])
        print()
        pause()
        final_label = (
            f"FINAL DRAFT  (after {reflect_count} round(s) of self-reflection"
            + (", EARLY STOP" if stopped_early else "")
            + "):"
        )
        print(final_label)
        print("-" * 70)
        print(draft_history[-1])
        print()
        pause()

    # -----------------------------------------------------------------------
    # OUTCOME SUMMARY
    # -----------------------------------------------------------------------
    print("=" * 70)
    print("  OUTCOME SUMMARY — REFLECTION PATTERN + EVALUATION IN ACTION")
    print("=" * 70)
    print()
    print("  HOW THE REFLECTION LOOP IMPROVED THE OUTPUT:")
    print(f"    - Started with 1 draft written from raw notes (no feedback)")
    print(f"    - Ran {reflect_count} self-reflection pass(es):")
    print(f"      each pass added to the agent's accumulated self-critique notes")
    print(f"    - Each new draft was given ALL previous reflection notes")
    print(f"    - {generate_count} total draft(s) produced")
    if eval_scores:
        first_overall = eval_scores[0]["overall"]
        final_overall = eval_scores[-1]["overall"]
        print(f"    - OVERALL score improved from {first_overall} → {final_overall} "
              f"(+{final_overall - first_overall:.1f} points)")
    print()
    print("  STOP DECISION:")
    if stopped_early:
        print(f"    EARLY STOP after Draft {generate_count}:")
        print(f"    OVERALL score {eval_scores[-1]['overall']} reached threshold {QUALITY_THRESHOLD}.")
        print(f"    {MAX_REFLECTIONS - reflect_count} reflection pass(es) were skipped — saving LLM calls.")
    else:
        print(f"    HARD CAP: used all {MAX_REFLECTIONS} allowed reflection passes.")
        if eval_scores and eval_scores[-1]["overall"] < QUALITY_THRESHOLD:
            print(f"    OVERALL score {eval_scores[-1]['overall']} did not reach "
                  f"threshold {QUALITY_THRESHOLD}.")
            print("    Consider raising MAX_REFLECTIONS or adjusting the prompt.")
    print()
    print("  WHAT MAKES THIS REFLECTION (NOT CRITIC):")
    print("    - ONE agent identity throughout — same system prompt, same 'voice'")
    print("    - The agent's reflection notes carry forward (state accumulation)")
    print("    - The improvement prompt literally says 'here is what YOU wrote'")
    print("      and 'here is what YOU said was wrong' — the agent learns from itself")
    print("    - No second agent, no external evaluator, no peer review")
    print()
    print("  EVALUATION MECHANICS:")
    print("    - evaluate_node fires after EVERY generate — zero extra LLM calls")
    print("    - Metrics are rule-based string matching — deterministic & fast")
    print("    - router reads evaluation_scores[-1]['overall'] to decide next step")
    print("    - Two stop conditions: quality threshold (early) + hard cap (fallback)")
    print()
    print("  LANGGRAPH MECHANICS:")
    print("    - generate → evaluate → router (conditional) → reflect or END")
    print("    - GraphState.evaluation_scores grows with each evaluate pass")
    print("    - GraphState.reflection_notes grows with each reflect pass")
    print("    - Same nodes visited multiple times with different state each time")
    print()
    print(f"  Total LLM calls  : {generate_count + reflect_count}"
          f"  ({generate_count} generate + {reflect_count} reflect)")
    print(f"  Eval calls       : {generate_count}  (rule-based, no LLM)")
    print("=" * 70)
