# -*- coding: utf-8 -*-
"""
Factory Pattern — Dynamic Care Pathway Assembly at Runtime
Implemented with LangGraph dynamic graph construction

Factory Pattern:
  A factory function examines the input and builds the right agent
  configuration at runtime.  The caller does not hardcode which pathway
  to use — the factory inspects the input and decides.

  "Don't build one graph that routes everything through every possible
   specialist.  Build the right graph for each case."

LangGraph implementation:
  - Three build_*_graph() functions create different StateGraph topologies
  - All three share a single CaseState TypedDict
  - specialist_notes: Annotated[List[str], operator.add]
      each specialist node APPENDS its assessment; the compile node
      reads them all — whether there is 1 note or 4
  - The factory function examines the case and calls the right builder

Healthcare use case: Meridian Health MDT Coordinator
  A patient case arrives with a complexity profile.  The factory
  assembles the right clinical team automatically — no more, no less:

    SIMPLE   → 2 nodes: GP review + recommendation
    MODERATE → 3 nodes: specialist + pharmacist + care plan
    COMPLEX  → 5 nodes: 4 specialists + MDT chair summary

  Nodes are reused across pathways.  The pharmacist and compile nodes
  appear in both the moderate and complex pathways — the factory
  assembles them differently each time.
"""

import os
import operator
from pathlib import Path
from typing import TypedDict, List, Annotated
from textwrap import dedent
from dotenv import load_dotenv
import warnings

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------

def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

from langchain_aws import ChatBedrock
from langgraph.graph import StateGraph, END

llm = ChatBedrock(model_id=MODEL_ID, region_name=AWS_REGION, model_kwargs={"temperature": 0.4})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def pause(msg="Press Enter to continue..."):
    input(f"\n  [{msg}] ")
    print()

def section(title, width=68):
    print("=" * width)
    print(f"  {title}")
    print("=" * width)

def subsection(title, width=68):
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print("─" * width)

def indent(text, prefix="  "):
    return "\n".join(prefix + line for line in text.splitlines())

# =============================================================================
# SHARED STATE — Used by ALL three graph topologies
#
# specialist_notes uses operator.add so each node APPENDS its assessment.
# The compile node reads them all — whether there is 1 note or 4.
# The same state type works for a 2-node graph and a 5-node graph.
# =============================================================================

class CaseState(TypedDict):
    # ── Case input ────────────────────────────────────────────────────────────
    patient_id:   str
    patient_name: str
    patient_age:  int
    case_summary: str          # Clinical profile handed to the pathway
    complexity:   str          # "simple" | "moderate" | "complex"

    # ── Accumulated specialist assessments ────────────────────────────────────
    # operator.add: each specialist node appends one item to this list.
    # The compile node synthesises whatever is present — 1, 3, or 4 items.
    specialist_notes: Annotated[List[str], operator.add]

    # ── Final output ──────────────────────────────────────────────────────────
    care_plan: str

# =============================================================================
# SPECIALIST NODE FUNCTIONS
# These are plain functions.  The factory assembles them into different
# graph topologies — some nodes appear in multiple pathways.
# =============================================================================

def gp_review_node(state: CaseState) -> dict:
    """General practitioner review — used in the SIMPLE pathway only."""
    prompt = dedent(f"""\
        You are a GP conducting an annual medication review at Meridian Health.

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        CASE SUMMARY: {state['case_summary']}

        Provide a brief GP assessment (3-4 sentences):
        - Current medication safety and appropriateness
        - Any flags or monitoring needed
        - Whether onward referral is needed (this is a routine review)
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"GP REVIEW:\n{result.content}"]}


def cardiologist_node(state: CaseState) -> dict:
    """Cardiologist review — used in the MODERATE and COMPLEX pathways."""
    prompt = dedent(f"""\
        You are a consultant cardiologist at Meridian Health.

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        CASE SUMMARY: {state['case_summary']}

        Provide a concise cardiology assessment (3-5 sentences):
        - Cardiac diagnosis and risk stratification
        - Recommended investigations
        - Treatment approach and monitoring plan
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"CARDIOLOGY:\n{result.content}"]}


def oncologist_node(state: CaseState) -> dict:
    """Oncologist review — used in the COMPLEX pathway only."""
    prompt = dedent(f"""\
        You are a consultant oncologist at Meridian Health.

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        CASE SUMMARY: {state['case_summary']}

        Provide a concise oncology assessment (3-5 sentences):
        - Current cancer status and treatment trajectory
        - How the cardiac presentation affects oncology management
        - Priority oncology actions this MDT should agree on
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"ONCOLOGY:\n{result.content}"]}


def pharmacist_node(state: CaseState) -> dict:
    """Pharmacist review — used in the MODERATE and COMPLEX pathways."""
    # Build context from any specialist notes already accumulated
    prior = "\n\n".join(state.get("specialist_notes", [])) or "None yet."
    prompt = dedent(f"""\
        You are a clinical pharmacist at Meridian Health.

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        CASE SUMMARY: {state['case_summary']}

        SPECIALIST NOTES SO FAR:
        {prior}

        Provide a medication safety review (3-4 sentences):
        - Key drug interactions or contraindications given the clinical picture
        - Dosing recommendations or adjustments
        - Monitoring parameters
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"PHARMACY:\n{result.content}"]}


def social_worker_node(state: CaseState) -> dict:
    """Social work assessment — used in the COMPLEX pathway only."""
    prompt = dedent(f"""\
        You are a medical social worker at Meridian Health.

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        CASE SUMMARY: {state['case_summary']}

        Provide a psychosocial assessment (3-4 sentences):
        - Key social determinants affecting this patient's care
        - Support needs: housing, carer, financial, emotional
        - Recommended social work actions or referrals
    """)
    result = llm.invoke(prompt)
    return {"specialist_notes": [f"SOCIAL WORK:\n{result.content}"]}


def compile_plan_node(state: CaseState) -> dict:
    """
    Final node — present in ALL three pathways.
    Reads all accumulated specialist_notes (1 to 4 items depending on pathway)
    and synthesises a unified care plan.
    The same function handles a 2-note simple case and a 5-note MDT.
    """
    all_notes  = "\n\n".join(state.get("specialist_notes", []))
    note_count = len(state.get("specialist_notes", []))
    role       = "GP" if note_count == 1 else "MDT chair" if note_count >= 4 else "care coordinator"

    prompt = dedent(f"""\
        You are the {role} compiling the final care plan for Meridian Health.

        PATIENT: {state['patient_name']}, {state['patient_age']} years old
        PATHWAY USED: {state['complexity'].upper()} ({note_count} specialist input(s))

        SPECIALIST ASSESSMENTS:
        {all_notes}

        Produce a concise, structured care plan:

        SUMMARY: <2 sentences capturing the overall clinical picture>
        PRIORITY ACTIONS:
        - <action 1>
        - <action 2>
        - <action 3>
        FOLLOW-UP: <who reviews this patient, and when>
    """)
    result = llm.invoke(prompt)
    return {"care_plan": result.content}

# =============================================================================
# FACTORY — Three build functions that create different graph topologies
# =============================================================================

def build_simple_graph():
    """
    SIMPLE pathway — 2 nodes.
    Assembled for routine, low-complexity cases.
    A single GP review is sufficient; no specialist escalation needed.

      gp_review → compile_plan
    """
    builder = StateGraph(CaseState)
    builder.add_node("gp_review",    gp_review_node)
    builder.add_node("compile_plan", compile_plan_node)

    builder.set_entry_point("gp_review")
    builder.add_edge("gp_review",    "compile_plan")
    builder.add_edge("compile_plan", END)

    return builder.compile()


def build_moderate_graph():
    """
    MODERATE pathway — 3 nodes.
    Assembled for cases requiring specialist expertise and medication review.
    A cardiologist and pharmacist work sequentially before the care coordinator
    produces a unified plan.

      cardiologist → pharmacist → compile_plan
    """
    builder = StateGraph(CaseState)
    builder.add_node("cardiologist", cardiologist_node)
    builder.add_node("pharmacist",   pharmacist_node)
    builder.add_node("compile_plan", compile_plan_node)

    builder.set_entry_point("cardiologist")
    builder.add_edge("cardiologist", "pharmacist")
    builder.add_edge("pharmacist",   "compile_plan")
    builder.add_edge("compile_plan", END)

    return builder.compile()


def build_complex_graph():
    """
    COMPLEX pathway — 5 nodes.
    Assembled for multi-morbidity cases requiring a full MDT.
    Four specialists contribute before the MDT chair compiles everything.

      oncologist → cardiologist → pharmacist → social_worker → compile_plan
    """
    builder = StateGraph(CaseState)
    builder.add_node("oncologist",   oncologist_node)
    builder.add_node("cardiologist", cardiologist_node)
    builder.add_node("pharmacist",   pharmacist_node)
    builder.add_node("social_worker",social_worker_node)
    builder.add_node("compile_plan", compile_plan_node)

    builder.set_entry_point("oncologist")
    builder.add_edge("oncologist",   "cardiologist")
    builder.add_edge("cardiologist", "pharmacist")
    builder.add_edge("pharmacist",   "social_worker")
    builder.add_edge("social_worker","compile_plan")
    builder.add_edge("compile_plan", END)

    return builder.compile()


# =============================================================================
# THE FACTORY FUNCTION
# This is the heart of the pattern.  Callers pass a case; the factory
# decides which pathway to build and returns a compiled graph.
# =============================================================================

PATHWAY_CONFIGS = {
    "simple": {
        "builder":     build_simple_graph,
        "nodes":       2,
        "specialists": "GP Physician → Care Recommendation",
        "label":       "QUICK REVIEW",
    },
    "moderate": {
        "builder":     build_moderate_graph,
        "nodes":       3,
        "specialists": "Cardiologist → Pharmacist → Care Coordinator",
        "label":       "SPECIALIST TEAM",
    },
    "complex": {
        "builder":     build_complex_graph,
        "nodes":       5,
        "specialists": "Oncologist → Cardiologist → Pharmacist → Social Worker → MDT Chair",
        "label":       "FULL MDT",
    },
}

def create_pathway(case: dict):
    """
    The factory function.

    Examines the case's complexity field and builds the appropriate
    LangGraph StateGraph at runtime.  Returns the compiled graph and
    the pathway config for display purposes.

    The caller never calls build_simple_graph() or build_complex_graph()
    directly — those are the factory's internal details.
    """
    complexity = case["complexity"]
    config     = PATHWAY_CONFIGS[complexity]

    print(f"\n  ┌─ FACTORY ──────────────────────────────────────────────┐")
    print(f"  │  Patient  : {case['patient_name']}, {case['patient_age']}                                   ")
    print(f"  │  Complexity: {complexity.upper():<8}  →  {config['label']} ({config['nodes']} nodes)   ")
    print(f"  │  Team      : {config['specialists']}")
    print(f"  └────────────────────────────────────────────────────────┘")

    graph = config["builder"]()
    return graph, config

# =============================================================================
# STORY & FLOW DISPLAYS
# =============================================================================

def print_story():
    section("FACTORY PATTERN — Dynamic Care Pathway Assembly")
    print("""
  SCENARIO
  ─────────
  Meridian Health's MDT Coordinator receives patient referrals throughout
  the day.  Each case has a different clinical complexity profile.

  The old approach: every case goes through the full MDT system.
  A simple medication review sits in the same queue as a full MDT case.
  Specialists waste time on cases that don't need them.

  The factory approach: a factory function examines each case and builds
  the RIGHT clinical team on the fly — no more, no less.

  THE FACTORY PATTERN:
    Input: a case with a complexity profile
    Factory: examines the input, selects a builder, creates a graph
    Output: a compiled LangGraph ready to run — different every time

    The caller never knows which builder was used.
    The specialists only appear if the factory puts them in the graph.

  THREE PATHWAYS the factory can build:

    ┌──────────────────────────────────────────────────────────────┐
    │  SIMPLE   (2 nodes)                                          │
    │  gp_review → compile_plan                                    │
    │  For: routine reviews, stable patients, single condition     │
    └──────────────────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────────────────┐
    │  MODERATE  (3 nodes)                                         │
    │  cardiologist → pharmacist → compile_plan                    │
    │  For: new specialist diagnoses, medication complexity        │
    └──────────────────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────────────────┐
    │  COMPLEX   (5 nodes)                                         │
    │  oncologist → cardiologist → pharmacist →                    │
    │  social_worker → compile_plan                                │
    │  For: multi-morbidity, intersecting conditions, MDT needed   │
    └──────────────────────────────────────────────────────────────┘

  THREE PATIENTS — all different, all handled correctly:

    [CASE 1]  Beatrice Hall, 71  —  stable hypertension, annual review
              complexity = SIMPLE → factory builds 2-node Quick Review
              One GP, one plan.  No specialist time wasted.

    [CASE 2]  Raj Nair, 56  —  new diagnosis of atrial fibrillation
              complexity = MODERATE → factory builds 3-node Specialist Team
              Cardiologist + pharmacist needed for anticoagulation decision.

    [CASE 3]  Diane Cho, 64  —  stage III breast cancer + new heart failure
                                  + housing instability
              complexity = COMPLEX → factory builds 5-node Full MDT
              Four specialists + MDT chair.  Every dimension addressed.
""")


def print_flow():
    subsection("FACTORY DECISION FLOW")
    print("""
    Input: case dict with complexity field
                         │
                         ▼
              ┌──────────────────┐
              │  create_pathway  │  ← The factory function
              │   (case)         │    Examines complexity.
              │                  │    Calls the right builder.
              │                  │    Returns compiled graph.
              └────────┬─────────┘
                       │
           ┌───────────┼───────────┐
           │           │           │
        "simple"   "moderate"   "complex"
           │           │           │
           ▼           ▼           ▼
    ┌────────────┐ ┌──────────┐ ┌─────────────────────────┐
    │ gp_review  │ │cardiol.  │ │ oncologist              │
    │     ↓      │ │    ↓     │ │      ↓                  │
    │ compile    │ │pharmacy  │ │ cardiologist            │
    │ _plan      │ │    ↓     │ │      ↓                  │
    └────────────┘ │ compile  │ │ pharmacist              │
     2 nodes       │ _plan    │ │      ↓                  │
                   └──────────┘ │ social_worker           │
                    3 nodes     │      ↓                  │
                                │ compile_plan            │
                                └─────────────────────────┘
                                 5 nodes

    All three share CaseState — the same TypedDict.
    specialist_notes: Annotated[List[str], operator.add]
      Each specialist node appends one item.
      compile_plan reads whatever is there — 1 item or 4.
      No changes needed in compile_plan for different pathway sizes.

    Nodes reused across pathways:
      cardiologist_node  → moderate AND complex
      pharmacist_node    → moderate AND complex
      compile_plan_node  → simple AND moderate AND complex
""")

# =============================================================================
# CASE DATA
# =============================================================================

CASES = [
    {
        "patient_id":   "MH-3301",
        "patient_name": "Beatrice Hall",
        "patient_age":  71,
        "complexity":   "simple",
        "case_summary": (
            "71-year-old female with a 12-year history of well-controlled hypertension. "
            "Current medications: amlodipine 5 mg, ramipril 5 mg, low-dose aspirin. "
            "Last BP reading 134/82, eGFR stable at 62. No new symptoms. "
            "Annual medication review requested by GP surgery. No specialist input needed."
        ),
        "label": "CASE 1 — Beatrice Hall  |  complexity: SIMPLE",
    },
    {
        "patient_id":   "MH-4478",
        "patient_name": "Raj Nair",
        "patient_age":  56,
        "complexity":   "moderate",
        "case_summary": (
            "56-year-old male with new diagnosis of paroxysmal atrial fibrillation confirmed "
            "on 7-day Holter monitor last week. CHA₂DS₂-VASc score 2 (age, hypertension). "
            "Currently on amlodipine 10 mg and metformin for type 2 diabetes. "
            "No prior anticoagulation. Cardiologist review and pharmacy input needed before "
            "starting anticoagulation. Patient anxious about stroke risk."
        ),
        "label": "CASE 2 — Raj Nair  |  complexity: MODERATE",
    },
    {
        "patient_id":   "MH-5912",
        "patient_name": "Diane Cho",
        "patient_age":  64,
        "complexity":   "complex",
        "case_summary": (
            "64-year-old female with stage III HER2+ breast cancer on trastuzumab. "
            "New echocardiogram shows LVEF drop from 65% to 42% — cardiotoxicity suspected. "
            "Hypertensive (BP 158/96), type 2 diabetes on insulin. "
            "Recent loss of housing: temporarily staying with a neighbour; limited support. "
            "On 11 medications including chemotherapy agents. Full MDT review requested: "
            "oncology, cardiology, pharmacy (complex polypharmacy), social work (housing/support)."
        ),
        "label": "CASE 3 — Diane Cho  |  complexity: COMPLEX",
    },
]


def initial_state_for(case: dict) -> CaseState:
    return {
        "patient_id":       case["patient_id"],
        "patient_name":     case["patient_name"],
        "patient_age":      case["patient_age"],
        "case_summary":     case["case_summary"],
        "complexity":       case["complexity"],
        "specialist_notes": [],
        "care_plan":        "",
    }

# =============================================================================
# MAIN
# =============================================================================

NODE_LABELS = {
    "gp_review":    "GP Review",
    "cardiologist": "Cardiology",
    "oncologist":   "Oncology",
    "pharmacist":   "Pharmacy",
    "social_worker":"Social Work",
    "compile_plan": "Compile Care Plan",
}

if __name__ == "__main__":
    print_story()
    pause("Press Enter to see the factory decision flow")

    print_flow()
    pause("Press Enter to start processing cases")

    section(f"RUNNING FACTORY DEMO  —  Model: {MODEL_ID}")

    outputs_dir = Path(__file__).resolve().parent / "outputs"
    os.makedirs(outputs_dir, exist_ok=True)
    output_lines = ["# Meridian Health MDT — Factory Pattern Demo\n\n"]

    for idx, case in enumerate(CASES):

        subsection(case["label"])
        print(f"\n  REFERRAL SUMMARY:\n{indent(case['case_summary'], '  ')}\n")

        # ── THE FACTORY CALL ──────────────────────────────────────────────────
        # This single line replaces all case-type branching in the caller.
        # The caller doesn't know or care which graph topology is built.
        graph, pathway_config = create_pathway(case)
        # ─────────────────────────────────────────────────────────────────────

        pause(f"Press Enter to run the {pathway_config['label']} pathway")

        step_num   = 0
        care_plan  = ""
        note_count = 0

        for step in graph.stream(initial_state_for(case)):
            node_name = list(step.keys())[0]
            data      = step[node_name]
            step_num += 1

            label = NODE_LABELS.get(node_name, node_name)

            if node_name != "compile_plan":
                # Specialist assessment — show the note added
                added = data.get("specialist_notes", [])
                if added:
                    note_count += 1
                    note_text = added[-1] if added else ""
                    print(f"\n  [STEP {step_num} — {label}]\n{indent(note_text, '  ')}")

            else:
                # Final compile step — show care plan
                care_plan = data.get("care_plan", "")
                total_inputs = note_count
                print(f"\n  [STEP {step_num} — {label}]  "
                      f"(synthesising {total_inputs} specialist input(s))\n"
                      f"{indent(care_plan, '  ')}")

        output_lines.append(f"## {case['label']}\n\n")
        output_lines.append(f"**Pathway:** {pathway_config['label']}  "
                            f"({pathway_config['nodes']} nodes)\n\n")
        output_lines.append(f"**Team:** {pathway_config['specialists']}\n\n")
        output_lines.append(f"**Referral:** {case['case_summary']}\n\n")
        output_lines.append(f"**Care Plan:**\n{care_plan}\n\n---\n\n")

        if idx < len(CASES) - 1:
            pause("Press Enter for the next case")

    # Save output
    output_path = outputs_dir / "factory_pattern_mdt.md"
    with open(output_path, "w", encoding="utf-8") as f:
        f.writelines(output_lines)

    # ── Final summary ─────────────────────────────────────────────────────────
    section("FACTORY PATTERN SUMMARY")
    print(f"""
  What the demo showed:

  THE FACTORY IN ACTION
  ──────────────────────
  One factory call per case.  Three different graphs produced.

    Case 1 (Beatrice Hall) — complexity: simple
      create_pathway(case) → build_simple_graph()
      Graph built:  gp_review → compile_plan   (2 nodes)
      Specialists:  1  (GP only)
      Right for:    routine review, no escalation needed

    Case 2 (Raj Nair) — complexity: moderate
      create_pathway(case) → build_moderate_graph()
      Graph built:  cardiologist → pharmacist → compile_plan   (3 nodes)
      Specialists:  2 + coordinator
      Right for:    new specialist diagnosis, anticoagulation decision

    Case 3 (Diane Cho) — complexity: complex
      create_pathway(case) → build_complex_graph()
      Graph built:  oncologist → cardiologist → pharmacist
                    → social_worker → compile_plan   (5 nodes)
      Specialists:  4 + MDT chair
      Right for:    multi-morbidity, intersecting conditions

  WHY THIS IS THE FACTORY PATTERN
  ─────────────────────────────────
  The factory pattern separates "deciding what to create" from
  "using what was created."

    Without factory:  The caller has a long if/elif chain.  Every new
      pathway type requires editing the caller.  Specialists are always
      present in the graph even when not needed.

    With factory:  The caller passes the case and uses the graph.
      New pathway types are added by writing a new build_*_graph()
      function and registering it — caller is never touched.

  KEY LANGGRAPH DETAILS
  ──────────────────────
  • All three pathways share one CaseState TypedDict
  • specialist_notes: Annotated[List[str], operator.add]
      Each specialist appends one item.  compile_plan_node reads all
      of them — the same function regardless of how many there are.
  • Nodes are reused: cardiologist_node, pharmacist_node, and
    compile_plan_node appear in multiple pathways unchanged.
  • No MemorySaver needed — each case is stateless and self-contained.

  Output saved → {output_path.name}

  NOTE: For educational purposes only.
  All clinical decisions must be made by qualified healthcare professionals.
""")


# =============================================================================
# DEPLOYING THIS FACTORY PATTERN ON AMAZON BEDROCK / AWS
# =============================================================================
#
# This demo already uses Amazon Bedrock (ChatBedrock / amazon.nova-micro-v1:0).
# Below are the main options for taking it from a local script to a
# production-grade AWS deployment.
#
# ─────────────────────────────────────────────────────────────────────────────
# OPTION 1 — AWS LAMBDA  (simplest, event-driven)
# ─────────────────────────────────────────────────────────────────────────────
# Package the LangGraph graphs + node functions into a Lambda function.
# One Lambda per case invocation; the factory selects the right graph inside.
#
# Architecture:
#   API Gateway POST /cases
#       └─→ Lambda (factory_handler)
#               ├─ create_pathway(case)       ← factory runs here
#               ├─ graph.invoke(initial_state)
#               └─ return care_plan JSON
#
# Key points:
#   • Use Lambda container images (ECR) — LangGraph + langchain_aws exceed
#     the 50 MB zip limit; a Docker image handles all dependencies cleanly.
#   • Set timeout to 5-15 min for complex (5-node) pathways; Nova Pro or
#     Claude models on Bedrock can be slower than Nova Micro.
#   • IAM role needs: bedrock:InvokeModel on the chosen model ARN.
#   • Enable Lambda Powertools for structured logging and tracing (X-Ray).
#   • Environment variables: AWS_REGION, BEDROCK_MODEL_ID (no .env file needed).
#
# Deployment steps (CDK / SAM):
#   1. docker build -t mdt-factory .
#   2. Push image to ECR
#   3. aws lambda create-function --package-type Image --image-uri <ecr-uri>
#      OR use AWS SAM: sam deploy --guided
#
# ─────────────────────────────────────────────────────────────────────────────
# OPTION 2 — AWS STEP FUNCTIONS  (mirrors the graph topology natively)
# ─────────────────────────────────────────────────────────────────────────────
# The three graph topologies (simple/moderate/complex) map almost directly
# to Step Functions state machines.  Each specialist node becomes a Lambda
# Task state; the factory's if/else becomes a Choice state.
#
# Architecture:
#   EventBridge / API GW  →  Step Functions Express Workflow
#       Choice state (complexity)
#           "simple"   → gp_review_task   → compile_plan_task
#           "moderate" → cardiologist_task → pharmacist_task → compile_plan_task
#           "complex"  → oncologist_task → cardiologist_task → pharmacist_task
#                        → social_worker_task → compile_plan_task
#
# Why this fits well:
#   • Step Functions natively handles retry, error catching, and timeouts
#     per specialist node — no extra code needed.
#   • Express Workflows support high-throughput case processing
#     (> 1 execution/sec).  Standard Workflows suit long-running MDTs.
#   • The execution history in the console gives a visual audit trail
#     of which specialists ran — useful for clinical governance.
#   • Parallel state: cardiologist + oncologist could run in parallel
#     (change build_complex_graph edges) with no Lambda code change.
#
# Tradeoffs vs LangGraph:
#   + No Python runtime needed for orchestration (Step Functions is managed)
#   + Built-in retries, dead-letter queues, CloudWatch metrics
#   - State machine definition (ASL JSON/YAML) is verbose to maintain
#   - LangGraph's operator.add reducer must be reimplemented via
#     a Lambda that merges specialist_notes lists between states
#
# ─────────────────────────────────────────────────────────────────────────────
# OPTION 3 — AMAZON ECS / FARGATE  (long-running, high-throughput)
# ─────────────────────────────────────────────────────────────────────────────
# Run the full LangGraph application as a containerised service.
# Best if you have a continuous stream of cases (clinic intake system).
#
# Architecture:
#   SQS queue (case intake)
#       └─→ ECS Fargate task (factory_worker)
#               ├─ poll SQS for new cases
#               ├─ create_pathway(case) + graph.invoke()
#               └─ write result to DynamoDB / S3
#
# Key points:
#   • Auto Scaling: scale ECS tasks on SQS ApproximateNumberOfMessagesVisible
#     so complex cases that take longer don't block simple ones.
#   • Use Spot capacity for Fargate to reduce cost (LLM calls dominate cost
#     anyway; compute is cheap relative to Bedrock token spend).
#   • DynamoDB table for CaseState persistence:
#       PK: patient_id  SK: run_id
#       Stores specialist_notes list and final care_plan.
#   • S3 + Athena for the markdown output files (replace local outputs/ dir).
#
# ─────────────────────────────────────────────────────────────────────────────
# OPTION 4 — AMAZON BEDROCK AGENTS  (fully managed agentic runtime)
# ─────────────────────────────────────────────────────────────────────────────
# Replace the LangGraph graphs with native Bedrock Agents + Action Groups.
# Each specialist node (gp_review, cardiologist, etc.) becomes an Action Group
# backed by a Lambda function.
#
# Architecture:
#   Bedrock Agent (MDT Coordinator)
#       ├─ Action Group: gp_review        → Lambda
#       ├─ Action Group: cardiologist     → Lambda
#       ├─ Action Group: pharmacist       → Lambda
#       ├─ Action Group: oncologist       → Lambda
#       ├─ Action Group: social_worker    → Lambda
#       └─ Agent orchestration decides which actions to call
#          based on the case complexity field in the prompt
#
# Factory replacement:
#   Instead of create_pathway(), the Bedrock Agent's system prompt instructs
#   it to call only the relevant action groups for the complexity level.
#   The agent itself is the factory.
#
# Benefits:
#   + No LangGraph dependency — fully managed on AWS
#   + Built-in session memory (MemorySaver equivalent) via Bedrock Agent sessions
#   + Knowledge Bases can attach clinical guidelines, formularies, NICE pathways
#   + Bedrock Guardrails for PII detection (patient names/IDs) and content safety
#   + Trace and audit logs in CloudWatch / CloudTrail out of the box
#
# Tradeoffs:
#   - Less control over exact graph topology vs LangGraph
#   - Agent may call actions in different order than the hardcoded edges
#   - Cold-start latency for first invocation in a session
#
# ─────────────────────────────────────────────────────────────────────────────
# OPTION 5 — AMAZON BEDROCK FLOWS  (visual, low-code)
# ─────────────────────────────────────────────────────────────────────────────
# Bedrock Flows (GA 2024) lets you build prompt pipelines visually.
# Represent each of the three pathways as a separate Flow definition.
# A routing Lambda or Condition node selects the right Flow at runtime.
#
# Architecture:
#   API GW → Lambda (router)
#       ├─ complexity == "simple"   → invoke Flow: simple_pathway_flow
#       ├─ complexity == "moderate" → invoke Flow: moderate_pathway_flow
#       └─ complexity == "complex"  → invoke Flow: complex_pathway_flow
#
# Each Flow contains:
#   Input node → Prompt node (specialist) → Prompt node (next) → Output node
#
# Best for:
#   Teams that want non-engineers (clinical informatics leads) to edit
#   the specialist prompts via the Bedrock console without touching Python.
#
# ─────────────────────────────────────────────────────────────────────────────
# MODEL SELECTION ON BEDROCK — practical guidance
# ─────────────────────────────────────────────────────────────────────────────
#
#   amazon.nova-micro-v1:0   ← current default (fast, cheap, text-only)
#       Good for: simple and moderate pathways, high-volume triage
#
#   amazon.nova-pro-v1:0     ← better reasoning, multimodal
#       Good for: complex pathway where nuance matters; can accept
#       echocardiogram images or lab PDF attachments as input
#
#   anthropic.claude-3-5-sonnet-20241022-v2:0  ← strongest clinical reasoning
#       Good for: compile_plan_node in complex MDT cases where synthesis
#       of 4 specialist notes needs high coherence
#
#   Mix models per node:
#       Simple/cheap nodes  → Nova Micro
#       compile_plan_node   → Claude Sonnet  (replace `llm` per node)
#       This is trivial in LangGraph — each node function can use its own
#       ChatBedrock instance with a different model_id.
#
#   Provisioned Throughput:
#       If running > 100 cases/hour, purchase Provisioned Throughput
#       for your chosen model to avoid throttling (LimitExceededException).
#
# ─────────────────────────────────────────────────────────────────────────────
# IAM — MINIMUM PERMISSIONS REQUIRED
# ─────────────────────────────────────────────────────────────────────────────
#
#   {
#     "Version": "2012-10-17",
#     "Statement": [{
#       "Effect": "Allow",
#       "Action": ["bedrock:InvokeModel"],
#       "Resource": [
#         "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-micro-v1:0",
#         "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-pro-v1:0"
#       ]
#     }]
#   }
#
#   Add bedrock:InvokeModelWithResponseStream if using streaming responses.
#   For Bedrock Agents: also add bedrock:InvokeAgent and bedrock:Retrieve
#   (if using Knowledge Bases).
#
# ─────────────────────────────────────────────────────────────────────────────
# HEALTHCARE / HIPAA CONSIDERATIONS
# ─────────────────────────────────────────────────────────────────────────────
#
#   • Amazon Bedrock is HIPAA-eligible — sign a BAA with AWS before storing
#     PHI (patient names, IDs, clinical summaries) in prompts/responses.
#   • Enable Bedrock Guardrails: PII detection + redaction to avoid logging
#     patient data in CloudWatch in plain text.
#   • Store care plan outputs in S3 with SSE-KMS encryption; enforce
#     bucket policies that deny HTTP (require HTTPS).
#   • Use AWS HealthLake for structured FHIR storage of the care plans
#     if integration with EMR systems (Epic, Cerner) is needed.
#   • All Lambda, Step Functions, and ECS resources should run inside a VPC
#     with VPC endpoints for Bedrock (no public internet traffic for PHI).
#   • Enable CloudTrail for all Bedrock API calls — required for HIPAA audit.
#
# ─────────────────────────────────────────────────────────────────────────────
# RECOMMENDED STARTING PATH
# ─────────────────────────────────────────────────────────────────────────────
#
#   Prototype / demo  →  Option 1 (Lambda + container image)
#       Fastest to deploy; keeps LangGraph code intact; ~1 hour to production.
#
#   Production clinic →  Option 2 (Step Functions) or Option 3 (ECS + SQS)
#       Step Functions if clinical audit trail is the priority.
#       ECS if you need high throughput and want to keep LangGraph as-is.
#
#   Product / SaaS    →  Option 4 (Bedrock Agents)
#       Fully managed, Knowledge Bases for clinical guidelines,
#       Guardrails for PHI, minimal infrastructure to maintain.
#
# =============================================================================
