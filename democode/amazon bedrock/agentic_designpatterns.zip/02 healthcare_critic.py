#!/usr/bin/env python3
"""
Critic Pattern Demonstration - Healthcare Discharge Summary

================================================================================
CRITIC PATTERN vs REFLECTION PATTERN — Key Difference (2-3 lines):
================================================================================
CRITIC pattern  : A SEPARATE agent evaluates and scores another agent's output
                  within the same execution.  Focus is quality control RIGHT NOW.
                  ("Is this output good enough?")

REFLECTION pattern : The SAME agent reviews its OWN past outputs across iterations
                     to update its reasoning strategy and improve future behaviour.
                     ("How do I get better over time?")

This demo implements the CRITIC pattern — two distinct agents, one execution loop.
================================================================================

================================================================================
CRITIC PATTERN OVERVIEW:
================================================================================
A Critic agent is an external evaluator that reviews another agent's output
during the same execution run.  It is NOT the generator; its entire purpose is
quality control.

Key Components:
- Author Agent    : Generates the initial output (discharge summary)
- Critic Agent    : Evaluates that output against a domain-specific rubric
- Feedback pass   : Critic's findings are used to produce a corrected version
- Single run      : Both agents execute once in the same pipeline (no episodes)

Key Benefits:
- Catches errors and dangerous omissions a single agent misses
- Forces systematic checking via an explicit rubric
- Produces a safer, higher-quality output than any single-pass generation
- Mirrors peer-review in professional settings (medicine, law, engineering)

Typical Workflow:
1. Author generates initial output
2. Critic evaluates output against rubric
3. Critic returns (a) numbered issues found  (b) a fully revised output
4. Pipeline ends — the revised output is the final deliverable

================================================================================
DEMO DESCRIPTION - What This Script Does:
================================================================================
1. Builds a LangGraph pipeline: Author node → Critic node
2. Author node drafts a discharge summary from raw clinical notes
3. Critic node reviews the draft against a four-point patient-safety rubric
4. Each step prints its prompt and output so you can see exactly what the LLM
   receives and returns
5. Saves both draft and revised summary to outputs/

Use Case: Hospital discharge summaries must be clear, complete, and safe.
A single LLM pass is competent but can miss:
- Medication contraindications / interaction warnings
- Explicit red-flag / 911 instructions
- Jargon that confuses patients
The Critic catches these gaps systematically.

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: LangGraph (stateful multi-node pipeline)
  - StateGraph : defines nodes and edges
  - GraphState : TypedDict that carries data between nodes
  - Streaming   : app.stream() lets us see each node's output as it completes

LLM Model: AWS Bedrock (accessed via langchain-aws ChatBedrock)
  - Model ID   : amazon.nova-micro-v1:0  (overridable via BEDROCK_MODEL_ID)
  - AWS Region : us-east-1               (overridable via AWS_REGION)

Data:
  - Input  : clinical notes (data/clinical_notes.txt)
  - Output : outputs/healthcare_critic_summary.md  (draft + revised)

Environment Configuration:
  - Uses .env file for AWS credentials / region
  - AWS_REGION defaults to us-east-1
  - BEDROCK_MODEL_ID can override the default model
================================================================================
"""

import os
import sys
from pathlib import Path
from typing import TypedDict

from dotenv import load_dotenv
from langchain_aws import ChatBedrock
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph

import warnings
warnings.filterwarnings('ignore')

# ---------------------------------------------------------------------------
# Ensure UTF-8 output on Windows terminals (avoids cp1252 UnicodeEncodeError
# when the LLM returns checkmarks, em-dashes, or other non-ASCII characters)
# ---------------------------------------------------------------------------
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------
def _find_project_root() -> Path:
    """Walk up from this file until we find a directory containing .env."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent


PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID   = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")

# ---------------------------------------------------------------------------
# LLM — ChatBedrock is LangChain's native Bedrock wrapper (no LiteLLM needed)
# ---------------------------------------------------------------------------
llm = ChatBedrock(
    model_id=MODEL_ID,
    region_name=AWS_REGION,
    model_kwargs={"temperature": 0.7},
)


# ---------------------------------------------------------------------------
# GRAPH STATE
# LangGraph passes this TypedDict between nodes; each node returns the keys
# it wants to update (partial updates are merged automatically).
# ---------------------------------------------------------------------------
class GraphState(TypedDict):
    clinical_notes: str   # raw input — set once before graph runs
    author_draft:   str   # produced by author_node
    critic_output:  str   # produced by critic_node


# ---------------------------------------------------------------------------
# PROMPTS — defined as module-level constants so we can print them to the
# user before the graph runs, making the Critic mechanism fully transparent.
# ---------------------------------------------------------------------------

# System prompt that shapes the Author's persona
AUTHOR_SYSTEM = (
    "You are a Clinical Author — a hospitalist who writes discharge summaries "
    "that are safe, complete, and easy for patients and caregivers to understand."
)

# Task instruction for the Author (clinical_notes will be injected at runtime)
AUTHOR_TASK_TEMPLATE = """\
Using the clinical notes below, write a discharge summary with these sections:

1. Diagnosis & Hospital Course
2. Medications  (name, dose, schedule, any critical warnings)
3. Follow-up & Monitoring  (named providers + timelines)
4. Patient Instructions  (plain language — no unexplained jargon)

Keep to approximately 180-220 words.

--- CLINICAL NOTES ---
{clinical_notes}
---------------------
"""

# System prompt that shapes the Critic's persona
CRITIC_SYSTEM = (
    "You are a Clinical QA Critic — a patient-safety quality officer whose only "
    "job is to find gaps in discharge summaries and produce a safer revised version. "
    "You do NOT write summaries from scratch; you evaluate and fix existing ones."
)

# Task instruction for the Critic (author_draft will be injected at runtime)
CRITIC_TASK_TEMPLATE = """\
Review the discharge summary draft below against this four-point safety rubric.
Be explicit about every issue you find under each rubric point.

RUBRIC:
1) MEDICATIONS  — Are all doses and schedules clearly stated?
                  Are there missing contraindications or dangerous interaction warnings?
2) FOLLOW-UP    — Are timelines and named providers specified?
3) RED FLAGS    — Are there explicit instructions for when to call 911 vs. the doctor?
4) CLARITY      — Is the language jargon-free and understandable by a patient?

Return:
  a) A numbered critique listing every issue found under each rubric point.
  b) A fully revised discharge summary that fixes all identified issues.

--- DRAFT TO REVIEW ---
{author_draft}
-----------------------
"""


# ---------------------------------------------------------------------------
# HELPER
# ---------------------------------------------------------------------------
def read_notes() -> str:
    """Read clinical notes from the data directory."""
    data_path = Path(__file__).resolve().parent / "data" / "clinical_notes.txt"
    with open(data_path, "r") as f:
        return f.read()


def pause(msg: str = "") -> None:
    """Print an optional message then wait for Enter.
    Falls back silently when stdin is not a TTY (CI / piped runs)."""
    if msg:
        print(msg)
    try:
        input("  >>> Press Enter to continue... ")
    except EOFError:
        print("  [non-interactive: continuing automatically]")
    print()


# ---------------------------------------------------------------------------
# LANGGRAPH NODE 1 — Author
# Receives: state["clinical_notes"]
# Returns:  {"author_draft": <LLM response>}
# ---------------------------------------------------------------------------
def author_node(state: GraphState) -> dict:
    """Generate the first-pass discharge summary from raw clinical notes."""
    user_prompt = AUTHOR_TASK_TEMPLATE.format(
        clinical_notes=state["clinical_notes"]
    )
    messages = [
        SystemMessage(content=AUTHOR_SYSTEM),
        HumanMessage(content=user_prompt),
    ]
    response = llm.invoke(messages)
    return {"author_draft": response.content}


# ---------------------------------------------------------------------------
# LANGGRAPH NODE 2 — Critic
# Receives: state["author_draft"]
# Returns:  {"critic_output": <LLM response>}
# ---------------------------------------------------------------------------
def critic_node(state: GraphState) -> dict:
    """Evaluate the author draft against the safety rubric and return a revised version."""
    user_prompt = CRITIC_TASK_TEMPLATE.format(
        author_draft=state["author_draft"]
    )
    messages = [
        SystemMessage(content=CRITIC_SYSTEM),
        HumanMessage(content=user_prompt),
    ]
    response = llm.invoke(messages)
    return {"critic_output": response.content}


# ---------------------------------------------------------------------------
# BUILD LANGGRAPH PIPELINE
#
#   START → author_node → critic_node → END
#
# LangGraph passes the full GraphState between nodes; each node reads what it
# needs and returns only the keys it updates (partial dict merge).
# ---------------------------------------------------------------------------
graph_builder = StateGraph(GraphState)
graph_builder.add_node("author", author_node)
graph_builder.add_node("critic", critic_node)
graph_builder.add_edge(START,    "author")
graph_builder.add_edge("author", "critic")
graph_builder.add_edge("critic", END)
app = graph_builder.compile()


# ===========================================================================
# MAIN — narrated, step-by-step walkthrough of the Critic pattern pipeline
# ===========================================================================
if __name__ == "__main__":

    # -----------------------------------------------------------------------
    # INTRODUCTION
    # -----------------------------------------------------------------------
    print("=" * 70)
    print("  CRITIC PATTERN DEMO  —  Healthcare Discharge Summary")
    print("=" * 70)
    print()
    print("WHAT IS THE CRITIC PATTERN?")
    print("-" * 70)
    print("A Critic agent is a SEPARATE evaluator that checks another agent's")
    print("output within the SAME execution run.")
    print()
    print("  Author node : generates the discharge summary (one LLM call)")
    print("  Critic node : evaluates the draft against a safety rubric (one LLM call)")
    print()
    print("  This is different from the Reflection pattern, where the SAME agent")
    print("  reviews its own past outputs across multiple episodes to update its")
    print("  reasoning strategy over time.")
    print()
    print("  Critic  = 'Is this output good RIGHT NOW?'")
    print("  Reflection = 'How do I get better OVER TIME?'")
    print()
    print(f"  LLM backend : {MODEL_ID}  (AWS Bedrock)")
    print(f"  AWS region  : {AWS_REGION}")
    print(f"  Framework   : LangGraph  (START → author → critic → END)")
    print()
    pause(
        "PATIENT SCENARIO\n"
        + "-" * 70 + "\n"
        + "John Smith, 67 y/o male, admitted with an acute heart attack (STEMI).\n"
        + "He had emergency stent surgery and was newly diagnosed with diabetes.\n"
        + "His discharge summary MUST be safe — a medication error here could kill him."
    )

    # -----------------------------------------------------------------------
    # STEP 1 — Show Author node configuration and prompt
    # -----------------------------------------------------------------------
    notes = read_notes()

    print("STEP 1 — AUTHOR NODE CONFIGURATION")
    print("-" * 70)
    print("The Author node sends two messages to the Bedrock LLM:")
    print()
    print("  [SYSTEM MESSAGE]  — defines the Author's persona:")
    print(f'  "{AUTHOR_SYSTEM}"')
    print()
    print("  [USER MESSAGE / TASK]  — the actual instruction with clinical notes:")
    print()
    rendered_author_prompt = AUTHOR_TASK_TEMPLATE.format(clinical_notes=notes)
    for line in rendered_author_prompt.splitlines():
        print(f"    {line}")
    print()
    pause(">> LangGraph will now invoke the Author node (Bedrock LLM call #1).")

    # -----------------------------------------------------------------------
    # STEP 2 — Show Critic node configuration and prompt (template)
    # -----------------------------------------------------------------------
    print("STEP 2 — CRITIC NODE CONFIGURATION")
    print("-" * 70)
    print("The Critic node sends two messages to the Bedrock LLM:")
    print()
    print("  [SYSTEM MESSAGE]  — defines the Critic's persona:")
    print(f'  "{CRITIC_SYSTEM}"')
    print()
    print("  [USER MESSAGE / TASK]  — rubric + the author draft (filled in at runtime):")
    print()
    # Show the template with a placeholder where the draft will go
    template_preview = CRITIC_TASK_TEMPLATE.replace(
        "{author_draft}", "<< Author draft will be inserted here at runtime >>"
    )
    for line in template_preview.splitlines():
        print(f"    {line}")
    print()
    print("KEY POINT: The Critic prompt contains an explicit RUBRIC.")
    print("Without a rubric, a reviewer LLM tends to give vague praise.")
    print("The rubric forces it to check every safety dimension and report issues.")
    print()
    pause(">> LangGraph will run the full pipeline (Author → Critic) now.\n"
          "   Watch each node's output appear as it completes.")

    # -----------------------------------------------------------------------
    # RUN THE LANGGRAPH PIPELINE — stream node-by-node
    # app.stream() yields a dict per node: {"node_name": {state_updates}}
    # -----------------------------------------------------------------------
    print("=" * 70)
    print("  RUNNING LANGGRAPH PIPELINE")
    print("=" * 70)
    print()
    print("  [ Author node executing... calling Bedrock LLM, please wait ]")
    print()

    final_state = {}
    for event in app.stream(
        {"clinical_notes": notes},
        stream_mode="updates",
    ):
        node_name, node_output = next(iter(event.items()))

        if node_name == "author":
            print("[ AUTHOR NODE COMPLETED ]")
            print("-" * 70)
            print("This is the first-pass draft — competent but potentially missing")
            print("safety details.  The Critic will review it next.")
            print()
            print(node_output["author_draft"])
            print()
            final_state["author_draft"] = node_output["author_draft"]
            pause(">> Author node done.  Critic node will now evaluate this draft.")
            print("  [ Critic node executing... calling Bedrock LLM, please wait ]")
            print()

        elif node_name == "critic":
            print("[ CRITIC NODE COMPLETED ]")
            print("-" * 70)
            print("The Critic evaluated the draft against all four rubric points.")
            print("Below: (a) numbered issues found,  (b) revised safer summary.")
            print()
            print(node_output["critic_output"])
            print()
            final_state["critic_output"] = node_output["critic_output"]
            pause()

    # -----------------------------------------------------------------------
    # SAVE OUTPUTS
    # -----------------------------------------------------------------------
    os.makedirs("outputs", exist_ok=True)
    output_path = "outputs/healthcare_critic_summary.md"
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("# AUTHOR DRAFT  (first-pass, pre-Critic)\n\n")
        f.write(final_state.get("author_draft", ""))
        f.write("\n\n---\n\n")
        f.write("# CRITIC-REVISED SUMMARY  (post quality-control pass)\n\n")
        f.write(final_state.get("critic_output", ""))
    print(f"Both draft and revised summary saved to: {output_path}")
    print()

    # -----------------------------------------------------------------------
    # OUTCOME SUMMARY
    # -----------------------------------------------------------------------
    print("=" * 70)
    print("  OUTCOME SUMMARY — CRITIC PATTERN IN ACTION")
    print("=" * 70)
    print()
    print("  BEFORE Critic pass (Author only):")
    print("    - Competent structured summary in one LLM call")
    print("    - Likely gaps: bleeding warnings, hypoglycemia instructions,")
    print("      explicit 911 vs. doctor guidance, unexplained jargon")
    print()
    print("  AFTER Critic pass (Author + Critic):")
    print("    - Critic identified every gap against the safety rubric")
    print("    - Revised summary is demonstrably safer and more complete")
    print("    - Cost: 2 LLM calls, 1 LangGraph pipeline execution")
    print()
    print("  WHY THE RUBRIC IS THE KEY INGREDIENT:")
    print("    Without the rubric, the Critic is just another writing assistant.")
    print("    With the rubric, it becomes a QA gate — it MUST address each")
    print("    safety dimension before the pipeline can end.  That is what")
    print("    separates the Critic pattern from a simple 'review this' prompt.")
    print()
    print("  LANGGRAPH ADVANTAGE OVER CREWAI HERE:")
    print("    LangGraph's StateGraph makes the data flow explicit — you can")
    print("    see exactly which keys each node reads and writes.  app.stream()")
    print("    lets you observe intermediate results node-by-node, which is")
    print("    critical for debugging multi-agent pipelines.")
    print("=" * 70)
