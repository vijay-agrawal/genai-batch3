# advanced_agent_operations.py
import boto3
import json

class AdvancedAgentOperations:
    def __init__(self, region_name='us-east-1'):
        self.bedrock_agent = boto3.client('bedrock-agent', region_name=region_name)
        self.bedrock_runtime = boto3.client('bedrock-agent-runtime', region_name=region_name)
    
    def list_all_agents(self):
        """List all agents in the account"""
        try:
            response = self.bedrock_agent.list_agents()
            print("📋 All Agents:")
            for agent in response['agentSummaries']:
                print(f"   • {agent['agentName']} (ID: {agent['agentId']}) - Status: {agent['agentStatus']}")
            return response['agentSummaries']
        except Exception as e:
            print(f"Error listing agents: {e}")
            return []
    
    def get_agent_details(self, agent_id):
        """Get detailed information about an agent"""
        try:
            response = self.bedrock_agent.get_agent(agentId=agent_id)
            agent = response['agent']
            
            print(f"🤖 Agent Details for {agent['agentName']}:")
            print(f"   ID: {agent['agentId']}")
            print(f"   Status: {agent['agentStatus']}")
            print(f"   Model: {agent['foundationModel']}")
            print(f"   Instructions: {agent['instruction']}")
            print(f"   Created: {agent['createdAt']}")
            print(f"   Updated: {agent['updatedAt']}")
            
            return agent
        except Exception as e:
            print(f"Error getting agent details: {e}")
            return None
    
    def update_agent_instructions(self, agent_id, new_instructions):
        """Update agent instructions"""
        try:
            response = self.bedrock_agent.update_agent(
                agentId=agent_id,
                agentName=agent_id,  # Keep same name
                instruction=new_instructions
            )
            
            # Prepare agent after update
            self.bedrock_agent.prepare_agent(agentId=agent_id)
            print(f"✅ Agent instructions updated and prepared!")
            return response
        except Exception as e:
            print(f"Error updating agent: {e}")
            return None
    
    def chat_with_agent(self, agent_id, alias_id, message, session_id=None):
        """Interactive chat with the agent"""
        if not session_id:
            session_id = f"session-{int(time.time())}"
        
        try:
            response = self.bedrock_runtime.invoke_agent(
                agentId=agent_id,
                agentAliasId=alias_id,
                sessionId=session_id,
                inputText=message,
                enableTrace=True  # Enable tracing for debugging
            )
            
            # Process response
            event_stream = response['completion']
            full_response = ""
            
            for event in event_stream:
                if 'chunk' in event:
                    chunk = event['chunk']
                    if 'bytes' in chunk:
                        full_response += chunk['bytes'].decode('utf-8')
                elif 'trace' in event:
                    # Print trace information for debugging
                    trace = event['trace']['trace']
                    if 'orchestrationTrace' in trace:
                        print(f"🔍 Trace: {trace['orchestrationTrace']}")
            
            return full_response, session_id
            
        except Exception as e:
            print(f"Error chatting with agent: {e}")
            return None, session_id

# Example usage
if __name__ == "__main__":
    ops = AdvancedAgentOperations()
    
    # List all agents
    agents = ops.list_all_agents()
    
    # Get details of your specific agent
    if agents:
        agent_id = "THZ5AMWWP2"  # Your agent ID
        ops.get_agent_details(agent_id)
        
        # Chat with the agent
        response, session = ops.chat_with_agent(
            agent_id=agent_id,
            alias_id="TSTALIASID",
            message="What can you help me with?"
        )
        print(f"🤖 Response: {response}")
