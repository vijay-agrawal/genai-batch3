import boto3
from datetime import datetime

def test_weather():
    client = boto3.client('bedrock-agent-runtime', region_name='us-east-1')
    session_id = f"weather-test-{int(datetime.now().timestamp())}"
    
    print(f"Testing weather query with agent PHJ8HSNSAZ")
    
    try:
        response = client.invoke_agent(
            agentId='PHJ8HSNSAZ',
            agentAliasId='TSTALIASID',
            sessionId=session_id,
            inputText='What is the weather like in Chennai?',
            enableTrace=True
        )
        
        print("\n--- Agent Response ---")
        completion_text = ""
        
        for event in response.get('completion', []):
            if 'chunk' in event:
                chunk = event['chunk']
                if 'bytes' in chunk:
                    chunk_text = chunk['bytes'].decode('utf-8')
                    print(chunk_text, end='', flush=True)
                    completion_text += chunk_text
            
            elif 'trace' in event:
                trace = event['trace']
                if 'orchestrationTrace' in trace:
                    orch_trace = trace['orchestrationTrace']
                    
                    # Check for action group invocation
                    if 'invocationInput' in orch_trace:
                        inv_input = orch_trace['invocationInput']
                        if 'actionGroupInvocationInput' in inv_input:
                            action_input = inv_input['actionGroupInvocationInput']
                            print(f"\n[INVOKING ACTION] {action_input.get('actionGroupName', 'unknown')}")
                            print(f"Function: {action_input.get('function', 'unknown')}")
                            print(f"Parameters: {action_input.get('parameters', [])}")
                    
                    # Check for action group results
                    elif 'observation' in orch_trace:
                        obs = orch_trace['observation']
                        if 'actionGroupInvocationOutput' in obs:
                            action_output = obs['actionGroupInvocationOutput']
                            print(f"\n[ACTION RESULT] {action_output.get('text', 'No text result')}")
        
        print(f"\n\nFinal response: '{completion_text}'")
        
        if 'weather' in completion_text.lower() or 'temperature' in completion_text.lower():
            print("✅ Weather data found in response!")
        else:
            print("❌ No weather data in response")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_weather()
