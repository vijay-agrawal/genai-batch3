# Weather Agent on Amazon Bedrock

## Overview

In this lab, you will build an AI-powered **Weather Agent** using Amazon Bedrock. The agent accepts natural language weather queries (e.g., "What's the weather in Tokyo?") and calls a real AWS Lambda function to fetch live weather data from the OpenWeatherMap API.

This lab demonstrates two core concepts:
- **Tools / Action Groups** — giving a Bedrock Agent the ability to call external functions
- **Agentic reasoning** — the agent decides when and how to call the tool based on user input

---

## Architecture

```
User Question
     |
     v
Amazon Bedrock Agent  (Foundation Model: Amazon Nova Lite)
     |
     |-- decides to call get_weather(location="Tokyo")
     v
AWS Lambda Function  (get_weather)
     |
     v
OpenWeatherMap API  (real-time weather data)
     |
     v
Response returned to Bedrock Agent --> formatted answer to user
```

---

## Prerequisites

Before starting, make sure you have:

- An **AWS account** with permissions to create Lambda functions, IAM roles, and Bedrock agents
- An **OpenWeatherMap API key** — sign up for free at [openweathermap.org](https://openweathermap.org/api)
- Access to **Amazon Bedrock** with the **Amazon Nova Lite** model enabled in your region (us-east-1 recommended)
- Basic familiarity with the AWS Console

---

## Part 1: Create the Lambda Tool (`get_weather`)

The Lambda function is the "tool" that the Bedrock Agent will call. It takes a city name, calls the OpenWeatherMap API, and returns current weather data.

### Step 1: Create the Lambda Function

1. Open the [AWS Lambda Console](https://console.aws.amazon.com/lambda)
2. Click **Create function**
3. Choose **Author from scratch**
4. Configure:
   - **Function name:** `get_weather`
   - **Runtime:** Python 3.12
   - **Architecture:** x86_64
5. Click **Create function**

Replace the default code in the editor with the following:

```python
import json
import os
import requests


def get_weather(location: str) -> str:
    """Retrieve real-time weather information for a given location."""
    print(f"Getting weather for: {location}")

    try:
        api_key = os.getenv('OPENWEATHERMAP_API_KEY')
        if not api_key:
            return "Error: OpenWeatherMap API key not configured"

        # Step 1: Get coordinates from the location name
        geo_url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={api_key}"
        geo_response = requests.get(geo_url, timeout=10)
        geo_response.raise_for_status()
        geo_data = geo_response.json()

        if not geo_data:
            return f"Could not find location: {location}"

        latitude = geo_data[0]['lat']
        longitude = geo_data[0]['lon']

        # Step 2: Get weather data using the coordinates
        weather_url = (
            f"https://api.openweathermap.org/data/2.5/weather"
            f"?lat={latitude}&lon={longitude}&appid={api_key}&units=metric"
        )
        weather_response = requests.get(weather_url, timeout=10)
        weather_response.raise_for_status()
        weather_data = weather_response.json()

        weather_info = (
            f"Weather in {location}:\n"
            f"Description: {weather_data['weather'][0]['description'].title()}\n"
            f"Temperature: {weather_data['main']['temp']}°C\n"
            f"Feels like: {weather_data['main']['feels_like']}°C\n"
            f"Humidity: {weather_data['main']['humidity']}%\n"
            f"Wind Speed: {weather_data['wind'].get('speed', 'N/A')} m/s"
        )

        print(f"Weather data retrieved successfully for {location}")
        return weather_info

    except requests.exceptions.RequestException as e:
        return f"Error fetching weather data for {location}: {str(e)}"
    except KeyError as e:
        return f"Error parsing weather data for {location}: Missing field {str(e)}"
    except Exception as e:
        return f"Unexpected error getting weather for {location}: {str(e)}"


def lambda_handler(event, context):
    """Lambda handler — supports both direct testing and Bedrock Agent invocation."""

    print(f"Received event: {json.dumps(event)}")

    # Check if this is a Bedrock Agent invocation
    if 'agent' in event and 'actionGroup' in event:
        action_group = event.get('actionGroup', '')
        function = event.get('function', '')
        parameters = event.get('parameters', [])

        # Extract the 'location' parameter
        location = None
        for param in parameters:
            if param['name'] == 'location':
                location = param['value']
                break

        if not location:
            result = "Error: Location parameter is required"
        else:
            result = get_weather(location)

        # Format the response in the structure Bedrock Agents expect
        return {
            'messageVersion': '1.0',
            'response': {
                'actionGroup': action_group,
                'function': function,
                'functionResponse': {
                    'responseBody': {
                        'TEXT': {'body': result}
                    }
                }
            },
            'sessionAttributes': event.get('sessionAttributes', {}),
            'promptSessionAttributes': event.get('promptSessionAttributes', {})
        }

    else:
        # Direct test invocation (from Lambda console or CLI)
        location = event.get('location', 'New York')
        result = get_weather(location)

        return {
            'statusCode': 200,
            'body': json.dumps({'location': location, 'weather': result})
        }
```

### Step 2: Add a Lambda Layer for the `requests` Library

The `requests` library is not included in Lambda's default Python runtime. Add the AWS-managed layer that bundles it:

1. In your Lambda function, scroll down to the **Layers** section
2. Click **Add a layer**
3. Select **AWS layers**
4. Choose: `AWSSDKPandas-Python312`
5. Select the latest version
6. Click **Add**

> **Why this layer?** The `AWSSDKPandas-Python312` managed layer bundles `requests` as a dependency, making it available inside your function without packaging anything manually.

### Step 3: Set the OpenWeatherMap API Key

1. In your Lambda function, go to **Configuration** > **Environment variables**
2. Click **Edit** > **Add environment variable**
3. Set:
   - **Key:** `OPENWEATHERMAP_API_KEY`
   - **Value:** your OpenWeatherMap API key
4. Click **Save**

### Step 4: Adjust Lambda Configuration

1. Go to **Configuration** > **General configuration** > **Edit**
2. Set:
   - **Timeout:** 30 seconds
   - **Memory:** 256 MB
3. Click **Save**

### Step 5: Create an IAM Execution Role for Lambda

The Lambda function needs permission to write logs to CloudWatch. The default execution role created by Lambda already includes this, but if you need to create or update one manually, attach this policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "arn:aws:logs:*:*:*"
    }
  ]
}
```

### Step 6: Publish the Lambda Function

Publishing creates a numbered version that cannot be changed, which makes deployments more stable.

1. Click **Actions** > **Publish new version**
2. Add a description (e.g., `Initial version`) and click **Publish**

---

## Part 2: Test the Lambda Function

Before connecting the Lambda to Bedrock, verify it works correctly on its own.

### Method A: Quick Test in the Lambda Console

1. Open your Lambda function and click the **Test** tab
2. Create a new test event named `direct_test`:

```json
{
  "location": "Pune"
}
```

3. Click **Test**

Expected result:

```json
{
  "statusCode": 200,
  "body": "{\"location\": \"Pune\", \"weather\": \"Weather in Pune:\\nDescription: Clear Sky\\nTemperature: 33.5°C\\nFeels like: 31.4°C\\nHumidity: 18%\\nWind Speed: 2.73 m/s\"}"
}
```

### Method B: Simulate a Bedrock Agent Invocation

This verifies the Lambda response format that Bedrock Agents expect.

Create a second test event named `bedrock_simulation`:

```json
{
  "messageVersion": "1.0",
  "agent": {
    "name": "weather-agent",
    "version": "DRAFT",
    "id": "dummy-agent-id",
    "alias": "dummy-alias"
  },
  "inputText": "What's the weather in Hyderabad?",
  "sessionId": "test-session-123",
  "actionGroup": "weather-tools",
  "function": "get_weather",
  "parameters": [
    {
      "name": "location",
      "type": "string",
      "value": "Hyderabad"
    }
  ],
  "sessionAttributes": {},
  "promptSessionAttributes": {}
}
```

Expected response:

```json
{
  "messageVersion": "1.0",
  "response": {
    "actionGroup": "weather-tools",
    "function": "get_weather",
    "functionResponse": {
      "responseBody": {
        "TEXT": {
          "body": "Weather in Hyderabad:\nDescription: Clear Sky\nTemperature: 34.19°C\nFeels like: 31.99°C\nHumidity: 18%\nWind Speed: 5.14 m/s"
        }
      }
    }
  },
  "sessionAttributes": {},
  "promptSessionAttributes": {}
}
```

### Method C: Test via AWS CloudShell

You can also invoke the Lambda from CloudShell using the AWS CLI or Python:

```bash
# Create the test script
cat > test_weather_lambda.py << 'EOF'
import boto3
import json

def test_lambda_function():
    lambda_client = boto3.client('lambda', region_name='us-east-1')

    test_event = {"location": "Chennai"}

    response = lambda_client.invoke(
        FunctionName='get_weather',
        InvocationType='RequestResponse',
        Payload=json.dumps(test_event)
    )

    response_payload = json.loads(response['Payload'].read())
    print("Lambda Response:")
    print(json.dumps(response_payload, indent=2))

    if 'errorMessage' in response_payload:
        print(f"Error: {response_payload['errorMessage']}")
    else:
        print("Success!")

if __name__ == "__main__":
    test_lambda_function()
EOF

# Run the test
python3 test_weather_lambda.py
```

---

## Part 3: Create the Bedrock Agent

Now that the Lambda tool works, create a Bedrock Agent that will use it.

### Step 1: Create an IAM Role for the Bedrock Agent

The agent needs an IAM role that allows Bedrock to assume it and invoke Foundation Models.

1. Open the [IAM Console](https://console.aws.amazon.com/iam)
2. Go to **Roles** > **Create role**
3. Select **Custom trust policy** and paste:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "bedrock.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

4. Attach the managed policy: `AmazonBedrockFullAccess`
5. Name the role: `AmazonBedrockExecutionRoleForAgents_WeatherAgent`
6. Click **Create role**

### Step 2: Create the Agent in the Bedrock Console

1. Open the [Amazon Bedrock Console](https://console.aws.amazon.com/bedrock)
2. In the left navigation, click **Agents**
3. Click **Create agent**
4. Configure:
   - **Agent name:** `weather-agent`
   - **Description:** `AI agent that provides real-time weather information`
   - **Agent resource role:** select the role you created in Step 1
   - **Foundation model:** Amazon Nova Lite (`amazon.nova-lite-v1:0`)
   - **Instructions for the Agent:**

```
You are a weather assistant that helps users get real-time weather information for any location.

When a user asks about weather for a specific location, use the get_weather function to retrieve current weather data.

Instructions:
- Always use the get_weather function when users ask about weather
- The get_weather function requires a location parameter (city name)
- Provide clear, helpful weather information to users
- If a user does not specify a location, ask them which city they want weather information for
```

5. Click **Create**

### Step 3: Add an Action Group

An Action Group tells the agent which tools are available and how to call them.

1. Inside your agent, click **Edit**
2. Scroll to the **Action groups** section and click **Add action group**
3. Configure:
   - **Action group name:** `weather-tools`
   - **Description:** `Tools for retrieving real-time weather information`
   - **Action group type:** Define with function details
4. Under **Function details**, click **Add function** and set:
   - **Function name:** `get_weather`
   - **Description:** `Retrieve real-time weather information for a specific location`
   - **Parameters:**

     | Name     | Description                                                    | Type   | Required |
     |----------|----------------------------------------------------------------|--------|----------|
     | location | The city name or location to get weather for (e.g., New York) | string | Yes      |

5. Under **Action group executor**, select **Lambda function**:
   - **Lambda function:** choose your `get_weather` function
   - **Lambda version/alias:** `$LATEST`
6. Click **Save and exit**

### Step 4: Grant Bedrock Permission to Invoke the Lambda Function

Bedrock needs explicit permission to call your Lambda function. Run this in **AWS CloudShell**:

```bash
# Set your values
LAMBDA_FUNCTION_NAME="get_weather"
AGENT_ID="<your-agent-id>"   # Copy from the Bedrock console agent details page
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REGION="us-east-1"

# Add the resource-based policy to Lambda
aws lambda add-permission \
    --function-name $LAMBDA_FUNCTION_NAME \
    --statement-id bedrock-agent-permission \
    --action lambda:InvokeFunction \
    --principal bedrock.amazonaws.com \
    --source-arn "arn:aws:bedrock:${REGION}:${ACCOUNT_ID}:agent/${AGENT_ID}" \
    --region $REGION
```

Verify the permission was added:

```bash
aws lambda get-policy --function-name get_weather --region us-east-1
```

You should see a policy statement with `"Principal": {"Service": "bedrock.amazonaws.com"}`.

### Step 5: Prepare the Agent

After making changes, you must **prepare** the agent before testing it.

1. Go back to your agent in the Bedrock console
2. Click **Prepare**
3. Wait for the status to change to **Prepared**

> Preparing compiles your agent configuration and makes it ready to handle requests. You must re-prepare after any change to the agent, action groups, or Lambda.

### Step 6: Create an Agent Alias

Aliases are stable pointers to a prepared version of your agent. They are required to invoke the agent programmatically.

1. In your agent, click the **Aliases** tab
2. Click **Create alias**
3. Configure:
   - **Alias name:** `live`
   - **Description:** `Agent with weather functionality`
4. Click **Create alias**
5. Note the **Alias ID** — you will need it for testing

---

## Part 4: Test the Complete Agent

### Test in the Bedrock Console

1. In your agent, click the **Test** button (chat window on the right)
2. Try these queries:
   - "What's the weather in London?"
   - "Tell me about the weather in Tokyo"
   - "How's the weather in San Francisco today?"

### Test via Python (CloudShell or Local)

Replace `YOUR_AGENT_ID` and `YOUR_ALIAS_ID` with your actual values from the Bedrock console.

```bash
# Create the test script
cat > test_agent_weather.py << 'EOF'
import boto3
from datetime import datetime

client = boto3.client('bedrock-agent-runtime', region_name='us-east-1')
session_id = f"test-session-{int(datetime.now().timestamp())}"

# Replace with your actual Agent ID and Alias ID
AGENT_ID = "YOUR_AGENT_ID"
ALIAS_ID = "YOUR_ALIAS_ID"

try:
    response = client.invoke_agent(
        agentId=AGENT_ID,
        agentAliasId=ALIAS_ID,
        sessionId=session_id,
        inputText='What is the weather like in London?',
        enableTrace=True
    )

    print("Agent Response:")
    completion = ""

    for event in response.get('completion', []):
        if 'chunk' in event:
            chunk = event['chunk']
            if 'bytes' in chunk:
                chunk_text = chunk['bytes'].decode('utf-8')
                print(chunk_text, end='', flush=True)
                completion += chunk_text
        elif 'trace' in event:
            # Uncomment to see agent reasoning steps:
            # print(f"\n[TRACE] {event['trace']}")
            pass

    print(f"\n\nFull response: {completion}")

except Exception as e:
    print(f"Error: {e}")
EOF

python3 test_agent_weather.py
```

---

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| Lambda returns `Error: OpenWeatherMap API key not configured` | Environment variable not set | Add `OPENWEATHERMAP_API_KEY` in Lambda configuration |
| Lambda returns `ModuleNotFoundError: requests` | `requests` layer not added | Add the `AWSSDKPandas-Python312` layer to your Lambda |
| Bedrock agent returns no response / timeout | Lambda permission missing | Run the `aws lambda add-permission` command in Step 4 |
| Agent invocation returns `AccessDeniedException` | Agent not prepared, or alias not created | Re-prepare the agent and verify the alias ID |
| `Could not find location: <city>` | Invalid city name passed to OpenWeatherMap | Try a more specific name (e.g., "New York, US") |

---

## Summary

You have built a complete end-to-end agentic workflow:

1. A **Lambda function** that calls the OpenWeatherMap API and returns structured weather data
2. A **Bedrock Agent** powered by Amazon Nova Lite that reasons about user queries
3. An **Action Group** that links the agent to the Lambda tool
4. An **Agent Alias** for stable, versioned invocation

The agent now responds to natural language questions by autonomously deciding to call `get_weather`, passing the right location, and formatting the response — all without any hard-coded logic in the agent itself.
