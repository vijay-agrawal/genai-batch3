"""
indexer.py
1. Creates an IAM role for Bedrock Knowledge Base.
2. Creates an Amazon S3 Vectors bucket.
3. Creates a vector index inside the bucket.
4. Creates a Bedrock Knowledge Base backed by S3 Vectors.
5. Adds an S3 data source and triggers ingestion.
6. Saves the resulting IDs to kb_config.json for use by app.py.
"""

import json
import os
import time

import boto3
from botocore.exceptions import ClientError
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))

# ── Configuration ─────────────────────────────────────────────────────────────
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME")
VECTOR_BUCKET_NAME = os.getenv("S3_VECTOR_BUCKET_NAME", "ragdemo-vectors")
VECTOR_INDEX_NAME = os.getenv("S3_VECTOR_INDEX_NAME", "ragdemo-index")
KB_NAME = os.getenv("BEDROCK_KB_NAME", "ragdemo-kb")
EMBEDDING_MODEL_ID = os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0")

VECTOR_DIMENSION = 1024    # titan-embed-text-v2 produces 1024-dimensional vectors
VECTOR_DISTANCE_METRIC = "cosine"
VECTOR_DATA_TYPE = "float32"

KB_ROLE_NAME = "BedrockKBRole-S3Vectors"
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kb_config.json")


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_account_and_caller():
    sts = boto3.client("sts", region_name=AWS_REGION)
    identity = sts.get_caller_identity()
    return identity["Account"], identity["Arn"]


# ── Step 1 – IAM Role ─────────────────────────────────────────────────────────

def create_kb_iam_role(iam, account_id, bucket_name, vector_bucket_name, vector_index_name):
    trust_policy = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "bedrock.amazonaws.com"},
            "Action": "sts:AssumeRole",
        }],
    }
    try:
        role = iam.create_role(
            RoleName=KB_ROLE_NAME,
            AssumeRolePolicyDocument=json.dumps(trust_policy),
            Description="IAM role for Bedrock Knowledge Base backed by S3 Vectors",
        )
        role_arn = role["Role"]["Arn"]
        print(f"  Created IAM role: {role_arn}")
    except ClientError as e:
        if e.response["Error"]["Code"] == "EntityAlreadyExists":
            role_arn = iam.get_role(RoleName=KB_ROLE_NAME)["Role"]["Arn"]
            print(f"  IAM role already exists: {role_arn}")
        else:
            raise

    inline_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "BedrockEmbeddingModel",
                "Effect": "Allow",
                "Action": ["bedrock:InvokeModel"],
                "Resource": f"arn:aws:bedrock:{AWS_REGION}::foundation-model/*",
            },
            {
                "Sid": "S3DataSourceRead",
                "Effect": "Allow",
                "Action": ["s3:GetObject", "s3:ListBucket"],
                "Resource": [
                    f"arn:aws:s3:::{bucket_name}",
                    f"arn:aws:s3:::{bucket_name}/*",
                ],
            },
            {
                "Sid": "S3VectorsIndexAccess",
                "Effect": "Allow",
                "Action": [
                    "s3vectors:PutVectors",
                    "s3vectors:GetVectors",
                    "s3vectors:DeleteVectors",
                    "s3vectors:QueryVectors",
                    "s3vectors:GetIndex",
                ],
                "Resource": (
                    f"arn:aws:s3vectors:{AWS_REGION}:{account_id}:"
                    f"bucket/{vector_bucket_name}/index/{vector_index_name}"
                ),
            },
        ],
    }
    iam.put_role_policy(
        RoleName=KB_ROLE_NAME,
        PolicyName="BedrockKBInlinePolicy-S3Vectors",
        PolicyDocument=json.dumps(inline_policy),
    )
    print("  Inline policy attached.")
    return role_arn


# ── Step 2 – S3 Vector Bucket ─────────────────────────────────────────────────

def create_vector_bucket(s3v, vector_bucket_name):
    try:
        resp = s3v.create_vector_bucket(vectorBucketName=vector_bucket_name)
        vector_bucket_arn = resp["vectorBucketArn"]
        print(f"  Created vector bucket: {vector_bucket_arn}")
        return vector_bucket_arn
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConflictException":
            # Bucket already exists – retrieve its ARN
            resp = s3v.get_vector_bucket(vectorBucketName=vector_bucket_name)
            vector_bucket_arn = resp["vectorBucket"]["vectorBucketArn"]
            print(f"  Vector bucket already exists: {vector_bucket_arn}")
            return vector_bucket_arn
        raise


# ── Step 3 – Vector Index ─────────────────────────────────────────────────────

def create_vector_index(s3v, vector_bucket_name, vector_index_name):
    try:
        resp = s3v.create_index(
            vectorBucketName=vector_bucket_name,
            indexName=vector_index_name,
            dataType=VECTOR_DATA_TYPE,
            dimension=VECTOR_DIMENSION,
            distanceMetric=VECTOR_DISTANCE_METRIC,
            metadataConfiguration={
                "nonFilterableMetadataKeys": ["AMAZON_BEDROCK_TEXT_CHUNK"]
            },
        )
        index_arn = resp["indexArn"]
        print(f"  Created vector index: {index_arn}")
        return index_arn
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConflictException":
            resp = s3v.get_index(
                vectorBucketName=vector_bucket_name,
                indexName=vector_index_name,
            )
            index_arn = resp["index"]["indexArn"]
            print(f"  Vector index already exists: {index_arn}")
            return index_arn
        raise


# ── Step 4 – Bedrock Knowledge Base ───────────────────────────────────────────

def create_knowledge_base(bedrock_agent, role_arn, vector_bucket_arn, index_arn):
    embedding_arn = f"arn:aws:bedrock:{AWS_REGION}::foundation-model/{EMBEDDING_MODEL_ID}"

    for kb in bedrock_agent.list_knowledge_bases(maxResults=50).get("knowledgeBaseSummaries", []):
        if kb["name"] == KB_NAME:
            print(f"  Knowledge base already exists: {kb['knowledgeBaseId']}")
            return kb["knowledgeBaseId"]

    resp = bedrock_agent.create_knowledge_base(
        name=KB_NAME,
        description="RAG demo knowledge base backed by S3 Vectors",
        roleArn=role_arn,
        knowledgeBaseConfiguration={
            "type": "VECTOR",
            "vectorKnowledgeBaseConfiguration": {"embeddingModelArn": embedding_arn},
        },
        storageConfiguration={
            "type": "S3_VECTORS",
            "s3VectorsConfiguration": {
                "vectorBucketArn": vector_bucket_arn,
                "indexArn": index_arn,
                "indexName": VECTOR_INDEX_NAME,
            },
        },
    )
    kb_id = resp["knowledgeBase"]["knowledgeBaseId"]
    print(f"  Created knowledge base: {kb_id}")
    return kb_id


# ── Step 5 – Data Source + Ingestion ──────────────────────────────────────────

def create_data_source(bedrock_agent, kb_id, bucket_name):
    ds_name = "s3-data-source"
    for ds in bedrock_agent.list_data_sources(knowledgeBaseId=kb_id, maxResults=50).get("dataSourceSummaries", []):
        if ds["name"] == ds_name:
            print(f"  Data source already exists: {ds['dataSourceId']}")
            return ds["dataSourceId"]

    resp = bedrock_agent.create_data_source(
        knowledgeBaseId=kb_id,
        name=ds_name,
        description="S3 document store for RAG demo",
        dataSourceConfiguration={
            "type": "S3",
            "s3Configuration": {"bucketArn": f"arn:aws:s3:::{bucket_name}"},
        },
        vectorIngestionConfiguration={
            "chunkingConfiguration": {
                "chunkingStrategy": "FIXED_SIZE",
                "fixedSizeChunkingConfiguration": {
                    "maxTokens": 512,
                    "overlapPercentage": 20,
                },
            }
        },
    )
    ds_id = resp["dataSource"]["dataSourceId"]
    print(f"  Created data source: {ds_id}")
    return ds_id


def start_and_wait_ingestion(bedrock_agent, kb_id, ds_id, timeout=600):
    job_id = bedrock_agent.start_ingestion_job(
        knowledgeBaseId=kb_id, dataSourceId=ds_id
    )["ingestionJob"]["ingestionJobId"]
    print(f"  Ingestion job started: {job_id}")

    deadline = time.time() + timeout
    while time.time() < deadline:
        job = bedrock_agent.get_ingestion_job(
            knowledgeBaseId=kb_id, dataSourceId=ds_id, ingestionJobId=job_id
        )["ingestionJob"]
        status = job["status"]
        stats = job.get("statistics", {})
        print(f"    status: {status} | stats: {stats}")
        if status == "COMPLETE":
            print("  Ingestion complete!")
            return
        if status in ("FAILED", "STOPPED"):
            raise RuntimeError(f"Ingestion failed: {job.get('failureReasons', [])}")
        time.sleep(20)
    raise TimeoutError("Ingestion did not complete within the timeout.")


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not S3_BUCKET_NAME:
        print("Error: S3_BUCKET_NAME is not set in .env")
        raise SystemExit(1)

    print("=== RAG Demo – S3 Vectors Indexer ===\n")

    account_id, caller_arn = get_account_and_caller()
    print(f"Account : {account_id}")
    print(f"Caller  : {caller_arn}\n")

    iam = boto3.client("iam", region_name=AWS_REGION)
    s3v = boto3.client("s3vectors", region_name=AWS_REGION)
    bedrock_agent = boto3.client("bedrock-agent", region_name=AWS_REGION)

    print("[1/5] Creating IAM role for Knowledge Base...")
    role_arn = create_kb_iam_role(iam, account_id, S3_BUCKET_NAME, VECTOR_BUCKET_NAME, VECTOR_INDEX_NAME)

    print("\n[2/5] Creating S3 vector bucket...")
    vector_bucket_arn = create_vector_bucket(s3v, VECTOR_BUCKET_NAME)

    print("\n[3/5] Creating vector index...")
    index_arn = create_vector_index(s3v, VECTOR_BUCKET_NAME, VECTOR_INDEX_NAME)

    print("\n[4/5] Creating Bedrock Knowledge Base...")
    time.sleep(15)  # allow IAM role propagation
    kb_id = create_knowledge_base(bedrock_agent, role_arn, vector_bucket_arn, index_arn)

    print("\n[5/5] Creating data source and ingesting documents...")
    ds_id = create_data_source(bedrock_agent, kb_id, S3_BUCKET_NAME)
    start_and_wait_ingestion(bedrock_agent, kb_id, ds_id)

    # Persist IDs for the chatbot
    config = {
        "knowledge_base_id": kb_id,
        "data_source_id": ds_id,
        "vector_bucket_arn": vector_bucket_arn,
        "index_arn": index_arn,
        "region": AWS_REGION,
    }
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

    print(f"\n=== Done! Configuration saved to kb_config.json ===")
    print(f"Knowledge Base ID : {kb_id}")
    print("Run app.py to start chatting.")
