"""
data_uploader.py
Uploads all files from the ragdemo/data/ folder to an S3 bucket.
"""

import mimetypes
import os

import boto3
from botocore.exceptions import ClientError
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME")
DATA_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def ensure_bucket(s3, bucket_name, region):
    try:
        s3.head_bucket(Bucket=bucket_name)
        print(f"Bucket '{bucket_name}' already exists.")
    except ClientError as e:
        code = e.response["Error"]["Code"]
        if code in ("404", "NoSuchBucket"):
            print(f"Creating bucket '{bucket_name}'...")
            if region == "us-east-1":
                s3.create_bucket(Bucket=bucket_name)
            else:
                s3.create_bucket(
                    Bucket=bucket_name,
                    CreateBucketConfiguration={"LocationConstraint": region},
                )
            print(f"Bucket created: {bucket_name}")
        else:
            raise


def upload_files(s3, data_folder, bucket_name):
    files = [f for f in os.listdir(data_folder) if os.path.isfile(os.path.join(data_folder, f))]
    if not files:
        print("No files found in the data folder.")
        return

    print(f"\nUploading {len(files)} files to s3://{bucket_name}/")
    for i, filename in enumerate(files, 1):
        file_path = os.path.join(data_folder, filename)
        content_type, _ = mimetypes.guess_type(file_path)
        content_type = content_type or "application/octet-stream"
        s3.upload_file(
            file_path,
            bucket_name,
            filename,
            ExtraArgs={"ContentType": content_type},
        )
        print(f"  [{i}/{len(files)}] {filename}  ({content_type})")

    print(f"\nAll {len(files)} files uploaded to s3://{bucket_name}/")


if __name__ == "__main__":
    if not S3_BUCKET_NAME:
        print("Error: S3_BUCKET_NAME is not set in .env")
        raise SystemExit(1)

    s3 = boto3.client("s3", region_name=AWS_REGION)
    ensure_bucket(s3, S3_BUCKET_NAME, AWS_REGION)
    upload_files(s3, DATA_FOLDER, S3_BUCKET_NAME)
