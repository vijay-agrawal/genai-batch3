"""
Healthcare Prior Authorization Knowledge Graph Population Script
================================================================
Connects to Neo4j and creates the full knowledge graph with nodes
and relationships representing the healthcare prior auth ecosystem.

Usage:
    python populate_kg.py

Requires:
    - Neo4j instance running (local or Aura)
    - .env file with NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD
"""

import json
import os
from neo4j import GraphDatabase
from dotenv import load_dotenv

load_dotenv()

NEO4J_URI = os.getenv("NEO4J_URI", "bolt://localhost:7687")
NEO4J_USERNAME = os.getenv("NEO4J_USERNAME", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "password")

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


# ── Helper ──────────────────────────────────────────────────────────────────

def load_json(filename):
    path = os.path.join(DATA_DIR, filename)
    with open(path, "r") as f:
        return json.load(f)


# ── Database setup ───────────────────────────────────────────────────────────

def create_constraints(session):
    """Create uniqueness constraints for all node types."""
    print("\n[1/9] Creating uniqueness constraints...")
    constraints = [
        ("Patient",         "id"),
        ("Provider",        "id"),
        ("InsurancePlan",   "id"),
        ("Diagnosis",       "code"),
        ("Procedure",       "code"),
        ("Medication",      "name"),
        ("Claim",           "id"),
        ("PriorAuthRequest","id"),
        ("CoverageRule",    "id"),
    ]
    for label, prop in constraints:
        session.run(
            f"CREATE CONSTRAINT IF NOT EXISTS "
            f"FOR (n:{label}) REQUIRE n.{prop} IS UNIQUE"
        )
        print(f"   Constraint: {label}.{prop}")


def clear_database(session):
    """
    DANGER: Deletes ALL nodes and relationships.
    Uncomment the call in main() only when you want a fresh start.
    """
    print("[!] Clearing entire database...")
    session.run("MATCH (n) DETACH DELETE n")
    print("[!] Database cleared.")


# ── Node creation ─────────────────────────────────────────────────────────────

def create_patients(session, patients):
    print("\n[2/9] Creating Patient nodes...")
    for p in patients:
        session.run(
            """
            MERGE (pt:Patient {id: $id})
            SET pt.name      = $name,
                pt.age       = $age,
                pt.gender    = $gender,
                pt.dob       = $dob,
                pt.member_id = $member_id,
                pt.address   = $address,
                pt.phone     = $phone,
                pt.plan_id   = $plan_id,
                pt.bmi       = $bmi,
                pt.notes     = $notes
            """,
            id=p["id"],
            name=p["name"],
            age=p["age"],
            gender=p["gender"],
            dob=p["dob"],
            member_id=p["member_id"],
            address=p["address"],
            phone=p["phone"],
            plan_id=p.get("plan_id", ""),
            bmi=p.get("bmi", 0.0),
            notes=p.get("notes", ""),
        )
    print(f"   Created/merged {len(patients)} Patient nodes.")


def create_providers(session, providers):
    print("\n[3/9] Creating Provider nodes...")
    for pr in providers:
        session.run(
            """
            MERGE (pv:Provider {id: $id})
            SET pv.name       = $name,
                pv.specialty  = $specialty,
                pv.npi        = $npi,
                pv.type       = $type,
                pv.address    = $address,
                pv.phone      = $phone
            """,
            id=pr["id"],
            name=pr["name"],
            specialty=pr["specialty"],
            npi=pr["npi"],
            type=pr["type"],
            address=pr["address"],
            phone=pr["phone"],
        )
    print(f"   Created/merged {len(providers)} Provider nodes.")


def create_insurance_plans(session, plans):
    print("\n[4/9] Creating InsurancePlan nodes...")
    for pl in plans:
        session.run(
            """
            MERGE (ip:InsurancePlan {id: $id})
            SET ip.name                         = $name,
                ip.type                         = $type,
                ip.insurer                      = $insurer,
                ip.deductible                   = $deductible,
                ip.max_out_of_pocket            = $max_out_of_pocket,
                ip.prior_auth_required_threshold= $pa_threshold,
                ip.prior_auth_phone             = $pa_phone,
                ip.appeal_timeframe_days        = $appeal_days
            """,
            id=pl["id"],
            name=pl["name"],
            type=pl["type"],
            insurer=pl["insurer"],
            deductible=pl["deductible"],
            max_out_of_pocket=pl["max_out_of_pocket"],
            pa_threshold=pl["prior_auth_required_threshold"],
            pa_phone=pl["prior_auth_phone"],
            appeal_days=pl["appeal_timeframe_days"],
        )
    print(f"   Created/merged {len(plans)} InsurancePlan nodes.")


def create_diagnoses(session, diagnoses):
    print("\n[5/9] Creating Diagnosis nodes...")
    for d in diagnoses:
        session.run(
            """
            MERGE (dx:Diagnosis {code: $code})
            SET dx.description    = $description,
                dx.category       = $category,
                dx.severity_level = $severity_level,
                dx.chronic        = $chronic
            """,
            code=d["code"],
            description=d["description"],
            category=d["category"],
            severity_level=d["severity_level"],
            chronic=d.get("chronic", False),
        )
    print(f"   Created/merged {len(diagnoses)} Diagnosis nodes.")


def create_procedures(session, procedures):
    print("\n[6/9] Creating Procedure nodes...")
    for proc in procedures:
        session.run(
            """
            MERGE (pr:Procedure {code: $code})
            SET pr.description         = $description,
                pr.type                = $type,
                pr.typical_cost        = $typical_cost,
                pr.prior_auth_required = $prior_auth_required,
                pr.inpatient_required  = $inpatient_required,
                pr.specialty_required  = $specialty_required
            """,
            code=proc["code"],
            description=proc["description"],
            type=proc["type"],
            typical_cost=proc["typical_cost"],
            prior_auth_required=proc["prior_auth_required"],
            inpatient_required=proc.get("inpatient_required", False),
            specialty_required=proc.get("specialty_required", "Any"),
        )
    print(f"   Created/merged {len(procedures)} Procedure nodes.")


def create_medications(session, medications):
    print("\n[7/9] Creating Medication nodes...")
    for med in medications:
        session.run(
            """
            MERGE (m:Medication {name: $name})
            SET m.generic_name            = $generic_name,
                m.drug_class              = $drug_class,
                m.ndc                     = $ndc,
                m.typical_monthly_cost    = $typical_monthly_cost,
                m.prior_auth_required     = $prior_auth_required,
                m.step_therapy_required   = $step_therapy_required,
                m.step_therapy_prerequisite = $step_therapy_prerequisite,
                m.tier                    = $tier,
                m.indication              = $indication
            """,
            name=med["name"],
            generic_name=med["generic_name"],
            drug_class=med["drug_class"],
            ndc=med["ndc"],
            typical_monthly_cost=med["typical_monthly_cost"],
            prior_auth_required=med["prior_auth_required"],
            step_therapy_required=med["step_therapy_required"],
            step_therapy_prerequisite=med.get("step_therapy_prerequisite", ""),
            tier=med["tier"],
            indication=med.get("indication", ""),
        )
    print(f"   Created/merged {len(medications)} Medication nodes.")


def create_claims(session, claims):
    print("\n[8/9] Creating Claim nodes...")
    for cl in claims:
        session.run(
            """
            MERGE (c:Claim {id: $id})
            SET c.date          = $date,
                c.item_type     = $item_type,
                c.item_name     = $item_name,
                c.amount        = $amount,
                c.status        = $status,
                c.denial_reason = $denial_reason,
                c.notes         = $notes
            """,
            id=cl["id"],
            date=cl["date"],
            item_type=cl["item_type"],
            item_name=cl["item_name"],
            amount=cl["amount"],
            status=cl["status"],
            denial_reason=cl.get("denial_reason") or "",
            notes=cl.get("notes") or "",
        )
    print(f"   Created/merged {len(claims)} Claim nodes.")


def create_prior_auth_requests(session, pa_requests):
    print("\n[9/9] Creating PriorAuthRequest nodes...")
    for pa in pa_requests:
        session.run(
            """
            MERGE (par:PriorAuthRequest {id: $id})
            SET par.request_date    = $request_date,
                par.item_type       = $item_type,
                par.item_code       = $item_code,
                par.status          = $status,
                par.decision_date   = $decision_date,
                par.urgency         = $urgency,
                par.decision_notes  = $decision_notes,
                par.auth_number     = $auth_number,
                par.plan_id         = $plan_id
            """,
            id=pa["id"],
            request_date=pa["request_date"],
            item_type=pa["item_type"],
            item_code=pa["item_code"],
            status=pa["status"],
            decision_date=pa.get("decision_date") or "",
            urgency=pa.get("urgency", "routine"),
            decision_notes=pa.get("decision_notes") or "",
            auth_number=pa.get("auth_number") or "",
            plan_id=pa.get("plan_id", ""),
        )
    print(f"   Created/merged {len(pa_requests)} PriorAuthRequest nodes.")


def create_coverage_rules(session, rules):
    print("\n[+] Creating CoverageRule nodes...")
    for r in rules:
        session.run(
            """
            MERGE (cr:CoverageRule {id: $id})
            SET cr.name                       = $name,
                cr.description                = $description,
                cr.applies_to_type            = $applies_to_type,
                cr.applies_to_code            = $applies_to_code,
                cr.requirements               = $requirements,
                cr.decision_timeframe_days    = $decision_timeframe_days,
                cr.appeal_allowed             = $appeal_allowed,
                cr.plan_id                    = $plan_id
            """,
            id=r["id"],
            name=r["name"],
            description=r["description"],
            applies_to_type=r["applies_to_type"],
            applies_to_code=r["applies_to_code"],
            requirements=r["requirements"],
            decision_timeframe_days=r["decision_timeframe_days"],
            appeal_allowed=r["appeal_allowed"],
            plan_id=r["plan_id"],
        )
    print(f"   Created/merged {len(rules)} CoverageRule nodes.")


# ── Relationship creation ────────────────────────────────────────────────────

def create_relationships(session, patients, providers, plans, diagnoses,
                         procedures, medications, claims, pa_requests, rules):
    print("\n[R] Creating relationships...")

    # Build quick-lookup maps
    plan_map  = {p["id"]: p for p in plans}
    diag_map  = {d["code"]: d for d in diagnoses}
    proc_map  = {p["code"]: p for p in procedures}
    med_map   = {m["name"]: m for m in medications}

    # ── Patient → InsurancePlan ──────────────────────────────────────────────
    print("   (Patient)-[:COVERED_BY]->(InsurancePlan)")
    for patient in patients:
        if patient.get("plan_id"):
            session.run(
                """
                MATCH (pt:Patient {id: $pid}),
                      (ip:InsurancePlan {id: $plan_id})
                MERGE (pt)-[:COVERED_BY]->(ip)
                """,
                pid=patient["id"], plan_id=patient["plan_id"],
            )

    # ── Patient → Diagnosis ──────────────────────────────────────────────────
    print("   (Patient)-[:HAS_DIAGNOSIS]->(Diagnosis)")
    diagnosed_dates = {
        "P001": {"E11.9": "2018-03-10", "E11.65": "2022-08-15"},
        "P002": {"C50.912": "2024-01-28"},
        "P003": {"M17.11": "2020-05-20"},
        "P004": {"M05.79": "2023-08-01"},
        "P005": {"I10": "2015-11-12", "N18.3": "2021-06-30"},
        "P006": {"J44.1": "2017-09-05"},
        "P007": {"K50.90": "2022-04-17"},
        "P008": {"I48.91": "2018-07-22"},
    }
    for patient in patients:
        for dx_code in patient.get("diagnoses", []):
            dx_date = diagnosed_dates.get(patient["id"], {}).get(dx_code, "2020-01-01")
            session.run(
                """
                MATCH (pt:Patient {id: $pid}),
                      (dx:Diagnosis {code: $code})
                MERGE (pt)-[r:HAS_DIAGNOSIS]->(dx)
                SET r.diagnosed_date = $dx_date
                """,
                pid=patient["id"], code=dx_code, dx_date=dx_date,
            )

    # ── Provider → InsurancePlan (in-network) ────────────────────────────────
    print("   (Provider)-[:IN_NETWORK_FOR]->(InsurancePlan)")
    for provider in providers:
        for plan_id in provider.get("in_network_plans", []):
            session.run(
                """
                MATCH (pv:Provider {id: $pvid}),
                      (ip:InsurancePlan {id: $plan_id})
                MERGE (pv)-[:IN_NETWORK_FOR]->(ip)
                """,
                pvid=provider["id"], plan_id=plan_id,
            )

    # ── Provider → Patient (treats) ──────────────────────────────────────────
    print("   (Provider)-[:TREATS]->(Patient)")
    # Primary providers
    for patient in patients:
        if patient.get("primary_provider_id"):
            session.run(
                """
                MATCH (pv:Provider {id: $pvid}),
                      (pt:Patient {id: $pid})
                MERGE (pv)-[:TREATS]->(pt)
                """,
                pvid=patient["primary_provider_id"], pid=patient["id"],
            )
    # Specialist treating relationships derived from claims and PA
    specialist_treats = [
        ("DR002", "P001"),  # Endocrinologist sees P001
        ("DR003", "P002"),  # Oncologist sees P002
        ("DR004", "P003"),  # Orthopedic sees P003
        ("DR005", "P004"),  # Rheumatologist sees P004
        ("DR006", "P006"),  # Pulmonologist sees P006
        ("DR007", "P007"),  # GI sees P007
        ("DR008", "P008"),  # Cardiologist sees P008
    ]
    for pvid, pid in specialist_treats:
        session.run(
            """
            MATCH (pv:Provider {id: $pvid}),
                  (pt:Patient {id: $pid})
            MERGE (pv)-[:TREATS]->(pt)
            """,
            pvid=pvid, pid=pid,
        )

    # ── Claim → Patient ──────────────────────────────────────────────────────
    print("   (Claim)-[:FOR_PATIENT]->(Patient)")
    for claim in claims:
        session.run(
            """
            MATCH (c:Claim {id: $cid}),
                  (pt:Patient {id: $pid})
            MERGE (c)-[:FOR_PATIENT]->(pt)
            """,
            cid=claim["id"], pid=claim["patient_id"],
        )

    # ── Claim → Provider ─────────────────────────────────────────────────────
    print("   (Claim)-[:SUBMITTED_BY]->(Provider)")
    for claim in claims:
        session.run(
            """
            MATCH (c:Claim {id: $cid}),
                  (pv:Provider {id: $pvid})
            MERGE (c)-[:SUBMITTED_BY]->(pv)
            """,
            cid=claim["id"], pvid=claim["provider_id"],
        )

    # ── Claim → Procedure OR Medication ─────────────────────────────────────
    print("   (Claim)-[:FOR_PROCEDURE | FOR_MEDICATION]->(...)")
    for claim in claims:
        if claim["item_type"] == "procedure" and claim.get("procedure_code"):
            session.run(
                """
                MATCH (c:Claim {id: $cid}),
                      (pr:Procedure {code: $code})
                MERGE (c)-[:FOR_PROCEDURE]->(pr)
                """,
                cid=claim["id"], code=claim["procedure_code"],
            )
        elif claim["item_type"] == "medication":
            session.run(
                """
                MATCH (c:Claim {id: $cid}),
                      (m:Medication {name: $name})
                MERGE (c)-[:FOR_MEDICATION]->(m)
                """,
                cid=claim["id"], name=claim["item_name"],
            )

    # ── PriorAuthRequest → Patient ───────────────────────────────────────────
    print("   (PriorAuthRequest)-[:FOR_PATIENT]->(Patient)")
    for pa in pa_requests:
        session.run(
            """
            MATCH (par:PriorAuthRequest {id: $paid}),
                  (pt:Patient {id: $pid})
            MERGE (par)-[:FOR_PATIENT]->(pt)
            """,
            paid=pa["id"], pid=pa["patient_id"],
        )

    # ── PriorAuthRequest → Provider ──────────────────────────────────────────
    print("   (PriorAuthRequest)-[:SUBMITTED_BY]->(Provider)")
    for pa in pa_requests:
        session.run(
            """
            MATCH (par:PriorAuthRequest {id: $paid}),
                  (pv:Provider {id: $pvid})
            MERGE (par)-[:SUBMITTED_BY]->(pv)
            """,
            paid=pa["id"], pvid=pa["provider_id"],
        )

    # ── PriorAuthRequest → InsurancePlan ─────────────────────────────────────
    print("   (PriorAuthRequest)-[:UNDER_PLAN]->(InsurancePlan)")
    for pa in pa_requests:
        session.run(
            """
            MATCH (par:PriorAuthRequest {id: $paid}),
                  (ip:InsurancePlan {id: $plan_id})
            MERGE (par)-[:UNDER_PLAN]->(ip)
            """,
            paid=pa["id"], plan_id=pa["plan_id"],
        )

    # ── PriorAuthRequest → Procedure OR Medication ───────────────────────────
    print("   (PriorAuthRequest)-[:REQUESTS_PROCEDURE | REQUESTS_MEDICATION]->(...)")
    for pa in pa_requests:
        if pa["item_type"] == "procedure":
            session.run(
                """
                MATCH (par:PriorAuthRequest {id: $paid}),
                      (pr:Procedure {code: $code})
                MERGE (par)-[:REQUESTS_PROCEDURE]->(pr)
                """,
                paid=pa["id"], code=pa["item_code"],
            )
        elif pa["item_type"] == "medication":
            session.run(
                """
                MATCH (par:PriorAuthRequest {id: $paid}),
                      (m:Medication {name: $name})
                MERGE (par)-[:REQUESTS_MEDICATION]->(m)
                """,
                paid=pa["id"], name=pa["item_code"],
            )

    # ── CoverageRule → Medication OR Procedure ───────────────────────────────
    print("   (CoverageRule)-[:GOVERNS]->(Medication | Procedure)")
    for rule in rules:
        if rule["applies_to_type"] == "medication":
            session.run(
                """
                MATCH (cr:CoverageRule {id: $rid}),
                      (m:Medication {name: $name})
                MERGE (cr)-[:GOVERNS]->(m)
                """,
                rid=rule["id"], name=rule["applies_to_code"],
            )
        elif rule["applies_to_type"] == "procedure":
            session.run(
                """
                MATCH (cr:CoverageRule {id: $rid}),
                      (pr:Procedure {code: $code})
                MERGE (cr)-[:GOVERNS]->(pr)
                """,
                rid=rule["id"], code=rule["applies_to_code"],
            )

    # ── CoverageRule → InsurancePlan ─────────────────────────────────────────
    print("   (CoverageRule)-[:BELONGS_TO_PLAN]->(InsurancePlan)")
    for rule in rules:
        session.run(
            """
            MATCH (cr:CoverageRule {id: $rid}),
                  (ip:InsurancePlan {id: $plan_id})
            MERGE (cr)-[:BELONGS_TO_PLAN]->(ip)
            """,
            rid=rule["id"], plan_id=rule["plan_id"],
        )

    # ── Diagnosis → Procedure (treated_by) ──────────────────────────────────
    print("   (Diagnosis)-[:TREATED_BY]->(Procedure)")
    diag_proc_links = [
        ("M17.11",  "27447"),   # Knee OA → Knee Replacement
        ("M17.11",  "97110"),   # Knee OA → PT
        ("C50.912", "96413"),   # Breast Cancer → Chemo
        ("C50.912", "70553"),   # Breast Cancer → MRI
        ("K50.90",  "45378"),   # Crohn's → Colonoscopy
        ("K50.90",  "43239"),   # Crohn's → EGD
        ("I48.91",  "93000"),   # AFib → ECG
        ("E11.9",   "99214"),   # Diabetes → Office Visit
        ("I10",     "93000"),   # HTN → ECG
    ]
    for dx_code, proc_code in diag_proc_links:
        session.run(
            """
            MATCH (dx:Diagnosis {code: $dx_code}),
                  (pr:Procedure {code: $proc_code})
            MERGE (dx)-[:TREATED_BY]->(pr)
            """,
            dx_code=dx_code, proc_code=proc_code,
        )

    # ── Diagnosis → Medication (treated_with) ───────────────────────────────
    print("   (Diagnosis)-[:TREATED_WITH]->(Medication)")
    diag_med_links = [
        ("E11.9",   "Metformin"),
        ("E11.9",   "Ozempic"),
        ("E11.65",  "Metformin"),
        ("E11.65",  "Ozempic"),
        ("C50.912", "Keytruda"),
        ("M05.79",  "Methotrexate"),
        ("M05.79",  "Humira"),
        ("K50.90",  "Humira"),
        ("K50.90",  "Stelara"),
        ("K50.90",  "Methotrexate"),
        ("J44.1",   "Spiriva"),
        ("J44.1",   "Dupixent"),
        ("I48.91",  "Eliquis"),
        ("I48.91",  "Xarelto"),
    ]
    for dx_code, med_name in diag_med_links:
        session.run(
            """
            MATCH (dx:Diagnosis {code: $dx_code}),
                  (m:Medication {name: $med_name})
            MERGE (dx)-[:TREATED_WITH]->(m)
            """,
            dx_code=dx_code, med_name=med_name,
        )

    # ── Step Therapy chains ──────────────────────────────────────────────────
    print("   (Medication)-[:STEP_THERAPY_BEFORE]->(Medication)")
    step_therapy_chains = [
        ("Metformin",    "Ozempic"),    # Metformin must precede Ozempic
        ("Methotrexate", "Humira"),     # MTX must precede Humira (RA)
        ("Humira",       "Stelara"),    # Humira must precede Stelara (Crohn's)
        ("Eliquis",      "Xarelto"),    # Eliquis preferred, Xarelto is step-up
    ]
    for prereq, target in step_therapy_chains:
        session.run(
            """
            MATCH (m1:Medication {name: $prereq}),
                  (m2:Medication {name: $target})
            MERGE (m1)-[:STEP_THERAPY_BEFORE]->(m2)
            """,
            prereq=prereq, target=target,
        )

    print("   All relationships created.")


# ── Reporting ─────────────────────────────────────────────────────────────────

def print_summary(session):
    print("\n" + "=" * 60)
    print("  KNOWLEDGE GRAPH POPULATION SUMMARY")
    print("=" * 60)

    node_types = [
        "Patient", "Provider", "InsurancePlan", "Diagnosis",
        "Procedure", "Medication", "Claim", "PriorAuthRequest", "CoverageRule"
    ]
    total_nodes = 0
    for label in node_types:
        result = session.run(f"MATCH (n:{label}) RETURN count(n) AS cnt")
        cnt = result.single()["cnt"]
        total_nodes += cnt
        print(f"  {label:<22} {cnt:>4} nodes")

    print(f"\n  {'TOTAL NODES':<22} {total_nodes:>4}")

    rel_result = session.run("MATCH ()-[r]->() RETURN count(r) AS cnt")
    total_rels = rel_result.single()["cnt"]
    print(f"  {'TOTAL RELATIONSHIPS':<22} {total_rels:>4}")

    print("\n  Relationship types:")
    rel_type_result = session.run(
        "MATCH ()-[r]->() RETURN type(r) AS rel_type, count(r) AS cnt "
        "ORDER BY cnt DESC"
    )
    for record in rel_type_result:
        print(f"    {record['rel_type']:<32} {record['cnt']:>3}")

    print("=" * 60)
    print("  Graph is ready for querying!")
    print("=" * 60)


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    print("=" * 60)
    print("  Healthcare Prior Auth KG - Population Script")
    print("=" * 60)
    print(f"\n  Connecting to Neo4j at: {NEO4J_URI}")

    try:
        driver = GraphDatabase.driver(
            NEO4J_URI,
            auth=(NEO4J_USERNAME, NEO4J_PASSWORD)
        )
        driver.verify_connectivity()
        print("  Connected successfully!\n")
    except Exception as e:
        print(f"\n  ERROR: Could not connect to Neo4j.")
        print(f"  Details: {e}")
        print("\n  Please check:")
        print("  1. Neo4j is running (local) or your Aura URI is correct")
        print("  2. .env file has correct NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD")
        return

    # Load all data files
    print("  Loading data files from ./data/ ...")
    patients    = load_json("patients.json")
    providers   = load_json("providers.json")
    plans       = load_json("insurance_plans.json")
    diagnoses   = load_json("diagnoses.json")
    procedures  = load_json("procedures.json")
    medications = load_json("medications.json")
    claims      = load_json("claims.json")
    pa_requests = load_json("prior_auth_requests.json")
    rules       = load_json("coverage_rules.json")
    print(f"  Loaded: {len(patients)} patients, {len(providers)} providers, "
          f"{len(plans)} plans, {len(diagnoses)} diagnoses")
    print(f"          {len(procedures)} procedures, {len(medications)} medications, "
          f"{len(claims)} claims, {len(pa_requests)} PA requests, "
          f"{len(rules)} coverage rules")

    with driver.session() as session:
        # Uncomment to wipe and restart:
        # clear_database(session)

        create_constraints(session)
        create_patients(session, patients)
        create_providers(session, providers)
        create_insurance_plans(session, plans)
        create_diagnoses(session, diagnoses)
        create_procedures(session, procedures)
        create_medications(session, medications)
        create_claims(session, claims)
        create_prior_auth_requests(session, pa_requests)
        create_coverage_rules(session, rules)

        create_relationships(
            session, patients, providers, plans, diagnoses,
            procedures, medications, claims, pa_requests, rules
        )

        print_summary(session)

    driver.close()
    print("\n  Done! Graph database populated successfully.")


if __name__ == "__main__":
    main()
