"""
Health Insurance Claim Filing Demo using CrewAI
================================================
Multi-agent pipeline with Pydantic validation, synthetic data, and human-in-the-loop review.

Agents:
  1. Input Agent          - validates patient ID
  2. Patient Details      - fetches demographics + policy info
  3. Treatment Details    - gathers bills and line items
  4. Policy Review        - matches bills vs policy, produces JSON
  5. Claim Form Generator - builds claim form with exclusion notes
  6. HITL Review          - emails claim form for human approval (mock)
  7. Submission Agent     - submits approved claim
"""

import os
import sys
import json
import datetime
from typing import List, Optional
from pydantic import BaseModel
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
from crewai.tools import tool

# ── encoding fix (Windows) ──────────────────────────────────────────────────
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if sys.stderr.encoding and sys.stderr.encoding.lower() != "utf-8":
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

load_dotenv()

# ── LLM via AWS Bedrock ──────────────────────────────────────────────────────
llm = LLM(
    model=f"bedrock/{os.getenv('BEDROCK_MODEL_ID', 'us.anthropic.claude-3-7-sonnet-20250219-v1:0')}",
    max_tokens=2000,
    temperature=0.3,
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    aws_region_name=os.getenv("AWS_REGION", "us-east-1"),
)

# ═══════════════════════════════════════════════════════════════════════════════
# SYNTHETIC DATA
# ═══════════════════════════════════════════════════════════════════════════════

PATIENT_DB = {
    "P001": {
        "patient_id": "P001",
        "name": "John Carter",
        "dob": "1978-04-15",
        "gender": "Male",
        "address": "123 Maple St, Austin, TX 78701",
        "phone": "512-555-0101",
        "email": "john.carter@email.com",
        "policy_id": "POL-BC-001",
    },
    "P002": {
        "patient_id": "P002",
        "name": "Sarah Mitchell",
        "dob": "1990-09-22",
        "gender": "Female",
        "address": "456 Oak Ave, Dallas, TX 75201",
        "phone": "214-555-0202",
        "email": "sarah.mitchell@email.com",
        "policy_id": "POL-AE-002",
    },
}

INSURANCE_POLICY_DB = {
    "POL-BC-001": {
        "policy_id": "POL-BC-001",
        "insurer": "BlueCross BlueShield",
        "plan_name": "Gold PPO",
        "holder": "John Carter",
        "group_number": "GRP-4521",
        "effective_date": "2024-01-01",
        "expiry_date": "2024-12-31",
        "deductible": 1500.00,
        "deductible_met": 1500.00,
        "out_of_pocket_max": 5000.00,
        "coverage": {
            "inpatient_surgery": {"covered": True, "limit_per_event": 20000.00, "coinsurance_pct": 80},
            "hospitalization": {"covered": True, "limit_per_day": 600.00, "max_days": 10, "coinsurance_pct": 80},
            "prescription_drugs": {"covered": True, "annual_limit": 1000.00, "coinsurance_pct": 80},
            "diagnostic_imaging": {"covered": True, "limit_per_event": 2000.00, "coinsurance_pct": 80},
            "physical_therapy": {"covered": True, "max_visits": 20, "cost_per_visit": 50.00},
            "cosmetic_procedures": {"covered": False, "reason": "Cosmetic procedures are excluded per plan terms"},
            "experimental_treatments": {"covered": False, "reason": "Experimental treatments require prior authorization"},
        },
    },
    "POL-AE-002": {
        "policy_id": "POL-AE-002",
        "insurer": "Aetna Health",
        "plan_name": "Silver HMO",
        "holder": "Sarah Mitchell",
        "group_number": "GRP-8832",
        "effective_date": "2024-03-01",
        "expiry_date": "2025-02-28",
        "deductible": 3000.00,
        "deductible_met": 800.00,
        "out_of_pocket_max": 7500.00,
        "coverage": {
            "inpatient_surgery": {"covered": True, "limit_per_event": 15000.00, "coinsurance_pct": 70},
            "hospitalization": {"covered": True, "limit_per_day": 500.00, "max_days": 7, "coinsurance_pct": 70},
            "prescription_drugs": {"covered": True, "annual_limit": 800.00, "coinsurance_pct": 70},
            "diagnostic_imaging": {"covered": True, "limit_per_event": 1500.00, "coinsurance_pct": 70},
            "physical_therapy": {"covered": False, "reason": "Physical therapy not covered under Silver HMO"},
            "cosmetic_procedures": {"covered": False, "reason": "Cosmetic procedures excluded from all plans"},
            "experimental_treatments": {"covered": False, "reason": "Experimental treatments excluded"},
        },
    },
}

TREATMENT_RECORDS_DB = {
    "P001": {
        "patient_id": "P001",
        "admission_date": "2024-11-10",
        "discharge_date": "2024-11-13",
        "hospital": "St. David's Medical Center, Austin TX",
        "attending_physician": "Dr. Emily Nguyen, MD (Orthopedic Surgeon)",
        "primary_diagnosis": "Severe osteoarthritis, right knee (M17.11)",
        "procedure": "Total right knee replacement arthroplasty",
        "line_items": [
            {"item_id": "LI-001", "category": "inpatient_surgery", "description": "Total knee replacement surgery (CPT 27447)", "amount": 22000.00, "date": "2024-11-10"},
            {"item_id": "LI-002", "category": "hospitalization",   "description": "Hospital room & board – 3 days @ $650/day",  "amount": 1950.00,  "date": "2024-11-10"},
            {"item_id": "LI-003", "category": "diagnostic_imaging","description": "Pre-op MRI right knee (CPT 27370)",            "amount": 1800.00,  "date": "2024-11-08"},
            {"item_id": "LI-004", "category": "prescription_drugs","description": "Post-op pain medications (Oxycodone, Naproxen)","amount": 380.00,  "date": "2024-11-13"},
            {"item_id": "LI-005", "category": "physical_therapy",  "description": "Inpatient PT sessions – 4 sessions @ $80",    "amount": 320.00,   "date": "2024-11-11"},
            {"item_id": "LI-006", "category": "cosmetic_procedures","description": "Scar revision treatment post-surgery",        "amount": 950.00,   "date": "2024-11-13"},
            {"item_id": "LI-007", "category": "experimental_treatments","description": "PRP injection therapy (experimental)",   "amount": 1200.00,  "date": "2024-11-12"},
        ],
    },
    "P002": {
        "patient_id": "P002",
        "admission_date": "2024-10-05",
        "discharge_date": "2024-10-07",
        "hospital": "Baylor University Medical Center, Dallas TX",
        "attending_physician": "Dr. Marcus Reynolds, MD (General Surgeon)",
        "primary_diagnosis": "Acute appendicitis (K37)",
        "procedure": "Laparoscopic appendectomy",
        "line_items": [
            {"item_id": "LI-001", "category": "inpatient_surgery", "description": "Laparoscopic appendectomy (CPT 44950)",         "amount": 9500.00,  "date": "2024-10-05"},
            {"item_id": "LI-002", "category": "hospitalization",   "description": "Hospital room & board – 2 days @ $550/day",  "amount": 1100.00,  "date": "2024-10-05"},
            {"item_id": "LI-003", "category": "diagnostic_imaging","description": "Abdominal CT scan (CPT 74177)",                "amount": 1400.00,  "date": "2024-10-05"},
            {"item_id": "LI-004", "category": "prescription_drugs","description": "Antibiotics and pain management (IV + oral)",  "amount": 290.00,   "date": "2024-10-06"},
            {"item_id": "LI-005", "category": "physical_therapy",  "description": "Post-op mobility PT sessions – 3 sessions",   "amount": 240.00,   "date": "2024-10-07"},
        ],
    },
}

# ═══════════════════════════════════════════════════════════════════════════════
# PYDANTIC SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════

class PatientDemographics(BaseModel):
    patient_id: str
    name: str
    dob: str
    gender: str
    address: str
    phone: str
    email: str
    policy_id: str

class CoverageDetail(BaseModel):
    covered: bool
    limit_per_event: Optional[float] = None
    limit_per_day: Optional[float] = None
    max_days: Optional[int] = None
    max_visits: Optional[int] = None
    cost_per_visit: Optional[float] = None
    annual_limit: Optional[float] = None
    coinsurance_pct: Optional[int] = None
    reason: Optional[str] = None

class InsurancePolicy(BaseModel):
    policy_id: str
    insurer: str
    plan_name: str
    holder: str
    group_number: str
    effective_date: str
    expiry_date: str
    deductible: float
    deductible_met: float
    out_of_pocket_max: float
    coverage: dict

class TreatmentLineItem(BaseModel):
    item_id: str
    category: str
    description: str
    amount: float
    date: str

class TreatmentDetails(BaseModel):
    patient_id: str
    admission_date: str
    discharge_date: str
    hospital: str
    attending_physician: str
    primary_diagnosis: str
    procedure: str
    line_items: List[TreatmentLineItem]
    total_billed: float = 0.0

    def model_post_init(self, __context):  # noqa: ANN001
        self.total_billed = sum(item.amount for item in self.line_items)

class ReviewedLineItem(BaseModel):
    item_id: str
    category: str
    description: str
    billed_amount: float
    covered: bool
    approved_amount: float
    exclusion_reason: Optional[str] = None
    notes: Optional[str] = None

class PolicyReviewResult(BaseModel):
    patient_id: str
    policy_id: str
    review_date: str
    total_billed: float
    total_approved: float
    total_excluded: float
    deductible_remaining: float
    estimated_insurer_payment: float
    estimated_patient_responsibility: float
    reviewed_items: List[ReviewedLineItem]

class ClaimForm(BaseModel):
    claim_id: str
    submission_date: str
    patient_name: str
    patient_id: str
    policy_id: str
    insurer: str
    hospital: str
    admission_date: str
    discharge_date: str
    primary_diagnosis: str
    procedure: str
    total_billed: float
    total_claimed: float
    approved_items: List[ReviewedLineItem]
    excluded_items: List[ReviewedLineItem]
    exclusion_summary: str
    estimated_payment: float
    status: str = "PENDING_REVIEW"

class ClaimSubmissionResult(BaseModel):
    claim_id: str
    confirmation_number: str
    submitted_at: str
    status: str
    expected_processing_days: int
    insurer_contact: str

# ═══════════════════════════════════════════════════════════════════════════════
# SHARED STATE  (passed between tasks via crew memory / task context)
# ═══════════════════════════════════════════════════════════════════════════════
_state: dict = {}


def _resolve_pid(patient_id: Optional[str]) -> str:
    """Return the patient ID: use the argument if provided, otherwise fall back to _state."""
    if patient_id and patient_id.strip():
        return patient_id.strip().upper()
    stored = _state.get("patient_id", "")
    if stored:
        return stored
    raise ValueError("patient_id is required but was not provided and is not in state.")


# ═══════════════════════════════════════════════════════════════════════════════
# TOOLS
# ═══════════════════════════════════════════════════════════════════════════════

@tool("validate_patient_id")
def validate_patient_id(patient_id: Optional[str] = None) -> str:
    """Validate that a patient ID exists in the system and return basic confirmation."""
    pid = _resolve_pid(patient_id)
    if pid in PATIENT_DB:
        _state["patient_id"] = pid
        return json.dumps({"valid": True, "patient_id": pid,
                           "message": f"Patient ID {pid} validated successfully."})
    return json.dumps({"valid": False, "patient_id": pid,
                       "message": f"Patient ID {pid} not found. Available IDs: {list(PATIENT_DB.keys())}"})


@tool("fetch_patient_details")
def fetch_patient_details(patient_id: Optional[str] = None) -> str:
    """Fetch patient demographic information and their insurance policy details."""
    pid = _resolve_pid(patient_id)
    patient_raw = PATIENT_DB.get(pid)
    if not patient_raw:
        return json.dumps({"error": f"Patient {pid} not found."})

    demographics = PatientDemographics(**patient_raw)
    policy_raw = INSURANCE_POLICY_DB.get(demographics.policy_id)
    if not policy_raw:
        return json.dumps({"error": f"Policy {demographics.policy_id} not found."})

    policy = InsurancePolicy(**policy_raw)
    _state["demographics"] = demographics.model_dump()
    _state["policy"] = policy.model_dump()

    return json.dumps({
        "demographics": demographics.model_dump(),
        "policy": policy.model_dump(),
    }, indent=2)


@tool("fetch_treatment_details")
def fetch_treatment_details(patient_id: Optional[str] = None) -> str:
    """Fetch all treatment records, bills, and line items for a patient."""
    pid = _resolve_pid(patient_id)
    record = TREATMENT_RECORDS_DB.get(pid)
    if not record:
        return json.dumps({"error": f"No treatment records found for patient {pid}."})

    line_items = [TreatmentLineItem(**li) for li in record["line_items"]]
    treatment = TreatmentDetails(
        patient_id=record["patient_id"],
        admission_date=record["admission_date"],
        discharge_date=record["discharge_date"],
        hospital=record["hospital"],
        attending_physician=record["attending_physician"],
        primary_diagnosis=record["primary_diagnosis"],
        procedure=record["procedure"],
        line_items=line_items,
    )
    _state["treatment"] = treatment.model_dump()
    return treatment.model_dump_json(indent=2)


@tool("review_policy_coverage")
def review_policy_coverage(patient_id: Optional[str] = None) -> str:
    """
    Match each treatment line item against the patient's insurance policy.
    Returns a JSON PolicyReviewResult with approved/excluded items and estimated payments.
    """
    pid = _resolve_pid(patient_id)
    treatment_data = _state.get("treatment")
    policy_data    = _state.get("policy")

    if not treatment_data or not policy_data:
        return json.dumps({"error": "Patient details or treatment records not loaded. Run earlier steps first."})

    policy   = InsurancePolicy(**policy_data)
    treatment = TreatmentDetails(**treatment_data)

    deductible_remaining = max(0.0, policy.deductible - policy.deductible_met)
    reviewed_items: List[ReviewedLineItem] = []
    total_approved = 0.0

    for item in treatment.line_items:
        cov = policy.coverage.get(item.category)

        # --- NOT IN POLICY at all ---
        if cov is None:
            reviewed_items.append(ReviewedLineItem(
                item_id=item.item_id, category=item.category,
                description=item.description, billed_amount=item.amount,
                covered=False, approved_amount=0.0,
                exclusion_reason="Category not recognized in policy.",
            ))
            continue

        # --- EXPLICITLY NOT COVERED ---
        if not cov.get("covered", False):
            reviewed_items.append(ReviewedLineItem(
                item_id=item.item_id, category=item.category,
                description=item.description, billed_amount=item.amount,
                covered=False, approved_amount=0.0,
                exclusion_reason=cov.get("reason", "Not covered under policy."),
            ))
            continue

        # --- COVERED – calculate approved amount ---
        coinsurance = cov.get("coinsurance_pct", 100) / 100.0
        approved = item.amount

        if item.category == "inpatient_surgery":
            limit = cov.get("limit_per_event", float("inf"))
            if approved > limit:
                notes = f"Billed ${item.amount:,.2f} exceeds surgery limit of ${limit:,.2f}; capped at limit."
                approved = limit
            else:
                notes = None
            approved_after_coin = approved * coinsurance
            reviewed_items.append(ReviewedLineItem(
                item_id=item.item_id, category=item.category,
                description=item.description, billed_amount=item.amount,
                covered=True, approved_amount=round(approved_after_coin, 2),
                notes=notes or f"{int(cov['coinsurance_pct'])}% coinsurance applied.",
            ))
            total_approved += approved_after_coin

        elif item.category == "hospitalization":
            limit_day = cov.get("limit_per_day", float("inf"))
            max_days  = cov.get("max_days", 999)
            # parse days from discharge - admission
            try:
                admit = datetime.date.fromisoformat(treatment.admission_date)
                disch = datetime.date.fromisoformat(treatment.discharge_date)
                days  = max(1, (disch - admit).days)
            except Exception:
                days = 1
            days = min(days, max_days)
            capped = min(item.amount, limit_day * days)
            approved_after_coin = capped * coinsurance
            reviewed_items.append(ReviewedLineItem(
                item_id=item.item_id, category=item.category,
                description=item.description, billed_amount=item.amount,
                covered=True, approved_amount=round(approved_after_coin, 2),
                notes=f"{days} days × ${limit_day}/day limit, {int(cov['coinsurance_pct'])}% coinsurance.",
            ))
            total_approved += approved_after_coin

        elif item.category == "prescription_drugs":
            annual_limit = cov.get("annual_limit", float("inf"))
            capped = min(item.amount, annual_limit)
            approved_after_coin = capped * coinsurance
            reviewed_items.append(ReviewedLineItem(
                item_id=item.item_id, category=item.category,
                description=item.description, billed_amount=item.amount,
                covered=True, approved_amount=round(approved_after_coin, 2),
                notes=f"Annual Rx limit ${annual_limit}, {int(cov['coinsurance_pct'])}% coinsurance.",
            ))
            total_approved += approved_after_coin

        elif item.category == "diagnostic_imaging":
            limit = cov.get("limit_per_event", float("inf"))
            capped = min(item.amount, limit)
            approved_after_coin = capped * coinsurance
            reviewed_items.append(ReviewedLineItem(
                item_id=item.item_id, category=item.category,
                description=item.description, billed_amount=item.amount,
                covered=True, approved_amount=round(approved_after_coin, 2),
                notes=f"Per-event limit ${limit}, {int(cov['coinsurance_pct'])}% coinsurance.",
            ))
            total_approved += approved_after_coin

        elif item.category == "physical_therapy":
            cost_per_visit = cov.get("cost_per_visit", item.amount)
            max_visits     = cov.get("max_visits", 999)
            # estimate visits from amount / cost_per_visit
            visits = min(round(item.amount / cost_per_visit) if cost_per_visit else 1, max_visits)
            approved_amt = visits * cost_per_visit
            reviewed_items.append(ReviewedLineItem(
                item_id=item.item_id, category=item.category,
                description=item.description, billed_amount=item.amount,
                covered=True, approved_amount=round(approved_amt, 2),
                notes=f"Covered up to {max_visits} visits at ${cost_per_visit}/visit.",
            ))
            total_approved += approved_amt

        else:
            # generic covered category
            approved_after_coin = approved * coinsurance
            reviewed_items.append(ReviewedLineItem(
                item_id=item.item_id, category=item.category,
                description=item.description, billed_amount=item.amount,
                covered=True, approved_amount=round(approved_after_coin, 2),
            ))
            total_approved += approved_after_coin

    total_excluded = sum(i.billed_amount for i in reviewed_items if not i.covered)
    insurer_payment = max(0.0, total_approved - deductible_remaining)
    patient_resp    = treatment.total_billed - insurer_payment

    review = PolicyReviewResult(
        patient_id=pid,
        policy_id=policy.policy_id,
        review_date=datetime.date.today().isoformat(),
        total_billed=treatment.total_billed,
        total_approved=round(total_approved, 2),
        total_excluded=round(total_excluded, 2),
        deductible_remaining=round(deductible_remaining, 2),
        estimated_insurer_payment=round(insurer_payment, 2),
        estimated_patient_responsibility=round(patient_resp, 2),
        reviewed_items=reviewed_items,
    )
    _state["review"] = review.model_dump()
    return review.model_dump_json(indent=2)


@tool("generate_claim_form")
def generate_claim_form(patient_id: Optional[str] = None) -> str:
    """Generate a structured insurance claim form from the policy review results."""
    pid = _resolve_pid(patient_id)
    review_data  = _state.get("review")
    treatment_data = _state.get("treatment")
    demographics_data = _state.get("demographics")
    policy_data = _state.get("policy")

    if not all([review_data, treatment_data, demographics_data, policy_data]):
        return json.dumps({"error": "Required state data missing. Ensure prior agents have run."})

    review     = PolicyReviewResult(**review_data)
    treatment  = TreatmentDetails(**treatment_data)
    demo       = PatientDemographics(**demographics_data)
    policy     = InsurancePolicy(**policy_data)

    approved_items = [i for i in review.reviewed_items if i.covered]
    excluded_items = [i for i in review.reviewed_items if not i.covered]

    # Build exclusion summary
    exclusion_lines = []
    for ex in excluded_items:
        exclusion_lines.append(
            f"- {ex.description} (${ex.billed_amount:,.2f}): {ex.exclusion_reason}"
        )
    exclusion_summary = (
        "The following items were excluded from this claim:\n" + "\n".join(exclusion_lines)
        if exclusion_lines else "No items were excluded from this claim."
    )

    claim_id = f"CLM-{pid}-{datetime.date.today().strftime('%Y%m%d')}"
    claim = ClaimForm(
        claim_id=claim_id,
        submission_date=datetime.date.today().isoformat(),
        patient_name=demo.name,
        patient_id=pid,
        policy_id=policy.policy_id,
        insurer=policy.insurer,
        hospital=treatment.hospital,
        admission_date=treatment.admission_date,
        discharge_date=treatment.discharge_date,
        primary_diagnosis=treatment.primary_diagnosis,
        procedure=treatment.procedure,
        total_billed=treatment.total_billed,
        total_claimed=review.total_approved,
        approved_items=approved_items,
        excluded_items=excluded_items,
        exclusion_summary=exclusion_summary,
        estimated_payment=review.estimated_insurer_payment,
        status="PENDING_REVIEW",
    )
    _state["claim"] = claim.model_dump()
    return claim.model_dump_json(indent=2)


@tool("human_review_claim")
def human_review_claim(_: Optional[str] = None) -> str:
    """
    Present the claim summary to a human reviewer in the terminal and capture
    their decision: 1 (Approved) or 2 (Not Approved).
    """
    claim_data = _state.get("claim")
    if not claim_data:
        return json.dumps({"error": "Claim form not yet generated."})

    claim = ClaimForm(**claim_data)

    summary = f"""
{'='*70}
  HUMAN REVIEW – INSURANCE CLAIM
{'='*70}
  Claim ID    : {claim.claim_id}
  Patient     : {claim.patient_name} ({claim.patient_id})
  Insurer     : {claim.insurer}  |  Policy: {claim.policy_id}
  Hospital    : {claim.hospital}
  Admission   : {claim.admission_date}  ->  Discharge: {claim.discharge_date}
  Diagnosis   : {claim.primary_diagnosis}
  Procedure   : {claim.procedure}

  FINANCIALS
  ----------
  Total Billed     : ${claim.total_billed:>12,.2f}
  Total Claimed    : ${claim.total_claimed:>12,.2f}
  Est. Payment     : ${claim.estimated_payment:>12,.2f}

  APPROVED ITEMS ({len(claim.approved_items)})
  ---------------"""
    for item in claim.approved_items:
        summary += f"\n  [{item.item_id}] {item.description[:55]:<55} ${item.approved_amount:>9,.2f}"

    if claim.excluded_items:
        summary += f"\n\n  EXCLUDED ITEMS ({len(claim.excluded_items)})\n  ----------------"
        for item in claim.excluded_items:
            summary += f"\n  [{item.item_id}] {item.description[:55]:<55} EXCLUDED"
            summary += f"\n         Reason: {item.exclusion_reason}"

    summary += f"\n\n  EXCLUSION NOTE\n  {'-'*40}\n  {claim.exclusion_summary}"
    summary += f"\n{'='*70}"
    print(summary)

    print("\n  HUMAN-IN-THE-LOOP DECISION")
    print("  1. Approved")
    print("  2. Not Approved")
    while True:
        choice = input("  Enter your choice [1 or 2]: ").strip()
        if choice in ("1", "2"):
            break
        print("  Invalid input. Please enter 1 or 2.")

    approved = choice == "1"
    _state["hitl_decision"] = {"approved": approved}

    print(f"\n  Decision recorded: {'APPROVED' if approved else 'NOT APPROVED'}")
    return json.dumps({
        "claim_id": claim.claim_id,
        "approved": approved,
        "timestamp": datetime.datetime.now().isoformat(),
    }, indent=2)


@tool("finalize_claim")
def finalize_claim(_: Optional[str] = None) -> str:
    """
    Finalize the claim based on the human reviewer's decision.
    If APPROVED: submit the claim and print the full claim form.
    If NOT APPROVED: print a rejection note with likely cause and item summary.
    """
    import random

    claim_data = _state.get("claim")
    decision   = _state.get("hitl_decision", {})

    if not claim_data:
        return json.dumps({"error": "No claim form found."})

    claim    = ClaimForm(**claim_data)
    approved = decision.get("approved", True)

    if not approved:
        # ── REJECTION PATH ────────────────────────────────────────────────────
        _state["claim"]["status"] = "REJECTED"

        # Determine likely rejection causes from excluded items
        causes = []
        if claim.excluded_items:
            for ex in claim.excluded_items:
                causes.append(f"  - {ex.description}: {ex.exclusion_reason}")

        rejection_note = f"""
{'='*70}
  CLAIM REJECTION NOTICE
{'='*70}
  Claim ID    : {claim.claim_id}
  Patient     : {claim.patient_name} ({claim.patient_id})
  Insurer     : {claim.insurer}
  Status      : NOT APPROVED

  LIKELY CAUSES OF REJECTION
  ---------------------------
{chr(10).join(causes) if causes else '  No specific exclusions found; manual review required.'}

  ITEM SUMMARY
  ------------
  Total Items Billed   : {len(claim.approved_items) + len(claim.excluded_items)}
  Items Approved       : {len(claim.approved_items)}
  Items Excluded       : {len(claim.excluded_items)}
  Total Billed Amount  : ${claim.total_billed:,.2f}
  Total Claimed        : ${claim.total_claimed:,.2f}
  Excluded Amount      : ${claim.total_billed - claim.total_claimed:,.2f}

  NEXT STEPS
  ----------
  The patient may appeal this decision within 60 days by contacting
  {claim.insurer} at 1-800-555-0100 and quoting Claim ID {claim.claim_id}.
{'='*70}
"""
        print(rejection_note)
        return json.dumps({
            "claim_id": claim.claim_id,
            "status": "REJECTED",
            "causes": causes,
        }, indent=2)

    # ── APPROVAL PATH ─────────────────────────────────────────────────────────
    confirm_num = f"CONF-{random.randint(100000, 999999)}"
    _state["claim"]["status"] = "SUBMITTED"

    form = f"""
{'='*70}
  INSURANCE CLAIM FORM – APPROVED & SUBMITTED
{'='*70}
  Claim ID            : {claim.claim_id}
  Confirmation No.    : {confirm_num}
  Submission Date     : {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

  PATIENT INFORMATION
  -------------------
  Name      : {claim.patient_name}
  ID        : {claim.patient_id}
  Insurer   : {claim.insurer}
  Policy    : {claim.policy_id}

  TREATMENT INFORMATION
  ---------------------
  Hospital   : {claim.hospital}
  Admission  : {claim.admission_date}
  Discharge  : {claim.discharge_date}
  Diagnosis  : {claim.primary_diagnosis}
  Procedure  : {claim.procedure}

  APPROVED LINE ITEMS
  -------------------"""
    for item in claim.approved_items:
        form += f"\n  [{item.item_id}] {item.description[:55]:<55} ${item.approved_amount:>10,.2f}"
        if item.notes:
            form += f"\n         Note: {item.notes}"

    if claim.excluded_items:
        form += f"\n\n  EXCLUDED LINE ITEMS (not claimed)\n  ----------------------------------"
        for item in claim.excluded_items:
            form += f"\n  [{item.item_id}] {item.description[:55]:<55} EXCLUDED"
            form += f"\n         Reason: {item.exclusion_reason}"

    form += f"""

  FINANCIAL SUMMARY
  -----------------
  Total Billed         : ${claim.total_billed:>12,.2f}
  Total Claimed        : ${claim.total_claimed:>12,.2f}
  Estimated Payment    : ${claim.estimated_payment:>12,.2f}

  EXCLUSION NOTE
  --------------
  {claim.exclusion_summary}

  Processing time: ~14 business days
  Insurer contact : 1-800-555-0100  (Ref: {confirm_num})
{'='*70}
"""
    print(form)

    result = ClaimSubmissionResult(
        claim_id=claim.claim_id,
        confirmation_number=confirm_num,
        submitted_at=datetime.datetime.now().isoformat(),
        status="SUBMITTED",
        expected_processing_days=14,
        insurer_contact=f"1-800-555-0100 (Ref: {confirm_num})",
    )
    _state["submission"] = result.model_dump()
    return result.model_dump_json(indent=2)


# ═══════════════════════════════════════════════════════════════════════════════
# AGENTS
# ═══════════════════════════════════════════════════════════════════════════════

input_agent = Agent(
    role="Patient Input Validator",
    goal="Validate the patient ID and confirm the patient exists in the system before proceeding.",
    backstory=(
        "You are the front-desk intake specialist for the claims system. "
        "Your job is to ensure that every claim request starts with a valid patient ID. "
        "You use the validate_patient_id tool and report the result clearly."
    ),
    tools=[validate_patient_id],
    verbose=True,
    allow_delegation=False,
    max_iter=3,
    llm=llm,
)

patient_details_agent = Agent(
    role="Patient & Policy Information Specialist",
    goal="Retrieve complete patient demographics and full insurance policy details.",
    backstory=(
        "You are a medical records and insurance data specialist. "
        "You retrieve patient profiles and policy documents, ensuring all data "
        "is accurate before a claim is processed."
    ),
    tools=[fetch_patient_details],
    verbose=True,
    allow_delegation=False,
    max_iter=3,
    llm=llm,
)

treatment_details_agent = Agent(
    role="Medical Billing & Treatment Analyst",
    goal="Gather all treatment records, procedures performed, and itemized bills.",
    backstory=(
        "You are a certified medical coder and billing analyst. "
        "You gather every line item from hospital records – surgery, hospitalization, "
        "diagnostics, pharmaceuticals, and therapy – to build a complete billing picture."
    ),
    tools=[fetch_treatment_details],
    verbose=True,
    allow_delegation=False,
    max_iter=3,
    llm=llm,
)

policy_review_agent = Agent(
    role="Insurance Policy Adjudicator",
    goal=(
        "Review each treatment line item against the patient's insurance policy. "
        "Determine what is covered, apply limits and coinsurance, and produce a "
        "structured JSON review result."
    ),
    backstory=(
        "You are a senior insurance adjudicator with 15 years of experience. "
        "You apply policy rules with precision – coverage limits, coinsurance percentages, "
        "deductibles, and exclusions – to determine what the insurer will pay."
    ),
    tools=[review_policy_coverage],
    verbose=True,
    allow_delegation=False,
    max_iter=3,
    llm=llm,
)

claim_form_agent = Agent(
    role="Claim Form Generator",
    goal=(
        "Generate a complete, well-structured insurance claim form from the policy review. "
        "Include a clear note explaining every excluded item and the reason."
    ),
    backstory=(
        "You are a claims documentation specialist who creates clear, accurate, "
        "and compliant claim forms that are ready for submission and human review."
    ),
    tools=[generate_claim_form],
    verbose=True,
    allow_delegation=False,
    max_iter=3,
    llm=llm,
)

hitl_agent = Agent(
    role="Human-in-the-Loop Review Coordinator",
    goal=(
        "Present the claim summary to a human reviewer in the terminal and "
        "capture their decision (1 = Approved, 2 = Not Approved) before proceeding."
    ),
    backstory=(
        "You coordinate the human review step in the claims workflow. "
        "You present the claim summary on screen, collect the reviewer's decision, "
        "and faithfully record it so the next agent can act on it."
    ),
    tools=[human_review_claim],
    verbose=True,
    allow_delegation=False,
    max_iter=3,
    llm=llm,
)

submission_agent = Agent(
    role="Claims Submission Specialist",
    goal=(
        "Finalize the claim based on the human reviewer's decision. "
        "If approved, submit and print the full claim form with confirmation. "
        "If not approved, print a rejection note with likely causes and an item summary."
    ),
    backstory=(
        "You are the final step in the claims pipeline. You either submit approved claims "
        "and print the official claim form, or issue a clear rejection notice explaining "
        "why the claim was denied and what the patient can do next."
    ),
    tools=[finalize_claim],
    verbose=True,
    allow_delegation=False,
    max_iter=3,
    llm=llm,
)

# ═══════════════════════════════════════════════════════════════════════════════
# TASKS
# ═══════════════════════════════════════════════════════════════════════════════

task_validate_input = Task(
    description=(
        "The patient has provided their ID: {patient_id}.\n"
        "Use the validate_patient_id tool to confirm this patient exists in the system.\n"
        "Report whether the ID is valid or invalid. If invalid, list available patient IDs."
    ),
    agent=input_agent,
    expected_output="A confirmation that patient ID {patient_id} is valid, or an error with available IDs.",
)

task_patient_details = Task(
    description=(
        "Fetch full patient demographics and insurance policy details for patient {patient_id}.\n"
        "Use the fetch_patient_details tool.\n"
        "Summarize: patient name, DOB, insurer, plan name, deductible status, and key coverage categories."
    ),
    agent=patient_details_agent,
    expected_output="A summary of patient demographics and insurance policy details including coverage overview.",
    context=[task_validate_input],
)

task_treatment_details = Task(
    description=(
        "Retrieve all treatment records, procedures, and itemized bills for patient {patient_id}.\n"
        "Use the fetch_treatment_details tool.\n"
        "List every line item with its category, description, date, and billed amount. "
        "Include the total billed amount."
    ),
    agent=treatment_details_agent,
    expected_output="Complete treatment record with all line items and total billed amount.",
    context=[task_patient_details],
)

task_policy_review = Task(
    description=(
        "Review each treatment line item against the insurance policy for patient {patient_id}.\n"
        "Use the review_policy_coverage tool.\n"
        "For each item: state whether it's covered, the approved amount after applying limits "
        "and coinsurance, and the reason for any exclusion.\n"
        "Provide totals: total approved, total excluded, estimated insurer payment."
    ),
    agent=policy_review_agent,
    expected_output=(
        "A JSON policy review result with each line item adjudicated, "
        "financial totals, and estimated insurer payment."
    ),
    context=[task_treatment_details],
)

task_generate_claim = Task(
    description=(
        "Generate the formal insurance claim form for patient {patient_id}.\n"
        "Use the generate_claim_form tool.\n"
        "The form must include: patient info, policy info, all approved line items, "
        "all excluded items with explanations, and a clear exclusion summary note."
    ),
    agent=claim_form_agent,
    expected_output=(
        "A complete, structured claim form JSON with approved items, excluded items, "
        "exclusion notes, and financial summary."
    ),
    context=[task_policy_review],
)

task_hitl_review = Task(
    description=(
        "Present the claim summary to a human reviewer in the terminal.\n"
        "Use the human_review_claim tool — it will display the claim and ask:\n"
        "  1. Approved\n"
        "  2. Not Approved\n"
        "Record and report the reviewer's decision."
    ),
    agent=hitl_agent,
    expected_output="The human reviewer's decision: Approved or Not Approved.",
    context=[task_generate_claim],
    human_input=False,  # human input is handled inside the tool itself
)

task_submit_claim = Task(
    description=(
        "Finalize the claim based on the human reviewer's decision.\n"
        "Use the finalize_claim tool.\n"
        "If the reviewer APPROVED: the tool will submit the claim and print the official "
        "claim form with confirmation number and processing timeline.\n"
        "If the reviewer did NOT APPROVE: the tool will print a rejection notice with "
        "likely causes and an item summary, and explain the patient's appeal options."
    ),
    agent=submission_agent,
    expected_output=(
        "Either a printed approved claim form with confirmation number, "
        "or a rejection notice with causes and next steps."
    ),
    context=[task_hitl_review],
)

# ═══════════════════════════════════════════════════════════════════════════════
# CREW
# ═══════════════════════════════════════════════════════════════════════════════

insurance_crew = Crew(
    agents=[
        input_agent,
        patient_details_agent,
        treatment_details_agent,
        policy_review_agent,
        claim_form_agent,
        hitl_agent,
        submission_agent,
    ],
    tasks=[
        task_validate_input,
        task_patient_details,
        task_treatment_details,
        task_policy_review,
        task_generate_claim,
        task_hitl_review,
        task_submit_claim,
    ],
    process=Process.sequential,
    verbose=True,
    memory=False,  # using shared _state dict for inter-task state
)

# ═══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def _select_patient() -> str:
    """Display a numbered patient menu and return the chosen patient ID."""
    patients = list(PATIENT_DB.values())
    print("\n" + "=" * 70)
    print("  PATIENT SELECTION")
    print("=" * 70)
    for idx, p in enumerate(patients, start=1):
        policy = INSURANCE_POLICY_DB.get(p["policy_id"], {})
        print(f"  [{idx}] {p['patient_id']} – {p['name']:<20}  "
              f"DOB: {p['dob']}  |  {policy.get('insurer', 'N/A')} – {policy.get('plan_name', 'N/A')}")
    print("=" * 70)

    while True:
        choice = input(f"  Select a patient [1-{len(patients)}]: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(patients):
            return patients[int(choice) - 1]["patient_id"]
        # also accept a direct patient ID
        upper = choice.upper()
        if upper in PATIENT_DB:
            return upper
        print(f"  Invalid choice. Enter a number between 1 and {len(patients)}, or a valid Patient ID.")


def run_insurance_claim(patient_id: str = None):
    """Run the full health insurance claim filing pipeline."""
    if not patient_id:
        patient_id = _select_patient()

    # Reset shared state and pre-seed patient_id so tools can fall back to it
    _state.clear()
    _state["patient_id"] = patient_id

    print("\n" + "=" * 70)
    print("  HEALTH INSURANCE CLAIM FILING SYSTEM")
    print("  Powered by CrewAI + Claude on AWS Bedrock")
    print("=" * 70)
    print(f"  Processing claim for Patient ID: {patient_id}")
    print("=" * 70 + "\n")

    try:
        result = insurance_crew.kickoff(inputs={"patient_id": patient_id})

        print("\n" + "=" * 70)
        print("  CLAIM PIPELINE COMPLETED")
        print("=" * 70)
        print("\nFinal Result:")
        print(result)

        # Print final claim status from state
        if _state.get("claim"):
            claim = _state["claim"]
            print(f"\n  Claim ID : {claim.get('claim_id')}")
            print(f"  Status   : {claim.get('status')}")
        if _state.get("submission"):
            sub = _state["submission"]
            print(f"  Confirm# : {sub.get('confirmation_number')}")
            print(f"  Est. Days: {sub.get('expected_processing_days')} business days")

        return result

    except Exception as e:
        print(f"\n[ERROR] Crew execution failed: {e}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    import sys
    run_insurance_claim()
