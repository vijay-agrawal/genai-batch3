# Role, Goal & Backstory in Agentic AI Frameworks
### A Student Study Guide — Multi-Agent Systems & CrewAI

---

## 1. Introduction

In multi-agent AI frameworks like **CrewAI**, **AutoGen**, and **LangGraph**, every AI agent is defined by three foundational attributes that shape how the underlying Large Language Model (LLM) reasons, communicates, and makes decisions:

| Attribute | Core Question | Analogy |
|-----------|--------------|---------|
| **Role** | *Who are you?* | Job title |
| **Goal** | *What are you optimising for?* | KPI / objective |
| **Backstory** | *How do you think, and what do you value?* | Resume + character |

These three elements work together to **prime the LLM's context window** — steering tone, reasoning style, domain focus, and risk tolerance without needing to hardcode any logic.

> **Key Insight:** LLMs are generalists. Without grounding, an agent asked to "analyse a patient report" might give vague, surface-level output. But when you give it a Role (Senior Oncologist), a Goal (detect early-stage anomalies), and a Backstory (15 years in oncology, trained to flag even borderline findings), the model activates a much richer, more precise reasoning pattern.

---

## 2. How the Framework Technically Leverages These Attributes

### 2.1 They Become the System Prompt

When you define an agent in CrewAI, the framework **automatically compiles** your `role`, `goal`, and `backstory` into a **structured system prompt** that is injected at the top of every LLM call made by that agent. You write Python — the framework translates it into prompt instructions.

Here is what that compiled prompt looks like under the hood:

```
You are {role}.
Your personal goal is: {goal}
Some context about your background: {backstory}
Your personal goal is to complete your task to the absolute best of your abilities.
You ONLY have access to the following tools and should NEVER make up tools that are not listed here:
...
```

### 2.2 The Internal Prompt Structure (XML/Structured Format)

CrewAI structures the full agent context using a layered prompt, which conceptually looks like this:

```xml
<agent_context>

  <identity>
    <role>Emergency Triage Nurse</role>
    <goal>
      Rapidly assess incoming patient symptoms and assign accurate
      priority levels to ensure life-threatening cases are seen first
    </goal>
    <backstory>
      You are a seasoned ER nurse with 12 years of experience in
      high-volume trauma centers. You have a sharp instinct for subtle
      warning signs like silent MIs, sepsis onset, and neurological
      red flags. You are calm under pressure and communicate precisely.
    </backstory>
  </identity>

  <task>
    <description>Review the following patient intake form and assign an ESI triage level.</description>
    <expected_output>A triage level (1–5) with a brief clinical justification.</expected_output>
  </task>

  <tools>
    <tool name="patient_record_lookup" />
    <tool name="vitals_analyser" />
  </tools>

  <conversation_history>
    <!-- Prior agent outputs, task context, memory -->
  </conversation_history>

</agent_context>
```

In practice, CrewAI serialises this as a structured string (not literal XML), but the **logical hierarchy is exactly this** — identity first, then task, then tools, then history.

### 2.3 Equivalent JSON Representation

When working with the raw Anthropic / OpenAI API directly (without a framework), developers often pass agent configuration as a JSON object used to build the system prompt:

```json
{
  "agent": {
    "role": "Clinical Pharmacist",
    "goal": "Review all proposed medications for contraindications, dosing errors, and interactions before any prescription is finalised",
    "backstory": "You are a PharmD with a specialty in critical care pharmacology. You have prevented dozens of near-miss medication errors in ICU settings. You are meticulous, conservative, and always flag anything ambiguous rather than assuming it is fine.",
    "tools": ["drug_interaction_db", "dosing_calculator"],
    "llm": "gpt-4o",
    "verbose": true,
    "allow_delegation": false
  }
}
```

This JSON is then **interpolated into a prompt template** at runtime, so the LLM receives a fully-formed system prompt — not a raw JSON object. The agent never "sees" JSON; it sees the rendered natural language prompt that JSON produces.

### 2.4 The Python API (CrewAI)

```python
from crewai import Agent, Task, Crew

triage_nurse = Agent(
    role="Emergency Triage Nurse",
    goal="""Rapidly assess incoming patient symptoms and assign accurate
            priority levels to ensure life-threatening cases are seen first""",
    backstory="""You are a seasoned ER nurse with 12 years of experience
                 in high-volume trauma centers. You've seen thousands of cases
                 and have a sharp instinct for subtle warning signs like silent
                 MIs, sepsis onset, and neurological red flags. You are calm
                 under pressure and communicate with precision.""",
    tools=[patient_lookup_tool, vitals_tool],
    llm="gpt-4o",
    verbose=True
)
```

### 2.5 What Each Attribute Controls at Inference Time

```
┌──────────────────────────────────────────────────────────────────┐
│                     LLM SYSTEM PROMPT                            │
├──────────────────┬───────────────────────────────────────────────┤
│  ROLE            │ Sets vocabulary, domain expertise, authority  │
│                  │ level, and communication register             │
├──────────────────┼───────────────────────────────────────────────┤
│  GOAL            │ Defines the objective function — what the     │
│                  │ model is optimising its output toward         │
├──────────────────┼───────────────────────────────────────────────┤
│  BACKSTORY       │ Shapes reasoning style, risk tolerance,       │
│                  │ personality, heuristics, and edge-case        │
│                  │ handling (e.g. "always flag ambiguous cases") │
└──────────────────┴───────────────────────────────────────────────┘
```

---

## 3. Healthcare Scenario: AI-Assisted Patient Triage & Care Coordination

Imagine a hospital deploying a CrewAI-powered system to handle incoming ER patients. Four specialised agents collaborate in a pipeline.

---

### Agent 1 — The Triage Nurse

```python
Agent(
    role="Emergency Triage Nurse",
    goal="""Rapidly assess incoming patient symptoms and assign accurate
            priority levels to ensure life-threatening cases are seen first""",
    backstory="""You are a seasoned ER nurse with 12 years of experience
                 in high-volume trauma centers. You've seen thousands of cases
                 and have a sharp instinct for subtle warning signs like silent
                 MIs, sepsis onset, and neurological red flags. You are calm
                 under pressure and communicate with precision."""
)
```

**What this unlocks:**
The agent prioritises urgency signals, uses triage-specific language (ESI levels 1–5), and will not get distracted by non-critical complaints when a high-acuity case is present.

**How the framework leverages it:**
The `role` primes the LLM to use clinical triage vocabulary. The `goal` focuses it on *speed and prioritisation* rather than comprehensive diagnosis. The `backstory`'s mention of "silent MIs and sepsis onset" injects specific clinical pattern-matching that generic prompts would miss entirely.

---

### Agent 2 — The Diagnostician

```python
Agent(
    role="Internal Medicine Diagnostician",
    goal="""Analyse patient history, vitals, and lab results to generate
            a ranked differential diagnosis with supporting evidence""",
    backstory="""You are a board-certified internist who trained at Johns
                 Hopkins and has a particular strength in rare disease
                 identification. You think systematically using frameworks
                 like VINDICATE and always consider drug interactions,
                 comorbidities, and atypical presentations in elderly patients."""
)
```

**What this unlocks:**
The agent applies structured clinical reasoning frameworks, considers edge cases, and produces output a physician can act on — not just generic suggestions.

**How the framework leverages it:**
The `backstory` reference to "VINDICATE" (a medical mnemonic for differential diagnosis) directly shapes the model's reasoning *structure* at inference time — the LLM will organise its analysis using that framework because the system prompt essentially says "this is how you think". The `goal` anchors the output format to a *ranked differential*, preventing narrative rambling.

---

### Agent 3 — The Pharmacist

```python
Agent(
    role="Clinical Pharmacist",
    goal="""Review all proposed medications for contraindications, dosing
            errors, and interactions before any prescription is finalised""",
    backstory="""You are a PharmD with a specialty in critical care
                 pharmacology. You have prevented dozens of near-miss
                 medication errors in ICU settings. You are meticulous,
                 conservative, and always flag anything ambiguous rather
                 than assuming it is fine."""
)
```

**What this unlocks:**
The `backstory`'s "conservative, flag ambiguous things" instruction meaningfully changes risk tolerance — the agent errs on the side of caution, which is exactly right for this role.

**How the framework leverages it:**
This is where `backstory` does something subtle and powerful: it encodes a **decision heuristic**. Without backstory, an LLM might confidently clear a medication even when uncertain. The phrase "always flag anything ambiguous" overrides that default confidence, producing appropriately cautious outputs in safety-critical pipelines.

---

### Agent 4 — The Care Coordinator

```python
Agent(
    role="Patient Care Coordinator",
    goal="""Create a clear, empathetic discharge plan that patients and
            families can understand and realistically follow at home""",
    backstory="""You specialise in health literacy and patient advocacy.
                 You work with diverse populations including non-English
                 speakers and elderly patients with low digital literacy.
                 You translate complex medical plans into simple, actionable
                 steps and always confirm understanding."""
)
```

**What this unlocks:**
This agent avoids medical jargon, simplifies language, and structures output for a patient audience — completely different behaviour from the Diagnostician, even when processing the same underlying data.

**How the framework leverages it:**
The same LLM model powers all four agents. The *only difference* is the system prompt compiled from role/goal/backstory. This is proof that persona-driven prompting produces genuinely different reasoning outputs — not just surface-level tone changes.

---

## 4. How the Agents Work Together (The Crew)

```
Patient arrives
      │
      ▼
┌─────────────────────┐
│  Triage Nurse Agent │  → Assigns ESI Priority Level + Summary
└─────────────────────┘
      │
      ▼
┌──────────────────────────┐
│  Diagnostician Agent     │  → Differential Diagnosis (ranked)
└──────────────────────────┘
      │
      ▼
┌─────────────────────────┐
│  Pharmacist Agent        │  → Medication Safety Review
└─────────────────────────┘
      │
      ▼
┌──────────────────────────┐
│  Care Coordinator Agent  │  → Patient Discharge Plan
└──────────────────────────┘
```

Each agent receives the prior agent's output as context, but interprets and acts on it through **its own role/goal/backstory lens** — creating a genuine division of cognitive labour. The framework passes prior outputs as `conversation_history` in each subsequent agent's prompt context.

---

## 5. Summary Comparison Table

| Attribute | Triage Nurse | Diagnostician | Pharmacist | Care Coordinator |
|-----------|-------------|---------------|------------|-----------------|
| **Role effect** | Clinical urgency vocabulary | Medical reasoning frameworks | Drug safety domain | Plain language / empathy |
| **Goal effect** | Speed + priority ranking | Ranked differential list | Flag before finalising | Readable discharge plan |
| **Backstory effect** | Instinct for red flags | VINDICATE framework, rare diseases | Conservative risk tolerance | Health literacy focus |
| **Risk orientation** | Fast + decisive | Thorough + evidence-based | Cautious + conservative | Accessible + compassionate |

---

## 6. Key Takeaways for Students

1. **Role, Goal, and Backstory are compiled into the system prompt** — they are not configuration stored separately; they become natural language instructions the LLM reads before every response.

2. **The same LLM can behave as radically different experts** based solely on these three attributes — no fine-tuning required.

3. **Backstory is the most nuanced lever** — it encodes reasoning style, heuristics, edge-case handling, and risk tolerance that cannot be captured by role or goal alone.

4. **In multi-agent systems**, each agent's identity stays consistent across all tasks assigned to it because the system prompt is rebuilt from the same role/goal/backstory on every API call.

5. **In healthcare (and any high-stakes domain)**, this framework allows AI to mirror real clinical teams — each agent staying in its lane while contributing to a unified, safe, patient-centred outcome.

---

## 7. Further Reading

- [CrewAI Documentation](https://docs.crewai.com)
- [Anthropic — Building with Claude Agents](https://docs.anthropic.com)
- Prompt Engineering Guide — System Prompts and Persona Design
- *"ReAct: Synergising Reasoning and Acting in Language Models"* — Yao et al., 2023

---

*Document prepared for student review — Agentic AI & Multi-Agent Systems module*
