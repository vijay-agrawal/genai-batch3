#!/usr/bin/env python3
"""
Healthcare Insurance Claims Management System
==============================================
LangGraph demo featuring:
  - 4 specialized agents as graph nodes
  - Reflection loop  (agent scores its own output quality)
  - Critique + Feedback + Modify loop  (iterative improvement cycle)
  - Amazon Bedrock LLM via langchain-aws
  - Typed graph state with append-only audit trail

Story: "The Chen Family Emergency"
  Margaret Chen, 72, is rushed to Memorial General Hospital with acute
  appendicitis.  Emergency surgery reveals peritonitis -- a life-threatening
  complication.  A 12-day ICU and ward stay follows.  Her insurer receives
  an $87,430 claim that contains apparent duplicate charges AND a mysterious
  knee replacement procedure she never had.

  Our 4-agent system must untangle the billing chaos, determine what is
  legitimate, what is a billing error, and what needs investigation --
  all while protecting Margaret's care and the insurer's integrity.

Agents:
  1. Claims Intake Agent        - triages and structures the raw claim
  2. Medical Necessity Reviewer - evaluates clinical docs against policy
  3. Fraud & Anomaly Detector   - identifies billing irregularities
  4. Claims Decision Agent      - synthesises findings into a determination
                                  (participates in the reflection + critique loop)

Graph Flow:
  intake -> medical_review -> fraud_detection -> decision
                                                    |
                                                 reflect
                                                    |
                              +---------------------+---------------------+
                              |                                           |
                        needs_revision                           approved_for_output
                              |                                           |
                       critique_feedback                              finalize -> END
                              |
                           decision  (loop back)
"""

import os
import operator
from typing import TypedDict, Annotated, List

from dotenv import load_dotenv

from langchain_aws import ChatBedrock
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END

load_dotenv()

# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-lite-v1:0")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MAX_REVISION_LOOPS = 2          # hard cap on critique-feedback-modify cycles


def get_llm(temperature: float = 0.2) -> ChatBedrock:
    return ChatBedrock(
        model_id=MODEL_ID,
        region_name=AWS_REGION,
        model_kwargs={
            "temperature": temperature,
            "max_tokens": 1800,
        },
    )


# ---------------------------------------------------------------------------
# GRAPH STATE
# All nodes read from and write to this shared state.
# audit_trail uses operator.add so each node *appends* rather than overwrites.
# ---------------------------------------------------------------------------
class ClaimsState(TypedDict):
    # Raw input
    claim_raw: str

    # Sequential agent outputs
    intake_summary: str        # Agent 1
    medical_review: str        # Agent 2
    fraud_assessment: str      # Agent 3

    # Decision loop
    current_decision: str      # Agent 4 -- latest draft
    reflection_notes: str      # Reflection node -- quality score + verdict
    critique_feedback: str     # Critique node -- specific revision instructions
    final_decision: str        # Stamped only when approved

    # Loop control
    revision_count: int
    needs_revision: bool

    # Append-only audit trail
    audit_trail: Annotated[List[str], operator.add]


# ---------------------------------------------------------------------------
# CLAIM SCENARIO  --  "The Chen Family Emergency"
# ---------------------------------------------------------------------------
SAMPLE_CLAIM = """
CLAIM ID:          MC-2024-087432
Submitted:         2024-11-15
Provider:          Memorial General Hospital, Boston MA

INSURED:           Margaret Chen  |  DOB: 1952-03-14  (Age 72)
POLICY:            UnitedCare Premier PPO  |  #UCH-441892-P  |  Group: RetireWell Corp

DIAGNOSIS CODES:
  K37    Unspecified appendicitis
  K65.0  Generalized (acute) peritonitis  [post-op complication]
  E11.9  Type 2 diabetes mellitus, without complications
  I10    Essential hypertension

PROCEDURE CODES & CHARGES:
  44950  Appendectomy, open                              $12,400.00
  44950  Appendectomy, open  [DUPLICATE LINE]            $12,400.00   <-- flagged
  99233  Subsequent hospital care, high complexity       $1,850.00 x 6 days  ($11,100)
  99233  Subsequent hospital care, high complexity       $1,850.00 x 2 days  ($3,700)  [overlap?]
  27447  Total knee arthroplasty  [unrelated??]          $22,500.00
  86920  Compatibility test, immediate spin              $380.00
  99291  Critical care, first 30-74 minutes              $1,200.00
  36556  Central venous catheter insertion               $2,100.00

DATES OF SERVICE:  2024-10-28  to  2024-11-08  (12 days total)
ATTENDING:         Dr. Priya Natarajan, MD  (General Surgery)
TOTAL BILLED:      $87,430.00

PRIOR AUTHORIZATION:  PA-2024-87432  (appendectomy only)

CLINICAL NOTES SUMMARY:
  Patient presented via ED with acute abdominal pain, fever 39.2 C, elevated
  WBC 18,400.  Emergency appendectomy performed 10/28.  Post-op day 2: patient
  developed peritonitis requiring ICU transfer, IV antibiotics, and central-line
  placement.  HbA1c 9.2% (poorly controlled diabetes) complicated wound healing.
  Discharged 11/08 with wound-care instructions.

  NOTE: No knee surgery was performed during this admission.  The knee replacement
  line item (27447) appears to be a billing/coding error.
"""


# ---------------------------------------------------------------------------
# AGENT NODE 1 -- CLAIMS INTAKE
# ---------------------------------------------------------------------------
def claims_intake_agent(state: ClaimsState) -> dict:
    """Triage the raw claim and produce a structured intake summary."""
    print("\n[AGENT 1] Claims Intake Agent -- triaging claim...")

    llm = get_llm(temperature=0.1)
    response = llm.invoke([
        SystemMessage(content=(
            "You are a Claims Intake Specialist at a health insurance company. "
            "Read raw claim submissions and produce a structured triage report. "
            "Identify: patient demographics, key diagnoses, procedures, billed amounts, "
            "dates, prior authorizations, and immediate red flags. "
            "Be concise and factual. Use structured formatting."
        )),
        HumanMessage(content=(
            f"Triage this insurance claim and produce a structured intake report:\n\n"
            f"{state['claim_raw']}\n\n"
            "Your report must include:\n"
            "1. Patient & Policy Overview\n"
            "2. Clinical Summary\n"
            "3. Procedures & Charges Breakdown\n"
            "4. Immediate Red Flags (if any)\n"
            "5. Completeness Check (missing info / items needing verification)"
        )),
    ])

    summary = response.content
    return {
        "intake_summary": summary,
        "audit_trail": ["[INTAKE] Claim MC-2024-087432 triaged. Structured summary generated."],
    }


# ---------------------------------------------------------------------------
# AGENT NODE 2 -- MEDICAL NECESSITY REVIEWER
# ---------------------------------------------------------------------------
def medical_necessity_reviewer(state: ClaimsState) -> dict:
    """Evaluate medical necessity of each procedure against clinical guidelines."""
    print("\n[AGENT 2] Medical Necessity Reviewer -- assessing clinical justification...")

    llm = get_llm(temperature=0.2)
    response = llm.invoke([
        SystemMessage(content=(
            "You are a Senior Medical Necessity Reviewer with 20 years of clinical experience. "
            "You evaluate insurance claims against InterQual and MCG guidelines to determine "
            "whether each procedure is medically necessary, appropriately coded, and supported "
            "by the clinical documentation. Be thorough. Cite clinical rationale."
        )),
        HumanMessage(content=(
            "Review this claim for medical necessity.\n\n"
            f"INTAKE SUMMARY:\n{state['intake_summary']}\n\n"
            f"RAW CLAIM:\n{state['claim_raw']}\n\n"
            "Assess:\n"
            "1. Medical Necessity per Procedure (Approved / Denied / Needs More Info)\n"
            "2. Length of Stay Appropriateness (12 days -- justified given peritonitis + diabetes?)\n"
            "3. Clinical Documentation Adequacy\n"
            "4. Comorbidity Impact (diabetes HbA1c 9.2%, hypertension on recovery)\n"
            "5. Prior Authorization Coverage (PA-2024-87432 covers appendectomy only)\n"
            "6. Overall Medical Necessity Verdict with rationale"
        )),
    ])

    review = response.content
    return {
        "medical_review": review,
        "audit_trail": ["[MEDICAL REVIEW] Medical necessity assessment complete."],
    }


# ---------------------------------------------------------------------------
# AGENT NODE 3 -- FRAUD & ANOMALY DETECTOR
# ---------------------------------------------------------------------------
def fraud_anomaly_detector(state: ClaimsState) -> dict:
    """Identify billing anomalies, duplicate charges, upcoding, and fraud signals."""
    print("\n[AGENT 3] Fraud & Anomaly Detector -- scanning for billing irregularities...")

    llm = get_llm(temperature=0.1)
    response = llm.invoke([
        SystemMessage(content=(
            "You are a Special Investigations Unit (SIU) analyst specializing in "
            "healthcare fraud detection. You analyze claims for billing anomalies, "
            "upcoding, duplicate charges, unbundling, and impossible charge combinations. "
            "Use a structured scoring approach. Distinguish billing ERRORS (accidental) "
            "from potential FRAUD (intentional). Be precise about which line items are "
            "suspicious and why."
        )),
        HumanMessage(content=(
            "Analyze this claim for fraud indicators and billing anomalies.\n\n"
            f"RAW CLAIM:\n{state['claim_raw']}\n\n"
            f"MEDICAL REVIEW CONTEXT:\n{state['medical_review']}\n\n"
            "Investigate:\n"
            "1. Duplicate Billing Analysis -- identify exact duplicate charges\n"
            "2. Procedure Code Consistency -- do CPT codes match the clinical narrative?\n"
            "3. Unbundling Check -- are procedures improperly separated?\n"
            "4. Upcoding Assessment -- are complexity/severity levels justified?\n"
            "5. Impossible or Contradictory Charges -- procedures that could not co-occur\n"
            "6. Overlap in Daily Hospital Charges -- are date ranges double-billed?\n"
            "7. Fraud Risk Score (Low / Medium / High) with point-by-point justification\n"
            "8. Recommended Action (approve / adjust / investigate / deny) per line item"
        )),
    ])

    assessment = response.content
    return {
        "fraud_assessment": assessment,
        "audit_trail": ["[FRAUD DETECTION] Anomaly and fraud analysis complete."],
    }


# ---------------------------------------------------------------------------
# AGENT NODE 4 -- CLAIMS DECISION AGENT
# Participates in the reflection + critique-feedback-modify loop.
# ---------------------------------------------------------------------------
def claims_decision_agent(state: ClaimsState) -> dict:
    """Synthesise all findings into a claims determination. Revises if critique exists."""
    revision = state.get("revision_count", 0)
    print(f"\n[AGENT 4] Claims Decision Agent -- drafting determination (revision #{revision})...")

    llm = get_llm(temperature=0.2)

    # Build optional critique section for revision passes
    critique_block = ""
    if state.get("critique_feedback"):
        critique_block = (
            f"\n\nPREVIOUS DETERMINATION CRITIQUE -- YOU MUST ADDRESS ALL POINTS:\n"
            f"{state['critique_feedback']}\n\n"
            f"PREVIOUS DRAFT DETERMINATION (to be revised):\n"
            f"{state.get('current_decision', 'N/A')}\n"
        )

    response = llm.invoke([
        SystemMessage(content=(
            "You are a Senior Claims Adjudicator at a health insurance company. "
            "You synthesise findings from medical necessity review and fraud detection "
            "to produce a final, legally defensible claims determination. "
            "Your determination must be fair, evidence-based, policy-compliant, "
            "and clearly explain the rationale for each approved or denied line item. "
            "Always include member rights and appeals information."
        )),
        HumanMessage(content=(
            "Produce a complete Claims Determination based on all agent findings.\n\n"
            f"INTAKE SUMMARY:\n{state['intake_summary']}\n\n"
            f"MEDICAL NECESSITY REVIEW:\n{state['medical_review']}\n\n"
            f"FRAUD & ANOMALY ASSESSMENT:\n{state['fraud_assessment']}"
            f"{critique_block}\n\n"
            "Your determination MUST include:\n"
            "1. Executive Summary  (approve / partial / deny + total approved amount)\n"
            "2. Line-by-Line Adjudication  (each CPT code: approved / denied / adjusted + reason)\n"
            "3. Fraud Disposition  (billing error vs. SIU investigation referral)\n"
            "4. Member Financial Impact  (what Margaret Chen owes after insurance payment)\n"
            "5. Provider Notification Requirements\n"
            "6. Appeals Rights Notice  (timeframe, contact, process)"
        )),
    ])

    decision = response.content
    return {
        "current_decision": decision,
        "audit_trail": [f"[DECISION] Determination drafted (revision #{revision})."],
    }


# ---------------------------------------------------------------------------
# REFLECTION NODE
# The system reflects on the quality of its own decision before finalising.
# ---------------------------------------------------------------------------
def reflection_agent(state: ClaimsState) -> dict:
    """Score the current decision on key quality dimensions; decide if revision needed."""
    print("\n[REFLECTION] Evaluating decision quality -- self-assessment in progress...")

    llm = get_llm(temperature=0.3)
    response = llm.invoke([
        SystemMessage(content=(
            "You are an independent Quality Assurance reviewer for insurance claims decisions. "
            "Critically evaluate a claims determination for completeness, accuracy, "
            "regulatory compliance, fairness to the member, and actionability. "
            "Score each dimension 1-5 and state clearly whether revision is needed."
        )),
        HumanMessage(content=(
            "Reflect on this claims determination and evaluate its quality:\n\n"
            f"DETERMINATION TO REVIEW:\n{state['current_decision']}\n\n"
            "SUPPORTING CONTEXT (abridged):\n"
            f"Medical Review: {state['medical_review'][:400]}...\n"
            f"Fraud Assessment: {state['fraud_assessment'][:400]}...\n\n"
            "Score on these dimensions (1 = poor, 5 = excellent):\n"
            "  A. Completeness       -- are ALL line items adjudicated?\n"
            "  B. Accuracy           -- are decisions consistent with the evidence?\n"
            "  C. Regulatory Compliance -- required notices (appeals, EOB) included?\n"
            "  D. Member Fairness    -- is Margaret's financial impact clearly stated?\n"
            "  E. Actionability      -- can the provider act on this immediately?\n\n"
            "After scoring, provide a brief narrative on what is strong and what is weak.\n\n"
            "CRITICAL: End your response with EXACTLY one of these two lines:\n"
            "  VERDICT: APPROVED FOR FINAL OUTPUT\n"
            "  VERDICT: NEEDS REVISION\n"
            "(Choose NEEDS REVISION if ANY dimension scores below 4.)"
        )),
    ])

    reflection = response.content
    needs_revision = "VERDICT: NEEDS REVISION" in reflection

    # Enforce the hard cap on revision loops
    if state.get("revision_count", 0) >= MAX_REVISION_LOOPS:
        needs_revision = False
        reflection += (
            f"\n\n[SYSTEM OVERRIDE: Maximum revision cycles ({MAX_REVISION_LOOPS}) "
            "reached. Approving current determination for final output.]"
        )

    return {
        "reflection_notes": reflection,
        "needs_revision": needs_revision,
        "audit_trail": [
            f"[REFLECTION] Quality assessment complete. "
            f"Needs revision: {needs_revision}. "
            f"Revision count so far: {state.get('revision_count', 0)}."
        ],
    }


# ---------------------------------------------------------------------------
# CRITIQUE + FEEDBACK NODE
# Generates specific, numbered, actionable revision instructions.
# ---------------------------------------------------------------------------
def critique_feedback_agent(state: ClaimsState) -> dict:
    """Translate reflection notes into precise revision instructions for the decision agent."""
    new_revision = state.get("revision_count", 0) + 1
    print(f"\n[CRITIQUE] Generating revision instructions -- cycle #{new_revision}...")

    llm = get_llm(temperature=0.2)
    response = llm.invoke([
        SystemMessage(content=(
            "You are a claims quality coach. Based on a QA reviewer's reflection notes, "
            "you produce specific, numbered, actionable revision instructions for the "
            "claims adjudicator. Reference exact CPT codes, missing sections, or "
            "specific language that needs fixing. "
            "Your instructions must be directly usable -- no vague guidance."
        )),
        HumanMessage(content=(
            "Generate precise revision instructions from this quality reflection:\n\n"
            f"REFLECTION NOTES:\n{state['reflection_notes']}\n\n"
            f"CURRENT DETERMINATION (to be revised):\n{state['current_decision']}\n\n"
            "Produce a numbered list of specific, actionable revision instructions.\n"
            "Each instruction must reference EXACTLY what needs to change and HOW.\n\n"
            "Format strictly as:\n"
            "REVISION INSTRUCTION #1: [specific action required]\n"
            "REVISION INSTRUCTION #2: [specific action required]\n"
            "(continue as needed)"
        )),
    ])

    critique = response.content
    return {
        "critique_feedback": critique,
        "revision_count": new_revision,
        "audit_trail": [f"[CRITIQUE] Revision instructions generated for cycle #{new_revision}."],
    }


# ---------------------------------------------------------------------------
# FINALIZE NODE
# Stamps the approved decision as the official final output.
# ---------------------------------------------------------------------------
def finalize_decision(state: ClaimsState) -> dict:
    """Stamp the approved determination as final."""
    print("\n[FINAL] Decision quality approved -- stamping as final output.")
    return {
        "final_decision": state["current_decision"],
        "audit_trail": [
            f"[FINAL] Determination approved after {state.get('revision_count', 0)} "
            "revision cycle(s). Claim MC-2024-087432 processing complete."
        ],
    }


# ---------------------------------------------------------------------------
# ROUTING FUNCTION
# ---------------------------------------------------------------------------
def route_after_reflection(state: ClaimsState) -> str:
    """Conditional edge: direct to critique loop or finalization."""
    if state.get("needs_revision", False):
        return "critique_feedback"
    return "finalize"


# ---------------------------------------------------------------------------
# BUILD THE LANGGRAPH
# ---------------------------------------------------------------------------
def build_claims_graph() -> StateGraph:
    graph = StateGraph(ClaimsState)

    # Register nodes
    graph.add_node("intake",            claims_intake_agent)
    graph.add_node("medical_review",    medical_necessity_reviewer)
    graph.add_node("fraud_detection",   fraud_anomaly_detector)
    graph.add_node("decision",          claims_decision_agent)
    graph.add_node("reflection",        reflection_agent)
    graph.add_node("critique_feedback", critique_feedback_agent)
    graph.add_node("finalize",          finalize_decision)

    # Sequential pipeline: intake -> medical -> fraud -> decision
    graph.set_entry_point("intake")
    graph.add_edge("intake",          "medical_review")
    graph.add_edge("medical_review",  "fraud_detection")
    graph.add_edge("fraud_detection", "decision")

    # Every decision draft goes to reflection
    graph.add_edge("decision", "reflection")

    # Conditional fork after reflection
    graph.add_conditional_edges(
        "reflection",
        route_after_reflection,
        {
            "critique_feedback": "critique_feedback",   # needs revision
            "finalize":          "finalize",             # approved
        },
    )

    # Critique feeds back into decision  (the MODIFY step of the loop)
    graph.add_edge("critique_feedback", "decision")

    # Finalize -> END
    graph.add_edge("finalize", END)

    return graph.compile()


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
def main():
    print("\n" + "=" * 72)
    print("  HEALTHCARE INSURANCE CLAIMS MANAGEMENT SYSTEM")
    print("  LangGraph  |  Amazon Bedrock  |  Reflection + Critique-Feedback Loop")
    print("=" * 72)
    print("""
  Story: "The Chen Family Emergency"

  Margaret Chen, 72, was rushed to Memorial General Hospital with acute
  appendicitis.  Emergency surgery revealed peritonitis -- a life-threatening
  complication.  A 12-day ICU and ward stay followed.  Her insurer received
  an $87,430 claim containing apparent duplicate charges AND a mysterious
  knee replacement procedure she never had.

  Our 4-agent LangGraph system must:
    - Triage the complex claim                  [Claims Intake Agent]
    - Validate clinical justification           [Medical Necessity Reviewer]
    - Detect billing anomalies                  [Fraud & Anomaly Detector]
    - Issue a fair, legally defensible ruling   [Claims Decision Agent]
      ... refined through a Reflection + Critique-Feedback-Modify loop.
""")
    print("-" * 72)

    # Build the compiled graph
    app = build_claims_graph()

    # Initial state
    initial_state: ClaimsState = {
        "claim_raw":         SAMPLE_CLAIM,
        "intake_summary":    "",
        "medical_review":    "",
        "fraud_assessment":  "",
        "current_decision":  "",
        "reflection_notes":  "",
        "critique_feedback": "",
        "final_decision":    "",
        "revision_count":    0,
        "needs_revision":    False,
        "audit_trail":       ["[SYSTEM] Claims processing initiated for MC-2024-087432."],
    }

    # Run the graph
    final_state = app.invoke(initial_state)

    # -----------------------------------------------------------------------
    # PRINT RESULTS
    # -----------------------------------------------------------------------
    sep = "=" * 72

    print(f"\n{sep}")
    print("  AGENT 1 OUTPUT -- INTAKE SUMMARY")
    print(sep)
    print(final_state["intake_summary"])

    print(f"\n{sep}")
    print("  AGENT 2 OUTPUT -- MEDICAL NECESSITY REVIEW")
    print(sep)
    print(final_state["medical_review"])

    print(f"\n{sep}")
    print("  AGENT 3 OUTPUT -- FRAUD & ANOMALY ASSESSMENT")
    print(sep)
    print(final_state["fraud_assessment"])

    print(f"\n{sep}")
    revision_count = final_state.get("revision_count", 0)
    print(f"  AGENT 4 OUTPUT -- FINAL CLAIMS DETERMINATION  (after {revision_count} revision cycle(s))")
    print(sep)
    print(final_state["final_decision"])

    print(f"\n{sep}")
    print("  REFLECTION NOTES (last iteration)")
    print(sep)
    print(final_state["reflection_notes"])

    if final_state.get("critique_feedback"):
        print(f"\n{sep}")
        print("  CRITIQUE FEEDBACK (last iteration)")
        print(sep)
        print(final_state["critique_feedback"])

    print(f"\n{sep}")
    print("  FULL AUDIT TRAIL")
    print(sep)
    for i, entry in enumerate(final_state["audit_trail"], 1):
        print(f"  {i:02d}. {entry}")
    print(sep + "\n")


if __name__ == "__main__":
    main()
