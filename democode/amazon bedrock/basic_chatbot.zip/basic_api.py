"""
bedrock_demo.py
───────────────
Demonstrates connecting to Amazon Bedrock, sending a system prompt
and a user prompt, and printing the response.
Configuration is loaded from a .env file using python-dotenv.

Model  : Amazon Nova Micro  (amazon.nova-micro-v1:0)  — set in .env
Region : us-east-1                                     — set in .env
Auth   : AWS credentials                               — set in .env

Setup
─────
pip install boto3 python-dotenv

1. Edit .env and fill in your AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY
2. Run: python bedrock_demo.py
"""

import boto3
from dotenv import load_dotenv
import os

# ANSI color/style codes
CYAN_BOLD = "\033[1;36m"
GREEN_BOLD = "\033[1;32m"
YELLOW_BOLD = "\033[1;33m"
MAGENTA_BOLD = "\033[1;35m"
WHITE_BOLD = "\033[1;37m"
RESET     = "\033[0m"

# ── Load environment variables from .env ──────────────────────────────────────

load_dotenv()  # reads .env from the current directory

# ── Read config from environment ──────────────────────────────────────────────

AWS_ACCESS_KEY_ID     = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION            = os.getenv("AWS_REGION", "us-east-1")

MODEL_ID    = os.getenv("BEDROCK_MODEL_ID",      "amazon.nova-micro-v1:0")
MAX_TOKENS  = int(os.getenv("BEDROCK_MAX_TOKENS",    "512"))
TEMPERATURE = float(os.getenv("BEDROCK_TEMPERATURE", "0.7"))

SYSTEM_PROMPT = "You are a helpful assistant who answers questions in a poetic manner in 2 lines only."
USER_PROMPT   = "What is the capital of France?"

# ── Connect to Bedrock Runtime ────────────────────────────────────────────────

client = boto3.client(
    "bedrock-runtime",
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
)

# ── Send the request ──────────────────────────────────────────────────────────

response = client.converse(
    modelId=MODEL_ID,
    system=[
        {"text": SYSTEM_PROMPT}
    ],
    messages=[
        {"role": "user", "content": [{"text": USER_PROMPT}]}
    ],
    inferenceConfig={
        "maxTokens": MAX_TOKENS,
        "temperature": TEMPERATURE,
    }
)

# ── Print the response ────────────────────────────────────────────────────────

reply = response["output"]["message"]["content"][0]["text"]

print("=" * 60)
print(f"Model         : {MODEL_ID}")
print(f"Region        : {AWS_REGION}")
print("=" * 60)
print(f"{CYAN_BOLD}System Prompt :{RESET} {SYSTEM_PROMPT.strip()}")
print(f"{CYAN_BOLD}User Prompt   :{RESET} {USER_PROMPT}")
print(f"{CYAN_BOLD}Response from Amazon Bedrock Model {MODEL_ID}:{RESET}")
print(f"{MAGENTA_BOLD}{reply}{RESET}")
print("=" * 60)
print(f"Tokens used — Input: {response['usage']['inputTokens']}  "
      f"Output: {response['usage']['outputTokens']}")