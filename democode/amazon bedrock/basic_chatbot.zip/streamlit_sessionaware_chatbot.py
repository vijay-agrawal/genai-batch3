import boto3
import streamlit as st
from dotenv import load_dotenv
import os

load_dotenv()

AWS_ACCESS_KEY_ID     = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION            = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID              = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
MAX_TOKENS            = int(os.getenv("BEDROCK_MAX_TOKENS", "512"))
TEMPERATURE           = float(os.getenv("BEDROCK_TEMPERATURE", "0.7"))

SYSTEM_PROMPT = "You are a helpful assistant."

client = boto3.client(
    "bedrock-runtime",
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
)

st.set_page_config(layout="wide")
st.title("Bedrock Chatbot")

if "messages" not in st.session_state:
    st.session_state.messages = []
if "last_payload" not in st.session_state:
    st.session_state.last_payload = None

# Layout: chat on left, LLM payload inspector on right (3:2 ratio, responsive via wide layout)
chat_col, debug_col = st.columns([3, 2])

with chat_col:
    # Display conversation history
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

# Chat input (outside columns so it spans full width)
question = st.chat_input("Ask a question...")

if question:
    with chat_col:
        # Show and store user message
        with st.chat_message("user"):
            st.write(question)
    st.session_state.messages.append({"role": "user", "content": question})

    # Build messages list for Bedrock (role must alternate user/assistant)
    bedrock_messages = [
        {"role": m["role"], "content": [{"text": m["content"]}]}
        for m in st.session_state.messages
    ]

    # Capture payload sent to LLM
    st.session_state.last_payload = {
        "system": SYSTEM_PROMPT,
        "messages": bedrock_messages,
        "inferenceConfig": {"maxTokens": MAX_TOKENS, "temperature": TEMPERATURE},
    }

    response = client.converse(
        modelId=MODEL_ID,
        system=[{"text": SYSTEM_PROMPT}],
        messages=bedrock_messages,
        inferenceConfig={"maxTokens": MAX_TOKENS, "temperature": TEMPERATURE},
    )
    reply = response["output"]["message"]["content"][0]["text"]

    with chat_col:
        # Show and store assistant message
        with st.chat_message("assistant"):
            st.write(reply)
    st.session_state.messages.append({"role": "assistant", "content": reply})

# Debug panel — show what was sent to the LLM
with debug_col:
    st.subheader("📤 What was sent to the LLM")
    if st.session_state.last_payload:
        payload = st.session_state.last_payload

        st.markdown("**System Prompt**")
        st.info(payload["system"])

        st.markdown("**Messages  sent**")
        st.json(payload["messages"])

        st.markdown("**Inference Config**")
        st.json(payload["inferenceConfig"])
    else:
        st.caption("Send a message to see the LLM payload here.")
