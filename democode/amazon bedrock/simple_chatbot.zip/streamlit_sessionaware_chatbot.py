import boto3
import streamlit as st
from dotenv import load_dotenv
import os

load_dotenv()

AWS_ACCESS_KEY_ID     = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION            = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID              = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
MAX_TOKENS            = int(os.getenv("BEDROCK_MAX_TOKENS", "512"))
TEMPERATURE           = float(os.getenv("BEDROCK_TEMPERATURE", "0.7"))

SYSTEM_PROMPT = "You are a helpful assistant."

client = boto3.client(
    "bedrock-runtime",
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
)

st.title("Bedrock Chatbot")

if "messages" not in st.session_state:
    st.session_state.messages = []

# Display conversation history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])

# Chat input
question = st.chat_input("Ask a question...")

if question:
    # Show and store user message
    with st.chat_message("user"):
        st.write(question)
    st.session_state.messages.append({"role": "user", "content": question})

    # Build messages list for Bedrock (role must alternate user/assistant)
    bedrock_messages = [
        {"role": m["role"], "content": [{"text": m["content"]}]}
        for m in st.session_state.messages
    ]

    response = client.converse(
        modelId=MODEL_ID,
        system=[{"text": SYSTEM_PROMPT}],
        messages=bedrock_messages,
        inferenceConfig={"maxTokens": MAX_TOKENS, "temperature": TEMPERATURE},
    )
    reply = response["output"]["message"]["content"][0]["text"]

    # Show and store assistant message
    with st.chat_message("assistant"):
        st.write(reply)
    st.session_state.messages.append({"role": "assistant", "content": reply})
