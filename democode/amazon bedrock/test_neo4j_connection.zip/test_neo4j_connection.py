"""
Neo4j Connection Diagnostic Test
=================================
Runs layered checks from network-level → TLS/SSL → driver → query.
Prints actionable diagnostics for every failure mode.

Usage:
    python test_neo4j_connection.py
"""

import os
import sys
import ssl
import socket
import traceback
from urllib.parse import urlparse

from dotenv import load_dotenv

# ── Load .env ─────────────────────────────────────────────────────────────────

load_dotenv()

_REQUIRED = ("NEO4J_URI", "NEO4J_USERNAME", "NEO4J_PASSWORD")
_missing = [v for v in _REQUIRED if not os.getenv(v)]
if _missing:
    print("ERROR: The following required variables are not set in .env:")
    for v in _missing:
        print(f"  missing: {v}")
    print("\nCopy .env.example to .env and fill in all values.")
    sys.exit(1)

NEO4J_URI      = os.environ["NEO4J_URI"]
NEO4J_USERNAME = os.environ["NEO4J_USERNAME"]
NEO4J_PASSWORD = os.environ["NEO4J_PASSWORD"]

# ── Helpers ───────────────────────────────────────────────────────────────────

def section(title: str):
    print(f"\n{'═' * 60}")
    print(f"  {title}")
    print('═' * 60)

def ok(msg):   print(f"  ✓  {msg}")
def fail(msg): print(f"  ✗  {msg}")
def info(msg): print(f"  ℹ  {msg}")
def warn(msg): print(f"  ⚠  {msg}")

# ── Step 0: Show config ───────────────────────────────────────────────────────

section("STEP 0 — Configuration")
info(f"NEO4J_URI      = {NEO4J_URI}")
info(f"NEO4J_USERNAME = {NEO4J_USERNAME}")
info(f"NEO4J_PASSWORD = {'*' * len(NEO4J_PASSWORD) if NEO4J_PASSWORD else '(not set)'}")

# Warn about common .env pitfalls
if NEO4J_PASSWORD in ("password", "your-password-here"):
    warn("Password looks like a placeholder — update .env with the real value.")
if "your-instance" in NEO4J_URI:
    warn("URI still contains placeholder text — update .env with your real URI.")

# ── Step 1: Parse URI ─────────────────────────────────────────────────────────

section("STEP 1 — URI Parsing")

parsed = urlparse(NEO4J_URI)
scheme = parsed.scheme.lower()
host   = parsed.hostname
port   = parsed.port

# Default ports per scheme
DEFAULT_PORTS = {
    "bolt":     7687,
    "bolt+s":   7687,
    "bolt+ssc": 7687,
    "neo4j":    7687,
    "neo4j+s":  7687,
    "neo4j+ssc":7687,
}
if port is None:
    port = DEFAULT_PORTS.get(scheme, 7687)
    info(f"No port in URI — using default {port}")

ENCRYPTED_SCHEMES = {"bolt+s", "bolt+ssc", "neo4j+s", "neo4j+ssc"}
uses_tls = scheme in ENCRYPTED_SCHEMES
uses_self_signed = scheme in {"bolt+ssc", "neo4j+ssc"}

info(f"Scheme : {scheme}")
info(f"Host   : {host}")
info(f"Port   : {port}")
info(f"TLS    : {'yes' if uses_tls else 'no'}")
if uses_self_signed:
    warn("Scheme *+ssc means self-signed certificate — driver will skip cert verification.")

# ── Step 2: DNS resolution ────────────────────────────────────────────────────

section("STEP 2 — DNS Resolution")
try:
    ip_list = socket.getaddrinfo(host, port)
    resolved_ips = list({entry[4][0] for entry in ip_list})
    ok(f"Resolved '{host}' → {resolved_ips}")
except socket.gaierror as e:
    fail(f"DNS resolution failed for '{host}': {e}")
    print("""
  DIAGNOSIS: The hostname cannot be resolved.
  ─────────────────────────────────────────────
  • Check NEO4J_URI in your .env file — the hostname may be wrong.
  • For Neo4j Aura the URI looks like: neo4j+s://xxxxxxxx.databases.neo4j.io
  • If using a local instance try: bolt://localhost:7687
  • Verify you have internet access / DNS is reachable.
""")
    sys.exit(1)

# ── Step 3: TCP connectivity ──────────────────────────────────────────────────

section("STEP 3 — TCP Connectivity")
try:
    sock = socket.create_connection((host, port), timeout=10)
    sock.close()
    ok(f"TCP connection to {host}:{port} succeeded")
except socket.timeout:
    fail(f"Connection to {host}:{port} timed out (10 s)")
    print(f"""
  DIAGNOSIS: Network timeout.
  ─────────────────────────────────────────────
  • A firewall or security group may be blocking port {port}.
  • For Neo4j Aura: ensure outbound TCP on port 7687 is allowed.
  • For local Neo4j: make sure the database is running.
    Windows: check Task Manager / Services for 'Neo4j'
    Command: neo4j status
""")
    sys.exit(1)
except ConnectionRefusedError:
    fail(f"Connection refused on {host}:{port}")
    print(f"""
  DIAGNOSIS: Nothing is listening on port {port}.
  ─────────────────────────────────────────────
  • If using local Neo4j Desktop / Community, start the database first.
  • If using Neo4j Aura, verify the URI is correct (cloud instances
    are always available — a refused connection suggests a wrong host/port).
  • Double-check the port in your NEO4J_URI.
""")
    sys.exit(1)
except OSError as e:
    fail(f"TCP connection failed: {e}")
    traceback.print_exc()
    sys.exit(1)

# ── Step 4: TLS / SSL certificate check (only for encrypted schemes) ──────────

if uses_tls and not uses_self_signed:
    section("STEP 4 — TLS / SSL Certificate Verification")
    try:
        ctx = ssl.create_default_context()
        with ctx.wrap_socket(socket.socket(), server_hostname=host) as tls_sock:
            tls_sock.settimeout(10)
            tls_sock.connect((host, port))
            cert = tls_sock.getpeercert()
            cipher = tls_sock.cipher()
            ok(f"TLS handshake succeeded")
            info(f"TLS version : {tls_sock.version()}")
            info(f"Cipher suite: {cipher[0]} ({cipher[1]})")
            # Subject / SANs
            subject = dict(x[0] for x in cert.get("subject", []))
            info(f"Cert CN     : {subject.get('commonName', 'n/a')}")
            san_list = [v for t, v in cert.get("subjectAltName", []) if t == "DNS"]
            if san_list:
                info(f"Cert SANs   : {', '.join(san_list)}")
            info(f"Cert expires: {cert.get('notAfter', 'unknown')}")
    except ssl.SSLCertVerificationError as e:
        fail(f"SSL certificate verification failed: {e}")
        print(f"""
  DIAGNOSIS: The server's TLS certificate is not trusted.
  ─────────────────────────────────────────────────────────
  Error detail: {e}

  Common causes & fixes:
  1. Self-signed certificate
     → Change your URI scheme from 'neo4j+s' to 'neo4j+ssc'
       (or 'bolt+s' → 'bolt+ssc') to skip cert verification.
  2. Certificate expired
     → Contact your Neo4j Aura / server admin to renew the cert.
  3. Wrong hostname in cert (CN/SAN mismatch)
     → Check that NEO4J_URI hostname matches the cert's CN or SAN.
  4. Custom / corporate CA not trusted
     → Install the CA cert into your system trust store, or set:
         NEO4J_DRIVER_TRUST=TRUST_CUSTOM_CA_SIGNED_CERTIFICATES
""")
        sys.exit(1)
    except ssl.SSLError as e:
        fail(f"TLS/SSL handshake error: {e}")
        print(f"""
  DIAGNOSIS: TLS negotiation failed.
  ─────────────────────────────────────────────
  Error detail: {e}
  SSL error number: {e.errno}

  Possible causes:
  • Protocol version mismatch (server may require TLS 1.2+ )
  • Cipher suite incompatibility
  • The server is not actually using TLS on this port
    → Try the plain 'bolt://' or 'neo4j://' scheme instead.
""")
        sys.exit(1)
elif uses_tls and uses_self_signed:
    section("STEP 4 — TLS / SSL Certificate Verification")
    warn(f"Skipping cert verification because scheme '{scheme}' trusts self-signed certs.")
else:
    section("STEP 4 — TLS / SSL Certificate Verification")
    info("Skipped — connection is not encrypted (plain bolt:// or neo4j://).")

# ── Step 5: Neo4j driver connection ──────────────────────────────────────────

section("STEP 5 — Neo4j Driver Connection")
try:
    from neo4j import GraphDatabase
    from neo4j.exceptions import (
        AuthError,
        ServiceUnavailable,
        ConfigurationError,
        Neo4jError,
    )
except ImportError:
    fail("neo4j Python package is not installed.")
    print("  Fix: pip install neo4j")
    sys.exit(1)

driver = None
try:
    driver = GraphDatabase.driver(
        NEO4J_URI,
        auth=(NEO4J_USERNAME, NEO4J_PASSWORD),
        connection_timeout=15,
        max_connection_lifetime=300,
    )
    driver.verify_connectivity()
    ok("Driver created and connectivity verified")
except AuthError as e:
    fail(f"Authentication failed: {e}")
    print(f"""
  DIAGNOSIS: Wrong username or password.
  ─────────────────────────────────────────────
  • Check NEO4J_USERNAME and NEO4J_PASSWORD in your .env
  • For Neo4j Aura the username is always 'neo4j'; password is from
    the Aura console (shown once at instance creation).
  • For local Neo4j, default creds are neo4j / neo4j (you must
    change the password on first login).
  Neo4j error: {e.code if hasattr(e, 'code') else 'N/A'}
""")
    sys.exit(1)
except ServiceUnavailable as e:
    fail(f"Neo4j service unavailable: {e}")
    print(f"""
  DIAGNOSIS: Driver connected at the TCP level but Neo4j Bolt
  protocol handshake failed or the service is starting up.
  ─────────────────────────────────────────────────────────────
  • If the database is still booting, wait a few seconds and retry.
  • Verify the correct bolt port (default 7687) in NEO4J_URI.
  • For Aura, confirm the instance status is 'Running' in the console.
  Detail: {e}
""")
    sys.exit(1)
except ConfigurationError as e:
    fail(f"Driver configuration error: {e}")
    print(f"""
  DIAGNOSIS: The Neo4j URI or driver options are invalid.
  ─────────────────────────────────────────────────────────
  • Check that the scheme is one of:
    bolt, bolt+s, bolt+ssc, neo4j, neo4j+s, neo4j+ssc
  • Example Aura URI: neo4j+s://xxxxxxxx.databases.neo4j.io
  • Example local URI: bolt://localhost:7687
  Detail: {e}
""")
    sys.exit(1)
except Neo4jError as e:
    fail(f"Neo4j error: {e}")
    info(f"  Code   : {e.code if hasattr(e, 'code') else 'N/A'}")
    info(f"  Message: {e.message if hasattr(e, 'message') else str(e)}")
    traceback.print_exc()
    sys.exit(1)
except Exception as e:
    fail(f"Unexpected error: {type(e).__name__}: {e}")
    traceback.print_exc()
    sys.exit(1)

# ── Step 6: Server info ───────────────────────────────────────────────────────

section("STEP 6 — Server Information")
try:
    with driver.session() as session:
        result = session.run(
            "CALL dbms.components() YIELD name, versions, edition "
            "RETURN name, versions[0] AS version, edition"
        )
        for record in result:
            ok(f"{record['name']} {record['version']} ({record['edition']} edition)")
except Exception as e:
    warn(f"Could not retrieve server info (non-fatal): {e}")

# ── Step 7: Simple read query ─────────────────────────────────────────────────

section("STEP 7 — Simple Read Query")
try:
    with driver.session() as session:
        result = session.run("RETURN 1 AS ping, timestamp() AS ts")
        row = result.single()
        ok(f"Query OK — ping={row['ping']}, server timestamp={row['ts']}")
except Exception as e:
    fail(f"Read query failed: {e}")
    traceback.print_exc()

# ── Step 8: Node count (data presence check) ─────────────────────────────────

section("STEP 8 — Data Presence Check")
try:
    with driver.session() as session:
        result = session.run("MATCH (n) RETURN count(n) AS total_nodes")
        total = result.single()["total_nodes"]
        if total == 0:
            warn(f"Database is empty (0 nodes). Have you run populate_kg.py?")
        else:
            ok(f"Database contains {total} nodes")

        # Per-label counts
        label_result = session.run(
            "CALL apoc.meta.stats() YIELD labels "
            "RETURN labels"
        )
        row = label_result.single()
        if row:
            labels = row["labels"]
            for label, count in sorted(labels.items()):
                info(f"  {label}: {count} nodes")
except Exception as e:
    # apoc may not be installed — fallback to manual count
    try:
        with driver.session() as session:
            label_result = session.run(
                "CALL db.labels() YIELD label "
                "CALL apoc.cypher.run('MATCH (n:`' + label + '`) RETURN count(n) AS c', {}) "
                "YIELD value RETURN label, value.c AS count"
            )
    except Exception:
        pass  # apoc not available — basic check already done above

# ── Done ──────────────────────────────────────────────────────────────────────

driver.close()

section("RESULT")
ok("All checks passed — Neo4j connection is healthy!")
print()
