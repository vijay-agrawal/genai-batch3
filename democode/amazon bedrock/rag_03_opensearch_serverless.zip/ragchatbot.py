"""
ragchatbot.py
RAG chatbot:
  1. Accepts a question from the user.
  2. Retrieves relevant document chunks from a Bedrock Knowledge Base.
  3. Passes the question + context to Amazon Nova (via Bedrock) for a grounded answer.
"""

import json
import os
import sys

import boto3
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))

# ── Configuration ─────────────────────────────────────────────────────────────
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
MAX_TOKENS = int(os.getenv("BEDROCK_MAX_TOKENS", "512"))
TEMPERATURE = float(os.getenv("BEDROCK_TEMPERATURE", "0.7"))
TOP_K_RESULTS = 5

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kb_config.json")

SYSTEM_PROMPT = (
    "You are a helpful AI assistant. Answer questions strictly based on the "
    "provided context documents. Be concise and accurate. If the context does "
    "not contain enough information to answer, say so clearly."
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_config():
    if not os.path.exists(CONFIG_FILE):
        print("Error: kb_config.json not found. Run indexer.py first.")
        sys.exit(1)
    with open(CONFIG_FILE) as f:
        return json.load(f)


def retrieve(bedrock_agent_runtime, kb_id, question):
    """Retrieve the top-K relevant chunks from the knowledge base."""
    response = bedrock_agent_runtime.retrieve(
        knowledgeBaseId=kb_id,
        retrievalQuery={"text": question},
        retrievalConfiguration={
            "vectorSearchConfiguration": {"numberOfResults": TOP_K_RESULTS}
        },
    )
    return response.get("retrievalResults", [])


def build_prompt(question, results):
    """Combine retrieved chunks into a single prompt."""
    context_blocks = []
    for i, r in enumerate(results, 1):
        text = r["content"]["text"]
        uri = r.get("location", {}).get("s3Location", {}).get("uri", "unknown")
        source = uri.split("/")[-1] if "/" in uri else uri
        context_blocks.append(f"[Document {i} – {source}]\n{text}")

    context = "\n\n".join(context_blocks)
    return (
        f"Answer the following question using ONLY the context documents below.\n\n"
        f"--- CONTEXT ---\n{context}\n--- END CONTEXT ---\n\n"
        f"Question: {question}"
    )


def invoke_nova(bedrock_runtime, prompt):
    """Call the Amazon Nova model and return the generated text."""
    body = {
        "messages": [{"role": "user", "content": [{"text": prompt}]}],
        "system": [{"text": SYSTEM_PROMPT}],
        "inferenceConfig": {
            "maxTokens": MAX_TOKENS,
            "temperature": TEMPERATURE,
        },
    }
    response = bedrock_runtime.invoke_model(
        modelId=MODEL_ID,
        body=json.dumps(body),
        contentType="application/json",
        accept="application/json",
    )
    result = json.loads(response["body"].read())
    return result["output"]["message"]["content"][0]["text"]


# ── Sample question menu ───────────────────────────────────────────────────────

MENU_QUESTIONS = [
    # ── Questions that showcase RAG VALUE ──────────────────────────────────────
    # These require private/internal documents the LLM was never trained on.
    (
        "RAG VALUE",
        "What is ABC Bank's 1-day VaR limit for the FX Trading desk, and what "
        "happens if a trader breaches it intraday?",
    ),
    (
        "RAG VALUE",
        "If ABC Bank records 7 VaR exceptions in the trailing 250 trading days, "
        "what capital multiplication factor applies and what zone is the bank in?",
    ),
    (
        "RAG VALUE",
        "Which patients at City General Hospital are currently on Warfarin, and "
        "are there any dangerous drug interactions in their current medication lists?",
    ),
    (
        "RAG VALUE",
        "What 12-month stress period does ABC Bank use for its Stressed VaR "
        "calculation, and why was that period chosen?",
    ),
    (
        "RAG VALUE",
        "Under RBI guidelines, within how many business days must a bank report "
        "a VaR exception, and what information must be included in the report?",
    ),
    (
        "RAG VALUE",
        "Patient Lakshmi Devi is on Furosemide and Digoxin. Based on her latest "
        "lab results, is there a clinical risk the doctor should address urgently?",
    ),
    (
        "RAG VALUE",
        "What reverse stress test scenario would reduce ABC Bank's CET1 ratio "
        "below its internal threshold, and what is the estimated loss?",
    ),
    # ── Questions that expose RAG LIMITATIONS ──────────────────────────────────
    # These reveal where retrieval-augmented generation struggles.
    (
        "RAG LIMITATION",
        "What is the Nifty 50 index level today, and how does it affect ABC "
        "Bank's current VaR?",
        # Limitation: RAG has no real-time market data; static documents only.
    ),
    (
        "RAG LIMITATION",
        "Comparing all the CVs in the knowledge base, who is the strongest "
        "candidate for a Market Risk Analyst role at ABC Bank?",
        # Limitation: Multi-document synthesis + subjective judgment; retrieval
        # fetches only top-K chunks and may miss key CV sections entirely.
    ),
    (
        "RAG LIMITATION",
        "Will ABC Bank be in the Yellow or Red backtesting zone by end of this "
        "financial year?",
        # Limitation: Predictive question — RAG cannot forecast future outcomes.
    ),
    (
        "RAG LIMITATION",
        "Summarise everything in the knowledge base.",
        # Limitation: Top-K retrieval cannot surface all documents; answer will
        # be incomplete and reflect only the chunks nearest to the query vector.
    ),
    (
        "RAG LIMITATION",
        "Is Rohan Desai's current lithium level safe, and should his doctor "
        "adjust the dose?",
        # Limitation: Requires clinical judgment beyond what's in the document;
        # RAG can surface data but cannot replace specialist medical reasoning.
    ),
]


def show_menu():
    """Print the sample question menu and return the chosen question string."""
    print("\n" + "=" * 70)
    print("  SAMPLE QUESTIONS  (select a number, or press Enter to type your own)")
    print("=" * 70)

    for i, entry in enumerate(MENU_QUESTIONS, 1):
        tag = entry[0]
        question = entry[1]
        label = f"[{tag}]"
        # Wrap the question text at 60 chars for readability
        prefix = f"  {i:>2}. {label:<18} "
        indent = " " * len(prefix)
        words = question.split()
        lines, current = [], ""
        for word in words:
            if len(current) + len(word) + 1 <= 60:
                current = (current + " " + word).strip()
            else:
                lines.append(current)
                current = word
        if current:
            lines.append(current)
        print(prefix + lines[0])
        for line in lines[1:]:
            print(indent + line)

    print("=" * 70)
    print("   0. Quit")
    print("=" * 70)

    choice = input("\nSelect [0-{}] or press Enter to type your own: ".format(len(MENU_QUESTIONS))).strip()

    if choice == "0":
        return None  # signal quit

    if choice.isdigit() and 1 <= int(choice) <= len(MENU_QUESTIONS):
        selected = MENU_QUESTIONS[int(choice) - 1]
        question = selected[1]
        tag = selected[0]
        print(f"\n[Selected ({tag})]\nYou: {question}")
        return question

    return ""  # empty → caller will prompt for free-text input


# ── Chat loop ─────────────────────────────────────────────────────────────────

def chat(kb_id):
    agent_rt = boto3.client("bedrock-agent-runtime", region_name=AWS_REGION)
    bedrock_rt = boto3.client("bedrock-runtime", region_name=AWS_REGION)

    print(f"\n=== RAG Chatbot  |  model: {MODEL_ID} ===")
    print("Type your question and press Enter. Type 'quit' to exit.")
    print("Tip: Press Enter at the prompt to see a menu of sample questions.\n")

    while True:
        try:
            question = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not question:
            # Show the interactive menu
            result = show_menu()
            if result is None:
                print("Goodbye!")
                break
            question = result
            if not question:
                # User pressed Enter again — go back to free-text prompt
                continue

        if question.lower() in ("quit", "exit", "q"):
            print("Goodbye!")
            break

        # ── Retrieval ──
        print("\n[Retrieving relevant context...]")
        results = retrieve(agent_rt, kb_id, question)

        if not results:
            print("Assistant: No relevant documents found in the knowledge base.\n")
            continue

        sources = sorted({
            r.get("location", {}).get("s3Location", {}).get("uri", "?").split("/")[-1]
            for r in results
        })
        print(f"[Found {len(results)} chunks from: {', '.join(sources)}]")

        # ── Generation ──
        prompt = build_prompt(question, results)
        answer = invoke_nova(bedrock_rt, prompt)

        print(f"\nAssistant: {answer}\n")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    config = load_config()
    chat(config["knowledge_base_id"])
