"""
indexer.py
1. Creates an IAM role for Bedrock Knowledge Base.
2. Creates an Amazon OpenSearch Serverless (AOSS) vector collection.
3. Creates a Bedrock Knowledge Base backed by that collection.
4. Adds an S3 data source and triggers ingestion.
5. Saves the resulting IDs to kb_config.json for use by ragchatbot.py.

PRE-REQUISITES
==============

1. Run data_uploader.py first:
       python data_uploader.py
   This uploads your source documents to S3 so Bedrock can ingest them.

2. Install dependencies:
       pip install boto3 python-dotenv opensearch-py requests-aws4auth

3. Set the following variables in the .env file (located one level up, in ragdemo/.env):

   Required:
     S3_BUCKET_NAME                 - S3 bucket that holds the documents to index
                                      (created and populated by data_uploader.py)

   Optional (defaults shown):
     AWS_REGION                     - AWS region to deploy resources (default: us-east-1)
     OPENSEARCH_COLLECTION_NAME     - Name of the AOSS vector collection (default: ragdemo-coll)
     BEDROCK_KB_NAME                - Name of the Bedrock Knowledge Base (default: ragdemo-kb)
     BEDROCK_EMBEDDING_MODEL        - Embedding model ID (default: amazon.titan-embed-text-v2:0)

4. Ensure your AWS credentials are configured (via ~/.aws/credentials, environment variables,
   or an IAM role) with permissions for: IAM, S3, OpenSearch Serverless, and Bedrock Agent.

5. After this script completes it writes kb_config.json — required by ragchatbot.py.
"""

import json
import os
import time

import boto3
from botocore.exceptions import ClientError
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))

# ── Configuration ─────────────────────────────────────────────────────────────
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME")
COLLECTION_NAME = os.getenv("OPENSEARCH_COLLECTION_NAME", "ragdemo-coll")
KB_NAME = os.getenv("BEDROCK_KB_NAME", "ragdemo-kb")
EMBEDDING_MODEL_ID = os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0")

# OpenSearch index / field names expected by Bedrock Knowledge Base
INDEX_NAME = "bedrock-kb-index"
VECTOR_FIELD = "bedrock-knowledge-base-default-vector"
TEXT_FIELD = "AMAZON_BEDROCK_TEXT_CHUNK"
METADATA_FIELD = "AMAZON_BEDROCK_METADATA"
VECTOR_DIMENSION = 1024  # titan-embed-text-v2 default

KB_ROLE_NAME = "BedrockKBRole"
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kb_config.json")


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_account_and_caller():
    sts = boto3.client("sts", region_name=AWS_REGION)
    identity = sts.get_caller_identity()
    return identity["Account"], identity["Arn"]


# ── Step 1 – IAM Role ─────────────────────────────────────────────────────────

def create_kb_iam_role(iam, account_id, bucket_name):
    trust_policy = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "bedrock.amazonaws.com"},
            "Action": "sts:AssumeRole",
        }],
    }
    try:
        role = iam.create_role(
            RoleName=KB_ROLE_NAME,
            AssumeRolePolicyDocument=json.dumps(trust_policy),
            Description="IAM role for Bedrock Knowledge Base",
        )
        role_arn = role["Role"]["Arn"]
        print(f"  Created IAM role: {role_arn}")
    except ClientError as e:
        if e.response["Error"]["Code"] == "EntityAlreadyExists":
            role_arn = iam.get_role(RoleName=KB_ROLE_NAME)["Role"]["Arn"]
            print(f"  IAM role already exists: {role_arn}")
        else:
            raise

    inline_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": ["bedrock:InvokeModel"],
                "Resource": f"arn:aws:bedrock:{AWS_REGION}::foundation-model/*",
            },
            {
                "Effect": "Allow",
                "Action": ["s3:GetObject", "s3:ListBucket"],
                "Resource": [
                    f"arn:aws:s3:::{bucket_name}",
                    f"arn:aws:s3:::{bucket_name}/*",
                ],
            },
            {
                "Effect": "Allow",
                "Action": ["aoss:APIAccessAll"],
                "Resource": f"arn:aws:aoss:{AWS_REGION}:{account_id}:collection/*",
            },
        ],
    }
    iam.put_role_policy(
        RoleName=KB_ROLE_NAME,
        PolicyName="BedrockKBInlinePolicy",
        PolicyDocument=json.dumps(inline_policy),
    )
    print("  Inline policy attached.")
    return role_arn


# ── Step 2 – AOSS Security & Access Policies ──────────────────────────────────

def _upsert_policy(aoss, *, create_fn, name, **kwargs):
    try:
        create_fn(name=name, **kwargs)
        print(f"  Created policy: {name}")
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConflictException":
            print(f"  Policy already exists: {name}")
        else:
            raise


def create_aoss_policies(aoss, collection_name, role_arn, caller_arn):
    # Encryption policy (mandatory)
    _upsert_policy(
        aoss,
        create_fn=aoss.create_security_policy,
        name=f"{collection_name}-enc",
        type="encryption",
        policy=json.dumps({
            "Rules": [{"Resource": [f"collection/{collection_name}"], "ResourceType": "collection"}],
            "AWSOwnedKey": True,
        }),
    )

    # Network policy – allow public access so Bedrock can reach the collection
    _upsert_policy(
        aoss,
        create_fn=aoss.create_security_policy,
        name=f"{collection_name}-net",
        type="network",
        policy=json.dumps([{
            "Rules": [
                {"Resource": [f"collection/{collection_name}"], "ResourceType": "collection"},
                {"Resource": [f"collection/{collection_name}"], "ResourceType": "dashboard"},
            ],
            "AllowFromPublic": True,
        }]),
    )

    # Data access policy – grant both the KB role and the current caller full index access
    _upsert_policy(
        aoss,
        create_fn=aoss.create_access_policy,
        name=f"{collection_name}-acc",
        type="data",
        policy=json.dumps([{
            "Rules": [
                {
                    "Resource": [f"index/{collection_name}/*"],
                    "Permission": [
                        "aoss:CreateIndex", "aoss:DeleteIndex", "aoss:UpdateIndex",
                        "aoss:DescribeIndex", "aoss:ReadDocument", "aoss:WriteDocument",
                    ],
                    "ResourceType": "index",
                },
                {
                    "Resource": [f"collection/{collection_name}"],
                    "Permission": [
                        "aoss:CreateCollectionItems", "aoss:DeleteCollectionItems",
                        "aoss:UpdateCollectionItems", "aoss:DescribeCollectionItems",
                    ],
                    "ResourceType": "collection",
                },
            ],
            "Principal": [role_arn, caller_arn],
            "Description": "Bedrock KB and admin access",
        }]),
    )


# ── Step 3 – AOSS Collection ──────────────────────────────────────────────────

def create_aoss_collection(aoss, collection_name):
    try:
        resp = aoss.create_collection(
            name=collection_name,
            type="VECTORSEARCH",
            description="RAG demo vector store",
        )
        detail = resp["createCollectionDetail"]
        print(f"  Collection creation initiated (id={detail['id']})")
        return detail["id"], detail["arn"]
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConflictException":
            print("  Collection already exists – fetching details...")
            summaries = aoss.list_collections(
                collectionFilters={"name": collection_name}
            )["collectionSummaries"]
            coll = summaries[0]
            return coll["id"], coll["arn"]
        raise


def wait_for_collection_active(aoss, collection_id, timeout=720):
    print("  Waiting for ACTIVE status (may take 5-10 min)...")
    deadline = time.time() + timeout
    while time.time() < deadline:
        details = aoss.batch_get_collection(ids=[collection_id])["collectionDetails"]
        if details:
            status = details[0]["status"]
            print(f"    status: {status}")
            if status == "ACTIVE":
                endpoint = details[0]["collectionEndpoint"]
                print(f"  Collection active. Endpoint: {endpoint}")
                return endpoint
            if status == "FAILED":
                raise RuntimeError(f"Collection failed: {details[0]}")
        time.sleep(30)
    raise TimeoutError("Collection did not reach ACTIVE within the timeout.")


# ── Step 4 – Vector Index ─────────────────────────────────────────────────────

def create_vector_index(endpoint, index_name):
    try:
        from opensearchpy import AWSV4SignerAuth, OpenSearch, RequestsHttpConnection
    except ImportError:
        raise ImportError("Run: pip install opensearch-py")

    credentials = boto3.Session().get_credentials()
    auth = AWSV4SignerAuth(credentials, AWS_REGION, "aoss")
    host = endpoint.replace("https://", "")

    client = OpenSearch(
        hosts=[{"host": host, "port": 443}],
        http_auth=auth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection,
        pool_maxsize=20,
    )

    if client.indices.exists(index=index_name):
        print(f"  Vector index '{index_name}' already exists.")
        return

    client.indices.create(
        index=index_name,
        body={
            "settings": {"index.knn": True},
            "mappings": {
                "properties": {
                    VECTOR_FIELD: {
                        "type": "knn_vector",
                        "dimension": VECTOR_DIMENSION,
                        "method": {"engine": "faiss", "name": "hnsw", "parameters": {}},
                    },
                    TEXT_FIELD: {"type": "text"},
                    METADATA_FIELD: {"type": "text", "index": False},
                }
            },
        },
    )
    print(f"  Created vector index: {index_name}")


# ── Step 5 – Bedrock Knowledge Base ───────────────────────────────────────────

def create_knowledge_base(bedrock_agent, role_arn, collection_arn):
    embedding_arn = f"arn:aws:bedrock:{AWS_REGION}::foundation-model/{EMBEDDING_MODEL_ID}"

    for kb in bedrock_agent.list_knowledge_bases(maxResults=50).get("knowledgeBaseSummaries", []):
        if kb["name"] == KB_NAME:
            print(f"  Knowledge base already exists: {kb['knowledgeBaseId']}")
            return kb["knowledgeBaseId"]

    resp = bedrock_agent.create_knowledge_base(
        name=KB_NAME,
        description="RAG demo knowledge base",
        roleArn=role_arn,
        knowledgeBaseConfiguration={
            "type": "VECTOR",
            "vectorKnowledgeBaseConfiguration": {"embeddingModelArn": embedding_arn},
        },
        storageConfiguration={
            "type": "OPENSEARCH_SERVERLESS",
            "opensearchServerlessConfiguration": {
                "collectionArn": collection_arn,
                "vectorIndexName": INDEX_NAME,
                "fieldMapping": {
                    "vectorField": VECTOR_FIELD,
                    "textField": TEXT_FIELD,
                    "metadataField": METADATA_FIELD,
                },
            },
        },
    )
    kb_id = resp["knowledgeBase"]["knowledgeBaseId"]
    print(f"  Created knowledge base: {kb_id}")
    return kb_id


# ── Step 6 – Data Source + Ingestion ──────────────────────────────────────────

def create_data_source(bedrock_agent, kb_id, bucket_name):
    ds_name = "s3-data-source"
    for ds in bedrock_agent.list_data_sources(knowledgeBaseId=kb_id, maxResults=50).get("dataSourceSummaries", []):
        if ds["name"] == ds_name:
            print(f"  Data source already exists: {ds['dataSourceId']}")
            return ds["dataSourceId"]

    resp = bedrock_agent.create_data_source(
        knowledgeBaseId=kb_id,
        name=ds_name,
        description="S3 document store for RAG demo",
        dataSourceConfiguration={
            "type": "S3",
            "s3Configuration": {"bucketArn": f"arn:aws:s3:::{bucket_name}"},
        },
        vectorIngestionConfiguration={
            "chunkingConfiguration": {
                "chunkingStrategy": "FIXED_SIZE",
                "fixedSizeChunkingConfiguration": {
                    "maxTokens": 512,
                    "overlapPercentage": 20,
                },
            }
        },
    )
    ds_id = resp["dataSource"]["dataSourceId"]
    print(f"  Created data source: {ds_id}")
    return ds_id


def start_and_wait_ingestion(bedrock_agent, kb_id, ds_id, timeout=600):
    job_id = bedrock_agent.start_ingestion_job(
        knowledgeBaseId=kb_id, dataSourceId=ds_id
    )["ingestionJob"]["ingestionJobId"]
    print(f"  Ingestion job started: {job_id}")

    deadline = time.time() + timeout
    while time.time() < deadline:
        job = bedrock_agent.get_ingestion_job(
            knowledgeBaseId=kb_id, dataSourceId=ds_id, ingestionJobId=job_id
        )["ingestionJob"]
        status = job["status"]
        stats = job.get("statistics", {})
        print(f"    status: {status} | stats: {stats}")
        if status == "COMPLETE":
            print("  Ingestion complete!")
            return
        if status in ("FAILED", "STOPPED"):
            raise RuntimeError(f"Ingestion failed: {job.get('failureReasons', [])}")
        time.sleep(20)
    raise TimeoutError("Ingestion did not complete within the timeout.")


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not S3_BUCKET_NAME:
        print("Error: S3_BUCKET_NAME is not set in .env")
        raise SystemExit(1)

    print("=== RAG Demo – Indexer ===\n")

    account_id, caller_arn = get_account_and_caller()
    print(f"Account : {account_id}")
    print(f"Caller  : {caller_arn}\n")

    iam = boto3.client("iam", region_name=AWS_REGION)
    aoss = boto3.client("opensearchserverless", region_name=AWS_REGION)
    bedrock_agent = boto3.client("bedrock-agent", region_name=AWS_REGION)

    print("[1/6] Creating IAM role for Knowledge Base...")
    role_arn = create_kb_iam_role(iam, account_id, S3_BUCKET_NAME)

    print("\n[2/6] Creating OpenSearch Serverless policies...")
    create_aoss_policies(aoss, COLLECTION_NAME, role_arn, caller_arn)

    print("\n[3/6] Creating OpenSearch Serverless collection...")
    collection_id, collection_arn = create_aoss_collection(aoss, COLLECTION_NAME)

    print("\n[4/6] Waiting for collection to become active...")
    endpoint = wait_for_collection_active(aoss, collection_id)

    print("\n[5/6] Creating vector index in collection...")
    time.sleep(15)  # brief delay after collection becomes active
    create_vector_index(endpoint, INDEX_NAME)

    print("\n[6/6] Creating Bedrock Knowledge Base, data source, and ingesting documents...")
    time.sleep(15)  # allow IAM role propagation
    kb_id = create_knowledge_base(bedrock_agent, role_arn, collection_arn)
    ds_id = create_data_source(bedrock_agent, kb_id, S3_BUCKET_NAME)
    start_and_wait_ingestion(bedrock_agent, kb_id, ds_id)

    # Persist IDs for the chatbot
    config = {
        "knowledge_base_id": kb_id,
        "data_source_id": ds_id,
        "collection_arn": collection_arn,
        "region": AWS_REGION,
    }
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

    print(f"\n=== Done! Configuration saved to kb_config.json ===")
    print(f"Knowledge Base ID : {kb_id}")
    print("Run ragchatbot.py to start chatting.")
