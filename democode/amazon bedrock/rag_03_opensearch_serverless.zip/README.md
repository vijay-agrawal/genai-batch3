# RAG Demo — AWS Console Setup Guide

This guide walks through building the full RAG (Retrieval-Augmented Generation) pipeline
entirely through the AWS Management Console, covering:

- IAM permissions for your user and for the Knowledge Base service role
- S3 bucket creation and document upload
- Amazon OpenSearch Serverless vector collection
- Amazon Bedrock Knowledge Base creation and document ingestion
- Retrieval testing directly in the console

---

> **COST WARNING — Read before proceeding**
>
> Amazon OpenSearch Serverless charges for **OpenSearch Compute Units (OCUs)** continuously,
> even when idle. The minimum is **2 OCUs at all times** (one for indexing, one for search),
> which costs approximately **$0.48/hr (~$350/month)** regardless of whether any queries are made.
>
> **Delete the collection when you are done with this demo** to stop incurring charges.
> See the [Cleanup and Teardown](#cleanup-and-teardown) section at the bottom of this guide
> for step-by-step deletion instructions.
>
> If cost is a concern, consider the [S3 Vectors setup](../s3vectors/README.md) instead —
> it has no minimum capacity and costs essentially nothing for a small demo.

---

## RAG Vector Store Options on AWS

When building a RAG pipeline on AWS with Amazon Bedrock Knowledge Bases, you have several
choices for where to store and query your vectors. Each option has different trade-offs
around cost, operational overhead, scalability, and query capabilities.

### Available Vector Store Options

| Vector Store | Type | Best For |
|---|---|---|
| **Amazon S3 Vectors** | Serverless, pay-per-request | Dev/demo, low traffic, cost-sensitive workloads |
| **Amazon OpenSearch Serverless** | Serverless, OCU-based | Production, full-text + vector hybrid search |
| **Amazon OpenSearch Service** (managed) | Managed cluster | High-throughput production, fine-grained control |
| **Amazon Aurora PostgreSQL** (pgvector) | Managed relational DB | Apps already on RDS/Aurora; SQL + vector in one DB |
| **Amazon Neptune Analytics** | Graph + vector | Knowledge graphs, relationship-aware retrieval |
| **Pinecone** (via partner) | Third-party SaaS | Pinecone-native workloads already in use |
| **MongoDB Atlas** (via partner) | Third-party SaaS | Existing MongoDB users, document + vector search |
| **Redis** (via partner) | Third-party SaaS | Ultra-low latency, in-memory vector search |

---

### Comparison Table

| Feature | S3 Vectors | OpenSearch Serverless | OpenSearch Managed | Aurora pgvector | Neptune Analytics |
|---|---|---|---|---|---|
| **Operational overhead** | None | None | Medium | Low | Low |
| **Minimum cost (idle)** | ~$0.00 | ~$0.48/hr (2 OCU min) | Depends on instance | Depends on instance | Depends on instance |
| **Pricing model** | Per request + storage | OCU-hours | Instance + storage | Instance + storage | NCU-hours |
| **Hybrid search** (vector + keyword) | No | Yes | Yes | No | No |
| **Metadata filtering** | Yes | Yes | Yes | Yes (SQL WHERE) | Yes |
| **Scales to zero** | Yes | Yes | No | No (Aurora Serverless v2: partial) | No |
| **Multi-AZ / HA** | Yes (S3-native) | Yes | Yes (multi-node) | Yes | Yes |
| **Max vector dimensions** | 4096 | 16000 | 16000 | 2000 (pgvector default) | 65535 |
| **SQL / structured queries alongside vectors** | No | No | No | Yes | No |
| **Graph traversal** | No | No | No | No | Yes |
| **Bedrock Knowledge Base integration** | Native | Native | Native | Native | Native |
| **GA status** | GA (Dec 2025) | GA | GA | GA | GA |

> **OCU (OpenSearch Compute Unit):** The billing unit for Amazon OpenSearch Serverless.
> Each OCU represents a fixed amount of compute and memory. OpenSearch Serverless requires
> a minimum of **2 OCUs** at all times (one for indexing, one for search) — even when idle —
> which is why the minimum cost is ~$0.48/hr regardless of actual usage.

### When to choose what

- **S3 Vectors** — starting out, demos, cost is a primary concern, no need for hybrid search
- **OpenSearch Serverless** — production RAG with hybrid (keyword + semantic) search, no infra management
- **OpenSearch Managed** — very high query throughput, custom plugins, or existing OpenSearch clusters
- **Aurora pgvector** — your application already uses PostgreSQL/Aurora and you want vectors without a new service
- **Neptune Analytics** — documents have rich relationships (e.g., org charts, knowledge graphs) that matter for retrieval

---

## Architecture Overview

```
Your Documents (local)
        │
        ▼
  S3 Bucket (raw files)
        │   ← Bedrock reads & chunks documents
        ▼
  Bedrock Knowledge Base
        │   ← embeds chunks with Titan Embed Text v2
        ▼
  OpenSearch Serverless (vector store)
        │
        ▼
  Bedrock retrieve() API  ──► Amazon Nova (reasoning & formatting)
```

---

## OpenSearch Serverless vs OpenSearch Service — Key Terminology

| Concept | OpenSearch Service (managed) | OpenSearch Serverless |
|---|---|---|
| Top-level resource | **Domain** | **Collection** |
| Provisioning | You choose instance type and count | AWS manages it automatically |
| Minimum cost | Based on instance running time | 2 OCUs minimum (~$0.48/hr) |
| Index creation | You create indexes directly | You create indexes inside a collection |
| Security | Domain-level access policy | Separate encryption / network / data access policies |

> **Important:** OpenSearch Serverless does **not** use the term "domain". If you are familiar with
> managed OpenSearch Service, replace "domain" with "collection" when working with Serverless.
> A **collection** is the serverless equivalent of a domain — it is the container that holds your indexes.

---

## Why OpenSearch Serverless? — Hybrid Search (Text + Vector)

The primary value proposition of OpenSearch Serverless over simpler vector stores (like S3 Vectors
or ChromaDB) is **hybrid search**: the ability to combine semantic vector similarity with traditional
full-text keyword search in a single query.

### The problem with pure vector search

Vector search finds chunks that are *semantically similar* to a query — it understands meaning and
paraphrasing. But it can miss exact matches. This surprises people because they assume: *"if the
exact term appears in both the query and the chunk, the embeddings should be similar."*

That is not how embeddings work.

**Why an exact term match does not guarantee high cosine similarity:**

An embedding model converts an entire chunk of text into a single fixed-size vector (e.g., 1024
numbers). That vector is a compressed representation of the *overall semantic meaning* of the whole
chunk — it is not a lookup table of which words are present. Every token in the chunk influences
the final vector, so a specific code like "Article 92" is just one signal among hundreds of others.
Its contribution to the final vector is diluted by all the surrounding text.

**Concrete example:**

Query: _"BASEL III Article 92 capital ratio"_

| | Chunk A | Chunk B |
|---|---|---|
| **Text** | "Article 92 of BASEL III requires banks to maintain a minimum CET1 ratio of 4.5% of risk-weighted assets." | "Banks must maintain adequate capital buffers to ensure financial stability and meet all regulatory solvency requirements." |
| **Contains exact term "Article 92"?** | Yes | No |
| **Embedding similarity to query** | Lower | Higher |
| **Why** | "Article 92" and "CET1" are rare, specific tokens that shift the vector toward a technical/numerical space. The surrounding context is narrow. | Dense with semantically rich terms — "capital", "buffers", "regulatory", "solvency" — which overlap heavily with the embedding cloud of the query. |

The embedding model has seen "capital", "buffers", "regulatory requirements" millions of times in
training in contexts very similar to the query. It has seen "Article 92" far less often, so that
specific reference has weaker representation in the embedding space. The cosine angle between
Chunk B's vector and the query vector ends up smaller (more similar) than Chunk A's, even though
Chunk A contains the exact term and Chunk B does not.

**BM25 handles this correctly** because it works purely on term frequency — "Article 92" appearing
in both the query and Chunk A produces a direct, guaranteed relevance signal regardless of
surrounding context. This is exactly what hybrid search combines: BM25 rescues the exact-match
cases that vector search misses.

> **What does BM25 stand for?** Best Match 25. It is the 25th iteration of a probabilistic
> relevance ranking function developed at the University of London through the 1970s–90s.
> The algorithm scores documents by how often query terms appear in them (term frequency),
> discounted by how common those terms are across all documents (inverse document frequency),
> with adjustments for document length. It is the default full-text ranking algorithm in
> OpenSearch, Elasticsearch, and most modern search engines.

Full-text (BM25) keyword search, on the other hand, is precise about exact terms but has no
semantic understanding — it cannot match synonyms or paraphrasing.

### How hybrid search works in OpenSearch

OpenSearch supports both search types natively in the same index and same query:

```
User query
    │
    ├──► BM25 (keyword/lexical search)  ──► ranked list of chunks by keyword relevance
    │
    └──► kNN (vector/semantic search)   ──► ranked list of chunks by embedding similarity
                │
                ▼
        Reciprocal Rank Fusion (RRF)
        Combines both ranked lists into a single merged score
                │
                ▼
        Top-k chunks returned to Bedrock Knowledge Base → LLM
```

**Reciprocal Rank Fusion (RRF)** is the standard algorithm used to merge two ranked lists without
needing to tune weights — a chunk that ranks highly in both lists rises to the top naturally.

### When hybrid search wins over pure vector search

| Query type | Pure vector | Hybrid |
|---|---|---|
| Conceptual / semantic ("explain capital adequacy") | Good | Good |
| Exact terms / codes ("BASEL III Article 92") | Can miss | Catches it via BM25 |
| Named entities ("HDFC Q3 2024 revenue") | Unreliable | Reliable |
| Paraphrased questions | Good | Good |
| Short keyword lookups ("VAR limit") | Mediocre | Better |

### How Bedrock Knowledge Base enables it

When you configure a Bedrock Knowledge Base backed by OpenSearch Serverless, you can enable
hybrid search in the retrieval configuration:

```python
response = bedrock.retrieve(
    knowledgeBaseId=kb_id,
    retrievalQuery={"text": "BASEL III Article 92 capital ratio"},
    retrievalConfiguration={
        "vectorSearchConfiguration": {
            "numberOfResults": 5,
            "overrideSearchType": "HYBRID"   # <-- enables BM25 + vector + RRF
        }
    },
)
```

Setting `overrideSearchType` to `"HYBRID"` is all that is needed — Bedrock handles sending
both query types to OpenSearch and merging the results. The default is `"SEMANTIC"` (vector only).

> **Note:** Hybrid search is only available when the vector store is OpenSearch (Serverless or
> Managed). S3 Vectors, Aurora pgvector, and other backends support semantic search only.

---

## Prerequisites

| What you need | Where to get it |
|---|---|
| AWS account with Console access | Your cloud admin |
| Region: **us-east-1** | Set in top-right corner of Console |
| Amazon Bedrock model access for **Nova Micro** and **Titan Embed Text v2** | Step 1 below |

---

## Step 1 — Enable Bedrock Model Access

> Skip this step if the models are already enabled.

1. In the Console search bar, type **Bedrock** and click **Amazon Bedrock**.
2. In the left sidebar, click **Model access** (under *Bedrock configurations*).
3. Click **Modify model access** (top-right).
4. Find and check the following two models:

   | Model Name | Provider | Used For |
   |---|---|---|
   | **Nova Micro** | Amazon | Chat / reasoning |
   | **Titan Embed Text v2** | Amazon | Embedding documents |

5. Click **Next**, then **Submit**.
6. Wait until both models show **Access granted** (refresh the page; may take a few minutes).

---

## Step 2 — Grant IAM Permissions to Your User

Your IAM user needs permissions to create and manage all the services in this demo.

1. In the Console search bar, type **IAM** and click **IAM**.
2. In the left sidebar, click **Users** → click your username.
3. Click the **Permissions** tab → **Add permissions** → **Attach policies directly**.
4. Search for and select each of the following managed policies:

   | Policy Name | Why needed |
   |---|---|
   | `AmazonBedrockFullAccess` | Create/manage Knowledge Bases, invoke models |
   | `AmazonOpenSearchServiceFullAccess` | Create OpenSearch Serverless collections and policies |
   | `AmazonS3FullAccess` | Create S3 bucket and upload documents |
   | `IAMFullAccess` | Create the service role for the Knowledge Base |

   > **Training note:** For production, replace these with fine-grained least-privilege policies.

5. Click **Next** → **Add permissions**.

---

## Step 3 — Create the S3 Bucket and Upload Documents

### 3a. Create the bucket

1. In the Console, go to **S3**.
2. Click **Create bucket**.
3. Set **Bucket name** to `rag-demo-<your-12-digit-account-id>`
   *(e.g. `rag-demo-123456789012` — must be globally unique)*
4. **Region:** us-east-1
5. Leave all other settings as default and click **Create bucket**.

### 3b. Upload documents

1. Click on the new bucket name.
2. Click **Upload** → **Add files**.
3. Select all files from the `ragdemo/data/` folder on your local machine.
4. Click **Upload**.
5. Confirm all files show **Succeeded** status.

---

## Step 4 — Create the IAM Role for the Knowledge Base

Bedrock Knowledge Base needs a service role to access S3, OpenSearch Serverless, and the
embedding model on your behalf.

### 4a. Create the role

1. In the Console, go to **IAM** → **Roles** → **Create role**.
2. **Trusted entity type:** AWS service.
3. **Use case:** In the search box type `Bedrock` and select **Bedrock** from the dropdown, then choose **Bedrock - Knowledge Base**.
4. Click **Next**.

### 4b. Attach permissions

5. On the *Add permissions* screen, search for and select:

   | Policy | Purpose |
   |---|---|
   | `AmazonBedrockFullAccess` | Invoke the embedding model |
   | `AmazonS3ReadOnlyAccess` | Read documents from S3 |
   | `AmazonOpenSearchServiceFullAccess` | Write vectors to OpenSearch Serverless |

6. Click **Next**.
7. **Role name:** `BedrockKBRole`
8. Click **Create role**.
9. Click on the newly created role and copy its **ARN** — you will need it in the next steps.
   It looks like: `arn:aws:iam::123456789012:role/BedrockKBRole`

---

## Step 5 — Create the OpenSearch Serverless Collection

Unlike managed OpenSearch (where you create a domain and attach an access policy to it),
OpenSearch Serverless separates security into **three independent policy types** that must
exist before the collection is created:

| Policy type | What it controls |
|---|---|
| **Encryption policy** | Which KMS key encrypts data at rest for this collection |
| **Network policy** | Whether the collection endpoint is public or VPC-private |
| **Data access policy** | Which IAM principals can read/write indexes and documents |

All three policies match a collection by name pattern — create them first, then the collection
picks them up automatically on creation.

### 5a. Create security policies first

1. In the Console, go to **Amazon OpenSearch Service**.
2. In the left sidebar, under *Serverless*, click **Security policies**.

#### Encryption policy

3. Click **Create encryption policy**.
4. **Name:** `ragdemo-coll-enc`
5. Under *Resources*, click **Add** and type: `Collection name: ragdemo-coll`
6. **Encryption:** Use AWS-owned key
7. Click **Create**.

#### Network policy

8. Click **Create network policy**.
9. **Name:** `ragdemo-coll-net`
10. Click **Add rule** → select **Collection** and type `ragdemo-coll`.
11. **Access type:** Public (allow public access to collection endpoint and Dashboards)
12. Click **Create**.

#### Data access policy

13. Click **Create data access policy**.
14. **Name:** `ragdemo-coll-acc`
15. Click **Add principals** and add **both**:
    - The ARN of your IAM user (e.g. `arn:aws:iam::123456789012:user/your-username`)
    - The ARN of `BedrockKBRole` (copied in Step 4)
16. Under *Grant permissions*, check all of the following:

    | Resource type | Permissions |
    |---|---|
    | **Index** (on `index/ragdemo-coll/*`) | `aoss:CreateIndex`, `aoss:DeleteIndex`, `aoss:UpdateIndex`, `aoss:DescribeIndex`, `aoss:ReadDocument`, `aoss:WriteDocument` |
    | **Collection** (on `collection/ragdemo-coll`) | `aoss:CreateCollectionItems`, `aoss:DeleteCollectionItems`, `aoss:UpdateCollectionItems`, `aoss:DescribeCollectionItems` |

17. Click **Create**.

### 5b. Create the collection

18. In the left sidebar, click **Collections** → **Create collection**.
19. **Collection name:** `ragdemo-coll`
20. **Collection type:** Vector search
21. **Security:** Standard create
    *(the policies you just created will be matched automatically by name)*
22. Click **Next** → review → **Submit**.
23. Wait until the collection status changes to **Active** (can take 5–10 minutes — refresh the page).
24. Once active, click the collection name and note the **Collection endpoint URL**
    (looks like `https://abc123xyz.us-east-1.aoss.amazonaws.com`).

---

## Step 6 — Create the Vector Index

The Knowledge Base needs a pre-existing index inside the collection.

1. Click the collection name → **Indexes** tab → **Create vector index**.
2. **Vector index name:** `bedrock-kb-index`
3. Click **Add vector field** and configure:

   | Setting | Value |
   |---|---|
   | Vector field name | `bedrock-knowledge-base-default-vector` |
   | Engine | faiss |
   | Dimensions | `1024` |
   | Distance metric | Euclidean |

4. Click **Add field** and add two more fields:

   | Field name | Field type |
   |---|---|
   | `AMAZON_BEDROCK_TEXT_CHUNK` | String |
   | `AMAZON_BEDROCK_METADATA` | String |

5. Click **Create**.

---

## Step 7 — Create the Bedrock Knowledge Base

1. In the Console, go to **Amazon Bedrock**.
2. In the left sidebar, under *Orchestration*, click **Knowledge bases**.
3. Click **Create knowledge base**.

### 7a. Knowledge base details

4. **Knowledge base name:** `ragdemo-kb`
5. **IAM permissions:** Select **Use an existing service role** → choose `BedrockKBRole`.
6. Click **Next**.

### 7b. Set up data source

7. **Data source name:** `s3-data-source`
8. **S3 URI:** Browse and select your bucket `rag-demo-<account-id>` (leave the prefix empty to index all files).
9. **Chunking strategy:** Fixed-size chunking
   - Max tokens: `512`
   - Overlap percentage: `20%`
10. Click **Next**.

### 7c. Configure embeddings and vector store

11. **Embeddings model:** Amazon — **Titan Text Embeddings V2** (dimension: 1024)
12. **Vector database:** Select **Choose a vector store you have created**.
13. **Select OpenSearch Serverless** and pick `ragdemo-coll`.
14. **Vector index name:** `bedrock-kb-index`
15. **Vector field:** `bedrock-knowledge-base-default-vector`
16. **Text field:** `AMAZON_BEDROCK_TEXT_CHUNK`
17. **Metadata field:** `AMAZON_BEDROCK_METADATA`
18. Click **Next** → review → **Create knowledge base**.

> The knowledge base will be created in a few seconds. Note the **Knowledge base ID** shown on the detail page (looks like `ABCDEF1234`).

---

## Step 8 — Add Data Source and Sync Documents

1. On the Knowledge Base detail page, scroll to the **Data sources** section.
2. Click the data source `s3-data-source` → **Sync**.
3. This triggers an ingestion job that:
   - Reads every file from S3
   - Splits them into chunks
   - Embeds each chunk using Titan Embed Text v2
   - Stores the vectors in the OpenSearch Serverless index
4. Watch the **Sync history** tab. The job moves through `In progress` → `Completed`.
   Duration depends on file count and size (typically 2–5 minutes for the demo dataset).

---

## Step 9 — Test Retrieval in the Console

1. On the Knowledge Base detail page, click **Test knowledge base** (top-right).
2. A chat panel opens on the right side.
3. Under *Select model*, choose **Amazon Nova Micro**.
4. Type a question related to your documents, for example:
   - *"What is the VAR backtesting policy?"*
   - *"Summarise the HDFC financial highlights for 2024."*
   - *"What Basel risk framework is mentioned in the RBI extract?"*
5. The response will show:
   - The **generated answer** from Nova
   - **Source chunks** with the originating S3 file names (expandable)
6. You can also switch between:
   - **Generate responses** — full RAG answer
   - **Retrieve only** — see raw chunks and similarity scores without model generation

---

## Step 10 — Configure and Use the Python Scripts

### 10a. Set environment variables

Create or edit `ragdemo/.env`:

```
AWS_ACCESS_KEY_ID=<your access key>
AWS_SECRET_ACCESS_KEY=<your secret key>
AWS_REGION=us-east-1
S3_BUCKET_NAME=rag-demo-<your-account-id>
OPENSEARCH_COLLECTION_NAME=ragdemo-coll
BEDROCK_KB_NAME=ragdemo-kb
BEDROCK_EMBEDDING_MODEL=amazon.titan-embed-text-v2:0
```

### 10b. Save the Knowledge Base config

Create `ragdemo/opensearch_serverless/kb_config.json` with the IDs from the console:

```json
{
  "knowledge_base_id": "<Knowledge Base ID from Step 7>",
  "data_source_id": "<Data Source ID from Step 8>",
  "collection_arn": "<Collection ARN from Step 5>",
  "region": "us-east-1"
}
```

> **Tip:** `indexer.py` creates this file automatically when run — this manual step is only needed if you set everything up through the console.

### 10c. Install dependencies

```bash
cd ragdemo
pip install -r requirements.txt
```

### 10d. Run the chatbot

```bash
python opensearch_serverless/ragchatbot.py
```

---

## How It Works — Querying the Knowledge Base in Python

Once the Knowledge Base is set up, your Python code interacts with it through the
**Bedrock Agent Runtime** `retrieve` and `retrieve_and_generate` APIs.
OpenSearch Serverless is completely abstracted — you never call it directly.

### Option A: Retrieve only (get chunks, no LLM)

```python
import boto3, json

bedrock = boto3.client("bedrock-agent-runtime", region_name="us-east-1")

with open("opensearch_serverless/kb_config.json") as f:
    kb_id = json.load(f)["knowledge_base_id"]

response = bedrock.retrieve(
    knowledgeBaseId=kb_id,
    retrievalQuery={"text": "What is the VAR backtesting policy?"},
    retrievalConfiguration={
        "vectorSearchConfiguration": {"numberOfResults": 5}
    },
)

for chunk in response["retrievalResults"]:
    print(chunk["content"]["text"])
    print("Source:", chunk["location"]["s3Location"]["uri"])
    print("Score:", chunk["score"])
    print("---")
```

### Option B: Retrieve and generate (full RAG — chunks + LLM answer)

```python
import boto3, json

bedrock = boto3.client("bedrock-agent-runtime", region_name="us-east-1")

with open("opensearch_serverless/kb_config.json") as f:
    kb_id = json.load(f)["knowledge_base_id"]

response = bedrock.retrieve_and_generate(
    input={"text": "Summarise the HDFC financial highlights for 2024."},
    retrieveAndGenerateConfiguration={
        "type": "KNOWLEDGE_BASE",
        "knowledgeBaseConfiguration": {
            "knowledgeBaseId": kb_id,
            "modelArn": "arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-micro-v1:0",
            "retrievalConfiguration": {
                "vectorSearchConfiguration": {"numberOfResults": 5}
            },
        },
    },
)

print(response["output"]["text"])

# Show source citations
for citation in response.get("citations", []):
    for ref in citation.get("retrievedReferences", []):
        print("Cited from:", ref["location"]["s3Location"]["uri"])
```

### Option C: LangChain integration (if you prefer the LangChain abstraction)

```python
from langchain_aws import AmazonKnowledgeBasesRetriever, ChatBedrock
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

retriever = AmazonKnowledgeBasesRetriever(
    knowledge_base_id="<your-kb-id>",
    retrieval_config={"vectorSearchConfiguration": {"numberOfResults": 5}},
)

llm = ChatBedrock(model_id="amazon.nova-micro-v1:0", model_kwargs={"temperature": 0})

prompt = ChatPromptTemplate.from_template("""
Answer using only the context below.
Context: {context}
Question: {question}
Answer:""")

chain = (
    {"context": retriever, "question": lambda x: x}
    | prompt
    | llm
    | StrOutputParser()
)

print(chain.invoke("What is the capital adequacy requirement?"))
```

---

## Troubleshooting

| Error | Likely Cause | Fix |
|---|---|---|
| `AccessDeniedException` on Bedrock | Model access not enabled | Complete Step 1 |
| `EntityAlreadyExists` on IAM role | Role was already created | Safe to ignore; the script reuses it |
| `ConflictException` on AOSS policy | Policy already exists | Safe to ignore; the script is idempotent |
| Collection stays in `Creating` > 15 min | Service delay | Wait longer or delete and recreate |
| Ingestion job `FAILED` | S3 access denied or unsupported file type | Verify `BedrockKBRole` has S3 read access and that the files are PDF, TXT, MD, DOCX, HTML, or CSV |
| `ResourceNotFoundException` in chatbot | Wrong KB ID in `kb_config.json` | Copy the correct ID from the Bedrock console |
| `No relevant documents found` | Ingestion not yet complete | Wait for the sync job to show `Completed` |

---

## Supported Document Formats

Bedrock Knowledge Base natively parses:

| Format | Notes |
|---|---|
| PDF | Scanned PDFs require Textract (extra cost) |
| Plain text (`.txt`) | — |
| Markdown (`.md`) | — |
| Microsoft Word (`.docx`) | — |
| HTML | — |
| CSV | Each row becomes a chunk |

---

## Cost Estimate (demo dataset, ~10 files)

| Service | Approximate cost |
|---|---|
| OpenSearch Serverless | ~$0.24/hr per OCU (minimum 2 OCUs = ~$0.48/hr while active) |
| Titan Embed Text v2 | $0.00002 per 1K tokens (ingestion is a one-time cost) |
| Amazon Nova Micro | $0.000035 per 1K input tokens |
| S3 | Negligible for small files |

> **Tip:** Delete the OpenSearch Serverless collection when not in use to avoid ongoing OCU charges.

---

## Cleanup and Teardown

Delete resources in this order — Bedrock resources first, then OpenSearch, then IAM and S3.
OCU charges stop as soon as the collection is deleted.

### 1. Delete the Bedrock Knowledge Base

1. Go to **Amazon Bedrock** → **Knowledge bases**.
2. Click `ragdemo-kb` → **Delete**.
3. Type the knowledge base name to confirm and click **Delete**.

> Deleting the Knowledge Base does **not** delete the OpenSearch collection or S3 bucket.

### 2. Delete the OpenSearch Serverless Collection

> **This stops OCU billing immediately.**

1. Go to **Amazon OpenSearch Service** → **Serverless** → **Collections**.
2. Select `ragdemo-coll` → **Actions** → **Delete**.
3. Type the collection name to confirm and click **Delete**.
4. The collection and all its indexes are permanently deleted.

### 3. Delete the OpenSearch Serverless Security Policies

1. Go to **Amazon OpenSearch Service** → **Serverless** → **Security policies**.
2. Delete the following policies (one at a time — select, then **Actions** → **Delete**):
   - `ragdemo-coll-acc` (Data access policy)
   - `ragdemo-coll-net` (Network policy)
   - `ragdemo-coll-enc` (Encryption policy)

### 4. Delete the IAM Role

1. Go to **IAM** → **Roles**.
2. Search for `BedrockKBRole`.
3. Select it → **Delete** → confirm deletion.

### 5. Empty and Delete the S3 Bucket

1. Go to **S3** → click `rag-demo-<account-id>`.
2. Click **Empty** → type `permanently delete` → confirm.
3. After emptying, click **Delete** → type the bucket name → confirm.

### 6. Delete `kb_config.json` (optional)

Remove the local config file so stale IDs do not cause confusion:

```bash
rm ragdemo/opensearch_serverless/kb_config.json
```

### Quick-verify: No active OCU charges

After deleting the collection, confirm no charges are accruing:

1. Go to **AWS Cost Explorer** or **Billing** → **Bills**.
2. Filter by service: **Amazon OpenSearch Service**.
3. The OCU-hours line should show $0.00 for new usage after deletion.
