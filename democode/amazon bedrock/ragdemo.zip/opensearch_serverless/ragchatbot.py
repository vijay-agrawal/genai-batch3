"""
ragchatbot.py
RAG chatbot:
  1. Accepts a question from the user.
  2. Retrieves relevant document chunks from a Bedrock Knowledge Base.
  3. Passes the question + context to Amazon Nova (via Bedrock) for a grounded answer.
"""

import json
import os
import sys

import boto3
from dotenv import load_dotenv

load_dotenv(dotenv_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env"))

# ── Configuration ─────────────────────────────────────────────────────────────
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
MAX_TOKENS = int(os.getenv("BEDROCK_MAX_TOKENS", "512"))
TEMPERATURE = float(os.getenv("BEDROCK_TEMPERATURE", "0.7"))
TOP_K_RESULTS = 5

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kb_config.json")

SYSTEM_PROMPT = (
    "You are a helpful AI assistant. Answer questions strictly based on the "
    "provided context documents. Be concise and accurate. If the context does "
    "not contain enough information to answer, say so clearly."
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_config():
    if not os.path.exists(CONFIG_FILE):
        print("Error: kb_config.json not found. Run indexer.py first.")
        sys.exit(1)
    with open(CONFIG_FILE) as f:
        return json.load(f)


def retrieve(bedrock_agent_runtime, kb_id, question):
    """Retrieve the top-K relevant chunks from the knowledge base."""
    response = bedrock_agent_runtime.retrieve(
        knowledgeBaseId=kb_id,
        retrievalQuery={"text": question},
        retrievalConfiguration={
            "vectorSearchConfiguration": {"numberOfResults": TOP_K_RESULTS}
        },
    )
    return response.get("retrievalResults", [])


def build_prompt(question, results):
    """Combine retrieved chunks into a single prompt."""
    context_blocks = []
    for i, r in enumerate(results, 1):
        text = r["content"]["text"]
        uri = r.get("location", {}).get("s3Location", {}).get("uri", "unknown")
        source = uri.split("/")[-1] if "/" in uri else uri
        context_blocks.append(f"[Document {i} – {source}]\n{text}")

    context = "\n\n".join(context_blocks)
    return (
        f"Answer the following question using ONLY the context documents below.\n\n"
        f"--- CONTEXT ---\n{context}\n--- END CONTEXT ---\n\n"
        f"Question: {question}"
    )


def invoke_nova(bedrock_runtime, prompt):
    """Call the Amazon Nova model and return the generated text."""
    body = {
        "messages": [{"role": "user", "content": [{"text": prompt}]}],
        "system": [{"text": SYSTEM_PROMPT}],
        "inferenceConfig": {
            "maxTokens": MAX_TOKENS,
            "temperature": TEMPERATURE,
        },
    }
    response = bedrock_runtime.invoke_model(
        modelId=MODEL_ID,
        body=json.dumps(body),
        contentType="application/json",
        accept="application/json",
    )
    result = json.loads(response["body"].read())
    return result["output"]["message"]["content"][0]["text"]


# ── Chat loop ─────────────────────────────────────────────────────────────────

def chat(kb_id):
    agent_rt = boto3.client("bedrock-agent-runtime", region_name=AWS_REGION)
    bedrock_rt = boto3.client("bedrock-runtime", region_name=AWS_REGION)

    print(f"\n=== RAG Chatbot  |  model: {MODEL_ID} ===")
    print("Type your question and press Enter. Type 'quit' to exit.\n")

    while True:
        try:
            question = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not question:
            continue
        if question.lower() in ("quit", "exit", "q"):
            print("Goodbye!")
            break

        # ── Retrieval ──
        print("\n[Retrieving relevant context...]")
        results = retrieve(agent_rt, kb_id, question)

        if not results:
            print("Assistant: No relevant documents found in the knowledge base.\n")
            continue

        sources = sorted({
            r.get("location", {}).get("s3Location", {}).get("uri", "?").split("/")[-1]
            for r in results
        })
        print(f"[Found {len(results)} chunks from: {', '.join(sources)}]")

        # ── Generation ──
        prompt = build_prompt(question, results)
        answer = invoke_nova(bedrock_rt, prompt)

        print(f"\nAssistant: {answer}\n")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    config = load_config()
    chat(config["knowledge_base_id"])
