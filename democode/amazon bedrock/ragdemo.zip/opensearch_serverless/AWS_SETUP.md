# RAG Demo — AWS Console Setup Guide

This guide walks through building the full RAG (Retrieval-Augmented Generation) pipeline
entirely through the AWS Management Console, covering:

- IAM permissions for your user and for the Knowledge Base service role
- S3 bucket creation and document upload
- Amazon OpenSearch Serverless vector collection
- Amazon Bedrock Knowledge Base creation and document ingestion
- Retrieval testing directly in the console

---

## Architecture Overview

```
Your Documents (local)
        │
        ▼
  S3 Bucket (raw files)
        │   ← Bedrock reads & chunks documents
        ▼
  Bedrock Knowledge Base
        │   ← embeds chunks with Titan Embed Text v2
        ▼
  OpenSearch Serverless (vector store)
        │
        ▼
  Bedrock retrieve() API  ──► Amazon Nova (reasoning & formatting)
```

---

## Prerequisites

| What you need | Where to get it |
|---|---|
| AWS account with Console access | Your cloud admin |
| Region: **us-east-1** | Set in top-right corner of Console |
| Amazon Bedrock model access for **Nova Micro** and **Titan Embed Text v2** | Step 1 below |

---

## Step 1 — Enable Bedrock Model Access

> Skip this step if the models are already enabled.

1. In the Console search bar, type **Bedrock** and click **Amazon Bedrock**.
2. In the left sidebar, click **Model access** (under *Bedrock configurations*).
3. Click **Modify model access** (top-right).
4. Find and check the following two models:

   | Model Name | Provider | Used For |
   |---|---|---|
   | **Nova Micro** | Amazon | Chat / reasoning |
   | **Titan Embed Text v2** | Amazon | Embedding documents |

5. Click **Next**, then **Submit**.
6. Wait until both models show **Access granted** (refresh the page; may take a few minutes).

---

## Step 2 — Grant IAM Permissions to Your User

Your IAM user needs permissions to create and manage all the services in this demo.

1. In the Console search bar, type **IAM** and click **IAM**.
2. In the left sidebar, click **Users** → click your username.
3. Click the **Permissions** tab → **Add permissions** → **Attach policies directly**.
4. Search for and select each of the following managed policies:

   | Policy Name | Why needed |
   |---|---|
   | `AmazonBedrockFullAccess` | Create/manage Knowledge Bases, invoke models |
   | `AmazonOpenSearchServiceFullAccess` | Create OpenSearch Serverless collections and policies |
   | `AmazonS3FullAccess` | Create S3 bucket and upload documents |
   | `IAMFullAccess` | Create the service role for the Knowledge Base |

   > **Training note:** For production, replace these with fine-grained least-privilege policies.

5. Click **Next** → **Add permissions**.

---

## Step 3 — Create the S3 Bucket and Upload Documents

### 3a. Create the bucket

1. In the Console, go to **S3**.
2. Click **Create bucket**.
3. Set **Bucket name** to `rag-demo-<your-12-digit-account-id>`
   *(e.g. `rag-demo-123456789012` — must be globally unique)*
4. **Region:** us-east-1
5. Leave all other settings as default and click **Create bucket**.

### 3b. Upload documents

1. Click on the new bucket name.
2. Click **Upload** → **Add files**.
3. Select all files from the `ragdemo/data/` folder on your local machine.
4. Click **Upload**.
5. Confirm all files show **Succeeded** status.

---

## Step 4 — Create the IAM Role for the Knowledge Base

Bedrock Knowledge Base needs a service role to access S3, OpenSearch Serverless, and the
embedding model on your behalf.

### 4a. Create the role

1. In the Console, go to **IAM** → **Roles** → **Create role**.
2. **Trusted entity type:** AWS service.
3. **Use case:** In the search box type `Bedrock` and select **Bedrock** from the dropdown, then choose **Bedrock - Knowledge Base**.
4. Click **Next**.

### 4b. Attach permissions

5. On the *Add permissions* screen, search for and select:

   | Policy | Purpose |
   |---|---|
   | `AmazonBedrockFullAccess` | Invoke the embedding model |
   | `AmazonS3ReadOnlyAccess` | Read documents from S3 |
   | `AmazonOpenSearchServiceFullAccess` | Write vectors to OpenSearch Serverless |

6. Click **Next**.
7. **Role name:** `BedrockKBRole`
8. Click **Create role**.
9. Click on the newly created role and copy its **ARN** — you will need it in the next steps.
   It looks like: `arn:aws:iam::123456789012:role/BedrockKBRole`

---

## Step 5 — Create the OpenSearch Serverless Collection

### 5a. Create security policies first

The collection requires three policies before it can be created.

1. In the Console, go to **Amazon OpenSearch Service**.
2. In the left sidebar, under *Serverless*, click **Security policies**.

#### Encryption policy

3. Click **Create encryption policy**.
4. **Name:** `ragdemo-coll-enc`
5. Under *Resources*, click **Add** and type: `Collection name: ragdemo-coll`
6. **Encryption:** Use AWS-owned key
7. Click **Create**.

#### Network policy

8. Click **Create network policy**.
9. **Name:** `ragdemo-coll-net`
10. Click **Add rule** → select **Collection** and type `ragdemo-coll`.
11. **Access type:** Public (allow public access to collection endpoint and Dashboards)
12. Click **Create**.

#### Data access policy

13. Click **Create data access policy**.
14. **Name:** `ragdemo-coll-acc`
15. Click **Add principals** and add **both**:
    - The ARN of your IAM user (e.g. `arn:aws:iam::123456789012:user/your-username`)
    - The ARN of `BedrockKBRole` (copied in Step 4)
16. Under *Grant permissions*, check all of the following:

    | Resource type | Permissions |
    |---|---|
    | **Index** (on `index/ragdemo-coll/*`) | `aoss:CreateIndex`, `aoss:DeleteIndex`, `aoss:UpdateIndex`, `aoss:DescribeIndex`, `aoss:ReadDocument`, `aoss:WriteDocument` |
    | **Collection** (on `collection/ragdemo-coll`) | `aoss:CreateCollectionItems`, `aoss:DeleteCollectionItems`, `aoss:UpdateCollectionItems`, `aoss:DescribeCollectionItems` |

17. Click **Create**.

### 5b. Create the collection

18. In the left sidebar, click **Collections** → **Create collection**.
19. **Collection name:** `ragdemo-coll`
20. **Collection type:** Vector search
21. **Security:** Standard create
    *(the policies you just created will be matched automatically by name)*
22. Click **Next** → review → **Submit**.
23. Wait until the collection status changes to **Active** (can take 5–10 minutes — refresh the page).
24. Once active, click the collection name and note the **Collection endpoint URL**
    (looks like `https://abc123xyz.us-east-1.aoss.amazonaws.com`).

---

## Step 6 — Create the Vector Index

The Knowledge Base needs a pre-existing index inside the collection.

1. Click the collection name → **Indexes** tab → **Create vector index**.
2. **Vector index name:** `bedrock-kb-index`
3. Click **Add vector field** and configure:

   | Setting | Value |
   |---|---|
   | Vector field name | `bedrock-knowledge-base-default-vector` |
   | Engine | faiss |
   | Dimensions | `1024` |
   | Distance metric | Euclidean |

4. Click **Add field** and add two more fields:

   | Field name | Field type |
   |---|---|
   | `AMAZON_BEDROCK_TEXT_CHUNK` | String |
   | `AMAZON_BEDROCK_METADATA` | String |

5. Click **Create**.

---

## Step 7 — Create the Bedrock Knowledge Base

1. In the Console, go to **Amazon Bedrock**.
2. In the left sidebar, under *Orchestration*, click **Knowledge bases**.
3. Click **Create knowledge base**.

### 7a. Knowledge base details

4. **Knowledge base name:** `ragdemo-kb`
5. **IAM permissions:** Select **Use an existing service role** → choose `BedrockKBRole`.
6. Click **Next**.

### 7b. Set up data source

7. **Data source name:** `s3-data-source`
8. **S3 URI:** Browse and select your bucket `rag-demo-<account-id>` (leave the prefix empty to index all files).
9. **Chunking strategy:** Fixed-size chunking
   - Max tokens: `512`
   - Overlap percentage: `20%`
10. Click **Next**.

### 7c. Configure embeddings and vector store

11. **Embeddings model:** Amazon — **Titan Text Embeddings V2** (dimension: 1024)
12. **Vector database:** Select **Choose a vector store you have created**.
13. **Select OpenSearch Serverless** and pick `ragdemo-coll`.
14. **Vector index name:** `bedrock-kb-index`
15. **Vector field:** `bedrock-knowledge-base-default-vector`
16. **Text field:** `AMAZON_BEDROCK_TEXT_CHUNK`
17. **Metadata field:** `AMAZON_BEDROCK_METADATA`
18. Click **Next** → review → **Create knowledge base**.

> The knowledge base will be created in a few seconds. Note the **Knowledge base ID** shown on the detail page (looks like `ABCDEF1234`).

---

## Step 8 — Add Data Source and Sync Documents

1. On the Knowledge Base detail page, scroll to the **Data sources** section.
2. Click the data source `s3-data-source` → **Sync**.
3. This triggers an ingestion job that:
   - Reads every file from S3
   - Splits them into chunks
   - Embeds each chunk using Titan Embed Text v2
   - Stores the vectors in the OpenSearch Serverless index
4. Watch the **Sync history** tab. The job moves through `In progress` → `Completed`.
   Duration depends on file count and size (typically 2–5 minutes for the demo dataset).

---

## Step 9 — Test Retrieval in the Console

1. On the Knowledge Base detail page, click **Test knowledge base** (top-right).
2. A chat panel opens on the right side.
3. Under *Select model*, choose **Amazon Nova Micro**.
4. Type a question related to your documents, for example:
   - *"What is the VAR backtesting policy?"*
   - *"Summarise the HDFC financial highlights for 2024."*
   - *"What Basel risk framework is mentioned in the RBI extract?"*
5. The response will show:
   - The **generated answer** from Nova
   - **Source chunks** with the originating S3 file names (expandable)
6. You can also switch between:
   - **Generate responses** — full RAG answer
   - **Retrieve only** — see raw chunks and similarity scores without model generation

---

## Step 10 — Configure the Python Scripts

1. Open `.env` in the project root and fill in the values:

   ```
   AWS_ACCESS_KEY_ID=<your access key>
   AWS_SECRET_ACCESS_KEY=<your secret key>
   AWS_REGION=us-east-1
   S3_BUCKET_NAME=rag-demo-<your-account-id>
   OPENSEARCH_COLLECTION_NAME=ragdemo-coll
   BEDROCK_KB_NAME=ragdemo-kb
   BEDROCK_EMBEDDING_MODEL=amazon.titan-embed-text-v2:0
   ```

2. Create `ragdemo/kb_config.json` with the IDs from the console:

   ```json
   {
     "knowledge_base_id": "<Knowledge Base ID from Step 7>",
     "data_source_id": "<Data Source ID from Step 8>",
     "collection_arn": "<Collection ARN from Step 5>",
     "region": "us-east-1"
   }
   ```

   > **Tip:** `indexer.py` creates this file automatically when run — this manual step is only needed if you set everything up through the console.

3. Install dependencies and run the chatbot:

   ```bash
   cd ragdemo
   pip install -r requirements.txt
   python ragchatbot.py
   ```

---

## Troubleshooting

| Error | Likely Cause | Fix |
|---|---|---|
| `AccessDeniedException` on Bedrock | Model access not enabled | Complete Step 1 |
| `EntityAlreadyExists` on IAM role | Role was already created | Safe to ignore; the script reuses it |
| `ConflictException` on AOSS policy | Policy already exists | Safe to ignore; the script is idempotent |
| Collection stays in `Creating` > 15 min | Service delay | Wait longer or delete and recreate |
| Ingestion job `FAILED` | S3 access denied or unsupported file type | Verify `BedrockKBRole` has S3 read access and that the files are PDF, TXT, MD, DOCX, HTML, or CSV |
| `ResourceNotFoundException` in chatbot | Wrong KB ID in `kb_config.json` | Copy the correct ID from the Bedrock console |
| `No relevant documents found` | Ingestion not yet complete | Wait for the sync job to show `Completed` |

---

## Supported Document Formats

Bedrock Knowledge Base natively parses:

| Format | Notes |
|---|---|
| PDF | Scanned PDFs require Textract (extra cost) |
| Plain text (`.txt`) | — |
| Markdown (`.md`) | — |
| Microsoft Word (`.docx`) | — |
| HTML | — |
| CSV | Each row becomes a chunk |

---

## Cost Estimate (demo dataset, ~10 files)

| Service | Approximate cost |
|---|---|
| OpenSearch Serverless | ~$0.24/hr per OCU (minimum 2 OCUs = ~$0.48/hr while active) |
| Titan Embed Text v2 | $0.00002 per 1K tokens (ingestion is a one-time cost) |
| Amazon Nova Micro | $0.000035 per 1K input tokens |
| S3 | Negligible for small files |

> **Tip:** Delete the OpenSearch Serverless collection when not in use to avoid ongoing OCU charges.
