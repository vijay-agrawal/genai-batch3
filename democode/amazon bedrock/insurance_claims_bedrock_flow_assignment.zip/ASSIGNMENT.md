# Amazon Bedrock Flow: Automated Insurance Claim Processing

## Overview

In this assignment you will build an **end-to-end automated insurance claim processing pipeline** using Amazon Bedrock Flows, Knowledge Bases, Agents, and Lambda functions. You will work with realistic synthetic healthcare data to simulate how an insurer might automatically process a patient's hospital discharge and generate a completed CMS-1500 claim form — all orchestrated through a Bedrock Flow.

---

## Learning Objectives

By the end of this assignment you will be able to:

1. Upload structured reference data to S3 and create a Bedrock Knowledge Base from it
2. Integrate external public APIs (ICD-10, drug lookup, NPI registry) via AWS Lambda
3. Build Bedrock Agents that invoke Lambda tools and query Knowledge Bases
4. Wire multiple agents together inside a **Bedrock Flow** with a defined input/output contract
5. Produce a structured JSON artifact (claim form) written back to S3

---

## Architecture Overview

```
                          BEDROCK FLOW
  ┌──────────────────────────────────────────────────────────┐
  │                                                          │
  │  [Input Node]                                            │
  │   Receives: patient_id, discharge_note (text), policy_id │
  │       │                                                  │
  │       ▼                                                  │
  │  [Agent 1: Diagnosis Extraction Agent]                   │
  │   - Reads discharge note                                 │
  │   - Calls Lambda → ICD-10 API to resolve diagnosis codes │
  │   - Calls Lambda → NPI Registry to verify provider       │
  │   - Outputs: structured diagnoses[], procedures[],       │
  │              provider NPI, dates of service              │
  │       │                                                  │
  │       ▼                                                  │
  │  [Agent 2: Policy Eligibility Agent]                     │
  │   - Queries Bedrock Knowledge Base (policy documents)    │
  │   - Checks: is each diagnosis/procedure covered?         │
  │   - Applies deductibles, co-pays, exclusions             │
  │   - Calls Lambda → OpenFDA API for drug coverage check   │
  │   - Outputs: coverage_decision[], allowed_amounts[]      │
  │       │                                                  │
  │       ▼                                                  │
  │  [Agent 3: Claim Form Builder Agent]                     │
  │   - Assembles CMS-1500 equivalent JSON claim             │
  │   - Validates required fields are present                │
  │   - Calculates total billed, allowed, patient liability  │
  │   - Outputs: completed claim JSON                        │
  │       │                                                  │
  │       ▼                                                  │
  │  [Output Node]                                           │
  │   - Writes claim JSON to S3:                             │
  │     s3://your-bucket/claims/{patient_id}/claim.json      │
  │   - Returns claim_id and summary to caller               │
  └──────────────────────────────────────────────────────────┘
          │                              │
  [S3 Knowledge Base]          [S3 Patient Claims]
  - policy_inclusions.json     - {patient_id}/claim.json
  - policy_exclusions.json     - {patient_id}/discharge_note.txt
  - icd10_reference.json
  - drug_formulary.json
```

See [architecture/flow_diagram.md](architecture/flow_diagram.md) for the detailed Mermaid diagram.

---

## Part 1 — Prepare Your Data and S3 Bucket

### 1.1 — Create Your S3 Bucket

Create an S3 bucket (e.g., `bedrock-claims-yourname`) with two prefixes:

```
s3://bedrock-claims-yourname/
  knowledge-base/          <-- reference data for KB
  patients/                <-- discharge notes + output claims
    P001/
      discharge_note.txt
    P002/
      discharge_note.txt
  claims/                  <-- output location for Bedrock Flow
    P001/
    P002/
```

Upload the provided datasets from the `data/` folder:

| File | Destination |
|------|-------------|
| `data/policy_inclusions.json` | `s3://…/knowledge-base/policy_inclusions.json` |
| `data/policy_exclusions.json` | `s3://…/knowledge-base/policy_exclusions.json` |
| `data/drug_formulary.json` | `s3://…/knowledge-base/drug_formulary.json` |
| `data/icd10_reference.json` | `s3://…/knowledge-base/icd10_reference.json` |
| `data/patient_discharge_notes/` | `s3://…/patients/{patient_id}/discharge_note.txt` |

You can use the console or the helper script:

```bash
python starter_code/upload_data.py --bucket bedrock-claims-yourname --region us-east-1
```

### 1.2 — Create the Bedrock Knowledge Base

Create a Knowledge Base in the Amazon Bedrock console:

1. Go to **Amazon Bedrock → Knowledge Bases → Create**
2. Name: `InsurancePolicyKB`
3. Data source: S3 — point to `s3://bedrock-claims-yourname/knowledge-base/`
4. Embeddings model: `Amazon Titan Embeddings G1 - Text`
5. Vector store: Amazon OpenSearch Serverless (auto-created)
6. Click **Create and Sync**

**Or** use the programmatic approach (see `starter_code/create_knowledge_base.py`).

> **Checkpoint:** Test your KB by asking it: *"Is chemotherapy covered under GOLD plan?"*

---

## Part 2 — Explore the Public APIs

You will use the following **free, no-auth-required** public APIs in your Lambda functions:

### API 1 — NLM ICD-10-CM Clinical Tables (Primary — implement this one)

- **Purpose:** Convert a diagnosis description to an ICD-10-CM code
- **Endpoint:** `https://clinicaltables.nlm.nih.gov/api/icd10cm/v3/search`
- **Example:**
  ```
  GET https://clinicaltables.nlm.nih.gov/api/icd10cm/v3/search?sf=code,name&terms=pneumonia
  ```
- **Returns:** `[total, codes[], extra[], displayStrings[]]`
- **Docs:** https://clinicaltables.nlm.nih.gov/apidoc/icd10cm/v3/doc.html

### API 2 — OpenFDA Drug API

- **Purpose:** Look up drug information, check if a drug is in a therapeutic class
- **Endpoint:** `https://api.fda.gov/drug/label.json`
- **Example:**
  ```
  GET https://api.fda.gov/drug/label.json?search=openfda.brand_name:"metformin"&limit=1
  ```
- **Docs:** https://open.fda.gov/apis/drug/label/

### API 3 — NPPES NPI Registry

- **Purpose:** Verify a healthcare provider by NPI number, retrieve provider details
- **Endpoint:** `https://npiregistry.cms.hhs.gov/api/`
- **Example:**
  ```
  GET https://npiregistry.cms.hhs.gov/api/?number=1234567890&version=2.1
  ```
- **Docs:** https://npiregistry.cms.hhs.gov/api-page

> **Note:** All three APIs are free, publicly accessible, and require no API key.

---

## Part 3 — Build the Lambda Function (ICD-10 Lookup)

Create an AWS Lambda function that wraps the NLM ICD-10 API so it can be called by a Bedrock Agent as a tool.

### 3.1 — Create the Function

1. Go to **AWS Lambda → Create Function**
2. Name: `icd10-lookup`
3. Runtime: Python 3.12
4. Paste the code from `lambda/icd10_lookup/lambda_function.py`

### 3.2 — Add Required IAM Permissions

The execution role needs no special permissions beyond basic Lambda execution (it only calls a public URL).

### 3.3 — Test Your Function

Use this test event:

```json
{
  "actionGroup": "DiagnosisTools",
  "function": "lookup_icd10_code",
  "parameters": [
    { "name": "diagnosis_description", "value": "type 2 diabetes mellitus" }
  ]
}
```

Expected response includes ICD-10 code `E11` (Type 2 diabetes mellitus).

### 3.4 — (Stretch) Add the NPI Lookup Lambda

Repeat the above for `lambda/npi_lookup/lambda_function.py` — name it `npi-lookup`.

---

## Part 4 — Build the Bedrock Agents

### Agent 1: Diagnosis Extraction Agent

1. Go to **Amazon Bedrock → Agents → Create Agent**
2. Name: `DiagnosisExtractionAgent`
3. Model: `Claude 3 Sonnet` (or Haiku for cost savings)
4. Instructions (system prompt):

```
You are a medical coding specialist. Given a patient discharge note, you will:
1. Extract all diagnoses mentioned and resolve them to ICD-10-CM codes using the lookup_icd10_code tool
2. Extract all procedures performed
3. Extract the attending physician name and look up their NPI using get_provider_npi tool
4. Extract dates of admission and discharge
Return a structured JSON with: diagnoses (list of {description, icd10_code}), procedures (list), provider_npi, admission_date, discharge_date
```

5. **Action Group:** Add action group `DiagnosisTools`
   - Lambda function: `icd10-lookup`
   - API Schema: use `lambda/icd10_lookup/openapi_schema.json`

6. Test with the sample discharge note in `data/patient_discharge_notes/P001_discharge_note.txt`

### Agent 2: Policy Eligibility Agent

1. Create Agent: `PolicyEligibilityAgent`
2. Model: `Claude 3 Sonnet`
3. Instructions:

```
You are an insurance policy analyst. Given a list of diagnoses (ICD-10 codes), procedures,
and a policy_id, you will:
1. Query the knowledge base to determine if each diagnosis/procedure is covered
2. Identify any exclusions that apply
3. Retrieve the applicable co-pay, deductible, and co-insurance percentages
4. For any prescription drugs mentioned, check the drug formulary tier
Return a structured JSON with: coverage_decisions (list of {code, covered, reason, allowed_amount}),
total_billed, total_allowed, patient_liability
```

4. **Knowledge Base:** Attach `InsurancePolicyKB`
5. Test with the output from Agent 1 + a policy ID (e.g., `GOLD-001`)

### Agent 3: Claim Form Builder Agent

1. Create Agent: `ClaimFormBuilderAgent`
2. Model: `Claude 3 Sonnet`
3. Instructions:

```
You are a medical billing specialist. Given patient demographics, provider details,
diagnosis codes, and coverage decisions, assemble a complete CMS-1500 equivalent
claim in JSON format.
Validate that all required fields are present: patient_name, patient_dob, insured_id,
provider_npi, diagnoses, service_dates, procedure_codes, billed_amounts.
Return the completed claim JSON. If any required field is missing, list what is missing.
```

4. No Lambda or KB needed — this agent synthesizes structured inputs into a structured output.

---

## Part 5 — Build the Bedrock Flow

Now wire everything together in a **Bedrock Flow**.

### 5.1 — Create the Flow

1. Go to **Amazon Bedrock → Flows → Create Flow**
2. Name: `InsuranceClaimProcessingFlow`
3. You will see a visual canvas with a default Input → Output connection

### 5.2 — Add Nodes

Add the following nodes in sequence:

| Node | Type | Configuration |
|------|------|---------------|
| `FlowInput` | Input | Fields: `patient_id (string)`, `discharge_note (string)`, `policy_id (string)` |
| `DiagnosisExtraction` | Agent | Agent: `DiagnosisExtractionAgent`, pass `discharge_note` as user message |
| `PolicyEligibility` | Agent | Agent: `PolicyEligibilityAgent`, pass Agent1 output + `policy_id` |
| `ClaimFormBuilder` | Agent | Agent: `ClaimFormBuilderAgent`, pass Agent2 output + patient demographics |
| `WriteToS3` | Lambda | Lambda: `write-claim-to-s3`, pass `patient_id` + claim JSON |
| `FlowOutput` | Output | Return `claim_id`, `total_billed`, `patient_liability` |

### 5.3 — Wire the Connections

In the flow canvas, connect:
- `FlowInput.discharge_note` → `DiagnosisExtraction.input`
- `FlowInput.policy_id` → `PolicyEligibility.input` (alongside DiagnosisExtraction output)
- `DiagnosisExtraction.output` → `PolicyEligibility.input`
- `PolicyEligibility.output` → `ClaimFormBuilder.input`
- `ClaimFormBuilder.output` → `WriteToS3.input`
- `FlowInput.patient_id` → `WriteToS3.input`
- `WriteToS3.output` → `FlowOutput`

> **Tip:** Use the **Prompt** node type if you want to add a lightweight transformation step (e.g., format the output) without a full agent.

### 5.4 — Create the S3 Writer Lambda

Create one more Lambda function (`write-claim-to-s3`) from `lambda/write_claim_to_s3/lambda_function.py`. This Lambda receives the final claim JSON and writes it to `s3://bedrock-claims-yourname/claims/{patient_id}/claim.json`.

Give its IAM role the `s3:PutObject` permission on your bucket.

### 5.5 — Test the Flow

Use the test input:

```json
{
  "patient_id": "P001",
  "policy_id": "GOLD-001",
  "discharge_note": "<contents of data/patient_discharge_notes/P001_discharge_note.txt>"
}
```

**Expected output:**
```json
{
  "claim_id": "CLM-P001-20240315",
  "total_billed": 12450.00,
  "total_allowed": 9800.00,
  "patient_liability": 850.00,
  "status": "SUBMITTED"
}
```

---

## Part 6 — Deliverables

Submit the following:

1. **Screenshot** of your Bedrock Flow canvas showing all 6 nodes wired together
2. **Screenshot** of a successful flow test execution with real output
3. **The generated `claim.json`** from S3 for patient P001
4. **Screenshot** of your Knowledge Base with sync status = "Complete"
5. **Short write-up** (300-500 words): What would you add/change to make this production-ready? Consider: PII handling, audit logging, denial management, human-in-the-loop review.

---

## Evaluation Rubric

| Component | Points |
|-----------|--------|
| S3 structure and KB creation | 15 |
| Lambda ICD-10 function working | 20 |
| All 3 agents created and tested individually | 25 |
| Bedrock Flow with all nodes wired | 25 |
| Generated claim JSON is structurally valid | 10 |
| Written reflection | 5 |
| **Total** | **100** |

---

## Hints and Gotchas

- **Agent input/output schema:** Bedrock Agents expect the user message as plain text. When passing data between agents in a flow, use a **Prompt node** to format the upstream JSON output into a natural language prompt before feeding it to the next agent.
- **Lambda action group schema:** Your OpenAPI schema must be valid JSON. Test it at https://editor.swagger.io before uploading to Bedrock.
- **Knowledge Base sync:** After uploading new files to S3, you must re-sync the KB from the console or via `start_ingestion_job` API.
- **Flow variables:** Bedrock Flows support passing variables between nodes. Use dot notation to reference nested fields (e.g., `DiagnosisExtraction.output.diagnoses`).
- **Cost:** Claude 3 Haiku is ~20x cheaper than Sonnet. Use Haiku for development and switch to Sonnet for final testing.
- **Region:** All resources (S3, Lambda, Bedrock KB, Agents, Flow) must be in the same region. `us-east-1` has the broadest Bedrock model availability.

---

## File Reference

```
bedrock_flow/
  ASSIGNMENT.md                          <- You are here
  architecture/
    flow_diagram.md                      <- Mermaid architecture diagram
  data/
    policy_inclusions.json               <- 3 plan tiers x 15 covered conditions
    policy_exclusions.json               <- Universal + plan-specific exclusions
    drug_formulary.json                  <- Tier 1-4 drug coverage
    icd10_reference.json                 <- 50 common ICD-10 codes
    patient_discharge_notes/
      P001_discharge_note.txt            <- Diabetic patient, cardiac event
      P002_discharge_note.txt            <- Orthopedic surgery
      P003_discharge_note.txt            <- Maternity / OB case
  lambda/
    icd10_lookup/
      lambda_function.py                 <- ICD-10 NLM API wrapper
      openapi_schema.json                <- Action group schema
    npi_lookup/
      lambda_function.py                 <- NPPES NPI Registry wrapper
      openapi_schema.json
    write_claim_to_s3/
      lambda_function.py                 <- Writes final claim to S3
  starter_code/
    upload_data.py                       <- Bulk upload data/ to S3
    create_knowledge_base.py             <- Programmatic KB creation
    invoke_flow.py                       <- Test flow end-to-end
```
