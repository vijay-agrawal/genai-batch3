# Insurance Claim Processing — Architecture & Flow Diagrams

## High-Level System Architecture

```mermaid
graph TB
    subgraph "Data Preparation (One-time Setup)"
        D1[policy_inclusions.json]
        D2[policy_exclusions.json]
        D3[drug_formulary.json]
        D4[icd10_reference.json]
        D1 & D2 & D3 & D4 -->|upload_data.py| S3KB[(S3: knowledge-base/)]
        S3KB -->|Bedrock Sync| KB[(Amazon Bedrock\nKnowledge Base\nInsurancePolicyKB)]
    end

    subgraph "External Public APIs"
        API1[NLM ICD-10-CM API\nclinicaltables.nlm.nih.gov]
        API2[NPPES NPI Registry\nnpiregistry.cms.hhs.gov]
        API3[OpenFDA Drug API\napi.fda.gov]
    end

    subgraph "AWS Lambda Functions"
        L1[icd10-lookup\nlambda_function.py]
        L2[npi-lookup\nlambda_function.py]
        L3[write-claim-to-s3\nlambda_function.py]
        L1 -->|HTTPS| API1
        L2 -->|HTTPS| API2
    end

    subgraph "Amazon Bedrock Agents"
        AG1[DiagnosisExtractionAgent\nClaude 3 Sonnet]
        AG2[PolicyEligibilityAgent\nClaude 3 Sonnet]
        AG3[ClaimFormBuilderAgent\nClaude 3 Sonnet]
        AG1 -->|Action Group| L1
        AG1 -->|Action Group| L2
        AG2 -->|KB Query| KB
        AG3 -->|Synthesizes| AG3
    end

    subgraph "Amazon Bedrock Flow"
        FI[FlowInput\npatient_id\ndischarge_note\npolicy_id]
        N1[Agent Node 1\nDiagnosisExtraction]
        N2[Agent Node 2\nPolicyEligibility]
        N3[Agent Node 3\nClaimFormBuilder]
        N4[Lambda Node\nWriteToS3]
        FO[FlowOutput\nclaim_id\nsummary]

        FI --> N1 --> N2 --> N3 --> N4 --> FO
        N1 --- AG1
        N2 --- AG2
        N3 --- AG3
        N4 --- L3
    end

    subgraph "S3 Storage"
        S3P[(S3: patients/\nP001/discharge_note.txt\nP002/discharge_note.txt)]
        S3C[(S3: claims/\nP001/claim.json\nP002/claim.json)]
    end

    %% Inputs / Outputs
    User([Caller / Application]) -->|invoke_flow.py| FI
    S3P -->|Read discharge note| FI
    N4 -->|PutObject| S3C
    FO --> User

    style KB fill:#FF9900,color:#fff
    style AG1 fill:#232F3E,color:#fff
    style AG2 fill:#232F3E,color:#fff
    style AG3 fill:#232F3E,color:#fff
    style L1 fill:#FF9900,color:#fff
    style L2 fill:#FF9900,color:#fff
    style L3 fill:#FF9900,color:#fff
    style FI fill:#146EB4,color:#fff
    style FO fill:#146EB4,color:#fff
```

---

## Bedrock Flow Node Detail

```mermaid
sequenceDiagram
    actor Caller
    participant Flow as Bedrock Flow
    participant Agent1 as DiagnosisExtraction<br/>Agent
    participant ICD as icd10-lookup<br/>Lambda
    participant NPI as npi-lookup<br/>Lambda
    participant NLM as NLM API
    participant NPPES as NPPES API
    participant Agent2 as PolicyEligibility<br/>Agent
    participant KB as InsurancePolicyKB
    participant Agent3 as ClaimFormBuilder<br/>Agent
    participant S3Writer as write-claim-to-s3<br/>Lambda
    participant S3 as S3 Bucket

    Caller->>Flow: {patient_id, policy_id, discharge_note}

    Flow->>Agent1: Process discharge note
    Agent1->>Agent1: Extract diagnoses, procedures,<br/>provider, dates from note

    loop For each diagnosis
        Agent1->>ICD: lookup_icd10_code(diagnosis_description)
        ICD->>NLM: GET /icd10cm/v3/search?terms=...
        NLM-->>ICD: [{code, description}]
        ICD-->>Agent1: ICD-10-CM codes
    end

    Agent1->>NPI: get_provider_by_npi(npi_number)
    NPI->>NPPES: GET /api/?number=...
    NPPES-->>NPI: Provider details
    NPI-->>Agent1: {name, specialty, address, status}

    Agent1-->>Flow: {diagnoses[], procedures[], provider, dates}

    Flow->>Agent2: diagnoses[] + policy_id
    Agent2->>KB: "Is ICD-10 I50.9 covered under GOLD-001?"
    KB-->>Agent2: Policy excerpt + coverage rules
    Agent2->>KB: "What is the coinsurance for cardiac surgery?"
    KB-->>Agent2: Cost-share details

    Agent2->>Agent2: Apply deductible, copay, coinsurance logic
    Agent2-->>Flow: {coverage_decisions[], total_billed, total_allowed, patient_liability}

    Flow->>Agent3: All structured data from Agents 1 & 2
    Agent3->>Agent3: Assemble CMS-1500 equivalent JSON
    Agent3->>Agent3: Validate required fields
    Agent3-->>Flow: completed_claim JSON

    Flow->>S3Writer: {patient_id, claim_json}
    S3Writer->>S3: PutObject → claims/P001/claim.json
    S3-->>S3Writer: 200 OK
    S3Writer-->>Flow: {claim_id, s3_uri, status: SUBMITTED}

    Flow-->>Caller: {claim_id, total_billed, total_allowed, patient_liability, status}
```

---

## Data Flow: What Each Agent Receives and Produces

### FlowInput
**Input fields:**
```json
{
  "patient_id": "P001",
  "policy_id": "GOLD-001",
  "discharge_note": "<full discharge note text>"
}
```

### Agent 1 — DiagnosisExtractionAgent
**Receives:** `discharge_note` (plain text)
**Produces:**
```json
{
  "patient_name": "Robert J. Martinez",
  "patient_dob": "03/14/1958",
  "admission_date": "03/10/2024",
  "discharge_date": "03/15/2024",
  "provider_name": "Dr. Priya Nair, MD",
  "provider_npi": "1538197452",
  "provider_specialty": "Internal Medicine",
  "facility_name": "Riverside General Hospital",
  "facility_npi": "1234567890",
  "diagnoses": [
    { "description": "Acute exacerbation of congestive heart failure", "icd10_code": "I50.9" },
    { "description": "Type 2 diabetes mellitus with hyperglycemia", "icd10_code": "E11.65" },
    { "description": "Essential hypertension", "icd10_code": "I10" },
    { "description": "Atrial fibrillation persistent", "icd10_code": "I48" },
    { "description": "Hyperlipidemia", "icd10_code": "E78.5" }
  ],
  "procedures": [
    { "description": "12-lead EKG", "cpt_code": "93000", "date": "03/10/2024" },
    { "description": "Echocardiogram with Doppler", "cpt_code": "93306", "date": "03/11/2024" },
    { "description": "Right heart catheterization", "cpt_code": "93453", "date": "03/12/2024" }
  ],
  "total_billed": 30800.00
}
```

### Agent 2 — PolicyEligibilityAgent
**Receives:** Agent 1 output + `policy_id`
**Produces:**
```json
{
  "policy_id": "GOLD-001",
  "plan_name": "Gold Premier",
  "annual_deductible": 1000.00,
  "deductible_met_ytd": 0.00,
  "coinsurance_pct": 10,
  "coverage_decisions": [
    { "code": "I50.9", "description": "CHF", "covered": true,
      "reason": "Cardiac inpatient covered at 10% coinsurance after deductible",
      "billed_amount": 14500.00, "allowed_amount": 12000.00 },
    { "code": "93453", "description": "Right heart catheterization", "covered": true,
      "reason": "Cardiovascular procedure covered", "billed_amount": 3200.00, "allowed_amount": 2800.00 }
  ],
  "total_billed": 30800.00,
  "total_allowed": 25400.00,
  "plan_paid": 24400.00,
  "patient_liability": 1000.00,
  "liability_breakdown": {
    "deductible": 1000.00,
    "copay": 0.00,
    "coinsurance": 0.00,
    "non_covered": 0.00
  }
}
```

### Agent 3 — ClaimFormBuilderAgent
**Receives:** Both prior agent outputs
**Produces:** Complete CMS-1500 equivalent claim (see `sample_outputs/P001_claim.json`)

---

## AWS Services and IAM Permissions Summary

| Service | Purpose | IAM Permissions Needed |
|---------|---------|----------------------|
| S3 | Store KB data, discharge notes, claim output | `s3:GetObject`, `s3:PutObject`, `s3:ListBucket` |
| Bedrock | Knowledge Base, Agents, Flows | `bedrock:InvokeModel`, `bedrock:Retrieve`, `bedrock:InvokeAgent`, `bedrock:InvokeFlow` |
| Lambda | ICD-10 lookup, NPI lookup, S3 writer | `lambda:InvokeFunction`; S3 writer needs `s3:PutObject` |
| OpenSearch Serverless | Vector store for KB | Auto-managed by Bedrock |
| CloudWatch Logs | Flow and Lambda logs | `logs:CreateLogGroup`, `logs:PutLogEvents` |

---

## Cost Estimation (for Assignment Development and Testing)

| Component | Estimated Cost |
|-----------|---------------|
| Bedrock KB (OpenSearch Serverless) | ~$0.24/hr (~$2/day while active — delete after assignment!) |
| Claude 3 Sonnet per flow invocation | ~$0.05–$0.15 (3 agents × ~1,000 tokens each) |
| Claude 3 Haiku per flow invocation | ~$0.003–$0.01 (much cheaper for development) |
| Lambda invocations | < $0.01 |
| S3 storage (small dataset) | < $0.01 |
| **Total for 10-20 test invocations** | **~$2–5** |

> **Important:** Delete the OpenSearch Serverless collection when done to avoid ongoing charges.
