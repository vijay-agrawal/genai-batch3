"""
Lambda function: NPPES NPI Registry Lookup
-------------------------------------------
Wraps the CMS NPPES NPI Registry public API for use as an Amazon Bedrock Agent action group.

Public API: https://npiregistry.cms.hhs.gov/api-page
No authentication required.

Functions:
  - get_provider_by_npi(npi_number)          -> provider details
  - search_provider(name, state, specialty)  -> list of matching providers
"""

import json
import urllib.request
import urllib.parse
import urllib.error
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

NPPES_API_BASE = "https://npiregistry.cms.hhs.gov/api/"


def get_provider_by_npi(npi_number: str) -> dict:
    """
    Look up a provider by their exact NPI number.

    Args:
        npi_number: 10-digit NPI number

    Returns:
        dict with provider details or error
    """
    params = urllib.parse.urlencode({
        "number": npi_number,
        "version": "2.1"
    })
    url = f"{NPPES_API_BASE}?{params}"

    logger.info(f"NPI lookup URL: {url}")

    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.URLError as e:
        logger.error(f"NPPES API call failed: {e}")
        return {"error": str(e)}

    results = data.get("results", [])
    if not results:
        return {"error": f"No provider found with NPI {npi_number}"}

    provider = results[0]
    return _parse_provider(provider)


def search_provider(last_name: str = "", first_name: str = "",
                    state: str = "", taxonomy_description: str = "") -> dict:
    """
    Search for providers by name and/or state.

    Args:
        last_name: Provider's last name (or organization name)
        first_name: Provider's first name
        state: Two-letter state code (e.g., TX)
        taxonomy_description: Specialty description (e.g., "cardiology")

    Returns:
        dict with list of matching providers
    """
    query_params = {"version": "2.1", "limit": 5}
    if last_name:
        query_params["last_name"] = last_name
    if first_name:
        query_params["first_name"] = first_name
    if state:
        query_params["state"] = state
    if taxonomy_description:
        query_params["taxonomy_description"] = taxonomy_description

    params = urllib.parse.urlencode(query_params)
    url = f"{NPPES_API_BASE}?{params}"

    logger.info(f"NPI search URL: {url}")

    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.URLError as e:
        return {"error": str(e), "results": []}

    results = data.get("results", [])
    return {
        "total": data.get("result_count", len(results)),
        "providers": [_parse_provider(p) for p in results]
    }


def _parse_provider(provider: dict) -> dict:
    """Extract the most relevant fields from an NPPES provider record."""
    basic = provider.get("basic", {})
    addresses = provider.get("addresses", [])
    taxonomies = provider.get("taxonomies", [])

    # Get primary practice address
    practice_address = {}
    for addr in addresses:
        if addr.get("address_purpose") == "LOCATION":
            practice_address = addr
            break

    # Get primary taxonomy (specialty)
    primary_taxonomy = {}
    for tax in taxonomies:
        if tax.get("primary"):
            primary_taxonomy = tax
            break

    return {
        "npi": provider.get("number"),
        "entity_type": provider.get("enumeration_type"),  # NPI-1 (individual) or NPI-2 (org)
        "name": {
            "first": basic.get("first_name", ""),
            "last": basic.get("last_name", ""),
            "credential": basic.get("credential", ""),
            "organization": basic.get("organization_name", "")
        },
        "specialty": {
            "taxonomy_code": primary_taxonomy.get("code", ""),
            "description": primary_taxonomy.get("desc", ""),
            "license_state": primary_taxonomy.get("state", "")
        },
        "address": {
            "street": practice_address.get("address_1", ""),
            "city": practice_address.get("city", ""),
            "state": practice_address.get("state", ""),
            "zip": practice_address.get("postal_code", ""),
            "phone": practice_address.get("telephone_number", "")
        },
        "status": basic.get("status", "")
    }


def lambda_handler(event, context):
    """
    Main Lambda handler for Bedrock Agent action group invocation.

    Expected event:
    {
        "actionGroup": "DiagnosisTools",
        "function": "get_provider_by_npi" | "search_provider",
        "parameters": [
            {"name": "npi_number", "value": "1234567890"}
        ]
    }
    """
    logger.info(f"Event: {json.dumps(event)}")

    action_group = event.get("actionGroup", "DiagnosisTools")
    function_name = event.get("function", "")
    parameters = {
        param["name"]: param["value"]
        for param in event.get("parameters", [])
    }

    if function_name == "get_provider_by_npi":
        npi_number = parameters.get("npi_number", "")
        if not npi_number:
            result = {"error": "Parameter 'npi_number' is required"}
        else:
            result = get_provider_by_npi(npi_number)

    elif function_name == "search_provider":
        result = search_provider(
            last_name=parameters.get("last_name", ""),
            first_name=parameters.get("first_name", ""),
            state=parameters.get("state", ""),
            taxonomy_description=parameters.get("taxonomy_description", "")
        )

    else:
        result = {"error": f"Unknown function: {function_name}"}

    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": action_group,
            "function": function_name,
            "functionResponse": {
                "responseBody": {
                    "TEXT": {
                        "body": json.dumps(result)
                    }
                }
            }
        }
    }
