"""
Lambda function: Write Completed Claim to S3
---------------------------------------------
Called as the final step in the Bedrock Flow.
Receives the completed claim JSON from the ClaimFormBuilderAgent and
writes it to S3 at: s3://{BUCKET}/{CLAIMS_PREFIX}/{patient_id}/claim.json

Environment variables:
  S3_BUCKET_NAME  - The S3 bucket name (e.g., bedrock-claims-yourname)
  CLAIMS_PREFIX   - S3 prefix for claims (default: claims)

IAM Role needs: s3:PutObject on your bucket/claims prefix
"""

import json
import os
import uuid
import logging
from datetime import datetime, timezone

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client("s3")

BUCKET_NAME = os.environ.get("S3_BUCKET_NAME", "bedrock-claims-yourname")
CLAIMS_PREFIX = os.environ.get("CLAIMS_PREFIX", "claims")


def write_claim(patient_id: str, claim_data: dict) -> dict:
    """
    Write the claim JSON to S3 and return the S3 URI and claim ID.

    Args:
        patient_id: Patient identifier (used as folder name)
        claim_data: The completed claim dict from ClaimFormBuilderAgent

    Returns:
        dict with claim_id, s3_uri, and summary fields
    """
    # Generate a deterministic claim ID
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    claim_id = f"CLM-{patient_id}-{timestamp}"

    # Enrich the claim with metadata before writing
    claim_data["claim_id"] = claim_id
    claim_data["patient_id"] = patient_id
    claim_data["submitted_at"] = datetime.now(timezone.utc).isoformat()
    claim_data["processing_system"] = "BedrockFlow-ClaimProcessor-v1"
    claim_data["status"] = claim_data.get("status", "SUBMITTED")

    s3_key = f"{CLAIMS_PREFIX}/{patient_id}/claim.json"

    logger.info(f"Writing claim {claim_id} to s3://{BUCKET_NAME}/{s3_key}")

    s3_client.put_object(
        Bucket=BUCKET_NAME,
        Key=s3_key,
        Body=json.dumps(claim_data, indent=2, default=str),
        ContentType="application/json",
        Metadata={
            "claim-id": claim_id,
            "patient-id": patient_id,
            "submitted-at": claim_data["submitted_at"]
        }
    )

    s3_uri = f"s3://{BUCKET_NAME}/{s3_key}"
    logger.info(f"Successfully wrote claim to {s3_uri}")

    return {
        "claim_id": claim_id,
        "s3_uri": s3_uri,
        "patient_id": patient_id,
        "status": claim_data["status"],
        "total_billed": claim_data.get("total_billed", 0),
        "total_allowed": claim_data.get("total_allowed", 0),
        "patient_liability": claim_data.get("patient_liability", 0),
        "submitted_at": claim_data["submitted_at"]
    }


def lambda_handler(event, context):
    """
    Bedrock Agent / Bedrock Flow Lambda handler.

    Can be invoked from:
    1. Bedrock Flow (as a Lambda node)
    2. Bedrock Agent action group

    Event structure (Bedrock Flow Lambda node):
    {
        "patient_id": "P001",
        "claim_json": "{...}"  or claim as dict
    }

    Event structure (Bedrock Agent action group):
    {
        "actionGroup": "ClaimOutputTools",
        "function": "write_claim_to_s3",
        "parameters": [
            {"name": "patient_id", "value": "P001"},
            {"name": "claim_json", "value": "{...}"}
        ]
    }
    """
    logger.info(f"Event: {json.dumps(event, default=str)}")

    # Handle both Bedrock Agent and direct/Flow invocation
    if "function" in event and "parameters" in event:
        # Bedrock Agent action group invocation
        action_group = event.get("actionGroup", "ClaimOutputTools")
        function_name = event.get("function", "write_claim_to_s3")
        parameters = {
            param["name"]: param["value"]
            for param in event.get("parameters", [])
        }

        patient_id = parameters.get("patient_id", "UNKNOWN")
        claim_json_str = parameters.get("claim_json", "{}")

        # Parse the claim JSON (it may arrive as a string)
        if isinstance(claim_json_str, str):
            try:
                claim_data = json.loads(claim_json_str)
            except json.JSONDecodeError:
                claim_data = {"raw_claim": claim_json_str}
        else:
            claim_data = claim_json_str

        result = write_claim(patient_id, claim_data)

        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": action_group,
                "function": function_name,
                "functionResponse": {
                    "responseBody": {
                        "TEXT": {
                            "body": json.dumps(result)
                        }
                    }
                }
            }
        }

    else:
        # Direct invocation from Bedrock Flow Lambda node or test event
        patient_id = event.get("patient_id", "UNKNOWN")
        claim_data = event.get("claim_json", event.get("claim", {}))

        if isinstance(claim_data, str):
            try:
                claim_data = json.loads(claim_data)
            except json.JSONDecodeError:
                claim_data = {"raw": claim_data}

        result = write_claim(patient_id, claim_data)
        return result
