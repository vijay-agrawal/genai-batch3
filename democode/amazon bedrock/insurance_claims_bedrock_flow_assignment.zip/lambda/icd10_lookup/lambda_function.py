"""
Lambda function: ICD-10-CM Code Lookup
---------------------------------------
Wraps the NLM Clinical Tables ICD-10-CM API for use as an Amazon Bedrock Agent action group.

Public API: https://clinicaltables.nlm.nih.gov/apidoc/icd10cm/v3/doc.html
No authentication required.

Bedrock Agent invokes this Lambda via an action group with the following functions:
  - lookup_icd10_code(diagnosis_description) -> list of {code, description}
  - get_icd10_details(icd10_code)            -> {code, description, category}
"""

import json
import urllib.request
import urllib.parse
import urllib.error
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

NLM_API_BASE = "https://clinicaltables.nlm.nih.gov/api/icd10cm/v3/search"


def lookup_icd10_code(diagnosis_description: str, max_results: int = 5) -> dict:
    """
    Search ICD-10-CM codes by diagnosis description text.

    Args:
        diagnosis_description: Free-text description (e.g., "type 2 diabetes")
        max_results: Maximum number of results to return (default 5)

    Returns:
        dict with 'results' list of {code, description} and 'total' count
    """
    params = urllib.parse.urlencode({
        "sf": "code,name",
        "terms": diagnosis_description,
        "maxList": max_results
    })
    url = f"{NLM_API_BASE}?{params}"

    logger.info(f"ICD-10 lookup URL: {url}")

    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.URLError as e:
        logger.error(f"API call failed: {e}")
        return {"error": str(e), "results": []}

    # NLM API response format: [total, [codes], null, [[code, description], ...]]
    # Index 0: total count
    # Index 3: list of [code, description] pairs
    total = data[0] if len(data) > 0 else 0
    code_pairs = data[3] if len(data) > 3 and data[3] else []

    results = [
        {"code": pair[0], "description": pair[1]}
        for pair in code_pairs
    ]

    logger.info(f"Found {total} total results, returning {len(results)}")
    return {
        "total": total,
        "results": results,
        "query": diagnosis_description
    }


def get_icd10_details(icd10_code: str) -> dict:
    """
    Look up details for a specific ICD-10-CM code.

    Args:
        icd10_code: Exact ICD-10-CM code (e.g., "E11.65")

    Returns:
        dict with code details or error message
    """
    params = urllib.parse.urlencode({
        "sf": "code,name",
        "terms": icd10_code,
        "maxList": 10
    })
    url = f"{NLM_API_BASE}?{params}"

    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.URLError as e:
        return {"error": str(e)}

    code_pairs = data[3] if len(data) > 3 and data[3] else []

    # Find exact match first
    for pair in code_pairs:
        if pair[0].upper() == icd10_code.upper():
            return {"code": pair[0], "description": pair[1], "exact_match": True}

    # Return closest match if no exact match
    if code_pairs:
        return {"code": code_pairs[0][0], "description": code_pairs[0][1], "exact_match": False}

    return {"error": f"ICD-10 code '{icd10_code}' not found", "code": icd10_code}


def format_agent_response(result: dict) -> dict:
    """
    Format the response in the structure Amazon Bedrock Agent expects.
    https://docs.aws.amazon.com/bedrock/latest/userguide/agents-lambda.html
    """
    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": "DiagnosisTools",
            "function": "lookup_icd10_code",
            "functionResponse": {
                "responseBody": {
                    "TEXT": {
                        "body": json.dumps(result)
                    }
                }
            }
        }
    }


def lambda_handler(event, context):
    """
    Main Lambda handler. Invoked by Amazon Bedrock Agent action group.

    Expected event structure from Bedrock Agent:
    {
        "actionGroup": "DiagnosisTools",
        "function": "lookup_icd10_code" | "get_icd10_details",
        "parameters": [
            {"name": "diagnosis_description", "type": "string", "value": "..."}
        ]
    }
    """
    logger.info(f"Received event: {json.dumps(event)}")

    # Extract function name and parameters from Bedrock Agent event
    action_group = event.get("actionGroup", "DiagnosisTools")
    function_name = event.get("function", "")
    parameters = {
        param["name"]: param["value"]
        for param in event.get("parameters", [])
    }

    logger.info(f"Function: {function_name}, Parameters: {parameters}")

    # Route to the appropriate function
    if function_name == "lookup_icd10_code":
        diagnosis_description = parameters.get("diagnosis_description", "")
        if not diagnosis_description:
            result = {"error": "Parameter 'diagnosis_description' is required"}
        else:
            result = lookup_icd10_code(
                diagnosis_description,
                max_results=int(parameters.get("max_results", 5))
            )

    elif function_name == "get_icd10_details":
        icd10_code = parameters.get("icd10_code", "")
        if not icd10_code:
            result = {"error": "Parameter 'icd10_code' is required"}
        else:
            result = get_icd10_details(icd10_code)

    else:
        result = {"error": f"Unknown function: {function_name}"}

    # Return in Bedrock Agent response format
    response = {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": action_group,
            "function": function_name,
            "functionResponse": {
                "responseBody": {
                    "TEXT": {
                        "body": json.dumps(result)
                    }
                }
            }
        }
    }

    logger.info(f"Returning response: {json.dumps(response)}")
    return response
