"""
upload_data.py
--------------
Uploads the synthetic insurance data and patient discharge notes to your S3 bucket.

Usage:
    python starter_code/upload_data.py --bucket bedrock-claims-yourname --region us-east-1

Prerequisites:
    pip install boto3
    AWS credentials configured (aws configure or IAM role)
"""

import argparse
import os
import sys
import boto3
from pathlib import Path
from botocore.exceptions import ClientError

# Resolve project root relative to this script
PROJECT_ROOT = Path(__file__).parent.parent


def upload_knowledge_base_data(s3_client, bucket: str, dry_run: bool = False):
    """Upload reference data files to the knowledge-base/ S3 prefix."""
    data_dir = PROJECT_ROOT / "data"
    kb_files = [
        "policy_inclusions.json",
        "policy_exclusions.json",
        "drug_formulary.json",
        "icd10_reference.json",
    ]

    print("\n--- Uploading Knowledge Base Reference Data ---")
    for filename in kb_files:
        local_path = data_dir / filename
        if not local_path.exists():
            print(f"  [WARN] {local_path} not found — skipping")
            continue
        s3_key = f"knowledge-base/{filename}"
        _upload_file(s3_client, bucket, str(local_path), s3_key, dry_run)


def upload_patient_notes(s3_client, bucket: str, dry_run: bool = False):
    """Upload patient discharge notes to patients/{patient_id}/discharge_note.txt."""
    notes_dir = PROJECT_ROOT / "data" / "patient_discharge_notes"
    if not notes_dir.exists():
        print(f"  [WARN] {notes_dir} not found — skipping patient notes upload")
        return

    print("\n--- Uploading Patient Discharge Notes ---")
    for note_file in sorted(notes_dir.glob("*.txt")):
        # Extract patient ID from filename: P001_discharge_note.txt -> P001
        patient_id = note_file.stem.split("_")[0]
        s3_key = f"patients/{patient_id}/discharge_note.txt"
        _upload_file(s3_client, bucket, str(note_file), s3_key, dry_run)


def create_placeholder_claim_folders(s3_client, bucket: str, dry_run: bool = False):
    """Create empty placeholder objects to establish the claims/ folder structure."""
    print("\n--- Creating claims/ folder placeholders ---")
    patient_ids = ["P001", "P002", "P003"]
    for patient_id in patient_ids:
        s3_key = f"claims/{patient_id}/.keep"
        if dry_run:
            print(f"  [DRY RUN] Would create s3://{bucket}/{s3_key}")
        else:
            s3_client.put_object(Bucket=bucket, Key=s3_key, Body=b"")
            print(f"  Created s3://{bucket}/{s3_key}")


def _upload_file(s3_client, bucket: str, local_path: str, s3_key: str, dry_run: bool):
    if dry_run:
        print(f"  [DRY RUN] Would upload {local_path} -> s3://{bucket}/{s3_key}")
        return
    try:
        content_type = "application/json" if s3_key.endswith(".json") else "text/plain"
        s3_client.upload_file(
            local_path,
            bucket,
            s3_key,
            ExtraArgs={"ContentType": content_type}
        )
        size = os.path.getsize(local_path)
        print(f"  Uploaded ({size:,} bytes): s3://{bucket}/{s3_key}")
    except ClientError as e:
        print(f"  [ERROR] Failed to upload {local_path}: {e}")
        sys.exit(1)


def verify_bucket_access(s3_client, bucket: str):
    """Check that the bucket exists and we have write access."""
    try:
        s3_client.head_bucket(Bucket=bucket)
        print(f"Bucket s3://{bucket} — accessible")
    except ClientError as e:
        code = e.response["Error"]["Code"]
        if code == "404":
            print(f"[ERROR] Bucket '{bucket}' does not exist. Create it first.")
        elif code == "403":
            print(f"[ERROR] Access denied to bucket '{bucket}'. Check your IAM permissions.")
        else:
            print(f"[ERROR] {e}")
        sys.exit(1)


def print_summary(bucket: str):
    print(f"""
=== Upload Complete ===

Your S3 bucket structure:
  s3://{bucket}/
    knowledge-base/
      policy_inclusions.json
      policy_exclusions.json
      drug_formulary.json
      icd10_reference.json
    patients/
      P001/discharge_note.txt
      P002/discharge_note.txt
      P003/discharge_note.txt
    claims/
      P001/
      P002/
      P003/

Next steps:
  1. Open Amazon Bedrock console -> Knowledge Bases -> Create
  2. Data source: s3://{bucket}/knowledge-base/
  3. Embeddings: Amazon Titan Embeddings G1 - Text
  4. Click 'Create and Sync'
  5. Wait for sync to complete (typically 2-5 minutes)
""")


def main():
    parser = argparse.ArgumentParser(
        description="Upload synthetic healthcare data to S3 for the Bedrock Flow assignment"
    )
    parser.add_argument("--bucket", required=True, help="S3 bucket name")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print what would be uploaded without actually uploading")
    args = parser.parse_args()

    print(f"Region: {args.region}")
    print(f"Bucket: s3://{args.bucket}")
    if args.dry_run:
        print("Mode: DRY RUN (no files will be uploaded)")

    s3_client = boto3.client("s3", region_name=args.region)

    if not args.dry_run:
        verify_bucket_access(s3_client, args.bucket)

    upload_knowledge_base_data(s3_client, args.bucket, args.dry_run)
    upload_patient_notes(s3_client, args.bucket, args.dry_run)
    create_placeholder_claim_folders(s3_client, args.bucket, args.dry_run)

    if not args.dry_run:
        print_summary(args.bucket)


if __name__ == "__main__":
    main()
