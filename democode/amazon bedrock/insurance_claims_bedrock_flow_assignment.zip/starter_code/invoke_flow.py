"""
invoke_flow.py
--------------
End-to-end test script for the InsuranceClaimProcessingFlow.
Reads a patient discharge note from S3 (or local file), invokes the Bedrock Flow,
and prints the resulting claim summary.

Usage:
    python starter_code/invoke_flow.py \
        --flow-id <your-flow-id> \
        --flow-alias-id <your-alias-id> \
        --bucket bedrock-claims-yourname \
        --patient-id P001 \
        --policy-id GOLD-001 \
        --region us-east-1

Prereqs:
    pip install boto3
    Flow must be deployed with an alias in the Bedrock console
"""

import argparse
import json
import sys
import time
from pathlib import Path

import boto3

PROJECT_ROOT = Path(__file__).parent.parent


def read_discharge_note(bucket: str, patient_id: str, region: str) -> str:
    """Read discharge note from S3 or fall back to local file."""
    # Try S3 first
    try:
        s3_client = boto3.client("s3", region_name=region)
        response = s3_client.get_object(
            Bucket=bucket,
            Key=f"patients/{patient_id}/discharge_note.txt"
        )
        content = response["Body"].read().decode("utf-8")
        print(f"Read discharge note from S3 ({len(content)} chars)")
        return content
    except Exception as e:
        print(f"Could not read from S3 ({e}), falling back to local file...")

    # Fall back to local file
    local_path = PROJECT_ROOT / "data" / "patient_discharge_notes" / f"{patient_id}_discharge_note.txt"
    if local_path.exists():
        content = local_path.read_text(encoding="utf-8")
        print(f"Read discharge note from local file ({len(content)} chars)")
        return content

    print(f"[ERROR] Could not find discharge note for patient {patient_id}")
    sys.exit(1)


def invoke_flow(
    client,
    flow_id: str,
    flow_alias_id: str,
    patient_id: str,
    policy_id: str,
    discharge_note: str
) -> dict:
    """
    Invoke the Bedrock Flow and stream the response.
    Returns the final output payload.
    """
    print(f"\nInvoking flow {flow_id} (alias: {flow_alias_id})...")
    print(f"  patient_id: {patient_id}")
    print(f"  policy_id:  {policy_id}")
    print(f"  note length: {len(discharge_note)} chars")

    # The Flow input must match your FlowInput node's defined fields
    flow_input = {
        "patient_id": patient_id,
        "policy_id": policy_id,
        "discharge_note": discharge_note
    }

    start_time = time.time()

    response = client.invoke_flow(
        flowIdentifier=flow_id,
        flowAliasIdentifier=flow_alias_id,
        inputs=[
            {
                "nodeName": "FlowInput",
                "nodeOutputName": "document",
                "content": {
                    "document": flow_input
                }
            }
        ]
    )

    # Collect streaming response events
    output_payload = {}
    event_stream = response.get("responseStream", [])

    for event in event_stream:
        if "flowOutputEvent" in event:
            output = event["flowOutputEvent"]
            content = output.get("content", {})
            if "document" in content:
                output_payload = content["document"]
                print(f"\n  Flow output received: {json.dumps(output_payload, indent=2)}")

        elif "flowCompletionEvent" in event:
            completion = event["flowCompletionEvent"]
            print(f"\n  Flow completed. Reason: {completion.get('completionReason', 'UNKNOWN')}")

        elif "flowTraceEvent" in event and "--verbose" in sys.argv:
            # Print trace events when running with --verbose
            trace = event["flowTraceEvent"].get("trace", {})
            node = trace.get("nodeName", "")
            trace_type = list(trace.keys())[-1] if trace else ""
            print(f"    [TRACE] Node={node} Type={trace_type}")

    elapsed = time.time() - start_time
    print(f"\n  Total flow execution time: {elapsed:.1f}s")

    return output_payload


def print_claim_summary(output: dict):
    print("\n" + "=" * 60)
    print("CLAIM PROCESSING SUMMARY")
    print("=" * 60)
    for key, value in output.items():
        if isinstance(value, (int, float)):
            if "amount" in key.lower() or "billed" in key.lower() or "liability" in key.lower() or "allowed" in key.lower():
                print(f"  {key:<25} ${value:>10,.2f}")
            else:
                print(f"  {key:<25} {value}")
        else:
            print(f"  {key:<25} {value}")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(description="Invoke the Insurance Claim Processing Bedrock Flow")
    parser.add_argument("--flow-id", required=True, help="Bedrock Flow ID")
    parser.add_argument("--flow-alias-id", required=True, help="Bedrock Flow Alias ID")
    parser.add_argument("--bucket", required=True, help="S3 bucket name")
    parser.add_argument("--patient-id", default="P001", help="Patient ID (P001, P002, P003)")
    parser.add_argument("--policy-id", default="GOLD-001", help="Policy ID (GOLD-001, SILVER-001, BRONZE-001)")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument("--verbose", action="store_true", help="Print trace events")
    args = parser.parse_args()

    # Add --verbose to sys.argv check in the invoke function
    if args.verbose:
        sys.argv.append("--verbose")

    # Read discharge note
    discharge_note = read_discharge_note(args.bucket, args.patient_id, args.region)

    # Invoke the flow
    bedrock_runtime = boto3.client("bedrock-agent-runtime", region_name=args.region)
    output = invoke_flow(
        bedrock_runtime,
        args.flow_id,
        args.flow_alias_id,
        args.patient_id,
        args.policy_id,
        discharge_note
    )

    if output:
        print_claim_summary(output)
    else:
        print("[WARN] Flow returned no output. Check CloudWatch logs for the flow execution.")
        print(f"  Log group: /aws/bedrock/flows/{args.flow_id}")


if __name__ == "__main__":
    main()
