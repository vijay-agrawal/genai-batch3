"""
create_knowledge_base.py
------------------------
Programmatically creates an Amazon Bedrock Knowledge Base backed by S3.
Run this AFTER upload_data.py has populated your S3 bucket.

Usage:
    python starter_code/create_knowledge_base.py \
        --bucket bedrock-claims-yourname \
        --region us-east-1 \
        --kb-role-arn arn:aws:iam::123456789012:role/BedrockKBRole

The IAM role (--kb-role-arn) needs:
  - AmazonBedrockFullAccess (or scoped Bedrock KB permissions)
  - s3:GetObject, s3:ListBucket on your data bucket
  - aoss:* on your OpenSearch Serverless collection (auto-created)

Prereqs:
    pip install boto3
"""

import argparse
import json
import time
import boto3
from botocore.exceptions import ClientError


def create_kb(bedrock_agent_client, s3_client, bucket: str, region: str, role_arn: str) -> dict:
    """
    Create a Bedrock Knowledge Base with an S3 data source.
    Returns the full KB configuration dict.
    """
    kb_name = "InsurancePolicyKB"
    embedding_model_arn = (
        f"arn:aws:bedrock:{region}::foundation-model/amazon.titan-embed-text-v1"
    )

    print(f"Creating Knowledge Base '{kb_name}'...")
    print(f"  Data source: s3://{bucket}/knowledge-base/")
    print(f"  Embeddings model: {embedding_model_arn}")
    print(f"  Execution role: {role_arn}")

    # Step 1: Create the Knowledge Base (Bedrock will provision OpenSearch Serverless)
    try:
        kb_response = bedrock_agent_client.create_knowledge_base(
            name=kb_name,
            description=(
                "Insurance policy inclusions, exclusions, drug formulary, and ICD-10 reference data "
                "for automated insurance claim processing."
            ),
            roleArn=role_arn,
            knowledgeBaseConfiguration={
                "type": "VECTOR",
                "vectorKnowledgeBaseConfiguration": {
                    "embeddingModelArn": embedding_model_arn
                }
            },
            storageConfiguration={
                "type": "OPENSEARCH_SERVERLESS",
                "opensearchServerlessConfiguration": {
                    "collectionArn": "",  # Leave empty — Bedrock auto-provisions
                    "vectorIndexName": "insurance-policy-index",
                    "fieldMapping": {
                        "vectorField": "embedding",
                        "textField": "text",
                        "metadataField": "metadata"
                    }
                }
            }
        )
    except bedrock_agent_client.exceptions.ConflictException:
        print(f"  Knowledge Base '{kb_name}' already exists — fetching existing...")
        existing = bedrock_agent_client.list_knowledge_bases(maxResults=20)
        for kb in existing.get("knowledgeBaseSummaries", []):
            if kb["name"] == kb_name:
                return kb
        raise

    kb_id = kb_response["knowledgeBase"]["knowledgeBaseId"]
    print(f"  Knowledge Base ID: {kb_id}")

    # Step 2: Wait for KB to become ACTIVE
    print("  Waiting for Knowledge Base to become ACTIVE (this may take 2-5 minutes)...")
    _wait_for_kb_active(bedrock_agent_client, kb_id)

    # Step 3: Add S3 data source
    print(f"  Adding S3 data source: s3://{bucket}/knowledge-base/")
    ds_response = bedrock_agent_client.create_data_source(
        knowledgeBaseId=kb_id,
        name="InsuranceS3DataSource",
        description="S3 bucket containing policy and reference data",
        dataSourceConfiguration={
            "type": "S3",
            "s3Configuration": {
                "bucketArn": f"arn:aws:s3:::{bucket}",
                "inclusionPrefixes": ["knowledge-base/"]
            }
        },
        vectorIngestionConfiguration={
            "chunkingConfiguration": {
                "chunkingStrategy": "FIXED_SIZE",
                "fixedSizeChunkingConfiguration": {
                    "maxTokens": 512,
                    "overlapPercentage": 20
                }
            }
        }
    )

    ds_id = ds_response["dataSource"]["dataSourceId"]
    print(f"  Data Source ID: {ds_id}")

    # Step 4: Start ingestion job
    print("  Starting ingestion job (syncing S3 data into vector store)...")
    ingest_response = bedrock_agent_client.start_ingestion_job(
        knowledgeBaseId=kb_id,
        dataSourceId=ds_id
    )

    job_id = ingest_response["ingestionJob"]["ingestionJobId"]
    print(f"  Ingestion Job ID: {job_id}")

    # Step 5: Wait for ingestion to complete
    print("  Waiting for ingestion to complete...")
    _wait_for_ingestion(bedrock_agent_client, kb_id, ds_id, job_id)

    result = {
        "knowledge_base_id": kb_id,
        "data_source_id": ds_id,
        "ingestion_job_id": job_id,
        "name": kb_name
    }

    print(f"\nKnowledge Base ready!")
    print(f"  KB ID: {kb_id}")
    print(f"  Save this ID — you will need it when creating your Bedrock Agents.")
    return result


def _wait_for_kb_active(client, kb_id: str, timeout_seconds: int = 300):
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        response = client.get_knowledge_base(knowledgeBaseId=kb_id)
        status = response["knowledgeBase"]["status"]
        print(f"    KB status: {status}")
        if status == "ACTIVE":
            return
        if status in ("FAILED", "DELETE_UNSUCCESSFUL"):
            raise RuntimeError(f"Knowledge Base entered terminal state: {status}")
        time.sleep(15)
    raise TimeoutError(f"Knowledge Base did not become ACTIVE within {timeout_seconds}s")


def _wait_for_ingestion(client, kb_id: str, ds_id: str, job_id: str, timeout_seconds: int = 300):
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        response = client.get_ingestion_job(
            knowledgeBaseId=kb_id,
            dataSourceId=ds_id,
            ingestionJobId=job_id
        )
        job = response["ingestionJob"]
        status = job["status"]
        stats = job.get("statistics", {})
        print(f"    Ingestion status: {status} | "
              f"Scanned: {stats.get('numberOfDocumentsScanned', 0)} | "
              f"Indexed: {stats.get('numberOfNewDocumentsIndexed', 0)} | "
              f"Failed: {stats.get('numberOfDocumentsFailed', 0)}")
        if status == "COMPLETE":
            return
        if status == "FAILED":
            raise RuntimeError(f"Ingestion job failed: {job.get('failureReasons', [])}")
        time.sleep(10)
    raise TimeoutError(f"Ingestion did not complete within {timeout_seconds}s")


def test_knowledge_base(bedrock_runtime_client, kb_id: str):
    """Run a quick retrieval test against the KB to verify it is working."""
    print("\n--- Testing Knowledge Base ---")
    test_queries = [
        "Is chemotherapy covered under the GOLD plan?",
        "What is the deductible for the Silver Select plan?",
        "Are fertility treatments covered?",
        "What tier is metformin on the drug formulary?"
    ]

    for query in test_queries:
        print(f"\n  Query: '{query}'")
        try:
            response = bedrock_runtime_client.retrieve(
                knowledgeBaseId=kb_id,
                retrievalQuery={"text": query},
                retrievalConfiguration={
                    "vectorSearchConfiguration": {"numberOfResults": 2}
                }
            )
            results = response.get("retrievalResults", [])
            if results:
                top = results[0]
                content = top.get("content", {}).get("text", "")[:200]
                score = top.get("score", 0)
                print(f"  Top result (score={score:.3f}): {content}...")
            else:
                print("  No results found")
        except Exception as e:
            print(f"  Error: {e}")


def main():
    parser = argparse.ArgumentParser(
        description="Create and populate an Amazon Bedrock Knowledge Base for the claims assignment"
    )
    parser.add_argument("--bucket", required=True, help="S3 bucket name")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument("--kb-role-arn", required=True,
                        help="IAM role ARN for the Knowledge Base execution role")
    parser.add_argument("--test-only", help="Skip creation, just test an existing KB ID")
    args = parser.parse_args()

    bedrock_agent_client = boto3.client("bedrock-agent", region_name=args.region)
    bedrock_runtime_client = boto3.client("bedrock-agent-runtime", region_name=args.region)
    s3_client = boto3.client("s3", region_name=args.region)

    if args.test_only:
        test_knowledge_base(bedrock_runtime_client, args.test_only)
    else:
        result = create_kb(bedrock_agent_client, s3_client, args.bucket, args.region, args.kb_role_arn)
        test_knowledge_base(bedrock_runtime_client, result["knowledge_base_id"])

        print("\n=== Save these IDs for the next steps ===")
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
