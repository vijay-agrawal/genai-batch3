# Patient Records & Clinical Data — City General Hospital

## PATIENTS

### Patient: Arjun Mehta  (ID: P-1001)
- Age: 67 | Gender: Male | Blood Group: B+
- Primary Physician: Dr. Sunita Rao (Cardiologist)
- Diagnosed Conditions: Type 2 Diabetes, Hypertension, Chronic Kidney Disease (Stage 3)
- Current Medications: Metformin 500 mg, Amlodipine 5 mg, Warfarin 5 mg
- Recent Lab: eGFR 42, HbA1c 8.1%, INR 2.3
- Allergies: Penicillin

### Patient: Priya Nair  (ID: P-1002)
- Age: 54 | Gender: Female | Blood Group: O+
- Primary Physician: Dr. Ramesh Iyer (Nephrologist)
- Diagnosed Conditions: Atrial Fibrillation, Chronic Kidney Disease (Stage 4), Anaemia
- Current Medications: Warfarin 3 mg, Erythropoietin injections, Aspirin 75 mg
- Recent Lab: eGFR 22, INR 3.8 (above therapeutic range), Hb 8.2 g/dL
- Allergies: Sulfonamides

### Patient: Vikram Singh  (ID: P-1003)
- Age: 45 | Gender: Male | Blood Group: A+
- Primary Physician: Dr. Anil Kapoor (Pulmonologist)
- Diagnosed Conditions: Asthma, Depression, Hypertension
- Current Medications: Fluticasone inhaler, Metoprolol 50 mg, Fluoxetine 20 mg
- Recent Lab: FEV1 72%, BP 148/92
- Allergies: NSAIDs

### Patient: Lakshmi Devi  (ID: P-1004)
- Age: 72 | Gender: Female | Blood Group: AB-
- Primary Physician: Dr. Sunita Rao (Cardiologist)
- Diagnosed Conditions: Heart Failure (NYHA Class II), Type 2 Diabetes, Osteoporosis
- Current Medications: Furosemide 40 mg, Digoxin 0.25 mg, Metformin 1000 mg, Alendronate 70 mg
- Recent Lab: BNP 480 pg/mL, K+ 3.1 mEq/L (low), eGFR 55
- Allergies: None known

### Patient: Rohan Desai  (ID: P-1005)
- Age: 38 | Gender: Male | Blood Group: O-
- Primary Physician: Dr. Meera Joshi (Psychiatrist)
- Diagnosed Conditions: Bipolar Disorder, Epilepsy, Obesity (BMI 36)
- Current Medications: Lithium 900 mg, Valproate 500 mg, Metformin 500 mg (for metabolic side effects)
- Recent Lab: Lithium level 1.4 mEq/L (upper limit of therapeutic range), TSH 6.8 (elevated)

---

## DOCTORS

### Dr. Sunita Rao
- Specialty: Cardiology
- Patients Under Care: Arjun Mehta (P-1001), Lakshmi Devi (P-1004)
- Clinic: Heart Care OPD, Block B, City General Hospital
- Availability: Monday, Wednesday, Friday

### Dr. Ramesh Iyer
- Specialty: Nephrology
- Patients Under Care: Priya Nair (P-1002)
- Clinic: Kidney Disease Centre, Block C
- Availability: Tuesday, Thursday

### Dr. Anil Kapoor
- Specialty: Pulmonology
- Patients Under Care: Vikram Singh (P-1003)
- Clinic: Respiratory OPD, Block A
- Availability: Monday, Wednesday

### Dr. Meera Joshi
- Specialty: Psychiatry
- Patients Under Care: Rohan Desai (P-1005)
- Clinic: Mental Health Centre, Block D
- Availability: Tuesday, Friday

---

## DRUG INTERACTION REFERENCE

### Warfarin — Known Interactions
- **Warfarin + Aspirin**: High risk of bleeding. Co-administration significantly increases haemorrhage risk, especially GI and intracranial. Requires close INR monitoring.
- **Warfarin + Fluoxetine**: Fluoxetine (an SSRI) inhibits CYP2C9, which metabolises Warfarin — can raise Warfarin plasma levels and increase bleeding risk.
- **Warfarin + NSAIDs**: Contraindicated. NSAIDs displace Warfarin from plasma protein binding and independently increase GI bleed risk.
- Warfarin dose must be adjusted in Chronic Kidney Disease — reduced clearance leads to drug accumulation.

### Metformin — Known Interactions
- **Metformin + Chronic Kidney Disease (Stage 3–4)**: Risk of lactic acidosis increases as eGFR falls below 45. Contraindicated when eGFR < 30.
- Metformin should be used with caution in heart failure due to risk of lactic acidosis.

### Metoprolol — Known Interactions
- **Metoprolol + Asthma**: Beta-blockers (including Metoprolol) can cause bronchospasm in asthmatic patients. Cardioselective beta-blockers carry lower risk but are not zero-risk.
- **Metoprolol + Fluoxetine**: Fluoxetine inhibits CYP2D6, increasing Metoprolol plasma concentration — may cause bradycardia and hypotension.

### Digoxin — Known Interactions
- **Digoxin + Hypokalaemia**: Low potassium (K+ < 3.5) dramatically increases Digoxin toxicity risk.
- Digoxin dose must be reduced in renal impairment.

### Lithium — Known Interactions
- **Lithium + NSAIDs**: NSAIDs reduce renal Lithium clearance, raising plasma Lithium to toxic levels.
- **Lithium + Hypothyroidism**: Lithium suppresses thyroid function. Elevated TSH suggests subclinical hypothyroidism requiring investigation.
- **Lithium + Valproate**: Combined use can increase Lithium neurotoxicity risk; requires monitoring.

### Fluoxetine — Known Interactions
- Fluoxetine is a potent CYP2D6 and CYP2C9 inhibitor — affects metabolism of many co-administered drugs.
- **Fluoxetine + Warfarin**: Raises Warfarin level (see Warfarin section).
- **Fluoxetine + Metoprolol**: Raises Metoprolol level (see Metoprolol section).

---

## CONDITION REFERENCE

### Chronic Kidney Disease (CKD)
- Stage 3: eGFR 30–59. Metformin: use with caution (review if eGFR < 45). Warfarin: monitor INR closely.
- Stage 4: eGFR 15–29. Metformin: contraindicated. Many renally cleared drugs require dose adjustment or substitution.

### Atrial Fibrillation
- Anticoagulation (Warfarin or DOAC) is standard of care to prevent stroke.
- Concurrent Aspirin increases bleeding risk without additional stroke protection in most AF patients.

### Asthma
- Beta-blockers (Metoprolol, Atenolol) are relatively contraindicated due to bronchospasm risk.

### Heart Failure
- Hypokalaemia (common with Furosemide use) potentiates Digoxin toxicity.
- Metformin should be used cautiously given lactic acidosis risk.

### Epilepsy + Bipolar Disorder
- Valproate is used for both conditions (dual purpose).
- Lithium monitoring is mandatory given narrow therapeutic index (target 0.6–1.2 mEq/L).
