"""
app.py
RAG chatbot backed by Amazon S3 Vectors:
  1. Presents a menu of preset questions or lets the user type their own.
  2. Retrieves relevant document chunks from a Bedrock Knowledge Base
     (which uses S3 Vectors as the vector store).
  3. Passes the question + context to Amazon Nova (via Bedrock) for a grounded answer.

Dataset in the knowledge base:
  - hdfc_financial_statement_2024.pdf  — HDFC Bank annual financials
  - rbi_risk_basel_extracts.md         — RBI Basel III regulatory extracts
  - Bank Market Risk Policy.md         — Internal market risk policy
  - VAR Backtesting policy.md          — VAR backtesting procedures
  - regulations.docx / regulations2.docx — General banking regulations
  - kunal.pdf / pankaj_cv.pdf / pooja.pdf / rahul.pdf — Candidate CVs
  - electricity_bill.pdf               — Sample utility bill
"""

import json
import os
import sys

import boto3
from dotenv import load_dotenv

def _find_dotenv():
    current = os.path.abspath(os.getcwd())
    while True:
        candidate = os.path.join(current, ".env")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            print("Error: .env file not found in current directory or any parent directory.")
            raise SystemExit(1)
        current = parent

load_dotenv(dotenv_path=_find_dotenv())

# ── Configuration ─────────────────────────────────────────────────────────────
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
MAX_TOKENS = int(os.getenv("BEDROCK_MAX_TOKENS", "512"))
TEMPERATURE = float(os.getenv("BEDROCK_TEMPERATURE", "0.7"))
TOP_K_RESULTS = 5

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kb_config.json")

SYSTEM_PROMPT = (
    "You are a helpful AI assistant. Answer questions strictly based on the "
    "provided context documents. Be concise and accurate. If the context does "
    "not contain enough information to answer, say so clearly."
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_config():
    if not os.path.exists(CONFIG_FILE):
        print("Error: kb_config.json not found. Run indexer.py first.")
        sys.exit(1)
    with open(CONFIG_FILE) as f:
        return json.load(f)


def retrieve(bedrock_agent_runtime, kb_id, question):
    """Retrieve the top-K relevant chunks from the knowledge base."""
    response = bedrock_agent_runtime.retrieve(
        knowledgeBaseId=kb_id,
        retrievalQuery={"text": question},
        retrievalConfiguration={
            "vectorSearchConfiguration": {"numberOfResults": TOP_K_RESULTS}
        },
    )
    return response.get("retrievalResults", [])


def build_prompt(question, results):
    """Combine retrieved chunks into a single prompt.

    Uses the custom 'filename' metadata attribute (set by upload_metadata_sidecars
    in indexer.py) as the document label.  Falls back to the S3 URI basename if
    the sidecar metadata is absent.
    """
    context_blocks = []
    for i, r in enumerate(results, 1):
        text = r["content"]["text"]
        # Custom metadata injected via sidecar file during ingestion
        meta = r.get("metadata", {})
        filename = meta.get("filename")
        if not filename:
            # Fallback: derive name from the S3 URI stored in location metadata
            uri = r.get("location", {}).get("s3Location", {}).get("uri", "unknown")
            filename = uri.split("/")[-1] if "/" in uri else uri
        context_blocks.append(f"[Document {i} – {filename}]\n{text}")

    context = "\n\n".join(context_blocks)
    return (
        f"Answer the following question using ONLY the context documents below.\n\n"
        f"--- CONTEXT ---\n{context}\n--- END CONTEXT ---\n\n"
        f"Question: {question}"
    )


def invoke_nova(bedrock_runtime, prompt):
    """Call the Amazon Nova model and return the generated text."""
    body = {
        "messages": [{"role": "user", "content": [{"text": prompt}]}],
        "system": [{"text": SYSTEM_PROMPT}],
        "inferenceConfig": {
            "maxTokens": MAX_TOKENS,
            "temperature": TEMPERATURE,
        },
    }
    response = bedrock_runtime.invoke_model(
        modelId=MODEL_ID,
        body=json.dumps(body),
        contentType="application/json",
        accept="application/json",
    )
    result = json.loads(response["body"].read())
    return result["output"]["message"]["content"][0]["text"]


# ── Preset questions ──────────────────────────────────────────────────────────
# These questions are designed to:
#  a) Cover different document types in the knowledge base.
#  b) Highlight WHY metadata stored alongside chunks matters:
#     - Questions about specific people (CVs) only make sense if the answer
#       includes WHICH document (= which person) each chunk came from.
#     - Policy comparisons require knowing which policy document each rule belongs to.
#     - Financial figures need the source document to establish credibility/date.

PRESET_QUESTIONS = [
    # Q1 — Financial document: straightforward factual retrieval
    (
        "What were HDFC Bank's total revenue, net profit, and key financial highlights "
        "for the year 2024?"
    ),
    # Q2 — People / CVs: metadata is CRITICAL here.
    # The chunks contain skills and experience, but without the source filename
    # (= the person's name) stored as metadata, the answer would be meaningless —
    # you'd know someone has Python experience but not WHO.
    (
        "Which candidates in the knowledge base have experience in banking or financial "
        "services? List each candidate's name and relevant experience. "
        "(Note: the source document name tells you which candidate each chunk belongs to.)"
    ),
    # Q3 — Policy: tests cross-document retrieval across two policy documents.
    # Metadata (source filename) lets the answer attribute each rule to the right policy.
    (
        "What is the VAR backtesting policy — what confidence interval and time horizon "
        "are used, and how often are results reviewed and reported to management?"
    ),
    # Q4 — Regulatory / RBI Basel: highlights that regulatory context matters.
    # A chunk about capital ratios means different things depending on whether it
    # comes from the RBI guidelines or an internal policy document.
    (
        "According to the RBI Basel III guidelines, what are the minimum capital "
        "adequacy requirements for banks, and how is Tier 1 capital defined?"
    ),
    # Q5 — Cross-document comparison: asks for differences between two documents.
    # Without metadata you cannot tell which rule came from which regulation.
    (
        "Compare the market risk limits and controls described in the Bank Market Risk "
        "Policy with any relevant clauses in the regulations documents. "
        "Which document imposes stricter controls, and on what basis?"
    ),
    # Q6 — Highlights the NEED FOR A KNOWLEDGE GRAPH over plain vector search.
    #
    # This question requires multi-hop relationship traversal:
    #   Patient → CurrentMedications → DrugInteractions → ContraIndicatedCondition
    #                                                              ↓
    #                                                     Patient.Conditions (same patient!)
    #                                                              ↓
    #                                                     PrimaryPhysician → notify
    #
    # RAG retrieves individual chunks well, but stitching together:
    #   "Priya Nair takes Warfarin AND Aspirin"  (Patient chunk)
    #   + "Warfarin + Aspirin = high bleed risk" (Drug interaction chunk)
    #   + "Priya's INR is already 3.8"           (Lab result chunk, same patient)
    #   + "Priya's doctor is Dr. Ramesh Iyer"    (Doctor chunk)
    # … requires the system to KNOW these four chunks refer to the SAME patient entity.
    # A knowledge graph stores Patient, Drug, Condition, Doctor as nodes with typed
    # edges (takes, has_condition, treated_by, interacts_with) so a single graph
    # traversal query answers this. Vector search alone cannot reliably infer the
    # entity identity links across independently retrieved chunks.
    (
        "Which patients at City General Hospital are currently at risk due to dangerous "
        "drug interactions or medications contraindicated with their diagnosed conditions? "
        "For each at-risk patient, name the specific interaction or contraindication, "
        "the severity, and which doctor should be notified."
    ),
]


# ── Question menu ─────────────────────────────────────────────────────────────

def choose_question():
    """Display a numbered menu and return the chosen question string."""
    print("\n" + "=" * 60)
    print("  Select a question to ask the knowledge base")
    print("=" * 60)
    for i, q in enumerate(PRESET_QUESTIONS, 1):
        # Print first 90 chars of the question so the menu stays readable
        preview = q if len(q) <= 90 else q[:87] + "..."
        print(f"  [{i}] {preview}")
    other_num = len(PRESET_QUESTIONS) + 1
    print(f"  [{other_num}] Other — type your own question")
    print(f"  [q] Quit")
    print("=" * 60)

    while True:
        try:
            choice = input("Your choice: ").strip()
        except (EOFError, KeyboardInterrupt):
            return None

        if choice.lower() in ("q", "quit", "exit"):
            return None
        if choice in {str(i) for i in range(1, len(PRESET_QUESTIONS) + 1)}:
            return PRESET_QUESTIONS[int(choice) - 1]
        if choice == str(other_num):
            try:
                custom = input("Your question: ").strip()
            except (EOFError, KeyboardInterrupt):
                return None
            return custom if custom else None
        print(f"  Please enter a number between 1 and {other_num}, or 'q' to quit.")


# ── Chat loop ─────────────────────────────────────────────────────────────────

def chat(kb_id):
    agent_rt = boto3.client("bedrock-agent-runtime", region_name=AWS_REGION)
    bedrock_rt = boto3.client("bedrock-runtime", region_name=AWS_REGION)

    print(f"\n=== RAG Chatbot (S3 Vectors)  |  model: {MODEL_ID} ===")

    while True:
        question = choose_question()
        if question is None:
            print("Goodbye!")
            break

        print(f"\nQuestion: {question}\n")

        # ── Retrieval ──
        print("[Retrieving relevant context...]")
        results = retrieve(agent_rt, kb_id, question)

        if not results:
            print("Assistant: No relevant documents found in the knowledge base.\n")
            continue

        # Print per-chunk metadata to show what was retrieved and from where.
        # 'filename' comes from the custom sidecar uploaded by indexer.py —
        # this is the key illustration: metadata travels with every chunk,
        # so we always know which source document each piece of context belongs to.
        print(f"\n[Retrieved {len(results)} chunks]")
        for i, r in enumerate(results, 1):
            meta = r.get("metadata", {})
            score = r.get("score", 0)
            filename = meta.get("filename", "—")
            # Show all custom metadata keys so learners can see what's available
            extra = {k: v for k, v in meta.items() if k != "filename"}
            extra_str = f"  extra metadata: {extra}" if extra else ""
            print(f"  chunk {i}: filename={filename!r}  score={score:.3f}{extra_str}")

        # ── Generation ──
        prompt = build_prompt(question, results)
        answer = invoke_nova(bedrock_rt, prompt)

        print(f"\nAssistant: {answer}\n")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    config = load_config()
    chat(config["knowledge_base_id"])
