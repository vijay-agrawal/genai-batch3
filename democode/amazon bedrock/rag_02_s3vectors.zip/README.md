# RAG Demo — S3 Vectors Setup Guide

---

## RAG Vector Store Options on AWS

When building a RAG pipeline on AWS with Amazon Bedrock Knowledge Bases, you have several
choices for where to store and query your vectors. Each option has different trade-offs
around cost, operational overhead, scalability, and query capabilities.

### Available Vector Store Options

| Vector Store | Type | Best For |
|---|---|---|
| **Amazon S3 Vectors** | Serverless, pay-per-request | Dev/demo, low traffic, cost-sensitive workloads |
| **Amazon OpenSearch Serverless** | Serverless, OCU-based | Production, full-text + vector hybrid search |
| **Amazon OpenSearch Service** (managed) | Managed cluster | High-throughput production, fine-grained control |
| **Amazon Aurora PostgreSQL** (pgvector) | Managed relational DB | Apps already on RDS/Aurora; SQL + vector in one DB |
| **Amazon Neptune Analytics** | Graph + vector | Knowledge graphs, relationship-aware retrieval |
| **Pinecone** (via partner) | Third-party SaaS | Pinecone-native workloads already in use |
| **MongoDB Atlas** (via partner) | Third-party SaaS | Existing MongoDB users, document + vector search |
| **Redis** (via partner) | Third-party SaaS | Ultra-low latency, in-memory vector search |

---

### Comparison Table

| Feature | S3 Vectors | OpenSearch Serverless | OpenSearch Managed | Aurora pgvector | Neptune Analytics |
|---|---|---|---|---|---|
| **Operational overhead** | None | None | Medium | Low | Low |
| **Minimum cost (idle)** | ~$0.00 | ~$0.48/hr (2 OCU min) | Depends on instance | Depends on instance | Depends on instance |
| **Pricing model** | Per request + storage | OCU-hours | Instance + storage | Instance + storage | NCU-hours |
| **Hybrid search** (vector + keyword) | No | Yes | Yes | No | No |
| **Metadata filtering** | Yes | Yes | Yes | Yes (SQL WHERE) | Yes |
| **Scales to zero** | Yes | Yes | No | No (Aurora Serverless v2: partial) | No |
| **Multi-AZ / HA** | Yes (S3-native) | Yes | Yes (multi-node) | Yes | Yes |
| **Max vector dimensions** | 4096 | 16000 | 16000 | 2000 (pgvector default) | 65535 |
| **SQL / structured queries alongside vectors** | No | No | No | Yes | No |
| **Graph traversal** | No | No | No | No | Yes |
| **Bedrock Knowledge Base integration** | Native | Native | Native | Native | Native |
| **GA status** | GA (Dec 2025) | GA | GA | GA | GA |

> **OCU (OpenSearch Compute Unit):** The billing unit for Amazon OpenSearch Serverless.
> Each OCU represents a fixed amount of compute and memory. OpenSearch Serverless requires
> a minimum of **2 OCUs** at all times (one for indexing, one for search) — even when idle —
> which is why the minimum cost is ~$0.48/hr regardless of actual usage.

### When to choose what

- **S3 Vectors** — starting out, demos, cost is a primary concern, no need for hybrid search
- **OpenSearch Serverless** — production RAG with hybrid (keyword + semantic) search, no infra management
- **OpenSearch Managed** — very high query throughput, custom plugins, or existing OpenSearch clusters
- **Aurora pgvector** — your application already uses PostgreSQL/Aurora and you want vectors without a new service
- **Neptune Analytics** — documents have rich relationships (e.g., org charts, knowledge graphs) that matter for retrieval

---

This guide covers building a RAG (Retrieval-Augmented Generation) pipeline using
**Amazon S3 Vectors** as the vector store instead of OpenSearch Serverless.
S3 Vectors is a fully serverless, pay-per-request vector store — no cluster provisioning,
no OCU charges, no minimum capacity.

---

## Architecture Overview

```
Your Documents (local)
        │
        ▼
  S3 Bucket (raw files)
        │   ← Bedrock reads & chunks documents
        ▼
  Bedrock Knowledge Base
        │   ← embeds chunks with Titan Embed Text v2
        ▼
  S3 Vectors (vector bucket + index)
        │
        ▼
  Bedrock retrieve() API  ──► Amazon Nova (reasoning & formatting)
```

---

## Prerequisites

| What you need | Where to get it |
|---|---|
| AWS account with Console access | Your cloud admin |
| Region: **us-east-1** (or any region where S3 Vectors is GA) | Set in top-right corner of Console |
| Amazon Bedrock model access for **Nova Micro** and **Titan Embed Text v2** | Step 1 below |

> **Region note:** S3 Vectors became generally available in December 2025. Confirm availability
> in your target region at the [S3 Vectors product page](https://aws.amazon.com/s3/features/vectors/).

---

## Step 1 — Enable Bedrock Model Access

> Skip this step if the models are already enabled.

1. In the Console, go to **Amazon Bedrock** → **Model access**.
2. Click **Modify model access**.
3. Enable the following two models:

   | Model Name | Provider | Used For |
   |---|---|---|
   | **Nova Micro** | Amazon | Chat / reasoning |
   | **Titan Embed Text v2** | Amazon | Embedding documents |

4. Click **Next** → **Submit**.
5. Wait until both models show **Access granted**.

---

## Step 2 — Grant IAM Permissions to Your User

Your IAM user needs permissions to create and manage all services used by this demo.

1. In the Console, go to **IAM** → **Users** → click your username.
2. Click **Permissions** → **Add permissions** → **Attach policies directly**.
3. Search for and select each of the following:

   | Policy Name | Why needed |
   |---|---|
   | `AmazonBedrockFullAccess` | Create/manage Knowledge Bases, invoke models |
   | `AmazonS3FullAccess` | Create the S3 data-source bucket and upload documents |
   | `IAMFullAccess` | Create the service role for the Knowledge Base |
   | **Custom S3 Vectors policy** (see below) | Create vector buckets and indexes |

4. Click **Next** → **Add permissions**.

### Custom S3 Vectors policy for your user

Because there is no AWS managed policy for S3 Vectors yet, create an inline or customer-managed
policy with the following JSON and attach it to your user:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "S3VectorsAdminAccess",
      "Effect": "Allow",
      "Action": [
        "s3vectors:CreateVectorBucket",
        "s3vectors:DeleteVectorBucket",
        "s3vectors:GetVectorBucket",
        "s3vectors:ListVectorBuckets",
        "s3vectors:CreateIndex",
        "s3vectors:DeleteIndex",
        "s3vectors:GetIndex",
        "s3vectors:ListIndexes",
        "s3vectors:PutVectors",
        "s3vectors:GetVectors",
        "s3vectors:DeleteVectors",
        "s3vectors:QueryVectors",
        "s3vectors:ListVectors",
        "s3vectors:PutVectorBucketPolicy",
        "s3vectors:GetVectorBucketPolicy",
        "s3vectors:DeleteVectorBucketPolicy",
        "s3vectors:TagResource",
        "s3vectors:ListTagsForResource",
        "s3vectors:UntagResource"
      ],
      "Resource": "*"
    }
  ]
}
```

> **Training note:** For production, scope `Resource` to specific bucket/index ARNs.

---

## Step 3 — Create the S3 Data-Source Bucket and Upload Documents

### 3a. Create the bucket

1. Go to **S3** → **Create bucket**.
2. **Bucket name:** `rag-demo-<your-12-digit-account-id>` (must be globally unique).
3. **Region:** us-east-1.
4. Leave all other settings as default → **Create bucket**.

### 3b. Upload documents

1. Click the bucket name → **Upload** → **Add files**.
2. Select all files from the `ragdemo/s3vectors/data/` folder.
3. Click **Upload** and confirm all files show **Succeeded**.

> **Tip:** You can skip the manual upload and use `data_uploader.py` instead (see Step 10c).

---

## Step 4 — Create the IAM Role for the Knowledge Base

Bedrock Knowledge Base needs a service role to access S3, S3 Vectors, and the embedding model.

### 4a. Create the role

1. Go to **IAM** → **Roles** → **Create role**.
2. **Trusted entity type:** AWS service.
3. Search for `Bedrock` and select **Bedrock - Knowledge Base**.
4. Click **Next**.

### 4b. Attach permissions

5. Search for and attach:

   | Policy | Purpose |
   |---|---|
   | `AmazonBedrockFullAccess` | Invoke the embedding model |
   | `AmazonS3ReadOnlyAccess` | Read documents from the S3 data-source bucket |

6. Click **Next**.
7. **Role name:** `BedrockKBRole-S3Vectors`
8. Click **Create role**.
9. Click the newly created role and copy its **ARN**.

### 4c. Attach inline S3 Vectors policy to the role

The role also needs S3 Vectors access scoped to your specific index.
After creating the role, select it → **Add permissions** → **Create inline policy** → **JSON**:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "S3VectorsIndexAccess",
      "Effect": "Allow",
      "Action": [
        "s3vectors:PutVectors",
        "s3vectors:GetVectors",
        "s3vectors:DeleteVectors",
        "s3vectors:QueryVectors",
        "s3vectors:GetIndex"
      ],
      "Resource": "arn:aws:s3vectors:<REGION>:<ACCOUNT_ID>:bucket/ragdemo-vectors/index/ragdemo-index"
    }
  ]
}
```

Replace `<REGION>` and `<ACCOUNT_ID>` with your values. Click **Review policy** → name it
`BedrockKBInlinePolicy-S3Vectors` → **Create policy**.

---

## Step 5 — Create the S3 Vector Bucket

S3 Vectors introduces a new resource type: the **vector bucket** (separate from regular S3 buckets).

1. In the Console, go to **S3**.
2. In the left sidebar, click **Vector buckets** → **Create vector bucket**.
3. **Vector bucket name:** `ragdemo-vectors`
   *(3–63 characters, lowercase letters, numbers, and hyphens)*
4. **Encryption:** SSE-S3 (default AWS-managed key).
5. Click **Create vector bucket**.

> **Note:** Vector bucket names and encryption settings cannot be changed after creation.

---

## Step 6 — Create the Vector Index

A vector index lives inside a vector bucket and defines the shape of your vectors.

1. Click the `ragdemo-vectors` bucket → **Create vector index**.
2. Configure the index:

   | Setting | Value |
   |---|---|
   | **Vector index name** | `ragdemo-index` |
   | **Data type** | `float32` |
   | **Dimension** | `1024` *(matches Titan Embed Text v2)* |
   | **Distance metric** | `cosine` |

3. Under **Non-filterable metadata keys**, add: `AMAZON_BEDROCK_TEXT_CHUNK`
   *(Bedrock stores chunk text here; marking it non-filterable keeps it as reference data only)*
4. Click **Create vector index**.

> **Note:** Index name, dimension, distance metric, and data type cannot be changed after creation.

---

## Step 7 — Create the Bedrock Knowledge Base

1. Go to **Amazon Bedrock** → **Knowledge bases** → **Create knowledge base**.

### 7a. Knowledge base details

2. **Knowledge base name:** `ragdemo-kb`
3. **IAM permissions:** Select **Use an existing service role** → choose `BedrockKBRole-S3Vectors`.
4. Click **Next**.

### 7b. Set up data source

5. **Data source name:** `s3-data-source`
6. **S3 URI:** Browse and select your bucket `rag-demo-<account-id>`.
7. **Chunking strategy:** Fixed-size chunking
   - Max tokens: `512`
   - Overlap percentage: `20%`
8. Click **Next**.

### 7c. Configure embeddings and vector store

9. **Embeddings model:** Amazon — **Titan Text Embeddings V2** (dimension: 1024)
10. **Vector database:** Select **S3 vector bucket**.
11. Choose **Use existing** → select `ragdemo-vectors` (bucket) and `ragdemo-index` (index).
12. Click **Next** → review → **Create knowledge base**.

> Note the **Knowledge base ID** shown on the detail page (e.g., `ABCDEF1234`).

---

## Step 8 — Sync Documents

1. On the Knowledge Base detail page, scroll to **Data sources**.
2. Click `s3-data-source` → **Sync**.
3. Bedrock will:
   - Read every file from S3
   - Split them into 512-token chunks with 20% overlap
   - Embed each chunk with Titan Embed Text v2
   - Store vectors in the `ragdemo-index` S3 vector index
4. Watch the **Sync history** tab until the job shows `Completed` (typically 2–5 minutes).

---

## Step 9 — Test in the Console

1. On the Knowledge Base detail page, click **Test knowledge base**.
2. Under *Select model*, choose **Amazon Nova Micro**.
3. Type a test question, e.g.:
   - *"What is the VAR backtesting policy?"*
   - *"Summarise the HDFC financial highlights for 2024."*
4. The panel shows the generated answer and expandable source chunks.

---

## Step 10 — Configure and Run the Python Scripts

### 10a. Set environment variables

Create or edit `ragdemo/.env`:

```
AWS_ACCESS_KEY_ID=<your access key>
AWS_SECRET_ACCESS_KEY=<your secret key>
AWS_REGION=us-east-1
S3_BUCKET_NAME=rag-demo-<your-account-id>
S3_VECTOR_BUCKET_NAME=ragdemo-vectors
S3_VECTOR_INDEX_NAME=ragdemo-index
BEDROCK_KB_NAME=ragdemo-kb
BEDROCK_DS_NAME=s3-data-source
BEDROCK_EMBEDDING_MODEL=amazon.titan-embed-text-v2:0
BEDROCK_MODEL_ID=amazon.nova-micro-v1:0
```

### 10b. Install dependencies

```bash
cd ragdemo
pip install -r requirements.txt
```

> The `s3vectors` client is included in `boto3 >= 1.38`. Update boto3 if needed:
> `pip install --upgrade boto3`

### 10c. Upload documents to S3

`data_uploader.py` creates the S3 bucket (if needed) and uploads all files from
`ragdemo/s3vectors/data/` — run this **before** the indexer:

```bash
python s3vectors/data_uploader.py
```

It will:
1. Create the S3 bucket `S3_BUCKET_NAME` if it does not exist
2. Upload every file from `ragdemo/s3vectors/data/` to that bucket

### 10d. Run the indexer (automated setup)

`indexer.py` automates Steps 4–8 above. Run this **after** `data_uploader.py`:

```bash
python s3vectors/indexer.py
```

It will:
1. Create the IAM role `BedrockKBRole-S3Vectors` with the correct trust and inline policies
2. Create the vector bucket `ragdemo-vectors`
3. Create the vector index `ragdemo-index`
4. Create the Bedrock Knowledge Base with S3 Vectors backend
5. Create the S3 data source and start ingestion
6. Save `s3vectors/kb_config.json` with the Knowledge Base ID

### 10e. Run the chatbot

```bash
python s3vectors/app.py
```

---

## IAM Permissions Summary

| Principal | Permissions Required |
|---|---|
| **Your IAM user** | `AmazonBedrockFullAccess`, `AmazonS3FullAccess`, `IAMFullAccess`, custom `s3vectors:*` policy |
| **BedrockKBRole-S3Vectors** (service role) | `bedrock:InvokeModel`, `s3:GetObject` + `s3:ListBucket` on data bucket, `s3vectors:PutVectors` + `s3vectors:GetVectors` + `s3vectors:DeleteVectors` + `s3vectors:QueryVectors` + `s3vectors:GetIndex` on the vector index ARN |

---

## Troubleshooting

| Error | Likely cause | Fix |
|---|---|---|
| `AccessDeniedException` on Bedrock | Model access not enabled | Complete Step 1 |
| `AccessDeniedException` on `s3vectors:*` | Custom S3 Vectors policy not attached to your user | Complete Step 2 |
| `ConflictException` on vector bucket or index | Already exists | Safe to ignore — the script reuses it |
| `EntityAlreadyExists` on IAM role | Already created | Safe to ignore |
| Ingestion job `FAILED` | S3 access denied or unsupported file type | Verify `BedrockKBRole-S3Vectors` has S3 read access |
| `ResourceNotFoundException` in chatbot | Wrong KB ID in `kb_config.json` | Copy the correct ID from the Bedrock console |
| `No relevant documents found` | Ingestion not yet complete | Wait for the sync job to show `Completed` |
| `boto3` doesn't recognise `s3vectors` client | Outdated boto3 | Run `pip install --upgrade boto3` (need >= 1.38) |

---

## Cost Comparison: S3 Vectors vs OpenSearch Serverless

| Service | Pricing model | Approximate cost (demo dataset) |
|---|---|---|
| **S3 Vectors** | Pay per request + storage | ~$0.00 for a small demo (request costs are fractions of a cent) |
| **OpenSearch Serverless** | OCU-hours (min 2 OCUs) | ~$0.48/hr even when idle |
| Titan Embed Text v2 | $0.00002 / 1K tokens | One-time ingestion cost |
| Amazon Nova Micro | $0.000035 / 1K input tokens | Per query |

> S3 Vectors has **no minimum capacity** — you pay only for what you use, making it significantly
> cheaper for demos, low-traffic workloads, and development environments.

---

## Supported Document Formats

| Format | Notes |
|---|---|
| PDF | Scanned PDFs require Textract (extra cost) |
| Plain text (`.txt`) | — |
| Markdown (`.md`) | — |
| Microsoft Word (`.docx`) | — |
| HTML | — |
| CSV | Each row becomes a chunk |
