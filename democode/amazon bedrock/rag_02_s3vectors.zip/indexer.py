"""
indexer.py
One-time setup script that wires together all AWS resources for the RAG pipeline.

What this script does (run once before using the chatbot):
1. Creates an IAM role that Bedrock will assume when running the pipeline.
2. Creates an Amazon S3 Vectors bucket — a special bucket that stores vectors,
   NOT regular files. This is separate from the S3 bucket that holds your documents.
3. Creates a vector index inside that bucket (defines vector shape/dimensions).
4. Creates a Bedrock Knowledge Base that ties the embedding model to the vector store.
5. Registers the regular S3 document bucket as a data source, then kicks off ingestion.
6. Saves the resulting IDs to kb_config.json for use by app.py.

What "ingestion" means here:
  Ingestion = Bedrock reads your raw documents FROM the regular S3 bucket,
  splits them into chunks, converts each chunk into a vector (embedding) using
  Titan Embed Text v2, and writes those vectors INTO the S3 Vectors index.
  It does NOT upload anything to S3 — your documents must already be in S3
  (use data_uploader.py first).

Data flow:
  S3 bucket (raw docs)
      │  Bedrock reads & chunks
      ▼
  Titan Embed Text v2  →  1024-dimensional float32 vector per chunk
      │
      ▼
  S3 Vectors index (ragdemo-index inside ragdemo-vectors bucket)
"""

import json
import os
import time

import boto3
from botocore.exceptions import ClientError
from dotenv import load_dotenv

def _find_dotenv():
    # Walk up from cwd until a .env file is found
    current = os.path.abspath(os.getcwd())
    while True:
        candidate = os.path.join(current, ".env")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            print("Error: .env file not found in current directory or any parent directory.")
            raise SystemExit(1)
        current = parent

load_dotenv(dotenv_path=_find_dotenv())

# ── Configuration ─────────────────────────────────────────────────────────────
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME")           # regular S3 bucket holding raw documents
VECTOR_BUCKET_NAME = os.getenv("S3_VECTOR_BUCKET_NAME", "ragdemo-vectors")  # S3 Vectors bucket
VECTOR_INDEX_NAME = os.getenv("S3_VECTOR_INDEX_NAME", "ragdemo-index")      # index inside the vector bucket
KB_NAME = os.getenv("BEDROCK_KB_NAME", "kb-ragdemo")
DS_NAME = os.getenv("BEDROCK_DS_NAME", "s3-data-source")
EMBEDDING_MODEL_ID = os.getenv("BEDROCK_EMBEDDING_MODEL", "amazon.titan-embed-text-v2:0")

VECTOR_DIMENSION = 1024    # titan-embed-text-v2 produces 1024-dimensional vectors
VECTOR_DISTANCE_METRIC = "cosine"
VECTOR_DATA_TYPE = "float32"

KB_ROLE_NAME = "BedrockKBRole-S3Vectors"
# kb_config.json is written next to this script and read by app.py at query time
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kb_config.json")
# data/ folder sits next to this script — same folder data_uploader.py reads from
DATA_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_account_and_caller():
    # Used to build ARNs that reference the specific account + region
    sts = boto3.client("sts", region_name=AWS_REGION)
    identity = sts.get_caller_identity()
    return identity["Account"], identity["Arn"]


# ── Step 1 – IAM Role ─────────────────────────────────────────────────────────
# Bedrock cannot use your credentials directly — it needs a service role it can
# assume. This role grants Bedrock permission to:
#   • call the embedding model (to turn chunks into vectors)
#   • read raw documents from the regular S3 bucket
#   • write/query vectors in the S3 Vectors index

def create_kb_iam_role(iam, account_id, bucket_name, vector_bucket_name, vector_index_name):
    # Trust policy: allows only the Bedrock service to assume this role
    trust_policy = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "bedrock.amazonaws.com"},
            "Action": "sts:AssumeRole",
        }],
    }
    try:
        role = iam.create_role(
            RoleName=KB_ROLE_NAME,
            AssumeRolePolicyDocument=json.dumps(trust_policy),
            Description="IAM role for Bedrock Knowledge Base backed by S3 Vectors",
        )
        role_arn = role["Role"]["Arn"]
        print(f"  Created IAM role: {role_arn}")
    except ClientError as e:
        if e.response["Error"]["Code"] == "EntityAlreadyExists":
            # Role was created on a previous run — reuse it
            role_arn = iam.get_role(RoleName=KB_ROLE_NAME)["Role"]["Arn"]
            print(f"  IAM role already exists: {role_arn}")
        else:
            raise

    # Inline policy attached directly to the role (no separate managed policy needed)
    inline_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                # Allows Bedrock to call the Titan embedding model to vectorise chunks
                "Sid": "BedrockEmbeddingModel",
                "Effect": "Allow",
                "Action": ["bedrock:InvokeModel"],
                "Resource": f"arn:aws:bedrock:{AWS_REGION}::foundation-model/*",
            },
            {
                # Allows Bedrock to read raw documents from the S3 data-source bucket
                "Sid": "S3DataSourceRead",
                "Effect": "Allow",
                "Action": ["s3:GetObject", "s3:ListBucket"],
                "Resource": [
                    f"arn:aws:s3:::{bucket_name}",
                    f"arn:aws:s3:::{bucket_name}/*",
                ],
            },
            {
                # Allows Bedrock to read/write vectors in the S3 Vectors index
                # during ingestion (write) and at query time (read)
                "Sid": "S3VectorsIndexAccess",
                "Effect": "Allow",
                "Action": [
                    "s3vectors:PutVectors",      # write vectors during ingestion
                    "s3vectors:GetVectors",      # retrieve vectors by key
                    "s3vectors:DeleteVectors",   # remove stale vectors on re-sync
                    "s3vectors:QueryVectors",    # nearest-neighbour search at query time
                    "s3vectors:GetIndex",        # read index metadata
                ],
                "Resource": (
                    f"arn:aws:s3vectors:{AWS_REGION}:{account_id}:"
                    f"bucket/{vector_bucket_name}/index/{vector_index_name}"
                ),
            },
        ],
    }
    iam.put_role_policy(
        RoleName=KB_ROLE_NAME,
        PolicyName="BedrockKBInlinePolicy-S3Vectors",
        PolicyDocument=json.dumps(inline_policy),
    )
    print("  Inline policy attached.")
    return role_arn


# ── Step 2 – S3 Vector Bucket ─────────────────────────────────────────────────
# An S3 Vectors bucket is a NEW resource type (not a regular S3 bucket).
# It is purpose-built to store and query high-dimensional vectors efficiently.
# Think of it as a managed vector database backed by S3 storage.

def create_vector_bucket(s3v, vector_bucket_name):
    try:
        resp = s3v.create_vector_bucket(vectorBucketName=vector_bucket_name)
        vector_bucket_arn = resp["vectorBucketArn"]
        print(f"  Created vector bucket: {vector_bucket_arn}")
        return vector_bucket_arn
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConflictException":
            # Bucket already exists from a previous run — retrieve its ARN
            resp = s3v.get_vector_bucket(vectorBucketName=vector_bucket_name)
            vector_bucket_arn = resp["vectorBucket"]["vectorBucketArn"]
            print(f"  Vector bucket already exists: {vector_bucket_arn}")
            return vector_bucket_arn
        raise


# ── Step 3 – Vector Index ─────────────────────────────────────────────────────
# A vector index lives inside a vector bucket and defines the shape of stored vectors:
# dimension (must match the embedding model output), distance metric (how similarity
# is measured), and data type. These settings are immutable after creation.

def create_vector_index(s3v, vector_bucket_name, vector_index_name):
    try:
        resp = s3v.create_index(
            vectorBucketName=vector_bucket_name,
            indexName=vector_index_name,
            dataType=VECTOR_DATA_TYPE,           # float32
            dimension=VECTOR_DIMENSION,          # 1024 — must match Titan Embed Text v2
            distanceMetric=VECTOR_DISTANCE_METRIC,  # cosine similarity
            metadataConfiguration={
                # All keys that Bedrock KB writes during ingestion are listed here so
                # none of them are subject to the 2048-byte filterable-value limit.
                # Key names confirmed by inspect_vector_metadata() diagnostic output:
                #   AMAZON_BEDROCK_TEXT:             raw text of the chunk (~1-7 KB)
                #   AMAZON_BEDROCK_METADATA:         JSON: source URI + doc metadata (can be >7 KB)
                #   x-amz-bedrock-kb-data-source-id: data source ID (10 bytes)
                #   x-amz-bedrock-kb-source-file-modality: file type e.g. "text" (4 bytes)
                # Add any new keys here if ingestion fails with "Filterable metadata
                # must have at most 2048 bytes".
                "nonFilterableMetadataKeys": [
                    "AMAZON_BEDROCK_TEXT",                     # raw text of the chunk
                    "AMAZON_BEDROCK_METADATA",                 # JSON: source URI + doc metadata
                    "x-amz-bedrock-kb-source-uri",            # S3 URI of the source document
                    "x-amz-bedrock-kb-chunk-id",              # unique chunk identifier
                    "x-amz-bedrock-kb-data-source-id",        # data source ID
                    "x-amz-bedrock-kb-source-file-modality",  # file type modality
                ]
            },
        )
        index_arn = resp["indexArn"]
        print(f"  Created vector index: {index_arn}")
        return index_arn
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConflictException":
            # Index already exists — reuse it
            resp = s3v.get_index(
                vectorBucketName=vector_bucket_name,
                indexName=vector_index_name,
            )
            index_arn = resp["index"]["indexArn"]
            print(f"  Vector index already exists: {index_arn}")
            return index_arn
        raise


# ── Step 4 – Bedrock Knowledge Base ───────────────────────────────────────────
# The Knowledge Base is the logical wrapper that connects:
#   • an embedding model (converts text → vectors)
#   • a vector store (the S3 Vectors index created above)
#   • one or more data sources (the regular S3 bucket with raw documents)

def create_knowledge_base(bedrock_agent, role_arn, vector_bucket_arn, index_arn):
    embedding_arn = f"arn:aws:bedrock:{AWS_REGION}::foundation-model/{EMBEDDING_MODEL_ID}"

    # Check if a KB with this name already exists to avoid duplicates
    for kb in bedrock_agent.list_knowledge_bases(maxResults=50).get("knowledgeBaseSummaries", []):
        if kb["name"] == KB_NAME:
            print(f"  Knowledge base already exists: {kb['knowledgeBaseId']}")
            return kb["knowledgeBaseId"]

    resp = bedrock_agent.create_knowledge_base(
        name=KB_NAME,
        description="RAG demo knowledge base backed by S3 Vectors",
        roleArn=role_arn,                        # the service role Bedrock will assume
        knowledgeBaseConfiguration={
            "type": "VECTOR",
            # Specifies which model turns text into vectors (used during both
            # ingestion and at query time when the user's question is embedded)
            "vectorKnowledgeBaseConfiguration": {"embeddingModelArn": embedding_arn},
        },
        storageConfiguration={
            "type": "S3_VECTORS",
            # Points Bedrock at the specific vector bucket + index to store/query vectors
            "s3VectorsConfiguration": {
                "vectorBucketArn": vector_bucket_arn,
                "indexArn": index_arn,
            },
        },
    )
    kb_id = resp["knowledgeBase"]["knowledgeBaseId"]
    print(f"  Created knowledge base: {kb_id}")
    return kb_id


# ── Step 5 – Data Source + Ingestion ──────────────────────────────────────────
# How the four resources relate to each other:
#
#   Regular S3 bucket  ←── Data Source (pointer)
#         │                      │
#         │                      └─ belongs to ──► Knowledge Base
#         │                                              │
#         │  Bedrock reads from here during ingestion    │ uses
#         ▼                                              ▼
#   (raw .pdf/.md/.docx files)              S3 Vectors bucket
#                                                  │
#                                                  └─ contains ──► Vector Index
#                                                                  (stores embeddings)
#
#   - Regular S3 bucket: plain object storage — holds the original documents.
#   - S3 Vectors bucket: a separate, purpose-built vector store — holds embeddings.
#     These are TWO DIFFERENT bucket types; the S3 Vectors bucket never contains
#     the raw files.
#   - Knowledge Base: the Bedrock logical wrapper that connects the embedding model,
#     the vector store, and the data sources.
#   - Data Source: a configuration record inside the KB that points to the regular
#     S3 bucket. It is NOT the bucket itself — it is the link between the KB and
#     the bucket. One KB can have multiple data sources (e.g. different S3 buckets).
#
#   Supported data source types (dataSourceConfiguration.type):
#     S3          – Amazon S3 bucket (used here)
#     WEB         – Web crawler: crawls a list of seed URLs
#     CONFLUENCE  – Atlassian Confluence spaces/pages
#     SHAREPOINT  – Microsoft SharePoint sites
#     SALESFORCE  – Salesforce objects (cases, articles, etc.)
#     CUSTOM      – API-driven: you push documents yourself via the Bedrock API
#
# Ingestion flows: S3 bucket → (Bedrock reads, chunks, embeds) → S3 Vectors index
# Nothing is written back to S3 during ingestion.

def create_data_source(bedrock_agent, kb_id, bucket_name):
    ds_name = DS_NAME
    # Avoid creating a duplicate if the data source already exists
    for ds in bedrock_agent.list_data_sources(knowledgeBaseId=kb_id, maxResults=50).get("dataSourceSummaries", []):
        if ds["name"] == ds_name:
            print(f"  Data source already exists: {ds['dataSourceId']}")
            return ds["dataSourceId"]

    resp = bedrock_agent.create_data_source(
        knowledgeBaseId=kb_id,
        name=ds_name,
        description="S3 document store for RAG demo",
        dataSourceConfiguration={
            "type": "S3",
            # The regular S3 bucket where data_uploader.py uploaded your documents
            "s3Configuration": {"bucketArn": f"arn:aws:s3:::{bucket_name}"},
        },
        vectorIngestionConfiguration={
            "chunkingConfiguration": {
                # Chunking strategy options:
                #
                # FIXED_SIZE   – split by token count (used here)
                #                requires: fixedSizeChunkingConfiguration
                #                  maxTokens: max tokens per chunk (e.g. 512)
                #                  overlapPercentage: % of tokens shared between
                #                    adjacent chunks to preserve context (e.g. 20)
                #
                # HIERARCHICAL – two-level split: large parent chunks for context +
                #                smaller child chunks for precise retrieval
                #                requires: hierarchicalChunkingConfiguration
                #                  levelConfigurations: [{maxTokens: 1500}, {maxTokens: 300}]
                #                  overlapTokens: 60
                #
                # SEMANTIC     – uses the embedding model itself to detect natural
                #                topic boundaries rather than counting tokens;
                #                chunk sizes vary but are more semantically coherent
                #                requires: semanticChunkingConfiguration
                #                  maxTokens: 300
                #                  bufferSize: 0 (sentences on each side to consider)
                #                  breakpointPercentileThreshold: 95
                #
                # NONE         – no chunking; each document becomes a single vector.
                #                Only suitable for very short documents.
                #
                "chunkingStrategy": "FIXED_SIZE",
                "fixedSizeChunkingConfiguration": {
                    "maxTokens": 512,
                    "overlapPercentage": 20,
                },
            }
        },
    )
    ds_id = resp["dataSource"]["dataSourceId"]
    print(f"  Created data source: {ds_id}")
    return ds_id


def start_and_wait_ingestion(bedrock_agent, kb_id, ds_id, timeout=600):
    # Trigger ingestion: Bedrock starts reading documents from S3, chunking,
    # embedding, and writing vectors into the S3 Vectors index.
    # This is an async job — we poll until it completes or fails.
    job_id = bedrock_agent.start_ingestion_job(
        knowledgeBaseId=kb_id, dataSourceId=ds_id
    )["ingestionJob"]["ingestionJobId"]
    print(f"  Ingestion job started: {job_id}")

    deadline = time.time() + timeout
    while time.time() < deadline:
        job = bedrock_agent.get_ingestion_job(
            knowledgeBaseId=kb_id, dataSourceId=ds_id, ingestionJobId=job_id
        )["ingestionJob"]
        status = job["status"]
        stats = job.get("statistics", {})  # counts of docs scanned, vectors written, failures
        print(f"    status: {status} | stats: {stats}")
        if status == "COMPLETE":
            print("  Ingestion complete!")
            return
        if status in ("FAILED", "STOPPED"):
            raise RuntimeError(f"Ingestion failed: {job.get('failureReasons', [])}")
        time.sleep(20)
    raise TimeoutError("Ingestion did not complete within the timeout.")


# ── Diagnostic ───────────────────────────────────────────────────────────────
# Call this after ingestion to see exactly which metadata keys Bedrock wrote to
# the index. Use this if you hit "Filterable metadata must have at most 2048 bytes"
# — any key NOT in nonFilterableMetadataKeys and with a value > 2048 bytes will
# cause that error. Add the offending key to the list in create_vector_index.

def inspect_vector_metadata(s3v):
    resp = s3v.list_vectors(
        vectorBucketName=VECTOR_BUCKET_NAME,
        indexName=VECTOR_INDEX_NAME,
        returnMetadata=True,
        maxResults=1,
    )
    vectors = resp.get("vectors", [])
    if not vectors:
        print("  No vectors found in index.")
        return
    metadata = vectors[0].get("metadata", {})
    print(f"  Metadata keys written by Bedrock ({len(metadata)} keys):")
    for k, v in metadata.items():
        val_str = str(v)
        print(f"    {k!r:45s}  {len(val_str)} bytes")


# ── Custom Metadata Sidecars ──────────────────────────────────────────────────
# Bedrock KB supports per-document metadata via sidecar JSON files stored in the
# same S3 bucket alongside each document.
#
# How it works:
#   For every document "foo.pdf" in S3, Bedrock looks for "foo.pdf.metadata.json".
#   If found, the attributes inside are attached to EVERY vector chunk produced
#   from that document during ingestion.  They are then returned alongside each
#   retrieved chunk at query time, inside the "metadata" field of the result.
#
# Sidecar file format (uploaded to S3 as <document_key>.metadata.json):
#   {
#     "metadataAttributes": {
#       "filename": "patient_records.md",
#       "category": "healthcare",          ← any key/value pairs you like
#       ...
#     }
#   }
#
# This is the ONLY mechanism to attach custom, searchable metadata to chunks
# when using the managed Bedrock ingestion pipeline — you cannot inject metadata
# into the chunking process itself.
#
# At retrieval time, r["metadata"]["filename"] will contain the original filename,
# letting the application show users exactly which source document each answer
# chunk came from — even when chunks from many documents are mixed in one response.

def upload_metadata_sidecars(s3, bucket_name, data_folder):
    """Upload <filename>.metadata.json sidecars for every document in the data folder.

    Bedrock reads these during ingestion and stores the attributes alongside each
    vector chunk, making them available in retrieve() responses.
    """
    files = [
        f for f in os.listdir(data_folder)
        if os.path.isfile(os.path.join(data_folder, f))
        and not f.endswith(".metadata.json")
    ]
    if not files:
        print("  No files found in data folder — nothing to do.")
        return

    print(f"  Uploading metadata sidecars for {len(files)} documents...")
    for filename in files:
        # Custom attributes to attach to every chunk produced from this document.
        # Add more keys here (e.g. "category", "author", "year") as needed.
        metadata_doc = {
            "metadataAttributes": {
                "filename": filename,
            }
        }
        sidecar_key = f"{filename}.metadata.json"
        s3.put_object(
            Bucket=bucket_name,
            Key=sidecar_key,
            Body=json.dumps(metadata_doc),
            ContentType="application/json",
        )
        print(f"    {sidecar_key}")
    print(f"  Done — {len(files)} sidecars uploaded.")


# ── Teardown  ────────────────────────────────────────────────────────
# Deletes the KB (and its data sources) and the vector index so the script can
# be re-run cleanly with a fresh configuration. The IAM role and vector bucket
# are left intact — they are safe to reuse.

def teardown(bedrock_agent, s3v):
    # 1. Find and delete the Knowledge Base
    kb_id = None
    for kb in bedrock_agent.list_knowledge_bases(maxResults=50).get("knowledgeBaseSummaries", []):
        if kb["name"] == KB_NAME:
            kb_id = kb["knowledgeBaseId"]
            break

    if kb_id:
        # Data sources must be deleted before the KB itself can be deleted
        for ds in bedrock_agent.list_data_sources(knowledgeBaseId=kb_id, maxResults=50).get("dataSourceSummaries", []):
            bedrock_agent.delete_data_source(knowledgeBaseId=kb_id, dataSourceId=ds["dataSourceId"])
            print(f"  Deleted data source: {ds['dataSourceId']}")
        bedrock_agent.delete_knowledge_base(knowledgeBaseId=kb_id)
        print(f"  Deleted knowledge base: {kb_id}")
        # KB deletion is async — wait until it disappears from the list before continuing
        print("  Waiting for KB deletion to complete...", end="", flush=True)
        for _ in range(30):
            time.sleep(10)
            ids = [kb["knowledgeBaseId"] for kb in
                   bedrock_agent.list_knowledge_bases(maxResults=50).get("knowledgeBaseSummaries", [])]
            if kb_id not in ids:
                print(" done.")
                break
            print(".", end="", flush=True)
        else:
            raise TimeoutError("Knowledge base deletion did not complete in time.")
    else:
        print("  Knowledge base not found — skipping.")

    # 2. Delete the vector index (immutable config — must recreate to change metadata keys)
    try:
        s3v.delete_index(vectorBucketName=VECTOR_BUCKET_NAME, indexName=VECTOR_INDEX_NAME)
        print(f"  Deleted vector index: {VECTOR_INDEX_NAME}")
    except ClientError as e:
        if e.response["Error"]["Code"] in ("NotFoundException", "ResourceNotFoundException"):
            print("  Vector index not found — skipping.")
        else:
            raise


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not S3_BUCKET_NAME:
        print("Error: S3_BUCKET_NAME is not set in .env")
        raise SystemExit(1)

    print("=== RAG Demo – S3 Vectors Indexer ===\n")

    account_id, caller_arn = get_account_and_caller()
    print(f"Account : {account_id}")
    print(f"Caller  : {caller_arn}\n")

    # Four AWS clients: IAM, regular S3 (for sidecars), S3 Vectors, Bedrock Agent
    iam = boto3.client("iam", region_name=AWS_REGION)
    s3 = boto3.client("s3", region_name=AWS_REGION)
    s3v = boto3.client("s3vectors", region_name=AWS_REGION)
    bedrock_agent = boto3.client("bedrock-agent", region_name=AWS_REGION)

    print("[0/6] Cleaning up any existing KB and vector index...")
    teardown(bedrock_agent, s3v)
    print()

    print("[1/6] Creating IAM role for Knowledge Base...")
    role_arn = create_kb_iam_role(iam, account_id, S3_BUCKET_NAME, VECTOR_BUCKET_NAME, VECTOR_INDEX_NAME)

    print("\n[2/6] Creating S3 vector bucket...")
    vector_bucket_arn = create_vector_bucket(s3v, VECTOR_BUCKET_NAME)

    print("\n[3/6] Creating vector index...")
    index_arn = create_vector_index(s3v, VECTOR_BUCKET_NAME, VECTOR_INDEX_NAME)

    print("\n[4/6] Creating Bedrock Knowledge Base...")
    time.sleep(15)  # IAM role changes take ~10-15 s to propagate globally before Bedrock can assume it
    kb_id = create_knowledge_base(bedrock_agent, role_arn, vector_bucket_arn, index_arn)

    print("\n[5/6] Uploading custom metadata sidecars to S3...")
    # Each sidecar is read by Bedrock during ingestion and its attributes are stored
    # alongside the vectors — they are returned with every retrieve() call.
    # Must run BEFORE ingestion starts so Bedrock picks them up.
    upload_metadata_sidecars(s3, S3_BUCKET_NAME, DATA_FOLDER)

    print("\n[6/6] Creating data source and ingesting documents...")
    # Ingestion: Bedrock reads raw docs FROM S3, chunks + embeds them,
    # and writes vectors INTO the S3 Vectors index. Typically takes 2-5 minutes.
    ds_id = create_data_source(bedrock_agent, kb_id, S3_BUCKET_NAME)
    start_and_wait_ingestion(bedrock_agent, kb_id, ds_id)

    print("\n[diagnostic] Inspecting metadata keys written by Bedrock...")
    inspect_vector_metadata(s3v)

    # Persist IDs for the chatbot — app.py reads this file to know which KB to query
    config = {
        "knowledge_base_id": kb_id,
        "data_source_id": ds_id,
        "vector_bucket_arn": vector_bucket_arn,
        "index_arn": index_arn,
        "region": AWS_REGION,
    }
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

    print(f"\n=== Done! Configuration saved to kb_config.json ===")
    print(f"Knowledge Base ID : {kb_id}")
    print("Run app.py to start chatting.")
