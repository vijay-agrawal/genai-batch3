"""
pydantic.py
───────────────────────────────────────────────────────────────────────────────
Healthcare demos of Pydantic — from basic models to LLM-powered structured
output using Amazon Bedrock (Nova Micro).

WHAT THIS FILE COVERS
─────────────────────
1. Basic Pydantic model — Patient schema with auto type coercion
2. Nested models      — Patient with embedded Vitals and Address
3. Field validators   — Custom rules (e.g. valid blood-pressure format)
4. Optional fields    — Sensible defaults for missing data
5. Serialization      — model → JSON and JSON → model round-trip
6. LLM integration    — Use Bedrock to extract structured data from a
                        free-text clinical note and validate with Pydantic
7. Pydantic as output schema — Ask LLM to return JSON matching a schema,
                        then validate and use the result

RUN
───
pip install pydantic boto3 python-dotenv
python pydantic.py

Prereqs: .env file in project root with AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY
"""

# ── Standard + third-party imports ───────────────────────────────────────────
import json
import re
import os
from typing import Optional
from dotenv import load_dotenv

# Pydantic v2 imports
# BaseModel  → base class every schema inherits from
# Field      → attach metadata (description, default, constraints) to a field
# validator  → decorator for custom field-level validation logic
# ValidationError → raised when incoming data fails schema rules
from pydantic import BaseModel, Field, field_validator, ValidationError

# ── Load AWS credentials from .env ───────────────────────────────────────────
load_dotenv()

def strip_markdown_json(text: str) -> str:
    """
    LLMs often wrap JSON in markdown fences like:
        ```json
        { ... }
        ```
    Pydantic's model_validate_json expects raw JSON with no surrounding text.
    This helper strips those fences so validation works correctly.
    """
    # Remove ```json ... ``` or ``` ... ``` wrappers
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()

# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 1 — Basic Pydantic Model (Patient)
#
# Key concept: define a class that inherits BaseModel.
# Each class attribute becomes a validated, typed field.
# Pydantic will COERCE compatible types (e.g. "45" → 45 for an int field).
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 1 — Basic Patient Model (type coercion)")
print("═" * 60)

class Patient(BaseModel):
    # str field — must be a string (or coercible to one)
    patient_id: str

    # int field — "45" as a string will be silently coerced to 45
    age: int

    # str field
    diagnosis: str


# Simulate data arriving from an API / LLM where age came back as a string
raw_data = {
    "patient_id": "P1001",
    "age": "45",          # <-- string, will be coerced to int automatically
    "diagnosis": "Hypertension"
}

patient = Patient(**raw_data)
print(f"Created : {patient}")
print(f"Age type: {type(patient.age).__name__}")   # → int, not str

# Accessing individual fields
print(f"Patient ID  : {patient.patient_id}")
print(f"Age         : {patient.age}")
print(f"Diagnosis   : {patient.diagnosis}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 2 — Validation Error
#
# Key concept: if incoming data is INCOMPATIBLE (not coercible), Pydantic
# raises a ValidationError with a clear, structured error message.
# This is critical in production — bad data is caught BEFORE it reaches your
# business logic or database.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 2 — Validation Error (bad data caught at the gate)")
print("═" * 60)

bad_data = {
    "patient_id": "P1002",
    "age": "sixty two",   # <-- cannot be converted to int → ValidationError
    "diagnosis": "Diabetes"
}

try:
    bad_patient = Patient(**bad_data)
except ValidationError as e:
    # e.errors() returns a structured list of all validation failures
    print("Validation failed (expected):")
    for err in e.errors():
        # loc  → which field failed
        # msg  → human-readable reason
        print(f"  Field : {err['loc']}")
        print(f"  Error : {err['msg']}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 3 — Optional Fields & Default Values
#
# Key concept: wrap a type with Optional[X] to allow None, and use
# Field(default=...) to provide fallback values.
# This is useful when LLM output or API payloads may omit certain keys.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 3 — Optional Fields & Defaults")
print("═" * 60)

class PatientFull(BaseModel):
    patient_id: str
    age: int
    diagnosis: str

    # Optional fields — these will default to None / given value if absent
    medication: Optional[list[str]] = None          # no meds listed yet
    attending_physician: Optional[str] = None       # might not be assigned
    is_critical: bool = False                       # default: not critical
    ward: str = Field(default="General", description="Hospital ward name")

# Minimal payload — only required fields supplied
minimal = PatientFull(patient_id="P1003", age=30, diagnosis="Flu")
print(f"Minimal patient: {minimal}")
print(f"  medication      : {minimal.medication}")        # None
print(f"  is_critical     : {minimal.is_critical}")       # False
print(f"  ward            : {minimal.ward}")              # General

# Full payload
full = PatientFull(
    patient_id="P1004",
    age=55,
    diagnosis="Cardiac Arrest",
    medication=["Aspirin", "Clopidogrel"],
    attending_physician="Dr. Smith",
    is_critical=True,
    ward="ICU"
)
print(f"\nFull patient   : {full}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 4 — Nested Models
#
# Key concept: embed one Pydantic model inside another to represent
# hierarchical / relational data (e.g. a patient HAS vitals, HAS address).
# Pydantic validates the nested model recursively.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 4 — Nested Models (Vitals + Address inside Patient)")
print("═" * 60)

class Vitals(BaseModel):
    """Represents a patient's measured vital signs."""
    blood_pressure: str          # e.g. "120/80"
    heart_rate: int              # beats per minute
    temperature_celsius: float   # body temperature
    oxygen_saturation: float     # SpO2 %

class Address(BaseModel):
    """Physical address — used for home-care coordination."""
    street: str
    city: str
    state: str
    zip_code: str

class HospitalPatient(BaseModel):
    patient_id: str
    name: str
    age: int
    diagnosis: str
    vitals: Vitals               # ← nested Pydantic model
    address: Address             # ← another nested model
    medication: list[str] = []

# Pydantic handles nested dict → nested model conversion automatically
hospital_data = {
    "patient_id": "P2001",
    "name": "Alice Johnson",
    "age": 67,
    "diagnosis": "Congestive Heart Failure",
    "vitals": {                  # dict is auto-converted to Vitals model
        "blood_pressure": "145/95",
        "heart_rate": 92,
        "temperature_celsius": 37.4,
        "oxygen_saturation": 94.2
    },
    "address": {                 # dict is auto-converted to Address model
        "street": "42 Maple Ave",
        "city": "Boston",
        "state": "MA",
        "zip_code": "02101"
    },
    "medication": ["Furosemide", "Lisinopril", "Carvedilol"]
}

hp = HospitalPatient(**hospital_data)
print(f"Patient        : {hp.name}")
print(f"Diagnosis      : {hp.diagnosis}")
print(f"Blood Pressure : {hp.vitals.blood_pressure}")   # access nested field
print(f"City           : {hp.address.city}")
print(f"Medications    : {hp.medication}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 5 — Custom Field Validators
#
# Key concept: @field_validator lets you add domain-specific rules that go
# beyond type checking.  Example: age must be 0-120, blood pressure must
# match the "systolic/diastolic" pattern.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 5 — Custom Field Validators")
print("═" * 60)

class ValidatedPatient(BaseModel):
    patient_id: str
    age: int
    blood_pressure: str   # expected format: "120/80"
    bmi: float

    # Validator for 'age' — must be a plausible human age
    @field_validator("age")
    @classmethod
    def check_age(cls, v):
        if not (0 <= v <= 120):
            raise ValueError(f"Age {v} is outside plausible range 0-120")
        return v

    # Validator for 'blood_pressure' — must match pattern NNN/NN or NN/NN
    @field_validator("blood_pressure")
    @classmethod
    def check_bp_format(cls, v):
        pattern = r"^\d{2,3}/\d{2,3}$"
        if not re.match(pattern, v):
            raise ValueError(
                f"blood_pressure '{v}' must be in 'systolic/diastolic' format e.g. '120/80'"
            )
        return v

    # Validator for 'bmi' — clinically implausible values are rejected
    @field_validator("bmi")
    @classmethod
    def check_bmi(cls, v):
        if not (10.0 <= v <= 80.0):
            raise ValueError(f"BMI {v} is outside plausible range 10-80")
        return v

# Valid patient
try:
    vp = ValidatedPatient(
        patient_id="P3001",
        age=45,
        blood_pressure="120/80",
        bmi=27.5
    )
    print(f"Valid patient created: {vp}")
except ValidationError as e:
    print(f"Unexpected error: {e}")

# Invalid patient — age 150, bad BP format
print("\nTrying invalid data (age=150, bp='120-80', bmi=5):")
try:
    bad_vp = ValidatedPatient(
        patient_id="P3002",
        age=150,             # fails age validator
        blood_pressure="120-80",  # fails bp format validator
        bmi=5.0              # fails bmi validator
    )
except ValidationError as e:
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 6 — Serialization: model → JSON and JSON → model
#
# Key concept: Pydantic models have built-in methods for serialization.
#   model.model_dump()       → Python dict
#   model.model_dump_json()  → JSON string
#   Model.model_validate()   → parse dict/JSON into model (Pydantic v2)
#
# This is essential for storing records in a database, sending over HTTP,
# or logging structured events.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 6 — Serialization (model ↔ JSON)")
print("═" * 60)

# Reuse HospitalPatient from Demo 4
as_dict = hp.model_dump()
print("model_dump() (Python dict):")
print(json.dumps(as_dict, indent=2))

# model → JSON string
as_json = hp.model_dump_json(indent=2)
print("\nmodel_dump_json() (JSON string, first 200 chars):")
print(as_json[:200])

# JSON string → model (round-trip)
restored = HospitalPatient.model_validate_json(as_json)
print(f"\nRound-trip restored patient: {restored.name}, {restored.vitals.blood_pressure}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 7 — LLM Integration: Extract Structured Data from a Clinical Note
#
# Key concept: LLMs produce free-text. We can instruct the LLM to return JSON
# that matches a Pydantic schema, then validate and use the result.
#
# Flow:
#   Clinical note (free text)
#       → Bedrock LLM (prompted to return JSON)
#           → JSON string
#               → Pydantic model (validate + use safely)
#
# This is the CORE pattern used in LangChain, LlamaIndex, and OpenAI
# structured-output features — Pydantic acts as the contract.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 7 — LLM Integration: Clinical Note → Structured Patient Data")
print("═" * 60)

# ── Pydantic schema for the LLM to populate ──────────────────────────────────
class ClinicalExtraction(BaseModel):
    """Schema we expect the LLM to fill from a clinical note."""
    patient_name: str
    age: int
    diagnosis: str
    symptoms: list[str]
    medications: list[str]
    follow_up_days: Optional[int] = None   # LLM might not always extract this

# ── Sample clinical note (unstructured text) ─────────────────────────────────
clinical_note = """
PATIENT: John Doe, 58-year-old male.
CHIEF COMPLAINT: Chest pain, shortness of breath, fatigue for 3 days.
ASSESSMENT: Stable angina likely secondary to coronary artery disease.
PLAN: Initiate Aspirin 81mg daily, Atorvastatin 40mg nightly, and
      Metoprolol 25mg twice daily. Follow up in 2 weeks.
"""

# ── System prompt that instructs the LLM to return structured JSON ────────────
# We embed the Pydantic schema's field names directly in the prompt so the LLM
# knows exactly what keys to produce.
system_prompt = """You are a clinical data extraction assistant.
Extract patient information from the provided clinical note and return ONLY
valid JSON (no markdown, no explanation) with these exact keys:
{
  "patient_name": "<string>",
  "age": <integer>,
  "diagnosis": "<string>",
  "symptoms": ["<string>", ...],
  "medications": ["<string>", ...],
  "follow_up_days": <integer or null>
}
"""

# ── Connect to Amazon Bedrock ─────────────────────────────────────────────────
AWS_ACCESS_KEY_ID     = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_REGION            = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID              = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")

import boto3

bedrock = boto3.client(
    "bedrock-runtime",
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY_ID,
    aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
)

# ── Call the LLM ──────────────────────────────────────────────────────────────
print(f"Calling Bedrock model: {MODEL_ID}")
print(f"Input note:\n{clinical_note.strip()}\n")

response = bedrock.converse(
    modelId=MODEL_ID,
    system=[{"text": system_prompt}],
    messages=[{"role": "user", "content": [{"text": clinical_note}]}],
    inferenceConfig={"maxTokens": 512, "temperature": 0.0},  # 0 temp for determinism
)

raw_llm_output = response["output"]["message"]["content"][0]["text"]
print(f"Raw LLM output:\n{raw_llm_output}\n")

# ── Parse and validate with Pydantic ─────────────────────────────────────────
# model_validate_json converts the JSON string into a ClinicalExtraction object
# and validates every field according to our schema.
try:
    extracted = ClinicalExtraction.model_validate_json(strip_markdown_json(raw_llm_output))
    print("Pydantic-validated extraction:")
    print(f"  Patient      : {extracted.patient_name}, age {extracted.age}")
    print(f"  Diagnosis    : {extracted.diagnosis}")
    print(f"  Symptoms     : {extracted.symptoms}")
    print(f"  Medications  : {extracted.medications}")
    print(f"  Follow-up    : {extracted.follow_up_days} days")
except ValidationError as e:
    print("LLM output failed Pydantic validation:")
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
except json.JSONDecodeError as e:
    print(f"LLM did not return valid JSON: {e}")
    print(f"Raw output was: {raw_llm_output}")


# ═══════════════════════════════════════════════════════════════════════════════
# DEMO 8 — LLM as Diagnostic Assistant (Schema-Driven Output)
#
# Key concept: define a richer output schema and ask the LLM to produce a
# complete clinical summary.  Pydantic ensures the response is usable by
# downstream code (e.g. an EHR system or alert engine) without any
# manual parsing.
# ═══════════════════════════════════════════════════════════════════════════════

print("\n" + "═" * 60)
print("DEMO 8 — Schema-Driven LLM Output (Clinical Summary)")
print("═" * 60)

class ClinicalSummary(BaseModel):
    """Structured summary that a downstream EHR system would consume."""
    patient_name: str
    diagnosis: str
    severity: str               # "mild" | "moderate" | "severe"
    treatment_plan: list[str]   # ordered list of actions
    red_flags: list[str]        # warning signs to watch
    referral_needed: bool

schema_prompt = """You are a clinical documentation assistant.
Given a patient case, return ONLY valid JSON (no markdown) matching:
{
  "patient_name": "<string>",
  "diagnosis": "<string>",
  "severity": "<mild|moderate|severe>",
  "treatment_plan": ["<step1>", "<step2>", ...],
  "red_flags": ["<flag1>", ...],
  "referral_needed": <true|false>
}
"""

case_description = """
Patient Maria Torres, 72F, presents with progressive confusion, fever 38.9°C,
dysuria, and urinary frequency for 48 hours.  History of recurrent UTIs.
Labs show WBC 14,000, UA positive for nitrites and leukocyte esterase.
"""

print(f"Case:\n{case_description.strip()}\n")

resp2 = bedrock.converse(
    modelId=MODEL_ID,
    system=[{"text": schema_prompt}],
    messages=[{"role": "user", "content": [{"text": case_description}]}],
    inferenceConfig={"maxTokens": 512, "temperature": 0.0},
)

raw2 = resp2["output"]["message"]["content"][0]["text"]
print(f"Raw LLM output:\n{raw2}\n")

try:
    summary = ClinicalSummary.model_validate_json(strip_markdown_json(raw2))
    print("Validated Clinical Summary:")
    print(f"  Patient         : {summary.patient_name}")
    print(f"  Diagnosis       : {summary.diagnosis}")
    print(f"  Severity        : {summary.severity}")
    print(f"  Treatment Plan  :")
    for step in summary.treatment_plan:
        print(f"    • {step}")
    print(f"  Red Flags       :")
    for flag in summary.red_flags:
        print(f"    ⚠ {flag}")
    print(f"  Referral Needed : {summary.referral_needed}")
except ValidationError as e:
    print("Validation error on clinical summary:")
    for err in e.errors():
        print(f"  {err['loc']} → {err['msg']}")
except json.JSONDecodeError as e:
    print(f"JSON parse error: {e}\nRaw: {raw2}")


print("\n" + "═" * 60)
print("All demos complete.")
print("═" * 60)
