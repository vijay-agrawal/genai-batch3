#!/usr/bin/env python3
import os
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from rich import print
from utils import load_tx, rule_score_tx, log_jsonl

from pathlib import Path
from crewai import LLM

def _find_project_root() -> Path:
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

load_dotenv(_find_project_root() / ".env")

# Amazon Bedrock LLM configuration via LiteLLM
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

llm = LLM(model=f"bedrock/{MODEL_ID}", temperature=0.7)
print(f"Using Bedrock model: bedrock/{MODEL_ID}")

TX_TABLE = rule_score_tx(load_tx()).to_markdown(index=False)

react_agent = Agent(
    role="Fraud Investigator (ReAct)",
    goal="Identify which transactions require review and explain why.",
    backstory="Iteratively: think → consult evidence → think…",
    allow_delegation=False,
    llm=llm,
)

react_task = Task(
    agent=react_agent,
    description=(
        "REACT LOOP:\n"
        "1) THINK about the next step.\n"
        "2) ACT by consulting exactly one 'tool': the TX TABLE provided below.\n"
        "3) OBSERVE: read the table and update your reasoning.\n"
        "Stop when confident. Then output a markdown report with:\n"
        "- Transactions to REVIEW (tx_id + rationale)\n"
        "- Transactions to ALLOW (tx_id + brief reason)\n"
        "- Portfolio summary: % review, average rule_score (2 decimals)\n"
        "≤150 words.\n\n"
        "TX TABLE:\n{tx_table}"
    ),
    expected_output="Markdown report with transactions to REVIEW, ALLOW, and portfolio summary."
)

crew = Crew(agents=[react_agent], tasks=[react_task], process=Process.sequential)

if __name__ == "__main__":
    log_jsonl("outputs/react_trace.jsonl", {"event":"start","pattern":"react"})
    result = crew.kickoff(inputs={"tx_table": TX_TABLE})
    log_jsonl("outputs/react_trace.jsonl", {"event":"end","pattern":"react","result":str(result)[:1500]})
    with open("outputs/react_report.md","w",encoding="utf-8") as f: f.write(str(result))
    print("[bold green]ReAct run complete → outputs/react_report.md[/bold green]")
