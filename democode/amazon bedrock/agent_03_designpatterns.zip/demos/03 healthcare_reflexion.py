#!/usr/bin/env python3
"""
Reflexion Pattern Demonstration - Healthcare Discharge Summary

================================================================================
REFLEXION PATTERN OVERVIEW:
================================================================================
Reflexion is an agentic pattern that implements self-correction and quality assurance:

Key Components:
- Author Agent: Creates initial draft/analysis
- Critic Agent: Reviews and challenges the work, identifies issues
- Feedback Loop: Outputs from critic inform author's revisions
- Quality Assurance: Multiple rounds of refinement until quality threshold met

Key Benefits:
- Catches errors and omissions that single agents miss
- Mimics peer review process in professional settings
- Produces higher quality outputs through iteration
- Ensures domain-specific requirements are met

Typical Workflow:
1. Author creates initial work
2. Critic reviews against rubric/requirements
3. Critic provides structured feedback
4. (Optional) Author revises based on feedback
5. Final output is higher quality

================================================================================
DEMO DESCRIPTION - What This Script Does:
================================================================================
1. Creates Clinical Author agent to draft discharge summary from medical notes
2. Creates Clinical Critic agent to review for safety/clarity/completeness
3. Uses reflexion pattern: Author creates → Critic reviews → Analysis provided
4. Demonstrates quality assurance in medical writing context
5. Outputs structured discharge summary with safety checks

Use Case: Hospital discharge summaries must be clear, complete, and safe
- Medications with correct doses and schedules
- Follow-up appointments and timelines
- Warning signs for patient safety
- Plain language for patient understanding

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: CrewAI (Multi-agent orchestration)
  - Agent: Author and Critic with specialized roles
  - Task: Separate tasks for drafting and reviewing
  - Crew: Orchestrates agents in sequential process
  - Process: Sequential (critic runs after author)

LLM Model: Google Gemini 2.0 Flash
  - API Provider: Google Cloud Vertex AI / Google AI
  - Model ID: gemini/gemini-2.0-flash
  - Temperature: 0.7

Data:
  - Input: Clinical notes (data/clinical_notes.txt)
  - Output: Formatted discharge summary

Environment Configuration:
  - Uses .env file for API keys (GEMINI_API_KEY)
  - Automatic credential path resolution for Google Cloud authentication
================================================================================
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
from textwrap import dedent
import warnings

warnings.filterwarnings('ignore')

def _find_project_root() -> Path:
    """Find project root by looking for .env file."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

# Load environment variables first
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Amazon Bedrock LLM configuration via LiteLLM
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

llm = LLM(
    model=f"bedrock/{MODEL_ID}",
    temperature=0.7
)
print(f"Using Bedrock model: bedrock/{MODEL_ID}")

def read_notes():
    """Read clinical notes from file"""
    data_path = Path(__file__).resolve().parent / "data" / "clinical_notes.txt"
    with open(data_path, "r") as f:
        return f.read()

# Create Author agent
author = Agent(
    role="Clinical Author",
    goal="Draft a safe and clear discharge summary from raw notes.",
    backstory="Hospitalist who communicates clearly with patients and caregivers.",
    llm=llm
)

# Create Critic agent for Reflexion review
critic = Agent(
    role="Clinical QA Critic",
    goal="Detect safety issues, omissions, and unclear language; suggest fixes.",
    backstory="Quality officer with a strict rubric: meds, follow-up, red flags, and plain language.",
    llm=llm
)

draft_task = Task(
    description=dedent("""\
    Using the clinical notes provided, create a discharge summary with these sections:
    - Diagnosis & Hospital Course
    - Medications (dose, schedule, changes)
    - Follow-up & Monitoring
    - Patient Instructions (plain language)
    Keep to ~180-220 words.

    Clinical Notes:
    {clinical_notes}
    """),
    agent=author,
    expected_output="A structured discharge summary (~180-220 words) with Diagnosis, Medications, Follow-up, and Patient Instructions sections."
)

review_task = Task(
    description=dedent("""\
    Review the draft against this rubric:
    1) Meds: doses/schedule clear? contraindications?
    2) Follow-up: timelines and provider?
    3) Red flags: when to seek help?
    4) Clarity: avoid jargon.
    Return a short critique and a revised summary.
    """),
    agent=critic,
    expected_output="A critique listing issues found and a revised discharge summary addressing those issues."
)

crew = Crew(agents=[author, critic], tasks=[draft_task, review_task], process=Process.sequential)

if __name__ == "__main__":
    notes = read_notes()
    result = crew.kickoff(inputs={"clinical_notes": notes})
    os.makedirs("outputs", exist_ok=True)
    with open("outputs/healthcare_reflexion_summary.md","w") as f: f.write(str(result))
    print("=== Healthcare Critic–Author (Reflexion) Result ===")
    print(result)
