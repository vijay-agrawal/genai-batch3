# Import required libraries
"""
Quality Control with Multi-Pattern Integration

================================================================================
MULTI-PATTERN INTEGRATION EXPLANATION:
================================================================================

This demo combines multiple agentic AI patterns:

1. SUPERVISOR-WORKER: Hierarchical coordination with delegation
2. COLLABORATION: Peer-to-peer agent cooperation
3. REFLEXION: Self-correction through review and challenge
4. MEMORY: Persistent context and learning across interactions

Integration Benefits:
- Leverages strengths of each pattern
- Creates robust, fault-tolerant systems
- Enables complex workflow orchestration
- Provides multiple quality assurance layers
- Supports continuous improvement through memory

Real-World Application:
Manufacturing quality control requires:
- Hierarchical oversight (supervisor)
- Specialist collaboration (inspection, analysis)
- Self-correction (quality review)
- Historical learning (memory of past issues)

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: CrewAI (Multi-agent orchestration)
  - Agent: Supervisor + specialist workers with memory
  - Task: Quality control workflow tasks
  - Crew: Multi-pattern orchestration
  - Process: Sequential for quality gates

LLM Model: Google Gemini 2.0 Flash
  - API Provider: Google Cloud Vertex AI / Google AI
  - Model ID: gemini/gemini-2.0-flash
  - Temperature: 0.7 (or 0 for consistent quality assessment)

Environment Configuration:
  - Uses .env file for API keys (GEMINI_API_KEY)
  - Automatic credential path resolution for Google Cloud authentication
================================================================================
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
from crewai.tools import tool

# Load environment variables
def _find_project_root() -> Path:
    """Find project root by looking for .env file."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

# Load environment variables first
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Amazon Bedrock LLM configuration via LiteLLM
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

llm = LLM(
    model=f"bedrock/{MODEL_ID}",
    temperature=0.7
)
print(f"Using Bedrock model: bedrock/{MODEL_ID}")

# ===============================
# CUSTOM TOOLS FOR INSPECTION
# ===============================

@tool("Visual Inspection")
def visual_inspect(part_description: str) -> str:
    """Inspect parts for visual defects like scratches, dents, or discoloration."""
    return f"Visual inspection complete for {part_description}: No critical visual defects found. Minor surface variations noted."

@tool("Measurement Tool")
def measure(part_id: str) -> str:
    """Take dimensional measurements of a part."""
    return f"Measurements for {part_id}: All dimensions within tolerance (±0.05mm). Length: 150.02mm, Width: 75.01mm, Height: 25.00mm"

# ===============================
# AGENTS WITH MEMORY
# ===============================

# Supervisor Agent
quality_supervisor = Agent(
    role='Quality Control Supervisor',
    goal='Oversee production quality workflow',
    backstory='Senior QC manager coordinating quality teams',
    allow_delegation=True,
    memory=True,
    llm=llm,
)

# Worker Agents (Collaborative)
inspector = Agent(
    role='Quality Inspector',
    goal='Inspect products for defects using visual inspection and measurements',
    backstory='Skilled inspector with defect detection expertise in visual inspection and dimensional measurements',
    tools=[visual_inspect, measure],
    memory=True,
    llm=llm,
)

analyst = Agent(
    role='Data Analyst',
    goal='Analyze quality trends and patterns',
    backstory='Statistical analyst tracking quality metrics',
    memory=True,
    llm=llm,
)

# Reflexion Agent
reviewer = Agent(
    role='Quality Reviewer',
    goal='Review and challenge quality decisions',
    backstory='Senior engineer ensuring quality standards',
    memory=True,
    llm=llm,
)

# Process Improvement Agent
optimizer = Agent(
    role='Process Optimizer',
    goal='Suggest manufacturing improvements',
    backstory='Continuous improvement specialist',
    memory=True,
    llm=llm,
)

# Multi-pattern tasks
inspection_task = Task(
    description='Inspect batch of automotive parts for defects',
    agent=inspector,
    expected_output='Inspection report with defect analysis'
)

trend_analysis = Task(
    description='Analyze quality trends from inspection data',
    agent=analyst,
    expected_output='Quality trend analysis',
    context=[inspection_task]
)

quality_review = Task(
    description='Review inspection decisions and identify risks',
    agent=reviewer,
    expected_output='Quality review with risk assessment',
    context=[inspection_task, trend_analysis]
)

process_optimization = Task(
    description='Recommend process improvements based on findings',
    agent=optimizer,
    expected_output='Process improvement recommendations',
    context=[trend_analysis, quality_review]
)

final_decision = Task(
    description='Make final quality decision for production batch',
    agent=quality_supervisor,
    expected_output='Final quality decision and actions',
    context=[inspection_task, quality_review, process_optimization]
)

# Multi-pattern crew
crew = Crew(
    agents=[quality_supervisor, inspector, analyst, reviewer, optimizer],
    tasks=[inspection_task, trend_analysis, quality_review, process_optimization, final_decision],
    process=Process.hierarchical,
    manager_llm=llm,
    memory=True,
    verbose=True,
)

result = crew.kickoff(inputs={
    'batch_id': 'AUTO2025-001',
    'product_type': 'Engine components',
    'quality_target': '99.5% defect-free'
})