"""
CrewAI + Amazon Bedrock Reusable Template

This is a standardized template for creating CrewAI agents with Amazon Bedrock LLM.
Use this as a starting point for new demos or when converting existing ones.

Key Features:
- Centralized environment and credential management
- Automatic .env detection
- Proper error handling with informative messages
- Ready-to-use LLM instance configured for Amazon Bedrock (Nova Micro)
- No LangChain dependencies (CrewAI only)

Usage:
    1. Import this template in your script
    2. Use the 'llm' object in all your agents
    3. Access PROJECT_ROOT for relative path resolution

Example:
    from crewai_gemini_template import llm, PROJECT_ROOT

    my_agent = Agent(
        role="My Role",
        goal="My Goal",
        backstory="My backstory",
        llm=llm
    )
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from crewai import LLM

# ================================================================================
# ENVIRONMENT SETUP - Common to all CrewAI + Bedrock projects
# ================================================================================

def _find_project_root() -> Path:
    """
    Find project root by looking for .env file.

    Searches upward from current script location until it finds a .env file.
    Falls back to current script's parent directory.
    """
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent


# Load environment variables first
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")


# ================================================================================
# BEDROCK LLM INITIALIZATION - Ready-to-use LLM instance
# ================================================================================

def _initialize_bedrock_llm() -> LLM:
    """
    Initialize and return a CrewAI LLM instance configured for Amazon Bedrock.

    Environment Variables (optional, with defaults):
        AWS_REGION      - AWS region (default: us-east-1)
        BEDROCK_MODEL_ID - Bedrock model ID (default: amazon.nova-micro-v1:0)

    AWS credentials are sourced from the environment or ~/.aws/credentials.

    Returns:
        LLM: Configured LLM instance ready for use with agents
    """
    aws_region = os.getenv("AWS_REGION", "us-east-1")
    model_id = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")

    os.environ.setdefault("AWS_REGION_NAME", aws_region)

    bedrock_llm = LLM(
        model=f"bedrock/{model_id}",
        temperature=0.7
    )

    print(f"Initialized Bedrock LLM: bedrock/{model_id} (region: {aws_region})")
    return bedrock_llm


# Create the globally available LLM instance
llm = _initialize_bedrock_llm()


# ================================================================================
# UTILITY FUNCTIONS
# ================================================================================

def get_data_path(filename: str) -> Path:
    """
    Resolve relative data file paths to absolute paths.

    Args:
        filename: Relative path from project root (e.g., "data/defects.csv")

    Returns:
        Path: Absolute path to the file

    Example:
        data_path = get_data_path("data/clinical_notes.txt")
    """
    return PROJECT_ROOT / filename


def ensure_output_dir(dirname: str = "outputs") -> Path:
    """
    Ensure output directory exists and return its path.

    Args:
        dirname: Name of output directory (default: "outputs")

    Returns:
        Path: Absolute path to output directory

    Example:
        output_dir = ensure_output_dir()
        result_file = output_dir / "results.txt"
    """
    output_path = PROJECT_ROOT / dirname
    output_path.mkdir(exist_ok=True)
    return output_path


# ================================================================================
# CONFIGURATION
# ================================================================================

class Config:
    """Centralized configuration for CrewAI projects"""

    PROJECT_ROOT = PROJECT_ROOT
    LLM_MODEL = f"bedrock/{os.getenv('BEDROCK_MODEL_ID', 'amazon.nova-micro-v1:0')}"
    LLM_TEMPERATURE = 0.7
    VERBOSE_MODE = True
    MEMORY_ENABLED = True


# ================================================================================
# EXAMPLE AGENT FACTORY FUNCTIONS
# ================================================================================

def create_agent(role: str, goal: str, backstory: str, tools=None, memory=True, verbose=True):
    """
    Factory function to create agents with consistent configuration.

    Args:
        role: Agent's professional role
        goal: What the agent is trying to achieve
        backstory: Agent's background and context
        tools: List of tools available to the agent (optional)
        memory: Whether to enable memory (default: True)
        verbose: Whether to show detailed execution (default: True)

    Returns:
        Agent: Configured CrewAI Agent instance

    Example:
        from crewai import Agent

        my_agent = create_agent(
            role="Data Analyst",
            goal="Analyze business metrics",
            backstory="Experienced analyst with SQL skills",
            tools=[analysis_tool]
        )
    """
    from crewai import Agent

    return Agent(
        role=role,
        goal=goal,
        backstory=backstory,
        tools=tools or [],
        memory=memory,
        verbose=verbose,
        llm=llm
    )


# ================================================================================
# DEBUG UTILITIES
# ================================================================================

def print_setup_info():
    """Print diagnostic information about the environment setup"""
    print("\n" + "=" * 70)
    print("SETUP INFORMATION")
    print("=" * 70)
    print(f"Project Root: {PROJECT_ROOT}")
    print(f"LLM Model: {Config.LLM_MODEL}")
    print(f"Temperature: {Config.LLM_TEMPERATURE}")
    print(f"Memory Enabled: {Config.MEMORY_ENABLED}")
    print(f"Verbose Mode: {Config.VERBOSE_MODE}")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    # When run directly, show setup information
    print_setup_info()
    print("Template loaded successfully")
    print("Use 'from crewai_gemini_template import llm' in your scripts")
