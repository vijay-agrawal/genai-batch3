#!/usr/bin/env python3
"""
ReWoo (Reasoning Without Observation) Pattern Demonstration

================================================================================
REWOO PATTERN OVERVIEW:
================================================================================
ReWoo stands for "Reasoning without Observation" - a three-stage approach:

1. REASONING (R): Plan what needs to be done
   - Break down complex problems into steps
   - Create a logical workflow without executing actions
   - Optimize the approach before taking action

2. WORKING (W): Execute the planned actions
   - Use tools and APIs to gather information
   - Perform calculations and data processing
   - Implement the reasoning plan step-by-step

3. OBSERVING (O): Evaluate results and provide feedback
   - Analyze the outcomes of executed actions
   - Identify issues or improvements needed
   - Provide recommendations for optimization

This pattern separates planning from execution, making workflows more reliable.

================================================================================
DEMO DESCRIPTION - What This Script Does:
================================================================================
1. Creates three specialized agents: Planner, Executor, Observer
2. Solves inventory optimization problem using ReWoo methodology
3. Plans approach before execution (no premature action)
4. Executes planned steps with tool calls
5. Reviews results and provides analysis/recommendations

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: CrewAI (Multi-agent orchestration)
  - Agent: Specialized roles for reasoning, execution, observation
  - Task: Specific work for each stage
  - Crew: Orchestrates agents in sequential process

LLM Model: Google Gemini 2.0 Flash
  - API Provider: Google Cloud Vertex AI / Google AI
  - Model ID: gemini/gemini-2.0-flash
  - Temperature: 0.7

Environment Configuration:
  - Uses .env file for API keys (GEMINI_API_KEY)
  - Automatic credential path resolution for Google Cloud authentication
================================================================================
"""

import os
import pandas as pd
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
from textwrap import dedent
import warnings

warnings.filterwarnings('ignore')

def _find_project_root() -> Path:
    """Find project root by looking for .env file."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

# Load environment variables first
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Amazon Bedrock LLM configuration via LiteLLM
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

llm = LLM(
    model=f"bedrock/{MODEL_ID}",
    temperature=0.7
)
print(f"Using Bedrock model: bedrock/{MODEL_ID}")

# Sample data loading function
def load_prices():
    """Load retail pricing data for demonstration"""
    data_path = Path(__file__).resolve().parent / "data" / "retail_prices.csv"
    return pd.read_csv(data_path)

# Create agents for ReWoo pattern
planner = Agent(
    role="Retail Pricing Planner",
    goal="Produce a symbolic plan (operations) to recommend price changes for top 3 SKUs.",
    backstory="Retail strategist who outlines exact tool I/O needed.",
    llm=llm
)

operator = Agent(
    role="Tool Operator",
    goal="Execute the plan strictly via local tools and report computed metrics.",
    backstory="Trusts data over hunches, returns small data tables from Python tools.",
    llm=llm
)

finalizer = Agent(
    role="Pricing Finalizer",
    goal="Synthesize a final price recommendation with rationale and projected impact.",
    backstory="Converts tool outputs into an executive note with actionables.",
    llm=llm
)

task1 = Task(
    description=dedent("""\
    ReWOO step 1 — Produce a plan with explicit operations:
    - OP1: Load retail_prices.csv
    - OP2: Compute price gap = (competitor_price - price)
    - OP3: Propose +/- price deltas to balance margin and competitiveness
    Return only the plan and I/O names (no narrative).
    """),
    agent=planner,
    expected_output="A structured plan with explicit operations (OP1, OP2, OP3) and their I/O names."
)

task2 = Task(
    description=dedent("""\
    Execute the plan using the local tools and return a small table with:
    sku, product, price, competitor_price, gap, proposed_price, rationale (1 line).

    Here is the data from our retail pricing system:
    {pricing_table}
    """),
    agent=operator,
    expected_output="A markdown table with columns: sku, product, price, competitor_price, gap, proposed_price, rationale."
)

task3 = Task(
    description=dedent("""\
    Using the operator's table, write a concise recommendation (<=150 words):
    - Highlight risks (race to bottom, inventory effects)
    - Include an 'Experiment plan' (A/B for 7 days)
    """),
    agent=finalizer,
    expected_output="A concise recommendation (<=150 words) with risk highlights and an A/B experiment plan."
)

crew = Crew(agents=[planner, operator, finalizer], 
            tasks=[task1, task2, task3], 
            process=Process.sequential)

if __name__ == "__main__":
    df = load_prices().copy()
    df["gap"] = (df["competitor_price"] - df["price"]).round(2)
    # generate a tiny "operator tool" output for the model to read
    df["proposed_price"] = (df["price"] + df["gap"].clip(-2,2)/2).round(2)
    df["rationale"] = ["Close gap modestly to test"]*len(df)
    table = df[["sku","product","price","competitor_price","gap","proposed_price","rationale"]].to_markdown(index=False)
    result = crew.kickoff(inputs={"pricing_table": table})
    os.makedirs("outputs", exist_ok=True)
    with open("outputs/retail_rewoo_pricing.md","w") as f: f.write(str(result))
    print("=== Retail ReWOO / Tool-Orchestration Result ===")
    print(result)
