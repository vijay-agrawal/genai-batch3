"""
ReAct (Reasoning + Acting) Pattern Demonstration

================================================================================
REACT PATTERN OVERVIEW:
================================================================================
ReAct is an agentic design pattern that enables LLMs to reason and act iteratively:
- THINK: Analyze the problem and plan approach
- ACT: Use a tool to gather information or perform an action
- OBSERVE: Analyze the tool results
- REPEAT: Continue the THINK-ACT-OBSERVE cycle until the goal is achieved
- FINAL ANSWER: Provide a comprehensive, well-reasoned answer

Key Benefits:
- Improves accuracy through transparent reasoning steps
- Enables complex problem-solving via iterative tool use
- Reduces hallucinations by grounding responses in real data
- Allows agents to correct course when observations don't match expectations

================================================================================
DEMO DESCRIPTION - What This Script Does:
================================================================================
1. Initializes a CrewAI agent with ReAct-enabled reasoning capabilities
2. Equips the agent with multiple tools:
   - Calculator: Performs mathematical computations
   - DataAnalyzer: Analyzes data patterns and statistics
   - FileReader: Reads local file contents
   - SerperDev (optional): Performs web searches if API key available
3. Demonstrates three example queries:
   - Mathematical problem (percentage growth calculation)
   - Research question (renewable energy trends)
   - Multi-step analysis (tech company market cap comparison)
4. Provides interactive mode for ad-hoc queries with full ReAct reasoning visibility
5. Showcases use cases across financial analysis, market research, and business intelligence

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Agent Orchestration Framework: CrewAI
Uses following CrewAI components/classes:
  - Agent: Represents an autonomous AI agent with tools and instructions
  - Task: Defines specific work for an agent to accomplish
  - Crew: Manages multiple agents and coordinates their execution
  - Process: Defines execution strategy (sequential in this demo)
  - LLM: Wrapper for language model configuration

LLM Model: Google Gemini 2.0 Flash
  - API Provider: Google Cloud Vertex AI / Google AI
  - Model ID: gemini/gemini-2.0-flash
  - Temperature: 0.7 (balanced creativity and consistency)
  - Reasoning: Advanced reasoning for complex problem-solving

Custom Tools: BaseTool from CrewAI
  - Pydantic models for input schema validation
  - Type hints for tool parameter specification

Optional Integration: SerperDev Tool (web search)
  - Requires SERPER_API_KEY environment variable
  - Enables real-time information retrieval

Environment Configuration:
  - Uses .env file for API keys (GEMINI_API_KEY, SERPER_API_KEY)
  - Automatic credential path resolution for Google Cloud authentication
================================================================================
"""

import os
import warnings
from pathlib import Path
from dotenv import load_dotenv

# Ignore warnings for cleaner output
warnings.filterwarnings('ignore')

def _find_project_root() -> Path:
    """Find project root by looking for .env file."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

# Load environment variables first
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

from crewai import Agent, Task, Crew, Process, LLM
from crewai.tools import BaseTool
from crewai_tools import FileReadTool
from typing import Type
from pydantic import BaseModel, Field

# Search tools require API keys - check for SERPER_API_KEY
SERPER_API_KEY = os.getenv("SERPER_API_KEY") or os.getenv("SERP_API_KEY")
if not SERPER_API_KEY:
    print("ERROR: SERPER_API_KEY not found in environment variables.")
    print("Please add SERPER_API_KEY (or SERP_API_KEY) to your .env file.")
    exit(1)

# Try to import search tools
SEARCH_TOOL_AVAILABLE = False
try:
    from crewai_tools import SerperDevTool
    SEARCH_TOOL_AVAILABLE = True
except ImportError:
    try:
        from crewai_tools import SerpApiTool as SerperDevTool
        SEARCH_TOOL_AVAILABLE = True
    except ImportError:
        print("ERROR: Search tools not available. Install with: pip install crewai-tools[search]")
        exit(1)

# Amazon Bedrock LLM configuration via LiteLLM
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

llm = LLM(
    model=f"bedrock/{MODEL_ID}",
    temperature=0.7
)
print(f"Using Bedrock model: bedrock/{MODEL_ID}")


class CalculatorInput(BaseModel):
    """Input schema for Calculator tool."""
    expression: str = Field(..., description="Mathematical expression to evaluate, e.g. '2 + 2' or '(1.8 - 1.2) / 1.2 * 100'")


class CalculatorTool(BaseTool):
    name: str = "Calculator"
    description: str = "Performs mathematical calculations. Input should be a mathematical expression as a string."
    args_schema: Type[BaseModel] = CalculatorInput

    def _run(self, expression: str) -> str:
        try:
            safe_chars = set('0123456789+-*/().,** ')
            if not all(c in safe_chars for c in expression.replace(' ', '')):
                return f"Error: Invalid characters in expression: {expression}"
            result = eval(expression)
            return f"Result: {result}"
        except Exception as e:
            return f"Error calculating '{expression}': {str(e)}"


class DataAnalyzerInput(BaseModel):
    """Input schema for DataAnalyzer tool."""
    data_description: str = Field(..., description="Description of the data analysis needed")


class DataAnalyzerTool(BaseTool):
    name: str = "DataAnalyzer"
    description: str = "Analyzes data patterns, calculates statistics, or processes structured data."
    args_schema: Type[BaseModel] = DataAnalyzerInput

    def _run(self, data_description: str) -> str:
        analysis_types = {
            "average": "calculated mean value",
            "trend": "identified upward/downward trend",
            "correlation": "found statistical relationship",
            "summary": "provided statistical summary",
            "percentage": "calculated percentage",
            "growth": "calculated growth rate"
        }
        for analysis_type, result in analysis_types.items():
            if analysis_type in data_description.lower():
                return f"Analysis complete: {result} for {data_description}"
        return f"General analysis performed on: {data_description}"


class FileReadInput(BaseModel):
    """Input schema for FileRead tool."""
    file_path: str = Field(..., description="Path to the file to read")


def create_react_agent(agent_llm=None) -> Agent:
    """Create a ReAct agent with comprehensive tools"""
    if agent_llm is None:
        agent_llm = llm

    # Initialize tools
    tools = []

    # Add search tool if available
    if SEARCH_TOOL_AVAILABLE:
        search_tool = SerperDevTool()
        tools.append(search_tool)

    # Add custom tools
    file_reader = FileReadTool()
    calculator = CalculatorTool()
    data_analyzer = DataAnalyzerTool()
    tools.extend([calculator, data_analyzer, file_reader])

    # Define the ReAct agent
    # Note: memory=False disables agent memory that may use OpenAI embeddings
    react_agent = Agent(
        role="ReAct Research Assistant",
        goal=(
            "Answer complex questions by systematically thinking through problems, "
            "using appropriate tools iteratively, and providing well-reasoned final answers."
        ),
        backstory=(
            "You are an intelligent research assistant that follows the ReAct (Reasoning + Acting) "
            "methodology. You break down complex problems into steps, use tools strategically, "
            "and always cite your sources. You're methodical, accurate, and transparent about "
            "your reasoning process."
        ),
        tools=tools,
        allow_delegation=False,
        verbose=True,
        llm=agent_llm,
        max_iter=2,  # Limit to 2-3 iterations (with buffer for final answer)
        memory=False,
    )

    return react_agent

def create_react_task(question: str, agent: Agent) -> Task:
    """Create a ReAct task for a specific question"""

    task_description = f"""
    Answer this question using the ReAct methodology: "{question}"

    Follow this structured approach:

    **THINK**: Analyze the question and plan your approach
    - What information do I need?
    - Which tools might be helpful?
    - What's my strategy?

    **ACT**: Use exactly one tool with specific, minimal parameters
    - Choose the most appropriate tool for the current step
    - Use clear, focused inputs

    **OBSERVE**: Analyze the tool results
    - What did I learn?
    - Is this information sufficient?
    - What should I do next?

    **REPEAT**: Continue the THINK-ACT-OBSERVE cycle for a MAXIMUM of 2-3 iterations total.
    - After 2 tool calls, strongly consider stopping and providing your final answer
    - Only use a 3rd iteration if absolutely critical information is still missing

    **FINAL ANSWER**: Provide a comprehensive answer that includes:
    - Direct answer to the question
    - Brief rationale explaining your reasoning
    - Citations and sources used
    - Confidence level in your answer

    Rules:
    - STOP EARLY: Provide your final answer as soon as you have sufficient information
    - Maximum 2-3 tool calls total - do not exceed this limit
    - Be concise in each step
    - Avoid redundant tool calls
    - Always cite sources when available
    - If uncertain, acknowledge limitations
    """

    task = Task(
        description=task_description,
        expected_output=(
            "A structured final answer containing: "
            "1) Direct answer to the question, "
            "2) Brief rationale and reasoning process, "
            "3) Sources and references used, "
            "4) Confidence assessment"
        ),
        agent=agent
    )

    return task

def run_react_query(question: str, agent_llm=None) -> str:
    """Run a complete ReAct query"""
    if agent_llm is None:
        agent_llm = llm

    print(f"Processing question: {question}")
    print("=" * 50)

    # Create agent and task
    agent = create_react_agent(agent_llm)
    task = create_react_task(question, agent)
    
    # Create and run crew
    # Note: memory=False disables CrewAI's built-in memory which may use OpenAI embeddings
    crew = Crew(
        agents=[agent],
        tasks=[task],
        process=Process.sequential,
        verbose=True,
        memory=False,
    )
    
    result = crew.kickoff()
    return result

# Example usage and test cases
if __name__ == "__main__":
    
    # Example 1: Mathematical reasoning
    print("Example 1: Mathematical Problem")
    print("-" * 30)
    math_question = "If a company's revenue grew from $1.2 million to $1.8 million, what was the percentage increase?"
    
    try:
        result1 = run_react_query(math_question)
        print(f"Result: {result1}\n")
    except Exception as e:
        print(f"Error: {e}\n")
    
    # Example 2: Research question
    print("Example 2: Research Question")
    print("-" * 30)
    research_question = "What are the current trends in renewable energy adoption globally?"
    
    try:
        result2 = run_react_query(research_question)
        print(f"Result: {result2}\n")
    except Exception as e:
        print(f"Error: {e}\n")
    
    # Example 3: Multi-step analysis
    print("Example 3: Multi-step Analysis")
    print("-" * 30)
    analysis_question = "Compare the market capitalization of the top 3 tech companies and calculate the average"
    
    try:
        result3 = run_react_query(analysis_question)
        print(f"Result: {result3}\n")
    except Exception as e:
        print(f"Error: {e}\n")

# Alternative: Interactive mode
def interactive_react_session():
    """Run an interactive ReAct session"""
    
    print("Welcome to Interactive ReAct Agent!")
    print("Ask any question and I'll use ReAct methodology to answer it.")
    print("Type 'quit' to exit.\n")
    
    while True:
        question = input("Your question: ").strip()
        
        if question.lower() in ['quit', 'exit', 'q']:
            print("Goodbye!")
            break
        
        if not question:
            continue
        
        try:
            result = run_react_query(question)
            print(f"\nAnswer: {result}\n")
            print("-" * 50)
        except Exception as e:
            print(f"Error: {e}\n")

# Usage examples for different scenarios
def demonstrate_use_cases():
    """Show various use cases for the ReAct agent
    
    NOTE: Multi-iteration loops (repeated THINK-ACT-OBSERVE cycles) occur when:
    - The agent needs to search for multiple pieces of information
    - Each tool call result informs the next step
    - The agent must reason about whether it has enough information
    
    Single-iteration: Questions answerable with one or two tool calls
    Multi-iteration: Questions requiring research + analysis + comparison + synthesis
    """
    
    use_cases = [
        {
            "category": "Financial Analysis",
            "questions": [
                # SINGLE-ITERATION: Basic math calculation, one Calculator tool call
                "Calculate the compound annual growth rate for an investment that grew from $10,000 to $15,000 over 3 years",
                # MULTI-ITERATION: Search Bitcoin price, search price history, analyze trends, synthesize answer
#                "What's the current price of Bitcoin and how has it changed in the last month?",
                # MULTI-ITERATION: Search Apple P/E, search Microsoft P/E, search Google P/E, compare all three
                "Compare the P/E ratios of Apple, Microsoft, and Google"
            ]
        },
        {
            "category": "Market Research", 
            "questions": [
                # MULTI-ITERATION: Search AI developments, search trends, search news, synthesize findings
 #               "What are the latest developments in artificial intelligence in 2024?",
                # MULTI-ITERATION: Search startup 1, startup 2, startup 3, startup 4, startup 5, then rank and compare
  #              "Find information about the top 5 fastest-growing startups in fintech",
                # MULTI-ITERATION: Search global EV trends, search statistics, search regional data, synthesize insights
                "What are the current trends in electric vehicle sales globally?"
            ]
        },
        {
            "category": "Scientific Inquiry",
            "questions": [
                # MULTI-ITERATION: Search climate research, search ocean data, search recent studies, synthesize findings
                "What's the latest research on climate change impacts on ocean temperatures?",
                # MULTI-ITERATION: Search quantum computing breakthrough, explain implications, research applications
#                "Explain the recent breakthrough in quantum computing and its implications",
                # MULTI-ITERATION: Search vaccine efficacy data, search side effects data, compare different vaccines
#                "What are the side effects and efficacy rates of the latest COVID-19 vaccines?"
            ]
        },
        {
            "category": "Business Intelligence",
            "questions": [
                # MULTI-ITERATION: Search competitors, search market data, analyze landscape, synthesize analysis
                "Analyze the competitive landscape in the cloud computing industry",
                # MULTI-ITERATION: Search success factors, search market data, search case studies, synthesize insights
                "What are the key success factors for SaaS companies in 2024?",
                # MULTI-ITERATION: Search Netflix model, search Disney+ model, search Prime model, compare all three
                "Compare the business models of Netflix, Disney+, and Amazon Prime"
            ]
        }
    ]
    
    print("ReAct Agent Use Cases")
    print("=" * 50)
    
    for use_case in use_cases:
        print(f"\n{use_case['category']}")
        print("-" * len(use_case['category']))
        for i, question in enumerate(use_case['questions'], 1):
            print(f"{i}. {question}")
    
    print(f"\nTo run any of these examples:")
    print(f"   result = run_react_query('your_question_here')")
    print(f"\nLegend:")
    print(f"   SINGLE-ITERATION: Minimal tool calls (basic computation)")
    print(f"   MULTI-ITERATION: Multiple tool calls, reasoning between steps (research + analysis)")

#demonstrate_use_cases()
# Uncomment for an interactive session
#interactive_react_session()