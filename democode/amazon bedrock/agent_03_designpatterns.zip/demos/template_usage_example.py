"""
Template Usage Example - Simple ReAct Agent

This script demonstrates how to use the crewai_gemini_template to create
a working agent with minimal boilerplate code.

Key Points:
1. Import just what you need from the template
2. The LLM is already configured and ready to use
3. Focus on your agent logic, not environment setup
4. Template handles all credential resolution

Before Running:
- Ensure AWS credentials are configured (via environment or ~/.aws/credentials)
- Optionally set BEDROCK_MODEL_ID and AWS_REGION in your .env file
"""

# ================================================================================
# IMPORTS - Minimal and clean
# ================================================================================

from crewai import Agent, Task, Crew, Process
from crewai_tools import FileReadTool
from crewai_gemini_template import llm, PROJECT_ROOT, create_agent, print_setup_info
from pydantic import BaseModel, Field
from typing import Type


# ================================================================================
# CUSTOM TOOLS - Example of adding domain-specific tools
# ================================================================================

from crewai.tools import BaseTool


class CalculatorInput(BaseModel):
    """Input schema for calculator tool"""
    expression: str = Field(..., description="Mathematical expression to evaluate")


class SimplCalculatorTool(BaseTool):
    """Simple calculator tool for mathematical operations"""
    name: str = "Calculator"
    description: str = "Performs mathematical calculations"
    args_schema: Type[BaseModel] = CalculatorInput

    def _run(self, expression: str) -> str:
        try:
            result = eval(expression)
            return f"Result: {result}"
        except Exception as e:
            return f"Error: {str(e)}"


# ================================================================================
# AGENTS - Using the template's create_agent or direct Agent instantiation
# ================================================================================

# Method 1: Using the factory function from template
researcher = create_agent(
    role="Research Assistant",
    goal="Answer questions by finding and analyzing information",
    backstory="Curious researcher who explores topics methodically"
)

# Method 2: Using Agent directly with template's llm
analyst = Agent(
    role="Data Analyst",
    goal="Provide insights from research findings",
    backstory="Analytical expert who draws conclusions from data",
    llm=llm,
    memory=True
)

# Add tools to researcher
researcher.tools = [FileReadTool(), SimplCalculatorTool()]


# ================================================================================
# TASKS - Define what agents should do
# ================================================================================

research_task = Task(
    description="Research the topic: 'What are the latest trends in artificial intelligence?'",
    expected_output="A comprehensive summary of AI trends with key points",
    agent=researcher
)

analysis_task = Task(
    description="Analyze the research findings and provide strategic insights",
    expected_output="Analysis with key takeaways and implications",
    agent=analyst
)


# ================================================================================
# CREW - Orchestrate agents and tasks
# ================================================================================

crew = Crew(
    agents=[researcher, analyst],
    tasks=[research_task, analysis_task],
    process=Process.sequential,
    verbose=True
)


# ================================================================================
# MAIN EXECUTION
# ================================================================================

def main():
    """Run the example"""
    print("\n" + "=" * 70)
    print("TEMPLATE USAGE EXAMPLE - Simple ReAct Agent")
    print("=" * 70)
    
    # Show setup information
    print_setup_info()
    
    # Run the crew
    print("Starting crew execution...\n")
    result = crew.kickoff()
    
    print("\n" + "=" * 70)
    print("RESULTS")
    print("=" * 70)
    print(result)
    print("=" * 70 + "\n")


if __name__ == "__main__":
    main()
