# Import required libraries
"""
Telco Customer Support with Memory & State Management

================================================================================
MEMORY & STATE MANAGEMENT PATTERN EXPLANATION:
================================================================================

MEMORY in AI Agents:
- Enables agents to remember past interactions and context
- Maintains continuity across multiple conversations
- Allows learning from previous experiences
- Critical for customer service where history matters

STATE MANAGEMENT:
- Tracks the current condition/status of entities (customers, processes)
- Maintains persistent information across sessions
- Enables context-aware decision making
- Allows for personalized responses based on history

Benefits:
- Consistent customer experience
- Avoids repetitive information gathering
- Enables escalation based on interaction history
- Supports continuous relationship building

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: CrewAI (Multi-agent orchestration)
  - Agent: Support agents with memory enabled
  - Task: Support tickets and escalation tasks
  - Crew: Orchestrates support workflow
  - Memory: Built-in CrewAI memory management
  - Embeddings: Google text-embedding-004 (via GEMINI_API_KEY)

LLM Model: Google Gemini 2.0 Flash
  - API Provider: Google Cloud Vertex AI / Google AI
  - Model ID: gemini/gemini-2.0-flash
  - Temperature: 0.7

Environment Configuration:
  - Uses .env file for API keys (GEMINI_API_KEY)
  - Automatic credential path resolution for Google Cloud authentication
================================================================================
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, LLM

# Load environment variables
def _find_project_root() -> Path:
    """Find project root by looking for .env file."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

# Load environment variables first
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Amazon Bedrock LLM configuration via LiteLLM
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "amazon.nova-micro-v1:0")
os.environ.setdefault("AWS_REGION_NAME", AWS_REGION)

llm = LLM(
    model=f"bedrock/{MODEL_ID}",
    temperature=0.7
)
print(f"Using Bedrock model: bedrock/{MODEL_ID}")

# ===============================
# MEMORY SETUP
# ===============================

# CrewAI provides built-in memory capabilities
# Agents with memory=True automatically maintain context across interactions

# ===============================
# STATE MANAGEMENT CLASS
# ===============================

# Custom class to track customer state across interactions
class CustomerState:
    """
    Persistent state object that tracks customer information
    This simulates a CRM system or customer database
    """
    def __init__(self):
        self.customer_id = None          # Unique customer identifier
        self.issue_history = []          # List of past problems
        self.resolution_attempts = []    # Previous solution attempts
        self.satisfaction_score = None   # Customer satisfaction rating
        # In real systems, this would be stored in a database

# ===============================
# MEMORY-ENABLED AGENTS
# ===============================

# AGENT 1: Customer Support with Memory
support_agent = Agent(
    role='Customer Support Specialist',
    goal='Handle customer inquiries with context awareness',
    backstory='Experienced support agent with access to customer history',
    memory=True,  # CRITICAL: Enables memory across interactions
    verbose=True,
    llm=llm,
    # This agent will remember all customer interactions
)

# AGENT 2: Technical Support with Memory
technical_agent = Agent(
    role='Technical Support',
    goal='Resolve technical issues using past solutions',
    backstory='Network engineer with memory of past fixes',
    memory=True,  # Remembers which solutions worked before
    verbose=True,
    llm=llm,
)

# AGENT 3: Escalation Manager with Memory
escalation_manager = Agent(
    role='Escalation Manager',
    goal='Handle complex cases with full context',
    backstory='Senior manager tracking customer journey',
    memory=True,  # Has access to complete customer history
    verbose=True,
    llm=llm,
)

# ===============================
# STATE-AWARE TASKS
# ===============================

# TASK 1: Context Gathering (uses memory and state)
context_gathering = Task(
    description='Gather customer history and current issue context',
    agent=support_agent,
    expected_output='Customer context summary',
    # This task will access memory to understand customer history
)

# TASK 2: Technical Resolution (informed by past attempts)
technical_resolution = Task(
    description='Apply technical solution considering past attempts',
    agent=technical_agent,
    expected_output='Technical resolution plan',
    context=[context_gathering],  # Uses customer context
    # Agent will remember what solutions were tried before
)

# TASK 3: Escalation Decision (based on complete history)
escalation_check = Task(
    description='Determine if escalation needed based on history',
    agent=escalation_manager,
    expected_output='Escalation decision with reasoning',
    context=[context_gathering, technical_resolution],  # Full context
    # Decision considers: issue complexity, customer history, past failures
)

# ===============================
# MEMORY-ENABLED CREW
# ===============================

# Crew with persistent memory across all agents
# Configure Gemini embeddings for memory (instead of default OpenAI)
crew = Crew(
    agents=[support_agent, technical_agent, escalation_manager],
    tasks=[context_gathering, technical_resolution, escalation_check],
    memory=True,  # CRITICAL: Enables shared memory across all agents
    verbose=True,
    embedder={
        "provider": "aws_bedrock",
        "config": {"model": "amazon.titan-embed-text-v2:0"}
    }
)

# ===============================
# STATE INITIALIZATION
# ===============================

# Initialize customer state with historical data
# In real systems, this would be loaded from a database
state = CustomerState()
state.customer_id = "CUST12345"
state.issue_history = [
    "Network outage",      # Previous issue 1
    "Slow internet",       # Previous issue 2  
    "Router reset"         # Previous issue 3
]
# This history informs current decision-making

# ===============================
# EXECUTION WITH STATE
# ===============================

result = crew.kickoff(inputs={
    'customer_issue': 'Internet connection drops frequently',
    'customer_state': state.__dict__  # Pass customer state to agents
})

"""
MEMORY & STATE EXECUTION FLOW:

PHASE 1 - CONTEXT AWARENESS:
1. Support agent accesses customer memory and state
2. Reviews past issues: "Network outage", "Slow internet", "Router reset"
3. Recognizes pattern: recurring connectivity problems
4. Understands this is a frustrated repeat customer

PHASE 2 - INFORMED TECHNICAL RESOLUTION:
5. Technical agent considers past resolution attempts
6. Avoids previously tried solutions (router reset already attempted)
7. Applies advanced troubleshooting based on pattern recognition
8. Proposes solution considering customer's technical history

PHASE 3 - ESCALATION DECISION:
9. Manager reviews complete customer journey
10. Notes recurring connectivity issues despite previous attempts
11. Considers customer satisfaction impact
12. Makes escalation decision based on full context

MEMORY BENEFITS:
- No need to re-explain problems (agent remembers)
- Solutions build on previous attempts
- Escalation decisions consider full relationship
- Personalized service based on customer history
- Continuous learning from past interactions

STATE BENEFITS:
- Persistent customer information across sessions
- Context-aware decision making
- Ability to track customer journey over time
- Support for complex, multi-session issue resolution
"""