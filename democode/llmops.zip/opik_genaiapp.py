# ====================================
# WHAT IS ÖPIK?
#
# Öpik is a powerful logging and observability tool built for tracking 
# and evaluating LLM (Language Model) workflows and other AI-powered 
# applications. It is designed to:
#
# 1. Track function calls with the `@track` decorator
#    - This means it logs inputs, outputs, execution time, and more for each tracked function.
# 2. Evaluate the quality of model outputs using built-in LLM scoring.
#    - You can automatically score responses based on helpfulness, accuracy, and other criteria.
# 3. Visualize the performance, usage, and errors in an interactive dashboard.
#    - This allows you to monitor how your models behave, detect issues, and optimize performance.
#
# By integrating Öpik into your code (as shown below), you get:
# - Real-time logging of all important function calls.
# - Automatic trace tracking without additional effort.
#
# To use Öpik, you need an API Key and a Workspace. These can be obtained
# from the Öpik dashboard by signing up/logging in at https://www.opik.ai.
#
# Read below for how to get your Öpik API Key and Workspace:
# 
# 1. Sign up or log in to Öpik (https://www.opik.ai).
# 2. In the top-right corner, click on **Profile → API Keys** and copy your key.
# 3. On the dashboard, your **Workspace name** will be visible in the top-left corner.
#    - Example: "riyabangera999".
#
# These details are required to set up your environment and track logs.
# ====================================

# ====================================
# STEP 1: Import necessary libraries
# ====================================
import os
from dotenv import load_dotenv
import streamlit as st

# LangChain Azure SDK for OpenAI
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage
from langchain_community.callbacks import get_openai_callback

# Öpik tracking decorator
from opik import track

# ====================================
# STEP 2: Set up Öpik API Key and Workspace
#
# 👉 HOW TO GET YOUR API KEY:
# 1. Go to https://www.opik.ai
# 2. Log in or sign up with email / GitHub / Google
# 3. On the top right, click your profile icon → "API Keys"
# 4. Copy your API key
#
# 👉 HOW TO GET YOUR WORKSPACE NAME:
# 1. It's shown in the top-left corner of your Öpik dashboard
# 2. Example: "riyabangera999"
#
# You can paste your values directly here or use a .env file
# ====================================
os.environ["OPIK_API_KEY"] = "naSAFwigwZoE385sYMH0hjW6p"  # Replace with your actual Öpik API Key
os.environ["OPIK_WORKSPACE"] = "riyabangera999"          # Replace with your actual workspace name

# ====================================
# STEP 3: Load Azure OpenAI config from .env
# Your .env file should include:
# - AZURE_OPENAI_ENDPOINT
# - AZURE_OPENAI_MODEL_DEPLOYMENT_NAME
# - AZURE_OPENAI_API_KEY
# - AZURE_OPENAI_API_VERSION
# ====================================
load_dotenv()

azure_config = {
    "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "AZURE_OPENAI_MODEL_DEPLOYMENT_NAME": os.getenv("AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"),
    "AZURE_OPENAI_MODEL_NAME": os.getenv("AZURE_OPENAI_MODEL_NAME"),  # optional
    "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
    "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION")
}

# ====================================
# STEP 4: Streamlit UI Header
# ====================================
st.subheader("EY GenAI class: GenAI chatbot Demo")

# (Optional) Assign endpoint visibly in sidebar for debugging
with st.sidebar:
    os.environ["AZURE_OPENAI_ENDPOINT"] = azure_config["AZURE_OPENAI_ENDPOINT"]

# ====================================
# STEP 5: Azure OpenAI LLM Call
# This function is decorated with @track from Öpik
# All inputs, outputs, and performance are automatically logged
# ====================================
@track
def generate_response(input_text):
    # Initialize Azure OpenAI client using LangChain wrapper
    llm = AzureChatOpenAI(
        temperature=0,
        api_key=azure_config["AZURE_OPENAI_API_KEY"],
        openai_api_version=azure_config["AZURE_OPENAI_API_VERSION"],
        azure_endpoint=azure_config["AZURE_OPENAI_ENDPOINT"],
        model=azure_config["AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"],
        validate_base_url=False
    )

    # Wrap user input in LangChain message format
    message = HumanMessage(content=input_text)

    # Callback will capture token usage and cost for display
    with get_openai_callback() as cb:
        response = llm([message]).content

        # Streamlit UI updates
        st.info("**Response:**")
        st.success(response)

        st.info("**Callback Info (usage/cost):**")
        st.code(cb)

    return response  # This return is also logged by Öpik

# ====================================
# STEP 6: User interaction in Streamlit
# Captures input and triggers OpenAI call
# Everything is auto-tracked by Öpik due to @track
# ====================================
user_question = st.text_input("Ask any question. Press enter to submit", key="user_question")

if user_question:
    generate_response(user_question)
