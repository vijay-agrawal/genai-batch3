# ICD Code Lookup MCP Server - Setup Guide

## Prerequisites
- Python 3.10 or higher
- VS Code with Claude Dev or Cline extension
- pip (Python package manager)

## Step 1: Install Dependencies

```bash
# Create a virtual environment (recommended)
python -m venv mcp-env
source mcp-env/bin/activate  # On Windows: mcp-env\Scripts\activate

# Install FastMCP
pip install fastmcp
```

## Step 2: Test the Server Locally

```bash
# Run the server to verify it works
python icdlookup_mcpserver.py
```

You should see output indicating the server is running.

## Step 3: Configure VS Code MCP Settings

### For Claude Dev Extension:

1. Open VS Code
2. Press `Cmd+Shift+P` (Mac) or `Ctrl+Shift+P` (Windows/Linux)
3. Type "Preferences: Open User Settings (JSON)"
4. Add the MCP server configuration:

```json
{
  "mcpServers": {
    "icd-lookup": {
      "command": "python",
      "args": ["/absolute/path/to/icdlookup_mcpserver.py"],
      "env": {}
    }
  }
}
```

### For Cline Extension:

1. Open VS Code Settings
2. Search for "Cline MCP"
3. Click "Edit in settings.json"
4. Add this configuration:

```json
{
  "cline.mcpServers": {
    "icd-lookup": {
      "command": "python",
      "args": ["/absolute/path/to/icdlookup_mcpserver.py"]
    }
  }
}
```

**Important**: Replace `/absolute/path/to/icdlookup_mcpserver.py` with the actual full path to your file.

## Step 4: Restart VS Code

Close and reopen VS Code to load the MCP server.

## Step 7: Verify the Tools are Available

### In Claude Dev:
1. Open Claude Dev panel
2. Start a new chat
3. Look for available tools - you should see:
   - `lookup_icd_code`
   - `list_available_conditions`

### In Cline:
1. Open Cline panel
2. The tools should appear in the tools list
3. You can reference them in your prompts

## Step 7: Test the Tools

Try these example prompts in your AI assistant:

```
"Use the lookup_icd_code tool to find the ICD code for diabetes"

"What ICD code should I use for high blood pressure?"

"Show me all available conditions using list_available_conditions"

"Look up the ICD code for migraine headache"
```

## Demonstration Example

**Prompt**: "I need to find ICD codes for these conditions: diabetes, asthma, and chest pain"

**Expected Behavior**:
1. The AI will automatically detect the `lookup_icd_code` tool
2. It will call the tool three times (once for each condition)
3. You'll see the tool being invoked in the UI
4. Results will be displayed:
   - Diabetes: E11.9
   - Asthma: J45.909
   - Chest pain: R07.9

## Troubleshooting

### Server not appearing in VS Code:
- Verify the path in settings.json is absolute and correct
- Check that Python is in your PATH
- Try using the full Python path: `/usr/bin/python3` or `C:\Python310\python.exe`
- Restart VS Code after configuration changes

### "Module not found" error:
- Activate your virtual environment first
- Or use the full path to Python in the virtual environment:
  ```json
  "command": "/path/to/mcp-env/bin/python"
  ```

### Tools not visible:
- Check VS Code Developer Console (Help → Toggle Developer Tools) for errors
- Verify FastMCP is installed: `pip show fastmcp`
- Check MCP server logs in the extension output panel

## How It Works

1. **FastMCP** creates an MCP-compliant server from Python functions
2. The `@mcp.tool()` decorator exposes functions as MCP tools
3. VS Code extensions (Claude Dev/Cline) connect to the server via stdio
4. The AI can see tool descriptions and invoke them automatically
5. Results are returned to the AI and incorporated into responses

## Extending the Demo

Add more tools by decorating functions:

```python
@mcp.tool()
def search_icd_by_code(code: str) -> str:
    """Search for condition description by ICD code"""
    # Your implementation here
    pass
```

The tool will automatically appear in VS Code after restarting!
