"""
ICD Code Lookup MCP Server using FastMCP
A minimal demo showing how to create and use MCP tools in VS Code
"""

from fastmcp import FastMCP
import re

# Initialize FastMCP server
mcp = FastMCP("ICD Code Lookup")

# Mock ICD-10 code database for demo purposes
ICD_DATABASE = {
    "diabetes": "E11.9 - Type 2 diabetes mellitus without complications",
    "type 1 diabetes": "E10.9 - Type 1 diabetes mellitus without complications",
    "type 2 diabetes": "E11.9 - Type 2 diabetes mellitus without complications",
    "hypertension": "I10 - Essential (primary) hypertension",
    "high blood pressure": "I10 - Essential (primary) hypertension",
    "pneumonia": "J18.9 - Pneumonia, unspecified organism",
    "asthma": "J45.909 - Unspecified asthma, uncomplicated",
    "copd": "J44.9 - Chronic obstructive pulmonary disease, unspecified",
    "bronchitis": "J40 - Bronchitis, not specified as acute or chronic",
    "migraine": "G43.909 - Migraine, unspecified, not intractable, without status migrainosus",
    "headache": "R51.9 - Headache, unspecified",
    "depression": "F32.9 - Major depressive disorder, single episode, unspecified",
    "anxiety": "F41.9 - Anxiety disorder, unspecified",
    "covid": "U07.1 - COVID-19",
    "coronavirus": "U07.1 - COVID-19",
    "influenza": "J11.1 - Influenza due to unidentified influenza virus with other respiratory manifestations",
    "flu": "J11.1 - Influenza due to unidentified influenza virus with other respiratory manifestations",
    "chest pain": "R07.9 - Chest pain, unspecified",
    "abdominal pain": "R10.9 - Unspecified abdominal pain",
    "back pain": "M54.9 - Dorsalgia, unspecified",
    "fracture": "S42.90 - Fracture of unspecified shoulder girdle, part unspecified",
    "sprain": "S93.40 - Sprain of unspecified ligament of ankle",
}


@mcp.tool()
def lookup_icd_code(description: str) -> str:
    """
    Look up ICD-10 code based on medical condition description.
    
    Args:
        description: Description of the medical condition (e.g., "diabetes", "high blood pressure")
    
    Returns:
        ICD-10 code and description, or a message if not found
    """
    # Convert to lowercase for case-insensitive matching
    description_lower = description.lower().strip()
    
    # Direct match
    if description_lower in ICD_DATABASE:
        return ICD_DATABASE[description_lower]
    
    # Partial match using regex
    for key, value in ICD_DATABASE.items():
        if re.search(r'\b' + re.escape(key) + r'\b', description_lower):
            return value
    
    # If no match found, return available options
    available = ", ".join(sorted(ICD_DATABASE.keys()))
    return f"No ICD code found for '{description}'. Available conditions: {available}"


@mcp.tool()
def list_available_conditions() -> str:
    """
    List all available medical conditions in the database.
    
    Returns:
        Comma-separated list of available conditions
    """
    conditions = sorted(ICD_DATABASE.keys())
    return f"Available conditions ({len(conditions)}): " + ", ".join(conditions)


if __name__ == "__main__":
    # Run the MCP server
    mcp.run()