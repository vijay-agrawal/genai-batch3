from crewai import Agent, Task, Crew, Process
from crewai_tools import SerpApiTool  # or your own tools

search = SerpApiTool()  # example tool
calculator = ...        # any callable tool

react_agent = Agent(
    role="Researcher",
    goal="Answer the user question accurately by iteratively using tools.",
    backstory="Curious, careful, cites sources.",
    tools=[search, calculator],
    allow_delegation=False,
    model="gpt-4o-mini"
)

react_task = Task(
    agent=react_agent,
    description=(
        "Follow a ReAct loop:\n"
        "1) THINK: reason about what to do next.\n"
        "2) ACT: call exactly one tool if needed with minimal parameters.\n"
        "3) OBSERVE: read the tool result.\n"
        "Repeat THINK–ACT–OBSERVE until confident.\n"
        "Then produce the FINAL ANSWER with a short rationale and references.\n"
        "Rules: be concise, avoid unnecessary tool calls, stop when confident."
    ),
    expected_output="Final answer text with brief rationale and any references."
)

crew = Crew(agents=[react_agent], tasks=[react_task], process=Process.sequential)
print(crew.kickoff())
