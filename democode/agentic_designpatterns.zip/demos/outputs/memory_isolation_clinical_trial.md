## CARDIOPROTECT-HF Phase III Trial � Status Report (Week 24)

**Sponsor:** CardioPharm Inc.
**ClinicalTrials.gov:** NCT-EXAMPLE-2024

**OPERATIONAL STATUS:**

*   ENROLLMENT: 480/480 (100% target met)
*   ACTIVE SITES: 28 sites across 6 countries
*   CURRENT PHASE: Week 24 primary endpoint analysis
*   DATABASE LOCK: Completed 2 weeks ago
*   NEXT MILESTONE: Interim analysis presentation to DSMB
*   REGULATORY: FDA pre-NDA meeting scheduled in 3 months

### 1. EXECUTIVE SUMMARY

*   Efficacy analysis shows statistically significant and clinically meaningful improvement in the primary endpoint (6MWD) and secondary endpoints (NT-proBNP, NYHA class, HF hospitalization rate) favoring Arm A.
*   Safety review identifies several concerning signals, including hypotension, renal function decline, hepatic enzyme elevation, and a fatal MI.
*   Safety monitor recommends pausing enrollment pending further investigation of safety signals.
*   DSMB review is critical to assess the benefit-risk profile and determine the next steps for the trial.
*   Sponsor decisions are needed regarding the safety monitor's recommendations and further investigation of safety signals.

### 2. EFFICACY HIGHLIGHTS (from Biostatistician's Summary)

*   The primary endpoint, change in 6-Minute Walk Distance (6MWD) from baseline, demonstrated a highly statistically significant difference between the two arms (p < 0.001). Arm A showed a mean improvement of +58m (95% CI [54, 62]) compared to Arm B's +21m (95% CI [17, 25]). The between-group difference was 37m.
*   A statistically significant difference (p < 0.001) was observed in NT-proBNP reduction between the arms. Arm A exhibited a -42% median reduction, while Arm B showed a -14% median reduction.
*   A statistically significant difference (p < 0.001) was observed in NYHA class improvement. In Arm A, 64% of patients improved by at least one NYHA class, compared to 31% in Arm B.
*   The heart failure hospitalization rate at 24 weeks was significantly lower in Arm A (8.3%) compared to Arm B (16.7%), with a hazard ratio (HR) of 0.47 (p = 0.006).
*   Subgroup analysis suggests a potential for enhanced benefit in patients with lower baseline LVEF (<30%).

### 3. SAFETY HIGHLIGHTS (from Safety Monitor's Summary)

*   Hypotension: The 18.5% overall rate is concerning.
*   Renal Function Decline: A 7.3% rate of >30% eGFR drop warrants close monitoring.
*   Hyperkalemia: The 5.4% rate of K+ >5.5 is a known risk in heart failure trials.
*   Hepatic Enzyme Elevation: The 3.1% rate requires further investigation.
*   Fatal MI: A fatal MI requires immediate adjudication committee review.
*   Deaths: Three deaths (MI, stroke, non-cardiac) require careful review.
*   Dropouts: The 7.9% dropout rate, especially the 22 due to adverse events, is significant.

### 4. KEY RISKS AND CONCERNS

*   **Safety Signals:** The identified safety signals, particularly hypotension, renal function decline, hepatic enzyme elevation, and the fatal MI, pose significant risks to patient safety.
*   **Unknown Treatment Arm Assignment:** The inability to assess the true risk-benefit profile due to blinded treatment arms is a major concern.
*   **Dropout Rate:** The high dropout rate due to adverse events raises concerns about tolerability and potential underestimation of safety risks.
*   **Diabetes Subgroup:** The biostatistician noted a slightly attenuated treatment effect in the diabetes subgroup (interaction p = 0.08), which warrants further investigation.
*   **DSMB Recommendation:** The DSMB's assessment of the risk-benefit profile is critical and could significantly impact the future of the trial.

### 5. RECOMMENDED NEXT STEPS for the Sponsor

*   **Implement the Safety Monitor's Recommendations:** Immediately enact the urgent actions recommended by the safety monitor, including requesting a per-arm breakdown of adverse events, expediting the adjudication committee review of the fatal MI, obtaining detailed reports on all deaths, reviewing the dose-adjustment protocol for hypotension, reviewing the criteria for eGFR decline and hepatic enzyme elevation, and requesting a summary of concomitant medications.
*   **Expedite DSMB Review:** Prioritize the DSMB meeting and provide them with all necessary information to make an informed decision.
*   **Prepare for Potential Enrollment Pause:** Prepare for a potential enrollment pause and develop a communication plan for sites and patients.
*   **Investigate Diabetes Subgroup:** Plan for further investigation of the diabetes subgroup in future studies or pooled analyses to understand the attenuated treatment effect.
*   **LVEF < 30% Subgroup:** The interaction p-value of 0.03 indicates a statistically significant interaction for LVEF < 30%. This finding should be confirmed in future studies, but is strongly suggestive of a differential treatment effect.

### 6. ITEMS REQUIRING SPONSOR DECISION

*   **Enrollment Pause:** Decision on whether to pause enrollment based on the safety monitor's recommendation and the DSMB's input.
*   **Resource Allocation:** Approval of resources for the urgent actions recommended by the safety monitor, including statistical analysis, adjudication committee review, and data collection.
*   **Communication Strategy:** Development and approval of a communication strategy for sites, patients, and regulatory agencies regarding the safety concerns and potential enrollment pause.
*   **Future Study Design:** Decisions on how to address the attenuated treatment effect observed in the diabetes subgroup in future studies.
*   **Contingency Planning:** Develop contingency plans based on the potential outcomes of the DSMB review, including trial continuation, modification, or termination.
