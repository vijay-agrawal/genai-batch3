"""
Healthcare Collaboration + Reflexion Pattern with Memory

================================================================================
COLLABORATION PATTERN:
================================================================================
- Multiple specialist agents work together as peers (no hierarchy)
- Each agent contributes their expertise to a shared goal
- Agents can build upon each other's work through task context
- Information flows horizontally between agents

Examples:
- Radiologist → Pathologist → Clinician (sequential expertise)
- Each brings specialized knowledge to a shared patient case
- Results combine into comprehensive assessment

================================================================================
REFLEXION PATTERN:
================================================================================
- A dedicated reviewer agent critically examines prior outputs
- Implements self-correction and quality assurance
- Forces the system to reconsider and improve initial outputs
- Mimics peer review process in professional settings

In this demo:
- Specialists collaborate on patient assessment
- Quality reviewer (Reflexion) checks all specialist outputs
- Clinician refines diagnosis based on reviewer feedback

================================================================================
NOTE ON CRITIQUE vs REFLEXION PATTERNS:
================================================================================
The Critique pattern and the Reflexion pattern are closely related but not
identical:

  CRITIQUE PATTERN (as in demo 03):
  - Author creates → Critic reviews → Revised output
  - Focuses on a SINGLE author-critic loop
  - The critic provides feedback; the author (or critic) revises
  - Typically one round of review

  REFLEXION PATTERN:
  - Agent acts → Evaluator reflects → Agent revises with self-awareness
  - Emphasizes SELF-REFLECTION: the original agent internalizes feedback
  - Can involve multiple rounds of reflect-and-revise
  - The agent "learns" from its mistakes within the session

In practice, both patterns use a feedback loop. The key difference is that
Reflexion emphasizes the original agent revising its OWN work after receiving
feedback (self-correction), while Critique can have the critic produce the
final output. In this demo, the clinician (original agent) revises their own
diagnosis after receiving reviewer feedback — making it a Reflexion pattern.

================================================================================
MEMORY IN CREWAI:
================================================================================
CrewAI supports agent memory through:
- Task context passing (previous task outputs become input to next)
- Agent memory settings (stores interaction history within the session)
- Enhanced with embeddings for semantic search (optional, requires OpenAI key)

This enables:
- Patient history tracking across tasks
- Building on previous analyses
- Maintaining continuity across interactions

NOTE: In this demo we use task context (the `context` parameter) for memory
rather than CrewAI's embedding-based memory, to avoid requiring an OpenAI key.

================================================================================
DEMO DESCRIPTION - What This Script Does:
================================================================================
1. Creates three specialist agents: Radiologist, Pathologist, Clinician
2. Creates a Reflexion reviewer agent (senior physician)
3. Specialists analyze a realistic patient case collaboratively
4. Reviewer critically examines all findings (Reflexion step)
5. Clinician revises their diagnosis based on reviewer feedback
6. Demonstrates collaboration + reflexion + memory (context) in one workflow

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: CrewAI (Multi-agent orchestration)
  - Agent: Specialist agents with collaboration capabilities
  - Task: Sequential tasks building on each other via context
  - Crew: Orchestrates collaborative specialists + reflexion reviewer
  - Process: Sequential (task outputs flow to downstream tasks)

LLM Model: Google Gemini 2.0 Flash
  - API Provider: Google Cloud Vertex AI / Google AI
  - Model ID: gemini/gemini-2.0-flash
  - Temperature: 0.7

Environment Configuration:
  - Uses .env file for API keys (GEMINI_API_KEY)
  - Automatic credential path resolution for Google Cloud authentication
================================================================================
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
from textwrap import dedent
import warnings

warnings.filterwarnings('ignore')

# ---------------------------------------------------------------------------
# Environment setup 
# ---------------------------------------------------------------------------

def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

# Load environment variables first
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Resolve relative credential paths to absolute
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

# Gemini LLM configuration using CrewAI's LLM class
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    print("ERROR: GEMINI_API_KEY not found in environment variables.")
    print("Please add GEMINI_API_KEY to your .env file.")
    exit(1)

llm = LLM(
    model="gemini/gemini-2.0-flash",
    api_key=GEMINI_API_KEY,
    temperature=0.7
)
print(f"Using Gemini model: gemini/gemini-2.0-flash")

# ---------------------------------------------------------------------------
# Realistic patient case data (embedded so the demo is self-contained)
# ---------------------------------------------------------------------------

PATIENT_CASE = dedent("""\
    Patient: Maria Santos, 58-year-old female
    Chief Complaint: Progressive shortness of breath over 3 weeks, worsening with exertion

    History of Present Illness:
    - Gradual onset dyspnea, now occurring at rest
    - Productive cough with white sputum for 2 weeks
    - Mild bilateral ankle swelling noticed 1 week ago
    - Orthopnea (needs 3 pillows to sleep)
    - 5 lb weight gain over 2 weeks
    - Denies chest pain, fever, or hemoptysis

    Past Medical History:
    - Hypertension (10 years, on lisinopril 20 mg daily)
    - Type 2 diabetes (5 years, on metformin 1000 mg BID)
    - Hyperlipidemia (on atorvastatin 40 mg daily)
    - Former smoker (quit 3 years ago, 20 pack-year history)

    Vitals: BP 158/95, HR 102, RR 24, SpO2 91% on room air, Temp 37.1C

    Chest X-Ray Findings:
    - Bilateral pleural effusions (small to moderate)
    - Cardiomegaly with cardiothoracic ratio 0.62
    - Upper lobe pulmonary venous distension (cephalization)
    - Kerley B lines in lower zones
    - No consolidation or mass lesions

    Laboratory Results:
    - BNP: 1,250 pg/mL (normal <100)
    - Troponin I: 0.04 ng/mL (normal <0.04) — borderline
    - Creatinine: 1.4 mg/dL (baseline 1.0)
    - eGFR: 48 mL/min (reduced)
    - HbA1c: 8.2% (suboptimal control)
    - Hemoglobin: 10.8 g/dL (mild anemia)
    - Sodium: 132 mEq/L (mild hyponatremia)
    - Potassium: 5.1 mEq/L (mildly elevated)
    - TSH: 2.4 mIU/L (normal)
    - Albumin: 3.1 g/dL (low)

    ECG: Sinus tachycardia, left ventricular hypertrophy, no ST changes
""")

# ===============================
# COLLABORATIVE SPECIALIST AGENTS
# ===============================

# SPECIALIST AGENT 1 — Radiology expert
radiologist = Agent(
    role="Radiologist",
    goal="Analyze the chest X-ray and ECG findings, identify abnormalities, and provide a structured imaging interpretation.",
    backstory=dedent("""\
        You are a board-certified radiologist with 15 years of experience in
        cardiothoracic imaging. You are methodical and always correlate imaging
        findings with clinical context. You report findings systematically:
        heart, lungs, pleura, mediastinum."""),
    llm=llm,
)

# SPECIALIST AGENT 2 — Laboratory / Pathology expert
pathologist = Agent(
    role="Pathologist",
    goal="Interpret all laboratory results, flag critical values, and identify patterns suggesting specific diagnoses.",
    backstory=dedent("""\
        You are a clinical pathologist specializing in laboratory medicine.
        You excel at correlating lab panels to identify multi-organ involvement.
        You always flag critical values and explain their clinical significance."""),
    llm=llm,
)

# SPECIALIST AGENT 3 — Clinician who integrates findings
clinician = Agent(
    role="Attending Physician",
    goal="Integrate imaging and lab findings into a coherent differential diagnosis, propose a primary diagnosis, and recommend a treatment plan.",
    backstory=dedent("""\
        You are an experienced internal medicine attending with 20 years of
        clinical practice. You are known for thorough differential diagnoses
        and evidence-based treatment plans. You always consider patient safety,
        drug interactions, and comorbidities."""),
    llm=llm,
)

# ===============================
# REFLEXION AGENT (Quality assurance)
# ===============================

# REFLEXION AGENT — Reviews and challenges decisions
reviewer = Agent(
    role="Medical Quality Reviewer",
    goal="Critically review the initial diagnosis and treatment plan for safety issues, logical gaps, missed diagnoses, and medication concerns.",
    backstory=dedent("""\
        You are a senior physician and chief of quality assurance. You have
        caught life-threatening medication errors and missed diagnoses in your
        career. You review every case with a checklist: Are all lab abnormalities
        addressed? Are medications safe given the patient's renal function?
        Are there alternative diagnoses being overlooked? You are thorough but
        constructive."""),
    llm=llm,
    verbose=True
)

# ===============================
# COLLABORATIVE TASKS
# ===============================

# TASK 1 — Imaging interpretation (independent)
image_analysis = Task(
    description=dedent(f"""\
        Analyze the following imaging and ECG findings for this patient.
        Provide a structured radiology report covering:
        1. Heart size and configuration
        2. Lung fields and pleural spaces
        3. Vascular markings
        4. ECG correlation
        5. Impression and differential considerations

        PATIENT DATA:
        {PATIENT_CASE}
    """),
    agent=radiologist,
    expected_output=dedent("""\
        A structured radiology report with sections for cardiac findings,
        pulmonary findings, pleural findings, and an overall impression
        with differential considerations.""")
)

# TASK 2 — Laboratory interpretation (independent)
lab_analysis = Task(
    description=dedent(f"""\
        Interpret all laboratory results for this patient. For each abnormal
        value, explain clinical significance. Specifically address:
        1. Cardiac biomarkers (BNP, troponin) — what do they indicate?
        2. Renal function (creatinine, eGFR, potassium) — implications?
        3. Metabolic status (HbA1c, sodium, albumin) — concerns?
        4. Hematology (hemoglobin) — relevance to presentation?
        5. Overall lab pattern — what diagnosis do these labs collectively support?

        PATIENT DATA:
        {PATIENT_CASE}
    """),
    agent=pathologist,
    expected_output=dedent("""\
        A structured lab interpretation report with each abnormal value
        explained, critical values flagged, and an overall pattern analysis
        pointing toward a likely diagnosis.""")
)

# TASK 3 — Clinical integration (builds on imaging + lab via context)
initial_diagnosis = Task(
    description=dedent(f"""\
        Using the radiology report and laboratory analysis from your colleagues,
        along with the patient's history, create:
        1. A ranked differential diagnosis (at least 3 possibilities)
        2. Your primary working diagnosis with supporting evidence
        3. An initial treatment plan including:
           - Immediate interventions
           - Medication changes (consider current medications and renal function)
           - Monitoring plan
        4. Additional tests or consultations you would order

        PATIENT DATA:
        {PATIENT_CASE}
    """),
    agent=clinician,
    expected_output=dedent("""\
        A clinical assessment with ranked differential diagnosis, primary
        working diagnosis with evidence, detailed treatment plan, and
        recommended additional workup."""),
    # MEMORY/CONTEXT: This task receives outputs from prior tasks
    context=[image_analysis, lab_analysis]
)

# ===============================
# REFLEXION TASKS (Self-correction)
# ===============================

# REFLEXION TASK 1 — Critical review of all prior work
diagnosis_review = Task(
    description=dedent("""\
        Critically review ALL prior specialist analyses and the initial
        diagnosis/treatment plan. Check against this quality rubric:

        SAFETY CHECKLIST:
        1. MEDICATIONS: Are doses safe for renal function (eGFR 48)?
           - Is metformin safe at this eGFR? (check guidelines)
           - Is potassium being monitored if starting/continuing ACE inhibitor?
           - Any drug interactions or contraindications?
        2. MISSED DIAGNOSES: Are there alternative explanations being overlooked?
           - Could this be a new cardiomyopathy vs. acute decompensation?
           - Is the borderline troponin adequately addressed?
           - Is the anemia worked up (iron studies, reticulocytes)?
        3. LAB GAPS: Are all abnormal values addressed in the treatment plan?
           - Hyponatremia management?
           - Hyperkalemia risk with ACE inhibitor + renal dysfunction?
           - Suboptimal diabetes control plan?
        4. FOLLOW-UP: Are discharge criteria and follow-up plans adequate?

        Provide:
        - A numbered list of specific issues found
        - Risk severity for each issue (HIGH / MEDIUM / LOW)
        - Specific recommendations to address each issue
    """),
    agent=reviewer,
    expected_output=dedent("""\
        A structured quality review with numbered issues, severity ratings,
        and specific actionable recommendations for each finding."""),
    # Context gives reviewer access to ALL prior task outputs
    context=[image_analysis, lab_analysis, initial_diagnosis]
)

# REFLEXION TASK 2 — Clinician revises their own work based on feedback
# (This is what makes it Reflexion: the ORIGINAL agent self-corrects)
final_diagnosis = Task(
    description=dedent("""\
        You previously created an initial diagnosis and treatment plan.
        The Medical Quality Reviewer has now provided critical feedback.

        REVISE your assessment by:
        1. Addressing EVERY issue raised by the reviewer
        2. Updating your differential diagnosis if needed
        3. Correcting any medication safety concerns
        4. Adding any missing workup or monitoring
        5. Creating a FINAL comprehensive assessment with:
           - Primary diagnosis with confidence level
           - Complete medication list with doses (adjusted for renal function)
           - Monitoring plan (labs, vitals, daily weights)
           - Clear discharge criteria
           - Follow-up schedule
           - Patient education points (plain language)

        Explicitly state what you changed from your initial plan and why.
    """),
    agent=clinician,  # Same clinician revises their OWN work (Reflexion)
    expected_output=dedent("""\
        A revised and final clinical assessment that addresses all reviewer
        feedback, with a clear summary of changes made and rationale.
        Includes complete medication list, monitoring plan, discharge
        criteria, and patient education."""),
    # Context: reviewer feedback (which itself references all prior work)
    context=[initial_diagnosis, diagnosis_review]
)

# ===============================
# CREW CONFIGURATION
# ===============================

crew = Crew(
    # All agents participate
    agents=[radiologist, pathologist, clinician, reviewer],

    # Task sequence: specialist analysis → integration → reflexion → refinement
    tasks=[image_analysis, lab_analysis, initial_diagnosis, diagnosis_review, final_diagnosis],

    # Sequential process for task dependencies and context sharing
    process=Process.sequential,

    # NOTE: memory=False avoids requiring OpenAI API key for embeddings.
    # Context passing between tasks (via the `context` parameter) provides
    # the "memory" needed for this demo.
    memory=False,
    verbose=True
)

# ===============================
# EXECUTION
# ===============================

if __name__ == "__main__":
    print("=" * 70)
    print("HEALTHCARE COLLABORATION + REFLEXION DEMO")
    print("Pattern: Multi-specialist Collaboration → Reflexion → Self-Correction")
    print("=" * 70)
    print()
    print("PATIENT CASE:")
    print("-" * 40)
    print(PATIENT_CASE)
    print()

    result = crew.kickoff()

    # Save output
    outputs_dir = Path(__file__).resolve().parent / "outputs"
    os.makedirs(outputs_dir, exist_ok=True)
    output_path = outputs_dir / "healthcare_collaboration_reflexion.md"
    with open(output_path, "w") as f:
        f.write(str(result))

    print()
    print("=" * 70)
    print("FINAL RESULT — Revised Diagnosis & Treatment Plan")
    print("=" * 70)
    print(result)
    print()
    print(f"Output saved to: {output_path}")

"""
EXECUTION FLOW — COLLABORATION + REFLEXION:

PHASE 1 — COLLABORATIVE ANALYSIS (Specialist agents work independently):
  Task 1: Radiologist interprets chest X-ray and ECG
  Task 2: Pathologist interprets laboratory results
  (These tasks have no dependencies and analyze in parallel domains)

PHASE 2 — CLINICAL INTEGRATION (Clinician synthesizes):
  Task 3: Attending Physician receives both specialist reports via `context`
          and creates an integrated diagnosis + treatment plan

PHASE 3 — REFLEXION (Quality review + self-correction):
  Task 4: Medical Reviewer critically examines ALL prior outputs
          and provides structured feedback with severity ratings
  Task 5: SAME Attending Physician revises their OWN plan based on
          reviewer feedback (this is the Reflexion self-correction step)

BENEFITS OF THIS COMBINED PATTERN:
- Collaboration: Multiple expertise domains combined (radiology + pathology + medicine)
- Reflexion: Self-correction catches medication safety issues, missed diagnoses
- Memory (Context): Each task builds on prior outputs, maintaining full case continuity
- Real-world parallel: Mirrors actual hospital multidisciplinary team (MDT) meetings
"""
