# Import required libraries
"""
Healthcare Collaboration + Reflexion Pattern with Memory

================================================================================
COLLABORATION PATTERN:
================================================================================
- Multiple specialist agents work together as peers (no hierarchy)
- Each agent contributes their expertise to a shared goal
- Agents can build upon each other's work through task contexts
- Information flows horizontally between agents

Examples:
- Radiologist → Cardiologist → Neurologist (parallel expertise)
- Each brings specialized knowledge
- Results combine into comprehensive assessment

================================================================================
REFLEXION PATTERN:
================================================================================
- A dedicated agent reviews and challenges initial decisions
- Implements self-correction and quality assurance
- Forces the system to reconsider and improve initial outputs
- Mimics peer review process in professional settings

In this demo:
- Specialists collaborate on patient assessment
- Quality reviewer (Reflexion) checks all specialist outputs
- Ensures safety and completeness

================================================================================
MEMORY IN CREWAI:
================================================================================
CrewAI supports agent memory through:
- Task context passing (previous task outputs become input to next)
- Agent memory settings (stores interaction history)
- Enhanced with embeddings for semantic search (optional)

This enables:
- Patient history tracking
- Building on previous analyses
- Maintaining continuity across interactions

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: CrewAI (Multi-agent orchestration)
  - Agent: Specialist agents with collaboration capabilities
  - Task: Sequential tasks building on each other
  - Crew: Orchestrates collaborative specialists + reflexion reviewer
  - Memory: Built-in CrewAI memory (no LangChain required)

LLM Model: Google Gemini 2.0 Flash
  - API Provider: Google Cloud Vertex AI / Google AI
  - Model ID: gemini/gemini-2.0-flash
  - Temperature: 0.7

Environment Configuration:
  - Uses .env file for API keys (GEMINI_API_KEY)
  - Automatic credential path resolution for Google Cloud authentication
================================================================================
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM

# Load environment variables
def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

# Load environment variables first
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Resolve relative credential paths to absolute
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

# Gemini LLM configuration using CrewAI's LLM class
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    print("ERROR: GEMINI_API_KEY not found in environment variables.")
    print("Please add GEMINI_API_KEY to your .env file.")
    exit(1)

llm = LLM(
    model="gemini/gemini-2.0-flash",
    api_key=GEMINI_API_KEY,
    temperature=0.7
)
print(f"Using Gemini model: gemini/gemini-2.0-flash")

# ===============================
# COLLABORATIVE SPECIALIST AGENTS
# ===============================

# SPECIALIST AGENT 1 - Medical imaging expert
radiologist = Agent(
    role='Radiologist',
    goal='Analyze medical images and provide insights',
    backstory='Specialist in medical imaging interpretation',
    llm=llm,
    memory=True
)

# SPECIALIST AGENT 2 - Laboratory analysis expert
pathologist = Agent(
    role='Pathologist',
    goal='Analyze lab results and tissue samples',
    backstory='Expert in laboratory diagnostics',
    llm=llm,
    memory=True
)

# SPECIALIST AGENT 3 - Clinical decision maker
clinician = Agent(
    role='Clinical Doctor',
    goal='Integrate findings for diagnosis',
    backstory='Experienced physician with broad medical knowledge',
    llm=llm,
    memory=True
)

# ===============================
# REFLEXION AGENT (Quality assurance)
# ===============================

# REFLEXION AGENT - Reviews and challenges decisions
reviewer = Agent(
    role='Medical Reviewer',
    goal='Review and challenge initial diagnosis',
    backstory='Senior physician focused on diagnostic accuracy',
    llm=llm,
    memory=True,
    verbose=True
)

# ===============================
# COLLABORATIVE TASKS
# ===============================

# PARALLEL ANALYSIS TASKS - Can run simultaneously
# Each specialist works independently on their domain

# TASK 1 - Image analysis (independent)
image_analysis = Task(
    description='Analyze chest X-ray for abnormalities',
    agent=radiologist,
    expected_output='Radiological findings report'
)

# TASK 2 - Laboratory analysis (independent)
lab_analysis = Task(
    description='Interpret blood work and lab values',
    agent=pathologist,
    expected_output='Laboratory analysis report'
)

# TASK 3 - Initial integration (depends on above tasks)
initial_diagnosis = Task(
    description='Combine imaging and lab results for preliminary diagnosis',
    agent=clinician,
    expected_output='Initial diagnostic assessment'
    # This task will automatically receive outputs from image_analysis and lab_analysis
)

# ===============================
# REFLEXION TASKS (Self-correction mechanism)
# ===============================

# REFLEXION TASK 1 - Critical review
diagnosis_review = Task(
    description='Review initial diagnosis, identify gaps, suggest additional tests',
    agent=reviewer,
    expected_output='Diagnostic review with recommendations',
    # CRITICAL: context parameter makes this task aware of previous analyses
    context=[image_analysis, lab_analysis, initial_diagnosis]
)

# REFLEXION TASK 2 - Improved final output
final_diagnosis = Task(
    description='Incorporate review feedback for final diagnosis',
    agent=clinician,  # Original clinician refines their diagnosis
    expected_output='Final diagnosis and treatment plan',
    context=[diagnosis_review]  # Uses feedback from reviewer
)

# ===============================
# CREW CONFIGURATION
# ===============================

# Create collaborative crew with memory and reflexion
crew = Crew(
    # All agents participate as equals (no supervisor hierarchy)
    agents=[radiologist, pathologist, clinician, reviewer],
    
    # Task sequence: parallel → integration → reflexion → refinement
    tasks=[image_analysis, lab_analysis, initial_diagnosis, diagnosis_review, final_diagnosis],
    
    # Sequential process allows for task dependencies and context sharing
    process=Process.sequential,
    
    # MEMORY ENABLED - Agents remember interactions and context
    memory=True,
    verbose=True
)

# ===============================
# EXECUTION
# ===============================

result = crew.kickoff(inputs={'patient_data': 'Patient: 45yo male, chest pain, smoker'})

"""
EXECUTION FLOW WITH COLLABORATION + REFLEXION:

PHASE 1 - COLLABORATIVE ANALYSIS:
1. Radiologist and Pathologist work independently (can be parallel)
2. Clinician integrates both specialist findings
3. Initial diagnosis is formed through collaboration

PHASE 2 - REFLEXION PROCESS:
4. Reviewer critically examines all previous work
5. Identifies potential errors, gaps, or alternative interpretations
6. Suggests improvements or additional considerations

PHASE 3 - REFINEMENT:
7. Clinician incorporates reviewer feedback
8. Final diagnosis is improved through reflexion

BENEFITS:
- Collaboration: Multiple expertise domains combined
- Reflexion: Self-correction and quality improvement
- Memory: Consistent context across all interactions
- Reduced errors through peer review process
- More robust decision-making
"""