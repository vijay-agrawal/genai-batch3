# CrewAI + Gemini Template Guide

## Overview

This template standardizes how to build CrewAI agents with Google Gemini LLM across all demos. It eliminates boilerplate code and provides consistent environment/credential management.

## Files

- **`crewai_gemini_template.py`** - Reusable template with all common setup
- **`template_usage_example.py`** - Simple example showing how to use the template

## Quick Start

### 1. Using the Template in Your Script

```python
# Import what you need
from crewai import Agent, Task, Crew
from crewai_gemini_template import llm, PROJECT_ROOT

# Create agents - just add llm=llm
my_agent = Agent(
    role="My Role",
    goal="My Goal",
    backstory="My backstory",
    llm=llm  # <-- Template provides this
)

# Run as normal
```

### 2. Converting Existing Demos

To convert an existing demo to use the template:

**Before:**
```python
import os
from dotenv import load_dotenv
from crewai import Agent, LLM

load_dotenv()
VERTEX_AI_MODEL = os.getenv("VERTEX_AI_MODEL", "vertex_ai/gemini-2.0-flash")

llm_instance = LLM(
    model="gemini/gemini-2.0-flash",
    api_key=os.getenv("GEMINI_API_KEY"),
    temperature=0.7
)
```

**After:**
```python
from crewai_gemini_template import llm
# That's it! LLM is already initialized and ready to use
```

## Features

### Environment Management
- Automatically finds `.env` file in project hierarchy
- Resolves relative credential paths to absolute
- Error handling with helpful messages

### Ready-to-Use LLM
```python
from crewai_gemini_template import llm

# llm is already configured and ready
my_agent = Agent(role="...", goal="...", llm=llm)
```

### Utility Functions

#### Get Project Root
```python
from crewai_gemini_template import PROJECT_ROOT

config_file = PROJECT_ROOT / "config.json"
```

#### Resolve Data Paths
```python
from crewai_gemini_template import get_data_path

data = pd.read_csv(get_data_path("data/defects.csv"))
```

#### Ensure Output Directory
```python
from crewai_gemini_template import ensure_output_dir

output_dir = ensure_output_dir()
result_file = output_dir / "results.txt"
```

#### Create Agents (Factory Function)
```python
from crewai_gemini_template import create_agent

agent = create_agent(
    role="Analyst",
    goal="Analyze data",
    backstory="Data expert",
    tools=[my_tool],
    memory=True,
    verbose=True
)
```

### Configuration Object
```python
from crewai_gemini_template import Config

print(Config.PROJECT_ROOT)      # Project root path
print(Config.LLM_MODEL)         # "gemini/gemini-2.0-flash"
print(Config.LLM_TEMPERATURE)   # 0.7
print(Config.VERBOSE_MODE)      # True
print(Config.MEMORY_ENABLED)    # True
```

### Debug Utilities
```python
from crewai_gemini_template import print_setup_info

print_setup_info()  # Shows environment configuration
```

## Pattern Applied to Existing Demos

The template pattern has been applied to these demos:
- ✅ 01 research_agent_ReAct.py
- ✅ 02 ReWoo_demo.py
- ✅ 03 healthcare_reflexion.py
- ✅ 04_credit_risk_supervisor_worker.py
- ✅ 05 healthcare_collaboration_reflexion_memory.py
- ✅ 06 telco_customersupport_memory_state.py
- ✅ 07 quality_control_multi_pattern.py
- ✅ 08 manufacturing_pipeline.py
- ✅ 09 memory_state.py

## Running Examples

### Run the Template Directly
```bash
python crewai_gemini_template.py
```
Shows setup information and confirms template is loaded.

### Run the Usage Example
```bash
python template_usage_example.py
```
Demonstrates a working ReAct agent using the template.

## Benefits

1. **Consistency** - All demos use same environment/LLM setup
2. **DRY** - Don't Repeat Yourself - one place for common code
3. **Maintainability** - Update once, apply everywhere
4. **Testability** - Easy to verify setup works
5. **Scalability** - New demos can use template immediately
6. **Clarity** - Focus on agent logic, not boilerplate

## Key Differences from Previous Approach

### Removed
- ❌ LangChain memory imports
- ❌ LangChain Vertex AI imports
- ❌ Duplicate env setup in each file
- ❌ Multiple LLM initialization patterns

### Added
- ✅ Centralized template file
- ✅ CrewAI-only approach
- ✅ Utility functions for common tasks
- ✅ Configuration object
- ✅ Debug utilities

## Troubleshooting

### "GEMINI_API_KEY not found" Error

1. Check `.env` file exists in project root
2. Verify it contains: `GEMINI_API_KEY=your-key-here`
3. Restart your Python process after adding to `.env`

### Relative Path Issues

The template automatically finds the project root. If it's not finding the correct directory:
- Ensure `.env` or `google-vertexai-serviceaccount-key.json` exists in project root
- Or run scripts from project root: `python agentic_designpatterns/demos/template_usage_example.py`

### LLM Connection Issues

1. Verify GEMINI_API_KEY is valid
2. Check internet connection
3. Verify Google Gemini API is enabled

## Migration Guide: Old Demo → New Template

### Step 1: Remove Environment Setup
Delete all this code:
```python
import os
from dotenv import load_dotenv
from langchain_google_vertexai import VertexAI

load_dotenv()
MODEL = os.getenv("VERTEX_AI_MODEL", "vertex_ai/gemini-2.0-flash")
vertex_llm = VertexAI(...)
```

### Step 2: Add Template Import
```python
from crewai_gemini_template import llm
```

### Step 3: Update Agents
Change:
```python
Agent(..., model=MODEL)  # or model=vertex_llm
```

To:
```python
Agent(..., llm=llm)
```

### Step 4: Remove LangChain Imports
Delete:
```python
from langchain.memory import ...
from langchain.tools import ...
```

## Example: Complete Migration

**Before (Old Way):**
```python
import os
from dotenv import load_dotenv
from crewai import Agent, Task, Crew
from langchain_google_vertexai import VertexAI

load_dotenv()
MODEL = os.getenv("VERTEX_AI_MODEL", "vertex_ai/gemini-2.0-flash")
vertex_llm = VertexAI(model_name="gemini-2.0-flash", ...)

support_agent = Agent(
    role="Support",
    goal="Help customers",
    backstory="...",
    model=MODEL
)
```

**After (New Template Way):**
```python
from crewai import Agent, Task, Crew
from crewai_gemini_template import llm

support_agent = Agent(
    role="Support",
    goal="Help customers",
    backstory="...",
    llm=llm
)
```

Much cleaner! 🎉

## Next Steps

1. Use `crewai_gemini_template.py` for new demos
2. Refer to `template_usage_example.py` for reference
3. Migrate remaining demos (09-2, 10-2, 10, 11, crewai-fraud-react-vs-rewoo/) using the pattern
4. Update documentation to reference this template

## Questions?

Refer to the docstrings in `crewai_gemini_template.py` for detailed function documentation.
