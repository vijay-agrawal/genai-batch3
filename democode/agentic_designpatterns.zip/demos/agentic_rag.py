"""
Agentic RAG Demo using Google ADK

This demo shows how an agent can intelligently decide when to use a retrieval tool
vs when to answer directly from its own knowledge. This is the key benefit of
"Agentic RAG" - the agent autonomously decides if retrieval is needed.

Example queries that USE the skill_lookup tool (retrieval):
- "What are skills of Pankaj?"
- "Show me 2 people with HR skills"
- "Who has Python experience?"

Example queries that BYPASS retrieval (direct LLM response):
- "What is the capital of France?"
- "Explain what RAG means in AI"
- "What is 2 + 2?"

Uses:
- Google ADK for the agent framework
- Chroma vector DB with employee skills/CV data (from rag_gemini/vectordb)
- Vertex AI embeddings (gemini-embedding-001)
"""

import os
import sys
from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

# ============================================================================
# Environment Setup
# ============================================================================

def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env in any parent directory.")
    sys.exit(1)

PROJECT_ROOT = _find_project_root()

# Load environment variables
from dotenv import load_dotenv
load_dotenv(PROJECT_ROOT / ".env")

# ============================================================================
# Environment Variable Validation
# ============================================================================

def _validate_environment():
    """Validate required environment variables for authentication."""
    errors = []

    # Check for GEMINI_API_KEY (alternative auth method)
    gemini_api_key = os.getenv("GEMINI_API_KEY")

    # Check for Vertex AI credentials
    project_id = os.getenv("GOOGLE_VERTEXAI_PROJECT_ID")
    location = os.getenv("GOOGLE_VERTEXAI_LOCATION")
    creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")

    # Determine which auth method is available
    has_gemini_key = bool(gemini_api_key and gemini_api_key.strip())
    has_vertex_config = bool(project_id and location)

    if not has_gemini_key and not has_vertex_config:
        errors.append("Missing authentication credentials. Provide either:")
        errors.append("  Option 1: GEMINI_API_KEY")
        errors.append("  Option 2: GOOGLE_VERTEXAI_PROJECT_ID + GOOGLE_VERTEXAI_LOCATION + GOOGLE_APPLICATION_CREDENTIALS")
        errors.append("")
        errors.append("Current status:")
        errors.append(f"  GEMINI_API_KEY: {'SET' if gemini_api_key else 'NOT SET'}")
        errors.append(f"  GOOGLE_VERTEXAI_PROJECT_ID: {'SET' if project_id else 'NOT SET'}")
        errors.append(f"  GOOGLE_VERTEXAI_LOCATION: {'SET' if location else 'NOT SET'}")
        errors.append(f"  GOOGLE_APPLICATION_CREDENTIALS: {'SET' if creds_path else 'NOT SET'}")

    # If using Vertex AI, validate credentials file exists
    if has_vertex_config and creds_path:
        # Resolve relative path
        if not Path(creds_path).is_absolute():
            resolved_path = PROJECT_ROOT / creds_path
        else:
            resolved_path = Path(creds_path)

        if not resolved_path.exists():
            errors.append(f"GOOGLE_APPLICATION_CREDENTIALS file not found:")
            errors.append(f"  Path: {creds_path}")
            errors.append(f"  Resolved to: {resolved_path}")
            errors.append(f"  Please ensure the service account key file exists at this location.")
    elif has_vertex_config and not creds_path:
        errors.append("GOOGLE_APPLICATION_CREDENTIALS not set.")
        errors.append("  This is required when using Vertex AI authentication.")
        errors.append("  Set it to the path of your service account key JSON file.")

    # Print errors and exit if any
    if errors:
        print("=" * 70)
        print("[ERROR] Environment Configuration Error")
        print("=" * 70)
        for error in errors:
            print(error)
        print("=" * 70)
        sys.exit(1)

    # Print which approach is being used
    if has_gemini_key:
        print("[OK] Using authentication: GEMINI_API_KEY")
    else:
        print(f"[OK] Using authentication: Vertex AI (Project: {project_id}, Location: {location})")

    return has_gemini_key, project_id, location

# Validate environment
USE_GEMINI_API, PROJECT_ID, LOCATION = _validate_environment()

# Resolve relative credential paths to absolute
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

# Initialize Vertex AI (needed for embeddings)
import vertexai
try:
    vertexai.init(project=PROJECT_ID, location=LOCATION)
    print(f"[OK] Vertex AI initialized: {PROJECT_ID}")
except Exception as e:
    print(f"[ERROR] Error initializing Vertex AI: {e}")
    sys.exit(1)

# ============================================================================
# Vector Store Setup (reusing from rag_gemini)
# ============================================================================

from langchain_google_vertexai import VertexAIEmbeddings
from langchain_community.vectorstores import Chroma

# Path to the vector database created by rag_gemini/indexer.py
CHROMA_PATH = str(PROJECT_ROOT / "rag_gemini" / "vectordb")

def load_vector_store(persist_directory: str = CHROMA_PATH) -> Chroma:
    """Load the Chroma vector store with employee skills data."""
    print(f"[OK] Loading Chroma vector DB from: {persist_directory}")

    if not Path(persist_directory).exists():
        print(f"[ERROR] Vector database not found at {persist_directory}")
        print("  Please run rag_gemini/indexer.py first to create the vector database")
        sys.exit(1)

    embeddings = VertexAIEmbeddings(model_name="gemini-embedding-001")
    vector_store = Chroma(persist_directory=persist_directory, embedding_function=embeddings)

    return vector_store

# Load the vector store globally
vector_store = load_vector_store()
print(f"[OK] Vector store loaded successfully")

# ============================================================================
# Skill Lookup Tool Definition
# ============================================================================

def skill_lookup(query: str, num_results: int = 3) -> str:
    """
    Look up employee skills and information from the knowledge base.

    Use this tool when the user asks about:
    - Skills or expertise of specific employees (e.g., "What skills does Pankaj have?")
    - Finding people with specific skills (e.g., "Who has Python experience?")
    - Employee qualifications, experience, or background
    - Any question about people in the organization

    Args:
        query: The search query about employee skills or information
        num_results: Number of relevant documents to retrieve (default: 3)

    Returns:
        Relevant information from employee CVs/profiles
    """
    print(f"\n  >> [TOOL CALLED] skill_lookup")
    print(f"     Query: {query}")
    print(f"     Retrieving {num_results} results...")

    # Create retriever from vector store
    retriever = vector_store.as_retriever(
        search_type='similarity',
        search_kwargs={'k': num_results}
    )

    # Retrieve relevant documents
    docs = retriever.invoke(query)

    if not docs:
        return "No relevant employee information found for the given query."

    # Format the results
    results = []
    for i, doc in enumerate(docs, 1):
        source = doc.metadata.get('source', 'Unknown')
        results.append(f"[Document {i}] (Source: {Path(source).name})\n{doc.page_content}")

    combined_results = "\n\n---\n\n".join(results)
    print(f"     [OK] Retrieved {len(docs)} documents")

    return combined_results

# ============================================================================
# Google ADK Agent Setup
# ============================================================================

from google.adk import Agent, Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from google import genai

# Configure Google GenAI client
# ADK uses the google.genai Client internally, which needs credentials
# Support both GEMINI_API_KEY and Vertex AI authentication
if USE_GEMINI_API:
    client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
    print(f"[OK] Google GenAI client configured with GEMINI_API_KEY")
else:
    client = genai.Client(
        vertexai=True,
        project=PROJECT_ID,
        location=LOCATION,
    )
    print(f"[OK] Google GenAI client configured with Vertex AI")

# Create the Skills Helper Agent
skills_agent = Agent(
    name="skills_helper_agent",
    model="gemini-2.5-flash",
    instruction="""You are a helpful Skills Helper Agent. Your primary job is to help users
find information about employee skills, qualifications, and expertise.

IMPORTANT GUIDELINES:
1. When users ask about employee skills, qualifications, or want to find people with
   specific skills, USE the skill_lookup tool to search the knowledge base.

2. When users ask general questions that don't require employee data (like math,
   general knowledge, explanations of concepts), answer directly WITHOUT using tools.

3. Always be helpful, concise, and accurate in your responses.

4. If the skill_lookup tool returns results, synthesize the information into a
   clear, user-friendly response.

Examples of when to USE skill_lookup:
- "What skills does Pankaj have?"
- "Show me 2 people with HR skills"
- "Who knows Python?"
- "Find employees with data science experience"

Examples of when to NOT use skill_lookup (answer directly):
- "What is the capital of France?"
- "What does RAG stand for?"
- "Calculate 15 * 23"
""",
    tools=[skill_lookup],
)

print("[OK] Skills Helper Agent created with skill_lookup tool")

# ============================================================================
# Runner Setup
# ============================================================================

# Create session service and runner
session_service = InMemorySessionService()
runner = Runner(
    agent=skills_agent,
    app_name="skills_helper_app",
    session_service=session_service,
    auto_create_session=True,  # Automatically create sessions when needed
)

print("[OK] Runner initialized")

# ============================================================================
# Helper Function to Run Queries
# ============================================================================

def ask_agent(query: str, user_id: str = "user1", session_id: str = "session1") -> str:
    """Send a query to the agent and get the response."""
    print(f"\n{'='*70}")
    print(f"USER QUERY: {query}")
    print(f"{'='*70}")

    # Create the message content
    message = types.Content(
        role="user",
        parts=[types.Part(text=query)]
    )

    # Run the agent and collect response
    final_response = ""
    for event in runner.run(
        user_id=user_id,
        session_id=session_id,
        new_message=message
    ):
        # Check if the event has a text response
        if event.content and event.content.parts:
            for part in event.content.parts:
                if hasattr(part, 'text') and part.text:
                    final_response = part.text

    print(f"\nAGENT RESPONSE:")
    print(f"{final_response}")
    print(f"{'='*70}\n")

    return final_response

# ============================================================================
# Main Demo
# ============================================================================

if __name__ == "__main__":
    print("\n" + "="*70)
    print("AGENTIC RAG DEMO - Skills Helper Agent")
    print("="*70)
    print("\nThis demo shows how the agent intelligently decides when to use")
    print("the retrieval tool vs when to answer directly from its knowledge.\n")

    # -------------------------------------------------------------------------
    # Demo 1: Queries that NEED retrieval (skill_lookup tool will be used)
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("PART 1: QUERIES THAT USE RETRIEVAL (skill_lookup tool)")
    print("="*70)

    retrieval_queries = [
        "What are the skills of Pankaj?",
        "Show me 2 people with HR skills",
        "Who has experience with Python programming?",
    ]

    for query in retrieval_queries:
        ask_agent(query)
        print("\n")

    # -------------------------------------------------------------------------
    # Demo 2: Queries that DON'T need retrieval (direct LLM response)
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("PART 2: QUERIES THAT BYPASS RETRIEVAL (direct LLM response)")
    print("="*70)
    print("Notice how the agent answers these WITHOUT calling skill_lookup!")

    direct_queries = [
        "What is the capital of France?",
        "Explain what RAG means in AI in one sentence.",
        "What is 15 multiplied by 23?",
    ]

    for query in direct_queries:
        ask_agent(query)
        print("\n")

    # -------------------------------------------------------------------------
    # Summary
    # -------------------------------------------------------------------------
    print("\n" + "="*70)
    print("DEMO SUMMARY")
    print("="*70)
    print("""
The key benefit of Agentic RAG is demonstrated above:

* RETRIEVAL QUERIES: The agent recognized questions about employee skills
  and automatically used the skill_lookup tool to search the vector database.

* DIRECT QUERIES: The agent recognized general knowledge questions and
  answered them directly WITHOUT unnecessary retrieval calls.

This is more efficient and intelligent than traditional RAG which would
retrieve documents for EVERY query regardless of whether it's needed.

The agent autonomously decides the best approach for each query!
""")
