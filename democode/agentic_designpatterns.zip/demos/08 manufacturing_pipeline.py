"""
Manufacturing Pipeline Demonstration

================================================================================
PATTERN: Sequential Processing Pipeline
================================================================================

This demo shows how to build a manufacturing quality pipeline:

Pipeline Stages:
1. INGEST: Load and clean data from manufacturing logs
2. ANALYZE: Identify patterns and systemic issues
3. VERIFY: Cross-check findings against data with confidence levels
4. PUBLISH: Communicate findings to operations team

Key Concept:
Each agent specializes in one stage of the pipeline. Output from one stage
becomes input to the next stage. This sequential processing creates a robust,
auditable workflow.

Benefits:
- Clear separation of concerns
- Easy to debug (identify which stage is failing)
- Scalable (add verification stages or analysis methods)
- Auditable (clear pipeline of decision-making)

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: CrewAI (Multi-agent orchestration)
  - Agent: Specialized agents for each pipeline stage
  - Task: Stage-specific tasks with input/output contracts
  - Crew: Sequential process for pipeline execution
  - Process: Sequential (strict ordering of stages)

LLM Model: Google Gemini 2.0 Flash
  - API Provider: Google Cloud Vertex AI / Google AI
  - Model ID: gemini/gemini-2.0-flash
  - Temperature: 0.7

Data:
  - Input: Manufacturing defects data (data/manufacturing_defects.csv)
  - Output: Incident bulletin for plant operations

Environment Configuration:
  - Uses .env file for API keys (GEMINI_API_KEY)
  - Automatic credential path resolution for Google Cloud authentication
================================================================================
"""

import os
import pandas as pd
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
from textwrap import dedent

def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

# Load environment variables first
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Resolve relative credential paths to absolute
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

# Gemini LLM configuration using CrewAI's LLM class
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    print("ERROR: GEMINI_API_KEY not found in environment variables.")
    print("Please add GEMINI_API_KEY to your .env file.")
    exit(1)

llm = LLM(
    model="gemini/gemini-2.0-flash",
    api_key=GEMINI_API_KEY,
    temperature=0.7
)
print(f"Using Gemini model: gemini/gemini-2.0-flash")

def load_defects():
    """Load manufacturing defects data"""
    data_path = Path(__file__).resolve().parent / "data" / "manufacturing_defects.csv"
    return pd.read_csv(data_path)

# Pipeline Stage 1: Ingestion
ingest = Agent(
    role="Ingestion Agent",
    goal="Read defect logs and produce a clean summary by lot and station.",
    backstory="Knows how to turn CSVs into compact summaries for engineers.",
    llm=llm
)

# Pipeline Stage 2: Analysis
analyze = Agent(
    role="Quality Analyst",
    goal="Identify top 2 systemic issues and suspected root causes.",
    backstory="Applies 5-Why style reasoning and links to stations.",
    llm=llm
)

# Pipeline Stage 3: Verification
verify = Agent(
    role="QA Verifier",
    goal="Check that the proposed root causes align with the data and add confidence levels.",
    backstory="Skeptical and concise; demands evidence.",
    llm=llm
)

# Pipeline Stage 4: Publication
publish = Agent(
    role="Incident Publisher",
    goal="Write a short incident bulletin for the plant Slack.",
    backstory="Communicates crisply with operators and supervisors.",
    llm=llm
)

t1 = Task(
    description=dedent("""\
    Load manufacturing_defects.csv and provide a compact table:
    lot, station, defect, count and a per-lot total row.

    Defects data:
    {defects_table}
    """),
    agent=ingest,
    expected_output="A compact table with lot, station, defect, count columns and per-lot totals."
)

t2 = Task(
    description=dedent("""\
    From the table, identify top 2 systemic issues and suspected root causes with evidence.
    """),
    agent=analyze,
    expected_output="Top 2 systemic issues with suspected root causes and supporting evidence."
)

t3 = Task(
    description=dedent("""\
    Verify claims against the table; add confidence (High/Med/Low) and gaps to check.
    """),
    agent=verify,
    expected_output="Verification report with confidence levels (High/Med/Low) and gaps to investigate."
)

t4 = Task(
    description=dedent("""\
    Publish an incident bulletin (<=100 words) with:
    - Issues, stations, lots affected
    - Immediate containment & owner
    """),
    agent=publish,
    expected_output="An incident bulletin (<=100 words) listing issues, affected stations/lots, and containment actions."
)

crew = Crew(agents=[ingest, analyze, verify, publish], tasks=[t1, t2, t3, t4], process=Process.sequential)

if __name__ == "__main__":
    df = load_defects()
    table = df.to_markdown(index=False)
    result = crew.kickoff(inputs={"defects_table": table})
    os.makedirs("outputs", exist_ok=True)
    with open("outputs/manufacturing_pipeline_bulletin.md","w") as f: f.write(str(result))
    print("=== Manufacturing Pipeline / Assembly Line Result ===")
    print(result)
