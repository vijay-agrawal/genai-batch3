"""
CrewAI + Gemini Reusable Template

This is a standardized template for creating CrewAI agents with Google Gemini LLM.
Use this as a starting point for new demos or when converting existing ones.

Key Features:
- Centralized environment and credential management
- Automatic .env and service account key detection
- Proper error handling with informative messages
- Ready-to-use LLM instance configured for Gemini 2.0 Flash
- No LangChain dependencies (CrewAI only)

Usage:
    1. Import this template in your script
    2. Use the 'llm' object in all your agents
    3. Access PROJECT_ROOT for relative path resolution
    
Example:
    from crewai_gemini_template import llm, PROJECT_ROOT
    
    my_agent = Agent(
        role="My Role",
        goal="My Goal",
        backstory="My backstory",
        llm=llm
    )
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from crewai import LLM

# ================================================================================
# ENVIRONMENT SETUP - Common to all CrewAI + Gemini projects
# ================================================================================

def _find_project_root() -> Path:
    """
    Find project root by looking for .env or service account key.
    
    Searches upward from current script location until it finds:
    - A .env file, or
    - A google-vertexai-serviceaccount-key.json file
    
    Falls back to current script's parent directory.
    """
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent


# Load environment variables first
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Resolve relative credential paths to absolute paths
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())


# ================================================================================
# GEMINI LLM INITIALIZATION - Ready-to-use LLM instance
# ================================================================================

def _initialize_gemini_llm() -> LLM:
    """
    Initialize and return a CrewAI LLM instance configured for Gemini 2.0 Flash.
    
    Required Environment Variable:
        GEMINI_API_KEY - Your Google Gemini API key
    
    Returns:
        LLM: Configured LLM instance ready for use with agents
    
    Raises:
        SystemExit: If GEMINI_API_KEY is not found
    """
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
    
    if not GEMINI_API_KEY:
        print("=" * 70)
        print("ERROR: GEMINI_API_KEY not found in environment variables")
        print("=" * 70)
        print("\nPlease add GEMINI_API_KEY to your .env file")
        print(f"Expected location: {PROJECT_ROOT / '.env'}")
        print("\nExample .env content:")
        print("  GEMINI_API_KEY=your-api-key-here")
        print("=" * 70)
        exit(1)
    
    gemini_llm = LLM(
        model="gemini/gemini-2.0-flash",
        api_key=GEMINI_API_KEY,
        temperature=0.7
    )
    
    print(f"✓ Initialized Gemini LLM: gemini/gemini-2.0-flash")
    return gemini_llm


# Create the globally available LLM instance
llm = _initialize_gemini_llm()


# ================================================================================
# UTILITY FUNCTIONS
# ================================================================================

def get_data_path(filename: str) -> Path:
    """
    Resolve relative data file paths to absolute paths.
    
    Args:
        filename: Relative path from project root (e.g., "data/defects.csv")
    
    Returns:
        Path: Absolute path to the file
    
    Example:
        data_path = get_data_path("data/clinical_notes.txt")
    """
    return PROJECT_ROOT / filename


def ensure_output_dir(dirname: str = "outputs") -> Path:
    """
    Ensure output directory exists and return its path.
    
    Args:
        dirname: Name of output directory (default: "outputs")
    
    Returns:
        Path: Absolute path to output directory
    
    Example:
        output_dir = ensure_output_dir()
        result_file = output_dir / "results.txt"
    """
    output_path = PROJECT_ROOT / dirname
    output_path.mkdir(exist_ok=True)
    return output_path


# ================================================================================
# CONFIGURATION
# ================================================================================

class Config:
    """Centralized configuration for CrewAI projects"""
    
    PROJECT_ROOT = PROJECT_ROOT
    LLM_MODEL = "gemini/gemini-2.0-flash"
    LLM_TEMPERATURE = 0.7
    VERBOSE_MODE = True
    MEMORY_ENABLED = True


# ================================================================================
# EXAMPLE AGENT FACTORY FUNCTIONS
# ================================================================================

def create_agent(role: str, goal: str, backstory: str, tools=None, memory=True, verbose=True):
    """
    Factory function to create agents with consistent configuration.
    
    Args:
        role: Agent's professional role
        goal: What the agent is trying to achieve
        backstory: Agent's background and context
        tools: List of tools available to the agent (optional)
        memory: Whether to enable memory (default: True)
        verbose: Whether to show detailed execution (default: True)
    
    Returns:
        Agent: Configured CrewAI Agent instance
    
    Example:
        from crewai import Agent
        
        my_agent = create_agent(
            role="Data Analyst",
            goal="Analyze business metrics",
            backstory="Experienced analyst with SQL skills",
            tools=[analysis_tool]
        )
    """
    from crewai import Agent
    
    return Agent(
        role=role,
        goal=goal,
        backstory=backstory,
        tools=tools or [],
        memory=memory,
        verbose=verbose,
        llm=llm
    )


# ================================================================================
# DEBUG UTILITIES
# ================================================================================

def print_setup_info():
    """Print diagnostic information about the environment setup"""
    print("\n" + "=" * 70)
    print("SETUP INFORMATION")
    print("=" * 70)
    print(f"Project Root: {PROJECT_ROOT}")
    print(f"LLM Model: {Config.LLM_MODEL}")
    print(f"Temperature: {Config.LLM_TEMPERATURE}")
    print(f"Memory Enabled: {Config.MEMORY_ENABLED}")
    print(f"Verbose Mode: {Config.VERBOSE_MODE}")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    # When run directly, show setup information
    print_setup_info()
    print("✓ Template loaded successfully")
    print("✓ Use 'from crewai_gemini_template import llm' in your scripts")
