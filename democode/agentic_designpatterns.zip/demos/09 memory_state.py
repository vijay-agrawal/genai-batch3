#!/usr/bin/env python3
"""
Memory & Shared State Pattern — Healthcare Patient Chart

================================================================================
MEMORY & STATE MANAGEMENT PATTERN:
================================================================================
MEMORY in AI Agents:
- Enables agents to remember prior task outputs within a session
- Maintains continuity as information flows between specialists
- CrewAI implements memory via the `context` parameter on Tasks
  (each task can receive outputs from earlier tasks)

STATE (Shared Mutable Context):
- A common data structure (e.g. a patient chart) shared across agents
- Each agent READS the current state and ADDS to it
- Passed into the crew via `inputs`, so every task description can
  reference it with {variable_name} placeholders
- Simulates a real Electronic Health Record (EHR) that multiple
  clinicians read and write to

KEY DIFFERENCE:
- Memory = agent recalls what happened earlier in the workflow
- State  = a structured data object that accumulates information

================================================================================
DEMO DESCRIPTION — What This Script Does:
================================================================================
A simple 3-agent workflow simulating a hospital patient encounter:

  1. Triage Nurse    — Reads patient intake data (shared state), assesses
                       urgency, and records triage findings
  2. Attending Doctor — Reads triage findings + patient state, forms a
                       diagnosis and treatment plan
  3. Discharge Planner — Reads all prior findings + patient state, creates
                        a safe discharge summary

Each agent builds on the shared patient chart (state) and prior task
outputs (memory via context). This mirrors how a real hospital chart
accumulates notes from different providers.

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: CrewAI (Multi-agent orchestration)
  - Agent: Specialist roles (Nurse, Doctor, Discharge Planner)
  - Task: Sequential tasks with context passing (memory)
  - Crew: Orchestrates agents, passes shared state via inputs

LLM Model: Google Gemini 2.0 Flash
  - Model ID: gemini/gemini-2.0-flash
  - Temperature: 0.7

Environment Configuration:
  - Uses .env file for API keys (GEMINI_API_KEY)
  - Automatic credential path resolution for Google Cloud authentication
================================================================================
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
from textwrap import dedent
import warnings

warnings.filterwarnings('ignore')

# ---------------------------------------------------------------------------
# Environment setup (same pattern as demos 01, 02, 03, 05)
# ---------------------------------------------------------------------------

def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    print("ERROR: GEMINI_API_KEY not found in environment variables.")
    print("Please add GEMINI_API_KEY to your .env file.")
    exit(1)

llm = LLM(
    model="gemini/gemini-2.0-flash",
    api_key=GEMINI_API_KEY,
    temperature=0.7
)
print(f"Using Gemini model: gemini/gemini-2.0-flash")

# ===============================
# SHARED STATE — Patient Chart
# ===============================
# This dictionary acts as the shared "Electronic Health Record".
# It is passed to the crew via `inputs=`, making every field available
# as {field_name} inside task descriptions.
#
# WHY THIS MATTERS:
# - All agents see the SAME patient data (single source of truth)
# - Each agent's task description can reference any field
# - This mirrors how hospital EHR systems work — one chart, many authors

patient_chart = {
    "patient_name": "James Rivera",
    "age": 72,
    "sex": "Male",
    "chief_complaint": "Sudden onset confusion and left-sided weakness for 2 hours",

    "vitals": (
        "BP 182/96, HR 88 irregular, RR 18, SpO2 96% on room air, "
        "Temp 37.0C, Blood Glucose 145 mg/dL"
    ),

    "medical_history": (
        "Atrial fibrillation (on warfarin 5 mg daily), "
        "Hypertension (on amlodipine 10 mg daily), "
        "Type 2 Diabetes (on glipizide 10 mg daily), "
        "Previous TIA 2 years ago"
    ),

    "allergies": "Penicillin (rash), Aspirin (GI bleeding)",

    "current_medications": (
        "Warfarin 5 mg daily, Amlodipine 10 mg daily, "
        "Glipizide 10 mg daily, Omeprazole 20 mg daily"
    ),

    "initial_observations": (
        "Patient alert but disoriented to time and place. "
        "Left facial droop noted. Left arm drift on exam. "
        "Speech slurred but comprehensible. "
        "Family reports symptoms started at 14:00, current time 16:00."
    ),
}

# ===============================
# AGENTS (3 simple roles)
# ===============================

triage_nurse = Agent(
    role="Emergency Triage Nurse",
    goal="Assess patient urgency, document vital signs interpretation, and flag critical findings for the doctor.",
    backstory=dedent("""\
        You are an experienced ER triage nurse. You quickly assess patients,
        identify red flags, and prioritize cases by severity. You always note
        the time-sensitive nature of neurological emergencies."""),
    llm=llm,
    verbose=True,
)

attending_doctor = Agent(
    role="Emergency Medicine Physician",
    goal="Review triage findings and patient chart, form a working diagnosis, and create an immediate action plan.",
    backstory=dedent("""\
        You are a board-certified emergency medicine physician. You are
        experienced with acute neurological presentations and always consider
        time-critical interventions. You check medication interactions and
        contraindications carefully."""),
    llm=llm,
    verbose=True,
)

discharge_planner = Agent(
    role="Discharge Planning Coordinator",
    goal="Create a safe, clear discharge or admission plan that accounts for ALL findings and medications.",
    backstory=dedent("""\
        You are a clinical discharge coordinator who ensures patients leave
        with clear instructions. You check that every medication is accounted
        for, follow-up appointments are scheduled, and warning signs are
        explained in plain language the patient and family can understand."""),
    llm=llm,
    verbose=True,
)

# ===============================
# TASKS (each reads shared state + prior outputs)
# ===============================

# TASK 1 — Triage assessment
# The nurse reads from the shared patient chart ({field_name} placeholders)
triage_task = Task(
    description=dedent("""\
        Perform an emergency triage assessment for this patient.

        PATIENT CHART (shared state):
        - Name: {patient_name}, Age: {age}, Sex: {sex}
        - Chief Complaint: {chief_complaint}
        - Vitals: {vitals}
        - Medical History: {medical_history}
        - Allergies: {allergies}
        - Current Medications: {current_medications}
        - Initial Observations: {initial_observations}

        Provide:
        1. TRIAGE LEVEL (1-5 ESI scale) with justification
        2. KEY RED FLAGS identified
        3. TIME-CRITICAL concerns (especially given the 2-hour symptom window)
        4. Immediate actions taken (IV access, monitoring, etc.)
        5. Priority alerts for the attending physician
    """),
    agent=triage_nurse,
    expected_output=dedent("""\
        A structured triage report with ESI level, red flags, time-critical
        concerns, immediate nursing actions, and priority alerts."""),
)

# TASK 2 — Doctor assessment
# The doctor reads shared state AND the triage nurse's output (via context)
# This is MEMORY in action: context=[triage_task] passes prior output forward
doctor_task = Task(
    description=dedent("""\
        Review the triage nurse's assessment and the patient chart to form
        a working diagnosis and immediate action plan.

        PATIENT CHART (shared state):
        - Name: {patient_name}, Age: {age}, Sex: {sex}
        - Chief Complaint: {chief_complaint}
        - Vitals: {vitals}
        - Medical History: {medical_history}
        - Allergies: {allergies}
        - Current Medications: {current_medications}
        - Initial Observations: {initial_observations}

        Based on the triage findings AND the patient chart, provide:
        1. WORKING DIAGNOSIS with clinical reasoning
        2. DIFFERENTIAL DIAGNOSES (at least 3)
        3. IMMEDIATE ORDERS:
           - Imaging (consider CT head, CTA)
           - Labs (CBC, BMP, coagulation panel — especially INR given warfarin use)
           - Medications (consider: patient is on warfarin and allergic to aspirin)
        4. TIME-CRITICAL DECISIONS (e.g., thrombolytic eligibility window)
        5. MEDICATION SAFETY NOTES (interactions, contraindications)
    """),
    agent=attending_doctor,
    expected_output=dedent("""\
        A clinical assessment with working diagnosis, differentials,
        immediate orders, time-critical decisions, and medication safety notes."""),
    # MEMORY: receives triage nurse's output as context
    context=[triage_task],
)

# TASK 3 — Discharge / admission plan
# The planner reads shared state AND all prior outputs (via context)
# Demonstrates how state accumulates: triage → doctor → planner
discharge_task = Task(
    description=dedent("""\
        Based on ALL prior assessments and the patient chart, create either:
        (a) An ADMISSION plan if the patient requires inpatient care, or
        (b) A DISCHARGE plan if the patient can be safely released.

        PATIENT CHART (shared state):
        - Name: {patient_name}, Age: {age}, Sex: {sex}
        - Medical History: {medical_history}
        - Allergies: {allergies}
        - Current Medications: {current_medications}

        Your plan must include:
        1. DISPOSITION DECISION: Admit or Discharge (with reasoning)
        2. COMPLETE MEDICATION LIST (reconciled — account for any changes
           the doctor ordered, check for allergies and interactions)
        3. MONITORING PLAN (what to watch, how often)
        4. FOLLOW-UP APPOINTMENTS (specialty, timeframe)
        5. PATIENT & FAMILY INSTRUCTIONS (plain language):
           - What happened
           - What to watch for (warning signs)
           - When to call 911
           - Medication changes explained simply
    """),
    agent=discharge_planner,
    expected_output=dedent("""\
        A comprehensive admission or discharge plan with disposition decision,
        reconciled medication list, monitoring plan, follow-up schedule,
        and plain-language patient/family instructions."""),
    # MEMORY: receives BOTH prior task outputs as context
    context=[triage_task, doctor_task],
)

# ===============================
# CREW CONFIGURATION
# ===============================

crew = Crew(
    agents=[triage_nurse, attending_doctor, discharge_planner],
    tasks=[triage_task, doctor_task, discharge_task],
    process=Process.sequential,
    # NOTE: memory=False avoids requiring OpenAI API key for embeddings.
    # We achieve "memory" through task context passing instead.
    memory=False,
    verbose=True,
)

# ===============================
# EXECUTION
# ===============================

if __name__ == "__main__":
    print("=" * 70)
    print("MEMORY & SHARED STATE DEMO — Healthcare Patient Chart")
    print("=" * 70)
    print()
    print("SHARED STATE (Patient Chart):")
    print("-" * 40)
    for key, value in patient_chart.items():
        print(f"  {key}: {value}")
    print()

    # The patient_chart dict is passed as `inputs` — this is the SHARED STATE.
    # Every {field_name} in task descriptions gets replaced with the value.
    result = crew.kickoff(inputs=patient_chart)

    # Save output
    outputs_dir = Path(__file__).resolve().parent / "outputs"
    os.makedirs(outputs_dir, exist_ok=True)
    output_path = outputs_dir / "memory_state_healthcare.md"
    with open(output_path, "w") as f:
        f.write(str(result))

    print()
    print("=" * 70)
    print("FINAL RESULT — Patient Disposition Plan")
    print("=" * 70)
    print(result)
    print()
    print(f"Output saved to: {output_path}")

"""
HOW SHARED STATE AND MEMORY WORK IN THIS DEMO:

┌─────────────────────────────────────────────────────────────┐
│                  SHARED STATE (patient_chart)                │
│  Passed via crew.kickoff(inputs=patient_chart)              │
│  Every agent can read: name, vitals, meds, allergies, etc.  │
└──────────┬──────────────────┬──────────────────┬────────────┘
           │                  │                  │
           ▼                  ▼                  ▼
    ┌─────────────┐   ┌─────────────┐   ┌─────────────────┐
    │ Triage Nurse│──▶│   Doctor    │──▶│Discharge Planner│
    │ (Task 1)    │   │ (Task 2)    │   │ (Task 3)         │
    │             │   │             │   │                   │
    │ Reads:      │   │ Reads:      │   │ Reads:            │
    │ - state     │   │ - state     │   │ - state           │
    │             │   │ - Task 1 out│   │ - Task 1 out      │
    │ Writes:     │   │             │   │ - Task 2 out      │
    │ - triage    │   │ Writes:     │   │                   │
    │   report    │   │ - diagnosis │   │ Writes:           │
    └─────────────┘   │ - orders    │   │ - disposition plan│
                      └─────────────┘   └─────────────────┘

STATE = patient_chart dict → injected into task descriptions via {placeholders}
MEMORY = context parameter → each task receives prior task outputs

This mirrors real healthcare:
- The patient chart (EHR) is the shared state — all providers read it
- Each provider adds their notes — building on what came before
- The discharge planner sees EVERYTHING — full continuity of care
"""
