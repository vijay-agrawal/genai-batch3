"""
Memory Isolation Pattern — Clinical Trial Data Privacy

================================================================================
MEMORY ISOLATION PATTERN:
================================================================================
In multi-agent systems, not every agent should see everything. Memory isolation
ensures each agent only accesses data appropriate for its role.

WHY IT MATTERS:
- Patient privacy (HIPAA): identifiable data must be restricted
- Clinical trial blinding: researchers must not see treatment assignments
- Regulatory compliance: safety monitors have specific data access rules
- Separation of duties: prevents bias and conflicts of interest

HOW THIS DEMO IMPLEMENTS ISOLATION:
Since CrewAI's `memory` parameter is a boolean (True/False) and does not
support per-agent memory objects, we achieve isolation through:

  1. SELECTIVE INPUT DATA: Each agent's task description includes ONLY the
     data fields that agent is authorized to see
  2. SELECTIVE CONTEXT: The `context` parameter controls which prior task
     outputs flow to which downstream tasks
  3. EXPLICIT REDACTION: Sensitive fields are deliberately excluded from
     task descriptions that shouldn't see them

This mirrors real clinical trial systems where database views restrict
what each role can query.

================================================================================
DEMO DESCRIPTION — What This Script Does:
================================================================================
Scenario: A Phase III clinical trial for a new heart failure medication.
Three agents process trial data, each with different access levels:

  1. Biostatistician   — Sees DE-IDENTIFIED outcomes data (no patient names,
                         no treatment arm assignments). Analyzes efficacy.
  2. Safety Monitor    — Sees adverse events WITH patient IDs (for safety
                         tracking) but NOT treatment arm assignments
                         (to maintain blinding).
  3. Trial Coordinator — Receives SUMMARIES from both agents, creates a
                         combined status report. Does NOT see raw patient
                         data directly.

Data flow:
  Biostatistician ──(efficacy summary)──┐
                                        ├──▶ Trial Coordinator
  Safety Monitor ──(safety summary)─────┘

================================================================================
FRAMEWORKS & TECHNOLOGIES USED:
================================================================================
Framework: CrewAI (Multi-agent orchestration)
  - Agent: Role-based specialists with restricted data views
  - Task: Selective context passing enforces data boundaries
  - Crew: Sequential process with controlled information flow

LLM Model: Google Gemini 2.0 Flash
  - Model ID: gemini/gemini-2.0-flash
  - Temperature: 0.7

Environment Configuration:
  - Uses .env file for API keys (GEMINI_API_KEY)
  - Automatic credential path resolution for Google Cloud authentication
================================================================================
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process, LLM
from textwrap import dedent
import warnings

warnings.filterwarnings('ignore')

# ---------------------------------------------------------------------------
# Environment setup (same pattern as demos 01, 02, 03, 05, 09)
# ---------------------------------------------------------------------------

def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    return Path(__file__).resolve().parent

PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    print("ERROR: GEMINI_API_KEY not found in environment variables.")
    print("Please add GEMINI_API_KEY to your .env file.")
    exit(1)

llm = LLM(
    model="gemini/gemini-2.0-flash",
    api_key=GEMINI_API_KEY,
    temperature=0.7
)
print(f"Using Gemini model: gemini/gemini-2.0-flash")

# =============================================================================
# TRIAL DATA — Simulated clinical trial dataset
# =============================================================================
# In a real system these would come from a clinical trial database with
# role-based access controls. Here we store everything in one place and
# selectively expose fields to each agent via their task descriptions.

# --- DATA VISIBLE TO BIOSTATISTICIAN (de-identified, blinded) ---------------
# No patient names, no treatment arm labels (just Arm A / Arm B)
DEIDENTIFIED_OUTCOMES = dedent("""\
    CARDIOPROTECT-HF Phase III Trial — De-identified Outcomes (Week 24)
    Total Enrolled: 480 patients (240 per arm)

    PRIMARY ENDPOINT — 6-Minute Walk Distance (6MWD) change from baseline:
      Arm A (n=240): Mean change +58m (SD 32), 95% CI [54, 62]
      Arm B (n=240): Mean change +21m (SD 28), 95% CI [17, 25]
      Between-group difference: 37m, p < 0.001

    SECONDARY ENDPOINTS:
      NT-proBNP reduction:
        Arm A: -42% median reduction
        Arm B: -14% median reduction (p < 0.001)
      NYHA class improvement (≥1 class):
        Arm A: 64% of patients improved
        Arm B: 31% of patients improved (p < 0.001)
      Heart failure hospitalization rate (24 weeks):
        Arm A: 8.3% (20/240)
        Arm B: 16.7% (40/240), HR 0.47 (p = 0.006)

    SUBGROUP ANALYSES:
      Age ≥65: Treatment effect consistent (interaction p = 0.42)
      Diabetes subgroup: Slightly attenuated effect (interaction p = 0.08)
      Baseline LVEF <30%: Enhanced benefit (interaction p = 0.03)
""")

# --- DATA VISIBLE TO SAFETY MONITOR (has patient IDs, NO arm labels) --------
# Safety monitor sees adverse events with patient IDs for tracking,
# but does NOT know which arm each patient is in (maintains blinding)
ADVERSE_EVENTS_DATA = dedent("""\
    CARDIOPROTECT-HF Phase III Trial — Adverse Events Report (Week 24)
    Data Safety Monitoring Board (DSMB) Review

    SERIOUS ADVERSE EVENTS (SAEs):
      Patient PT-0042: Acute kidney injury (Day 45), hospitalized 4 days, recovered
      Patient PT-0118: Symptomatic hypotension (Day 30), dose reduced, resolved
      Patient PT-0205: Hyperkalemia K+ 6.2 mEq/L (Day 60), treated, resolved
      Patient PT-0287: Syncope (Day 15), ER visit, no recurrence after dose adjustment
      Patient PT-0331: Hepatic enzyme elevation ALT 3x ULN (Day 90), drug held, normalized
      Patient PT-0419: Fatal MI (Day 112) — adjudication committee review pending

    ADVERSE EVENT SUMMARY (all grades):
      Hypotension: 18.5% overall (need per-arm breakdown from unblinded statistician)
      Dizziness: 22.1% overall
      Renal function decline (>30% eGFR drop): 7.3% overall
      Hyperkalemia (K+ >5.5): 5.4% overall
      Hepatic enzyme elevation: 3.1% overall
      GI symptoms (nausea/diarrhea): 14.6% overall

    DEATHS: 3 total (causes: 1 MI, 1 stroke, 1 non-cardiac) — all under review
    DROPOUTS: 38 total (7.9%) — 22 for adverse events, 16 for non-medical reasons

    ALERT: The fatal MI (PT-0419) and overall hypotension rate warrant
    committee discussion on whether dose-adjustment protocol is adequate.
""")

# --- DATA VISIBLE ONLY TO COORDINATOR (operational, no patient data) ---------
OPERATIONAL_STATUS = dedent("""\
    CARDIOPROTECT-HF Phase III Trial — Operational Status
    Sponsor: CardioPharm Inc.
    ClinicalTrials.gov: NCT-EXAMPLE-2024

    ENROLLMENT: 480/480 (100% target met)
    ACTIVE SITES: 28 sites across 6 countries
    CURRENT PHASE: Week 24 primary endpoint analysis
    DATABASE LOCK: Completed 2 weeks ago
    NEXT MILESTONE: Interim analysis presentation to DSMB
    REGULATORY: FDA pre-NDA meeting scheduled in 3 months
""")

# =============================================================================
# AGENTS — Each has a specific role with restricted data access
# =============================================================================

biostatistician = Agent(
    role="Clinical Trial Biostatistician",
    goal="Analyze de-identified efficacy outcomes and provide statistical interpretation. You must NEVER attempt to unblind treatment arms or identify patients.",
    backstory=dedent("""\
        You are a PhD biostatistician working on a Phase III heart failure
        trial. You receive only de-identified, blinded data (Arm A vs Arm B).
        You do not know which arm is drug vs placebo. You focus purely on
        statistical significance, effect sizes, and clinical meaningfulness.
        You flag any subgroup findings that need further investigation."""),
    llm=llm,
    verbose=True,
)

safety_monitor = Agent(
    role="Data Safety Monitoring Board Member",
    goal="Review adverse events for safety signals and recommend whether the trial should continue, be modified, or be stopped. You must NOT access efficacy data or treatment arm assignments.",
    backstory=dedent("""\
        You are an independent physician on the DSMB. You review adverse
        events and safety data. You have access to patient IDs for tracking
        purposes but you do NOT know which treatment arm patients are in
        (to maintain blinding). You assess whether the safety profile is
        acceptable and flag any signals that require urgent action."""),
    llm=llm,
    verbose=True,
)

trial_coordinator = Agent(
    role="Clinical Trial Coordinator",
    goal="Compile a combined trial status report from efficacy and safety summaries, without accessing raw patient data.",
    backstory=dedent("""\
        You are the trial coordinator responsible for compiling status
        reports for the sponsor. You receive SUMMARIES from the
        biostatistician and safety monitor but you do NOT have direct
        access to patient-level data. You synthesize their findings into
        a coherent report and flag any issues that need sponsor attention."""),
    llm=llm,
    verbose=True,
)

# =============================================================================
# TASKS — Data isolation enforced by what each task description contains
# =============================================================================

# TASK 1 — Biostatistician: sees ONLY de-identified outcomes
# ISOLATION: No patient names, no treatment arm labels, no adverse events
efficacy_analysis = Task(
    description=dedent(f"""\
        Analyze the following de-identified efficacy data from the
        CARDIOPROTECT-HF trial. You are blinded — Arm A and Arm B are
        labels only; you do not know which is drug and which is placebo.

        IMPORTANT DATA ACCESS RESTRICTION:
        You have access ONLY to efficacy outcomes below. You do NOT have
        access to adverse event data, patient identifiers, or treatment
        arm unblinding.

        DE-IDENTIFIED OUTCOMES DATA:
        {DEIDENTIFIED_OUTCOMES}

        Provide:
        1. STATISTICAL ASSESSMENT of primary endpoint (is it clinically meaningful?)
        2. SECONDARY ENDPOINT interpretation
        3. SUBGROUP FINDINGS that warrant attention
        4. OVERALL EFFICACY CONCLUSION (strong/moderate/weak evidence)
        5. LIMITATIONS and caveats in the data

        Do NOT speculate about which arm is drug vs placebo.
    """),
    agent=biostatistician,
    expected_output=dedent("""\
        A statistical analysis report covering primary endpoint assessment,
        secondary endpoints, subgroup findings, overall efficacy conclusion,
        and study limitations."""),
)

# TASK 2 — Safety Monitor: sees adverse events WITH patient IDs, NO arm labels
# ISOLATION: Has patient IDs (for safety tracking) but NO efficacy data,
#            NO treatment arm assignments (blinded)
safety_review = Task(
    description=dedent(f"""\
        Review the following adverse events data from the CARDIOPROTECT-HF
        trial. You are an independent DSMB member.

        IMPORTANT DATA ACCESS RESTRICTION:
        You can see patient IDs for safety tracking, but you do NOT have
        access to: (1) which treatment arm each patient is in, (2) efficacy
        outcomes, or (3) the biostatistician's analysis. This maintains
        your independence and blinding.

        ADVERSE EVENTS DATA:
        {ADVERSE_EVENTS_DATA}

        Provide:
        1. SAFETY SIGNAL ASSESSMENT: Are any adverse events concerning?
        2. SPECIFIC PATIENT CONCERNS: Which cases need follow-up?
        3. RISK-BENEFIT PRELIMINARY VIEW (based on safety data alone)
        4. RECOMMENDATION: Continue / Modify protocol / Pause enrollment / Stop trial
        5. URGENT ACTIONS needed (if any)

        You must base your recommendation ONLY on safety data. Do NOT
        request or speculate about efficacy results.
    """),
    agent=safety_monitor,
    expected_output=dedent("""\
        A safety review with signal assessment, patient-specific concerns,
        risk-benefit view, trial continuation recommendation, and any
        urgent actions needed."""),
)

# TASK 3 — Trial Coordinator: sees SUMMARIES only, NO raw patient data
# ISOLATION: Receives prior task outputs via context (summaries),
#            plus operational data. Does NOT see raw patient-level data.
combined_report = Task(
    description=dedent(f"""\
        Compile a combined trial status report using the biostatistician's
        efficacy summary and the safety monitor's review.

        IMPORTANT DATA ACCESS RESTRICTION:
        You receive SUMMARIES from the biostatistician and safety monitor
        (via their task outputs). You do NOT have access to raw patient
        data, individual adverse events, or patient identifiers.
        If either summary references patient IDs, do NOT include them
        in your report.

        OPERATIONAL STATUS (your direct data):
        {OPERATIONAL_STATUS}

        Using the efficacy and safety summaries provided, create:
        1. EXECUTIVE SUMMARY (3-5 bullet points)
        2. EFFICACY HIGHLIGHTS (from biostatistician's summary)
        3. SAFETY HIGHLIGHTS (from safety monitor's summary)
        4. KEY RISKS AND CONCERNS
        5. RECOMMENDED NEXT STEPS for the sponsor
        6. ITEMS REQUIRING SPONSOR DECISION

        REDACTION RULE: If any patient identifiers appear in the summaries
        you received, replace them with [REDACTED] in your report.
    """),
    agent=trial_coordinator,
    expected_output=dedent("""\
        A combined trial status report with executive summary, efficacy
        and safety highlights, risks, recommended next steps, and items
        requiring sponsor decision. No patient identifiers included."""),
    # MEMORY: Coordinator sees BOTH prior summaries
    context=[efficacy_analysis, safety_review],
)

# =============================================================================
# CREW CONFIGURATION
# =============================================================================

crew = Crew(
    agents=[biostatistician, safety_monitor, trial_coordinator],
    tasks=[efficacy_analysis, safety_review, combined_report],
    process=Process.sequential,
    # memory=False: we handle isolation manually via selective task descriptions
    memory=False,
    verbose=True,
)

# =============================================================================
# EXECUTION
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("MEMORY ISOLATION DEMO — Clinical Trial Data Privacy")
    print("=" * 70)
    print()
    print("DATA ACCESS BOUNDARIES:")
    print("-" * 40)
    print("  Biostatistician  : De-identified outcomes ONLY (no patient IDs, no AEs)")
    print("  Safety Monitor   : Adverse events + patient IDs (no efficacy, no arm labels)")
    print("  Trial Coordinator: Summaries ONLY (no raw patient data)")
    print()
    print("  ┌──────────────────┐       ┌────────────────┐")
    print("  │ Biostatistician  │       │ Safety Monitor  │")
    print("  │ Sees: outcomes   │       │ Sees: AEs + IDs │")
    print("  │ Blind: arms      │       │ Blind: arms     │")
    print("  │ No: AEs, IDs     │       │ No: efficacy    │")
    print("  └───────┬──────────┘       └───────┬─────────┘")
    print("          │ summary                  │ summary")
    print("          └──────────┐   ┌───────────┘")
    print("                     ▼   ▼")
    print("              ┌─────────────────┐")
    print("              │Trial Coordinator │")
    print("              │ Sees: summaries  │")
    print("              │ No: raw data     │")
    print("              └─────────────────┘")
    print()

    result = crew.kickoff()

    # Save output
    outputs_dir = Path(__file__).resolve().parent / "outputs"
    os.makedirs(outputs_dir, exist_ok=True)
    output_path = outputs_dir / "memory_isolation_clinical_trial.md"
    with open(output_path, "w") as f:
        f.write(str(result))

    print()
    print("=" * 70)
    print("FINAL RESULT — Combined Trial Status Report")
    print("=" * 70)
    print(result)
    print()
    print(f"Output saved to: {output_path}")

"""
MEMORY ISOLATION — HOW IT WORKS IN THIS DEMO:

┌─────────────────────────────────────────────────────────────────────┐
│                    FULL TRIAL DATABASE                              │
│  (In reality: role-based database views restrict access)           │
│                                                                     │
│  Patient IDs ── Outcomes ── Adverse Events ── Treatment Arms       │
└─────┬──────────────┬──────────────┬──────────────┬─────────────────┘
      │              │              │              │
      │    ┌─────────┘              │              │
      │    │                        │              │
      │    ▼                        ▼              │
      │  ┌─────────────┐    ┌────────────────┐    │
      │  │Biostatistician│   │ Safety Monitor │    │
      │  │              │    │               │    │
      │  │ ✓ Outcomes   │    │ ✓ AEs         │    │
      │  │ ✗ Patient IDs│    │ ✓ Patient IDs │    │
      │  │ ✗ AEs        │    │ ✗ Outcomes    │    │
      │  │ ✗ Arm labels │    │ ✗ Arm labels  │    │
      │  └──────┬───────┘    └──────┬────────┘    │
      │         │ summary           │ summary     │
      │         └──────┐   ┌───────┘              │
      │                ▼   ▼                      │
      │        ┌─────────────────┐                │
      │        │Trial Coordinator│                │
      │        │                 │                │
      │        │ ✓ Summaries     │                │
      │        │ ✓ Operational   │                │
      │        │ ✗ Raw patient   │                │
      │        │ ✗ Arm labels    │                │
      │        └─────────────────┘                │
      │                                           │
      │          NOBODY SEES ─────────────────────┘
      │          (Treatment arm unblinding is locked
      │           until the DSMB formally requests it)
      │
      └── Patient IDs: ONLY safety monitor (for AE tracking)

IMPLEMENTATION TECHNIQUE:
- Each task description explicitly includes ONLY the data that agent should see
- The `context` parameter controls which task outputs flow downstream
- This is analogous to database views / row-level security in a real CTMS
- CrewAI's memory parameter is boolean; true isolation requires controlling
  what data enters each task description

REAL-WORLD PARALLEL:
This mirrors FDA 21 CFR Part 11 and ICH-GCP guidelines where:
- Biostatisticians work with de-identified datasets
- DSMBs review safety independently from efficacy
- Sponsors receive combined reports (not raw data)
- Treatment arm unblinding requires formal DSMB vote
"""
