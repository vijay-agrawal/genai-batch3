#!/usr/bin/env python3
import os, pandas as pd
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from textwrap import dedent


"""
SUPERVISOR-WORKER PATTERN EXPLANATION:
This pattern follows a hierarchical structure where:
1. One supervisor agent coordinates and delegates work to multiple worker agents
2. Worker agents perform specialized tasks independently
3. The supervisor reviews all outputs and makes final decisions
4. Communication flows top-down (delegation) and bottom-up (reporting)
"""


load_dotenv()
MODEL = os.getenv("MODEL_NAME","gpt-4o-mini")

# --- Tools (local, simple) ---
def load_apps():
    return pd.read_csv("data/credit_applications.csv")

def compute_basic_metrics(df):
    df = df.copy()
    df["dti"] = (df["debt"] / df["income"]).round(2)
    df["risk_flag"] = ((df["fico"]<620) | (df["dti"]>0.6) | (df["delinq_12m"]>1)).astype(int)
    return df

# --- Agents ---
supervisor = Agent(
    role="Credit Risk Supervisor",
    goal="Oversee quick risk triage and ensure clear, auditable outputs.",
    backstory="20 years in retail credit, cares about explainability and policy adherence.",
    allow_delegation=True,
    model=MODEL,
)

analyst = Agent(
    role="Credit Data Analyst",
    goal="Compute KPIs (DTI, delinquency risk) and summarize applicant-level insights.",
    backstory="Hands-on analyst who works in pandas and keeps things crisp.",
    allow_delegation=False,
    model=MODEL,
)

writer = Agent(
    role="Risk Report Writer",
    goal="Draft a 1-page triage report with recommendations and policy rationale.",
    backstory="Ex-underwriter who writes clearly for risk committees.",
    allow_delegation=False,
    model=MODEL,
)

# --- Tasks ---
task1 = Task(
    description=dedent("""\
    Load `data/credit_applications.csv`, compute DTI and a simple risk flag:
    - DTI = debt/income (round to 2 decimals)
    - Risk flag = 1 if (FICO<620) OR (DTI>0.6) OR (delinq_12m>1) else 0
    Return a compact markdown table with columns: app_id, fico, dti, delinq_12m, risk_flag.
    """),
    agent=analyst,
    expected_output="Markdown table with computed KPIs."
)

task2 = Task(
    description=dedent("""\
    Using the analyst's KPIs, produce a crisp risk triage note:
    - Who is high risk and why (bullet list with rationale)
    - Who is borderline (if any) and what to verify
    - Portfolio summary: % high risk, average DTI, average FICO
    Keep it under 200 words.
    """),
    agent=writer,
    expected_output="Short risk triage note with bullets and a tiny summary."
)

task3 = Task(
    description=dedent("""\
    Review and finalize the triage for auditability:
    - Check that rationale aligns with the rule
    - Add a final 'Approve / Review / Decline' recommendation per app_id
    Output a final markdown report. 
    """),
    agent=supervisor,
    expected_output="Final markdown triage report with recommendations."
)

crew = Crew(
    agents=[supervisor, analyst, writer],
    tasks=[task1, task2, task3],
    process=Process.sequential
)

if __name__ == "__main__":
    df = compute_basic_metrics(load_apps())
    # Place the table into the first task context so the LLM can reference it
    task1.context = [df.to_markdown(index=False)]
    result = crew.kickoff()
    os.makedirs("outputs", exist_ok=True)
    with open("outputs/bfs_credit_risk_report.md","w") as f: f.write(str(result))
    print("=== BFSI Supervisor–Worker Final Report ===")
    print(result)
