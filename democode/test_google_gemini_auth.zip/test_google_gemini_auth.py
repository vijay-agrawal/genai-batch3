import os
import warnings
# Ignore all warnings 
warnings.filterwarnings('ignore')
import vertexai
import requests
from dotenv import load_dotenv
from vertexai.generative_models import GenerativeModel, Part

# --- Step 1: Load Environment Variables ---
# This MUST be done before importing/using the vertexai library
# It loads the GOOGLE_APPLICATION_CREDENTIALS from your .env file
load_dotenv()

# --- Step 2: Set Your Project Details ---
# Replace with your actual project ID and location
PROJECT_ID = os.getenv("GOOGLE_VERTEXAI_PROJECT_ID", "your-gcp-project-id")  
LOCATION = os.getenv("GOOGLE_VERTEXAI_LOCATION", "us-central1")  # e.g., "us-central1"

# --- Step 2.5: Check Who You Are (Auth Check) ---
print("\n--- Authentication Check ---")
import google.auth
import google.auth.transport.requests
import requests

# --- Helper Function to Get Email ---
def get_authenticated_email():
    try:
        # 1. Get the basic credentials
        creds, project = google.auth.default()

        # 2. Check if it's a Service Account (easy case)
        if hasattr(creds, "service_account_email"):
            return creds.service_account_email

        # 3. If it's a User Account, we must "refresh" to get a token
        #    and then query the Google API to find the email.
        auth_req = google.auth.transport.requests.Request()
        creds.refresh(auth_req) # Ensure we have a valid token
        
        # 4. Use the token to ask Google who we are
        token = creds.token
        response = requests.get(
            "https://www.googleapis.com/oauth2/v1/userinfo",
            headers={"Authorization": f"Bearer {token}"}
        )
        
        if response.status_code == 200:
            return response.json().get('email')
        else:
            return f"Unknown User (API returned {response.status_code})"

    except Exception as e:
        return f"Could not determine user: {str(e)}"

# --- Step 2: Print Identity ---
print(f"Logged in as: {get_authenticated_email()}")
print(f"Target Project: {PROJECT_ID}")
try:
    # google.auth.default() looks for credentials in the same order as Vertex AI
    credentials, auth_project_id = google.auth.default()
    
    # CASE A: Service Account (common in production/scripts)
    if hasattr(credentials, "service_account_email"):
        print(f"Logged in as Service Account: {credentials.service_account_email}")
        
    # CASE B: User Credentials (local development/ADC)
    # The email is often not directly stored in the object for User Creds, 
    # but we can infer the type.
    else:
        print("Logged in with Application Default Credentials).")
        print(f"Credential Type: {type(credentials).__name__}")
        

except Exception as e:
    print(f"Could not determine auth identity: {e}")

# --- Step 3: Initialize Vertex AI ---
# The client automatically uses the credentials
# loaded from the .env file
try:
    vertexai.init(project=PROJECT_ID, location=LOCATION)
except Exception as e:
    print(f"Error initializing Vertex AI: {e}")
    print("Please ensure your PROJECT_ID and LOCATION are correct and you have enabled the Vertex AI API.")
    exit()
# --- Step 4: Define Prompts and Load the Model ---
print("Vertex AI Initialization Successful.")

# Define your system prompt (the model's instructions)
system_prompt = "You are a helpful AI assistant."

# Define your user prompt (the user's question)
user_prompt = "What is the capital of France? Answer in one word."

# Load the generative model and pass the system prompt
try:
    model = GenerativeModel(
        "gemini-2.5-flash",
        system_instruction=system_prompt
    )

    # --- Step 5: Send the User Prompt ---
    # Send only the user's prompt to generate_content
    response = model.generate_content(user_prompt)
    
    # Print the text response
    if "paris" in response.text.lower():
        print("Gemini 2.5 Flash Model is accessible and operational.")
    else:
        print("Gemini 2.5 Flash Model responded, but the answer was unexpected:\n")
        print(f"Model Response: {response.text}")
except Exception as e:
    print(f"An error occurred while accessing the model: {e}")
print("Script finished.")
