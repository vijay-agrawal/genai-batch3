import requests
import os
from pathlib import Path
from dotenv import load_dotenv
import vertexai
from vertexai.generative_models import GenerativeModel, Tool, FunctionDeclaration


def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env or google-vertexai-serviceaccount-key.json in any parent directory.")
    print(f"Started searching from: {Path(__file__).resolve().parent}")
    exit(1)


# Load environment variables from project root
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Resolve relative credential paths to absolute
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

# Get project configuration
PROJECT_ID = os.getenv("GOOGLE_VERTEXAI_PROJECT_ID", os.getenv("PROJECT_ID", "gen-ai-training-476514"))
LOCATION = os.getenv("GOOGLE_VERTEXAI_LOCATION", os.getenv("LOCATION", "us-central1"))


# Define these functions OUTSIDE of main() at the module level
def get_weather(location: str) -> str:
    """Retrieve real-time weather information about a particular location."""
    print("Getting weather for: " + location)
    url = "http://api.openweathermap.org/geo/1.0/direct?q=" + location + "&limit=1&appid=" + os.getenv("OPENWEATHERMAP_API_KEY")
    response = requests.get(url, verify=False)
    print(response)
    get_response = response.json()

    if not get_response:
        return f"Could not find location: {location}"

    latitude = get_response[0]['lat']
    longitude = get_response[0]['lon']

    url_final = "https://api.openweathermap.org/data/2.5/weather?lat=" + str(latitude) + "&lon=" + \
        str(longitude) + "&appid=" + os.getenv("OPENWEATHERMAP_API_KEY") + "&units=metric"
    final_response = requests.get(url_final, verify=False)
    final_response_json = final_response.json()

    weather = (f"Weather: {final_response_json['weather'][0]['description']}\n"
               f"Temperature: {final_response_json['main']['temp']}°C\n"
               f"Humidity: {final_response_json['main']['humidity']}%")
    print(weather)
    return weather


def get_latlong(location: str) -> str:
    """Retrieve latitude and longitude for a particular location."""
    print("Getting lat/long for: " + location)
    url = "http://api.openweathermap.org/geo/1.0/direct?q=" + location + "&limit=1&appid=" + os.getenv("OPENWEATHERMAP_API_KEY")
    response = requests.get(url, verify=False)
    print(response)
    get_response = response.json()

    if not get_response:
        return f"Could not find location: {location}"

    latitude = get_response[0]['lat']
    longitude = get_response[0]['lon']

    result = f"Latitude: {latitude}, Longitude: {longitude}"
    print(result)
    return result


def main():
    # Initialize Vertex AI
    vertexai.init(project=PROJECT_ID, location=LOCATION)
    print(f"Initialized Vertex AI with project: {PROJECT_ID}, location: {LOCATION}")

    # Define function declarations for Gemini
    get_weather_func = FunctionDeclaration(
        name="get_weather",
        description="Retrieve real-time weather information/data about a particular location/place",
        parameters={
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "The exact location whose real-time weather is to be determined"
                }
            },
            "required": ["location"]
        }
    )

    get_latlong_func = FunctionDeclaration(
        name="get_latlong",
        description="Retrieve latitude and longitude information about a particular location/place",
        parameters={
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "The exact location whose latitude and longitude is to be determined"
                }
            },
            "required": ["location"]
        }
    )

    # Create a Tool with all function declarations
    weather_tool = Tool(function_declarations=[get_weather_func, get_latlong_func])

    # Initialize the model with tools
    model = GenerativeModel(
        "gemini-2.5-flash",
        tools=[weather_tool],
        system_instruction="You are a helpful weather assistant."
    )

    # Start a chat session
    chat = model.start_chat()

    # Send user message
    user_message = "How is the weather in Mumbai?"
    print(f"\nUser: {user_message}")

    response = chat.send_message(user_message)

    # Check if the model wants to call a function
    if response.candidates[0].content.parts[0].function_call:
        function_call = response.candidates[0].content.parts[0].function_call
        function_name = function_call.name
        function_args = dict(function_call.args)

        print(f"\nLLM returned a function call response for: {function_name}")
        print(f"Arguments: {function_args}")

        # Call the function dynamically by name
        try:
            result = globals()[function_name](**function_args)
        except KeyError:
            result = f"Unknown function: {function_name}"

        print(f"\nFunction result: {result}")

        # Send the function result back to the model
        from vertexai.generative_models import Part

        response = chat.send_message(
            Part.from_function_response(
                name=function_name,
                response={"result": result}
            )
        )

        # Get the final response
        final_response = response.candidates[0].content.parts[0].text
        print(f"\nAssistant: {final_response}")
    else:
        # Model returned a direct response
        print(f"\nAssistant: {response.candidates[0].content.parts[0].text}")


if __name__ == "__main__":
    main()
