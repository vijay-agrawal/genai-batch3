import json
import requests
import urllib3
from openai import OpenAI
from pathlib import Path
from dotenv import load_dotenv
import os

# Suppress InsecureRequestWarning when using verify=False
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

system_prompt = "You are a helpful weather assistant."
user_prompt = "How is the weather in Mumbai?"


def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env or google-vertexai-serviceaccount-key.json in any parent directory.")
    print(f"Started searching from: {Path(__file__).resolve().parent}")
    exit(1)


# Load environment variables from project root
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")


def get_weather(location: str) -> str:
    """Retrieve real-time weather information about a particular location."""
    print("Getting weather for: " + location)
    url = "http://api.openweathermap.org/geo/1.0/direct?q=" + location + "&limit=1&appid=" + os.getenv("OPENWEATHERMAP_API_KEY")
    response = requests.get(url, verify=False)
    print(response)
    get_response = response.json()

    if not get_response:
        return f"Could not find location: {location}"

    latitude = get_response[0]['lat']
    longitude = get_response[0]['lon']

    url_final = "https://api.openweathermap.org/data/2.5/weather?lat=" + str(latitude) + "&lon=" + \
        str(longitude) + "&appid=" + os.getenv("OPENWEATHERMAP_API_KEY") + "&units=metric"
    final_response = requests.get(url_final, verify=False)
    final_response_json = final_response.json()

    weather = (f"Weather: {final_response_json['weather'][0]['description']}\n"
               f"Temperature: {final_response_json['main']['temp']}°C\n"
               f"Humidity: {final_response_json['main']['humidity']}%")
    print(weather)
    return weather


def get_latlong(location: str) -> str:
    """Retrieve latitude and longitude for a particular location."""
    print("Getting lat/long for: " + location)
    url = "http://api.openweathermap.org/geo/1.0/direct?q=" + location + "&limit=1&appid=" + os.getenv("OPENWEATHERMAP_API_KEY")
    response = requests.get(url, verify=False)
    print(response)
    get_response = response.json()

    if not get_response:
        return f"Could not find location: {location}"

    latitude = get_response[0]['lat']
    longitude = get_response[0]['lon']

    result = f"Latitude: {latitude}, Longitude: {longitude}"
    print(result)
    return result


def main():
    # Create Gemini client using OpenAI-compatible API
    client = OpenAI(
        api_key=os.getenv("GOOGLE_VERTEXAI_API_KEY"),
        base_url="https://generativelanguage.googleapis.com/v1beta/openai/"
    )

    # Define tools (functions) for the model
    tools = [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Retrieve real-time weather information/data about a particular location/place",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "The exact location whose real-time weather is to be determined"
                        }
                    },
                    "required": ["location"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "get_latlong",
                "description": "Retrieve latitude and longitude information about a particular location/place",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "The exact location whose latitude and longitude is to be determined"
                        }
                    },
                    "required": ["location"]
                }
            }
        }
    ]

    # Initial messages
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ]

    print("System: " + system_prompt)
    print("User: " + user_prompt)

    # First API call - model may request a function call
    initial_response = client.chat.completions.create(
        model="gemini-2.0-flash",
        messages=messages,
        tools=tools
    )

    assistant_message = initial_response.choices[0].message

    # Check if the model wants to call a function
    if assistant_message.tool_calls:
        tool_call = assistant_message.tool_calls[0]
        function_name = tool_call.function.name
        function_args = json.loads(tool_call.function.arguments)

        print(f"\nLLM returned a function call response for: {function_name}")
        print(f"Arguments: {function_args}")

        # Call the function dynamically by name
        try:
            result = globals()[function_name](**function_args)
        except KeyError:
            result = f"Unknown function: {function_name}"

        print(f"\nFunction result: {result}")

        # Add assistant message and function result to conversation
        messages.append(assistant_message)
        messages.append({
            "role": "tool",
            "tool_call_id": tool_call.id,
            "content": result
        })

        # Second API call - send function result back to model for final response
        final_response = client.chat.completions.create(
            model="gemini-2.0-flash",
            messages=messages,
            tools=tools
        )

        final_answer = final_response.choices[0].message.content
        print(f"\nAssistant: {final_answer}")
    else:
        # Model returned a direct response (no function call)
        print(f"\nAssistant: {assistant_message.content}")


if __name__ == "__main__":
    main()
