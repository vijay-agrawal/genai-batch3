import json
import os
import requests
from pathlib import Path
from dotenv import load_dotenv
import streamlit as st
import vertexai
from vertexai.generative_models import GenerativeModel, Tool, FunctionDeclaration, Part


def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env or google-vertexai-serviceaccount-key.json in any parent directory.")
    print(f"Started searching from: {Path(__file__).resolve().parent}")
    exit(1)


# Load environment variables from project root
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Resolve relative credential paths to absolute
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

# Get project configuration
PROJECT_ID = os.getenv("GOOGLE_VERTEXAI_PROJECT_ID", os.getenv("PROJECT_ID", "gen-ai-training-476514"))
LOCATION = os.getenv("GOOGLE_VERTEXAI_LOCATION", os.getenv("LOCATION", "us-central1"))
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

# Initialize Vertex AI
vertexai.init(project=PROJECT_ID, location=LOCATION)

# App title
st.title("Weather Assistant - Umbrella Advisor (Gemini)")
st.markdown("Ask me if you should carry an umbrella tomorrow!")

# Initialize chat history in session state if it doesn't exist
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])


# Function to get weather data
def get_weather(location: str) -> dict:
    """Get weather forecast for a location."""
    print(f"Getting weather for location: {location}")

    # Get latitude and longitude from location name
    geo_url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={OPENWEATHERMAP_API_KEY}"
    geo_response = requests.get(geo_url)

    if geo_response.status_code != 200:
        return {"error": f"Could not retrieve location data. Status code: {geo_response.status_code}"}

    geo_data = geo_response.json()
    if not geo_data:
        return {"error": f"Location '{location}' not found."}

    latitude = geo_data[0]['lat']
    longitude = geo_data[0]['lon']

    # Get current weather data
    weather_url = f"http://api.openweathermap.org/data/2.5/forecast?lat={latitude}&lon={longitude}&appid={OPENWEATHERMAP_API_KEY}&units=metric"
    weather_response = requests.get(weather_url)

    if weather_response.status_code != 200:
        return {"error": f"Could not retrieve weather data. Status code: {weather_response.status_code}"}

    weather_data = weather_response.json()

    # Extract tomorrow's weather data (assuming forecast entries are in 3-hour intervals)
    tomorrow_forecasts = []
    for forecast in weather_data['list'][:8]:  # First 24 hours (8 entries of 3 hours each)
        forecast_time = forecast['dt_txt']
        description = forecast['weather'][0]['description']
        rain_probability = forecast.get('pop', 0) * 100  # Probability of precipitation

        tomorrow_forecasts.append({
            'time': forecast_time,
            'description': description,
            'rain_probability': rain_probability,
            'temp': forecast['main']['temp']
        })

    # Return formatted weather data
    return {
        'location': location,
        'forecast': tomorrow_forecasts
    }


# Function to generate response using Gemini
def generate_response(input_text):
    # Define function declaration for Gemini
    get_weather_func = FunctionDeclaration(
        name="get_weather",
        description="Retrieve weather forecast for tomorrow for a specific location",
        parameters={
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "The city or location to get weather information for"
                }
            },
            "required": ["location"]
        }
    )

    # Create a Tool with the function declaration
    weather_tool = Tool(function_declarations=[get_weather_func])

    # ReAct system prompt
    system_prompt = """
    You are an intelligent weather assistant that helps users decide if they should carry an umbrella tomorrow.
    Follow a ReAct-based approach to reason about the weather before responding.

    Steps to follow:
    1. Identify if the user has mentioned a location.
       - If no location is provided, ask the user to specify one.
    2. Retrieve the weather forecast for the given location.
    3. Based on the forecast, decide whether carrying an umbrella is necessary.
       - Consider rain probability, weather descriptions like "rain", "drizzle", "shower", etc.
       - If any period tomorrow has >30% chance of rain or contains rain-related terms, recommend an umbrella.
    4. Explain your reasoning in a natural, conversational manner.

    Example Responses:
    - "You do not need to carry an umbrella tomorrow as the weather in {location} is sunny with only a 5% chance of precipitation."
    - "Yes, you should carry an umbrella as there is a high chance of rain in {location} tomorrow afternoon, with a 60% probability of precipitation."

    Always provide your reasoning based on the actual forecast data.
    """

    # Initialize the model with tools
    model = GenerativeModel(
        "gemini-2.5-flash",
        tools=[weather_tool],
        system_instruction=system_prompt
    )

    # Start a chat session
    chat = model.start_chat()

    # Send the user message
    response = chat.send_message(input_text)

    # Check if the model wants to call a function
    if response.candidates[0].content.parts[0].function_call:
        function_call = response.candidates[0].content.parts[0].function_call
        function_name = function_call.name
        function_args = dict(function_call.args)

        location = function_args.get('location')

        if not location:
            return "I'd be happy to help! To check if you need an umbrella tomorrow, could you please tell me your location?"

        # Call the function dynamically by name
        try:
            weather_data = globals()[function_name](**function_args)
        except KeyError:
            return f"Unknown function: {function_name}"

        # Handle API errors
        if "error" in weather_data:
            return f"I'm sorry, I couldn't get the weather information: {weather_data['error']}"

        # Prepare a summary of tomorrow's weather
        weather_summary = f"Weather forecast for {weather_data['location']} for tomorrow:\n\n"

        for forecast in weather_data['forecast']:
            weather_summary += f"- {forecast['time']}: {forecast['description'].capitalize()}, {forecast['temp']}°C, Rain probability: {forecast['rain_probability']}%\n"

        # Send the function result back to the model
        response = chat.send_message(
            Part.from_function_response(
                name=function_name,
                response={"weather_data": weather_summary}
            )
        )

        return response.candidates[0].content.parts[0].text
    else:
        # Model didn't call function, maybe asking for location
        return response.candidates[0].content.parts[0].text


# User input via chat interface
if prompt := st.chat_input("Type your question here..."):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})

    # Display user message
    with st.chat_message("user"):
        st.markdown(prompt)

    # Generate and display response
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            response = generate_response(prompt)
            st.markdown(response)

    # Add assistant response to chat history
    st.session_state.messages.append({"role": "assistant", "content": response})

# Sidebar with app information
with st.sidebar:
    st.header("About")
    st.markdown(f"""
    This Weather Assistant uses:
    - **Gemini 2.5 Flash** for reasoning
    - **OpenWeatherMap API** for real-time weather data
    - **ReAct approach** for planning and execution

    **Project:** {PROJECT_ID}
    **Location:** {LOCATION}

    Ask if you should carry an umbrella tomorrow!
    """)

    st.subheader("Sample Questions")
    st.markdown("""
    - Should I bring an umbrella tomorrow?
    - Will it rain tomorrow in Seattle?
    - Do I need an umbrella in London tomorrow?
    """)
