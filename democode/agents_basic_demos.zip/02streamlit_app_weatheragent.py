import os
import requests
from pathlib import Path
from dotenv import load_dotenv
import streamlit as st
import vertexai
from vertexai.generative_models import GenerativeModel, Tool, FunctionDeclaration, Part


def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env or google-vertexai-serviceaccount-key.json in any parent directory.")
    print(f"Started searching from: {Path(__file__).resolve().parent}")
    exit(1)


# Load environment variables from project root
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Resolve relative credential paths to absolute
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

# Get project configuration
PROJECT_ID = os.getenv("GOOGLE_VERTEXAI_PROJECT_ID", os.getenv("PROJECT_ID", "gen-ai-training-476514"))
LOCATION = os.getenv("GOOGLE_VERTEXAI_LOCATION", os.getenv("LOCATION", "us-central1"))
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

# Initialize Vertex AI
vertexai.init(project=PROJECT_ID, location=LOCATION)

st.title("Agent and Function Calling Demo (Gemini)")

with st.sidebar:
    st.markdown(f"**Project:** {PROJECT_ID}")
    st.markdown(f"**Location:** {LOCATION}")


def get_weather(location: str) -> str:
    """Get current weather for a location."""
    print("get weather function called. Parameter passed:", location)
    url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={OPENWEATHERMAP_API_KEY}"
    response = requests.get(url)
    get_response = response.json()

    if not get_response:
        return f"Could not find location: {location}"

    latitude = get_response[0]['lat']
    longitude = get_response[0]['lon']

    url_final = f"https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={OPENWEATHERMAP_API_KEY}&units=metric"
    final_response = requests.get(url_final)
    final_response_json = final_response.json()

    weather = (f"Weather: {final_response_json['weather'][0]['description']}, "
               f"Temperature: {final_response_json['main']['temp']}°C")
    return weather


def generate_response(input_text):
    # Define function declaration for Gemini
    get_weather_func = FunctionDeclaration(
        name="get_weather",
        description="Retrieve real-time weather information/data about a particular location/place",
        parameters={
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "The exact location whose real-time weather is to be determined"
                }
            },
            "required": ["location"]
        }
    )

    # Create a Tool with the function declaration
    weather_tool = Tool(function_declarations=[get_weather_func])

    # Initialize the model with tools
    model = GenerativeModel(
        "gemini-2.5-flash",
        tools=[weather_tool],
        system_instruction="You are a helpful assistant."
    )

    with st.spinner('Processing...'):
        # Start a chat session and send message
        chat = model.start_chat()
        response = chat.send_message(input_text)

        # Check if the model wants to call a function
        if response.candidates[0].content.parts[0].function_call:
            function_call = response.candidates[0].content.parts[0].function_call
            function_name = function_call.name
            function_args = dict(function_call.args)

            # Call the function dynamically by name
            try:
                result = globals()[function_name](**function_args)
            except KeyError:
                result = f"Unknown function: {function_name}"

            # Send the function result back to the model
            response = chat.send_message(
                Part.from_function_response(
                    name=function_name,
                    response={"result": result}
                )
            )

            resp = response.candidates[0].content.parts[0].text
        else:
            resp = response.candidates[0].content.parts[0].text

    st.info(resp)


with st.form("my_form"):
    text = st.text_area("Enter text:", "What's the weather in Mumbai today?")
    submitted = st.form_submit_button("Submit")
    if submitted:
        generate_response(text)
