# Import os to handle environment variables
#
# To run this app
# 
# streamlit run <path to this file, for example, rag\streamlit_app_basic.py>
#
import os
from dotenv import load_dotenv
import streamlit as st
import vertexai
from dotenv import load_dotenv
from vertexai.generative_models import GenerativeModel, Part

load_dotenv()

st.subheader("<Your Name>'s AI chatbot")

def generate_response(input_text):
        # --- Step 2: Set Your Project Details ---
        # Replace with your actual project ID and location
        PROJECT_ID = "gen-ai-training-476514"  
        LOCATION = "us-central1"  # e.g., "us-central1"

        # --- Step 3: Initialize Vertex AI ---
        # The client automatically uses the credentials
        # loaded from the .env file
        try:
                vertexai.init(project=PROJECT_ID, location=LOCATION)
        except Exception as e:
                print(f"Error initializing Vertex AI: {e}")
                print("Please ensure your PROJECT_ID and LOCATION are correct and you have enabled the Vertex AI API.")
                exit()
                # --- Step 4: Define Prompts and Load the Model ---
        print("Vertex AI Initialized. Defining prompts...")

        # Define your system prompt (the model's instructions)
        system_prompt = "You are a helpful assistant."

        # Define your user prompt (the user's question)
        user_prompt = input_text

        print(f"System Prompt: {system_prompt}")
        print(f"User Prompt: {user_prompt}")

        # Load the generative model and pass the system prompt
        try:
                model = GenerativeModel(
                "gemini-2.5-flash",
                system_instruction=system_prompt
                )
                print("Model loaded. Sending prompt...")

                # --- Step 5: Send the User Prompt ---
                # Send only the user's prompt to generate_content
                response = model.generate_content(user_prompt)
                
                # Print the text response
                print("\n--- Model Response ---")
                print(response.text)
                print("------------------------\n")
        except Exception as e:
                print(f"An error occurred while generating content: {e}")

        st.info(response.text)  # Display the response content

user_question = st.text_input("Ask any question. Press enter to submit", key="user_question")
if user_question:
    generate_response(user_question)