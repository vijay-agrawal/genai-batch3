# Credit Risk Classification - Quick Start Guide

## Complete Demo Execution

This guide walks you through running the entire credit risk assessment pipeline from data generation to model evaluation.

---

## Prerequisites

```bash
# Navigate to project directory
cd machinelearning/creditriskclassification

# Create virtual environment (recommended)
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

---

## Step-by-Step Execution

### Step 1: Generate Synthetic Data

```bash
python src/01_generate_data.py
```

**What it does:**
- Generates 50,000 realistic loan applications
- Creates 19 features with appropriate correlations
- Simulates 15% default rate
- Saves raw data to `data/raw/credit_risk_data.csv`

**Expected output:**
```
================================================================================
CREDIT RISK SYNTHETIC DATA GENERATOR
================================================================================

Generating 50,000 loan applications...
Target default rate: 15.0%

Generating features...

Generating default labels...
Actual default rate: 15.02%
Default probability range: 0.003 - 0.892

Adding realistic missing values...
Missing values added:
  employment_length: 1000 (2.0%)
  num_late_payments: 1000 (2.0%)
  monthly_debt: 1000 (2.0%)

================================================================================
Dataset saved to: data\raw\credit_risk_data.csv
================================================================================
```

---

### Step 2: Exploratory Data Analysis

```bash
python src/02_eda.py
```

**What it does:**
- Analyzes data quality and distributions
- Creates visualizations for all features
- Examines feature relationships with default
- Generates correlation analysis
- Performs risk segmentation

**Expected output:**
- 8 visualization files in `outputs/eda/`:
  - `01_target_distribution.png` - Default vs non-default split
  - `02_numerical_distributions.png` - Histograms of numerical features
  - `03_categorical_distributions.png` - Bar charts of categorical features
  - `04_features_vs_default_boxplot.png` - Feature distributions by default status
  - `05_default_rate_by_categorical.png` - Default rates across categories
  - `06_correlation_matrix.png` - Feature correlations heatmap
  - `07_default_correlation.png` - Feature correlations with default
  - `08_risk_segmentation.png` - Default rates by risk segments

---

### Step 3: Feature Engineering

```bash
python src/03_feature_engineering.py
```

**What it does:**
- Handles missing values (median/mode imputation)
- Creates 12 derived features:
  - debt_to_income_ratio
  - loan_to_income_ratio
  - payment_to_income_ratio
  - credit_util_category
  - credit_score_category
  - age_group
  - income_category
  - employment_stability
  - has_late_payments
  - high_risk_flag
  - total_debt_load
  - monthly_payment_estimate
- Encodes categorical variables
- Creates train-test split (80/20)
- Scales features for linear models

**Expected output:**
```
================================================================================
FEATURE ENGINEERING - CREDIT RISK
================================================================================

1. HANDLING MISSING VALUES
...

2. CREATING DERIVED FEATURES
...
Total derived features created: 12

3. ENCODING CATEGORICAL VARIABLES
...

4. FEATURE SELECTION
...
Total features selected: 35

5. TRAIN-TEST SPLIT
...
Train set: 40,000 samples (80.0%)
Test set: 10,000 samples (20.0%)

Files created:
  data\processed\X_train.csv
  data\processed\X_test.csv
  data\processed\y_train.csv
  data\processed\y_test.csv
  data\processed\X_train_scaled.csv
  data\processed\X_test_scaled.csv
  data\processed\feature_names.txt
  models\encoders.pkl
  models\scaler.pkl
```

---

### Step 4: Model Training

```bash
python src/04_model_training.py
```

**What it does:**
- Trains 4 models with 5-fold cross-validation:
  1. Logistic Regression (baseline)
  2. Random Forest
  3. XGBoost
  4. LightGBM
- Evaluates each model on test set
- Compares model performance
- Saves all trained models

**Expected output:**
```
================================================================================
MODEL TRAINING - CREDIT RISK PREDICTION
================================================================================

MODEL 1: LOGISTIC REGRESSION (Baseline)
Cross-Validation Results (5-Fold):
  AUC-ROC:   0.8512 (+/- 0.0032)
  Precision: 0.4523 (+/- 0.0145)
  Recall:    0.7821 (+/- 0.0231)
  F1-Score:  0.5745 (+/- 0.0112)

Test Set Performance:
  AUC-ROC:   0.8523
  Precision: 0.4567
  Recall:    0.7845
  F1-Score:  0.5768

MODEL 2: RANDOM FOREST
...
  AUC-ROC:   0.8987

MODEL 3: XGBOOST
...
  AUC-ROC:   0.9145

MODEL 4: LIGHTGBM
...
  AUC-ROC:   0.9123

MODEL COMPARISON SUMMARY
              Model  CV AUC  Test AUC  Precision  Recall    F1  Log Loss
 Logistic Regression  0.8512    0.8523     0.4567  0.7845  0.5768    0.3456
      Random Forest  0.8945    0.8987     0.5234  0.7123  0.6012    0.2987
            XGBoost  0.9098    0.9145     0.5678  0.7456  0.6445    0.2345
           LightGBM  0.9076    0.9123     0.5623  0.7398  0.6398    0.2389

BEST MODEL: XGBoost (Test AUC: 0.9145)
```

---

### Step 5: Model Evaluation and Explainability

```bash
python src/05_model_evaluation.py
```

**What it does:**
- Generates ROC curves for all models
- Creates Precision-Recall curves
- Plots confusion matrices
- Analyzes feature importance
- Generates SHAP explanations
- Creates calibration plots
- Finds optimal decision threshold
- Calculates business metrics

**Expected output:**
```
================================================================================
MODEL EVALUATION AND EXPLAINABILITY
================================================================================

1. GENERATING ROC CURVES
...

2. GENERATING PRECISION-RECALL CURVES
...

3. GENERATING CONFUSION MATRICES
...

4. FEATURE IMPORTANCE ANALYSIS
...

5. SHAP EXPLANATIONS (XGBoost Model)
Calculating SHAP values (this may take a moment)...
...

6. CALIBRATION ANALYSIS
...

7. OPTIMAL THRESHOLD ANALYSIS
Optimal Threshold: 0.35
F1-Score at optimal: 0.6445

8. BUSINESS IMPACT ANALYSIS
Business Metrics (at optimal threshold):
  Approved Loans: 7,234 (72.3% approval rate)
  True Positives (Good Loans): 6,456
  False Positives (Bad Loans): 778
  False Negatives (Missed Opportunities): 345

  Cost from Bad Loans: $3,890,000
  Cost from Missed Opportunities: $69,000
  Revenue from Good Loans: $6,456,000
  Total Profit: $2,497,000

  Average Profit per Application: $249.70
  Default Rate in Approved Loans: 10.8%

Key Recommendations:
  1. Use XGBoost or LightGBM as production model (highest AUC)
  2. Set decision threshold at 0.35 for optimal F1-score
  3. Expected approval rate: 72.3%
  4. Expected default rate in approved loans: 10.8%
```

**Output files:**
- `outputs/model_performance/`:
  - `roc_curves.png`
  - `precision_recall_curves.png`
  - `confusion_matrices.png`
  - `calibration_plot.png`
  - `threshold_optimization.png`

- `outputs/explainability/`:
  - `feature_importance_comparison.png`
  - `shap_summary_bar.png`
  - `shap_summary_beeswarm.png`
  - `shap_waterfall_default.png`

---

## Complete Pipeline (All Steps)

Run all steps sequentially:

```bash
# Windows
python src/01_generate_data.py && python src/02_eda.py && python src/03_feature_engineering.py && python src/04_model_training.py && python src/05_model_evaluation.py

# Linux/Mac
python src/01_generate_data.py && \
python src/02_eda.py && \
python src/03_feature_engineering.py && \
python src/04_model_training.py && \
python src/05_model_evaluation.py
```

**Total execution time:** ~5-10 minutes (depending on hardware)

---

## Understanding the Results

### Key Files to Review

1. **EDA Visualizations** (`outputs/eda/`)
   - Understand data distributions
   - Identify key risk factors
   - See feature correlations

2. **Model Comparison** (`models/model_comparison.csv`)
   - Compare all models
   - Identify best performer
   - Review cross-validation scores

3. **Feature Importance** (`models/feature_importance_*.csv`)
   - See which features drive predictions
   - Compare across models
   - Identify consistent patterns

4. **SHAP Explanations** (`outputs/explainability/`)
   - Understand individual predictions
   - See feature contributions
   - Validate model logic

### Expected Model Rankings (Best to Worst)

1. **XGBoost** - Best overall (AUC ~0.91-0.93)
2. **LightGBM** - Close second (AUC ~0.91-0.92)
3. **Random Forest** - Solid performer (AUC ~0.89-0.90)
4. **Logistic Regression** - Baseline (AUC ~0.85-0.87)

### Top Predictive Features

Based on typical results, expect these to be most important:

1. **credit_score** - Single most important
2. **credit_utilization** - High utilization = higher risk
3. **num_late_payments** - Strong indicator
4. **debt_to_income_ratio** - Derived feature
5. **annual_income** - Inverse relationship
6. **employment_length** - Stability indicator
7. **loan_to_income_ratio** - Derived feature
8. **bankruptcies** - Strong negative signal
9. **num_credit_lines** - Credit history depth
10. **age** - Experience/stability proxy

---

## Troubleshooting

### Issue: Import Errors

**Problem:** Missing packages
**Solution:**
```bash
pip install -r requirements.txt
```

### Issue: Memory Errors

**Problem:** Insufficient RAM for large datasets
**Solution:** Reduce sample size in `src/01_generate_data.py`:
```python
N_SAMPLES = 10000  # Instead of 50000
```

### Issue: SHAP Takes Too Long

**Problem:** SHAP calculation is slow
**Solution:** Already handled - script samples 1000 observations. To reduce further, edit `src/05_model_evaluation.py`:
```python
sample_size = min(500, len(X_data))  # Reduce from 1000 to 500
```

---

## Next Steps

After running the demo:

1. **Review Documentation**
   - Read [ML vs Rule-Based Scorecards](docs/ml_vs_rulebased.md)
   - Understand probabilistic vs rule-based approaches

2. **Experiment**
   - Modify feature engineering
   - Try different hyperparameters
   - Test ensemble methods

3. **Production Considerations**
   - API deployment (FastAPI)
   - Model monitoring
   - A/B testing framework
   - Bias detection and mitigation

4. **Advanced Topics**
   - Cost-sensitive learning
   - Fairness constraints
   - Explainability for regulators
   - Model risk management

---

## Demo for Training Sessions

### Presentation Flow (60 minutes)

**Part 1: Problem Setup (10 min)**
- Business context
- Default risk in lending
- ML vs traditional scorecards

**Part 2: Data & EDA (10 min)**
- Run data generation
- Show EDA visualizations
- Discuss key insights

**Part 3: Feature Engineering (10 min)**
- Explain derived features
- Show encoding strategies
- Discuss domain knowledge incorporation

**Part 4: Model Training (15 min)**
- Train all models (live or pre-run)
- Show cross-validation results
- Compare model performance

**Part 5: Evaluation & Explainability (15 min)**
- Show ROC/PR curves
- Demonstrate SHAP explanations
- Discuss business metrics
- Explain threshold optimization

**Q&A (optional)**

---

## Support

For issues or questions:
1. Check the [IMPLEMENTATION_GUIDE.md](IMPLEMENTATION_GUIDE.md)
2. Review [README.md](README.md)
3. Examine code comments in scripts

---

**Happy Modeling!** 🎯📊

