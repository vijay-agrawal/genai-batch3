"""
Model Evaluation and Explainability for Credit Risk Models

Comprehensive evaluation including:
- ROC curves and AUC
- Precision-Recall curves
- Confusion matrices
- Feature importance analysis
- SHAP explanations
- Business metrics
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import joblib
import warnings
warnings.filterwarnings('ignore')

# Sklearn metrics
from sklearn.metrics import (
    roc_curve, auc, precision_recall_curve, confusion_matrix,
    classification_report, RocCurveDisplay, PrecisionRecallDisplay
)

# SHAP for explainability
import shap

# Configuration
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

# Paths
DATA_DIR = Path("data/processed")
MODELS_DIR = Path("models")
OUTPUT_DIR = Path("outputs")
PERFORMANCE_DIR = OUTPUT_DIR / "model_performance"
EXPLAINABILITY_DIR = OUTPUT_DIR / "explainability"

PERFORMANCE_DIR.mkdir(parents=True, exist_ok=True)
EXPLAINABILITY_DIR.mkdir(parents=True, exist_ok=True)

print("="*80)
print("MODEL EVALUATION AND EXPLAINABILITY")
print("="*80)

# Load data
print("\nLoading test data...")
X_test = pd.read_csv(DATA_DIR / "X_test.csv")
y_test = pd.read_csv(DATA_DIR / "y_test.csv").values.ravel()
X_test_scaled = pd.read_csv(DATA_DIR / "X_test_scaled.csv")

print(f"Test set: {X_test.shape}")
print(f"Default rate: {y_test.mean():.2%}\n")

# Load models
print("Loading trained models...")
models = {
    'Logistic Regression': (joblib.load(MODELS_DIR / "model_logistic.pkl"), X_test_scaled),
    'Random Forest': (joblib.load(MODELS_DIR / "model_random_forest.pkl"), X_test),
    'XGBoost': (joblib.load(MODELS_DIR / "model_xgboost.pkl"), X_test),
    'LightGBM': (joblib.load(MODELS_DIR / "model_lightgbm.pkl"), X_test),
}

print("Models loaded successfully.\n")

# =============================================================================
# 1. ROC CURVES
# =============================================================================

def plot_roc_curves():
    """Plot ROC curves for all models"""

    print("\n" + "="*80)
    print("1. GENERATING ROC CURVES")
    print("="*80)

    plt.figure(figsize=(10, 8))

    for model_name, (model, X_data) in models.items():
        y_pred_proba = model.predict_proba(X_data)[:, 1]
        fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
        roc_auc = auc(fpr, tpr)

        plt.plot(fpr, tpr, lw=2, label=f'{model_name} (AUC = {roc_auc:.3f})')

        print(f"{model_name}: AUC = {roc_auc:.4f}")

    # Plot diagonal
    plt.plot([0, 1], [0, 1], 'k--', lw=2, label='Random Classifier')

    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', fontsize=12)
    plt.ylabel('True Positive Rate', fontsize=12)
    plt.title('ROC Curves - Credit Risk Models', fontsize=14, fontweight='bold')
    plt.legend(loc="lower right", fontsize=10)
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(PERFORMANCE_DIR / 'roc_curves.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {PERFORMANCE_DIR / 'roc_curves.png'}")
    plt.close()


# =============================================================================
# 2. PRECISION-RECALL CURVES
# =============================================================================

def plot_precision_recall_curves():
    """Plot Precision-Recall curves for all models"""

    print("\n" + "="*80)
    print("2. GENERATING PRECISION-RECALL CURVES")
    print("="*80)

    plt.figure(figsize=(10, 8))

    for model_name, (model, X_data) in models.items():
        y_pred_proba = model.predict_proba(X_data)[:, 1]
        precision, recall, _ = precision_recall_curve(y_test, y_pred_proba)
        pr_auc = auc(recall, precision)

        plt.plot(recall, precision, lw=2, label=f'{model_name} (AUC = {pr_auc:.3f})')

        print(f"{model_name}: PR-AUC = {pr_auc:.4f}")

    # Baseline
    baseline = y_test.mean()
    plt.plot([0, 1], [baseline, baseline], 'k--', lw=2, label=f'Baseline ({baseline:.2f})')

    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.title('Precision-Recall Curves - Credit Risk Models', fontsize=14, fontweight='bold')
    plt.legend(loc="best", fontsize=10)
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(PERFORMANCE_DIR / 'precision_recall_curves.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {PERFORMANCE_DIR / 'precision_recall_curves.png'}")
    plt.close()


# =============================================================================
# 3. CONFUSION MATRICES
# =============================================================================

def plot_confusion_matrices():
    """Plot confusion matrices for all models"""

    print("\n" + "="*80)
    print("3. GENERATING CONFUSION MATRICES")
    print("="*80)

    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    axes = axes.flatten()

    for idx, (model_name, (model, X_data)) in enumerate(models.items()):
        y_pred = model.predict(X_data)
        cm = confusion_matrix(y_test, y_pred)

        # Plot
        ax = axes[idx]
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                    xticklabels=['Non-Default', 'Default'],
                    yticklabels=['Non-Default', 'Default'])
        ax.set_title(f'{model_name}', fontsize=12, fontweight='bold')
        ax.set_ylabel('Actual', fontsize=11)
        ax.set_xlabel('Predicted', fontsize=11)

        # Calculate metrics
        tn, fp, fn, tp = cm.ravel()
        accuracy = (tp + tn) / (tp + tn + fp + fn)
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0

        print(f"\n{model_name}:")
        print(f"  True Negatives:  {tn:,}")
        print(f"  False Positives: {fp:,}")
        print(f"  False Negatives: {fn:,}")
        print(f"  True Positives:  {tp:,}")
        print(f"  Accuracy:  {accuracy:.4f}")
        print(f"  Precision: {precision:.4f}")
        print(f"  Recall:    {recall:.4f}")

    plt.tight_layout()
    plt.savefig(PERFORMANCE_DIR / 'confusion_matrices.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {PERFORMANCE_DIR / 'confusion_matrices.png'}")
    plt.close()


# =============================================================================
# 4. FEATURE IMPORTANCE COMPARISON
# =============================================================================

def plot_feature_importance():
    """Plot and compare feature importance across tree-based models"""

    print("\n" + "="*80)
    print("4. FEATURE IMPORTANCE ANALYSIS")
    print("="*80)

    # Load feature importance from saved files
    importance_files = {
        'Random Forest': MODELS_DIR / 'feature_importance_rf.csv',
        'XGBoost': MODELS_DIR / 'feature_importance_xgb.csv',
        'LightGBM': MODELS_DIR / 'feature_importance_lgb.csv',
    }

    fig, axes = plt.subplots(1, 3, figsize=(20, 8))

    for idx, (model_name, file_path) in enumerate(importance_files.items()):
        importance_df = pd.read_csv(file_path)
        top_features = importance_df.head(15)

        ax = axes[idx]
        ax.barh(range(len(top_features)), top_features['importance'], color='steelblue')
        ax.set_yticks(range(len(top_features)))
        ax.set_yticklabels(top_features['feature'])
        ax.invert_yaxis()
        ax.set_xlabel('Importance', fontsize=11)
        ax.set_title(f'{model_name}\nTop 15 Features', fontsize=12, fontweight='bold')
        ax.grid(True, alpha=0.3, axis='x')

    plt.tight_layout()
    plt.savefig(EXPLAINABILITY_DIR / 'feature_importance_comparison.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {EXPLAINABILITY_DIR / 'feature_importance_comparison.png'}")
    plt.close()

    # Print top 5 common important features
    all_importance = []
    for file_path in importance_files.values():
        importance_df = pd.read_csv(file_path)
        all_importance.append(set(importance_df.head(10)['feature'].tolist()))

    common_features = set.intersection(*all_importance)
    print(f"\nTop features common across all models:")
    for feat in common_features:
        print(f"  - {feat}")


# =============================================================================
# 5. SHAP EXPLANATIONS
# =============================================================================

def generate_shap_explanations():
    """Generate SHAP value explanations for XGBoost model"""

    print("\n" + "="*80)
    print("5. SHAP EXPLANATIONS (XGBoost Model)")
    print("="*80)

    # Use XGBoost model (best performer typically)
    model_xgb, X_data = models['XGBoost']

    print("\nCalculating SHAP values (this may take a moment)...")

    # Create SHAP explainer
    explainer = shap.TreeExplainer(model_xgb)

    # Calculate SHAP values for test set (sample for speed)
    sample_size = min(1000, len(X_data))
    X_sample = X_data.sample(n=sample_size, random_state=42)
    shap_values = explainer.shap_values(X_sample)

    print("SHAP values calculated successfully.")

    # Summary plot (bar)
    print("\nGenerating SHAP summary plot (bar)...")
    plt.figure(figsize=(10, 8))
    shap.summary_plot(shap_values, X_sample, plot_type="bar", show=False)
    plt.tight_layout()
    plt.savefig(EXPLAINABILITY_DIR / 'shap_summary_bar.png', dpi=300, bbox_inches='tight')
    print(f"Saved: {EXPLAINABILITY_DIR / 'shap_summary_bar.png'}")
    plt.close()

    # Summary plot (beeswarm)
    print("Generating SHAP summary plot (beeswarm)...")
    plt.figure(figsize=(10, 10))
    shap.summary_plot(shap_values, X_sample, show=False)
    plt.tight_layout()
    plt.savefig(EXPLAINABILITY_DIR / 'shap_summary_beeswarm.png', dpi=300, bbox_inches='tight')
    print(f"Saved: {EXPLAINABILITY_DIR / 'shap_summary_beeswarm.png'}")
    plt.close()

    # Waterfall plot for single prediction (first defaulter)
    print("Generating SHAP waterfall plot (single prediction)...")
    default_idx = np.where(y_test == 1)[0][0]  # First default case in test set

    plt.figure(figsize=(10, 8))
    shap.waterfall_plot(
        shap.Explanation(
            values=shap_values[default_idx],
            base_values=explainer.expected_value,
            data=X_sample.iloc[default_idx],
            feature_names=X_sample.columns.tolist()
        ),
        show=False
    )
    plt.tight_layout()
    plt.savefig(EXPLAINABILITY_DIR / 'shap_waterfall_default.png', dpi=300, bbox_inches='tight')
    print(f"Saved: {EXPLAINABILITY_DIR / 'shap_waterfall_default.png'}")
    plt.close()

    print("\nSHAP explanation generation complete.")


# =============================================================================
# 6. CALIBRATION PLOT
# =============================================================================

def plot_calibration():
    """Plot calibration curves to check probability calibration"""

    print("\n" + "="*80)
    print("6. CALIBRATION ANALYSIS")
    print("="*80)

    from sklearn.calibration import calibration_curve

    fig, ax = plt.subplots(1, 1, figsize=(10, 8))

    for model_name, (model, X_data) in models.items():
        y_pred_proba = model.predict_proba(X_data)[:, 1]

        # Calculate calibration curve
        fraction_of_positives, mean_predicted_value = calibration_curve(
            y_test, y_pred_proba, n_bins=10
        )

        ax.plot(mean_predicted_value, fraction_of_positives, 's-', label=model_name)

    # Perfect calibration
    ax.plot([0, 1], [0, 1], 'k--', label='Perfect Calibration')

    ax.set_xlabel('Mean Predicted Probability', fontsize=12)
    ax.set_ylabel('Fraction of Positives', fontsize=12)
    ax.set_title('Calibration Plot - Credit Risk Models', fontsize=14, fontweight='bold')
    ax.legend(loc='best', fontsize=10)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(PERFORMANCE_DIR / 'calibration_plot.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {PERFORMANCE_DIR / 'calibration_plot.png'}")
    plt.close()


# =============================================================================
# 7. THRESHOLD OPTIMIZATION
# =============================================================================

def find_optimal_threshold():
    """Find optimal decision threshold based on F1-score"""

    print("\n" + "="*80)
    print("7. OPTIMAL THRESHOLD ANALYSIS")
    print("="*80)

    # Use best model (XGBoost)
    model_xgb, X_data = models['XGBoost']
    y_pred_proba = model_xgb.predict_proba(X_data)[:, 1]

    # Test different thresholds
    thresholds = np.arange(0.1, 0.9, 0.05)
    f1_scores = []
    precision_scores = []
    recall_scores = []

    for threshold in thresholds:
        y_pred_thresh = (y_pred_proba >= threshold).astype(int)

        from sklearn.metrics import f1_score, precision_score, recall_score

        f1 = f1_score(y_test, y_pred_thresh)
        precision = precision_score(y_test, y_pred_thresh)
        recall = recall_score(y_test, y_pred_thresh)

        f1_scores.append(f1)
        precision_scores.append(precision)
        recall_scores.append(recall)

    # Find optimal threshold (max F1)
    optimal_idx = np.argmax(f1_scores)
    optimal_threshold = thresholds[optimal_idx]
    optimal_f1 = f1_scores[optimal_idx]

    print(f"\nOptimal Threshold: {optimal_threshold:.2f}")
    print(f"F1-Score at optimal: {optimal_f1:.4f}")
    print(f"Precision at optimal: {precision_scores[optimal_idx]:.4f}")
    print(f"Recall at optimal: {recall_scores[optimal_idx]:.4f}")

    # Plot threshold analysis
    plt.figure(figsize=(10, 6))
    plt.plot(thresholds, f1_scores, 'b-', label='F1-Score', linewidth=2)
    plt.plot(thresholds, precision_scores, 'g--', label='Precision')
    plt.plot(thresholds, recall_scores, 'r--', label='Recall')
    plt.axvline(x=optimal_threshold, color='black', linestyle=':', label=f'Optimal ({optimal_threshold:.2f})')
    plt.xlabel('Decision Threshold', fontsize=12)
    plt.ylabel('Score', fontsize=12)
    plt.title('Threshold Optimization - XGBoost Model', fontsize=14, fontweight='bold')
    plt.legend(loc='best', fontsize=10)
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(PERFORMANCE_DIR / 'threshold_optimization.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {PERFORMANCE_DIR / 'threshold_optimization.png'}")
    plt.close()

    return optimal_threshold


# =============================================================================
# 8. BUSINESS METRICS
# =============================================================================

def calculate_business_metrics(optimal_threshold):
    """Calculate business-oriented metrics"""

    print("\n" + "="*80)
    print("8. BUSINESS IMPACT ANALYSIS")
    print("="*80)

    # Use XGBoost model
    model_xgb, X_data = models['XGBoost']
    y_pred_proba = model_xgb.predict_proba(X_data)[:, 1]

    # Define business costs (example values)
    COST_FP = 5000   # Cost of approving a defaulter (loss)
    COST_FN = 200    # Cost of rejecting a good customer (opportunity cost)
    REVENUE_TP = 1000  # Revenue from approving good customer
    REVENUE_TN = 0   # No cost/revenue for correctly rejecting

    # Calculate metrics at optimal threshold
    y_pred_optimal = (y_pred_proba >= optimal_threshold).astype(int)
    cm = confusion_matrix(y_test, y_pred_optimal)
    tn, fp, fn, tp = cm.ravel()

    # Business metrics
    total_cost_fp = fp * COST_FP
    total_cost_fn = fn * COST_FN
    total_revenue_tp = tp * REVENUE_TP
    total_profit = total_revenue_tp - total_cost_fp - total_cost_fn

    print("\nBusiness Metrics (at optimal threshold):")
    print(f"  Approved Loans: {tp + fp:,} ({(tp + fp)/len(y_test):.1%} approval rate)")
    print(f"  True Positives (Good Loans): {tp:,}")
    print(f"  False Positives (Bad Loans): {fp:,}")
    print(f"  False Negatives (Missed Opportunities): {fn:,}")
    print(f"\n  Cost from Bad Loans: ${total_cost_fp:,}")
    print(f"  Cost from Missed Opportunities: ${total_cost_fn:,}")
    print(f"  Revenue from Good Loans: ${total_revenue_tp:,}")
    print(f"  Total Profit: ${total_profit:,}")

    print(f"\n  Average Profit per Application: ${total_profit/len(y_test):.2f}")
    print(f"  Default Rate in Approved Loans: {fp/(tp+fp):.2%}")

    return {
        'total_profit': total_profit,
        'approval_rate': (tp + fp)/len(y_test),
        'default_rate_approved': fp/(tp+fp)
    }


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """Run complete evaluation pipeline"""

    # 1. ROC Curves
    plot_roc_curves()

    # 2. Precision-Recall Curves
    plot_precision_recall_curves()

    # 3. Confusion Matrices
    plot_confusion_matrices()

    # 4. Feature Importance
    plot_feature_importance()

    # 5. SHAP Explanations
    generate_shap_explanations()

    # 6. Calibration
    plot_calibration()

    # 7. Optimal Threshold
    optimal_threshold = find_optimal_threshold()

    # 8. Business Metrics
    business_metrics = calculate_business_metrics(optimal_threshold)

    print("\n" + "="*80)
    print("MODEL EVALUATION COMPLETE!")
    print("="*80)

    print("\nOutputs generated:")
    print(f"  Performance Metrics: {PERFORMANCE_DIR}")
    print(f"  Explainability: {EXPLAINABILITY_DIR}")

    print("\nKey Recommendations:")
    print(f"  1. Use XGBoost or LightGBM as production model (highest AUC)")
    print(f"  2. Set decision threshold at {optimal_threshold:.2f} for optimal F1-score")
    print(f"  3. Expected approval rate: {business_metrics['approval_rate']:.1%}")
    print(f"  4. Expected default rate in approved loans: {business_metrics['default_rate_approved']:.1%}")

    print("\n" + "="*80 + "\n")


if __name__ == "__main__":
    main()
