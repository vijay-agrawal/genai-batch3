"""
Exploratory Data Analysis (EDA) for Credit Risk Dataset

Generates comprehensive visualizations and statistical summaries to understand:
- Distribution of features
- Relationship between features and default
- Correlations
- Data quality issues
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Configuration
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

# Paths
DATA_DIR = Path("data/raw")
OUTPUT_DIR = Path("outputs/eda")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

print("="*80)
print("EXPLORATORY DATA ANALYSIS - CREDIT RISK")
print("="*80)

# Load data
print("\nLoading data...")
df = pd.read_csv(DATA_DIR / "credit_risk_data.csv")
print(f"Dataset shape: {df.shape}")
print(f"Columns: {list(df.columns)}\n")

# =============================================================================
# 1. DATA QUALITY ASSESSMENT
# =============================================================================

def analyze_data_quality(df):
    """Analyze missing values, duplicates, and data types"""

    print("\n" + "="*80)
    print("1. DATA QUALITY ASSESSMENT")
    print("="*80)

    # Data types
    print("\nData Types:")
    print(df.dtypes)

    # Missing values
    print("\nMissing Values:")
    missing = df.isnull().sum()
    missing_pct = (missing / len(df) * 100).round(2)
    missing_df = pd.DataFrame({
        'Missing Count': missing,
        'Percentage': missing_pct
    })
    missing_df = missing_df[missing_df['Missing Count'] > 0].sort_values('Missing Count', ascending=False)

    if len(missing_df) > 0:
        print(missing_df)
    else:
        print("No missing values found")

    # Duplicates
    duplicates = df.duplicated().sum()
    print(f"\nDuplicate rows: {duplicates}")

    # Summary statistics
    print("\nSummary Statistics:")
    print(df.describe().round(2))

    return missing_df


# =============================================================================
# 2. TARGET VARIABLE ANALYSIS
# =============================================================================

def analyze_target(df):
    """Analyze the distribution of the target variable"""

    print("\n" + "="*80)
    print("2. TARGET VARIABLE ANALYSIS")
    print("="*80)

    # Class distribution
    default_counts = df['default'].value_counts()
    default_pct = df['default'].value_counts(normalize=True) * 100

    print("\nClass Distribution:")
    print(f"Non-Default (0): {default_counts[0]:,} ({default_pct[0]:.2f}%)")
    print(f"Default (1): {default_counts[1]:,} ({default_pct[1]:.2f}%)")
    print(f"Class Imbalance Ratio: 1:{(default_counts[0]/default_counts[1]):.2f}")

    # Visualization
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Bar plot
    default_counts.plot(kind='bar', ax=axes[0], color=['green', 'red'])
    axes[0].set_title('Default Distribution', fontsize=14, fontweight='bold')
    axes[0].set_xlabel('Default Status')
    axes[0].set_ylabel('Count')
    axes[0].set_xticklabels(['Non-Default', 'Default'], rotation=0)
    axes[0].grid(True, alpha=0.3)

    # Pie chart
    axes[1].pie(default_counts, labels=['Non-Default', 'Default'],
                autopct='%1.1f%%', colors=['green', 'red'], startangle=90)
    axes[1].set_title('Default Proportion', fontsize=14, fontweight='bold')

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / '01_target_distribution.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {OUTPUT_DIR / '01_target_distribution.png'}")
    plt.close()


# =============================================================================
# 3. NUMERICAL FEATURES ANALYSIS
# =============================================================================

def analyze_numerical_features(df):
    """Analyze distribution of numerical features"""

    print("\n" + "="*80)
    print("3. NUMERICAL FEATURES ANALYSIS")
    print("="*80)

    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    numerical_cols = [col for col in numerical_cols if col not in ['default', 'default_probability']]

    print(f"\nNumerical features ({len(numerical_cols)}): {numerical_cols}")

    # Distribution plots
    n_cols = 3
    n_rows = (len(numerical_cols) + n_cols - 1) // n_cols

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(18, n_rows * 4))
    axes = axes.flatten() if n_rows > 1 else [axes] if n_cols == 1 else axes

    for idx, col in enumerate(numerical_cols):
        ax = axes[idx]
        df[col].hist(bins=50, ax=ax, color='skyblue', edgecolor='black', alpha=0.7)
        ax.set_title(f'{col}\n(mean: {df[col].mean():.2f}, std: {df[col].std():.2f})', fontsize=10)
        ax.set_xlabel(col)
        ax.set_ylabel('Frequency')
        ax.grid(True, alpha=0.3)

    # Hide extra subplots
    for idx in range(len(numerical_cols), len(axes)):
        axes[idx].axis('off')

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / '02_numerical_distributions.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {OUTPUT_DIR / '02_numerical_distributions.png'}")
    plt.close()


# =============================================================================
# 4. CATEGORICAL FEATURES ANALYSIS
# =============================================================================

def analyze_categorical_features(df):
    """Analyze distribution of categorical features"""

    print("\n" + "="*80)
    print("4. CATEGORICAL FEATURES ANALYSIS")
    print("="*80)

    categorical_cols = df.select_dtypes(include='object').columns.tolist()

    print(f"\nCategorical features ({len(categorical_cols)}): {categorical_cols}")

    # Distribution plots
    n_cols = 2
    n_rows = (len(categorical_cols) + n_cols - 1) // n_cols

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(14, n_rows * 4))
    axes = axes.flatten() if n_rows > 1 else [axes] if n_cols == 1 else axes

    for idx, col in enumerate(categorical_cols):
        ax = axes[idx]
        value_counts = df[col].value_counts()
        value_counts.plot(kind='bar', ax=ax, color='coral', edgecolor='black')
        ax.set_title(f'{col} Distribution', fontsize=11, fontweight='bold')
        ax.set_xlabel(col)
        ax.set_ylabel('Count')
        ax.tick_params(axis='x', rotation=45)
        ax.grid(True, alpha=0.3, axis='y')

        # Add count labels on bars
        for container in ax.containers:
            ax.bar_label(container, fmt='%d')

    # Hide extra subplots
    for idx in range(len(categorical_cols), len(axes)):
        axes[idx].axis('off')

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / '03_categorical_distributions.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {OUTPUT_DIR / '03_categorical_distributions.png'}")
    plt.close()


# =============================================================================
# 5. FEATURE vs TARGET ANALYSIS
# =============================================================================

def analyze_features_vs_target(df):
    """Analyze relationship between features and default"""

    print("\n" + "="*80)
    print("5. FEATURES vs TARGET ANALYSIS")
    print("="*80)

    # Key numerical features
    key_features = ['credit_score', 'annual_income', 'credit_utilization',
                    'num_late_payments', 'loan_amount', 'age']

    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    axes = axes.flatten()

    for idx, col in enumerate(key_features):
        ax = axes[idx]
        df.boxplot(column=col, by='default', ax=ax)
        ax.set_title(f'{col} by Default Status', fontsize=11, fontweight='bold')
        ax.set_xlabel('Default (0=No, 1=Yes)')
        ax.set_ylabel(col)
        plt.sca(ax)
        plt.xticks([1, 2], ['Non-Default', 'Default'])

    plt.suptitle('')  # Remove default title
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / '04_features_vs_default_boxplot.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {OUTPUT_DIR / '04_features_vs_default_boxplot.png'}")
    plt.close()

    # Categorical features vs default
    categorical_cols = ['education', 'employment_type', 'home_ownership', 'loan_purpose']

    fig, axes = plt.subplots(2, 2, figsize=(16, 10))
    axes = axes.flatten()

    for idx, col in enumerate(categorical_cols):
        ax = axes[idx]
        default_by_cat = df.groupby(col)['default'].agg(['sum', 'count'])
        default_by_cat['default_rate'] = (default_by_cat['sum'] / default_by_cat['count'] * 100).round(2)

        default_by_cat['default_rate'].plot(kind='bar', ax=ax, color='indianred', edgecolor='black')
        ax.set_title(f'Default Rate by {col}', fontsize=11, fontweight='bold')
        ax.set_xlabel(col)
        ax.set_ylabel('Default Rate (%)')
        ax.tick_params(axis='x', rotation=45)
        ax.grid(True, alpha=0.3, axis='y')

        # Add percentage labels on bars
        for container in ax.containers:
            ax.bar_label(container, fmt='%.1f%%')

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / '05_default_rate_by_categorical.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {OUTPUT_DIR / '05_default_rate_by_categorical.png'}")
    plt.close()


# =============================================================================
# 6. CORRELATION ANALYSIS
# =============================================================================

def analyze_correlations(df):
    """Analyze correlations between numerical features"""

    print("\n" + "="*80)
    print("6. CORRELATION ANALYSIS")
    print("="*80)

    # Select numerical columns
    numerical_df = df.select_dtypes(include=[np.number])

    # Remove default_probability (target leakage)
    if 'default_probability' in numerical_df.columns:
        numerical_df = numerical_df.drop('default_probability', axis=1)

    # Compute correlation matrix
    corr_matrix = numerical_df.corr()

    # Plot correlation heatmap
    plt.figure(figsize=(14, 12))
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))  # Mask upper triangle
    sns.heatmap(corr_matrix, mask=mask, annot=True, fmt='.2f', cmap='coolwarm',
                center=0, square=True, linewidths=1, cbar_kws={"shrink": 0.8})
    plt.title('Feature Correlation Matrix', fontsize=16, fontweight='bold', pad=20)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / '06_correlation_matrix.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {OUTPUT_DIR / '06_correlation_matrix.png'}")
    plt.close()

    # Top correlations with default
    default_corr = corr_matrix['default'].drop('default').sort_values(ascending=False)
    print("\nTop Features Correlated with Default:")
    print(default_corr.head(10))

    # Visualize top correlations with default
    fig, ax = plt.subplots(figsize=(10, 8))
    default_corr_abs = default_corr.abs().sort_values(ascending=True)
    colors = ['red' if x < 0 else 'green' for x in default_corr[default_corr_abs.index]]
    default_corr[default_corr_abs.index].plot(kind='barh', ax=ax, color=colors, edgecolor='black')
    ax.set_title('Feature Correlation with Default', fontsize=14, fontweight='bold')
    ax.set_xlabel('Correlation Coefficient')
    ax.set_ylabel('Features')
    ax.axvline(x=0, color='black', linestyle='--', linewidth=1)
    ax.grid(True, alpha=0.3, axis='x')
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / '07_default_correlation.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {OUTPUT_DIR / '07_default_correlation.png'}")
    plt.close()


# =============================================================================
# 7. RISK SEGMENTATION
# =============================================================================

def analyze_risk_segments(df):
    """Analyze default rates across different risk segments"""

    print("\n" + "="*80)
    print("7. RISK SEGMENTATION ANALYSIS")
    print("="*80)

    # Credit score bands
    df['credit_score_band'] = pd.cut(df['credit_score'],
                                      bins=[0, 580, 670, 740, 800, 900],
                                      labels=['Poor', 'Fair', 'Good', 'Very Good', 'Excellent'])

    # Income bands
    df['income_band'] = pd.qcut(df['annual_income'],
                                  q=5,
                                  labels=['Very Low', 'Low', 'Medium', 'High', 'Very High'])

    # Analyze default rates by segments
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    # Credit score band
    score_default = df.groupby('credit_score_band')['default'].agg(['sum', 'count'])
    score_default['default_rate'] = (score_default['sum'] / score_default['count'] * 100).round(2)

    score_default['default_rate'].plot(kind='bar', ax=axes[0], color='steelblue', edgecolor='black')
    axes[0].set_title('Default Rate by Credit Score Band', fontsize=13, fontweight='bold')
    axes[0].set_xlabel('Credit Score Band')
    axes[0].set_ylabel('Default Rate (%)')
    axes[0].tick_params(axis='x', rotation=45)
    axes[0].grid(True, alpha=0.3, axis='y')

    for container in axes[0].containers:
        axes[0].bar_label(container, fmt='%.1f%%')

    # Income band
    income_default = df.groupby('income_band')['default'].agg(['sum', 'count'])
    income_default['default_rate'] = (income_default['sum'] / income_default['count'] * 100).round(2)

    income_default['default_rate'].plot(kind='bar', ax=axes[1], color='darkorange', edgecolor='black')
    axes[1].set_title('Default Rate by Income Band', fontsize=13, fontweight='bold')
    axes[1].set_xlabel('Income Band')
    axes[1].set_ylabel('Default Rate (%)')
    axes[1].tick_params(axis='x', rotation=45)
    axes[1].grid(True, alpha=0.3, axis='y')

    for container in axes[1].containers:
        axes[1].bar_label(container, fmt='%.1f%%')

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / '08_risk_segmentation.png', dpi=300, bbox_inches='tight')
    print(f"\nSaved: {OUTPUT_DIR / '08_risk_segmentation.png'}")
    plt.close()

    print("\nDefault Rate by Credit Score Band:")
    print(score_default)

    print("\nDefault Rate by Income Band:")
    print(income_default)


# =============================================================================
# MAIN EXECUTION
# =============================================================================

if __name__ == "__main__":
    # Run all analyses
    analyze_data_quality(df)
    analyze_target(df)
    analyze_numerical_features(df)
    analyze_categorical_features(df)
    analyze_features_vs_target(df)
    analyze_correlations(df)
    analyze_risk_segments(df)

    print("\n" + "="*80)
    print("EDA COMPLETE!")
    print(f"All visualizations saved to: {OUTPUT_DIR}")
    print("="*80 + "\n")
