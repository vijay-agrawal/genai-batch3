"""
Feature Engineering for Credit Risk Dataset

Creates derived features, handles missing values, encodes categorical variables,
and prepares train/test splits for modeling.
"""

import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
import joblib
import warnings
warnings.filterwarnings('ignore')

# Configuration
RANDOM_STATE = 42
TEST_SIZE = 0.2

# Paths
DATA_DIR = Path("data")
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)

MODELS_DIR = Path("models")
MODELS_DIR.mkdir(parents=True, exist_ok=True)

print("="*80)
print("FEATURE ENGINEERING - CREDIT RISK")
print("="*80)

# Load data
print("\nLoading raw data...")
df = pd.read_csv(RAW_DIR / "credit_risk_data.csv")
print(f"Dataset shape: {df.shape}")
print(f"Default rate: {df['default'].mean():.2%}\n")

# =============================================================================
# 1. HANDLE MISSING VALUES
# =============================================================================

def handle_missing_values(df):
    """Impute missing values with appropriate strategies"""

    print("\n" + "="*80)
    print("1. HANDLING MISSING VALUES")
    print("="*80)

    df_clean = df.copy()

    # Check missing values
    missing = df_clean.isnull().sum()
    missing = missing[missing > 0]

    if len(missing) > 0:
        print("\nMissing values found:")
        for col, count in missing.items():
            print(f"  {col}: {count} ({count/len(df):.1%})")

        # Imputation strategies
        # Numerical: median
        numerical_missing = ['employment_length', 'monthly_debt']
        for col in numerical_missing:
            if col in df_clean.columns and df_clean[col].isnull().any():
                median_val = df_clean[col].median()
                df_clean[col].fillna(median_val, inplace=True)
                print(f"\n  Imputed {col} with median: {median_val:.2f}")

        # Categorical: mode or 'Unknown'
        if 'num_late_payments' in df_clean.columns and df_clean['num_late_payments'].isnull().any():
            mode_val = df_clean['num_late_payments'].mode()[0]
            df_clean['num_late_payments'].fillna(mode_val, inplace=True)
            print(f"  Imputed num_late_payments with mode: {mode_val}")
    else:
        print("\nNo missing values found")

    return df_clean


# =============================================================================
# 2. CREATE DERIVED FEATURES
# =============================================================================

def create_derived_features(df):
    """Create new features from existing ones"""

    print("\n" + "="*80)
    print("2. CREATING DERIVED FEATURES")
    print("="*80)

    df_eng = df.copy()

    # 1. Debt-to-Income Ratio
    df_eng['debt_to_income_ratio'] = (df_eng['monthly_debt'] * 12) / df_eng['annual_income']
    df_eng['debt_to_income_ratio'] = df_eng['debt_to_income_ratio'].clip(0, 2)  # Cap at 200%
    print("\n✓ Created: debt_to_income_ratio")

    # 2. Loan-to-Income Ratio
    df_eng['loan_to_income_ratio'] = df_eng['loan_amount'] / df_eng['annual_income']
    df_eng['loan_to_income_ratio'] = df_eng['loan_to_income_ratio'].clip(0, 5)
    print("✓ Created: loan_to_income_ratio")

    # 3. Monthly Payment Estimate (simple: loan / term)
    df_eng['monthly_payment_estimate'] = df_eng['loan_amount'] / df_eng['loan_term']
    print("✓ Created: monthly_payment_estimate")

    # 4. Payment-to-Income Ratio
    df_eng['payment_to_income_ratio'] = (df_eng['monthly_payment_estimate'] /
                                          (df_eng['annual_income'] / 12))
    df_eng['payment_to_income_ratio'] = df_eng['payment_to_income_ratio'].clip(0, 1)
    print("✓ Created: payment_to_income_ratio")

    # 5. Credit Utilization Bins
    df_eng['credit_util_category'] = pd.cut(
        df_eng['credit_utilization'],
        bins=[0, 0.3, 0.6, 1.0],
        labels=['Low', 'Medium', 'High']
    )
    print("✓ Created: credit_util_category")

    # 6. Credit Score Bins
    df_eng['credit_score_category'] = pd.cut(
        df_eng['credit_score'],
        bins=[0, 580, 670, 740, 800, 900],
        labels=['Poor', 'Fair', 'Good', 'Very Good', 'Excellent']
    )
    print("✓ Created: credit_score_category")

    # 7. Age Groups
    df_eng['age_group'] = pd.cut(
        df_eng['age'],
        bins=[0, 25, 35, 45, 55, 100],
        labels=['18-25', '26-35', '36-45', '46-55', '56+']
    )
    print("✓ Created: age_group")

    # 8. Income Bins (quintiles)
    df_eng['income_category'] = pd.qcut(
        df_eng['annual_income'],
        q=5,
        labels=['Very Low', 'Low', 'Medium', 'High', 'Very High']
    )
    print("✓ Created: income_category")

    # 9. Employment Stability Score
    df_eng['employment_stability'] = (
        (df_eng['employment_length'] / df_eng['age']) * 100
    ).clip(0, 100)
    print("✓ Created: employment_stability")

    # 10. Has Late Payments Flag
    df_eng['has_late_payments'] = (df_eng['num_late_payments'] > 0).astype(int)
    print("✓ Created: has_late_payments")

    # 11. High Risk Flag (multiple risk factors)
    df_eng['high_risk_flag'] = (
        ((df_eng['credit_score'] < 640) &
         (df_eng['credit_utilization'] > 0.7)) |
        ((df_eng['num_late_payments'] >= 2) &
         (df_eng['bankruptcies'] == 1))
    ).astype(int)
    print("✓ Created: high_risk_flag")

    # 12. Total Debt Load
    df_eng['total_debt_load'] = df_eng['monthly_debt'] * 12 + df_eng['loan_amount']
    print("✓ Created: total_debt_load")

    print(f"\nTotal derived features created: 12")
    print(f"New dataset shape: {df_eng.shape}")

    return df_eng


# =============================================================================
# 3. ENCODE CATEGORICAL VARIABLES
# =============================================================================

def encode_categorical_features(df):
    """Encode categorical variables for modeling"""

    print("\n" + "="*80)
    print("3. ENCODING CATEGORICAL VARIABLES")
    print("="*80)

    df_encoded = df.copy()
    encoders = {}

    # Categorical columns to encode
    categorical_cols = [
        'gender', 'education', 'marital_status', 'employment_type',
        'home_ownership', 'loan_purpose',
        'credit_util_category', 'credit_score_category',
        'age_group', 'income_category'
    ]

    # One-Hot Encoding for nominal variables
    nominal_cols = ['gender', 'employment_type', 'home_ownership', 'loan_purpose']

    print("\nOne-Hot Encoding:")
    for col in nominal_cols:
        if col in df_encoded.columns:
            dummies = pd.get_dummies(df_encoded[col], prefix=col, drop_first=True)
            df_encoded = pd.concat([df_encoded, dummies], axis=1)
            df_encoded.drop(col, axis=1, inplace=True)
            print(f"  ✓ {col} → {len(dummies.columns)} dummy variables")

    # Ordinal Encoding for ordinal variables
    ordinal_mappings = {
        'education': {
            'High School': 1,
            'Some College': 2,
            'Bachelor': 3,
            'Master': 4,
            'PhD': 5
        },
        'credit_util_category': {
            'Low': 1,
            'Medium': 2,
            'High': 3
        },
        'credit_score_category': {
            'Poor': 1,
            'Fair': 2,
            'Good': 3,
            'Very Good': 4,
            'Excellent': 5
        },
        'age_group': {
            '18-25': 1,
            '26-35': 2,
            '36-45': 3,
            '46-55': 4,
            '56+': 5
        },
        'income_category': {
            'Very Low': 1,
            'Low': 2,
            'Medium': 3,
            'High': 4,
            'Very High': 5
        },
        'marital_status': {
            'Single': 1,
            'Married': 2,
            'Divorced': 3,
            'Widowed': 4
        }
    }

    print("\nOrdinal Encoding:")
    for col, mapping in ordinal_mappings.items():
        if col in df_encoded.columns:
            df_encoded[col] = df_encoded[col].map(mapping)
            encoders[col] = mapping
            print(f"  ✓ {col} (levels: {len(mapping)})")

    # Save encoders
    joblib.dump(encoders, MODELS_DIR / 'encoders.pkl')
    print(f"\nEncoders saved to: {MODELS_DIR / 'encoders.pkl'}")

    return df_encoded, encoders


# =============================================================================
# 4. FEATURE SELECTION
# =============================================================================

def select_features(df):
    """Select final feature set for modeling"""

    print("\n" + "="*80)
    print("4. FEATURE SELECTION")
    print("="*80)

    # Remove target leakage and ID columns
    columns_to_drop = [
        'default',  # Target
        'default_probability',  # Target leakage (synthetic generation artifact)
    ]

    # Drop if they exist
    columns_to_drop = [col for col in columns_to_drop if col in df.columns]

    feature_cols = [col for col in df.columns if col not in columns_to_drop]

    print(f"\nTotal features selected: {len(feature_cols)}")
    print(f"Features: {feature_cols[:10]}... (showing first 10)")

    # Save feature names
    with open(PROCESSED_DIR / 'feature_names.txt', 'w') as f:
        for feat in feature_cols:
            f.write(f"{feat}\n")

    print(f"Feature names saved to: {PROCESSED_DIR / 'feature_names.txt'}")

    return feature_cols


# =============================================================================
# 5. TRAIN-TEST SPLIT
# =============================================================================

def create_train_test_split(df, feature_cols):
    """Create stratified train-test split"""

    print("\n" + "="*80)
    print("5. TRAIN-TEST SPLIT")
    print("="*80)

    # Prepare X and y
    X = df[feature_cols]
    y = df['default']

    # Stratified split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=y
    )

    print(f"\nTrain set: {X_train.shape[0]:,} samples ({X_train.shape[0]/len(df):.1%})")
    print(f"Test set: {X_test.shape[0]:,} samples ({X_test.shape[0]/len(df):.1%})")
    print(f"\nTrain default rate: {y_train.mean():.2%}")
    print(f"Test default rate: {y_test.mean():.2%}")

    # Save splits
    X_train.to_csv(PROCESSED_DIR / 'X_train.csv', index=False)
    X_test.to_csv(PROCESSED_DIR / 'X_test.csv', index=False)
    y_train.to_csv(PROCESSED_DIR / 'y_train.csv', index=False)
    y_test.to_csv(PROCESSED_DIR / 'y_test.csv', index=False)

    print(f"\nData splits saved to: {PROCESSED_DIR}")

    return X_train, X_test, y_train, y_test


# =============================================================================
# 6. OPTIONAL: FEATURE SCALING
# =============================================================================

def scale_features(X_train, X_test):
    """
    Optional: Scale features using StandardScaler
    Note: Tree-based models don't require scaling, but keep for logistic regression
    """

    print("\n" + "="*80)
    print("6. FEATURE SCALING (Optional - for Linear Models)")
    print("="*80)

    scaler = StandardScaler()

    # Fit on training data only
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Convert back to DataFrame
    X_train_scaled = pd.DataFrame(X_train_scaled, columns=X_train.columns, index=X_train.index)
    X_test_scaled = pd.DataFrame(X_test_scaled, columns=X_test.columns, index=X_test.index)

    # Save scaler
    joblib.dump(scaler, MODELS_DIR / 'scaler.pkl')
    print(f"\nScaler saved to: {MODELS_DIR / 'scaler.pkl'}")

    # Save scaled data
    X_train_scaled.to_csv(PROCESSED_DIR / 'X_train_scaled.csv', index=False)
    X_test_scaled.to_csv(PROCESSED_DIR / 'X_test_scaled.csv', index=False)

    print(f"Scaled data saved to: {PROCESSED_DIR}")
    print("\nNote: Use unscaled data for tree-based models (Random Forest, XGBoost, LightGBM)")
    print("      Use scaled data for linear models (Logistic Regression)")

    return X_train_scaled, X_test_scaled, scaler


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """Run complete feature engineering pipeline"""

    # 1. Handle missing values
    df_clean = handle_missing_values(df)

    # 2. Create derived features
    df_engineered = create_derived_features(df_clean)

    # 3. Encode categorical variables
    df_encoded, encoders = encode_categorical_features(df_engineered)

    # 4. Select features
    feature_cols = select_features(df_encoded)

    # 5. Train-test split
    X_train, X_test, y_train, y_test = create_train_test_split(df_encoded, feature_cols)

    # 6. Scale features (optional)
    X_train_scaled, X_test_scaled, scaler = scale_features(X_train, X_test)

    print("\n" + "="*80)
    print("FEATURE ENGINEERING COMPLETE!")
    print("="*80)

    print("\nSummary:")
    print(f"  Total features: {len(feature_cols)}")
    print(f"  Training samples: {X_train.shape[0]:,}")
    print(f"  Test samples: {X_test.shape[0]:,}")
    print(f"  Class balance (train): {y_train.mean():.2%} default")

    print("\nFiles created:")
    print(f"  {PROCESSED_DIR / 'X_train.csv'}")
    print(f"  {PROCESSED_DIR / 'X_test.csv'}")
    print(f"  {PROCESSED_DIR / 'y_train.csv'}")
    print(f"  {PROCESSED_DIR / 'y_test.csv'}")
    print(f"  {PROCESSED_DIR / 'X_train_scaled.csv'} (for linear models)")
    print(f"  {PROCESSED_DIR / 'X_test_scaled.csv'} (for linear models)")
    print(f"  {PROCESSED_DIR / 'feature_names.txt'}")
    print(f"  {MODELS_DIR / 'encoders.pkl'}")
    print(f"  {MODELS_DIR / 'scaler.pkl'}")

    print("\n" + "="*80 + "\n")


if __name__ == "__main__":
    main()
