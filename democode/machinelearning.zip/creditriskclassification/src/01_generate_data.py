"""
Synthetic Credit Risk Dataset Generator

Generates realistic loan application data with appropriate correlations
between features and default probability.
"""

import numpy as np
import pandas as pd
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Set random seed for reproducibility
np.random.seed(42)

# Configuration
N_SAMPLES = 50000
DEFAULT_RATE = 0.15  # 15% default rate (realistic for subprime lending)

# Create output directories
DATA_DIR = Path("data")
RAW_DIR = DATA_DIR / "raw"
RAW_DIR.mkdir(parents=True, exist_ok=True)

print("="*80)
print("CREDIT RISK SYNTHETIC DATA GENERATOR")
print("="*80)
print(f"\nGenerating {N_SAMPLES:,} loan applications...")
print(f"Target default rate: {DEFAULT_RATE:.1%}\n")

def generate_correlated_features():
    """Generate features with realistic correlations"""

    # 1. DEMOGRAPHIC FEATURES
    age = np.random.normal(40, 12, N_SAMPLES).clip(18, 75)

    gender = np.random.choice(['Male', 'Female'], N_SAMPLES)

    education_levels = ['High School', 'Some College', 'Bachelor', 'Master', 'PhD']
    education_probs = [0.3, 0.25, 0.30, 0.12, 0.03]
    education = np.random.choice(education_levels, N_SAMPLES, p=education_probs)

    marital_status = np.random.choice(
        ['Single', 'Married', 'Divorced', 'Widowed'],
        N_SAMPLES,
        p=[0.35, 0.45, 0.15, 0.05]
    )

    num_dependents = np.random.poisson(0.8, N_SAMPLES).clip(0, 5)

    # 2. EMPLOYMENT AND INCOME
    # Education affects income
    education_income_mult = {
        'High School': 0.7,
        'Some College': 0.85,
        'Bachelor': 1.0,
        'Master': 1.3,
        'PhD': 1.5
    }

    base_income = np.random.lognormal(10.8, 0.6, N_SAMPLES)  # Median ~$50k
    income_multiplier = np.array([education_income_mult[e] for e in education])
    annual_income = (base_income * income_multiplier).clip(15000, 500000)

    employment_length = np.random.exponential(5, N_SAMPLES).clip(0, 40)

    employment_type = np.random.choice(
        ['Full-time', 'Part-time', 'Self-employed', 'Contract'],
        N_SAMPLES,
        p=[0.70, 0.10, 0.15, 0.05]
    )

    home_ownership = np.random.choice(
        ['Own', 'Mortgage', 'Rent'],
        N_SAMPLES,
        p=[0.25, 0.40, 0.35]
    )

    # 3. CREDIT HISTORY
    # Base credit score with some correlation to income and age
    base_credit_score = (
        600 +
        (annual_income / 1000) * 0.3 +  # Income effect
        age * 1.5 +                      # Age effect
        employment_length * 2 +          # Employment stability effect
        np.random.normal(0, 50, N_SAMPLES)  # Random noise
    ).clip(300, 850)

    credit_score = base_credit_score.astype(int)

    # Number of credit lines (correlated with age and credit score)
    num_credit_lines = (
        age / 10 +
        (credit_score - 300) / 100 +
        np.random.poisson(2, N_SAMPLES)
    ).clip(0, 20).astype(int)

    # Total credit limit (correlated with income and credit score)
    total_credit_limit = (
        annual_income * 0.5 * (credit_score / 700) +
        np.random.normal(0, 5000, N_SAMPLES)
    ).clip(500, 200000)

    # Credit utilization (inverse correlation with credit score)
    credit_utilization = (
        0.6 - (credit_score - 300) / 1000 +
        np.random.normal(0, 0.15, N_SAMPLES)
    ).clip(0, 1)

    # Late payments (more likely with lower credit score)
    late_payment_prob = 1 - (credit_score - 300) / 550
    num_late_payments = (
        np.random.binomial(10, late_payment_prob) *
        np.random.binomial(1, 0.3, N_SAMPLES)  # Only 30% have any late payments
    ).clip(0, 10)

    # Bankruptcies (rare, more likely with lower credit score)
    bankruptcy_prob = ((700 - credit_score) / 1000).clip(0, 0.15)
    bankruptcies = np.random.binomial(1, bankruptcy_prob)

    # Monthly debt (correlated with income)
    monthly_debt = (
        annual_income / 12 * np.random.uniform(0.1, 0.5, N_SAMPLES)
    ).clip(0, annual_income/12 * 0.8)

    # 4. LOAN DETAILS
    loan_amount = (
        annual_income * np.random.uniform(0.1, 2.0, N_SAMPLES)
    ).clip(1000, 100000)

    loan_purpose = np.random.choice(
        ['Debt Consolidation', 'Home Improvement', 'Business', 'Car', 'Medical', 'Other'],
        N_SAMPLES,
        p=[0.35, 0.20, 0.15, 0.15, 0.10, 0.05]
    )

    loan_term = np.random.choice([12, 24, 36, 48, 60], N_SAMPLES, p=[0.10, 0.20, 0.35, 0.20, 0.15])

    # Create DataFrame
    df = pd.DataFrame({
        # Demographics
        'age': age.round(0).astype(int),
        'gender': gender,
        'education': education,
        'marital_status': marital_status,
        'num_dependents': num_dependents,

        # Employment & Income
        'annual_income': annual_income.round(2),
        'employment_length': employment_length.round(1),
        'employment_type': employment_type,
        'home_ownership': home_ownership,
        'monthly_debt': monthly_debt.round(2),

        # Credit History
        'credit_score': credit_score,
        'num_credit_lines': num_credit_lines,
        'total_credit_limit': total_credit_limit.round(2),
        'credit_utilization': credit_utilization.round(3),
        'num_late_payments': num_late_payments,
        'bankruptcies': bankruptcies,

        # Loan Details
        'loan_amount': loan_amount.round(2),
        'loan_purpose': loan_purpose,
        'loan_term': loan_term,
    })

    return df


def generate_default_target(df):
    """
    Generate default labels based on risk factors

    Key risk factors (from credit risk literature):
    - Low credit score
    - High credit utilization
    - Recent late payments
    - Bankruptcy history
    - High debt-to-income ratio
    - Low income
    - Short employment history
    """

    # Calculate risk score (higher = more risky)
    risk_score = (
        # Credit score effect (most important)
        (700 - df['credit_score']) / 100 * 3.0 +

        # Credit utilization effect
        df['credit_utilization'] * 2.0 +

        # Late payments effect
        df['num_late_payments'] * 0.5 +

        # Bankruptcy effect
        df['bankruptcies'] * 2.5 +

        # Debt-to-income ratio effect
        (df['monthly_debt'] / (df['annual_income'] / 12)) * 1.5 +

        # Employment stability effect (inverse)
        -df['employment_length'] / 10 * 0.3 +

        # Income effect (inverse, log scale)
        -np.log(df['annual_income'] / 10000) * 0.5 +

        # Loan amount to income ratio
        (df['loan_amount'] / df['annual_income']) * 0.8 +

        # Random noise
        np.random.normal(0, 1, len(df))
    )

    # Convert risk score to probability using logistic function
    default_probability = 1 / (1 + np.exp(-risk_score + 5))  # Shift to get ~15% default rate

    # Generate binary default outcome
    default = (np.random.random(len(df)) < default_probability).astype(int)

    print(f"Actual default rate: {default.mean():.2%}")
    print(f"Default probability range: {default_probability.min():.3f} - {default_probability.max():.3f}")

    df['default_probability'] = default_probability.round(4)  # Keep for reference
    df['default'] = default

    return df


def add_missing_values(df, missing_rate=0.02):
    """
    Add realistic missing values to simulate real-world data

    Missing patterns:
    - Employment length: Sometimes not reported
    - Credit history: May be unavailable for thin-file applicants
    """

    df_copy = df.copy()

    # Features that might have missing values
    missing_candidates = ['employment_length', 'num_late_payments', 'monthly_debt']

    for col in missing_candidates:
        mask = np.random.random(len(df)) < missing_rate
        df_copy.loc[mask, col] = np.nan

    missing_summary = df_copy.isnull().sum()
    missing_summary = missing_summary[missing_summary > 0]

    if len(missing_summary) > 0:
        print("\nMissing values added:")
        for col, count in missing_summary.items():
            print(f"  {col}: {count} ({count/len(df):.1%})")

    return df_copy


def generate_dataset():
    """Main function to generate complete dataset"""

    # Generate features
    print("Generating features...")
    df = generate_correlated_features()

    # Generate target variable
    print("\nGenerating default labels...")
    df = generate_default_target(df)

    # Add missing values
    print("\nAdding realistic missing values...")
    df = add_missing_values(df, missing_rate=0.02)

    # Shuffle the dataset
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)

    # Save dataset
    output_path = RAW_DIR / "credit_risk_data.csv"
    df.to_csv(output_path, index=False)

    print(f"\n{'='*80}")
    print(f"Dataset saved to: {output_path}")
    print(f"{'='*80}")

    # Print summary statistics
    print("\nDataset Summary:")
    print(f"  Total samples: {len(df):,}")
    print(f"  Features: {len(df.columns) - 2}")  # Exclude default and default_probability
    print(f"  Default cases: {df['default'].sum():,} ({df['default'].mean():.2%})")
    print(f"  Non-default cases: {(~df['default'].astype(bool)).sum():,} ({(~df['default'].astype(bool)).mean():.2%})")

    print("\nFeature Statistics:")
    print(df.describe().round(2))

    print("\nCategorical Feature Distributions:")
    categorical_cols = df.select_dtypes(include='object').columns
    for col in categorical_cols:
        print(f"\n{col}:")
        print(df[col].value_counts())

    print(f"\n{'='*80}")
    print("Data generation complete!")
    print(f"{'='*80}\n")

    return df


if __name__ == "__main__":
    df = generate_dataset()
