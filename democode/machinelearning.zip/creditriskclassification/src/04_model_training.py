"""
Model Training and Selection for Credit Risk Prediction

Trains multiple classification models and selects the best performer based on
cross-validation results and test set performance.
"""

import numpy as np
import pandas as pd
from pathlib import Path
import joblib
import time
import warnings
warnings.filterwarnings('ignore')

# Sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.metrics import (
    roc_auc_score, precision_score, recall_score, f1_score,
    log_loss, classification_report, confusion_matrix
)

# Gradient Boosting
import xgboost as xgb
import lightgbm as lgb

# Configuration
RANDOM_STATE = 42
CV_FOLDS = 5

# Paths
DATA_DIR = Path("data/processed")
MODELS_DIR = Path("models")
MODELS_DIR.mkdir(parents=True, exist_ok=True)

print("="*80)
print("MODEL TRAINING - CREDIT RISK PREDICTION")
print("="*80)

# Load processed data
print("\nLoading processed data...")
X_train = pd.read_csv(DATA_DIR / "X_train.csv")
X_test = pd.read_csv(DATA_DIR / "X_test.csv")
y_train = pd.read_csv(DATA_DIR / "y_train.csv").values.ravel()
y_test = pd.read_csv(DATA_DIR / "y_test.csv").values.ravel()

# Load scaled data for logistic regression
X_train_scaled = pd.read_csv(DATA_DIR / "X_train_scaled.csv")
X_test_scaled = pd.read_csv(DATA_DIR / "X_test_scaled.csv")

print(f"Training set: {X_train.shape}")
print(f"Test set: {X_test.shape}")
print(f"Default rate (train): {y_train.mean():.2%}")
print(f"Default rate (test): {y_test.mean():.2%}\n")

# =============================================================================
# CROSS-VALIDATION SETUP
# =============================================================================

def evaluate_model_cv(model, X, y, model_name):
    """
    Evaluate model using stratified k-fold cross-validation

    Returns:
        dict: Cross-validation scores for multiple metrics
    """

    print(f"\n{'='*80}")
    print(f"Cross-Validating: {model_name}")
    print(f"{'='*80}")

    cv = StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)

    start_time = time.time()

    # AUC-ROC
    auc_scores = cross_val_score(model, X, y, cv=cv, scoring='roc_auc', n_jobs=-1)

    # Precision
    precision_scores = cross_val_score(model, X, y, cv=cv, scoring='precision', n_jobs=-1)

    # Recall
    recall_scores = cross_val_score(model, X, y, cv=cv, scoring='recall', n_jobs=-1)

    # F1
    f1_scores = cross_val_score(model, X, y, cv=cv, scoring='f1', n_jobs=-1)

    elapsed_time = time.time() - start_time

    # Print results
    print(f"\nCross-Validation Results ({CV_FOLDS}-Fold):")
    print(f"  AUC-ROC:   {auc_scores.mean():.4f} (+/- {auc_scores.std():.4f})")
    print(f"  Precision: {precision_scores.mean():.4f} (+/- {precision_scores.std():.4f})")
    print(f"  Recall:    {recall_scores.mean():.4f} (+/- {recall_scores.std():.4f})")
    print(f"  F1-Score:  {f1_scores.mean():.4f} (+/- {f1_scores.std():.4f})")
    print(f"\nTraining time: {elapsed_time:.2f} seconds")

    return {
        'model_name': model_name,
        'auc_mean': auc_scores.mean(),
        'auc_std': auc_scores.std(),
        'precision_mean': precision_scores.mean(),
        'precision_std': precision_scores.std(),
        'recall_mean': recall_scores.mean(),
        'recall_std': recall_scores.std(),
        'f1_mean': f1_scores.mean(),
        'f1_std': f1_scores.std(),
        'training_time': elapsed_time
    }


# =============================================================================
# MODEL 1: LOGISTIC REGRESSION (Baseline)
# =============================================================================

def train_logistic_regression():
    """Train Logistic Regression baseline model"""

    print("\n" + "="*80)
    print("MODEL 1: LOGISTIC REGRESSION (Baseline)")
    print("="*80)

    # Initialize model
    model = LogisticRegression(
        max_iter=1000,
        class_weight='balanced',  # Handle class imbalance
        random_state=RANDOM_STATE,
        n_jobs=-1
    )

    # Cross-validation
    cv_results = evaluate_model_cv(model, X_train_scaled, y_train, "Logistic Regression")

    # Train on full training set
    print("\nTraining on full training set...")
    model.fit(X_train_scaled, y_train)

    # Evaluate on test set
    y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]
    y_pred = model.predict(X_test_scaled)

    test_auc = roc_auc_score(y_test, y_pred_proba)
    test_precision = precision_score(y_test, y_pred)
    test_recall = recall_score(y_test, y_pred)
    test_f1 = f1_score(y_test, y_pred)
    test_logloss = log_loss(y_test, y_pred_proba)

    print("\nTest Set Performance:")
    print(f"  AUC-ROC:   {test_auc:.4f}")
    print(f"  Precision: {test_precision:.4f}")
    print(f"  Recall:    {test_recall:.4f}")
    print(f"  F1-Score:  {test_f1:.4f}")
    print(f"  Log Loss:  {test_logloss:.4f}")

    # Save model
    joblib.dump(model, MODELS_DIR / "model_logistic.pkl")
    print(f"\nModel saved to: {MODELS_DIR / 'model_logistic.pkl'}")

    return model, cv_results, {
        'test_auc': test_auc,
        'test_precision': test_precision,
        'test_recall': test_recall,
        'test_f1': test_f1,
        'test_logloss': test_logloss
    }


# =============================================================================
# MODEL 2: RANDOM FOREST
# =============================================================================

def train_random_forest():
    """Train Random Forest model"""

    print("\n" + "="*80)
    print("MODEL 2: RANDOM FOREST")
    print("="*80)

    # Initialize model
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=15,
        min_samples_split=50,
        min_samples_leaf=20,
        class_weight='balanced',
        random_state=RANDOM_STATE,
        n_jobs=-1
    )

    # Cross-validation (use unscaled data for tree models)
    cv_results = evaluate_model_cv(model, X_train, y_train, "Random Forest")

    # Train on full training set
    print("\nTraining on full training set...")
    model.fit(X_train, y_train)

    # Evaluate on test set
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    y_pred = model.predict(X_test)

    test_auc = roc_auc_score(y_test, y_pred_proba)
    test_precision = precision_score(y_test, y_pred)
    test_recall = recall_score(y_test, y_pred)
    test_f1 = f1_score(y_test, y_pred)
    test_logloss = log_loss(y_test, y_pred_proba)

    print("\nTest Set Performance:")
    print(f"  AUC-ROC:   {test_auc:.4f}")
    print(f"  Precision: {test_precision:.4f}")
    print(f"  Recall:    {test_recall:.4f}")
    print(f"  F1-Score:  {test_f1:.4f}")
    print(f"  Log Loss:  {test_logloss:.4f}")

    # Feature importance
    feature_importance = pd.DataFrame({
        'feature': X_train.columns,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)

    print("\nTop 10 Most Important Features:")
    print(feature_importance.head(10).to_string(index=False))

    # Save model and feature importance
    joblib.dump(model, MODELS_DIR / "model_random_forest.pkl")
    feature_importance.to_csv(MODELS_DIR / "feature_importance_rf.csv", index=False)
    print(f"\nModel saved to: {MODELS_DIR / 'model_random_forest.pkl'}")

    return model, cv_results, {
        'test_auc': test_auc,
        'test_precision': test_precision,
        'test_recall': test_recall,
        'test_f1': test_f1,
        'test_logloss': test_logloss
    }


# =============================================================================
# MODEL 3: XGBOOST
# =============================================================================

def train_xgboost():
    """Train XGBoost model"""

    print("\n" + "="*80)
    print("MODEL 3: XGBOOST")
    print("="*80)

    # Calculate scale_pos_weight for class imbalance
    scale_pos_weight = (y_train == 0).sum() / (y_train == 1).sum()

    # Initialize model
    model = xgb.XGBClassifier(
        n_estimators=100,
        max_depth=6,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale_pos_weight,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        eval_metric='logloss'
    )

    # Cross-validation
    cv_results = evaluate_model_cv(model, X_train, y_train, "XGBoost")

    # Train on full training set
    print("\nTraining on full training set...")
    model.fit(X_train, y_train)

    # Evaluate on test set
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    y_pred = model.predict(X_test)

    test_auc = roc_auc_score(y_test, y_pred_proba)
    test_precision = precision_score(y_test, y_pred)
    test_recall = recall_score(y_test, y_pred)
    test_f1 = f1_score(y_test, y_pred)
    test_logloss = log_loss(y_test, y_pred_proba)

    print("\nTest Set Performance:")
    print(f"  AUC-ROC:   {test_auc:.4f}")
    print(f"  Precision: {test_precision:.4f}")
    print(f"  Recall:    {test_recall:.4f}")
    print(f"  F1-Score:  {test_f1:.4f}")
    print(f"  Log Loss:  {test_logloss:.4f}")

    # Feature importance
    feature_importance = pd.DataFrame({
        'feature': X_train.columns,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)

    print("\nTop 10 Most Important Features:")
    print(feature_importance.head(10).to_string(index=False))

    # Save model and feature importance
    joblib.dump(model, MODELS_DIR / "model_xgboost.pkl")
    feature_importance.to_csv(MODELS_DIR / "feature_importance_xgb.csv", index=False)
    print(f"\nModel saved to: {MODELS_DIR / 'model_xgboost.pkl'}")

    return model, cv_results, {
        'test_auc': test_auc,
        'test_precision': test_precision,
        'test_recall': test_recall,
        'test_f1': test_f1,
        'test_logloss': test_logloss
    }


# =============================================================================
# MODEL 4: LIGHTGBM
# =============================================================================

def train_lightgbm():
    """Train LightGBM model"""

    print("\n" + "="*80)
    print("MODEL 4: LIGHTGBM")
    print("="*80)

    # Initialize model
    model = lgb.LGBMClassifier(
        n_estimators=100,
        num_leaves=31,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        is_unbalance=True,  # Handle class imbalance
        random_state=RANDOM_STATE,
        n_jobs=-1,
        verbose=-1
    )

    # Cross-validation
    cv_results = evaluate_model_cv(model, X_train, y_train, "LightGBM")

    # Train on full training set
    print("\nTraining on full training set...")
    model.fit(X_train, y_train)

    # Evaluate on test set
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    y_pred = model.predict(X_test)

    test_auc = roc_auc_score(y_test, y_pred_proba)
    test_precision = precision_score(y_test, y_pred)
    test_recall = recall_score(y_test, y_pred)
    test_f1 = f1_score(y_test, y_pred)
    test_logloss = log_loss(y_test, y_pred_proba)

    print("\nTest Set Performance:")
    print(f"  AUC-ROC:   {test_auc:.4f}")
    print(f"  Precision: {test_precision:.4f}")
    print(f"  Recall:    {test_recall:.4f}")
    print(f"  F1-Score:  {test_f1:.4f}")
    print(f"  Log Loss:  {test_logloss:.4f}")

    # Feature importance
    feature_importance = pd.DataFrame({
        'feature': X_train.columns,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)

    print("\nTop 10 Most Important Features:")
    print(feature_importance.head(10).to_string(index=False))

    # Save model and feature importance
    joblib.dump(model, MODELS_DIR / "model_lightgbm.pkl")
    feature_importance.to_csv(MODELS_DIR / "feature_importance_lgb.csv", index=False)
    print(f"\nModel saved to: {MODELS_DIR / 'model_lightgbm.pkl'}")

    return model, cv_results, {
        'test_auc': test_auc,
        'test_precision': test_precision,
        'test_recall': test_recall,
        'test_f1': test_f1,
        'test_logloss': test_logloss
    }


# =============================================================================
# MODEL COMPARISON
# =============================================================================

def compare_models(all_results):
    """Compare all trained models"""

    print("\n" + "="*80)
    print("MODEL COMPARISON SUMMARY")
    print("="*80)

    # Create comparison DataFrame
    comparison = pd.DataFrame(all_results)

    # Format for display
    comparison_display = comparison[[
        'model_name', 'cv_auc_mean', 'test_auc',
        'test_precision', 'test_recall', 'test_f1', 'test_logloss'
    ]].copy()

    comparison_display.columns = [
        'Model', 'CV AUC', 'Test AUC',
        'Precision', 'Recall', 'F1', 'Log Loss'
    ]

    print("\n" + comparison_display.to_string(index=False))

    # Identify best model
    best_model_idx = comparison['test_auc'].idxmax()
    best_model_name = comparison.loc[best_model_idx, 'model_name']
    best_model_auc = comparison.loc[best_model_idx, 'test_auc']

    print(f"\n{'='*80}")
    print(f"BEST MODEL: {best_model_name} (Test AUC: {best_model_auc:.4f})")
    print(f"{'='*80}")

    # Save comparison
    comparison.to_csv(MODELS_DIR / "model_comparison.csv", index=False)
    print(f"\nComparison saved to: {MODELS_DIR / 'model_comparison.csv'}")

    return comparison, best_model_name


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """Train all models and compare results"""

    all_results = []

    # Train models
    _, cv_lr, test_lr = train_logistic_regression()
    all_results.append({**cv_lr, **{f'test_{k}': v for k, v in test_lr.items()}, 'cv_auc_mean': cv_lr['auc_mean']})

    _, cv_rf, test_rf = train_random_forest()
    all_results.append({**cv_rf, **{f'test_{k}': v for k, v in test_rf.items()}, 'cv_auc_mean': cv_rf['auc_mean']})

    _, cv_xgb, test_xgb = train_xgboost()
    all_results.append({**cv_xgb, **{f'test_{k}': v for k, v in test_xgb.items()}, 'cv_auc_mean': cv_xgb['auc_mean']})

    _, cv_lgb, test_lgb = train_lightgbm()
    all_results.append({**cv_lgb, **{f'test_{k}': v for k, v in test_lgb.items()}, 'cv_auc_mean': cv_lgb['auc_mean']})

    # Compare models
    comparison, best_model = compare_models(all_results)

    print("\n" + "="*80)
    print("MODEL TRAINING COMPLETE!")
    print("="*80)

    print("\nNext steps:")
    print("  1. Run model evaluation script: python src/05_model_evaluation.py")
    print("  2. Generate SHAP explanations")
    print("  3. Analyze feature importance")
    print("  4. Select optimal decision threshold")

    print("\n" + "="*80 + "\n")


if __name__ == "__main__":
    main()
