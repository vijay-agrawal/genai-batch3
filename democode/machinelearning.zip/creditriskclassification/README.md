# Credit Risk Assessment Using Supervised Machine Learning

A comprehensive demonstration of credit risk modeling using machine learning to predict the probability of loan default.

## Problem Statement

**Objective**: Predict the probability of default for loan applicants based on historical data.

**Business Context**:
- Traditional credit scoring relies on rule-based scorecards (e.g., FICO scores)
- Machine Learning offers probabilistic predictions with better accuracy and explainability
- Critical for financial institutions to minimize default risk while maximizing loan approvals

## Project Structure

```
creditriskclassification/
├── README.md                          # This file
├── requirements.txt                   # Python dependencies
├── data/                              # Generated synthetic data
│   ├── raw/                          # Raw generated data
│   └── processed/                    # Processed features
├── notebooks/                         # Jupyter notebooks for exploration
│   └── credit_risk_analysis.ipynb   # Complete analysis notebook
├── src/                              # Source code
│   ├── 01_generate_data.py          # Synthetic data generation
│   ├── 02_eda.py                    # Exploratory Data Analysis
│   ├── 03_feature_engineering.py    # Feature creation and selection
│   ├── 04_model_training.py         # Model selection and training
│   ├── 05_model_evaluation.py       # Evaluation and explainability
│   └── utils.py                     # Helper functions
├── models/                           # Saved trained models
├── outputs/                          # Visualizations and reports
│   ├── eda/                         # EDA plots
│   ├── feature_importance/          # Feature analysis
│   ├── model_performance/           # Model metrics
│   └── explainability/              # SHAP and LIME outputs
└── docs/                            # Documentation
    └── ml_vs_rulebased.md          # Comparison guide
```

## Dataset Features

### Demographic Information
- Age
- Gender
- Education Level
- Marital Status
- Number of Dependents

### Financial Information
- Annual Income
- Monthly Debt Payments
- Employment Length
- Employment Type
- Home Ownership Status

### Credit History
- Credit Score (300-850)
- Number of Open Credit Lines
- Total Credit Limit
- Credit Utilization Ratio
- Number of Late Payments (past 2 years)
- Bankruptcies

### Loan Details
- Loan Amount
- Loan Purpose
- Loan Term

### Target Variable
- **Default** (0 = No Default, 1 = Default)

## Quick Start

### 1. Installation

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Generate Synthetic Data

```bash
python src/01_generate_data.py
```

This creates a realistic dataset of 50,000 loan applications with appropriate correlations and distributions.

### 3. Run Exploratory Data Analysis

```bash
python src/02_eda.py
```

Generates comprehensive visualizations and statistical summaries in `outputs/eda/`.

### 4. Feature Engineering

```bash
python src/03_feature_engineering.py
```

Creates derived features, handles missing values, and encodes categorical variables.

### 5. Train Models

```bash
python src/04_model_training.py
```

Trains multiple models:
- Logistic Regression (baseline)
- Random Forest
- Gradient Boosting (XGBoost)
- LightGBM

### 6. Evaluate and Explain

```bash
python src/05_model_evaluation.py
```

Generates:
- ROC curves and AUC scores
- Precision-Recall curves
- Confusion matrices
- SHAP values for model explainability
- Feature importance rankings

### 7. Interactive Notebook (Optional)

```bash
jupyter notebook notebooks/credit_risk_analysis.ipynb
```

## Key Concepts

### 1. Probability of Default (PD)
- ML models output probability scores (0-1)
- Threshold selection based on business objectives
- Trade-off between false positives and false negatives

### 2. Model Evaluation Metrics
- **AUC-ROC**: Overall discriminative ability
- **Precision**: Of predicted defaults, how many actually defaulted
- **Recall**: Of actual defaults, how many were predicted
- **F1-Score**: Harmonic mean of precision and recall
- **Log Loss**: Penalizes confident wrong predictions

### 3. Explainability
- **SHAP (SHapley Additive exPlanations)**: Unified approach to explain predictions
- **Feature Importance**: Which variables drive predictions
- **Partial Dependence Plots**: How features affect probability

## ML vs Rule-Based Scorecards

### Traditional Rule-Based Scorecards
- Fixed weight assignments (e.g., -5 points for late payment)
- Linear combinations
- Expert-defined rules
- Limited interaction terms
- Periodic manual updates

### Machine Learning Approach
- Data-driven weight learning
- Captures non-linear relationships
- Automatic interaction detection
- Continuous improvement with new data
- Probabilistic outputs with confidence intervals

**See [docs/ml_vs_rulebased.md](docs/ml_vs_rulebased.md) for detailed comparison**

### Examples Where ML Outshines Rule-Based Approaches

#### 1. Detecting Complex Feature Interactions
A rule-based system might reject an applicant with a credit score of 620 (below a 650 threshold). However, ML can learn that a 620 credit score combined with 10+ years of stable employment, low debt-to-income ratio, and no recent delinquencies actually represents a low-risk borrower. ML automatically captures these multi-way interactions that would require hundreds of manual rules to encode.

**Rule-Based**: Rejects based on single threshold → Missed opportunity
**ML Approach**: Considers holistic profile → Approves with 8% predicted default probability

#### 2. Handling Non-Linear Relationships
Income's relationship to default risk isn't linear. Very low income correlates with high default risk, but beyond a certain threshold, additional income provides diminishing risk reduction. Rule-based systems use arbitrary brackets ($0-30k: -20 points, $30-50k: +10 points), while ML learns the actual curved relationship from data, including income's varying impact at different debt levels.

**Rule-Based**: Flat scoring brackets miss nuance → Misprices risk
**ML Approach**: Learns true relationship curves → More accurate probability estimates

#### 3. Adapting to Changing Economic Conditions
When economic conditions shift (e.g., gig economy growth, remote work trends), rule-based scorecards become stale because they were built on historical assumptions. ML models can be retrained on recent data to capture new patterns—like recognizing that "self-employed, tech industry, high savings" now represents a different risk profile than it did 10 years ago.

**Rule-Based**: Static rules miss emerging patterns → Increasing error rates over time
**ML Approach**: Continuous learning from new data → Maintains accuracy through market changes

#### 4. Identifying Subtle Fraud and Misrepresentation Patterns
Fraudulent applications often exhibit subtle combinations of signals: slightly inconsistent address history, unusual application timing, specific patterns in stated income vs. employment type. Rule-based systems catch obvious fraud but miss sophisticated patterns. ML models can detect anomalies across dozens of features simultaneously, flagging applications that appear normal individually but are suspicious collectively.

**Rule-Based**: Catches obvious red flags only → Higher fraud losses
**ML Approach**: Detects subtle multi-feature anomalies → 40-60% better fraud detection

## Model Performance Expectations

For the synthetic dataset:
- **Baseline Logistic Regression**: AUC ~0.85
- **Random Forest**: AUC ~0.90
- **XGBoost**: AUC ~0.92
- **LightGBM**: AUC ~0.92

## Business Use Cases

1. **Automated Loan Approval**: Set threshold for automatic approval/rejection
2. **Risk-Based Pricing**: Interest rates based on predicted default probability
3. **Portfolio Risk Management**: Monitor aggregate risk across loan portfolio
4. **Early Warning System**: Identify high-risk accounts for intervention
5. **Regulatory Compliance**: Explainable decisions for fair lending requirements

## Regulatory Considerations

- **Fair Lending**: Model fairness across protected classes
- **Model Documentation**: Comprehensive model risk management
- **Explainability**: Adverse action notices require explanation
- **Monitoring**: Ongoing performance tracking and model decay detection
- **Stress Testing**: Model performance under adverse scenarios

## Next Steps

1. **Model Deployment**: API service for real-time predictions
2. **A/B Testing**: Compare against current scorecard
3. **Champion/Challenger**: Monitor performance over time
4. **Feedback Loop**: Incorporate actual outcomes to retrain
5. **Bias Detection**: Ensure fair treatment across demographics

## References

- Fair Isaac Corporation (FICO) Credit Scoring
- Basel II/III Capital Requirements
- Federal Reserve SR 11-7: Guidance on Model Risk Management
- SHAP: https://github.com/slundberg/shap
- XGBoost: https://xgboost.readthedocs.io/

## License

MIT License - Educational purposes only. Not for production use without proper validation and regulatory approval.

## Author

GenAI Training Demo
