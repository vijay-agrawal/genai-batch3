# RAG Conversational Chatbot - Streamlit Application

A modern, interactive Streamlit application for building conversational chatbots using Retrieval-Augmented Generation (RAG). Upload your documents and chat with your data while ensuring responses come only from your document context.

## Features

✨ **Key Capabilities**:
- 📁 **Dynamic Document Upload**: Upload PDF and Markdown files directly in the UI
- 🔍 **Automatic Indexing**: Files are indexed on-the-fly into a vector database
- 💬 **Conversational Interface**: Multi-turn conversations with session state management
- 📚 **Source Attribution**: See exactly which documents your answers come from
- 🛡️ **Context-Only Responses**: System prompt ensures answers come only from your documents, not LLM's prior knowledge
- 🗂️ **Temporary Storage**: Vector databases are isolated in temp directories
- ⚙️ **Adjustable Retrieval**: Configure how many document chunks to use for context

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Streamlit UI                                  │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │ Upload Files → Index Documents → Chat Interface             │ │
│  └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│              Document Processing Pipeline                         │
│  ┌──────────────┐ ┌─────────────┐ ┌──────────────┐             │
│  │ PDF/MD Load  │→│ Text Split  │→│ Embeddings   │             │
│  └──────────────┘ └─────────────┘ └──────────────┘             │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│              Vector Store (ChromaDB)                              │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │ Embedded Document Chunks (Temporary Directory)               │ │
│  └─────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│           RAG Chain (LangChain + Vertex AI)                       │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐             │
│  │ Retriever    │→│ Prompt Build │→│ Gemini LLM   │             │
│  └──────────────┘ └──────────────┘ └──────────────┘             │
└─────────────────────────────────────────────────────────────────┘
```

## Installation

### 1. Install Dependencies

```bash
cd rag_gemini
pip install -r requirements.txt
```

### 2. Set Up Google Cloud Credentials

Ensure your `.env` file is configured with:
```bash
GOOGLE_APPLICATION_CREDENTIALS=path/to/your/service-account-key.json
GOOGLE_VERTEXAI_PROJECT_ID=your-gcp-project-id
GOOGLE_VERTEXAI_LOCATION=us-central1
```

## Usage

### Start the Streamlit App

```bash
streamlit run app.py
```

The app will open in your browser at `http://localhost:8501`

### Using the Chatbot

1. **Upload Documents**
   - Click "Upload PDF or Markdown files" in the sidebar
   - Select one or more PDF or Markdown files
   - Files are shown with checkmarks

2. **Index Documents**
   - Click the green "🔍 Index Documents" button
   - The app processes files and creates embeddings
   - Status shows documents indexed and total chunks created

3. **Start Chatting**
   - Type your question in the chat input
   - The chatbot retrieves relevant context and responds
   - Sources are displayed with expandable section

4. **Manage Documents**
   - Use "🗑️ Clear Database" to remove all documents
   - Upload new files to replace existing documents
   - Adjust "Number of context chunks" in settings

## System Architecture Details

### Session State Management

The app uses Streamlit's `session_state` to maintain:
```python
- messages: Conversation history (user & assistant)
- vector_store: ChromaDB instance for current session
- vectordb_path: Temporary directory for vector database
- uploaded_files: Set of uploaded file names
- documents_indexed: Count of indexed pages
- current_chunks: Total chunks in database
```

### Document Processing

1. **File Upload**: Files saved to temporary directory
2. **Loading**: 
   - PDFs loaded with `PyPDFDirectoryLoader`
   - Markdown loaded with `UnstructuredMarkdownLoader`
3. **Chunking**: `RecursiveCharacterTextSplitter` with:
   - Chunk size: 1000 characters
   - Overlap: 200 characters (for context continuity)
4. **Embedding**: Vertex AI `gemini-embedding-001` model
5. **Storage**: ChromaDB persisted in temp directory

### RAG Chain Configuration

**System Prompt** (ensures context-only responses):
```
You are a helpful assistant that answers questions ONLY based on 
the provided context.

IMPORTANT RULES:
1. Answer ONLY from the provided context
2. Do NOT use your prior knowledge or training data
3. If the answer is not in the context, say "I cannot find..."
4. Be accurate and quote from the context when relevant
5. If asked about something not covered, explicitly state it's 
   not covered in the documents
```

**LLM Model**: Gemini 2.5 Flash
- Temperature: 0 (deterministic responses)
- Project: From environment variable
- Location: From environment variable

**Retrieval Settings**:
- Search type: Similarity search
- Default k: 3 (adjustable in UI)
- Returns top-k similar document chunks

## File Structure

```
rag_gemini/
├── app.py                      # Streamlit application (THIS FILE)
├── indexer.py                  # Document indexing utility
├── retriever.py                # Retrieval chain implementation
├── requirements.txt            # Python dependencies
├── README.md                   # This file
├── data/                       # Original documents (not used by app)
└── vectordb/                   # Default vector database (replaced by temp)
```

## Advanced Usage

### Customize System Prompt

Edit the `system_prompt` in the `create_rag_chain()` function:

```python
system_prompt = """Your custom system prompt here...
{context}
Question: {question}"""
```

### Adjust Chunking Strategy

Modify `RecursiveCharacterTextSplitter` parameters in `index_documents()`:

```python
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1500,        # Larger chunks
    chunk_overlap=300,      # More overlap
    length_function=len,
)
```

### Change Retrieval Model

Replace embedding model in `index_documents()`:

```python
embeddings = VertexAIEmbeddings(
    model_name="text-embedding-004"  # Newer model
)
```

## Troubleshooting

### "No documents indexed yet"
- **Cause**: Vector store not created
- **Solution**: Upload files and click "Index Documents"

### "Vector database not found"
- **Cause**: Temporary directory cleaned or app restarted
- **Solution**: Re-upload and re-index documents

### LLM Responses Include Prior Knowledge
- **Cause**: System prompt not enforced properly
- **Solution**: Check system prompt in `create_rag_chain()` is present

### Slow Indexing
- **Cause**: Large PDF files or many documents
- **Solution**: Start with fewer/smaller files

### Memory Issues
- **Cause**: Large vector database in memory
- **Solution**: Clear database and use fewer retrieval chunks

## Storage Locations

### Temporary Directories

The app uses system temporary directories:
- **Uploads**: `%TEMP%/streamlit_rag_uploads/` (Windows)
- **Vector DB**: `%TEMP%/streamlit_rag_app/vectordb/` (Windows)

On Linux/Mac:
- **Uploads**: `/tmp/streamlit_rag_uploads/`
- **Vector DB**: `/tmp/streamlit_rag_app/vectordb/`

These are automatically cleaned by OS periodically.

## Performance Tips

1. **Optimal Chunk Size**: 1000 characters balances context and specificity
2. **Retrieval K**: Start with 3-5 chunks, increase if missing context
3. **Document Size**: Keep individual PDFs < 50MB for best performance
4. **Token Limit**: Gemini 2.5 Flash supports large context windows (100K+ tokens)

## Security Considerations

 **Important**:
- Documents are processed locally (no public upload)
- Vector store stored in system temp directory
- Credentials from environment variables
- Session state cleared on app restart
- No conversation history persistence

## Future Enhancements

Potential improvements:
- [ ] Document metadata tracking
- [ ] Multi-session support with database persistence
- [ ] Custom document metadata indexing
- [ ] Export conversation history
- [ ] Analytics on retrieval performance
- [ ] Support for other file types (Excel, CSV, etc.)
- [ ] Streaming responses for large contexts
- [ ] Document versioning

## Example Workflows

### Workflow 1: Quick Document Query
```
1. Start app
2. Upload single document
3. Click "Index Documents"
4. Ask questions
5. Review sources
6. Close app (temp storage auto-cleaned)
```

### Workflow 2: Multi-Document Analysis
```
1. Upload multiple documents
2. Increase retrieval K to 5
3. Ask comprehensive questions
4. Compare answers across documents (from sources)
5. Ask follow-up questions (multi-turn)
6. Clear database and upload new batch
```

### Workflow 3: Document-Constrained Q&A
```
1. Upload company policy documents
2. Set system prompt for tone
3. Distribute chatbot for policy queries
4. Users ask questions, get policy-based answers
5. All answers sourced from documents
```

## Support & Issues

For issues or questions:
1. Check logs in Streamlit console
2. Verify credentials in `.env`
3. Ensure all dependencies installed
4. Try clearing cache: `streamlit cache clear`

## References

- [Streamlit Documentation](https://docs.streamlit.io)
- [LangChain Documentation](https://python.langchain.com)
- [Google Vertex AI](https://cloud.google.com/vertex-ai)
- [ChromaDB Documentation](https://docs.trychroma.com)

---

**Built with**: Streamlit + LangChain + Vertex AI + ChromaDB

**Last Updated**: February 2, 2026
