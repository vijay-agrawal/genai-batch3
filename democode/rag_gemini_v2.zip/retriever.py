import os
from pathlib import Path
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_google_vertexai import ChatVertexAI
import warnings
warnings.filterwarnings("ignore")

from dotenv import load_dotenv
import google.auth
import vertexai

# ============================================================================
# Helper Function: Find Project Root
# ============================================================================
def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env or google-vertexai-serviceaccount-key.json in any parent directory.")
    print(f"Started searching from: {Path(__file__).resolve().parent}")
    exit(1)

# --- Setup Google Vertex AI Authentication ---
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Resolve relative credential paths to absolute
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

# Set Project Details
PROJECT_ID = os.getenv("GOOGLE_VERTEXAI_PROJECT_ID", "your-gcp-project-id")
LOCATION = os.getenv("GOOGLE_VERTEXAI_LOCATION", "us-central1")

# Initialize Vertex AI
try:
    vertexai.init(project=PROJECT_ID, location=LOCATION)
    print(f"✓ Vertex AI initialized: {PROJECT_ID}")
except Exception as e:
    print(f"✗ Error initializing Vertex AI: {e}")
    exit(1)

# Use the script directory instead of cwd
script_dir = Path(__file__).resolve().parent
CHROMA_PATH = str(script_dir / "vectordb")

def load_embeddings_chroma(persist_directory=CHROMA_PATH):
    from langchain_community.vectorstores import Chroma

    # Instantiate the same embedding model used during creation (gemini-embedding-001)
    print('✓ Instantiating Vertex AI embedding model: gemini-embedding-001')

    embeddings = VertexAIEmbeddings(model_name="gemini-embedding-001")

    print(f'✓ Loading Chroma vector database from: {persist_directory}')
    
    # Check if path exists
    if not Path(persist_directory).exists():
        print(f'✗ ERROR: Vector database not found at {persist_directory}')
        print('  Please run indexer2.py first to create the vector database')
        exit(1)

    # Load the Chroma vector store from the specified directory, using the provided embedding function
    vector_store = Chroma(persist_directory=persist_directory, embedding_function=embeddings) 

    return vector_store  # Return the loaded vector store

def ask_and_get_answer(vector_store, q, k=3):
    from langchain_core.runnables import RunnablePassthrough
    from langchain_core.output_parsers import StrOutputParser
    from langchain_core.prompts import PromptTemplate

    llm = ChatVertexAI(
        model="gemini-2.5-flash",
        temperature=0,
        project=PROJECT_ID,
        location=LOCATION
    )
    print('✓ Fetching retriever for the vector DB')
    retriever = vector_store.as_retriever(search_type='similarity', search_kwargs={'k': k})

    # Create a simple RAG chain using LangChain Expression Language (LCEL)
    template = """Use the following pieces of context to answer the question at the end.
If you don't know the answer, just say that you don't know, don't try to make up an answer.

{context}

Question: {question}
Answer:"""
    
    prompt = PromptTemplate.from_template(template)
    
    print('✓ Executing the Chain with the retriever and the LLM')
    
    # Build the chain using LCEL
    chain = (
        {"context": retriever | (lambda docs: "\n".join([d.page_content for d in docs])), "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    
    answer = chain.invoke(q)
    return answer
    

# Creating a Chroma vector store using the provided text chunks and embedding model (default is text-embedding-3-small)
vector_store = load_embeddings_chroma()

# Asking questions
q = 'What technical skills does Pankaj have?'
print(f"\nQuestion: {q}")
answer = ask_and_get_answer(vector_store, q)
print(answer)