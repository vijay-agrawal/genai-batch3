# RAG Streamlit Chatbot App - Implementation Summary


## Architecture Overview

### Session State Management
```python
st.session_state = {
    "messages": [],              # Conversation history
    "vector_store": None,        # ChromaDB instance
    "vectordb_path": str,        # Temp directory path
    "uploaded_files": set,       # Uploaded file names
    "documents_indexed": int,    # Document count
    "current_chunks": int        # Chunk count
}
```

### Document Processing Pipeline
```
User Upload Files (PDF/MD)
         ↓
Save to Temp Directory
         ↓
Load Documents (PyPDF + Markdown)
         ↓
Split into Chunks (1000 chars, 200 overlap)
         ↓
Generate Embeddings (Gemini Embedding 001)
         ↓
Store in ChromaDB (Temp Directory)
         ↓
Ready for Retrieval
```

### RAG Chain Flow
```
User Question
         ↓
Retrieve Similar Chunks (k=1-10, configurable)
         ↓
Build Context from Chunks
         ↓
Call LLM with Context + System Prompt
         ↓
LLM Responds (from context only)
         ↓
Display Response + Sources
         ↓
Save to Conversation History
```

---

## Key Features

### 1. Dynamic Document Upload
**Location**: Sidebar file uploader
- Multi-file selection
- File type filtering (PDF, MD only)
- Real-time file display with checkmarks
- Progress indication during processing

### 2. Automatic Indexing
**Function**: `index_documents()`
- Loads PDFs with `PyPDFDirectoryLoader`
- Loads Markdown with `UnstructuredMarkdownLoader`
- Splits documents with `RecursiveCharacterTextSplitter`
- Creates embeddings with `VertexAIEmbeddings`
- Persists to ChromaDB

### 3. Conversational Interface
**Implemented via**: Streamlit Chat
- Full conversation history display
- User and assistant roles
- Session persistence (within session)
- Multi-turn support

### 4. Session State Management
**Maintained in**: `st.session_state`
- Messages history
- Vector store reference
- Document metadata
- File tracking

### 5. Context-Only System Prompt
**Enforced by**: System prompt in `create_rag_chain()`
```
You are a helpful assistant that answers questions ONLY based 
on the provided context.

IMPORTANT RULES:
1. Answer ONLY from the provided context
2. Do NOT use your prior knowledge or training data
3. If the answer is not in the context, say "I cannot find..."
4. Be accurate and quote from the context when relevant
5. If asked about something not covered, explicitly state 
   it's not covered
```

### 6. Source Attribution/Citation
**Displayed via**: Expandable "Sources" section
- Shows document file names
- Preview of relevant content
- Metadata tracking

### 7. Temporary Storage
**Location**: System temp directories
- **Uploads**: `%TEMP%/streamlit_rag_uploads/`
- **Vector DB**: `%TEMP%/streamlit_rag_app/vectordb/`
- Auto-cleanup by OS
- Isolated per session

---
## 🔧 Technical Implementation Details

### Import Structure
```python
# Core
import streamlit as st
from streamlit_chat import message

# LangChain
from langchain_community.document_loaders import (
    PyPDFDirectoryLoader,
    UnstructuredMarkdownLoader
)
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_vertexai import VertexAIEmbeddings, ChatVertexAI
from langchain_community.vectorstores import Chroma
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate

# Google Cloud
import vertexai
import google.auth
```

### Streamlit Configuration
```python
st.set_page_config(
    page_title="RAG Chatbot",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)
```

### Vector Store Management
```python
# Create vector store
vector_store = Chroma.from_documents(
    documents=chunks,
    embedding=embeddings,
    persist_directory=vectordb_path
)
vector_store.persist()

# Retrieve documents
retriever = vector_store.as_retriever(
    search_type='similarity',
    search_kwargs={'k': k}
)
```

### LLM Configuration
```python
llm = ChatVertexAI(
    model="gemini-2.5-flash",
    temperature=0,
    project=PROJECT_ID,
    location=LOCATION
)
```

---

## 💬 UI Components

### Sidebar
- 📁 **Document Management**: File uploader, index button
- 📊 **Status**: Document count, chunk count, ready indicator
- ⚙️ **Settings**: Retrieval K slider (1-10)
- 🗑️ **Actions**: Clear database button

### Main Area
- **Header**: Title and description
- **Conversation Display**: Chat history with roles
- **Chat Input**: Message input field
- **Sources Expander**: Relevant document chunks
- **Clear Button**: Reset conversation
- **Footer**: Attribution and links

### Chat Display Features
- User messages with role badge
- Assistant messages with role badge
- Source attribution with expandable sections
- Loading spinners during processing
- Error messages and warnings

---

## 🔐 Security & Privacy

✅ **Implemented**:
- No PII exposure in logs
- Credentials from environment variables
- Temporary storage (not persistent)
- Local document processing
- No third-party uploads
- Session-isolated state

**Important Notes**:
- Vertex AI API called for embeddings/LLM
- No conversation history persistence
- Temp files auto-cleaned by OS
- Sessions isolated

---

## Usage Instructions

### Quick Start (5 minutes)
1. `pip install -r requirements.txt`
2. `streamlit run app.py`
3. Upload PDF or Markdown file
4. Click "🔍 Index Documents"
5. Start chatting!

### Detailed Usage
1. **Upload**: Click file uploader, select 1+ files
2. **Index**: Click green Index button
3. **Wait**: Processing shows status updates
4. **Chat**: Type question in chat input
5. **Review**: Check "📚 Sources" for context
6. **Continue**: Ask follow-up questions
7. **Clear**: Clear conversation or database as needed

---

## ⚙️ Configuration Options

### Adjustable Settings
```python
# Chunk retrieval (in UI)
retrieval_k = st.slider(
    "Number of context chunks to retrieve",
    min_value=1,
    max_value=10,
    value=3
)

# Chunking strategy (in code)
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,        # Adjust size
    chunk_overlap=200,      # Adjust overlap
)

# Embedding model (in code)
embeddings = VertexAIEmbeddings(
    model_name="gemini-embedding-001"  # Change model
)

# LLM model (in code)
llm = ChatVertexAI(
    model="gemini-2.5-flash",      # Change model
    temperature=0,                  # 0=deterministic, 1=creative
)
```

---

## 🐛 Troubleshooting Guide

### Common Issues

**Issue**: File uploader appears but button disabled
- **Cause**: No files selected
- **Solution**: Click uploader, select PDF/MD files

**Issue**: "Vector database not found"
- **Cause**: Session restarted or files not indexed
- **Solution**: Re-upload files and click Index

**Issue**: LLM returns prior knowledge answers
- **Cause**: System prompt not enforced
- **Solution**: Verify system prompt in `create_rag_chain()`

**Issue**: Slow indexing
- **Cause**: Large files or many files
- **Solution**: Start with smaller/fewer files

**Issue**: Memory usage high
- **Cause**: Large vector store in memory
- **Solution**: Clear database, reduce retrieval K

### Debug Mode
Add to `app.py` for debugging:
```python
st.write("DEBUG:", st.session_state)  # Show all state
```

---

## 📊 Performance Characteristics

### Typical Performance (per operation)
| Operation | Time | Notes |
|-----------|------|-------|
| Upload 1 PDF | < 1s | Depends on file size |
| Index 10 pages | 2-5s | Includes embedding generation |
| Retrieve context | < 1s | Vector similarity search |
| LLM response | 2-5s | Depends on context size |
| **Total Q&A cycle** | **5-10s** | Average end-to-end |

### Storage Usage
| Component | Size | Notes |
|-----------|------|-------|
| Vector DB (per 100 pages) | ~50MB | Compressed embeddings |
| Temp uploads | Variable | Depends on files |
| Memory (active) | ~200-500MB | Streamlit + LangChain |

---

## Workflow Examples

### Example 1: Single Document Q&A
```
1. Run app
2. Upload 1 PDF
3. Index (2-3 seconds)
4. Ask 3-5 questions
5. Review sources for each
6. Close app
```

### Example 2: Multi-Document Analysis
```
1. Upload 5-10 PDFs
2. Index (10-20 seconds)
3. Ask comprehensive questions
4. Cross-document queries work
5. Clear and upload new batch
```

### Example 3: Policy Documentation
```
1. Upload company policies
2. Set custom system prompt
3. Share with team
4. Team asks policy questions
5. Answers sourced from docs only
```

---

## 📚 Dependencies

### Core Libraries
```
streamlit               # Web UI
streamlit-chat         # Chat interface
langchain              # RAG framework
langchain-google-vertexai  # Vertex AI integration
langchain-community    # Document loaders
langchain-text-splitters  # Text processing
chromadb              # Vector database
google-cloud-aiplatform  # GCP integration
```

### Document Processing
```
pypdf                 # PDF loading
PyPDF2                # PDF utilities
unstructured          # Markdown loading
python-dotenv         # Environment variables
```

---

## 🎓 Learning Resources

### Key Concepts
- **RAG**: Retrieval-Augmented Generation
- **Vector Embeddings**: Semantic representation of text
- **ChromaDB**: Vector database
- **LangChain**: RAG orchestration framework
- **Streamlit**: Web UI framework

### External Resources
- [Streamlit Docs](https://docs.streamlit.io)
- [LangChain Docs](https://python.langchain.com)
- [Vertex AI Docs](https://cloud.google.com/vertex-ai)
- [ChromaDB Docs](https://docs.trychroma.com)

---

## 🚀 Next Steps / Future Enhancements

### Potential Improvements
- [ ] Database persistence (save conversations)
- [ ] Multi-session support
- [ ] Document metadata search
- [ ] Custom model selection
- [ ] Export conversations
- [ ] Analytics dashboard
- [ ] User authentication
- [ ] Document versioning
- [ ] Bulk document management
- [ ] Advanced search filters