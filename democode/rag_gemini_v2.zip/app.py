"""
Streamlit RAG Chatbot Application
Combines document upload, indexing, and conversational retrieval
"""

import os
import sys
import shutil
import tempfile
from pathlib import Path
from datetime import datetime
import warnings

warnings.filterwarnings('ignore')

import streamlit as st
from streamlit_chat import message as st_message
from dotenv import load_dotenv
import google.auth
import vertexai

from langchain_community.document_loaders import PyPDFDirectoryLoader, UnstructuredMarkdownLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_vertexai import VertexAIEmbeddings, ChatVertexAI
from langchain_community.vectorstores import Chroma
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate


# ============================================================================
# CONFIGURATION & INITIALIZATION
# ============================================================================

def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    return Path.home()


# Load environment
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Resolve credentials
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

PROJECT_ID = os.getenv("GOOGLE_VERTEXAI_PROJECT_ID", "gen-ai-training-476514")
LOCATION = os.getenv("GOOGLE_VERTEXAI_LOCATION", "us-central1")

# Initialize Vertex AI
try:
    vertexai.init(project=PROJECT_ID, location=LOCATION)
except:
    pass

# Streamlit page configuration
st.set_page_config(
    page_title="RAG Chatbot",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================================
# SESSION STATE INITIALIZATION
# ============================================================================

if "messages" not in st.session_state:
    st.session_state.messages = []

if "vector_store" not in st.session_state:
    st.session_state.vector_store = None

if "vectordb_path" not in st.session_state:
    # Use app-specific temp directory for vector DB
    app_temp_dir = Path(tempfile.gettempdir()) / "streamlit_rag_app"
    app_temp_dir.mkdir(exist_ok=True)
    st.session_state.vectordb_path = str(app_temp_dir / "vectordb")

if "uploaded_files" not in st.session_state:
    st.session_state.uploaded_files = {}

if "documents_indexed" not in st.session_state:
    st.session_state.documents_indexed = 0

if "current_chunks" not in st.session_state:
    st.session_state.current_chunks = 0

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def load_documents_from_temp(temp_dir: str) -> list:
    """Load PDF and Markdown files from temporary directory"""
    documents = []
    temp_path = Path(temp_dir)
    
    # Load PDFs
    pdf_files = list(temp_path.glob("*.pdf"))
    if pdf_files:
        loader = PyPDFDirectoryLoader(str(temp_path))
        documents.extend(loader.load())
    
    # Load Markdown files
    for md_file in temp_path.glob("*.md"):
        loader = UnstructuredMarkdownLoader(str(md_file))
        documents.extend(loader.load())
    
    return documents


def index_documents(documents: list, vectordb_path: str) -> tuple:
    """Index documents and create vector store"""
    if not documents:
        return None, 0, 0
    
    # Clear existing vector database
    if Path(vectordb_path).exists():
        shutil.rmtree(vectordb_path)
    
    # Split documents into chunks
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        length_function=len,
    )
    chunks = text_splitter.split_documents(documents)
    
    # Create embeddings
    embeddings = VertexAIEmbeddings(model_name="gemini-embedding-001")
    
    # Create and persist vector store
    vector_store = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=vectordb_path
    )
    vector_store.persist()
    
    return vector_store, len(documents), len(chunks)


def create_rag_chain(vector_store, k: int = 3) -> tuple:
    """Create RAG chain for question answering"""
    
    llm = ChatVertexAI(
        model="gemini-2.5-flash",
        temperature=0,
        project=PROJECT_ID,
        location=LOCATION
    )
    
    retriever = vector_store.as_retriever(
        search_type='similarity',
        search_kwargs={'k': k}
    )
    
    # System prompt ensures answer from context only
    system_prompt = """You are a helpful assistant that answers questions ONLY based on the provided context.

IMPORTANT RULES:
1. Answer ONLY from the provided context
2. Do NOT use your prior knowledge or training data
3. If the answer is not in the context, say "I cannot find this information in the provided documents"
4. Be accurate and quote from the context when relevant
5. If asked about something not covered, explicitly state it's not covered in the documents

Context:
{context}

Question: {question}

Answer (based only on the context above):"""
    
    prompt = PromptTemplate.from_template(system_prompt)
    
    chain = (
        {
            "context": retriever | (lambda docs: "\n\n".join([
                f"[Document {i+1}]\n{d.page_content}\n[Source: {d.metadata.get('source', 'Unknown')}]"
                for i, d in enumerate(docs)
            ])),
            "question": RunnablePassthrough()
        }
        | prompt
        | llm
        | StrOutputParser()
    )
    
    return chain, retriever


def get_source_context(retriever, question: str, k: int = 3) -> list:
    """Get source documents for a question"""
    docs = retriever.invoke(question)
    return docs[:k]


# ============================================================================
# STREAMLIT UI
# ============================================================================

# Header
col1, col2 = st.columns([0.8, 0.2])
with col1:
    st.title("🤖 RAG Conversational Chatbot")
    st.markdown("*Upload documents and chat with your data*")

# Sidebar
with st.sidebar:
    st.header("📁 Document Management")
    
    # File uploader
    uploaded_files = st.file_uploader(
        "Upload PDF or Markdown files",
        type=["pdf", "md"],
        accept_multiple_files=True,
        help="Select one or more PDF or Markdown files to index"
    )
    
    # Process uploaded files
    if uploaded_files:
        # Create temporary directory for uploads
        temp_upload_dir = Path(tempfile.gettempdir()) / "streamlit_rag_uploads"
        temp_upload_dir.mkdir(exist_ok=True)
        
        # Save uploaded files
        uploaded_file_names = set()
        for uploaded_file in uploaded_files:
            file_path = temp_upload_dir / uploaded_file.name
            with open(file_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
            uploaded_file_names.add(uploaded_file.name)
        
        st.session_state.uploaded_files = uploaded_file_names
        
        # Show uploaded files
        st.info(f"📋 Uploaded {len(uploaded_files)} file(s):")
        for file in uploaded_files:
            st.caption(f"✓ {file.name}")
        
        # Index button
        if st.button("🔍 Index Documents", type="primary", use_container_width=True):
            with st.spinner("Indexing documents..."):
                try:
                    # Load documents from temp directory
                    documents = load_documents_from_temp(str(temp_upload_dir))
                    
                    if documents:
                        # Index and create vector store
                        vector_store, num_docs, num_chunks = index_documents(
                            documents,
                            st.session_state.vectordb_path
                        )
                        
                        st.session_state.vector_store = vector_store
                        st.session_state.documents_indexed = num_docs
                        st.session_state.current_chunks = num_chunks
                        
                        # Clear conversation when new documents are indexed
                        st.session_state.messages = []
                        
                        st.success(f"✓ Indexed {num_docs} pages into {num_chunks} chunks!")
                    else:
                        st.error("No documents found. Please check your files.")
                
                except Exception as e:
                    st.error(f"Error indexing documents: {str(e)}")
    
    # Status section
    st.divider()
    st.subheader("📊 Status")
    
    if st.session_state.vector_store:
        st.metric("Documents Indexed", st.session_state.documents_indexed)
        st.metric("Total Chunks", st.session_state.current_chunks)
        st.success("✓ Vector database ready")
        
        # Clear database button
        if st.button("🗑️ Clear Database", use_container_width=True):
            vectordb_path = Path(st.session_state.vectordb_path)
            if vectordb_path.exists():
                shutil.rmtree(vectordb_path)
            st.session_state.vector_store = None
            st.session_state.documents_indexed = 0
            st.session_state.current_chunks = 0
            st.session_state.messages = []
            st.rerun()
    else:
        st.warning("No documents indexed yet")
        st.info("👆 Upload and index documents to get started")
    
    st.divider()
    st.subheader("⚙️ Settings")
    retrieval_k = st.slider(
        "Number of context chunks to retrieve",
        min_value=1,
        max_value=10,
        value=3,
        help="How many document chunks to use for context"
    )

# Main chat interface
if st.session_state.vector_store is None:
    st.info("👈 **Get Started**: Upload PDF or Markdown files in the sidebar, then click 'Index Documents' to begin chatting!")
else:
    # Display conversation history
    st.subheader("💬 Conversation")
    
    # Display previous messages
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])
            
            # Show sources for assistant messages
            if msg["role"] == "assistant" and "sources" in msg:
                with st.expander("📚 Sources"):
                    for source in msg["sources"]:
                        st.caption(f"📄 {source['source']}")
                        st.text(source['content'][:300] + "...")
    
    # Chat input
    user_input = st.chat_input(
        "Ask a question about your documents...",
        key="chat_input"
    )
    
    if user_input:
        # Add user message to history
        st.session_state.messages.append({
            "role": "user",
            "content": user_input
        })
        
        # Display user message
        with st.chat_message("user"):
            st.write(user_input)
        
        # Generate assistant response
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    # Create RAG chain
                    chain, retriever = create_rag_chain(
                        st.session_state.vector_store,
                        k=retrieval_k
                    )
                    
                    # Get response from chain (with conversation context)
                    response = chain.invoke(user_input)
                    
                    # Get source documents
                    source_docs = get_source_context(retriever, user_input, k=retrieval_k)
                    
                    st.write(response)
                    
                    # Show sources
                    if source_docs:
                        with st.expander("📚 Sources"):
                            for i, doc in enumerate(source_docs, 1):
                                st.caption(f"📄 **Source {i}**: {doc.metadata.get('source', 'Unknown')}")
                                st.text(doc.page_content[:300] + "...")
                    
                    # Add assistant message to history
                    sources = [
                        {
                            "source": doc.metadata.get('source', 'Unknown'),
                            "content": doc.page_content
                        }
                        for doc in source_docs
                    ]
                    
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": response,
                        "sources": sources
                    })
                
                except Exception as e:
                    st.error(f"Error generating response: {str(e)}")
    
    # Clear conversation button
    if st.session_state.messages:
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🗑️ Clear Conversation", use_container_width=True):
                st.session_state.messages = []
                st.rerun()

# Footer
st.divider()
st.markdown("""
<div style='text-align: center; color: gray; font-size: 0.8rem;'>
    <p>RAG Chatbot powered by LangChain + Vertex AI</p>
    <p>Questions are answered only from your uploaded documents</p>
</div>
""", unsafe_allow_html=True)
