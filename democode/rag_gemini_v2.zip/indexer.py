"""
Simple RAG Indexer using LangChain
A straightforward script showing each step of the RAG indexing process
"""

import os
import shutil
from pathlib import Path
from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFDirectoryLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_community.vectorstores import Chroma
import google.auth
import vertexai
from google.cloud import aiplatform

print("=" * 70)
print("RAG INDEXER - Simple LangChain Implementation")
print("=" * 70)

# ============================================================================
# Helper Function: Find Project Root
# ============================================================================
def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env or google-vertexai-serviceaccount-key.json in any parent directory.")
    print(f"Started searching from: {Path(__file__).resolve().parent}")
    exit(1)

# ============================================================================
# STEP 1: Load Environment Variables and Setup Google Vertex AI Authentication
# ============================================================================
print("\n[STEP 1] Setting up Google Vertex AI authentication...")

# Find project root and load .env
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

# Resolve relative credential paths to absolute
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())

# Debug: Show credentials file path
_resolved_creds = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
print(f"  - Credentials file: {_resolved_creds}")

# Check if credentials file exists
if _resolved_creds and not Path(_resolved_creds).exists():
    print(f"✗ ERROR: Credentials file not found at {_resolved_creds}")
    exit(1)
elif _resolved_creds:
    print(f"✓ Credentials file exists")
    # Try to validate JSON format
    try:
        import json
        with open(_resolved_creds, 'r') as f:
            creds_json = json.load(f)
            if "type" in creds_json and creds_json["type"] == "service_account":
                print(f"✓ Valid service account key format")
                print(f"  Service Account: {creds_json.get('client_email', 'Unknown')}")
    except Exception as e:
        print(f"✗ ERROR: Invalid credentials file format: {e}")
        exit(1)

# Set Project Details
PROJECT_ID = os.getenv("GOOGLE_VERTEXAI_PROJECT_ID", "your-gcp-project-id")
LOCATION = os.getenv("GOOGLE_VERTEXAI_LOCATION", "us-central1")

# Authentication Check
print("\n--- Authentication Check ---")
try:
    credentials, auth_project_id = google.auth.default()
    
    # CASE A: Service Account (common in production/scripts)
    if hasattr(credentials, "service_account_email"):
        print(f"✓ Logged in as SERVICE ACCOUNT: {credentials.service_account_email}")
    # CASE B: User Credentials (local development/ADC)
    else:
        print("✓ Logged in as USER (Application Default Credentials)")
        print(f"  Credential Type: {type(credentials).__name__}")
        
    print(f"✓ Using Project ID: {auth_project_id}")
    print("----------------------------")

except Exception as e:
    print(f"✗ Could not determine auth identity: {e}")
    print(f"✗ Error details: {str(e)}")
    exit(1)

# ============================================================================
# STEP 2: Initialize Vertex AI
# ============================================================================
print("\n[STEP 2] Initializing Vertex AI...")

try:
    vertexai.init(project=PROJECT_ID, location=LOCATION)
    print("✓ Vertex AI initialized")
except Exception as e:
    print(f"✗ Error initializing Vertex AI: {e}")
    exit(1)

# ============================================================================
# STEP 3: Load PDF Documents
# ============================================================================
print("\n[STEP 3] Loading PDF documents from 'data' folder...")

# Use the same directory as this script file
script_dir = Path(__file__).resolve().parent
data_folder = script_dir / "data"

# Check if folder exists
if not data_folder.exists():
    print(f"✗ Error: 'data' folder not found at {data_folder}")
    print(f"  Please create it and add PDF files.")
    exit(1)

# Load all PDFs from the data folder
loader = PyPDFDirectoryLoader(str(data_folder))
documents = loader.load()

print(f"✓ Loaded {len(documents)} pages from PDF files")

if len(documents) == 0:
    print("✗ No PDF documents found. Please add PDF files to the 'data' folder.")
    exit(1)

# Display document info
for i, doc in enumerate(documents[:3]):  # Show first 3 documents
    print(f"  - Document {i+1}: {doc.metadata.get('source', 'Unknown')} ({len(doc.page_content)} chars)")
if len(documents) > 3:
    print(f"  ... and {len(documents) - 3} more pages")

# ============================================================================
# STEP 4: Split Documents into Chunks
# ============================================================================
print("\n[STEP 4] Splitting documents into chunks...")

# Create text splitter with overlap for better context preservation
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,        # Size of each chunk in characters
    chunk_overlap=200,      # Overlap between chunks
    length_function=len,
)

# Split all documents into chunks
chunks = text_splitter.split_documents(documents)

print(f"✓ Created {len(chunks)} text chunks")
print(f"  Chunk size: 1000 characters")
print(f"  Overlap: 200 characters")

# Show example chunk
if chunks:
    print(f"\n  Example chunk preview:")
    print(f"  '{chunks[0].page_content[:150]}...'")

# ============================================================================
# STEP 5: Initialize Embedding Model
# ============================================================================
print("\n[STEP 5] Initializing Vertex AI embedding model...")

# Use Vertex AI's text embedding model
embeddings = VertexAIEmbeddings(
    model_name="gemini-embedding-001"
)

print("✓ Embedding model initialized: gemini-embedding-001")

# ============================================================================
# STEP 6: Create Vector Database and Store Embeddings
# ============================================================================
print("\n[STEP 6] Creating embeddings and storing in ChromaDB...")

# Define where to store the vector database - use script directory
persist_directory = str(script_dir / "vectordb")

# Clear existing vector database if it exists
print("  - Clearing existing vector database...")
if Path(persist_directory).exists():
    shutil.rmtree(persist_directory)
    print(f"  ✓ Removed existing vectordb folder")

print(f"  - Vector database will be saved to: {persist_directory}")

# Create vector store with embeddings
# This will automatically:
# 1. Create embeddings for all chunks using Vertex AI
# 2. Store them in ChromaDB
vectordb = Chroma.from_documents(
    documents=chunks,
    embedding=embeddings,
    persist_directory=persist_directory
)

# Persist the database to disk
vectordb.persist()

print(f"✓ Vector database created and saved to '{persist_directory}'")
print(f"✓ Stored {len(chunks)} embedded chunks")

# ============================================================================
# STEP 7: Test the Vector Database with a Sample Query
# ============================================================================
print("\n[STEP 7] Testing retrieval with a sample query...")

# Example query - modify this to test with your documents
test_query = "What is this document about?"

# Search for similar chunks
results = vectordb.similarity_search(test_query, k=3)

print(f"✓ Query: '{test_query}'")
print(f"✓ Found {len(results)} relevant chunks:\n")

for i, result in enumerate(results):
    print(f"  Result {i+1}:")
    print(f"    Source: {result.metadata.get('source', 'Unknown')}")
    print(f"    Content preview: {result.page_content[:200]}...")
    print()

# ============================================================================
# Summary
# ============================================================================
print("=" * 70)
print("INDEXING COMPLETE!")
print("=" * 70)
print(f"✓ Total pages processed: {len(documents)}")
print(f"✓ Total chunks created: {len(chunks)}")
print(f"✓ Vector database location: {persist_directory}")
print(f"\nYou can now use this vector database for RAG applications!")
print("=" * 70)