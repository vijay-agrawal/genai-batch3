# LLM API - Multiple LLM Provider Tests

This folder contains Python scripts to interact with various LLM APIs (Azure OpenAI, OpenAI, Google Gemini) for testing and demonstration purposes.

## Files

- **test_azure_openai.py**: Demonstrates how to make API calls to Azure OpenAI using the OpenAI Python SDK. Includes functions for environment validation and querying the API.
- **test_openai.py**: Tests direct OpenAI API integration using LangChain's ChatOpenAI wrapper with gpt-3.5-turbo model.
- **test_google_gemini.py**: Tests Google Vertex AI Gemini API integration with authentication checks and project initialization.
- **test_google_gemini_auth.py**: Extended version of Google Gemini test with detailed authentication checks and email identification for both service accounts and user accounts.
- **my_first_gemini_chatbot.py**: A Streamlit-based interactive chatbot using Google Vertex AI Gemini. Features the same robust authentication as test_google_gemini.py with a web UI for real-time conversations.

## Prerequisites

- Python 3.10 or higher (tested with Python 3.10)
- API credentials for the LLM provider(s) you want to use:
  - **Azure OpenAI**: Endpoint, API key, API version, and model deployment name
  You can obtain them from the "Details" tab in the Azure Foundry portal > Models.
  - **OpenAI**: API key
  - **Google Vertex AI**: GCP project credentials and project ID

## Installation

### 1. Install Required Packages

Install the necessary Python packages using pip:

```bash
pip install openai python-dotenv langchain-openai google-cloud-aiplatform google-auth-oauthlib streamlit
```

Or create and use a `requirements.txt` file:

```bash
openai
python-dotenv
langchain-openai
google-cloud-aiplatform
google-auth-oauthlib
requests
streamlit
```

Then install:

```bash
pip install -r requirements.txt
```

### 2. Setup Environment Variables (.env file)

Create a `.env` file in the top level directory with the variables needed for your chosen provider(s):

#### For Azure OpenAI:
```
AZURE_OPENAI_ENDPOINT=https://<your-resource-name>.openai.azure.com/
AZURE_OPENAI_API_KEY=<your-api-key>
AZURE_OPENAI_API_VERSION=2024-02-15
AZURE_OPENAI_MODEL_NAME=<your-model-deployment-name>
```

#### For OpenAI:
```
OPENAI_API_KEY=<your-openai-api-key>
```

#### For Google Vertex AI:
```
GOOGLE_VERTEXAI_PROJECT_ID=<your-gcp-project-id>
GOOGLE_VERTEXAI_LOCATION=us-central1
GOOGLE_APPLICATION_CREDENTIALS=<path-to-your-service-account-json>
```

**Note**: Replace the placeholder values with your actual credentials.

## How to Run

### Azure OpenAI Test
```bash
python test_azure_openai.py
```

The script will:
1. Validate that all required environment variables are loaded
2. Initialize the Azure OpenAI client
3. Send a test prompt ("What is the capital of France?") to the LLM
4. Display the prompt and response

### OpenAI Test
```bash
python test_openai.py
```

### Google Gemini Test
```bash
python test_google_gemini.py
```

### Google Gemini with Auth Check
```bash
python test_google_gemini_auth.py
```

### Gemini Chatbot (Streamlit)
```bash
streamlit run my_first_gemini_chatbot.py
```

The chatbot will:
1. Validate environment variables and authentication
2. Initialize Vertex AI with your project credentials
3. Launch a web interface where you can ask questions interactively
4. Use the Gemini 2.5 Flash model to generate responses

## Expected Output

### Azure OpenAI:
```
✓ All required environment variables are loaded successfully.
Prompt:
What is the capital of France?
Response from LLM:
Paris
```

### OpenAI:
```
✅ OpenAI working: The response from the model...
```

### Gemini Chatbot:
```
[OK] Using authentication: (Service account key ..., Project: your-project-id, Location: us-central1)
[OK] Vertex AI initialized: your-project-id

  You can now view your Streamlit app in your browser.

  Local URL: http://localhost:8501
```

## Troubleshooting

- **Missing .env file**: Ensure the `.env` file is created in the top level directory with all required environment variables.
- **Invalid API credentials**: Verify that your API endpoints, keys, and project IDs are correct.
- **Missing packages**: Run `pip install -r requirements.txt` to ensure all dependencies are installed.
- **Authentication errors for Google**: Ensure `GOOGLE_APPLICATION_CREDENTIALS` points to a valid service account JSON file.

## Notes

- Each test script includes error handling to catch and print exceptions during API calls.
- The Azure OpenAI script includes validation functions to ensure environment variables are properly loaded.
- Modify the prompt/query in each script to test different questions and use cases.
- The Google Gemini scripts include authentication checking to identify if you're logged in as a service account or user account.
- Knowledge cutoff dates vary by model; some models may not answer questions about recent events. See: https://github.com/HaoooWang/llm-knowledge-cutoff-dates
