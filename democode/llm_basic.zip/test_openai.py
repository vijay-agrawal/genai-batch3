# Test script
import os
from pathlib import Path
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv


def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env or google-vertexai-serviceaccount-key.json in any parent directory.")
    print(f"Started searching from: {Path(__file__).resolve().parent}")
    exit(1)


# Load environment variables from project root
PROJECT_ROOT = _find_project_root()
load_dotenv(PROJECT_ROOT / ".env")

def test_openai():
    try:
        llm = ChatOpenAI(
            model="gpt-3.5-turbo",  # Cheapest option
            api_key=os.getenv("OPENAI_API_KEY"),
            max_tokens=50
        )
        response = llm.invoke("How are you?")
        print(f"✅ OpenAI working: {response.content}")
    except Exception as e:
        print(f"❌ OpenAI error: {e}")

test_openai()