import os
import vertexai
from dotenv import load_dotenv
from vertexai.generative_models import GenerativeModel, Part

# --- Step 1: Load Environment Variables ---
# This MUST be done before importing/using the vertexai library
# It loads the GOOGLE_APPLICATION_CREDENTIALS from your .env file
load_dotenv()

# --- Step 2: Set Your Project Details ---
# Replace with your actual project ID and location
PROJECT_ID = "your-gcp-project-id"  
LOCATION = "us-central1"  # e.g., "us-central1"

# --- Step 3: Initialize Vertex AI ---
# The client automatically uses the credentials
# loaded from the .env file
try:
    vertexai.init(project=PROJECT_ID, location=LOCATION)
except Exception as e:
    print(f"Error initializing Vertex AI: {e}")
    print("Please ensure your PROJECT_ID and LOCATION are correct and you have enabled the Vertex AI API.")
    exit()

# --- Step 4: Load the Model and Send a Prompt ---
print("Vertex AI Initialized. Loading model...")

# Load the generative model (e.g., Gemini 1.5 Flash)
model = GenerativeModel("gemini-2.5-flash")

print("Model loaded. Sending prompt...")

# Send a simple prompt
try:
    response = model.generate_content("What is the capital of France?")
    # Print the text response
    print("\n--- Model Response ---")
    print(response.text)
    print("------------------------\n")
except Exception as e:
    print(f"An error occurred while generating content: {e}")
print("Script finished.")
