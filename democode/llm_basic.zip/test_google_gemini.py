import os
import sys
import warnings
from pathlib import Path
# Ignore all warnings
warnings.filterwarnings('ignore')
import vertexai
from dotenv import load_dotenv
from vertexai.generative_models import GenerativeModel, Part

# ============================================================================
# Environment Setup
# ============================================================================

def _find_project_root() -> Path:
    """Find project root by looking for .env or service account key."""
    current = Path(__file__).resolve().parent
    while current != current.parent:
        if (current / ".env").exists() or (current / "google-vertexai-serviceaccount-key.json").exists():
            return current
        current = current.parent
    print("ERROR: Could not find .env in any parent directory.")
    sys.exit(1)

PROJECT_ROOT = _find_project_root()

# Load environment variables
from dotenv import load_dotenv
load_dotenv(PROJECT_ROOT / ".env")

# ============================================================================
# Environment Variable Validation
# ============================================================================

def _validate_environment():
    """Validate required environment variables for authentication."""
    errors = []

    # Check for GEMINI_API_KEY (alternative auth method)
    gemini_api_key = os.getenv("GEMINI_API_KEY")

    # Check for Vertex AI credentials
    project_id = os.getenv("GOOGLE_VERTEXAI_PROJECT_ID")
    location = os.getenv("GOOGLE_VERTEXAI_LOCATION")
    creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")

    # Determine which auth method is available
    has_gemini_key = bool(gemini_api_key and gemini_api_key.strip())
    has_vertex_config = bool(project_id and location)

    if not has_gemini_key and not has_vertex_config:
        errors.append("Missing authentication credentials. Provide either:")
        errors.append("  Option 1: GEMINI_API_KEY")
        errors.append("  Option 2: GOOGLE_VERTEXAI_PROJECT_ID + GOOGLE_VERTEXAI_LOCATION + GOOGLE_APPLICATION_CREDENTIALS")
        errors.append("")
        errors.append("Current status:")
        errors.append(f"  GEMINI_API_KEY: {'SET' if gemini_api_key else 'NOT SET'}")
        errors.append(f"  GOOGLE_VERTEXAI_PROJECT_ID: {'SET' if project_id else 'NOT SET'}")
        errors.append(f"  GOOGLE_VERTEXAI_LOCATION: {'SET' if location else 'NOT SET'}")
        errors.append(f"  GOOGLE_APPLICATION_CREDENTIALS: {'SET' if creds_path else 'NOT SET'}")

    # If using Vertex AI, validate credentials file exists
    if has_vertex_config and creds_path:
        # Resolve relative path
        if not Path(creds_path).is_absolute():
            resolved_path = PROJECT_ROOT / creds_path
        else:
            resolved_path = Path(creds_path)

        if not resolved_path.exists():
            errors.append(f"GOOGLE_APPLICATION_CREDENTIALS file not found:")
            errors.append(f"  Path: {creds_path}")
            errors.append(f"  Resolved to: {resolved_path}")
            errors.append(f"  Please ensure the service account key file exists at this location.")
    elif has_vertex_config and not creds_path:
        errors.append("GOOGLE_APPLICATION_CREDENTIALS not set.")
        errors.append("  This is required when using Vertex AI authentication.")
        errors.append("  Set it to the path of your service account key JSON file.")

    # Print errors and exit if any
    if errors:
        print("=" * 70)
        print("[ERROR] Environment Configuration Error")
        print("=" * 70)
        for error in errors:
            print(error)
        print("=" * 70)
        sys.exit(1)

    # Print which approach is being used
    if has_gemini_key:
        print("[OK] Using authentication: GEMINI_API_KEY")
    else:
        print(f"[OK] Using authentication: (Service account key {creds_path}, Project: {project_id}, Location: {location})")

    return has_gemini_key, project_id, location

# Validate environment
USE_GEMINI_API, PROJECT_ID, LOCATION = _validate_environment()

# Resolve relative credential paths to absolute
_creds_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
if _creds_path and not Path(_creds_path).is_absolute():
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str((PROJECT_ROOT / _creds_path).resolve())


# --- Step 3: Initialize Vertex AI ---
# The client automatically uses the credentials
# loaded from the .env file
try:
    vertexai.init(project=PROJECT_ID, location=LOCATION)
    print(f"[OK] Vertex AI initialized: {PROJECT_ID}")
except Exception as e:
    print(f"[ERROR] Error initializing Vertex AI: {e}")
    sys.exit(1)


# --- Step 4: Define Prompts and Load the Model ---
print("Vertex AI Initialized. Defining prompts...")

# Define your system prompt (the model's instructions)
system_prompt = "You are a helpful travel assistant. You must always respond in French and English both."

# Define your user prompt (the user's question)
user_prompt = "What is the best experience to have in Paris? Describe in one sentence."

print(f"System Prompt: {system_prompt}")
print(f"User Prompt: {user_prompt}")

# Load the generative model and pass the system prompt
try:
    model = GenerativeModel(
        "gemini-2.5-flash",
        system_instruction=system_prompt
    )
    print("Model loaded. Sending prompt...")

    # --- Step 5: Send the User Prompt ---
    # Send only the user's prompt to generate_content
    response = model.generate_content(user_prompt)
    
    # Print the text response
    print("\n--- Model Response ---")
    print(response.text)
    print("------------------------\n")
except Exception as e:
    print(f"An error occurred while generating content: {e}")
print("Script finished.")
