import os
from langchain_google_vertexai import VertexAIEmbeddings
import warnings
from dotenv import load_dotenv
import glob
import shutil

load_dotenv()
warnings.filterwarnings("ignore")

CHROMA_PATH = os.path.join(os.getcwd(), "chroma_db")

def load_document(file):
    name, extension = os.path.splitext(file)

    if extension == '.pdf':
        from langchain_community.document_loaders import PyPDFLoader
        print(f'Loading {file}')
        loader = PyPDFLoader(file)
    elif extension == '.docx':
        from langchain_community.document_loaders import Docx2txtLoader
        print(f'Loading {file}')
        loader = Docx2txtLoader(file)
    elif extension == '.txt':
        from langchain_community.document_loaders import TextLoader
        loader = TextLoader(file)
    else:
        print('Document format is not supported!')
        return None

    data = loader.load()
    return data

def chunk_data(data, chunk_size=256):
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, 
        chunk_overlap=20
    )
    chunks = text_splitter.split_documents(data)
    print(f"Created {len(chunks)} chunks")
    return chunks 

def clear_chroma_db(persist_directory):
    """Clear existing Chroma database if it exists"""
    if os.path.exists(persist_directory):
        print(f"Removing existing Chroma database at {persist_directory}")
        shutil.rmtree(persist_directory)
        print("Old database removed successfully")

def create_embeddings_chroma(chunks, persist_directory=CHROMA_PATH, batch_size=200):
    from langchain_community.vectorstores import Chroma
 
    # Clear existing database to avoid dimension mismatch
    clear_chroma_db(persist_directory)
    
    # Initialize Vertex AI embeddings
    embeddings = VertexAIEmbeddings(
        model_name="text-embedding-004",
        project=os.getenv("GOOGLE_CLOUD_PROJECT"),
        location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
    )

    try:
        # Process chunks in batches to avoid the 250 limit
        if len(chunks) > batch_size:
            print(f"Processing {len(chunks)} chunks in batches of {batch_size}...")
            
            # Create initial vector store with first batch
            vector_store = Chroma.from_documents(
                chunks[:batch_size], 
                embeddings, 
                persist_directory=persist_directory
            )
            print(f"Processed batch 1/{(len(chunks) - 1) // batch_size + 1}")
            
            # Add remaining chunks in batches
            for i in range(batch_size, len(chunks), batch_size):
                batch = chunks[i:i + batch_size]
                vector_store.add_documents(batch)
                print(f"Processed batch {(i // batch_size) + 1}/{(len(chunks) - 1) // batch_size + 1}")
        else:
            # If chunks are within limit, process all at once
            Chroma.from_documents(chunks, embeddings, persist_directory=persist_directory)
        
        print("Successfully created Chroma vector store")
    except Exception as e:
        print(f"Error creating embeddings: {e}")
        raise

#### MAIN PROCESSING STARTS HERE

data_dir = os.path.join(os.getcwd(), 'ragdemo/data')
pdf_files = glob.glob(os.path.join(data_dir, '*.pdf'))

# Load all PDF documents
all_documents = []
for pdf_file in pdf_files:
    try:
        print(f'Processing file: {pdf_file}')
        docs = load_document(pdf_file)
        if docs:
            all_documents.extend(docs)
            print(f"Loaded: {os.path.basename(pdf_file)}")
    except Exception as e:
        print(f"Error loading {pdf_file}: {e}")

if not all_documents:
    print("No documents loaded successfully!")
    exit(1)

print(f'Loaded {len(all_documents)} document pages...')

# Split the documents into chunks
print('Splitting documents into chunks')
chunks = chunk_data(all_documents, chunk_size=256)

if chunks:
    create_embeddings_chroma(chunks)
    print('Chroma vector db created successfully')
else:
    print('No chunks created - check your documents')