import os
from langchain_google_vertexai import ChatVertexAI
from langchain_google_vertexai import VertexAIEmbeddings
import warnings
warnings.filterwarnings("ignore")

from dotenv import load_dotenv

load_dotenv()

CHROMA_PATH = os.path.join(os.getcwd(), "chroma_db")

def load_embeddings_chroma(persist_directory=CHROMA_PATH):
    from langchain_community.vectorstores import Chroma

    # Instantiate the same embedding model used during creation
    print('Instantiating the embedding model')

    embeddings = VertexAIEmbeddings(
        model_name="text-embedding-004",
        project=os.getenv("GOOGLE_CLOUD_PROJECT"),
        location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
    )

    print('Loading Chroma vector database, passing the embedding model to be used to it...')

    # Load the Chroma vector store from the specified directory, using the provided embedding function
    vector_store = Chroma(persist_directory=persist_directory, embedding_function=embeddings) 

    return vector_store  # Return the loaded vector store

def ask_and_get_answer(vector_store, q, k=3):
    from langchain_core.prompts import PromptTemplate
    from langchain_core.output_parsers import StrOutputParser
    from langchain_core.runnables import RunnablePassthrough

    llm = ChatVertexAI(
        model="gemini-2.0-flash-exp",
        temperature=0,
        project=os.getenv("GOOGLE_CLOUD_PROJECT"),
        location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
    )
    
    print('Fetching the retriever for the vector DB')
    retriever = vector_store.as_retriever(search_type='similarity', search_kwargs={'k': k})

    # Simple prompt template
    template = """Answer the question based only on the following context:

{context}

Question: {question}

Answer:"""
    
    prompt = PromptTemplate.from_template(template)
    
    # Create a simple chain
    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)
    
    chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    
    answer = chain.invoke(q)
    return answer

# Usage
vector_store = load_embeddings_chroma()
q = 'What technical skills does Pankaj have?'
answer = ask_and_get_answer(vector_store, q)
print("\nAnswer:", answer)