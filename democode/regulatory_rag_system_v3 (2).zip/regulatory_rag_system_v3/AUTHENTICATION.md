# Authentication Setup Guide

## Using Google Cloud Application Default Credentials (ADC)

This project uses **Application Default Credentials** (ADC) for authentication, which is the recommended approach for local development and deployment.

## Why Application Default Credentials?

✅ **No service account key files** to manage  
✅ **More secure** - credentials tied to your user account  
✅ **Easier setup** - one command to authenticate  
✅ **Works seamlessly** in Cloud environments (Cloud Run, GKE, Cloud Functions)  
✅ **Automatic credential refresh**  

## Setup Steps

### 1. Install gcloud CLI

If you don't have gcloud installed:

**macOS:**
```bash
brew install --cask google-cloud-sdk
```

**Linux:**
```bash
curl https://sdk.cloud.google.com | bash
exec -l $SHELL
```

**Windows:**
Download from: https://cloud.google.com/sdk/docs/install

### 2. Initialize gcloud

```bash
# Initialize gcloud (first time setup)
gcloud init

# Or just set your project if already initialized
gcloud config set project your-project-id
```

### 3. Authenticate with Application Default Credentials

```bash
# This opens a browser for authentication
gcloud auth application-default login
```

**What happens:**
- Browser opens for Google authentication
- You login with your corporate/personal Google account
- Credentials saved to `~/.config/gcloud/application_default_credentials.json`
- All Google Cloud client libraries automatically use these credentials

### 4. Verify Authentication

```bash
# Check if authentication worked
gcloud auth application-default print-access-token

# Should output an access token like:
# ya29.a0AfB_byBxxxx...
```

### 5. Set Environment Variables

```bash
# Required
export GOOGLE_CLOUD_PROJECT="your-project-id"

# Optional (defaults to us-central1)
export VERTEX_AI_LOCATION="us-central1"
```

## Required IAM Permissions

Your Google account needs these roles:

| Role | Purpose |
|------|---------|
| `roles/aiplatform.user` | Access Vertex AI (RAG Engine, Gemini) |
| `roles/storage.objectViewer` | Read from Cloud Storage (if using GCS) |

### Grant Permissions

**Option 1: Using gcloud**
```bash
# Replace with your email and project ID
gcloud projects add-iam-policy-binding your-project-id \
  --member="user:your-email@example.com" \
  --role="roles/aiplatform.user"
```

**Option 2: Using Cloud Console**
1. Go to https://console.cloud.google.com/iam-admin/iam
2. Find your email in the list
3. Click "Edit Principal"
4. Add role: "Vertex AI User"
5. Save

### Verify Permissions

```bash
# Check your current permissions
gcloud projects get-iam-policy your-project-id \
  --flatten="bindings[].members" \
  --filter="bindings.members:user:your-email@example.com"
```

## Using the Credentials in Code

### Automatic (Recommended)

The Google Cloud client libraries automatically detect and use ADC:

```python
import vertexai

# No explicit credentials needed!
vertexai.init(project="your-project-id", location="us-central1")
```

### How It Works

The library searches for credentials in this order:

1. **GOOGLE_APPLICATION_CREDENTIALS** environment variable (if set)
2. **Application Default Credentials** (`~/.config/gcloud/application_default_credentials.json`)
3. **Compute Engine/Cloud Run metadata server** (if running in GCP)

## Credential File Location

ADC credentials are stored at:

**Linux/macOS:**
```
~/.config/gcloud/application_default_credentials.json
```

**Windows:**
```
%APPDATA%\gcloud\application_default_credentials.json
```

**Don't commit this file to Git!** (Already in .gitignore)

## Running on Different Machines

### Developer Laptop
```bash
# Each developer runs once
gcloud auth application-default login
```

### CI/CD Pipeline
Use service account with Workload Identity Federation:
```bash
gcloud auth application-default login --impersonate-service-account=SA_EMAIL
```

### Cloud Run / Cloud Functions
No setup needed! ADC automatically uses service account attached to the service.

### Compute Engine / GKE
No setup needed! ADC automatically uses VM's service account.

## Troubleshooting

### Error: "Could not automatically determine credentials"

**Solution:**
```bash
# Re-run authentication
gcloud auth application-default login

# Verify credentials file exists
ls -la ~/.config/gcloud/application_default_credentials.json
```

### Error: "User does not have permission to access project"

**Solution:**
```bash
# Ensure project is set correctly
gcloud config get-value project

# If wrong project:
gcloud config set project correct-project-id

# Re-authenticate
gcloud auth application-default login
```

### Error: "Vertex AI API has not been enabled"

**Solution:**
```bash
# Enable Vertex AI API
gcloud services enable aiplatform.googleapis.com --project=your-project-id
```

### Error: "Permission denied on Vertex AI operation"

**Solution:**
```bash
# Add required role
gcloud projects add-iam-policy-binding your-project-id \
  --member="user:your-email@example.com" \
  --role="roles/aiplatform.user"

# Wait 1-2 minutes for propagation, then retry
```

### Credentials Expired

ADC tokens expire. If you get authentication errors after a while:

```bash
# Refresh credentials
gcloud auth application-default login
```

## Switching Between Projects

```bash
# List available projects
gcloud projects list

# Switch project
gcloud config set project another-project-id

# Re-authenticate for new project (if needed)
gcloud auth application-default login
```

## Security Best Practices

✅ **Use ADC for development** - Never hardcode credentials  
✅ **Use Workload Identity** for production - Service accounts attached to workloads  
✅ **Principle of least privilege** - Only grant necessary roles  
✅ **Rotate credentials** - Re-run `gcloud auth application-default login` periodically  
✅ **Never commit credentials** - .gitignore is configured to exclude them  

## Comparison: ADC vs Service Account Key

| Aspect | Application Default Credentials (ADC) | Service Account Key JSON |
|--------|--------------------------------------|--------------------------|
| Setup | One command: `gcloud auth application-default login` | Download JSON, set env var |
| Security | ✅ Tied to user, auto-refresh | ❌ Long-lived, easy to leak |
| Rotation | Automatic | Manual |
| Revocation | Instant (revoke user access) | Must delete key |
| Local Dev | ✅ Perfect | ⚠️ Not recommended |
| Production | Use Workload Identity | ✅ Acceptable (if secured) |
| Audit | ✅ Tied to user identity | Service account identity |

## Summary Commands

```bash
# Complete setup in 3 commands
gcloud auth application-default login
gcloud config set project your-project-id
export GOOGLE_CLOUD_PROJECT="your-project-id"

# Verify everything works
python -c "
from google.cloud import aiplatform
aiplatform.init(project='your-project-id', location='us-central1')
print('✅ Authentication successful!')
"
```

## Additional Resources

- [Application Default Credentials Documentation](https://cloud.google.com/docs/authentication/application-default-credentials)
- [Best practices for using service accounts](https://cloud.google.com/iam/docs/best-practices-service-accounts)
- [Workload Identity Federation](https://cloud.google.com/iam/docs/workload-identity-federation)

---

**Questions?** Check the troubleshooting section or contact your GCP administrator.
