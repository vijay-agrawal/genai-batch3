# Google Cloud Storage Setup for Vertex AI RAG Engine

## Why GCS is Required

Vertex AI RAG Engine **requires** documents to be stored in Google Cloud Storage (GCS) before indexing. This is because:

1. RAG Engine needs a persistent URI to reference documents
2. It performs its own chunking and processing on GCS files
3. It creates vector embeddings from GCS-stored documents
4. This ensures consistency across indexing and retrieval

## Step-by-Step Setup

### Step 1: Create a GCS Bucket

**Option A: Using gcloud CLI (Recommended)**

```bash
# Set your project
gcloud config set project your-project-id

# Create bucket (choose a globally unique name)
# Format: gs://your-regulatory-docs-bucket
export BUCKET_NAME="genai-training-rag"

gcloud storage buckets create gs://${BUCKET_NAME} \
  --location=us-central1 \
  --uniform-bucket-level-access

# Verify bucket created
gcloud storage buckets list
```

**Option B: Using Cloud Console**

1. Go to https://console.cloud.google.com/storage
2. Click "CREATE BUCKET"
3. Bucket name: `your-regulatory-docs-bucket` (must be globally unique)
4. Location type: `Region`
5. Location: `us-central1` (match your VERTEX_AI_LOCATION)
6. Default storage class: `Standard`
7. Access control: `Uniform`
8. Click "CREATE"

### Step 2: Set Bucket Permissions

```bash
# Grant yourself storage permissions
gcloud storage buckets add-iam-policy-binding gs://${BUCKET_NAME} \
  --member="user:your-email@example.com" \
  --role="roles/storage.objectAdmin"

# Grant Vertex AI service account access
PROJECT_NUMBER=$(gcloud projects describe $(gcloud config get-value project) --format="value(projectNumber)")

gcloud storage buckets add-iam-policy-binding gs://${BUCKET_NAME} \
  --member="serviceAccount:service-${PROJECT_NUMBER}@gcp-sa-aiplatform.iam.gserviceaccount.com" \
  --role="roles/storage.objectViewer"
```

### Step 3: Upload Documents to GCS

After running `python scripts/generate_data.py`, upload the documents:

**Option A: Using gcloud CLI**

```bash
# Upload all regulatory documents
gcloud storage cp data/regulatory_documents/*.txt \
  gs://${BUCKET_NAME}/regulatory_documents/

# Verify upload
gcloud storage ls gs://${BUCKET_NAME}/regulatory_documents/

# Should show:
# gs://your-regulatory-docs-bucket/regulatory_documents/RBI_Capital_Adequacy_Guidelines_2024.txt
# gs://your-regulatory-docs-bucket/regulatory_documents/MAS_Liquidity_Framework_2024.txt
# gs://your-regulatory-docs-bucket/regulatory_documents/RBI_NPA_Classification_Guidelines_2024.txt
# gs://your-regulatory-docs-bucket/regulatory_documents/FATF_AML_CFT_Standards_2024.txt
```

**Option B: Using Cloud Console**

1. Go to https://console.cloud.google.com/storage/browser
2. Click on your bucket name
3. Click "CREATE FOLDER" → Name it `regulatory_documents`
4. Click into the folder
5. Click "UPLOAD FILES"
6. Select all files from `data/regulatory_documents/`
7. Wait for upload to complete

**Option C: Using Python Script (Automated)**

```bash
# Use the provided upload script
python scripts/upload_to_gcs.py
```

### Step 4: Configure Environment Variables

```bash
# Set environment variables
export GOOGLE_CLOUD_PROJECT="your-project-id"
export VERTEX_AI_LOCATION="us-central1"
export GCS_BUCKET_NAME="your-regulatory-docs-bucket"

# Or edit .env file
cat > .env << EOF
GOOGLE_CLOUD_PROJECT=your-project-id
VERTEX_AI_LOCATION=us-central1
GCS_BUCKET_NAME=your-regulatory-docs-bucket
EOF
```

### Step 5: Verify Setup

```bash
# Verify you can list bucket contents
gcloud storage ls gs://${GCS_BUCKET_NAME}/regulatory_documents/

# Test access from Python
python -c "
from google.cloud import storage
import os

bucket_name = os.getenv('GCS_BUCKET_NAME', 'your-regulatory-docs-bucket')
client = storage.Client()
bucket = client.bucket(bucket_name)

blobs = list(bucket.list_blobs(prefix='regulatory_documents/'))
print(f'✓ Found {len(blobs)} files in GCS')
for blob in blobs:
    print(f'  - {blob.name} ({blob.size} bytes)')
"
```

## Bucket Structure

After setup, your GCS bucket should look like this:

```
gs://your-regulatory-docs-bucket/
└── regulatory_documents/
    ├── RBI_Capital_Adequacy_Guidelines_2024.txt
    ├── MAS_Liquidity_Framework_2024.txt
    ├── RBI_NPA_Classification_Guidelines_2024.txt
    └── FATF_AML_CFT_Standards_2024.txt
```

## GCS URIs Format

Vertex AI RAG Engine uses GCS URIs in this format:

```
gs://BUCKET_NAME/FOLDER_NAME/FILENAME.txt
```

Examples:
- `gs://my-regulatory-bucket/regulatory_documents/RBI_Capital_Adequacy_Guidelines_2024.txt`
- `gs://my-regulatory-bucket/regulatory_documents/MAS_Liquidity_Framework_2024.txt`

## Cost Considerations

**GCS Storage Costs (us-central1):**
- Standard storage: $0.020 per GB/month
- Our documents: ~2 MB total = **$0.00004/month**

**GCS Operations:**
- Class A operations (uploads): $0.05 per 10,000 operations
- Class B operations (reads): $0.004 per 10,000 operations
- Initial upload: 4 files = **$0.00002**

**Vertex AI RAG Engine:**
- Indexing: One-time cost when documents are imported
- Retrieval: Per-query cost
- Total: ~$0.01-0.05 per validation report

**Total Monthly Cost:** < $1 for demo/training purposes

## Troubleshooting

### Error: "Bucket already exists"

```bash
# Bucket names are globally unique
# Try a different name with your project ID
export BUCKET_NAME="${GOOGLE_CLOUD_PROJECT}-regulatory-docs"
```

### Error: "Permission denied"

```bash
# Ensure you're authenticated
gcloud auth application-default login

# Check your permissions
gcloud projects get-iam-policy $(gcloud config get-value project) \
  --flatten="bindings[].members" \
  --filter="bindings.members:user:$(gcloud config get-value account)"

# Grant storage admin role if missing
gcloud projects add-iam-policy-binding $(gcloud config get-value project) \
  --member="user:$(gcloud config get-value account)" \
  --role="roles/storage.admin"
```

### Error: "Files not found in GCS"

```bash
# List bucket contents
gcloud storage ls -r gs://${GCS_BUCKET_NAME}/

# If empty, re-upload
gcloud storage cp data/regulatory_documents/*.txt \
  gs://${GCS_BUCKET_NAME}/regulatory_documents/
```

### Error: "Vertex AI can't access bucket"

```bash
# Grant Vertex AI service account access
PROJECT_NUMBER=$(gcloud projects describe $(gcloud config get-value project) --format="value(projectNumber)")

gcloud storage buckets add-iam-policy-binding gs://${GCS_BUCKET_NAME} \
  --member="serviceAccount:service-${PROJECT_NUMBER}@gcp-sa-aiplatform.iam.gserviceaccount.com" \
  --role="roles/storage.objectViewer"
```

## Verification Checklist

Before running the indexing script, verify:

- [ ] GCS bucket created in same region as Vertex AI (us-central1)
- [ ] Documents uploaded to `gs://BUCKET/regulatory_documents/`
- [ ] You can list bucket contents with `gcloud storage ls`
- [ ] Environment variable `GCS_BUCKET_NAME` is set
- [ ] Vertex AI service account has objectViewer role on bucket

## Next Steps

After GCS setup is complete:

```bash
# 1. Generate documents (if not already done)
python scripts/generate_data.py

# 2. Upload to GCS
python scripts/upload_to_gcs.py

# 3. Index into RAG Engine
python scripts/index_documents.py

# 4. Validate reports
python scripts/validate_report.py --validate-all
```

## Understanding the RAG Flow

```
Local Files → GCS Upload → RAG Import → Chunking → Embedding → Index
   ↓
data/regulatory_documents/*.txt
   ↓
gs://bucket/regulatory_documents/*.txt ← Vertex AI RAG reads from here
   ↓
RAG Corpus (managed by Vertex AI)
   ↓
Vector Index (embeddings)
   ↓
Query → Retrieve → Generate
```

## Additional Resources

- [GCS Documentation](https://cloud.google.com/storage/docs)
- [Vertex AI RAG Engine](https://cloud.google.com/vertex-ai/docs/generative-ai/rag-overview)
- [gcloud storage commands](https://cloud.google.com/sdk/gcloud/reference/storage)
