#!/usr/bin/env python3
"""
Validate regulatory reports using RAG-augmented LLM
"""
import sys
from pathlib import Path
import argparse
import json
import logging
from colorama import Fore, Style, init

# Initialize colorama
init(autoreset=True)

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import settings
from src.rag_engine import VertexRAGEngine
from src.validator import RegulatoryValidator

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def print_validation_result(result: dict):
    """
    Pretty print validation results
    
    Args:
        result: Validation result dictionary
    """
    print("\n" + "=" * 70)
    print(f"{Fore.CYAN}Regulatory Report Validation{Style.RESET_ALL}")
    print("=" * 70)
    
    print(f"\n{Fore.WHITE}Report: {result['report_type']}{Style.RESET_ALL}")
    print(f"Bank: {result['bank_name']}")
    print(f"Reporting Date: {result['reporting_date']}")
    print(f"File: {result['report_file']}")
    
    print(f"\n{Fore.YELLOW}{'=' * 70}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}Validation Results{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}{'=' * 70}{Style.RESET_ALL}")
    
    # Print each check
    for idx, check in enumerate(result['checks'], 1):
        status = check['status']
        check_name = check['check_name']
        
        # Color code status
        if status == 'PASS':
            status_str = f"{Fore.GREEN}✓ PASS{Style.RESET_ALL}"
        elif status == 'FAIL':
            status_str = f"{Fore.RED}✗ FAIL{Style.RESET_ALL}"
        elif status == 'WARNING':
            status_str = f"{Fore.YELLOW}⚠ WARNING{Style.RESET_ALL}"
        else:
            status_str = f"{Fore.MAGENTA}? {status}{Style.RESET_ALL}"
        
        print(f"\n{status_str}: {check_name}")
        
        if check.get('value') is not None:
            print(f"  Reported Value: {check['value']}")
        
        # Print message (truncated if too long)
        message = check.get('message', 'No details available')
        if len(message) > 300:
            message = message[:297] + "..."
        
        print(f"  {Fore.WHITE}Details:{Style.RESET_ALL}")
        for line in message.split('\n'):
            if line.strip():
                print(f"    {line.strip()}")
    
    # Print summary
    print(f"\n{Fore.CYAN}{'=' * 70}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}Summary{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'=' * 70}{Style.RESET_ALL}")
    
    summary = result['summary']
    print(f"Total Checks: {summary['total_checks']}")
    print(f"{Fore.GREEN}Passed: {summary['passed']}{Style.RESET_ALL}")
    print(f"{Fore.RED}Failed: {summary['failed']}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}Warnings: {summary['warnings']}{Style.RESET_ALL}")
    
    # Overall status
    overall_status = result['overall_status']
    if 'COMPLIANT' in overall_status and 'REQUIRES' not in overall_status:
        status_color = Fore.GREEN
    elif 'REQUIRES' in overall_status:
        status_color = Fore.RED
    else:
        status_color = Fore.YELLOW
    
    print(f"\n{status_color}Overall Status: {overall_status}{Style.RESET_ALL}")
    print("=" * 70 + "\n")


def validate_single_report(
    report_path: Path,
    rag_engine: VertexRAGEngine,
    regulator: str = None
):
    """
    Validate a single report
    
    Args:
        report_path: Path to report JSON file
        rag_engine: Initialized RAG engine
        regulator: Optional specific regulator
    """
    logger.info(f"Validating report: {report_path.name}")
    
    # Initialize validator
    validator = RegulatoryValidator(rag_engine)
    
    # Validate report
    result = validator.validate_report(report_path, regulator)
    
    # Print results
    print_validation_result(result)
    
    # Save results
    output_file = settings.OUTPUT_DIR / f"validation_{report_path.stem}.json"
    with open(output_file, 'w') as f:
        json.dump(result, f, indent=2)
    
    logger.info(f"Validation results saved to: {output_file}")
    
    return result


def validate_all_reports(
    rag_engine: VertexRAGEngine,
    regulator: str = None
):
    """
    Validate all reports in submissions directory
    
    Args:
        rag_engine: Initialized RAG engine
        regulator: Optional specific regulator
    """
    report_files = list(settings.REPORT_SUBMISSIONS_DIR.glob("*.json"))
    
    if not report_files:
        logger.warning("No reports found to validate!")
        return
    
    logger.info(f"Found {len(report_files)} reports to validate")
    
    all_results = []
    
    for report_file in report_files:
        result = validate_single_report(report_file, rag_engine, regulator)
        all_results.append(result)
    
    # Print overall summary
    print("\n" + "=" * 70)
    print(f"{Fore.CYAN}Overall Validation Summary{Style.RESET_ALL}")
    print("=" * 70)
    
    compliant = sum(1 for r in all_results if 'COMPLIANT' in r['overall_status'] and 'REQUIRES' not in r['overall_status'])
    non_compliant = sum(1 for r in all_results if 'REQUIRES' in r['overall_status'])
    review_needed = len(all_results) - compliant - non_compliant
    
    print(f"\nTotal Reports Validated: {len(all_results)}")
    print(f"{Fore.GREEN}Compliant: {compliant}{Style.RESET_ALL}")
    print(f"{Fore.RED}Non-Compliant: {non_compliant}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}Needs Review: {review_needed}{Style.RESET_ALL}")
    print("=" * 70 + "\n")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Validate regulatory reports using RAG-augmented LLM'
    )
    parser.add_argument(
        '--report',
        type=str,
        help='Path to specific report JSON file to validate'
    )
    parser.add_argument(
        '--validate-all',
        action='store_true',
        help='Validate all reports in submissions directory'
    )
    parser.add_argument(
        '--regulator',
        type=str,
        choices=['RBI', 'MAS', 'BIS', 'FATF'],
        help='Focus on specific regulator guidelines'
    )
    
    args = parser.parse_args()
    
    if not args.report and not args.validate_all:
        parser.error("Must specify either --report or --validate-all")
    
    try:
        # Initialize RAG engine
        logger.info("Initializing Vertex AI RAG engine...")
        rag_engine = VertexRAGEngine(
            project_id=settings.GOOGLE_CLOUD_PROJECT,
            location=settings.VERTEX_AI_LOCATION,
            corpus_display_name=settings.RAG_CORPUS_DISPLAY_NAME,
            embedding_model=settings.EMBEDDING_MODEL,
            bucket_name=settings.GCS_BUCKET_NAME
        )
        
        # Get existing corpus
        corpus_name = rag_engine.create_corpus()
        logger.info(f"Using corpus: {corpus_name}")
        
        # Validate report(s)
        if args.validate_all:
            validate_all_reports(rag_engine, args.regulator)
        else:
            report_path = Path(args.report)
            if not report_path.exists():
                logger.error(f"Report file not found: {report_path}")
                sys.exit(1)
            
            validate_single_report(report_path, rag_engine, args.regulator)
        
        logger.info("Validation complete!")
        
    except Exception as e:
        logger.error(f"Validation failed: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
