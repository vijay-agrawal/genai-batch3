"""
Generate synthetic regulatory documents and sample bank reports for validation testing
"""
import json
import sys
from pathlib import Path
from datetime import datetime, timedelta

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.settings import REGULATORY_DOCS_DIR, REPORT_SUBMISSIONS_DIR


def generate_regulatory_documents():
    """Generate synthetic regulatory guideline documents"""
    
    documents = {
        "RBI_Capital_Adequacy_Guidelines_2024.txt": """
RESERVE BANK OF INDIA
Master Direction - Basel III Capital Regulations
DBR.No.BP.BC.1/21.06.201/2023-24
Effective Date: April 1, 2024

SECTION 1: INTRODUCTION
These directions apply to all commercial banks operating in India including foreign banks.
The framework aims to strengthen the resilience of the banking sector.

SECTION 2: MINIMUM CAPITAL REQUIREMENTS

2.1 Common Equity Tier 1 (CET1) Capital
Banks must maintain Common Equity Tier 1 capital at a minimum of 5.5% of Risk Weighted Assets (RWA).
CET1 capital comprises of paid-up equity capital, statutory reserves, and other disclosed reserves.

2.2 Tier 1 Capital
Minimum Tier 1 capital ratio shall be 7.0% of RWA.
Tier 1 capital = CET1 + Additional Tier 1 capital instruments.

2.3 Total Capital Ratio
Minimum total capital (Tier 1 + Tier 2) ratio shall be 9.0% of RWA.
This is higher than the Basel Committee's 8% requirement.

2.4 Capital Conservation Buffer (CCB)
Banks must maintain a CCB of 2.5% of RWA in the form of CET1 capital.
This is in addition to the minimum capital requirements.
Effective total capital requirement = 9.0% + 2.5% = 11.5%

2.5 Domestic Systemically Important Banks (D-SIB)
D-SIBs must maintain additional CET1 capital ranging from 0.2% to 0.8% based on systemic importance.
DBS Bank India is classified as a D-SIB and must maintain an additional 0.2% capital.
Effective requirement for DBS = 11.5% + 0.2% = 11.7%

SECTION 3: COMPONENTS OF CAPITAL

3.1 Common Equity Tier 1
Includes:
- Paid-up equity capital
- Statutory reserves
- Capital reserves representing surplus from sale of assets
- General reserves and balance in Profit & Loss account
- Less: Regulatory adjustments and deductions

3.2 Regulatory Deductions from CET1
- Goodwill and other intangible assets
- Deferred tax assets dependent on future profitability
- Shortfall in provisions for NPAs
- Defined benefit pension fund assets
- Investments in own shares (treasury stock)

3.3 Additional Tier 1 Capital
- Perpetual non-cumulative preference shares
- Perpetual debt instruments
Subject to: write-down or conversion features at point of non-viability

3.4 Tier 2 Capital
- General provisions up to 1.25% of credit RWA
- Debt capital instruments with minimum maturity of 10 years
- Revaluation reserves at 55% discount
- Subordinated debt

SECTION 4: RISK WEIGHTED ASSETS

4.1 Credit Risk
Risk weights for corporate exposures:
- AAA to AA-: 20%
- A+ to A-: 50%
- BBB+ to BBB-: 100%
- Below BBB-: 150%
- Unrated: 100%

Retail exposures: 75% (if criteria met)
Residential mortgages: 35% to 75% (based on LTV)

4.2 Market Risk
Capital charge for market risk using Standardized Measurement Method.
Covers interest rate risk, equity risk, foreign exchange risk, and commodity risk.

4.3 Operational Risk
Capital charge calculated using Basic Indicator Approach (15% of average gross income).

SECTION 5: REPORTING REQUIREMENTS

5.1 Frequency
Quarterly submission within 21 days of quarter end.
Annual detailed report with auditor certification (LFAR).

5.2 Format
Use specified Form X format available on RBI website.
Include detailed computation worksheets.

5.3 Breaches
Any breach of minimum requirements must be reported immediately.
Bank must submit a capital restoration plan within 7 days.

SECTION 6: TRANSITIONAL PROVISIONS

6.1 Capital Instruments
Capital instruments issued prior to April 1, 2023 that do not meet Basel III criteria:
- Will be phased out at 10% per annum starting 2024
- Complete phase-out by April 1, 2033

6.2 Regulatory Adjustments
Deductions implemented with transitional arrangements.

SECTION 7: SUPERVISORY REVIEW

7.1 Pillar 2 Requirements
Banks must maintain capital above minimum to cover risks not captured in Pillar 1.
RBI may impose higher capital requirements based on supervisory review.

7.2 Internal Capital Adequacy Assessment Process (ICAAP)
Banks must conduct annual ICAAP and submit to RBI.
Should cover credit concentration risk, interest rate risk in banking book, liquidity risk, etc.

SECTION 8: PENALTIES

Non-compliance may result in:
- Restrictions on dividend distribution
- Restrictions on expansion of risk-weighted assets
- Enhanced reporting requirements
- Monetary penalties up to ₹1 crore per violation
- Other supervisory actions as deemed necessary

Last Updated: January 15, 2024
Circular Reference: RBI/2023-24/183
""",

        "MAS_Liquidity_Framework_2024.txt": """
MONETARY AUTHORITY OF SINGAPORE
Notice 649 - Liquidity Framework
MAS Notice 649 (Amendment) 2024
Effective Date: January 1, 2024

PART I: INTRODUCTION
This Notice applies to all banks incorporated in Singapore and merchant banks.

PART II: LIQUIDITY COVERAGE RATIO (LCR)

2.1 Minimum LCR Requirement
Banks must maintain an LCR of at least 100% at all times.
LCR = Stock of High-Quality Liquid Assets (HQLA) / Total Net Cash Outflows over next 30 days

2.2 High-Quality Liquid Assets (HQLA)

Level 1 Assets (0% haircut):
- Cash and reserves with MAS
- Marketable securities issued by sovereigns, central banks, PSEs with 0% risk weight
- Singapore Government Securities (SGS)

Level 2A Assets (15% haircut):
- Marketable securities issued by sovereigns with 20% risk weight
- Corporate debt securities rated AA- or higher
- Covered bonds rated AA- or higher

Level 2B Assets (50% haircut):
- Corporate debt securities rated A- to BBB-
- Residential mortgage-backed securities (RMBS) rated AA or higher
- Common equity shares (limited to 50% of Level 2B)

2.3 HQLA Cap
Level 2 assets cannot exceed 40% of total HQLA.
Level 2B assets cannot exceed 15% of total HQLA.

2.4 Cash Outflows (30-day stressed scenario)

Retail Deposits:
- Stable deposits: 5% outflow
- Less stable deposits: 10% outflow

Wholesale Funding:
- Operational deposits: 25% outflow
- Non-operational deposits from non-financial corporates: 40% outflow
- Unsecured wholesale funding from financial institutions: 100% outflow

Other Outflows:
- Derivatives collateral calls: Based on mark-to-market valuation
- Committed credit facilities: 10% (retail), 30% (non-financial corporates), 100% (financial institutions)
- Contractual obligations: 100%

2.5 Cash Inflows (Capped at 75% of outflows)

- Maturing reverse repo: 0% inflow
- Retail lending: 50% inflow
- Wholesale lending to non-financial corporates: 50% inflow
- Operational deposits placed at other banks: 0% inflow

PART III: NET STABLE FUNDING RATIO (NSFR)

3.1 Minimum NSFR Requirement
Banks must maintain an NSFR of at least 100%.
NSFR = Available Stable Funding (ASF) / Required Stable Funding (RSF)

3.2 Available Stable Funding

Capital and Liabilities with ASF factors:
- Tier 1 and Tier 2 capital: 100%
- Stable retail deposits: 95%
- Less stable retail deposits: 90%
- Wholesale funding with maturity > 1 year: 100%
- Wholesale funding with maturity 6 months - 1 year: 50%

3.3 Required Stable Funding

Assets with RSF factors:
- Cash and reserves: 0%
- Level 1 HQLA: 5%
- Level 2A HQLA: 15%
- Level 2B HQLA: 50%
- Performing loans with maturity < 1 year: 50%
- Performing loans with maturity > 1 year: 65%
- Retail mortgages: 65%
- Unencumbered non-financial equity: 85%
- Physical traded commodities: 85%
- Other assets: 100%

PART IV: REPORTING

4.1 Reporting Frequency
Monthly submission of LCR report within 10 business days.
Quarterly submission of NSFR report within 21 days.

4.2 Breach Reporting
Immediate notification to MAS of any LCR breach.
Submission of remediation plan within 5 business days.

4.3 Intraday Liquidity
Banks must monitor and manage intraday liquidity positions.
Report significant intraday liquidity stress events to MAS within 24 hours.

PART V: ADDITIONAL LIQUIDITY MONITORING TOOLS

5.1 Contractual Maturity Mismatch
Report contractual cash flows over specified time buckets.
Identify potential liquidity gaps.

5.2 Concentration of Funding
Monitor reliance on large depositors and wholesale funding sources.
Single counterparty funding concentration should not exceed 10% of total liabilities.

5.3 Available Unencumbered Assets
Maintain buffer of unencumbered marketable assets.
Should be sufficient to cover stressed outflows beyond 30-day horizon.

5.4 LCR by Currency
Monitor LCR in significant currencies separately (SGD, USD, EUR, JPY).
Each currency LCR should be at least 80%.

PART VI: INTRADAY LIQUIDITY MANAGEMENT

6.1 Payment Systems
Ensure timely settlement of payment obligations.
Maintain sufficient balances in MEPS+ (Singapore's RTGS system).

6.2 Collateral Management
Effective management of collateral for intraday credit facilities.
Monitor velocity of collateral and concentration.

PART VII: CONTINGENCY FUNDING PLAN

7.1 Requirements
Banks must maintain a comprehensive CFP.
Annual review and testing required.
Update CFP within 30 days of material changes to business or liquidity profile.

7.2 Components
- Early warning indicators
- Diversified funding sources
- Stress testing scenarios
- Escalation procedures
- Communication plan

PART VIII: PENALTIES

Breach of minimum LCR/NSFR may result in:
- Composition fines up to SGD 1 million
- Restrictions on business activities
- Increased reporting frequency
- Additional capital requirements

Last Updated: December 20, 2023
Reference: MAS Notice 649 (Amendment No. 2) 2024
""",

        "RBI_NPA_Classification_Guidelines_2024.txt": """
RESERVE BANK OF INDIA
Master Circular - Prudential Norms on Income Recognition, Asset Classification and Provisioning
RBI/2023-24/105 DOR.STR.REC.51/21.04.048/2023-24
Effective Date: April 1, 2024

SECTION 1: INCOME RECOGNITION

1.1 Accrual Basis
Income from performing assets to be recognized on accrual basis.
Income on non-performing assets (NPAs) to be recognized on cash basis only.

1.2 Interest on NPAs
Interest on NPAs should not be taken to income account on accrual basis.
Interest received on NPAs should first be appropriated to principal outstanding.

SECTION 2: ASSET CLASSIFICATION

2.1 Standard Assets
Assets carrying normal credit risk.
Not more than 90 days past due.
No signs of weakness in borrower's financial position.

2.2 Non-Performing Assets (NPAs)
An asset becomes NPA when:
- Interest and/or principal payment remains overdue for more than 90 days
- Interest payment is overdue for more than 90 days for term loans
- Account remains out-of-order for more than 90 days for cash credit/overdraft
- Bill remains overdue for more than 90 days
- Installment of principal or interest remains overdue for two harvest seasons for agricultural loans

2.3 Sub-Standard Assets
NPA for a period not exceeding 12 months.
Asset shows well-defined credit weaknesses.
Distinct possibility that bank will sustain some loss if deficiencies are not corrected.

2.4 Doubtful Assets
NPA for more than 12 months.
Further classified into:
- Doubtful 1: NPA for 12-24 months
- Doubtful 2: NPA for 24-36 months
- Doubtful 3: NPA for more than 36 months

2.5 Loss Assets
Asset identified by bank or RBI inspector as loss asset.
Asset where loss has been identified but not written off.
Identified as uncollectible and of such little value that continuance as bankable asset is not warranted.

SECTION 3: PROVISIONING REQUIREMENTS

3.1 Standard Assets Provisioning

Direct Agriculture: 0.25%
SME Advances: 0.25%
Commercial Real Estate: 1.00%
Commercial Real Estate - Residential Housing (CRE-RH): 0.75%
Housing Loans (Priority Sector): 0.25%
Housing Loans (Non-Priority Sector): 0.40%
Consumer Credit (including credit cards): 0.40%
All other loans: 0.40%

3.2 Sub-Standard Assets Provisioning

Secured Exposures: 15%
Unsecured Exposures: 25%

Secured exposure means exposure backed by tangible security.
Tangible security includes mortgage, hypothecation, pledge, but excludes guarantees.

3.3 Doubtful Assets Provisioning

For Secured Portion:
- Doubtful 1 (12-24 months): 25%
- Doubtful 2 (24-36 months): 40%
- Doubtful 3 (> 36 months): 100%

For Unsecured Portion: 100%

Secured portion = Realizable value of security (after haircut)
Unsecured portion = Outstanding - Secured portion

3.4 Loss Assets Provisioning
100% of outstanding to be provided for.
If not written off, entire asset to be provided for.

SECTION 4: RESTRUCTURED ADVANCES

4.1 Definition
Restructuring involves modification of terms of loan due to deterioration in borrower's financial position.
Includes:
- Extension of repayment period
- Conversion of principal/interest into debt/equity
- Sanctioning of additional credit facility
- Any other modification

4.2 Asset Classification
Restructured standard assets to remain standard but classified as 'standard-restructured'.
Additional provision of 5% on restructured standard assets (over and above standard asset provisioning).

Restructured NPA:
- Continues to be NPA for at least one year after restructuring
- Shows satisfactory performance during this period for upgradation
- Additional provisioning of 10% even after upgradation (minimum 2 years)

SECTION 5: WILFUL DEFAULTERS

5.1 Definition
Borrower who has:
- Defaulted despite capacity to pay
- Diverted funds for purposes other than those for which loan was sanctioned
- Siphoned off funds
- Not utilized funds for specified purpose
- Disposed off assets without bank's knowledge

5.2 Action
100% provisioning required.
Additional provisioning for diminution in fair value of security.
No additional facilities to be granted.
Report to CRILC (Central Repository of Information on Large Credits).

SECTION 6: CENTRAL REPOSITORY OF INFORMATION ON LARGE CREDITS (CRILC)

6.1 Reporting Threshold
All borrowers with aggregate fund-based and non-fund-based exposure of ₹5 crore and above.

6.2 Information to be Reported
- Basic borrower details
- Credit facilities sanctioned
- Outstanding amounts
- Asset classification
- Suit-filed accounts
- Date of becoming NPA
- Amount of write-offs

6.3 Reporting Frequency
Monthly, within 10 days of month-end.
Special reporting for SMA (Special Mention Accounts):
- SMA-0: Principal or interest overdue for 1-30 days
- SMA-1: Principal or interest overdue for 31-60 days
- SMA-2: Principal or interest overdue for 61-90 days

SECTION 7: SALE OF NPAs

7.1 Permissibility
Banks may sell NPAs to:
- Asset Reconstruction Companies (ARCs)
- Other banks/FIs
- Non-Banking Financial Companies (NBFCs)
- Qualified buyers

7.2 True Sale Criteria
- Transfer should be without recourse
- Risks and rewards transferred to buyer
- Seller cannot retain beneficial interest

7.3 Accounting Treatment
Profit/loss on sale to be recognized in P&L account.
Excess provision reversed or additional provision made.

SECTION 8: WRITE-OFF

8.1 Policy
Banks must have Board-approved policy for write-off.
Should be based on realistic assessment of recovery prospects.

8.2 Continuation of Recovery
Write-off does not mean waiver of debt.
Recovery efforts to continue even after write-off.
Any amount recovered to be taken to income account.

8.3 Reporting
Accounts written off should continue to be reported in CRILC.

SECTION 9: DISCLOSURE IN FINANCIAL STATEMENTS

9.1 Required Disclosures
- Gross NPAs and Net NPAs
- NPA ratios (Gross and Net)
- Movement of NPAs and provisions
- Sector-wise NPAs
- Geographical distribution of NPAs
- Write-offs and recoveries

9.2 Format
Follow Schedule 7, 8, and 9 of BR Act 1949 format.
Additional disclosures as per Notes to Accounts.

SECTION 10: SUPERVISORY ACTION

10.1 High NPA Banks
Banks with Gross NPA ratio > 6% classified as high NPA banks.
Subject to enhanced monitoring by RBI.

10.2 Prompt Corrective Action (PCA)
Banks trigger PCA if:
- Tier 1 capital < 6%
- Net NPA ratio > 9%
- Return on Assets (RoA) negative for two consecutive years

PCA Framework involves restrictions on:
- Dividend distribution
- Branch expansion
- Director compensation

Last Updated: February 10, 2024
Circular Reference: RBI/2023-24/105
""",

        "FATF_AML_CFT_Standards_2024.txt": """
FINANCIAL ACTION TASK FORCE (FATF)
International Standards on Combating Money Laundering and the Financing of Terrorism & Proliferation
The FATF Recommendations
Updated: March 2024

RECOMMENDATION 10: CUSTOMER DUE DILIGENCE (CDD)

10.1 CDD Measures
Financial institutions should be required to undertake customer due diligence measures when:
- Establishing business relationships
- Carrying out occasional transactions above USD/EUR 15,000
- There is suspicion of money laundering or terrorist financing
- There are doubts about previously obtained customer identification data

10.2 CDD Requirements
Identify and verify customer identity using reliable, independent source documents.
Identify beneficial owner and verify identity.
Understand purpose and intended nature of business relationship.
Conduct ongoing due diligence on business relationship.

10.3 Beneficial Owner
Natural person who ultimately owns or controls customer.
Threshold: 25% ownership or control.
Senior managing official if no natural person identified.

10.4 Politically Exposed Persons (PEPs)
Enhanced due diligence for:
- Foreign PEPs
- Domestic PEPs (based on risk)
- International organization PEPs

Requirements:
- Senior management approval for establishing relationship
- Reasonable measures to establish source of wealth and funds
- Enhanced ongoing monitoring

RECOMMENDATION 11: RECORD KEEPING

11.1 Transaction Records
Maintain records of transactions for at least 5 years.
Should be sufficient to permit reconstruction of individual transactions.

11.2 CDD Records
Maintain copies of identification documents for at least 5 years after relationship ends.
Include account files and business correspondence.

11.3 Availability
Records must be available to competent authorities upon appropriate authority.

RECOMMENDATION 16: WIRE TRANSFERS

16.1 Originator Information
Cross-border wire transfers of USD/EUR 1,000 or more:
- Originator name
- Originator account number
- Originator address or national identity number or date and place of birth

16.2 Beneficiary Information
- Beneficiary name
- Beneficiary account number

16.3 Travel Rule
Required information should accompany wire transfer through payment chain.

16.4 Screening
Intermediary and beneficiary institutions should screen for sanctions compliance.

RECOMMENDATION 20: SUSPICIOUS TRANSACTION REPORTING (STR)

20.1 Reporting Obligation
Report to Financial Intelligence Unit (FIU) when:
- Transaction suspected to be proceeds of criminal activity
- Funds suspected to be related to terrorist financing

20.2 Threshold
No minimum threshold for STR reporting.
All suspicious transactions must be reported regardless of amount.

20.3 Attempted Transactions
Report attempted transactions even if not completed.

20.4 Tipping Off
Prohibition on disclosing STR filing to customer or third parties.

20.5 Safe Harbor
Legal protection for institutions and employees making STR in good faith.

RECOMMENDATION 23: ENHANCED DUE DILIGENCE (EDD)

23.1 High-Risk Scenarios
Apply EDD measures for higher risk situations:
- PEP relationships
- Correspondent banking
- Non-face-to-face business
- High-risk jurisdictions identified by FATF

23.2 EDD Measures
- Obtain additional information on customer and beneficial owner
- Obtain information on source of funds and wealth
- Obtain information on reasons for transactions
- Obtain approval of senior management
- Enhanced monitoring of business relationship
- First payout in correspondent relationship only after AML/CFT controls verified

RECOMMENDATION 24: TRANSPARENCY OF LEGAL PERSONS

24.1 Beneficial Ownership Information
Countries should ensure adequate, accurate, and timely information on beneficial ownership.

24.2 Central Register
Consider establishing central register of beneficial ownership.
Accessible to competent authorities.

INDIA-SPECIFIC IMPLEMENTATION (RBI/PMLA Guidelines)

A. CASH TRANSACTION REPORT (CTR)
Threshold: Transactions of ₹10 lakh or more in cash
- Single transaction
- Series of connected transactions
Reporting: Within 15 days of month-end to FIU-IND

B. SUSPICIOUS TRANSACTION REPORT (STR)
Reporting: Within 7 days of arriving at conclusion that transaction is suspicious
To: Financial Intelligence Unit - India (FIU-IND)

C. CROSS-BORDER WIRE TRANSFER REPORTING
Threshold: All cross-border wire transfers
Information required per FATF R.16
Monthly reporting to FIU-IND

D. POLITICALLY EXPOSED PERSONS (PEP)
Definition includes:
- Foreign PEPs
- Domestic PEPs (in positions of public function)
- Close relatives of PEPs
- Close associates of PEPs

Enhanced due diligence:
- Senior management approval
- Periodic review of relationship (at least annually)
- Enhanced monitoring of transactions

E. RISK CATEGORIZATION OF CUSTOMERS
Low Risk: Salaried employees, government departments, PSUs
Medium Risk: Small businesses, professionals, HNIs
High Risk: PEPs, NRIs from high-risk jurisdictions, casinos, dealers in precious metals

F. KNOW YOUR CUSTOMER (KYC) NORMS

F.1 Customer Identification
Officially Valid Documents (OVD):
- Passport
- PAN Card
- Aadhaar Card
- Voter ID Card
- Driving License

F.2 Periodic Updates
Low risk: Once in 10 years
Medium risk: Once in 8 years
High risk: Once in 2 years
Re-KYC process mandatory.

G. CUSTOMER ACCEPTANCE POLICY
Do not open account if:
- Unable to verify identity
- Identity documents appear fake
- Customer reluctant to provide information
- Background checks reveal adverse information

H. PENALTIES UNDER PMLA
- Failure to maintain records: Up to ₹10,000 per day
- Failure to furnish information: Up to ₹1 lakh
- Failure to file STR: Up to ₹1 lakh per day
- Tipping off: Imprisonment up to 7 years and fine

I. MONITORING AND REVIEW

I.1 Transaction Monitoring
Real-time monitoring for:
- Large cash transactions
- Structured transactions (smurfing)
- Rapid movement of funds
- Transactions with high-risk jurisdictions

I.2 Alerts and Investigations
Automated alert generation based on rules and scenarios.
Investigation by AML compliance officer.
Escalation to senior management and FIU-IND as needed.

Last Updated: March 15, 2024
Reference: FATF Recommendations 2024, RBI Master Direction on KYC
""",
    }
    
    print("Generating regulatory documents...")
    for filename, content in documents.items():
        filepath = REGULATORY_DOCS_DIR / filename
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"  ✓ Created: {filename}")
    
    print(f"\nTotal documents created: {len(documents)}")


def generate_report_submissions():
    """Generate sample bank report submissions for validation"""
    
    reports = [
        {
            "filename": "basel_iii_report_q3_2024.json",
            "content": {
                "report_type": "Basel_III_Capital_Adequacy",
                "bank_name": "DBS Bank India",
                "reporting_period": "Q3 2024",
                "reporting_date": "2024-09-30",
                "submission_date": "2024-10-15",
                "currency": "INR",
                "amounts_in": "Crores",
                "capital_components": {
                    "common_equity_tier1": {
                        "paid_up_capital": 5000,
                        "statutory_reserves": 12000,
                        "capital_reserves": 3000,
                        "general_reserves": 8000,
                        "balance_profit_loss": 2500,
                        "regulatory_deductions": {
                            "goodwill": 500,
                            "intangible_assets": 300,
                            "dta_future_profitability": 200,
                            "shortfall_provisions": 100,
                            "investments_own_shares": 50
                        },
                        "total_cet1": 29350
                    },
                    "additional_tier1": {
                        "perpetual_debt_instruments": 2000,
                        "perpetual_preference_shares": 500,
                        "total_at1": 2500
                    },
                    "tier2_capital": {
                        "general_provisions": 400,
                        "subordinated_debt": 3000,
                        "revaluation_reserves": 200,
                        "total_tier2": 3600
                    }
                },
                "risk_weighted_assets": {
                    "credit_risk_rwa": 320000,
                    "market_risk_rwa": 15000,
                    "operational_risk_rwa": 25000,
                    "total_rwa": 360000
                },
                "capital_ratios": {
                    "cet1_ratio": 8.15,  # 29350/360000
                    "tier1_ratio": 8.85,  # (29350+2500)/360000
                    "total_capital_ratio": 9.85  # (29350+2500+3600)/360000
                },
                "dsib_status": "Yes",
                "dsib_buffer_requirement": 0.2,
                "capital_conservation_buffer": 2.5,
                "comments": "Total capital ratio below RBI requirement when including CCB and D-SIB buffer"
            }
        },
        {
            "filename": "lcr_report_oct_2024.json",
            "content": {
                "report_type": "Liquidity_Coverage_Ratio",
                "bank_name": "DBS Bank Singapore",
                "reporting_period": "October 2024",
                "reporting_date": "2024-10-31",
                "submission_date": "2024-11-08",
                "currency": "SGD",
                "amounts_in": "Millions",
                "high_quality_liquid_assets": {
                    "level1_assets": {
                        "cash_reserves_mas": 5000,
                        "singapore_government_securities": 8000,
                        "us_treasury_securities": 3000,
                        "total_level1": 16000,
                        "haircut": 0,
                        "adjusted_value": 16000
                    },
                    "level2a_assets": {
                        "corporate_bonds_aa_plus": 2000,
                        "covered_bonds_aaa": 1500,
                        "total_level2a": 3500,
                        "haircut": 0.15,
                        "adjusted_value": 2975
                    },
                    "level2b_assets": {
                        "corporate_bonds_bbb": 1000,
                        "rmbs_aa": 500,
                        "equity_shares": 300,
                        "total_level2b": 1800,
                        "haircut": 0.50,
                        "adjusted_value": 900
                    },
                    "total_hqla": 19825
                },
                "cash_outflows_30_days": {
                    "retail_deposits": {
                        "stable_deposits": 50000,
                        "stable_outflow_rate": 0.05,
                        "stable_outflow": 2500,
                        "less_stable_deposits": 30000,
                        "less_stable_outflow_rate": 0.10,
                        "less_stable_outflow": 3000,
                        "total_retail_outflow": 5500
                    },
                    "wholesale_funding": {
                        "operational_deposits": 10000,
                        "operational_outflow_rate": 0.25,
                        "operational_outflow": 2500,
                        "non_operational_deposits": 20000,
                        "non_operational_outflow_rate": 0.40,
                        "non_operational_outflow": 8000,
                        "financial_institution_deposits": 5000,
                        "fi_outflow_rate": 1.00,
                        "fi_outflow": 5000,
                        "total_wholesale_outflow": 15500
                    },
                    "derivatives_collateral": 500,
                    "committed_credit_facilities": {
                        "retail_commitment": 2000,
                        "retail_drawdown_rate": 0.10,
                        "retail_drawdown": 200,
                        "corporate_commitment": 5000,
                        "corporate_drawdown_rate": 0.30,
                        "corporate_drawdown": 1500,
                        "total_commitment_drawdown": 1700
                    },
                    "other_contractual_outflows": 800,
                    "total_outflows": 24000
                },
                "cash_inflows_30_days": {
                    "retail_lending_maturing": 3000,
                    "retail_inflow_rate": 0.50,
                    "retail_inflow": 1500,
                    "wholesale_lending_maturing": 8000,
                    "wholesale_inflow_rate": 0.50,
                    "wholesale_inflow": 4000,
                    "total_inflows": 5500,
                    "inflow_cap": 0.75,
                    "capped_inflows": 4125
                },
                "net_cash_outflows": 19875,
                "lcr_ratio": 99.75,  # 19825/19875
                "lcr_by_currency": {
                    "SGD": 105.2,
                    "USD": 98.5,
                    "EUR": 102.1,
                    "JPY": 88.3
                },
                "comments": "Overall LCR marginally below 100% requirement. JPY LCR significantly below threshold."
            }
        },
        {
            "filename": "npa_provisioning_report_q2_2024.json",
            "content": {
                "report_type": "NPA_Classification_Provisioning",
                "bank_name": "DBS Bank India",
                "reporting_period": "Q2 2024",
                "reporting_date": "2024-06-30",
                "submission_date": "2024-07-18",
                "currency": "INR",
                "amounts_in": "Crores",
                "asset_classification": {
                    "standard_assets": {
                        "priority_sector_agriculture": {
                            "outstanding": 15000,
                            "provisioning_rate": 0.0025,
                            "provision_required": 37.5,
                            "provision_held": 37.5
                        },
                        "priority_sector_housing": {
                            "outstanding": 25000,
                            "provisioning_rate": 0.0025,
                            "provision_required": 62.5,
                            "provision_held": 62.5
                        },
                        "commercial_real_estate": {
                            "outstanding": 50000,
                            "provisioning_rate": 0.01,
                            "provision_required": 500,
                            "provision_held": 500
                        },
                        "housing_non_priority": {
                            "outstanding": 80000,
                            "provisioning_rate": 0.004,
                            "provision_required": 320,
                            "provision_held": 320
                        },
                        "consumer_credit": {
                            "outstanding": 30000,
                            "provisioning_rate": 0.004,
                            "provision_required": 120,
                            "provision_held": 120
                        },
                        "other_loans": {
                            "outstanding": 150000,
                            "provisioning_rate": 0.004,
                            "provision_required": 600,
                            "provision_held": 600
                        },
                        "total_standard": {
                            "outstanding": 350000,
                            "provision_required": 1640,
                            "provision_held": 1640
                        }
                    },
                    "sub_standard_assets": {
                        "secured_portion": {
                            "outstanding": 3000,
                            "provisioning_rate": 0.15,
                            "provision_required": 450,
                            "provision_held": 450
                        },
                        "unsecured_portion": {
                            "outstanding": 1000,
                            "provisioning_rate": 0.25,
                            "provision_required": 250,
                            "provision_held": 250
                        },
                        "total_substandard": {
                            "outstanding": 4000,
                            "provision_required": 700,
                            "provision_held": 700
                        }
                    },
                    "doubtful_assets": {
                        "doubtful_1_secured": {
                            "outstanding": 1500,
                            "provisioning_rate": 0.25,
                            "provision_required": 375,
                            "provision_held": 375
                        },
                        "doubtful_1_unsecured": {
                            "outstanding": 500,
                            "provisioning_rate": 1.00,
                            "provision_required": 500,
                            "provision_held": 500
                        },
                        "doubtful_2_secured": {
                            "outstanding": 800,
                            "provisioning_rate": 0.40,
                            "provision_required": 320,
                            "provision_held": 320
                        },
                        "doubtful_2_unsecured": {
                            "outstanding": 200,
                            "provisioning_rate": 1.00,
                            "provision_required": 200,
                            "provision_held": 200
                        },
                        "doubtful_3_secured": {
                            "outstanding": 600,
                            "provisioning_rate": 1.00,
                            "provision_required": 600,
                            "provision_held": 550
                        },
                        "doubtful_3_unsecured": {
                            "outstanding": 100,
                            "provisioning_rate": 1.00,
                            "provision_required": 100,
                            "provision_held": 100
                        },
                        "total_doubtful": {
                            "outstanding": 3700,
                            "provision_required": 2095,
                            "provision_held": 2045
                        }
                    },
                    "loss_assets": {
                        "outstanding": 300,
                        "provisioning_rate": 1.00,
                        "provision_required": 300,
                        "provision_held": 300
                    }
                },
                "npa_summary": {
                    "gross_npa": 8000,
                    "total_advances": 358000,
                    "gross_npa_ratio": 2.23,
                    "total_provisions": 4685,
                    "net_npa": 3315,
                    "net_npa_ratio": 0.93
                },
                "crilc_reporting": {
                    "accounts_reported": 156,
                    "total_exposure_reported": 125000,
                    "sma_0_accounts": 12,
                    "sma_1_accounts": 5,
                    "sma_2_accounts": 3
                },
                "comments": "Shortfall in provisioning for Doubtful-3 secured assets. Need additional ₹50 crores provision."
            }
        },
        {
            "filename": "aml_cft_compliance_report_sep_2024.json",
            "content": {
                "report_type": "AML_CFT_Compliance",
                "bank_name": "DBS Bank India",
                "reporting_period": "September 2024",
                "reporting_date": "2024-09-30",
                "submission_date": "2024-10-07",
                "currency": "INR",
                "cash_transaction_reporting": {
                    "total_ctr_filed": 1254,
                    "threshold_amount": 1000000,
                    "individual_transactions": 987,
                    "series_of_transactions": 267,
                    "filing_deadline_met": "Yes",
                    "late_filings": 0
                },
                "suspicious_transaction_reporting": {
                    "total_str_filed": 47,
                    "str_filing_deadline_days": 7,
                    "timely_filings": 45,
                    "delayed_filings": 2,
                    "delayed_filing_details": [
                        {
                            "str_reference": "STR/2024/0823",
                            "transaction_date": "2024-09-03",
                            "suspicion_identified_date": "2024-09-05",
                            "filing_date": "2024-09-15",
                            "delay_days": 3,
                            "reason": "Additional investigation required"
                        },
                        {
                            "str_reference": "STR/2024/0831",
                            "transaction_date": "2024-09-18",
                            "suspicion_identified_date": "2024-09-19",
                            "filing_date": "2024-09-28",
                            "delay_days": 2,
                            "reason": "System downtime"
                        }
                    ],
                    "suspicious_activity_categories": {
                        "structuring_smurfing": 15,
                        "unusual_transaction_patterns": 18,
                        "high_risk_jurisdiction": 8,
                        "pep_related": 4,
                        "trade_based_ml": 2
                    }
                },
                "customer_due_diligence": {
                    "new_customers_onboarded": 1850,
                    "cdd_completed": 1850,
                    "edd_customers": 127,
                    "pep_customers_identified": 23,
                    "pep_relationships": {
                        "new_pep_relationships": 5,
                        "senior_management_approval": "Yes",
                        "source_of_wealth_documented": "Yes",
                        "enhanced_monitoring_active": "Yes"
                    },
                    "kyc_periodic_updates": {
                        "high_risk_due": 45,
                        "high_risk_completed": 45,
                        "medium_risk_due": 320,
                        "medium_risk_completed": 310,
                        "low_risk_due": 150,
                        "low_risk_completed": 148
                    }
                },
                "wire_transfer_reporting": {
                    "cross_border_transfers": 8456,
                    "originator_info_complete": 8450,
                    "missing_originator_info": 6,
                    "beneficiary_info_complete": 8456,
                    "sanctions_screening_performed": "Yes",
                    "sanctions_hits": 23,
                    "false_positives": 21,
                    "true_positives": 2,
                    "blocked_transactions": 2
                },
                "transaction_monitoring": {
                    "total_alerts_generated": 3250,
                    "false_positives": 2987,
                    "false_positive_rate": 91.9,
                    "escalated_for_investigation": 263,
                    "resulted_in_str": 47,
                    "alert_categories": {
                        "large_cash_deposits": 850,
                        "rapid_movement_of_funds": 420,
                        "high_risk_jurisdiction": 380,
                        "velocity_checks": 920,
                        "unusual_activity": 680
                    }
                },
                "training_and_awareness": {
                    "aml_training_sessions": 12,
                    "employees_trained": 2450,
                    "training_completion_rate": 98.5,
                    "mandatory_certification": "Yes"
                },
                "regulatory_interactions": {
                    "rbi_inspections": 0,
                    "fiu_queries": 3,
                    "fiu_query_response_time_days": [5, 4, 6],
                    "regulatory_notices": 0
                },
                "compliance_gaps": [
                    "2 STR filings delayed beyond 7-day deadline",
                    "6 wire transfers with incomplete originator information",
                    "10 pending KYC updates for medium-risk customers",
                    "High false positive rate (91.9%) in transaction monitoring - need system tuning"
                ],
                "remediation_actions": [
                    "Implement automated escalation for approaching STR deadlines",
                    "Enhance wire transfer validation at source",
                    "Dedicate resources for pending KYC updates (completion target: Oct 15)",
                    "Engage vendor for transaction monitoring system optimization"
                ]
            }
        },
        {
            "filename": "forex_position_report_nov_2024.json",
            "content": {
                "report_type": "Forex_Open_Position",
                "bank_name": "DBS Bank India",
                "reporting_period": "November 2024",
                "reporting_date": "2024-11-15",
                "submission_date": "2024-11-18",
                "currency": "INR",
                "amounts_in": "Crores",
                "capital_funds": 35450,
                "net_open_position_limit": 2.0,
                "nop_limit_amount": 709,
                "currency_positions": {
                    "USD": {
                        "spot_assets": 15000,
                        "spot_liabilities": 14200,
                        "forward_purchases": 3000,
                        "forward_sales": 3500,
                        "net_position": 300,
                        "as_percent_of_capital": 0.85
                    },
                    "EUR": {
                        "spot_assets": 5000,
                        "spot_liabilities": 4800,
                        "forward_purchases": 1200,
                        "forward_sales": 1100,
                        "net_position": 300,
                        "as_percent_of_capital": 0.85
                    },
                    "GBP": {
                        "spot_assets": 2000,
                        "spot_liabilities": 1950,
                        "forward_purchases": 500,
                        "forward_sales": 450,
                        "net_position": 100,
                        "as_percent_of_capital": 0.28
                    },
                    "JPY": {
                        "spot_assets": 3000,
                        "spot_liabilities": 3100,
                        "forward_purchases": 800,
                        "forward_sales": 750,
                        "net_position": -50,
                        "as_percent_of_capital": 0.14
                    },
                    "SGD": {
                        "spot_assets": 1500,
                        "spot_liabilities": 1400,
                        "forward_purchases": 300,
                        "forward_sales": 280,
                        "net_position": 120,
                        "as_percent_of_capital": 0.34
                    }
                },
                "aggregate_position": {
                    "sum_of_absolute_positions": 870,
                    "as_percent_of_capital": 2.45,
                    "aggregate_gap_limit": 20.0
                },
                "single_customer_exposure": {
                    "largest_forex_exposure": {
                        "customer_id": "CORP_12345",
                        "customer_name": "ABC Manufacturing Ltd",
                        "exposure_amount": 450,
                        "as_percent_of_capital": 1.27,
                        "limit": 1.5,
                        "status": "Within Limit"
                    }
                },
                "derivative_exposures": {
                    "currency_swaps_notional": 8000,
                    "currency_options_notional": 2000,
                    "total_derivative_notional": 10000,
                    "mark_to_market_value": 85,
                    "potential_future_exposure": 240
                },
                "intraday_positions": {
                    "max_intraday_nop_usd": 420,
                    "max_intraday_nop_eur": 380,
                    "max_intraday_aggregate": 950,
                    "intraday_limit_breaches": 0
                },
                "comments": "Aggregate open position (2.45%) exceeds 2% limit. Need to reduce positions immediately."
            }
        }
    ]
    
    print("\nGenerating report submissions...")
    for report in reports:
        filepath = REPORT_SUBMISSIONS_DIR / report["filename"]
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report["content"], f, indent=2)
        print(f"  ✓ Created: {report['filename']}")
    
    print(f"\nTotal reports created: {len(reports)}")


def main():
    """Main execution function"""
    print("=" * 60)
    print("Regulatory RAG System - Data Generation")
    print("=" * 60)
    
    # Generate regulatory documents
    generate_regulatory_documents()
    
    # Generate report submissions
    generate_report_submissions()
    
    print("\n" + "=" * 60)
    print("Data generation complete!")
    print("=" * 60)
    print(f"\nRegulatory documents: {REGULATORY_DOCS_DIR}")
    print(f"Report submissions: {REPORT_SUBMISSIONS_DIR}")
    print("\nNext steps:")
    print("1. Run: python scripts/index_documents.py")
    print("2. Run: python scripts/validate_report.py --validate-all")


if __name__ == "__main__":
    main()
