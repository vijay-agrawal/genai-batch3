#!/usr/bin/env python3
"""
Index regulatory documents into Vertex AI RAG Engine
"""
import sys
from pathlib import Path
import argparse
import logging

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import settings
from src.document_processor import DocumentProcessor
from src.rag_engine import VertexRAGEngine
from google.cloud import storage

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def index_documents(incremental: bool = False):
    """
    Index all regulatory documents from GCS into RAG corpus
    
    Args:
        incremental: If True, only index new documents
    """
    print("=" * 80)
    print("VERTEX AI RAG ENGINE - DOCUMENT INDEXING")
    print("=" * 80)
    
    # Validate configuration
    print(f"\n📋 Configuration:")
    print(f"  Project ID: {settings.GOOGLE_CLOUD_PROJECT}")
    print(f"  Location: {settings.VERTEX_AI_LOCATION}")
    print(f"  Corpus Name: {settings.RAG_CORPUS_DISPLAY_NAME}")
    print(f"  GCS Bucket: gs://{settings.GCS_BUCKET_NAME}")
    print(f"  GCS Folder: {settings.GCS_FOLDER_NAME}")
    
    if settings.GCS_BUCKET_NAME == "your-bucket-name":
        print("\n❌ ERROR: GCS_BUCKET_NAME not configured!")
        print("\nPlease:")
        print("1. Create a GCS bucket (see GCS_SETUP.md)")
        print("2. Upload documents: python scripts/upload_to_gcs.py")
        print("3. Set GCS_BUCKET_NAME in .env or environment")
        sys.exit(1)
    
    # Initialize RAG engine
    rag_engine = VertexRAGEngine(
        project_id=settings.GOOGLE_CLOUD_PROJECT,
        location=settings.VERTEX_AI_LOCATION,
        corpus_display_name=settings.RAG_CORPUS_DISPLAY_NAME,
        embedding_model=settings.EMBEDDING_MODEL,
        bucket_name=settings.GCS_BUCKET_NAME
    )
    
    # Create or get corpus
    corpus_name = rag_engine.create_corpus(
        description=settings.RAG_CORPUS_DESCRIPTION
    )
    
    # Get GCS URIs
    print("\n" + "=" * 80)
    print("STEP 3: COLLECT GCS URIS")
    print("=" * 80)
    
    print(f"\n🔍 Listing files in gs://{settings.GCS_BUCKET_NAME}/{settings.GCS_FOLDER_NAME}/")
    
    try:
        storage_client = storage.Client(project=settings.GOOGLE_CLOUD_PROJECT)
        bucket = storage_client.bucket(settings.GCS_BUCKET_NAME)
        
        blobs = list(bucket.list_blobs(prefix=f"{settings.GCS_FOLDER_NAME}/"))
        
        # Filter for .txt files only
        gcs_uris = []
        for blob in blobs:
            if blob.name.endswith('.txt'):
                gcs_uri = f"gs://{settings.GCS_BUCKET_NAME}/{blob.name}"
                gcs_uris.append(gcs_uri)
                print(f"  📄 {blob.name} → {gcs_uri}")
        
        print(f"\n✓ Found {len(gcs_uris)} documents to index")
        
        if not gcs_uris:
            print("\n❌ ERROR: No .txt files found in GCS bucket!")
            print("\nPlease upload documents first:")
            print("  python scripts/upload_to_gcs.py")
            sys.exit(1)
        
    except Exception as e:
        print(f"\n❌ ERROR: Failed to access GCS bucket: {e}")
        print("\nMake sure:")
        print("1. Bucket exists: gcloud storage buckets describe gs://{settings.GCS_BUCKET_NAME}")
        print("2. You have access: gcloud storage ls gs://{settings.GCS_BUCKET_NAME}/")
        print("3. Documents are uploaded: python scripts/upload_to_gcs.py")
        sys.exit(1)
    
    # Import files into RAG corpus
    stats = rag_engine.import_files_from_gcs(
        gcs_uris=gcs_uris,
        chunk_size=settings.CHUNK_SIZE,
        chunk_overlap=settings.CHUNK_OVERLAP
    )
    
    print("\n" + "=" * 80)
    print("INDEXING COMPLETE")
    print("=" * 80)
    print(f"\n✅ Successfully indexed {stats['imported_files']} documents")
    print(f"📊 RAG Corpus: {corpus_name}")
    print(f"\n💡 Next steps:")
    print(f"  python scripts/validate_report.py --validate-all")
    print("=" * 80)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='Index regulatory documents into Vertex AI RAG Engine'
    )
    parser.add_argument(
        '--incremental',
        action='store_true',
        help='Only index new documents (not yet implemented)'
    )
    
    args = parser.parse_args()
    
    try:
        index_documents(incremental=args.incremental)
    except Exception as e:
        logger.error(f"Indexing failed: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
