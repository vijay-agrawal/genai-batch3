#!/usr/bin/env python3
"""
Upload regulatory documents to Google Cloud Storage
Required before indexing into Vertex AI RAG Engine
"""
import sys
from pathlib import Path
import logging
from google.cloud import storage

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import settings

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def upload_documents_to_gcs():
    """Upload all regulatory documents to GCS bucket"""
    
    print("=" * 80)
    print("UPLOADING REGULATORY DOCUMENTS TO GOOGLE CLOUD STORAGE")
    print("=" * 80)
    
    # Validate configuration
    if settings.GCS_BUCKET_NAME == "your-bucket-name":
        print("\n❌ ERROR: GCS_BUCKET_NAME not configured!")
        print("\nPlease set GCS_BUCKET_NAME in one of these ways:")
        print("1. Environment variable: export GCS_BUCKET_NAME='your-bucket-name'")
        print("2. Edit config/settings.py")
        print("3. Edit .env file")
        print("\nSee GCS_SETUP.md for detailed instructions.")
        sys.exit(1)
    
    print(f"\n📋 Configuration:")
    print(f"  Project ID: {settings.GOOGLE_CLOUD_PROJECT}")
    print(f"  GCS Bucket: gs://{settings.GCS_BUCKET_NAME}")
    print(f"  GCS Folder: {settings.GCS_FOLDER_NAME}")
    print(f"  Local Directory: {settings.REGULATORY_DOCS_DIR}")
    
    # Check if documents exist locally
    doc_files = list(settings.REGULATORY_DOCS_DIR.glob("*.txt"))
    
    if not doc_files:
        print(f"\n❌ ERROR: No documents found in {settings.REGULATORY_DOCS_DIR}")
        print("Please run: python scripts/generate_data.py")
        sys.exit(1)
    
    print(f"\n📄 Found {len(doc_files)} documents to upload:")
    for doc_file in doc_files:
        print(f"  - {doc_file.name} ({doc_file.stat().st_size:,} bytes)")
    
    # Initialize GCS client
    print("\n🔐 Initializing Google Cloud Storage client...")
    try:
        storage_client = storage.Client(project=settings.GOOGLE_CLOUD_PROJECT)
        logger.info("✓ GCS client initialized")
    except Exception as e:
        print(f"\n❌ ERROR: Failed to initialize GCS client: {e}")
        print("\nMake sure you've run: gcloud auth application-default login")
        sys.exit(1)
    
    # Get bucket
    print(f"\n📦 Accessing bucket: gs://{settings.GCS_BUCKET_NAME}")
    try:
        bucket = storage_client.bucket(settings.GCS_BUCKET_NAME)
        
        # Check if bucket exists
        if not bucket.exists():
            print(f"\n❌ ERROR: Bucket gs://{settings.GCS_BUCKET_NAME} does not exist!")
            print("\nCreate the bucket with:")
            print(f"  gcloud storage buckets create gs://{settings.GCS_BUCKET_NAME} \\")
            print(f"    --location={settings.VERTEX_AI_LOCATION} \\")
            print("    --uniform-bucket-level-access")
            print("\nSee GCS_SETUP.md for detailed instructions.")
            sys.exit(1)
        
        logger.info("✓ Bucket found")
    except Exception as e:
        print(f"\n❌ ERROR: Failed to access bucket: {e}")
        sys.exit(1)
    
    # Upload files
    print(f"\n⬆️  Uploading documents to GCS...")
    print("=" * 80)
    
    uploaded_files = []
    failed_files = []
    total_bytes = 0
    
    for doc_file in doc_files:
        blob_name = f"{settings.GCS_FOLDER_NAME}/{doc_file.name}"
        blob = bucket.blob(blob_name)
        
        try:
            print(f"\n📤 Uploading: {doc_file.name}")
            print(f"  Source: {doc_file}")
            print(f"  Destination: gs://{settings.GCS_BUCKET_NAME}/{blob_name}")
            
            # Upload with content type
            blob.upload_from_filename(
                str(doc_file),
                content_type='text/plain'
            )
            
            file_size = doc_file.stat().st_size
            total_bytes += file_size
            
            print(f"  ✅ Uploaded successfully ({file_size:,} bytes)")
            print(f"  GCS URI: gs://{settings.GCS_BUCKET_NAME}/{blob_name}")
            
            uploaded_files.append({
                'filename': doc_file.name,
                'gcs_uri': f"gs://{settings.GCS_BUCKET_NAME}/{blob_name}",
                'size': file_size
            })
            
        except Exception as e:
            print(f"  ❌ Failed to upload: {e}")
            failed_files.append(doc_file.name)
    
    # Summary
    print("\n" + "=" * 80)
    print("UPLOAD SUMMARY")
    print("=" * 80)
    
    print(f"\n✅ Successfully uploaded: {len(uploaded_files)}/{len(doc_files)} files")
    print(f"📊 Total data uploaded: {total_bytes:,} bytes ({total_bytes/1024/1024:.2f} MB)")
    
    if uploaded_files:
        print(f"\n📋 Uploaded files:")
        for file_info in uploaded_files:
            print(f"  ✓ {file_info['filename']}")
            print(f"    URI: {file_info['gcs_uri']}")
            print(f"    Size: {file_info['size']:,} bytes")
    
    if failed_files:
        print(f"\n❌ Failed uploads: {len(failed_files)}")
        for filename in failed_files:
            print(f"  ✗ {filename}")
    
    # Verification
    print("\n" + "=" * 80)
    print("VERIFICATION")
    print("=" * 80)
    
    print(f"\n🔍 Listing files in gs://{settings.GCS_BUCKET_NAME}/{settings.GCS_FOLDER_NAME}/")
    
    blobs = list(bucket.list_blobs(prefix=f"{settings.GCS_FOLDER_NAME}/"))
    print(f"  Found {len(blobs)} files in GCS:")
    
    for blob in blobs:
        print(f"  📄 {blob.name} ({blob.size:,} bytes)")
    
    # Next steps
    print("\n" + "=" * 80)
    print("NEXT STEPS")
    print("=" * 80)
    
    print("\n✅ GCS upload complete!")
    print("\nNow you can index the documents into Vertex AI RAG Engine:")
    print("  python scripts/index_documents.py")
    print("\nThis will:")
    print("  1. Create RAG corpus in Vertex AI")
    print("  2. Import files from GCS")
    print("  3. Chunk and embed documents")
    print("  4. Build vector index for retrieval")
    
    # Save GCS URIs for reference
    gcs_uris_file = settings.OUTPUT_DIR / "gcs_uris.txt"
    with open(gcs_uris_file, 'w') as f:
        for file_info in uploaded_files:
            f.write(f"{file_info['gcs_uri']}\n")
    
    print(f"\n📝 GCS URIs saved to: {gcs_uris_file}")
    
    return len(uploaded_files) == len(doc_files)


def main():
    """Main entry point"""
    try:
        success = upload_documents_to_gcs()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n⚠️  Upload cancelled by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Upload failed: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
