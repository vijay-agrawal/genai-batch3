# Technical Deep Dive - Regulatory RAG System

## Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Chunking Strategy Details](#chunking-strategy-details)
3. [Metadata Schema](#metadata-schema)
4. [RAG Retrieval Process](#rag-retrieval-process)
5. [Validation Logic](#validation-logic)
6. [Performance Optimization](#performance-optimization)

## Architecture Overview

### System Components

```
┌─────────────────────────────────────────────────────────────────┐
│                     Regulatory RAG System                        │
└─────────────────────────────────────────────────────────────────┘

┌───────────────────┐
│  Input Layer      │
├───────────────────┤
│ • Regulatory Docs │ (PDF, DOCX, TXT)
│ • Bank Reports    │ (JSON, Excel)
└────────┬──────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Document Processing Layer              │
├─────────────────────────────────────────┤
│  DocumentProcessor                      │
│  • Structural Chunking                  │
│  • Semantic Chunking                    │
│  • Metadata Extraction                  │
│  • Overlap Management                   │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────┐
│  Vertex AI RAG Engine Layer                         │
├─────────────────────────────────────────────────────┤
│  Corpus Management                                  │
│  ┌───────────────────────────────────────┐        │
│  │  RAG Corpus                            │        │
│  │  • 300+ indexed chunks                 │        │
│  │  • Metadata filters                    │        │
│  │  • Vector embeddings (768-dim)         │        │
│  └───────────────────────────────────────┘        │
│                                                     │
│  Embedding Model: text-embedding-004               │
│  • Semantic search                                 │
│  • Cross-lingual support                           │
│  • Financial domain understanding                  │
└────────┬────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────┐
│  Retrieval & Generation Layer                       │
├─────────────────────────────────────────────────────┤
│  RAG Retrieval                                      │
│  • Query: "What is RBI CET1 requirement?"          │
│  • Metadata Filter: {regulator: RBI, category...}  │
│  • Top-K: 7 chunks                                  │
│  • Similarity Threshold: 0.7                        │
│  ↓                                                  │
│  Retrieved Context (3000-4000 tokens)              │
│  ↓                                                  │
│  Gemini Flash 2.5                                   │
│  • Temperature: 0.1 (deterministic)                 │
│  • Max tokens: 2048                                 │
│  • Chain-of-thought reasoning                       │
└────────┬────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│  Validation Layer                       │
├─────────────────────────────────────────┤
│  RegulatoryValidator                    │
│  • Multi-check validation               │
│  • Gap analysis                         │
│  • Remediation suggestions              │
│  • Status determination                 │
└────────┬────────────────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Output Layer       │
├─────────────────────┤
│ • Validation Report │
│ • Status: PASS/FAIL │
│ • Detailed findings │
│ • Audit trail       │
└─────────────────────┘
```

## Chunking Strategy Details

### Why Hybrid Chunking?

Regulatory documents have unique characteristics:
- **Hierarchical structure**: Sections, subsections, clauses
- **Dense legal language**: Every word matters
- **Cross-references**: "As per Section 2.4"
- **Precise requirements**: "≥ 5.5%" vs "at least 5.5%"

### Chunking Algorithm

```python
def chunk_document(content):
    """
    Hybrid structural + semantic chunking
    """
    # Step 1: Structural Split (preserve sections)
    sections = split_by_headers(content)
    # Pattern: SECTION X, PART Y, RECOMMENDATION Z
    
    # Step 2: Semantic Chunking within sections
    for section in sections:
        chunks = []
        current_chunk = []
        current_length = 0
        
        sentences = split_sentences(section)
        
        for sentence in sentences:
            # Add sentence to chunk
            current_chunk.append(sentence)
            current_length += len(sentence)
            
            # Check if chunk size reached
            if current_length >= TARGET_SIZE:
                # Save chunk
                chunks.append(' '.join(current_chunk))
                
                # Create overlap for next chunk
                overlap = get_last_n_tokens(current_chunk, OVERLAP_SIZE)
                current_chunk = overlap
                current_length = sum(len(s) for s in overlap)
        
        # Save final chunk
        if current_chunk:
            chunks.append(' '.join(current_chunk))
    
    return chunks
```

### Example: Chunking in Action

**Original Document:**
```
SECTION 2: MINIMUM CAPITAL REQUIREMENTS

2.1 Common Equity Tier 1 (CET1) Capital
Banks must maintain Common Equity Tier 1 capital at a minimum of 5.5% 
of Risk Weighted Assets (RWA). CET1 capital comprises of paid-up equity 
capital, statutory reserves, and other disclosed reserves.

2.2 Tier 1 Capital
Minimum Tier 1 capital ratio shall be 7.0% of RWA. Tier 1 capital = 
CET1 + Additional Tier 1 capital instruments.
```

**After Chunking:**

**Chunk 1:**
```
Content: "SECTION 2: MINIMUM CAPITAL REQUIREMENTS. 
2.1 Common Equity Tier 1 (CET1) Capital. Banks must maintain 
Common Equity Tier 1 capital at a minimum of 5.5% of Risk 
Weighted Assets (RWA). CET1 capital comprises of paid-up 
equity capital, statutory reserves, and other disclosed reserves."

Metadata: {
  "section": "2.1",
  "regulator": "RBI",
  "category": "capital_adequacy",
  "effective_date": "April 1, 2024"
}

Token count: ~650
```

**Chunk 2:**
```
Content: "CET1 capital comprises of paid-up equity capital, 
statutory reserves, and other disclosed reserves. 
2.2 Tier 1 Capital. Minimum Tier 1 capital ratio shall be 
7.0% of RWA. Tier 1 capital = CET1 + Additional Tier 1 
capital instruments."

Metadata: {
  "section": "2.2",
  "regulator": "RBI",
  "category": "capital_adequacy",
  "effective_date": "April 1, 2024"
}

Token count: ~550
Overlap: 100 tokens from Chunk 1
```

### Chunk Size Optimization

| Chunk Size | Pros | Cons | Use Case |
|------------|------|------|----------|
| 200-400 tokens | Precise retrieval | Loss of context | Definitions, specific values |
| 500-800 tokens | **Optimal balance** | Medium granularity | **Regulatory clauses** |
| 1000+ tokens | Full context | Noise in retrieval | Narrative sections |

For regulatory documents: **500-800 tokens** is optimal because:
- Captures complete regulatory clause
- Includes context (section header + body)
- Fits within typical embedding model limits
- Allows 5-7 chunks in LLM context window

## Metadata Schema

### Document-Level Metadata

```python
{
  "source_file": "RBI_Capital_Adequacy_Guidelines_2024.txt",
  "regulator": "RBI",
  "category": "capital_adequacy",
  "report_type": "Basel_III",
  "effective_date": "April 1, 2024",
  "document_type": "regulatory_guideline",
  "version": "2024",
  "last_updated": "January 15, 2024"
}
```

### Chunk-Level Metadata

```python
{
  "source_file": "RBI_Capital_Adequacy_Guidelines_2024.txt",
  "regulator": "RBI",
  "category": "capital_adequacy",
  "section": "2.4",
  "section_title": "Capital Conservation Buffer",
  "chunk_index": 15,
  "total_chunks": 47,
  "token_count": 650,
  "effective_date": "April 1, 2024"
}
```

### Metadata Filtering Examples

**Example 1: Capital Adequacy for RBI**
```python
filter = {
  "regulator": "RBI",
  "category": "capital_adequacy",
  "effective_date": ">= 2024-01-01"
}
# Retrieves: Only RBI capital adequacy rules effective after 2024
```

**Example 2: AML across multiple regulators**
```python
filter = {
  "category": "aml_cft",
  "regulator": ["RBI", "FATF", "MAS"]
}
# Retrieves: AML rules from RBI, FATF, and MAS
```

**Example 3: Specific section**
```python
filter = {
  "regulator": "RBI",
  "section": "2.4"
}
# Retrieves: Only Section 2.4 from RBI documents
```

## RAG Retrieval Process

### Step-by-Step Retrieval

```
1. User Query Generation
   ↓
   Query: "What is the minimum CET1 ratio for banks in India?"
   
2. Metadata Filter Application
   ↓
   Filter: {regulator: "RBI", category: "capital_adequacy"}
   
3. Embedding Generation
   ↓
   Query Embedding: [0.23, -0.45, 0.67, ..., 0.12]  (768-dim)
   
4. Vector Similarity Search
   ↓
   Cosine Similarity with all chunks in corpus
   Filter by metadata
   
5. Top-K Selection
   ↓
   Rank by similarity score
   Select top 7 chunks (similarity > 0.7)
   
6. Context Assembly
   ↓
   Concatenate retrieved chunks
   Total context: 3000-4000 tokens
   
7. LLM Generation
   ↓
   Input: Context + Query
   Model: Gemini Flash 2.5
   Temperature: 0.1 (low for consistency)
   
8. Response
   ↓
   Structured validation result
```

### Retrieval Optimization Techniques

**1. Semantic Search Quality**
- Use domain-specific embeddings when available
- Fine-tune similarity threshold (0.7 works well for regulatory text)
- Implement re-ranking for better relevance

**2. Metadata Filtering**
- Apply filters BEFORE vector search (reduces search space)
- Use hierarchical metadata (regulator → category → section)
- Cache frequently accessed filters

**3. Context Window Management**
- Prioritize most relevant chunks (top 5-7)
- Remove redundant information
- Truncate if exceeding LLM context limit

## Validation Logic

### Multi-Step Validation Process

```
Report Data → Extract Values → Generate Query → RAG Retrieval
                                                      ↓
                                              Retrieve Regulation
                                                      ↓
                                              LLM Reasoning
                                                      ↓
                                           Compare & Validate
                                                      ↓
                                         Status: PASS/FAIL/WARNING
```

### Validation Check Structure

```python
{
  "check_name": "CET1 Ratio Requirement",
  "value": 8.15,  # Reported value
  "status": "PASS",  # or "FAIL" or "WARNING"
  "message": "CET1 ratio of 8.15% exceeds minimum requirement of 5.5%",
  "retrieved_regulation": {
    "source": "RBI Master Circular DBR.No.BP.BC.1/21.06.201/2023-24",
    "section": "2.1",
    "requirement": "minimum 5.5%",
    "effective_date": "April 1, 2024"
  },
  "gap_analysis": {
    "required": 5.5,
    "actual": 8.15,
    "gap": 2.65,  # Positive = compliant
    "severity": "COMPLIANT"
  },
  "remediation": null  # Only if FAIL
}
```

### Prompt Engineering for Validation

**Chain-of-Thought Prompts:**

```
Given the retrieved regulation:
[CONTEXT FROM RAG]

And the bank's reported value:
- CET1 Ratio: 8.15%

Please follow these steps:
1. Extract the minimum CET1 ratio requirement from the regulation
2. Compare 8.15% against this requirement
3. Determine if compliant (actual >= required)
4. If non-compliant, calculate the gap
5. Provide remediation suggestions if needed

Response format:
- Requirement: [X]%
- Actual: [Y]%
- Status: PASS/FAIL
- Gap: [Z] percentage points
- Remediation: [if applicable]
```

## Performance Optimization

### Latency Optimization

| Component | Latency | Optimization |
|-----------|---------|--------------|
| Document Chunking | 50-100ms | Cache chunks |
| Embedding Generation | 200-300ms | Batch processing |
| Vector Search | 100-200ms | Index optimization |
| LLM Generation | 1-3s | Use Flash model |
| **Total per validation** | **2-5s** | Parallel processing |

### Cost Optimization

**Embedding Costs:**
- Embeddings generated once during indexing
- Cached for repeated use
- Batch processing reduces API calls

**LLM Costs:**
- Use Gemini Flash (cheaper than Pro)
- Low temperature (faster, cheaper)
- Structured output (reduces token usage)

**Estimated Monthly Cost (100 reports):**
```
Embeddings: 300 chunks × $0.000025 = $0.0075
RAG Queries: 100 reports × 5 checks × $0.01 = $5.00
LLM Generation: 100 reports × 5 checks × $0.02 = $10.00
Total: ~$15/month
```

### Scalability Considerations

**Current Capacity:**
- 300 chunks → 100MB storage
- 100 reports/day → ~2 minutes processing time
- Concurrent validations: 5-10

**Scaling to 10,000 reports/month:**
1. **Horizontal Scaling:** Deploy on Cloud Run with auto-scaling
2. **Batch Processing:** Queue reports, process in batches
3. **Caching:** Cache frequent queries and regulations
4. **CDN:** Distribute static regulatory docs

**Infrastructure:**
```
Cloud Run (Validation Service)
    ↓
Cloud Tasks (Queue)
    ↓
Vertex AI RAG Engine
    ↓
Cloud Storage (Document Cache)
    ↓
BigQuery (Audit Logs)
```

## Advanced Features (Future Roadmap)

### 1. Multi-Modal Support
- Process regulatory PDFs with tables/charts
- Extract data from scanned documents (OCR)
- Validate reports with embedded images

### 2. Real-Time Monitoring
- Connect to core banking systems
- Stream transactions for real-time validation
- Alert on threshold breaches

### 3. Explainable AI
- Visualize chunk relevance scores
- Show regulation → validation mapping
- Generate audit-ready explanations

### 4. Continuous Learning
- Fine-tune embeddings on banking corpus
- Update regulations automatically
- Learn from human feedback

---

**End of Technical Deep Dive**
