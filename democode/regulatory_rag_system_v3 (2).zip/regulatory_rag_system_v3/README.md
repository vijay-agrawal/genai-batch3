# Regulatory Report Validation System using Google Vertex AI RAG Engine

## Overview
This system implements a Retrieval-Augmented Generation (RAG) solution for automated validation of banking regulatory reports against RBI (Reserve Bank of India), MAS (Monetary Authority of Singapore), and other global regulatory requirements. Built specifically for DBS Bank's compliance and regulatory reporting needs.

## Business Context
Banking institutions must submit periodic regulatory reports (e.g., LFAR - Long Form Audit Report, CRILC - Central Repository of Information on Large Credits, Basel III Capital Adequacy, Liquidity Coverage Ratio). This system automates the validation of:

- **Capital Adequacy Reports**: Tier 1/Tier 2 capital calculations, RWA computations
- **Liquidity Reports**: LCR, NSFR calculations and thresholds
- **Credit Risk Reports**: NPA classifications, provisioning requirements
- **AML/CFT Reports**: Suspicious transaction reporting compliance
- **LFAR Submissions**: Auditor certification requirements
- **Forex Position Reports**: Open position limits, exposure calculations

## Architecture

```
┌─────────────────┐
│  Regulatory     │
│  Documents      │
│  (PDF/DOCX)     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐      ┌──────────────────┐
│  Document       │      │  Report Data     │
│  Processor      │      │  (GL, Credit,    │
│  & Chunker      │      │   Liquidity)     │
└────────┬────────┘      └────────┬─────────┘
         │                        │
         ▼                        ▼
┌─────────────────────────────────────────┐
│     Vertex AI RAG Engine                │
│  ┌─────────────────────────────────┐   │
│  │  Vector Store (Embeddings)      │   │
│  │  - Semantic search              │   │
│  │  - Metadata filtering           │   │
│  └─────────────────────────────────┘   │
└──────────────────┬──────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────┐
│  Gemini Flash 2.5 (via Vertex AI)       │
│  - Context-aware validation             │
│  - Multi-step reasoning                 │
│  - Compliance gap identification        │
└──────────────────┬──────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────┐
│  Validation Report Output               │
│  - Pass/Fail status                     │
│  - Specific violations                  │
│  - Remediation suggestions              │
└─────────────────────────────────────────┘
```

## Technical Components

### 1. Document Chunking Strategy

**Hybrid Chunking Approach:**
- **Structural Chunking**: Preserves regulatory sections (e.g., "Section 3.2: Capital Adequacy Requirements")
- **Semantic Chunking**: Maintains context within regulatory clauses
- **Metadata Enrichment**: Each chunk tagged with:
  - `regulator`: RBI, MAS, BIS, FATF, etc.
  - `category`: capital_adequacy, liquidity, credit_risk, aml_cft, forex
  - `effective_date`: Regulation effective date
  - `report_type`: LFAR, CRILC, Basel_III, LCR, etc.
  - `section`: Specific section reference

**Chunk Parameters:**
- **Size**: 500-800 tokens (optimal for regulatory text)
- **Overlap**: 100 tokens (ensures continuity across chunks)
- **Delimiter Priority**: Section headers > Paragraphs > Sentences

### 2. Embedding Model
- **Model**: `text-embedding-004` (Google's latest)
- **Dimension**: 768
- **Advantages**: 
  - Superior semantic understanding of financial terminology
  - Multi-lingual support (important for global regulations)
  - Efficient for large document corpus

### 3. Vertex AI RAG Engine Configuration

**RAG Corpus Setup:**
```
- Corpus ID: regulatory_knowledge_base
- Distance Measure: COSINE similarity
- Metadata Indexing: Enabled for fast filtering
- Max Chunks per Query: 10
```

**Retrieval Strategy:**
- **Hybrid Search**: Combines semantic similarity + metadata filtering
- **Re-ranking**: LLM-based re-ranking for regulatory relevance
- **Context Window**: Top 5-7 most relevant chunks (3000-4000 tokens)

### 4. Validation Checks Implemented

#### Capital Adequacy (Basel III / RBI Guidelines)
- ✓ Minimum CET1 ratio ≥ 5.5%
- ✓ Tier 1 capital ratio ≥ 7%
- ✓ Total capital ratio ≥ 9% (RBI requirement, higher than Basel's 8%)
- ✓ Correct classification of capital instruments
- ✓ Regulatory deductions properly applied
- ✓ Risk-weighted assets calculation accuracy

#### Liquidity Coverage Ratio (LCR)
- ✓ LCR ≥ 100% (minimum regulatory requirement)
- ✓ High-quality liquid assets (HQLA) calculation
- ✓ Stressed cash outflow assumptions (30-day scenario)
- ✓ Inflow caps applied correctly
- ✓ Asset categorization (Level 1, 2A, 2B)

#### Credit Risk & NPA Classification
- ✓ 90-day past due classification for NPA
- ✓ Sub-standard, Doubtful, Loss asset categories
- ✓ Provisioning rates: 
  - Sub-standard: 15% (secured), 25% (unsecured)
  - Doubtful 1: 25%, Doubtful 2: 40%, Doubtful 3: 100%
  - Loss: 100%
- ✓ Standard asset provisioning (0.25% - 2% based on category)
- ✓ CRILC reporting for exposures ≥ ₹5 crore

#### AML/CFT Compliance
- ✓ Suspicious Transaction Report (STR) filing within 7 days
- ✓ Cash Transaction Report (CTR) for transactions ≥ ₹10 lakh
- ✓ PEP (Politically Exposed Person) enhanced due diligence
- ✓ Cross-border transaction reporting
- ✓ Wire transfer information completeness (FATF Travel Rule)

#### Forex and Derivative Exposures
- ✓ Net Open Position limit compliance (2% of capital funds)
- ✓ Aggregate Gap limit compliance
- ✓ Single customer exposure limits
- ✓ Mark-to-market valuation methodology

### 5. Prompt Engineering Techniques

**Chain-of-Thought Validation:**
```
1. Extract reported value from submission
2. Retrieve relevant regulatory requirement
3. Compare against threshold/formula
4. Identify discrepancies
5. Assess severity (Critical/Major/Minor)
6. Provide remediation guidance
```

**Few-Shot Learning Examples:**
- Pre-loaded with 10+ validated report examples
- Demonstrates correct interpretation of regulatory nuances
- Handles edge cases (e.g., transitional provisions, COVID-19 relaxations)

**Metadata Filtering in Prompts:**
```python
# Example: Only retrieve RBI capital adequacy rules effective after 2023
filter_criteria = {
    "regulator": "RBI",
    "category": "capital_adequacy",
    "effective_date": ">= 2023-01-01"
}
```

## Installation

### Prerequisites
- Python 3.9+
- Google Cloud Project with Vertex AI API enabled
- **gcloud CLI installed** ([Install guide](https://cloud.google.com/sdk/docs/install))
- User account with roles:
  - `Vertex AI User` (or `roles/aiplatform.user`)
  - `Storage Object Viewer` (if using GCS - `roles/storage.objectViewer`)

### Setup

```bash
# Clone repository
git clone <repository-url>
cd regulatory_rag_system

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Authenticate with Google Cloud using Application Default Credentials
gcloud auth application-default login

# Set your GCP project
gcloud config set project your-project-id

# Set environment variables
export GOOGLE_CLOUD_PROJECT="your-project-id"
export VERTEX_AI_LOCATION="us-central1"  # or your preferred region
```

### Configuration

Edit `config/settings.py`:
```python
PROJECT_ID = "your-gcp-project-id"
LOCATION = "us-central1"
RAG_CORPUS_NAME = "regulatory_knowledge_base"
MODEL_NAME = "gemini-2.0-flash-exp"
```

## Usage

### Step 1: Generate Synthetic Data
```bash
python scripts/generate_data.py
```

This creates:
- `data/regulatory_documents/`: Sample regulatory guidelines (RBI, MAS, BIS)
- `data/report_submissions/`: Sample bank reports to validate

### Step 2: Index Documents into RAG Engine
```bash
python scripts/index_documents.py
```

This process:
- Chunks regulatory documents using hybrid strategy
- Generates embeddings using Vertex AI
- Creates RAG corpus with metadata
- Indexes documents for retrieval

**Expected Output:**
```
Starting document indexing...
Processing RBI_Capital_Adequacy_Guidelines_2024.txt
  - Created 47 chunks
  - Indexed with metadata: regulator=RBI, category=capital_adequacy
Processing MAS_Liquidity_Framework_2024.txt
  - Created 38 chunks
  - Indexed with metadata: regulator=MAS, category=liquidity
...
Total documents indexed: 8
Total chunks created: 312
RAG Corpus ID: projects/.../ragCorpora/regulatory_knowledge_base
```

### Step 3: Validate Reports
```bash
# Validate a specific report
python scripts/validate_report.py --report data/report_submissions/basel_iii_report_q3_2024.json

# Validate all reports
python scripts/validate_report.py --validate-all

# Validate with specific regulator focus
python scripts/validate_report.py --report data/report_submissions/lcr_report_oct_2024.json --regulator RBI
```

**Sample Output:**
```
=== Regulatory Report Validation ===
Report: Basel III Capital Adequacy Report - Q3 2024
Bank: DBS Bank India
Submission Date: 2024-10-15

Validation Results:

✓ PASS: CET1 Ratio (8.2%) meets minimum requirement (5.5%)
✓ PASS: Tier 1 Ratio (10.1%) meets minimum requirement (7.0%)
✗ FAIL: Total Capital Ratio (11.8%) below RBI requirement (12.5% including CCB)
  └─ Retrieved Regulation: RBI Master Circular DBR.No.BP.BC.1/21.06.201/2023-24
  └─ Requirement: Total Capital Ratio must be ≥ 9% + 2.5% CCB + 0.2% (D-SIB) = 11.7% minimum
  └─ Gap: -0.7 percentage points
  └─ Remediation: Increase Tier 2 capital by raising subordinated debt or review RWA calculation

⚠ WARNING: Risk Weight Assignment
  └─ Corporate exposures (AAA rated): Using 20% RW
  └─ Verify external credit rating and ensure rating agency is RBI-approved (CRISIL/ICRA/CARE)

Total Checks: 8
Passed: 6
Failed: 1
Warnings: 1

Overall Status: REQUIRES CORRECTION
```

## Project Structure

```
regulatory_rag_system/
├── README.md
├── requirements.txt
├── config/
│   └── settings.py              # Configuration parameters
├── data/
│   ├── regulatory_documents/    # Regulatory guidelines (generated)
│   └── report_submissions/      # Sample reports to validate (generated)
├── scripts/
│   ├── generate_data.py         # Generate synthetic data
│   ├── index_documents.py       # Index docs into RAG engine
│   └── validate_report.py       # Main validation script
└── src/
    ├── __init__.py
    ├── document_processor.py    # Document chunking & preprocessing
    ├── rag_engine.py            # Vertex AI RAG Engine wrapper
    ├── validator.py             # Validation logic & prompts
    └── utils.py                 # Helper functions
```

## Validation Logic Deep Dive

### Multi-Step Validation Process

1. **Report Parsing**: Extract structured data from submission
2. **Regulation Retrieval**: Query RAG engine with metadata filters
3. **Contextual Analysis**: Use Gemini to interpret regulatory text
4. **Calculation Verification**: Validate formulas and computations
5. **Threshold Checking**: Compare against regulatory limits
6. **Gap Analysis**: Identify specific non-compliance areas
7. **Remediation Suggestions**: Provide actionable fixes

### Metadata Filtering Examples

```python
# Example 1: Capital adequacy for RBI only
metadata_filter = {
    "regulator": "RBI",
    "category": "capital_adequacy",
    "effective_date": ">= 2024-01-01"
}

# Example 2: AML regulations from multiple regulators
metadata_filter = {
    "category": "aml_cft",
    "regulator": ["RBI", "FATF", "MAS"]
}

# Example 3: Basel III implementation across regulators
metadata_filter = {
    "report_type": "Basel_III",
    "section": ["3.2", "3.3"]  # Specific sections only
}
```

## Performance Considerations

- **Retrieval Latency**: ~300-500ms per query
- **Validation Time**: 2-5 seconds per report (depending on complexity)
- **Batch Processing**: Can validate 100+ reports in <10 minutes
- **Cost**: ~$0.02-0.05 per report validation (Gemini Flash pricing)

## Regulatory Updates

To update regulations:
```bash
# Add new document
cp new_regulation.pdf data/regulatory_documents/

# Re-index (incremental)
python scripts/index_documents.py --incremental

# The system automatically versions regulations by effective_date metadata
```

## Limitations & Future Enhancements

**Current Limitations:**
- Requires manual verification for novel regulatory interpretations
- Does not handle complex derivative valuations
- Limited to text-based reports (no image/chart analysis)

**Planned Enhancements:**
- [ ] Multi-modal support for charts/tables in reports
- [ ] Automated alert system for regulation changes
- [ ] Integration with GL systems for real-time validation
- [ ] Support for 30+ regulators globally
- [ ] Audit trail and explainability dashboard

## Compliance & Security

- All data processing occurs within GCP project boundary
- No PII or sensitive financial data in embeddings
- Audit logs maintained via Cloud Logging
- Role-based access control via IAM
- Compliant with data residency requirements

## Support & Contact

For technical issues or enhancement requests, contact:
- DBS Bank Data Analytics Team
- Email: data-analytics@dbs.com

## License

Internal Use Only - DBS Bank Proprietary

---

## Learning Guide: Semantic RAG vs Rule-Based Approaches

### Why This Matters

Traditional compliance systems rely on **rule-based/regex approaches** - hard-coded patterns that match specific text. While these work for simple cases, regulatory compliance requires understanding **context, meaning, and relationships** that only semantic approaches can provide.

This section explains when to use each approach and illustrates with real examples from this system.

---

### What is Semantic Chunking?

**Semantic chunking** divides documents into meaningful units that preserve context, rather than splitting at arbitrary character/word boundaries.

```
NAIVE CHUNKING (500 chars):                    SEMANTIC CHUNKING:
┌─────────────────────────────┐               ┌─────────────────────────────┐
│ "...capital ratio must be   │               │ SECTION 2.4: Capital Buffers│
│ at least 9%. Banks class"   │ ← BROKEN!     │                             │
├─────────────────────────────┤               │ Banks must maintain minimum │
│ "ified as D-SIB must main"  │ ← BROKEN!     │ capital ratio of 9%. D-SIB  │
├─────────────────────────────┤               │ banks require additional    │
│ "tain additional buffer..." │               │ 0.2% buffer...              │
└─────────────────────────────┘               └─────────────────────────────┘
                                                        ↑
                                              Complete, meaningful unit
```

**Our Hybrid Approach:**
1. **Structural chunking**: Respects section boundaries (SECTION, PART, RECOMMENDATION)
2. **Semantic chunking**: Within sections, splits at sentence boundaries
3. **Overlap**: 100 tokens overlap ensures context continuity

---

### What is RAG (Retrieval-Augmented Generation)?

RAG combines **semantic search** with **LLM reasoning**:

```
┌─────────────────────────────────────────────────────────────────┐
│                          RAG PIPELINE                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Query: "Is 8.15% CET1 ratio compliant?"                       │
│                    │                                            │
│                    ▼                                            │
│  ┌─────────────────────────────────┐                           │
│  │  1. EMBED: Convert to vector    │  [0.23, -0.15, 0.87, ...] │
│  └─────────────────────────────────┘                           │
│                    │                                            │
│                    ▼                                            │
│  ┌─────────────────────────────────┐                           │
│  │  2. SEARCH: Find similar chunks │  Cosine similarity        │
│  │     + Metadata filter:          │                           │
│  │     regulator=RBI               │                           │
│  │     category=capital_adequacy   │                           │
│  └─────────────────────────────────┘                           │
│                    │                                            │
│                    ▼                                            │
│  ┌─────────────────────────────────┐                           │
│  │  3. RETRIEVE: Top 5-7 chunks    │  "CET1 minimum is 5.5%..."│
│  └─────────────────────────────────┘                           │
│                    │                                            │
│                    ▼                                            │
│  ┌─────────────────────────────────┐                           │
│  │  4. GENERATE: LLM reasons over  │  "8.15% exceeds 5.5%     │
│  │     query + retrieved context   │   minimum. COMPLIANT."    │
│  └─────────────────────────────────┘                           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

### Comparison: Rule-Based vs Semantic RAG

| Aspect | Rule-Based / Regex | Semantic RAG |
|--------|-------------------|--------------|
| **Pattern matching** | Exact string matches | Meaning-based similarity |
| **Maintenance** | Update rules for every regulation change | Regulations indexed automatically |
| **Ambiguity handling** | Fails on paraphrasing | Understands synonyms & context |
| **Multi-regulation** | Separate rules per regulator | Single model handles all |
| **Complex reasoning** | Cannot do | LLM performs multi-step logic |
| **Setup complexity** | Low (write regex) | Medium (setup RAG pipeline) |
| **False positives** | High with broad patterns | Low with semantic precision |

---

### Examples: Where RAG Excels (Rule-Based Would Fail)

#### Example 1: Synonym & Paraphrase Handling

**Regulatory Text (RBI):**
> "The minimum Common Equity Tier 1 capital ratio shall be 5.5% of risk-weighted assets."

**Regulatory Text (MAS):**
> "Core Equity Tier 1 must not fall below 5.5% of total RWA."

**Query:** "What is the CET1 requirement?"

```python
# RULE-BASED APPROACH (FAILS) ❌
import re

# Would need SEPARATE patterns for each variation:
patterns = [
    r"CET1.*?(\d+\.?\d*)%",           # Matches "CET1 ratio of 5.5%"
    r"Common Equity Tier 1.*?(\d+)",   # Matches RBI phrasing
    r"Core Equity Tier 1.*?(\d+)",     # Matches MAS phrasing
    r"Tier 1 common.*?(\d+)",          # Another variation
    # ... dozens more patterns needed
]

# Problems:
# 1. Must anticipate every phrasing variation
# 2. New regulations require new patterns
# 3. Cannot distinguish CET1 from Tier 1 from Total Capital

# RAG APPROACH (WORKS) ✓
# Embedding captures semantic meaning:
# "CET1", "Common Equity Tier 1", "Core Equity Tier 1" → similar vectors
# RAG retrieves relevant chunks regardless of exact wording
```

---

#### Example 2: Contextual Requirements (D-SIB Buffer)

**Regulatory Text:**
> "Banks designated as Domestic Systemically Important Banks (D-SIB) shall maintain an additional capital buffer of 0.2% over and above the capital conservation buffer."

**Scenario A:** Bank is D-SIB, reports Total Capital = 11.5%
**Scenario B:** Bank is NOT D-SIB, reports Total Capital = 11.5%

```python
# RULE-BASED APPROACH (INCOMPLETE) ❌
def validate_total_capital(reported_ratio, is_dsib):
    base_requirement = 9.0
    ccb = 2.5
    dsib_buffer = 0.2 if is_dsib else 0.0

    total_requirement = base_requirement + ccb + dsib_buffer
    return reported_ratio >= total_requirement

# Problems:
# 1. Hard-coded values - what if RBI changes CCB to 2.75%?
# 2. What if D-SIB buffer varies by bucket (0.2%, 0.4%, 0.6%)?
# 3. What about counter-cyclical buffer (0-2.5%)?
# 4. Transitional provisions during phase-in periods?

# RAG APPROACH (DYNAMIC) ✓
query = f"""
The bank reports Total Capital Ratio: {reported_ratio}%
D-SIB status: {is_dsib}

According to current RBI Basel III guidelines:
1. What is the complete capital requirement including all buffers?
2. Is {reported_ratio}% compliant?
"""

# RAG retrieves the LATEST regulation text and LLM computes:
# - Base requirement from retrieved text
# - Applicable buffers based on bank characteristics
# - Handles transitional provisions automatically
```

---

#### Example 3: Cross-Referential Requirements

**Regulatory Text (Clause 3.2):**
> "Provisioning for sub-standard assets shall be as per rates specified in Clause 4.7."

**Regulatory Text (Clause 4.7):**
> "Sub-standard secured assets: 15%. Sub-standard unsecured assets: 25%. Infrastructure loans: refer Clause 4.9."

**Query:** "What provisioning rate applies to an unsecured infrastructure loan classified as sub-standard?"

```python
# RULE-BASED APPROACH (FAILS) ❌
# Cannot follow cross-references without complex graph logic
# Would need to:
# 1. Parse "refer Clause X.Y" patterns
# 2. Build document graph
# 3. Traverse references recursively
# 4. Handle circular references
# 5. Resolve conflicts between clauses

# This is essentially rebuilding semantic understanding!

# RAG APPROACH (WORKS) ✓
# 1. Query embedding captures "sub-standard + unsecured + infrastructure"
# 2. RAG retrieves ALL relevant chunks (3.2, 4.7, 4.9)
# 3. LLM reasons across multiple chunks
# 4. Synthesizes: "Infrastructure sub-standard unsecured = 25% base + specific provisions"
```

---

#### Example 4: Temporal Reasoning (Regulation Versions)

**RBI Circular 2022:**
> "Minimum LCR requirement shall be 100%."

**RBI Circular 2020 (COVID relaxation):**
> "Minimum LCR requirement reduced to 80% until March 2022."

**Query (in Jan 2021):** "Is LCR of 85% compliant?"

```python
# RULE-BASED APPROACH (FAILS) ❌
# Would need:
# 1. Date parsing for every regulation
# 2. Version control system
# 3. Complex "effective_from" and "effective_until" logic
# 4. Handling of superseded regulations

# RAG APPROACH (WORKS) ✓
# Metadata filtering handles this elegantly:
metadata_filter = {
    "regulator": "RBI",
    "category": "liquidity",
    "effective_date": "<= 2021-01-15"  # Query date
}
# Retrieves 2020 circular with COVID relaxation
# LLM correctly interprets: 85% >= 80% → COMPLIANT
```

---

#### Example 5: Negation and Exception Handling

**Regulatory Text:**
> "All exposures to corporates must be risk-weighted at 100%, EXCEPT:
> (a) Exposures to PSUs: 20%
> (b) Exposures rated AAA/AA: 50%
> (c) Exposures to infrastructure companies as defined in Annex B: special treatment"

**Query:** "What risk weight for AAA-rated infrastructure PSU?"

```python
# RULE-BASED APPROACH (AMBIGUOUS) ❌
# Multiple patterns match:
pattern_corporate = r"corporates.*?100%"           # → 100%
pattern_psu = r"PSUs.*?20%"                        # → 20%
pattern_aaa = r"AAA.*?50%"                         # → 50%
pattern_infra = r"infrastructure.*?special"        # → ???

# Which rule wins? Order dependency creates bugs.
# Exception hierarchies are impossible to encode.

# RAG APPROACH (REASONS CORRECTLY) ✓
# LLM understands hierarchy:
# 1. Base rule: Corporate = 100%
# 2. Exception (a): PSU → 20%
# 3. Exception (b): AAA → 50%
# 4. Exception (c): Infrastructure → special
# 5. Synthesizes: "AAA-rated infrastructure PSU" requires
#    review of Annex B, likely 20% or special treatment
```

---

### Examples: Where Rule-Based is Sufficient (RAG May Be Overkill)

Not everything needs RAG! Here are cases where simple rules work better:

#### Example 1: Fixed Format Validation

**Task:** Validate that Customer ID follows format: 8 digits starting with "CUST"

```python
# RULE-BASED (PERFECT) ✓
import re
def validate_customer_id(cid):
    return bool(re.match(r'^CUST\d{8}$', cid))

# RAG (OVERKILL) ❌
# - No semantic understanding needed
# - Pattern is deterministic
# - RAG adds latency (~500ms) for simple check
```

---

#### Example 2: Simple Threshold Checks

**Task:** Check if transaction amount exceeds ₹10 lakh (CTR threshold)

```python
# RULE-BASED (PERFECT) ✓
CTR_THRESHOLD = 1000000  # ₹10 lakh

def requires_ctr(amount):
    return amount >= CTR_THRESHOLD

# RAG (RISKY) ❌
# - LLM might hallucinate different threshold
# - Simple numeric comparison doesn't need "understanding"
# - Determinism is critical for compliance
```

---

#### Example 3: Enumeration Validation

**Task:** Validate asset classification is one of: Standard, Sub-standard, Doubtful, Loss

```python
# RULE-BASED (PERFECT) ✓
VALID_CLASSIFICATIONS = {'Standard', 'Sub-standard', 'Doubtful', 'Loss'}

def validate_classification(classification):
    return classification in VALID_CLASSIFICATIONS

# RAG (UNPREDICTABLE) ❌
# - LLM might accept "Substandard" (no hyphen)
# - Might accept synonyms like "Non-performing"
# - Strict enumeration needs exact matching
```

---

#### Example 4: Date Format Validation

**Task:** Ensure report date is in DD-MM-YYYY format

```python
# RULE-BASED (PERFECT) ✓
from datetime import datetime

def validate_date_format(date_str):
    try:
        datetime.strptime(date_str, '%d-%m-%Y')
        return True
    except ValueError:
        return False

# RAG (UNRELIABLE) ❌
# - LLM might accept "15th January 2024" as valid
# - Format validation requires exactness, not understanding
```

---

### Decision Framework: When to Use What

```
                              ┌─────────────────────────────────┐
                              │        START VALIDATION         │
                              └──────────────┬──────────────────┘
                                             │
                        ┌────────────────────┴────────────────────┐
                        │   Is this a format/structure check?     │
                        │   (date format, ID pattern, enum value) │
                        └────────────────────┬────────────────────┘
                                     YES     │      NO
                                      │      │       │
                        ┌─────────────┴──┐   │   ┌───┴───────────────┐
                        │  RULE-BASED    │   │   │ Does it require   │
                        │  Regex/Logic   │   │   │ regulatory lookup?│
                        └────────────────┘   │   └─────────┬─────────┘
                                             │        YES  │    NO
                                             │         │   │     │
                                             │   ┌─────┴───┴─┐   │
                                             │   │Can the reg │   │
                                             │   │change or   │   │
                                             │   │vary by     │   │
                                             │   │context?    │   │
                                             │   └─────┬─────┘   │
                                             │    YES  │   NO    │
                                             │     │   │    │    │
                                             │ ┌───┴───┴┐ ┌─┴────┴───┐
                                             │ │SEMANTIC│ │RULE-BASED│
                                             │ │  RAG   │ │ (config) │
                                             │ └────────┘ └──────────┘
```

**Use RULE-BASED when:**
- Fixed patterns (regex for formats)
- Static thresholds that rarely change
- Enumeration validation
- Performance-critical checks (avoid LLM latency)
- Determinism is mandatory

**Use SEMANTIC RAG when:**
- Regulation text is complex/ambiguous
- Requirements vary by context (bank type, date, jurisdiction)
- Cross-referential reasoning needed
- New regulations added frequently
- Natural language queries expected

---

### Hybrid Architecture (Best Practice)

This system uses a **hybrid approach**:

```
┌─────────────────────────────────────────────────────────────────┐
│                    VALIDATION PIPELINE                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  LAYER 1: RULE-BASED (Fast, Deterministic)                     │
│  ├── Format validation (dates, IDs, enums)                     │
│  ├── Static thresholds (CTR ≥ ₹10 lakh)                        │
│  └── Schema validation (required fields present)               │
│                          │                                      │
│                          ▼                                      │
│  LAYER 2: CONFIGURABLE RULES (Semi-dynamic)                    │
│  ├── Thresholds from config (CET1 ≥ 5.5%)                      │
│  ├── Jurisdiction-specific rules                                │
│  └── Periodically updated parameters                           │
│                          │                                      │
│                          ▼                                      │
│  LAYER 3: SEMANTIC RAG (Complex Reasoning)                     │
│  ├── Multi-regulation interpretation                            │
│  ├── Context-dependent requirements                             │
│  ├── Cross-reference resolution                                 │
│  └── Natural language compliance questions                      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**Example Flow:**
```python
def validate_report(report):
    errors = []

    # LAYER 1: Rule-based (instant)
    if not validate_date_format(report['date']):
        errors.append("Invalid date format")
    if report['classification'] not in VALID_CLASSIFICATIONS:
        errors.append("Invalid asset classification")

    # LAYER 2: Config-based (instant)
    if report['cet1_ratio'] < settings.CET1_MIN:
        errors.append(f"CET1 below minimum {settings.CET1_MIN}%")

    # LAYER 3: RAG (2-5 seconds, only if needed)
    if report['bank_type'] == 'D-SIB':
        # Complex: D-SIB buffer varies by bucket, needs regulation lookup
        rag_result = validate_with_rag(
            f"Is total capital ratio of {report['total_capital']}% "
            f"compliant for D-SIB bucket {report['dsib_bucket']}?"
        )
        if not rag_result['compliant']:
            errors.append(rag_result['message'])

    return errors
```

---

### Summary: Choosing the Right Tool

| Validation Type | Approach | Latency | Example |
|-----------------|----------|---------|---------|
| Format check | Regex | <1ms | Date format DD-MM-YYYY |
| Enum validation | Set lookup | <1ms | Classification in {Standard, Sub-standard...} |
| Fixed threshold | Config | <1ms | CTR ≥ ₹10 lakh |
| Simple calculation | Formula | <10ms | CET1 = CET1 Capital / RWA |
| Context-dependent rule | RAG | 300-500ms | D-SIB buffer by bucket |
| Cross-reference | RAG | 500-1000ms | Provisioning with exceptions |
| Multi-regulation | RAG | 1-2s | RBI vs MAS vs FATF comparison |
| Natural language query | RAG | 2-5s | "Is this compliant?" |

**Key Takeaway:** Use the simplest approach that correctly handles the requirement. Reserve RAG for cases requiring genuine semantic understanding.
