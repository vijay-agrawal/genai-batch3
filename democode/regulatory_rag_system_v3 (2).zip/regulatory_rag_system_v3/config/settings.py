"""
Configuration settings for Regulatory RAG System
"""
import os
from pathlib import Path

# Project root directory
PROJECT_ROOT = Path(__file__).parent.parent

# Google Cloud Configuration
# Using Application Default Credentials (gcloud auth application-default login)
# No need to set GOOGLE_APPLICATION_CREDENTIALS
GOOGLE_CLOUD_PROJECT = os.getenv("GOOGLE_CLOUD_PROJECT", "your-project-id")
VERTEX_AI_LOCATION = os.getenv("VERTEX_AI_LOCATION", "us-central1")

# Google Cloud Storage Configuration for RAG Engine
# RAG Engine requires documents to be in GCS before indexing
GCS_BUCKET_NAME = os.getenv("GCS_BUCKET_NAME", "your-bucket-name")
GCS_FOLDER_NAME = "regulatory_documents"  # Folder within bucket

# Vertex AI RAG Configuration
RAG_CORPUS_DISPLAY_NAME = "regulatory_knowledge_base"
RAG_CORPUS_DESCRIPTION = "Regulatory guidelines for banking compliance (RBI, MAS, BIS, FATF)"

# Model Configuration
EMBEDDING_MODEL = "text-embedding-004"
GENERATION_MODEL = "gemini-2.0-flash-exp"
GENERATION_MODEL_FALLBACK = "gemini-1.5-flash-002"  # Fallback if 2.0 not available

# Chunking Configuration
CHUNK_SIZE = 700  # tokens
CHUNK_OVERLAP = 100  # tokens
MAX_CHUNK_SIZE = 1000  # maximum tokens per chunk

# Retrieval Configuration
TOP_K_CHUNKS = 7  # Number of chunks to retrieve
SIMILARITY_THRESHOLD = 0.7  # Minimum similarity score
MAX_CONTEXT_TOKENS = 4000  # Maximum context window for LLM

# Validation Configuration
VALIDATION_TEMPERATURE = 0.1  # Low temperature for deterministic validation
MAX_OUTPUT_TOKENS = 2048

# Data Directories
DATA_DIR = PROJECT_ROOT / "data"
REGULATORY_DOCS_DIR = DATA_DIR / "regulatory_documents"
REPORT_SUBMISSIONS_DIR = DATA_DIR / "report_submissions"
OUTPUT_DIR = PROJECT_ROOT / "output"

# Ensure directories exist
REGULATORY_DOCS_DIR.mkdir(parents=True, exist_ok=True)
REPORT_SUBMISSIONS_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Regulatory Categories
REGULATORY_CATEGORIES = [
    "capital_adequacy",
    "liquidity",
    "credit_risk",
    "aml_cft",
    "forex",
    "operational_risk",
    "market_risk"
]

# Regulators
REGULATORS = [
    "RBI",      # Reserve Bank of India
    "MAS",      # Monetary Authority of Singapore
    "BIS",      # Bank for International Settlements
    "FATF",     # Financial Action Task Force
    "BCBS",     # Basel Committee on Banking Supervision
    "IOSCO",    # International Organization of Securities Commissions
]

# Report Types
REPORT_TYPES = [
    "Basel_III",
    "LFAR",
    "CRILC",
    "LCR",
    "NSFR",
    "STR",
    "CTR",
    "Forex_Position"
]

# Validation Thresholds (RBI Requirements)
CAPITAL_ADEQUACY_THRESHOLDS = {
    "cet1_ratio_min": 5.5,  # %
    "tier1_ratio_min": 7.0,  # %
    "total_capital_ratio_min": 9.0,  # % (base requirement)
    "capital_conservation_buffer": 2.5,  # %
    "dsib_buffer": 0.2,  # % for D-SIB banks
}

LIQUIDITY_THRESHOLDS = {
    "lcr_min": 100.0,  # %
    "nsfr_min": 100.0,  # %
}

NPA_THRESHOLDS = {
    "npa_classification_days": 90,  # days past due
    "provisioning": {
        "standard_secured": 0.40,  # %
        "standard_unsecured": 1.00,  # %
        "substandard_secured": 15.0,  # %
        "substandard_unsecured": 25.0,  # %
        "doubtful_1": 25.0,  # %
        "doubtful_2": 40.0,  # %
        "doubtful_3": 100.0,  # %
        "loss": 100.0,  # %
    }
}

AML_THRESHOLDS = {
    "ctr_threshold_inr": 1000000,  # ₹10 lakh
    "str_filing_days": 7,  # days
    "pep_enhanced_dd": True,
}

FOREX_THRESHOLDS = {
    "net_open_position_limit": 2.0,  # % of capital funds
    "aggregate_gap_limit": 20.0,  # % of capital funds
}

# Logging
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
