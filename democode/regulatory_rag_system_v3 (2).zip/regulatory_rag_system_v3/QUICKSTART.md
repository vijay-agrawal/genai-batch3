# Quick Start Guide - Regulatory RAG System

## Prerequisites

1. **Google Cloud Project** with Vertex AI API enabled
2. **gcloud CLI** installed ([Install guide](https://cloud.google.com/sdk/docs/install))
3. **User account** with permissions:
   - Vertex AI User (`roles/aiplatform.user`)
   - Storage Object Viewer (if using GCS - `roles/storage.objectViewer`)
4. **Python 3.9+** installed

## Setup (5 minutes)

### Step 1: Clone and Setup Environment

```bash
cd regulatory_rag_system

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Step 2: Authenticate with Google Cloud

```bash
# Authenticate using Application Default Credentials
gcloud auth application-default login

# Set your GCP project
gcloud config set project your-project-id

# Verify authentication
gcloud auth application-default print-access-token
```

### Step 3: Configure Environment Variables

```bash
# Set required environment variables
export GOOGLE_CLOUD_PROJECT="your-project-id"
export VERTEX_AI_LOCATION="us-central1"  # or your preferred region
```

**Alternative: Create .env file**
```bash
# Copy example and edit
cp .env.example .env

# Edit .env file with your values:
# GOOGLE_CLOUD_PROJECT=your-project-id
# VERTEX_AI_LOCATION=us-central1
```

### Step 4: Generate Sample Data

```bash
python scripts/generate_data.py
```

**Output:**
- `data/regulatory_documents/`: 4 regulatory guideline files
- `data/report_submissions/`: 5 sample bank reports

### Step 5: Index Documents into RAG Engine

```bash
python scripts/index_documents.py
```

**What happens:**
- Creates RAG corpus in Vertex AI
- Chunks documents (500-800 tokens each)
- Generates embeddings using `text-embedding-004`
- Indexes ~300 chunks with metadata

**Time:** ~2-3 minutes

### Step 6: Validate Reports

```bash
# Validate a single report
python scripts/validate_report.py --report data/report_submissions/basel_iii_report_q3_2024.json

# Validate all reports
python scripts/validate_report.py --validate-all

# Focus on specific regulator
python scripts/validate_report.py --report data/report_submissions/lcr_report_oct_2024.json --regulator MAS
```

## Understanding the Output

### Validation Report Format

```
=== Regulatory Report Validation ===
Report: Basel III Capital Adequacy Report - Q3 2024
Bank: DBS Bank India

✓ PASS: CET1 Ratio (8.2%) meets requirement (5.5%)
✗ FAIL: Total Capital Ratio (11.8%) below requirement (12.5%)
  └─ Gap: -0.7 percentage points
  └─ Remediation: Increase Tier 2 capital or review RWA

Summary:
- Total Checks: 8
- Passed: 6
- Failed: 1
- Warnings: 1

Overall Status: REQUIRES CORRECTION
```

### Key Components

1. **Status Indicators:**
   - ✓ PASS (Green): Compliant with regulation
   - ✗ FAIL (Red): Non-compliant, action required
   - ⚠ WARNING (Yellow): Needs review

2. **Retrieved Regulation:** Shows source regulation used for validation

3. **Gap Analysis:** Quantifies non-compliance

4. **Remediation:** Suggests corrective actions

## Example Use Cases

### Use Case 1: Capital Adequacy Check

```bash
python scripts/validate_report.py \
  --report data/report_submissions/basel_iii_report_q3_2024.json \
  --regulator RBI
```

**Checks:**
- CET1 ratio ≥ 5.5%
- Tier 1 ratio ≥ 7.0%
- Total capital ratio ≥ 11.7% (including CCB + D-SIB buffer)
- Risk weight assignments

### Use Case 2: Liquidity Coverage Ratio

```bash
python scripts/validate_report.py \
  --report data/report_submissions/lcr_report_oct_2024.json \
  --regulator MAS
```

**Checks:**
- Overall LCR ≥ 100%
- HQLA composition limits (Level 2 ≤ 40%, Level 2B ≤ 15%)
- Currency-specific LCR thresholds
- Cash outflow/inflow calculations

### Use Case 3: AML/CFT Compliance

```bash
python scripts/validate_report.py \
  --report data/report_submissions/aml_cft_compliance_report_sep_2024.json
```

**Checks:**
- STR filing within 7 days
- Wire transfer information completeness (FATF Travel Rule)
- KYC periodic updates
- PEP due diligence

## How RAG Works in This System

### 1. Document Chunking

```
RBI Capital Adequacy Guidelines (15 pages)
    ↓
Structural Chunking (by sections)
    ↓
Semantic Chunking (500-800 tokens)
    ↓
47 chunks with metadata
    {
      "content": "Section 2.4: Capital Conservation Buffer...",
      "metadata": {
        "regulator": "RBI",
        "category": "capital_adequacy",
        "section": "2.4",
        "effective_date": "April 1, 2024"
      }
    }
```

### 2. Metadata-Filtered Retrieval

When validating a Basel III report:

```python
metadata_filter = {
    "regulator": "RBI",
    "category": "capital_adequacy",
    "report_type": "Basel_III"
}

# Retrieves only relevant regulation chunks
# Ignores liquidity, AML, forex rules
```

### 3. RAG-Augmented Validation

```
User Report → Query Generation → Metadata Filter → RAG Retrieval
                                                          ↓
                                                    Top 5-7 Chunks
                                                          ↓
                                              Gemini Flash 2.5
                                                          ↓
                                                 Validation Result
                                                  (Pass/Fail/Warning)
```

## Customization

### Add New Regulations

1. Create `.txt` file in `data/regulatory_documents/`
2. Run: `python scripts/index_documents.py --incremental`

### Add New Report Type

Edit `src/validator.py` and add validation method:

```python
def _validate_new_report_type(self, report_data, metadata):
    # Your validation logic
    pass
```

### Adjust Chunking Parameters

Edit `config/settings.py`:

```python
CHUNK_SIZE = 700  # Adjust based on your needs
CHUNK_OVERLAP = 100
TOP_K_CHUNKS = 7  # Number of chunks to retrieve
```

## Troubleshooting

### Error: "Corpus not found"

**Solution:** Run indexing first:
```bash
python scripts/index_documents.py
```

### Error: "No module named 'vertexai'"

**Solution:** Install dependencies:
```bash
pip install -r requirements.txt
```

### Error: "Permission denied" or "Unauthenticated"

**Solution:** Authenticate with gcloud:
```bash
# Login with Application Default Credentials
gcloud auth application-default login

# Verify authentication
gcloud auth application-default print-access-token

# Ensure you have the right roles
gcloud projects get-iam-policy PROJECT_ID \
  --flatten="bindings[].members" \
  --filter="bindings.members:user:YOUR_EMAIL"
```

**Grant permissions if needed:**
```bash
# Add Vertex AI User role to your account
gcloud projects add-iam-policy-binding PROJECT_ID \
  --member="user:YOUR_EMAIL" \
  --role="roles/aiplatform.user"
```

### Error: "Application Default Credentials not found"

**Solution:** 
```bash
# Run authentication command
gcloud auth application-default login

# If using a different project
gcloud config set project your-project-id
```

### RAG retrieval returns no results

**Possible causes:**
1. Corpus not indexed properly
2. Metadata filter too restrictive
3. Query mismatch with document content

**Solution:** Check corpus status and re-index if needed

## Cost Estimation

Based on Google Cloud pricing (as of 2024):

| Component | Cost per Report |
|-----------|----------------|
| Embedding Generation | $0.000025 per 1K tokens |
| RAG Retrieval | $0.01 per query |
| Gemini Flash Generation | $0.02 per 1K tokens |
| **Total per Report** | **~$0.02-0.05** |

For 100 reports/month: **~$2-5/month**

## Next Steps

1. **Connect to Real Data Sources:**
   - Integrate with core banking systems
   - Connect to GL databases
   - Pull from regulatory portals

2. **Expand Regulation Coverage:**
   - Add more regulators (ECB, FCA, APRA)
   - Include sector-specific rules
   - Add historical regulation versions

3. **Enhance Validation:**
   - Add calculation verification
   - Implement cross-report consistency checks
   - Build audit trail

4. **Deploy to Production:**
   - Set up Cloud Run/Cloud Functions
   - Add authentication
   - Create monitoring dashboard

## Support

For issues or questions:
- Check logs in `output/` directory
- Review README.md for detailed documentation
- Contact: data-analytics@dbs.com
