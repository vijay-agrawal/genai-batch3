"""
Utility functions for regulatory RAG system
"""
import json
import logging
from typing import Dict, List, Any
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)


def load_json_file(filepath: Path) -> Dict:
    """
    Load JSON file
    
    Args:
        filepath: Path to JSON file
        
    Returns:
        Parsed JSON data
    """
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_json_file(data: Dict, filepath: Path, indent: int = 2):
    """
    Save data to JSON file
    
    Args:
        data: Data to save
        filepath: Output file path
        indent: JSON indentation
    """
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=indent)


def format_currency(amount: float, currency: str = "INR") -> str:
    """
    Format currency amount
    
    Args:
        amount: Amount to format
        currency: Currency code
        
    Returns:
        Formatted string
    """
    if currency == "INR":
        # Indian numbering system
        if amount >= 10000000:  # Crores
            return f"₹{amount/10000000:.2f} Cr"
        elif amount >= 100000:  # Lakhs
            return f"₹{amount/100000:.2f} L"
        else:
            return f"₹{amount:,.2f}"
    else:
        return f"{currency} {amount:,.2f}"


def format_percentage(value: float, decimal_places: int = 2) -> str:
    """
    Format percentage value
    
    Args:
        value: Percentage value
        decimal_places: Number of decimal places
        
    Returns:
        Formatted string
    """
    return f"{value:.{decimal_places}f}%"


def calculate_gap(actual: float, required: float) -> float:
    """
    Calculate gap between actual and required values
    
    Args:
        actual: Actual value
        required: Required value
        
    Returns:
        Gap (negative if below requirement)
    """
    return actual - required


def determine_severity(gap: float, threshold_major: float = 1.0) -> str:
    """
    Determine severity of compliance gap
    
    Args:
        gap: Compliance gap
        threshold_major: Threshold for major issue
        
    Returns:
        Severity level
    """
    if gap >= 0:
        return "COMPLIANT"
    elif abs(gap) >= threshold_major:
        return "CRITICAL"
    else:
        return "MINOR"


def extract_numbers_from_text(text: str) -> List[float]:
    """
    Extract numeric values from text
    
    Args:
        text: Input text
        
    Returns:
        List of extracted numbers
    """
    import re
    
    # Pattern for numbers (including decimals and percentages)
    pattern = r'-?\d+\.?\d*'
    matches = re.findall(pattern, text)
    
    return [float(m) for m in matches]


def chunk_list(lst: List, chunk_size: int) -> List[List]:
    """
    Split list into chunks
    
    Args:
        lst: Input list
        chunk_size: Size of each chunk
        
    Returns:
        List of chunks
    """
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]


def get_timestamp(format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    Get current timestamp
    
    Args:
        format_str: Datetime format string
        
    Returns:
        Formatted timestamp
    """
    return datetime.now().strftime(format_str)


def validate_environment():
    """
    Validate that required environment variables are set
    
    Raises:
        ValueError: If required variables are missing
    """
    import os
    
    required_vars = [
        'GOOGLE_CLOUD_PROJECT'
    ]
    
    missing = []
    for var in required_vars:
        if not os.getenv(var):
            missing.append(var)
    
    if missing:
        raise ValueError(
            f"Missing required environment variables: {', '.join(missing)}\n"
            f"Please set GOOGLE_CLOUD_PROJECT environment variable.\n"
            f"Make sure you've run: gcloud auth application-default login"
        )


def create_directory_structure(base_dir: Path):
    """
    Create required directory structure
    
    Args:
        base_dir: Base directory path
    """
    directories = [
        base_dir / "data" / "regulatory_documents",
        base_dir / "data" / "report_submissions",
        base_dir / "output",
        base_dir / "logs"
    ]
    
    for directory in directories:
        directory.mkdir(parents=True, exist_ok=True)
        logger.info(f"Created directory: {directory}")
