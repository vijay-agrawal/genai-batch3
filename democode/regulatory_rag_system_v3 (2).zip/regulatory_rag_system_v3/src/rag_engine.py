"""
Vertex AI RAG Engine wrapper
Handles corpus creation, document indexing from GCS, and retrieval
"""
import logging
import time
from typing import List, Dict, Optional
from google.cloud import storage
from google.cloud import aiplatform
from google.api_core import retry
from vertexai.preview import rag
from vertexai.preview.generative_models import GenerativeModel, Tool
import vertexai

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class VertexRAGEngine:
    """Vertex AI RAG Engine for regulatory document retrieval"""
    
    def __init__(
        self,
        project_id: str,
        location: str,
        corpus_display_name: str,
        embedding_model: str = "text-embedding-004",
        bucket_name: str = None
    ):
        """
        Initialize RAG Engine
        
        Args:
            project_id: GCP project ID
            location: GCP region (e.g., 'us-central1')
            corpus_display_name: Display name for RAG corpus
            embedding_model: Embedding model to use
            bucket_name: GCS bucket name where documents are stored
        """
        self.project_id = project_id
        self.location = location
        self.corpus_display_name = corpus_display_name
        self.embedding_model = embedding_model
        self.bucket_name = bucket_name
        
        print("\n" + "=" * 80)
        print("INITIALIZING VERTEX AI RAG ENGINE")
        print("=" * 80)
        print(f"  Project ID: {project_id}")
        print(f"  Location: {location}")
        print(f"  Corpus Name: {corpus_display_name}")
        print(f"  Embedding Model: {embedding_model}")
        if bucket_name:
            print(f"  GCS Bucket: gs://{bucket_name}")
        
        # Initialize Vertex AI
        vertexai.init(project=project_id, location=location)
        logger.info("✓ Vertex AI initialized")
        
        self.corpus = None
        self.rag_corpus_resource_name = None
        
    def create_corpus(
        self,
        description: str = "Regulatory knowledge base for banking compliance"
    ) -> str:
        """
        Create or get existing RAG corpus
        
        Args:
            description: Corpus description
            
        Returns:
            RAG corpus resource name
        """
        print("\n" + "=" * 80)
        print("STEP 1: CREATE/GET RAG CORPUS")
        print("=" * 80)
        
        try:
            # Try to find existing corpus
            print("\n🔍 Searching for existing RAG corpus...")
            corpora = rag.list_corpora()
            
            found_corpus = None
            corpus_count = 0
            for corpus in corpora:
                corpus_count += 1
                print(f"  Found corpus: {corpus.display_name} ({corpus.name})")
                if corpus.display_name == self.corpus_display_name:
                    found_corpus = corpus
                    print(f"  ✓ Matching corpus found!")
            
            print(f"\nTotal corpora in project: {corpus_count}")
            
            if found_corpus:
                self.corpus = found_corpus
                self.rag_corpus_resource_name = found_corpus.name
                
                print(f"\n✅ Using existing corpus:")
                print(f"  Name: {found_corpus.display_name}")
                print(f"  Resource: {found_corpus.name}")
                print(f"  Description: {getattr(found_corpus, 'description', 'N/A')}")
                
                return found_corpus.name
            
            # Create new corpus if not found
            print(f"\n📝 Creating new RAG corpus: {self.corpus_display_name}")
            
            corpus = rag.create_corpus(
                display_name=self.corpus_display_name,
                description=description
            )
            
            self.corpus = corpus
            self.rag_corpus_resource_name = corpus.name
            
            print(f"\n✅ Created new corpus:")
            print(f"  Name: {corpus.display_name}")
            print(f"  Resource: {corpus.name}")
            print(f"  Description: {description}")
            
            return corpus.name
            
        except Exception as e:
            logger.error(f"❌ Error creating corpus: {e}")
            raise
    
    def import_files_from_gcs(
        self,
        gcs_uris: List[str],
        chunk_size: int = 1000,
        chunk_overlap: int = 200
    ) -> Dict[str, int]:
        """
        Import files from GCS into RAG corpus
        
        Args:
            gcs_uris: List of GCS URIs (gs://bucket/path/file.txt)
            chunk_size: Size of chunks in tokens
            chunk_overlap: Overlap between chunks in tokens
            
        Returns:
            Statistics about import
        """
        if not self.rag_corpus_resource_name:
            raise ValueError("Corpus not created. Call create_corpus() first.")
        
        print("\n" + "=" * 80)
        print("STEP 2: IMPORT FILES FROM GCS INTO RAG CORPUS")
        print("=" * 80)
        
        print(f"\n📋 Import Configuration:")
        print(f"  Corpus: {self.corpus_display_name}")
        print(f"  Chunk Size: {chunk_size} tokens")
        print(f"  Chunk Overlap: {chunk_overlap} tokens")
        print(f"  Number of files: {len(gcs_uris)}")
        
        print(f"\n📂 Files to import:")
        for i, uri in enumerate(gcs_uris, 1):
            print(f"  {i}. {uri}")
        
        try:
            print(f"\n⏳ Importing files into RAG corpus...")
            print("  This may take 2-5 minutes depending on document size...")
            
            # Import files
            response = rag.import_files(
                corpus_name=self.rag_corpus_resource_name,
                paths=gcs_uris,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap
            )
            
            print(f"\n✅ Import completed!")
            print(f"  Import response: {response}")
            
            # Get corpus stats
            print(f"\n📊 Corpus Statistics:")
            corpus = rag.get_corpus(name=self.rag_corpus_resource_name)
            
            # Note: Vertex AI RAG corpus doesn't expose chunk count directly
            # It processes and chunks internally
            print(f"  Corpus Resource Name: {corpus.name}")
            print(f"  Display Name: {corpus.display_name}")
            
            stats = {
                'total_files': len(gcs_uris),
                'imported_files': len(gcs_uris),
                'failed_files': 0,
                'corpus_name': corpus.name
            }
            
            print(f"\n✓ Successfully imported {stats['imported_files']} files")
            
            return stats
            
        except Exception as e:
            logger.error(f"❌ Error importing files: {e}")
            raise
    
    def retrieve(
        self,
        query: str,
        top_k: int = 5,
        similarity_threshold: float = 0.5
    ) -> List[Dict[str, any]]:
        """
        Retrieve relevant chunks from RAG corpus
        
        Args:
            query: Search query
            top_k: Number of results to return
            similarity_threshold: Minimum similarity score
            
        Returns:
            List of retrieved chunks with content and metadata
        """
        if not self.rag_corpus_resource_name:
            raise ValueError("Corpus not created. Call create_corpus() first.")
        
        print("\n" + "=" * 80)
        print("RAG RETRIEVAL")
        print("=" * 80)
        print(f"  Query: {query[:100]}...")
        print(f"  Query Length: {len(query)} characters")
        print(f"  Top-K: {top_k}")
        print(f"  Similarity Threshold: {similarity_threshold}")
        
        try:
            print(f"\n🔍 Retrieving from RAG corpus...")
            
            # Retrieve from RAG corpus
            response = rag.retrieval_query(
                rag_resources=[
                    rag.RagResource(
                        rag_corpus=self.rag_corpus_resource_name,
                    )
                ],
                text=query,
                similarity_top_k=top_k,
            )
            
            # Process results
            results = []
            print(f"\n📄 Retrieved Contexts:")
            
            for i, context in enumerate(response.contexts, 1):
                print(f"\n  [{i}] Chunk from RAG Corpus:")
                print(f"      Source URI: {getattr(context, 'source_uri', 'N/A')}")
                print(f"      Distance/Score: {getattr(context, 'distance', 'N/A')}")
                print(f"      Content Length: {len(context.text)} characters")
                print(f"      Content Preview: {context.text[:150]}...")
                
                result = {
                    'content': context.text,
                    'score': 1.0 - context.distance if hasattr(context, 'distance') else 1.0,
                    'source': getattr(context, 'source_uri', 'RAG Corpus'),
                }
                
                # Add metadata if available
                if hasattr(context, 'metadata'):
                    result['metadata'] = dict(context.metadata)
                    print(f"      Metadata: {result['metadata']}")
                
                # Filter by similarity threshold
                if result['score'] >= similarity_threshold:
                    results.append(result)
            
            print(f"\n✅ Retrieved {len(results)} chunks (above threshold {similarity_threshold})")
            
            if not results:
                print(f"\n⚠️  WARNING: No chunks met the similarity threshold!")
                print(f"   Consider lowering threshold or checking query relevance")
            
            return results
            
        except Exception as e:
            logger.error(f"❌ Error during retrieval: {e}")
            return []
    
    def generate_with_rag(
        self,
        query: str,
        model_name: str = "gemini-2.0-flash-exp",
        top_k: int = 7,
        temperature: float = 0.1,
        max_output_tokens: int = 2048
    ) -> Dict[str, any]:
        """
        Generate response using RAG-augmented generation
        
        Args:
            query: User query/prompt
            model_name: Gemini model to use
            top_k: Number of chunks to retrieve
            temperature: Generation temperature
            max_output_tokens: Maximum tokens in response
            
        Returns:
            Generated response with sources
        """
        print("\n" + "=" * 80)
        print("RAG-AUGMENTED GENERATION")
        print("=" * 80)
        print(f"  Model: {model_name}")
        print(f"  Temperature: {temperature}")
        print(f"  Max Output Tokens: {max_output_tokens}")
        print(f"  Top-K Retrieval: {top_k}")
        
        try:
            # Create RAG retrieval tool
            print(f"\n🔧 Creating RAG retrieval tool...")
            rag_retrieval_tool = Tool.from_retrieval(
                retrieval=rag.Retrieval(
                    source=rag.VertexRagStore(
                        rag_resources=[
                            rag.RagResource(
                                rag_corpus=self.rag_corpus_resource_name,
                            )
                        ],
                        similarity_top_k=top_k,
                    ),
                )
            )
            print(f"  ✓ RAG tool created with corpus: {self.corpus_display_name}")
            
            # Initialize model with RAG tool
            print(f"\n🤖 Initializing Gemini model: {model_name}")
            model = GenerativeModel(
                model_name=model_name,
                tools=[rag_retrieval_tool]
            )
            print(f"  ✓ Model initialized with RAG tool")
            
            # Generate response
            print(f"\n⚡ Generating response...")
            print(f"  Query sent to model: {query[:200]}...")
            
            response = model.generate_content(
                query,
                generation_config={
                    'temperature': temperature,
                    'max_output_tokens': max_output_tokens,
                }
            )
            
            # Extract response text
            response_text = response.text if hasattr(response, 'text') else str(response)
            
            print(f"\n✅ Response generated:")
            print(f"  Length: {len(response_text)} characters")
            print(f"  Preview: {response_text[:200]}...")
            
            # Extract grounding metadata if available
            grounding_metadata = None
            if hasattr(response, 'candidates') and response.candidates:
                candidate = response.candidates[0]
                if hasattr(candidate, 'grounding_metadata'):
                    grounding_metadata = candidate.grounding_metadata
                    print(f"\n📚 Grounding Metadata Available:")
                    print(f"  {grounding_metadata}")
            
            return {
                'response': response_text,
                'grounding_metadata': grounding_metadata,
                'model': model_name
            }
            
        except Exception as e:
            logger.error(f"❌ Error generating RAG response: {e}")
            raise
    
    def delete_corpus(self) -> bool:
        """
        Delete the RAG corpus
        
        Returns:
            True if successful
        """
        if not self.rag_corpus_resource_name:
            logger.warning("No corpus to delete")
            return False
        
        try:
            print(f"\n🗑️  Deleting corpus: {self.rag_corpus_resource_name}")
            rag.delete_corpus(name=self.rag_corpus_resource_name)
            
            self.corpus = None
            self.rag_corpus_resource_name = None
            
            print("✅ Corpus deleted successfully")
            return True
            
        except Exception as e:
            logger.error(f"❌ Error deleting corpus: {e}")
            return False
