"""
Regulatory report validator
Uses RAG engine to validate reports against regulatory requirements
"""
import json
import logging
from typing import Dict, List, Optional
from pathlib import Path

from src.rag_engine import VertexRAGEngine
from src.document_processor import extract_report_metadata
from config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RegulatoryValidator:
    """Validate regulatory reports using RAG-augmented LLM"""
    
    def __init__(self, rag_engine: VertexRAGEngine):
        """
        Initialize validator
        
        Args:
            rag_engine: Initialized RAG engine
        """
        self.rag_engine = rag_engine
        self.validation_results = []
    
    def validate_report(
        self,
        report_path: Path,
        regulator_focus: Optional[str] = None
    ) -> Dict[str, any]:
        """
        Validate a regulatory report
        
        Args:
            report_path: Path to report JSON file
            regulator_focus: Optional specific regulator to focus on
            
        Returns:
            Validation results dictionary
        """
        logger.info(f"Validating report: {report_path.name}")
        
        # Load report
        with open(report_path, 'r') as f:
            report_data = json.load(f)
        
        # Extract report metadata
        report_metadata = extract_report_metadata(report_data)
        if regulator_focus:
            report_metadata['regulator'] = regulator_focus
        
        # Determine validation type
        report_type = report_data.get('report_type', '')
        
        if 'Capital' in report_type or 'Basel' in report_type:
            results = self._validate_capital_adequacy(report_data, report_metadata)
        elif 'Liquidity' in report_type or 'LCR' in report_type:
            results = self._validate_liquidity(report_data, report_metadata)
        elif 'NPA' in report_type:
            results = self._validate_npa_provisioning(report_data, report_metadata)
        elif 'AML' in report_type or 'CFT' in report_type:
            results = self._validate_aml_cft(report_data, report_metadata)
        elif 'Forex' in report_type:
            results = self._validate_forex(report_data, report_metadata)
        else:
            results = self._generic_validation(report_data, report_metadata)
        
        # Compile final report
        validation_report = {
            'report_file': report_path.name,
            'report_type': report_data.get('report_type'),
            'bank_name': report_data.get('bank_name'),
            'reporting_date': report_data.get('reporting_date'),
            'validation_timestamp': self._get_timestamp(),
            'checks': results['checks'],
            'summary': results['summary'],
            'overall_status': results['overall_status']
        }
        
        return validation_report
    
    def _validate_capital_adequacy(
        self,
        report_data: Dict,
        metadata: Dict
    ) -> Dict[str, any]:
        """Validate Basel III capital adequacy report"""
        
        checks = []
        
        # Extract capital ratios
        capital_ratios = report_data.get('capital_ratios', {})
        cet1_ratio = capital_ratios.get('cet1_ratio', 0)
        tier1_ratio = capital_ratios.get('tier1_ratio', 0)
        total_capital_ratio = capital_ratios.get('total_capital_ratio', 0)
        
        # Check 1: CET1 Ratio
        check_result = self._validate_with_rag(
            check_name="CET1 Ratio Requirement",
            value=cet1_ratio,
            query=f"""
            According to {metadata.get('regulator', 'RBI')} Basel III capital adequacy guidelines,
            what is the minimum Common Equity Tier 1 (CET1) capital ratio requirement?
            
            The bank has reported a CET1 ratio of {cet1_ratio}%.
            Is this compliant with the requirement?
            
            Provide:
            1. The minimum CET1 ratio requirement
            2. Whether {cet1_ratio}% meets this requirement
            3. If non-compliant, the gap in percentage points
            """,
            metadata_filter={
                'category': 'capital_adequacy',
                'regulator': metadata.get('regulator', 'RBI')
            }
        )
        checks.append(check_result)
        
        # Check 2: Tier 1 Ratio
        check_result = self._validate_with_rag(
            check_name="Tier 1 Capital Ratio Requirement",
            value=tier1_ratio,
            query=f"""
            According to {metadata.get('regulator', 'RBI')} Basel III guidelines,
            what is the minimum Tier 1 capital ratio requirement?
            
            The bank has reported a Tier 1 ratio of {tier1_ratio}%.
            Is this compliant?
            
            Provide the minimum requirement and compliance status.
            """,
            metadata_filter={
                'category': 'capital_adequacy',
                'regulator': metadata.get('regulator', 'RBI')
            }
        )
        checks.append(check_result)
        
        # Check 3: Total Capital Ratio with CCB and D-SIB
        dsib_status = report_data.get('dsib_status') == 'Yes'
        dsib_buffer = report_data.get('dsib_buffer_requirement', 0)
        ccb = report_data.get('capital_conservation_buffer', 2.5)
        
        check_result = self._validate_with_rag(
            check_name="Total Capital Ratio with Buffers",
            value=total_capital_ratio,
            query=f"""
            According to {metadata.get('regulator', 'RBI')} Basel III guidelines:
            
            The bank reports:
            - Total Capital Ratio: {total_capital_ratio}%
            - D-SIB status: {'Yes' if dsib_status else 'No'}
            - D-SIB buffer requirement: {dsib_buffer}%
            - Capital Conservation Buffer: {ccb}%
            
            What is the complete total capital requirement including:
            1. Base requirement
            2. Capital Conservation Buffer
            3. D-SIB buffer (if applicable)
            
            Is {total_capital_ratio}% compliant with the total requirement?
            Calculate the exact gap if non-compliant.
            """,
            metadata_filter={
                'category': 'capital_adequacy',
                'regulator': metadata.get('regulator', 'RBI')
            }
        )
        checks.append(check_result)
        
        # Check 4: Risk Weight Assignments
        if 'risk_weighted_assets' in report_data:
            check_result = self._validate_with_rag(
                check_name="Risk Weight Assignment Verification",
                value=None,
                query=f"""
                Review the risk-weighted assets calculation for compliance with
                {metadata.get('regulator', 'RBI')} guidelines:
                
                {json.dumps(report_data.get('risk_weighted_assets'), indent=2)}
                
                Are the risk weights properly applied according to standardized approach?
                Highlight any potential issues.
                """,
                metadata_filter={
                    'category': 'capital_adequacy',
                    'regulator': metadata.get('regulator', 'RBI')
                }
            )
            checks.append(check_result)
        
        # Compile summary
        passed = sum(1 for c in checks if c['status'] == 'PASS')
        failed = sum(1 for c in checks if c['status'] == 'FAIL')
        warnings = sum(1 for c in checks if c['status'] == 'WARNING')
        
        overall_status = 'COMPLIANT' if failed == 0 else 'REQUIRES CORRECTION'
        if warnings > 0 and failed == 0:
            overall_status = 'COMPLIANT WITH WARNINGS'
        
        return {
            'checks': checks,
            'summary': {
                'total_checks': len(checks),
                'passed': passed,
                'failed': failed,
                'warnings': warnings
            },
            'overall_status': overall_status
        }
    
    def _validate_liquidity(
        self,
        report_data: Dict,
        metadata: Dict
    ) -> Dict[str, any]:
        """Validate liquidity coverage ratio report"""
        
        checks = []
        
        # Extract LCR
        lcr_ratio = report_data.get('lcr_ratio', 0)
        
        # Check 1: Overall LCR
        check_result = self._validate_with_rag(
            check_name="LCR Minimum Requirement",
            value=lcr_ratio,
            query=f"""
            According to {metadata.get('regulator', 'MAS')} liquidity framework,
            what is the minimum Liquidity Coverage Ratio (LCR) requirement?
            
            The bank reports an LCR of {lcr_ratio}%.
            Is this compliant?
            """,
            metadata_filter={
                'category': 'liquidity',
                'regulator': metadata.get('regulator', 'MAS')
            }
        )
        checks.append(check_result)
        
        # Check 2: HQLA Composition
        if 'high_quality_liquid_assets' in report_data:
            hqla = report_data['high_quality_liquid_assets']
            check_result = self._validate_with_rag(
                check_name="HQLA Composition Limits",
                value=None,
                query=f"""
                According to {metadata.get('regulator', 'MAS')} liquidity rules,
                verify if the HQLA composition meets regulatory limits:
                
                {json.dumps(hqla, indent=2)}
                
                Check:
                1. Are Level 2 assets within 40% cap?
                2. Are Level 2B assets within 15% cap?
                3. Are haircuts correctly applied?
                """,
                metadata_filter={
                    'category': 'liquidity',
                    'regulator': metadata.get('regulator', 'MAS')
                }
            )
            checks.append(check_result)
        
        # Check 3: Currency-specific LCR
        if 'lcr_by_currency' in report_data:
            currencies = report_data['lcr_by_currency']
            check_result = self._validate_with_rag(
                check_name="Currency-Specific LCR Requirements",
                value=None,
                query=f"""
                According to {metadata.get('regulator', 'MAS')} requirements,
                what are the minimum LCR thresholds for significant currencies?
                
                The bank reports:
                {json.dumps(currencies, indent=2)}
                
                Are any currencies below the threshold?
                """,
                metadata_filter={
                    'category': 'liquidity',
                    'regulator': metadata.get('regulator', 'MAS')
                }
            )
            checks.append(check_result)
        
        # Compile summary
        passed = sum(1 for c in checks if c['status'] == 'PASS')
        failed = sum(1 for c in checks if c['status'] == 'FAIL')
        warnings = sum(1 for c in checks if c['status'] == 'WARNING')
        
        overall_status = 'COMPLIANT' if failed == 0 else 'REQUIRES CORRECTION'
        
        return {
            'checks': checks,
            'summary': {
                'total_checks': len(checks),
                'passed': passed,
                'failed': failed,
                'warnings': warnings
            },
            'overall_status': overall_status
        }
    
    def _validate_npa_provisioning(
        self,
        report_data: Dict,
        metadata: Dict
    ) -> Dict[str, any]:
        """Validate NPA classification and provisioning"""
        
        checks = []
        
        # Check provisioning adequacy
        if 'asset_classification' in report_data:
            for asset_type in ['sub_standard_assets', 'doubtful_assets', 'loss_assets']:
                if asset_type in report_data['asset_classification']:
                    asset_data = report_data['asset_classification'][asset_type]
                    
                    check_result = self._validate_with_rag(
                        check_name=f"{asset_type.replace('_', ' ').title()} Provisioning",
                        value=None,
                        query=f"""
                        According to RBI NPA provisioning norms, verify if provisioning is adequate:
                        
                        {json.dumps(asset_data, indent=2)}
                        
                        Check:
                        1. Are provisioning rates correct?
                        2. Is provision_held >= provision_required?
                        3. Any shortfalls?
                        """,
                        metadata_filter={
                            'category': 'credit_risk',
                            'regulator': 'RBI'
                        }
                    )
                    checks.append(check_result)
        
        # Compile summary
        passed = sum(1 for c in checks if c['status'] == 'PASS')
        failed = sum(1 for c in checks if c['status'] == 'FAIL')
        warnings = sum(1 for c in checks if c['status'] == 'WARNING')
        
        overall_status = 'COMPLIANT' if failed == 0 else 'REQUIRES CORRECTION'
        
        return {
            'checks': checks,
            'summary': {
                'total_checks': len(checks),
                'passed': passed,
                'failed': failed,
                'warnings': warnings
            },
            'overall_status': overall_status
        }
    
    def _validate_aml_cft(
        self,
        report_data: Dict,
        metadata: Dict
    ) -> Dict[str, any]:
        """Validate AML/CFT compliance"""
        
        checks = []
        
        # Check STR filing timeliness
        if 'suspicious_transaction_reporting' in report_data:
            str_data = report_data['suspicious_transaction_reporting']
            
            check_result = self._validate_with_rag(
                check_name="STR Filing Timeliness",
                value=None,
                query=f"""
                According to RBI/FATF AML guidelines, what is the deadline for filing
                Suspicious Transaction Reports (STR)?
                
                The bank reports:
                - Total STRs filed: {str_data.get('total_str_filed')}
                - Timely filings: {str_data.get('timely_filings')}
                - Delayed filings: {str_data.get('delayed_filings')}
                
                {json.dumps(str_data.get('delayed_filing_details', []), indent=2)}
                
                Are there any violations? What are the penalties?
                """,
                metadata_filter={
                    'category': 'aml_cft',
                    'regulator': 'RBI'
                }
            )
            checks.append(check_result)
        
        # Check wire transfer information completeness
        if 'wire_transfer_reporting' in report_data:
            wire_data = report_data['wire_transfer_reporting']
            
            check_result = self._validate_with_rag(
                check_name="Wire Transfer Information (Travel Rule)",
                value=None,
                query=f"""
                According to FATF Recommendation 16 (Travel Rule), what information
                must accompany wire transfers?
                
                The bank reports:
                - Transfers with complete originator info: {wire_data.get('originator_info_complete')}
                - Transfers with missing info: {wire_data.get('missing_originator_info')}
                
                Is this compliant?
                """,
                metadata_filter={
                    'category': 'aml_cft',
                    'regulator': 'FATF'
                }
            )
            checks.append(check_result)
        
        # Compile summary
        passed = sum(1 for c in checks if c['status'] == 'PASS')
        failed = sum(1 for c in checks if c['status'] == 'FAIL')
        warnings = sum(1 for c in checks if c['status'] == 'WARNING')
        
        overall_status = 'COMPLIANT' if failed == 0 else 'REQUIRES CORRECTION'
        
        return {
            'checks': checks,
            'summary': {
                'total_checks': len(checks),
                'passed': passed,
                'failed': failed,
                'warnings': warnings
            },
            'overall_status': overall_status
        }
    
    def _validate_forex(
        self,
        report_data: Dict,
        metadata: Dict
    ) -> Dict[str, any]:
        """Validate forex position limits"""
        
        checks = []
        
        # Check net open position limit
        if 'aggregate_position' in report_data:
            agg_pos = report_data['aggregate_position']
            
            check_result = self._validate_with_rag(
                check_name="Net Open Position Limit",
                value=agg_pos.get('as_percent_of_capital'),
                query=f"""
                According to RBI forex guidelines, what is the maximum Net Open Position
                limit as a percentage of capital funds?
                
                The bank reports:
                - Aggregate open position: {agg_pos.get('as_percent_of_capital')}% of capital
                
                Is this within limits?
                """,
                metadata_filter={
                    'category': 'forex',
                    'regulator': 'RBI'
                }
            )
            checks.append(check_result)
        
        # Compile summary
        passed = sum(1 for c in checks if c['status'] == 'PASS')
        failed = sum(1 for c in checks if c['status'] == 'FAIL')
        warnings = sum(1 for c in checks if c['status'] == 'WARNING')
        
        overall_status = 'COMPLIANT' if failed == 0 else 'REQUIRES CORRECTION'
        
        return {
            'checks': checks,
            'summary': {
                'total_checks': len(checks),
                'passed': passed,
                'failed': failed,
                'warnings': warnings
            },
            'overall_status': overall_status
        }
    
    def _generic_validation(
        self,
        report_data: Dict,
        metadata: Dict
    ) -> Dict[str, any]:
        """Generic validation for unknown report types"""
        
        checks = [{
            'check_name': 'Generic Validation',
            'status': 'WARNING',
            'message': f"Unknown report type: {report_data.get('report_type')}. Manual review required.",
            'retrieved_regulation': None
        }]
        
        return {
            'checks': checks,
            'summary': {
                'total_checks': 1,
                'passed': 0,
                'failed': 0,
                'warnings': 1
            },
            'overall_status': 'MANUAL REVIEW REQUIRED'
        }
    
    def _validate_with_rag(
        self,
        check_name: str,
        value: Optional[float],
        query: str,
        metadata_filter: Dict[str, str]
    ) -> Dict[str, any]:
        """
        Perform validation using RAG retrieval and LLM reasoning
        
        Args:
            check_name: Name of the check
            value: Reported value (if applicable)
            query: Validation query for RAG
            metadata_filter: Metadata filters (embedded in query for Vertex AI)
            
        Returns:
            Validation check result
        """
        logger.info(f"\n{'='*70}")
        logger.info(f"Validation Check: {check_name}")
        logger.info(f"{'='*70}")
        logger.info(f"Reported value: {value}")
        logger.info(f"Context filter: {metadata_filter}")
        logger.info(f"Query length: {len(query)} chars")
        
        try:
            # Generate response using RAG
            # Note: Vertex AI RAG Engine doesn't support metadata filtering directly
            # The query should be specific enough to retrieve relevant documents
            rag_response = self.rag_engine.generate_with_rag(
                query=query,
                top_k=5,
                temperature=0.1
            )
            
            response_text = rag_response['response']
            
            logger.info(f"\n✅ Response received:")
            logger.info(f"  Length: {len(response_text)} chars")
            logger.info(f"  Model: {rag_response.get('model')}")
            logger.info(f"  Preview: {response_text[:200]}...")
            
            # Parse response to determine status
            status = 'PASS'
            response_lower = response_text.lower()
            
            if any(word in response_lower for word in [
                'non-compliant', 'violation', 'breach', 'shortfall', 
                'below', 'exceeds limit', 'not compliant', 'fails to meet',
                'does not meet', 'insufficient'
            ]):
                status = 'FAIL'
            elif any(word in response_lower for word in [
                'warning', 'verify', 'review', 'caution', 'should check'
            ]):
                status = 'WARNING'
            elif any(phrase in response_lower for phrase in [
                'no sources', 'cannot answer', 'no relevant', 'not found in'
            ]):
                status = 'ERROR'
                response_text = f"⚠️ RAG retrieval may have failed or found no relevant regulations.\n\n" \
                               f"Possible causes:\n" \
                               f"1. Documents not indexed in RAG corpus\n" \
                               f"2. Query not matching document content\n" \
                               f"3. RAG corpus empty or not accessible\n\n" \
                               f"LLM Response: {response_text}"
            
            logger.info(f"  Determined status: {status}")
            
            return {
                'check_name': check_name,
                'value': value,
                'status': status,
                'message': response_text,
                'retrieved_regulation': rag_response.get('grounding_metadata'),
                'metadata_context': metadata_filter
            }
            
        except Exception as e:
            logger.error(f"❌ Error in RAG validation: {e}", exc_info=True)
            return {
                'check_name': check_name,
                'value': value,
                'status': 'ERROR',
                'message': f"Validation error: {str(e)}\n\nThis may indicate:\n"
                          f"- RAG corpus not properly initialized\n"
                          f"- Documents not imported from GCS\n"
                          f"- Network or authentication issues\n\n"
                          f"Run: python scripts/index_documents.py",
                'retrieved_regulation': None,
                'metadata_context': metadata_filter
            }
    
    def _get_timestamp(self) -> str:
        """Get current timestamp"""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
