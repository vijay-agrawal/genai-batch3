"""
Document processing module for regulatory documents
Handles chunking, metadata extraction, and preprocessing
"""
import re
from typing import List, Dict, Tuple
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DocumentProcessor:
    """Process regulatory documents for RAG indexing"""
    
    def __init__(
        self,
        chunk_size: int = 700,
        chunk_overlap: int = 100,
        max_chunk_size: int = 1000
    ):
        """
        Initialize document processor
        
        Args:
            chunk_size: Target size for each chunk in tokens (approximate)
            chunk_overlap: Number of overlapping tokens between chunks
            max_chunk_size: Maximum chunk size in tokens
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.max_chunk_size = max_chunk_size
        
    def process_document(
        self,
        filepath: Path,
        metadata: Dict[str, str]
    ) -> List[Dict[str, any]]:
        """
        Process a document into chunks with metadata
        
        Args:
            filepath: Path to document file
            metadata: Document-level metadata
            
        Returns:
            List of chunks with content and metadata
        """
        logger.info(f"Processing document: {filepath.name}")
        
        # Read document content
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Extract metadata from content if not provided
        extracted_metadata = self._extract_metadata(content, filepath)
        full_metadata = {**extracted_metadata, **metadata}
        
        # Perform structural chunking
        chunks = self._chunk_document(content, full_metadata)
        
        logger.info(f"  Created {len(chunks)} chunks")
        
        return chunks
    
    def _extract_metadata(
        self,
        content: str,
        filepath: Path
    ) -> Dict[str, str]:
        """
        Extract metadata from document content
        
        Args:
            content: Document text
            filepath: Document file path
            
        Returns:
            Extracted metadata dictionary
        """
        metadata = {}
        
        # Extract regulator from filename or content
        filename = filepath.stem.upper()
        if 'RBI' in filename:
            metadata['regulator'] = 'RBI'
        elif 'MAS' in filename:
            metadata['regulator'] = 'MAS'
        elif 'BIS' in filename or 'BASEL' in filename:
            metadata['regulator'] = 'BIS'
        elif 'FATF' in filename:
            metadata['regulator'] = 'FATF'
        
        # Extract category from filename or content
        if 'CAPITAL' in filename or 'BASEL' in filename:
            metadata['category'] = 'capital_adequacy'
        elif 'LIQUIDITY' in filename or 'LCR' in filename or 'NSFR' in filename:
            metadata['category'] = 'liquidity'
        elif 'NPA' in filename or 'CREDIT' in filename:
            metadata['category'] = 'credit_risk'
        elif 'AML' in filename or 'CFT' in filename or 'FATF' in filename:
            metadata['category'] = 'aml_cft'
        elif 'FOREX' in filename:
            metadata['category'] = 'forex'
        
        # Extract effective date
        date_pattern = r'Effective Date:\s*([A-Za-z]+\s+\d{1,2},\s+\d{4})'
        date_match = re.search(date_pattern, content)
        if date_match:
            metadata['effective_date'] = date_match.group(1)
        
        # Extract report type
        if 'Basel III' in content or 'BASEL III' in content:
            metadata['report_type'] = 'Basel_III'
        elif 'LFAR' in content:
            metadata['report_type'] = 'LFAR'
        elif 'LCR' in content or 'Liquidity Coverage' in content:
            metadata['report_type'] = 'LCR'
        elif 'NSFR' in content:
            metadata['report_type'] = 'NSFR'
        
        return metadata
    
    def _chunk_document(
        self,
        content: str,
        metadata: Dict[str, str]
    ) -> List[Dict[str, any]]:
        """
        Chunk document using hybrid structural + semantic approach
        
        Args:
            content: Full document text
            metadata: Document metadata
            
        Returns:
            List of chunks with metadata
        """
        chunks = []
        
        # Split by major sections (SECTION, PART, RECOMMENDATION, etc.)
        section_pattern = r'(?:^|\n)((?:SECTION|PART|RECOMMENDATION|CHAPTER)\s+\d+[A-Z]?[:.][^\n]+)'
        sections = re.split(section_pattern, content, flags=re.MULTILINE)
        
        # Handle case where no sections found
        if len(sections) == 1:
            sections = self._split_into_paragraphs(content)
            section_headers = [None] * len(sections)
        else:
            # Pair headers with content
            section_headers = [sections[i] if i % 2 == 1 else None 
                             for i in range(len(sections))]
            sections = [sections[i] if i % 2 == 0 else sections[i+1] 
                       for i in range(0, len(sections)-1, 2)]
        
        # Process each section
        for section_idx, (header, section_text) in enumerate(
            zip(section_headers, sections)
        ):
            if not section_text or len(section_text.strip()) < 50:
                continue
            
            # Create section-level metadata
            section_metadata = metadata.copy()
            if header:
                section_metadata['section'] = header.strip()
            
            # Split section into sub-chunks if too large
            section_chunks = self._create_semantic_chunks(
                section_text,
                section_metadata
            )
            
            chunks.extend(section_chunks)
        
        return chunks
    
    def _create_semantic_chunks(
        self,
        text: str,
        metadata: Dict[str, str]
    ) -> List[Dict[str, any]]:
        """
        Create semantic chunks from text with overlap
        
        Args:
            text: Text to chunk
            metadata: Chunk metadata
            
        Returns:
            List of semantic chunks
        """
        # Estimate tokens (rough: 1 token ≈ 4 characters)
        char_per_token = 4
        target_chars = self.chunk_size * char_per_token
        overlap_chars = self.chunk_overlap * char_per_token
        max_chars = self.max_chunk_size * char_per_token
        
        chunks = []
        
        # Split into sentences
        sentences = self._split_sentences(text)
        
        current_chunk = []
        current_length = 0
        
        for sentence in sentences:
            sentence_length = len(sentence)
            
            # If single sentence exceeds max, split it further
            if sentence_length > max_chars:
                if current_chunk:
                    chunks.append({
                        'content': ' '.join(current_chunk),
                        'metadata': metadata.copy()
                    })
                    current_chunk = []
                    current_length = 0
                
                # Split long sentence
                words = sentence.split()
                temp_chunk = []
                temp_length = 0
                
                for word in words:
                    word_length = len(word) + 1
                    if temp_length + word_length > target_chars and temp_chunk:
                        chunks.append({
                            'content': ' '.join(temp_chunk),
                            'metadata': metadata.copy()
                        })
                        # Keep overlap
                        overlap_words = []
                        overlap_length = 0
                        for w in reversed(temp_chunk):
                            if overlap_length < overlap_chars:
                                overlap_words.insert(0, w)
                                overlap_length += len(w) + 1
                            else:
                                break
                        temp_chunk = overlap_words
                        temp_length = overlap_length
                    
                    temp_chunk.append(word)
                    temp_length += word_length
                
                if temp_chunk:
                    current_chunk = temp_chunk
                    current_length = temp_length
                continue
            
            # Check if adding sentence exceeds target
            if current_length + sentence_length > target_chars and current_chunk:
                # Save current chunk
                chunks.append({
                    'content': ' '.join(current_chunk),
                    'metadata': metadata.copy()
                })
                
                # Start new chunk with overlap
                overlap_sentences = []
                overlap_length = 0
                for sent in reversed(current_chunk):
                    if overlap_length < overlap_chars:
                        overlap_sentences.insert(0, sent)
                        overlap_length += len(sent)
                    else:
                        break
                
                current_chunk = overlap_sentences
                current_length = overlap_length
            
            current_chunk.append(sentence)
            current_length += sentence_length
        
        # Add final chunk
        if current_chunk:
            chunks.append({
                'content': ' '.join(current_chunk),
                'metadata': metadata.copy()
            })
        
        return chunks
    
    def _split_sentences(self, text: str) -> List[str]:
        """
        Split text into sentences
        
        Args:
            text: Input text
            
        Returns:
            List of sentences
        """
        # Handle common abbreviations
        text = re.sub(r'(\d+\.\d+)%', r'\1 percent', text)
        text = re.sub(r'([A-Z]\.)([A-Z]\.)', r'\1 \2', text)
        
        # Split on sentence boundaries
        sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z])', text)
        
        # Clean sentences
        sentences = [s.strip() for s in sentences if s.strip()]
        
        return sentences
    
    def _split_into_paragraphs(self, text: str) -> List[str]:
        """
        Split text into paragraphs when no sections found
        
        Args:
            text: Input text
            
        Returns:
            List of paragraphs
        """
        paragraphs = re.split(r'\n\s*\n', text)
        return [p.strip() for p in paragraphs if p.strip()]


def extract_report_metadata(report_data: Dict) -> Dict[str, str]:
    """
    Extract metadata from report submission for validation
    
    Args:
        report_data: Report JSON data
        
    Returns:
        Metadata dictionary for RAG filtering
    """
    metadata = {}
    
    # Extract report type
    report_type = report_data.get('report_type', '')
    if 'Basel' in report_type or 'Capital' in report_type:
        metadata['report_type'] = 'Basel_III'
        metadata['category'] = 'capital_adequacy'
    elif 'Liquidity' in report_type or 'LCR' in report_type:
        metadata['report_type'] = 'LCR'
        metadata['category'] = 'liquidity'
    elif 'NPA' in report_type or 'Provisioning' in report_type:
        metadata['category'] = 'credit_risk'
    elif 'AML' in report_type or 'CFT' in report_type:
        metadata['category'] = 'aml_cft'
    elif 'Forex' in report_type:
        metadata['category'] = 'forex'
    
    # Extract bank location to infer regulator
    bank_name = report_data.get('bank_name', '')
    if 'India' in bank_name:
        metadata['regulator'] = 'RBI'
    elif 'Singapore' in bank_name:
        metadata['regulator'] = 'MAS'
    
    return metadata
