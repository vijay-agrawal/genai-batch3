import pandas as pd
import numpy as np
import io
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, roc_curve, auc

# ==========================================
# PHASE 1: Data Ingestion
# ==========================================
print("--- PHASE 1: LOADING DATA ---")

df = pd.read_csv('loan_data_mlready.csv')

print(f"Data Loaded. Shape: {df.shape}")
print(df[['applicant_id', 'monthly_income', 'loan_approved']].head(3))

# ==========================================
# PHASE 2: Feature Selection & Setup
# ==========================================
print("\n--- PHASE 2: FEATURE SELECTION ---")

# Even though features are engineered, we must drop:
# 1. ID columns (applicant_id)
# 2. Spurious correlations (shoe_size, hobby, color) - Noise
# 3. Categorical strings that we already have encoded versions of (education, city, etc)
# 4. Redundant columns (monthly_income vs monthly_income_log)

features_to_drop = [
    'applicant_id', 'education', 'hobby', 'favorite_color', 
    'preferred_cuisine', 'blood_group', 'shoe_size', 'age_group', 
    'income_category', 'credit_category', 'loan_size', 
    'monthly_income', 'loan_amount', 'co_applicant_income' # Dropping raw values in favor of logs/scaled
]

df_clean = df.drop(columns=features_to_drop)

# Convert Target 'Yes'/'No' to 1/0
df_clean['loan_approved'] = df_clean['loan_approved'].map({'Yes': 1, 'No': 0})

print("Irrelevant features dropped.")
print(f"Remaining Features: {df_clean.columns.tolist()[:5]}...")

# Separate X (Features) and y (Target)
X = df_clean.drop('loan_approved', axis=1)
y = df_clean['loan_approved']

# ==========================================
# PHASE 3: Train / Test Split
# ==========================================
print("\n--- PHASE 3: TRAIN/TEST SPLIT ---")

# 80% for training the model, 20% for testing its performance
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print(f"Training Data: {X_train.shape[0]} rows")
print(f"Testing Data:  {X_test.shape[0]} rows")

# ==========================================
# PHASE 4: Algorithm Selection & Comparison
# ==========================================
print("\n--- PHASE 4: ALGORITHM SELECTION ---")

# We will try three different approaches
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "Random Forest": RandomForestClassifier(random_state=42),
    "Gradient Boosting": GradientBoostingClassifier(random_state=42)
}

results = {}

for name, model in models.items():
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    results[name] = acc
    print(f"{name} Accuracy: {acc:.4f}")

# Visualization of Model Comparison
plt.figure(figsize=(8, 4))
plt.bar(results.keys(), results.values(), color=['blue', 'green', 'orange'])
plt.title('Model Accuracy Comparison')
plt.ylim(0, 1.1)
plt.show()

from sklearn.metrics import f1_score, roc_curve, auc

print("\n--- PHASE 5: HYPERPARAMETER TUNING & COMPARISON ---")

# 1. Train Base Model (Default Parameters)
base_rf = RandomForestClassifier(random_state=42)
base_rf.fit(X_train, y_train)
base_preds = base_rf.predict(X_test)
base_probs = base_rf.predict_proba(X_test)[:, 1]

# 2. Hyperparameter Tuning (Finding the Best Parameters)
# We expand the grid slightly to force a search for better 'fit'
param_grid = {
    'n_estimators': [10, 50, 100],
    'max_depth': [3, 5, 10, None],
    'min_samples_split': [2, 5, 10]
}

grid_search = GridSearchCV(estimator=RandomForestClassifier(random_state=42),
                           param_grid=param_grid,
                           cv=3, verbose=0)
grid_search.fit(X_train, y_train)

best_model = grid_search.best_estimator_
tuned_preds = best_model.predict(X_test)
tuned_probs = best_model.predict_proba(X_test)[:, 1]

print(f"Best Parameters: {grid_search.best_params_}")

# ==========================================
# VISUALIZATION OF IMPROVEMENTS
# ==========================================

# Setup the figure for 3 different plots
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# --- PLOT 1: Accuracy & F1-Score Comparison ---
metrics = ['Accuracy', 'F1-Score']
base_scores = [accuracy_score(y_test, base_preds), f1_score(y_test, base_preds)]
tuned_scores = [accuracy_score(y_test, tuned_preds), f1_score(y_test, tuned_preds)]

x = np.arange(len(metrics))
width = 0.35

axes[0].bar(x - width/2, base_scores, width, label='Base Model', color='lightgray')
axes[0].bar(x + width/2, tuned_scores, width, label='Tuned Model', color='#4c72b0')
axes[0].set_ylabel('Score')
axes[0].set_title('Metric Comparison')
axes[0].set_xticks(x)
axes[0].set_xticklabels(metrics)
axes[0].legend()
axes[0].set_ylim(0, 1.1)

# --- PLOT 2: ROC Curve Comparison ---
# Calculate False Positive Rate (fpr) and True Positive Rate (tpr)
fpr_base, tpr_base, _ = roc_curve(y_test, base_probs)
roc_auc_base = auc(fpr_base, tpr_base)

fpr_tuned, tpr_tuned, _ = roc_curve(y_test, tuned_probs)
roc_auc_tuned = auc(fpr_tuned, tpr_tuned)

axes[1].plot(fpr_base, tpr_base, color='gray', linestyle='--', label=f'Base (AUC = {roc_auc_base:.2f})')
axes[1].plot(fpr_tuned, tpr_tuned, color='blue', linewidth=2, label=f'Tuned (AUC = {roc_auc_tuned:.2f})')
axes[1].plot([0, 1], [0, 1], color='red', linestyle=':', alpha=0.5) # Random guess line
axes[1].set_xlabel('False Positive Rate')
axes[1].set_ylabel('True Positive Rate')
axes[1].set_title('ROC Curve Improvement')
axes[1].legend(loc="lower right")

# --- PLOT 3: Confusion Matrix Delta ---
# We visualize the Tuned Matrix, but subtract the Base Matrix to see changes if desired
# Here we just show the Tuned Matrix for clarity on final result
cm = confusion_matrix(y_test, tuned_preds)
sns.heatmap(cm, annot=True, fmt='d', cmap='Greens', ax=axes[2],
            xticklabels=['Rejected', 'Approved'], yticklabels=['Rejected', 'Approved'])
axes[2].set_title('Final Confusion Matrix (Tuned)')
axes[2].set_ylabel('Actual')
axes[2].set_xlabel('Predicted')

plt.tight_layout()
plt.show()


# ==========================================
# PHASE 7: Interpretability (Feature Importance)
# ==========================================
print("\n--- PHASE 7: EXPLAINABILITY ---")
# Which features drove the decision?

feature_imp = pd.Series(best_model.feature_importances_, index=X.columns).sort_values(ascending=False).head(10)

plt.figure(figsize=(10, 6))
sns.barplot(x=feature_imp, y=feature_imp.index, hue=feature_imp.index, legend=False)
plt.title("Top 10 Factors Influencing Loan Approval")
plt.xlabel("Importance Score")
plt.show()

print("Demo Complete.")