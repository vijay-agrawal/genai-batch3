import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder, StandardScaler
import warnings
warnings.filterwarnings('ignore')

# Set visualization style
sns.set_style('whitegrid')
plt.rcParams['figure.figsize'] = (12, 6)

# Enable inline plotting for Jupyter Notebooks
# %matplotlib inline

def pause_and_continue(step_name):
    """Pause execution and wait for user input"""
    print(f"\n{'='*80}")
    print(f"✓ COMPLETED: {step_name}")
    print(f"{'='*80}")
    input("\n⏸️  Press ENTER to continue to the next step...")
    print("\n")

print("="*80)
print("COMPREHENSIVE EDA FOR INDIAN LOAN APPROVAL DATA")
print("="*80)

# Load the dataset
df = pd.read_csv('indian_loan_approval_data_messy.csv')

print(f"\n{'='*80}")
print("1. DATASET OVERVIEW")
print(f"{'='*80}")
print(f"\nShape: {df.shape}")
print(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")
print("\nColumn Names and Types:")
print(df.dtypes)
print("\nFirst 5 rows:")
print(df.head())

pause_and_continue("Dataset Overview")

# ============================================================================
# 2. MISSING VALUE ANALYSIS
# ============================================================================
print(f"\n{'='*80}")
print("2. MISSING VALUE ANALYSIS")
print(f"{'='*80}")

missing_counts = df.isnull().sum()
missing_percentage = (df.isnull().sum() / len(df)) * 100
missing_df = pd.DataFrame({
    'Missing_Count': missing_counts,
    'Percentage': missing_percentage
})
missing_df = missing_df[missing_df['Missing_Count'] > 0].sort_values('Percentage', ascending=False)

print("\nMissing Values Summary:")
print(missing_df)

# Visualize missing values
plt.figure(figsize=(14, 6))
missing_df['Percentage'].plot(kind='bar', color='coral')
plt.title('Missing Values by Feature (%)', fontsize=14, fontweight='bold')
plt.xlabel('Features')
plt.ylabel('Percentage Missing')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()
print("\n✓ Displayed: Missing values chart")

pause_and_continue("Missing Value Analysis")

# ============================================================================
# 3. DATA CLEANING
# ============================================================================
print(f"\n{'='*80}")
print("3. DATA CLEANING")
print(f"{'='*80}")

# Create a copy for cleaning
df_clean = df.copy()

# Handle monthly_income - extract numeric value from different formats
def clean_income(value):
    if pd.isna(value) or value in ['N/A', 'NA', 'null', '', None]:
        return np.nan
    value = str(value)
    # Remove currency symbols and text
    value = value.replace('Rs', '').replace('INR', '').replace('₹', '').strip()
    try:
        return float(value)
    except:
        return np.nan

df_clean['monthly_income'] = df_clean['monthly_income'].apply(clean_income)
print("\n✓ Cleaned monthly_income column")

# Replace various missing value representations with np.nan
missing_values = ['N/A', 'NA', 'null', '', 'None', None]
df_clean = df_clean.replace(missing_values, np.nan)
print("✓ Standardized missing value representations")

# Handle missing values in numerical columns with median
numerical_cols = ['age', 'monthly_income', 'dependents', 'credit_score', 
                  'loan_amount', 'loan_term', 'proposed_emi', 'existing_emi',
                  'debt_to_income_ratio', 'co_applicant_income', 'shoe_size']

for col in numerical_cols:
    if col in df_clean.columns:
        median_val = df_clean[col].median()
        df_clean[col].fillna(median_val, inplace=True)
        print(f"✓ Filled {col} with median: {median_val:.2f}")

# Handle missing values in categorical columns with mode
categorical_cols = ['gender', 'education', 'occupation', 'city', 'property_area',
                    'loan_purpose', 'co_applicant', 'hobby', 'favorite_color',
                    'preferred_cuisine', 'blood_group']

for col in categorical_cols:
    if col in df_clean.columns:
        mode_val = df_clean[col].mode()[0] if not df_clean[col].mode().empty else 'Unknown'
        df_clean[col].fillna(mode_val, inplace=True)
        print(f"✓ Filled {col} with mode: {mode_val}")

print(f"\nMissing values after cleaning: {df_clean.isnull().sum().sum()}")

pause_and_continue("Data Cleaning")

# ============================================================================
# 4. STATISTICAL SUMMARY
# ============================================================================
print(f"\n{'='*80}")
print("4. STATISTICAL SUMMARY")
print(f"{'='*80}")

print("\nNumerical Features Summary:")
print(df_clean[numerical_cols].describe())

print("\nCategorical Features Summary:")
for col in categorical_cols + ['loan_approved']:
    if col in df_clean.columns:
        print(f"\n{col}:")
        print(df_clean[col].value_counts())

pause_and_continue("Statistical Summary")

# ============================================================================
# 5. TARGET VARIABLE ANALYSIS
# ============================================================================
print(f"\n{'='*80}")
print("5. TARGET VARIABLE ANALYSIS")
print(f"{'='*80}")

approval_counts = df_clean['loan_approved'].value_counts()
approval_percentage = df_clean['loan_approved'].value_counts(normalize=True) * 100

print("\nLoan Approval Distribution:")
print(f"Approved: {approval_counts['Yes']} ({approval_percentage['Yes']:.2f}%)")
print(f"Rejected: {approval_counts['No']} ({approval_percentage['No']:.2f}%)")

# Visualize target distribution
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

approval_counts.plot(kind='bar', ax=axes[0], color=['#2ecc71', '#e74c3c'])
axes[0].set_title('Loan Approval Distribution (Count)', fontsize=12, fontweight='bold')
axes[0].set_xlabel('Loan Status')
axes[0].set_ylabel('Count')
axes[0].set_xticklabels(axes[0].get_xticklabels(), rotation=0)

approval_counts.plot(kind='pie', ax=axes[1], autopct='%1.1f%%', colors=['#2ecc71', '#e74c3c'])
axes[1].set_title('Loan Approval Distribution (%)', fontsize=12, fontweight='bold')
axes[1].set_ylabel('')

plt.tight_layout()
plt.show()
print("\n✓ Displayed: Target distribution chart")

pause_and_continue("Target Variable Analysis")

# ============================================================================
# 6. UNIVARIATE ANALYSIS
# ============================================================================
print(f"\n{'='*80}")
print("6. UNIVARIATE ANALYSIS")
print(f"{'='*80}")

# Distribution of key numerical features
key_numerical = ['age', 'monthly_income', 'credit_score', 'loan_amount', 'debt_to_income_ratio']

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.ravel()

for idx, col in enumerate(key_numerical):
    axes[idx].hist(df_clean[col], bins=50, color='steelblue', edgecolor='black', alpha=0.7)
    axes[idx].set_title(f'Distribution of {col}', fontsize=11, fontweight='bold')
    axes[idx].set_xlabel(col)
    axes[idx].set_ylabel('Frequency')
    axes[idx].grid(alpha=0.3)
    
    # Add mean line
    mean_val = df_clean[col].mean()
    axes[idx].axvline(mean_val, color='red', linestyle='--', linewidth=2, label=f'Mean: {mean_val:.2f}')
    axes[idx].legend()

axes[5].axis('off')

plt.tight_layout()
plt.show()
print("\n✓ Displayed: Univariate numerical distributions")

pause_and_continue("Univariate Analysis")

# ============================================================================
# 7. BINNING / DISCRETIZATION
# ============================================================================
print(f"\n{'='*80}")
print("7. BINNING / DISCRETIZATION")
print(f"{'='*80}")

# Age binning
df_clean['age_group'] = pd.cut(df_clean['age'], 
                                bins=[0, 25, 35, 45, 55, 100],
                                labels=['22-25', '26-35', '36-45', '46-55', '56+'])
print("\n✓ Created age_group bins")
print(df_clean['age_group'].value_counts().sort_index())

# Income binning
df_clean['income_category'] = pd.qcut(df_clean['monthly_income'], 
                                       q=4, 
                                       labels=['Low', 'Medium', 'High', 'Very High'])
print("\n✓ Created income_category bins")
print(df_clean['income_category'].value_counts())

# Credit score binning
df_clean['credit_category'] = pd.cut(df_clean['credit_score'],
                                      bins=[0, 600, 700, 750, 900],
                                      labels=['Poor', 'Fair', 'Good', 'Excellent'])
print("\n✓ Created credit_category bins")
print(df_clean['credit_category'].value_counts())

# Loan amount binning
df_clean['loan_size'] = pd.qcut(df_clean['loan_amount'],
                                 q=3,
                                 labels=['Small', 'Medium', 'Large'])
print("\n✓ Created loan_size bins")
print(df_clean['loan_size'].value_counts())

pause_and_continue("Binning / Discretization")

# ============================================================================
# 8. LOG TRANSFORMATION
# ============================================================================
print(f"\n{'='*80}")
print("8. LOG TRANSFORMATION (for skewed features)")
print(f"{'='*80}")

# Identify skewed features
skewed_features = ['monthly_income', 'loan_amount', 'co_applicant_income']

fig, axes = plt.subplots(len(skewed_features), 2, figsize=(14, 12))

for idx, col in enumerate(skewed_features):
    # Original distribution
    axes[idx, 0].hist(df_clean[col], bins=50, color='orange', edgecolor='black', alpha=0.7)
    axes[idx, 0].set_title(f'Original: {col}', fontsize=11, fontweight='bold')
    axes[idx, 0].set_xlabel(col)
    axes[idx, 0].set_ylabel('Frequency')
    
    # Log transformed distribution
    df_clean[f'{col}_log'] = np.log1p(df_clean[col])
    axes[idx, 1].hist(df_clean[f'{col}_log'], bins=50, color='green', edgecolor='black', alpha=0.7)
    axes[idx, 1].set_title(f'Log Transformed: {col}', fontsize=11, fontweight='bold')
    axes[idx, 1].set_xlabel(f'{col}_log')
    axes[idx, 1].set_ylabel('Frequency')
    
    print(f"\n✓ Created {col}_log transformation")
    print(f"  Original Skewness: {df_clean[col].skew():.3f}")
    print(f"  Log-transformed Skewness: {df_clean[f'{col}_log'].skew():.3f}")

plt.tight_layout()
plt.show()
print("\n✓ Displayed: Log transformations")

pause_and_continue("Log Transformation")

# ============================================================================
# 10. BIVARIATE ANALYSIS
# ============================================================================
print(f"\n{'='*80}")
print("10. BIVARIATE ANALYSIS")
print(f"{'='*80}")

# Key features vs target
key_features = ['credit_score', 'monthly_income', 'debt_to_income_ratio', 
                'age', 'loan_amount']

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.ravel()

for idx, feature in enumerate(key_features):
    df_clean.boxplot(column=feature, by='loan_approved', ax=axes[idx])
    axes[idx].set_title(f'{feature} vs Loan Approval', fontsize=11, fontweight='bold')
    axes[idx].set_xlabel('Loan Approved')
    axes[idx].set_ylabel(feature)
    plt.sca(axes[idx])
    plt.xticks([1, 2], ['No', 'Yes'])

axes[5].axis('off')
plt.suptitle('')
plt.tight_layout()
plt.show()
print("\n✓ Displayed: Bivariate analysis")

pause_and_continue("Bivariate Analysis - Numerical Features")

# Categorical features vs target
categorical_features = ['education', 'occupation', 'property_area', 'income_category']

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
axes = axes.ravel()

for idx, feature in enumerate(categorical_features):
    ct = pd.crosstab(df_clean[feature], df_clean['loan_approved'], normalize='index') * 100
    ct.plot(kind='bar', stacked=True, ax=axes[idx], color=['#e74c3c', '#2ecc71'])
    axes[idx].set_title(f'{feature} vs Loan Approval', fontsize=11, fontweight='bold')
    axes[idx].set_xlabel(feature)
    axes[idx].set_ylabel('Percentage')
    axes[idx].legend(['Rejected', 'Approved'])
    axes[idx].set_xticklabels(axes[idx].get_xticklabels(), rotation=45, ha='right')

plt.tight_layout()
plt.show()
print("✓ Displayed: Categorical bivariate analysis")

pause_and_continue("Bivariate Analysis - Categorical Features")

# ============================================================================
# 11. CORRELATION ANALYSIS
# ============================================================================
print(f"\n{'='*80}")
print("11. CORRELATION ANALYSIS")
print(f"{'='*80}")

# Prepare data for correlation
df_corr = df_clean.copy()

# Encode target variable
df_corr['loan_approved_encoded'] = df_corr['loan_approved'].map({'Yes': 1, 'No': 0})

# Select numerical columns for correlation
numerical_columns = ['age', 'monthly_income', 'dependents', 'credit_score', 
                    'loan_amount', 'loan_term', 'proposed_emi', 'existing_emi',
                    'debt_to_income_ratio', 'co_applicant_income', 'shoe_size',
                    'loan_approved_encoded']

# Calculate correlation matrix
correlation_matrix = df_corr[numerical_columns].corr()

# Plot correlation heatmap
plt.figure(figsize=(14, 12))
mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))
sns.heatmap(correlation_matrix, mask=mask, annot=True, fmt='.2f', 
            cmap='RdYlGn', center=0, square=True, linewidths=1,
            cbar_kws={"shrink": 0.8})
plt.title('Correlation Matrix of Numerical Features', fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.show()
print("\n✓ Displayed: Correlation matrix")

# Correlation with target variable
target_correlation = correlation_matrix['loan_approved_encoded'].sort_values(ascending=False)
print("\nCorrelation with Loan Approval (Target):")
print(target_correlation)

pause_and_continue("Correlation Matrix")

# Visualize correlation with target
plt.figure(figsize=(10, 8))
target_correlation_filtered = target_correlation[target_correlation.index != 'loan_approved_encoded']
colors = ['green' if x > 0 else 'red' for x in target_correlation_filtered.values]
plt.barh(target_correlation_filtered.index, target_correlation_filtered.values, color=colors, alpha=0.7)
plt.xlabel('Correlation Coefficient', fontsize=12)
plt.title('Feature Correlation with Loan Approval', fontsize=14, fontweight='bold')
plt.axvline(x=0, color='black', linestyle='--', linewidth=1)
plt.grid(alpha=0.3, axis='x')
plt.tight_layout()
plt.show()
print("✓ Displayed: Target correlation chart")

pause_and_continue("Target Correlation Analysis")

# ============================================================================
# 12. FEATURE IMPORTANCE - IDENTIFYING IRRELEVANT FEATURES
# ============================================================================
print(f"\n{'='*80}")
print("12. FEATURE IMPORTANCE & DIMENSIONALITY REDUCTION")
print(f"{'='*80}")

# Identify low correlation features (candidates for removal)
low_correlation_threshold = 0.05
low_corr_features = target_correlation_filtered[abs(target_correlation_filtered) < low_correlation_threshold]

print(f"\nFeatures with LOW correlation (|r| < {low_correlation_threshold}) with target:")
print("(These are candidates for dimensionality reduction)\n")
for feature, corr in low_corr_features.items():
    print(f"  {feature:<30} : {corr:>7.4f}")

print(f"\n✓ Identified {len(low_corr_features)} low-importance features")
print(f"✓ These features can be dropped to reduce dimensionality")

# High correlation features
high_correlation_threshold = 0.15
high_corr_features = target_correlation_filtered[abs(target_correlation_filtered) >= high_correlation_threshold]

print(f"\nFeatures with HIGH correlation (|r| >= {high_correlation_threshold}) with target:")
print("(These are important features to keep)\n")
for feature, corr in high_corr_features.items():
    print(f"  {feature:<30} : {corr:>7.4f}")

pause_and_continue("Feature Importance & Dimensionality Reduction")

# ============================================================================
# 13. MULTICOLLINEARITY CHECK
# ============================================================================
print(f"\n{'='*80}")
print("13. MULTICOLLINEARITY CHECK")
print(f"{'='*80}")

# Find highly correlated feature pairs (excluding diagonal and duplicates)
high_corr_pairs = []
for i in range(len(correlation_matrix.columns)):
    for j in range(i+1, len(correlation_matrix.columns)):
        if abs(correlation_matrix.iloc[i, j]) > 0.7:
            high_corr_pairs.append({
                'Feature 1': correlation_matrix.columns[i],
                'Feature 2': correlation_matrix.columns[j],
                'Correlation': correlation_matrix.iloc[i, j]
            })

if high_corr_pairs:
    print("\nHighly Correlated Feature Pairs (|r| > 0.7):")
    print("(Consider removing one from each pair to reduce multicollinearity)\n")
    for pair in high_corr_pairs:
        print(f"  {pair['Feature 1']:<25} <-> {pair['Feature 2']:<25} : {pair['Correlation']:>6.3f}")
else:
    print("\nNo highly correlated feature pairs found (threshold: 0.7)")

pause_and_continue("Multicollinearity Check")

# ============================================================================
# 14. OUTLIER DETECTION
# ============================================================================
print(f"\n{'='*80}")
print("14. OUTLIER DETECTION")
print(f"{'='*80}")

def detect_outliers_iqr(data, column):
    Q1 = data[column].quantile(0.25)
    Q3 = data[column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = data[(data[column] < lower_bound) | (data[column] > upper_bound)]
    return len(outliers), lower_bound, upper_bound

outlier_summary = []
for col in ['monthly_income', 'credit_score', 'loan_amount', 'debt_to_income_ratio']:
    count, lower, upper = detect_outliers_iqr(df_clean, col)
    outlier_summary.append({
        'Feature': col,
        'Outlier_Count': count,
        'Outlier_Percentage': (count / len(df_clean)) * 100,
        'Lower_Bound': lower,
        'Upper_Bound': upper
    })

outlier_df = pd.DataFrame(outlier_summary)
print("\nOutlier Detection Summary (IQR Method):")
print(outlier_df.to_string(index=False))

# Visualize outliers
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
axes = axes.ravel()

for idx, col in enumerate(['monthly_income', 'credit_score', 'loan_amount', 'debt_to_income_ratio']):
    axes[idx].boxplot(df_clean[col], vert=False)
    axes[idx].set_title(f'Outlier Detection: {col}', fontsize=11, fontweight='bold')
    axes[idx].set_xlabel(col)
    axes[idx].grid(alpha=0.3)

plt.tight_layout()
plt.show()
print("\n✓ Displayed: Outlier detection")

pause_and_continue("Outlier Detection")

# ============================================================================
# 15. FEATURE SCALING
# ============================================================================
print(f"\n{'='*80}")
print("15. FEATURE SCALING (Standardization)")
print(f"{'='*80}")

# Select numerical features for scaling
features_to_scale = ['age', 'monthly_income', 'credit_score', 'loan_amount', 
                     'debt_to_income_ratio', 'proposed_emi']

scaler = StandardScaler()
df_scaled = df_clean.copy()
df_scaled[features_to_scale] = scaler.fit_transform(df_clean[features_to_scale])

print("\nFeatures scaled using StandardScaler (mean=0, std=1)")
print("\nBefore Scaling (sample statistics):")
print(df_clean[features_to_scale].describe().loc[['mean', 'std']])
print("\nAfter Scaling:")
print(df_scaled[features_to_scale].describe().loc[['mean', 'std']])

# Visualize before and after scaling
fig, axes = plt.subplots(3, 2, figsize=(14, 12))

for idx, col in enumerate(features_to_scale[:3]):
    # Before scaling
    axes[idx, 0].hist(df_clean[col], bins=50, color='skyblue', edgecolor='black', alpha=0.7)
    axes[idx, 0].set_title(f'Before Scaling: {col}', fontsize=10, fontweight='bold')
    axes[idx, 0].set_xlabel(col)
    axes[idx, 0].set_ylabel('Frequency')
    
    # After scaling
    axes[idx, 1].hist(df_scaled[col], bins=50, color='lightcoral', edgecolor='black', alpha=0.7)
    axes[idx, 1].set_title(f'After Scaling: {col}', fontsize=10, fontweight='bold')
    axes[idx, 1].set_xlabel(f'{col} (scaled)')
    axes[idx, 1].set_ylabel('Frequency')

plt.tight_layout()
plt.show()
print("\n✓ Displayed: Feature scaling comparison")

df_clean = df_scaled.copy()
pause_and_continue("Feature Scaling")

# ============================================================================
# 16. LABEL ENCODING
# ============================================================================
print(f"\n{'='*80}")
print("16. LABEL ENCODING")
print(f"{'='*80}")

df_encoded = df_clean.copy()

# Ordinal encoding for education (Ordinal as education levels have a natural order)
education_order = {'12th Pass': 1, 'Under-Graduate': 2, 'Graduate': 3, 'Post-Graduate': 4}
df_encoded['education_encoded'] = df_encoded['education'].map(education_order)
print("\n✓ Education encoded ordinally:")
print(df_encoded[['education', 'education_encoded']].drop_duplicates().sort_values('education_encoded'))

# Ordinal encoding for credit category
credit_order = {'Poor': 1, 'Fair': 2, 'Good': 3, 'Excellent': 4}
df_encoded['credit_category_encoded'] = df_encoded['credit_category'].map(credit_order)
print("\n✓ Credit category encoded ordinally:")
print(df_encoded[['credit_category', 'credit_category_encoded']].drop_duplicates().sort_values('credit_category_encoded'))

print("\nFinal Data Shape:", df_encoded.shape)
print(df_encoded.head())

df_clean = df_encoded.copy()
pause_and_continue("Label Encoding")

# ============================================================================
# 9. ONE-HOT ENCODING
# ============================================================================
print(f"\n{'='*80}")
print("9. ONE-HOT ENCODING")
print(f"{'='*80}")

# Select categorical columns for encoding
categorical_for_onehot_encoding = ['gender', 'occupation', 'property_area', 
                            'loan_purpose', 'co_applicant', 'city' ]

# Create encoded dataframe
df_onehot_encoded = df_clean.copy()
df_onehot_encoded = pd.get_dummies(df_onehot_encoded, columns=categorical_for_onehot_encoding, prefix=categorical_for_onehot_encoding)

print(f"\n✓ One-hot encoded {len(categorical_for_onehot_encoding)} categorical features")
print(f"Original shape: {df_clean.shape}")
print(f"After encoding: {df_onehot_encoded.shape}")
print(f"New features created: {df_onehot_encoded.shape[1] - df_clean.shape[1]}")

print("\nNew encoded columns (sample):")
new_cols = [col for col in df_onehot_encoded.columns if any(cat in col for cat in categorical_for_onehot_encoding)]
print(new_cols[:15])

df_clean = df_=df_onehot_encoded.copy()
pause_and_continue("One Hot Encoding")


# ============================================================================
# 17. FEATURE ENGINEERING SUMMARY
# ============================================================================
print(f"\n{'='*80}")
print("17. FEATURE ENGINEERING SUMMARY")
print(f"{'='*80}")

print("\nNew Features Created:")
print("  1. age_group - Binned age into categories")
print("  2. income_category - Quartile-based income categories")
print("  3. credit_category - Credit score categories")
print("  4. loan_size - Loan amount categories")
print("  5. monthly_income_log - Log transformation of income")
print("  6. loan_amount_log - Log transformation of loan amount")
print("  7. co_applicant_income_log - Log transformation of co-applicant income")
print("  8. education_encoded - Ordinal encoding of education")
print("  9. credit_category_encoded - Ordinal encoding of credit category")

print(f"\nOriginal features: {df.shape[1]}")
print(f"After feature engineering: {df_encoded.shape[1]}")
print(f"New features added: {df_encoded.shape[1] - df.shape[1]}")

pause_and_continue("Feature Engineering Summary")

# ============================================================================
# 18. FINAL RECOMMENDATIONS
# ============================================================================
print(f"\n{'='*80}")
print("18. RECOMMENDATIONS FOR MODELING")
print(f"{'='*80}")

print("\n🎯 HIGH IMPORTANCE FEATURES (Strong correlation with target):")
for feature, corr in high_corr_features.items():
    print(f"  ✓ {feature:<30} (r = {corr:>6.3f})")

print("\n❌ LOW IMPORTANCE FEATURES (Weak correlation - consider removing):")
for feature, corr in low_corr_features.items():
    print(f"  ✗ {feature:<30} (r = {corr:>6.3f})")

print("\n📊 DATA QUALITY:")
print(f"  • Total records: {len(df_clean)}")
print(f"  • Missing values handled: Yes")
print(f"  • Outliers detected: Yes")
print(f"  • Features scaled: Yes")
print(f"  • Categorical encoding: Yes (One-hot & Label)")

print("\n💡 NEXT STEPS:")
print("  1. Remove irrelevant features (hobby, favorite_color, blood_group, shoe_size, preferred_cuisine)")
print("  2. Handle multicollinearity (remove one from highly correlated pairs)")
print("  3. Consider feature selection using: RFE, Feature Importance, or SelectKBest")
print("  4. Use scaled features for distance-based algorithms (KNN, SVM)")
print("  5. Use one-hot encoded features for tree-based models")
print("  6. Address class imbalance if needed")

pause_and_continue("Recommendations for Modeling")

# ============================================================================
# 19. SAVE PROCESSED DATA
# ============================================================================
print(f"\n{'='*80}")
print("19. SAVING PROCESSED DATA")
print(f"{'='*80}")

# Save cleaned data
df_clean.to_csv('loan_data_mlready.csv', index=False)
print("\n✓ Saved: loan_data_mlready.csv")

pause_and_continue("Saved Processed Data")

print("\n✅ All EDA tasks completed successfully!")
print("="*80)

print("\n📊 Summary of Visualizations Displayed:")
print("  1. Missing values by feature")
print("  2. Target distribution (bar + pie)")
print("  3. Univariate numerical distributions")
print("  4. Log transformations")
print("  5. Bivariate analysis (numerical vs target)")
print("  6. Categorical bivariate analysis")
print("  7. Correlation matrix heatmap")
print("  8. Target correlation bar chart")
print("  9. Outlier detection boxplots")
print("  10. Feature scaling comparison")

print("\n📁 Processed Dataset Saved:")
print("  - loan_data_mlready.csv")