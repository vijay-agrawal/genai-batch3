import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import re

# Load synthetic healthcare data from JSON
json_file = "eda/set3/patient_admission_data.json"
with open(json_file, "r") as f:
    raw = json.load(f)

print(f"Loaded {len(raw)} records from {json_file}\n")
# ==============================================================================
# STEP 1: NORMALIZE - Flatten Nested Objects into Tabular Form
# ==============================================================================
# "Normalize" in pandas.json_normalize() means converting hierarchical/nested
# objects into a flat dataframe where dot-notation column names represent paths.
# 
# Original structure (nested):
#   {"patient": {"id": "P123", "age": 45}, "vitals": {"bp": {"systolic": 120}}}
#
# After normalization (flat):
#   patient.id | patient.age | vitals.bp.systolic
#   P123       | 45          | 120
#
# This creates one row per top-level record (one row per patient encounter).

base = pd.json_normalize(raw, sep=".")
base = base.rename(columns={
    "patient.id":"patient_id",
    "encounter.encounter_id":"encounter_id"
})

# Select relevant clinical and encounter columns
base_cols = [
    "patient_id","encounter_id",
    "patient.age","patient.gender",
    "encounter.facility","encounter.reason",
    "encounter.admit_ts","encounter.discharge_ts",
    "vitals.bp.systolic","vitals.bp.diastolic","vitals.pulse","vitals.temperature_c",
    "claim.amount_usd",
    "note.text"
]
df = base[base_cols].copy()


#Compute note length distribution, boilerplate %, repetition ratio + missing text handling

notes = df[["patient_id","encounter_id","encounter.facility","note.text"]].copy()
notes["note.text"] = notes["note.text"].fillna("")  # missing text handling

def token_count(s: str) -> int:
    return len(re.findall(r"\w+", s or ""))

def repetition_ratio(s: str) -> float:
    toks = re.findall(r"\w+", (s or "").lower())
    if not toks:
        return 1.0
    return 1 - (len(set(toks)) / len(toks))

notes["token_count"] = notes["note.text"].apply(token_count)
notes["is_empty_or_short"] = notes["token_count"] < 15

notes["boilerplate_like"] = (
    notes["note.text"].str.contains(r"\bHPI:\b", regex=True, na=False) &
    notes["note.text"].str.contains(r"\bAssessment:\b", regex=True, na=False) &
    notes["note.text"].str.contains(r"\bPlan:\b", regex=True, na=False)
)

notes["repetition_ratio"] = notes["note.text"].apply(repetition_ratio)
notes["high_repetition"] = notes["repetition_ratio"] > 0.55

print("Text quality rates (%):")
print((notes[["is_empty_or_short","boilerplate_like","high_repetition"]].mean()*100).round(2))

plt.figure()
notes["token_count"].hist(bins=40)
plt.title("Clinical Note Length Distribution (tokens)")
plt.xlabel("token_count"); plt.ylabel("count")
plt.show()

# Facility segmentation for text quality
text_by_fac = notes.groupby("encounter.facility")[["is_empty_or_short","boilerplate_like","high_repetition"]].mean().mul(100).round(2)
print("\nText quality by facility (%):\n", text_by_fac)
