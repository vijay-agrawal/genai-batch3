import json
import pandas as pd
import numpy as np

# ==============================================================================
# SCRIPT: Normalize Nested JSON → Extract Clinical Insights
# ==============================================================================
# This script demonstrates how to transform nested JSON healthcare records into
# analytics-ready tables by:
#   1. Normalizing (flattening) nested objects into a flat table
#   2. Exploding (unnesting) arrays into child records
#   3. Aggregating to compute condition prevalence and per-patient derived features
# ==============================================================================

# Load synthetic healthcare data from JSON
json_file = "eda/set3/patient_admission_data.json"
with open(json_file, "r") as f:
    raw = json.load(f)

print(f"Loaded {len(raw)} records from {json_file}\n")

# ==============================================================================
# STEP 1: NORMALIZE - Flatten Nested Objects into Tabular Form
# ==============================================================================
# "Normalize" in pandas.json_normalize() means converting hierarchical/nested
# objects into a flat dataframe where dot-notation column names represent paths.
# 
# Original structure (nested):
#   {"patient": {"id": "P123", "age": 45}, "vitals": {"bp": {"systolic": 120}}}
#
# After normalization (flat):
#   patient.id | patient.age | vitals.bp.systolic
#   P123       | 45          | 120
#
# This creates one row per top-level record (one row per patient encounter).

base = pd.json_normalize(raw, sep=".")
base = base.rename(columns={
    "patient.id":"patient_id",
    "encounter.encounter_id":"encounter_id"
})

# Select relevant clinical and encounter columns
base_cols = [
    "patient_id","encounter_id",
    "patient.age","patient.gender",
    "encounter.facility","encounter.reason",
    "encounter.admit_ts","encounter.discharge_ts",
    "vitals.bp.systolic","vitals.bp.diastolic","vitals.pulse","vitals.temperature_c",
    "claim.amount_usd",
    "note.text"
]
df = base[base_cols].copy()

# ==============================================================================
# STEP 2: EXPLODE - Convert Nested Arrays into Child Table
# ==============================================================================
# Conditions are stored as an array within each patient record:
#   "conditions": [{"code": "I10", "onset": "2025-06-15"}, {...}]
#
# Exploding creates one row per array element, preserving parent context (patient_id).
# This transforms from 1-to-Many relationships into a normalized child table.
#
# Before (nested array):
#   patient_id | conditions: [{"code": "I10"}, {"code": "E11.9"}]
#
# After (exploded):
#   patient_id | code    | onset
#   P001       | I10     | 2025-06-15
#   P001       | E11.9   | 2025-08-20

conditions = pd.json_normalize(
    raw,
    record_path=["conditions"],  # Navigate into conditions array
    meta=[["patient","id"], ["encounter","encounter_id"], ["encounter","facility"]],  # Preserve parent context
    errors="ignore"  # Skip records with missing conditions array
).rename(columns={"patient.id":"patient_id","encounter.encounter_id":"encounter_id","encounter.facility":"facility"})

print("conditions shape:", conditions.shape)
print(conditions.head())

# ==============================================================================
# STEP 3: AGGREGATION - Compute Condition Prevalence & Per-Patient Derived Features
# ==============================================================================

# 3a) CONDITION PREVALENCE: What are the most common diagnoses?
# Shows which ICD-10 codes appear most frequently across all patient encounters
top_icd = conditions["code"].value_counts(dropna=False).head(10)
print("\nTop ICD codes (Condition Prevalence):\n", top_icd)

# 3b) PER-PATIENT AGGREGATION: Derived Features from Conditions Array
# Computes three key features per patient:
#   - n_conditions: Total number of diagnosed conditions (comorbidity burden)
#   - has_htn: Boolean flag for Hypertension (ICD-10: I10)
#   - has_diabetes: Boolean flag for Diabetes Mellitus (ICD-10: E11.9)
#
# These flags are "chronic condition indicators" - useful for risk stratification,
# clinical cohort definition, and predictive modeling.

cond_agg = conditions.groupby("patient_id").agg(
    n_conditions=("code","count"),  # Count total conditions per patient
    has_htn=("code", lambda s: (s=="I10").any()),  # Flag: HTN present?
    has_diabetes=("code", lambda s: (s=="E11.9").any()),  # Flag: Diabetes present?
).reset_index()

# 3c) MERGE DERIVED FEATURES INTO MAIN TABLE
# Join aggregated condition features back to patient encounter table
df = df.merge(cond_agg, how="left", on="patient_id")

# Handle missing values (patients with no conditions)
df["n_conditions"] = df["n_conditions"].fillna(0).astype(int)
df[["has_htn","has_diabetes"]] = df[["has_htn","has_diabetes"]].fillna(False)

# Display final analytics-ready features
print("\nPer-Patient Derived Features (Chronic Condition Flags):")
print(df[["patient_id","n_conditions","has_htn","has_diabetes"]].head())
