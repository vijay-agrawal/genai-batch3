import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load synthetic healthcare data from JSON
json_file = "eda/set3/patient_admission_data.json"
with open(json_file, "r") as f:
    raw = json.load(f)

print(f"Loaded {len(raw)} records from {json_file}\n")
# ==============================================================================
# STEP 1: NORMALIZE - Flatten Nested Objects into Tabular Form
# ==============================================================================
# "Normalize" in pandas.json_normalize() means converting hierarchical/nested
# objects into a flat dataframe where dot-notation column names represent paths.
# 
# Original structure (nested):
#   {"patient": {"id": "P123", "age": 45}, "vitals": {"bp": {"systolic": 120}}}
#
# After normalization (flat):
#   patient.id | patient.age | vitals.bp.systolic
#   P123       | 45          | 120
#
# This creates one row per top-level record (one row per patient encounter).

base = pd.json_normalize(raw, sep=".")
base = base.rename(columns={
    "patient.id":"patient_id",
    "encounter.encounter_id":"encounter_id"
})

# Select relevant clinical and encounter columns
base_cols = [
    "patient_id","encounter_id",
    "patient.age","patient.gender",
    "encounter.facility","encounter.reason",
    "encounter.admit_ts","encounter.discharge_ts",
    "vitals.bp.systolic","vitals.bp.diastolic","vitals.pulse","vitals.temperature_c",
    "claim.amount_usd",
    "note.text"
]
df = base[base_cols].copy()

# Type cleaning: Convert vitals and claims to numeric
df["bp_sys"] = pd.to_numeric(df["vitals.bp.systolic"], errors="coerce")
df["bp_dia"] = pd.to_numeric(df["vitals.bp.diastolic"], errors="coerce")
df["pulse"] = pd.to_numeric(df["vitals.pulse"], errors="coerce")
df["temp_c"] = pd.to_numeric(df["vitals.temperature_c"], errors="coerce")
df["claim_amount"] = pd.to_numeric(df["claim.amount_usd"], errors="coerce")

# Extract conditions and compute per-patient features
conditions = pd.json_normalize(
    raw,
    record_path=["conditions"],
    meta=[["patient","id"], ["encounter","encounter_id"]],
    errors="ignore"
).rename(columns={"patient.id":"patient_id","encounter.encounter_id":"encounter_id"})

# Per-patient condition aggregation
cond_agg = conditions.groupby("patient_id").agg(
    n_conditions=("code","count"),
    has_htn=("code", lambda s: (s=="I10").any()),
    has_diabetes=("code", lambda s: (s=="E11.9").any()),
).reset_index()

# Merge conditions back to main dataframe
df = df.merge(cond_agg, how="left", left_on="patient_id", right_on="patient_id")
df["n_conditions"] = df["n_conditions"].fillna(0).astype(int)
df[["has_htn","has_diabetes"]] = df[["has_htn","has_diabetes"]].fillna(False)

# Parse timestamps + LOS
df["admit_dt"] = pd.to_datetime(df["encounter.admit_ts"], errors="coerce")
df["discharge_dt"] = pd.to_datetime(df["encounter.discharge_ts"], errors="coerce")
df["los_hours"] = (df["discharge_dt"] - df["admit_dt"]).dt.total_seconds() / 3600.0

# Remove impossible negative LOS (data quality rule)
df["los_invalid"] = df["los_hours"].notna() & (df["los_hours"] < 0)
print("Invalid LOS count:", df["los_invalid"].sum())
df.loc[df["los_invalid"], "los_hours"] = np.nan

# Cross-field summaries
print(df[["patient.age","bp_sys","los_hours","n_conditions","claim_amount"]].describe(percentiles=[.05,.5,.95]).T)

# Group comparison: claims by facility
claims_by_fac = df.groupby("encounter.facility")["claim_amount"].agg(["count","median","mean"]).round(2)
print("\nClaims by facility:\n", claims_by_fac)

# Relationship: BP vs age (correlation)
corr = df[["patient.age","bp_sys","bp_dia","pulse","claim_amount","n_conditions","los_hours"]].corr(numeric_only=True)
print("\nCorrelation (numeric):\n", corr)

# Visualization: BP vs Age
tmp = df.dropna(subset=["patient.age","bp_sys"])
plt.figure()
plt.scatter(tmp["patient.age"], tmp["bp_sys"], s=10)
plt.title("BP vs Age (cleaned)")
plt.xlabel("age")
plt.ylabel("bp_sys")
plt.show()
