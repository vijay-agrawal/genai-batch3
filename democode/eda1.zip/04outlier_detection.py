import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load synthetic healthcare data from JSON
json_file = "eda/set3/patient_admission_data.json"
with open(json_file, "r") as f:
    raw = json.load(f)

print(f"Loaded {len(raw)} records from {json_file}\n")
# ==============================================================================
# STEP 1: NORMALIZE - Flatten Nested Objects into Tabular Form
# ==============================================================================
# "Normalize" in pandas.json_normalize() means converting hierarchical/nested
# objects into a flat dataframe where dot-notation column names represent paths.
# 
# Original structure (nested):
#   {"patient": {"id": "P123", "age": 45}, "vitals": {"bp": {"systolic": 120}}}
#
# After normalization (flat):
#   patient.id | patient.age | vitals.bp.systolic
#   P123       | 45          | 120
#
# This creates one row per top-level record (one row per patient encounter).

base = pd.json_normalize(raw, sep=".")
base = base.rename(columns={
    "patient.id":"patient_id",
    "encounter.encounter_id":"encounter_id"
})

# Select relevant clinical and encounter columns
base_cols = [
    "patient_id","encounter_id",
    "patient.age","patient.gender",
    "encounter.facility","encounter.reason",
    "encounter.admit_ts","encounter.discharge_ts",
    "vitals.bp.systolic","vitals.bp.diastolic","vitals.pulse","vitals.temperature_c",
    "claim.amount_usd",
    "note.text"
]
df = base[base_cols].copy()

# Type cleaning: Convert vitals and claims to numeric
df["bp_sys"] = pd.to_numeric(df["vitals.bp.systolic"], errors="coerce")
df["bp_dia"] = pd.to_numeric(df["vitals.bp.diastolic"], errors="coerce")
df["pulse"] = pd.to_numeric(df["vitals.pulse"], errors="coerce")
df["temp_c"] = pd.to_numeric(df["vitals.temperature_c"], errors="coerce")
df["claim_amount"] = pd.to_numeric(df["claim.amount_usd"], errors="coerce")

# Extract conditions and compute per-patient features
conditions = pd.json_normalize(
    raw,
    record_path=["conditions"],
    meta=[["patient","id"], ["encounter","encounter_id"]],
    errors="ignore"
).rename(columns={"patient.id":"patient_id","encounter.encounter_id":"encounter_id"})

# Per-patient condition aggregation
cond_agg = conditions.groupby("patient_id").agg(
    n_conditions=("code","count"),
    has_htn=("code", lambda s: (s=="I10").any()),
    has_diabetes=("code", lambda s: (s=="E11.9").any()),
).reset_index()

# Merge conditions back to main dataframe
df = df.merge(cond_agg, how="left", left_on="patient_id", right_on="patient_id")
df["n_conditions"] = df["n_conditions"].fillna(0).astype(int)
df[["has_htn","has_diabetes"]] = df[["has_htn","has_diabetes"]].fillna(False)

# Compute length of stay (LOS) in hours
df["admit_ts"] = pd.to_datetime(df["encounter.admit_ts"], errors="coerce")
df["discharge_ts"] = pd.to_datetime(df["encounter.discharge_ts"], errors="coerce")
df["los_hours"] = (df["discharge_ts"] - df["admit_ts"]).dt.total_seconds() / 3600.0
# Rule-based outliers (clinical plausibility)
rule_outliers = pd.DataFrame(index=df.index)
rule_outliers["bp_sys_outlier"] = df["bp_sys"].notna() & ~df["bp_sys"].between(70, 250)
rule_outliers["bp_dia_outlier"] = df["bp_dia"].notna() & ~df["bp_dia"].between(40, 150)
rule_outliers["pulse_outlier"] = df["pulse"].notna() & ~df["pulse"].between(30, 220)
rule_outliers["temp_outlier"] = df["temp_c"].notna() & ~df["temp_c"].between(34.0, 43.0)

print("Rule-outlier counts:\n", rule_outliers.sum().sort_values(ascending=False))

# Robust z-score (MAD)
def robust_z(x: pd.Series) -> pd.Series:
    s = pd.to_numeric(x, errors="coerce")
    med = np.nanmedian(s)
    mad = np.nanmedian(np.abs(s - med))
    if mad == 0 or np.isnan(mad):
        return pd.Series([np.nan]*len(s), index=s.index)
    return 0.6745 * (s - med) / mad

df["rz_claim"] = robust_z(df["claim_amount"])
df["rz_bp_sys"] = robust_z(df["bp_sys"])

df["claim_anomaly"] = df["rz_claim"].abs() > 5
df["bp_sys_anomaly"] = df["rz_bp_sys"].abs() > 5

print("Anomaly rates (%):",
      round(df["claim_anomaly"].mean()*100,2),
      round(df["bp_sys_anomaly"].mean()*100,2))

# Triage: show top problematic rows
df["n_rule_fail"] = rule_outliers.sum(axis=1)
triage = df.sort_values(["n_rule_fail","bp_sys_anomaly","claim_anomaly"], ascending=False)
print(triage[["patient_id","encounter_id","encounter.facility","bp_sys","bp_dia","pulse","temp_c","claim_amount",
                "los_hours","n_conditions","n_rule_fail","bp_sys_anomaly","claim_anomaly"]].head(12))

# ==============================================================================
# BOXPLOT VISUALIZATION - Outlier Detection Illustration
# ==============================================================================
# Boxplots show:
#   - Box: 25th-75th percentile (interquartile range, IQR)
#   - Line inside box: Median (50th percentile)
#   - Whiskers: 1.5 * IQR beyond Q1 and Q3
#   - Points beyond whiskers: OUTLIERS (flagged by IQR method)
#
# This complements our robust z-score method for visual comparison

print("\n" + "="*80)
print("BOXPLOT VISUALIZATION - Outlier Detection")
print("="*80)

# 1) Vital Signs Boxplots
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

vital_fields = [
    ("bp_sys", "Systolic BP (mmHg)", 0, 0),
    ("bp_dia", "Diastolic BP (mmHg)", 0, 1),
    ("pulse", "Pulse (bpm)", 1, 0),
    ("temp_c", "Temperature (°C)", 1, 1)
]

for col, title, i, j in vital_fields:
    data = df[col].dropna()
    
    # Create boxplot
    axes[i, j].boxplot(data, vert=True, patch_artist=True,
                       boxprops=dict(facecolor='lightblue', alpha=0.7),
                       medianprops=dict(color='red', linewidth=2),
                       whiskerprops=dict(color='black', linewidth=1.5),
                       flierprops=dict(marker='o', markerfacecolor='red', markersize=6, alpha=0.5))
    
    # Calculate and display IQR boundaries
    Q1 = data.quantile(0.25)
    Q3 = data.quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    
    axes[i, j].set_title(f"{title}\n(Outliers shown as red dots)", fontweight='bold')
    axes[i, j].set_ylabel("Value")
    axes[i, j].grid(axis='y', alpha=0.3)
    
    # Add text annotation with boundaries
    axes[i, j].text(0.5, 0.98, f"IQR=[{Q1:.1f}, {Q3:.1f}] | Bounds=[{lower_bound:.1f}, {upper_bound:.1f}]",
                   transform=axes[i, j].transAxes, fontsize=9,
                   verticalalignment='top', horizontalalignment='center',
                   bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.tight_layout()
plt.show()

# 2) Boxplot by Facility - Highlight Data Quality Differences
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# BP Systolic by Facility
df.boxplot(column='bp_sys', by='encounter.facility', ax=axes[0], patch_artist=True)
axes[0].set_title("Systolic BP Distribution by Facility\n(Box shows IQR, red dots are outliers)", fontweight='bold')
axes[0].set_xlabel("Facility")
axes[0].set_ylabel("Systolic BP (mmHg)")
axes[0].grid(axis='y', alpha=0.3)
plt.sca(axes[0])
plt.xticks(rotation=45)

# Claim Amount by Facility (log scale due to skewness)
df_log_claim = df.copy()
df_log_claim['log_claim'] = np.log1p(df_log_claim['claim_amount'])
df_log_claim.boxplot(column='log_claim', by='encounter.facility', ax=axes[1], patch_artist=True)
axes[1].set_title("Log(Claim Amount) by Facility\n(Log scale handles right skew)", fontweight='bold')
axes[1].set_xlabel("Facility")
axes[1].set_ylabel("log1p(Claim Amount)")
axes[1].grid(axis='y', alpha=0.3)
plt.sca(axes[1])
plt.xticks(rotation=45)

plt.suptitle("Boxplots: Facility-Level Data Quality Comparison", fontsize=13, fontweight='bold', y=1.02)
plt.tight_layout()
plt.show()

# 3) Statistical Summary with Outlier Context
print("\n" + "="*80)
print("OUTLIER STATISTICS BY FIELD")
print("="*80)

for col, title, _, _ in vital_fields:
    data = df[col].dropna()
    Q1 = data.quantile(0.25)
    Q3 = data.quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = ((data < lower) | (data > upper)).sum()
    outlier_pct = (outliers / len(data)) * 100 if len(data) > 0 else 0
    
    print(f"\n{title}:")
    print(f"  Median:        {data.median():.2f}")
    print(f"  IQR:           [{Q1:.2f}, {Q3:.2f}] (width: {IQR:.2f})")
    print(f"  Outlier Range: <{lower:.2f} or >{upper:.2f}")
    print(f"  Outliers:      {outliers} records ({outlier_pct:.2f}%)")
    print(f"  → Boxplot whiskers extend to [{lower:.2f}, {upper:.2f}]")
