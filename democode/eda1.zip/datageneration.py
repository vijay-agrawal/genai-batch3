import json, random, re
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.decomposition import PCA

import matplotlib.pyplot as plt

random.seed(42)
np.random.seed(42)

pd.set_option("display.max_columns", 200)
pd.set_option("display.width", 140)

# ----------------------------
# 0) Synthetic nested JSON generator
# ----------------------------

ICD10 = ["I10", "E11.9", "J45.909", "E78.5", "M54.5", "K21.9", "F32.9"]  # HTN, DM, asthma, etc.
FACILITIES = ["Hospital-A", "Hospital-B", "Clinic-C"]
REASONS = ["Chest pain", "Fever", "Follow-up", "Back pain", "Routine check"]

def rid(prefix, n=6):
    return prefix + "".join(random.choices("0123456789", k=n))

def maybe(val, p=0.08):
    return None if random.random() < p else val

def rand_dt(start_dt, end_dt):
    delta = end_dt - start_dt
    return start_dt + timedelta(seconds=random.randint(0, int(delta.total_seconds())))

def gen_note():
    boilerplate = "HPI: Patient seen today.\nROS: Negative except as noted.\nAssessment: Stable.\nPlan: Follow up.\n"
    variants = [
        "HPI: Fever x 2 days.\nAssessment: Viral fever.\nPlan: Rest, fluids.\n",
        "HPI: Follow-up for hypertension.\nVitals: BP elevated.\nAssessment: HTN uncontrolled.\nPlan: Adjust meds.\n",
        "HPI: Back pain after lifting.\nAssessment: Acute strain.\nPlan: NSAIDs, physiotherapy.\n",
        boilerplate,
        ""  # empty note
    ]
    t = random.choice(variants)
    # inject copy-paste artifact
    if random.random() < 0.25:
        t += "\n---\nPatient denies chest pain, shortness of breath, or palpitations.\n---\n" * random.randint(1,3)
    # inject contact-like strings (demo)
    if random.random() < 0.12:
        t += f"Contact: +91-{random.randint(7000000000, 9999999999)}\n"
    if random.random() < 0.08:
        t += f"Email: patient{random.randint(1,999)}@example.com\n"
    return t.strip()

def generate_records(n=1200, days_back=180):
    now = datetime.now()
    start = now - timedelta(days=days_back)
    recs = []
    for _ in range(n):
        patient_id = rid("P")
        age = int(np.clip(np.random.normal(50, 18), 18, 90))
        gender = random.choice(["M", "F", "O"])

        admit = rand_dt(start, now)
        los_hours = max(2, int(np.random.lognormal(mean=3.0, sigma=0.6)))  # skewed LOS
        discharge = admit + timedelta(hours=los_hours)

        facility = random.choice(FACILITIES)

        # vitals with facility bias (to create insight)
        # Hospital-B slightly higher BP, more missingness to simulate bad source
        sys_base = 120 + (8 if facility == "Hospital-B" else 0)
        dia_base = 80 + (4 if facility == "Hospital-B" else 0)

        systolic = int(np.clip(np.random.normal(sys_base, 18), 60, 260))
        diastolic = int(np.clip(np.random.normal(dia_base, 12), 35, 170))
        pulse = int(np.clip(np.random.normal(85, 20), 30, 220))
        temp_c = round(float(np.clip(np.random.normal(37.0, 0.6), 34.0, 43.0)), 1)

        # inject outliers
        if random.random() < 0.02:
            systolic = random.choice([20, 310, -5])
        if random.random() < 0.02:
            diastolic = random.choice([10, 220, -2])

        # inject type drift
        if random.random() < 0.02:
            systolic = str(systolic)

        # inject missing nested object / missing fields
        vitals = {
            "bp": {"systolic": maybe(systolic, p=0.03 if facility != "Hospital-B" else 0.08),
                   "diastolic": maybe(diastolic, p=0.03 if facility != "Hospital-B" else 0.08)},
            "pulse": maybe(pulse, p=0.04 if facility != "Hospital-B" else 0.10),
            "temperature_c": maybe(temp_c, p=0.04 if facility != "Hospital-B" else 0.10),
        }
        if random.random() < (0.02 if facility != "Hospital-B" else 0.06):
            vitals.pop("bp", None)  # missing nested entry

        # conditions array (some empty)
        n_cond = np.random.choice([0,1,2,3], p=[0.25,0.35,0.25,0.15])
        conditions = []
        for _c in range(n_cond):
            conditions.append({
                "code": random.choice(ICD10),
                "onset": (admit - timedelta(days=random.randint(0, 365))).strftime("%Y-%m-%d")
            })
        # inject malformed code
        if conditions and random.random() < 0.01:
            conditions[0]["code"] = "ICD??"

        # claims
        amount = round(float(np.clip(np.random.lognormal(5.3, 0.7), 20, 6000)), 2)
        if facility == "Clinic-C":
            amount *= 0.8  # lower claims
        amount = maybe(amount, p=0.03)

        # random missing timestamps (time series gaps)
        admit_ts = maybe(admit.isoformat(), p=0.01)
        discharge_ts = maybe(discharge.isoformat(), p=0.01)

        recs.append({
            "patient": {"id": patient_id, "age": age, "gender": maybe(gender, p=0.02)},
            "encounter": {
                "encounter_id": rid("E"),
                "facility": facility,
                "reason": random.choice(REASONS),
                "admit_ts": admit_ts,
                "discharge_ts": discharge_ts,
            },
            "vitals": vitals,
            "conditions": conditions,
            "claim": {"claim_id": rid("C"), "amount_usd": amount},
            "note": {"note_id": rid("N"), "text": gen_note()}
        })
    return recs

raw = generate_records()
print("records:", len(raw))
print(json.dumps(raw[0], indent=2)[:900])

# Save as JSON file
output_file = "eda/set3/patient_admission_data.json"
with open(output_file, "w") as f:
    json.dump(raw, f, indent=2)
print(f"\n✓ Saved {len(raw)} records to {output_file}")

