import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import RobustScaler
from sklearn.decomposition import PCA

# Load synthetic healthcare data from JSON
json_file = "eda/set3/patient_admission_data.json"
with open(json_file, "r") as f:
    raw = json.load(f)

print(f"Loaded {len(raw)} records from {json_file}\n")
# ==============================================================================
# STEP 1: NORMALIZE - Flatten Nested Objects into Tabular Form
# ==============================================================================
# "Normalize" in pandas.json_normalize() means converting hierarchical/nested
# objects into a flat dataframe where dot-notation column names represent paths.
# 
# Original structure (nested):
#   {"patient": {"id": "P123", "age": 45}, "vitals": {"bp": {"systolic": 120}}}
#
# After normalization (flat):
#   patient.id | patient.age | vitals.bp.systolic
#   P123       | 45          | 120
#
# This creates one row per top-level record (one row per patient encounter).

base = pd.json_normalize(raw, sep=".")
base = base.rename(columns={
    "patient.id":"patient_id",
    "encounter.encounter_id":"encounter_id"
})

# Select relevant clinical and encounter columns
base_cols = [
    "patient_id","encounter_id",
    "patient.age","patient.gender",
    "encounter.facility","encounter.reason",
    "encounter.admit_ts","encounter.discharge_ts",
    "vitals.bp.systolic","vitals.bp.diastolic","vitals.pulse","vitals.temperature_c",
    "claim.amount_usd",
    "note.text"
]
df = base[base_cols].copy()

# Convert timestamp columns to datetime
df["admit_ts"] = pd.to_datetime(df["encounter.admit_ts"], errors="coerce")
df["discharge_ts"] = pd.to_datetime(df["encounter.discharge_ts"], errors="coerce")

# Type cleaning: Convert vitals and claims to numeric
df["bp_sys"] = pd.to_numeric(df["vitals.bp.systolic"], errors="coerce")
df["bp_dia"] = pd.to_numeric(df["vitals.bp.diastolic"], errors="coerce")
df["pulse"] = pd.to_numeric(df["vitals.pulse"], errors="coerce")
df["temp_c"] = pd.to_numeric(df["vitals.temperature_c"], errors="coerce")
df["claim_amount"] = pd.to_numeric(df["claim.amount_usd"], errors="coerce")
df["patient_age"] = pd.to_numeric(df["patient.age"], errors="coerce")

# Derive length of stay (hours) from admit and discharge timestamps
df["los_hours"] = (df["discharge_ts"] - df["admit_ts"]).dt.total_seconds() / 3600

# Get unique facilities for later use
FACILITIES = sorted(df["encounter.facility"].unique())

# Create n_conditions feature (synthetic based on age as proxy for comorbidities)
np.random.seed(42)
df["n_conditions"] = np.random.poisson(2, len(df)).clip(0, 5)

# Use PCA to:
# detect clusters (facility patterns)
# find correlated measures (BP/pulse/temp/claim/LOS)
# identify anomalies in low-dimensional space

# Select numeric features
feat = df[["bp_sys","bp_dia","pulse","temp_c","claim_amount","los_hours","patient_age","n_conditions"]].copy()

# Handle missing values:
# Strategy A (simple): median imputation
feat_imp = feat.fillna(feat.median(numeric_only=True))

# Normalize:
# RobustScaler is good with skewed claim_amount and outliers
scaler = RobustScaler()
X = scaler.fit_transform(feat_imp)

# PCA
pca = PCA(n_components=2, random_state=42)
Z = pca.fit_transform(X)

print("Explained variance:", pca.explained_variance_ratio_.round(3), "Total:", round(pca.explained_variance_ratio_.sum(),3))

pca_df = pd.DataFrame(Z, columns=["PC1","PC2"])
pca_df["facility"] = df["encounter.facility"].values

plt.figure()
for fac in FACILITIES:
    sub = pca_df[pca_df["facility"]==fac]
    plt.scatter(sub["PC1"], sub["PC2"], s=10, label=fac)
plt.title("PCA of Cleaned Structured Features (colored by facility)")
plt.xlabel("PC1"); plt.ylabel("PC2")
plt.legend()
plt.show()

# Insight helper: which features drive PC1/PC2?
loadings = pd.DataFrame(pca.components_.T, index=feat_imp.columns, columns=["PC1_loading","PC2_loading"]).round(3)
print("\nPCA Loadings:\n", loadings.sort_values("PC1_loading", key=lambda s: s.abs(), ascending=False))
print("""
## What this chart represents

* This is a **PCA (Principal Component Analysis)** of **cleaned structured features**
* **Each point = one record (e.g., patient / visit / case)**
* **PC1 (x-axis)** and **PC2 (y-axis)** are the top two directions of maximum variance
* Colors indicate **facility**:

  * Clinic-C (blue)
  * Hospital-A (orange)
  * Hospital-B (green)

---

## Key observations

### 1. Strong overlap across facilities

* The **dense central cluster around (PC1 ≈ 0, PC2 ≈ 0)** contains points from **all three facilities**
* This means:

  * The **core data patterns are very similar**
  * No strong facility-specific separation in the main variance directions

**Interpretation:**
Facility alone does **not** explain most of the variance in these structured features.

---

### 2. PC1 does NOT separate facilities

* Along PC1:

  * All facilities spread roughly between **−2 to +2**
  * No facility dominates one side

**PC1 likely captures a common operational or clinical gradient**, e.g.:

* Overall severity
* Utilization intensity
* Aggregated vitals or lab magnitude

---

### 3. PC2 shows mild vertical spread (especially Hospital-B)

* Hospital-B (green) shows:

  * **Higher positive PC2 outliers** (values up to ~10)
* Clinic-C and Hospital-A are more compact vertically

 **Interpretation:**
Hospital-B may have:

* Greater variability in some features
* Occasional extreme cases (complex patients, referrals, ICU cases, etc.)

But this effect is **not strong enough** to form a separate cluster.

---

### 4. Presence of clear outliers

You can see:

* A few points far right (PC1 ≈ 9–10)
* A few far left (PC1 ≈ −6)

 These likely represent:

* Data quality anomalies
* Rare patient profiles
* Edge-case operational scenarios

These should be **investigated**, not ignored.

---

## What this chart is **not** saying (important)

*  It does **not** say facilities are identical
*  It does **not** imply no differences exist

It only says:

> **Facility identity is not the dominant source of variance in the structured data.**

Differences may exist in:

* Higher-order PCs (PC3, PC4…)
* Specific feature distributions
* Conditional subsets (e.g., ICU only, elderly only)

---

## Practical implications (especially for healthcare analytics)

### Modeling

* A **single global model** may work reasonably well
* Facility-specific models may not add much unless:

  * You focus on outlier populations
  * You include interaction terms

### Feature engineering

* Consider:

  * Normalizing or capping extreme contributors to PC2
  * Investigating features driving Hospital-B’s vertical spread

### Data quality checks

* Audit:

  * High PC1 / PC2 points
  * Missing or imputed fields
  * Units or scale mismatches

---

## One-line summary

> **Most patients across Clinic-C, Hospital-A, and Hospital-B look statistically similar in the main dimensions of structured data, with Hospital-B showing slightly higher variability and a few notable outliers.**

""")