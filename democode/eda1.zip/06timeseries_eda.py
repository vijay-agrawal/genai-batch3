import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load synthetic healthcare data from JSON
json_file = "eda/set3/patient_admission_data.json"
with open(json_file, "r") as f:
    raw = json.load(f)

print(f"Loaded {len(raw)} records from {json_file}\n")
# ==============================================================================
# STEP 1: NORMALIZE - Flatten Nested Objects into Tabular Form
# ==============================================================================
# "Normalize" in pandas.json_normalize() means converting hierarchical/nested
# objects into a flat dataframe where dot-notation column names represent paths.
# 
# Original structure (nested):
#   {"patient": {"id": "P123", "age": 45}, "vitals": {"bp": {"systolic": 120}}}
#
# After normalization (flat):
#   patient.id | patient.age | vitals.bp.systolic
#   P123       | 45          | 120
#
# This creates one row per top-level record (one row per patient encounter).

base = pd.json_normalize(raw, sep=".")
base = base.rename(columns={
    "patient.id":"patient_id",
    "encounter.encounter_id":"encounter_id"
})

# Select relevant clinical and encounter columns
base_cols = [
    "patient_id","encounter_id",
    "patient.age","patient.gender",
    "encounter.facility","encounter.reason",
    "encounter.admit_ts","encounter.discharge_ts",
    "vitals.bp.systolic","vitals.bp.diastolic","vitals.pulse","vitals.temperature_c",
    "claim.amount_usd",
    "note.text"
]
df = base[base_cols].copy()

# Convert timestamp columns to datetime
df["admit_ts"] = pd.to_datetime(df["encounter.admit_ts"], errors="coerce")
df["discharge_ts"] = pd.to_datetime(df["encounter.discharge_ts"], errors="coerce")

# Daily encounter volume
ts = df.dropna(subset=["admit_ts"]).copy()
ts["admit_date"] = ts["admit_ts"].dt.date

daily = ts.groupby(["admit_date","encounter.facility"]).size().reset_index(name="encounters")

# Get list of unique facilities
FACILITIES = sorted(ts["encounter.facility"].unique())

# Create a complete date index to expose missing days
full_dates = pd.date_range(ts["admit_ts"].min().date(), ts["admit_ts"].max().date(), freq="D")
full = pd.MultiIndex.from_product([full_dates.date, FACILITIES], names=["admit_date","facility"]).to_frame(index=False)

daily_full = full.merge(daily, how="left", left_on=["admit_date","facility"], right_on=["admit_date","encounter.facility"])
daily_full = daily_full.drop(columns=["encounter.facility"])
daily_full["encounters"] = daily_full["encounters"].fillna(0).astype(int)

print("\nDaily encounter volume (first 10 rows):")
print(daily_full.head(10))

# ==============================================================================
# DEEPER TIMESERIES INSIGHTS
# ==============================================================================

print("\n" + "="*80)
print("TIMESERIES ANALYSIS - FACILITY ADMISSION PATTERNS")
print("="*80)

# 1) OVERALL STATISTICS BY FACILITY
print("\n1. FACILITY-LEVEL STATISTICS:")
fac_stats = daily_full.groupby("facility")["encounters"].agg([
    ('Mean Daily', 'mean'),
    ('Median Daily', 'median'),
    ('Std Dev', 'std'),
    ('Min', 'min'),
    ('Max', 'max'),
    ('Coeff Var', lambda x: x.std() / x.mean())  # Variability measure (lower = more stable)
]).round(3)
print(fac_stats)

# 2) TREND ANALYSIS - Linear Trend Over Time
daily_full["admit_date_dt"] = pd.to_datetime(daily_full["admit_date"])
daily_full["days_since_start"] = (daily_full["admit_date_dt"] - daily_full["admit_date_dt"].min()).dt.days

print("\n2. TREND ANALYSIS (Linear Regression):")
from scipy import stats

for fac in FACILITIES:
    fac_data = daily_full[daily_full["facility"] == fac].copy()
    slope, intercept, r_value, p_value, std_err = stats.linregress(
        fac_data["days_since_start"], 
        fac_data["encounters"]
    )
    trend = "↑ Increasing" if slope > 0 else "↓ Decreasing"
    print(f"  {fac:15} Slope={slope:6.4f} (encounters/day)  R²={r_value**2:.3f}  {trend}")

# 3) SEASONALITY - Weekly Pattern (Day of Week)
ts["day_of_week"] = ts["admit_ts"].dt.day_name()
ts["week_num"] = ts["admit_ts"].dt.isocalendar().week

weekly_pattern = ts.groupby("day_of_week").size()
# Reorder by day of week
day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
weekly_pattern = weekly_pattern.reindex([d for d in day_order if d in weekly_pattern.index])

print("\n3. WEEKLY SEASONALITY PATTERN:")
print("Admissions by day of week:")
print(weekly_pattern)

# 4) VOLATILITY & CONSISTENCY
print("\n4. FACILITY STABILITY METRICS:")
print("Coefficient of Variation (CV): Lower = More Predictable Operations")
stability = daily_full.groupby("facility")["encounters"].agg(
    lambda x: x.std() / x.mean() if x.mean() > 0 else 0
).sort_values()
for fac, cv in stability.items():
    stability_label = "★★★ Very Stable" if cv < 0.3 else "★★ Moderate" if cv < 0.5 else "★ High Volatility"
    print(f"  {fac:15} CV={cv:.3f}  {stability_label}")

# 5) AUTOCORRELATION - Day-to-Day Dependency
print("\n5. AUTOCORRELATION ANALYSIS (Day-to-Day Dependency):")
print("Do high-volume days predict high-volume next days?")
for fac in FACILITIES:
    fac_daily = daily_full[daily_full["facility"] == fac]["encounters"].values
    if len(fac_daily) > 1:
        autocorr = np.corrcoef(fac_daily[:-1], fac_daily[1:])[0, 1]
        dependency = "Strong autocorrelation (planned admissions)" if autocorr > 0.4 else \
                    "Weak autocorrelation (random walk)" if autocorr < 0.2 else "Moderate"
        print(f"  {fac:15} Lag-1 Autocorr={autocorr:.3f}  {dependency}")

# ==============================================================================
# COMPREHENSIVE VISUALIZATION - TIMESERIES DEEP DIVE
# ==============================================================================

fig, axes = plt.subplots(3, 2, figsize=(16, 12))

# Plot 1: Raw Time Series All Facilities
ax = axes[0, 0]
daily_full["admit_date_dt"] = pd.to_datetime(daily_full["admit_date"])
for fac in FACILITIES:
    fac_data = daily_full[daily_full["facility"] == fac]
    ax.plot(fac_data["admit_date_dt"], fac_data["encounters"], label=fac, linewidth=1.5, alpha=0.7)
ax.set_title("Raw Daily Encounter Volume - All Facilities\n(Trend + Noise)", fontweight='bold')
ax.set_xlabel("Date")
ax.set_ylabel("Encounters")
ax.legend()
ax.grid(alpha=0.3)

# Plot 2: Smoothed Trend (7-day Rolling Average)
ax = axes[0, 1]
daily_pivot = daily_full.pivot_table(
    values="encounters", 
    index="admit_date_dt", 
    columns="facility", 
    aggfunc="sum"
)
daily_pivot_smooth = daily_pivot.rolling(window=7, center=True).mean()
for col in daily_pivot_smooth.columns:
    ax.plot(daily_pivot_smooth.index, daily_pivot_smooth[col], label=col, linewidth=2.5)
ax.set_title("7-Day Rolling Average - Underlying Trend\n(Smooths out daily noise)", fontweight='bold')
ax.set_xlabel("Date")
ax.set_ylabel("Avg Encounters (7-day MA)")
ax.legend()
ax.grid(alpha=0.3)

# Plot 3: Weekly Seasonality Heatmap (Facility × Day of Week)
ax = axes[1, 0]
ts_pivot = ts.copy()
ts_pivot["day_num"] = ts_pivot["admit_ts"].dt.dayofweek
ts_pivot["facility"] = ts_pivot["encounter.facility"]
heatmap_data = ts_pivot.groupby(["facility", "day_num"]).size().unstack(fill_value=0)
heatmap_data.columns = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
sns.heatmap(heatmap_data, annot=True, fmt="d", cmap="YlOrRd", ax=ax, cbar_kws={'label': 'Count'})
ax.set_title("Weekly Seasonality: Admissions by Facility × Day\n(Hotter = More Admissions)", fontweight='bold')
ax.set_ylabel("Facility")

# Plot 4: Distribution of Daily Encounters (Boxplot + Histogram)
ax = axes[1, 1]
daily_pivot.boxplot(ax=ax, patch_artist=True)
ax.set_title("Daily Encounter Distribution by Facility\n(Box shows IQR, outliers as points)", fontweight='bold')
ax.set_ylabel("Encounters")
ax.grid(axis='y', alpha=0.3)

# Plot 5: Cumulative Admissions Over Time (Growth Trajectory)
ax = axes[2, 0]
daily_full["admit_date_dt"] = pd.to_datetime(daily_full["admit_date"])
for fac in FACILITIES:
    fac_data = daily_full[daily_full["facility"] == fac].sort_values("admit_date_dt")
    cumsum = fac_data["encounters"].cumsum()
    ax.plot(fac_data["admit_date_dt"], cumsum, label=fac, linewidth=2.5)
ax.set_title("Cumulative Admissions Over Time\n(Slope indicates growth rate)", fontweight='bold')
ax.set_xlabel("Date")
ax.set_ylabel("Cumulative Encounters")
ax.legend()
ax.grid(alpha=0.3)

# Plot 6: Coefficient of Variation by Facility (Stability Scorecard)
ax = axes[2, 1]
cv_scores = daily_full.groupby("facility")["encounters"].apply(
    lambda x: x.std() / x.mean() if x.mean() > 0 else 0
).sort_values(ascending=True)
colors = ['green' if cv < 0.3 else 'orange' if cv < 0.5 else 'red' for cv in cv_scores.values]
cv_scores.plot(kind='barh', ax=ax, color=colors)
ax.set_title("Stability Score: Coefficient of Variation\n(Lower = More Predictable, Green = Excellent)", fontweight='bold')
ax.set_xlabel("Coefficient of Variation")
ax.axvline(0.3, color='green', linestyle='--', alpha=0.5, label='Excellent (<0.3)')
ax.axvline(0.5, color='orange', linestyle='--', alpha=0.5, label='Moderate (0.3-0.5)')
ax.legend(loc='lower right')
ax.grid(axis='x', alpha=0.3)

plt.tight_layout()
plt.show()

# ==============================================================================
# ADMISSION REASON TRENDS
# ==============================================================================

print("\n" + "="*80)
print("ADMISSION REASON ANALYSIS OVER TIME")
print("="*80)

ts["month"] = ts["admit_ts"].dt.to_period("M")
reason_by_month = ts.groupby(["month", "encounter.reason"]).size().unstack(fill_value=0)

print("\nAdmission reasons by month (top 5 reasons):")
top_reasons = ts["encounter.reason"].value_counts().head(5).index
print(reason_by_month[[col for col in reason_by_month.columns if col in top_reasons]])

# Visualize reason trends
fig, ax = plt.subplots(figsize=(14, 6))
reason_by_month[[col for col in reason_by_month.columns if col in top_reasons]].plot(ax=ax, marker='o', linewidth=2)
ax.set_title("Admission Reason Trends Over Time\n(Top 5 reasons tracked monthly)", fontweight='bold')
ax.set_xlabel("Month")
ax.set_ylabel("Count")
ax.legend(title="Reason", bbox_to_anchor=(1.05, 1), loc='upper left')
ax.grid(alpha=0.3)
plt.tight_layout()
plt.show()

print("\n" + "="*80)
print("TIMESERIES ANALYSIS COMPLETE")
print("="*80)


"""
 Facility-Level Statistics

Mean, median, std dev, min/max daily encounters
Coefficient of Variation showing predictability of each facility
2. Trend Analysis

Linear regression to detect if admission volumes are increasing/decreasing over time
R² values showing strength of trend
3. Weekly Seasonality

Day-of-week patterns showing Friday peaks (186 admissions) vs Thursday lows (153)
4. Stability Metrics

Coefficient of Variation comparison across facilities
Identifies which facilities have predictable vs volatile admission patterns
5. Autocorrelation Analysis

Tests if high-volume days predict high-volume next days
Shows all facilities have weak autocorrelation (random walk pattern)
6. Comprehensive Visualizations (6 plots):

Raw time series for all facilities
7-day rolling average trend
Weekly seasonality heatmap (facility × day of week)
Boxplots showing distribution by facility
Cumulative admissions (growth trajectory)
Stability scorecard (coefficient of variation)
7. Admission Reason Trends

Monthly tracking of top 5 admission reasons
Line chart showing seasonal patterns by reason
The analysis reveals that all facilities have similar admission volumes (~2.2 encounters/day), exhibit high volatility (CV > 0.6), and show no strong day-to-day dependency, suggesting admissions follow a random pattern rather than planned scheduling.

"""