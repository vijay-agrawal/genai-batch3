import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load synthetic healthcare data from JSON
json_file = "eda/set3/patient_admission_data.json"
with open(json_file, "r") as f:
    raw = json.load(f)

print(f"Loaded {len(raw)} records from {json_file}\n")
# ==============================================================================
# STEP 1: NORMALIZE - Flatten Nested Objects into Tabular Form
# ==============================================================================
# "Normalize" in pandas.json_normalize() means converting hierarchical/nested
# objects into a flat dataframe where dot-notation column names represent paths.
# 
# Original structure (nested):
#   {"patient": {"id": "P123", "age": 45}, "vitals": {"bp": {"systolic": 120}}}
#
# After normalization (flat):
#   patient.id | patient.age | vitals.bp.systolic
#   P123       | 45          | 120
#
# This creates one row per top-level record (one row per patient encounter).

base = pd.json_normalize(raw, sep=".")
base = base.rename(columns={
    "patient.id":"patient_id",
    "encounter.encounter_id":"encounter_id"
})

# Select relevant clinical and encounter columns
base_cols = [
    "patient_id","encounter_id",
    "patient.age","patient.gender",
    "encounter.facility","encounter.reason",
    "encounter.admit_ts","encounter.discharge_ts",
    "vitals.bp.systolic","vitals.bp.diastolic","vitals.pulse","vitals.temperature_c",
    "claim.amount_usd",
    "note.text"
]
df = base[base_cols].copy()

# Type cleaning + coercion
df["bp_sys"] = pd.to_numeric(df["vitals.bp.systolic"], errors="coerce")
df["bp_dia"] = pd.to_numeric(df["vitals.bp.diastolic"], errors="coerce")
df["pulse"] = pd.to_numeric(df["vitals.pulse"], errors="coerce")
df["temp_c"] = pd.to_numeric(df["vitals.temperature_c"], errors="coerce")
df["claim_amount"] = pd.to_numeric(df["claim.amount_usd"], errors="coerce")

# Basic missingness (helps talk about data quality)
missing = (df[["bp_sys","bp_dia","pulse","temp_c","claim_amount"]].isna().mean()*100).round(2)
print("Missing %:\n", missing)

# Distribution plots (matplotlib only)
plt.figure()
df["bp_sys"].dropna().hist(bins=40)
plt.title("Distribution: Systolic BP (cleaned)")
plt.xlabel("bp_sys")
plt.ylabel("count")
plt.show()

plt.figure()
df["claim_amount"].dropna().hist(bins=40)
plt.title("Distribution: Claim Amount (USD, cleaned)")
plt.xlabel("claim_amount")
plt.ylabel("count")
plt.show()


plt.figure()
np.log1p(df["claim_amount"].dropna()).hist(bins=40)
plt.title("Distribution: log1p(Claim Amount)")
plt.xlabel("log1p(claim_amount)")
plt.ylabel("count")
plt.show()


# ==============================================================================
# DENSITY PLOTS - Probability Density Functions (PDF)
# ==============================================================================
# Density transforms frequency counts into probability per unit value.
# This allows comparison of distributions with different sample sizes.
#
# KEY INSIGHT: Area under density curve = 1 (represents 100% probability)
# This makes it a true Probability Density Function (PDF)
#
# Use cases:
#   1. Compare distributions across subgroups (e.g., facilities)
#   2. Identify skewness and multimodality
#   3. Normalize for group size differences

print("\n" + "="*80)
print("DENSITY ANALYSIS - Probability Distributions")
print("="*80)

# 1) Systolic BP Density: Facility Comparison
plt.figure(figsize=(10, 6))

# Extract data by facility
facilities = df["encounter.facility"].unique()
for facility in facilities:
    facility_data = df[df["encounter.facility"] == facility]["bp_sys"].dropna()
    if len(facility_data) > 0:
        # Plot density: area under curve = 1 (probability)
        facility_data.plot.density(label=facility, linewidth=2)

plt.title("Systolic BP Density by Facility\n(Area under curve = 1.0 = 100% probability)", fontsize=12)
plt.xlabel("Systolic BP (mmHg)")
plt.ylabel("Probability Density")
plt.legend()
plt.grid(alpha=0.3)
plt.show()

# 2) Claim Amount Density (raw vs log-transformed)
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Raw claim amounts (skewed distribution)
claim_data = df["claim_amount"].dropna()
axes[0].hist(claim_data, bins=40, density=True, alpha=0.6, color='blue', edgecolor='black')
claim_data.plot.density(ax=axes[0], linewidth=2, color='red', label='Density')
axes[0].set_title("Claim Amount Distribution (Raw)\nDensity curve shows right-skew")
axes[0].set_xlabel("Claim Amount (USD)")
axes[0].set_ylabel("Probability Density")
axes[0].legend()
axes[0].grid(alpha=0.3)

# Log-transformed claim amounts (more normal-like)
log_claim = np.log1p(claim_data)
axes[1].hist(log_claim, bins=40, density=True, alpha=0.6, color='green', edgecolor='black')
log_claim.plot.density(ax=axes[1], linewidth=2, color='red', label='Density')
axes[1].set_title("Log1p(Claim Amount) Distribution\nDensity curve more symmetric after transformation")
axes[1].set_xlabel("log1p(Claim Amount)")
axes[1].set_ylabel("Probability Density")
axes[1].legend()
axes[1].grid(alpha=0.3)

plt.tight_layout()
plt.show()

# 3) Multi-variate Density: Pulse vs Temperature
plt.figure(figsize=(10, 6))

# Remove missing values
vital_data = df[["pulse", "temp_c"]].dropna()

# 2D Density plot (KDE - Kernel Density Estimation)
sns.jointplot(data=vital_data, x="pulse", y="temp_c", kind="hex", height=8)
plt.suptitle("Joint Distribution: Pulse vs Temperature\n(Hexbin density shows concentration)", fontsize=12, y=1.00)
plt.show()

# 4) Statistical Summary from Density Analysis
print("\nDENSITY STATISTICS:")
print("-" * 80)

for col, label in [("bp_sys", "Systolic BP"), ("claim_amount", "Claim Amount")]:
    data = df[col].dropna()
    if len(data) > 0:
        print(f"\n{label}:")
        print(f"  Mean (Expected Value): {data.mean():.2f}")
        print(f"  Median (50th percentile): {data.median():.2f}")
        print(f"  Std Dev (Spread): {data.std():.2f}")
        print(f"  Skewness: {data.skew():.3f} {'(right-skewed)' if data.skew() > 0 else '(left-skewed)'}")
        print(f"  Sample Size: {len(data)}")
        print(f"  → Interpretation: Density curve represents the probability distribution")

# ==============================================================================
# EXAMPLE: WHY DENSITY IS BETTER THAN RAW NUMBERS
# ==============================================================================
# Scenario: Compare Systolic BP distributions across facilities
# Problem: Different facilities have different patient volumes
#   - Hospital-A: 400 patients
#   - Hospital-B: 380 patients  
#   - Clinic-C: 350 patients
#
# With RAW COUNTS (histogram): Harder to compare because bar heights depend on:
#   1. The underlying distribution (what we care about)
#   2. Sample size (what we don't care about)
#
# With DENSITY: Fair comparison because area-normalized to 1.0
#   - Shows true probability distribution regardless of sample size
#   - Overlapping curves reveal whether distributions are truly similar/different

print("\n" + "="*80)
print("EXAMPLE: DENSITY vs RAW COUNTS - Why Density Wins")
print("="*80)

# Split data by facility
facility_counts = df["encounter.facility"].value_counts().sort_values(ascending=False)
print("\nPatient counts by facility:")
for fac, count in facility_counts.items():
    print(f"  {fac}: {count} records")

# Create side-by-side comparison
fig, axes = plt.subplots(1, 2, figsize=(15, 6))

# LEFT: RAW COUNTS (Difficult to Compare)
# Raw frequency histograms - hard to see if distributions are similar
# because Hospital-A (more patients) will have taller bars than Clinic-C
for facility in df["encounter.facility"].unique():
    facility_data = df[df["encounter.facility"] == facility]["bp_sys"].dropna()
    if len(facility_data) > 0:
        axes[0].hist(facility_data, bins=30, alpha=0.5, label=f"{facility} (n={len(facility_data)})", edgecolor='black')

axes[0].set_title("RAW COUNTS: Histograms Difficult to Compare\n(Bar heights influenced by sample size)", fontsize=11, fontweight='bold')
axes[0].set_xlabel("Systolic BP (mmHg)")
axes[0].set_ylabel("Frequency (Count)")
axes[0].legend()
axes[0].grid(alpha=0.3)

# RIGHT: DENSITY (Easy to Compare)
# Density plots normalized to area=1, making fair comparison
for facility in df["encounter.facility"].unique():
    facility_data = df[df["encounter.facility"] == facility]["bp_sys"].dropna()
    if len(facility_data) > 0:
        facility_data.plot.density(ax=axes[1], label=f"{facility} (n={len(facility_data)})", linewidth=2.5)

axes[1].set_title("DENSITY: Curves Directly Comparable\n(Area under each curve = 1.0 = 100%)", fontsize=11, fontweight='bold')
axes[1].set_xlabel("Systolic BP (mmHg)")
axes[1].set_ylabel("Probability Density")
axes[1].legend()
axes[1].grid(alpha=0.3)

plt.tight_layout()
plt.show()

# Quantitative comparison
print("\nQUANTITATIVE INSIGHT:")
print("-" * 80)
for facility in sorted(df["encounter.facility"].unique()):
    facility_data = df[df["encounter.facility"] == facility]["bp_sys"].dropna()
    if len(facility_data) > 0:
        print(f"\n{facility}:")
        print(f"  Sample Size: {len(facility_data)}")
        print(f"  Mean BP: {facility_data.mean():.1f} mmHg")
        print(f"  Std Dev: {facility_data.std():.1f} mmHg")
        print(f"  Why Density Matters: Even though sample sizes differ,")
        print(f"  density curves show the TRUE underlying distribution shapes")
        print(f"  → Enables fair clinical comparison across facilities")


