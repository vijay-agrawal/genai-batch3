
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load synthetic healthcare data from JSON
json_file = "eda/set3/patient_admission_data.json"
with open(json_file, "r") as f:
    raw = json.load(f)

print(f"Loaded {len(raw)} records from {json_file}\n")
# ==============================================================================
# STEP 1: NORMALIZE - Flatten Nested Objects into Tabular Form
# ==============================================================================
# "Normalize" in pandas.json_normalize() means converting hierarchical/nested
# objects into a flat dataframe where dot-notation column names represent paths.
# 
# Original structure (nested):
#   {"patient": {"id": "P123", "age": 45}, "vitals": {"bp": {"systolic": 120}}}
#
# After normalization (flat):
#   patient.id | patient.age | vitals.bp.systolic
#   P123       | 45          | 120
#
# This creates one row per top-level record (one row per patient encounter).

base = pd.json_normalize(raw, sep=".")
base = base.rename(columns={
    "patient.id":"patient_id",
    "encounter.encounter_id":"encounter_id"
})

# Select relevant clinical and encounter columns
base_cols = [
    "patient_id","encounter_id",
    "patient.age","patient.gender",
    "encounter.facility","encounter.reason",
    "encounter.admit_ts","encounter.discharge_ts",
    "vitals.bp.systolic","vitals.bp.diastolic","vitals.pulse","vitals.temperature_c",
    "claim.amount_usd",
    "note.text"
]
df = base[base_cols].copy()

# Convert timestamp columns to datetime
df["admit_ts"] = pd.to_datetime(df["encounter.admit_ts"], errors="coerce")
df["discharge_ts"] = pd.to_datetime(df["encounter.discharge_ts"], errors="coerce")

# Type cleaning: Convert vitals to numeric
df["bp_sys"] = pd.to_numeric(df["vitals.bp.systolic"], errors="coerce")
df["bp_dia"] = pd.to_numeric(df["vitals.bp.diastolic"], errors="coerce")
df["pulse"] = pd.to_numeric(df["vitals.pulse"], errors="coerce")
df["temp_c"] = pd.to_numeric(df["vitals.temperature_c"], errors="coerce")

# Daily encounter volume
ts = df.dropna(subset=["admit_ts"]).copy()
ts["admit_date"] = ts["admit_ts"].dt.date

# Get list of unique facilities
FACILITIES = sorted(ts["encounter.facility"].unique())

# Create a complete date index to expose missing days
full_dates = pd.date_range(ts["admit_ts"].min().date(), ts["admit_ts"].max().date(), freq="D")
full = pd.MultiIndex.from_product([full_dates.date, FACILITIES], names=["admit_date","facility"]).to_frame(index=False)

# Daily median BP per facility
bp_daily = ts.groupby(["admit_date","encounter.facility"])["bp_sys"].median().reset_index(name="bp_sys_median")

bp_full = full.merge(bp_daily, how="left", left_on=["admit_date","facility"], right_on=["admit_date","encounter.facility"])
bp_full = bp_full.drop(columns=["encounter.facility"])
bp_full["admit_date"] = pd.to_datetime(bp_full["admit_date"])

# Missing days are NaN -> options:
# 1) forward-fill (good for operational dashboards)
# 2) time interpolation (good for trend lines)
# 3) keep NaN (good if you want to show gaps explicitly)
bp_full = bp_full.sort_values(["facility","admit_date"])

# Forward fill by facility
bp_full["bp_ffill"] = bp_full.groupby("facility")["bp_sys_median"].ffill()

# Interpolate by facility (fix index alignment issue)
bp_full["bp_interp"] = bp_full["bp_sys_median"].copy()
for fac in FACILITIES:
    mask = bp_full["facility"] == fac
    bp_full.loc[mask, "bp_interp"] = bp_full.loc[mask, "bp_sys_median"].interpolate(limit_direction="both")

# Plot
fac = "Hospital-A"
p = bp_full[bp_full["facility"]==fac]
plt.figure()
plt.plot(p["admit_date"], p["bp_sys_median"], label="raw (NaN gaps)")
plt.plot(p["admit_date"], p["bp_interp"], label="interpolated")
plt.title(f"Daily Median BP — {fac}")
plt.xlabel("date"); plt.ylabel("bp_sys median")
plt.legend()
plt.show()
