import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load synthetic healthcare data from JSON
json_file = "eda/set3/patient_admission_data.json"
with open(json_file, "r") as f:
    raw = json.load(f)

print(f"Loaded {len(raw)} records from {json_file}\n")
# ==============================================================================
# STEP 1: NORMALIZE - Flatten Nested Objects into Tabular Form
# ==============================================================================
# "Normalize" in pandas.json_normalize() means converting hierarchical/nested
# objects into a flat dataframe where dot-notation column names represent paths.
# 
# Original structure (nested):
#   {"patient": {"id": "P123", "age": 45}, "vitals": {"bp": {"systolic": 120}}}
#
# After normalization (flat):
#   patient.id | patient.age | vitals.bp.systolic
#   P123       | 45          | 120
#
# This creates one row per top-level record (one row per patient encounter).

base = pd.json_normalize(raw, sep=".")
base = base.rename(columns={
    "patient.id":"patient_id",
    "encounter.encounter_id":"encounter_id"
})

# Select relevant clinical and encounter columns
base_cols = [
    "patient_id","encounter_id",
    "patient.age","patient.gender",
    "encounter.facility","encounter.reason",
    "encounter.admit_ts","encounter.discharge_ts",
    "vitals.bp.systolic","vitals.bp.diastolic","vitals.pulse","vitals.temperature_c",
    "claim.amount_usd",
    "note.text"
]
df = base[base_cols].copy()

# Type cleaning: Convert vitals and claims to numeric
df["bp_sys"] = pd.to_numeric(df["vitals.bp.systolic"], errors="coerce")
df["bp_dia"] = pd.to_numeric(df["vitals.bp.diastolic"], errors="coerce")
df["pulse"] = pd.to_numeric(df["vitals.pulse"], errors="coerce")
df["temp_c"] = pd.to_numeric(df["vitals.temperature_c"], errors="coerce")
df["claim_amount"] = pd.to_numeric(df["claim.amount_usd"], errors="coerce")

# Derive length of stay (hours) from admit and discharge timestamps
df["admit_ts"] = pd.to_datetime(df["encounter.admit_ts"], errors="coerce")
df["discharge_ts"] = pd.to_datetime(df["encounter.discharge_ts"], errors="coerce")
df["los_hours"] = (df["discharge_ts"] - df["admit_ts"]).dt.total_seconds() / 3600

# Missingness by facility (nested missing entries show up here)
by_fac_missing = df.groupby("encounter.facility")[["bp_sys","bp_dia","pulse","temp_c","claim_amount","los_hours"]].apply(
    lambda g: (g.isna().mean()*100).round(2)
)
print("Missing % by facility:\n", by_fac_missing)

# Clinical summaries by facility
by_fac_stats = df.groupby("encounter.facility").agg(
    bp_sys_median=("bp_sys","median"),
    bp_sys_p95=("bp_sys", lambda s: np.nanpercentile(s,95)),
    los_median=("los_hours","median"),
    claim_median=("claim_amount","median"),
    n=("encounter_id","count"),
).round(2)
print("\nFacility stats:\n", by_fac_stats)

# Quick bar plot: median BP by facility
plt.figure()
by_fac_stats["bp_sys_median"].plot(kind="bar")
plt.title("Median Systolic BP by Facility")
plt.xlabel("facility")
plt.ylabel("median bp_sys")
plt.show()

# ==============================================================================
# LENGTH OF STAY (LOS) ANALYSIS - Deeper Insights
# ==============================================================================
# LOS is a key operational & clinical metric:
#   - Operational: Resource utilization, bed turnover, staffing costs
#   - Clinical: Disease severity, comorbidities, complication rates
#   - Financial: Claim amount correlation, reimbursement analysis

#LOS Distribution Analysis

#Histogram with KDE curve showing right-skewed pattern
#Log-scale histogram revealing multi-modal patterns
#2. LOS by Facility

#Boxplots showing facility-level variations
#Bar charts comparing median, mean, and P95 statistics
#Identifies which facilities have extended stays
#3. LOS vs Clinical Factors

#Age correlation (older patients = longer stays)
#Claim amount relationship (log scale for visibility)
#LOS by admission reason (top 5 reasons)
#Violin plots by gender (shows distribution shape)
#4. Risk Stratification
#
#Defines LOS risk categories: Normal (<P75), High (P75-P95), Very High (>P95)
#Profiles high-LOS cohorts (mean age, claim costs)
#5. Temporal Trends

#7-day rolling average of LOS over admission dates
#Daily admission volume trends showing seasonality
#Each visualization includes detailed titles explaining the clinical/operational insights (e.g., "Older Patients → Longer Stays", "Exponential Cost Growth", "Complex Reasons → Higher LOS").


print("\n" + "="*80)
print("LENGTH OF STAY (LOS) - COMPREHENSIVE ANALYSIS")
print("="*80)

# Basic LOS statistics
df_los_clean = df[df["los_hours"] > 0].copy()  # Remove invalid/negative LOS
print(f"\nLOS Summary (n={len(df_los_clean)} valid records):")
print(f"  Mean:      {df_los_clean['los_hours'].mean():.2f} hours ({df_los_clean['los_hours'].mean()/24:.2f} days)")
print(f"  Median:    {df_los_clean['los_hours'].median():.2f} hours ({df_los_clean['los_hours'].median()/24:.2f} days)")
print(f"  Std Dev:   {df_los_clean['los_hours'].std():.2f} hours")
print(f"  Min/Max:   {df_los_clean['los_hours'].min():.2f} / {df_los_clean['los_hours'].max():.2f} hours")
print(f"  P25/P75:   {df_los_clean['los_hours'].quantile(0.25):.2f} / {df_los_clean['los_hours'].quantile(0.75):.2f} hours")

# 1) LOS Distribution: Histogram + KDE Curve
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Histogram with KDE overlay
axes[0].hist(df_los_clean["los_hours"], bins=40, density=True, alpha=0.6, color='steelblue', edgecolor='black')
df_los_clean["los_hours"].plot(kind='kde', ax=axes[0], color='red', linewidth=2, label='KDE')
axes[0].set_xlabel("LOS (hours)")
axes[0].set_ylabel("Density")
axes[0].set_title("LOS Distribution: Right-Skewed (Most Stays <200h)\nLonger Tail = Complex Cases", fontweight='bold')
axes[0].legend()
axes[0].grid(alpha=0.3)

# Log-scale histogram (reveals pattern across all ranges)
axes[1].hist(df_los_clean["los_hours"], bins=40, alpha=0.7, color='steelblue', edgecolor='black')
axes[1].set_xlabel("LOS (hours)")
axes[1].set_ylabel("Count (log scale)")
axes[1].set_yscale('log')
axes[1].set_title("LOS Distribution: Log-Scale View\nReveals Multi-Modal Pattern", fontweight='bold')
axes[1].grid(alpha=0.3, which='both')

plt.tight_layout()
plt.show()

# 2) LOS by Facility: Boxplot + Statistical Summary
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Boxplot by facility
df_los_clean.boxplot(column='los_hours', by='encounter.facility', ax=axes[0], patch_artist=True)
axes[0].set_title("LOS Distribution by Facility\n(Box=IQR, Whiskers=1.5×IQR, Dots=Outliers)", fontweight='bold')
axes[0].set_xlabel("Facility")
axes[0].set_ylabel("LOS (hours)")
axes[0].grid(axis='y', alpha=0.3)
plt.sca(axes[0])
plt.xticks(rotation=45)

# Bar plot: Facility statistics
fac_los_stats = df_los_clean.groupby("encounter.facility")["los_hours"].agg([
    ('Median', 'median'),
    ('Mean', 'mean'),
    ('P95', lambda x: np.percentile(x, 95)),
    ('Count', 'count')
]).round(1)

fac_los_stats[['Median', 'Mean', 'P95']].plot(kind='bar', ax=axes[1], width=0.8)
axes[1].set_title("LOS Statistics by Facility\nP95 Shows Outlier Burden (Extended Stays)", fontweight='bold')
axes[1].set_xlabel("Facility")
axes[1].set_ylabel("LOS (hours)")
axes[1].legend(['Median', 'Mean', 'P95 (90th Percentile)'], loc='upper right')
axes[1].grid(axis='y', alpha=0.3)
plt.sca(axes[1])
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

print("\nLOS Statistics by Facility:\n", fac_los_stats)

# 3) LOS vs Clinical Factors: Age, Claim Amount, Admission Reason
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Age vs LOS correlation
df_los_clean_copy = df_los_clean.copy()
df_los_clean_copy["patient_age"] = pd.to_numeric(df_los_clean_copy["patient.age"], errors="coerce")
df_scatter = df_los_clean_copy[["los_hours", "patient_age"]].dropna()
if len(df_scatter) > 0:
    axes[0, 0].scatter(df_scatter["patient_age"], df_scatter["los_hours"], alpha=0.5, s=30, color='steelblue')
    corr_age = df_scatter["patient_age"].corr(df_scatter["los_hours"])
    axes[0, 0].set_xlabel("Patient Age (years)")
    axes[0, 0].set_ylabel("LOS (hours)")
    axes[0, 0].set_title(f"Age vs LOS Correlation (r={corr_age:.3f})\nOlder Patients → Longer Stays", fontweight='bold')
    axes[0, 0].grid(alpha=0.3)

# Claim Amount vs LOS (log-log for visibility)
valid_claims = df_los_clean[df_los_clean["claim_amount"] > 0].copy()
axes[0, 1].scatter(valid_claims["los_hours"], valid_claims["claim_amount"], alpha=0.5, s=30, color='darkgreen')
corr_claim = valid_claims["los_hours"].corr(valid_claims["claim_amount"])
axes[0, 1].set_xlabel("LOS (hours)")
axes[0, 1].set_ylabel("Claim Amount ($)")
axes[0, 1].set_yscale('log')
axes[0, 1].set_title(f"LOS vs Claim Amount (r={corr_claim:.3f})\nLog Scale: Exponential Cost Growth", fontweight='bold')
axes[0, 1].grid(alpha=0.3)

# LOS by Admission Reason (top 5 reasons)
reason_counts = df_los_clean["encounter.reason"].value_counts().head(5).index
df_top_reasons = df_los_clean[df_los_clean["encounter.reason"].isin(reason_counts)]
df_top_reasons.boxplot(column='los_hours', by='encounter.reason', ax=axes[1, 0], patch_artist=True)
axes[1, 0].set_title("LOS by Admission Reason (Top 5)\nComplex Reasons → Higher LOS", fontweight='bold')
axes[1, 0].set_xlabel("Admission Reason")
axes[1, 0].set_ylabel("LOS (hours)")
axes[1, 0].grid(axis='y', alpha=0.3)
plt.sca(axes[1, 0])
plt.xticks(rotation=45, ha='right', fontsize=9)

# Gender vs LOS (violin plot for distribution shape)
gender = df_los_clean["patient.gender"]
sns.violinplot(x=gender, y=df_los_clean["los_hours"], ax=axes[1, 1], palette='Set2')
axes[1, 1].set_title("LOS Distribution by Gender\nViolin Width = Density at Each LOS Level", fontweight='bold')
axes[1, 1].set_xlabel("Gender")
axes[1, 1].set_ylabel("LOS (hours)")
axes[1, 1].grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.show()

# 4) LOS Risk Stratification: Identify High-LOS Cases
print("\n" + "="*80)
print("LOS RISK STRATIFICATION")
print("="*80)

los_p75 = df_los_clean["los_hours"].quantile(0.75)
los_p95 = df_los_clean["los_hours"].quantile(0.95)

print(f"\nLOS Thresholds:")
print(f"  Normal:  < {los_p75:.0f} hours ({los_p75/24:.1f} days)")
print(f"  High:    {los_p75:.0f} - {los_p95:.0f} hours ({los_p75/24:.1f} - {los_p95/24:.1f} days)")
print(f"  Very High: > {los_p95:.0f} hours ({los_p95/24:.1f} days)")

df_los_clean["los_risk"] = "Normal"
df_los_clean.loc[df_los_clean["los_hours"] > los_p75, "los_risk"] = "High"
df_los_clean.loc[df_los_clean["los_hours"] > los_p95, "los_risk"] = "Very High"

print(f"\nRisk Distribution:")
print(df_los_clean["los_risk"].value_counts().sort_index(ascending=False))

# Analyze characteristics of high-LOS patients
print(f"\nHigh-LOS Cohort (Top 25%):")
high_los = df_los_clean[df_los_clean["los_hours"] > los_p75]
print(f"  Mean Age: {pd.to_numeric(high_los['patient.age'], errors='coerce').mean():.1f} years")
print(f"  Mean Claim: ${high_los['claim_amount'].mean():.0f}")
print(f"  Median LOS: {high_los['los_hours'].median():.0f} hours ({high_los['los_hours'].median()/24:.1f} days)")

# 5) Temporal Patterns: LOS Trend Over Admission Date
df_los_clean["admit_date"] = pd.to_datetime(df_los_clean["admit_ts"]).dt.date
daily_los = df_los_clean.groupby("admit_date")["los_hours"].agg(['mean', 'median', 'count']).rolling(window=7).mean()

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Time series of LOS trend
daily_los[['mean', 'median']].plot(ax=axes[0], linewidth=2)
axes[0].set_xlabel("Admission Date")
axes[0].set_ylabel("LOS (hours) - 7-Day Moving Average")
axes[0].set_title("LOS Temporal Trend\nSmooth Line = 7-Day Rolling Average", fontweight='bold')
axes[0].legend(['Mean LOS', 'Median LOS'])
axes[0].grid(alpha=0.3)

# Admission count trend
daily_los[['count']].plot(ax=axes[1], linewidth=2, color='darkred')
axes[1].set_xlabel("Admission Date")
axes[1].set_ylabel("Daily Admission Count - 7-Day MA")
axes[1].set_title("Daily Admission Volume Over Time\nTrend Shows Facility Seasonality", fontweight='bold')
axes[1].grid(alpha=0.3)

plt.tight_layout()
plt.show()

print("\n" + "="*80)
print("LOS Analysis Complete")
print("="*80)
