import json
import requests
import vertexai
from vertexai.generative_models import GenerativeModel, FunctionDeclaration, Tool
from dotenv import load_dotenv
import warnings
import os

# Ignore all warnings
warnings.filterwarnings('ignore')

def main():
    # Load environment variables
    load_dotenv()
    
    # Set your project details
    PROJECT_ID = os.getenv("GOOGLE_PROJECT_ID", "gen-ai-training-476514")
    LOCATION = os.getenv("GOOGLE_LOCATION", "us-central1")
    
    # Initialize Vertex AI
    try:
        vertexai.init(project=PROJECT_ID, location=LOCATION)
        print("Vertex AI Initialized.")
    except Exception as e:
        print(f"Error initializing Vertex AI: {e}")
        print("Please ensure your PROJECT_ID and LOCATION are correct and you have enabled the Vertex AI API.")
        return
    
    # Define function declarations for Vertex AI
    get_weather_func = FunctionDeclaration(
        name="get_weather",
        description="Retrieve real-time weather information/data about a particular location/place",
        parameters={
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "the exact location whose real-time weather is to be determined"
                }
            },
            "required": ["location"]
        }
    )
    
    get_latlong_func = FunctionDeclaration(
        name="get_latlong",
        description="Retrieve latitude and longitude information/data about a particular location/place",
        parameters={
            "type": "object",
            "properties": {
                "location": {
                    "type": "string",
                    "description": "the exact location whose latitude and longitude is to be determined"
                }
            },
            "required": ["location"]
        }
    )
    
    # Create a Tool with the function declarations
    weather_tool = Tool(
        function_declarations=[get_weather_func, get_latlong_func]
    )
    
    # Initialize the model with tools
    model = GenerativeModel(
        "gemini-2.0-flash-exp",
        tools=[weather_tool],
        system_instruction="You are a helpful weather assistant."
    )
    
    # Start a chat session
    chat = model.start_chat()
    
    # Send the user's message
    user_message = "How is the weather in Mumbai?"
    print(f"\nUser: {user_message}")
    
    response = chat.send_message(user_message)
    
    # Check if the model wants to call a function
    if response.candidates[0].content.parts[0].function_call:
        function_call = response.candidates[0].content.parts[0].function_call
        function_name = function_call.name
        function_args = dict(function_call.args)
        
        print(f"\nModel wants to call function: {function_name}")
        print(f"With arguments: {function_args}")
        
        location = function_args.get('location')
        
        # Execute the actual function
        if function_name == "get_weather":
            function_result = get_weather(location)
        elif function_name == "get_latlong":
            function_result = get_latlong(location)
        else:
            function_result = {"error": "Unknown function"}
        
        # Send the function result back to the model
        from vertexai.generative_models import Part
        response = chat.send_message(
            Part.from_function_response(
                name=function_name,
                response={"content": function_result}
            )
        )
        
        # Print the final response
        print("\n--- Final Response ---")
        print(response.text)
        print("----------------------\n")
    else:
        print("\n--- Response ---")
        print(response.text)
        print("----------------\n")


def get_weather(location):
    """Retrieve weather information for a location using OpenWeatherMap API"""
    try:
        print(f"\nGetting weather for: {location}")
        
        # Get latitude and longitude
        url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={os.getenv('OPENWEATHERMAP_API_KEY')}"
        response = requests.get(url, verify=False)
        geo_data = response.json()
        
        if not geo_data:
            return {"error": f"Location '{location}' not found"}
        
        latitude = geo_data[0]['lat']
        longitude = geo_data[0]['lon']
        
        # Get weather data
        weather_url = f"https://api.openweathermap.org/data/3.0/onecall?lat={latitude}&lon={longitude}&appid={os.getenv('OPENWEATHERMAP_API_KEY')}"
        weather_response = requests.get(weather_url, verify=False)
        weather_data = weather_response.json()
        
        # Extract weather information
        weather_info = {
            "location": location,
            "description": weather_data['current']['weather'][0]['description'],
            "humidity": weather_data['current']['humidity'],
            "uv_index": weather_data['current']['uvi'],
            "temperature": weather_data['current']['temp']
        }
        
        print(f"Weather: {weather_info['description']}")
        print(f"Humidity: {weather_info['humidity']}%")
        print(f"UV Index: {weather_info['uv_index']}")
        
        return weather_info
        
    except Exception as e:
        print(f"Error getting weather: {e}")
        return {"error": str(e)}


def get_latlong(location):
    """Retrieve latitude and longitude for a location using OpenWeatherMap API"""
    try:
        print(f"\nGetting coordinates for: {location}")
        
        url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={os.getenv('OPENWEATHERMAP_API_KEY')}"
        response = requests.get(url, verify=False)
        geo_data = response.json()
        
        if not geo_data:
            return {"error": f"Location '{location}' not found"}
        
        latitude = geo_data[0]['lat']
        longitude = geo_data[0]['lon']
        
        coordinates = {
            "location": location,
            "latitude": latitude,
            "longitude": longitude
        }
        
        print(f"Latitude: {latitude}, Longitude: {longitude}")
        
        return coordinates
        
    except Exception as e:
        print(f"Error getting coordinates: {e}")
        return {"error": str(e)}


if __name__ == "__main__":
    main()