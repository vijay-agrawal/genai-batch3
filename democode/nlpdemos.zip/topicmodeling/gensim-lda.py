# =============================================================================
# Latent Dirichlet Allocation (LDA) - Topic Modeling
# =============================================================================
#
# CONCEPT:
#   LDA is a generative probabilistic model that discovers hidden "topics"
#   within a collection of documents. It assumes each document is a mixture
#   of topics, and each topic is a mixture of words. For example, a news
#   article about Tesla could be 70% "technology" and 30% "economy".
#
# Note this technique is different than classification
# Classification techniques in the nlp/classification folder use labeled training data, 
# predict from predefined categories, and are explicitly designed to be compared against each other 
# as a step-by-step progression. 
# Why LDA is different:
# Unsupervised — no labels, no predefined categories. It discovers structure rather than learning to predict known classes.
# Generative / probabilistic — models how documents are produced, not how to discriminate between classes.
# Topic modeling, not classification — the output is probability distributions over latent topics, not a predicted label.
# Different toolchain — Gensim + corpora/BoW format, vs. sklearn pipelines throughout the classification series.

# HOW IT WORKS:
#   1. Each document is represented as a probability distribution over topics.
#   2. Each topic is represented as a probability distribution over words.
#   3. LDA works backwards — given observed words, it infers the latent topic
#      structure that most likely produced them, using Bayesian inference
#      (typically via Gibbs sampling or variational Bayes).
#
# KEY PARAMETERS:
#   - num_topics : How many topics to discover (set manually).
#   - passes     : Number of training passes over the corpus (more = better
#                  convergence, slower training).
#   - alpha      : Controls document-topic density (low = documents focus on
#                  fewer topics).
#   - eta (beta) : Controls topic-word density (low = topics focus on fewer
#                  words).
#
# TECHNOLOGY — Gensim:
#   This script uses the Gensim library, a Python NLP toolkit optimized for
#   topic modeling. Key Gensim components used here:
#   - corpora.Dictionary : Maps words to integer IDs.
#   - doc2bow            : Converts a document to Bag-of-Words (word ID, count)
#                          format required by LDA.
#   - LdaModel           : Trains the LDA model on the BoW corpus.
#
# STOPWORD REMOVAL (NLTK):
#   Common words like "the", "and", "is" carry no topical signal and are
#   removed before training. NLTK provides a standard English stopword list.
#   Removing them forces LDA to focus on semantically meaningful words.
#
# USE-CASE — News Article Topic Discovery:
#   This script applies LDA to a small set of news headlines spanning two
#   domains: technology (AI, Apple, Tesla) and economics (inflation, interest
#   rates, stock market). With num_topics=2, LDA is expected to separate these
#   themes automatically — without any labeling — demonstrating unsupervised
#   topic discovery. Results are visualized as word clouds, one per topic,
#   where word size reflects its probability weight within that topic.
# =============================================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
from gensim import corpora
from gensim.models import LdaModel
from wordcloud import WordCloud

# Download NLTK stopwords (if running for the first time)
nltk.download('stopwords')
stop_words = set(stopwords.words('english'))

# Sample documents
documents = [
    "Apple releases a new iPhone while Tesla launches an electric car.",
    "The stock market is seeing a downturn due to inflation concerns.",
    "Tesla and other automakers are focusing on electric vehicles.",
    "Technology companies like Apple and Google are investing in AI.",
    "The economy is affected by rising interest rates and inflation.",
    "AI is transforming the way companies operate and innovate.",
    "New government policies impact the automobile industry.",
    "Machine learning and AI are the future of technology."
]

# Preprocessing: Tokenization + Lowercasing + Stopword Removal
texts = [
    [word.lower() for word in doc.split() if word.lower() not in stop_words]
    for doc in documents
]

# Create a dictionary and corpus
dictionary = corpora.Dictionary(texts)
corpus = [dictionary.doc2bow(text) for text in texts]

# Train LDA model (2 topics for demonstration)
lda_model = LdaModel(corpus, num_topics=2, id2word=dictionary, passes=10, random_state=42)

# Extract topics
topics = lda_model.print_topics(num_words=5)
topics_df = pd.DataFrame({"Topic": [f"Topic {i+1}" for i in range(len(topics))], 
                          "Words": [topic[1] for topic in topics]})

# Display extracted topics
print("\nExtracted Topics:")
print(topics_df)

# Generate word clouds for topics
fig, axes = plt.subplots(1, 2, figsize=(12, 6))
for i, topic in enumerate(lda_model.show_topics(num_topics=2, num_words=10, formatted=False)):
    topic_words = dict(topic[1])
    wordcloud = WordCloud(width=400, height=400, background_color='white').generate_from_frequencies(topic_words)
    axes[i].imshow(wordcloud, interpolation='bilinear')
    axes[i].set_title(f"Topic {i+1}")
    axes[i].axis("off")

plt.show()
