# =============================================================================
# Bag of Words & TF-IDF — News Article Classification
# =============================================================================
#
# This demo classifies a news article into one of three categories:
#   "sports"  |  "entertainment"  |  "politics"
#
# Two classical NLP pipelines are compared side-by-side:
#   1. Bag of Words  (CountVectorizer)  + Multinomial Naive Bayes
#   2. TF-IDF        (TfidfVectorizer)  + Multinomial Naive Bayes
#
# =============================================================================
# CONCEPT: Bag of Words (BoW)
# =============================================================================
#
# The simplest way to turn text into numbers: ignore word order and grammar,
# just count how many times each word appears.
#
# Example — two articles:
#   A: "The player scored a goal in the final match"
#   B: "The minister signed a trade deal in the final vote"
#
# Vocabulary (all unique words across A and B):
#   ['deal', 'final', 'goal', 'match', 'minister', 'player',
#    'scored', 'signed', 'trade', 'vote']
#
# BoW vectors (raw counts):
#   A: [0, 1, 1, 1, 0, 1, 1, 0, 0, 0]   ← 'goal', 'match', 'player' are high
#   B: [1, 1, 0, 0, 1, 0, 0, 1, 1, 1]   ← 'minister', 'trade', 'vote' are high
#
# A classifier can now learn that 'goal', 'match', 'player' → sports,
# and 'minister', 'trade', 'vote' → politics.
#
# Limitation: common words like "the", "a", "in" appear in every document
# and inflate counts without carrying useful class signal.
#
# =============================================================================
# CONCEPT: TF-IDF (Term Frequency – Inverse Document Frequency)
# =============================================================================
#
# TF-IDF down-weights words that are common across ALL documents (like "the",
# "said", "has") and up-weights words that are rare and distinctive.
#
# TF  (Term Frequency)        = count(word in doc) / total words in doc
# IDF (Inverse Doc Frequency) = log( total docs / docs containing word )
# TF-IDF score                = TF × IDF
#
# Intuition:
#   • "the"      appears in every article → IDF ≈ 0 → TF-IDF ≈ 0 (ignored)
#   • "touchdown" appears only in sports  → IDF is high → TF-IDF is high
#   • "parliament"appears only in politics→ IDF is high → TF-IDF is high
#
# Result: the feature vector for each article highlights its truly
# discriminating words, making the classifier's job much easier.
#
# =============================================================================
# CONCEPT: Multinomial Naive Bayes Classifier
# =============================================================================
#
# Naive Bayes uses Bayes' theorem to pick the most likely class:
#
#   P(class | words) ∝ P(class) × ∏ P(word | class)
#
# During training it learns:
#   • P(sports)        — how often is any article labelled "sports"?
#   • P("goal"|sports) — how often does "goal" appear in sports articles?
#
# At prediction time it multiplies these probabilities for every word in the
# new article and picks the class with the highest combined score.
#
# "Naive" because it assumes all words are independent of each other
# (obviously false — "kick" and "goal" co-occur a lot — but the model still
# works remarkably well in practice for text classification).
#
# Why "Multinomial"? Because word counts are discrete integers, which follow
# a multinomial distribution (like rolling a die with one face per vocabulary
# word). This variant is the standard choice for BoW/TF-IDF features.
#
# =============================================================================

from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

# ---------------------------------------------------------------------------
# Training data — labelled news articles
# ---------------------------------------------------------------------------

train_texts = [
    # Sports
    "The football team won the championship after a thrilling final match.",
    "Rohit Sharma scored a brilliant century to lead India to victory.",
    "The tennis star claimed her third Grand Slam title of the season.",
    "Manchester United signed a new striker for a record transfer fee.",
    "The Olympics opening ceremony drew millions of viewers worldwide.",
    "The basketball player broke the all-time scoring record last night.",
    "Spain's national team clinched the World Cup with a stunning goal.",
    "The marathon runner set a new world record at the Berlin race.",

    # Entertainment
    "The blockbuster film grossed over a billion dollars at the box office.",
    "The pop star announced a world tour starting next month in London.",
    "The award-winning actress received an Oscar for her role in the drama.",
    "A new streaming series broke viewership records on its premiere weekend.",
    "The music album debuted at number one on charts in fifteen countries.",
    "Hollywood director unveiled the trailer for his highly anticipated sequel.",
    "The comedian's stand-up special became the most-watched show on the platform.",
    "The fashion icon launched a new clothing line at Milan Fashion Week.",
    "The celebrity couple confirmed their engagement, with fans celebrating on social media.",
    "A viral video of the actress's red carpet look sent social media into a frenzy.",
    "The reality TV star's wedding was watched by millions on the streaming platform.",
    "Celebrity gossip dominated social media after the singer confirmed the romance.",

    # Politics
    "The prime minister announced a new budget focused on infrastructure spending.",
    "Parliament passed the landmark climate bill after months of debate.",
    "The senator called for an independent inquiry into the defence contract.",
    "Diplomatic talks between the two nations resumed after a year-long freeze.",
    "The opposition party filed a motion of no confidence against the cabinet.",
    "Voters went to the polls in a closely contested gubernatorial election.",
    "The president signed an executive order on immigration policy reform.",
    "United Nations delegates agreed on a new global trade framework.",
]

train_labels = (
    ["sports"] * 8
    + ["entertainment"] * 12
    + ["politics"] * 8
)

# ---------------------------------------------------------------------------
# New articles to classify (unseen during training)
# ---------------------------------------------------------------------------

test_articles = [
    "The striker netted a hat-trick to push his club to the top of the league.",
    "The celebrity couple confirmed their engagement on social media.",
    "The finance minister unveiled tax cuts ahead of the general election.",
    "The stadium roared as the home side equalised in the dying minutes.",
    "Award season kicks off with critics praising the lead actor's performance.",
    "The ruling party announced new subsidies for farmers in rural districts.",
]

# ---------------------------------------------------------------------------
# Pipeline 1 — Bag of Words + Naive Bayes
# ---------------------------------------------------------------------------

bow_pipeline = Pipeline([
    ("vectorizer", CountVectorizer(stop_words="english")),
    ("classifier", MultinomialNB()),
])

bow_pipeline.fit(train_texts, train_labels)

# ---------------------------------------------------------------------------
# Pipeline 2 — TF-IDF + Naive Bayes
# ---------------------------------------------------------------------------

tfidf_pipeline = Pipeline([
    ("vectorizer", TfidfVectorizer(stop_words="english")),
    ("classifier", MultinomialNB()),
])

tfidf_pipeline.fit(train_texts, train_labels)

# ---------------------------------------------------------------------------
# Classify and compare
# ---------------------------------------------------------------------------

print("=" * 70)
print("  News Article Classifier - BoW vs TF-IDF")
print("=" * 70)

for i, article in enumerate(test_articles, start=1):
    bow_pred   = bow_pipeline.predict([article])[0]
    tfidf_pred = tfidf_pipeline.predict([article])[0]

    bow_proba   = bow_pipeline.predict_proba([article])[0]
    tfidf_proba = tfidf_pipeline.predict_proba([article])[0]

    classes = bow_pipeline.classes_

    print(f"\nArticle {i}: {article}")
    print(f"  BoW    => {bow_pred:<15}  "
          + "  ".join(f"{c}={p:.2f}" for c, p in zip(classes, bow_proba)))
    print(f"  TF-IDF => {tfidf_pred:<15}  "
          + "  ".join(f"{c}={p:.2f}" for c, p in zip(classes, tfidf_proba)))

# ---------------------------------------------------------------------------
# Top discriminating words per category (TF-IDF model)
# ---------------------------------------------------------------------------

print("\n" + "=" * 70)
print("  Top 8 words most UNIQUE to each category (TF-IDF model)")
print("=" * 70)
print("  (scored by how much more a word appears in THIS class vs the other two)")

import numpy as np

vectorizer    = tfidf_pipeline.named_steps["vectorizer"]
nb_model      = tfidf_pipeline.named_steps["classifier"]
feature_names = np.array(vectorizer.get_feature_names_out())

# log_prob_matrix shape: (n_classes, n_features)
# Each row = log P(word | class)
log_probs = nb_model.feature_log_prob_          # shape (3, vocab_size)

for idx, category in enumerate(nb_model.classes_):
    # Discriminative score: how much higher is log P(word|this class)
    # compared to the best of the other two classes?
    other_indices  = [i for i in range(len(nb_model.classes_)) if i != idx]
    best_other     = log_probs[other_indices].max(axis=0)   # best rival score per word
    disc_score     = log_probs[idx] - best_other            # positive = unique to this class

    top_indices = disc_score.argsort()[-8:][::-1]
    top_words   = feature_names[top_indices]
    print(f"\n  {category.upper()}: {', '.join(top_words)}")

# =============================================================================
# WHY THIS TECHNIQUE IS STILL WIDELY USED
# =============================================================================
#
# Despite being decades old, BoW + TF-IDF classifiers remain a staple in
# production NLP for several practical reasons:
#
# 1. Speed and scalability
#    Vectorisation is a single matrix multiplication. Training Naive Bayes
#    on a million documents takes seconds on a laptop. Inference is
#    essentially instantaneous — no GPU required.
#
# 2. Fully interpretable
#    You can inspect exactly which words drove a prediction (as shown in
#    the "top words" block above). This matters in regulated domains
#    (finance, healthcare, legal) where a model must be explainable.
#
# 3. Low data requirements
#    A transformer needs tens of thousands of labelled examples to
#    fine-tune reliably. A TF-IDF + Naive Bayes classifier can reach
#    useful accuracy with a few hundred examples — sometimes even fewer.
#
# 4. Strong baseline
#    In many real-world tasks (spam detection, support-ticket routing,
#    content moderation, language identification) TF-IDF classifiers
#    match or come within a few percentage points of deep learning models,
#    at a tiny fraction of the infrastructure cost.
#
# 5. No black-box pre-training dependencies
#    The model only knows what is in YOUR data. There is no risk of
#    inheriting biases or confidential knowledge baked into a large
#    pre-trained model — important for on-premise or air-gapped deployments.
#
# =============================================================================
# SHORTCOMINGS
# =============================================================================
#
# 1. Vocabulary coverage (out-of-vocabulary problem)
#    Any word not seen during training gets a zero feature. In this demo,
#    "equalised" and "stadium" were absent from training, so the model had
#    no signal and returned uniform probabilities. A larger training corpus
#    reduces this, but never eliminates it.
#
# 2. No word order or grammar
#    "India beat Pakistan" and "Pakistan beat India" produce identical BoW
#    vectors. The model cannot distinguish them. Sentiment reversals like
#    "not good" vs "good" are also invisible unless you explicitly add
#    bigrams (CountVectorizer(ngram_range=(1, 2))).
#
# 3. No understanding of meaning (synonymy / polysemy)
#    "car", "automobile", and "vehicle" are three completely unrelated
#    features, even though they mean the same thing. Conversely, "bank"
#    (financial) and "bank" (river) share the same feature despite meaning
#    different things. TF-IDF has no concept of semantics.
#
# 4. Sparse, high-dimensional vectors
#    A vocabulary of 100,000 words means every document is a 100,000-dim
#    vector that is ~99% zeros. This wastes memory and makes similarity
#    calculations brittle.
#
# 5. Sensitive to class imbalance and topic drift
#    If one class dominates the training data, or if the language used in
#    production drifts from training (new slang, new events), accuracy
#    degrades quickly and the model must be retrained from scratch.
#
# =============================================================================
# THE NEXT LEVEL UP: WORD EMBEDDINGS
# =============================================================================
#
# The step beyond TF-IDF is to represent each word as a dense vector in a
# continuous semantic space — a "word embedding" — instead of a sparse count.
#
# How it works:
#   Words are mapped to vectors of ~100-300 floats (instead of a 1-hot
#   count). These vectors are learned from millions of documents so that
#   words with similar meaning end up close together in vector space:
#     vector("king") - vector("man") + vector("woman") ≈ vector("queen")
#     vector("football") is close to vector("soccer"), "goal", "striker"
#
# Popular algorithms:
#   • Word2Vec  (Google, 2013) — predicts a word from its neighbours
#                                (CBOW) or neighbours from a word (Skip-gram)
#   • GloVe     (Stanford, 2014)— learns from global word co-occurrence
#                                statistics across the whole corpus
#   • FastText  (Meta, 2016)  — extends Word2Vec by also encoding
#                                sub-word character n-grams, so it handles
#                                misspellings and unseen words gracefully
#
# For classification, a common approach is to average the word vectors
# for all words in a document, then feed that single dense vector to a
# Logistic Regression or a small neural network.
#
# What this fixes:
#   + "car" and "automobile" are now close in vector space — synonyms
#     are no longer treated as unrelated features.
#   + Out-of-vocabulary is reduced (FastText handles unknown words via
#     sub-word pieces).
#   + Dense vectors (300 dims) are far more compact than sparse BoW
#     vectors (100,000 dims).
#
# What it still does NOT fix:
#   - Word order and grammar are still ignored when averaging vectors.
#   - A word has ONE fixed vector regardless of context: "bank" always
#     maps to the same point whether it means a financial institution or
#     a river bank.
#
# =============================================================================
# THE LEVEL AFTER THAT: CONTEXTUAL EMBEDDINGS & TRANSFORMERS (BERT / DistilBERT)
# =============================================================================
#
# The state-of-the-art approach generates a DIFFERENT vector for each word
# depending on the full sentence context — solving the polysemy problem.
#
#   "I went to the river bank."    → "bank" gets vector_A
#   "I deposited money at the bank."→ "bank" gets vector_B
#   vector_A ≠ vector_B
#
# This is what models like BERT, RoBERTa, and DistilBERT do. They read the
# entire sentence bidirectionally through many layers of self-attention
# (see sentimentanalysis_distilbert.py for a detailed walkthrough).
#
# For classification, the [CLS] token's final hidden state — a single 768-dim
# vector encoding the full-sentence meaning — is passed to a linear classifier.
# Fine-tuning on a few hundred to a few thousand labelled examples is usually
# sufficient to reach high accuracy.
#
# The accuracy ladder (approximate, task-dependent):
#
#   BoW / TF-IDF + Naive Bayes       ~80-88%   (this demo)
#   Word2Vec / GloVe + ML classifier ~85-92%
#   Fine-tuned BERT / DistilBERT     ~92-97%
#   Large Language Models (GPT-4 etc)~95-99%   (often zero-shot)
#
# The trade-off is cost: each step up the ladder multiplies compute, memory,
# and latency requirements — which is exactly why TF-IDF classifiers are still
# the right tool for many production workloads.
# =============================================================================
