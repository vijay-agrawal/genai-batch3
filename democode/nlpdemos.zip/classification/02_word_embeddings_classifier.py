# =============================================================================
# Word Embeddings for Text Classification
# Mean GloVe Vector (spaCy en_core_web_md) + Logistic Regression
# =============================================================================
#
# This demo builds directly on 01_tfidf_classifier.py.
# It replaces the TF-IDF sparse count vector with a DENSE SEMANTIC VECTOR
# by averaging the pre-trained GloVe word vectors of every word in the
# article, then feeding that single 300-dimensional vector (dimension values averaged over all words in the document)
# to a LogisticRegression classifier. Note the 300 dimensions become the "features" that the classifier learns weights for, 
# instead of the thousands of word features in TF-IDF.
#
# The "before and after" section demonstrates three articles that are
# DELIBERATELY designed to expose TF-IDF's three core weaknesses, and shows
# how word embeddings overcome each one.
#
# Requirement (run once if not already done):
#   python -m spacy download en_core_web_md
#
# =============================================================================
# HOW MEAN WORD VECTORS WORK
# =============================================================================
#
# Step 1 — Tokenise
#   spaCy splits text into word tokens: ["The", "squad", "netted", ...]
#
# Step 2 — Look up each token's pre-trained GloVe vector
#   spaCy's en_core_web_md contains 300-dimensional GloVe vectors for
#   ~20,000 common English words, trained on Common Crawl (billions of
#   web pages). Each word is a POINT in 300-dimensional space, and words
#   with similar meaning are geometrically CLOSE to each other:
#
#     vector("squad")  is close to  vector("team")
#     vector("netted") is close to  vector("scored")
#     vector("strike") is close to  vector("goal")
#     vector("rapper") is close to  vector("singer")
#
#   This is the key property that BoW / TF-IDF completely lacks.
#
# Step 3 — Average all token vectors
#   document_vector = mean( v_token1, v_token2, ..., v_tokenN )
#
#   This collapses the whole article into one 300-dimensional point that
#   approximates the semantic "centre of gravity" of the text.
#   spaCy computes this automatically via  doc.vector.
#
# Step 4 — Train Logistic Regression on the document vectors
#   Logistic Regression learns one 300-dimensional weight vector per class.
#   At prediction time it scores each class and picks the highest.
#
# Why Logistic Regression instead of Naive Bayes?
#   Naive Bayes requires non-negative features (word counts are always >= 0).
#   GloVe embedding dimensions are signed floats that CAN be negative.
#   Logistic Regression handles signed, continuous features natively and
#   is the standard pairing for dense vector document representations.
#
# =============================================================================

import numpy as np
import spacy
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

# Load the medium spaCy model — has 300-dim GloVe vectors for ~20k words.
# If not yet downloaded:  python -m spacy download en_core_web_md
nlp = spacy.load("en_core_web_md")

# ---------------------------------------------------------------------------
# Custom scikit-learn transformer: list of strings → (n, 300) numpy array
# ---------------------------------------------------------------------------

class MeanWordVectorizer(BaseEstimator, TransformerMixin):
    """
    Converts each document to the mean of its token GloVe vectors.
    doc.vector in spaCy already computes this mean, so transform is trivial.
    """
    def __init__(self, nlp_model):
        self.nlp_model = nlp_model

    def fit(self, X, y=None):
        return self                        # nothing to learn — vectors are pre-trained

    def transform(self, X):
        # shape: (n_documents, 300)
        return np.array([self.nlp_model(text).vector for text in X])

# ---------------------------------------------------------------------------
# Training data — same corpus as 01_article_classification.py
# (keeping it identical makes the before/after comparison fair)
# ---------------------------------------------------------------------------

train_texts = [
    # Sports
    "The football team won the championship after a thrilling final match.",
    "Rohit Sharma scored a brilliant century to lead India to victory.",
    "The tennis star claimed her third Grand Slam title of the season.",
    "Manchester United signed a new striker for a record transfer fee.",
    "The Olympics opening ceremony drew millions of viewers worldwide.",
    "The basketball player broke the all-time scoring record last night.",
    "Spain's national team clinched the World Cup with a stunning goal.",
    "The marathon runner set a new world record at the Berlin race.",

    # Entertainment
    "The blockbuster film grossed over a billion dollars at the box office.",
    "The pop star announced a world tour starting next month in London.",
    "The award-winning actress received an Oscar for her role in the drama.",
    "A new streaming series broke viewership records on its premiere weekend.",
    "The music album debuted at number one on charts in fifteen countries.",
    "Hollywood director unveiled the trailer for his highly anticipated sequel.",
    "The comedian's stand-up special became the most-watched show on the platform.",
    "The fashion icon launched a new clothing line at Milan Fashion Week.",
    "The celebrity couple confirmed their engagement, with fans celebrating on social media.",
    "A viral video of the actress's red carpet look sent social media into a frenzy.",
    "The reality TV star's wedding was watched by millions on the streaming platform.",
    "Celebrity gossip dominated social media after the singer confirmed the romance.",

    # Politics
    "The prime minister announced a new budget focused on infrastructure spending.",
    "Parliament passed the landmark climate bill after months of debate.",
    "The senator called for an independent inquiry into the defence contract.",
    "Diplomatic talks between the two nations resumed after a year-long freeze.",
    "The opposition party filed a motion of no confidence against the cabinet.",
    "Voters went to the polls in a closely contested gubernatorial election.",
    "The president signed an executive order on immigration policy reform.",
    "United Nations delegates agreed on a new global trade framework.",
]

train_labels = (
    ["sports"] * 8
    + ["entertainment"] * 12
    + ["politics"] * 8
)

# ---------------------------------------------------------------------------
# Pipeline A — TF-IDF + Naive Bayes  (from demo 01, kept for comparison)
# ---------------------------------------------------------------------------

tfidf_pipeline = Pipeline([
    ("vectorizer", TfidfVectorizer(stop_words="english")),
    ("classifier", MultinomialNB()),
])
tfidf_pipeline.fit(train_texts, train_labels)

# ---------------------------------------------------------------------------
# Pipeline B — Mean GloVe vector + Logistic Regression  (this demo)
# ---------------------------------------------------------------------------

embedding_pipeline = Pipeline([
    ("vectorizer", MeanWordVectorizer(nlp)),
    ("classifier", LogisticRegression(max_iter=1000, C=0.5)),
])
embedding_pipeline.fit(train_texts, train_labels)

# ---------------------------------------------------------------------------
# Helper: compare predictions side-by-side for one article
# ---------------------------------------------------------------------------

def compare(article, true_label, shortcoming, key_words):
    tfidf_pred  = tfidf_pipeline.predict([article])[0]
    tfidf_proba = tfidf_pipeline.predict_proba([article])[0]
    emb_pred    = embedding_pipeline.predict([article])[0]
    emb_proba   = embedding_pipeline.predict_proba([article])[0]

    tfidf_classes = tfidf_pipeline.classes_
    emb_classes   = embedding_pipeline.classes_

    verdict_t = "CORRECT" if tfidf_pred == true_label else "WRONG  "
    verdict_e = "CORRECT" if emb_pred   == true_label else "WRONG  "

    t_scores = "  ".join(f"{c}={p:.2f}" for c, p in zip(tfidf_classes, tfidf_proba))
    e_scores = "  ".join(f"{c}={p:.2f}" for c, p in zip(emb_classes,   emb_proba))

    print(f"  Shortcoming : {shortcoming}")
    print(f"  Article     : {article}")
    print(f"  Key words   : {key_words}")
    print(f"  True label  : {true_label}")
    print(f"  TF-IDF      : {verdict_t} => {tfidf_pred:<15}  ({t_scores})")
    print(f"  Embeddings  : {verdict_e} => {emb_pred:<15}  ({e_scores})")

# =============================================================================
# PROOF: synonymous words are close in GloVe vector space
# =============================================================================
# Before the classification comparison, let's make the core claim concrete.
# cosine similarity = 1.0 means identical direction, 0.0 means unrelated.
# TF-IDF treats every word below as a COMPLETELY DIFFERENT, UNRELATED feature.

print("=" * 70)
print("  GloVe vector similarity - words TF-IDF treats as completely unrelated")
print("=" * 70)

# Only pairs where the GloVe similarity is meaningful (>= 0.2).
# Low-similarity pairs would be misleading to show here.
word_pairs = [
    # sports  (used in Example 1)
    ("netted",      "scored"),
    # politics (used in Example 2)
    ("lawmakers",   "parliament"),
    ("legislation", "bill"),
    ("fiscal",      "budget"),
    # entertainment (used in Example 3)
    ("mixtape",     "album"),
    ("rapper",      "singer"),
]

for w1, w2 in word_pairs:
    sim = nlp(w1).similarity(nlp(w2))
    bar = "#" * int(sim * 20)
    print(f"  {w1:<14} vs {w2:<12}  similarity={sim:.2f}  [{bar:<20}]")

print()
print("  TF-IDF score for every pair above: 0.00 (treated as completely unrelated)")
print("  GloVe cosine similarity: ranges from moderate to very high (see bars above)")

# =============================================================================
# BEFORE & AFTER: three articles exposing TF-IDF's weaknesses
# =============================================================================

print("\n" + "=" * 70)
print("  BEFORE vs AFTER - TF-IDF vs Mean Word Embeddings")
print("=" * 70)

# ---------------------------------------------------------------------------
# Example 1 — SYNONYMY  (Sports)
#
# The training corpus uses specific football words: "scored", "goal", "team",
# "championship", "match". This test article covers the same topic — a footballer
# scoring multiple goals in a top-flight league — but uses DIFFERENT words
# for each concept. None of them appear in the TF-IDF vocabulary.
#
# Training vocabulary has : scored, goal, team, championship, match
# This article uses       : netted, hat-trick, winger, club, Premier League
#
# TF-IDF: every key sports word in this article is out-of-vocabulary.
#   All feature values = 0. Model has no signal, returns near-uniform
#   probabilities, and picks the wrong class.
#
# Embeddings: vector("netted") is almost identical to vector("scored") — a
#   verified cosine similarity of 1.00 (see proof section above).
#   "winger" lives close to "player/striker" in GloVe space, and
#   "Premier League" is close to "championship/World Cup".
#   The averaged document vector lands firmly in the sports region.
# ---------------------------------------------------------------------------

print("\n--- Example 1: Synonymy ---")
print("    (sports article using different words for the same concepts)\n")
compare(
    article="The winger netted a hat-trick, propelling his club to the top of the Premier League.",
    true_label="sports",
    shortcoming="Synonymy",
    key_words="netted=scored(sim 1.00)  winger=player  Premier League=championship",
)

# ---------------------------------------------------------------------------
# Example 2 — SEMANTIC PARAPHRASE  (Politics)
#
# The article expresses a clear political idea using vocabulary that does
# NOT appear in the training set.
#
# Training vocabulary has : parliament, party, minister, cabinet, budget, debate
# This article uses       : lawmakers, fiscal, legislation, partisan, disagreements
#
# TF-IDF: none of these article words exist in its learned vocabulary.
#   Features are all zero → near-uniform probabilities → wrong prediction.
#
# Embeddings: "lawmakers"  lives near "parliament/senator" in GloVe space,
#             "fiscal"     lives near "budget/financial",
#             "legislation"lives near "bill/law",
#             "partisan"   lives near "party/political"
#   The document vector settles into the politics neighbourhood → correct.
# ---------------------------------------------------------------------------

print("\n--- Example 2: Semantic paraphrase ---")
print("    (politics expressed in entirely different vocabulary from training)\n")
compare(
    article="Lawmakers clashed over fiscal legislation amid bitter partisan disagreements.",
    true_label="politics",
    shortcoming="Semantic paraphrase",
    key_words="lawmakers=parliament  fiscal=budget  legislation=bill  partisan=party",
)

# ---------------------------------------------------------------------------
# Example 3 — OUT-OF-VOCABULARY DOMAIN SLANG  (Entertainment)
#
# The article is clearly about the music / entertainment industry but uses
# genre-specific slang that was never in the training corpus.
#
# Training vocabulary has : pop star, album, charts, singer, music
# This article uses       : rapper, mixtape, platinum, Grammy, viral, TikTok
#
# TF-IDF: "rapper", "mixtape", "platinum", "Grammy" are all out-of-vocabulary.
#   The only weak signal is words like "debut" — not enough for a clear call.
#   Prediction is wrong or highly uncertain.
#
# Embeddings: "rapper"  is very close to "singer/pop star" in GloVe space,
#             "mixtape" is close to "album/record",
#             "Grammy"  is close to "Oscar/award" (both prestigious ceremonies),
#             "platinum"is close to "hit/popular/sold"
#   The document vector remains firmly in entertainment territory → correct.
# ---------------------------------------------------------------------------

print("\n--- Example 3: Out-of-vocabulary domain slang ---")
print("    (entertainment industry jargon not present in training data)\n")
compare(
    article="The Grammy-winning rapper's debut mixtape went double platinum after going viral.",
    true_label="entertainment",
    shortcoming="Out-of-vocabulary slang",
    key_words="rapper=singer  mixtape=album  Grammy=Oscar  platinum=hit",
)

print("\n" + "=" * 70)
print("  Summary")
print("=" * 70)
print("""
  TF-IDF is a vocabulary lookup: a word either exists in training or it does
  not. Unknown words contribute zero signal, regardless of their meaning.

  Mean word embeddings work in semantic space: words close in meaning produce
  similar vectors, so the document vector captures the topic even when the
  exact training words were never used. This is why embedding-based classifiers
  generalise far better to real-world text, which is endlessly varied.

  The trade-off: embeddings require a large pre-trained model (en_core_web_md
  is ~43 MB; Google News Word2Vec is ~1.7 GB), while TF-IDF has zero external
  dependencies and can be trained entirely from your own data.
""")
