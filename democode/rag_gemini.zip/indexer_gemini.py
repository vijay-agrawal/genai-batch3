import os
import shutil
import vertexai
from langchain_google_vertexai import VertexAIEmbeddings
import warnings
from dotenv import load_dotenv
import glob

load_dotenv()
warnings.filterwarnings("ignore")

# Vertex AI Configuration
PROJECT_ID = "gen-ai-training-476514"
LOCATION = "us-central1"

# Initialize Vertex AI
vertexai.init(project=PROJECT_ID, location=LOCATION)

CHROMA_PATH = os.path.join(os.getcwd(), "chroma_db_3")

# Clear existing vector database
if os.path.exists(CHROMA_PATH):
    print(f"Clearing existing vector database at {CHROMA_PATH}")
    shutil.rmtree(CHROMA_PATH)

def load_document(file):
    name, extension = os.path.splitext(file)

    if extension == '.pdf':
        from langchain_community.document_loaders import PyPDFLoader
        print(f'Loading {file}')
        loader = PyPDFLoader(file)
    elif extension == '.docx':
        from langchain_community.document_loaders import Docx2txtLoader
        print(f'Loading {file}')
        loader = Docx2txtLoader(file)
    elif extension == '.txt':
        from langchain_community.document_loaders import TextLoader
        loader = TextLoader(file)
    else:
        print('Document format is not supported!')
        return None

    data = loader.load()
    return data

def chunk_data(data, chunk_size=256):
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, 
        chunk_overlap=20  # Added some overlap
    )
    chunks = text_splitter.split_documents(data)
    print(f"Created {len(chunks)} chunks")
    return chunks 

def create_embeddings_chroma(chunks, persist_directory=CHROMA_PATH, batch_size=250):
    from langchain_community.vectorstores import Chroma

    # Use Vertex AI embeddings (Gemini)
    embeddings = VertexAIEmbeddings(
        model_name="text-embedding-004",
        project=PROJECT_ID,
        location=LOCATION
    )

    try:
        # Process in batches due to Vertex AI limit of 250 per request
        vectorstore = None
        for i in range(0, len(chunks), batch_size):
            batch = chunks[i:i + batch_size]
            print(f"Processing batch {i // batch_size + 1} ({len(batch)} chunks)...")

            if vectorstore is None:
                vectorstore = Chroma.from_documents(batch, embeddings, persist_directory=persist_directory)
            else:
                vectorstore.add_documents(batch)

        print("Successfully created Chroma vector store with Gemini embeddings")
    except Exception as e:
        print(f"Error creating embeddings: {e}")
        raise

#### MAIN PROCESSING STARTS HERE

data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
print(f'Looking for PDF files in {data_dir}')
pdf_files = glob.glob(os.path.join(data_dir, '*.pdf'))

print(f'Found {len(pdf_files)} PDF files to process.')

# Load all PDF documents - flatten the structure
all_documents = []  # Renamed for clarity
for pdf_file in pdf_files:
    try:
        print(f'Processing file: {pdf_file}')
        docs = load_document(pdf_file)
        if docs:
            all_documents.extend(docs)  # Use extend instead of append
            print(f"Loaded: {os.path.basename(pdf_file)}")
    except Exception as e:
        print(f"Error loading {pdf_file}: {e}")

if not all_documents:
    print("No documents loaded successfully!")
    exit(1)

print(f'Loaded {len(all_documents)} document pages...')

# Split the documents into chunks
print('Splitting documents into chunks')
chunks = chunk_data(all_documents, chunk_size=256)

if chunks:
    create_embeddings_chroma(chunks)
    print('Chroma vector db created successfully')
else:
    print('No chunks created - check your documents')