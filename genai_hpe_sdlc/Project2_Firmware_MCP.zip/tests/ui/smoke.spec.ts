import { test, expect } from '@playwright/test';
test('firmware console renders', async ({ page }) => { await page.goto('/'); await expect(page.getByRole('heading',{name:'Firmware Update Console'})).toBeVisible(); await expect(page.locator('#model')).toHaveText('ProLiant DL360 Gen11'); });
