from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
def setup_function(): client.post('/lab/reset')
def test_system_model(): assert client.get('/api/system').json()['model']=='ProLiant DL360 Gen11'
def test_starter_accepts_known_good_version(): assert client.post('/api/firmware',json={'target_version':'1.2.0'}).status_code==200
