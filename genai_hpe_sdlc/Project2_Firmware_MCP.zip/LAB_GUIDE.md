# Mini-project 2 — Firmware Compatibility via Custom MCP Tools

**Duration:** ~3 h 20 min  **Spotlight:** custom MCP domain tools, **MCP-driven (governed) code edits**, API tests + Playwright UI tests

---

## Table of contents

1. [Why this lab exists](#1-why-this-lab-exists)
2. [Capabilities you will exercise and the value each delivers](#2-capabilities-you-will-exercise-and-the-value-each-delivers)
3. [The scenario and the starter application](#3-the-scenario-and-the-starter-application)
4. [Architecture at a glance](#4-architecture-at-a-glance)
5. [Before vs. after: the whole lab in one table](#5-before-vs-after-the-whole-lab-in-one-table)
6. [Timeline](#6-timeline)
7. [Part 0 — Common first 15 minutes (every team)](#7-part-0--common-first-15-minutes-every-team)
8. [Part 1 — Connect the MCP server (0:15–0:20)](#8-part-1--connect-the-mcp-server-015020)
9. [Part 2 — Establish the "before" baseline, then use the MCP fact tools (0:20–0:45)](#9-part-2--establish-the-before-baseline-then-use-the-mcp-fact-tools-020045)
10. [Part 3 — Plan with MCP-sourced facts (0:45–1:15)](#10-part-3--plan-with-mcp-sourced-facts-045115)
11. [Part 4 — Test first, then governed edits via `apply_repo_patch` (1:15–2:20)](#11-part-4--test-first-then-governed-edits-via-apply_repo_patch-115220)
12. [Part 5 — Verify with pytest and Playwright (2:20–2:50)](#12-part-5--verify-with-pytest-and-playwright-220250)
13. [Part 6 — Review the tool trace and discuss governance (2:50–3:20)](#13-part-6--review-the-tool-trace-and-discuss-governance-250320)
14. [Part 7 — Commit and open the PR](#14-part-7--commit-and-open-the-pr)
15. [Troubleshooting](#15-troubleshooting)
16. [Stretch goals](#16-stretch-goals)
17. [Reflection questions](#17-reflection-questions)
18. [Facilitator appendix](#18-facilitator-appendix)

---

## 1. Why this lab exists

An AI coding assistant is only as trustworthy as the **facts** it works from and the **actions** it is allowed to take.
Out of the box, Copilot has neither of the things an enterprise needs:

| Gap | What goes wrong in real life |
|---|---|
| **No access to your private domain knowledge** | Asked "which firmware is valid for a DL360 Gen11?", a model answers from public training data. It sounds confident and may be wrong, outdated, or invented. In a firmware context, a wrong answer can brick a server. |
| **Unrestricted write access** | The built-in edit tool can modify *any* file in the workspace: production code, config, secrets, even the compatibility data itself. There is no policy layer between "the model decided" and "the file changed". |

**Model Context Protocol (MCP)** closes both gaps. You expose your own tools to the assistant over a standard protocol, so that:

* **facts** come from an authoritative, versioned source your organization owns (`get_supported_firmware`, `check_compatibility`), and
* **actions** go through a narrow, auditable, policy-enforcing gate that your organization controls (`apply_repo_patch`).

In this lab you build a real safety feature — *block incompatible firmware updates* — and, while doing it, you will directly observe the difference between an assistant that guesses and writes freely, and one that is grounded and governed.

### Learning objectives

By the end of this lab you will be able to:

1. Register a custom MCP server in VS Code and confirm that Copilot Agent mode can see its tools.
2. Demonstrate, with evidence, the difference between a **hallucinated** answer and an **MCP-grounded** answer.
3. Drive a **test-first** workflow where compatibility rules come from MCP rather than from the model's memory.
4. Make all code changes through a **path-allowlisted, exact-match patch tool**, and explain why that is a governance control.
5. Prove the feature works with **pytest (API)** and **Playwright (UI)**: `2.0.0` rejected with a clear reason, `1.2.0` accepted.
6. Read a Copilot **tool-call trace** and classify each call as MCP vs. built-in.

---

## 2. Capabilities you will exercise and the value each delivers

| # | Capability | Where you will see it | Value proposition |
|---|---|---|---|
| **C1** | **Custom MCP server registration** (`mcp.json`, stdio transport) | Part 1 | Plug *your* systems into Copilot with a ~40-line Python file and a 6-line config. No Copilot plugin SDK, no vendor ticket. The same server works in any MCP-aware client, so the investment is portable. |
| **C2** | **Domain fact tool: `get_supported_firmware(model)`** | Part 2 | Gives the assistant the **complete list** of supported and blocked versions, plus the human-readable note, for a model. Replaces "what the model remembers" with "what your data says". |
| **C3** | **Decision tool: `check_compatibility(model, target_version)`** | Parts 2, 5 | Returns a precise yes/no **with a reason** (`compatible`, `reason`). Ideal for spot checks and for producing the exact error text the UI should show. Keeps the *decision logic* in one place instead of re-implemented in prompts. |
| **C4** | **Single source of truth** | Parts 3–4 | The same `compatibility.json` backs the MCP tools. When engineering updates a rule, every Copilot session sees it immediately; no re-prompting, no stale copy-paste in chat history. |
| **C5** | **Governed write tool: `apply_repo_patch(path, old_text, new_text)`** | Part 4 | A **policy-enforcing edit gate**: (a) paths are confined to `app/` and `tests/`; (b) `../` escapes are blocked; (c) the edit only happens when `old_text` matches **exactly once**, so the change is deterministic and cannot silently clobber the wrong region. |
| **C6** | **Auditability** | Part 6 | Every MCP call is visible in the chat tool trace with its arguments and result. You can show a reviewer *what facts were consulted* and *what exactly was changed*. |
| **C7** | **Test-first, evidence-based delivery** | Parts 4–5 | The acceptance test is written *before* the fix, fails for the right reason, then goes green. Combined with Playwright you get end-to-end proof from API to pixels. |
| **C8** | **Human-in-the-loop review** | Part 7 | The repo's `copilot-instructions.md` tells the assistant to stop before merge. The PR carries a diff, test evidence and a risk list for a human to approve. |

> **Key idea to hold on to:** *MCP is not "more tools for the model". It is a way to decide, as an organization, what the model may **know** and what it may **do**.*

---

## 3. The scenario and the starter application

### The business problem

The **Firmware Update Console** lets an operator schedule a firmware update for a server.
Today it accepts **any** version string. Scheduling `2.0.0` (a Gen12-only image) on a **ProLiant DL360 Gen11** would be accepted, and in production it could lead to a failed flash or an unrecoverable server.

### What the starter app does (verified from the source)

| Item | Behaviour |
|---|---|
| `GET /api/system` | Returns `{"model": "ProLiant DL360 Gen11", "current_firmware": "1.1.0", "target_firmware": null}` |
| `POST /api/firmware` | Body `{"target_version": "..."}`. **Always** returns `200 {"accepted": true, ...}` and stores the version. *This is the defect.* |
| `POST /lab/reset` | Test helper: clears `target_firmware`. |
| `GET /` | Single-page UI: dropdown with `1.2.0`, `1.3.0`, `2.0.0`, a **Schedule Update** button, and a message area. |
| UI message logic | Shows `Update scheduled` on success; on failure shows `body.detail` (or `Rejected`). So a FastAPI `HTTPException(detail=...)` is surfaced automatically. |

### What the MCP server exposes (`mcp_server/server.py`)

| Tool | Input | Output | Nature |
|---|---|---|---|
| `get_supported_firmware` | `model` | `{supported: [...], blocked: [...], note: "..."}` or `{error: "unknown model"}` | read-only fact |
| `check_compatibility` | `model`, `target_version` | `{compatible: bool, reason: str}` | read-only decision |
| `apply_repo_patch` | `path`, `old_text`, `new_text` | `{ok: true, path}` or `{ok: false, reason}`; raises on a forbidden path | **governed write** |

### The authoritative data (`mcp_server/data/compatibility.json`)

| Model | Supported | Blocked | Note |
|---|---|---|---|
| ProLiant DL360 Gen11 | `1.2.0`, `1.3.0` | `2.0.0` | "2.0.0 is for Gen12 lab hardware only" |
| ProLiant DL380 Gen11 | `1.1.5`, `1.2.0` | `1.3.0` | "1.3.0 requires a different controller package" |

> Note that `1.3.0` is **valid** for the DL360 but **blocked** for the DL380. This is deliberate: a rule like "reject anything above 1.2.0" would be wrong, and a model that guesses will often get it wrong.

### Work item (`work-items/MP2.md`)

> Use the custom `hpe-firmware` MCP tools as the compatibility source of truth. Reject incompatible targets with **HTTP 409**, explain the reason in the UI, and add API + Playwright tests. Production/test file modifications must be performed through MCP `apply_repo_patch`, **not** the normal edit tool.

### Acceptance criteria (use this as your checklist)

- [ ] `POST /api/firmware` with `2.0.0` for the DL360 Gen11 returns **409**, and the body contains the MCP-sourced reason (`2.0.0 is for Gen12 lab hardware only`).
- [ ] `POST /api/firmware` with `1.2.0` (and `1.3.0`) returns **200**.
- [ ] A rejected request must **not** change `target_firmware`.
- [ ] A version not known to the model's `supported` list (e.g. `9.9.9`) is rejected, not silently accepted.
- [ ] The UI shows the rejection reason in the message area and does **not** show "Update scheduled".
- [ ] New API tests and a new Playwright test exist, and **fail before** the fix and **pass after**.
- [ ] Every edit to `app/` and `tests/` was made through `apply_repo_patch`.
- [ ] Existing tests still pass; no valid test was weakened or deleted.

---

## 4. Architecture at a glance

```
                          ┌────────────────────────────────────────────┐
                          │  VS Code · GitHub Copilot Chat (Agent mode)│
                          └───────┬───────────────────────┬────────────┘
                 built-in tools   │                       │  MCP (stdio)
        (read / search / terminal)│                       │
                                  ▼                       ▼
                     ┌────────────────────┐   ┌─────────────────────────────────┐
                     │ Workspace files    │   │ hpe-firmware MCP server         │
                     │ (read & search OK; │   │  • get_supported_firmware       │
                     │  direct edits NOT  │   │  • check_compatibility          │
                     │  allowed in lab)   │   │  • apply_repo_patch ──┐         │
                     └────────────────────┘   └───────────┬───────────┼─────────┘
                                                          │ reads     │ policy gate
                                                          ▼           ▼
                                             compatibility.json   safe_path():
                                             (single source       ✔ app/…  ✔ tests/…
                                              of truth)           ✘ ../…   ✘ everything else
                                                                  + exactly-one-match rule
                                                                          │ writes
                                                                          ▼
                                                              app/main.py, tests/**
```

Two distinct trust channels flow through MCP:

* **Knowledge channel (read):** `get_supported_firmware`, `check_compatibility`
* **Action channel (write):** `apply_repo_patch`, which is *narrower* than the built-in editor by design

---

## 5. Before vs. after: the whole lab in one table

You will **observe the "before" yourself** in Parts 2 and 4 (it takes about two minutes each) so that the "after" is something you have measured, not something you were told.

| Dimension | BEFORE (plain Copilot, no MCP) | AFTER (Copilot + `hpe-firmware` MCP) | Evidence you will capture |
|---|---|---|---|
| **Source of compatibility facts** | Model memory and guesses. May say "2.0.0 is the latest, so use it" or invent a matrix. | Authoritative JSON via `get_supported_firmware`. | Screenshot/paste of the tool call and result in the chat trace. |
| **Correctness for DL380 vs. DL360** | Likely to generalise ("1.3.0 is newer, so fine") and get one of them wrong. | Exact: `1.3.0` OK on DL360, blocked on DL380 with the real reason. | Answers to the Part 2 baseline prompt vs. MCP prompt. |
| **Error message to the operator** | Generic: "Invalid version" (invented wording). | The business-owned reason: *"2.0.0 is for Gen12 lab hardware only"*. | Playwright assertion on the exact text. |
| **Who decides a rule changed?** | Whoever last edited a prompt or code comment. | Data owner updates `compatibility.json`; every session sees it. | Part 6 discussion. |
| **Write access** | Built-in editor can touch any file, including `compatibility.json`, `server.py`, `.github/`, CI config. | `apply_repo_patch` can touch only `app/` and `tests/`. | The refusal you will provoke in Part 4, Step 4.1. |
| **Edit safety** | Whole-file rewrites; model may reflow or drop unrelated code. | Exact-match, single-occurrence replacement; `Expected one exact match, found 0/2` if anything is ambiguous. | The tool result for a deliberately ambiguous patch. |
| **Audit trail** | A diff after the fact; unclear *why* the model chose a version. | Each fact lookup and each patch is a discrete, logged tool call with arguments and results. | Part 6 trace classification table. |
| **Quality gate** | "It looks right." | Acceptance test written first, red → green, plus UI proof. | `pytest` and Playwright output. |
| **Production risk** | Incompatible firmware can be scheduled. | `409` before anything is stored. | `2.0.0 → 409`, `1.2.0 → 200`. |

---

## 6. Timeline

| Time | Part | Outcome |
|---|---|---|
| 0:00–0:15 | **Part 0** Repo, venv, green baseline | Private repo with starter pushed; `pytest -q` green |
| 0:15–0:20 | **Part 1** Register MCP server | Copilot lists 3 `hpe-firmware` tools |
| 0:20–0:45 | **Part 2** Baseline vs. MCP facts | Written proof that MCP answers differ from un-grounded answers |
| 0:45–1:15 | **Part 3** Implementation + test plan | Plan citing MCP results, with no invented facts |
| 1:15–2:20 | **Part 4** Red test → governed patches | Failing acceptance tests, then the fix, all via `apply_repo_patch` |
| 2:20–2:50 | **Part 5** Verification | `pytest` + Playwright green; 2.0.0 rejected, 1.2.0 accepted |
| 2:50–3:20 | **Part 6** Trace review + governance | Trace classification table completed |
| 3:20+ | **Part 7** Commit and PR | PR with evidence |

---

## 7. Part 0 — Common first 15 minutes (every team)

**Goal:** a private repo containing the untouched starter, and a working local environment with all starter tests green.

1. **Create the repository.** Go to **https://github.com/new** and create a new **private** repository. Do **not** initialise it with a README, `.gitignore` or license (an empty repo avoids a merge conflict on first push).
2. **Unzip** the starter project locally and open a terminal **in the project folder** (the one that contains `app/`, `mcp_server/`, `tests/`).
3. **Push the starter** to your new repo:

   ```bash
   git init
   git add .
   git commit -m "lab: starter application"
   git branch -M main
   git remote add origin <YOUR-NEW-REPO-URL>
   git push -u origin main
   ```

   *Why this matters:* this commit is your "before" snapshot. At the end, `git diff main` against it is the complete record of what the assistant changed.

4. **Open the folder in VS Code** (`code .`) and **sign in to GitHub Copilot** (account icon, bottom-left). Confirm the Copilot icon in the status bar is not struck through.
5. **Create the Python environment** (PowerShell):

   ```powershell
   python -m venv .venv
   .venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```

   If activation is blocked: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then re-run the activate line.
   The prompt should now start with `(.venv)`.

6. **Install UI dependencies** (this project has a UI):

   ```bash
   npm install
   npx playwright install chromium
   ```

7. **Run the baseline tests:**

   ```powershell
   pytest -q
   ```

   Expected: `2 passed`. If anything fails, stop and fix it now; every later "red" must be one *you* caused on purpose.

8. **Read the work item** in `work-items/MP2.md` and `.github/copilot-instructions.md` *before* prompting Copilot. These two files are the contract: the first says what to build, the second says how Copilot must behave (inspect first, minimal diffs, test first, never weaken tests, summarise files/tests/assumptions/risks).

✅ **Checkpoint 0:** private repo has one commit; `pytest -q` shows `2 passed`.

---

## 8. Part 1 — Connect the MCP server (0:15–0:20)

**Goal:** Copilot Agent mode can see and call the three `hpe-firmware` tools.

1. In VS Code run **`Ctrl+Shift+P` → `MCP: Open Workspace Folder Configuration`**. VS Code creates/opens `.vscode/mcp.json`.
2. Copy the contents of `lab-assets/mcp.windows.json` into it.
3. **Replace both `<ABSOLUTE_PATH_TO_REPO>` placeholders** with the full path to your project folder. In JSON, backslashes must be doubled. Example:

   ```json
   {
     "servers": {
       "hpe-firmware": {
         "type": "stdio",
         "command": "C:\\labs\\p2_firmware_mcp\\.venv\\Scripts\\python.exe",
         "args": ["C:\\labs\\p2_firmware_mcp\\mcp_server\\server.py"]
       }
     }
   }
   ```

   *Why the venv's `python.exe`?* The MCP SDK was installed into `.venv`; the system Python does not have it.
4. Click **Start** above the `hpe-firmware` entry in `mcp.json` (or use `MCP: List Servers → hpe-firmware → Start`). The status should turn to **Running**. If it errors, open **Output → MCP: hpe-firmware** (see [Troubleshooting](#15-troubleshooting)).
5. Open **Copilot Chat**, switch the mode dropdown to **Agent**, then click the **Tools** (wrench) icon. Expand `hpe-firmware`; you should see exactly:
   * `get_supported_firmware`
   * `check_compatibility`
   * `apply_repo_patch`
6. Keep all three ticked.

> `.vscode/mcp.json` contains machine-specific absolute paths. Do **not** include it in your PR (check `git status` before committing).

✅ **Checkpoint 1:** three tools visible under `hpe-firmware`, server status Running.

---

## 9. Part 2 — Establish the "before" baseline, then use the MCP fact tools (0:20–0:45)

**Goal:** see for yourself that the un-grounded assistant and the grounded assistant give different answers, and learn what each fact tool returns.

### Step 2.1 — The BEFORE experiment (about 5 minutes)

Temporarily **untick the three `hpe-firmware` tools** in the Tools picker (or open a new chat with them disabled), then ask:

```text
Without using any tools: which firmware versions are supported for a ProLiant DL360 Gen11
and for a ProLiant DL380 Gen11? Is 2.0.0 safe to install on the DL360? Is 1.3.0 safe on the DL380?
```

Record in a scratch note (you will reuse it in Part 6):

| Question | Un-grounded answer | Confident? | Matches `compatibility.json`? |
|---|---|---|---|
| DL360 Gen11 supported versions | | | |
| DL380 Gen11 supported versions | | | |
| 2.0.0 on DL360 | | | |
| 1.3.0 on DL380 | | | |

What you should typically observe: a fluent, plausible answer that is either hedged ("check HPE's site") or **confidently wrong/invented**. Neither is something you can put into a code path that gates real hardware.

> Do **not** open `compatibility.json` yet. The point is to feel the gap.

### Step 2.2 — Re-enable the MCP tools and discover the model

Re-tick the `hpe-firmware` tools. First find out which model the app is running. Start the app in a separate terminal (venv active):

```powershell
python -m uvicorn app.main:app --reload --port 8000
```

Then ask Copilot:

```text
Call GET http://127.0.0.1:8000/api/system (use the terminal, e.g. Invoke-RestMethod) and tell me the model.
Then call the MCP tool get_supported_firmware for exactly that model string.
Show me the raw tool result.
```

Expected tool call and result (for `ProLiant DL360 Gen11`):

```json
{
  "supported": ["1.2.0", "1.3.0"],
  "blocked": ["2.0.0"],
  "note": "2.0.0 is for Gen12 lab hardware only"
}
```

Copilot will ask for confirmation before running an MCP tool the first time. Review the arguments, then click **Allow**. That confirmation prompt is itself a governance feature.

### Step 2.3 — Probe the decision tool

```text
Using the MCP tool check_compatibility, check these four combinations and give me a table:
1) ProLiant DL360 Gen11 + 1.2.0
2) ProLiant DL360 Gen11 + 2.0.0
3) ProLiant DL380 Gen11 + 1.3.0
4) ProLiant Unknown Gen99 + 1.0.0
```

Expected:

| Model | Version | `compatible` | `reason` |
|---|---|---|---|
| DL360 Gen11 | 1.2.0 | `true` | `supported` |
| DL360 Gen11 | 2.0.0 | `false` | `2.0.0 is for Gen12 lab hardware only` |
| DL380 Gen11 | 1.3.0 | `false` | `1.3.0 requires a different controller package` |
| Unknown Gen99 | 1.0.0 | `false` | `unknown model` |

### Step 2.4 — Compare

Fill in the right-hand column of your Step 2.1 table using the MCP results. Count how many of the four baseline answers were wrong, incomplete, or unverifiable.

**What to take away:**

| | Un-grounded | MCP-grounded |
|---|---|---|
| Answer shape | Prose, hedged or invented | Structured JSON, machine-usable |
| Reason text | Paraphrased | Verbatim business wording, reusable in the UI |
| Unknown model | Often a guess | Explicit `unknown model` (fail-safe) |
| Repeatable? | Varies run to run | Same input gives same output |

✅ **Checkpoint 2:** a filled comparison table and at least three MCP tool calls visible in your chat history.

---

## 10. Part 3 — Plan with MCP-sourced facts (0:45–1:15)

**Goal:** a short implementation + test plan in which **every compatibility fact is traceable to an MCP result**. No code changes yet.

### Step 3.1 — Ask for the plan

```text
Read work-items/MP2.md and .github/copilot-instructions.md, then inspect app/main.py and the existing tests
(read-only; do NOT edit anything). Using the MCP results already obtained (and calling the tools again if needed),
produce an implementation plan and a test plan for MP2.

Requirements for the plan:
- Quote every compatibility fact together with the MCP tool call it came from.
- State where the compatibility rules will live in the app and how they stay in sync with the MCP data.
- List the exact tests (API and Playwright) with the expected status codes and messages.
- Call out edge cases and risks.
- Remind me that all edits must go through apply_repo_patch.
```

### Step 3.2 — Review the plan against this checklist

| Check | Good plan | Red flag |
|---|---|---|
| Facts cited | "DL360: supported `1.2.0`, `1.3.0`; blocked `2.0.0` (from `get_supported_firmware`)" | Facts stated with no tool reference |
| Status code | `409 Conflict` | `400`, `422`, or `403` |
| Message source | Reason text taken from MCP data | Newly invented wording |
| Unknown version (`9.9.9`) | Rejected | "Accept anything not blocked" |
| State safety | `target_firmware` unchanged on rejection | Stored before validation |
| Tests | API: 2.0.0 → 409 (+ reason), 1.2.0 → 200, 1.3.0 → 200, 9.9.9 → 409; UI: reject path + accept path | Only a happy-path test |
| Editing approach | Explicit `apply_repo_patch` for each change | "I'll edit the files directly" |

### Step 3.3 — Decide how the app obtains the rules

The app is a separate process and cannot call Copilot's MCP session at runtime. MCP is the source of truth **at authoring time**; the app needs the rules in code or data. Choose one and note it in your plan:

| Option | How | Pros | Cons |
|---|---|---|---|
| **A. Embed the facts** | Add a dict to `app/main.py` mirroring the MCP result | Simple; self-contained | Can drift from `compatibility.json`; a rule change means a code change |
| **B. Load the shared JSON** | `app/main.py` reads `mcp_server/data/compatibility.json` at startup | One source of truth; no drift | App now depends on that file's location and format |

Both are acceptable for the lab. B is the better production instinct because the MCP server and the app cannot disagree. Whichever you choose, the facts must come from what the tools returned, and you must be able to say so.

✅ **Checkpoint 3:** a reviewed plan that cites MCP calls. Paste it into the PR description later.

---

## 11. Part 4 — Test first, then governed edits via `apply_repo_patch` (1:15–2:20)

**Goal:** red acceptance tests, then green, with **every file change** made via `apply_repo_patch`.

### Rules of engagement

* ✅ Allowed: built-in **read, search, list, terminal commands that don't modify files** (e.g. running tests, `git diff`).
* ✅ Allowed: MCP `get_supported_firmware`, `check_compatibility`, `apply_repo_patch`.
* ❌ Not allowed: the built-in **edit / create / replace** tools, or shell redirection (`>>`, `Set-Content`, `sed -i`) to change files.

Put this in your first prompt so Copilot knows:

```text
From now on you may read and search the repo with built-in tools, but you must make EVERY file change by calling
the MCP tool apply_repo_patch(path, old_text, new_text). Do not use any built-in edit or create-file tool and do not
modify files from the terminal. If apply_repo_patch refuses, report the refusal; do not work around it.
```

### How `apply_repo_patch` behaves (know this before you start)

| Situation | Result |
|---|---|
| `old_text` found exactly once in an allowed file | `{"ok": true, "path": "..."}`; file updated |
| `old_text` not found | `{"ok": false, "reason": "Expected one exact match, found 0"}` |
| `old_text` found more than once | `{"ok": false, "reason": "Expected one exact match, found N"}`; add more surrounding context |
| `path` outside `app/` or `tests/` | Raises `Path ... is outside the training allowlist`; **no write** |
| `path` escapes the repo (`../x`) | Raises `Path escapes repository`; **no write** |
| `path` is a **file that does not exist** | Fails (the tool reads before it writes). **It cannot create files.** |

> ⚠️ **Practical consequence:** you cannot create `tests/test_firmware_compat.py` with this tool. Add the new tests to the **existing** files (`tests/test_api.py` and `tests/ui/smoke.spec.ts`) by anchoring on a unique existing line. This is part of the point: the tool's narrowness is a feature, and you have to design your change to fit it.

### Step 4.1 — Provoke the guardrails first (10 minutes, BEFORE vs. AFTER governance)

This step makes the governance value visible. Ask Copilot to run each of the following **through `apply_repo_patch`** and report the raw result:

```text
Call apply_repo_patch three times, exactly as written, and show me each raw result:
1) path="mcp_server/data/compatibility.json", old_text="2.0.0", new_text="2.0.1"
2) path="../outside.txt", old_text="a", new_text="b"
3) path="app/main.py", old_text="this text does not exist", new_text="x"
```

Expected:

| # | Attempt | Expected outcome | What it proves |
|---|---|---|---|
| 1 | Edit the compatibility data | Refused: *outside the training allowlist* | The assistant **cannot rewrite the rules to make its own change pass**. |
| 2 | Escape the repo | Refused: *Path escapes repository* | No traversal beyond the project. |
| 3 | Non-existent text | `ok: false`, *found 0* | No silent, partial, or guessed edits. |

Then verify nothing changed: `git status` should show a clean tree.

**BEFORE (built-in editor):** the same assistant, using the normal edit tool, *could* have edited `compatibility.json` or `server.py`. Nothing in the workspace would stop it. **AFTER:** the policy lives in code the organization owns (`ALLOWED_PREFIXES`, `safe_path`), and the model cannot negotiate with it.

### Step 4.2 — Write the failing API acceptance tests (red)

Prompt:

```text
Following the plan, add API acceptance tests to tests/test_api.py using apply_repo_patch only.
Anchor on the existing line `def test_starter_accepts_known_good_version()` so the patch matches exactly once.
Add tests that assert, for ProLiant DL360 Gen11:
 - target_version "2.0.0" returns 409 and the response detail contains "Gen12 lab hardware only"
 - target_version "1.2.0" returns 200
 - target_version "1.3.0" returns 200
 - target_version "9.9.9" returns 409
 - after a rejected request, GET /api/system still shows target_firmware as null
Do not change or delete existing tests. Do not touch app/ yet.
```

Run the tests yourself:

```powershell
pytest -q
```

**Expected: the new rejection tests FAIL**, because the starter returns 200 for everything. Typical failure:

```text
assert 200 == 409
```

> A test that passes before the fix proves nothing. If your rejection tests pass, they are not testing what you think. Fix the tests before proceeding.

### Step 4.3 — Write the failing Playwright test (red)

Prompt:

```text
Add a Playwright test to tests/ui/smoke.spec.ts using apply_repo_patch only. It must:
 - call POST /lab/reset in a beforeEach so tests are independent
 - select 2.0.0, click "Schedule Update", and assert the #message text contains the Gen12 reason
   and does NOT contain "Update scheduled"
 - select 1.2.0, click "Schedule Update", and assert #message is "Update scheduled"
Use stable locators (#target, #update, #message).
```

Run it:

```powershell
npx playwright test
```

**Expected: the 2.0.0 test FAILS** (message reads `Update scheduled`). The accept-path test and the original smoke test pass.

✅ **Checkpoint 4a:** red API test(s) and red UI test, for the right reason (200 instead of 409).

### Step 4.4 — Implement the fix (green)

Prompt:

```text
Now implement the feature in app/main.py using apply_repo_patch only (one small, exactly-matching patch per change).
Requirements:
 - Rules come from the MCP data we retrieved (Option <A or B>, as agreed in the plan).
 - In POST /api/firmware, validate BEFORE storing: if the target is not in the model's supported list, raise
   HTTPException(status_code=409, detail=<the note from the MCP data>).
 - Unknown version/model must also be rejected (fail closed).
 - Do not change /health, /api/system, /lab/reset or the HTML.
After each patch, report the apply_repo_patch result.
```

What to look for in the patches:

* Each `old_text` is small and unique; each result is `ok: true`.
* `from fastapi import FastAPI` becomes `from fastapi import FastAPI, HTTPException` (an import change is a classic missed step; if the app fails to import, you'll see it immediately).
* Validation happens **before** `SYSTEM['target_firmware']=...`.
* The UI needs **no** change: it already renders `b.detail` when `r.ok` is false. If Copilot proposes UI changes, ask it why.

### Step 4.5 — Inspect the diff

```powershell
git diff
```

Check: only `app/main.py`, `tests/test_api.py`, `tests/ui/smoke.spec.ts` changed. No change to `mcp_server/`, `work-items/`, or `.github/`.

✅ **Checkpoint 4b:** the diff touches only allowed files; every patch was an MCP call.

---

## 12. Part 5 — Verify with pytest and Playwright (2:20–2:50)

**Goal:** objective proof that `2.0.0` is rejected and `1.2.0` is accepted, from the API and from the browser.

### Step 5.1 — API tests

```powershell
pytest -q
```

Expected: all tests pass (the 2 starter tests plus your new ones).

### Step 5.2 — UI tests

```powershell
npx playwright test
```

Playwright starts the app itself on `http://127.0.0.1:8000` (`reuseExistingServer: true`, so stop any other server on that port or let it reuse yours). Optional: `npm run test:ui:headed` to watch it.

### Step 5.3 — Manual proof (2 minutes)

With the app running, open `http://127.0.0.1:8000`:

| Action | Expected UI | Expected API |
|---|---|---|
| Select **2.0.0** → *Schedule Update* | Message: **2.0.0 is for Gen12 lab hardware only** | `409` |
| Select **1.2.0** → *Schedule Update* | Message: **Update scheduled** | `200` |
| Select **1.3.0** → *Schedule Update* | Message: **Update scheduled** | `200` (valid on DL360) |

Or from PowerShell:

```powershell
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/api/firmware -ContentType 'application/json' -Body '{"target_version":"2.0.0"}'   # expect HTTP 409
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/api/firmware -ContentType 'application/json' -Body '{"target_version":"1.2.0"}'   # expect accepted
```

### Step 5.4 — Cross-check against MCP (consistency proof)

```text
Call check_compatibility for ProLiant DL360 Gen11 with 2.0.0, 1.2.0 and 1.3.0, and confirm that the app's behaviour
matches each result exactly (status code and message).
```

### The Before → After result

| Request (DL360 Gen11) | BEFORE (starter) | AFTER (your work) |
|---|---|---|
| `2.0.0` | `200 accepted: true`, stored | `409`, reason shown, **nothing stored** |
| `1.2.0` | `200` | `200` |
| `1.3.0` | `200` | `200` |
| `9.9.9` | `200` (accepted!) | `409` |
| UI for `2.0.0` | "Update scheduled" | "2.0.0 is for Gen12 lab hardware only" |
| Tests covering this | none | API + Playwright, written before the fix |

✅ **Checkpoint 5:** pytest green, Playwright green, manual proof matches the table.

---

## 13. Part 6 — Review the tool trace and discuss governance (2:50–3:20)

**Goal:** be able to explain, with evidence, *which* calls were MCP vs. built-in and *why the patch allowlist is a governance control*.

### Step 6.1 — Classify the trace

Scroll through the Copilot Chat history and expand each tool call. Build this table (add rows as needed):

| # | Tool call (name + key args) | MCP or built-in? | Read / Write? | Purpose |
|---|---|---|---|---|
| 1 | `get_supported_firmware("ProLiant DL360 Gen11")` | MCP | Read | Source the facts |
| 2 | `check_compatibility(...)` | MCP | Read | Verify decisions |
| 3 | read/search `app/main.py` | built-in | Read | Understand code |
| 4 | `apply_repo_patch("tests/test_api.py", …)` | MCP | **Write** | Add red tests |
| 5 | `apply_repo_patch("app/main.py", …)` | MCP | **Write** | Implement fix |
| 6 | run `pytest` / `playwright` | built-in (terminal) | Read-only | Verify |
| … | | | | |

Then answer:

1. How many **write** calls were there, and were **all** of them `apply_repo_patch`? (If any built-in write occurred, the lab rule was broken. Note it and discuss why it happened.)
2. For every compatibility fact in your final code, which MCP call produced it?
3. Were there any refused or `ok:false` patches? What did Copilot do next? (Good behaviour: re-read, narrow the match, retry. Bad behaviour: switch to a built-in edit.)

### Step 6.2 — Why the allowlist is a governance control

Discuss in your team, using this frame:

| Control | Implementation in `server.py` | Risk it mitigates | Real-world analogue |
|---|---|---|---|
| **Path allowlist** (`ALLOWED_PREFIXES = ('app/', 'tests/')`) | `safe_path()` rejects anything else | AI edits CI pipelines, secrets, infrastructure code, or the rules data itself | Least privilege / protected paths in CODEOWNERS |
| **Traversal guard** | resolves the path and requires it under `REPO_ROOT` | `../../` escapes | Sandbox boundary |
| **Exact-one-match** | `count != 1` returns `ok:false` | Wrong-region edits, mass replacements, hallucinated context | Optimistic concurrency / compare-and-swap |
| **Separation of duties** | Rules (`compatibility.json`) are outside the writable zone | AI "fixing" a failing check by changing the rule | Maker–checker |
| **Central, versioned policy** | One file, reviewed like code | Per-developer, per-prompt rules | Policy-as-code |
| **Visible, per-call confirmation + trace** | VS Code tool prompts and chat log | Silent actions | Audit logging |

Prompts for discussion:

* What would you add to this allowlist in your own organization? (e.g. deny `*.env`, `infra/`, `.github/workflows/`, require a ticket ID argument.)
* This tool allows editing `tests/`. What stops the assistant from **weakening a test** to make it pass? (Answer: nothing technical here; it's `copilot-instructions.md` plus human diff review. What additional control would you want?)
* The allowlist is a **training** allowlist. What would a production version need? (Authentication, per-user scopes, rate limits, dry-run mode, approvals, structured audit log shipped to your SIEM.)
* Where else in your organization is there "facts the model must not guess"? (Part numbers, entitlement, pricing, regulatory limits, runbooks.)

### Step 6.3 — Summarise the value

Complete this sentence as a team and share it:

> "Before MCP, Copilot could *<…>*. With our MCP server, Copilot can *<…>* but is prevented from *<…>*, and we can prove it by *<…>*."

✅ **Checkpoint 6:** completed trace table and governance discussion notes.

---

## 14. Part 7 — Commit and open the PR

1. Check what will be committed:

   ```bash
   git status
   git diff --stat
   ```

   Expected files: `app/main.py`, `tests/test_api.py`, `tests/ui/smoke.spec.ts`. Do **not** commit `.vscode/mcp.json`, `.venv/`, or `node_modules/`.
2. Create a branch, commit, push:

   ```bash
   git switch -c feature/mp2-firmware-compat
   git add app tests
   git commit -m "feat: reject incompatible firmware updates (409) using MCP-sourced rules"
   git push -u origin feature/mp2-firmware-compat
   ```
3. Open a PR into `main` and include, per `copilot-instructions.md`:
   * **Files changed**
   * **Tests run** (paste the pytest and Playwright summaries)
   * **Assumptions** (e.g. Option A/B choice; unknown versions are rejected)
   * **Risks** (e.g. embedded facts may drift from `compatibility.json`; only DL360 is exercised by the UI)
   * **MCP evidence:** the key `get_supported_firmware` / `check_compatibility` results and a count of `apply_repo_patch` calls
4. **Stop here.** Do not merge or deploy; a human reviews the diff and evidence.

---

## 15. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `hpe-firmware` shows **Error**, or tools list is empty | Wrong path in `mcp.json`; single backslashes; placeholders left in | Use double backslashes, a full absolute path, and confirm both files exist. Restart via `MCP: List Servers`. |
| `ModuleNotFoundError: No module named 'mcp'` in MCP output | `command` points to system Python | Point `command` to `.venv\Scripts\python.exe`; re-run `pip install -r requirements.txt` in the venv. |
| Tools don't appear in Chat | Chat is not in **Agent** mode, or tools are unticked | Switch to Agent; open the Tools picker and tick `hpe-firmware`. |
| `Activate.ps1 cannot be loaded` | PowerShell execution policy | `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` |
| `apply_repo_patch` → `found 0` | `old_text` differs in whitespace, quotes, or line endings from the file | Have Copilot re-read the exact lines (the starter is written in a compact style) and copy them verbatim. |
| `apply_repo_patch` → `found 2` (or more) | Anchor is not unique | Include more surrounding lines to make it unique. |
| "Cannot create file" when adding a new test file | The tool edits existing files only | Add tests to `tests/test_api.py` / `tests/ui/smoke.spec.ts`. |
| Copilot keeps using the built-in editor | Instruction not explicit | Re-state the rule; untick the editing tools in the Tools picker if your VS Code version allows it. |
| Playwright: `ECONNREFUSED` or timeout | Port 8000 busy or app crashed | Stop other servers on 8000, or run the app yourself and set `BASE_URL`. |
| UI test sees stale "Update scheduled" | State left over from a previous test | Call `POST /lab/reset` in `beforeEach`. |
| After the fix, **all** updates return 500 | Missing `HTTPException` import, or rule lookup raised for the unknown model | Read the traceback in the uvicorn terminal; patch the import / handle `None` (fail closed with 409). |
| UI shows `Rejected` instead of the reason | Response body lacks `detail` | Use `HTTPException(status_code=409, detail="...")` (FastAPI puts it in `detail`). |

---

## 16. Stretch goals

(Still only via `apply_repo_patch`.)

1. **Model-aware API:** make `POST /api/firmware` look up the rules by `SYSTEM['model']`, then add a test that swaps the model to `ProLiant DL380 Gen11` and proves `1.3.0` is **rejected** while `1.1.5` is accepted.
2. **Expose the rules:** add `GET /api/firmware/supported` returning the supported list so the UI dropdown only offers valid options (keep the server-side 409 as the real guard).
3. **Add a fourth MCP tool** in `mcp_server/server.py` (e.g. `list_models`). Note that you'll need the *built-in* editor for this because `mcp_server/` is outside the allowlist, which is the governance boundary working as intended. Discuss who should be allowed to do this in a real organization.
4. **Tighten the gate:** propose (don't implement) two more guardrails for `apply_repo_patch` (e.g. maximum patch size, blocklist for `.github/`).

---

## 17. Reflection questions

1. Which facts in this lab would have been wrong if the model had answered from memory? What would that have cost in production?
2. Why is it better to have the rule in `compatibility.json` rather than in a prompt or a code comment?
3. What is the difference between *access to a tool* and *permission to use it for anything*? Where was that difference visible today?
4. Which of today's controls are technical (enforced by code) and which are procedural (enforced by instructions and review)? Which would you strengthen first?
5. What other internal system in your organization would be the first candidate for an MCP server, and what would be its **read** tools vs. **write** tools?

---

## 18. Facilitator appendix

### Timing notes

* Part 4 is the long one. If a team is behind at 2:00, tell them to skip the Playwright accept-path test and finish the reject-path test; Part 5 depends on that.
* Part 2's baseline is the highest-value 5 minutes of the lab. Don't let teams skip it.

### Expected shape of a correct solution (don't share before Part 5)

Application change (Option B shown; Option A swaps the `json.loads` for an inline dict):

```python
import json
from pathlib import Path
from fastapi import FastAPI, HTTPException
...
RULES = json.loads((Path(__file__).resolve().parents[1] / 'mcp_server' / 'data' / 'compatibility.json').read_text())

@app.post('/api/firmware')
def update_firmware(body: UpdateRequest):
    record = RULES.get(SYSTEM['model'])
    if not record or body.target_version not in record['supported']:
        reason = record['note'] if record else 'unknown model'
        raise HTTPException(status_code=409, detail=reason)
    SYSTEM['target_firmware'] = body.target_version
    return {'accepted': True, 'target_version': body.target_version}
```

Caveats to point out: for a version like `9.9.9`, the note ("2.0.0 is for Gen12…") is a slightly misleading reason. A strong solution distinguishes "blocked" (use the note) from "not in supported list" (use a generic message such as *"9.9.9 is not a supported version for <model>"*). Use that as a discussion point on message quality.

### Common good/bad behaviours to watch for

| Behaviour | Coaching |
|---|---|
| Copilot answers compatibility questions without calling a tool | Ask: "Which tool call is that from?" |
| Copilot silently switches to the built-in editor after a failed patch | Stop, restore with `git restore`, and restart Step 4.x with the rule restated |
| Tests edited to fit the implementation | Cite `copilot-instructions.md`: never weaken a valid test |
| Fix applied before tests | Revert, and redo test-first |

### Known limitations of the training server (worth discussing openly)

* `apply_repo_patch` cannot create files and has no authentication, size limit or audit log of its own.
* `check_compatibility` treats any version not in `supported` as incompatible, regardless of whether it is in `blocked`; `blocked` is informational.
* The allowlist uses simple prefix matching on `app/` and `tests/`.
* The app is not wired to MCP at runtime by design; MCP governs authoring, not production request handling.

### Reset between runs

```bash
git restore . && git clean -fd -e .venv -e node_modules
```

(Review `git status` first; `clean` deletes untracked files.)
