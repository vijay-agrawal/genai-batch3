# MP2 — Prevent incompatible firmware updates
Use the custom `hpe-firmware` MCP tools as the compatibility source of truth. Reject incompatible targets with HTTP 409, explain the reason in the UI, and add API + Playwright tests. For this exercise, production/test file modifications must be performed through MCP `apply_repo_patch`, not the normal edit tool.
