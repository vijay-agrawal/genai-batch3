from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
app=FastAPI(title='Firmware Update Console')
SYSTEM={'model':'ProLiant DL360 Gen11','current_firmware':'1.1.0','target_firmware':None}
class UpdateRequest(BaseModel): target_version:str
@app.get('/health')
def health(): return {'status':'ok'}
@app.get('/api/system')
def system(): return SYSTEM
@app.post('/api/firmware')
def update_firmware(body:UpdateRequest):
    SYSTEM['target_firmware']=body.target_version
    return {'accepted':True,'target_version':body.target_version}
@app.post('/lab/reset')
def reset(): SYSTEM['target_firmware']=None; return SYSTEM
@app.get('/',response_class=HTMLResponse)
def home():
    return HTMLResponse('''<!doctype html><html><head><meta charset='utf-8'><title>Firmware Console</title><style>body{font-family:Arial;margin:40px;max-width:720px}select,button{padding:9px;margin:6px}.msg{font-weight:600;margin-top:12px}</style></head><body>
<h1>Firmware Update Console</h1><p>Model: <strong id='model'></strong></p><p>Current: <span id='current'></span></p>
<label for='target'>Target firmware</label><select id='target'><option>1.2.0</option><option>1.3.0</option><option>2.0.0</option></select><button id='update'>Schedule Update</button><div id='message' class='msg'></div>
<script>async function load(){const s=await (await fetch('/api/system')).json();model.textContent=s.model;current.textContent=s.current_firmware;}update.onclick=async()=>{const r=await fetch('/api/firmware',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target_version:target.value})});const b=await r.json();message.textContent=r.ok?'Update scheduled':(b.detail||'Rejected');};load();</script></body></html>''')
