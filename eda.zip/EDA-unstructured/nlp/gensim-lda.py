import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from gensim import corpora
from gensim.models import LdaModel
from wordcloud import WordCloud

# Sample documents
documents = [
    "Apple releases a new iPhone while Tesla launches an electric car.",
    "The stock market is seeing a downturn due to inflation concerns.",
    "Tesla and other automakers are focusing on electric vehicles.",
    "Technology companies like Apple and Google are investing in AI.",
    "The economy is affected by rising interest rates and inflation.",
    "AI is transforming the way companies operate and innovate.",
    "New government policies impact the automobile industry.",
    "Machine learning and AI are the future of technology."
]

# Preprocessing: Tokenize and lowercase
texts = [[word.lower() for word in doc.split()] for doc in documents]

# Create a dictionary and corpus
dictionary = corpora.Dictionary(texts)
corpus = [dictionary.doc2bow(text) for text in texts]

# Train LDA model (2 topics for demonstration)
lda_model = LdaModel(corpus, num_topics=2, id2word=dictionary, passes=10, random_state=42)

# Extract topics
topics = lda_model.print_topics(num_words=5)
topics_df = pd.DataFrame({"Topic": [f"Topic {i+1}" for i in range(len(topics))], 
                          "Words": [topic[1] for topic in topics]})

# Display extracted topics
print("\nExtracted Topics:")
print(topics_df)

# Generate word clouds for topics
fig, axes = plt.subplots(1, 2, figsize=(12, 6))
for i, topic in enumerate(lda_model.show_topics(num_topics=2, num_words=10, formatted=False)):
    topic_words = dict(topic[1])
    wordcloud = WordCloud(width=400, height=400, background_color='white').generate_from_frequencies(topic_words)
    axes[i].imshow(wordcloud, interpolation='bilinear')
    axes[i].set_title(f"Topic {i+1}")
    axes[i].axis("off")

plt.show()
