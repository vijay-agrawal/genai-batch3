import numpy as np
import matplotlib.pyplot as plt
from skimage import data, img_as_float

# ------------------------------------------------------------------------------
# 1. Load a Sample Image and Simulate a Non-Normalized Version
# ------------------------------------------------------------------------------
# Load the "astronaut" image (originally float in [0,1]) and simulate an 8-bit image.
image = img_as_float(data.astronaut())
# Simulate an 8-bit version: values in the range 0-255
image_8bit = (image * 255).astype(np.uint8)
# Convert back to float64 without scaling back to [0,1]
# (This simulates an image in the 0-255 range that needs normalization.)
image_float = image_8bit.astype(np.float64)

print("Before normalization: min =", np.min(image_float), ", max =", np.max(image_float))

# ------------------------------------------------------------------------------
# 2. Normalization Techniques
# ------------------------------------------------------------------------------

# Technique 1: Global Min-Max Normalization
global_min = np.min(image_float)
global_max = np.max(image_float)
normalized_global = (image_float - global_min) / (global_max - global_min)

# Technique 2: Channel-wise Min-Max Normalization
normalized_channel = np.zeros_like(image_float)
for c in range(image_float.shape[2]):
    channel = image_float[..., c]
    channel_min = channel.min()
    channel_max = channel.max()
    normalized_channel[..., c] = (channel - channel_min) / (channel_max - channel_min)

# Technique 3: Robust Normalization Using Percentiles (e.g., 2nd to 98th percentile)
p_low, p_high = np.percentile(image_float, (2, 98))
# Clip values outside the 2nd and 98th percentiles, then normalize.
robust_normalized = np.clip(image_float, p_low, p_high)
robust_normalized = (robust_normalized - p_low) / (p_high - p_low)

# Technique 4: Unit Vector Normalization
# For each pixel, compute the L2 norm (across channels) and divide the pixel by that norm.
# (A small epsilon is added to avoid division by zero.)
epsilon = 1e-8
norm = np.linalg.norm(image_float, axis=2, keepdims=True)
unit_vector_normalized = image_float / (norm + epsilon)

# ------------------------------------------------------------------------------
# 3. Plotting the Results
# ------------------------------------------------------------------------------
fig, axes = plt.subplots(2, 3, figsize=(18, 12))
axes = axes.flatten()

# Original simulated 8-bit image (0-255 scale)
axes[0].imshow(image_8bit, cmap='gray')
axes[0].set_title("Original (Simulated 8-bit, 0-255)")
axes[0].axis('off')

# Global Min-Max Normalization
axes[1].imshow(normalized_global)
axes[1].set_title("Global Min-Max Normalization")
axes[1].axis('off')

# Channel-wise Min-Max Normalization
axes[2].imshow(normalized_channel)
axes[2].set_title("Channel-wise Min-Max Normalization")
axes[2].axis('off')

# Robust Normalization (2nd to 98th Percentile)
axes[3].imshow(robust_normalized)
axes[3].set_title("Robust Normalization (2-98 Percentile)")
axes[3].axis('off')

# Unit Vector Normalization (per-pixel normalization)
axes[4].imshow(unit_vector_normalized)
axes[4].set_title("Unit Vector Normalization")
axes[4].axis('off')

# Leave one subplot empty (or you could add another method)
axes[5].axis('off')

plt.tight_layout()
plt.show()
