import numpy as np
import matplotlib.pyplot as plt

from skimage import data, color, exposure, transform, img_as_float

# 1. Load a Sample Image
# Use the "astronaut" image from skimage and convert it to float [0,1]
image = img_as_float(data.astronaut())
# Also get a grayscale version
gray = color.rgb2gray(image)

# 2. Spatial Standardization: Resize
# Resize the image to 256x256 for consistency.
resized_image = transform.resize(image, (256, 256), anti_aliasing=True)
resized_gray = transform.resize(gray, (256, 256), anti_aliasing=True)

# 3. Intensity Normalization

## a. Min-Max Normalization
# Simulate an 8-bit image (range 0-255), then normalize back to [0, 1]
image_uint8 = (resized_image * 255).astype(np.uint8)
min_val = np.min(image_uint8)
max_val = np.max(image_uint8)
norm_image = (image_uint8 - min_val) / (max_val - min_val)

## b. Standardization (Z-score normalization)
# Compute the mean and std of the grayscale image and apply z-score normalization.
mean_val = np.mean(resized_gray)
std_val = np.std(resized_gray)
standardized_image = (resized_gray - mean_val) / std_val

# 4. Contrast Enhancement

## a. Histogram Equalization
hist_eq_image = exposure.equalize_hist(resized_gray)

## b. Adaptive Histogram Equalization (CLAHE)
clahe_image = exposure.equalize_adapthist(resized_gray, clip_limit=0.03)

# 5. Color and Illumination Standardization

## a. Color Space Conversion: RGB to Lab (we show the L channel)
lab_image = color.rgb2lab(resized_image)
l_channel = lab_image[:, :, 0]

## b. Gamma Correction
def gamma_correction(img, gamma=2.2):
    # Assumes the image is in [0,1]; applies the inverse gamma curve.
    return np.power(img, 1 / gamma)

gamma_corrected_image = gamma_correction(resized_image, gamma=2.2)

# 6. Spatial Standardization: Cropping
def center_crop(img, new_size):
    h, w = img.shape[:2]
    new_h, new_w = new_size
    start_h = (h - new_h) // 2
    start_w = (w - new_w) // 2
    return img[start_h:start_h+new_h, start_w:start_w+new_w]

cropped_image = center_crop(resized_image, (128, 128))

# 7. Plotting the Results
fig, axes = plt.subplots(3, 3, figsize=(15, 15))
axes = axes.flatten()

axes[0].imshow(image)
axes[0].set_title("Original Astronaut")
axes[0].axis('off')

axes[1].imshow(resized_image)
axes[1].set_title("Resized to 256x256")
axes[1].axis('off')

axes[2].imshow(norm_image, cmap='gray')
axes[2].set_title("Min-Max Normalized (simulated 8-bit)")
axes[2].axis('off')

axes[3].imshow(standardized_image, cmap='gray')
axes[3].set_title("Standardized (Z-score)")
axes[3].axis('off')

axes[4].imshow(hist_eq_image, cmap='gray')
axes[4].set_title("Histogram Equalization")
axes[4].axis('off')

axes[5].imshow(clahe_image, cmap='gray')
axes[5].set_title("Adaptive Hist. Equalization (CLAHE)")
axes[5].axis('off')

axes[6].imshow(l_channel, cmap='gray')
axes[6].set_title("L Channel (RGB to Lab)")
axes[6].axis('off')

axes[7].imshow(gamma_corrected_image)
axes[7].set_title("Gamma Corrected (γ=2.2)")
axes[7].axis('off')

axes[8].imshow(cropped_image)
axes[8].set_title("Center Crop (128x128)")
axes[8].axis('off')

plt.tight_layout()
plt.show()
